import React ,{ useState, useEffect } from 'react'  
import { BrowserRouter} from 'react-router-dom';
import Header from './views/Header';
import Sidenav from './views/Sidenav'; 
import Router from './routes/Router'; 
import './styles/scss/globalstyles.scss';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

function App() {
  const [currPath, setCurrPath] = useState(window.location.pathname)
  useEffect(() => {
    setCurrPath(window.location.pathname)
}, [])

function isAuthRoutes(path){

  return ['/login','/public/email-validate','/signup','/public/reset-password','/forgotpassword'].findIndex((item)=>item==path)>-1
}


  return (
    <React.Fragment>       
      <BrowserRouter>
          <div className='wrapper'>
            <Header/>             
            <div className='bodylayout'>
           {/*  {currPath !== '/login' && <><Sidenav /></>}*/}
           {!isAuthRoutes(currPath) && <Sidenav />}
              <div className='maincontent'>
                <Router/>
              </div>      
            </div>  
          </div>         
      </BrowserRouter> 
      <ToastContainer
        // position="bottom-right"
        // autoClose={3000}
        // hideProgressBar={true}
        // closeOnClick
        // draggable
      />
    </React.Fragment>
  );
}

export default App;
