import React, { useState,useEffect,useRef } from 'react'; 
import Grid from '@mui/material/Grid';
import { DropzoneArea } from 'material-ui-dropzone';
import { AttachFile } from '@material-ui/icons';
import{isEmpty} from "./Utils";
import { EndPointService } from '../services/endPointServices';
import "react-datepicker/dist/react-datepicker.css";
import Loader from '../images/loader.gif';
import { Controller,useForm } from 'react-hook-form';
import { StorageService } from '../services/storageService';
function UploadFileComponent({label,className,showPreviews,filesLimit,dropzoneText,Icon,showPreviewsInDropzone,
    previewGridProps,register,errorText,fieldName,errors,handleSelectedFile,id,isRequired,control,isValidationRequired}) {
    const [isLoading, setIsLoading] = useState(false);
    const [userData, setUserData] = useState(null);
    const dropzoneRef = useRef(id)
    useEffect(() => {
        const storageService = new StorageService();
        const userinfoData=JSON.parse(storageService.get("userinfo"))
        setUserData(userinfoData)
        
      },[]);

    function uploadFiles(file){
        setIsLoading(true)
        const endpointService = new EndPointService();
            const formData = new FormData();
          file.forEach((fileItem) => {
            formData.append('file', fileItem);
          });
          formData.append('secureType', 'private');
         // alert(JSON.stringify(userData.accessToken))  
          //console.log("userData.userData",userData)  
        fetch(endpointService.getUpload(), {
            method: 'POST',
            headers: {
                'Authorization':'Bearer ' + userData.accessToken,
                //'Authorization': 'Bearer ' +"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2NGIwZTY2YmRiMzA0NDFkNjQ4ZmRmMzQiLCJlbWFpbCI6ImVzdHJva2VzbG9jYWxAeW9wbWFpbC5jb20iLCJuYW1lIjoiRGlsZWVwIE0iLCJyb2xlSWQiOjIsInJvbGVOYW1lIjoiQWRtaW4iLCJzdGF0dXNJZCI6MiwiY29tcGFueUlkIjoiNjRiMGU2NmNkYjMwNDQxZDY0OGZkZjM4IiwidmVyc2lvbklkIjoiMS4wIiwiYWRtaW5Qb3BydGFsIjp0cnVlLCJpYXQiOjE2ODkzMTU0NDl9.sq-oVZcLD8JumvtHB7E6WHkYdSYuuM4vkj2pDOLpbQk",
            },
            body:formData
        })
            .then(response => response.json())
            .then((responseJson) => {
                setIsLoading(false)
                if(responseJson.status==="Success"){
                    handleSelectedFile(responseJson.result)
                }
            })
            .catch((error) => {
                console.error("ErrorMessage",error);
            });
        
    }
    const validateFile = (value) => {
        //console.log
        if (!value || value.length === 0) {
          return errorText + ' is reqired';
        }
        return true;
    };
    return (
        <div>   
                <label>{label}</label>
                <div className='file_upload_wrapper'>
                 <Controller
                        control={control}
                        name={fieldName}
                        variant="outlined"
                        rules={{ required: isValidationRequired?errorText + ' is reqired':false}}
                        render={({ field }) => (
                            <DropzoneArea
                            {...field}
                            ref={dropzoneRef}
                            className={className}
                            showPreviews={showPreviews}
                            filesLimit={filesLimit}
                            dropzoneText={dropzoneText}
                            Icon={Icon}
                            showPreviewsInDropzone={showPreviewsInDropzone}
                            previewGridProps={previewGridProps}
                            onDrop={(file)=>uploadFiles(file)}
                            id={id} />
                        )}
                    />
                  {isLoading&&(<div>
                    <span className='loader'>
                    <img src={Loader} alt='Loader' />
                </span>
                </div>)}  
                </div>
                 {isValidationRequired&&errors[fieldName] &&<span className='form_error'>{errors[fieldName].message}</span>}
        </div>
    )
}
export default UploadFileComponent;