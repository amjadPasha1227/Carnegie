import { ToastContainer, toast } from 'react-toastify'
//import 'react-toastify/dist/ReactToastify.css';
export function isEmpty(value) {
    if (value !== undefined && value !== null) {
        if (typeof (value) == 'string') {
            if (value.toString().trim() !== '' && value.toString().trim() !== 'null' && value.toString().trim() !== "") {
                return false
            }
        } else {
            if (value !== '' && value !== 'null' && value !== "")
                return false;
        }
    }
    return true;
}
export function showToast(message,type) {
 //alert(JSON.stringify(type))
//   toast(message, {
//     position: "top-right",
//     autoClose: 3000,
//     hideProgressBar: true,
//     closeOnClick: true,
//     draggable: true,
//     theme: "colored",
//   });success,error
  switch (type) {
    case "success":
      toast.success(message, {
            position: "top-right",
            autoClose: 3000,
            hideProgressBar: true,
            closeOnClick: true,
            draggable: true,
            theme: "colored",
          });
      break;
    case "error":
      toast.error(message, {
        position: "top-right",
        autoClose: 3000,
        hideProgressBar: true,
        closeOnClick: true,
        draggable: true,
        theme: "colored",
      });;
      break;
    default:
      toast(message, {
        position: "top-right",
        autoClose: 3000,
        hideProgressBar: true,
        closeOnClick: true,
        draggable: true,
        theme: "colored",
      });;
      break;
  }
}