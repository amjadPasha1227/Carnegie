import React from 'react';
import { useForm, Controller } from 'react-hook-form'
import '../styles/scss/templates.scss';
import '../styles/scss/settings.scss';
import '../styles/scss/modal.scss';

import { NavLink } from 'react-router-dom';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import Tooltip from '@mui/material/Tooltip';
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import { EndPointService } from '../services/endPointServices';
import { FetchService } from '../services/fetchServices';
import { DateUtilService } from '../services/dateUtilService';
import { StorageService } from '../services/storageService';
import { ToastContainer, toast } from 'react-toastify';
import Close from '../images/x-mark.svg'
import Simpleinput from './components/simpleInput';
import UploadFileComponent from './UploadFileComponent.js';
import { AttachFile, Details } from '@material-ui/icons';
import { useEffect } from 'react';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import OutlinedInput from '@mui/material/OutlinedInput';
import { makeStyles } from "@material-ui/core/styles";
import { TextField } from '@mui/material';
import NoData from './components/noData';
import Pagination from '@mui/material/Pagination';


function documentsData(name, owner, createdate, date,) {
    return { name, owner, createdate, date, };
}

const rows = [
    documentsData(' Mobile Project Agreement', 'Ravi Kumar', '05 Dec 2022', '05 Dec 2022'),
    documentsData(' NDA Agreement', 'Joseph', '10 Dec 2022', '10 Dec 2022'),
    documentsData(' Mobile Project Agreement', 'Ravi Kumar', '05 Dec 2022', '05 Dec 2022'),
    documentsData(' NDA Agreement', 'Joseph', '10 Dec 2022', '10 Dec 2022'),
];


function Mytemplates() {
    const [modaluploadTemplateOpen, setModalUploadTemp] = React.useState(false)
    const [myTemplateList, setMyTemplateList] = React.useState([])
    const [showNoData, setShowNoData] = React.useState(true)
    const [tplDetails, setTplDetails] = React.useState({})
    const [modalStatusChangeOpen, setModalStatusChangeOpen] = React.useState(false)
    const [modalUpdateDetailsOpen, setModalUpdateDetailsOpen] = React.useState(false)
    const [uploadTemplateData, setUploadTemplateData] = React.useState({
        name: "",
        pages: [],
        fields: [],
        tplType: "",
        document: null,
        companyId: ""
    })
    const [updateTemplateData, setUpdateTemplateData] = React.useState({
        name: "",
        pages: [],
        fields: [],
        tplType: "",
        companyId: ""
    })
    const [paginationProps, setPaginationProps] = React.useState({
        count: 1,
    })
    const [searchfilters, setFilters] = React.useState({
        filters: {
            title: "",
            typeIds: [],
            createdByIds: [],
            createdOnRange: []
        },
        sorting: {
            path: "statusName", // name, customId, createdByName, createdOn, updatedOn
            order: 1
        },
        page: 1,
        perpage: 5
    })
    const [companiesList, setCompaniesList] = React.useState([])
    const { register, handleSubmit, formState: { errors }, clearErrors, control } = useForm();
    const { register: register2, handleSubmit: handleSubmit2, formState: { errors: errors2 }, reset, clearErrors: clearErrors2, control: control2 } = useForm({
        mode: 'onChange',
        defaultValues: updateTemplateData
    });

    const [fileValidation, setFileValidation] = React.useState(false);
    const [fieldsList, setFieldsList] = React.useState([])
    const [statusChangeData, setStatusChangeData] = React.useState({
        templateId: "",
        statusId: "",
        statusName: ""
    })

    const registerOption = {
        name: {
            required: {
                value: true,
                message: "Please enter Template Name."
            },
            type: 'text'
        },
        companyId: {
            required: {
                value: false,
                message: "Please Select a Company."
            },
            type: 'text'
        },
        tplType: {
            required: {
                value: true,
                message: "Please Select a Template type"
            },
            type: "text"
        },
        fields: {
            required: {
                value: true,
                message: "Please Select a field"
            },
            type: "text"
        }
    }
    const dateUtilService = new DateUtilService();
    useEffect(() => {
        getCompaniesList()
        getFieldsList()
        getTemplateList()
        // getMyTemplateDetails()
    }, [modaluploadTemplateOpen, searchfilters, modalUpdateDetailsOpen, modalStatusChangeOpen])


    // const templateUploadFormFields = [
    //     { name: "name", label: "Template Name", placeholder: "Template Name", isRequired: true,errorText: "Template Name", helperText: "", md: 12, xs: 12 },
    //     { name: "pages", label: "pages", placeholder: "pages", isRequired: true,errorText: "pages", helperText: "", md: 6, xs: 6 },
    //     { name: "fields", label: "fields", placeholder: "fields", isRequired: true,errorText: "fields", helperText: "", md: 6, xs: 6 },
    //     { name: "tplType", label: "Template Type", placeholder: "Template Type", isRequired: true,errorText: "Template Type", helperText: "", md: 6, xs: 6 },
    //     { name: "document", label: "Document", placeholder: "Document", isRequired: true,errorText: "Document", helperText: "", md: 6, xs: 6 },
    //     { name: "companyId", label: "Company", placeHolder: "Company",isRequired: true, errorText: "Company", helperText: "", md: 6, xs: 6 }

    // ]

    const tplTypeList = [
        {
            _id: 1,
            type: 1,
            name: "Type 1"
        },
        {
            _id: 2,
            type: 2,
            name: "Type 2"
        }
    ]

    const usePlaceholderStyles = makeStyles(theme => ({
        placeholder: {
            color: "#aaa"
        }
    }));

    const Placeholder = ({ children }) => {
        const classes = usePlaceholderStyles();
        return <div className={classes.placeholder}>{children}</div>;
    };


    const getAccessToken = () => {
        const storageService = new StorageService();
        return (storageService.get() === "undefined") ? "" : JSON.parse(storageService.get("userinfo")).accessToken
    }

    //get Template List
    const getTemplateList = () => {
        // console.log("request starting Template list.................")
        const endpointService = new EndPointService();
        const fetchService = new FetchService();
        const token = getAccessToken()
        fetchService.post({
            url: endpointService.getTemplateListUrl(),
            headers: token,
            data: searchfilters
        })
            .subscribe(
                //onNext callback
                (response) => {
                    if (response.status_code === 200) {
                        let { list, totalCount, perpage } = response.result
                        let count = Math.ceil(totalCount / perpage)
                        setPaginationProps((prev) => ({ ...prev, count }))
                        setMyTemplateList(list)
                        if (totalCount) {
                            setShowNoData(false)
                        }
                        else {
                            setShowNoData(true)
                        }
                    }
                    else {
                        let { message, error } = response.result.error_message
                        setMyTemplateList([])
                        setShowNoData(true)
                    }
                },
                //onError callback
                (error) => {
                    console.error("There has been an error", error);

                }
            );
    }
    console.log("myTemplateList ", myTemplateList )
    console.log("setShowNoData   ",showNoData)

    //FIELDS LIST
    const getFieldsList = () => {
        //console.log("request starting for fields list.................")
        const endpointService = new EndPointService();
        const fetchService = new FetchService();
        const token = getAccessToken()
        fetchService.post({
            url: endpointService.getFieldsListUrl(),
            headers: token,
            data: {
                matcher: {
                    title: "",
                    cntryIds: [],
                    stateIds: []
                },
                category: "template_field", //template_field, company_status, city, state, country,  user_role, user_status, 
                page: 1,
                perpage: 500
            }

        })
            .subscribe(
                //onNext callback
                (response) => {
                    if (response.status_code === 200) {
                        setFieldsList(response.result.list)
                    }
                    else {
                        let { message, error } = response.result.error_message
                        setFieldsList([])
                    }
                },
                //onError callback
                (error) => {
                    console.error("There has been an error", error);

                }
            );
    }


    //companies list
    const getCompaniesList = () => {
        // console.log("request starting for companies list.................")
        const endpointService = new EndPointService();
        const fetchService = new FetchService();
        const token = getAccessToken()
        fetchService.post({
            url: endpointService.getCompaniesListUrl(),
            headers: token,
            data: {
                page: 1,
                perpage: 500,
                filters: {
                    title: "",
                    statusIds: [],
                    createdByIds: [],
                    createdOnRange: []
                },
                sorting: {
                    path: "createdOn", // statusName,createdByName, name, email, phone, createdOn, updatedOn
                    order: -1
                }
            }
        })
            .subscribe(
                //onNext callback
                (response) => {
                    if (response.status_code === 200) {
                        setCompaniesList(response.result.list)
                    }
                    else {
                        let { message, error } = response.result.error_message
                        setCompaniesList([])
                    }
                },
                //onError callback
                (error) => {
                    console.error("There has been an error", error);

                }
            );
    }

    //to upload template 
    const uploadTemplateApi = () => {
        // console.log("request starting for upload template .................", uploadTemplateData)
        const endpointService = new EndPointService();
        const fetchService = new FetchService();
        const dateUtilService = new DateUtilService();
        const token = getAccessToken()
        const { name, pages, fields, tplType, document, companyId } = uploadTemplateData
        fetchService.post({
            url: endpointService.getTemplateCreateUrl(),
            headers: token,
            data: {
                name,
                pages: [{
                    html: "<!DOCTYPE html><html lang=\"en\"><head><title>{title}</title><meta name=\"keywords\" content=\"Lorem Ipsum, Lipsum, Lorem, Ipsum, Text, Generate, Generator, Facts, Information, What, Why, Where, Dummy Text, Typesetting, Printing, de Finibus, Bonorum et Malorum, de Finibus Bonorum et Malorum, Extremes of Good and Evil, Cicero, Latin, Garbled, Scrambled, Lorem ipsum dolor sit amet, dolor, sit amet, consectetur, adipiscing, elit, sed, eiusmod, tempor, incididunt\" /><meta name=\"description\" content=\"Reference site about Lorem Ipsum, giving information on its origins, as well as a random Lipsum generator.\" /><meta name=\"viewport\" content=\"width=device-width,initial-scale=1.0\" /><meta http-equiv=\"content-type\" content=\"text/html; charset=utf-8\" /><link rel=\"icon\" type=\"image/x-icon\" href=\"favicon.ico\" /><style>@import url(https://fonts.googleapis.com/css?family=Open+Sans:400,700);@font-face{font-family:DauphinPlain;src:url(/fonts/DauphinPlain.eot?#iefix) format('embedded-opentype'),url(/fonts/DauphinPlain.woff) format('woff'),url(/fonts/DauphinPlain.ttf) format('truetype'),url(/fonts/DauphinPlain.svg#DauphinPlain) format('svg');font-weight:400;font-style:normal}body,html{margin:0;padding:0;font-family:'Open Sans',Arial,sans-serif;font-size:100%;font-size:14px;line-height:20px;-webkit-text-size-adjust:none}*{margin:0;padding:0}body{background:#fff}table{border-collapse:collapse;border-spacing:0}table,td,th{border:0}p{text-align:justify;margin:0 0 15px 0}h1,h2{font-weight:400;font-family:DauphinPlain}h3,h4,h5{font-weight:400}input,textarea{font-size:14px;font-family:'Open Sans',Arial,sans-serif}h1{font-size:70px;line-height:90px}h2{font-size:24px;line-height:24px;text-align:left;margin-bottom:10px}h3{margin:15px 0;font-size:14px;text-align:left;font-weight:700}h4{margin:10px 10px 5px 10px;font-size:14px;line-height:18px;text-align:center;font-style:italic}h5{margin:5px 10px 20px 10px;font-size:12px;line-height:14px;text-align:center}hr{clear:both;border:0;height:1px;background-image:linear-gradient(to right,rgba(0,0,0,0),rgba(0,0,0,.75),rgba(0,0,0,0))}#Outer{text-align:center}#Inner{width:960px;margin:0 auto}#Content{position:relative}#bannerL{position:sticky;position:-webkit-sticky;top:20px;width:160px;height:10px;margin-left:-160px;float:left;text-align:right}#bannerR{position:sticky;position:-webkit-sticky;top:20px;width:160px;height:10px;margin-right:-160px;float:right;text-align:left}.banner{margin:15px auto}#Translation{text-align:left;margin:0 3%}#Languages{margin:20px 15px 5px 15px;clear:both}#Languages a{padding:2px;font-size:12px;line-height:10px}#Languages a.zz,#Languages a.zz:hover{text-decoration:none;color:#000}div#Panes{margin-top:15px}#Panes>div{width:45.5%;text-align:left}#Panes>br{clear:both}#Panes>div:nth-of-type(odd){float:left;margin:0 1.5% 0 3%}#Panes>div:nth-of-type(even){float:right;margin:0 3% 0 1.5%}a:active,a:link,a:visited{color:#000}a:hover{color:#d00}#Packages a{margin:0 5px}#Footer a{margin:10px;color:grey;white-space:nowrap}#Footer{margin-bottom:10px}.lc{clear:left;float:left;width:348px}.rc{clear:right;float:right;width:348px}.lc div{float:left;text-align:left}.rc div{float:left;text-align:left}#lipsum{text-align:justify}#generated{font-weight:700;text-align:left}#lipsumTextarea{height:300px;width:98%;padding:3px 5px;border:1px solid #888;margin:5px 0}#cafepress{float:right;margin:0 0 15px 15px}#cafepress img{margin:0}.boxed{clear:both;margin:10px 3% 10px 3%}.boxed img{margin:10px 5px 0 5px;border:0}.boxedTight{clear:both;margin:10px 3% 10px 3%}.boxedTight img{margin:0;border:0}a.lnk:active,a.lnk:hover,a.lnk:link,a.lnk:visited{font-weight:700;color:#d00}form{margin-bottom:10px}input{margin:3px 6px}input#amount{width:30px;text-align:center;padding:3px 5px;border-width:1px;border-style:solid;border-color:#666 #ccc #ccc #666}input#generate{text-align:center;margin:10px 0 0 0;padding:3px 10px;border:1px solid #999;background:#eee;border-radius:4px;-webkit-appearance:none}input#generate:hover{background:#ccc;border:1px solid #666}label{cursor:pointer}td,th{padding:0}td{vertical-align:middle;text-align:center}td td{text-align:left}#Partner{text-align:left;margin:0 3%;padding:0}#Partner h1{font-family:'Open Sans',Arial,sans-serif;font-weight:700;font-size:20px;line-height:24px;margin:10px 0}#Partner h2{font-family:'Open Sans',Arial,sans-serif;font-weight:700;font-size:14px;line-height:18px;margin:10px 0}.ltr{direction:ltr;unicode-bidi:embed}@media screen and (max-width:1280px){#bannerL{display:none}#bannerR{display:none}}@media screen and (max-width:980px){#Inner{width:100%}}@media screen and (max-width:480px){h1{font-size:64px}#Panes>div{width:94%;clear:both;float:none}#Panes>div:nth-of-type(odd){float:none;margin:0 3%}#Panes>div:nth-of-type(even){float:none;margin:0 3%}#Panes>br{display:none}}@media screen and (max-width:350px){#Inner{width:320px}h1{font-size:58px}}</style></head><body><div id=\"Outer\"><div id=\"Inner\"><h1>Lorem Ipsum</h1><h4>\"Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit...\"</h4><h5>\"There is no one who loves pain itself, who seeks after it and wants to have it, simply because it is pain...\"</h5><hr /><div id=\"Content\"><div id=\"Panes\"><div><h2>{name}- {email}</h2><p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p></div><div><h2>{custom_field_1}</h2><p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p></div><br /><div><h2>Where does it come from?</h2><p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of \"de Finibus Bonorum et Malorum\" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.</p><p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from \"de Finibus Bonorum et Malorum\" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.</p></div><div><h2>Where can I get some?</h2><p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</p></div><br /></div></div></div></div></body></html>"
                }, {

                    html: "<!DOCTYPE html><html lang=\"en\"><head><title>{title}</title><meta name=\"keywords\" content=\"Lorem Ipsum, Lipsum, Lorem, Ipsum, Text, Generate, Generator, Facts, Information, What, Why, Where, Dummy Text, Typesetting, Printing, de Finibus, Bonorum et Malorum, de Finibus Bonorum et Malorum, Extremes of Good and Evil, Cicero, Latin, Garbled, Scrambled, Lorem ipsum dolor sit amet, dolor, sit amet, consectetur, adipiscing, elit, sed, eiusmod, tempor, incididunt\" /><meta name=\"description\" content=\"Reference site about Lorem Ipsum, giving information on its origins, as well as a random Lipsum generator.\" /><meta name=\"viewport\" content=\"width=device-width,initial-scale=1.0\" /><meta http-equiv=\"content-type\" content=\"text/html; charset=utf-8\" /><link rel=\"icon\" type=\"image/x-icon\" href=\"/favicon.ico\" /><style>@import url(https://fonts.googleapis.com/css?family=Open+Sans:400,700);@font-face{font-family:DauphinPlain;src:url(/fonts/DauphinPlain.eot?#iefix) format('embedded-opentype'),url(/fonts/DauphinPlain.woff) format('woff'),url(/fonts/DauphinPlain.ttf) format('truetype'),url(/fonts/DauphinPlain.svg#DauphinPlain) format('svg');font-weight:400;font-style:normal}body,html{margin:0;padding:0;font-family:'Open Sans',Arial,sans-serif;font-size:100%;font-size:14px;line-height:20px;-webkit-text-size-adjust:none}*{margin:0;padding:0}body{background:#fff}table{border-collapse:collapse;border-spacing:0}table,td,th{border:0}p{text-align:justify;margin:0 0 15px 0}h1,h2{font-weight:400;font-family:DauphinPlain}h3,h4,h5{font-weight:400}input,textarea{font-size:14px;font-family:'Open Sans',Arial,sans-serif}h1{font-size:70px;line-height:90px}h2{font-size:24px;line-height:24px;text-align:left;margin-bottom:10px}h3{margin:15px 0;font-size:14px;text-align:left;font-weight:700}h4{margin:10px 10px 5px 10px;font-size:14px;line-height:18px;text-align:center;font-style:italic}h5{margin:5px 10px 20px 10px;font-size:12px;line-height:14px;text-align:center}hr{clear:both;border:0;height:1px;background-image:linear-gradient(to right,rgba(0,0,0,0),rgba(0,0,0,.75),rgba(0,0,0,0))}#Outer{text-align:center}#Inner{width:960px;margin:0 auto}#Content{position:relative}#bannerL{position:sticky;position:-webkit-sticky;top:20px;width:160px;height:10px;margin-left:-160px;float:left;text-align:right}#bannerR{position:sticky;position:-webkit-sticky;top:20px;width:160px;height:10px;margin-right:-160px;float:right;text-align:left}.banner{margin:15px auto}#Translation{text-align:left;margin:0 3%}#Languages{margin:20px 15px 5px 15px;clear:both}#Languages a{padding:2px;font-size:12px;line-height:10px}#Languages a.zz,#Languages a.zz:hover{text-decoration:none;color:#000}div#Panes{margin-top:15px}#Panes>div{width:45.5%;text-align:left}#Panes>br{clear:both}#Panes>div:nth-of-type(odd){float:left;margin:0 1.5% 0 3%}#Panes>div:nth-of-type(even){float:right;margin:0 3% 0 1.5%}a:active,a:link,a:visited{color:#000}a:hover{color:#d00}#Packages a{margin:0 5px}#Footer a{margin:10px;color:grey;white-space:nowrap}#Footer{margin-bottom:10px}.lc{clear:left;float:left;width:348px}.rc{clear:right;float:right;width:348px}.lc div{float:left;text-align:left}.rc div{float:left;text-align:left}#lipsum{text-align:justify}#generated{font-weight:700;text-align:left}#lipsumTextarea{height:300px;width:98%;padding:3px 5px;border:1px solid #888;margin:5px 0}#cafepress{float:right;margin:0 0 15px 15px}#cafepress img{margin:0}.boxed{clear:both;margin:10px 3% 10px 3%}.boxed img{margin:10px 5px 0 5px;border:0}.boxedTight{clear:both;margin:10px 3% 10px 3%}.boxedTight img{margin:0;border:0}a.lnk:active,a.lnk:hover,a.lnk:link,a.lnk:visited{font-weight:700;color:#d00}form{margin-bottom:10px}input{margin:3px 6px}input#amount{width:30px;text-align:center;padding:3px 5px;border-width:1px;border-style:solid;border-color:#666 #ccc #ccc #666}input#generate{text-align:center;margin:10px 0 0 0;padding:3px 10px;border:1px solid #999;background:#eee;border-radius:4px;-webkit-appearance:none}input#generate:hover{background:#ccc;border:1px solid #666}label{cursor:pointer}td,th{padding:0}td{vertical-align:middle;text-align:center}td td{text-align:left}#Partner{text-align:left;margin:0 3%;padding:0}#Partner h1{font-family:'Open Sans',Arial,sans-serif;font-weight:700;font-size:20px;line-height:24px;margin:10px 0}#Partner h2{font-family:'Open Sans',Arial,sans-serif;font-weight:700;font-size:14px;line-height:18px;margin:10px 0}.ltr{direction:ltr;unicode-bidi:embed}@media screen and (max-width:1280px){#bannerL{display:none}#bannerR{display:none}}@media screen and (max-width:980px){#Inner{width:100%}}@media screen and (max-width:480px){h1{font-size:64px}#Panes>div{width:94%;clear:both;float:none}#Panes>div:nth-of-type(odd){float:none;margin:0 3%}#Panes>div:nth-of-type(even){float:none;margin:0 3%}#Panes>br{display:none}}@media screen and (max-width:350px){#Inner{width:320px}h1{font-size:58px}}</style></head><body><div id=\"Outer\"><div id=\"Inner\"><h1>Lorem Ipsum</h1><h4>\"Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit...\"</h4><h5>\"There is no one who loves pain itself, who seeks after it and wants to have it, simply because it is pain...\"</h5><hr /><div id=\"Content\"><div class=\"boxed\"><strong>Translations:</strong> Can you help translate this site into a foreign language ? Please email us with details if you can help.</div><hr /><div id=\"Lipsum-Unit5\" style=\"margin:10px 0\"></div><hr /><div id=\"Translation\"><h3>The standard Lorem Ipsum passage, used since the 1500s</h3><p>\"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\"</p><h3>Section 1.10.32 of \"de Finibus Bonorum et Malorum\", written by Cicero in 45 BC</h3><p>\"Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?\"</p><h3>{email} - {name}</h3><p>\"But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness. No one rejects, dislikes, or avoids pleasure itself, because it is pleasure, but because those who do not know how to pursue pleasure rationally encounter consequences that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure. To take a trivial example, which of us ever undertakes laborious physical exercise, except to obtain some advantage from it? But who has any right to find fault with a man who chooses to enjoy a pleasure that has no annoying consequences, or one who avoids a pain that produces no resultant pleasure?\"</p><h3>Section 1.10.33 of \"de Finibus Bonorum et Malorum\", written by Cicero in 45 BC</h3><p>\"At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.\"</p><h3>1914 translation by H. Rackham</h3><p>\"On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire, that they cannot foresee the pain and trouble that are bound to ensue; and equal blame belongs to those who fail in their duty through weakness of will, which is the same as saying through shrinking from toil and pain. These cases are perfectly simple and easy to distinguish. In a free hour, when our power of choice is untrammelled and when nothing prevents our being able to do what we like best, every pleasure is to be welcomed and every pain avoided. But in certain circumstances and owing to the claims of duty or the obligations of business it will frequently occur that pleasures have to be repudiated and annoyances accepted. The wise man therefore always holds in these matters to this principle of selection: he rejects pleasures to secure other greater pleasures, or else he endures pains to avoid worse pains.\"</p></div></div><hr /></div></div></body></html>"
                }],
                fields,
                tplType,
                document: document[0],
                companyId,
                timezone: dateUtilService.getTimeZone()
            }
        })
            .subscribe(
                //onNext callback
                (response) => {
                    if (response.status_code === 200) {
                        toast.success(response.result.message)
                        cancelUploadTemplate()
                    }
                    else {
                        let { message, error } = response.result.error_message
                        toast.error(message)
                    }

                },
                //onError callback
                (error) => {
                    console.error("There has been an error", error);
                    toast.error(error)
                }
            );
    }

    const cancelUploadTemplate = () => {
        setModalUploadTemp(false)

        setUploadTemplateData({
            name: "",
            pages: [],
            fields: [],
            tplType: "",
            document: {},
            companyId: ""
        })
        clearErrors()
    }


    //to get details of template
    const getMyTemplateDetails = (templateId) => {
        // console.log("request starting template Details.................", uploadTemplateData)
        const endpointService = new EndPointService();
        const fetchService = new FetchService();
        const dateUtilService = new DateUtilService();
        const token = getAccessToken()
        fetchService.post({
            url: endpointService.getTemplateDetailsUrl(),
            headers: token,
            data: {
                templateId
            }
        })
            .subscribe(
                //onNext callback
                (response) => {
                    if (response.status_code === 200) {
                        toast.success(response.result.message)
                        let { result } = response
                        setTplDetails(result)
                        setUpdateTemplateData({
                            name: result.name,
                            pages: result.pages,
                            fields: result.fields,
                            tplType: result.tplType,
                            companyId: result.companyId
                        })
                        reset({
                            name: result.name,
                            pages: result.pages,
                            fields: result.fields,
                            tplType: result.tplType,
                            companyId: result.companyId
                        })
                    }
                    else {
                        let { message, error } = response.result.error_message
                        toast.error(message)
                        setTplDetails({})
                        setUpdateTemplateData({
                            name: "",
                            pages: [],
                            fields: [],
                            tplType: "",
                            companyId: ""
                        })
                    }

                },
                //onError callback
                (error) => {
                    console.error("There has been an error", error);
                    toast.error(error)
                }
            );
    }

    //to update Template details 
    const onUpdateTemplateDetails = (data) => {
        //        console.log("request starting update template Details.................",updateTemplateData)
        const endpointService = new EndPointService();
        const fetchService = new FetchService();
        const dateUtilService = new DateUtilService();
        const token = getAccessToken()
        const { name, tplType, fields, document, companyId, pages } = updateTemplateData
        fetchService.post({
            url: endpointService.getTemplateUpdateUrl(),
            headers: token,
            data: {
                templateId: tplDetails._id,
                name,
                tplType,
                fields,
                pages,
                companyId,
                document: document[0]
            }
        })
            .subscribe(
                //onNext callback
                (response) => {
                    if (response.status_code === 200) {
                        toast.success(response.result.message)
                        onCancelUpdateTemplate()
                    }
                    else {
                        let { message, error } = response.result.error_message
                        toast.error(message)
                    }

                },
                //onError callback
                (error) => {
                    console.error("There has been an error", error);
                    toast.error(error)
                }
            );
    }

    //to update status for template 
    const onTemplateStatuUpdate = (e) => {
        e.preventDefault()
        // console.log("request starting update template status.................")
        const endpointService = new EndPointService();
        const fetchService = new FetchService();
        const dateUtilService = new DateUtilService();
        const token = getAccessToken()
        fetchService.post({
            url: endpointService.getTemplateStatuUpdateUrl(),
            headers: token,
            data: {
                templateId: statusChangeData.templateId,
                statusId: statusChangeData.statusId
            }
        })
            .subscribe(
                //onNext callback
                (response) => {
                    if (response.status_code === 200) {
                        toast.success(response.result.message)
                        onCancelStatusUpdate()
                    }
                    else {
                        let { message, error } = response.result.error_message
                        toast.error(message)
                    }

                },
                //onError callback
                (error) => {
                    console.error("There has been an error", error);
                    toast.error(error)
                }
            );
    }

    const onChangePage = (e, value) => {
        setFilters((prev) => ({ ...prev, page: value }))
    }

    const searchInputChange = (e) => {
        console.log("input search key ",e.target.value)
        setFilters((prev) => ({
            ...prev,
            filters: { ...prev.filters, title: e.target.value }
        }))
    }

    const onClickChangeStatus = (templateId, statusId, statusName) => {
        setModalStatusChangeOpen(true)
        setStatusChangeData({ templateId, statusId, statusName })
    }

    const onCancelStatusUpdate = () => {

        setModalStatusChangeOpen(false)
        setStatusChangeData({})
    }

    const onClickUpdateTemplate = (templateId) => {
        getMyTemplateDetails(templateId)
        setModalUpdateDetailsOpen(true)
    }

    const onCancelUpdateTemplate = () => {
        setModalUpdateDetailsOpen(false)
        setUpdateTemplateData({
            name: "",
            pages: [],
            fields: [],
            tplType: "",
            companyId: ""
        })
        clearErrors2()
    }

    const renderTemplatesListView = () => {
        return (
            <>
                <div className='body-content'>
                    <div className='eq-table'>
                        <TableContainer component={Paper}>
                            <Table aria-label="simple table">
                                <TableHead>
                                    <TableRow>
                                        <TableCell>Document Name</TableCell>
                                        <TableCell>Owner</TableCell>
                                        <TableCell>Created On</TableCell>
                                        <TableCell>Last Change</TableCell>
                                        <TableCell>Status</TableCell>
                                        <TableCell>Actions</TableCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody>

                                    {myTemplateList.map((row) => {
                                        let { _id, name, createdByDetails, createdOn, updatedOn, statusDetails, } = row

                                        createdOn = dateUtilService.getFormattedDate(createdOn)
                                        updatedOn = dateUtilService.getFormattedDate(updatedOn)
                                        let createdByName = createdByDetails ? createdByDetails.name : ""
                                        let statusName = statusDetails ? statusDetails.name : ""
                                        let changeStatusText = (statusDetails._id === 1) ? "Activate" : "Inactivate"
                                        let changeToStatusId = (statusDetails._id === 1) ? 2 : 3
                                        if (statusDetails._id === 3) {
                                            changeStatusText = "Activate"
                                            changeToStatusId = 2
                                        }

                                        return (
                                            <TableRow
                                                key={_id}
                                            >
                                                <TableCell>
                                                    <span>{name}</span>
                                                </TableCell>
                                                <TableCell>
                                                    <span>{createdByName}</span>
                                                </TableCell>
                                                <TableCell>
                                                    <span>{createdOn}</span>
                                                </TableCell>
                                                <TableCell>
                                                    <span>{updatedOn}</span>
                                                </TableCell>
                                                <TableCell>
                                                    <span>{statusName}</span>
                                                </TableCell>
                                                <TableCell>
                                                    <div arrow className='actions-td'>
                                                        <Tooltip enterTouchDelay={0} arrow placement="bottom-end" id="actions-menu"
                                                            title={
                                                                <React.Fragment>
                                                                    <div className='actions-menu'>
                                                                        <ul>
                                                                            <li>
                                                                                <NavLink to="#"> View   </NavLink>
                                                                            </li>
                                                                            <li onClick={() => onClickChangeStatus(row._id, changeToStatusId, changeStatusText)} >
                                                                                <NavLink to="#">{changeStatusText}</NavLink>
                                                                            </li>
                                                                            <li onClick={() => onClickUpdateTemplate(row._id)}>
                                                                                <NavLink to="#">Edit</NavLink>
                                                                            </li>
                                                                            <li onClick={() => onClickChangeStatus(row._id, 4, "Delete")}>
                                                                                <NavLink to="#">Delete</NavLink>
                                                                            </li>
                                                                        </ul>
                                                                    </div>
                                                                </React.Fragment>
                                                            }
                                                        >
                                                            <span className='actions-icon'></span>
                                                        </Tooltip>
                                                    </div>
                                                </TableCell>
                                            </TableRow>
                                        )
                                    })}
                                </TableBody>
                            </Table>
                        </TableContainer>
                    </div>
                </div>
                <Pagination
                    count={paginationProps.count}
                    page={searchfilters.page}
                    onChange={onChangePage}
                    defaultPage={1}
                    siblingCount={2}
                    boundaryCount={1}
                    size='large'
                    color="secondary"
                    variant="outlined"
                    shape="rounded" />
            </>
        )
    }

    const renderUploadFormView = () => {

        return (
            <div className={modaluploadTemplateOpen ? "custom_modal open" : "custom_modal"} >
                <div className='modal-dialog'>
                    <div className='modal-content'>
                        <div className='modal-header'>
                            <h2 className='modal-title'>Upload Template</h2>
                            <a className="close_btn" onClick={cancelUploadTemplate}><img src={Close} alt='close' /></a>
                        </div>
                        <form onSubmit={handleSubmit(uploadTemplateApi)}>
                            <div className='modal-body'>
                                <div className="form-group">
                                    <TextField
                                        name={'name'}
                                        label={'Template Name*'}
                                        placeholder={'Template Name'}
                                        variant="outlined"
                                        {...register('name', registerOption.name)}
                                        value={uploadTemplateData['name']}
                                        onChange={(e) => setUploadTemplateData((p) => ({ ...p, ["name"]: e.target.value }))}
                                        helperText={''}
                                    />
                                    {errors?.['name'] && <span className='form_error'>{errors['name'].message}</span>}

                                </div>
                                {/* <div className="form-group"> 
                            <Simpleinput
                                id={'pages'}
                                fieldName={'pages'}
                                label={''}
                                hideLabel={true}
                                placeHolder={"pages"}
                                errorText={"pages"}
                                register={register}
                                inputValue={uploadTemplateData.pages}
                                errors={errors}
                                isRequired={false} />
                            </div> */}
                                <label className='form_label'>Select a Template Type*</label>
                                <div className='form-group'>
                                    <FormControl sx={{ m: 1, width: 160 }}>
                                        <Select
                                            type="text"
                                            name="tplType"
                                            labelId="demo-multiple-name-label"
                                            id="demo-multiple-name"
                                            placeholder={"Select a Template Type...."}
                                            {...register("tplType", registerOption["tplType"])}
                                            defaultValue="All Documents"
                                            value={uploadTemplateData.tplType}
                                            onChange={(E) => setUploadTemplateData((p) => ({ ...p, tplType: E.target.value }))}
                                            renderValue={
                                                uploadTemplateData.tplType !== "" ? undefined : () => <Placeholder>Select</Placeholder>
                                            }
                                            displayEmpty
                                            input={<OutlinedInput label="Name" />}
                                        >
                                            <MenuItem value="">
                                                <em>None</em>
                                            </MenuItem>
                                            {
                                                tplTypeList.map((eachType) =>
                                                    <MenuItem
                                                        key={eachType._id}
                                                        value={eachType.type}
                                                    >
                                                        {eachType.name}
                                                    </MenuItem>
                                                )
                                            }


                                        </Select>
                                    </FormControl>
                                    {errors?.["tplType"] && <p className='form_error'>{errors["tplType"].message}</p>}
                                </div>
                                <label className='form_label'>Select the fields*</label>
                                <div className='form-group'>
                                    <FormControl sx={{ m: 1, width: 160 }}>
                                        <Select
                                            multiple
                                            type="text"
                                            name="fields"
                                            labelId="demo-multiple-name-label"
                                            id="demo-multiple-name"
                                            placeholder={"Select a field ...."}
                                            {...register("fields", registerOption["fields"])}
                                            defaultValue="All Documents"
                                            value={uploadTemplateData.fields}
                                            displayEmpty
                                            onChange={(E) => setUploadTemplateData((p) => ({ ...p, fields: E.target.value }))}
                                            renderValue={
                                                uploadTemplateData.fields !== "" ? undefined : () => <Placeholder>Select</Placeholder>
                                            }
                                            input={<OutlinedInput label="Name" />}
                                        >
                                            <MenuItem value="">
                                                <em>None</em>
                                            </MenuItem>

                                            {
                                                fieldsList.map((eachType) =>
                                                    <MenuItem
                                                        key={eachType._id}
                                                        value={eachType.key}
                                                    >
                                                        {eachType.name}
                                                    </MenuItem>
                                                )
                                            }


                                        </Select>
                                    </FormControl>
                                    {errors?.["fields"] && <p className='form_error'>{errors["fields"].message}</p>}
                                </div>
                                <label className='form_label'>Select a Company</label>
                                <div className='form-group'>
                                    <FormControl sx={{ m: 1, width: 300 }}>
                                        <Select

                                            type="text"
                                            name="companyId"
                                            labelId="demo-multiple-name-label"
                                            id="demo-multiple-name"
                                            placeholder={"Search Country...."}
                                            {...register("companyName", registerOption["companyId"])}
                                            defaultValue="All Documents"
                                            value={uploadTemplateData['companyId']}
                                            displayEmpty
                                            onChange={(e) => setUploadTemplateData((p) => ({ ...p, companyId: e.target.value }))}
                                            renderValue={
                                                uploadTemplateData.companyId !== "" ? undefined : () => <Placeholder>Select</Placeholder>
                                            }

                                            input={<OutlinedInput label="Name" />}
                                        >
                                            <MenuItem value="">
                                                <em>None</em>
                                            </MenuItem>
                                            {companiesList.map((company) => {
                                                return (
                                                    <MenuItem
                                                        key={company._id}
                                                        value={company._id}
                                                    >
                                                        {company.name}
                                                    </MenuItem>
                                                )
                                            })}
                                        </Select>
                                    </FormControl>
                                    {errors?.["companyName"] && <p className='form_error'>{errors["companyName"].message}</p>}
                                </div>
                                <div className="form-group">
                                    <UploadFileComponent
                                        id={'document'}
                                        fieldName={'document'}
                                        label={'Document'}
                                        className="file-upload"
                                        showPreviews={false}
                                        filesLimit={1}
                                        dropzoneText={"+ Add"}
                                        Icon={AttachFile}
                                        errorText={"Document"}
                                        showPreviewsInDropzone={true}
                                        isValidationRequired={false}
                                        previewGridProps={{ container: { spacing: 1, direction: 'row' } }}
                                        handleSelectedFile={(selectedFile) => setUploadTemplateData((P) => ({ ...P, document: selectedFile }))}
                                        // selectedFile={uploadTemplateData["document"]}
                                        control={control}
                                        // register={register}
                                        // fieldName={'Doc'}
                                        // isRequired={true}
                                        errors={errors}
                                    />
                                </div>


                            </div>
                            <div className='modal-footer'>
                                <button className="primary_btn more" type='button' onClick={cancelUploadTemplate} >Cancel</button>
                                <button className="primary_btn active" type='submit'  >Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        )
    }

    const renderUpdateFormView = () => {

        return (
            <div className={modalUpdateDetailsOpen ? "custom_modal open" : "custom_modal"} >
                <div className='modal-dialog'>
                    <div className='modal-content'>
                        <div className='modal-header'>
                            <h2 className='modal-title'>Update Template Details</h2>
                            <a className="close_btn" onClick={onCancelUpdateTemplate}><img src={Close} alt='close' /></a>
                        </div>
                        <form onSubmit={handleSubmit2(onUpdateTemplateDetails)}>
                            <div className='modal-body'>
                                <div className="form-group">
                                    <Controller
                                        control={control2}
                                        name={"name"}
                                        rules={registerOption["name"]}
                                        render={({ field: { name, value, ref, onChange } }) => (
                                            <TextField
                                                label={'Template Name*'}
                                                placeholder={'Template Name'}
                                                ref={ref}
                                                name={name}
                                                value={value}
                                                onChange={e => {
                                                    onChange(e.target.value);
                                                    setUpdateTemplateData((p) => ({ ...p, name: e.target.value }))
                                                }}
                                            />
                                        )}
                                    />
                                    {errors2 && errors2?.['name'] && <span className='form_error'>{errors2['name'].message}</span>}

                                </div>
                                <div className="form-group">
                                    <label className='form_label'>Select a Template Type*</label>

                                    <Controller
                                        control={control2}
                                        name={"tplType"}
                                        defaultValue={updateTemplateData["tplType"]}
                                        rules={registerOption["tplType"]}
                                        render={({ field: { value, name, ref, onChange } }) => (
                                            <Select
                                                placeholder={"Select a Template Type...."}
                                                displayEmpty
                                                inputRef={ref}
                                                value={updateTemplateData["tplType"]}
                                                name={name}
                                                onChange={e => {
                                                    onChange(e.target.value);
                                                    setUpdateTemplateData((p) => ({ ...p, tplType: e.target.value }))
                                                }}
                                                labelId="demo-multiple-name-label"
                                                id="demo-multiple-name"
                                                renderValue={
                                                    updateTemplateData.tplType !== "" ? undefined : () => <Placeholder>Select</Placeholder>
                                                }
    
                                                input={<OutlinedInput label="Name" />}
                                            >
                                                <MenuItem value="">
                                                    <em>None</em>
                                                </MenuItem>
                                                {
                                                    tplTypeList.map((eachType) =>
                                                        <MenuItem
                                                            key={eachType._id}
                                                            value={eachType.type}
                                                        >
                                                            {eachType.name}
                                                        </MenuItem>
                                                    )
                                                }
                                            </Select>
                                        )}
                                    />
                                    {errors2 && errors2?.['tplType'] && <span className='form_error'>{errors2['tplType'].message}</span>}

                                </div>
                                <div className="form-group">
                                    <label className='form_label'>Select a Template Fields*</label>
                                    <Controller
                                        control={control2}
                                        name={"fields"}
                                        defaultValue={updateTemplateData["fields"]}
                                        rules={registerOption["fields"]}
                                        render={({ field: { value, name, ref, onChange } }) => (
                                            <Select
                                                multiple
                                                displayEmpty
                                                inputRef={ref}
                                                value={updateTemplateData["fields"]}
                                                name={name}
                                                onChange={e => {
                                                    onChange(e.target.value);
                                                    setUpdateTemplateData((p) => ({ ...p, fields: e.target.value }))
                                                }}
                                            >
                                                <MenuItem value="">
                                                    <em>None</em>
                                                </MenuItem>
                                                {
                                                    fieldsList.map((eachType) =>
                                                        <MenuItem
                                                            key={eachType._id}
                                                            value={eachType.key}
                                                        >
                                                            {eachType.name}
                                                        </MenuItem>
                                                    )
                                                }
                                            </Select>
                                        )}
                                    />
                                    {errors2 && errors2?.['fields'] && <span className='form_error'>{errors2['fields'].message}</span>}

                                </div>
                                <div className="form-group">
                                    <label className='form_label'>Select a Company</label>
                                    <Controller
                                        control={control2}
                                        name={"companyId"}
                                        defaultValue={updateTemplateData["companyId"]}
                                        rules={registerOption["companyId"]}
                                        render={({ field: { value, name, ref, onChange } }) => (
                                            <Select
                                                displayEmpty
                                                inputRef={ref}
                                                value={updateTemplateData["companyId"]}
                                                name={name}
                                                onChange={e => {
                                                    onChange(e.target.value);
                                                    setUpdateTemplateData((p) => ({ ...p, companyId: e.target.value }))
                                                }}
                                            >
                                                <MenuItem value="">
                                                    <em>None</em>
                                                </MenuItem>
                                                {
                                                    companiesList.map((eachType) =>
                                                        <MenuItem
                                                            key={eachType._id}
                                                            value={eachType._id}
                                                        >
                                                            {eachType.name}
                                                        </MenuItem>
                                                    )
                                                }
                                            </Select>
                                        )}
                                    />
                                    {errors2 && errors2?.['companyId'] && <span className='form_error'>{errors2['companyId'].message}</span>}

                                </div>
                            </div>
                            <div className='modal-footer'>
                                <button className="primary_btn more" type='button' onClick={onCancelUpdateTemplate} >Cancel</button>
                                <button className="primary_btn active" type='submit'  >Confirm</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        )
    }

    return (
        <>
            <ToastContainer
                position="top-center"
                autoClose={false}
                hideProgressBar={false}
                newestOnTop={false}
                closeOnClick
                rtl={false}
                pauseOnFocusLoss
                draggable
                pauseOnHover
                theme="colored"
            />
            <div>
                <div className='side-nav-tabs'>
                    <Tabs>
                        <TabList>
                            <Tab>
                                <p>My Templates     </p>
                            </Tab>
                            <Tab>
                                <p> Shared with Me </p>
                            </Tab>
                            <Tab>
                                <p> Favorites</p>
                            </Tab>
                            <Tab>
                                <p>Common Templates</p>
                            </Tab>
                            <Tab>
                                <p>Draft</p>
                            </Tab>
                            <Tab>
                                <p>Deleted</p>
                            </Tab>
                        </TabList>
                        <div class="tab-panel-content">
                            <TabPanel>
                                <div className='sub-header'>
                                    <div className='page-title'>
                                        <h3>Templates</h3>
                                    </div>
                                    <div className='page-filters'>
                                        <ul>
                                            <li>
                                                <div className="search_area">
                                                    <input type="text" className="form-control" placeholder="Search" onChange={searchInputChange} />
                                                </div>
                                            </li>
                                            <li>
                                                <button className="primary_btn document_btn" data-bs-toggle="modal" data-bs-target="#add_doc_sign" onClick={() => setModalUploadTemp(true)}>Upload Template</button>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                {showNoData && <NoData />}
                                {!showNoData && renderTemplatesListView()}

                            </TabPanel>
                            <TabPanel>
                                <div className='sub-header'>
                                    <div className='page-title'>
                                        <h3>Shared with Me</h3>
                                    </div>
                                </div>
                            </TabPanel>
                            <TabPanel>
                                <div className='sub-header'>
                                    <div className='page-title'>
                                        <h3>Favorites</h3>
                                    </div>
                                </div>
                            </TabPanel>
                            <TabPanel>
                                <div className='sub-header'>
                                    <div className='page-title'>
                                        <h3>Common Templates</h3>
                                    </div>
                                </div>
                            </TabPanel>
                            <TabPanel>
                                <div className='sub-header'>
                                    <div className='page-title'>
                                        <h3>Draft</h3>
                                    </div>
                                </div>
                            </TabPanel>
                            <TabPanel>
                                <div className='sub-header'>
                                    <div className='page-title'>
                                        <h3>Deleted</h3>
                                    </div>
                                </div>
                            </TabPanel>
                        </div>
                    </Tabs>
                </div>
            </div>
            {/* upload template modal */}
            {modaluploadTemplateOpen && renderUploadFormView()}
            {/* status change modal */}
            <div className={modalStatusChangeOpen ? "custom_modal open" : "custom_modal"} >
                <div className='modal-dialog'>
                    <div className='modal-content'>
                        <div className='modal-header'>
                            <h2 className='modal-title'>Template Status Change</h2>
                            <a className="close_btn" onClick={onCancelStatusUpdate}><img src={Close} alt='close' /></a>
                        </div>
                        <form onSubmit={onTemplateStatuUpdate}>
                            <div className='modal-body'>
                                <p>Click on Confirm to {statusChangeData.statusName} Template</p>
                            </div>
                            <div className='modal-footer'>
                                <button className="primary_btn more" type='button' onClick={onCancelStatusUpdate} >Cancel</button>
                                <button className="primary_btn active" type='submit'  >Confirm</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            {/* update details modal */}
            {modalUpdateDetailsOpen && renderUpdateFormView()}

        </>
    )
}

export default Mytemplates;