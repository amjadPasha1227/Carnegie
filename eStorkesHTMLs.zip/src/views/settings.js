import React, { useState,useEffect,useRef } from 'react'; 
import '../styles/scss/settings.scss';
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import TextField from '@mui/material/TextField';
import Grid from '@mui/material/Grid';
import Switch from '@mui/material/Switch';
import FormControlLabel from '@mui/material/FormControlLabel';
import { DropzoneArea } from 'material-ui-dropzone';
import { AttachFile } from '@material-ui/icons';
import QuestionMark from '../images/question-mark.svg';
import Select from '@mui/material/Select';
import DateTimePicker from 'react-datetime-picker';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import TimezoneSelect from 'react-timezone-select';
import { makeStyles } from "@material-ui/core/styles";
import { EndPointService } from '../services/endPointServices';
import { render } from '@testing-library/react';
import PhoneNumberInput from './components/PhoneNumberInput.js';
import Moment from 'moment';
import{isEmpty} from "./Utils";
//import { ToastContainer, toast } from 'react-toastify'
import { StorageService } from '../services/storageService';
import '../styles/scss/components/simpleInput.scss';
import Simpleinput from './components/simpleInput';
import { useForm } from "react-hook-form";
import Envelope from '../images/envelope.svg';
import UploadFileComponent from './UploadFileComponent.js';
import 'react-datetime-picker/dist/DateTimePicker.css';
import 'react-calendar/dist/Calendar.css';
import 'react-clock/dist/Clock.css';
import { FetchService } from '../services/fetchServices';
import {showToast} from './Utils'
const usePlaceholderStyles = makeStyles(theme => ({
    placeholder: {
      color: "#aaa"
    }
  }));
  const Placeholder = ({ children }) => {
    const classes = usePlaceholderStyles();
    return <div className={classes.placeholder}>{children}</div>;
  };
function Settings() {
    const [answer, setAnswer] = useState("");
    const [answers, setAnswers] = useState("");
    const [value, onChange] = useState(new Date());
    const [selectedTimezone, setSelectedTimezone] = useState({})
    const [startDate, setStartDate] = useState(new Date());
    const [startDates, setStartDates] = useState(new Date());
    const [signature, setSignature] = useState([]);
    const [stamp, setStamp] = useState([]);
    const [userData, setUserData] = useState(null);
    const [companyUpdate, setCompanyUpdate] = useState({
        name:"",website:"",phoneCountryCode: {countryCode: 'US',countryCallingCode: '1'},phone:"",
        authorizedSignatory:{
            fName: "",
            lName: "",
            title: "",
            email: "",
            phone:"",
            phoneCountryCode: {countryCode: 'US',countryCallingCode: '1'},
            homePhone: "",
            homePhoneCountryCode: {countryCode: 'US',countryCallingCode: '1'}
        }

    });
    const inputRef = useRef();
    const { register, clearErrors,handleSubmit, formState: { errors }, control,setValue} = useForm();
        useEffect(() => {
         const storageService = new StorageService();
         const userinfoData=JSON.parse(storageService.get("userinfo"))
         setUserData(userinfoData)
         //console.log(userinfoData)
         setValue('browserTS', value)
         setCompanyUpdate((prevData) => ({
            ...prevData,
            name: userinfoData.name,
            phone:userinfoData.phone,
            authorizedSignatory:{
            fName: "",
            lName: "",
            title: "",
            email: userinfoData.email,
            phone:userinfoData.phone,
            phoneCountryCode: {countryCode: 'US',countryCallingCode: '1'},
            homePhone: userinfoData.phone,
            homePhoneCountryCode: {countryCode: 'US',countryCallingCode: '1'}
        } }))
       },[]);
      
    function handleSelectedFile(selectedFile,type){
        if(type===1){
            setSignature(selectedFile)
        }else{
            setStamp(selectedFile)
        }
      
    }
    const handleInputChange = (e, data, formattedValue, isPhoneNumber) => {
        
        //console.log("input data", data)
        const { name, value } = e.target
        //console.log("input name", name)
        if (name.startsWith("authorizedSignatory.")) {
            const [, nestedName] = name.split(".");
            setCompanyUpdate((prevState) => ({
              ...prevState,
              authorizedSignatory: {
                ...prevState.authorizedSignatory,
                [nestedName]: value,
              },
            }));
          } else {
            setCompanyUpdate((prevState) => ({
              ...prevState,
              [name]: value,
            }));
          }
          if (value) {
            clearErrors(name);
        }
        //console.log("input data companyUpdate", companyUpdate)

    };
    function onSubmit(data) {
        // alert(JSON.stringify(data))
        // console.log("Data",data)
       const endpointService = new EndPointService();
       const fetchService = new FetchService();
       data.companyId=userData.companyId
       //"64b0e66cdb30441d648fdf38"
       //data.browserTS=Moment(value).format("YYYY-MM-DDTHH:mm:ssZ")
       //data.timezone= selectedTimezone.value
       data.signature={ "name": signature[0].name, "path":  signature[0].path,"mimetype":  signature[0].mimetype,"extn":  signature[0].extn}
       data.stamp={ "name": stamp[0].name,"path":  stamp[0].path,"mimetype": stamp[0].mimetype, "extn": stamp[0].extn}
    //    data.authorizedSignatory={
    //           "fName": data.fName,
    //           "lName": data.lName,
	// 			"title": data.jobTitle,
	// 			"email": data.email,
	// 			"phone": data.authorizedPhoneNumber,
	// 			"phoneCountryCode":  { 
	// 				"countryCode":"IN",
	// 				"countryCallingCode":"91"
	// 			},
	// 			"homePhone": data.homePhone,
	// 			"homePhoneCountryCode": {
	// 				"countryCode": "IN",
	// 				"countryCallingCode": "+91"
	// 			}
    //    }
    //data.website= "https://www.rmtportal.com" headers: token,
       data.phoneCountryCode=companyUpdate.phoneCountryCode
       data.authorizedSignatory.phoneCountryCode=companyUpdate.authorizedSignatory.phoneCountryCode
       data.authorizedSignatory.homePhoneCountryCode=companyUpdate.authorizedSignatory.homePhoneCountryCode
       data.contactEmail= data.authorizedSignatory.email
       data.signDocUrl="http://localhost:4200/#/auth/sign-document"
       fetchService.post({
          // headers:"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2NGIwZTY2YmRiMzA0NDFkNjQ4ZmRmMzQiLCJlbWFpbCI6ImVzdHJva2VzbG9jYWxAeW9wbWFpbC5jb20iLCJuYW1lIjoiRGlsZWVwIE0iLCJyb2xlSWQiOjIsInJvbGVOYW1lIjoiQWRtaW4iLCJzdGF0dXNJZCI6MiwiY29tcGFueUlkIjoiNjRiMGU2NmNkYjMwNDQxZDY0OGZkZjM4IiwidmVyc2lvbklkIjoiMS4wIiwiYWRtaW5Qb3BydGFsIjp0cnVlLCJpYXQiOjE2ODkzMTU0NDl9.sq-oVZcLD8JumvtHB7E6WHkYdSYuuM4vkj2pDOLpbQk",
           headers:userData.accessToken,
           url: endpointService.getUpdateCompany(),
           data: data
       }).subscribe(
               (response) => {
                  if (response.status === 'Success') {
                    showToast(response.message,"success") 
                } else {
                    showToast(response.message,"error")
                }
               },
               (error) => {
                   console.error("Error", error);
               }
           );
        // fetch(endpointService.getUpdateCompany(), {
        //     method: 'POST',
        //     headers: {
        //         'Content-Type': 'application/json',
        //         'Authorization': 'Bearer ' +"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2NGIwZTY2YmRiMzA0NDFkNjQ4ZmRmMzQiLCJlbWFpbCI6ImVzdHJva2VzbG9jYWxAeW9wbWFpbC5jb20iLCJuYW1lIjoiRGlsZWVwIE0iLCJyb2xlSWQiOjIsInJvbGVOYW1lIjoiQWRtaW4iLCJzdGF0dXNJZCI6MiwiY29tcGFueUlkIjoiNjRiMGU2NmNkYjMwNDQxZDY0OGZkZjM4IiwidmVyc2lvbklkIjoiMS4wIiwiYWRtaW5Qb3BydGFsIjp0cnVlLCJpYXQiOjE2ODkzMTU0NDl9.sq-oVZcLD8JumvtHB7E6WHkYdSYuuM4vkj2pDOLpbQk",// userData.accessToken,
        //     },
        //     body: JSON.stringify(data)
        // })
        //     .then(response => response.json())
        //     .then((responseJson) => {
        //         showToast(responseJson.message)
        //     })
        //     .catch((error) => {
        //         console.error(error);
        //     });
    };
    const onErrors = (errors) => {
        console.log("errors are ", errors)
    }
    return (
        <div>
            <div className='side-nav-tabs'>
                <Tabs>
                    <TabList>
                    <Tab>
                        <p>Profile </p>
                    </Tab>
                    <Tab>
                        <p>Account</p>
                    </Tab>
                    <Tab>
                        <p> Notifications</p>
                    </Tab>
                    <Tab>
                        <p>Email Branding</p>
                    </Tab>
                    <Tab>
                        <p>Team Members</p>
                    </Tab>
                    <Tab>
                        <p>Teams</p>
                    </Tab>
                    <Tab>
                        <p>Integrations</p>
                    </Tab>
                    <Tab>
                        <p>API</p>
                    </Tab>
                    </TabList>
                    <div class="tab-panel-content">
                    <TabPanel>
                    <div className="panel-content">
                        <div className="profile">
                        {!isEmpty(userData)&&<div className="profile-header"><div className="user">{userData.name}</div>
                        <p><span>{userData.email}</span></p></div>}
                            <div className="Profile-body profile-tab">
                                <form>
                                    <Grid container rowSpacing={1} columnSpacing={{ xs: 1, sm: 2, md: 3 }}>
                                        <Grid item xs={12} sm={12} md={8}>
                                           <UploadFileComponent
                                            label={"Signature and Initial"}
                                            className="file-upload"
                                            showPreviews={false}
                                            filesLimit={1}
                                            dropzoneText={"+ Add"}
                                            Icon={AttachFile}
                                            showPreviewsInDropzone={true}
                                            errorText={"Signature"}
                                            isValidationRequired={true}
                                            previewGridProps={{container: { spacing: 1, direction: 'row' }}}
                                            handleSelectedFile={(selectedFile)=>handleSelectedFile(selectedFile,1)}
                                            selectedFile={signature}
                                            fieldName={'Signature'}
                                            errors={errors}
                                            id={'Signature'}
                                            control={control}
                                           // userData={userData}
                                        />   
                                        </Grid>
                                        <Grid item xs={12} sm={12} md={4}>
                                            <UploadFileComponent
                                            label={"Stamp"}
                                            showPreviews={false}
                                            filesLimit={1}
                                            dropzoneText={"+ Add"}
                                            Icon={AttachFile}
                                            showPreviewsInDropzone={true}
                                            errorText={"Stamp"}
                                            isValidationRequired={true}
                                            previewGridProps={{container: { spacing: 1, direction: 'row' }}}
                                            handleSelectedFile={(selectedFile)=>handleSelectedFile(selectedFile,2)}
                                            selectedFile={stamp}
                                            fieldName={'Stamp'}
                                            errors={errors}
                                            id={'Stamp'}
                                            control={control}
                                            //userData={userData}
                                            //   dropzoneClass={'customsdropzone'}
                                            //  previewChipProps={{classes: { root: classes.previewChip } }}
                                            
                                        />                          
                                        </Grid>
                                        <div className='devider'></div>
                                        <Grid item xs={12} sm={12} md={12}>
                                            <div className='form-group' > 
                                                <Simpleinput
                                                    id={'Company'}
                                                    fieldName={'name'}
                                                    label={'Company'}
                                                    hideLabel={true}
                                                    placeHolder={"Company"}
                                                    errorText={"Company Name"}
                                                    register={register}
                                                    inputValue={companyUpdate.name}
                                                    errors={errors}
                                                    isRequired={true}
                                                    onInputChange={handleInputChange} />
                                            </div>
                                        </Grid>
                                        <Grid item xs={12} sm={12} md={6}>
                                        <div className="form-group">
                                            {/* <img src={Envelope} alt="Envelope" /> */}
                                            <Simpleinput
                                                id={'website'}
                                                fieldName={'website'}
                                                label={'Website'}
                                                hideLabel={true}
                                                placeHolder={"Website"}
                                                errorText={"Website"}
                                                register={register}
                                                inputValue={companyUpdate.website}
                                                errors={errors}
                                                isRequired={true}
                                                onInputChange={handleInputChange}    
                                                />
                                        </div>
                                        </Grid>
                                        <Grid item xs={12} sm={12} md={6}>
                                           <div className="form-group">
                                            <label className='form_label'>Phone Number</label>
                                                    <Simpleinput
                                                        id={'phoneNumber'}
                                                        fieldName={'phone'}
                                                        label={'PhoneNumber'}
                                                        hideLabel={true}
                                                        placeHolder={"Phone Number"}
                                                        errorText={"Phone Number"}
                                                        register={register}
                                                        inputValue={companyUpdate.phone}
                                                        phoneCountryCode={companyUpdate.phoneCountryCode}
                                                        errors={errors}
                                                        isRequired={true}
                                                        type={'phone'}
                                                        control={control}
                                                        onInputChange={handleInputChange}/>
                                        </div>
                                        </Grid>
                                        <Grid item xs={12} sm={12} md={12}>
                                         <h5>Representative/Authorized Signatory</h5> 
                                       </Grid>
                                        <Grid item xs={12} sm={12} md={12}>
                                            <div className='form-group' > 
                                                <Simpleinput
                                                    ref={inputRef}
                                                    id={"Job title"}
                                                    fieldName={"authorizedSignatory.title"}
                                                    label={"Job title"}
                                                    hideLabel={true}
                                                    placeHolder={"Job title"}
                                                    errorText={"Job title"}
                                                    register={register}
                                                    inputValue={companyUpdate.authorizedSignatory?.title}
                                                    errors={errors}
                                                    isRequired={true} 
                                                    onInputChange={handleInputChange}    
                                                    />
                                            </div>
                                        </Grid>
                                          <Grid item xs={12} sm={12} md={6}>
                                            <div className='form-group' > 
                                            <Simpleinput
                                                    id={"First name"}
                                                    fieldName={"authorizedSignatory.fName"}
                                                    //fieldName={companyUpdate.authorizedSignatory.fName}
                                                    label={"First name"}
                                                    hideLabel={true}
                                                    placeHolder={"First name"}
                                                    errorText={"First name"}
                                                    register={register}
                                                    inputValue={companyUpdate.authorizedSignatory.fName}
                                                    errors={errors}
                                                    //error={Boolean(errors?.[name])}
                                                    isRequired={true}
                                                    onInputChange={handleInputChange}
                                                     />
                                            </div>
                                        </Grid>
                                        <Grid item xs={12} sm={12} md={6}>
                                            <div className='form-group' > 
                                                    <Simpleinput
                                                    id={"Last name"}
                                                    fieldName={"authorizedSignatory.lName"}
                                                    label={"Last name"}
                                                    hideLabel={true}
                                                    placeHolder={"Last name"}
                                                    errorText={"Last name"}
                                                    register={register}
                                                    inputValue={companyUpdate.authorizedSignatory.lName}
                                                    errors={errors}
                                                    isRequired={true}
                                                    onInputChange={handleInputChange}/>
                                            </div>
                                        </Grid> 
                                        <Grid item xs={12} sm={12} md={6}>
                                        <div className="form-group">
                                            {/* <img src={Envelope} alt="Envelope" /> */}
                                            <Simpleinput
                                                id={'email'}
                                                fieldName={'authorizedSignatory.email'}
                                                label={'Email'}
                                                hideLabel={true}
                                                placeHolder={"Email Address"}
                                                errorText={"Email Address"}
                                                register={register}
                                                inputValue={companyUpdate.authorizedSignatory.email}
                                                errors={errors}
                                                isRequired={true}
                                                type={'email'}
                                                onInputChange={handleInputChange} />
                                        </div>
                                        </Grid>
                                        <Grid item xs={12} sm={12} md={6}>
                                            <div className="form-group">
                                                {/* <img src={Phone} alt="Phone" /> */}
                                                <label className='form_label'>Phone Number</label>
                                                <Simpleinput
                                                    id={'phoneNumber'}
                                                    fieldName={'authorizedSignatory.phone'}
                                                    label={'PhoneNumber'}
                                                    hideLabel={true}
                                                    placeHolder={"Phone Number"}
                                                    errorText={"Phone Number"}
                                                    register={register}
                                                    errors={errors}
                                                    isRequired={true}
                                                    type={'phone'}
                                                    control={control}
                                                    inputValue={companyUpdate.authorizedSignatory.phone}
                                                    phoneCountryCode={companyUpdate.authorizedSignatory.phoneCountryCode}
                                                    onInputChange={handleInputChange}/>
                                            </div>
                                        </Grid>
                                        <Grid item xs={12} sm={12} md={6}>
                                            <div className="form-group">
                                                {/* <img src={Phone} alt="Phone" /> */}
                                                <label className='form_label'>Phone Number</label>
                                                <Simpleinput
                                                    id={'mobile Telephone Number'}
                                                    fieldName={'authorizedSignatory.homePhone'}
                                                    label={'Mobile Telephone Number'}
                                                    hideLabel={true}
                                                    placeHolder={"Mobile Telephone Number"}
                                                 // errorText={"Mobile Telephone Number"}
                                                    register={register}
                                                    //errors={errors}
                                                    isRequired={false}
                                                    type={'phone'}
                                                    control={control}
                                                    inputValue={companyUpdate.authorizedSignatory.homePhone}
                                                    phoneCountryCode={companyUpdate.authorizedSignatory.homePhoneCountryCode}
                                                    onInputChange={handleInputChange} 
                                                    />
                                            </div>
                                        </Grid>
                                        <Grid item xs={12} sm={12} md={6}>
                                            <div className='form-group' > 
                                                <label>Date format</label>
                                                <DateTimePicker 
                                                id="browserTS"
                                                {...register('browserTS', { required: 'Date and Time is required' })}
                                                //onChange={onChange}
                                                onChange={(datetime) => {
                                                    if(!isEmpty(datetime)){
                                                    let dateFormat=Moment(datetime).format("YYYY-MM-DDTHH:mm:ssZ")
                                                    onChange(dateFormat);
                                                    setValue('browserTS', dateFormat);
                                                    errors.browserTS=false
                                                    }else{
                                                    onChange("");
                                                    setValue('browserTS', "");
                                                    }
                                                 }} 
                                                value={value} 
                                                dayPlaceholder='DD' 
                                                hourPlaceholder='HH' 
                                                yearPlaceholder='YYYY' 
                                                minutePlaceholder='SS' 
                                                secondPlaceholder='SS' 
                                                monthPlaceholder='MM' 
                                                placeholder='Date format'/>
                                                {errors.browserTS&&<span className='form_error'>{errors.browserTS.message}</span>} 
                                            </div>
                                        </Grid>
                                        <Grid item xs={12} sm={12} md={6}>
                                            <div className='form-group' >
                                                <label>Time zone</label>
                                                <TimezoneSelect  
                                                id="timezone"
                                                {...register('timezone', { required: 'Timezone is required' })}
                                                menuPlacement='auto'
                                                value={selectedTimezone}
                                                classNamePrefix="react-timezone-select"
                                                //onChange={handleTimezoneChange}
                                                 onChange={(timezone) => {
                                                    setSelectedTimezone(timezone.value);
                                                    setValue('timezone', timezone.value);
                                                    errors.timezone=false
                                                 }}
                                                placeholder='Asia/Kolkata'
                                                />
                                                {errors.timezone&&<span className='form_error'>{errors.timezone.message}</span>}
                                            </div>
                                        </Grid>
                            </Grid>
                            {/* <ToastContainer
                                position="bottom-right"
                                autoClose={3000}
                                hideProgressBar={true}
                                closeOnClick
                                draggable
                                /> */}
                            </form>
                            </div>
                            <div className="Profile-footer">
                                <button className="primary_btn active" onClick={(event)=>event.preventDefault()}>Cancel</button>
                                <button className="primary_btn more" onClick={handleSubmit(onSubmit, onErrors)}
                                >Save Changes</button>
                            </div>
                        </div>
                    </div>
                    </TabPanel>
                    <TabPanel>
                    <div className="panel-content">
                        <div className="profile">
                            <p>Account</p>
                            <div className="Profile-body">
                                <form>
                                    <Grid container rowSpacing={1} columnSpacing={{ xs: 1, sm: 2, md: 3 }}>
                                        <Grid item xs={12} sm={12} md={6}>
                                            <div className='form-group' > 
                                            <TextField id="outlined-basic" label="Account Name" hiddenLabel variant="outlined" />
                                            </div>
                                        </Grid>
                                        <Grid item xs={12} sm={12} md={6}>
                                            <div className='form-group' > 
                                            <label>Date Field Format</label>
                                            <DatePicker selected={startDate} onChange={(date) => setStartDate(date)} placeholderText='MM/DD/YYYY'/>
                                            </div>
                                        </Grid>
                                        <Grid item xs={12} sm={12} md={6}>
                                            <div className='form-group' > 
                                            <label>(GMT+00:00) Coordinated Universal Time</label>
                                            <DatePicker selected={startDates} onChange={(date) => setStartDates(date)}  placeholderText='MM/DD/YYYY'/>
                                            </div>
                                        </Grid>
                                        <Grid item xs={12} sm={12}>
                                            <div class="badge">Branding</div>
                                            <div className='form-group question_switch' > 
                                            <FormControlLabel control={<Switch defaultChecked />} label="Mute ESTROKES Branding" className="switch-field"/>
                                            <img src={QuestionMark} alt="QuestionMark" />
                                            </div>
                                        </Grid>
                                        <Grid item xs={12}>
                                            <div class="badge">Signature & Initials Preferences <img src={QuestionMark} alt="QuestionMark" /></div>
                                            <div className='form-group question_switch' > 
                                            <Grid container rowSpacing={1} columnSpacing={{ xs: 1, sm: 2, md: 3 }}>
                                                <Grid item xs={12} sm={12} md={6}>
                                                <FormControlLabel control={<Switch defaultChecked />} label="Disable Typed Signatures" className="switch-field"/>
                                                </Grid>
                                                <Grid item xs={12} sm={12} md={6}>
                                                <FormControlLabel control={<Switch defaultChecked />} label="Disable Drawn Signatures" className="switch-field"/>
                                                </Grid>
                                                <Grid item xs={12} sm={12} md={6}>
                                                <FormControlLabel control={<Switch defaultChecked />} label="Disable Uploaded Signatures" className="switch-field"/>
                                                </Grid>
                                                <Grid item xs={12} sm={12} md={6}>
                                                <FormControlLabel control={<Switch defaultChecked />} label="Disable “Apply Everywhere”" className="switch-field"/>
                                                </Grid>
                                            </Grid>
                                            </div>
                                        </Grid>
                                        <Grid item xs={12}>
                                            <div className="badge">Document Preferences</div>
                                            <div className='form-group question_switch' >
                                            <Grid container rowSpacing={1} columnSpacing={{ xs: 1, sm: 2, md: 3 }}>
                                                <Grid item xs={12} sm={12} md={6}>
                                                <FormControlLabel control={<Switch defaultChecked />} label="Hide Document ID" className="switch-field"/>
                                                </Grid>
                                                <Grid item xs={12} sm={12} md={6}>
                                                <FormControlLabel control={<Switch defaultChecked />} label="Separate All Completed Document Files" className="switch-field"/>
                                                </Grid>
                                                <Grid item xs={12} sm={12} md={6}>
                                                    <Select native
                                                        className="select-option-doc"
                                                        labelId="demo-simple-select-label"
                                                        id="demo-simple-select"
                                                        label="Age"
                                                        fullWidth
                                                        value={answers}
                                                        onChange={event => setAnswers(event.target.value)}
                                                        renderValue={
                                                            answers !== "" ? undefined : () => <Placeholder>Select</Placeholder>
                                                        }
                                                        displayEmpty
                                                    >
                                                        <option value={10}>Ten</option>
                                                        <option value={20}>Twenty</option>
                                                        <option value={30}>Thirty</option>
                                                    </Select>
                                                </Grid>
                                            </Grid>
                                            </div>
                                        </Grid>
                                        <Grid item xs={12}>
                                            <div className="badge">Branding</div>
                                            <Grid item xs={12} sm={12} md={6}>
                                                <div className="select-field">
                                                    <span>Links expire in</span>
                                                    <Select native
                                                        className="select-option-doc"
                                                        labelId="demo-simple-select-label"
                                                        id="demo-simple-select"
                                                        label="Age"
                                                        fullWidth
                                                        value={answer}
                                                        onChange={event => setAnswer(event.target.value)}
                                                        renderValue={
                                                            answer !== "" ? undefined : () => <Placeholder>10</Placeholder>
                                                        }
                                                        displayEmpty
                                                    >
                                                        <option value={10}>10</option>
                                                        <option value={20}>20</option>
                                                        <option value={30}>30</option>
                                                    </Select>
                                                    <span> days</span>
                                                </div>
                                            </Grid>
                                        </Grid>
                                        <Grid item xs={12}>
                                            <div className="badge">Redirect To Page After Signing</div>
                                            <div className='form-group question_switch' >
                                            <FormControlLabel control={<Switch defaultChecked />} label="Enable" class="switch-field"/>
                                            </div>
                                            <Grid item  xs={12} sm={12} md={6}>
                                            <div className='form-group' > 
                                            <TextField id="outlined-basic" label="" hiddenLabel variant="outlined" placeholder='https://custom.com/page'/>
                                            </div>
                                            </Grid>
                                        </Grid>
                                    </Grid>
                                </form>
                            </div>
                        </div>
                    </div>
                    </TabPanel>
                    <TabPanel>
                    <div className="panel-content">
                        <div className="profile">
                            <p>Notifications</p>
                            <div className="Profile-body branding"></div>
                        </div>
                    </div>
                    </TabPanel>
                    <TabPanel>
                    <div className="panel-content">
                        <div className="profile">
                            <p>Email Branding</p>
                            <div className="Profile-body branding">
                                <form>
                                    <Grid container rowSpacing={1} columnSpacing={{ xs: 1, sm: 2, md: 3 }}>
                                        <Grid item xs={12}>
                                            <div className='form-group' > 
                                                <label>Logo (Email and Recipient Page)</label>
                                                <DropzoneArea
                                                    dropzoneClass={'customdropzone'}
                                                    showPreviews={true}
                                                    dropzoneText="Drag and drop here or Browse"
                                                    Icon={AttachFile}
                                                    showPreviewsInDropzone={false}
                                                    //useChipsForPreview
                                                    previewGridProps={{container: { spacing: 1, direction: 'row' }}}
                                                // previewChipProps={{classes: { root: classes.previewChip } }}
                                                     onChange={(files) => console.log('Files:', files)}
                                                     
                                                />
                                                <span className='drop-label'>Maximum image size: 300px by 60px. We recommend using a logo with a transparent background</span>
                                            </div>
                                        </Grid>
                                        <Grid item xs={12}>
                                            <div className='form-group' > 
                                            <TextField id="outlined-basic" label="Email “From” Field" hiddenLabel variant="outlined" />
                                            </div>
                                        </Grid>
                                        <Grid item xs={12}>
                                            <div className='form-group ' > 
                                                <label>Email Signature</label>
                                                <FormControlLabel control={<Switch defaultChecked />} label="Enable" className="switch-field"/>
                                                <div className='text-area'>
                                                    <p>Thanks, </p><br />
                                                    <p>new bee <br />Company</p>
                                                </div>
                                            </div>
                                        </Grid>
                                    </Grid>
                                </form>
                            </div>
                        </div>
                    </div>
                    </TabPanel>
                    <TabPanel>
                    <div className="panel-content">
                        <div className="profile">
                            <p>Team Members</p>
                            <div className="Profile-body branding"></div>
                        </div>
                    </div>
                    </TabPanel>
                    <TabPanel>
                    <div className="panel-content">
                        <div className="profile">
                            <p>Teams</p>
                            <div className="Profile-body branding"></div>
                        </div>
                    </div>
                    </TabPanel>
                    <TabPanel>
                    <div className="panel-content">
                        <div className="profile">
                            <p>Integrations</p>
                            <div className="Profile-body branding"></div>
                        </div>
                    </div>
                    </TabPanel>
                    <TabPanel>
                    <div className="panel-content">
                        <div className="profile">
                            <p>API</p>
                            <div className="Profile-body branding"></div>
                        </div>
                    </div>
                    </TabPanel>
                    </div>
                </Tabs>
            </div>
        </div>
    )
}


export default Settings;