import React, { useState } from 'react'; 
import '../styles/scss/login.scss';  
import '../styles/scss/components/simpleInput.scss';
import Padlock from '../images/padlock.svg';
//import { useHistory }from 'react-router-dom';
import { EndPointService }  from '../services/endPointServices';
import { FetchService } from '../services/fetchServices';

import TextField from '@mui/material/TextField';
import { Link } from 'react-router-dom';
import { useLocation } from 'react-router-dom'


function ResetPassword  ()  {
    const [newPwd, setNewPwd] = useState("");
    const [confirmPwd,setConfirmPwd] = useState("");

    //Get query params
    const search = useLocation().search
    const searchParams = new URLSearchParams(search)
    
    const handleClick = (e) => {
        e.preventDefault();

        //JSON format  for payload
       const endpointService = new EndPointService();
       const fetchService = new FetchService();
       fetchService.post({
            url: endpointService.getResetPassword(),
            data: {
                "pin": searchParams? searchParams.get('key'): '',
                "action": "forgot-password",
                "newPwd": newPwd,
                "confirmPwd": confirmPwd,
                "userId": searchParams? searchParams.get('userId'): ''
            } 
        });
    }
    return (
        <div className="login_page_wrapper"> 
            <div className="login_area">
                <h4> Reset Password</h4>
                <div className="login-form">
                    <form>
                        <div className="form-group"> 
                            <img src={Padlock} alt="Padlock" />
                            <TextField id="outlined-basic" placeholder="NewPassword" hiddenLabel variant="outlined"
                              value={newPwd}
                              onChange={(e) =>setNewPwd(e.target.value)} 
                           />
                        </div>
                        <div className="form-group"> 
                            <img src={Padlock} alt="Padlock" />
                            <TextField id="outlined-basic" placeholder="ConfirmPassword" hiddenLabel variant="outlined" 
                              value={confirmPwd}
                              onChange={(e) => setConfirmPwd(e.target.value)} 
                            />
                        </div>
                        <button type="button"  onClick={handleClick} className="primary_btn login">
                            Submit
                        </button>
                        <div className="sign_up"> 
                            <p>If you want to login? <Link to="/login"> <span>Login</span></Link></p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    )
}


export default ResetPassword;
