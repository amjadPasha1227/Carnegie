import React from 'react';
import '../styles/scss/table.scss';
import '../styles/scss/dialog.scss';

import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';  
import Tooltip from '@mui/material/Tooltip';
import { Link} from 'react-router-dom';  


function documentsData(name, requested,  date, status, sign) {
    return { name, requested, date, status, sign};
}
  
const rows = [
    documentsData(' Mobile Project Agreement', 'Ravi Kumar','05 Dec 2022', 'In-Progress' ,'', 'Sign Now' ),
    documentsData(' Joining Agreement', 'Joseph', '10 Dec 2022' , 'Completed' ,'', 'Sign Now'),
];


function PendingWithMe() { 
    

   
   

    

    return (      
        <React.Fragment>  
            <div className='sub-header'>
                <div className='page-title'>
                    <h3>Pending with Me</h3>
                </div>
                <div className='page-filters'>
                    <ul>
                        <li>
                            <div className="search_area">
                                <input type="text" className="form-control" placeholder="Search for email or file name" />
                                {/* <img src="./images/search.png" className="search_icon" alt="search"> */}
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
            <div className='body-content'>
                <div className='eq-table'>
                    <TableContainer component={Paper}>
                        <Table aria-label="simple table">
                            <TableHead>
                                <TableRow>
                                    <TableCell>Document Name</TableCell>
                                    <TableCell>Requested By</TableCell>
                                    <TableCell>Due By</TableCell>
                                     <TableCell>Status</TableCell> 
                                   <TableCell>Actions</TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {rows.map((row) => (
                                <TableRow
                                    key={row.name}                                     
                                    >
                                    <TableCell>
                                        <span>{row.name}</span>
                                    </TableCell>  
                                    <TableCell> 
                                         {row.requested}
                                    </TableCell>                                  
                                    <TableCell> 
                                        {row.date}
                                    </TableCell>
                                    <TableCell>
                                        <span className={row.status+' es-status'}>{row.status}</span>
                                    </TableCell>
                                        <TableCell>
                                            <div className='d-inline-flex align-center'>
                                                <div className='td-link'>
                                                    Waiting for
                                                    <Tooltip arrow enterTouchDelay={1} leaveTouchDelay={5000}
                                                        title={
                                                        <React.Fragment>                                                            
                                                            <ul>
                                                                <li>
                                                                    <figure>
                                                                        <img src={require("../images/user-img.jpg")} alt="Material"/>
                                                                    </figure>
                                                                    <label>Ravi Kumar</label>
                                                                </li>
                                                                <li>
                                                                    <span>
                                                                        SK
                                                                    </span>
                                                                    <label>Syam Kumar</label>
                                                                </li>
                                                            </ul>
                                                        </React.Fragment>
                                                        }
                                                    >
                                                        <span>2 Signers</span>
                                                    </Tooltip>
                                                </div>             
                                            <button className=' primary_btn'>Sign Now</button>                                   
                                                <div  className='actions-td'>
                                                    
                                                    <Tooltip  enterTouchDelay={0}  arrow  placement="bottom-end"  id="actions-menu"
                                                        title={
                                                            <React.Fragment>    
                                                                <div className='actions-menu'>
                                                                    <ul>
                                                                        <li>
                                                                            <Link>View</Link>                                                                        
                                                                        </li>
                                                                        <li>
                                                                            <Link>Edit</Link>
                                                                        </li>
                                                                        <li>                                                                        
                                                                            <Link>Delete</Link>
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                            </React.Fragment>
                                                        }
                                                    > 
                                                        <span className='actions-icon'></span>
                                                    </Tooltip>
                                                </div>
                                            </div>
                                        </TableCell> 
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </TableContainer>
                </div>
            </div>
        </React.Fragment>        
    )
}

export default PendingWithMe;