import TextField from "@mui/material/TextField";

const customInput = (props) => {

    const { name, value, id, label, placeholder, variant, errors, helperText,onChangeTextField } = props

    //console.log("props ",props)

    return (
        <TextField
           
            name={props.name}
            value={value}
            onChange={(e) => onChangeTextField(e)}
            id={id}
            label={label}
            variant={variant}
            placeholder={placeholder}
            errors={errors}
            helperText={helperText}
        />
    )
}

export default customInput