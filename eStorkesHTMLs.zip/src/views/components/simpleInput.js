import React from 'react';
import '../../styles/scss/components/simpleInput.scss';
import TextField from '@mui/material/TextField';
import PhoneInput from 'react-phone-input-2';
import 'react-phone-input-2/lib/style.css';
import { Controller } from 'react-hook-form';
import parsePhoneNumber from 'libphonenumber-js';


function Simpleinput({ label = "", fieldName = "", id = "", isRequired = false, hideLabel = false, onInputChange, placeHolder, errorText,
    inputValue, register, errors, type = "", phoneCountryCode = {
        countryCode: 'US',
        countryCallingCode: '+1'
    }, control,ref }) {
        
    const handlePhoneNumberChange = (value, data, event, formattedValue) => {
        onInputChange(event, data, formattedValue, true)
        validatePhoneNumber(value)
    };
    const validatePhoneNumber = (value) => {
        try {
            const phoneNumber = parsePhoneNumber(value, phoneCountryCode.countryCode);
            if (!phoneNumber || !phoneNumber.isValid()) {
                return false;
            }
        } catch (error) {
            console.log("parsePhoneNumberFromString ", error)
            return false;
        }
        return true;
    };

    return (
        <div>
            <div>
                {type != 'phone' && type != 'email' &&
                    <TextField
                        // id={fieldName+id }
                       
                        ref={ref}
                        name={fieldName}
                        label={label ? label : ''}
                        hiddenLabel={hideLabel ? hideLabel : ''}
                        variant="outlined"
                        error={errors?.[fieldName] ? true : false}
                        //inputRef={fieldName+id }
                        placeholder={placeHolder ? (placeHolder + (isRequired && "*")) : ''}
                        // defaultValue={inputValue ? inputValue : ''}
                        type={type}

                        {...register(fieldName, { required: isRequired })}
                        onChange={onInputChange}
                        value={inputValue}
                    />}
                {type == 'email' &&
                    <TextField
                        // id={fieldName+id }
                        name={fieldName}
                        label={label ? label : ''}
                        hiddenLabel={hideLabel ? hideLabel : ''}
                        variant="outlined"
                        error={errors?.[fieldName] ? true : false}
                        //inputRef={fieldName+id }
                        placeholder={placeHolder ? (placeHolder + (isRequired && "*")) : ''}
                        // helperText={errors?.[fieldName] ?errorText+' is reqired':""}
                        defaultValue={inputValue ? inputValue : ''}
                        type={type}
                        value={inputValue}
                        {...register(fieldName, {
                            required: isRequired, pattern: {
                                value: /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
                                message: 'Invalid email address',
                            },
                        })}
                        onChange={onInputChange}
                    />}

                {type == 'phone' &&
                    <Controller
                        control={control}
                        name={fieldName}
                        variant="outlined"
                        value={inputValue}
                        rules={{ required: isRequired, validate: validatePhoneNumber, }}
                        // onChange={onInputChange}
                        render={({ field: { onChange, value } }) => (
                            <PhoneInput
                                placeholder={placeHolder ? (placeHolder + (isRequired && "*")) : ''}
                                country={phoneCountryCode.countryCode.toLowerCase()}
                               // onChange={handlePhoneNumberChange}
                                onChange={onChange
                                    //onChange(fieldName, { phoneNumber: value, countryData: countryData })
                                    //homePhone:{//fieldName
                                    // countryData:{name: 'Zimbabwe', dialCode: '263', countryCode: 'zw', format: '+... ... ... ... ... ..'}
                                    // phoneNumber: "263425873728657"
                                    //}
                                    // let phoneCountryCode={
                                    //         "countryCode": selectedCountry.countryCode,
                                    //         "countryCallingCode": selectedCountry.dialCode,
                                    // }
                                }
                                
                                id="phone-input"
                                value={inputValue}
                                countryCodeEditable={false}
                            // isValid={validatePhoneNumber}
                            />
                        )}

                    />


                }

            </div>
            {errors?.[fieldName] && errors?.[fieldName].type && errors?.[fieldName].type === "required" &&
                <span className='form_error'>{errorText + ' is reqired'}</span>}
            {errors?.[fieldName] && errors?.[fieldName].type && errors?.[fieldName].type === "validate" &&
                <span className='form_error'>{errorText + ' not valid'}</span>
            }
            {errors?.[fieldName] && errors?.[fieldName].type && errors?.[fieldName].type === "pattern" &&
                <span className='form_error'>{errors?.[fieldName].message}</span>
            }
        </div>
    )
}

export default Simpleinput;