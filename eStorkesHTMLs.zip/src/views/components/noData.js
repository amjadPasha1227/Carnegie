import React from 'react';
import '../../styles/scss/components/noData.scss';

function NoData() {
    return (
        <div class="nodataTemplate">
            <div class="accordian-table">
                <table class="tg">
                    <tr>
                        <th class="tg-cly1">
                            <div class="line"></div>
                        </th>
                        <th class="tg-cly1">
                            <div class="line"></div>
                        </th>
                        <th class="tg-cly1">
                            <div class="line"></div>
                        </th>
                        <th class="tg-cly1">
                            <div class="line"></div>
                        </th>
                        <th class="tg-cly1">
                            <div class="line"></div>
                        </th>
                        <th class="tg-cly1">
                            <div class="line"></div>
                        </th>
                    </tr>
                    <tr>
                        <td class="tg-cly1">
                            <div class="line"></div>
                        </td>
                        <td class="tg-cly1">
                            <div class="line"></div>
                        </td>
                        <td class="tg-cly1">
                            <div class="line"></div>
                        </td>
                        <td class="tg-cly1">
                            <div class="line"></div>
                        </td>
                        <td class="tg-cly1">
                            <div class="line"></div>
                        </td>
                        <td class="tg-cly1">
                            <div class="line"></div>
                        </td>
                    </tr>
                    <tr>
                        <td class="tg-cly1">
                            <div class="line"></div>
                        </td>
                        <td class="tg-cly1">
                            <div class="line"></div>
                        </td>
                        <td class="tg-cly1">
                            <div class="line"></div>
                        </td>
                        <td class="tg-cly1">
                            <div class="line"></div>
                        </td>
                        <td class="tg-cly1">
                            <div class="line"></div>
                        </td>
                        <td class="tg-cly1">
                            <div class="line"></div>
                        </td>
                    </tr>
                    <tr>
                        <td class="tg-cly1">
                            <div class="line"></div>
                        </td>
                        <td class="tg-cly1">
                            <div class="line"></div>
                        </td>
                        <td class="tg-cly1">
                            <div class="line"></div>
                        </td>
                        <td class="tg-cly1">
                            <div class="line"></div>
                        </td>
                        <td class="tg-cly1">
                            <div class="line"></div>
                        </td>
                        <td class="tg-cly1">
                            <div class="line"></div>
                        </td>
                    </tr>
                    <tr>
                        <td class="tg-cly1">
                            <div class="line"></div>
                        </td>
                        <td class="tg-cly1">
                            <div class="line"></div>
                        </td>
                        <td class="tg-cly1">
                            <div class="line"></div>
                        </td>
                        <td class="tg-cly1">
                            <div class="line"></div>
                        </td>
                        <td class="tg-cly1">
                        <div class="line"></div>
                        </td>
                        <td class="tg-cly1">
                            <div class="line"></div>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    )
}

export default NoData;