import React ,{useState}from 'react';
import PhoneInput from 'react-phone-input-2';
import 'react-phone-input-2/lib/style.css';

function PhoneNumberInput(props) {
    return (
        <div>
            <PhoneInput
             placeholder={props.placeholder}
             country={props.country}
             value={props.value}
             onChange={props.onChange}
             countryCodeEditable={false}
            />   
        </div>
    )
// const [searchTerm, setSearchTerm] = useState('');
// const handleSearch = (event) => {
//   setSearchTerm(event.target.value);
// };
// const CustomSearchInput = () => {
//   return (
//     <input
//       type="text"
//       value={searchTerm}
//       onChange={handleSearch}
//       placeholder="Search country code..."
//     />
//   );
// };
// return (
//   <PhoneInput
//     country={'us'}
//     disableDropdown={false}
//     disableSearchIcon={true}
//     inputExtraProps={{
//       autoComplete: 'off',
//     }}
//     inputComponent={CustomSearchInput}
//     searchPlaceholder="Search country code..."
//     searchValue={searchTerm}
//     //inputStyle={{ width: '100%',height:"50%",backgroundColor:'red' }}
//   />
// );
};
export default PhoneNumberInput;