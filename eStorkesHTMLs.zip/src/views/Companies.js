import React from 'react';
import { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import '../styles/scss/table.scss';
import '../styles/scss/dialog.scss';
import '../styles/scss/modal.scss';

import { EndPointService } from '../services/endPointServices';
import { FetchService } from '../services/fetchServices';
import { DateUtilService } from '../services/dateUtilService';
import { StorageService } from '../services/storageService';

import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import Tooltip from '@mui/material/Tooltip';
import { Link } from 'react-router-dom';
import { useTheme } from '@mui/material/styles';
import OutlinedInput from '@mui/material/OutlinedInput';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import { makeStyles } from "@material-ui/core/styles";
import Close from '../images/x-mark.svg';
import Grid from '@mui/material/Unstable_Grid2';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import InputLabel from '@mui/material/InputLabel';
import CustomInput from '../views/components/customInput';
import NoData from './components/noData'
import 'react-toastify/dist/ReactToastify.css';
import { Redirect } from 'react-router-dom/cjs/react-router-dom.min';
import Pagination from '@mui/material/Pagination';
import { ToastContainer, toast } from 'react-toastify';
import { TextField } from '@mui/material';
import Simpleinput from './components/simpleInput';



const usePlaceholderStyles = makeStyles(theme => ({
    placeholder: {
        color: "#aaa"
    }
}));

const Placeholder = ({ children }) => {
    const classes = usePlaceholderStyles();
    return <div className={classes.placeholder}>{children}</div>;
};

function documentsData(name, email, status, date, sign) {
    return { name, email, status, date, sign };
}

const rows = [
    documentsData(' Mobile Project Agreement', 'Madison@Scarlett.com', 'In-Progress', '', 'Sign Now'),
    documentsData(' Joining Agreement', 'Madison@Scarlett.com', 'Completed', '', 'Sign Now'),
    documentsData(' Project Extend Contract', 'Madison@Scarlett.com', 'Cancelled', '12-Dec-2022', '', ''),
    documentsData(' Website Design Agreement', 'Madison@Scarlett.com', 'In-Progress', '12-Dec-2022'),
    documentsData(' NDA Agreement', 'Madison@Scarlett.com', 'Completed', '12-Dec-2022'),
    documentsData(' Mobile Project Agreement', 'Madison@Scarlett.com', 'In-Progress', '12-Dec-2022'),
    documentsData(' Joining Agreement', 'Madison@Scarlett.com', 'Completed', '12-Dec-2022'),
    documentsData(' Project Extend Contract', 'Madison@Scarlett.com', 'Cancelled', '12-Dec-2022'),
    documentsData(' Website Design Agreement', 'Madison@Scarlett.com', 'In-Progress', '12-Dec-2022'),
    documentsData(' NDA Agreement', 'Madison@Scarlett.com', 'Completed', '12-Dec-2022'),
];

function Companies() {
    const [answer, setAnswer] = React.useState("");
    const [showNoData, setShowNoData] = React.useState(true)
    const { register, handleSubmit, formState: { errors }, reset, clearErrors, control } = useForm();
    const { register: register2, reset: reset2, handleSubmit: handleSubmit2, formState: { errors: errors2 }, clearErrors: clearErrors2, control: control2 } = useForm();

    const formFieldsList = [
        { name: "name", type: "", label: "Company Name", placeholder: "Company Name", required: true, helperText: "", md: 12, xs: 12 },
        { name: "fullName", type: "", label: "Full Name", placeholder: "Full Name", required: "", helperText: "", md: 6, xs: 6 },
        { name: "email", type: "email", label: "Email", placeholder: "Ex: username@domain", required: true, helperText: "", md: 6, xs: 6 },
        { name: "contactEmail", type: "", label: "Contact Email", placeholder: "Contact Email", required: "", helperText: "Optional", md: 6, xs: 6 },
        { name: "website", type: "", label: "Website", placeholder: "Website", required: "", helperText: "", md: 6, xs: 6 },
        { name: "phone", type: "phone", label: "Phone Number", placeholder: "Ex: +1 1231231230", required: "", helperText: "", md: 6, xs: 6 }
    ]

    const updateFormFieldsList = [
        { name: "name", type: "", label: "Company Name", placeholder: "Company Name", required: true, helperText: "", md: 12, xs: 12 },
        { name: "fullName", type: "", label: "Full Name", placeholder: "Full Name", required: "", helperText: "", md: 6, xs: 6 },
        { name: "email", type: "email", label: "Email", placeholder: "Ex: username@domain", required: true, helperText: "", md: 6, xs: 6 },
        { name: "contactEmail", type: "", label: "Contact Email", placeholder: "Contact Email", required: true, helperText: "Optional", md: 6, xs: 6 },
        { name: "website", type: "", label: "Website", placeholder: "Website", required: true, helperText: "", md: 6, xs: 6 },
        { name: "phone", type: "phone", label: "Phone Number", placeholder: "Ex: +1 1231231230", required: "", helperText: "", md: 6, xs: 6 }
    ]

    const registerOptions = {
        name: {
            required: {
                value: true,
                message: "Company name is required."
            },
            type: 'text'
        },
        firstName: {
            type: "text"
        },
        lastName: {
            type: "text"
        },
        email: {
            required: "Email is required.",
            type: "email",
            pattern: {
                message: "Enter Valid Email Address",
                value: /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/
            }
        },
        phoneNumber: {
            type: "tel",
            pattern: {
                value: /^[0-9+-]+$/,
                message: "Enter Valid Phone Number."
            }

        }
    }

    const [formDetails, setFormDetails] = React.useState({
        name: "",
        fullName: "",
        contactEmail: "",
        website: "",
        email: "",
        phoneCode: "+1",
        phone: ""
    })
    const [companiesList, setCompaniesList] = React.useState([])
    const [paginationProps, setPaginationProps] = React.useState({
        count: 1,
    })
    const [filters, setFilters] = React.useState({
        page: 1,
        perpage: 6,
        filters: {
            title: "",
            statusIds: [],
            createdByIds: [],
            createdOnRange: []
        },
        sorting: {
            path: "createdOn", // statusName,createdByName, name, email, phone, createdOn, updatedOn
            order: -1
        }
    })
    const theme = useTheme();
    const [personName] = React.useState([]);
    const [modalOpen, modalActive] = React.useState(false);
    const [modalStatusChangeOpen, modalStatusChangeActive] = React.useState(false)
    const [modalEditOpen, modalEditActive] = React.useState(false);
    //const [editCompanyId, setEditCompanyId] = React.useState("");
    const [statusChangeData, setStatusChangeData] = React.useState({
        companyId: "",
        statusId: "",
        statusName: ""
    })

    const [companyDetails, setCompanyDetails] = React.useState({
        companyId: "",
        name: "",
        fullName: "",
        email: "",
        contactEmail: "",
        website: "",
        phoneCode: "+1",
        phone: "",
        timezone: "",
        browserTS: "",
    })

    const getAccessToken = () => {
        const storageService = new StorageService();
        return (storageService.get("userinfo") === "undefined") ? "" : JSON.parse(storageService.get("userinfo")).accessToken
    }

    const onChangePage = (e, value) => {
        setFilters((prev) => ({ ...prev, page: value }))
    }

    const getCompaniesList = () => {
        //  console.log("request starting for companies list.................")
        const endpointService = new EndPointService();
        const fetchService = new FetchService();
        const token = getAccessToken()
        fetchService.post({
            url: endpointService.getCompaniesListUrl(),
            headers: token,
            data: filters
        })
            .subscribe(
                //onNext callback
                (response) => {
                    if (response.status_code === 200) {
                        let { list, totalCount, perpage } = response.result
                        let count = Math.ceil(totalCount / perpage)
                        setPaginationProps((prev) => ({ ...prev, count }))
                        setCompaniesList(list)
                        if (totalCount) {
                            setShowNoData(false)
                        }
                        else {
                            setShowNoData(true)
                        }

                    }
                    else {
                        let { message, error } = response.result.error_message
                        setCompaniesList([])
                        setShowNoData(true)
                        toast.error(message)
                    }

                },
                //onError callback
                (error) => {
                    console.error("There has been an error", error);

                }
            );
    }

    const showModal = event => {
        modalActive(current => !current);
    };
    const hideModal = () => modalActive(false);
    const hideEditModal = () => modalEditActive(false);
    const hideStatusChangeModal = () => modalStatusChangeActive(false)

    useEffect(() => {
        getCompaniesList()
    }, [filters, modalOpen, modalEditOpen, modalStatusChangeOpen])


    function getStyles(name, personName, theme) {
        return {
            fontWeight:
                personName.indexOf(name) === 1
                    ? theme.typography.fontWeightRegular
                    : theme.typography.fontWeightMedium,
        };
    }

    // const names = [
    //     'All Documents',
    //     'Pdf Documents',
    //     'Agreements',
    //     'Contracts',
    // ];

    //to add new company
    const onClickSave = (data) => {
        // console.log("you clicked on save.", data)
        const dateUtilService = new DateUtilService();
        const endpointService = new EndPointService();
        const fetchService = new FetchService();
        const token = getAccessToken()
        fetchService.post({
            url: endpointService.getCreateCompany(),
            data: {
                ...data,
                "timezone": dateUtilService.getTimeZone(),
                "browserTS": dateUtilService.getCurDateTime()
            },
            headers: token
        })
            .subscribe(
                //onNext callback
                (response) => {
                    if (response.status_code === 200) {
                        let { result } = response
                        let { message } = result
                        toast.success(message)
                        onClickCancel()
                    }
                    else {
                        let { error_message } = response.result
                        let { message, error } = error_message
                        toast.error(error_message)
                    }
                },
                //onError callback
                (error) => {
                    console.error("There has been an error", error);


                }
            );
    }

    // upon cancel of add new company form
    const onClickCancel = () => {
        reset()
        clearErrors()
        hideModal()
    }

    //change status to active or inactive
    const onActiveStatusChange = (e) => {
        e.preventDefault()
       // console.log("you clicked changing company status.")
        const dateUtilService = new DateUtilService();
        const endpointService = new EndPointService();
        const fetchService = new FetchService();
        const token = getAccessToken()

        fetchService.post({
            url: endpointService.getCompanyUpdateStatus(),
            data: {
                companyId: statusChangeData.companyId,
                statusId: statusChangeData.statusId,
                timezone: dateUtilService.getTimeZone(),
                browserTS: dateUtilService.getCurDateTime()
            },
            headers: token
        })
            .subscribe(
                //onNext callback
                (response) => {
                    if (response.status_code === 200) {
                        let { result } = response
                        let { message } = result
                        hideStatusChangeModal()
                        toast.success(message)
                        getCompaniesList()
                    }
                    else {
                        let { error_message } = response.result
                        let { message, error } = error_message
                        toast.error(error_message)
                    }
                },
                //onError callback
                (error) => {
                    console.error("There has been an error", error);
                    toast.error(error)

                }
            );
    }

    const getCompanyDetails = (companyId) => {
        // console.log("requesting company details...", companyId)
        const dateUtilService = new DateUtilService();
        const endpointService = new EndPointService();
        const fetchService = new FetchService();
        const token = getAccessToken()
        fetchService.post({
            url: endpointService.getCompanyDetailsUrl(),
            data: {
                companyId
            },
            headers: token
        })
            .subscribe(
                //onNext callback
                (response) => {
                    let { result } = response
                    if (response.status_code === 200) {
                        let { message } = result
                        const companyDetails = {
                            companyId: result._id ? result._id : "",
                            name: result.name ? result.name : "",
                            fullName: result.fullName ? result.fullName : "",
                            contactEmail: result.contactEmail ? result.contactEmail : "",
                            website: result.website ? result.website : "",
                            email: result.email ? result.email : "",
                            phoneCode: result.phoneCode ? result.phoneCode : "",
                            phone: result.phone ? result.phone : "",
                        }
                        setCompanyDetails(companyDetails)
                        reset2(companyDetails)
                        modalEditActive(true)
                    }
                    else {
                        let { error_message } = response.result
                        let { message, error } = error_message
                        toast.error(error_message)
                    }
                },
                //onError callback
                (error) => {
                    console.error("There has been an error", error);
                    alert(error)

                }
            );
    }

    const onChangeEditFormDetails = (e) => {
        const { name, value } = e.target
        setCompanyDetails((previous) => ({
            ...previous,
            [name]: value
        }))
    }

    //to update company details
    const onUpdateCompanyDetails = (data) => {
    // console.log("you clicked on edit submit ....",data)
        const dateUtilService = new DateUtilService();
        const endpointService = new EndPointService();
        const fetchService = new FetchService();
        const token = getAccessToken()
        const { name,website,contactEmail,phone,fullName,email } = data
        fetchService.post({
            url: endpointService.getUpdateCompany(),
            data: {
                companyId: companyDetails.companyId,
                name,
                fullName,
                email,
                contactEmail,
                website,
                phone,
                signDocUrl: "http://localhost:4200/#/auth/sign-document",
                timezone: dateUtilService.getTimeZone(),
                browserTS: dateUtilService.getCurDateTime()
            },
            headers: token
        })
            .subscribe(
                //onNext callback

                (response) => {
                    if (response.status_code === 200) {
                        let { result } = response
                        let { message } = result
                        toast.success(message)
                        onCancelDetailsUpdate()
                    }
                    else {
                        let { error_message } = response.result
                        let { message, error } = error_message
                        toast.error(message)
                        hideEditModal()
                    }
                },
                //onError callback
                (error) => {
                    console.error("There has been an error", error);
                    alert(error)

                }
            );
    }

    // to cancel update company details 
    const onCancelDetailsUpdate = () => {
        setCompanyDetails({
            companyId: "",
            name: "",
            fullName: "",
            email: "",
            contactEmail: "",
            website: "",
            phoneCode: "+1",
            phone: "",
            timezone: "",
            browserTS: "",
        })
        hideEditModal()
    }

   // to store add new company form details change
    const onChangeFormDetails = (e) => {
        const { name, value } = e.target
        setFormDetails((previous) => ({
            ...previous,
            [name]: value
        }))
    }

    const onEditClick = (companyId) => {
        getCompanyDetails(companyId)
    }

    const onClickChangeStatus = (companyId, statusId, statusName) => {
        modalStatusChangeActive(true)
        setStatusChangeData({ companyId, statusId, statusName })
    }



    // to store search value changes
    const onChangeSearchInput = (e) => {
        const { name, value } = e.target
        setFilters((prev) => ({
            ...prev,
            filters: { ...prev.filters, [name]: value }
        }))
    }

    const renderCompaniesListView = () => {
        return (
            <TableContainer component={Paper}>
                <Table aria-label="simple table">
                    <TableHead>
                        <TableRow>
                            <TableCell>Company Name</TableCell>
                            <TableCell>Name</TableCell>
                            <TableCell>Email</TableCell>
                            <TableCell>Phone Number</TableCell>
                            <TableCell>Status</TableCell>
                            <TableCell>Actions</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {
                            companiesList.map((row) => {

                                let phone = row.phone ? row.phone : undefined
                                let phoneCode = row.phoneCode ? row.phoneCode : ""
                                let phoneNumber = (phone === undefined) ? "-" : `${phoneCode} ${phone}`
                                let changeStatusText = (row.statusId === 1) ? "Activate" : "Inactivate"
                                let changeToStatusId = (row.statusId === 1) ? 2 : 3

                                return (<TableRow
                                    key={row.name}
                                >
                                    <TableCell>
                                        <span>{row.name}</span>
                                    </TableCell>
                                    <TableCell>
                                        <span>
                                            {row.name}
                                        </span>
                                    </TableCell>
                                    <TableCell>
                                        <span>
                                            {row.email}
                                        </span>
                                    </TableCell>
                                    <TableCell>
                                        <span>{phoneNumber}</span>
                                    </TableCell>
                                    <TableCell>
                                        <span>{row.statusDetails.name}</span>
                                    </TableCell>
                                    <TableCell>
                                        <div className='d-inline-flex align-center'>
                                            <div className='actions-td'>

                                                <Tooltip enterTouchDelay={0} placement="bottom-end" id="actions-menu" effect="solid"
                                                    arrow
                                                    title={
                                                        <React.Fragment>
                                                            <div className='actions-menu'>
                                                                <ul>
                                                                    <li>
                                                                        <Link>View</Link>
                                                                    </li>
                                                                    <li onClick={() => onClickChangeStatus(row._id, changeToStatusId, changeStatusText)} >
                                                                        <Link>{changeStatusText}</Link>
                                                                    </li>
                                                                    <li onClick={() => onEditClick(row._id)}>
                                                                        <Link>Edit</Link>
                                                                    </li>
                                                                    <li>
                                                                        <Link>Delete</Link>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </React.Fragment>
                                                    }
                                                >
                                                    <span className='actions-icon'></span>
                                                </Tooltip>
                                            </div>
                                        </div>
                                    </TableCell>
                                </TableRow>)
                            }
                            )
                        }
                    </TableBody>
                    {/* <TableBody> */}
                    {/* {rows.map((row) => (
                    <TableRow
                        key={row.name}
                    >
                        <TableCell>
                            <span>{row.name}</span>
                        </TableCell>
                        <TableCell>
                            <span>
                                SY
                            </span>
                        </TableCell>
                        <TableCell>
                            <span>
                                SY@yopmail.com
                            </span>
                        </TableCell>
                        <TableCell>
                            <span>+91 9876543210</span>
                        </TableCell>
                        <TableCell>
                            <div className='d-inline-flex align-center'>
                                <div className='actions-td'>

                                    <Tooltip enterTouchDelay={0} placement="bottom-end" id="actions-menu" effect="solid"
                                        arrow
                                        title={
                                            <React.Fragment>
                                                <div className='actions-menu'>
                                                    <ul>
                                                        <li>
                                                            <Link>View</Link>
                                                        </li>
                                                        <li>
                                                            <Link>Edit</Link>
                                                        </li>
                                                        <li>
                                                            <Link>Delete</Link>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </React.Fragment>
                                        }
                                    >
                                        <span className='actions-icon'></span>
                                    </Tooltip>
                                </div>
                            </div>
                        </TableCell>
                    </TableRow>
                ))} */}
                  
                </Table>
            </TableContainer>
        )
    }


    return (
        <React.Fragment>
            <ToastContainer
                position="top-center"
                autoClose={5000}
                hideProgressBar={false}
                newestOnTop={false}
                closeOnClick
                rtl={false}
                pauseOnFocusLoss
                draggable
                pauseOnHover
                theme="colored"
            />
            <div className='sub-header'>
                <div className='page-title'>
                    <h3>Companies</h3>
                </div>
                <div className='page-filters'>
                    <ul>
                        <li>
                            <div className="search_area">
                                <input type="text" className="form-control" placeholder="Search for email or file name" name="title" onChange={onChangeSearchInput} />
                                {/* <img src="./images/search.png" className="search_icon" alt="search"> */}
                            </div>
                        </li>
                        <li>
                            <button className='primary_btn' onClick={showModal}>Add New</button>
                        </li>
                    </ul>
                </div>
            </div>
            <div className='body-content'>
                <div className='eq-table'>
                    { showNoData ? <NoData /> : renderCompaniesListView() }
                </div>
            </div>
            {/* add company modal */}
            <div className={modalOpen ? "custom_modal open" : "custom_modal"} >
                <div className='modal-dialog'>
                    <div className='modal-content'>
                        <div className='modal-header'>
                            <h2 className='modal-title'>Add Company</h2>
                            <a className="close_btn" onClick={onClickCancel}><img src={Close} alt='close' /></a>
                        </div>
                        <form onSubmit={handleSubmit(onClickSave)}>
                            <div className='modal-body'>
                                {/* <Grid container xs={12} spacing={1.3}>
                                <Grid md={12} xs={12}>
                                <div className='form-group'>
                                        <TextField
                                            label="Company Name"
                                            hiddenLabel
                                            placeholder="Company Name"
                                            
                                            name="name"
                                        {...register('name',registerOptions.name)}
                                            value={formDetails.name}
                                            helperText={errors?.name && errors.name.message}
                                            onChange={onChangeFormDetails} />
                                            
                                    </div>
                                </Grid>
                                <Grid md={6} xs={6}>
                                    <div className='form-group'>
                                        <TextField
                                         label="First Name" 
                                         hiddenLabel 
                                         placeholder="First Name" 
                                         name="firstName"   
                                         {...register('firstName',registerOptions.firstName)} 
                                         value={formDetails.firstName} 
                                         onChange={onChangeFormDetails} />
                                    </div>
                                </Grid>
                                <Grid md={6} xs={6}>
                                    <div className='form-group'>
                                        <TextField label="Last Name"
                                         hiddenLabel 
                                         placeholder="Last Name" 
                                         name="lastName"   
                                         {...register('lastName',registerOptions.lastName)} 
                                         value={formDetails.lastName} 
                                         onChange={onChangeFormDetails} />
                                    </div>
                                </Grid>
                                <Grid md={6} xs={6}>
                                    <div className='form-group'>
                                        <TextField
                                            label="Email"
                                            hiddenLabel
                                            placeholder="username@domain"
                                            helperText={errors?.email && errors.email.message}
                                            name="email"
                                        {...register('email',registerOptions.email)}
                                            value={formDetails.email}
                                            onChange={onChangeFormDetails} />
                                    </div>
                                </Grid>
                                <Grid md={6} xs={6}>
                                    <div className='form-group'>
                                        <TextField label="Phone Number" 
                                        hiddenLabel 
                                        placeholder="Phone Number" 
                                        name="phone"   
                                        {...register('phone',registerOptions.phone)} 
                                        value={formDetails.phone} 
                                        onChange={onChangeFormDetails} />
                                    </div>
                                </Grid>
                            </Grid> */}
                                <Grid container xs={12} spacing={1.3}>
                                    {formFieldsList.map((field) => (
                                            <Grid md={field.md} xs={field.xs}>
                                                <div className='form-group'>

                                                    <Simpleinput
                                                        id={field.name}
                                                        fieldName={field.name}
                                                        label={field.label}
                                                        hideLabel={true}
                                                        placeHolder={field.placeholder}
                                                        errorText={field.placeholder}
                                                        register={register}
                                                        inputValue={formDetails[field.name]}
                                                        onInputChange={onChangeFormDetails}
                                                        errors={errors}
                                                        type={field.type}
                                                        control={control}
                                                        isRequired={field.required}


                                                    />
                                                </div>

                                            </Grid>
                                        )
                                    )}
                                </Grid>

                            </div>
                            <div className='modal-footer'>
                                <button className="primary_btn more" type='button' onClick={onClickCancel} >Cancel</button>
                                <button className="primary_btn active" type='submit'  >Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            {/* company details update modal */}
            <div className={modalEditOpen ? "custom_modal open" : "custom_modal"} >
                <div className='modal-dialog'>
                    <div className='modal-content'>
                        <div className='modal-header'>
                            <h2 className='modal-title'>Update Company Details</h2>
                            <a className="close_btn" onClick={hideEditModal}><img src={Close} alt='close' /></a>
                        </div>
                        <form onSubmit={handleSubmit2(onUpdateCompanyDetails)}>
                            <div className='modal-body'>

                                <Grid container xs={12} spacing={1.3}>
                                    {updateFormFieldsList.map((field) => {

                                        return (
                                            <Grid md={field.md} xs={field.xs}>
                                                <div className='form-group'>
                                                    <Simpleinput
                                                         id={field.name}
                                                         fieldName={field.name}
                                                         label={field.label}
                                                         hideLabel={true}
                                                         placeHolder={field.placeholder}
                                                         errorText={field.placeholder}
                                                         register={register2}
                                                         inputValue={companyDetails[field.name]}
                                                         onInputChange={onChangeEditFormDetails}
                                                         errors={errors2}
                                                         type={field.type}
                                                         control={control2}
                                                         isRequired={field.required}
                                                    />
                                                </div>
                                            </Grid>
                                        )
                                    })}
                                </Grid>
                            </div>
                            <div className='modal-footer'>
                                <button className="primary_btn more" type='button' onClick={onCancelDetailsUpdate} >Cancel</button>
                                <button className="primary_btn active" type='submit'  >Update</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            {/* status change modal */}
            <div className={modalStatusChangeOpen ? "custom_modal open" : "custom_modal"} >
                <div className='modal-dialog'>
                    <div className='modal-content'>
                        <div className='modal-header'>
                            <h2 className='modal-title'>Company Status Change</h2>
                            <a className="close_btn" onClick={hideStatusChangeModal}><img src={Close} alt='close' /></a>
                        </div>
                        <form onSubmit={onActiveStatusChange}>
                            <div className='modal-body'>
                                <p>Click on Confirm to {statusChangeData.statusName}</p>
                            </div>
                            <div className='modal-footer'>
                                <button className="primary_btn more" type='button' onClick={hideStatusChangeModal} >Cancel</button>
                                <button className="primary_btn active" type='submit'  >Confirm</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <Pagination
                count={paginationProps.count}
                page={filters.page}
                onChange={onChangePage}
                // defaultPage={4} 
                // siblingCount={0} 
                // boundaryCount={2}
                size='large'
                color="secondary"
                variant="outlined"
                shape="rounded" />
        </React.Fragment>
    )

}

export default Companies;