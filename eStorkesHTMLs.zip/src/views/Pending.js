import React from 'react';
import '../styles/scss/table.scss';
import '../styles/scss/dialog.scss';

import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';  
import Tooltip from '@mui/material/Tooltip';
import { Link} from 'react-router-dom'; 
import search from '../images/searching.svg';

function documentsData(name, reqname, date, status, sign) {
    return { name, reqname, date, status, sign};
}
  
const rows = [
    documentsData(' Mobile Project Agreement', 'Ravi Kumar', '05 Dec 2022', 'In-Progress','', 'Sign Now'),
    documentsData(' NDA Agreement', 'Joseph', '10 Dec 2022', 'In-Progress', 'Sign Now' ),
];

function Pending() { 

    return (      
        <React.Fragment>  
            <div className='sub-header'>
                <div className='page-title'>
                    <h3>Pending with Me</h3>
                </div>
                <div className='page-filters'>
                    <ul>       
                        <li>
                            <div className="search_area">
                                <input type="text" className="form-control" placeholder="Search for email or file name" />
                                <img src={search} alt="search"/>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
            <div className='body-content'>
                <div className='eq-table'>
                    <TableContainer component={Paper}>
                        <Table aria-label="simple table">
                            <TableHead>
                                <TableRow>
                                    <TableCell>Document Name</TableCell>
                                    <TableCell>Requested By</TableCell>
                                    <TableCell>Due By</TableCell>
                                     <TableCell>Status</TableCell> 
                                   <TableCell>Actions</TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {rows.map((row) => (
                                <TableRow
                                    key={row.name}                                     
                                    >
                                    <TableCell>
                                        <span>{row.name}</span>
                                    </TableCell>  
                                    <TableCell> 
                                        <span>{row.reqname}</span>
                                    </TableCell>  
                                    <TableCell> 
                                        <span>{row.date}</span>
                                    </TableCell> 
                                    <TableCell>
                                        <span className={row.status+' es-status'}>{row.status}</span>
                                    </TableCell>   
                                    <TableCell>
                                        <div className='flex-label'>
                                            <div className='list-elements'>
                                                        <Tooltip arrow
                                                            title={
                                                            <React.Fragment>                                                            
                                                                <ul>
                                                                    <li>
                                                                        <span>
                                                                            MK
                                                                        </span>
                                                                        <label>Madhu Kumar</label>
                                                                    </li>
                                                                    <li>
                                                                        <span>
                                                                        JP
                                                                        </span>
                                                                        <label>Joseph</label>
                                                                    </li>
                                                                    <li>
                                                                        <span>
                                                                        RK
                                                                        </span>
                                                                        <label>Ravi Kumar</label>
                                                                    </li>
                                                                </ul>
                                                            </React.Fragment>
                                                            }
                                                        >
                                                        <span className='waiting-list'>Waiting for <span>2 Signers</span></span>
                                                        </Tooltip>
                                            </div>
                                            <button className=' primary_btn'>Sign Now</button>
                                            <div arrow className='actions-td'>
                                                <Tooltip  enterTouchDelay={0}  
                                                    title={
                                                        <React.Fragment>    
                                                            <div className='actions-menu'>
                                                                <ul>
                                                                    <li>
                                                                        <Link>View</Link>                                                                        
                                                                    </li>
                                                                    <li>
                                                                        <Link>Edit</Link>
                                                                    </li>
                                                                    <li>                                                                        
                                                                        <Link>Delete</Link>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </React.Fragment>
                                                    }
                                                > 
                                                    <span className='actions-icon'></span>
                                                </Tooltip>
                                            </div>
                                        </div>
                                    </TableCell> 
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </TableContainer>
                </div>
            </div>
        </React.Fragment>        
    )
}

export default Pending;