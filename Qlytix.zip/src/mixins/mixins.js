import Vue from 'vue'
import { _ } from 'core-js'
import moment from "moment";


Vue.mixin({
  data(){
    return{
      

    }
  },
  created: function () {
  },
  methods: {

   
    showToster({message='',isError=false }){
      // alert(JSON.stringify(message))
      let duration = 3000 
      try{
        this.$toast.clear()
      }catch(e){

      }
      setTimeout(()=>{

      
        if(isError){
    
          this.$toast.open({
            message: message,
            type: "error",
            duration: duration,
            position:"top-right"
          });
    
        }else{
          this.$toast.open({
            message: message,
            type: "success",
            duration: duration,
            position:"top-right"
          });
          
          
    
      }
    } ,1)
    },


  },
  computed:{
    
    getCurrentUser() {
      if(_.has(this.$store.state,'user') ){
        let user =_.cloneDeep(this.$store.state['user']);
        if(_.has(user,'_id') && _.has(user['_id'] ,'$oid')){
          user =Object.assign(user ,{ "userId":user['_id']['$oid'] });
        }
        return user
      }else{
        return null
      }
      
    },
    getUserRoleId(){
      if(_.has(this.$store.state,'user') && _.has(this.$store.state['user'] ,'role_id')){
        return this.$store.state['user']['role_id']
      }else{
        return 0;
      }
     
    },
    getDtatType(){
      return (data='')=>{

        let datatype = typeof(data);
            datatype = datatype.charAt(0).toUpperCase() + datatype.slice(1);
            if(datatype=='Number'){
              datatype ='Integer'
            }
            return datatype

      }
    }
    
  },
  mounted(){

  },
  watch: {
   
  }
 
})
