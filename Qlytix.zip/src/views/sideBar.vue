<template>
    <div class="side_menu" id="mobile_menu">
        <ul>
            <li class="dashboard"  v-if="getCurrentUserPermissions(1)">
                <a href="#">
                    <span class="menu-img"></span>
                    <!-- <img src="@/assets/images/menu/dashboard.svg" class="defaultimg">
                    <img src="@/assets/images/menu/dashboardClrd.svg" class="hoverimg"> -->
                    <span class="menu-text">Dashboard</span>
                </a>
            </li>
            <li class="reports" v-if="getCurrentUserPermissions(2)">
                <a href="#">
                    <span class="menu-img"></span>
                    <!-- <img src="@/assets/images/menu/report.svg" class="defaultimg">
                    <img src="@/assets/images/menu/reportClrd.svg" class="hoverimg"> -->
                    <span class="menu-text">Reports</span>
                </a>
            </li>
            <li v-if="getCurrentUserPermissions(3)" class="data-collection" @click="gotoPage('/data-collection')" :class="[{'active': $route.path.indexOf('data-collection') > -1 }]">
                <a href="javascript:;">
                    <span class="menu-img"></span>
                    <!-- <img src="@/assets/images/menu/data-collection.svg" class="defaultimg">
                    <img src="@/assets/images/menu/data-collectionClrd.svg" class="hoverimg"> -->
                    <span class="menu-text">Data Collection</span>
                </a>
            </li>
            <li class="rule-engine" v-if="getCurrentUserPermissions(4)">
                <a href="#">
                    <span class="menu-img"></span>
                    <!-- <img src="@/assets/images/menu/rule-engine.svg" class="defaultimg">
                    <img src="@/assets/images/menu/rule-engineClrd.svg" class="hoverimg"> -->
                    <span class="menu-text">Rule Engine</span>
                </a>
            </li>
            <li v-if="getCurrentUserPermissions(5)" class="users" @click="gotoPage('/users')" :class="[{'active': $route.path.indexOf('users') > -1 }]">
                <a href="javascript:;">
                    <span class="menu-img"></span>
                    <!-- <img src="@/assets/images/menu/users.svg" class="defaultimg">
                    <img src="@/assets/images/menu/usersClrd.svg" class="hoverimg"> -->
                    <span class="menu-text">Users</span>
                </a>
               
            </li>
        </ul>
    </div>
</template> 
<script>
import * as _ from "lodash";

export default {
      name: 'side-bar',
      computed:{
    
    getCurrentUserPermissions() {
      /*  [
    {
      "_id":1,
       "name":"Dashboard"
    },
    {
      "_id":2,
      "name":"Reports"

    },
    {
      "_id":3,
      "name":"Data Collection"

    },
    {
      "_id":4,
      "name":"Rule Engine"

    },
    {
      "_id":5,
      "name":"Users"

    }
    ]*/
    return (itemId)=>{

    
        let returnVal =false;
      if(_.has(this.$store.state,'user') ){
        let user =_.cloneDeep(this.$store.state['user']);

        
        if(user  && _.has(user ,'modules') && user['modules'].length>0){
            if(_.find(user['modules'] ,{'_id':itemId}) || user['role_id'] ==1  ){
                returnVal =true;
            }

        }else{
            returnVal =true;
        }
         
      }else{
        returnVal =true;

      }
      return returnVal;
    }
      
    }
},
      
      components: {
       
       
      },
      data: () => ({ 
     
    }),
    methods: {
        gotoPage(path='/'){
            this.$router.push(path)
        }
       
      },
    }
    </script>

