<template>
  <div>
    <div class="sub_header">
      <div class="sub_header_left m-0">
        <a @click="goToList()"><img src="@/assets/images/left-chevron.svg" /></a>        
        <template v-if="userId"><h5>Edit User</h5></template>
        <template v-else><h5>Add User</h5></template>
        
      </div>
    </div>
    <div class="dsConfig_sec">

      <b-alert show dismissible v-if="showErros">
    {{errormessage}} <b>&rArr;</b>
  </b-alert> 
      <form @submit.prevent>
        <simpleInput
          :wrapclass="'col-md-12'"
          :fieldName="'first_name'"
          :cid="'first_name'"
          :vvas="'First Name'"
          :label="'First Name'"
          :display="true"
          :place-holder="'First Name'"
          :required="true"
          v-model="user.first_name"
          :allowAlphNum="true"
        />

        <simpleInput
          :wrapclass="'col-md-12'"
          :fieldName="'middle_name'"
          :cid="'middle_name'"
          :vvas="'Middle Name'"
          :label="'Middle Name'"
          :display="true"
          :place-holder="'Middle Name'"
          :required="false"
          v-model="user.middle_name"
          :allowAlphNum="true"
        />

        <simpleInput
          :wrapclass="'col-md-12'"
          :fieldName="'last_name'"
          :cid="'last_name'"
          :vvas="'Last Name'"
          :label="'Last Name'"
          :display="true"
          :place-holder="'Last Name'"
          :required="true"
          v-model="user.last_name"
          :allowAlphNum="true"
        />

        <simpleInput
           :disabled="userId?true:false"
          :wrapclass="'col-md-12'"
          :fieldName="'email'"
          :cid="'email'"
          :vvas="'Email'"
          :label="'Email'"
          :display="true"
          :place-holder="'Email'"
          :required="true"
          :datatype="'email'"
          v-model="user.email"
          :emailFormat="true"
        />

        <simpleInput
          :wrapclass="'col-md-12'"
          :fieldName="'employee_id'"
          :cid="'employee_id'"
          :vvas="'Employee ID'"
          :label="'Employee ID'"
          :display="true"
          :place-holder="'Employee ID'"
          :required="true"
          v-model="user.employee_id"
          :allowAlphNum="true"
        />

        <simpleselect
         
          :multiple="false"
          :wrapclass="'col-md-12'"
          :optionslist="roles"
          :fieldName="'role'"
          :cid="'role'"
          :vvas="'Role'"
          :label="'Role'"
          :display="true"
          :place-holder="'Role'"
          :searchable="false"
          :required="true"
          v-model="selectedRole"
          :isDisabled="userId?true:false"
          @input="chagedRole"
        />

        <simpleselect
          v-if="selectedRole && selectedRole['_id'] !=1"
          :multiple="true"
          :wrapclass="'col-md-12'"
          :optionslist="modules"
          :fieldName="'modules'"
          :cid="'modules'"
          :vvas="'Access Permissions'"
          :label="'Access Permissions'"
          :display="true"
          :place-holder="'Access Permissions'"
          :searchable="false"
          :required="true"
          v-model="user.modules"
          :close-on-select="false"
          :clear-on-select="false"
          :hide-selected="true"
        />

        <div class="divider"></div>
        <div class="col-12 text-end">
        
          <button :disabled="showLoader" @click="saveAction()" class="primary_btn sm" type="button">
            <span class="btn_loader" v-if="showLoader"></span>
            <template v-if="userId">Update</template>
            <template v-else>Save</template>
          </button>
        </div>
      </form>
    </div>

   

   <!----- <span class="globalloader" v-if="showLoader" ><img src="@/assets/images/loader.gif"></span>-->

  </div>
</template> 

<script>
import simpleInput from "@/views/forms/simple-input.vue";
import passwordInput from "@/views/forms/password.vue";

import simpleselect from "@/views/forms/simpleselect.vue";
import * as XLSX from "xlsx";
import VueTimepicker from 'vue2-timepicker'
import * as _ from "lodash";

// CSS
import 'vue2-timepicker/dist/VueTimepicker.css'

export default {
  name: "data-source",
  components: {
    simpleInput,
    simpleselect,
    passwordInput,
    VueTimepicker
  },
  provide() {
    return {
      parentValidator: this.$validator,
    };
  },
  data: () => ({
    selectedRole:null,
    roles:[
    {
      "_id": 1, 
      "name": "Administrator"
    }, 
    {
      "_id": 2, 
      "name": "Manager"
    }, 
    {
      "_id": 3, 
      "name": "Employee"
    }
  ],
    showErros:false,
    errormessage:null,
    showLoader:false,
    filerequired:false,
    customizeData: false,
    datasourcetypes: [],
    apitypes: [],
    ftptypes: [],
    scheduletype:null,
    dataheaders: [],
    scheduletypes: [],
    modules:[
    {
      "_id":1,
       "name":"Dashboard"
    },
    {
      "_id":2,
      "name":"Reports"

    },
    {
      "_id":3,
      "name":"Data Collection"

    },
    {
      "_id":4,
      "name":"Rule Engine"

    },
    {
      "_id":5,
      "name":"Users"

    }
    ],
    file:null,
    ftptype:null,
      apitype:null,
      type:null,
    user: {
      first_name:'',
      middle_name:'',
      employee_id:'',
      last_name:'',
      email:null,
      role_id:null,
      modules:null
    },
    userId:null,
    userDetails:null,
  }),
  mounted() {

    if(this.$store.getters['getuserRole'] !=1){
      this.goToList();
    }
    
    this.getDataSources();
    if(this.$route.params && this.$route.params.id) {
      this.userId = this.$route.params.id;
      this.getUserDetails(); 
    }
  },
  methods: {
    chagedRole(){
     
      if(this.userId){

        if(_.has(this.userDetails['UserDetails'] ,'modules')){
          this.user['modules'] = this.userDetails['UserDetails']['modules'];
        }

      }else{

        if(this.selectedRole['_id'] ==1){
          this.user['modules'] = this.modules;
        }else{
          this.user['modules'] = [];
          

        }
        this.$validator.reset();


      }

      

    },
    goToList(){
      this.$router.push("/users");
    },
    prefillData(){ 
       if(this.userDetails && _.has(this.userDetails ,'UserDetails')){

        if(_.has(this.userDetails['UserDetails'] ,'email')){
          this.user['email'] = this.userDetails['UserDetails']['email'];
        }
        if(_.has(this.userDetails['UserDetails'] ,'first_name')){
          this.user['first_name'] = this.userDetails['UserDetails']['first_name'];
        }
        this.user['middle_name'] ='';
        if(_.has(this.userDetails['UserDetails'] ,'middle_name')){
          this.user['middle_name'] = this.userDetails['UserDetails']['middle_name'];
        }
        if(_.has(this.userDetails['UserDetails'] ,'last_name')){
          this.user['last_name'] = this.userDetails['UserDetails']['last_name'];
        }
        if(_.has(this.userDetails['UserDetails'] ,'modules')){
          this.user['modules'] = this.userDetails['UserDetails']['modules'];
        }
        if(_.has(this.userDetails['UserDetails'] ,'role_id')){
          
            this.selectedRole = _.find(this.roles,{ "_id":this.userDetails['UserDetails']['role_id']} );
        }
        
        if(_.has(this.userDetails['UserDetails'] ,'employee_id')){
          this.user['employee_id'] = this.userDetails['UserDetails']['employee_id'];
        }

       }
    },
    getUserDetails(){
      let payload = {
        user_id:null
      }
      payload['user_id'] = this.userId;
      this.$store
        .dispatch("commonAction", {
          data: payload,
          path: "/users/get-details",
        })
        .then((response) => {
          let userDetails = JSON.parse(response);
          if(userDetails && userDetails.length>0){
            this.userDetails = userDetails[0];
            this.prefillData();
          }
         
        }).catch(()=>{

        });

    },
    makeToast(variant = null, message) {
        this.$bvToast.toast(message, {
          title: `Error`,
          delay: 50000,
          variant: variant
        })
    },
    clearErrors(){

      this.showErros = false;
      this.errormessage = null;


    },
    
    
    
    getDataSources() {
      this.$store
        .dispatch("getList", {
          data: { name: "Roles" },
          path: "/masterdata/list",
        })
        .then((response) => {
          if(_.has(response ,'result') && response['result'].length>0 ){
            this.roles =  response['result'];
          }
         
          this.prefillData();
        });
    },
    saveAction() {
      this.clearErrors();
      this.$validator.validateAll().then((result) => {
      
        if(result){
        this.showLoader =true;
        if(this.selectedRole && this.selectedRole._id!=null){
          this.user.role_id = this.selectedRole._id
        }

        if(this.selectedRole['_id'] ==1){
          this.user['modules'] = this.modules;
        }
        let propsData =_.cloneDeep(this.user);

        if(_.has(propsData ,'employee_id'))
          propsData['employee_id'] = propsData['employee_id'].trim();

        if(_.has(propsData ,'email')){
          propsData['email'] = propsData['email'].trim();
          propsData['email'] = propsData['email'].toLowerCase();
          
        }
          

        let path = "/users/add";
       // propsData['email'] = propsData['email'].trim()
        if(this.userId){
          path ="/users/edit"
          _.unset(propsData, "email");
          _.unset(propsData, "role_id");
          propsData = Object.assign(propsData ,{"user_id":this.userId});
          propsData['user_id'] = this.userId;
        }       
    
       

      this.$store
        .dispatch("commonAction", {
          data: propsData,
          path: path,
        })
        .then((response) => {
          this.showLoader =false;
          if(_.has(response ,'message')){
            this.showToster({message:response.message,isError:false })
          }else{
           let msg = 'User created Successfully';
            if(this.userId){
              msg = 'User details updated successfully'
            }
            this.showToster({message:msg,isError:false })
          }
        
          
          
          var _s = this;
          setTimeout(function(){
            _s.$router.push("/users");
          },500)

        }).catch((error) => { 
          
          this.showLoader = false;
          if(_.has(error ,'message')){
              this.showToster({message:error.message,isError:true });
            }else{
              this.showToster({message:'Something went wrong',isError:true });
              //Something went wrong
            }



      });

        }
      });
    },
  },
};
</script>
