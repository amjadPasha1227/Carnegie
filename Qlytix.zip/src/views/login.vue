<template>
  <div class="login_area">
    <form>
      <div v-if="!showForgotPassword"  >
        <h4 class="text-center">Login</h4>
        <input
        @keyup.enter.native="login()"
          type="text"
          class="form-control"
          :data-vv-as="'Email'"
          v-validate="'required'"
          v-model="email"
          placeholder="Email"
          name="email"
         
        />
        <p v-show="errors.has('email')" class="form-error">
          {{ errors.first("email") }}
        </p>

        <div class="password_area"  >
          <input
            @keyup.enter.native="login()"
            v-validate="'required'"
            :data-vv-as="'Password'"
            v-model="password"
            :type="showPassword?'text':'password'"
            class="form-control eye"
            placeholder="Password"
            id="inputPassword"
            name="password"
            
          />
          <div v-if="password" class="view_eye" :class="{ close : showPassword }" @click="toggleShow">
          </div>
          <p v-show="errors.has('password')" class="form-error">
            {{ errors.first("password") }}
          </p>
        </div>
        <div class="keep_logged_in">
          <div class="form-check">
            <input
            v-model="checkbox_remember_me"
              type="checkbox"
              class="form-check-input"
              id="keepMeLoggedIn"
            />
            <label class="form-check-label" for="keepMeLoggedIn"
              >Remember me </label
            >
          </div>
          <a @click="showForgotPassword = true ;disabledBtn =false">Trouble logging in?</a>
        </div>
        <button :disabled="disabledBtn" type="button" @click="login()" class="login_btn">
          <span class="btn_loader" v-if="disabledBtn"></span>
          Sign In
        </button>
      </div>

      <div v-if="showForgotPassword" @keyup.enter.native="forgotPassword()">
        <h4 class="text-center">Forgot Password</h4>
        <input
        
          type="text"
          class="form-control"
          :data-vv-as="'Email'"
          v-model="email"
          v-validate="'required'"
          placeholder="Email"
          name="email"
        />
        <p v-show="errors.has('email')" class="form-error">
          {{ errors.first("email") }}
        </p>

        <div class="keep_logged_in">
          <a @click="showForgotPassword = false ,disabledBtn=false">Back to sign in?</a>
        </div>
        <button :disabled="disabledBtn" type="button" @click="forgotPassword()" class="login_btn">
          <span class="btn_loader" v-if="disabledBtn"></span>
          Submit
        </button>
      </div>
    </form>
  </div>
</template>
<script>
import simpleInput from "@/views/forms/simple-input.vue";
import * as _ from "lodash";
export default {
  name: "LoginView",
  provide() {
    return {
      parentValidator: this.$validator,
    };
  },
  components: {
    simpleInput,
  },
  methods: {

    setCookie(cname = "", cvalue = "", exdays = 1) {
      const d = new Date();
      d.setTime(d.getTime() + exdays * 24 * 60 * 60 * 1000);
      let expires = "expires=" + d.toUTCString();
      document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
    },
    getCookie(cname) {
      let name = cname + "=";
      let decodedCookie = decodeURIComponent(document.cookie);
      let ca = decodedCookie.split(";");
      for (let i = 0; i < ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) == " ") {
          c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
          return c.substring(name.length, c.length);
        }
      }
      return "";
    },
    rememberMe(email = "", pwd = "") {
      console.log("------------------------------------");
      const timestamp = new Date().getTime(); // current time
      const exp = timestamp + 60 * 60 * 24 * 1000 * 7;

      if (email != "" && pwd != "") {
        //remember_me
        // this.$cookies.set("remember_me", true, exp);
        let userData = { email: email, pwd: pwd, rememberMe: true };
        let encoded = JSON.stringify(userData);
        let enc = window.btoa(encoded);
        this.setCookie("sdas7sJs", enc, 7);
        
      } else {
        this.setCookie("sdas7sJs", "", 7);
      }

      //let email =this.CryptoJS.AES.decrypt(this.$cookies.get("email"),"FV$HSEDEEPV@JUG" ).toString(this.CryptoJS.enc.Utf8);
    },
    setRemember() {
      let enc = this.getCookie("sdas7sJs");

      if (enc) {
        let tokenData = JSON.parse(atob(enc));

        if (tokenData.email) {
          this.email = tokenData.email;
        }
        if (tokenData.pwd) {
          this.password = tokenData.pwd;
        }

       
        if (
          tokenData.pwd &&
          tokenData.pwd != "" &&
          tokenData.email &&
          tokenData.email != "" &&
          (tokenData.rememberMe == true || tokenData.rememberMe == "true")
        ) {
          this.checkbox_remember_me = true;
        } else {
          this.setCookie("sdas7sJs", "", 7);
        }
      }
      this.$validator.reset();
    },
    forgotPassword() {
      this.$validator.validateAll().then((result) => {
        if(result){
        this.disabledBtn =true;
        let email =this.email.trim();
        email =email.toLowerCase();
        this.$store
          .dispatch("commonAction", {
            data: { email: email},
            path: "/auth/forget-password",
          })
          .then((response) => {
            this.showToster({message:response.message,isError:false });
            this.email ='';
            this.disabledBtn =false;
            this.$validator.reset();
            this.showForgotPassword =false;
            this.setRemember();
          })
          .catch((error) => {
            this.disabledBtn =false;
            this.disabledBtn =false;
            if(_.has(error ,'message')){
              this.showToster({message:error.message,isError:true });
            }else{
              this.showToster({message:'Something went wrong',isError:true });
              //Something went wrong
            }
          });
        }
      });
    },
    login() {
      this.$validator.validateAll().then((result) => {
        if(result){
          this.disabledBtn =true;
          let email =this.email.trim();
           email =email.toLowerCase();
          let password =this.password;
          this.$store
          .dispatch("login", { email: email, password:password })
          .then((response) => {


            if(response && response.token){

              if (this.checkbox_remember_me) {
                  this.rememberMe(this.email, this.password);
                } else {
                  this.rememberMe("", "");
                }
                
              this.$router.push("/dashboard");
            }
            this.disabledBtn =false;
            console.log(response);
          })
          .catch((error) => {
            this.disabledBtn =false;
            if(_.has(error ,'message')){
              this.showToster({message:error.message,isError:true });
            }else{
              this.showToster({message:'Something went wrong',isError:true });
              //Something went wrong
            }
            
              
             
          });

        }
     
      });

      return false;
    },
    gotoData() {
      // this.$router.push("/data-collection");
    },
    toggleShow() {
      this.showPassword = !this.showPassword;
    }
  },
  data: () => ({
    checkbox_remember_me: false,
    showForgotPassword: false,
    showPassword: false,
    email: "",
    password: "",
    disabledBtn:false,
  }),
  mounted() {
    this.setRemember()
  }
};
</script>