<template>
  <div>
    <div class="sub_header" v-if="datasource">
      <div class="sub_header_left" @click="gotListPage()">
        <a  ><img src="@/assets/images/left-chevron.svg"></a>
        <h5>{{datasource.title}}</h5>
      </div>
      
   
    </div>

    <div class="dcDetails">
      <div class="table-responsive">
        <table class="table" v-if="datasource && !islistLoading">
          <thead>
            <tr>
              <template v-for="(item, index) in headers" >
                <th  v-bind:key="index" v-if="item.selected">
                <span>{{item.title}}</span>
              </th>
              </template>
             
            </tr>
          </thead>
          <tbody v-if="listing && listing.length > 0">
            <tr  v-for="index in listing.length" :key="index">
              <template v-for="(aitem, aindex) in headers" >
              <td v-bind:key="aindex" v-if="aitem.selected">
                <span class="dc_name"> {{ getItem(listing[index],aitem.title) }} </span>
              </td>
            </template>
            </tr>
          </tbody>
        </table>
        <h2 v-if="listing.length <= 0" class="loading_NoData">
          <template v-if="islistLoading"> Loading.....</template>
          <template v-else> No Data Found!</template>
        </h2>
      </div>
      <div class="pagination-sec">
        <div class="per-page">
          <label v-if="listing && listing.length > 0" class="page_label">Per Page</label>
          <simpleselect v-if="listing && listing.length > 0" :listContainsId="false" @input="paginator()" :multiple="false" :wrapclass="'user_status'"
          :optionslist="perPageList" :fieldName="'UserStatus'" :cid="'UserStatus'" :vvas="'User Status'" :display="true"
          :place-holder="'Per Page'" :searchable="false" :required="true" v-model="perpage"
          :close-on-select="true" :clear-on-select="false" />
        </div>
        <b-pagination v-if="totalCount > perpage" v-model="page" :total-rows="totalCount" :per-page="perpage"
          aria-controls="my-table"></b-pagination>
      </div>
      

        
    </div>
  </div>
</template>
    
<script>
import * as _ from "lodash";

 import simpleInput from '@/views/forms/simple-input.vue';    
    import simpleselect from '@/views/forms/simpleselect.vue';
    import searchInput from '@/views/forms/search-Input.vue';
export default {
  watch: {
    page: function (val) {
      this.paginator();
    }
  },
      provide() {
          return {
              parentValidator: this.$validator,
          };
      },
      components: {
        simpleInput,
        simpleselect,
        searchInput
      },
  computed: {
  
  },
  mounted() {
    this.getDataSourceDetails();
  },
  data: () => ({
    perPageList:[10,25,50,100],
    listing: [],
    masterList:[],
    islistLoading: true,
    showLoader: false,
    page: 1,
    perpage: 25,
    totalCount: 0,  
    datasource:null,
    headers:[],
  }),
  methods: {
    paginator() {

var page = _.cloneDeep(this.page)
page =page
var per_page = this.perpage
var offset = (page - 1) * per_page
let items = this.masterList
this.listing = items.slice(offset).slice(0, per_page);
//let total_pages = Math.ceil(items.length / per_page);

},
    gotListPage(){
      let path ="/data-collection";
      let query ={}
      if(_.has(this.$route ,'query')){
       
         query = this.$route['query'];
        
      }

      this.$router.replace({ name: "data collection", params: {}, query: query })
    //  this.$router.push({pathname:path ,'query':query});


    },
    getItem(obj,cap){
      console.log(_.get(obj, [cap]))
      return _.get(obj, [cap])
    },
    getDataSourceDetails() {
      this.masterList =[];
      let payload = {
        _id: null,
        page: 1,
        perpage: 25,
      };
      payload['page'] = this.page;
      payload['perpage'] = this.perpage;
      payload["_id"] = this.$route.params.id;
      this.$store
        .dispatch("commonAction", {
          data: payload,
          path: "/datasource/get-details",
        })
        .then((response) => {
          let datasourceDetails = JSON.parse(response);
          if (datasourceDetails && datasourceDetails.length > 0) {
            let _dt = datasourceDetails[0];
            this.datasource = datasourceDetails[0];
            this.islistLoading = false;

            this.headers = this.datasource.dsfields;
            if(this.datasource.data){
             // this.listing = this.datasource.data;
              this.masterList =this.datasource.data

            }
            this.totalCount = this.masterList.length;
            this.paginator();


        //  let listing = JSON.parse(response.result);
        //     if (listing.length > 0) {
        //     let res = listing[0];
        //     if (res && res['docs']) {
        //       this.listing = res['docs'];

        //     }
        //     if (res && res['totalCount']) {
        //       this.totalCount = res['totalCount'][0]['count'];

        //     }


        //   }


          }
        })

      }
  }
};
</script>