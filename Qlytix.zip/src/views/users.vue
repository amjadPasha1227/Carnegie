<template>
  <div>
    <div class="sub_header">
      <div class="sub_header_left">
        <h5>Users</h5>
      </div>
      <div class="sub_header_right">
        <div class="search_area">
          <input type="text" v-on:input="page=1;perpage=25;searchDS()" v-model="title" class="form-control" placeholder="Search by Name/Email">
          <img src="@/assets/images/search.svg" class="search_icon" alt="search">
        </div>
        <simpleselect v-if="true" @input="page=1;perpage=25;getList(title)" :multiple="false" :wrapclass="'user_status'"
          :optionslist="statusList" :fieldName="'UserStatus'" :cid="'UserStatus'" :vvas="'User Status'" :display="true"
          :place-holder="'User Status'" :searchable="false" :required="true" v-model="selectedFilterStatusId"
          :close-on-select="true" :clear-on-select="false" />
        <button v-if="$store.getters['getuserRole'] == 1" @click="gotoPage('/users/add')" class="primary_btn add">
          <span></span> <em>Add User</em>
        </button>
      </div>
    </div>
    <!-- {{ getCurrentUser }}
    
    sortKeys:{
        
        "UserDetails.created_on":-1,
        "UserDetails.updated_on":1,
        "UserDetails.name":1,
        "UserDetails.email":1,
       
        }
    -->

    <div class="dcDetails">
      <div class="table-responsive">
        <table class="table" v-if="listing.length > 0 && !islistLoading">
          <thead>
            <tr>
              <th @click="sortMe('UserDetails.name')" :class="{'descending_order':sortKeys['UserDetails.name']<=-1 ,'ascending_order':sortKeys['UserDetails.name']==1}"><span>Name</span></th>
              <th @click="sortMe('UserDetails.email')" :class="{'descending_order':sortKeys['UserDetails.email']<=-1 ,'ascending_order':sortKeys['UserDetails.email']==1}"><span>Email</span></th>
              <th>Role</th>
              <th>Employee ID</th>
              <th @click="sortMe('UserDetails.created_on')" :class="{'descending_order':sortKeys['UserDetails.created_on']<=-1 ,'ascending_order':sortKeys['UserDetails.created_on']==1}"><span>Created Date{{  }}</span></th>
              <th>Status</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(item, index) in listing" v-bind:key="index">
              <td>
                <span class="dc_name">{{ item.UserDetails.name }}</span>
              </td>
              <td>
                <span>{{ item.UserDetails.email }}</span>
              </td>
              <td>
                <div>
                  <b-tooltip v-if="(item.modules && item.modules.length > 0)" :target="('tooltip-target-' + index)"
                    triggers="hover">
                    <div v-for="(sitem, sindex) in item.modules" v-bind:key="sindex">
                      {{ sitem.name }}
                    </div>
                  </b-tooltip>
                  <span :id="('tooltip-target-' + index)">
                    <span v-if="item.RoleDetails && item.RoleDetails.name">{{ item.RoleDetails.name }}</span>
                  </span>
                </div>
              </td>
              <td>
                <span>{{ item.UserDetails.employee_id }}</span>
              </td>
              <td>
                <span>{{ item.updated_on | formatDateTime }}</span>
              </td>
              <td>
                <span class="status-inactive" v-if="item.UserDetails.status_id == 3">Inactive</span>
                <span class="status-active" v-else-if="item.UserDetails.status_id == 1">Active</span>
                <span class="status-created" v-else-if="item.UserDetails.status_id == 0">Created</span>
                <span class="status-deleted"  v-else-if="item.UserDetails.status_id == 2">Deleted</span>
                
              </td>
              <td>
                <div>
                  <b-dropdown size="lg" right variant="link" toggle-class="text-decoration-none" :disabled="item.UserDetails.status_id == 2" no-caret>
                    <template #button-content>
                      <div class="more dropdown-toggle" :class="{'action-menu-disable' : item.UserDetails.status_id == 2}">
                      </div>
                    </template>
                    <b-dropdown-item href="#"
                      v-if="item.UserDetails.status_id == 1 && getCurrentUser['userId'] != item.UserDetails['_id']"><span
                        @click="editMe(item)">Edit</span></b-dropdown-item>
                    <b-dropdown-item
                      v-if="item.UserDetails.status_id != 2 && getCurrentUser['userId'] != item.UserDetails['_id']"
                      @click="showModal('delete-modal', item)">Delete</b-dropdown-item>
                    <template
                      v-if="[1,3].indexOf(item.UserDetails.status_id)>- 1 && getCurrentUser['userId'] != item.UserDetails['_id']">

                      <b-dropdown-item v-if="[1].indexOf(item.UserDetails.status_id)>-1"
                        @click="showModal('change-status-modal', item)">
                        Inactivate
                      </b-dropdown-item>
                      <b-dropdown-item v-if="item.UserDetails.status_id ==3"
                        @click="showModal('change-status-modal', item)">Activate</b-dropdown-item>
                    </template>
                    <b-dropdown-item v-if="[0, 1].indexOf(item.UserDetails.status_id) > -1"
                      @click="showModal('setpwd-modal', item)">
                      <template v-if="[0].indexOf(item.UserDetails.status_id) > -1">Set Password</template>
                      <template v-else>Update Password</template>
                    </b-dropdown-item>
                    <b-dropdown-item href="#" v-if="item.UserDetails.status_id == 0"><span
                        @click="showModal('resend-activation-link', item)">Resend Activation</span></b-dropdown-item>
                  </b-dropdown>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
        <h2 v-if="listing.length <= 0" class="loading_NoData">
          <template v-if="islistLoading"> Loading.....</template>
          <template v-else> No Users Found!</template>
        </h2>
      </div>
      <div class="pagination-sec">
        <div class="per-page">
          <label v-if="listing && listing.length > 0" class="page_label">Per Page</label>
          <simpleselect v-if="listing && listing.length > 0" :listContainsId="false" @input="page=1;getList(title)" :multiple="false" :wrapclass="'user_status'"
          :optionslist="perPageList" :fieldName="'UserStatus'" :cid="'UserStatus'" :vvas="'User Status'" :display="true"
          :place-holder="'Per Page'" :searchable="false" :required="true" v-model="perpage"
          :close-on-select="true" :clear-on-select="false" />
        </div>
        <b-pagination v-if="totalCount > perpage" v-model="page" :total-rows="totalCount" :per-page="perpage"
          aria-controls="my-table"></b-pagination>
      </div>
      
        
    </div>

    <b-modal ref="resend-activation-link" hide-footer centered no-close-on-backdrop title="Resend Activation Link">
      <template #modal-header>
        <h6 class="modal-title">Resend Activation Link</h6>
        <a class="close" @click="hideModal('resend-activation-link')"></a>
      </template>
      <template>
        <h4>Do you want to Resend Activation Link?</h4>
        <div class="modal_footer center">
          <button :disabled="showLoader" class="secondary_btn" variant="outline-danger"
            @click="hideModal('resend-activation-link')">No</button>
          <button :disabled="showLoader" @click="resendLink()" variant="success" class="primary_btn">
            <span class="btn_loader" v-if="showLoader"></span>
            Yes</button>
        </div>
      </template>
    </b-modal>

    <b-modal ref="change-status-modal" centered hide-footer no-close-on-backdrop
      :title="selectedItemStatus ? 'Inactivate User' : 'Activate User'">
      <template #modal-header>
        <h6 class="modal-title">{{ selectedItemStatus ? 'Inactivate User' : 'Activate User' }}</h6>
        <a class="close" @click="hideModal('change-status-modal')"></a>
      </template>
      <template>
        <h4>Do you want to {{ selectedItemStatus ? 'Inactivate User' : 'Activate User' }}?</h4>
        <div class="modal_footer center">
          <button :disabled="showLoader" class="secondary_btn" variant="outline-danger"
            @click="hideModal('change-status-modal')">No</button>
          <button :disabled="showLoader" @click="changeStatus()" variant="success" class="primary_btn">
            <span class="btn_loader" v-if="showLoader"></span>
            Yes</button>
        </div>
      </template>
    </b-modal>

    <!---delete-modal-->
    <b-modal ref="delete-modal" centered hide-footer no-close-on-backdrop title="Delete User">
      <template #modal-header>
        <h6 class="modal-title">Delete User</h6>
        <a class="close" @click="hideModal('delete-modal')"></a>
      </template>
      <template>
        <h4>Do you want to Delete User?</h4>
        <div class="modal_footer center">
          <button :disabled="showLoader" class="secondary_btn" variant="outline-danger" block
            @click="hideModal('delete-modal')">No</button>
          <button :disabled="showLoader" @click="deleteUser()" variant="success" class="primary_btn">
            <span class="btn_loader" v-if="showLoader"></span>
            Yes</button>
        </div>
      </template>
    </b-modal>

    <b-modal ref="setpwd-modal" centered hide-footer no-close-on-backdrop
      :title="setPassword ? 'Set Password' : 'Update Password'">
      <template #modal-header>
        <h6 class="modal-title">{{ setPassword ? 'Set Password' : 'Update Password' }}</h6>
        <a class="close" @click="hideModal('setpwd-modal')"></a>
      </template>
      <template>
        <form @submit.prevent>
          <div class="form_group">
            <lable class="form_label">Password<em>*</em></lable>
            <input ref="password"  v-validate="'required|min:5|strongpassword'" :data-vv-as="'Password'" v-model="password"
              :type="'password'" class="form-control" placeholder="Password" id="inputPassword" name="password" />
            <span v-show="errors.has('password')" class="form-error">
              {{ errors.first("password") }}
            </span>
          </div>
          <div class="form_group">
            <lable class="form_label">Confirm Password<em>*</em></lable>
            <input v-validate="'required|confirmed:password'" :data-vv-as="'Confirm Password'" v-model="cpassword" 
            :type="showPassword?'text':'password'"
              class="form-control eye" placeholder="Confirm Password" id="inputPassword" name="cpassword" 
              
              />
              <div v-if="checkcpassword" class="view_eye" :class="{ close : showPassword }" @click="toggleShow"> </div>
              
            <span v-show="errors.has('cpassword')" class="form-error">
              {{ errors.first("cpassword") }}
            </span>
          </div>
          <div class="modal_footer">
            <button :disabled="showLoader" class="secondary_btn" variant="outline-danger"
              @click="hideModal('setpwd-modal')">Cancel</button>
            <button :disabled="showLoader" @click="setPwdAction()" variant="success" class="primary_btn">
              <span class="btn_loader" v-if="showLoader"></span>
              {{ setPassword ? 'Submit' : 'Update' }}
            </button>
          </div>
        </form>
      </template>
    </b-modal>
  </div>
</template>
    

<script>
import * as _ from "lodash";

import simpleselect from "@/views/forms/simpleselect.vue";
export default {
  watch: {
    page: function (val) {

      this.getList(this.title);
    }
  },
  provide() {
    return {
      parentValidator: this.$validator,
    };
  },
  components: { simpleselect, },
  mounted() {
    this.getList(null);
  },
  data: () => ({
    perPageList:[10,25,50,100],
    
    sortKeys:{
        
        "UserDetails.created_on":-1,
        "UserDetails.updated_on":1,
        "UserDetails.name":1,
        "UserDetails.email":1,
       
        } ,
      sortKey:{"UserDetails.created_on":-1},
    setPassword: true,
    showPassword: false,
    password: "",
    cpassword: '',
    selectedFilterStatusId:{ "name": 'All', "_id": 100 },
    islistLoading: true,
    showLoader: false,
    title: null,
    listing: [],
    page: 1,
    perpage: 25,
    totalCount: 0,
    selectedUser: null,
    selectedItemStatus: false,
    statusList: [
      { "name": 'Created', "_id": 0 },
      { "name": 'Active', "_id": 1 },
      { "name": 'Inactive', "_id": 3 },
      { "name": 'Deleted', "_id": 2 },
      { "name": 'All', "_id": 100 },
      
    ]


  }),
  methods: {
    sortMe(sort_key='' ){

    

  if(sort_key !=''){
      this.sortKeys[sort_key] = this.sortKeys[sort_key]==1?-1:1
      this.sortKey ={};
      this.sortKey = {};
      this.sortKey[sort_key] =this.sortKeys[sort_key]
      
    
      this.getList(this.title ,true);
  }
},
    toggleShow() {
      this.showPassword = !this.showPassword;
    },
    setPwdAction() {

      this.$validator.validateAll().then((result) => {

        if (result) {
          this.showLoader = true;
          let password = this.password.trim();
          let cpassword = this.cpassword.trim();
          let path = "users/change-password";
          let postData = { new_password: '', confirm_password: '', 'user_id': '' };
          postData['new_password'] = password;
          postData['confirm_password'] = cpassword;
          postData['user_id'] = this.selectedUser['_id'];

          this.$store.dispatch("commonAction", { data: postData, path: path, })
            .then((response) => {
              this.showToster({ message: response.message, isError: false })
              this.showLoader = false;
              this.hideModal('setpwd-modal');
              this.getList(this.title);

            }).catch((error) => {
              this.showToster({ message: error.message, isError: false })
              this.showLoader = false;
              this.hideModal('setpwd-modal');

            });


        }

      });

    },

    showModal(modelRef, user) {
      //change-status-modal
      // setPassword
      if ([0].indexOf(user.UserDetails.status_id) > -1) {
        this.setPassword = true;
      } else {
        this.setPassword = false;
      }
      this.password = '';
      this.cpassword = '';
      if ([1].indexOf(user.UserDetails.status_id) > -1) {
        this.selectedItemStatus = true;
      } else {
        this.selectedItemStatus = false;
      }
      this.selectedUser = user;
      this.showLoader = false;
      this.$refs[modelRef].show();
      this.$validator.reset();

    },
    hideModal(modelId) {
      this.$refs[modelId].hide();
      this.selectedUser = null
      this.showLoader = false;
    },
    deleteUser() {

      this.showLoader = true;
      let payload = { user_id: null, statusId: false }
      payload['user_id'] = this.selectedUser['_id'];
      payload['statusId'] = 2

      this.$store.dispatch("commonAction", { data: payload, path: "/users/delete-user", })
        .then((response) => {
          this.showToster({ message: response.message, isError: false })
          this.showLoader = false;
          this.hideModal('delete-modal');
          this.getList(this.title);
        }).catch((error) => {
          this.showToster({ message: error.message, isError: false })
          this.showLoader = false;
          this.hideModal('change-status-modal');

        });

    },
    changeStatus() {

      this.showLoader = true;
      let payload = { user_id: null, status_id: 1 }
      payload['user_id'] = this.selectedUser['_id'];
      
      if ([1].indexOf(this.selectedUser.UserDetails.status_id) > -1) {  
        payload['status_id'] = 3
      } else {
        payload['status_id'] = 1
      }
      this.$store.dispatch("commonAction", { data: payload, path: "/users/change-status", })
        .then((response) => {
          this.showToster({ message: response.message, isError: false })
          this.showLoader = false;
          this.hideModal('change-status-modal');
          this.getList(this.title);

        }).catch((error) => {
          this.showToster({ message: error.message, isError: true })
          this.showLoader = false;
          this.hideModal('change-status-modal');

        });

    },
    resendLink() {
      this.showLoader = true;
      let payload = { user_id: null }
      payload['user_id'] = this.selectedUser['_id'];
      this.$store.dispatch("commonAction", { data: payload, path: "/auth/resend-activationlink", })
        .then((response) => {
          this.showToster({ message: response.message, isError: false })
          this.showLoader = false;
          this.hideModal('resend-activation-link');
          this.getList(this.title);
        }).catch((error) => {
          this.showToster({ message: error.message, isError: false })
          this.showLoader = false;
          this.hideModal('resend-activation-link');

        });
    },
    editMe(user) {
      this.selectedUser = user;
      this.$router.push("/user/edit/" + user['_id']);
    },
    gotoPage(path = "/") {
      this.$router.push(path);
    },
    ProcessData(item) {

      if (item) {

        this.$toast.open({
          message: 'Data Collection Started',
          type: 'info',
          duration: 3000
        });



      }

    },

    searchDS() {

      if (this.title && this.title.length > 2) {
        this.getList(this.title);
      }


      if (this.title == '') {
        this.getList(null);
      }

    },
    getList(title ,fromSort=false) {
      if (!title && fromSort==false) {
        this.listing = []
        this.islistLoading = true;
      }
      let postData = {
        title: null,
        statusId: [0,1,2,3],
        status: [false, true],
        page: 1,
        perpage: 25,
        "sortBy":{'UserDetails.created_on': -1}
      }//sortKey
      postData['sortBy'] =this.sortKey
      if (this.selectedFilterStatusId && _.has(this.selectedFilterStatusId ,'_id')) {
        if(this.selectedFilterStatusId['_id'] ==100){
          postData['statusId'] =[0,1,2,3]
        }else{
          postData['statusId'] = [this.selectedFilterStatusId['_id']];
        }
        
      }
      postData['page'] = this.page;
      postData['perpage'] = this.perpage;
      postData['title'] = title;
      
      this.$store
        .dispatch("getList", {
          data: postData,
          path: "/users/list",
        })
        .then((response) => {
          this.islistLoading = false;
          let listing = JSON.parse(response.result);
          //this.listing = listing[0];
          if (listing.length > 0) {
            let res = listing[0];
            if (res && res['docs']) {
              this.listing = res['docs'];

            }
            if (res && res['totalCount']) {
              this.totalCount = res['totalCount'][0]['count'];

            }


          }
        }).catch((err) => {
          this.islistLoading = false;
        });
    }
  },
  computed:{
    checkcpassword(){

      if(this.cpassword.trim()){
       return true;
      }else{
        return false;
      }

    }
  }
};
</script>