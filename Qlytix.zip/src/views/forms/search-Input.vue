<template>
    <div class="search_area">
        <input type="text" class="form-control" :placeholder="placeHolder">
        <img src="@/assets/images/search.svg" class="search_icon" alt="search">
    </div>
</template>
<script>
    export default {
        name:'search-input',
        props: {
            placeHolder: {
                type: String,
                default: null,
            },
        }
    }
</script>