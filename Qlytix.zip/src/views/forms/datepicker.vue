<template>
  <div
    class="col-6" :class="wrapclass">
    <div class="form_group ">
      <label class="form_label">{{label}}<em v-if="required">*</em>
        <span v-if="helpText" class="form_info" data-toggle="tooltip" data-placement="bottom-left" :title="helpText">info</span>
      </label>

      <date-picker
      v-if="required"
        :editable="true"
        @clear="clearValue()"
        :typeable="true"
        value-type="YYYY-MM-DD"
        format="MM/DD/YYYY"
        :name="fieldName+cid" 
        @change="setModel"
       
        :data-vv-as="vvas?vvas:label"
        v-model="value"
        v-validate="'required'"
        :placeholder="placeHolder"
        :default-value="openDate"
        :disabled-date="checkDisabled"
        :disabled = "isDisabled"
        :open-date="dateOpenFrom"
      >
      </date-picker>
      <date-picker
      v-else
        :editable="true"
        @clear="clearValue()"
        :typeable="true"
        value-type="YYYY-MM-DD"
        format="MM/DD/YYYY"
        :name="fieldName+cid" 
        @change="setModel"
        :data-vv-as="label"
        v-model="value"
        :placeholder="placeHolder"
        :default-value="openDate"
        :disabled-date="checkDisabled"
        :disabled = "isDisabled"
        :open-date="dateOpenFrom"
      >
      </date-picker>
      <template v-if="formscope">
          <span v-show="errors.has( formscope+'.'+fieldName+cid)" class="form-error">{{ errors.first(formscope+'.'+fieldName+cid) }}</span>
       </template>
       <template v-else>
        <span v-show="errors.has(fieldName+cid)" class="form-error" >{{ errors.first(fieldName+cid) }}</span>
       </template>
      <span
        class="form-error"         
        v-show="invalidate"
        >{{ errormessage }}
      </span>
    </div>
  </div>
</template>

<script>
import DatePicker from "vue2-datepicker";
import "vue2-datepicker/index.css";
import moment from "moment";

export default {
  inject: ["parentValidator"],

  props: { 
    helpText: {
            type: String,
            default: ""
        },
    dateOpenFrom: null,
    isDisabled:{
      type: Boolean,
      default: false,
    },
    fieldsArray: Array,
    display: {
      type: Boolean,
      default: false,
    },
    type: {
      type: String,
      defalt: "date",
    },
    invalidate: {
      type: Boolean,
      default: false,
    },
    errormessage: String,
    required: {
      type: Boolean,
      default: false,
    },
    wrapclass: {
      type: String,
      default: "col-6",
    },
    value: String,
    formscope: String,
    label: String,
    fieldName: String,
    placeHolder: {
      type: String,
      default: "MM/DD/YYYY",
    },
    dateEnableFrom: null,
    dateEnableTo: null,
    enableDays:{
      //it will enable only given day numers
      type:Array,
      default:[]
    //  sunday 0
     // monday 1
    //  thu 2
    },
    cid: {
        type: String,
        default: null,
    },
    vvas:{
            type:String,
                default:""
            },
     
  },
  components: {
    DatePicker,
  },
  data() {
    return {
      datestring: null,
    };
  },
  computed: {
    openDate() {
      if(this.dateOpenFrom){
        return moment(this.dateOpenFrom).format("YYYY-MM-DD");
      }else if (this.dateEnableTo) {
        return moment(this.dateEnableTo).format("YYYY-MM-DD");
      }else if (this.dateEnableFrom) {
        return moment(this.dateEnableFrom).format("YYYY-MM-DD");
      }
      return moment(new Date()).format("YYYY-MM-DD");
    },
  },
  methods: {
    clearValue() {
      this.value = null;
    },
    checkDisabled(val) {
      try {
        if (val && moment(val)) {
          if(this.enableDays && this.enableDays.length>0){
            let dayNumber = moment(val).day();
            if(this.enableDays.indexOf(dayNumber)>-1){
              return false;
            }else{
              return true;
             
            }

          }else{
            if (this.dateEnableTo && this.dateEnableFrom) {
              return moment(val) >= moment(this.dateEnableFrom) &&
                moment(val) <= moment(this.dateEnableTo)
                ? false
                : true;
            } else if (this.dateEnableTo) {
              return moment(this.dateEnableTo) <= moment(val);
            } else if (this.dateEnableFrom) {
              return moment(this.dateEnableFrom) >= moment(val);
            }
          }
        }
      } catch (e) {}

      // return true;
    },
    setModel() {
      if (this.value) {
        var _t = moment(this.value)
          .startOf("day")
          .format("YYYY-MM-DDTHH:mm:ss");
        this.$emit("input", _t);
      } else {
        this.$emit("input", null);
      }
    },
  },
  created() {
    this.$validator = this.parentValidator;
  },
  mounted() {
    setTimeout(() => {
      this.datestring = this.value;
    }, 10);
  },
};
</script>
