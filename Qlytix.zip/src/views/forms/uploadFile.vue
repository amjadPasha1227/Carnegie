<template>
    <div class="upload_file">
        <input type="file" name="file-input" id="file-input" class="file-input__input" />
        <label class="file-input__label" for="file-input">
            <img src="@/assets/images/upload.svg" />
            <span>Upload File</span>
        </label>
    </div>
</template>
<script>
    export default {
        name:'upload-file'
    }
</script>