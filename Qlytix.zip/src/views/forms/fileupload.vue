<template>
  
  
<div class="vx-col  w-full" :class="wrapclass" >
    <div class="form_group">
        <label class="form_label">{{label}}<em v-if="required">*</em>
            <span v-if="helpText" class="form_info" data-toggle="tooltip" data-placement="top" :title="helpText">info</span>
            
        </label>
        <file-upload  :ref="fieldName+cid"  v-validate="required? 'required|'+datatype : datatype " :hideSelected="true" v-model="fvalue" class="file-upload-input file-upload-input-cs" :name="fieldName+cid"  :data-vv-as="vvas?vvas:placeHolder" :multiple="multiple" accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document" @input="upload(fvalue)">
            <img class="file-icon" src="@/assets/images/file-upload.svg" />
            
            Upload
            <span class="loader" v-if="filesUploading" ><img src="@/assets/images/loader.gif"></span>
        </file-upload>

        <span v-show="errors.has((formscope!=''?formscope+'.':'')+fieldName+cid)" class="form-error">{{ errors.first((formscope!=''?formscope+'.':'')+fieldName+cid) }}</span>
        <ul class="uploaded-list">
            <template v-for="(item, index) in getlist">
                <vs-chip v-if="item.status" @click="remove(index)"  :key="index" closable>
                    <img src="@/assets/images/down-arrow2.svg" @click="downloads3file(item)" />
                    {{ item.name }}
                </vs-chip>
               
            </template>
        </ul>
    </div>
</div>
</template>

<script>
import FileUpload from "vue-upload-component/src";

import _ from "lodash";
export default {
    inject: ["parentValidator"],
    props: {
        helpText:{
            type: String,
            default:'',
        },
        deleteDocPermenantly:{
            type:Boolean,
            default:false
        },
        tooltip:{
            type: String,
            default: null,
        },
        display: {
            type: Boolean,
            default: false,
        },
         fieldsArray:Array,
        multiple: {
            type: Boolean,
            default: false
        },
        vvas: {
            type: String,
            default: ""
        },
        wrapclass: {
            type: String,
            default: "md:w-1/2"
        },
        datatype: {
            type: String,
            default: ""
        },
        cid: {
            type: String,
            default: '',
        },
        formscope: {
            type: String,
            default: null
        },
        value: null,
        label: {
            type: String,
            default: null,
        },
        fieldName: {
            type: String,
            default: null,
        },
        placeHolder: {
            type: String,
            default: null,
        },
        required: {
            type: Boolean,
            default: false,
        }
    },    data() {
        return {
            fvalue: [],
            filesUploading:false,

        };
    },
    mounted() {
       
        if(this.value){
            this.fvalue = _.cloneDeep(this.value);

        }
        console.log("this.valuethis.valuethis.valuethis.valuethis.value");
        console.log(this.value)
    },
    created() {
        this.$validator = this.parentValidator;
    },

    computed: {
        getlist() {
            
            return  _.filter(this.fvalue, function (item) {

                return item.status == true
            })

        }
    },
    methods: {
        upload(model) {
            let mapper = model.map(
                (item) =>
                (item = {
                    name: item.name,
                    file: item.file ? item.file : null,
                    url: item.url ? item.url : "",
                    path: item.path ? item.path : "",
                    isNew: item.isNew ? item.isNew : false,
                    status: item.status === false || item.status === true ? item.status : true,
                    mimetype: item.type ? item.type : item.mimetype,
                })
            );
            if (mapper.length > 0) {
                this.filesUploading =true;
                let count =0;
                mapper.forEach((doc, index) => {
                    if (doc.file) {
                        let formData = new FormData();
                        formData.append("files", doc.file);
                        formData.append("secureType", "private");
                        this.$store.dispatch("uploadS3File", formData).then((response) => {
                            response.data.result.forEach((urlGenerated) => {
                                doc.isNew = true;
                                doc.url = urlGenerated;
                                doc.path = urlGenerated;
                                delete doc.file;
                                mapper[index] = doc;
                            });

                            count =count+1;
                            if(mapper.length >=count ){
                                this.filesUploading =false;

                            }
                        });
                    }
                });
                model.splice(0, mapper.length, ...mapper);
            }

            this.updateData()

        },
        remove(index) {
            if(this.deleteDocPermenantly){
                this.fvalue.splice(index, 1); 
            }
            else{
                this.fvalue[index].status = false;
                this.$emit('input', this.fvalue)
            }         
        },
        updateData() {
            this.$emit('input', this.fvalue)
        }
    },
    components: {
        FileUpload,
       
    }
};
</script>
