<template>
    <div class="choose_folder">
        <input type="file" name="file-input" id="file-input" class="file-input__input" />
        <label class="file-input__label" for="file-input">
            <img src="@/assets/images/folder.svg" />
            <span> Choose Folder</span></label>
    </div>
</template>
<script>
    export default {
        name:'choose-folder'
    }
</script>