<template>
<div class="col-12" :class="wrapclass" >   
    <div class="form_group">
        <lable class="form_label">{{label}}<em v-if="required">*</em>
            <span v-if="helpText" class="form_info" data-toggle="tooltip" data-placement="top" :title="helpText">info</span>
        </lable>
        <template v-if="onlyNumbers==true">
            <template v-if="allowFloatingPoint">
                <input type="password" class="form-control" @keyup.enter.native="$emit('keyEnter')" oninput="this.value = this.value.replace(/[^0-9 .]/g, '').replace(/(\..*)\./g, '$1'); this.value = this.value.replace(/ /g,'');" :disabled="disabled" :name="fieldName+cid" v-on="listeners" v-model="value" v-validate="required? 'required|decimal:2':'decimal:2' "  :maxLength="maxLength"  :data-vv-as="vvas?vvas:placeHolder"  />
            </template>
            <template v-else>
                <input type="password" class="form-control" @keyup.enter.native="$emit('keyEnter')" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1'); this.value = this.value.replace(/ /g,'');" :disabled="disabled" :name="fieldName+cid" v-on="listeners" v-model="value" v-validate="required? 'required':'' "  :maxLength="maxLength"  :data-vv-as="vvas?vvas:placeHolder"  />
            </template>           
        </template>
        <template v-else>
            <input type="password" class="form-control" @keyup.enter.native="$emit('keyEnter')" 
            :disabled="disabled" :name="fieldName+cid" v-on="listeners" 
            v-model="value" v-validate="required? 'required|'+datatype : datatype "   :data-vv-as="vvas?vvas:placeHolder" :maxLength="maxCharacters" />
        </template>       
        <template v-if="formscope">
          <span v-show="errors.has( formscope+'.'+fieldName+cid)" class="form-error">{{ errors.first(formscope+'.'+fieldName+cid) }}</span>
       </template>
       <template v-else>
        <span v-show="errors.has(fieldName+cid)" class="form-error" >{{ errors.first(fieldName+cid) }}</span>
       </template>
    </div>
</div>
</template>

<script>

export default {
    name:'simple-input',
    inject: ["parentValidator"],
    props: {
        helpText:{
            type: String,
            default:'',
        },
        maxCharacters:{
            type: Number,
            default:200,
        },
        maxLength:{
            type: Number,
            default:25,
        },
        display: {
            type: Boolean,
            default: false,
        },
        disabled:{
            type: Boolean,
            default: false,
        },
        allowFloatingPoint:{
            type: Boolean,
            default: true,
        },
         fieldsArray:Array,
        vvas:{
        type:String,
            default:""
        },
        wrapclass:{
        type:String,
            default:"col-6"
        },
        datatype:{
            type:String,
            default:""
        },
         cid: {
            type: String,
            default: null,
        },
        formscope: {
            type: String,
            default: null
        },
        value: null,
        label: {
            type: String,
            default: null,
        },
        fieldName: {
            type: String,
            default: null,
        },
        placeHolder: {
            type: String,
            default: null,
        },
        required: {
            type: Boolean,
            default: false,
        },
        onlyNumbers: {
            type: Boolean,
            default: false,
        }
    },
    created() {
        this.$validator = this.parentValidator;
    },
    
  methods: {
   
  },
  components: {
   
  },
  computed:{
    listeners(){
      return {
        ...this.$listeners,
        input: (evt) => {
          this.$emit('input',evt.target.value)
        },
        focus: (evt) => {
          this.$emit('focus',evt)
         // this.changeFocus(true)
        },
        blur: (evt) => {
          this.$emit('blur',evt)
          //this.changeFocus(false)
        }
      }
    },

  }
};
</script>
