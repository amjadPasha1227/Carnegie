<template>

    <div class="no_data_found_sec">
        <img src="@/assets/images/Data_collection_img.svg">
        <h3>Data Views</h3>
        <small>No Data View Added</small>
        <button type="button" class="primary_btn lg">
            Add Data View
        </button>
    </div>
</template>

<script>
    // @ is an alias to /src
   
    
    export default {
      name: 'data-view',
      components: {
       
      }
    }
    </script>