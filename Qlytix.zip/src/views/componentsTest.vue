<!-- <template>

    <div class="no_data_found_secdd pt-6" style="padding-top: 20px">
      <form>
        <div class="row">
         
         <simpleInput :wrapclass="'col-md-6'" :fieldName="'userName'" :cid="'ddssasfsd'" :vvas="'Email'" :label="'Email'" :helpText="''" :display="true" :place-holder="'Email'" :required="true" v-model="testName"  />
         <simpleselect :multiple="false" :wrapclass="'col-md-6'" :optionslist="[{'id':'hsd' ,'name':'ravi'} ,{'id':'hssdfdsd' ,'name':'SR'}]" :fieldName="'sel'" :cid="'testSelectBox'" :vvas="'USER IS'" :label="'Select'" :helpText="''" :display="true" :place-holder="'Select'" :searchable="false" :required="true" v-model="seletDetails"  />
        <fileuploader  :formscope="''" :required="true" fieldName="fileUpload" v-model="documents" label="Documents" vvas="documents"></fileuploader> 
         <datepicker :wrapclass="'col-md-12'" :required="true" v-model="dateOfBirth"  fieldName="dateOfBirth" label="Date of Birth" />
         <simpleTextField :wrapclass="'col-md-12'"  :fieldName="'Comments'" :cid="'Comments'" :vvas="'Comments'" :label="'Comments'" :helpText="' '" :display="true" :place-holder="'Comments'" :required="true" v-model="comments"  />
                                          
       </div>
       <button @click="validateMe()" type="button" class="primary_btn sm">
        Validate Me
            </button>
          </form>
    </div>
</template>  -->
<template>
  <div class="no_data_found_secdd">
    <button type="button" class="btn btn-secondary m-2" @click="$bvModal.show('modal_SFTP')">
        SFTP Modal
    </button>
    <button type="button" class="btn btn-secondary m-2" @click="$bvModal.show('success_model')">
        Success Modal
    </button>
    <button type="button" class="btn btn-secondary m-2" @click="$bvModal.show('add_data_view')">
        Add Data View Modal
    </button>
    <button type="button" class="btn btn-secondary m-2" @click="$bvModal.show('add_filter')">
        Add Filter Modal
    </button>     
    <button type="button" class="btn btn-secondary m-2" @click="$bvModal.show('grouping_filter')">
        Add Grouping Modal
    </button> 
    <button type="button" class="btn btn-secondary m-2" @click="$bvModal.show('actions_filter')">
        Add Actions Modal
    </button>
    <button type="button" class="btn btn-secondary m-2" @click="toggleCustomModal">
        Custom Side Modal
    </button>
    <button type="button" class="btn btn-secondary m-2" @click="toggleCustomModalEmp">
        Custom Side Modal 2
    </button>

    <!-- SFTP Modal -->
    <b-modal id="modal_SFTP" dialog-class="modal_SFTP" centered hide-footer no-close-on-backdrop>
        <template #modal-header>
            <h6 class="modal-title">SFTP Details</h6>
            <a class="close" @click="$bvModal.hide('modal_SFTP')"></a>
        </template>
        <template>
          <form>
              <div class="row">
                  <div class="col-md-8">
                    <simpleInput :fieldName="'HostAddress'" :cid="'HostAddress'" :vvas="'Host Address'" :label="'Host Address'" :display="true" :placeHolder="''" :required="true"  />
                  </div>
                  <div class="col-md-4">
                    <simpleInput :fieldName="'PortNumber'" :cid="'PortNumber'" :vvas="'Port Number'" :label="'Port Number'" :display="true" :placeHolder="''" :required="true"  />
                  </div>
              </div>

              <simpleselect :multiple="false" :optionslist="dataSourceTypes" :fieldName="'LoginType'" :cid="'testSelectBox'" :vvas="'Login Type'" :label="'Login Type'" :display="true" :place-holder="'Normal'" :searchable="false" :required="true" v-model="dataSource.dataSourceType" />
              
              <simpleInput :fieldName="'userName'" :cid="'userName'" :vvas="'User Name'" :label="'User Name'" :display="true" :place-holder="'User Name'" :required="true" v-model="dataSource.userName"  />
              
              <div class="form_group">
                  <label class="form_label">Password</label>
                  <input
                  v-validate="'required'"
                  :data-vv-as="'Password'"
                  :type="showPassword?'text':'password'"
                    class="form-control"
                    placeholder="Password"
                    id="inputPassword"
                    name="password"
                  />
                  <div class="view_eye" :class="{ close : showPassword }" @click="toggleShow">
                  </div>
                  <p v-show="errors.has('password')" class="form-error">{{ errors.first('password') }}</p>
              </div>
              <div class="col-12 text-end">
                  <button class="primary_btn xs m-0" type="button" @click="saveAction()">
                      Save
                  </button>
              </div>
          </form>
        </template>
    </b-modal>

    <!-- Success Modal -->
    <b-modal id="success_model" dialog-class="success_model" centered hide-header hide-footer no-close-on-backdrop>
        <template>
          <a class="close black" @click="$bvModal.hide('success_model')"></a>
          <figure>
              <img src="@/assets/images/success_checkmark.svg" />
          </figure>
          <h4>Data Source Added Successfully</h4>
        </template>
    </b-modal>

    <!-- Add Data View Name Modal -->
    <b-modal id="add_data_view" dialog-class="add_data_view" centered hide-footer no-close-on-backdrop>
        <template #modal-header>
            <h6 class="modal-title"></h6>
            <a class="close black" @click="$bvModal.hide('add_data_view')"></a>
        </template>
        <template>
            <form>
                <simpleInput :wrapclass="'m-0'" :fieldName="'DataViewName'" :cid="'DataViewName'" :vvas="'Data View Name'" :label="'Data View Name'" :display="true" :placeHolder="''" :required="true"  />
                <div class="col-12 text-end">
                    <button class="primary_btn xs" type="button" @click="saveAction()">
                        Save
                    </button>
                </div>
            </form>
        </template>
    </b-modal>

    <!-- Add Filter Modal -->
    <b-modal id="add_filter" dialog-class="filter_popup" centered hide-footer no-close-on-backdrop>
        <template #modal-header>
            <h6 class="modal-title">Add Filter</h6>
            <a class="close" @click="$bvModal.hide('add_filter')"></a>
        </template>
        <template>
          <form>
            <div class="row">
                <div class="col-md-9">
                  <simpleInput :fieldName="'EmployeeRole'" :cid="'EmployeeRole'" :vvas="'Employee Role'"  :display="true" :placeHolder="'Employee Role Customization Data'" :required="true" v-model="dataSource.name"  />
                </div>
            </div>
            <div class="filter-config-list">
                <div class="filter-config">
                  <simpleselect :multiple="false" :optionslist="dataSourceTypes" :fieldName="'DataSourceType'" :cid="'testSelectBox'" :vvas="'Age'" :display="true" :place-holder="'Age'" :searchable="false" :required="false" />
                  <span class="close_rounded">
                      <img src="@/assets/images/close_rounded.svg">
                  </span>
                </div>
                <div class="filter-config">
                  <simpleInput :fieldName="'emptyText'" :cid="'emptyText'" :vvas="''"  :display="true" :placeHolder="''" :required="false" v-model="dataSource.name"  />
                  <span class="close_rounded">
                      <img src="@/assets/images/close_rounded.svg">
                  </span>
                </div>
                <div class="filter-config">
                  <simpleInput :fieldName="'emptyText'" :cid="'emptyText'" :vvas="''"  :display="true" :placeHolder="''" :required="false" v-model="dataSource.name"  />
                  <span class="close_rounded">
                      <img src="@/assets/images/close_rounded.svg">
                  </span>
                </div>
                <b-dropdown right no-caret class="add-more">
                    <template #button-content>
                        <span class="add-btn">+</span>
                    </template>
                    <b-form-group>
                      <b-form-radio-group>
                        <b-form-radio value="column">Column</b-form-radio>
                        <b-form-radio value="operator">Operator</b-form-radio>
                        <b-form-radio value="value">Value</b-form-radio>
                      </b-form-radio-group>
                    </b-form-group>
                    
                    <simpleselect :multiple="false" :optionslist="dataSourceTypes" :fieldName="'DataSourceType'" :cid="'testSelectBox'" :vvas="'Age'" :display="true" :place-holder="'Select'" :searchable="false" :required="false" />
                    
                    <button class="primary_btn xs" type="button">
                            Add
                    </button> 
                </b-dropdown>
            </div>
            <div class="filter-config-list">
                <div class="filter-config">
                  <simpleselect :multiple="false" :optionslist="dataSourceTypes" :fieldName="'DataSourceType'" :cid="'testSelectBox'" :vvas="'Age'" :display="true" :place-holder="'Age'" :searchable="false" :required="false" />
                  <span class="close_rounded">
                      <img src="@/assets/images/close_rounded.svg">
                  </span>
                </div>
                <div class="filter-config">
                  <simpleInput :fieldName="'emptyText'" :cid="'emptyText'" :vvas="''"  :display="true" :placeHolder="''" :required="false" v-model="dataSource.name"  />
                  <span class="close_rounded">
                      <img src="@/assets/images/close_rounded.svg">
                  </span>
                </div>
                <div class="filter-config">
                  <simpleInput :fieldName="'emptyText'" :cid="'emptyText'" :vvas="''"  :display="true" :placeHolder="''" :required="false" v-model="dataSource.name"  />
                  <span class="close_rounded">
                      <img src="@/assets/images/close_rounded.svg">
                  </span>
                </div>
                <b-dropdown right no-caret class="add-more">
                    <template #button-content>
                        <span class="add-btn">+</span>
                    </template>
                    <b-form-group>
                      <b-form-radio-group>
                        <b-form-radio value="column">Column</b-form-radio>
                        <b-form-radio value="operator">Operator</b-form-radio>
                        <b-form-radio value="value">Value</b-form-radio>
                      </b-form-radio-group>
                    </b-form-group>
                    
                    <simpleselect :multiple="false" :optionslist="dataSourceTypes" :fieldName="'DataSourceType'" :cid="'testSelectBox'" :vvas="'Age'" :display="true" :place-holder="'Select'" :searchable="false" :required="false" />
                    
                    <button class="primary_btn xs" type="button">
                            Add
                    </button> 
                </b-dropdown>
            </div>
            <a href="#" class="add_filter_link">+ Add Filter</a>
            <div class="divider"></div>
            <div class="col-12 text-end">
                <button type="button" class="primary_btn xs"  @click="saveAction()">
                    Save
                </button>
            </div>
          </form>
        </template>
    </b-modal>

    <!-- Add Grouping Modal -->
    <b-modal id="grouping_filter" dialog-class="filter_popup" centered hide-footer no-close-on-backdrop>
        <template #modal-header>
            <h6 class="modal-title">Add Grouping</h6>
            <a class="close" @click="$bvModal.hide('grouping_filter')"></a>
        </template>
        <template>
          <form>
            <div class="row">
                <div class="col-md-9">
                  <simpleInput :fieldName="'GroupingName'" :cid="'GroupingName'" :vvas="'Grouping Name'"  :display="true" :placeHolder="'Enter Grouping Name'" :required="true" v-model="dataSource.name"  />
                </div>
            </div>
            <div class="filter-config-list">
                <div class="filter-config">
                  <simpleselect :multiple="false" :optionslist="dataSourceTypes" :fieldName="'CourseID'" :cid="'testSelectBox'" :vvas="'Course ID'" :display="true" :place-holder="'Course ID'" :searchable="false" :required="false" />
                  <span class="close_rounded">
                      <img src="@/assets/images/close_rounded.svg">
                  </span>
                </div>
                <b-dropdown no-caret class="add-more">
                    <template #button-content>
                        <span class="add-btn">+</span>
                    </template>
                    <b-form-group>
                      <b-form-radio-group>
                        <b-form-radio value="column">Column</b-form-radio>
                      </b-form-radio-group>
                    </b-form-group>
                    
                    <simpleselect :multiple="false" :optionslist="dataSourceTypes" :fieldName="'DataSourceType'" :cid="'testSelectBox'" :vvas="'Age'" :display="true" :place-holder="'Select'" :searchable="false" :required="false" />
                    
                    <button class="primary_btn xs" type="button">
                            Add
                    </button> 
                </b-dropdown>
            </div>
            <div class="divider mt-4"></div>
            <div class="col-12 text-end">
                <button type="button" class="primary_btn xs"  @click="saveAction()">
                    Save
                </button>
            </div>
          </form>
        </template>
    </b-modal>

    <!-- Add Actions Modal -->
    <b-modal id="actions_filter" dialog-class="filter_popup" centered hide-footer no-close-on-backdrop>
        <template #modal-header>
            <h6 class="modal-title">Add Actions</h6>
            <a class="close" @click="$bvModal.hide('actions_filter')"></a>
        </template>
        <template>
          <form>
            <div class="row">
                <div class="col-md-9">
                  <simpleInput :fieldName="'ActionsName'" :cid="'ActionsName'" :vvas="'Actions Name'"  :display="true" :placeHolder="'Enter Actions Name'" :required="true" v-model="dataSource.name"  />
                </div>
            </div>
            <div class="filter-config-list">
                <div class="filter-config">
                  <simpleselect :multiple="false" :optionslist="dataSourceTypes" :fieldName="'DataSourceType'" :cid="'testSelectBox'" :vvas="'Score'" :display="true" :place-holder="'Score'" :searchable="false" :required="false" />
                  <span class="close_rounded">
                      <img src="@/assets/images/close_rounded.svg">
                  </span>
                </div>
                <div class="filter-config">
                  <simpleInput :fieldName="'emptyText'" :cid="'emptyText'" :vvas="''"  :display="true" :placeHolder="''" :required="false" v-model="dataSource.name"  />
                  <span class="close_rounded">
                      <img src="@/assets/images/close_rounded.svg">
                  </span>
                </div>
                <div class="filter-config">
                  <simpleInput :fieldName="'emptyText'" :cid="'emptyText'" :vvas="''"  :display="true" :placeHolder="''" :required="false" v-model="dataSource.name"  />
                  <span class="close_rounded">
                      <img src="@/assets/images/close_rounded.svg">
                  </span>
                </div>
                <b-dropdown right no-caret class="add-more">
                    <template #button-content>
                        <span class="add-btn">+</span>
                    </template>
                    <b-form-group>
                      <b-form-radio-group>
                        <b-form-radio value="column">Column</b-form-radio>
                        <b-form-radio value="operator">Operator</b-form-radio>
                        <b-form-radio value="value">Value</b-form-radio>
                      </b-form-radio-group>
                    </b-form-group>
                    
                    <simpleselect :multiple="false" :optionslist="dataSourceTypes" :fieldName="'DataSourceType'" :cid="'testSelectBox'" :vvas="'Age'" :display="true" :place-holder="'Select'" :searchable="false" :required="false" />
                    
                    <button class="primary_btn xs" type="button">
                            Add
                    </button> 
                </b-dropdown>
            </div>
            <div class="filter-config-list">
                <div class="filter-config">
                  <simpleselect :multiple="false" :optionslist="dataSourceTypes" :fieldName="'ColumnName'" :cid="'testSelectBox'" :vvas="'Column Name'" :display="true" :place-holder="'Column Name'" :searchable="false" :required="false" />
                  <span class="close_rounded">
                      <img src="@/assets/images/close_rounded.svg">
                  </span>
                </div>
                <div class="filter-config">
                  <simpleselect :multiple="false" :optionslist="dataSourceTypes" :fieldName="'Segmentation'" :cid="'testSelectBox'" :vvas="'Segmentation'" :display="true" :place-holder="'Segmentation'" :searchable="false" :required="false" />
                  <span class="close_rounded">
                      <img src="@/assets/images/close_rounded.svg">
                  </span>
                </div>
                <b-dropdown right no-caret class="add-more">
                    <template #button-content>
                        <span class="add-btn">+</span>
                    </template>
                    <b-form-group>
                      <b-form-radio-group>
                        <b-form-radio value="column">Column</b-form-radio>
                        <b-form-radio value="operator">Operator</b-form-radio>
                        <b-form-radio value="value">Value</b-form-radio>
                      </b-form-radio-group>
                    </b-form-group>
                    
                    <simpleselect :multiple="false" :optionslist="dataSourceTypes" :fieldName="'DataSourceType'" :cid="'testSelectBox'" :vvas="'Age'" :display="true" :place-holder="'Select'" :searchable="false" :required="false" />
                    
                    <button class="primary_btn xs" type="button">
                            Add
                    </button> 
                </b-dropdown>
            </div>
            <div class="filter-config-list">
                <div class="filter-config">
                  <simpleselect :multiple="false" :optionslist="dataSourceTypes" :fieldName="'Value'" :cid="'testSelectBox'" :vvas="'Value'" :display="true" :place-holder="'Value'" :searchable="false" :required="false" />
                  <span class="close_rounded">
                      <img src="@/assets/images/close_rounded.svg">
                  </span>
                </div>
                <div class="filter-config">
                  <simpleselect :multiple="false" :optionslist="dataSourceTypes" :fieldName="'Top Performer'" :cid="'testSelectBox'" :vvas="'Top Performer'" :display="true" :place-holder="'Top Performer'" :searchable="false" :required="false" />
                  <span class="close_rounded">
                      <img src="@/assets/images/close_rounded.svg">
                  </span>
                </div>
                <b-dropdown right no-caret class="add-more">
                    <template #button-content>
                        <span class="add-btn">+</span>
                    </template>
                    <b-form-group>
                      <b-form-radio-group>
                        <b-form-radio value="column">Column</b-form-radio>
                        <b-form-radio value="operator">Operator</b-form-radio>
                        <b-form-radio value="value">Value</b-form-radio>
                      </b-form-radio-group>
                    </b-form-group>
                    
                    <simpleselect :multiple="false" :optionslist="dataSourceTypes" :fieldName="'DataSourceType'" :cid="'testSelectBox'" :vvas="'Age'" :display="true" :place-holder="'Select'" :searchable="false" :required="false" />
                    
                    <button class="primary_btn xs" type="button">
                            Add
                    </button> 
                </b-dropdown>
            </div>
            <h5 class="mt-4">Generate A New Column</h5>
            <div class="row">
                <div class="col-md-4">
                  <simpleInput :fieldName="'ColumnName'" :cid="'ColumnName'" :vvas="'Column Name'"  :display="true" :placeHolder="''" :label="'Column Name'" :required="true" v-model="dataSource.name"  />
                </div>
                <div class="col-md-3">
                  <simpleInput :fieldName="'Value'" :cid="'Value'" :vvas="'Value'"  :display="true" :placeHolder="''" :label="'Value'" :required="true" v-model="dataSource.name"  />
                </div>
            </div>
            <div class="divider"></div>
            <div class="col-12 text-end">
                <button type="button" class="primary_btn xs"  @click="saveAction()">
                    Save
                </button>
            </div>
          </form>
        </template>
    </b-modal>

    <!-- Custom Side Modal -->
    <div class="custom_modal" :class="{ show : showCustomModal }">
        <div class="custom_overlay"></div>
        <div class="custom_mdl_cnt medium">
            <div class="modal_header">
                <h6>Employee Master</h6>
                <a class="close" @click="showCustomModal = false"></a>
            </div>
            <div class="modal_body">
                <form>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form_group">
                                <label class="form_label">Start Date</label>
                                <p>1 Oct, 2022</p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form_group">
                                <label class="form_label">Recurring</label>
                                <div class="rec_info">
                                    <span class="rec_type">DAILY</span>
                                    <span class="rec_time">4:30 pm</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form_group">
                                <label class="form_label">Type of Data Source</label>
                                <p>API</p>
                            </div>
                        </div>
                    </div>
                    <div class="user_detals">
                        <div class="form_group">
                            <label class="form_label">Username</label>
                            <p>TcohA7KPiassd3252ascsdkvmsCvkodsmvsSMKDM</p>
                        </div>
                        <div class="form_group m-0">
                            <label class="form_label">Password</label>
                            <input
                            v-validate="'required'"
                            :data-vv-as="'Password'"
                            value="TcohA7KPiassd3252ascsdkvmsCvkodsmvsSMKDM"
                            :type="showPasswordRead?'text':'password'"
                            class="form-control form-control-info"
                              placeholder="Password"
                              id="inputPassword"
                              name="password"
                              readonly/>
                            <div class="view_eye readonly" :class="{ close : showPasswordRead }" @click="toggleShowReadonly">
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Custom Side Modal 2 -->
    <div class="custom_modal" :class="{ show : showCustomModalEmp }">
        <div class="custom_overlay"></div>
        <div class="custom_mdl_cnt">
            <div class="modal_header">
                <h6>Employee Master</h6>
                <a class="close" @click="showCustomModalEmp = false"></a>
            </div>
            <div class="modal_body">
                <form>
                    <div class="table-responsive">
                        <table class="table table_transparent">
                            <thead>
                                <tr>
                                    <th>
                                        <div class="form-check">
                                            <input type="checkbox" class="form-check-input" onclick="checkAll(this)">
                                        </div>
                                    </th>
                                    <th>Fields</th>
                                    <th>Data Types</th>
                                    <th>Custom Label</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>
                                        <div class="form-check">
                                            <input type="checkbox" class="form-check-input">
                                        </div>
                                    </td>
                                    <td>First Name</td>
                                    <td>
                                        <simpleselect :wrapclass="'m-0'" :multiple="false" :optionslist="dataSourceTypes" :fieldName="'DataSourceType'" :cid="'testSelectBox'" :vvas="'Data Source Type'" :display="true" :place-holder="'Select'" :searchable="false" :required="false" v-model="dataSource.dataSourceType"  />
                                    </td>
                                    <td>
                                        <simpleInput :wrapclass="'m-0 transparent'" :fieldName="'LabelName'" :cid="'LabelName'" :vvas="'Label Name'" :display="true" :placeHolder="'Enter Label Name'" :required="false" v-model="dataSource.name"  />
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="form-check">
                                            <input type="checkbox" class="form-check-input">
                                        </div>
                                    </td>
                                    <td>Last Name</td>
                                    <td>
                                        <simpleselect :wrapclass="'m-0'" :multiple="false" :optionslist="dataSourceTypes" :fieldName="'DataSourceType'" :cid="'testSelectBox'" :vvas="'Data Source Type'" :display="true" :place-holder="'Select'" :searchable="false" :required="false" v-model="dataSource.dataSourceType"  />
                                    </td>
                                    <td>
                                        <simpleInput :wrapclass="'m-0 transparent'" :fieldName="'LabelName'" :cid="'LabelName'" :vvas="'Label Name'" :display="true" :placeHolder="'Enter Label Name'" :required="false" v-model="dataSource.name"  />
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="form-check">
                                            <input type="checkbox" class="form-check-input">
                                        </div>
                                    </td>
                                    <td>Email</td>
                                    <td>
                                        <simpleselect :wrapclass="'m-0'" :multiple="false" :optionslist="dataSourceTypes" :fieldName="'DataSourceType'" :cid="'testSelectBox'" :vvas="'Data Source Type'" :display="true" :place-holder="'Select'" :searchable="false" :required="false" v-model="dataSource.dataSourceType"  />
                                    </td>
                                    <td>
                                        <simpleInput :wrapclass="'m-0 transparent'" :fieldName="'LabelName'" :cid="'LabelName'" :vvas="'Label Name'" :display="true" :placeHolder="'Enter Label Name'" :required="false" v-model="dataSource.name"  />
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="form-check">
                                            <input type="checkbox" class="form-check-input">
                                        </div>
                                    </td>
                                    <td>Education</td>
                                    <td>
                                        <simpleselect :wrapclass="'m-0'" :multiple="false" :optionslist="dataSourceTypes" :fieldName="'DataSourceType'" :cid="'testSelectBox'" :vvas="'Data Source Type'" :display="true" :place-holder="'Select'" :searchable="false" :required="false" v-model="dataSource.dataSourceType"  />
                                    </td>
                                    <td>
                                        <simpleInput :wrapclass="'m-0 transparent'" :fieldName="'LabelName'" :cid="'LabelName'" :vvas="'Label Name'" :display="true" :placeHolder="'Enter Label Name'" :required="false" v-model="dataSource.name"  />
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="form-check">
                                            <input type="checkbox" class="form-check-input">
                                        </div>
                                    </td>
                                    <td>Designation</td>
                                    <td>
                                        <simpleselect :wrapclass="'m-0'" :multiple="false" :optionslist="dataSourceTypes" :fieldName="'DataSourceType'" :cid="'testSelectBox'" :vvas="'Data Source Type'" :display="true" :place-holder="'Select'" :searchable="false" :required="false" v-model="dataSource.dataSourceType"  />
                                    </td>
                                    <td>
                                        <simpleInput :wrapclass="'m-0 transparent'" :fieldName="'LabelName'" :cid="'LabelName'" :vvas="'Label Name'" :display="true" :placeHolder="'Enter Label Name'" :required="false" v-model="dataSource.name"  />
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="form-check">
                                            <input type="checkbox" class="form-check-input">
                                        </div>
                                    </td>
                                    <td>Division</td>
                                    <td>
                                        <simpleselect :wrapclass="'m-0'" :multiple="false" :optionslist="dataSourceTypes" :fieldName="'DataSourceType'" :cid="'testSelectBox'" :vvas="'Data Source Type'" :display="true" :place-holder="'Select'" :searchable="false" :required="false" v-model="dataSource.dataSourceType"  />
                                    </td>
                                    <td>
                                        <simpleInput :wrapclass="'m-0 transparent'" :fieldName="'LabelName'" :cid="'LabelName'" :vvas="'Label Name'" :display="true" :placeHolder="'Enter Label Name'" :required="false" v-model="dataSource.name"  />
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="form-check">
                                            <input type="checkbox" class="form-check-input">
                                        </div>
                                    </td>
                                    <td>Zone</td>
                                    <td>
                                        <simpleselect :wrapclass="'m-0'" :multiple="false" :optionslist="dataSourceTypes" :fieldName="'DataSourceType'" :cid="'testSelectBox'" :vvas="'Data Source Type'" :display="true" :place-holder="'Select'" :searchable="false" :required="false" v-model="dataSource.dataSourceType"  />
                                    </td>
                                    <td>
                                        <simpleInput :wrapclass="'m-0 transparent'" :fieldName="'LabelName'" :cid="'LabelName'" :vvas="'Label Name'" :display="true" :placeHolder="'Enter Label Name'" :required="false" v-model="dataSource.name"  />
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="form-check">
                                            <input type="checkbox" class="form-check-input">
                                        </div>
                                    </td>
                                    <td>Education</td>
                                    <td>
                                        <simpleselect :wrapclass="'m-0'" :multiple="false" :optionslist="dataSourceTypes" :fieldName="'DataSourceType'" :cid="'testSelectBox'" :vvas="'Data Source Type'" :display="true" :place-holder="'Select'" :searchable="false" :required="false" v-model="dataSource.dataSourceType"  />
                                    </td>
                                    <td>
                                        <simpleInput :wrapclass="'m-0 transparent'" :fieldName="'LabelName'" :cid="'LabelName'" :vvas="'Label Name'" :display="true" :placeHolder="'Enter Label Name'" :required="false" v-model="dataSource.name"  />
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="form-check">
                                            <input type="checkbox" class="form-check-input">
                                        </div>
                                    </td>
                                    <td>Department</td>
                                    <td>
                                        <simpleselect :wrapclass="'m-0'" :multiple="false" :optionslist="dataSourceTypes" :fieldName="'DataSourceType'" :cid="'testSelectBox'" :vvas="'Data Source Type'" :display="true" :place-holder="'Select'" :searchable="false" :required="false" v-model="dataSource.dataSourceType"  />
                                    </td>
                                    <td>
                                        <simpleInput :wrapclass="'m-0 transparent'" :fieldName="'LabelName'" :cid="'LabelName'" :vvas="'Label Name'" :display="true" :placeHolder="'Enter Label Name'" :required="false" v-model="dataSource.name"  />
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="col-12 text-end">
                        <button type="button" class="primary_btn xs">
                            Save
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
  </div>
</template>
<script>
    // @ is an alias to /src
  import simpleInput from '@/views/forms/simple-input.vue';
  import simpleselect from '@/views/forms/simpleselect.vue';
  import simpleTextField from '@/views/forms/simpleTextField.vue';
  import fileuploader from "@/views/forms/fileupload.vue";
  
  import datepicker from "@/views/forms/datepicker.vue";
  
    
    export default {
      name: 'test-view',
      provide() {
          return {
              parentValidator: this.$validator,
          };
      },
      components: {
        simpleInput,
        simpleselect,
        simpleTextField,
        fileuploader,
        datepicker
      },
      data: () => ({ 
        scheduleList:[
            {"id":1,'name':'One' },
            {'id':2,'name':'Two'},
            {"id":3,'name':'Three'} ,
            {'id':4,'name':'Four'}
        ],
        dataSourceTypes:[
            {"id":1,'name':'One' },
            {'id':2,'name':'Two'},
            {"id":3,'name':'Three'} ,
            {'id':4,'name':'Four'}
        ],
        dataSource:{
            name:'',
            schedule:'',
            dataSourceType:'',
            keyType:'',
            userName:'',
            password:''
        },
        showCustomModal: false,
        showCustomModalEmp:false,
        testName:'',
        seletDetails:[],
        comments:'',
        documents:[],
        dateOfBirth:null,
        showPassword: false,
        showPasswordRead:false,
        password: null
      }),
      methods: {
        validateMe(){
            this.$validator.validateAll((result)=>{
                alert(result)
            });
        },
        saveAction(){
            this.$validator.validateAll((result)=>{
                alert(result)
            });
        },
        toggleShow() {
            this.showPassword = !this.showPassword;
        },
        toggleShowReadonly(){
          this.showPasswordRead = !this.showPasswordRead;
        },
        toggleCustomModal() {
            this.showCustomModal = !this.showCustomModal;
        },
        toggleCustomModalEmp() {
            this.showCustomModalEmp = !this.showCustomModalEmp;
        },
      },
    }
    </script>
