<template>
  <div class="login_area">
    <form>
      <div >
        <h4 class="text-center">Set Password</h4>
        <input
            v-validate="'required|min:5|strongpassword'"
            :data-vv-as="'Password'"
            v-model="cpassword"
            :type="'password'"
            class="form-control"
            placeholder="Password"
            id="inputPassword"
            name="password"
            ref="password"
          />
        <p v-show="errors.has('password')" class="form-error">
          {{ errors.first("password") }}
        </p>

        <div class="password_area">
          <input
            v-validate="'required|confirmed:password'"
            :data-vv-as="'Confirm Password'"
            v-model="password"
            :type="showPassword?'text':'password'"
            class="form-control having_eye_icon"
            placeholder="Confirm Password"
            id="inputPassword"
            name="cpassword"
          />
          <div v-if="password"  class="view_eye" :class="{ close : showPassword }" @click="toggleShow">
          </div>
          <p v-show="errors.has('cpassword')" class="form-error">
            {{ errors.first("cpassword") }}
          </p>
        </div>
        <div class="keep_logged_in" >
          <div class="form-check" >
            <input
            v-if="false"
              type="checkbox"
              class="form-check-input"
              id="keepMeLoggedIn"
            />
            <label class="form-check-label" for="keepMeLoggedIn"
              ><template  v-if="false">Keep me logged in</template></label
            >
          </div>
          <a  @click="goToLoginpage()">Login</a>
        </div>
        <button :disabled="disabledBtn" type="button" @click="login()" class="login_btn">
          <span class="btn_loader" v-if="disabledBtn"></span>
          Submit
        </button>
      </div>

      
    </form>
  </div>
</template>
<script>
import simpleInput from "@/views/forms/simple-input.vue";

export default {
  name: "LoginView",
  provide() {
    return {
      parentValidator: this.$validator,
    };
  },
  components: {
    simpleInput,
  },
  methods: {
    goToLoginpage(){
        this.$router.push("/");
    },
    
    login() {
      this.$validator.validateAll().then((result) => {
        if(this.cpassword.trim() != this.password.trim()){

        }
        if(result ){
         let password =this.password.trim();
         let cpassword =this.cpassword.trim();
         let path ="auth/set-password";
         let postData = { new_password:'', confirm_password:'' ,'user_id':'',key:''};
         postData['new_password'] = password;
         postData['confirm_password'] = cpassword;
         postData['user_id'] = this.userId;
         postData['key'] = this.token;
         this.disabledBtn =true;
          this.$store
          .dispatch("commonAction", {path:path ,data:postData})
          .then((response) => {
            this.disabledBtn =false;
              this.$router.push("/");
              this.showToster({message:response.message,isError:false });
              setTimeout(()=>{
                this.$router.push("/login");
              },10);

            console.log(response);
          })
          .catch((error) => {
            this.disabledBtn =false;
            if(_.has(error ,'message')){
              this.showToster({message:error.message,isError:true });
            }else{
              this.showToster({message:'Something went wrong',isError:true });
              //Something went wrong
            }
           
            
          });

        }
     
      });

      return false;
    },
    gotoData() {
      // this.$router.push("/data-collection");
    },
    toggleShow() {
      this.showPassword = !this.showPassword;
    }
  },
  data: () => ({
    disabledBtn:false,
    showForgotPassword: false,
    showPassword: false,
    email: "",
    password: "",
    cpassword:'',
    userId:'',
    token:''

  }),
  mounted() {
    if(this.$route.params && this.$route.params.userId) {
        this.userId = this.$route.params.userId;
    }
    if(this.$route.query && this.$route.query.key) {
        this.token = this.$route.query.key;
    }
  }
};
</script>