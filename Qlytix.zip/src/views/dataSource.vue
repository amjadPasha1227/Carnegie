<template>
  <div>
    <div class="sub_header">
      <div class="sub_header_left m-0" @click="gotListPage()">
        <a
          ><img src="@/assets/images/left-chevron.svg"
        /></a>
        <h5 v-if="currentdatasourceId == null">Data Source Configuration</h5>
        <h5 v-if="currentdatasourceId!=null">Edit Data Source Configuration</h5>
      </div>
    </div>
    <div class="dsConfig_sec">
      <b-alert show dismissible v-if="showErros">
        {{ errormessage }} <b>&rArr;</b>
      </b-alert>
      <form @submit.prevent>
        <simpleInput
          :wrapclass="'col-md-12'"
          :fieldName="'DataSourceName'"
          :cid="'DataSourceName'"
          :vvas="'Name'"
          :label="'Name'"
          :display="true"
          :place-holder="'Name'"
          :required="true"
          v-model="dataSource.title"
          :allowAlphNum="true"
        />
        <simpleselect
          :multiple="false"
          :wrapclass="'col-md-12'"
          :optionslist="datacollectiontypes"
          :fieldName="'DataCollectionType'"
          :cid="'testSelectBox'"
          :vvas="'Data Collection Type'"
          :label="'Data Collection Type'"
          :display="true"
          :place-holder="'Data Collection Type'"
          :searchable="false"
          :isDisabled="currentdatasourceId && datacollectiontype!=null"
          :required="true"
          v-model="datacollectiontype"
        />

        <simpleselect
          :multiple="false"
          :wrapclass="'col-md-12'"
          :optionslist="datasourcetypes"
          :fieldName="'DataSourceType'"
          :isDisabled="currentdatasourceId"
          :cid="'testSelectBox'"
          :vvas="'Data Source Type'"
          :label="'Data Source Type'"
          :display="true"
          :place-holder="'Data Source Type'"
          :searchable="false"
          :required="true"
          v-model="type"
          @input="dataSourceTypeChanged"
        />
        <template v-if="type && type._id == 1 && currentdatasourceId==null">
          <div class="col-md-12 d-flex flex-wrap form_group">
            <div class="choose_folder">
              <input
                type="file"
                name="file-input"
                id="file-input"
                required="true"
                class="file-input__input"
                @change="onFileUpload"
              />
              <label class="file-input__label" for="file-input">
                <img src="@/assets/images/folder.svg" />
                <span> Choose Folder</span></label
              >
            </div>
            <div v-if="filerequired" class="form-error">*File is required</div>
          </div>
        </template>

        <div
          class="uploaded_file_details"
          v-if="type && type._id == 1 && file && dataheaders.length > 0"
        >
          <h6>Uploaded File</h6>
          <div class="file_info">
            <div class="info_left">
              <div class="file_type">
                <span>XLS</span>
              </div>
              <div class="file_name">
                <p>{{ file.name }}</p>
                <span>{{ getSelectedColumnsCount }} Fields selected</span>
              </div>
            </div>
            <div class="action_list">
              <figure @click="editHeaders(true);customizeData = true;customizeData = true;">
                <img src="@/assets/images/editing.svg" />
              </figure>
              <figure @click="clearFile()">
                <img src="@/assets/images/delete.svg" />
              </figure>
            </div>
          </div>
        </div>

        <template v-if="type && type._id == 2">
          <div class="row" >
            <simpleselect v-if="type && type._id == 2"
              :multiple="false"
              :wrapclass="'col-md-5'"
              :optionslist="ftptypes"
              :fieldName="'APIType'"
              :cid="'APIType'"
              :vvas="'FTP Authentication Type'"
              :label="'FTP Authentication Type'"
              :display="true"
              :place-holder="'Authentication'"
              :searchable="false"
              :required="true"
              v-model="ftptype"
            />
            <simpleInput v-if="type && type._id == 2"
              :wrapclass="'col-md-7'"
              :fieldName="'dataSourcehostname'"
              :cid="'1'"
              :vvas="'FTP Host'"
              :label="'FTP Host'"
              :display="true"
              :place-holder="'FTP Host'"
              :required="true"
              v-model="dataSource.hostname"
            />
          </div>
        </template>

        <template v-if="type && type._id == 3">
          <div class="row">
            <simpleselect
            v-if="type && type._id == 3"
              :multiple="false"
              :wrapclass="'col-md-5'"
              :optionslist="apitypes"
              :fieldName="'APIType'"
              :cid="'APIType'"
              :vvas="'API Type'"
              :label="'API Type'"
              :display="true"
              :place-holder="'API Type'"
              :searchable="false"
              :required="true"
              v-model="apitype"
            />
            <simpleInput
            v-if="type && type._id == 3"
              :wrapclass="'col-md-7'"
              :fieldName="'dataSourcehostname'"
              :cid="'2'"
              :vvas="'API URL'"
              :label="'API URL'"
              :display="true"
              :place-holder="'API URL'"
              :required="true"
              v-model="dataSource.hostname"
            />
        
          </div>
        </template>

        <div v-if="apitype && apitype._id == 2">
          <passwordInput
            :wrapclass="'col-md-12'"
            :fieldName="'password'"
            :cid="'password'"
            :vvas="'API Key'"
            :label="'API Key'"
            :display="true"
            :place-holder="'API Key'"
            :required="true"
            v-model="dataSource.apikey"
          />
        </div>

        <simpleInput
          v-if="(apitype && apitype._id == 3) || (ftptype && ftptype._id == 3)"
          :wrapclass="'col-md-12'"
          :fieldName="'userName'"
          :cid="'userName'"
          :vvas="'User Name'"
          :label="'User Name'"
          :display="true"
          :place-holder="'User Name'"
          :required="true"
          v-model="dataSource.username"
        />

        <div
          v-if="(apitype && apitype._id == 3) || (ftptype && ftptype._id == 3)"
        >
          <passwordInput
            :wrapclass="'col-md-12'"
            :fieldName="'password'"
            :cid="'password'"
            :vvas="'Password'"
            :label="'Password'"
            :display="true"
            :place-holder="'Password'"
            :required="true"
            v-model="dataSource.password"
          />
        </div>

        <simpleInput
          v-if="type && type._id == 3"
          :wrapclass="'col-md-12'"
          :fieldName="'path'"
          :cid="'path'"
          :vvas="'Object Path'"
          :label="'Object Path'"
          :display="true"
          :place-holder="'Object Path'"
          :required="true"
          v-model="dataSource.path"
        />

        <simpleInput
          v-if="type && type._id == 2"
          :wrapclass="'col-md-12'"
          :fieldName="'path'"
          :cid="'path'"
          :vvas="'Folder Path'"
          :label="'Folder Path'"
          :display="true"
          :place-holder="'Folder Path'"
          :required="true"
          v-model="dataSource.path"
        />

        <template v-if="type && type._id != 1">
          <div class="row">
            <simpleselect
              :multiple="false"
              :wrapclass="'col-md-5'"
              :optionslist="scheduletypes"
              :fieldName="'scheduletype'"
              :cid="'scheduletype'"
              :vvas="'Frequency'"
              :label="'Frequency'"
              :display="true"
              :place-holder="'Frequency'"
              :searchable="false"
              :required="true"
              v-model="scheduletype"
            />

            <simpleselect
              v-if="scheduletype && scheduletype._id == 2"
              :multiple="true"
              :wrapclass="'col-md-3'"
              :optionslist="weekdays"
              :fieldName="'days'"
              :cid="'days'"
              :vvas="'Days'"
              :label="'Days'"
              :display="true"
              :place-holder="'Days'"
              :closeOnSelect="false"
              :hideSelected="true"
              :searchable="false"
              :required="true"
              v-model="dataSource.days"
            />

            <simpleInput
              v-if="scheduletype && scheduletype._id > 2"
              :wrapclass="'col-md-3'"
              :fieldName="'daynumber'"
              :cid="'daynumber'"
              :vvas="'Day Number'"
              :label="'Day Number'"
              :display="true"
              :place-holder="'Day Number'"
              :required="true"
              :datatype="'max_value:'+maxdays"
              v-model="dataSource.daynumber"
              :onlyNumbers="true"
              :allowFloatingPoint="false"
            />

            <div class="form_group col-md-4" >
              <lable class="form_label">Time <em>*</em> </lable>
              <vue-timepicker
               @input="checkTimeValidation"
                v-model="dataSource.time"
                format="HH:mm:ss"
                drop-direction="up"
              ></vue-timepicker>

              <div v-if="timeequired" class="form-error">*Time is required</div>

            </div>
          </div>
        </template>


        <div
          class="uploaded_file_details"
          v-if="currentdatasourceId!= null && dataheaders.length > 0"
        >
          <h6>Data Selection</h6>
          <div class="file_info">
            <div class="info_left">
              <div class="file_name">
                <span>{{ getSelectedColumnsCount}} Fields selected</span>
              </div>
            </div>
            <div class="action_list">
              <figure @click="customizeData = true">
                <img src="@/assets/images/editing.svg" />
              </figure>
            </div>
          </div>
        </div>

        <div
          class="uploaded_file_details"
          v-if="currentdatasourceId == null && type && type._id != 1 && dataheaders.length > 0"
        >
          <h6>Data Selection</h6>
          <div class="file_info">
            <div class="info_left">
              <div class="file_name">
                <span>{{ getSelectedColumnsCount }} Fields selected</span>
              </div>
            </div>
            <div class="action_list">
              <figure @click="editHeaders()">
                <img src="@/assets/images/editing.svg" />
              </figure>
            </div>
          </div>
        </div>

        <div class="divider"></div>
        <div class="col-12 text-end">
          <button
            :disabled="showLoader"
            v-if="type && type._id != 1 && dataheaders.length == 0"
            @click="testConnection()"
            class="primary_btn sm"
            type="button"
          >
            <span class="btn_loader" v-if="showLoader"></span>
            Check Connection
          </button>
          <button
            v-else

            @click="saveAction()"
            class="primary_btn sm"
            type="button"
            :disabled="showLoader"
          >
            <span class="btn_loader" v-if="showLoader"></span>
            Save
          </button>
        </div>
      </form>
    </div>

    <div class="custom_modal show" v-if="customizeData">
      <div class="custom_overlay"></div>
      <div class="custom_mdl_cnt">
        <div class="modal_header">
          <h6>Data Customization</h6>
          <a class="close" @click="closeCustomizePopup()"></a>
        </div>
        <div class="modal_body">
          <form @submit.prevent>
            <table class="table table_transparent">
              <thead>
                <tr>
                  <th>
                    <div class="form-check">
                      <input
                        type="checkbox"
                        class="form-check-input"
                        v-model="selectAll"
                        v-on:change="numColumnsError='';selectAllFun()"
                      />
                    </div>
                  </th>
                  <th>Field Name</th>
                  <th>Data Type</th>
                  <th>Custom Label</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(item, index) in dataheaders" v-bind:key="index">
                  <td>
                    <div class="form-check">
                      <input
                        type="checkbox"
                        class="form-check-input"
                        v-on:change="checkselectAll();numColumnsError=''"
                        v-model="item.selected"
                      />
                    </div>
                  </td>
                  <td>{{ item.title }}</td>
                  <td>
                    <div class="form_group m-0">
                      <select class="form-select" v-model="item.datatype">
                        <option value="String">String</option>
                        <option value="Integer">Integer</option>
                        <option value="Boolean">Boolean</option>
                        <option value="Object">Object</option>
                        <option value="Double">Double</option>
                        <option value="Date">Date</option>
                        <option value="Timestamp">Timestamp</option>
                      </select>
                    </div>
                  </td>
                  <td>
                    <div class="form_group m-0">
                      <input
                        type="text"
                        class="form-control form-transparent"
                        v-model="item.utitle"
                        placeholder="Enter Label Name"
                      />
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
            <div class="custom_modal_footer">
              <p class="form-error" v-if="numColumnsError!=''">{{ numColumnsError }}</p>
              <button
                :disabled="showLoader"
                @click="saveHeaderColumns()"
                type="button"
                class="primary_btn xs"
              >
                <span class="btn_loader" v-if="showLoader"></span>
                Save 
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>

    <!-----
    <span class="globalloader" v-if="showLoader" ><img v-if="showLoader" src="@/assets/images/loader.gif"></span>
  --></div>
</template> 

<script>
import simpleInput from "@/views/forms/simple-input.vue";
import passwordInput from "@/views/forms/password.vue";

import simpleselect from "@/views/forms/simpleselect.vue";
import * as XLSX from "xlsx";
import VueTimepicker from "vue2-timepicker";
import * as _ from "lodash";

// CSS
import "vue2-timepicker/dist/VueTimepicker.css";

export default {
  name: "data-source",
  components: {
    simpleInput,
    simpleselect,
    passwordInput,
    VueTimepicker,
  },
  provide() {
    return {
      parentValidator: this.$validator,
    };
  },
  data: () => ({
    showErros: false,
    errormessage: null,
    showLoader: false,
    filerequired: false,
    timeequired: false,
    customizeData: false,
    datasourcetypes: [],
    apitypes: [],
    ftptypes: [],
    scheduletype: null,
    dataheaders: [],
    tempHeaders:[],
    scheduletypes: [],
   numColumnsError:'',
    datacollectiontypes: [
      {
        _id: 1,
        name: "Append",
      },
      {
        _id: 2,
        name: "Replace",
      },
    ],
    weekdays: [
      {
        _id: 1,
        name: "Sunday",
      },
      {
        _id: 2,
        name: "Monday",
      },
      {
        _id: 3,
        name: "Tuesday",
      },
      {
        _id: 4,
        name: "Wednesday",
      },
      {
        _id: 5,
        name: "Thursday",
      },
      {
        _id: 6,
        name: "Friday",
      },
      {
        _id: 7,
        name: "Saturday",
      },
    ],
    file: null,
    selectAll: true,
    ftptype: null,
    apitype: null,
    type: null,
    currentdatasourceId: null,
    maxdays:31,
    firstRow:null,
    dataSource: {
      editid: null,
      days: [],
      datacollectiontype:null,
      daynumber: 0,
      time: null,
      schedule_id: null,
      dsfields: null,
      path: null,
      ftptype_id: 0,
      apitype_id: 0,
      username: "",
      password: "",
      apikey: "",
      title: null,
      hostname: null,
      dst_id: null,
      data:[],
    },
  }),
  mounted() {
    
    
    this.getDataSources();

    if (this.$route.params && this.$route.params.id) {
      this.currentdatasourceId = this.$route.params.id;
      this.dataSource.editid = this.$route.params.id;
      this.getDataSourceDetails();
    }
  },
  watch: {
    customizeData:function(val){
      try{

      if(val){
        document.body.className="modal-open";
      }else{
        document.body.className="";
      }

        
      }catch(e){

      }
      
    },
    scheduletype: function (val) {

      if (val && val._id == 4) {
        this.maxdays = 365;
      }else{
        this.maxdays = 31;
      }
    },
    type: function (val) {
      


      if (this.$route.params && this.$route.params.id) {


      }else{
        if (val._id == 2) {
        this.apitype = null;
      } else {
        this.ftptype = null;
      }
      this.dataSource.hostname= null;

      this.timeequired = false;
        this.dataheaders = [];
      this.customizeData = false;
      }
    },
  },
  methods: {

    editHeaders(checkAll=false){
      //alert();
      this.numColumnsError='';
      this.dataheaders = _.cloneDeep(this.tempHeaders);
      this.customizeData = true;
      this.checkselectAll()
    },
   
    closeCustomizePopup(){
      this.numColumnsError='';
      //alert('closeCustomizePopup')
      this.dataheaders = _.cloneDeep(this.tempHeaders);
      this.customizeData = false;
      this.checkselectAll()
            

    },
    saveHeaderColumns(){
      this.numColumnsError ='';
      if(this.getSelectedColumnsCount<2){
        //this.showToster({ message: "Please select at least two fields", isError: true });
       // this.showErros =true;
       this.numColumnsError ="Please select at least two fields";
        return false;
      }else{

        this.tempHeaders = _.cloneDeep(this.dataheaders);
        this.customizeData = false;
        
       

      }

    },
    checkTimeValidation(){
     // alert(this.dataSource.time.HH);
      this.timeequired = false;
      if(this.dataSource.time!=null && ( this.dataSource.time.HH == '' || this.dataSource.time.mm == '' )){
         this.timeequired = true;


      }

    },
    gotListPage(){
      let path ="/data-collection";
      let query ={}
      if(_.has(this.$route ,'query')){
        query = this.$route['query'];
        
      }

      this.$router.replace({ name: "data collection", params: {}, query: query })
    
    },
    dataSourceTypeChanged(){

    //   this.dataSource= {
    //   editid: null,
    //   days: [],
    //   datacollectiontype:null,
    //   daynumber: 0,
    //   time: null,
    //   schedule_id: null,
    //   dsfields: null,
    //   path: null,
    //   ftptype_id: 0,
    //   apitype_id: 0,
    //   username: "",
    //   password: "",
    //   apikey: "",
    //   title: null,
    //   hostname: null,
    //   dst_id: null,
    //   data:[],
    // };
     
    if(this.dataSource.editid ==null){

    
         // this.dataSource.title ='';
          this.dataheaders=[];
          //datacollectiontype
          this.dataSource.hostname='';
          this.apitype=null,
          this.dataSource.hostname=''
          this.dataSource.apikey =''
          this.dataSource.username='';
          this.dataSource.password ='';
          this.dataSource.path ='';
          this.scheduletype =null,
          this.dataSource.days =null;
          this.dataSource.daynumber =null;
          this.dataSource.time= null;
          this.file =null
          this.timeequired=false;
          this.$validator.reset();
    }


    },
    getDataSourceDetails() {
      let payload = {
        _id: null,
      };
      payload["_id"] = this.currentdatasourceId;
      this.$store
        .dispatch("commonAction", {
          data: payload,
          path: "/datasource/get-details",
        })
        .then((response) => {
          let datasourceDetails = JSON.parse(response);
          if (datasourceDetails && datasourceDetails.length > 0) {
            let _dt = datasourceDetails[0];
            console.log(_dt);

            this.type = _dt.DstDetails;

            this.dataSource.days = _dt.days;
            this.datacollectiontype = _.find(
              this.datacollectiontypes,
              { _id: _dt.datacollectiontype }
            );
            this.dataSource.daynumber = _dt.daynumber;
            this.dataSource.time = _dt.time;
            this.dataSource.schedule_id = _dt.schedule_id;
            this.dataSource.dsfields = _dt.dsfields;
            this.dataSource.path = _dt.path;
            this.dataSource.ftptype_id = _dt.ftptype_id;
            this.dataSource.apitype_id = _dt.apitype_id;
            this.dataSource.username = _dt.username;
            this.dataSource.password = _dt.password;
            this.dataSource.apikey = _dt.apikey;
            this.dataSource.title = _dt.title;
            this.dataSource.hostname = _dt.hostname;
            this.dataSource.dst_id = _dt.dst_id;

            this.ftptype = _dt.FTPTypeDetails;
            this.apitype = _dt.APITypeDetails;
            this.scheduletype = _dt.ScheduleDetails;
            this.dataheaders = _dt.dsfields;
            this.tempHeaders = _.cloneDeep(this.dataheaders);
            // this.dataSource = datasourceDetails[0];
            // this.prefillData();
          }
        })
        .catch(() => {});
    },
    selectAllFun() {
      if (this.selectAll) {
        this.dataheaders.forEach((element, index) => {
          this.dataheaders[index].selected = true;
        });
      } else {
        this.dataheaders.forEach((element, index) => {
          this.dataheaders[index].selected = false;
        });
      }
    },
    makeToast(variant = null, message) {
      this.$bvToast.toast(message, {
        title: `Error`,
        delay: 50000,
        variant: variant,
      });
    },
    clearErrors() {
      this.showErros = false;
      this.errormessage = null;
    },
    testConnection() {
      this.clearErrors();
      if(this.type._id != 1 && (this.dataSource.time == null) ){

this.timeequired = true;
}
if(this.dataSource.time!=null && ( this.dataSource.time.HH == '' || this.dataSource.time.mm == '' )){
  this.timeequired = true;


}
      this.$validator.validateAll().then((result) => {
        console.log(this.errors)

        var connection_type = "API";
        if (result) {
          this.showLoader = true;
          connection_type = "API";
          if (this.ftptype != null) {
            connection_type = "FTP";
          }
          var payload = {
            connection_type: connection_type,
            hostname: this.dataSource.hostname,
            apikey: this.dataSource.apikey,
            username: this.dataSource.username,
            password: this.dataSource.password,
            path: this.dataSource.path,
          };
          this.$store
            .dispatch("getList", {
              data: payload,
              path: "/datasource/testconnection",
            })
            .then((d) => {
              var response = d.result;
              this.showLoader = false;
              if (response && response.length > 0) {
                const keys = Object.keys(response[0]);
                if (keys && keys.length > 0) {
                  var dataheaders = [];
                  if(this.firstRow == null){
                    this.firstRow = response[0];
                    this.dataSource.data = response;
                  }
                  keys.forEach((element) => {
                    let datatype = null;
                    if (this.firstRow!=null && _.has(this.firstRow, element)) {
                      datatype = this.getDtatType(this.firstRow[element]);
                    }
                    dataheaders.push({
                      selected: true,
                      title: element,
                      datatype: datatype,
                      utitle: element,
                    });
                  });

                  this.dataheaders = dataheaders;
                  this.customizeData = true;
                  this.selectAll = true;
                  this.tempHeaders = _.cloneDeep(this.dataheaders);
                }
              } else {
              }
            })
            .catch((error) => {
              console.log(error)
              this.showLoader = false;
              this.showToster({ message: "Unable to Fetch the data. Make sure you have entered valid "+connection_type+" details", isError: true })
           
            });
        }
      });
    },
    clearFile() {
      this.file = null;
      this.dataheaders = [];
      this.customizeData = false;
      document.getElementById('file-input').value = ''
    },
    getFileExtension(filename)
{
  var ext = /^.+\.([^.]+)$/.exec(filename);
  return ext == null ? "" : ext[1];
},
checkselectAll(){
  let items = _.filter(this.dataheaders, { selected: true });
  if(items.length != this.dataheaders.length){

    this.selectAll = false;
  }
  if(items.length == this.dataheaders.length){
    this.selectAll = true;
  }
  
},
    onFileUpload(event) {
      this.file = null;
      this.dataheaders = [];
      this.customizeData = false;
      var validExts = ["xlsx", "xls","csv"];
        var file = event.target.files ? event.target.files[0] : null;
        var fileExt = this.getFileExtension(file.name);
        if (validExts.indexOf(fileExt) < 0) {
            var _msg = "Invalid file type selected, valid files are of " + validExts.toString() + " types.";
   
              this.showToster({ message: _msg, isError: true })

      }
      this.filerequired = false;
      this.file = event.target.files ? event.target.files[0] : null;
      if (this.file && validExts.indexOf(fileExt) >= 0) {
        const reader = new FileReader();
        reader.onload = (e) => {
          const bstr = e.target.result;
          const wb = XLSX.read(bstr, { type: "binary" });
          const wsname = wb.SheetNames[0];
          const ws = wb.Sheets[wsname];

          var XL_row_object = XLSX.utils.sheet_to_row_object_array(ws);
          var json_object = JSON.stringify(XL_row_object);
          json_object = JSON.parse(json_object);
          this.firstRow = null;
          if (json_object.length > 0) {
            this.firstRow = json_object[0];
            this.dataSource.data = json_object;
          }
          const data = XLSX.utils.sheet_to_json(ws, { header: 1 });
          if (data && data[0].length > 0) {
            var dataheaders = [];
            data[0].forEach((element) => {
              let datatype = null;
              if (this.firstRow && _.has(this.firstRow, element)) {
                datatype = this.getDtatType(this.firstRow[element]);
              }

              dataheaders.push({
                selected: true,
                title: element,
                datatype: datatype,
                utitle: element,
              });
            });

            this.dataheaders = dataheaders;
            this.customizeData = true;
            this.tempHeaders =_.cloneDeep(this.dataheaders);
            this.selectAll = true;
          }
        };

        reader.readAsBinaryString(this.file);
      }else{
        event.target.value = '';
        this.clearFile();
      }
    },
    getDataSources() {
      this.$store
        .dispatch("getList", {
          data: { name: "DataSourceTypes" },
          path: "/masterdata/list",
        })
        .then((response) => {
          this.datasourcetypes = response.result;
        });
      this.$store
        .dispatch("getList", {
          data: { name: "FTPTypes" },
          path: "/masterdata/list",
        })
        .then((response) => {
          this.ftptypes = response.result;
        });
      this.$store
        .dispatch("getList", {
          data: { name: "APITypes" },
          path: "/masterdata/list",
        })
        .then((response) => {
          this.apitypes = response.result;
        });
      this.$store
        .dispatch("getList", {
          data: { name: "ScheduleTypes" },
          path: "/masterdata/list",
        })
        .then((response) => {
          this.scheduletypes = response.result;
        });
    },
    saveAction() {
     
      
      this.clearErrors();
      var valid = false;
      this.filerequired = false;


      if(this.dataSource.time == null){

this.timeequired = true;
valid = false;
}

      this.$validator.validateAll().then((result) => {
        console.log(this.errors)
        valid = true;
        if (this.$route.params && this.$route.params.id) {
          valid = true;

        }else{
          if (this.type._id == 1 && this.file == null) {
          this.filerequired = true;
          valid = false;
         }
        }
     
        
        if(this.type._id != 1 && this.dataSource.time == null ){

          this.timeequired = true;
          valid = false;
        }

        if(this.dataSource.time!=null && ( this.dataSource.time.HH == '' || this.dataSource.time.mm == '')){
  this.timeequired = true;
  valid = false;


}
if(valid && this.getSelectedColumnsCount<2){
        this.showToster({ message: "Please select at least two fields", isError: true });
       // this.showErros =true;
       // this.errormessage ="Atleast two fields are required";
       valid = false;
      }

        if (valid && result) {
          this.timeequired = false;
          if (this.apitype && this.apitype._id != null) {
            this.dataSource.apitype_id = this.apitype._id;
          }
          if (this.ftptype && this.ftptype._id != null) {
            this.dataSource.ftptype_id = this.ftptype._id;
          }
          if (this.scheduletype && this.scheduletype._id != null) {
            this.dataSource.schedule_id = this.scheduletype._id;
          }
          if (this.datacollectiontype && this.datacollectiontype._id != null) {

            this.dataSource.datacollectiontype = this.datacollectiontype._id;

          }
          if (this.type._id == 1 && this.file == null) {
            this.dataSource.time = null;
            this.dataSource.ftptype_id = null;
            this.dataSource.days = null;
            this.dataSource.daynumber = null;
            this.dataSource.schedule_id = null;
         }
      
          this.dataSource.dst_id = this.type._id;
          this.dataSource.dsfields = this.dataheaders;
this.showLoader = true;
          this.$store
            .dispatch("getList", {
              data: this.dataSource,
              path: "/datasource/add",
            })
            .then((response) => {
              if (this.$route.params && this.$route.params.id) {

                this.showToster({ message: "Data Collection Updated Successfully", isError: false })

             
              } else {

                this.showToster({ message: "Data Collection Created Successfully", isError: false })


              }

              var _s = this;
              setTimeout(function () {
                _s.$router.push("/data-collection");
                _s.showLoader = false;
              }, 500);
            })
            .catch((error) => {
              this.showLoader = false;

              this.showToster({ message: "Unable to Create Data Collection. Please enter valid details", isError: true })


           
            });
        }
      });
    },
  },
  computed: {
    getSelectedColumnsCount() {
      try {
        if (this.dataheaders.length > 0) {
          let items = _.filter(this.dataheaders, { selected: true });
          return items.length;
        } else {
          return 0;
        }
      } catch (err) {
        return 0;
      }
    },
  },
};
</script>
