<template>
    <header>
        <div class="logo">
            <a href="#"><img src="@/assets/images/Logo-white.svg" alt="logo"></a>
            <span class="divider"></span>
            <div class="dt_caption">
                <span>DataTech Platform</span>
            </div>
        </div>
        <div class="right_cnt">
            <div class="right_menu">
                <b-dropdown size="lg"  variant="link" right >
                    <template #button-content>
                        <div class="profile">
                            <div class="profile_icon">
                                <img src="@/assets/images/user.svg" class="dt_icon">
                                <img src="@/assets/images/userWhite.svg" class="mb_icon">
                            </div>
                            <div class="profile_text">
                                <p>{{user['name']}}</p>
                                <small v-if="user['role_id'] ==1">Administrator</small>
                                <small v-if="user['role_id'] ==2">Manager</small>
                                <small v-if="user['role_id'] ==3">Employee</small>
                            </div>
                            <em class="profile_arrow">
                                <img src="@/assets/images/down-chevron.svg" class="dt_icon">
                                <img src="@/assets/images/down-chevronWhite.svg" class="mb_icon">
                            </em>
                        </div>
                    </template>
                    <b-dropdown-item href="javascript:;" @click="showModal('profilepwd-modal')">Update Password</b-dropdown-item>
                    <b-dropdown-item href="javascript:;" @click="logout()">Logout</b-dropdown-item>
                    
                </b-dropdown>
                <div class="mobile_menu" id="navicon" onclick="toggleMenu()">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
            <b-modal ref="profilepwd-modal" centered hide-footer no-close-on-backdrop title="Update Password">
              <template #modal-header>
                <h6 class="modal-title">Update Password</h6>
                <a class="close"  @click="hideModal('profilepwd-modal')"></a>
              </template>
              <template>
                <form @submit.prevent>
                  <div class="form_group">
                    <lable class="form_label">Password<em>*</em></lable>
                    <input
                    ref="password"
                    v-validate="'required|min:5|strongpassword'" 
                        :data-vv-as="'Password'"
                        v-model="password"
                        :type="'password'"
                        class="form-control"
                        placeholder="Password"
                        id="inputPassword"
                        name="password"
                      />
                    <span v-show="errors.has('password')" class="form-error">
                      {{ errors.first("password") }}
                    </span>
                  </div>
                  <div class="form_group">
                    <lable class="form_label">Confirm Password<em>*</em></lable>
                    <input
                        v-validate="'required|confirmed:password'"
                        :data-vv-as="'Confirm Password'"
                        v-model="cpassword"
                        :type="showPassword?'text':'password'"
                        class="form-control eye"
                        placeholder="Confirm Password"
                        id="inputPassword"
                        name="cpassword"
                      />
                      <div v-if="checkcpassword" class="view_eye" :class="{ close : showPassword }" @click="toggleShow"> </div>
                      <span v-show="errors.has('cpassword')" class="form-error">
                        {{ errors.first("cpassword") }}
                      </span>
                  </div>
                  <div class="modal_footer">
                    <button :disabled="showLoader" class="secondary_btn" variant="outline-danger" @click="hideModal('profilepwd-modal')">Cancel</button>
                    <button :disabled="showLoader" @click="setPwdAction()" variant="success" class="primary_btn">
                      <span class="btn_loader" v-if="showLoader"></span>
                      Update
                    </button>
                  </div>
                </form>
              </template>
              <!-- <div class="d-block text-center">
              {{ user }}
              </div> -->
            </b-modal>
        </div>
    </header>
</template>
<script>
    // @ is an alias to /src
   
    
    export default {
        data: () => ({
        showPassword:false,
        password: "",
        cpassword:'',
        showLoader:false
        }),
      name: 'header-vue',
      components: {
        
      },
      computed: {
        checkcpassword(){

        if(this.cpassword.trim()){
        return true;
        }else{
          return false;
        }
      },


        user() {
      return this.$store.state.user;
    }

      },
      methods: {
        showModal(modelRef ) {
          //change-status-modal
          this.password ='';
          this.cpassword ='';
           this.showLoader =false;
          this.$refs[modelRef].show();
          this.$validator.reset();

      },
      hideModal(modelId) {
        this.$refs[modelId].hide();
        this.showLoader =false;
      },
        toggleShow() {
          this.showPassword = !this.showPassword;
    },
    setPwdAction(){
          
          this.$validator.validateAll().then((result) => {
            
            if(result){
                  this.showLoader = true;
                  let password =this.password.trim();
                  let cpassword =this.cpassword.trim();
                  let path ="users/change-password";
                  let postData = { new_password:'', confirm_password:'' ,'user_id':''};
                  postData['new_password'] = password;
                  postData['confirm_password'] = cpassword;
                  postData['user_id'] = this.user['_id']['$oid'];

                  this.$store.dispatch("commonAction", {data: postData,path: path,})
                  .then((response) => {
                  this.showToster({message:response.message,isError:false })
                  this.showLoader =false;
                  this.hideModal('profilepwd-modal');
                  

                  }).catch((error)=>{
                  this.showToster({message:error.message,isError:false })
                  this.showLoader =false;
                  this.hideModal('setpwd-modal');

                  });


            }

          });

        },
        logout() {
      this.$store.dispatch("logout").then(() => {
        this.$router.push("/login");
      });
    }
      }
    }
    </script>