<template>
    <div>
        <div class="sub_header">
            <div class="sub_header_left">
                <a href="#"><img src="@/assets/images/left-chevron.svg"></a>
                <h5>Productivity</h5>
                <a href="#"><img src="@/assets/images/edit.svg" class="edit"></a>
            </div>
            <div class="sub_header_right">
                <searchInput :place-holder="'Search by Data Source name'"/>
                <button class="add_btn filter" @click="$bvModal.show('add_filter')">
                    <span>+</span> Add Filter
                </button>
                <button class="add_btn actions" @click="$bvModal.show('grouping_filter')">
                    <span>+</span> Add Actions
                </button>
                <button class="add_btn group" @click="$bvModal.show('actions_filter')">
                    <span>+</span> Add Group
                </button>
                <button class="sort_btn">
                    Sort by
                </button>
            </div>
            <button class="primary_btn xs ms-lg-auto">
                Save
            </button>
        </div>
        <div class="data_view">
            <div :class="{ 'view_left open': !closedLeft, 'view_left closed': closedLeft }" >
                <div class="sub_child" id="people" :class="{ none : noneLeft }">
                    <h6>Data Sources</h6>
                    <ul class="nav nav-tabs">
                        <li class="nav-item">
                        <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true" onclick="filterSelection('all')">All</button>
                        </li>
                        <li class="nav-item" role="presentation">
                        <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false" onclick="filterSelection('files')">Files</button>
                        </li>
                        <li class="nav-item" role="presentation">
                        <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#contact" type="button" role="tab" aria-controls="contact" aria-selected="false" onclick="filterSelection('api')">API</button>
                        </li>
                    </ul>
                    <div class="data_source_list">
                        <ul>
                            <li class="data_source files active">Employee Master</li>
                            <li class="data_source api active">Kra Master With Weightage And Threshold</li>
                            <li class="data_source files">Org Structure</li>
                            <li class="data_source files">Annual Performance Rating</li>
                            <li class="data_source files">Assessment Scores From Lms</li>
                            <li class="data_source api">Monthly Performance Rating</li>
                            <li class="data_source api active">Master-O</li>
                            <li class="data_source api">Training List from LMS</li>
                        </ul>
                    </div> 
                </div>
                <img src="@/assets/images/arrow_circle.svg" class="arrow_circle" @click="toggleLeft">
            </div>
            <div class="view_main">
                <!-- <div id="rete" style="width: 100%;height:100%;"></div> -->
                <div>
                    Lorem Ipsum is simply dummy text of the printing 
                    and typesetting industry. Lorem Ipsum has been the 
                    industry's standard dummy text ever since the 1500s, 
                    when an unknown printer took a galley of type and scrambled 
                    it to make a type specimen book. It has survived not only 
                    five centuries, but also the leap into electronic typesetting, 
                    remaining essentially unchanged. It was popularised in the 1960s 
                    with the release of Letraset sheets containing Lorem Ipsum passages,
                     and more recently with desktop publishing software like Aldus PageMaker 
                     including versions of Lorem Ipsum.
                </div>
                <div class="zoom_actions">
                    <div class="fullscreen">
                        <figure>
                            <img src="@/assets/images/full-size.svg">
                        </figure>
                    </div>
                    <div class="zoom">
                        <figure>
                            <img src="@/assets/images/zoom-in.svg">
                        </figure>
                        <figure>
                            <img src="@/assets/images/zoom-out.svg">
                        </figure>
                    </div>
                </div>
            </div>
            <div :class="{ 'view_right open': !closedRight, 'view_right closed': closedRight }">
                <div class="sub_child" :class="{ none : noneRight }">
                    <div class="filters_details">
                        <ul>
                            <li class="filters">Filters</li>
                            <li class="action">Actions</li>
                            <li class="groups">Groups</li>
                        </ul>
                    </div>
                    <div class="filters_list">
                        <ul>
                            <li>
                                <div class="filter_name">
                                    Employee Role Customization Data
                                </div>
                                <div class="more"></div>
                            </li>
                            <li class="actions">
                                <div class="filter_name">
                                    Employee Role Customization Data
                                </div>
                                <div class="more"></div>
                            </li>
                            <li class="groups">
                                <div class="filter_name">
                                    Employee Role Customization Data
                                </div>
                                <div class="more"></div>
                            </li>
                        </ul>
                    </div>  
                </div>
                <img src="@/assets/images/arrow_circle.svg" class="arrow_circle" @click="toggleRight">
            </div>
        </div>


        <!-- Add Filter Modal -->
    <b-modal id="add_filter" dialog-class="filter_popup" centered hide-footer no-close-on-backdrop>
        <template #modal-header>
            <h6 class="modal-title">Add Filter</h6>
            <a class="close" @click="$bvModal.hide('add_filter')"></a>
        </template>
        <template>
          <form>
            <div class="row">
                <div class="col-md-9">
                  <simpleInput :fieldName="'EmployeeRole'" :cid="'EmployeeRole'" :vvas="'Employee Role'"  :display="true" :placeHolder="'Employee Role Customization Data'" :required="true" v-model="dataSource.name"  />
                </div>
            </div>
            <div class="filter-config-list">
                <div class="filter-config">
                  <simpleselect :multiple="false" :optionslist="dataSourceTypes" :fieldName="'DataSourceType'" :cid="'testSelectBox'" :vvas="'Age'" :display="true" :place-holder="'Age'" :searchable="false" :required="false" />
                  <span class="close_rounded">
                      <img src="@/assets/images/close_rounded.svg">
                  </span>
                </div>
                <div class="filter-config">
                  <simpleInput :fieldName="'emptyText'" :cid="'emptyText'" :vvas="''"  :display="true" :placeHolder="''" :required="false" v-model="dataSource.name"  />
                  <span class="close_rounded">
                      <img src="@/assets/images/close_rounded.svg">
                  </span>
                </div>
                <div class="filter-config">
                  <simpleInput :fieldName="'emptyText'" :cid="'emptyText'" :vvas="''"  :display="true" :placeHolder="''" :required="false" v-model="dataSource.name"  />
                  <span class="close_rounded">
                      <img src="@/assets/images/close_rounded.svg">
                  </span>
                </div>
                <b-dropdown right no-caret class="add-more">
                    <template #button-content>
                        <span class="add-btn">+</span>
                    </template>
                    <b-form-group>
                      <b-form-radio-group>
                        <b-form-radio value="column">Column</b-form-radio>
                        <b-form-radio value="operator">Operator</b-form-radio>
                        <b-form-radio value="value">Value</b-form-radio>
                      </b-form-radio-group>
                    </b-form-group>
                    
                    <simpleselect :multiple="false" :optionslist="dataSourceTypes" :fieldName="'DataSourceType'" :cid="'testSelectBox'" :vvas="'Age'" :display="true" :place-holder="'Select'" :searchable="false" :required="false" />
                    
                    <button class="primary_btn xs" type="button">
                            Add
                    </button> 
                </b-dropdown>
            </div>
            <div class="filter-config-list">
                <div class="filter-config">
                  <simpleselect :multiple="false" :optionslist="dataSourceTypes" :fieldName="'DataSourceType'" :cid="'testSelectBox'" :vvas="'Age'" :display="true" :place-holder="'Age'" :searchable="false" :required="false" />
                  <span class="close_rounded">
                      <img src="@/assets/images/close_rounded.svg">
                  </span>
                </div>
                <div class="filter-config">
                  <simpleInput :fieldName="'emptyText'" :cid="'emptyText'" :vvas="''"  :display="true" :placeHolder="''" :required="false" v-model="dataSource.name"  />
                  <span class="close_rounded">
                      <img src="@/assets/images/close_rounded.svg">
                  </span>
                </div>
                <div class="filter-config">
                  <simpleInput :fieldName="'emptyText'" :cid="'emptyText'" :vvas="''"  :display="true" :placeHolder="''" :required="false" v-model="dataSource.name"  />
                  <span class="close_rounded">
                      <img src="@/assets/images/close_rounded.svg">
                  </span>
                </div>
                <b-dropdown right no-caret class="add-more">
                    <template #button-content>
                        <span class="add-btn">+</span>
                    </template>
                    <b-form-group>
                      <b-form-radio-group>
                        <b-form-radio value="column">Column</b-form-radio>
                        <b-form-radio value="operator">Operator</b-form-radio>
                        <b-form-radio value="value">Value</b-form-radio>
                      </b-form-radio-group>
                    </b-form-group>
                    
                    <simpleselect :multiple="false" :optionslist="dataSourceTypes" :fieldName="'DataSourceType'" :cid="'testSelectBox'" :vvas="'Age'" :display="true" :place-holder="'Select'" :searchable="false" :required="false" />
                    
                    <button class="primary_btn xs" type="button">
                            Add
                    </button> 
                </b-dropdown>
            </div>
            <a href="#" class="add_filter_link">+ Add Filter</a>
            <div class="divider"></div>
            <div class="col-12 text-end">
                <button type="button" class="primary_btn xs"  @click="saveAction()">
                    Save
                </button>
            </div>
          </form>
        </template>
    </b-modal>

    <!-- Add Grouping Modal -->
    <b-modal id="grouping_filter" dialog-class="filter_popup" centered hide-footer no-close-on-backdrop>
        <template #modal-header>
            <h6 class="modal-title">Add Grouping</h6>
            <a class="close" @click="$bvModal.hide('grouping_filter')"></a>
        </template>
        <template>
          <form>
            <div class="row">
                <div class="col-md-9">
                  <simpleInput :fieldName="'GroupingName'" :cid="'GroupingName'" :vvas="'Grouping Name'"  :display="true" :placeHolder="'Enter Grouping Name'" :required="true" v-model="dataSource.name"  />
                </div>
            </div>
            <div class="filter-config-list">
                <div class="filter-config">
                  <simpleselect :multiple="false" :optionslist="dataSourceTypes" :fieldName="'CourseID'" :cid="'testSelectBox'" :vvas="'Course ID'" :display="true" :place-holder="'Course ID'" :searchable="false" :required="false" />
                  <span class="close_rounded">
                      <img src="@/assets/images/close_rounded.svg">
                  </span>
                </div>
                <b-dropdown no-caret class="add-more">
                    <template #button-content>
                        <span class="add-btn">+</span>
                    </template>
                    <b-form-group>
                      <b-form-radio-group>
                        <b-form-radio value="column">Column</b-form-radio>
                      </b-form-radio-group>
                    </b-form-group>
                    
                    <simpleselect :multiple="false" :optionslist="dataSourceTypes" :fieldName="'DataSourceType'" :cid="'testSelectBox'" :vvas="'Age'" :display="true" :place-holder="'Select'" :searchable="false" :required="false" />
                    
                    <button class="primary_btn xs" type="button">
                            Add
                    </button> 
                </b-dropdown>
            </div>
            <div class="divider mt-4"></div>
            <div class="col-12 text-end">
                <button type="button" class="primary_btn xs"  @click="saveAction()">
                    Save
                </button>
            </div>
          </form>
        </template>
    </b-modal>

    <!-- Add Actions Modal -->
    <b-modal id="actions_filter" dialog-class="filter_popup" centered hide-footer no-close-on-backdrop>
        <template #modal-header>
            <h6 class="modal-title">Add Actions</h6>
            <a class="close" @click="$bvModal.hide('actions_filter')"></a>
        </template>
        <template>
          <form>
            <div class="row">
                <div class="col-md-9">
                  <simpleInput :fieldName="'ActionsName'" :cid="'ActionsName'" :vvas="'Actions Name'"  :display="true" :placeHolder="'Enter Actions Name'" :required="true" v-model="dataSource.name"  />
                </div>
            </div>
            <div class="filter-config-list">
                <div class="filter-config">
                  <simpleselect :multiple="false" :optionslist="dataSourceTypes" :fieldName="'DataSourceType'" :cid="'testSelectBox'" :vvas="'Score'" :display="true" :place-holder="'Score'" :searchable="false" :required="false" />
                  <span class="close_rounded">
                      <img src="@/assets/images/close_rounded.svg">
                  </span>
                </div>
                <div class="filter-config">
                  <simpleInput :fieldName="'emptyText'" :cid="'emptyText'" :vvas="''"  :display="true" :placeHolder="''" :required="false" v-model="dataSource.name"  />
                  <span class="close_rounded">
                      <img src="@/assets/images/close_rounded.svg">
                  </span>
                </div>
                <div class="filter-config">
                  <simpleInput :fieldName="'emptyText'" :cid="'emptyText'" :vvas="''"  :display="true" :placeHolder="''" :required="false" v-model="dataSource.name"  />
                  <span class="close_rounded">
                      <img src="@/assets/images/close_rounded.svg">
                  </span>
                </div>
                <b-dropdown right no-caret class="add-more">
                    <template #button-content>
                        <span class="add-btn">+</span>
                    </template>
                    <b-form-group>
                      <b-form-radio-group>
                        <b-form-radio value="column">Column</b-form-radio>
                        <b-form-radio value="operator">Operator</b-form-radio>
                        <b-form-radio value="value">Value</b-form-radio>
                      </b-form-radio-group>
                    </b-form-group>
                    
                    <simpleselect :multiple="false" :optionslist="dataSourceTypes" :fieldName="'DataSourceType'" :cid="'testSelectBox'" :vvas="'Age'" :display="true" :place-holder="'Select'" :searchable="false" :required="false" />
                    
                    <button class="primary_btn xs" type="button">
                            Add
                    </button> 
                </b-dropdown>
            </div>
            <div class="filter-config-list">
                <div class="filter-config">
                  <simpleselect :multiple="false" :optionslist="dataSourceTypes" :fieldName="'ColumnName'" :cid="'testSelectBox'" :vvas="'Column Name'" :display="true" :place-holder="'Column Name'" :searchable="false" :required="false" />
                  <span class="close_rounded">
                      <img src="@/assets/images/close_rounded.svg">
                  </span>
                </div>
                <div class="filter-config">
                  <simpleselect :multiple="false" :optionslist="dataSourceTypes" :fieldName="'Segmentation'" :cid="'testSelectBox'" :vvas="'Segmentation'" :display="true" :place-holder="'Segmentation'" :searchable="false" :required="false" />
                  <span class="close_rounded">
                      <img src="@/assets/images/close_rounded.svg">
                  </span>
                </div>
                <b-dropdown right no-caret class="add-more">
                    <template #button-content>
                        <span class="add-btn">+</span>
                    </template>
                    <b-form-group>
                      <b-form-radio-group>
                        <b-form-radio value="column">Column</b-form-radio>
                        <b-form-radio value="operator">Operator</b-form-radio>
                        <b-form-radio value="value">Value</b-form-radio>
                      </b-form-radio-group>
                    </b-form-group>
                    
                    <simpleselect :multiple="false" :optionslist="dataSourceTypes" :fieldName="'DataSourceType'" :cid="'testSelectBox'" :vvas="'Age'" :display="true" :place-holder="'Select'" :searchable="false" :required="false" />
                    
                    <button class="primary_btn xs" type="button">
                            Add
                    </button> 
                </b-dropdown>
            </div>
            <div class="filter-config-list">
                <div class="filter-config">
                  <simpleselect :multiple="false" :optionslist="dataSourceTypes" :fieldName="'Value'" :cid="'testSelectBox'" :vvas="'Value'" :display="true" :place-holder="'Value'" :searchable="false" :required="false" />
                  <span class="close_rounded">
                      <img src="@/assets/images/close_rounded.svg">
                  </span>
                </div>
                <div class="filter-config">
                  <simpleselect :multiple="false" :optionslist="dataSourceTypes" :fieldName="'Top Performer'" :cid="'testSelectBox'" :vvas="'Top Performer'" :display="true" :place-holder="'Top Performer'" :searchable="false" :required="false" />
                  <span class="close_rounded">
                      <img src="@/assets/images/close_rounded.svg">
                  </span>
                </div>
                <b-dropdown right no-caret class="add-more">
                    <template #button-content>
                        <span class="add-btn">+</span>
                    </template>
                    <b-form-group>
                      <b-form-radio-group>
                        <b-form-radio value="column">Column</b-form-radio>
                        <b-form-radio value="operator">Operator</b-form-radio>
                        <b-form-radio value="value">Value</b-form-radio>
                      </b-form-radio-group>
                    </b-form-group>
                    
                    <simpleselect :multiple="false" :optionslist="dataSourceTypes" :fieldName="'DataSourceType'" :cid="'testSelectBox'" :vvas="'Age'" :display="true" :place-holder="'Select'" :searchable="false" :required="false" />
                    
                    <button class="primary_btn xs" type="button">
                            Add
                    </button> 
                </b-dropdown>
            </div>
            <h5 class="mt-4">Generate A New Column</h5>
            <div class="row">
                <div class="col-md-4">
                  <simpleInput :fieldName="'ColumnName'" :cid="'ColumnName'" :vvas="'Column Name'"  :display="true" :placeHolder="''" :label="'Column Name'" :required="true" v-model="dataSource.name"  />
                </div>
                <div class="col-md-3">
                  <simpleInput :fieldName="'Value'" :cid="'Value'" :vvas="'Value'"  :display="true" :placeHolder="''" :label="'Value'" :required="true" v-model="dataSource.name"  />
                </div>
            </div>
            <div class="divider"></div>
            <div class="col-12 text-end">
                <button type="button" class="primary_btn xs"  @click="saveAction()">
                    Save
                </button>
            </div>
          </form>
        </template>
    </b-modal>
        
    </div>
</template>

<script>
    // @ is an alias to /src
    import simpleInput from '@/views/forms/simple-input.vue';    
    import simpleselect from '@/views/forms/simpleselect.vue';
    import searchInput from '@/views/forms/search-Input.vue';
    
    export default {
      name: 'data-process',
      provide() {
          return {
              parentValidator: this.$validator,
          };
      },
      components: {
        simpleInput,
        simpleselect,
        searchInput
      },
      data: () => ({ 
        scheduleList:[
            {"id":1,'name':'One' },
            {'id':2,'name':'Two'},
            {"id":3,'name':'Three'} ,
            {'id':4,'name':'Four'}
        ],
        dataSourceTypes:[
            {"id":1,'name':'One' },
            {'id':2,'name':'Two'},
            {"id":3,'name':'Three'} ,
            {'id':4,'name':'Four'}
        ],
        dataSource:{
            name:'',
            schedule:'',
            dataSourceType:'',
            keyType:'',
            userName:'',
            password:''
        },
        closedLeft: false,
        closedRight: false,
        noneLeft: false,
        noneRight: false,
        show: false,
      }),
      methods: {
        validateMe(){
            this.$validator.validateAll((result)=>{
                alert(result)
            });
        },
        saveAction(){
            this.$validator.validateAll((result)=>{
                alert(result)
            });
        },
        toggleLeft() {
            this.closedLeft = !this.closedLeft;
            setTimeout(() => {
                this.noneLeft = !this.noneLeft;
            }, 200)
        },
        toggleRight() {
            this.closedRight = !this.closedRight;
            setTimeout(() => {
                this.noneRight = !this.noneRight;
            }, 200)
        },
        modalShow(){
            this.show = !this.show;
        }

      },
    }
    </script>

