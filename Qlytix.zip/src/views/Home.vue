<template>
  <div class="Home">
    <b-alert show>Welcome on vue-bootstrap-boilerplate.</b-alert>
  </div>
</template>
