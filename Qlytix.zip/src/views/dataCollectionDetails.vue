<template>
    <div>
        <div class="sub_header">
            <div class="sub_header_left">
                <h5>Data Collection</h5>
            </div>
            <div class="sub_header_right">
                <searchInput :place-holder="'Search...'"/>
                <div class="fliter_all">
                    <simpleselect :multiple="false" :optionslist="dataSourceTypes" :fieldName="'FilterType'" :cid="'testSelectBox'" :vvas="'FilterType'"  :display="true" :place-holder="'All'" :searchable="false" :required="false" v-model="dataSource.dataSourceType"  />
                </div>
                <div class="source_type">
                    <simpleselect :multiple="false" :optionslist="dataSourceTypes" :fieldName="'SourceType'" :cid="'testSelectBox'" :vvas="'SourceType'"  :display="true" :place-holder="'Source Type'" :searchable="false" :required="false" v-model="dataSource.keyType"  />
                </div>
                <button class="primary_btn add">
                    <span></span> <em>Add Data Source</em>
                </button>
            </div>
        </div>
        <div class="dcDetails">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                        <th>Name</th>
                        <th>Recurring</th>
                        <th>Type of Data Source</th>
                        <th>Last Run Date</th>
                        <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                        <td>
                            <div class="dc_name">
                                <a href="#">South Zone Branches</a>
                            </div>
                        </td>
                        <td>
                            <div class="recurring">
                                <span class="rec_schedule">
                                    <span>Daily</span>
                                </span>
                                <span class="rec_time">
                                    <span>4:30 pm</span>
                                </span>
                            </div>
                        </td>
                        <td>
                            <div class="ds_type">
                                <span>API</span>
                            </div>
                        </td>
                        <td>
                            <div class="last_run_date">
                                <span>Yesterday, 4:30 pm</span>
                            </div>
                        </td>
                        <td>
                            <b-dropdown variant="link" right no-caret>
                                <template #button-content>
                                    <div class="more dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    </div>
                                </template>
                                <b-dropdown-item href="#">Edit</b-dropdown-item>
                                <b-dropdown-item href="#">De-Activate</b-dropdown-item>
                                <b-dropdown-item href="#">Archive</b-dropdown-item>
                                <b-dropdown-item href="#">View Data</b-dropdown-item>
                            </b-dropdown>
                        </td>
                        </tr>
                        <tr>
                        <td>
                            <div class="dc_name">
                                <a href="#">South Zone Branches</a>
                            </div>
                        </td>
                        <td>
                            <div class="recurring">
                                <span class="rec_schedule">
                                    <span>Daily</span>
                                </span>
                                <span class="rec_time">
                                    <span>4:30 pm</span>
                                </span>
                            </div>
                        </td>
                        <td>
                            <div class="ds_type">
                                <span>API</span>
                            </div>
                        </td>
                        <td>
                            <div class="last_run_date">
                                <span>Yesterday, 4:30 pm</span>
                            </div>
                        </td>
                        <td>
                            <b-dropdown variant="link" right no-caret>
                                <template #button-content>
                                    <div class="more dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    </div>
                                </template>
                                <b-dropdown-item href="#">Edit</b-dropdown-item>
                                <b-dropdown-item href="#">De-Activate</b-dropdown-item>
                                <b-dropdown-item href="#">Archive</b-dropdown-item>
                                <b-dropdown-item href="#">View Data</b-dropdown-item>
                            </b-dropdown>
                        </td>
                        </tr>
                    </tbody>
                    </table>
            </div>
        </div>
    </div>
    </template>
    
    <script>
        // @ is an alias to /src
        import simpleInput from '@/views/forms/simple-input.vue';    
        import simpleselect from '@/views/forms/simpleselect.vue';
        import searchInput from '@/views/forms/search-Input.vue';
        
        export default {
          name: 'dashboard-view',
          components: {
            simpleInput,
            simpleselect,
            searchInput
          },
          provide() {
              return {
                  parentValidator: this.$validator,
              };
          },
          data: () => ({ 
            dataSourceTypes:[
                {"id":1,'name':'One' },
                {'id':2,'name':'Two'},
                {"id":3,'name':'Three'} ,
                {'id':4,'name':'Four'}
            ],
            dataSource:{
                name:'',
                schedule:'',
                dataSourceType:'',
                keyType:'',
                userName:'',
            }
          }),
        }
        </script>