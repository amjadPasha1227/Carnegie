<template>
  <div>
    <div class="sub_header">
      <div class="sub_header_left">
        <h5>Data Collection</h5>
      </div>
      
      <div class="sub_header_right">
        <div class="search_area">
          <input
            type="text"
            v-on:input="page=1;perpage=25;searchDS()"
            v-model="title"
            class="form-control"
            placeholder="Search by Name"
          />
         

          <img
            src="@/assets/images/search.svg"
            class="search_icon"
            alt="search"
          />
        </div>

       
        <simpleselect 
         @input="page=1;getList(title, true)" :multiple="false" :wrapclass="'user_status'"
          :optionslist="statusList" :fieldName="'sourcetype1'" :cid="'sourcetype1'" :vvas="'Source type'" :display="true"
          :place-holder="'Source Type'" :searchable="false" :required="true" v-model="selectedFilterStatusId"
          :close-on-select="true" :clear-on-select="false"  />
     

        <button
          @click="gotoPage('/data-collection/add')"
          class="primary_btn add"
        >
          <span></span> <em>Add Data Source</em>
        </button>
      </div>
    </div>

    <div class="dcDetails">
      <div class="table-responsive">
        <table class="table" v-if="listing.length > 0 && !islistLoading">
          <thead>
            <tr>
              <th @click="sortMe('title')" :class="{'descending_order':sortKeys['title']<=-1 ,'ascending_order':sortKeys['title']==1}"><span>Name</span></th>
              <th>Recurring</th>
              <th>Type of Data Source</th>
              <th @click="sortMe('lastrun')" :class="{'descending_order':sortKeys['lastrun']<=-1 ,'ascending_order':sortKeys['lastrun']==1}"><span>Last Run Date</span></th>

              <th>Status</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(item, index) in listing" v-bind:key="index">
              <td>
                <span class="dc_name"> {{ item.title }} </span>
              </td>
              <td>
                <div
                  class="recurring" 
                  v-if="item.DstDetails && item.DstDetails.name != 'File'"
                  :class="{ [getClassName(item)]: true }"
                >
                
                  <b-tooltip custom-class="custom_tooltip"
                    v-if="item.ScheduleDetails._id==1 "
                    :target="'tooltip-target-' + index"
                    triggers="hover"
                  >

                  <span class="rec_time">
                    <span
                      >{{ item.time.HH==''?'00':item.time.HH }}:{{ item.time.mm==''?'00':item.time.mm }}:{{
                        item.time.ss==''?'00':item.time.ss
                      }}</span
                    >
                  </span>
                
                </b-tooltip>
                  <b-tooltip custom-class="custom_tooltip"
                    v-if="item.ScheduleDetails._id!=1 "
                    :target="'tooltip-target-' + index"
                    triggers="hover"
                  >
                  <template v-if="item.ScheduleDetails._id == 2 ">
                    <div 
                      v-for="(sitem, sindex) in item.days"
                      v-bind:key="sindex"
                    >
                      {{ sitem.name }}
                    </div>
                  </template>
                  <template v-if="item.ScheduleDetails._id!= 2 ">
                    {{item.daynumber}}
                  </template>

                  </b-tooltip>
                  <span class="rec_schedule" :id="'tooltip-target-' + index">
                    <span v-if="item.ScheduleDetails">{{
                      item.ScheduleDetails.name
                    }}</span>
                  </span>
                  <span class="rec_time">
                    <span
                      >{{ item.time.HH==''?'00':item.time.HH }}:{{ item.time.mm==''?'00':item.time.mm }}:{{
                        item.time.ss==''?'00':item.time.ss
                      }}</span
                    >
                  </span>
                </div>
                <div class="recurring" v-else><span class="not_applicable">N/A</span></div>
              </td>
              <td>
                <span v-if="item.DstDetails">{{ item.DstDetails.name }}</span>
              </td>
           
              <td>
                <span>{{ item.lastrun | formatDateTime }}</span>
              </td>   <td>
                <span class="status-active" v-if="item.status">Active</span>
                <span class="status-inactive" v-if="!item.status">Inactive</span>
              </td>
              <td>
                <div>
                  <b-dropdown
                    size="lg"
                    right
                    variant="link"
                    toggle-class="text-decoration-none"
                    no-caret
                  >
                    <template #button-content>
                      <div class="more dropdown-toggle"></div>
                    </template>
                    <b-dropdown-item  @click="editMe(item)" >Edit</b-dropdown-item>
                    <b-dropdown-item
                      @click="showModal('change-status-modal', item)"
                      
                      v-if="item.status"
                      >Inactivate</b-dropdown-item
                    >
                    <b-dropdown-item
                      @click="showModal('change-status-modal', item)"
                      
                      v-if="!item.status"
                      >Activate</b-dropdown-item
                    >
                  
                    <!----page title selectedFilterStatusId--->
                    <b-dropdown-item   v-if="item.status && item.DstDetails && item.DstDetails.name != 'File'" @click="ProcessData(item)" href="#" 
                      >Run Data</b-dropdown-item
                    >  <b-dropdown-item :to="'/data-collection/view/'+item._id+'?page='+page+'&&title='+title+'&&statusId='+filterStatusId" 
                      >View Data</b-dropdown-item
                    >
                  </b-dropdown>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
        <h2 v-if="listing.length <= 0" class="loading_NoData">
          <template v-if="islistLoading"> Loading.....</template>
          <template v-else> No Data Found!</template>
        </h2>

        <b-modal
          ref="change-status-modal"
          centered
          hide-footer
          no-close-on-backdrop
          :title="
            selectedItemStatus
              ? 'Inactivate Data Collection'
              : 'Activate Data Collection'
          "
        >
          <template #modal-header>
            <h6 class="modal-title">
              {{
                selectedItemStatus
                  ? "Inactivate Data Collection"
                  : "Activate Data Collection"
              }}
            </h6>
            <a class="close" @click="hideModal('change-status-modal')"></a>
          </template>
          <template>
            <h4>
              Do you want to
              {{
                selectedItemStatus
                  ? "Inactivate Data Collection"
                  : "Activate Data Collection"
              }}?
            </h4>
            <div class="modal_footer center">
              <button
                :disabled="showLoader"
                class="secondary_btn"
                variant="outline-danger"
                @click="hideModal('change-status-modal')"
              >
                No
              </button>
              <button
                :disabled="showLoader"
                @click="changeStatus()"
                variant="success"
                class="primary_btn"
              >
                <span class="btn_loader" v-if="showLoader"></span>
                Yes
              </button>
            </div>
          </template>
        </b-modal>
      </div>
      <div class="pagination-sec">
        <div class="per-page">
          <label v-if="listing && listing.length > 0" class="page_label">Per Page</label>
          <simpleselect v-if="listing && listing.length > 0" :listContainsId="false" @input="page=1;getList(title)" :multiple="false" :wrapclass="'user_status'"
          :optionslist="perPageList" :fieldName="'UserStatus'" :cid="'UserStatus'" :vvas="'User Status'" :display="true"
          :place-holder="'Per Page'" :searchable="false" :required="true" v-model="perpage"
          :close-on-select="true" :clear-on-select="false" />
        </div>
        <b-pagination v-if="totalCount > perpage" v-model="page" :total-rows="totalCount" :per-page="perpage"
          aria-controls="my-table"></b-pagination>
      </div>
    </div>
  </div>
</template>
    
<script>
import * as _ from "lodash";

 import simpleInput from '@/views/forms/simple-input.vue';    
    import simpleselect from '@/views/forms/simpleselect.vue';
    import searchInput from '@/views/forms/search-Input.vue';
export default {
  watch: {
    page: function (val) {

      this.getList(this.title);
    }
  },
      provide() {
          return {
              parentValidator: this.$validator,
          };
      },
      components: {
        simpleInput,
        simpleselect,
        searchInput
      },
  computed: {
    getClassName() {
      return (item) => {
        if (item.ScheduleDetails && item.ScheduleDetails.name) {
          return item.ScheduleDetails.name;
        }
      };
    },
  },
  mounted() {
    //selectedFilterStatusId:{ "name": 'All', "_id": 100 },

    //statusList
    
    
    if(_.has(this.$route ,'query')){
       if(_.has(this.$route['query'] ,'title') ){
        if(this.$route['query']['title'] !='null' && this.$route['query']['title'] !=null && this.$route['query']['title'] !=undefined && this.$route['query']['title'] !=''){
          this.title = this.$route['query']['title'];
        }
         
       }
       if(_.has(this.$route['query'] ,'page')){
        if(parseInt(this.$route['query']['page'])>0){
          this.page = parseInt(this.$route['query']['page']);
        }
         
       }
       if(_.has(this.$route['query'] ,'statusId')){
         let statusId = parseInt(this.$route['query']['statusId']);
         if([1,2,3,100].indexOf(parseInt(statusId)) >-1 ){
            this.filterStatusId = parseInt(statusId)
            this.selectedFilterStatusId =  _.find(this.statusList ,{"_id":parseInt(statusId)})

         }
         
       }

    }
    this.getList(this.title);
  },
  data: () => ({
    perPageList:[10,25,50,100],
    filterStatusId:100,
    selectedFilterStatusId:{ "name": 'All', "_id": 100 },

    statusList: [
      { "name": 'File', "_id": 1 },
      { "name": 'FTP', "_id": 2 },
      { "name": 'API', "_id": 3 },
      { "name": 'All', "_id": 100 },
      
    ],
    title: null,
    listing: [],
    islistLoading: true,
    showLoader: false,
    page: 1,
    perpage: 25,
    totalCount: 0,
    selectedDataItem: null,
    selectedItemStatus: false,
    datasources: [],
    sortKeys:{
        
        "title":-1,
        "lastrun":-1,
       
        } ,
      sortKey:{"lastrun":-1},
  }),
  methods: {
    editMe(item) {
      this.selectedDataItem = item;
      //+'?page='+page+'&&title='+title+'&&statusId='+filterStatusId
      let query= {
        page:1
      }
      query['page'] = this.page;

      if(this.title){
        query = Object.assign(query ,{ "title":this.title});
      }

      if(this.filterStatusId){
        query = Object.assign(query ,{ "statusId":this.filterStatusId});
      }
      
      this.$router.push({"path":"/data-collection/edit/"+item['_id'] ,"query":query});
    },
    changeStatus() {
      this.showLoader = true;
      let payload = { _id: null, status: false };
      payload["_id"] = this.selectedDataItem["_id"];

      if (this.selectedDataItem.status) {
        payload["status"] = false;
      } else {
        payload["status"] = true;
      }
      this.$store
        .dispatch("commonAction", {
          data: payload,
          path: "/datasource/change-status",
        })
        .then((response) => {
          this.showToster({ message: response.message, isError: false });
          this.showLoader = false;
          this.hideModal("change-status-modal");
          this.getList(this.title);
        })
        .catch((error) => {
          this.showToster({ message: error.message, isError: false });
          this.showLoader = false;
          this.hideModal("change-status-modal");
        });
    },
    showModal(modelRef, Item) {
      if (Item.status) {
        this.selectedItemStatus = true;
      } else {
        this.selectedItemStatus = false;
      }
      this.selectedDataItem = Item;
      this.showLoader = false;
      this.$refs[modelRef].show();
      this.$validator.reset();
    },
    hideModal(modelId) {
      this.$refs[modelId].hide();
      this.selectedDataItem = null;
      this.showLoader = false;
    },
    gotoPage(path = "/") {
      this.$router.push(path);
    },
    sortMe(sort_key='' ){

    

if(sort_key !=''){
    this.sortKeys[sort_key] = this.sortKeys[sort_key]==1?-1:1
    this.sortKey ={};
    this.sortKey = {};
    this.sortKey[sort_key] =this.sortKeys[sort_key]
    
  
    this.getList(this.title ,true);
}
},
    ProcessData(item) {

      this.showLoader = true;
      let payload = { _id: null};
      payload["_id"] = item["_id"];

   
      this.$store
        .dispatch("commonAction", {
          data: payload,
          path: "/datasource/run-data",
        })
        .then((response) => {
        
      
        
          this.showToster({ message: "Data Collection Started", isError: false });
          this.showLoader = false;
          this.getList(this.title);
        })
        .catch((error) => {
          this.showToster({ message: error.message, isError: false });
          this.showLoader = false;
        });

     
    },
    searchDS() {
      if (this.title && this.title.length > 2) {
        this.getList(this.title);
      }

      if (this.title == "") {
        this.getList(null);
      }
    },
    getDataSources(title) {
      this.$store
        .dispatch("getList", {
          data: { title: title },
          path: "/datasource/list",
        })
        .then((response) => {
          this.datasources = JSON.parse(response.result);
        });
    },
    getList(title, resetpage = false) {
      if (!title) {
        this.listing = [];
      }
      let postData = {
        title: null,
        page: 1,
        perpage: 25,
        "sortBy":{'lastrun': -1}
      }//sortKey
      postData['sortBy'] =this.sortKey
      postData['sortBy'] =this.sortKey
      if (this.selectedFilterStatusId && _.has(this.selectedFilterStatusId ,'_id')) {
        if(this.selectedFilterStatusId['_id'] ==100){
          postData['statusId'] =[0,1,2,3]
        }else{
          postData['statusId'] = [this.selectedFilterStatusId['_id']];
        }

        this.filterStatusId =this.selectedFilterStatusId['_id']
        
      }
      
   
      if(!resetpage){
        postData["page"] = this.page;
      postData["perpage"] = this.perpage;
      }
    
      postData["title"] = title;
      this.islistLoading = true;
      this.$store
        .dispatch("getList", {
          data: postData,
          path: "/datasource/list",
        })
        .then((response) => {
          this.islistLoading = false;
          let listing = JSON.parse(response.result);
          this.listing = listing[0];
          if (listing.length > 0) {
            let res = listing[0];
            if (res && res["docs"]) {
              this.listing = res["docs"];
            }
            if (res && res["totalCount"]) {
              this.totalCount = res["totalCount"][0]["count"];
            }
          }
        })
        .catch((err) => {
          this.islistLoading = false;
        });
    },
  },
};
</script>