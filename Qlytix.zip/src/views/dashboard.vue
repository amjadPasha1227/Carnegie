<template>
    <div class="no_data_found_sec">
        <img src="@/assets/images/Data_collection_img.svg">
        <h3>Dashboard</h3>
        <small>No Dashboard(s) Were Added</small>
        <button type="button" class="primary_btn lg">
            Add Dashboard
        </button>
    </div>
</template>

<script>
    // @ is an alias to /src
   
    
    export default {
      name: 'dashboard-view',
      components: {
       
      }
    }
    </script>