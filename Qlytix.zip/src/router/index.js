import Vue from 'vue'
import VueRouter from 'vue-router'
import _ from "lodash";
import store from '@/store'


Vue.use(VueRouter)

const routes = [

  {
    path: '/',
    name: 'login',
    component: () => import('@/layouts/Login.vue'),
    children: [

      {
        path: '/',
        name: 'Login View',
        meta: {
          title: 'Login',
          requiresAuth: false,

        },
        component: () => import('@/views/login.vue')
      },
      {
        path: '/login',
        name: 'Login View',
        meta: {
          title: 'Login',
          requiresAuth: false,

        },
        component: () => import('@/views/login.vue')
      },
      {
        path: '/set-password/:userId',
        name: 'Set Password',
        meta: {
          title: 'Set Password',
          requiresAuth: false,

        },
        component: () => import('@/views/setPassword.vue')
      }
      ///set-password

    ]
  },

  //After Login Layout
  {
    path: '/',
    name: 'dataview',
    component: () => import('@/layouts/Main.vue'),
    children: [

      {
        path: '/',
        name: 'dashboard View',
        meta: {
          title: 'Dashboard',
          requiresAuth: true,

        },
        component: () => import('@/views/dashboard.vue')
      },
      {
        path: '/dashboard',
        name: 'dashboard View',
        meta: {
          title: 'Dashboard',
          requiresAuth: true,

        },
        component: () => import('@/views/dashboard.vue')
      },
      {
        path: '/dataview',
        name: 'Data View',
        meta: {
          title: 'Data View',
          requiresAuth: true,

        },
        component: () => import('@/views/dataview.vue')
      },
      {
        path: '/data-collection/add',
        name: 'Data Source',
        meta: {
          title: 'Data Source',
          requiresAuth: true,

        },
        component: () => import('@/views/dataSource.vue')
      },
      {
        path: '/data-collection/edit/:id',
        name: 'Edit Data Source',
        meta: {
          title: 'Edit Data Source',
          requiresAuth: true,

        },
        component: () => import('@/views/dataSource.vue')
      },{
        path: '/data-collection/view/:id',
        name: 'View Data Source',
        meta: {
          title: 'View Data Source',
          requiresAuth: true,

        },
        component: () => import('@/views/dataCollectionview.vue')
      },
      {
        path: '/users/add',
        name: 'addUser',
        meta: {
          title: 'User',
          requiresAuth: true,

        },
        component: () => import('@/views/addUser.vue')
      },
      {
        path: '/user/edit/:id',
        name: 'addUser',
        meta: {
          title: 'Edit User',
          requiresAuth: true,

        },
        component: () => import('@/views/addUser.vue')
      },
      {
        path: '/dataprocess',
        name: 'data process',
        meta: {
          title: 'Data Process',
          requiresAuth: true,

        },
        component: () => import('@/views/dataProcess.vue')
      },


      {
        path: '/data-collection',
        name: 'data collection',
        meta: {
          title: 'Data Collection',
          requiresAuth: true,

        },
        component: () => import('@/views/dataCollection.vue')
      },
      {
        path: '/users',
        name: 'users',
        meta: {
          title: 'Users',
          requiresAuth: true,

        },
        component: () => import('@/views/users.vue')
      },
      //data-collection-details.vue
      {
        path: '/data-collection-details',
        name: 'data collection details',
        meta: {
          title: 'Data Collection Details',
          requiresAuth: true,

        },
        component: () => import('@/views/dataCollectionDetails.vue')
      },
      {
        path: '/test-components',
        name: 'test-components',
        meta: {
          title: 'Data View',
          requiresAuth: true,

        },
        component: () => import('@/views/componentsTest.vue')
      },


    ]
  }
]

const router = new VueRouter({
  base: process.env.BASE_URL,
  scrollBehavior() {
    return { x: 0, y: 0 }
  },
  mode: 'history',
  routes
})





router.beforeEach((to, from, next) => {
const user = store.getters.getuser;
  

 
  if(to.meta.requiresAuth === false){
    

    if(['/set-password'].indexOf(to.path)>-1 && store.getters['isLoggedIn'] ){
      localStorage.removeItem('token');
      localStorage.removeItem('role_id');
      localStorage.removeItem('user');
      delete axios.defaults.headers.common['Authorization']
      store.dispatch("logout");
     
  
    }
    if (store.getters['isLoggedIn'] && to.path != '/dashboard' ) {
      next('/dashboard');
      return;
    }

  }else{
    
    if (store.getters['isLoggedIn'] && to.path == '/') {
      next('/dashboard');
      return;
    }
    if (!store.getters['isLoggedIn'] && to.path != '/') {
      next('/');
      return;
    }
    


  }
 
  next()
})

router.afterEach(() => {

})


export default router
