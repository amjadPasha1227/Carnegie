import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'

import { BootstrapVue, IconsPlugin } from 'bootstrap-vue'

import 'bootstrap/dist/css/bootstrap.css'
import 'bootstrap-vue/dist/bootstrap-vue.css'
import 'vue-multiselect-inv/dist/vue-multiselect.min.css'
import '@/scss/style.scss'

Vue.use(BootstrapVue)
Vue.use(IconsPlugin)

import VueToast from 'vue-toast-notification';
import 'vue-toast-notification/dist/theme-sugar.css';
Vue.use(VueToast);

import VueTimepicker from 'vue2-timepicker'
import 'vue2-timepicker/dist/VueTimepicker.css'
Vue.use(VueTimepicker);
import './mixins/mixins.js'

import './filters'




// Form validators 
import "./vee-validate";

import VeeValidate from 'vee-validate';
Vue.use(VeeValidate);

import { Validator } from 'vee-validate';

Validator.extend("maxval", {
 
  validate(value, args) {
    console.log(value + "====  "+JSON.stringify(args[0]));
    if(value<=parseInt(args[0])){
      return true;
    }else{
      return false;
    }
  },
  params: ['length'],
  message: 'Max value {length} is required'
});

Validator.extend("minval", {
 
  validate(value, args) {
    console.log(value + "====  "+JSON.stringify(args[0]));
    if(value>=parseInt(args[0])){
      return true;
    }else{
      return false;
    }
  },
  params: ['length'],
  message: 'Minimum value {length} is required'
});

Validator.extend('strongpassword', {
  getMessage: field => `The password must contain at least: 1 uppercase, 1 lowercase, 1 number, and one special character`,
  validate: value => {
      var strongRegex = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{6,})");
      return strongRegex.test(value);
  }
});



Vue.config.productionTip = false

new Vue({
  router,
  store,
  render: h => h(App),
  mounted() {
    this.$validator.localize('en', {
      messages: {
        required: (field) => '*' + field + ' is required',
        date_format: (field, args) => `Date must be a valid format (MM/DD/YYYY)`
      },
    })
  }
}).$mount('#app')
