<template>
    <div class="login_page_wrapper">
        <header class="login_header">
            <div class="logo">
                <a href="#"><img src="@/assets/images/Logo-white.svg" alt="logo"></a>
                <span class="divider"></span>
                <div class="dt_caption">
                    <span>DataTech Platform</span>
                </div>
            </div>
            <div class="right_cnt login_right">
                <div class="right_menu"></div>
            </div>
        </header>
        <router-view/>
        <footer class="footer_sec">
            <div class="copyright">
                <p>Copyright© 2022 - Axis Bank. All Rights Reserved.</p>
            </div>
            <div class="disclaimer">
                <ul>
                    <li>
                        <a href="#">Disclaimer</a>
                    </li>|
                    <li>
                        <a href="#" class="me-0">Privacy Policy</a>
                    </li>
                </ul>
            </div>
        </footer>
    </div>
  </template>
  
  <script>
  // @ is an alias to /src
  //import HelloWorld from '@/components/HelloWorld.vue'
  
  export default {
    name: 'before-login-layout',
    components: {
     // HelloWorld
    },
    data: () => ({
     
    })
  }
  </script>
  