<template>

    <div class="wrapper">
         <headerVue />
        <sideBar />
        <div class="main_area">
          <router-view/>
        </div>
    </div>
</template>

<script>
    // @ is an alias to /src
    import sideBar from "@/views/sideBar.vue"
    import headerVue from "@/views/header.vue"
    
    export default {
      name: 'Main',
      components: {
        sideBar,
        headerVue
      }
    }
    </script>