

const state = {
    status:'',
    token: localStorage.getItem('token') || '',
    user : JSON.parse(localStorage.getItem('user')) || [],
    userRole: localStorage.getItem('userRole') || '',
    windowWidth: null,
  
}

export default state
