


const getters = {
  isLoggedIn: state => !!state.token,
  authStatus: state => state.status,
  getuser: state => state.user,
  getuserRole: state => state.user.role_id,
  getToken:state => state.token
  
  
}

export default getters