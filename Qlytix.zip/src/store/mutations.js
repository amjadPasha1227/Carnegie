import _ from "lodash"
const mutations = {
      
      auth_success(state, details){
        state.status = 'success'
        state.token = details.token
        state.user = details.user
        state.role_id = details.role_id
      
      },
     logout(state){
        state.status = ''
        state.token = ''
        
      }
}

export default mutations
