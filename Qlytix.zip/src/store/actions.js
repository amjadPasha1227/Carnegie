import axios from '@/axios.js';
//import store from '@/store'
//import moment from 'moment'


const actions = {
  

  
  login({ commit }, item) {
    return new Promise((resolve,reject) => {
      axios.post("/auth/login", item)
        .then((response) => {

    
         
          localStorage.setItem('role_id', response.data.result.role_id)
          localStorage.setItem('token', response.data.result.token)
          localStorage.setItem('user',JSON.stringify(response.data.result.user))
         

          const user = response.data.result;
          commit('auth_success', user)
        
         
         
         resolve(response.data.result)
        })
        .catch((error) => { 
          
          reject(error.response.data.result) }
        )
    })
  },
  
 
  logout({commit}){
    return new Promise((resolve) => {
      console.log(commit);
      commit('logout')
      
      localStorage.removeItem('token');
      localStorage.removeItem('role_id');
      localStorage.removeItem('user');
      delete axios.defaults.headers.common['Authorization']
      localStorage.clear();
      resolve()
    })
  },
  
getList({commit}, {data ,path=""}) {
  return new Promise((resolve, reject) => {
      axios.post(path, data)
      .then((response) => {
        console.log(response)
          resolve(response.data)
      })
      .catch((error) => { 
        //console.log(error)
          reject(error.response.data);

      })
  })
},

commonAction({commit}, {data ,path=""}) {
  return new Promise((resolve, reject) => {
      axios.post(path, data)
      .then((response) => {
          
          resolve(response.data.result)
      })
      .catch((error) => { 
       console.log(error);
       // alert(error.response.data.message);
        reject(error.response.data.result);

      })
  })
},
uploadS3File({commit}, postdata) {
  return new Promise((resolve) => {
    axios.post("/s3/upload", postdata)
      .then((response) => {
        console.log(response);
        resolve(response)
      })
      .catch((error) => {
        if (error.response) {
          resolve(error.response.data.result.message);
        }
      })
  })
},

  
  
}

export default actions
