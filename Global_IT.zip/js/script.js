$(document).ready(function() {
    // Swiper: Slider
        new Swiper('.swiper-container', {
        loop: true,
        nextButton: '.swiper-button-next',
        prevButton: '.swiper-button-prev',
        slidesPerView: 4,
        paginationClickable: true,
        spaceBetween: 20,
        breakpoints: {
            1920: {
                slidesPerView: 4,
                spaceBetween: 20,
                width: 1400,
            },
            1028: {
                slidesPerView: 3,
                spaceBetween: 30
            },
            991: {
                slidesPerView: 2,
                spaceBetween: 30,
                width: 650,
            },
            767: {
                slidesPerView: 2,
                spaceBetween: 10,
            }
        }
    });

    new Swiper('.swiper-container-success', {
        loop: true,
        nextButton: '.swiper-button-next',
        prevButton: '.swiper-button-prev',
        slidesPerView: 1,
        paginationClickable: true,
        pagination: '.swiper-pagination',
    });

    new Swiper('.swiper-container-ourteam', {
        loop: true,
        nextButton: '.swiper-button-next',
        prevButton: '.swiper-button-prev',
        slidesPerView: 3,
        paginationClickable: true,
        pagination: '.swiper-pagination'
    });
});
