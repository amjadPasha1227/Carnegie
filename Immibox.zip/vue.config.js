module.exports = {
  publicPath: '/'
}

