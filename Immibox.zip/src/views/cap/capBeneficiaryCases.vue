<template>
    <div>
      
      <div class="content-header">
        <div class="content-header-left">
          <div class="search">
            <vs-input
              icon-pack="feather"
              icon="icon-search"
              :placeholder="beneficiaryId ==null?'Search by Case No':'Search by Case No'"
              class="is-label-placeholder"
              v-model.lazy="searchtxt"
            /> 
          </div>
           <div class=" con-select  selection_search" v-if="false" >
                      
                       <multiselect
                        @input="getpetitions(true);"
                        v-model="selectedDeletedCase"
                        :options="caselist"
                        :multiple="true"
                        :close-on-select="true"
                        :clear-on-select="false"
                        :preserve-search="true"
                        placeholder="Select"
                        label="name"
                        track-by="name"
                        :preselect-first="false"
                        :allow-empty="true"
                      >
                       
                        <template slot="selection" slot-scope="{ values, isOpen }">
                          <span
                          class="multiselect__selectcustom"
                          v-if="values.length && !isOpen"
                          >{{ values.length }} Case Type(s) Selected</span
                          >
                          <span
                          class="multiselect__selectcustom"
                          v-if="values.length && isOpen"
                          ></span>
                        </template>
                      </multiselect>
         </div>
        </div>
    
         
      </div>
  
      <div class="accordian-table custom-table no-wrap relative">
  
              <NoDataFound ref="NoDataFoundRef"  :loading="isListLoading" v-if="petitioners.length == 0" content="" :heading="callFromSerch?'No Results Found':'No Cases Found'" type='petitions' />
  
      
  
  
        <div v-if="petitioners.length >  0">
         <div class="notes_section pl-0 pr-0" v-if="petitioners.length > 0">
         <div>
           <div class="notes_list_wrap">
            <template >
              <div class="notes_list"  v-for="(ticket, tindex) in petitioners" :key="tindex">
                <div class="notes_info" @click="petitionlink(ticket)">
                  <h4  >{{ ticket.caseNo }}</h4>
                  <!-- <p  >{{ checkProperty(ticket ,'typeDetails','name') }} -->
                 <!-- <small v-if="checkProperty(ticket ,'subTypeDetails','name')" > ({{ checkProperty(ticket ,'subTypeDetails','name') }}) </small></p> -->
                  <ul>
                    <li  v-if="checkProperty(ticket, 'companyDetails')">
                      <label v-if="checkProperty(ticket, 'companyDetails')"  >Petitioner: </label>
                      <p>
                        {{ checkProperty(ticket, "companyDetails", 'name') }}
                        
                      </p>
                    </li>
                    <li v-if="checkProperty(ticket,'clientInfo','name')" >
                       <label >Client: </label>
                       <p>
                          {{checkProperty(ticket,'clientInfo','name')}}
                       </p>
                    </li>
                  </ul>
                </div>
                <div class="notes_status_sec">
                  <template >
                    <span
                      class="statusspan" v-bind:class="{
                      ' status_created ': checkProperty(ticket, 'statusDetails', 'id') == 1 || checkProperty(ticket, 'statusDetails', 'id') == 11,
                      ' status_submited ': checkProperty(ticket, 'statusDetails', 'id') == 2,
                      ' status_inProcess ': checkProperty(ticket, 'statusDetails', 'id') == 3,
                      ' status_verified ': checkProperty(ticket, 'statusDetails', 'id') == 4,
                      ' status_registered ': checkProperty(ticket, 'statusDetails', 'id') == 5,
                      ' status_submited-USCIS ': checkProperty(ticket, 'statusDetails', 'id') == 6,
                      ' status_selected': checkProperty(ticket, 'statusDetails', 'id') == 7,
                      ' status_not_selected ': checkProperty(ticket, 'statusDetails', 'id') == 8,
                      ' status_denied': checkProperty(ticket, 'statusDetails', 'id') == 9,
                      ' status_payment_failed ': checkProperty(ticket, 'statusDetails', 'id') == 10,
                    }"
                            >{{checkProperty(ticket,'statusDetails','name')}}</span>
                  </template>     
                    <label v-if=" checkProperty(ticket, 'updatedOn')"
                    >Last Updated: 
                    <strong v-if="checkProperty(ticket, 'updatedOn')"  >
                      {{ ticket.updatedOn | formatDate }}</strong
                    >
                    </label>
                    <label v-else>
                      Created On:
                    <strong v-if="checkProperty(ticket, 'createdOn')">
                      {{ ticket.createdOn | formatDate }}</strong
                    >
                    </label>
                   <div  class="right-buttons">
                      <button
                        color="primary"
                        type="border"
                        class="IB_primary-btn mt-2"
                       @click="petitionlink(ticket)"
                        v-if="!checkProperty(ticket, 'questionnaireFilled') "
                      ><span>Fill Questionnaire</span> 
                     </button> 
                  </div>
                </div>
              </div>
            </template>
          </div>
          </div>
          </div>
          
        
  
           
        
        
        </div>
      </div>
  
        
    </div>
  </template>
  
  <script>
  import DateRangePicker from "vue2-daterange-picker";
  import Paginate from "vuejs-paginate";
  import Datepicker from "vuejs-datepicker-inv";
  import Multiselect from "vue-multiselect-inv";
  import JQuery from "jquery";
  import NoDataFound from "@/views/common/noData.vue";
  
  import * as _ from "lodash";
  import "vue2-daterange-picker/dist/vue2-daterange-picker.css";
  import addBeneficiary  from "@/views/common/addBeneficiary.vue" 
  import addBenewPet  from "@/views/common/invitePet.vue" 
  import moment from 'moment'
  export default {
    props: {
      beneficiaryId:null,
      beneficiaryInfo:null,
      petitionerDetails:null,
      isRfe:{
        type: Boolean, default:false
      }
    },
    components: {
     
      Datepicker,
      DateRangePicker,
      Multiselect,
      Paginate,
      NoDataFound
    },
    data: () => ({
      caselist:[{_id:true,name:'Active'},{_id:false,name:'Deleted'}],
      selectedDeletedCase:[],
      premiumProcessingList:[{name:'Enabled' ,_id:true },{name:'Disabled' ,_id:false }],
      selectedpremiumProcessing:[],
      premiumProcessing:false,
      newPetitionFormSubmited:false,
       formerrors: {
        msg: ""
      },
      selectedBranch:null,
      NewPetition:false,
      petitionersList:[],
      invitepetitioner:false,
      AddBeneficiary:false,
      selectedPetitioner:null,
      saveBenbtn:false,
      selectedUser:'',
      selectedUsername:'',
      beneficiaryMasterDataList:[],
      visatypes:[],
      visasubtypes:[],
      visasubtype:null,
      selectedBeneficiary:null,
       
  
  
  
      branchList:[],
      selectedBranches:[],
     isListloading:false,
      callFromSerch:false,
      sortKeys:{},
      sortKey:{},
      buttoncol: true,
      ChangePetition: false,
      formerrors: {
        msg: ""
      },
      searchtxt: "",
      query: [],
      selected: [],
      petitioners: [],
      currentuserRole: null,
      selecteduser: {
        petitionId: null,
        userName: null,
        email: null,
        typeName: null,
        subTypeName: null,
        instructions: null
      },
      SendQuestionnaire: false,
      SuccessQuestionnaire: false,
      selected_createdDateRange: ["", ""],
      selected_deadLineDateRange: ["", ""],
      autoApply: "",
      countries: [],
      country_code: 0,
      selected_country_obj: "",
      selected_statusids: [],
      final_selected_statusids: [],
      all_states: [],
      seleted_states: [],
      final_selected_states: [],
      singel_final_selected_state: "",
      all_locations: [],
      seleted_locations: [],
      final_selected_locations: [],
      all_statusids: [],
      selected_statusids: [],
      final_selected_statusids: [],
      page: 1,
      perpage: 25,
      totalpages: 0,
  
      filter_searchtxt: "",
      visaTypes:[],
      selectedVisaType:null,
      all_subtypes: [],
      selected_subtypes: [],
      final_selected_subtypes: [],
  
      final_filter_roleIds: [3, 4, 5, 9, 10],
      rolebased_filter: {
        3: { name: "supervisorIds", values: [] },
        4: { name: "paralegalIds", values: [] },
        5: { name: "attorneyIds", values: [] },
        9: { name: "offshoreUserIds", values: [] },
        10: { name: "evidenceSupervisorIds", values: [] }
      },
      users: [],
      selected_users: [],
      final_selected_users: [],
      user_search_value: "",
      roleId: 0,
  
      all_peritioners: [],
      peritioners_search_value: "",
      selected_peritioners: [],
      final_selected_peritioners: [],
  
    isListLoading:false,
      sortKeys:{},
      sortKey:{},
      perPeges: [10,25,50,75,100], // [  {name:10 ,perPage:10} , {name:25 ,perPage:25} ,{name:50 ,perPage:50},{name:100 ,perPage:100}],
      selectedForArchiveList:[],
      archiving:false,
      selectedarchive:[],
      selectedAllForArchive:false,
      encodedString:'',
     
    }),
    watch: {
      searchtxt: function(value) {
        let text = value.trim();
  
        if(text.length>3 || text==''){
           this.getpetitions(true);
           
        }
       
      },
       '$route.query.filter':function (val) {
  
          if(this.checkProperty(this.$route ,'query' ,'filter')){
                  try{
                    let filter =this.$route['query']['filter']; this.checkProperty(this.$route ,'query' ,'filter')
                    var actual = JSON.parse(atob(filter));
                    let keys = Object.keys(actual);
                    if(this.checkProperty(keys ,'length') >0){
  
  
                      if(actual && (Object.keys(actual)).length>0 ){
                      _.forEach(actual ,(item ,key) => {
                          if(key=='matcher' ){
                            
                            if((Object.keys(item)).length>0 ){
  
                              if(_.has(item ,'typeIds') && this.checkProperty(item , 'typeIds' ,'length')>0 ){
                                 
                                this.selectedVisaType = _.find(this.visaTypes ,{"id":item['typeIds'][0]})
                             
                               this.getvisa_subtypes();
                             
                              }  
                            }
                          
                          }
                      })
                    }
                      
                      
                    }
  
                  }catch(e){
                    
  
                  }
                    
                }
          
            this.getpetitions(true);
        }
    },
    methods: {
        getpetitions(callFromSearch=false, callFromFilter=false){
     
     this.callFromSearch = callFromSearch
     if(this.callFromSearch){
       this.petitioners = []
     }
     //'623b3c3c75d58329b830cdcd','625e6857cadbc43c50c92ee7','628f6b6b096c8624d886648b'
     let Payload = {
       matcher : {
         searchString:this.searchtxt,
         petitionerIds: [],
         beneficiaryIds: [],
         statusIds: [],
         statusList: [],
         branchIds: [],
         typeNames: [],
         seasonList:[],
         capTypeList:[],
         premiumProcessing:[],
       },
         page: 1,
         perpage:1000000,
         sorting: this.sortKey,
         today: moment().format('YYYY-MM-DD'),
       }
     this.isListloading = true;
     this.updateLoading(true);
     this.$store.dispatch("commonAction", {"data":Payload ,"path":"/cap-registrations/list"}).then((response) => {
       this.isListloading = false;
       this.updateLoading(false);
       this.petitioners = response.list
       //this.totalpages = Math.ceil(response.totalCount / this.perpage)
       setTimeout(()=>{
         this.updateLoading(false);
       },10);
     })
     .catch((err)=>{
       this.isListloading = false;
       this.updateLoading(false);
     })
   },
      goTodetails(petition , stab ='Communication'){
  
        this.$store.dispatch("setPetitionTab" , stab)
        this.$router.push("/petition-details/"+petition['_id'])
      },  
      petitionlink(ticket) {
        let routedId = ticket._id;
        if(this.checkProperty(ticket,'questionnaireFilled')){
            this.$router.push({ path: `/cap-registration-details/${routedId}` ,query: {'filter':this.encodedString} })
        }else{
            this.$router.push({path: `/cap-registration-questionnaire/${routedId}` ,query: {'filter':this.encodedString} })  
        }
      },
      pageNate(pageNum) {
       
        this.page = pageNum;
        this.getpetitions();
      },
 
 
   
   
    
   
      setQueryString(obj){
        const string = JSON.stringify(obj) // convert Object to a String
        this.encodedString = btoa(string) // Base64 encode the String
      },
    
  
   
  
   
    

      getusers() {
        let matcher = {
          roleIds: this.final_filter_roleIds,
          searchString: this.user_search_value,
          page: 1
        };
        let query = {};
        query["page"] = 1;
        query["perpage"] = 100;
        query["matcher"] = matcher;
  
        this.$store.dispatch("getusers", query).then(response => {
          this.users = response.list;
        });
      },
      
     
      user_search(searchValue) {
        this.user_search_value = searchValue;
        this.getusers();
      },
  
    
      changeperPage(){
       
        this.page = 1;
        localStorage.setItem('petitions_perpage', this.perpage);
        this.getpetitions(true);
       
        
      },
        
    },
  
    mounted() {
  this.getpetitions();
      if (this.checkProperty(this.$router.currentRoute ,"query"  ,"status") ){
           
            let status = this.checkProperty(this.$router.currentRoute ,"query"  ,"status");
          
            
            if(status){
             
              this.final_selected_statusids =[parseInt(status)];
  
            }
            
          
          }
          if(this.checkProperty(this.$route ,'query' ,'page')>0){
              this.page = parseInt(this.checkProperty(this.$route ,'query' ,'page'))
          }
           if(this.checkProperty(this.$route ,'query' ,'search')){
              this.searchtxt =this.checkProperty(this.$route ,'query' ,'search')
          }
       this.visatype = {
          id: 1,
          name: "H-1B"
        }
       //this.getPetitioners();
    //   this.getvisatypes();
    //   this.username = this.$store.state.user.name;
    //   this.roleId = this.$store.state.user["roleId"][0];
  
     
    //    this.sortKey= {"path":'updatedOn',"order":-1};
        if(this.checkProperty(this.$route ,'query' ,'filter')){
          try{
             let filter =this.$route['query']['filter']; this.checkProperty(this.$route ,'query' ,'filter')
            var actual = JSON.parse(atob(filter));
            let keys = Object.keys(actual);
            if(this.checkProperty(keys ,'length') >0){
              
              
               this.getpetitions( false,actual);
            }else{
              this.getpetitions();
            }
  
          }catch(e){
             this.getpetitions();
  
          }
          
            
        }else{
  
            this.getpetitions();
  
        }
     
      this.$store.dispatch("getcountries").then(response => {
        this.countries = response;
      });
  
     
      //this.get_statusids();
     
  
    
    },
    computed:{
      checkEnableSelectAll(){
        let returnVal =false;
  let activeItems = _.filter(this.petitioners ,(item)=>{
          return this.checkProperty( item ,'status') !=false
       });
       if(activeItems && this.checkProperty(activeItems ,'length')>0){
         returnVal =true;
       }
        return returnVal;
      }
    }
  };
  </script>
  