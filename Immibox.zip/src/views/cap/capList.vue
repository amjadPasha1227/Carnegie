<template >
 
    <beneficiaryCases v-if="[51].indexOf(this.getUserRoleId)>-1"/>
    <cap v-else />
       
   </template>
   
   
   
   <script>
       import cap from "@/views/cap/Cap.vue"
       import beneficiaryCases from "@/views/cap/capBeneficiaryCases.vue"
   
      export default {
           name:'caselist',
          components: {
            cap,
               beneficiaryCases
   
           },
           mounted(){
           }
   
       }
   </script>