<template>
    <div class="pad20">
        <h3 class="small-header pt-0 mt-0 cap-info-header">Personal Information</h3>
        <div class="vx-row m-0 main-list-panel " :class="{'border-0':checkProperty(petition,'questionnaireTplType') !='slg'}">
            <div class="vx-col md:w-1/3 w-full p-0"
                v-if="checkProperty(petition, 'beneficiaryInfo', 'name') || checkProperty(petition, 'beneficiaryInfo', 'firstName') ||
                    checkProperty(petition, 'beneficiaryInfo', 'middleName') || checkProperty(petition, 'beneficiaryInfo', 'lastName')">
                <div class="main-list">
                    <p>
                        Full Name
                        <span>{{ formatFullname(petition.beneficiaryInfo) }}</span>
                    </p>
                </div>
            </div>

            <template v-if="checkProperty(petition, 'beneficiaryInfo', 'email')">
                <div class="vx-col md:w-1/3 w-full p-0"
                    v-if="checkIsTempAccount(checkProperty(petition, 'beneficiaryInfo', 'email'))">
                    <div class="main-list">
                        <p>
                            Email
                            <span>{{ checkProperty(petition, 'beneficiaryInfo', 'email') }}</span>
                        </p>
                    </div>
                </div>
            </template>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition, 'beneficiaryInfo', 'gender')">
                <div class="main-list">
                    <p>
                        Gender
                        <span style="text-transform: capitalize;">{{ petition.beneficiaryInfo.gender }}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="petition.beneficiaryInfo.cellPhoneNumber">
                <div class="main-list">
                    <p>
                        Phone Number
                        <span>
                            <template
                                v-if="checkProperty(petition['beneficiaryInfo'], 'cellPhoneCountryCode', 'countryCallingCode')">{{
                                    checkProperty(petition['beneficiaryInfo']
                                        , 'cellPhoneCountryCode', 'countryCallingCode') + "&nbsp;" }}</template>
                            {{ petition.beneficiaryInfo.cellPhoneNumber | formatPhone }}

                        </span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="petition.beneficiaryInfo.homePhoneNumber">
                <div class="main-list">
                    <p>

                        Home Phone Number
                        <span>
                            <template
                                v-if="checkProperty(petition['beneficiaryInfo'], 'homePhoneCountryCode', 'countryCallingCode')">{{
                                    checkProperty(petition['beneficiaryInfo']
                                        , 'homePhoneCountryCode', 'countryCallingCode') + "&nbsp;" }}</template>
                            {{ petition.beneficiaryInfo.homePhoneNumber | formatPhone }}
                        </span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition, 'beneficiaryInfo', 'dateOfBirth')">
                <div class="main-list">
                    <p>
                        Date of Birth
                        <span>{{ petition.beneficiaryInfo.dateOfBirth | formatDate }}</span>
                    </p>
                </div>
            </div>

            <div class="vx-col md:w-1/3 w-full p-0"
                v-if="checkProperty(petition['beneficiaryInfo'], 'countryOfBirthDetails', 'name')">
                <div class="main-list">
                    <p>
                        Country of Birth
                        <span>{{ checkProperty(petition['beneficiaryInfo'], 'countryOfBirthDetails', 'name') }}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0"
                v-if="checkProperty(petition['beneficiaryInfo'], 'provinceOfBirthDetails', 'name')">
                <div class="main-list">
                    <p>
                        Province of Birth
                        <span>{{ checkProperty(petition['beneficiaryInfo'], 'provinceOfBirthDetails', 'name') }}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition['beneficiaryInfo'], 'locationOfBirth')">
                <div class="main-list">
                    <p>
                        Location of Birth
                        <span>{{ checkProperty(petition['beneficiaryInfo'], 'locationOfBirth') }}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0"
                v-if="checkProperty(petition['beneficiaryInfo'], 'countryOfCitizenshipDetails', 'name')">
                <div class="main-list">
                    <p>
                        Country of Citizenship
                        <span>{{ checkProperty(petition['beneficiaryInfo'], 'countryOfCitizenshipDetails', 'name') }}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition, 'beneficiaryInfo', 'passportNumber')">
                <div class="main-list">
                    <p>
                        Passport Number
                        <span>{{ checkProperty(petition, 'beneficiaryInfo', 'passportNumber') }}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition, 'beneficiaryInfo', 'passportExpiryDate')">
                <div class="main-list">
                    <p>
                        Date of Passport Expiry
                        <span>{{ checkProperty(petition, 'beneficiaryInfo', 'passportExpiryDate') | formatDate }}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col w-full p-0" v-if="checkProperty(petition, 'documents')&&checkProperty(petition, 'documents','passport')
            && checkProperty(petition['documents'], 'passport', 'length') > 0">
                <h3 class="small-header mb-0 cap-info-header" v-if="checkProperty(petition,'questionnaireTplType') =='slg' ">Passport</h3>
                <ul class="documents_new_list">
                    <li class="doc_list_item"
                        v-if="checkProperty(petition, 'documents', 'passport') && checkProperty(petition['documents'], 'passport', 'length') > 0">
                        <documentsView @download_or_view="downloadfile" :type="'passport'"
                            :documentsList="petition['documents']['passport']" :petitionDetails="petition" />
                    </li>
                </ul>
            </div>
            

        </div>
        <div class="vx-row main-list-wrap pl-4" v-if="checkProperty(petition,'questionnaireTplType') !='slg' ">
                <div class="vx-col md:w-1/3 w-full p-0 main-list-panel border-0"
                    v-if="checkProperty(petition, 'beneficiaryInfo', 'reqConsdnOfAdvDegreeExptn') == false || checkProperty(petition, 'beneficiaryInfo', 'reqConsdnOfAdvDegreeExptn') == true">
                    <div class="main-list">
                        <p>
                            Do you have master's degree from United States University?
                            <span>{{ petition.beneficiaryInfo.reqConsdnOfAdvDegreeExptn | booleanFormat }}</span>
                        </p>
                    </div>
                </div>
                <div class="vx-col md:w-1/3 w-full p-0 main-list-panel border-0" v-if="checkProperty(petition,'beneficiaryInfo', 'mastersUniversityName')">
                    <div class="main-list">
                        <p>
                            University Name
                            <span>{{ checkProperty(petition,'beneficiaryInfo', 'mastersUniversityName') }}</span>
                        </p>
                    </div>
                </div>
                <div class="vx-col w-full p-0" v-if="petition.questionnaireTplType != 'slg'">
                    <ul class="documents_new_list">
                        <li class="doc_list_item"
                            v-if="checkProperty(petition, 'documents', 'eduTranscripts') && checkProperty(petition['documents'], 'eduTranscripts', 'length') > 0">
                            <documentsView @download_or_view="downloadfile" :type="'eduTranscripts'"
                                :documentsList="petition['documents']['eduTranscripts']" :petitionDetails="petition" />
                        </li>
                    </ul>
                </div>
            </div>
        
        
        <template v-if="checkProperty(petition,'questionnaireTplType') =='slg' ">
            <h3 class="small-header pt-2 cap-info-header">Educational Information</h3>
            <div class="vx-row main-list-wrap pl-4">
                <div class="vx-col md: w-full p-0 main-list-panel"
                    v-if="checkProperty(petition, 'beneficiaryInfo', 'reqConsdnOfAdvDegreeExptn') == false || checkProperty(petition, 'beneficiaryInfo', 'reqConsdnOfAdvDegreeExptn') == true">
                    <div class="main-list">
                        <p>
                            Do you have master's degree from United States University?
                            <span>{{ petition.beneficiaryInfo.reqConsdnOfAdvDegreeExptn | booleanFormat }}</span>
                        </p>
                    </div>
                </div>
            </div>
            <div v-if="petition.questionnaireTplType != 'slg' && false" class="cap-edu-info">
                <!-- <h3 class="small-header mb-0 cap-info-header">Passport</h3> -->
                <div class="vx-row m-0 main-list-panel">
                    <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'beneficiaryInfo', 'mastersUniversityName')">
                        <div class="main-list">
                            <p>
                                University Name
                                <span>{{ checkProperty(petition,'beneficiaryInfo', 'mastersUniversityName') }}</span>
                            </p>
                        </div>
                    </div>
                </div>
                <ul class="documents_new_list">
                    <li class="doc_list_item"
                        v-if="checkProperty(petition, 'documents', 'eduTranscripts') && checkProperty(petition['documents'], 'eduTranscripts', 'length') > 0">
                        <documentsView @download_or_view="downloadfile" :type="'eduTranscripts'"
                            :documentsList="petition['documents']['eduTranscripts']" :petitionDetails="petition" />
                    </li>
                </ul>
            </div>

            <!-- petition.beneficiaryInfo.reqConsdnOfAdvDegreeExptn -->
            <div v-if="petition.questionnaireTplType == 'slg'" class="cap-edu-info">
                <educationInfo :visastatuses="visastatuses" :petition="petition"></educationInfo>
            </div>


        </template>
    </div>
</template>
    
<script>
import educationInfo from "@/views/petition/subtabs/educationsVersion2.vue";
import documentsView from "@/views/common/documentsView.vue";
import _ from "lodash";
export default {
    components: {
        educationInfo,
        documentsView,
    },
    data: () => ({
        visastatuses: [],
        docPrivew: false,
    }),
    props: {
        petition: {
            type: Object,
            default: null
        },

    },
    computed: {

    },
    methods: {
        formatFullname(item) {
            let returnVal = ''
            if (this.checkProperty(item, 'name')) {
                return returnVal = this.checkProperty(item, 'name')
            }
            else {
                if (this.checkProperty(item, 'firstName')) {
                    returnVal = this.checkProperty(item, 'firstName')
                }
                if (this.checkProperty(item, 'middleName')) {
                    returnVal = returnVal + ' ' + this.checkProperty(item, 'middleName')
                }
                if (this.checkProperty(item, 'lastName')) {
                    returnVal = returnVal + ' ' + this.checkProperty(item, 'lastName')
                }
                return returnVal
            }
        }, downloadfile(value) {
            this.$emit('download_or_view', value);
        },
        download_or_view(value) {
            if (_.has(value, "path")) {
                value['url'] = value['path'];
                value['document'] = value['path'];
            }

            if (_.has(value, "url")) {
                value['path'] = value['url'];
                value['document'] = value['url'];
            }

            if (_.has(value, "document")) {
                value['path'] = value['document'];
                value['url'] = value['document'];
            }

            this.selectedFile = value;
            this.docValue = '';
            this.docPrivew = false;
            this.docType = false;
            this.docType = this.findmsDoctype(value);

            if (this.docType == "office" || this.docType == "image") {

                value.url = value.url.replace(this.$globalgonfig._S3URL, "");
                value.url = value.url.replace(this.$globalgonfig._S3URLAWS, "");
                let postdata = {
                    keyName: value.url
                };
                this.$store.dispatch("getSignedUrl", postdata).then((response) => {
                    this.docValue = response.data.result.data;

                    if (this.docType == "office") {
                        this.docValue = encodeURIComponent(response.data.result.data);
                    }
                    this.docPrivew = true;
                });

            } else {
                this.downloads3file(value);
            }

        },

    },
    mounted() {

    }
};
</script>
    