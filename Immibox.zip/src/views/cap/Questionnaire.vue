<template >
  <span>
    <div class="block-layout questionnaire" id="scrollableques" :class="{ 'padt20': !checkCurrentUrl }">
      <div class="vx-col w-full wizard-container form_section  questionnairesection pad0 case-form-v2">
        <div class="questionnaire_page" id="questionnaire_page">
          <div class="questionnaire_sec">
            <div class="questionnaire_titles">
              <div class="questionnaire_titles_info">
                <h2>
                  Questionnaire for Cap Registration
                  <!-- <small v-if="petition.subTypeDetails">{{petition.subTypeDetails.name}}</small> -->
                </h2>
                <p>
                  Please take a few moments to complete this short registration form
                </p>

                <ul>
                  <template v-for="(item, index) in tabslist">
                    <li :key="index"
                      :class="{ 'active': currentTab == item.key || (index <= checkActiveTab && currentTab != item.key) }"
                      @click="setActiveTab(item.key, true)">
                      <span>{{ index + 1 }}</span><a>{{ item.name }} </a>
                    </li>
                  </template>
                </ul>
              </div>
              <figure><img src="@/assets/images/main/content-bottom-image.svg" /></figure>
            </div>
            <div class="questionnaire_form">
              <div id="case_details_dt" v-if="currentTab == 'casedetails'">
                <form data-vv-scope="casedetailsform">
                  <div class="vs-col w-full p-0 vs-xs- vs-sm- vs-lg-">
                    <div class="con-vs-alert warning-alert top-warning-alert con-vs-alert-warning con-icon">
                      <div class="vs-alert con-icon">
                        <i class="vs-icon notranslate icon-scale icon-alert IntakePortal IP-information-button null"></i>
                        NOTE: This questionnaire should be filled out completely and
                        accurately. Kindly read the instructions carefully.
                      </div>
                    </div>
                  </div>
                  <div class="vs-col m-auto float-none vs-xs- vs-sm-12 vs-lg-12">
                    <div class="form-container pt-10 form-container-questionnaire">
                      <div class="vx-row  pt-10">
                        <genderField :display="true" :required="true" :formScope="'casedetailsform'"
                          :fieldsArray="questionnaireDetails" :gender="petition.beneficiaryInfo.gender"
                          v-model="petition.beneficiaryInfo.gender" :tplsection="'beneficiaryInfo'" :tplkey="'gender'"
                          :fieldName="'gender'" />

                        <div class="divider full-divider mb-10"></div>
                        <div class="vx-col w-full">
                          <vx-input-group class="form-input-group FML">
                            <immiInput :display="true" :fieldsArray="questionnaireDetails" cid="benf"
                              formscope="casedetailsform" v-model="petition.beneficiaryInfo.firstName"
                              :tplsection="'beneficiaryInfo'" :tplkey="'firstName'" :fieldName="'firstName'"
                              :required="checkSLGAndRenderField" label="First Name" placeHolder="First Name" />
                            <immiInput :display="true" :fieldsArray="questionnaireDetails" cid="benm"
                              formscope="casedetailsform" v-model="petition.beneficiaryInfo.middleName"
                              :tplsection="'beneficiaryInfo'" :tplkey="'middleName'" :fieldName="'middleName'"
                              :required="false" label="Middle Name" placeHolder="Middle Name" />
                            <immiInput :display="true" :fieldsArray="questionnaireDetails" cid="benl"
                              formscope="casedetailsform" v-model="petition.beneficiaryInfo.lastName"
                              :tplsection="'beneficiaryInfo'" :tplkey="'lastName'" :fieldName="'lastName'"
                              :required="true" label="Last Name" placeHolder="Last Name" />
                          </vx-input-group>
                        </div>
                        <immiInput :display="true" :fieldsArray="questionnaireDetails" datatype="email" wrapclass=" "
                          cid="benfemail" formscope="casedetailsform" v-model="petition.beneficiaryInfo.email"
                          :tplsection="'beneficiaryInfo'" :tplkey="'email'" :fieldName="'email'" :required="checkEmailRequired"
                          label="Email" placeHolder="Email" />
                        <immiPhone :display="true" @updatephoneCountryCode="updatecellPhoneCountryCode"
                          :fieldsArray="questionnaireDetails"
                          :countrycode="petition.beneficiaryInfo.cellPhoneCountryCode.countryCode"
                          cid="bencellPhoneNumber" formscope="casedetailsform"
                          v-model="petition.beneficiaryInfo.cellPhoneNumber" :tplsection="'beneficiaryInfo'"
                          :tplkey="'cellPhoneNumber'" :fieldName="'cellPhoneNumber'" :required="false"
                          label="Phone Number" placeHolder="Phone Number" />
                        <immiPhone :display="true" @updatephoneCountryCode="updatehomePhoneCountryCode"
                          :fieldsArray="questionnaireDetails"
                          :countrycode="petition.beneficiaryInfo.homePhoneCountryCode.countryCode"
                          cid="benhomePhoneNumber" formscope="casedetailsform"
                          v-model="petition.beneficiaryInfo.homePhoneNumber" :tplsection="'beneficiaryInfo'"
                          :tplkey="'homePhoneNumber'" :fieldName="'homePhoneNumber'" label="Home Phone Number"
                          placeHolder="Home Phone Number" />
                        <template v-if="false">
                          <immiPhone :display="true" @updatephoneCountryCode="updateworkPhoneCountryCode"
                            :fieldsArray="questionnaireDetails"
                            :countrycode="petition.beneficiaryInfo.workPhoneCountryCode.countryCode"
                            cid="benworkPhoneNumber" formscope="casedetailsform"
                            v-model="petition.beneficiaryInfo.workPhoneNumber" :tplsection="'beneficiaryInfo'"
                            :tplkey="'workPhoneNumber'" :fieldName="'workPhoneNumber'" label="Work Phone Number"
                            placeHolder="Work Phone Number" />
                          <immiPhone :display="true" @updatephoneCountryCode="updatefaxCountryCode"
                            :fieldsArray="questionnaireDetails"
                            :countrycode="petition.beneficiaryInfo.faxCountryCode.countryCode" cid="benfaxPhoneNumber"
                            formscope="casedetailsform" v-model="petition.beneficiaryInfo.fax"
                            :tplsection="'beneficiaryInfo'" :tplkey="'fax'" :fieldName="'fax'" label="Fax Number"
                            placeHolder="Work Fax Number" />
                        </template>
                        <datepickerField :display="true" :fieldsArray="questionnaireDetails"
                          :dateEnableTo="startEligibleDate" :validationRequired="true"
                          v-model="petition.beneficiaryInfo.dateOfBirth" :tplsection="'beneficiaryInfo'"
                          :tplkey="'dateOfBirth'" :fieldName="'dateOfBirth'" formscope="casedetailsform"
                          label="Date of Birth" />
                        <selectField :display="true" :fieldsArray="questionnaireDetails" @input="changeBfProvince"
                          :required="true" :optionslist="countriesWithoutUS"
                          v-model="petition.beneficiaryInfo.countryOfBirthDetails" :tplsection="'beneficiaryInfo'"
                          :tplkey="'countryOfBirth'" :fieldName="'countryOfBirth'" formscope="casedetailsform"
                          label="Country of Birth" placeHolder="Country of Birth" />
                        <selectField v-if="checkSLGAndRenderField" :display="true" :fieldsArray="questionnaireDetails"
                          @input="petition.beneficiaryInfo.provinceOfBirth = petition.beneficiaryInfo.provinceOfBirthDetails.id"
                          :required="true" :optionslist="bfeprovinceStates"
                          v-model="petition.beneficiaryInfo.provinceOfBirthDetails" :tplsection="'beneficiaryInfo'"
                          :tplkey="'provinceOfBirth'" :fieldName="'provinceOfBirth'" formscope="casedetailsform"
                          label="Province of Birth" placeHolder="Province of Birth" />
                        <immiInput v-if="checkSLGAndRenderField" :display="true" :fieldsArray="questionnaireDetails"
                          cid="benflocationOfBirth" formscope="casedetailsform"
                          v-model="petition.beneficiaryInfo.locationOfBirth" :tplsection="'beneficiaryInfo'"
                          :tplkey="'locationOfBirth'" :fieldName="'locationOfBirth'" :required="true"
                          label="Location of Birth" placeHolder="Location of Birth" />
                        <selectField :display="true" :fieldsArray="questionnaireDetails"
                          @input="petition.beneficiaryInfo.countryOfCitizenship = petition.beneficiaryInfo.countryOfCitizenshipDetails.id"
                          :required="true" :optionslist="countries"
                          v-model="petition.beneficiaryInfo.countryOfCitizenshipDetails" :tplsection="'beneficiaryInfo'"
                          :tplkey="'countryOfCitizenship'" :fieldName="'countryOfCitizenship'" formscope="casedetailsform"
                          label="Country of Citizenship" placeHolder="Country of Citizenship" />
                        <template v-if="false">
                          <immiInput :display="true" :fieldsArray="questionnaireDetails" cid="benI94" datatype="max:15"
                            formscope="casedetailsform" v-model="petition.beneficiaryInfo.I94"
                            :tplsection="'beneficiaryInfo'" :tplkey="'I94'" :fieldName="'I94'" :required="true"
                            label="I-94 Number" placeHolder="I-94 Number" />
                          <datepickerField :display="true" :fieldsArray="questionnaireDetails"
                            :dateEnableFrom="new Date()"
                            :validationRequired="petition.beneficiaryInfo.I94 != null && petition.beneficiaryInfo.I94 != ''"
                            v-model="petition.beneficiaryInfo.I94ExpiryDate" :tplsection="'beneficiaryInfo'"
                            :tplkey="'I94ExpiryDate'" :fieldName="'I94ExpiryDate'" formscope="casedetailsform"
                            label="I-94 Expiry Date" />
                        </template>

                        <immiInput
                          :helpText="'Make sure you input the most recent passport information. Also, note that the passport must have more than 6 months validity.'"
                          :display="true" :fieldsArray="questionnaireDetails" datatype="alpha_num|max:15"
                          cid="benfpassportNumber" formscope="casedetailsform"
                          v-model="petition.beneficiaryInfo.passportNumber" :tplsection="'beneficiaryInfo'"
                          :tplkey="'passportNumber'" :fieldName="'passportNumber'" :required="true"
                          label="Passport Number" placeHolder="Passport Number" />
                        <datepickerField v-if="checkSLGAndRenderField" :display="true" :fieldsArray="questionnaireDetails"
                          :dateEnableFrom="featureDates" :validationRequired="checkSLGAndRenderField"
                          v-model="petition.beneficiaryInfo.passportExpiryDate" :tplsection="'beneficiaryInfo'"
                          :tplkey="'passportExpiryDate'" :fieldName="'passportExpiryDate'" formscope="casedetailsform"
                          label="Passport Expiry Date" />



                        <div class="vx-col w-full md:w-1/2 cap_questinnaire_docs">
                          <casedocumentslist v-if="petitionLoaded" :showTitle="false" :docslist="docsList"
                            :formscope="'casedetailsform'" :fieldsArray="[]" v-model="petition.documents" :tplsection="''"
                            :fieldName="''" :required="checkSLGAndRenderField">
                          </casedocumentslist>
                        </div>
                        <immiyesorno v-if="!checkSLGAndRenderField" :display="true" :tplkey="'h4Required'" :fieldsArray="questionnaireDetails"
                                :callFromCap="false" v-model="petition.beneficiaryInfo.reqConsdnOfAdvDegreeExptn"
                                :helpText="'Are you requesting consideration under the INA 214(g)(5)(C) advanced degree exemption because the beneficiary has earned, or will earn prior to the filling of the petition, a master(s) or higher degree from a U.S. institution of higher education?'"
                                :tplsection="'dependentsInfo.spouse'" :fieldName="'h4Required'"
                                @input="checkMasterDegreeYesorNo"
                                label="Do you have master's degree from United States University?"></immiyesorno>


                               
                        <div v-if="!checkSLGAndRenderField && petition.beneficiaryInfo.reqConsdnOfAdvDegreeExptn"
                          class="vx-col w-full cap_questinnaire_docs">
                          <immiInput :display="true" :fieldsArray="questionnaireDetails" cid="mUniversityName"
                            formscope="casedetailsform" v-model="petition.beneficiaryInfo.mastersUniversityName" :tplsection="''"
                            wrapclass="w-full uni_name_input"
                            :tplkey="'mastersUniversityName'" :fieldName="'mastersUniversityName'" :required="checkMastersUniversityNameRequired"
                            label="University Name" placeHolder="University Name" @input="checkEduTranscriptsDocumentsRequired"/>
                        </div>
                        
                        <div class="vx-col w-full text-center" v-if="!checkSLGAndRenderField && petition.beneficiaryInfo.reqConsdnOfAdvDegreeExptn">
                          <p class="py-3 font-bold">OR</p>
                        </div>
                        <div v-if="!checkSLGAndRenderField && petition.beneficiaryInfo.reqConsdnOfAdvDegreeExptn"
                          class="vx-col w-full cap_questinnaire_docs">
                          <casedocumentslist v-if="petitionLoaded" :showTitle="false" :docslist="eduDocsList"
                            :formscope="'casedetailsform'" :fieldsArray="[]" v-model="petition.documents" :tplsection="''"
                            :fieldName="''">
                          </casedocumentslist>
                        </div>
                      



                        <template v-if="false">
                          <div class="vx-col w-full">
                            <div class="form_group w-full">
                              <label class="form_label">
                                <h3 class="small-header">Passport</h3>
                                <div class="IB_tooltip H1-140">
                                  <span><info-icon size="1.5x" class="custom-class"></info-icon></span>
                                  <div class="tooltip_cnt">
                                    <p>Make sure you input the most recent passport information. Also, note that the
                                      passport must have more than 6 months validity.</p>
                                  </div>
                                </div>
                              </label>
                            </div>
                          </div>

                          <!-- :helpText="'Make sure you input the most recent passport information. Also, note that the passport must have more than 6 months validity.'" -->

                          <datepickerField :display="true" :fieldsArray="questionnaireDetails" :validationRequired="true"
                            v-model="petition.beneficiaryInfo.passportIssuedDate" :tplsection="'beneficiaryInfo'"
                            :tplkey="'passportIssuedDate'" :fieldName="'passportIssuedDate'" formscope="casedetailsform"
                            :dateEnableTo="featureDates" label="Passport Issued Date" />

                          <selectField :display="true" :fieldsArray="questionnaireDetails"
                            @input="petition.beneficiaryInfo.curNonImmigrantVisaStatus = petition.beneficiaryInfo.curNonImmigrantVisaStatusDetails.id"
                            :required="true" :optionslist="petition.visaStatusList"
                            v-model="petition.beneficiaryInfo.curNonImmigrantVisaStatusDetails"
                            :tplsection="'beneficiaryInfo'" :tplkey="'curNonImmigrantVisaStatus'"
                            :fieldName="'curNonImmigrantVisaStatus'" formscope="casedetailsform"
                            label="Current Nonimmigrant Status" vvas="Nonimmigrant Status"
                            placeHolder="Nonimmigrant Status" />
                          <datepickerField :display="true" :fieldsArray="questionnaireDetails" :validationRequired="true"
                            v-model="petition.beneficiaryInfo.curVisaExpiryDate" :tplsection="'beneficiaryInfo'"
                            :tplkey="'curVisaExpiryDate'" :fieldName="'curVisaExpiryDate'" formscope="casedetailsform"
                            :dateEnableFrom="new Date()" label="Current Status Expiry Date" />
                          <datepickerField :display="true" :fieldsArray="questionnaireDetails" :validationRequired="true"
                            v-model="petition.beneficiaryInfo.firstEntryDateOrApprovalInUsWithH1B"
                            :tplsection="'beneficiaryInfo'" :tplkey="'firstEntryDateOrApprovalInUsWithH1B'"
                            :fieldName="'firstEntryDateOrApprovalInUsWithH1B'" formscope="casedetailsform"
                            :dateEnableTo="featureDates" label="First Entry Date or Approval in US With H1B" />
                          <datepickerField :display="true" :fieldsArray="questionnaireDetails" :validationRequired="true"
                            v-model="petition.beneficiaryInfo.dateFifthYearOfHExpire" :tplsection="'beneficiaryInfo'"
                            :tplkey="'dateFifthYearOfHExpire'" :fieldName="'dateFifthYearOfHExpire'"
                            formscope="casedetailsform" :dateEnableFrom="null"
                            label="Date Fifth Year of H1B Status Expires" />
                          <immiMask :display="true" :fieldsArray="questionnaireDetails" :patren="['### - ## - ####']"
                            datatype="min:9|max:9"
                            :wrapclass="canRenderField('ben_alienNumber', questionnaireDetails) ? 'md:w-1/2' : ' '"
                            cid="benfSSN" formscope="casedetailsform" v-model="petition.beneficiaryInfo.SSN"
                            :tplsection="'beneficiaryInfo'" :tplkey="'SSN'" :fieldName="'SSN'" :required="false"
                            label="Social Security Number (if applicable)" vvas="Social Security Number"
                            placeHolder="123 - 45 - 6789" />
                          <immiInput :display="true" :fieldsArray="questionnaireDetails" datatype="alpha_num|max:9"
                            cid="benfalienNumber" formscope="casedetailsform"
                            v-model="petition.beneficiaryInfo.alienNumber" :tplsection="'beneficiaryInfo'"
                            :tplkey="'alienNumber'" :fieldName="'alienNumber'" label="Your Alien Number (if applicable)"
                            placeHolder="Alien Number " />

                          <div class="vx-col w-full">
                            <div
                              v-if="canRenderField('currentAddress', questionnaireDetails, true, 'beneficiaryInfo') && countries.length > 0">
                              <h3 class="small-header">Current Address</h3>
                              <addressField :display="true" :fieldsArray="questionnaireDetails" :disableCountry="false"
                                formscope="casedetailsform" :showaptType="true" :addFormContainerCls="false"
                                :countries="countries" v-model="petition.beneficiaryInfo.currentAddress"
                                :tplsection="'beneficiaryInfo'" :fieldName="'currentAddress'"
                                :validationRequired="checkFieldIsRequired({ 'key': 'currentAddress', 'section': 'beneficiaryInfo', 'fieldsArray': questionnaireDetails, 'required': true })"
                                :cid="'currentAddress'" />
                            </div>
                            <div v-if="canRenderField('mailingAddress', questionnaireDetails, true, 'beneficiaryInfo')">
                              <div class="vx-col w-full d-flex">
                                <h3 class="small-header">Mailing Address</h3>
                                <vs-checkbox @change="setSameaddress()"
                                  v-model="petition.beneficiaryInfo.mailingAddressIsSameAsAddress"
                                  :tplsection="'beneficiaryInfo'" :fieldName="'mailingAddressIsSameAsAddress'"
                                  style="margin-left: 15px; margin-bottom:12px;">Same as Current Address </vs-checkbox>
                              </div>
                              <template
                                v-if="petition.beneficiaryInfo.mailingAddressIsSameAsAddress != true && countries.length > 0">
                                <div>
                                  <addressField :display="true" :fieldsArray="questionnaireDetails"
                                    :disableCountry="petition.beneficiaryInfo.currentlyInUS" formscope="casedetailsform"
                                    :showaptType="true" :addFormContainerCls="false"
                                    :validationRequired="checkFieldIsRequired({ 'key': 'mailingAddress', 'section': 'beneficiaryInfo', 'fieldsArray': questionnaireDetails, 'required': true })"
                                    :countries="countries" v-model="petition.beneficiaryInfo.mailingAddress"
                                    :tplsection="'beneficiaryInfo'" :fieldName="'mailingAddress'"
                                    :cid="'beneficiarymailInfoaddress'" />
                                </div>
                              </template>
                            </div>
                          </div>
                          <immiyesorno :display="false" :tplkey="'haveYouEverTravelledToUS'"
                            :fieldsArray="questionnaireDetails"
                            v-model="petition.beneficiaryInfo.haveYouEverTravelledToUS" :tplsection="'beneficiaryInfo'"
                            :fieldName="'haveYouEverTravelledToUS'" label="Have you ever travelled to the United States?">
                          </immiyesorno>
                          <immipriorstay :fieldsArray="questionnaireDetails" formscope="casedetailsform"
                            v-if="canRenderField('priorPeriodOfStayInUS', questionnaireDetails, true, 'beneficiaryInfo') && petition && petition.visaStatusList && petition.visaStatusList.length > 0"
                            :petition="petition" v-model="petition.beneficiaryInfo.priorPeriodOfStayInUS"
                            :tplsection="'beneficiaryInfo'" :fieldName="'priorPeriodOfStayInUS'"></immipriorstay>
                        </template>


                      </div>
                    </div>
                  </div>
                </form>
              </div>
              <div id="case_details_dt" v-if="currentTab == 'education'">
                <form data-vv-scope="educationform" @submit.prevent="">
                  <div class="vs-col w-full p-0 vs-xs- vs-sm- vs-lg-" v-if="checkSLGAndRenderField">
                    <div class="con-vs-alert warning-alert top-warning-alert con-vs-alert-warning con-icon">
                      <div class="vs-alert con-icon">
                        <i class="vs-icon notranslate icon-scale icon-alert IntakePortal IP-information-button null"></i>
                        After your 12th grade – Starting from the most recent degree first
                      </div>
                    </div>
                  </div>
                  <div class="vs-col m-auto float-none vs-xs- vs-sm-12 vs-lg-12">
                    <div class="form-container pt-10 form-container-questionnaire">
                      <div class="vx-row  pt-10">
                        <div class="vx-col w-full ">

                          <!-- <immiswitchyesno :tplkey="'reqConsdnOfAdvDegreeExptn'" :display="true" wrapclass="degreeExtn" :fieldsArray="questionnaireDetails" :cid="'reqConsdnOfAdvDegreeExptn'" formscope="educationform" v-model="petition.beneficiaryInfo.reqConsdnOfAdvDegreeExptn" :tplsection="'beneficiaryInfo'"  :fieldName="'reqConsdnOfAdvDegreeExptn'"   label="Are you requesting consideration of advanced degree exemption?" placeHolder="" /> -->
                          <div class="vx-col w-full">
                            <div class="d-flex align-center">
                              <!-- <a class="switch-label mr-3 d-flex align-center">
                                                Do you have master's degree from United States University?
                                                <div class="IB_tooltip">
                                                  <span><info-icon size="1.5x" class="custom-class"></info-icon></span>
                                                  <div class="tooltip_cnt">
                                                    <p>
                                                      Are you requesting consideration under the INA 214(g)(5)(C) advanced
                                                      degree exemption because the beneficiary has earned, or will earn prior
                                                      to the filling of the petition, a master's or higher degree from a U.S.
                                                      institution of higher education?
                                                    </p>
                                                  </div>
                                                </div>
                                              </a>
                                              <vs-switch v-model="petition.beneficiaryInfo.reqConsdnOfAdvDegreeExptn">
                                                <span slot="on">Yes</span>
                                                <span slot="off">No</span>
                                              </vs-switch> -->

                              <immiyesorno :display="true" :tplkey="'h4Required'" :fieldsArray="questionnaireDetails"
                                :callFromCap="true" v-model="petition.beneficiaryInfo.reqConsdnOfAdvDegreeExptn"
                                :helpText="'Are you requesting consideration under the INA 214(g)(5)(C) advanced degree exemption because the beneficiary has earned, or will earn prior to the filling of the petition, a master(s) or higher degree from a U.S. institution of higher education?'"
                                :tplsection="'dependentsInfo.spouse'" :fieldName="'h4Required'"
                                @input="checkMasterDegreeYesorNo"
                                label="Do you have master's degree from United States University?"></immiyesorno>


                            </div>

                          </div>
                          <!-- <a class="switch-label mr-3">Are you requesting consideration under the INA 214(g)(5)(C) advanced degree exemption because the beneficiary has earned, or will earn prior to the filling of the petition, a master's or higher degree from a U.S. institution of higher education?
                                            </a>
                                              <vs-switch :disabled="false" v-model="switchvalue" >
                                                <span slot="on">Yes</span>
                                                <span slot="off">No</span>
                                            </vs-switch> -->
                        </div>
                      </div>
                    </div>
                  </div>
                  <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12"
                    vs-sm="12">
                    <div class="form-container pt-10 form-container-questionnaire cap-questionnaire">
                      <h3 v-if="checkSLGAndRenderField" class="small-header">Educational Information</h3>
                      <!-- <div class="vx-row">
                        <div v-if="!checkSLGAndRenderField && petition.beneficiaryInfo.reqConsdnOfAdvDegreeExptn && false"
                          class="vx-col w-full md:w-1/2 cap_questinnaire_docs">
                          <immiInput :display="true" :fieldsArray="questionnaireDetails" cid="mUniversityName"
                            formscope="educationform" v-model="petition.beneficiaryInfo.mastersUniversityName" :tplsection="''"
                            wrapclass="'w-full'"
                            :tplkey="'mastersUniversityName'" :fieldName="'mastersUniversityName'" :required="checkMastersUniversityNameRequired"
                            label="University Name" placeHolder="University Name" @input="checkEduTranscriptsDocumentsRequired"/>
                        </div>
                      </div>
                      <div class="vx-row">
                        <div v-if="!checkSLGAndRenderField && petition.beneficiaryInfo.reqConsdnOfAdvDegreeExptn && false"
                          class="vx-col w-full md:w-1/2 cap_questinnaire_docs">
                          <casedocumentslist v-if="petitionLoaded" :showTitle="false" :docslist="eduDocsList"
                            :formscope="'educationform'" :fieldsArray="[]" v-model="petition.documents" :tplsection="''"
                            :fieldName="''">
                          </casedocumentslist>
                        </div>
                      </div> -->

                     
                      


                      <!-- <selectField v-if="!checkSLGAndRenderField" :display="false" :fieldsArray="questionnaireDetails"
                        :tplsection="'beneficiaryInfo'" :tplkey="'highestDegree'" @input="getHighestDegree($event)"
                        :required="true" :optionslist="temporaryDegreeList"
                        v-model="petition.beneficiaryInfo.highestDegreeDetails" :formscope="'educationform'"
                        :fieldName="'highestDegree'" label="Highest Degree" placeHolder="Highest Degree" /> -->

                      <!-- <div
                        v-if="(checkSLGAndRenderField || (!checkSLGAndRenderField && checkProperty(petition, 'beneficiaryInfo', 'highestDegree')))"
                        class="vx-row">
                        <educationsList :callformCap="true"
                          :reqConsdnOfAdvDegreeExptn="petition.beneficiaryInfo.reqConsdnOfAdvDegreeExptn" :display="true"
                          :petition="petition" :countries="countries" :fieldsArray="questionnaireDetails"
                          cid="ben_educations" sdsd="SR" formscope="educationform"
                          v-model="petition.beneficiaryInfo.educations" :tplsection="'beneficiaryInfo.educations'"
                          :fieldName="'educations'" />
                      </div> -->


                      <div v-if="(checkSLGAndRenderField)" class="vx-row">
                        <educationsList :callformCap="true"
                          :reqConsdnOfAdvDegreeExptn="petition.beneficiaryInfo.reqConsdnOfAdvDegreeExptn" :display="true"
                          :petition="petition" :countries="countries" :fieldsArray="questionnaireDetails"
                          cid="ben_educations" sdsd="SR" formscope="educationform"
                          v-model="petition.beneficiaryInfo.educations" :tplsection="'beneficiaryInfo.educations'"
                          :fieldName="'educations'" />
                      </div>
                    </div>
                  </vs-col>


                  <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12"
                    vs-sm="12" v-if="false">
                    <div class="form-container pt-10 form-container-questionnaire">
                      <div class="divider full-divider mb-10"></div>
                      <h3 class="small-header">Vocational or Training</h3>
                      <div class="vx-row">
                        <educationsList :popupTitle="'Vocational or Training'" :callformCap="true" :display="true"
                          :petition="petition" :countries="countries" :fieldsArray="questionnaireDetails"
                          cid="ben_vacationalOrTrainingInst" sdsd="SR" formscope="educationform"
                          v-model="petition.beneficiaryInfo.vacationalOrTrainingInst"
                          :tplsection="'beneficiaryInfo.vacationalOrTrainingInst'"
                          :fieldName="'vacationalOrTrainingInst'" />
                      </div>
                    </div>
                  </vs-col>
                </form>
              </div>
            </div>
          </div>
          <div class="questionnaire_footer">
            <div class="d-flex">
              <vs-button v-if="checkActiveTab == 1" @click="goBack()" class="questionnaire_btn"
                type="filled">Back</vs-button>
            </div>
            <div class="d-flex">
              <vs-button @click="saveCase(true, true, false);" class="questionnaire_btn" type="filled">Save</vs-button>
              <vs-button color="success" @click="submitCase();" class="save questionnaire_btn" type="filled">{{
                actiontype
              }}</vs-button>

            </div>
          </div>
        </div>
      </div>
      <div class="custom_modal_sec preview_questionarie" :class="{ modalopen: questionnairePreview }">
        <div class="custom_modal_overlay"></div>

        <div class="custom_modal_cnt">
          <div class="modal_title">
            <h2>Questionnaire Review</h2>
            <span @click="questionnairePreview = false">
              <x-icon size="1.5x" class="close"></x-icon>
            </span>
          </div>
          <div class="modal_cnt preview_content new_questionnaire_review">
            <VuePerfectScrollbar ref="mainSidebarPs1" :settings="settings">
              <CapDetails v-if="questionnairePreview" :loadedFromPreview="true" :previewData="questionnairePreviewData" />
            </VuePerfectScrollbar>
          </div>
          <div class="questionnaire_footer">
            <div class="d-flex">
              <vs-button @click="questionnairePreview = false" class="cancel questionnaire_btn" type="filled">Cancel
              </vs-button>
              <vs-button @click="saveCase(false, false, false);" :disabled="questionnaireLoader"
                class="save questionnaire_btn" type="filled">
                <figure v-if="questionnaireLoader" class="loader loader-btn"><img src="@/assets/images/main/loader.gif" />
                </figure>
                Submit
              </vs-button>
            </div>
          </div>
        </div>
      </div>

      <vs-popup class="holamundo success-popups" title="Your registration is complete."
        :active.sync="SuccessQuestionnaire">
        <figure>
          <img src="@/assets/images/main/icon-note.svg" alt="login" class="mx-auto" />
        </figure>
        <h2 class="title">Questionnaire submitted successfully!</h2>
        <template v-if="checkProperty($route, 'name') != 'fill-cap-registration'">
          <p v-if="getUserData && checkProperty(getUserData['tenantDetails']['typeDetails'], 'id') == 1">
            It will be reviewed by the petitioner and appropriate actions will be
            taken soon.
          </p>
          <p v-if="getUserData && checkProperty(getUserData['tenantDetails']['typeDetails'], 'id') == 2">
            It will be reviewed by the Admin and appropriate actions will be
            taken soon.
          </p>
        </template>
      </vs-popup>

      <vs-popup class="holamundo main-popup" title="Case Details" :active.sync="showPrefillPopup">
        <div class="form-container">
          <div class="vx-row">
            <div class="vx-col w-full">
              <p style="line-height: 20px">
                Do you want to pre-fill the basic information from the previous
                case details?
              </p>
            </div>
          </div>
        </div>
        <div class="popup-footer">
          <vs-button color="dark" class="cancel" type="filled"
            @click="showPrefillPopup = false; setBasicData()">Cancel</vs-button>
          <vs-button color="success" class="save" type="filled" @click="
            prefilltheDetails();
          showPrefillPopup = false;">Yes</vs-button>
        </div>
      </vs-popup>
    </div>
  </span>
</template>

<script>
//import petitionform from "./forms/petition.vue";
//import petitionform from "./forms/case.vue";
//import gcform from "./forms/gcform.vue";
import { XIcon } from "vue-feather-icons";
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import JQuery from 'jquery';
import CapDetails from "@/views/cap/CapDetails.vue";
import moment from "moment";
import immiswitchyesno from "@/views/forms/fields/switchyesno.vue";
import educationsList from "@/views/forms/fields/educationsList.vue";
import immieducations from "@/views/forms/fields/educations.vue";
import immipriorstay from "@/views/forms/fields/priorstay.vue";
import immiyesorno from "@/views/forms/fields/yesorno.vue";
import addressField from "@/views/forms/fields/address.vue";
import immiMask from "@/views/forms/fields/maskinput.vue";
import selectField from "@/views/forms/fields/simpleselect.vue";
import datepickerField from "@/views/forms/fields/datepicker.vue";
import immiPhone from "@/views/forms/fields/phonenumber.vue";
import immiInput from "@/views/forms/fields/simpleinput.vue";
import genderField from '@/views/forms/fields/gender.vue'
import DatePicker from 'vue2-datepicker';
import 'vue2-datepicker/index.css';
import PhoneMaskInput from "vue-phone-mask-input";
import { TheMask } from 'vue-the-mask';
import casedocumentslist from "@/views/common/casedocuments.vue";

export default {
  provide() {
    return {
      parentValidator: this.$validator,
    };
  },
  components: {
    casedocumentslist,
    VuePerfectScrollbar,
    XIcon,
    CapDetails,
    immiswitchyesno,
    educationsList,
    immieducations,
    immipriorstay,
    immiyesorno,
    addressField,
    immiMask,
    selectField,
    datepickerField,
    immiPhone,
    immiInput,
    DatePicker,
    PhoneMaskInput,
    TheMask,
    genderField,
  },
  data: function () {
    return {
      questionnaireLoader: false,
      petitionLoaded: false,
      settings: {},
      SuccessQuestionnaire: false,
      showPrefillPopup: false,
      petition: null,
      featureDates: null,
      startEligibleDate: new Date().setFullYear(new Date().getFullYear() - 18),
      bfeprovinceStates: [],
      countries: [],
      countriesWithoutUS:[],
      questionnaireDetails: null,
      petitionId: "",
      userName: "",
      typeName: "",
      subTypeName: "",
      temp_save: false,
      action: "", // BENEFICIARY_INFO_UPDATE /
      questionnaireFilled: true,// Set true when submit questionnaire
      questionnaireUpdate: true, // Set true when you are updating questionnaire
      visastatuses: [],
      petition: {
        visaStatusList: [],
        beneficiaryInfo: {
          firstName: "",
          middleName: "",
          lastName: "",
          email: "",
          gender: '',
          reqConsdnOfAdvDegreeExptn: false,
          passportExpiryDate: "",
          "homePhoneNumber": null,
          "homePhoneCountryCode": {
            "countryCode": "",
            "countryCallingCode": ""
          },
          "cellPhoneNumber": null,
          "cellPhoneCountryCode": {
            "countryCode": "",
            "countryCallingCode": ""
          },


          "dateOfBirth": null,
          "countryOfBirth": null,
          "countryOfBirthDetails": null,
          "provinceOfBirth": null,
          "provinceOfBirthDetails": null,
          "locationOfBirth": "",
          "countryOfCitizenship": null,
          countryOfCitizenshipDetails: null,
          haveYouEverTravelledToUS: "Yes",

          highestDegreeDetails: null,
          passportNumber: null,
          mastersUniversityName: "",

          educations: [
              /*{
                
              name: "",
              address: {
              line1 : null,
              line2 : null,
              aptType:null,
              locationId :null ,
              stateId : null,
              countryId : null,
              zipcode : null,
              locationDetails : {
                id : null,
                name : null,
                stateId : null,
                countryId : null
              },
              stateDetails : {
                id: null,
                name : "",
                shortName : "",
                countryId : null
              },
              countryDetails : {
                id : '',
                shortName : "",
                name : "",
                phoneCode : '',
                order : '',
                currencySymbol : "",
                currencyCode : "",
                zipcodeLength : ''
              }
            },
              highestDegree: null,
              majorFieldOfStudy: "",
              attendedFrom: "",
              attendedTo: "",
              graduatedYear: null,
              isAccredited: true,
              isForProfit: false
            }
          */],



        },
        documents: {
          "passport": [],
          "eduTranscripts": [],
        },
      },
      questionnairePreview: false,
      questionnairePreviewData: null,
      education_types: [],
      showPrefillPopup: false,
      latestPetition: null,
      questionnaireTplType: 'general',
      time1: null,
      time2: null,
      time3: null,
      time4: null,
      time5: null,
      currentTab: 'casedetails',
      tabslist: [{
        key: "casedetails",
        name: "Personal Info"
      },
      {
                key: "education",
                name: "Educational Info"
              },],
      tabName: 'PersonalInfo',
      value: null,
      values: null,
      val: null,
      highest: null,
      states: null,
      year: null,
      citys: null,
      countres: null,
      switchvalue: true,
      switche: true,
      switchvalues: true,
      showsideModal: false,
      country: ['India', 'canda'],
      countre: ['India', 'canda'],
      provice: ['Andra pradesh', 'Bihar'],
      citizenship: ['India', 'canda'],
      degree: ['10th / 12th Grade', 'Bachelors', 'Associate', 'Masters'],
      graduation: ['2022', '2021', '2020', '2019'],
      city: ['Hyderabad', 'Khammamm', 'Warangal'],
      state: ['Cokato', 'California', 'Colorado'],
      educationForm: false,
      docsList: [
        {
          display: true,
          required: true,
          key: "passport",
          fieldName: 'passport',
          label: "Passport Copy"
        },
      ],
      eduDocsList: [
        {
          display: true,
          required: false,
          key: "eduTranscripts",
          fieldName: 'eduTranscripts',
          label: "Upload a copy of U.S. Master's Degree Certificate and Transcripts. (Optional)"
        },
      ],
      temporaryDegreeList: [],

    }
  },
  methods: {
    init() {
      let _self = this;
      this.loadStatesByCountry('bfeprovinceStates', 231);
      this.$store.dispatch("getcountries").then((response) => {
        this.countries = response;
        if(this.checkProperty(this.countries, 'length')>0){
          this.countriesWithoutUS = _.filter(this.countries,(item)=> {
              return item.id != 231;
          });
        }
      });
      this.$store.dispatch("getmasterdata", "visa_status").then((response) => {
        this.visastatuses = response;
        this.petition.visaStatusList = response;
      });
      this.$store.dispatch("getmasterdata", "education_types").then((response) => {
        this.education_types = response;
      });

      this.petitionLoaded = false;
      this.$store.dispatch("commonAction", { data: { "petitionId": this.$route.params.itemId }, path: "/cap-registrations/details" })
        .then((response) => {
          if (response) {
            if (_.has(response, 'documents')) {
              response = Object.assign(response, { "documents": response['documents'] });
              response = _.cloneDeep(response);
            } else {
              let documents = {
                passport: []
              }
              response = Object.assign(response, { "documents": documents });
              response = _.cloneDeep(response);
            }
            var data = _.merge(this.petition, response);

            this.petition = _.cloneDeep(data);
            if(this.checkProperty(this.petition,'questionnaireTplType') == 'general'){
         
              this.tabslist= [{
                key: "casedetails",
                name: "Personal Info"
              },
              ]
            }
            this.petitionLoaded = true;
            // this.lastNameToUpperCase(this.petition.beneficiaryInfo.lastName)
            this.temporaryDegreeList = this.petition.highestDegreeList
            let currentRoute = this.$route;
            if (this.checkProperty(this.petition, 'questionnaireFilled') && _.has(currentRoute, "query.token") && this.checkProperty(this.$route, 'name') == 'fill-cap-registration' && _.has(currentRoute, "meta.getTokenFromUrl")) {
              let token = _.get(currentRoute, "query.token", "");
              let url = "/filled-cap-registration-details/" + this.$route.params.itemId + "?token=" + token;
              this.$router.push(url)
              //this.$router.push({ name: 'filled-cap-registration-details', params: { itemId: this.petition._id } })
            }
            let postData = {
              userId: this.petition.userId,
              getDocuments: true,
            };
            let pth = "petition-common/get-recent-by-beneficiary";
            this.$store.dispatch("commonAction", { data: postData, path: pth, }).then((response) => {
              if (response && response.caseDetails && response.caseDetails.beneficiaryInfo) {
                if (!this.petition.questionnaireFilled) {
                  this.showPrefillPopup = true;
                }
                this.latestPetition = response["caseDetails"];
              } else if (response && response.userDetails && response.userDetails && (!this.petition.questionnaireFilled && (this.petition.beneficiaryInfo.email == null || this.petition.beneficiaryInfo.email == ''))) {

                if (this.checkProperty(response, 'userDetails', 'email') && !this.checkProperty(this.petition, 'beneficiaryInfo', 'email')) {

                  this.petition['beneficiaryInfo']['email'] = this.checkProperty(response, 'userDetails', 'email')
                }
                if (this.checkProperty(response, 'userDetails', 'firstName') && !this.checkProperty(this.petition, 'beneficiaryInfo', 'firstName')) {
                  this.petition['beneficiaryInfo']['firstName'] = this.checkProperty(response, 'userDetails', 'firstName');
                }
                if (this.checkProperty(response, 'userDetails', 'middleName') && !this.checkProperty(this.petition, 'beneficiaryInfo', 'middleName')) {
                  this.petition['beneficiaryInfo']['firstName'] = this.checkProperty(response, 'userDetails', 'middleName');
                }
                if (this.checkProperty(response, 'userDetails', 'lastName') && !this.checkProperty(this.petition, 'beneficiaryInfo', 'lastName')) {
                  this.petition['beneficiaryInfo']['lastName'] = this.checkProperty(response, 'userDetails', 'lastName');
                }
              }
              // if (!this.checkSLGAndRenderField && this.checkProperty(this.petition, 'beneficiaryInfo', 'educations') && this.checkProperty(this.petition['beneficiaryInfo'], 'educations', 'length') > 0) {
              //   let highestDegree = -1
              //   _.map(this.petition.beneficiaryInfo.educations, (item, index) => {
              //     if (this.checkProperty(item, 'highestDegree')) {
              //       if (item.highestDegree > highestDegree) {
              //         highestDegree = item.highestDegree
              //       }
              //     }
              //   })
              //   if (highestDegree > -1) {
              //     this.petition.beneficiaryInfo['highestDegree'] = highestDegree
              //     this.petition.beneficiaryInfo.highestDegreeDetails = _.find(this.petition.highestDegreeList, { "id": highestDegree })
              //   }
              //   this.checkMasterDegreeYesorNo()
              // }

              if (!this.checkSLGAndRenderField) {
                this.petition['beneficiaryInfo']['educations'] = [];
              }
              this.docsList[0]['required'] = this.checkSLGAndRenderField
              this.setTheInitData()
              this.$vs.loading.close();
            }).catch((err) => {
              this.$vs.loading.close();
            });
          } else {
            this.$vs.loading.close();
          }
        }).catch((err) => {
          this.$vs.loading.close();
        });

        
      this.featureDates = new Date();
    },
    validateandScroll() {
      var $self = this;
      const $ = JQuery;
      var el = _.find(this.errors["items"], function (item) {
        return item.scope == $self.currentTab + "form"
      })
      if (el) {
        const ele = $("[name=" + el.field + "]").parents(".vx-col");
        var _top = 0;
        if (ele) {
          _top = ele.position().top;
        }
      }
      document.getElementById("scrollableques").scrollTo({
        top: _top,
        left: 0,
        behavior: 'smooth'
      })

    },
    submitCase() {
      this.$validator.validateAll(this.currentTab + "form").then((result) => {
        if (result) {
          if (this.checkActiveTab < this.tabslist.length - 1) {
            this.setActiveTab(this.tabslist[this.checkActiveTab + 1].key);
            setTimeout(function () {
              document.getElementById("scrollableques").scrollTo({
                top: 0,
                left: 0,
                behavior: 'smooth'
              })
            }, 500)
          }
          else {
            if (this.petition.questionnaireFilled) {
              //  this.$vs.loading();
              //  
              this.saveCase(true, false, true);
            } else {

              this.setSameaddress(false);
              let temp_save = false;
              this.questionnairePreviewData = {
                petitionId: this.$route.params.itemId,
                userName: this.$store.state.user.name,
                typeName: "Cap Registration",
                subTypeName: "Regular",
                typeDetails: this.petition.typeDetails,
                subTypeDetails: this.petition.subTypeDetails,
                highestDegreeList: this.petition.highestDegreeList,
                action: temp_save ? "BENEFICIARY_INFO_UPDATE" : "SUBMIT_BY_BENEFICIARY",
                // "updateSection": "SUBMIT_BY_BENEFICIARY",
                // "action": "SUBMIT_BY_BENEFICIARY",
                currentDate: moment().format("YYYY-MM-DD"),
                beneficiaryInfo: this.petition.beneficiaryInfo,
                documents: this.petition.documents,
                temp_save: false,
                questionnaireFilled: true,
                today: moment().format("YYYY-MM-DD"),
                questionnaireTplType: this.petition.questionnaireTplType,
              };
              this.questionnairePreviewData.noOfDaysStayInUS = this.gettotalDays;
              let mastedDegree = null;
              let bachelorDegree = null;
              let isMasterDegreeError = false

              if (!temp_save && this.checkProperty(this.questionnairePreviewData, 'beneficiaryInfo', 'educations')
                && this.checkProperty(this.questionnairePreviewData['beneficiaryInfo'], 'educations', 'length') > 0
                && this.checkSLGAndRenderField) {
                //highestDegree
                mastedDegree = _.find(this.questionnairePreviewData['beneficiaryInfo']['educations'], { 'highestDegree': 6 });
                bachelorDegree = _.find(this.questionnairePreviewData['beneficiaryInfo']['educations'], { 'highestDegree': 4 });
                if (this.checkSLGAndRenderField && mastedDegree && !bachelorDegree) {
                  isMasterDegreeError = true
                  this.showToster({ message: "Seems you have not submitted bachelor's information. Please fill to continue", isError: true, });
                  return;
                } else if (!mastedDegree && this.petition.beneficiaryInfo.reqConsdnOfAdvDegreeExptn == true) {
                  isMasterDegreeError = true
                  this.showToster({ message: "Seems you have not submitted master's information. Please fill to continue", isError: true, });
                  return;
                }

                else if (!this.checkEducationDocuments(this.questionnairePreviewData)) {
                  isMasterDegreeError = true
                  this.showToster({ message: "Seems you have not uploaded education documents . Please upload to continue", isError: true, });
                  return;
                }

              } else if (this.checkSLGAndRenderField && this.petition.beneficiaryInfo.reqConsdnOfAdvDegreeExptn == true) {
                isMasterDegreeError = true
                this.showToster({ message: "Seems you have not submitted master's information. Please fill to continue", isError: true, });
                return;

              }
              if (isMasterDegreeError == false) {
                this.questionnairePreview = true;
              }
            }

          }
        }
        else {
          this.validateandScroll();
        }
      })
    },
    saveCase(temp_save, show_message = true, checkMasters) {
      this.setSameaddress(false);

      //this.petition.noOfDaysStayInUS = this.gettotalDays;
      var postpetition = {
        petitionId: this.$route.params.itemId,
        userName: this.$store.state.user.name,
        action: temp_save ? "BENEFICIARY_INFO_UPDATE" : "SUBMIT_BY_BENEFICIARY",
        // "updateSection": "SUBMIT_BY_BENEFICIARY",
        // "action": "SUBMIT_BY_BENEFICIARY",
        currentDate: moment().format("YYYY-MM-DD"),
        beneficiaryInfo: this.petition.beneficiaryInfo,
        documents: this.petition.documents,
        //mastersUniversityName:this.petition.mastersUniversityName,
        temp_save: temp_save,
        questionnaireFilled: temp_save ? false : true,
        today: moment().format("YYYY-MM-DD"),
      };
      let mastedDegree = null;
      let bachelorDegree = null;
      let isMasterDegreeError = false
      if (this.checkProperty(this.petition, 'questionnaireFilled')) {
        postpetition['questionnaireUpdate'] = true
      }

      if (checkMasters && this.checkProperty(postpetition, 'beneficiaryInfo', 'educations')
        && this.checkProperty(postpetition['beneficiaryInfo'], 'educations', 'length') > 0
        && this.checkSLGAndRenderField) {
        mastedDegree = _.find(postpetition['beneficiaryInfo']['educations'], { 'highestDegree': 6 });
        bachelorDegree = _.find(postpetition['beneficiaryInfo']['educations'], { 'highestDegree': 4 });
        if (this.checkSLGAndRenderField && mastedDegree && !bachelorDegree) {
          isMasterDegreeError = true
          this.showToster({ message: "Seems you have not submitted bachelor's information. Please fill to continue", isError: true, });
          return;
        } else if (!mastedDegree && this.petition.beneficiaryInfo.reqConsdnOfAdvDegreeExptn == true) {
          isMasterDegreeError = true
          this.showToster({ message: "Seems you have not submitted master's information. Please fill to continue", isError: true, });
          return;
        }
        else if (!this.checkEducationDocuments(postpetition)) {
          isMasterDegreeError = true
          this.showToster({ message: "Seems you have not uploaded education documents . Please upload to continue", isError: true, });
          return;
        }

      } else if (checkMasters && this.checkSLGAndRenderField && this.petition.beneficiaryInfo.reqConsdnOfAdvDegreeExptn == true) {

        isMasterDegreeError = true
        this.showToster({ message: "Seems you have not submitted master's information. Please fill to continue", isError: true, });
        return;

      }
      if (isMasterDegreeError == false) {


        this.$vs.loading();

        let path = "/cap-registrations/update";
        if (!this.checkCurrentUrl) {
          postpetition['submittedWithLink'] = true;
        }
        this.questionnaireLoader = true;
        this.$store.dispatch('commonAction', { data: postpetition, path: path })
          .then((response) => {
            this.questionnaireLoader = false;
            if (this.checkProperty(response, "error")) {
              if (show_message) {
                this.showToster({
                  message: response.error.message,
                  isError: true,
                });
              } else {
                this.$vs.loading.close();
              }
            }
            else {
              let currentRoute = this.$route;
              if (!show_message && !this.checkCurrentUrl && _.has(currentRoute, "meta.getTokenFromUrl") && _.get(currentRoute, "name", "") == "fill-cap-registration" &&
                _.has(currentRoute, "query.token")
              ) {
                let token = _.get(currentRoute, "query.token", "");
                let url = "/filled-cap-registration-details/" + this.$route.params.itemId + "?token=" + token;
                this.showToster({ message: "Questionnaire saved successfully", isError: false, });
                this.$router.push(url)
              }
              else {
                //success
                this.spouseModalForm = false;
                this.childModalForm = false;
                if (show_message) {
                  if (!temp_save) {
                    this.SuccessQuestionnaire = true;
                  } else {
                    this.showToster({ message: "Questionnaire saved successfully", isError: false, });
                  }
                }
                else {
                  if (this.petition.questionnaireFilled) {
                    this.showToster({ message: "Questionnaire updated successfully", isError: false, });
                    this.$router.push("/cap-registration-details/" + this.$route.params.itemId) //petitionId
                  }
                  else {
                    if (!temp_save) {
                      this.questionnairePreview = false;
                      this.$vs.loading.close();
                      this.SuccessQuestionnaire = true;
                      document.addEventListener("click", this.reloadthePage);
                    } else {
                      this.$vs.loading.close();
                      this.questionnairePreview = false;
                      this.showToster({ message: "Questionnaire updated successfully", isError: false, });
                      this.$router.push("/cap-registration-details/" + this.$route.params.itemId) //petitionId                                                                         
                    }
                  }
                }
              }
            }
            this.$vs.loading.close();
          }).catch((err) => {
            this.$vs.loading.close();
            this.questionnaireLoader = false;
            this.showToster({ message: err, isError: true, });
          })
      }
    },
    reloadthePage() {
      let routeTest = this.$route.params.itemId;
      var _self = this;
      if (this.SuccessQuestionnaire) {
        this.SuccessQuestionnaire = false;
      }
      setTimeout(() => {
        let currentRoute = _self.$route;
        if (
          _.get(currentRoute, "name", "") == "Cap questionnaire" &&
          _.has(currentRoute, "meta.getTokenFromUrl") &&
          _.has(currentRoute, "query.token")
        ) {
          let token = _.get(currentRoute, "query.token", "");
          let url = "/cap-registration-details/" + routeTest + "?token=" + token;
          _self.$router.push(url);
        }
        else {
          _self.$router.push("/cap-registration-details/" + routeTest);
        }
      }, 10);
    },
    prefilltheDetails() {
      var data = _.merge(this.petition, this.latestPetition);
      if (_.has(data, 'beneficiaryInfo') && _.has(data['beneficiaryInfo'], 'educations') && this.checkProperty(data, 'beneficiaryInfo', 'educations') && this.checkProperty(data['beneficiaryInfo'], 'educations', 'length') > 0) {
        let filterBenEducations = _.filter(data['beneficiaryInfo']['educations'], (item) => {
          if (this.checkProperty(item, 'name') && this.checkProperty(item, 'name') != null) {
            return item
          }
        })
        if (this.checkSLGAndRenderField && filterBenEducations && this.checkProperty(filterBenEducations, 'length') > 0) {
          data['beneficiaryInfo']['educations'] = filterBenEducations;
        } else {
          data['beneficiaryInfo']['educations'] = [];
        }

      }
      this.petition = data;

      if (!this.checkSLGAndRenderField) {
        if (this.checkProperty(this.petition, 'beneficiaryInfo', 'provinceOfBirth'))
          this.petition.beneficiaryInfo.provinceOfBirth = null
        if (this.checkProperty(this.petition, 'beneficiaryInfo', 'provinceOfBirthDetails'))
          this.petition.beneficiaryInfo.provinceOfBirthDetails = null


        if (this.checkProperty(this.petition, 'beneficiaryInfo', 'educations') && this.checkProperty(data['beneficiaryInfo'], 'educations', 'length') > 0) {

          let highestDegree = -1

          _.map(this.petition.beneficiaryInfo.educations, (item, index) => {
            //alert(JSON.stringify(item))
            if (this.checkProperty(item, 'highestDegree')) {
              if (item.highestDegree > highestDegree) {
                highestDegree = item.highestDegree
              }
            }
            if (this.checkProperty(item, 'address')) {
              item.address = null
            }
            if (this.checkProperty(item, 'attendedFrom')) {
              item.attendedFrom = null
            } if (this.checkProperty(item, 'attendedTo')) {
              item.attendedTo = null
            } if (this.checkProperty(item, 'isAccredited')) {
              item.isAccredited = false
            } if (this.checkProperty(item, 'isForProfit')) {
              item.isForProfit = false
            }
            // this.petition.beneficiaryInfo.educations[index] = item
          })
          if (highestDegree > -1) {
            this.petition.beneficiaryInfo.highestDegree = highestDegree
            this.petition.beneficiaryInfo.highestDegreeDetails = _.find(this.petition.highestDegreeList, { "id": highestDegree })
          }
        }
        this.checkMasterDegreeYesorNo()
        this.docsList[0]['required'] = this.checkSLGAndRenderField
      } else {
        if (this.checkProperty(this.petition, 'beneficiaryInfo', 'educations') && this.checkProperty(data['beneficiaryInfo'], 'educations', 'length') > 0) {
          _.map(this.petition.beneficiaryInfo.educations, (item, index) => {
            if (this.checkProperty(item, 'attendedFrom')) {
              item.attendedFrom = null
            } if (this.checkProperty(item, 'attendedTo')) {
              item.attendedTo = null
            }
          })
        }
      }

      this.setTheInitData()
    },
    setBasicData() {
      if (this.checkProperty(this.latestPetition, 'beneficiaryInfo', 'email')) {
        this.petition['beneficiaryInfo']['email'] = this.checkProperty(this.latestPetition, 'beneficiaryInfo', 'email')
      }
      if (this.checkProperty(this.latestPetition, 'beneficiaryInfo', 'firstName')) {
        this.petition['beneficiaryInfo']['firstName'] = this.checkProperty(this.latestPetition, 'beneficiaryInfo', 'firstName');
      }
      if (this.checkProperty(this.latestPetition, 'beneficiaryInfo', 'middleName')) {
        this.petition['beneficiaryInfo']['middleName'] = this.checkProperty(this.latestPetition, 'beneficiaryInfo', 'middleName');
      }
      if (this.checkProperty(this.latestPetition, 'beneficiaryInfo', 'lastName')) {
        this.petition['beneficiaryInfo']['lastName'] = this.checkProperty(this.latestPetition, 'beneficiaryInfo', 'lastName');
      }

      this.petition['beneficiaryInfo']['homePhoneCountryCode'] = {
        "countryCode": "US",
        "countryCallingCode": "1"
      }
      this.petition['beneficiaryInfo']['cellPhoneCountryCode'] = {
        "countryCode": "US",
        "countryCallingCode": "1"
      }
      this.docsList[0]['required'] = this.checkSLGAndRenderField
      // this.lastNameToUpperCase(this.petition.beneficiaryInfo.lastName)
    },
    setTheInitData() {
      if (this.petition.beneficiaryInfo.countryOfBirthDetails && this.petition.beneficiaryInfo.countryOfBirth != null) {
        this.loadStatesByCountry('bfeprovinceStates', this.petition.beneficiaryInfo.countryOfBirth)
      }
      let provinceOfBirth = this.checkProperty(this.petition, 'beneficiaryInfo', 'provinceOfBirth');
      if (provinceOfBirth != null) {
        let provinceOfBirthDetails = _.find(this.bfeprovinceStates, function (item) { return item.id == provinceOfBirth })
        if (provinceOfBirthDetails) {
          this.petition.beneficiaryInfo.provinceOfBirthDetails = provinceOfBirthDetails;
        }
      }
      let curNonImmigrantVisaStatus = this.checkProperty(this.petition, 'beneficiaryInfo', 'curNonImmigrantVisaStatus');
      if (curNonImmigrantVisaStatus != null) {
        this.petition.beneficiaryInfo.curNonImmigrantVisaStatusDetails = _.find(this.petition.visaStatusList, function (item) {

          return item.id == curNonImmigrantVisaStatus
        })
      }
      if (this.petition.beneficiaryInfo.priorPeriodOfStayInUS.length == 1 && this.petition.beneficiaryInfo.priorPeriodOfStayInUS[0].departedDate == null && this.petition.beneficiaryInfo.priorPeriodOfStayInUS[0].enteredDate == null) {
        this.petition.beneficiaryInfo.priorPeriodOfStayInUS = [{
          _id: 0,
          visaStatus: null,
          visaStatusDetails: null,
          noOfDays: null,
          enteredDate: null,
          departedDate: null,
          dateerror: false
        }]
      }
      if (this.petition.beneficiaryInfo && this.petition.beneficiaryInfo.educations == null) {
        this.petition.beneficiaryInfo.educations = []
      }
      this.featureDates = new Date();
      var $self = this;
      this.petition.beneficiaryInfo.priorPeriodOfStayInUS.forEach((item, index) => {
        $self.petition.beneficiaryInfo.priorPeriodOfStayInUS[index].visaStatusDetails = _.find($self.petition.visaStatusList, function (aitem) {
          return aitem.id == item.visaStatus
        })
      })

      this.docsList[0]['required'] = this.checkSLGAndRenderField

      // this.lastNameToUpperCase(this.petition.beneficiaryInfo.lastName)
      this.$vs.loading.close();
    },
    changeBfProvince(value) {
      this.petition.beneficiaryInfo.countryOfBirth = this.petition.beneficiaryInfo.countryOfBirthDetails.id;
      this.bfeprovinceStates = [];
      this.loadStatesByCountry('bfeprovinceStates', value.id)
    },
    loadStatesByCountry(model, countryId) {
      this.$store.dispatch("getstates", countryId).then((response) => {
        switch (model) {
          case "bfeprovinceStates":
            this.bfeprovinceStates = response;
            break;
        }
      });
    },
    setSameaddress(callFromCheckBox = true) {
      if (this.petition.beneficiaryInfo.mailingAddressIsSameAsAddress) {
        this.petition.beneficiaryInfo['mailingAddress'] = _.cloneDeep(this.petition.beneficiaryInfo['currentAddress']);
      } else {
        if (callFromCheckBox) {
          this.petition.beneficiaryInfo['mailingAddress'] = {
            line1: null,
            line2: null,
            aptType: null,
            locationId: null,
            locationDetails: null,
            stateId: null,
            stateDetails: null,
            countryId: null,
            countryDetails: null,
            zipcode: null
          }
        }
      }
    },
    goBack() {
      this.setActiveTab(this.tabslist[this.checkActiveTab - 1].key)
    },
    updatecellPhoneCountryCode(data) {
      this.petition.beneficiaryInfo.cellPhoneCountryCode = data
    },
    updatehomePhoneCountryCode(data) {
      this.petition.beneficiaryInfo.homePhoneCountryCode = data
    },
    updateworkPhoneCountryCode(data) {
      this.petition.beneficiaryInfo.workPhoneCountryCode = data
    },
    updatefaxCountryCode(data) {
      this.petition.beneficiaryInfo.faxCountryCode = data
    },
    setActiveTab(item, validate = false) {
      if (validate) {
        this.$validator.validateAll(this.currentTab + "form").then((result) => {
          if (result) {
            this.currentTab = item;
            document.getElementById("scrollableques").scrollTo({
              top: 0,
              left: 0,
              behavior: 'smooth'
            })
          } else {
            this.validateandScroll()
          }
        })
      } else {
        this.currentTab = item;
        setTimeout(function () {
          document.getElementById("scrollableques").scrollTo({
            top: 0,
            left: 0,
            behavior: 'smooth'
          })
        }, 500)
      }

    },
    lastNameToUpperCase(val) {
      if (val) {
        this.petition.beneficiaryInfo.lastName = val.toUpperCase();
      }
    },
    checkEducationDocuments(petitionDetails) {
      let returnValue = true
      if (this.checkProperty(petitionDetails['beneficiaryInfo'], 'educations')
        && this.checkProperty(petitionDetails['beneficiaryInfo'], 'educations', 'length') > 0) {
        let educationsList = this.checkProperty(petitionDetails['beneficiaryInfo'], 'educations')
        _.forEach(educationsList, (edu) => {
          let graduationCertificate = this.checkProperty(edu, 'documents', 'graduationCertificate')
          let transcripts = this.checkProperty(edu, 'documents', 'transcripts')
          if (!graduationCertificate || !transcripts) {
            returnValue = false;
          } else if (graduationCertificate && graduationCertificate.length == 0) {
            returnValue = false;
          } else if (transcripts && transcripts.length == 0) {
            returnValue = false;
          }
        })
      }

      return returnValue
    },
    checkMasterDegreeCountry(petitionDetails) {
      let returnValue = true
      if (this.checkProperty(petitionDetails['beneficiaryInfo'], 'educations')
        && this.checkProperty(petitionDetails['beneficiaryInfo'], 'educations', 'length') > 0) {
        let educationsList = this.checkProperty(petitionDetails['beneficiaryInfo'], 'educations')
        _.forEach(educationsList, (edu) => {
          if (this.checkProperty(edu, 'highestDegree') && this.checkProperty(edu, 'highestDegree') == 6
            && this.petition.beneficiaryInfo.reqConsdnOfAdvDegreeExptn == true
            && this.checkProperty(edu, 'address', 'countryId') != 231) {
            returnValue = false
          }
        })
      }
      return returnValue
    },
    getHighestDegree(val) {
      if (val) {
        this.petition['beneficiaryInfo']['highestDegree'] = val.id
      }
    },
    checkMasterDegreeYesorNo() {
      if (!this.checkSLGAndRenderField) {
        if (this.petition.beneficiaryInfo.reqConsdnOfAdvDegreeExptn) {
          // let mastedDegree = _.find(this.petition.highestDegreeList, { "id": 6 })

          // if (mastedDegree && this.checkProperty(this.petition, 'beneficiaryInfo', 'highestDegree')) {
          //   if (mastedDegree.id < this.petition.beneficiaryInfo['highestDegree']) {
          //     this.petition.beneficiaryInfo['highestDegree'] = 6
          //     this.petition.beneficiaryInfo.highestDegreeDetails = mastedDegree
          //   }
          // }
        } else {
          this.petition['documents']['eduTranscripts'] = [];
          this.petition.beneficiaryInfo.mastersUniversityName = '';
        }
      }
    }
  },
  beforeDestroy() {
    try {
      const $ = JQuery;
      document.removeEventListener("click", this.reloadthePage);
      $('body').removeClass('questionnairetpl')
    } catch (err) {
    }
  },
  computed: {
    checkEmailRequired(){
      let returnVal = true;
      if(this.checkProperty(this.petition,'tempUser') && this.checkProperty(this.petition,'questionnaireTplType') == 'general' ){
        returnVal = false;
      }
      return returnVal
    },
    // gettotalDays() { 
    //   var totaldays = 0;
    //   this.petition.beneficiaryInfo.priorPeriodOfStayInUS.forEach(function (item, index) {
    //     if (item.noOfDays > 0) {
    //       totaldays = totaldays + item.noOfDays;
    //     }
    //   })
    //   return totaldays;
    // },

    checkActiveTab() {
      return _.findIndex(this.tabslist, { "key": this.currentTab });
    },
    actiontype() {
      if (this.checkActiveTab == (this.tabslist.length - 1)) {
        if (this.petition.questionnaireFilled) {
          return "Update";
        }
        if (!this.petition.questionnaireFilled) {
          return "Review & Submit";
        }
        return "Submit";
      }
      return "Next";
    },
    checkSLGAndRenderField() {
      if (this.checkProperty(this.petition, 'questionnaireTplType')
        && this.petition.questionnaireTplType == 'slg') {
        return true
      }
      return false
    },

    checkEduTranscriptsDocumentsRequired() {
      if (!this.checkSLGAndRenderField) {
        if (this.checkProperty(this.petition,'beneficiaryInfo', 'mastersUniversityName')) {
          this.eduDocsList[0]['required'] = false
          return false
        }else{
          this.eduDocsList[0]['required'] = false
          return true
        }
      }
      return true
    }, checkMastersUniversityNameRequired() {
      if (!this.checkSLGAndRenderField) {
        if (this.checkProperty(this.petition, 'documents', 'eduTranscripts')
          && this.petition['documents']['eduTranscripts'].length > 0)
          return false
      }
      return true
    },

  },
  mounted() {

    // this.masterDegreeList = this.petition.highestDegreeList
    
    const $ = JQuery;
    this.$vs.loading();
    $('body').addClass('questionnairetpl')
    this.init()

  }
};
</script>