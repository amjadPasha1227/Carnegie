<template>
   <div class="main-tabs-content"
      :class="{ 'petetion__details_full_width': !loadedFromPreview, 'anonymouslogin': !checkCurrentUrl }">
      <!-- header area-->
      <div class="tabs-layout-header cpr_heading" v-if="!loadedFromPreview">

         <div class="case-no-panel">
            <div class="casenumber_sec">
               <div class="case_number">
                  <div class="d-flex align-items-center">
                     Case No
                  </div>
                  <span>{{ checkProperty(petition, "caseNo") }}
                  </span>
                  <i class="material-icons"
                     v-if="!loadedFromPreview && checkCurrentUrl && checkProperty(petitions, 'length') > 0">arrow_drop_down</i>
               </div>
               <div class="case_number_list"
                  v-if="!loadedFromPreview && checkCurrentUrl && checkProperty(petitions, 'length') > 0">
                  <VuePerfectScrollbar class="scroll-area">
                     <ul v-if="petitions">
                        <li @click="petetionChange(petition._id)" v-for="(petition, index) in petitions" :key="index">{{
                           petition.caseNo }}
                        </li>
                     </ul>
                  </VuePerfectScrollbar>
               </div>
            </div>
            <!-- <vs-dropdown>
            <a class="flex items-center" href.prevent>
               <div class="drop-down-content">Case ID<span>0508201900003</span></div>
               <i class="material-icons">arrow_drop_down</i>
            </a>
            <vs-dropdown-menu class="caseno-dropdown">
               <vs-dropdown-item to="/components/"> 0508201900003 </vs-dropdown-item>
               <vs-dropdown-item> 0508201900004 </vs-dropdown-item>
               <vs-dropdown-item> 0508201900005 </vs-dropdown-item>
            </vs-dropdown-menu>
         </vs-dropdown> -->
         </div>
         <capProcessFlow ref="process_flow" v-bind:petition="petition" @updatepetition="reloadPetition"
            @download_or_view="download_or_view" :loadedFromPreview="loadedFromPreview" />

         <!-- <div class="tabs-layout-header-items padr0">
            <div class="items-left">
            </div>
            <div class="items-right capactions">
               <ul>
                  <li>
                     <div class="dropdown-button-container">
                        <vs-button class="borderRadius20 status-btn"><span class="statusspan cursor-pointer" v-bind:class="{
                           'status_created': routeId == 1,
                           'status_sent_for_signatures': routeId == 2,
                           'status_accepted': routeId == 3,
                           'status_approved': routeId == 4,
                           'status_request_for_withdrawal': routeId == 5,
                           'status_submited': routeId == 6,
                           'status_completed': routeId == 7,
                           'status_denied': routeId == 8,}">{{routeQuery}}</span></vs-button>
                     </div>
                  </li>
                  <li>
                     <div class="Generate_buttons">     
                        <button class="copy_link" @click="showShareLink()" >
                          <img src="@/assets/images/main/link.svg"/>
                          <small>Share Link </small>    
                        </button>
                      </div>
                  </li>
                  
                  <li class="menu_dropdown actions_dropdown actions_dropdown-hover mar0" v-if="!(routeQuery == 'Denied' || routeQuery == 'Not Selected' || routeQuery == 'Case Created') ">
                     <div class="d-flex">
                        <button class="actions_btn actions_btn_v2">Actions</button>
                           <div class="menu_list_wrap new_actions_menu menu_v2 nextstep-shadow">
                              <div class="menu_list">
                                 <div class="menu_item drop_menu_items" v-if="routeQuery == 'Questionnaire Submitted'" > 
                                    <router-link to="/cap-registration-questionnaire">Edit Questionnaire</router-link>
                                 </div>
                                 <div class="menu_item drop_menu_items" v-if="routeQuery == ''"> 
                                    <router-link to="/cap-registration-questionnaire">Submit Case</router-link>
                                 </div>
                               <div class="menu_item drop_menu_items" v-if="routeQuery == 'Receipt of Payment Made'"> 
                                    <a @click="efilingmodal()">E-File</a>
                                 </div>
                                 <div class="menu_item drop_menu_items" v-if="routeQuery == 'Receipt of Payment Made'"> 
                                    <a @click="Trackinginfomodal()">Update Tracking Info</A>
                                 </div>  
                                 <div class="menu_item drop_menu_items" v-if="routeQuery == ' '"> 
                                    <a @click="paymentInfomodal()">Update Payment Info</A>
                                 </div> 
                                 <div class="menu_item drop_menu_items" v-if="routeQuery == 'Submitted to USCIS' || routeQuery == 'Denied'  "> 
                                    <a @click="UpdateUSICmodal()">Update USCIS Response</A>
                                 </div> 
                                 <div class="menu_item drop_menu_items" v-if="routeQuery == 'Selected' "> 
                                    <a @click="CreateCaseModal()">Create Case</A>
                                 </div> 
                              </div>
                           </div>
                     </div>
                  </li>
               </ul>
            </div>
         </div> -->
      </div>

      <div class="main-tabs-content tabs_mob petetion__details_page  petetion__details_full_width">
         <div class="
              tabs-content
              detail_page_sec
              petetion__details
              case-details-box-width
             petetion__details_full_width">
            <section class="petition__details_section cap_page"
               :class="{ 'cap_page_full': checkCurrentUrl && !loadedFromPreview && [50, 51].indexOf(getUserRoleId) > -1 }">
               <div class="pd_left">
                  <ul>
                     <li v-if="
                        (( checkProperty(petition, 'questionnaireTplType') == 'slg' &&(checkProperty(petition, 'questionnaireFilled')) && petition.completedActivities && petition.completedActivities.indexOf('VERIFY') > -1)||
                        (checkProperty(petition, 'questionnaireTplType') == 'general' &&(checkProperty(petition, 'questionnaireFilled')) && petition.completedActivities && petition.completedActivities.indexOf('REGISTERED') > -1))
                        && getUserRoleId != 51 && !loadedFromPreview"
                        :class="{ current_child: getPetitionTab == 'Petition Updates', }"
                        @click="setActivetab('Petition Updates', true)">
                        <a>Case Updates </a>
                     </li>
                     <li :class="{
                        current_child: getPetitionTab == 'Case Details' || (getPetitionTab == 'Petition Updates' && getUserRoleId == 51),
                     }" @click="setActivetab('Case Details', true)">
                        <a>Beneficiary Info </a>
                     </li>
                     <li v-if="false && checkProperty(petition, 'beneficiaryInfo') && checkProperty(petition['beneficiaryInfo'], 'educations') && checkProperty(petition['beneficiaryInfo'], 'educations', 'length') > 0"
                        :class="{
                           current_child: getPetitionTab == 'Education Info',
                        }" @click="setActivetab('Education Info', true)">
                        <a>Education Info </a>
                     </li>
                     <!-- <li v-if="!(routeQuery == 'Questionnaire Submitted' )" @click="activeTab='caseUpdate'" :class="{'current_child':activeTab=='caseUpdate'}"  class=""><a>Case Updates</a></li>
                  <li @click="activeTab='caseDetails'" :class="{'current_child':activeTab=='caseDetails'}" ><a>Beneficiary Info</a></li> -->
                  </ul>
               </div>
               <div class="pd_right petition__details_cnt">
                  <div class="pd_right_cnt">
                     <template>
                        <div v-if="getPetitionTab == 'Petition Updates' && getUserRoleId != 51 && !loadedFromPreview">
                           <capCaseUpdates :petition="petition" :checkCurrentUrl="checkCurrentUrl"
                              @download_or_view="download_or_view" />
                        </div>
                        <!-- {{ getPetitionTab }} -->
                        <div v-if="getPetitionTab == 'Case Details'">
                           <template
                              v-if="(loadedFromPreview && petition.beneficiaryInfo != null && petition.beneficiaryInfo.firstName != null) || (checkProperty(petition, 'questionnaireFilled'))">

                              <div class="main-list-wrap petition_details_wrap">
                                 <div class="tab-inner-content tabs-nobg">
                                    <div class="tabs-content-panel tab-pad-wrap">
                                       <div class="vs-col w-full p-0 vs-xs- vs-sm- vs-lg- marb10"  v-if="!loadedFromPreview && checkProperty(petition, 'questionnaireTplType') !='slg'&&[50,51].indexOf(getUserRoleId)<=-1 &&checkCurrentUrl" >
                                       <div class="con-vs-alert warning-alert top-warning-alert con-vs-alert-warning con-icon">
                                          <div class="vs-alert con-icon">
                                             <i class="vs-icon notranslate icon-scale icon-alert IntakePortal IP-information-button null"></i>
                                             Payment Information - <span v-if="checkProperty(petition,'ptnrPaymentInfoConfirmed')">Received </span>
                                             <span v-else>Yet to confirm</span>
                                          </div>
                                       </div>
                                       </div>
                                       <div class="card-panels">
                                          <personalInfo :visastatuses="visastatuses" @download_or_view="download_or_view"
                                             :petition="petition"></personalInfo>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </template>
                           <template v-else>
                              <div class="no-activities q_not_submitted">
                                 <div class="q_not_submitted_cnt">
                                    <figure>
                                       <img src="@/assets/images/main/no-activity-img.png" />
                                    </figure>
                                    <h3 :removeAction="updatePetiotionActionBtn(false)">
                                       <template v-if="checkProperty(petition, 'questionnaireTplType') == 'general'">
                                          <template v-if="checkProperty(petition,'intStatusDetails','id')==1" > <a class="cursor" @click="goToQuestionaireLink(petition._id)"> Fill
                                                Questionnaire.</a></template>
                                          <template v-else> <a >Questionnaire Not Submitted Yet</a></template>
                                          <!-- <template v-else >Questionnaire Not Submitted Yet</template> && this.checkProperty(this.petition,'intStatusDetails','id')==1 -->
                                       </template>
                                       <template v-else>
                                          <template> <a class="cursor" @click="goToQuestionaireLink(petition._id)"> Fill
                                                Questionnaire.</a></template>
                                       </template>
                                    </h3>
                                 </div>
                              </div>
                           </template>

                        </div>
                        <div v-if="getPetitionTab == 'Education Info' && false">
                           <div class="main-list-wrap petition_details_wrap">
                              <div class="tab-inner-content tabs-nobg">
                                 <div class="tabs-content-panel tab-pad-wrap">
                                    <div class="card-panels">
                                       <educationInfo :visastatuses="visastatuses" :petition="petition"></educationInfo>
                                    </div>
                                 </div>
                              </div>
                           </div>

                        </div>
                     </template>

                     <div>

                     </div>
                  </div>

               </div>
            </section>
            <div vs-type="flex" class="padr0 padl0 mob-right activies_list_wrap status_wrap cap_activies_list_wrap"
               v-if="!loadedFromPreview && checkCurrentUrl && [50, 51].indexOf(getUserRoleId) <= -1">
               <!-- Newly Added -->
               <ul v-if="checkCurrentUrl && !loadedFromPreview">
                  <li class="ptstatusBar " v-if="[50, 51].indexOf(getUserRoleId) < 0">
                     <div class="status_activities" style="justify-content:center">
                        <label class="active">Activities </label>
                     </div>
                  </li>
               </ul>
               <div class="history-sidebar petition_history activies_list cap_details_activies_list">
                  <div class="vs-sidebar">
                     <div class="petition_updated" v-if="petitionhistory.length == 0">
                        Last Updated -
                        {{ checkProperty(petition, "updatedOn") | formatDateTime }}
                     </div>
                     <div class="petition_updated" v-if="petitionhistory.length > 0">
                        Last Updated - {{ petitionhistory[0].createdOn | formatDateTime }}
                     </div>

                     <div class="vs-sidebar--items">
                        <VuePerfectScrollbar class="scroll-area">
                           <div class="timeline-sidebar 2">
                              <ul>
                                 <li v-for="(history, index) in petitionhistory" :key="index">
                                    <div class="timeline-icon">
                                       <i class="icon IP-tick-sign"></i>
                                    </div>
                                    <div class="timeline-info">
                                       <button class="btn active-green ml-0">
                                          {{ history.createdByRoleName }}
                                       </button>
                                       <ul>
                                          <li>
                                             <h3><span>
                                                   {{ history.title }}
                                                </span>
                                                <div v-if="
                                                   history.comment && history.comment != ''
                                                " class="title_des">
                                                   <small></small>
                                                   <div class="dec-content">
                                                      <p v-html="history.comment"></p>
                                                   </div>
                                                </div>
                                             </h3>

                                             <span>{{ history.description }}</span>
                                             <span>{{
                                                history.createdOn | formatDateTime
                                             }}</span>

                                             <p calss="cursor-pointer" style="margin-top: 5px;cursor: pointer; "
                                                v-if="checkProperty(history, 'action') == 'MANAGE_PREMIUM_PROCESS' && checkProperty(history, 'documents', 'length') > 0"
                                                @click="downloads3file(history['documents'][0])">
                                                <docmentType :title="checkProperty(history['documents'][0], 'name')"
                                                   :item="history['documents'][0]" />
                                                <!----<figcaption>{{checkProperty(history['documents'][0] ,'name')}}</figcaption>-->


                                             </p>
                                          </li>
                                       </ul>
                                    </div>
                                 </li>
                              </ul>
                           </div>
                        </VuePerfectScrollbar>
                     </div>
                  </div>
               </div>



            </div>
         </div>
      </div>
      <!--- Share Modal  --->
      <template v-if="false">
         <modal name="capgenaratModal" classes="v-modal-sec" :min-width="200" :min-height="200" :scrollable="true"
            :reset="true" width="500px" height="auto">
            <div class="v-modal">
               <!---------Contanexdv--------->
               <div class="genarate_body">
                  <span @click="$modal.hide('capgenaratModal')" class="closemodal">
                     <em class="material-icons">close</em>
                  </span>
                  <!-- <h4>Your link has been<br/> generated Successfully</h4> -->
                  <h6>Copy link.</h6>
                  <div class="copysec">
                     <p>http://localhost:8081/fill-questionnaire/6391be75f4a69aa58dabec0f?token=</p>
                     <img src="@/assets/images/main/copy.svg">
                     <small>Copy</small>
                  </div>
                  <div class="orshare"><span>OR</span></div>
                  <h6>Share link.</h6>

                  <div class="copysec">
                     <vs-input placeholder="Enter comma separated emails " class="form-control"
                        v-model="linkShareToemailsText" @keyup="formatEmail()" />
                     <vs-button class="primary-btn" type="filled">Share</vs-button>
                  </div>




               </div>

            </div>
         </modal>
         <!--- E file Modal  --->
         <modal name="efileModal" classes="v-modal-sec" :min-width="200" :min-height="200" :scrollable="true" :reset="true"
            width="500px" height="auto">
            <div class="v-modal">

               <div class="popup-header fromDetailsPage">
                  <h2 class="popup-title">
                     E-File PWD
                  </h2>
                  <span @click="$modal.hide('efileModal')">
                     <em class="material-icons">close</em>
                  </span>
               </div>
               <div class="form-container">


                  <div class="modal-confirm-msg">
                     <p>Using our Browser Extension PERM details can be filled automatically
                     </p>
                     <div class="popup-footer pl-0 pr-0">
                        <a @click="showPopup = false; $modal.hide('efileModal');" href="https://my.uscis.gov/"
                           target="_blank"> <vs-button color="success" class="save" type="filled">Click here to
                              proceed</vs-button>
                        </a>
                     </div>
                  </div>
               </div>


            </div>
         </modal>
         <!--- Tracking Info Modal  --->
         <modal name="Trackingmodal" classes="v-modal-sec" :min-width="200" :min-height="200" :scrollable="true"
            :reset="true" width="500px" height="auto">
            <div class="v-modal">
               <div class="popup-header">
                  <h2 class="popup-title">
                     Update Tracking Info
                  </h2>
                  <span @click="$modal.hide('Trackingmodal')">
                     <em class="material-icons">close</em>
                  </span>
               </div>
               <div class="form-container">
                  <div class="vx-row">
                     <immiInput :wrapclass="'md:w-full'" label="Tracking Number" placeHolder="Tracking Number" />
                  </div>
                  <div class="vx-row">
                     <div class="vx-col w-full">
                        <div class="form_group file_group">
                           <div class="vs-component marb20">
                              <label class="form_label">Acknowledgement</label>
                              <div class="relative">
                                 <file-upload v-model="value" class="file-upload-input upload_file justify-center"
                                    :accept="allDocEntity"
                                    :name="'documents'" :multiple="true" :hideSelected="true"
                                    @input="upload(value, 'permDocuments')">
                                    <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                                    Upload
                                 </file-upload>
                                 <!-- <span class="loader"   ><img src="@/assets/images/main/loader.gif"   /></span> -->
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="popup-footer">
                  <vs-button color="dark" @click="$modal.hide('Trackingmodal')" class="cancel"
                     type="filled">Cancel</vs-button>
                  <vs-button color="success" @click="SendQuestionnaireUser" class="save" type="filled">Update</vs-button>
               </div>
            </div>
         </modal>

         <!--- Payment Info Modal  --->
         <modal name="paymentmodal" classes="v-modal-sec" :min-width="200" :min-height="200" :scrollable="true"
            :reset="true" width="500px" height="auto">
            <div class="v-modal">
               <div class="popup-header">
                  <h2 class="popup-title">
                     Update Payment Info
                  </h2>
                  <span @click="$modal.hide('paymentmodal')">
                     <em class="material-icons">close</em>
                  </span>
               </div>
               <div class="form-container">
                  <div class="vx-row">
                     <immiInput :wrapclass="'md:w-full'" label="Amount" placeHolder="" />
                  </div>
                  <div class="vx-row">
                     <div class="vx-col w-full">
                        <div class="form_group file_group">
                           <div class="vs-component marb20">
                              <label class="form_label">Receipt</label>
                              <div class="relative">
                                 <file-upload v-model="value" class="file-upload-input upload_file justify-center"
                                    :accept="allDocEntity"
                                    :name="'documents'" :multiple="true" :hideSelected="true"
                                    @input="upload(value, 'permDocuments')">
                                    <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                                    Upload
                                 </file-upload>
                                 <!-- <span class="loader"   ><img src="@/assets/images/main/loader.gif"   /></span> -->
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="popup-footer">
                  <vs-button color="dark" @click="$modal.hide('paymentmodal')" class="cancel"
                     type="filled">Cancel</vs-button>
                  <vs-button color="success" class="save" type="filled">Update</vs-button>
               </div>
            </div>
         </modal>

         <!--- Update USIC Response Modal  --->
         <modal name="usicResponsemodal" classes="v-modal-sec" :min-width="200" :min-height="200" :scrollable="true"
            :reset="true" width="500px" height="auto">
            <div class="v-modal">
               <div class="popup-header">
                  <h2 class="popup-title">
                     Update USCIS Response
                  </h2>
                  <span @click="$modal.hide('usicResponsemodal')">
                     <em class="material-icons">close</em>
                  </span>
               </div>
               <div class="form-container">
                  <div class="vx-row">
                     <selectField :listContainsId="true" :display="true" :wrapclass="'md:w-full'"
                        :optionslist="USCISstatus" v-model="status" label="Status" fieldName="status"
                        placeHolder="Select" />
                  </div>
                  <div class="vx-row">
                     <div class="vx-col w-full">
                        <div class="form_group file_group">
                           <div class="vs-component marb20">
                              <label class="form_label">Documents</label>
                              <div class="relative">
                                 <file-upload v-model="value" class="file-upload-input upload_file justify-center"
                                    :accept="allDocEntity"
                                    :name="'documents'" :multiple="true" :hideSelected="true"
                                    @input="upload(value, 'permDocuments')">
                                    <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                                    Upload
                                 </file-upload>
                                 <!-- <span class="loader"   ><img src="@/assets/images/main/loader.gif"   /></span> -->
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="vx-row">
                     <!-- <immitextarea :wrapclass="'md:w-full'" label="Comments"></immitextarea> -->
                     <ckeditor :wrapclass="'md:w-full'" label="Comments" :editor="editor" :config="editorConfig">
                     </ckeditor>

                  </div>
               </div>
               <div class="popup-footer">
                  <vs-button color="dark" @click="$modal.hide('usicResponsemodal')" class="cancel"
                     type="filled">Cancel</vs-button>
                  <vs-button color="success" class="save" type="filled">Update</vs-button>
               </div>
            </div>
         </modal>

         <!--- Create Case Modal  --->
         <modal name="Createcasemodal" classes="v-modal-sec" :min-width="200" :min-height="200" :scrollable="true"
            :reset="true" width="700px" height="auto">
            <div class="v-modal">
               <div class="popup-header">
                  <h2 class="popup-title">
                     Create Case
                  </h2>
                  <span @click="$modal.hide('Createcasemodal')">
                     <em class="material-icons">close</em>
                  </span>
               </div>
               <div class="form-container">
                  <div class="vx-row">
                     <selectField :listContainsId="true" :display="true" :wrapclass="'md:w-1/2'" :optionslist="casetype"
                        v-model="status" label="Case Type*" fieldName="status" placeHolder="Select" />
                     <selectField :listContainsId="true" :display="true" :wrapclass="'md:w-1/2'" :optionslist="casesubtype"
                        v-model="status" label="Case Case Subtype*" fieldName="status" placeHolder="Select" />
                  </div>
                  <div class="vx-row">
                     <div class="vx-col w-full pp-col">
                        <vs-checkbox id="premium" name="premiumProcessing" v-model="premiumProcessing">Premium Processing
                        </vs-checkbox>
                     </div>
                  </div>
                  <div class="vx-row">
                     <selectField :listContainsId="true" :isDisabled="true" :display="true" :wrapclass="'md:w-full'"
                        :optionslist="branchList" v-model="branchvalue" label="Branch" value="Head Office"
                        fieldName="status" placeHolder="Select" />
                  </div>
                  <div class="vx-row">
                     <selectField :listContainsId="true" :isDisabled="true" :display="true" :wrapclass="'md:w-1/2'"
                        :optionslist="PetitionerList" v-model="Petitionervalue" label="Petitioner" fieldName="status"
                        placeHolder="Select" />
                     <selectField :listContainsId="true" :isDisabled="true" :display="true" :wrapclass="'md:w-1/2'"
                        :optionslist="BeneficiaryList" v-model="Beneficiaryvalue" label="Beneficiary" fieldName="status"
                        placeHolder="Select" />
                  </div>

               </div>
               <div class="popup-footer">
                  <vs-button color="dark" @click="$modal.hide('Createcasemodal')" class="cancel"
                     type="filled">Cancel</vs-button>
                  <vs-button color="success" class="save" type="filled">Submit</vs-button>
               </div>
            </div>
         </modal>
      </template>
      <vs-popup class="document_modal document_modal-v2" 
      :class="{ expand: expandModal }"
       :title="checkProperty(selectedFile, 'name')" :active.sync="docPrivew">
       <div class="document_actions" @click="expandModal = !expandModal">
      <figure v-if="!expandModal" class="maximize-img"><img src="@/assets/images/maximize.png"  width="18" height="18"/></figure>
      <figure v-else class="minimize-img"><img src="@/assets/images/minimize.png"  width="20" height="20"/></figure>
    </div>
         <h2> <img :class="{
            pdf_view_download: docType == 'pdf',
            office_view_download: docType == 'office',
            image_view_download: docType == 'image',
         }" class="download-button" @click="downloads3file(selectedFile)" src="@/assets/images/download.svg" /></h2>

         <div class="pdf_loader">
            <figure v-if="formSubmited" class="loader loader2"><img src="@/assets/images/main/loader.gif" /></figure>

            <!-- <span :class="{'pdf_view_close':docType == 'pdf', 'office_view_close':docType == 'office'  , 'image_view_close 33':docType =='image'}" class="close close2" @click="docPrivew= false"></span> -->
            <template v-if="docType == 'office'">
               <div style="height:90vh">

                  <div id="placeholder" style="height:100%"></div>
               </div>
            </template>
            <template v-else-if="docType == 'image'">
               <img :src="docValue" />
            </template>
            <template v-else-if="docType == 'pdf'">
               <div class="pdf" style="height:90vh">

                  <iframe v-if="docValue != ''" border="0" style="border:0px;" :src="docValue" height="100%" width="100%">

                  </iframe>
               </div>
            </template>
         </div>
      </vs-popup>


   </div>
</template>

<script>
import Vue from 'vue';
Vue.use(CKEditor);
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import docmentType from "@/views/common/docType.vue"
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import capCaseUpdates from "@/views/cap/capCaseUpdates.vue";
import capProcessFlow from "@/views/cap/capProcessFlow.vue";
import educationInfo from "@/views/petition/subtabs/educationsVersion2.vue";
import personalInfo from "@/views/cap/capPersonalDetails.vue";
import immiInput from "@/views/forms/fields/simpleinput.vue";
import immitextarea from "@/views/forms/fields/simpletextarea.vue";
import selectField from "@/views/forms/fields/simpleselect.vue";
import FileUpload from "vue-upload-component/src";
import axios from '@/axios.js';
export default {
   provide() {
      return {
         parentValidator: this.$validator,
      };
   },
   data: () => ({
      expandModal: false,
      editor: ClassicEditor,
      editorConfig: {
         toolbar: ['bold', 'italic', '|', 'undo', 'redo', 'NumberedList', 'BulletedList',],
      },
      petitionhistory: [],
      formSubmited: false,
      selectedFile: '',
      docValue: "",
      docPrivew: false,
      docType: false,
      petitions: [],
      currentRole: null,
      setTab: false,
      visastatuses: [],
      getPetitionTab: null,
      petitionId: null,
      petition: null,
      ///////////////////////////
      activeTab: 'caseUpdate',
      routeId: '',
      routeQuery: '',
      linkShareToemailsText: "",
      users: [
         {
            "id": "B-1",
            "name": "24 September 2013",
            "email": "12 June 2013",
         },
         {
            "id": "H-1B",
            "name": "08 March 2017",
            "email": "18 January 2014",
         }
      ],
      USCISstatus: [
         { "name": 'Selected', 'id': 'Selected' },
         { "name": 'Not Selected', 'id': 'Not Selected' },
         { "name": 'Denied', 'id': 'Denied' },
         { "name": 'Invalidated-Failed Payment', 'id': 'Invalidated-Failed Payment' }
      ],
      casetype: [
         { "name": 'H-1B', 'id': 'H-1B' }
      ],
      casesubtype: [
         { "name": 'Master Cap - Consular Processing', 'id': 'Master' },
         { "name": 'Regular Cap - Consular Processing', 'id': 'Regular' }
      ],
      branchList: [
         { "name": 'Head Office', 'id': 'Head Office' }
      ],
      PetitionerList: [
         { "name": 'Berkshare LLP', 'id': 'Berkshare LLP' }
      ],
      BeneficiaryList: [
         { "name": 'Wasim Pathan', 'id': 'Wasim Pathan' }
      ],


      SubmitParalegal: false,
      SuccessQuestionnaire: false,
      branchvalue: { "name": 'Head Office', 'id': 'Head Office' },
      Petitionervalue: { "name": 'Berkshare LLP', 'id': 'Berkshare LLP' },
      Beneficiaryvalue: { "name": 'Wasim Pathan', 'id': 'Wasim Pathan' }

   }),
   components: {
      docmentType,
      VuePerfectScrollbar,
      capCaseUpdates,
      capProcessFlow,
      //ProcessFlow,
      personalInfo,
      educationInfo,
      immiInput,
      FileUpload,
      selectField,
      immitextarea
   },
   methods: {
      loadPetetion(tab = "") {
         let paylaod = {
            petitionId: ''
         }
         let path = '/cap-registrations/details'
         paylaod['petitionId'] = this.petitionId
         this.$store.dispatch("commonAction", { "data": paylaod, "path": path })
            .then((response) => {
               this.petition = response
               if ( (this.checkProperty(this.petition, 'questionnaireTplType') == 'slg' && this.petition && (this.petition.completedActivities.indexOf('VERIFY') > -1) && this.getUserRoleId != 51)||
               (this.checkProperty(this.petition, 'questionnaireTplType') == 'general' && this.petition && (this.petition.completedActivities.indexOf('REGISTERED') > -1) && this.getUserRoleId != 51)
               ) {
                  this.getPetitionTab = "Petition Updates"
                  this.setTab = true;
               }
               if (!this.setTab && tab == '') {
                  this.getPetitionTab = "Case Details"
               }
               this.$store.dispatch("setPetitionData", {
                  petitionDetails: this.petition,
                  lcaDetails: null,
                  workFlowDetails: null,
               });
               this.getcaseHistory();
               if (this.checkProperty(this.petition, "userId")) {
                  let postdata = {
                     matcher: { rfeCases: '', getMasterDataOnly: true, beneficiaryIds: '', },
                     "page": 1,
                     "perpage": 100
                  }
                  postdata['matcher']['userId'] = this.petition['userId'];
                  if (_.has(this.petition, "rfeCase")) {
                     postdata['matcher']['isRfeCase'] = false
                  }
                  this.$store.dispatch("getList", { data: postdata, path: '/cap-registrations/list', }).then((response) => {
                     this.petitions = response['list'];
                  });
               }
            }).catch((err) => {})
      },
      setActivetab(stab = "Case Details", callFromClick = false) {
         if (!stab) {
            stab = "Case Details";
         }
         this.getPetitionTab = stab

      },
      reloadPetition(tab = "Case Details") {
         //reloading Petition Updates

         if (this.getPetitionTab == 'Petition Updates') {
            this.getPetitionTab = 'Case Details';
         }


         if (tab != "") {

            this.$store.dispatch("setPetitionTab", tab)
               .then(() => {

                  this.init(tab);
               })
               .catch((err) => {

                  this.init();
               });
         } else {
            this.$store.dispatch("setPetitionTab", "Case Details");
            this.init();
         }
      },
      getcaseHistory() {
         if (this.petitionId) {
            let postData = {
               "petitionId": '', "page": 1,
               "perpage": 500
            };
            postData['petitionId'] = this.petitionId;

            this.$store
               .dispatch("getList", {
                  data: postData,
                  path: '/cap-registrations/activity-list',
               }).then((response) => {

                  this.petitionhistory = response['list'];
               });

         }


      },
      init(tab = '') {
         //this.updatePetiotionActionBtn(false);
         this.currentRole = this.$store.state.user.loginRoleId;
         this.currentUserId = this.$store.state.user._id;
         this.loadPetetion(tab);
         this.$store.dispatch("getmasterdata", "visa_status").then((response) => {
            this.visastatuses = response;
         });
      },
      petetionChange(id) {
         this.setActivetab("Case Details", true);
         this.petition = null;
         this.petitionId = id;
         this.$store.dispatch("setPetitionData", { petitionDetails: this.petition, })
            .then(() => {
               setTimeout(() => {
                  this.init();
               }, 10);
            })
            .catch(() => {
               setTimeout(() => {
                  this.init();
               }, 1);
            });
         this.updateUrl();
      },
      updateUrl() {
         this.$route['params']['itemId'] = _.cloneDeep(this.petitionId);
      },
      goToQuestionaireLink(item) {
         this.$router.push({ name: 'Cap questionnaire', params: { itemId: item } })
      },
      showShareLink() {
         this.$modal.show('capgenaratModal')
      },
      efilingmodal() {
         this.$modal.show('efileModal')
      },
      Trackinginfomodal() {
         this.$modal.show('Trackingmodal')
      },
      paymentInfomodal() {
         this.$modal.show('paymentmodal')
      },
      UpdateUSICmodal() {
         this.$modal.show('usicResponsemodal')
      },
      CreateCaseModal() {
         this.$modal.show('Createcasemodal')
      },
      download_or_view(docItem) {


         let value = _.cloneDeep(docItem);
         this.expandModal= false;
         if (this.checkProperty(this.getPetitionDetails, 'caseNo') && this.checkProperty(value, 'name')) {
            let docName = _.cloneDeep(value['name']);
            value['name'] = this.checkProperty(this.getPetitionDetails, 'caseNo') + "_" + docName;
         }


         var _self = this;
         this.formSubmited = false;
         if (_.has(value, "path")) {
            value["url"] = value["path"];
            value["document"] = value["path"];
         }

         if (_.has(value, "url")) {
            value["path"] = value["url"];
            value["document"] = value["url"];
         }

         if (_.has(value, "document")) {
            value["path"] = value["document"];
            value["url"] = value["document"];
         }
         value = Object.assign(value, { 'petitionId': this.petition['_id'] })
         value = Object.assign(value, { 'subTypeDetails': this.petition['subTypeDetails'] })


         this.selectedFile = value;
         this.docValue = "";
         this.docPrivew = false;
         this.docType = false;
         this.docType = this.findmsDoctype(value);

         if ((this.docType == "office" || this.docType == "image" || this.docType == "pdf")) {
            //if ( (this.docType == "office" || this.docType == "image" || this.docType == "pdf") && value.download == false ) {
            value.url = value.url.replace(this.$globalgonfig._S3URL, "");
            value.url = value.url.replace(this.$globalgonfig._S3URLAWS, "");
            let postdata = {
               keyName: value.url,
               "petitionId": value['petitionId'],

               // entityType:value['petitionId']
               // "fileName":value.name?value.name:''
            };
            if (this.checkProperty(value, 'subTypeDetails', 'id') == 15) {
               postdata['entityType'] = 'perm'
            } else {
               postdata['entityType'] = 'case'
            }


            this.$store.dispatch("getSignedUrl", postdata).then((response) => {
               this.docValue = response.data.result.data;

               if (this.docType == "office") {
                  document.getElementById("placeholder").innerHTML = "  <div  id='placeholder2' style='height:100%'></div>";
                  let _editing = true;

                  if ([50, 51].indexOf(this.getUserRoleId) > -1) {
                     _editing = false;
                  }

                  if (value.viewmode) {
                     _editing = false;
                  }
                  var _ob = {}
                  if (value.editedDocument) {
                     _ob = {

                        petitionId: this.petition._id,
                        name: value.name,
                        _id: value._id,
                        "extn": "docx",
                        "formLetterType": "Letter",
                        parentId: value.parentId
                     }

                  } else {

                     _ob = {

                        name: value.name,
                        petitionId: this.petition._id,
                        _id: value._id,
                        "extn": "docx",
                        "formLetterType": "Letter",
                        parentId: value._id

                     }

                  }


                  window.docEditor = new DocsAPI.DocEditor("placeholder2",
                     {

                        "document": {
                           "c": "forcesave",
                           "fileType": "docx",
                           "key": value._id,
                           "userdata": JSON.stringify(_ob),
                           "title": value.name,
                           "url": response.data.result.data,
                           permissions: {
                              edit: _editing,
                              download: true,
                              reader: false,
                              review: false,
                              comment: false
                           }
                        },

                        "documentType": "word",
                        "height": "100%",
                        "width": "100%",

                        "editorConfig": {
                           "userdata": JSON.stringify(_ob),
                           "callbackUrl": "https://immibox.com/api/perm/post-edited-document?payload=" + JSON.stringify(_ob) + "&token=" + _self.$store.state.token + "&name=" + value.name.replace('.docx', ''),
                           "customization": {
                              "logo": {
                                 "image": "https://immibox.com/app/favicon.png",
                                 "imageDark": "https://immibox.com/app/favicon.png",
                                 "url": "https://immibox.com"
                              },
                              "anonymous": {
                                 "request": false,
                                 "label": "Guest"
                              },
                              "chat": false,
                              "comments": false,
                              "compactHeader": false,
                              "compactToolbar": true,
                              "compatibleFeatures": false,
                              "feedback": {
                                 "visible": false
                              },
                              "forcesave": true,
                              "help": false,
                              "hideNotes": true,
                              "hideRightMenu": true,
                              "hideRulers": true,
                              layout: {
                                 toolbar: {
                                    "collaboration": false,
                                 },
                              },
                              "macros": false,
                              "macrosMode": "warn",
                              "mentionShare": false,
                              "plugins": false,
                              "spellcheck": false,
                              "toolbarHideFileName": true,
                              "toolbarNoTabs": true,
                              "uiTheme": "theme-light",
                              "unit": "cm",
                              "zoom": 100
                           },
                        }, events: {
                           onReady: function () {

                           },
                           onDocumentStateChange: function (event) {
                              var url = event.data;
                              if (!event.data) {

                                 if (value.editedDocument) {

                                 }

                              }
                           }

                        }
                     });
                  //this.docValue = encodeURIComponent(response.data.result.data);
               }

               if (this.docType == "pdf") {

                  // this.downloadFile(this.docValue, value.mimetype, value.name)

                  // return
                  var _vid = value._id;
                  if (value.parentId) {
                     _vid = value.parentId;
                  }
                  var viewmode = 1; // Enable edit
                  viewmode = 0; //Disabled Edit
                  if (value.viewmode) {
                     viewmode = 0;
                  }
                  let pdfViewUrl ='https://immibox.com/viewer/pdfjs-dist/web/viewerv2.html';            
                  if(_.has(this.$globalgonfig, 'PDF_VIEW_URL')){
                     pdfViewUrl = this.$globalgonfig['PDF_VIEW_URL']; //PDF_EDIT_URL
                  }

                  if(viewmode==1){
                     if(_.has(this.$globalgonfig, 'PDF_EDIT_URL')){
                     pdfViewUrl = this.$globalgonfig['PDF_EDIT_URL'];
                  }

                  }
                  this.docValue = pdfViewUrl+"?view=" + viewmode + "+&file=" + encodeURIComponent(response.data.result.data);
               }
                this.docPrivew = true;
            });
         } else {



            this.downloads3file(value);
         }

      },

      downloadFile(url, mimetype, fireName) {
         axios({
            url: url,
            method: 'GET',
            responseType: 'blob',
         }).then((res) => {
            var FILE = window.URL.createObjectURL(new Blob([res.data], { type: mimetype }));

            var docUrl = document.createElement('x');
            docUrl.href = FILE;
            docUrl.setAttribute('download', fireName);
            document.body.appendChild(docUrl);
            docUrl.click();
         });
      }

   },
   mounted() {
      if (this.$route.params && this.$route.params.itemId) {
         this.petitionId = this.$route.params.itemId;
         if (this.loadedFromPreview && this.previewData) {
            this.setActivetab('Case Details', true);
            this.petition = _.cloneDeep(this.previewData);
         } else {
            this.init();
         }
      }
      //this.loadPetetion();
   },
   props: {
      loadedFromPreview: false,
      previewData: null,
   },
   computed: {
      checkCaseStatus() {
         if (this.checkProperty(this.petition, 'intStatusDetails', 'id') == 1) {
            return this.checkProperty(this.petition, 'intStatusDetails', 'id')
         }
         else {
            return 4
         }
      },
      checkCaseCreatedLogin() {
         let returnVal = true
         let createdBy = null;
         if (this.petition && this.checkProperty(this.petition, 'createdBy')) {
            createdBy = this.checkProperty(this.petition, 'createdBy')
            if (this.checkProperty(this.getUserData, 'userId') && (createdBy == this.checkProperty(this.getUserData, 'userId'))) {
               returnVal = true
            } else {
               returnVal = false
            }
         }
         return returnVal
      }
   }
}
</script>