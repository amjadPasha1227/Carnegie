<template>
  <div>
    <div class="content-header  primary_filters bulk-assign-btn ">
      <div class="content-header content-header-left pad0">
        <div class="filters-row">
          <div class="con-select">
            <div class="selection_search casetype ml-0">
              <div class="search">
                <div class="vs-component vs-con-input-label vs-input is-label-placeholder vs-input-primary">
                  <div class="vs-con-input">
                    <vs-input icon-pack="feather" icon="icon-search" :placeholder="'Case No/Beneficiary Name/Email'"
                      class="is-label-placeholder" v-model.lazy="searchtxt" />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="con-select selection_search selection_search-v2 casetype pn_width"
            v-if="[3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13].indexOf(getUserRoleId) > -1 && getTenantTypeId != 2">
            <div class="search">
              <div class="vs-component vs-con-input-label vs-input is-label-placeholder vs-input-primary">
                <div class="vs-con-input">
                  <multiselect @input="changedperitionersSearch()" v-model="header_selected_petitioners"
                    :options="petitionersList" :multiple="true" :hideSelected="true" :close-on-select="false"
                    :clear-on-select="false" :preserve-search="true" placeholder="Petitioner" label="name" track-by="name"
                    :preselect-first="false" @search-change="peritioners_search_fun">
                    <template slot="selection" slot-scope="{ values, isOpen }">
                      <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                        Petitioner(s)</span>
                      <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                    </template>

                  </multiselect>
                  <!-- <multiselect  v-model="capvalues" :placeholder="'Petitioner'" :options="Petitioners"></multiselect> -->
                </div>
              </div>
            </div>
          </div>
          <div class="con-select  selection_search casetype mc_rc_width" v-if="[51].indexOf(getUserRoleId) <= -1">
            <multiselect @input="changedCaseTypes()" v-model="headerTypeNames" :options="cap" :multiple="true"
              :hideSelected="true" :close-on-select="false" :clear-on-select="false" :preserve-search="true"
              placeholder="Case Type" label="name" track-by="name" :preselect-first="false">
              <template slot="selection" slot-scope="{ values, isOpen }">
                <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                  Case Type(s)</span>
                <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
              </template>

            </multiselect>
          </div>
          
          <div class="con-select  selection_search casetype section_width" v-if="[51].indexOf(getUserRoleId) <= -1">
            <multiselect @input="set_filter" v-model="selectedSeasons" :options="season" :multiple="true"
              :hideSelected="true" :close-on-select="false" :clear-on-select="false" :preserve-search="true"
              placeholder="Season" :preselect-first="false">
              <template slot="selection" slot-scope="{ values, isOpen }">
                <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                  Season(s)</span>
                <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
              </template>
            </multiselect>
            <!-- <multiselect   v-model="values" :placeholder="'Season'" :options="season"></multiselect>  -->
          </div>
          <div class="con-select  selection_search casetype mc_rc_width" v-if="[51].indexOf(getUserRoleId) <= -1">


          </div>

        </div>
      </div>
      <div class="content-header-right">
        <!--filter dropdown-->
        <vs-dropdown vs-custom-content vs-trigger-click>
          <vs-button color="primary" class="filter-btn" type="border" icon-pack="feather" icon="icon-chevron-down"
            icon-after>
            <img src="@/assets/images/main/icon-filter.svg" /> Filters
          </vs-button>
          <vs-dropdown-menu ref="filter_menu" class="filters-content">
            <div class="filters-form-fileds">
              <div class="form-container">
                <div class="vx-row">
                  <div class="vx-col md:w-1/3 w-full con-select filters-search">
                    <label class="typo__label">Title</label>
                    <vs-input icon-pack="feather" icon placeholder="Search by Case No/Beneficiary"
                      class="is-label-placeholder" v-model="filter_searchtxt" />
                  </div>
                  <div class="vx-col md:w-1/3 w-full con-select"
                    v-if="[3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13].indexOf(getUserRoleId) > -1 && getTenantTypeId != 2">
                    <label class="typo__label">Petitioner</label>
                    <multiselect @input="changedperitioners()" v-model="selected_peritioners" :options="petitionersList"
                      :multiple="true" :hideSelected="true" :close-on-select="false" :clear-on-select="false"
                      :preserve-search="true" placeholder="Select Petitioner" label="name" track-by="name"
                      :preselect-first="false" @search-change="peritioners_search_fun">
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          Petitioner(s) Selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>

                    </multiselect>

                  </div>
                  <!-- <div class="vx-col md:w-1/3 w-full con-select filters-search">
                      <label class="typo__label">Petitioner</label>
                      <multiselect  v-model="Petitioner" :options="Petitioneroptions">
                      </multiselect> 
                    </div> -->
                  <div class="vx-col md:w-1/3 w-full con-select filters-search">
                    <label class="typo__label">Case Type</label>
                    <!-- <multiselect  v-model="selectedtypeNames" :options="cap">
                    </multiselect>  -->
                    <multiselect @input="changedperitioners()" v-model="selectedtypeNames" :options="cap" :multiple="true"
                      :hideSelected="true" :close-on-select="false" :clear-on-select="false" :preserve-search="true"
                      placeholder="Select Case Type" label="name" track-by="name" :preselect-first="false">
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          Case Type(s) Selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>

                    </multiselect>
                  </div>
                  <div class="vx-col md:w-1/3  w-full con-select filters-search" v-if="false">
                    <div class=" select-large">
                      <label for="" class="typo__label">Degree Level</label>
                      <multiselect v-model="selectedEducations" :options="education_types" :multiple="true"
                        :hideSelected="true" :close-on-select="false" :clear-on-select="false" :preserve-search="true"
                        placeholder="Select Degree Level" label="name" track-by="name" :preselect-first="false">
                        <template slot="selection" slot-scope="{ values, isOpen }">
                          <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                            Degree(s) Selected</span>
                          <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                        </template>

                      </multiselect>
                    </div>
                  </div>
                  <div class="vx-col md:w-1/3 w-full con-select" v-if="false">
                    <label class="typo__label">Graduation Period</label>
                    <date-range-picker :maxDate="new Date()" :autoApply="autoApply" :ranges="false" :opens="'left'"
                      v-model="selected_createdDateRange"></date-range-picker>
                  </div>
                  <div class="vx-col md:w-1/3  w-full con-select filters-search">
                    <div class=" select-large">
                      <label for="" class="typo__label">Case Status </label>
                      <multiselect v-model="selectedStatus" :options="caseStatusList" :multiple="true"
                        :hideSelected="true" :close-on-select="false" :clear-on-select="false" :preserve-search="true"
                        placeholder="Select status" label="name" track-by="name" :preselect-first="false">
                        <template slot="selection" slot-scope="{ values, isOpen }">
                          <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                            Status(s) Selected</span>
                          <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                        </template>

                      </multiselect>
                    </div>
                  </div>
                  <div class="vx-col md:w-1/3 w-full con-select" v-if="false">
                    <label class="typo__label">Premium Processing</label>
                    <multiselect @input="$router.push({ query: {} })" v-model="selectedpremiumProcessing"
                      :options="premiumProcessingList" :multiple="true" :hideSelected="true" :close-on-select="false"
                      :clear-on-select="false" :preserve-search="true" placeholder="Select Premium Processing"
                      label="name" track-by="name" :preselect-first="false">

                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          Premium Processing(s) Selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>
                </div>
              </div>
            </div>
            <div class="filters-status">
              <div class="left-buttons"></div>
              <div class="right-buttons">
                <vs-button color="success" class="save" type="filled" v-on:click="set_filter()">Apply</vs-button>
                <vs-button color="dark" class="cancel" type="filled" v-on:click="clear_filter($event)">Clear</vs-button>
              </div>
            </div>
          </vs-dropdown-menu>
        </vs-dropdown>
        
        <vs-button color="primary" type="border" class="light-blue-btn"
          v-if="showCapRegistrations && checkCapCaseCreatePermisions && [51].indexOf(getUserRoleId) <= -1"
          @click="openCreateCasePopup(false)">New&nbsp;Case</vs-button>
        <div class="Generate_buttons" v-if="false">
          <button class="copy_link">
            <img src="@/assets/images/main/share.png" />
            <small>Export</small>
          </button>
        </div>
      </div>
    </div>
    <NoDataFound ref="NoDataFoundRef" :loading="isListloading" v-if="capRegistartionList.length == 0" content=""
      :heading="callFromSearch ? 'No Results Found' : 'No Cases Found'" type='petitions' />
    <div class="accordian-table custom-table cpr_table" v-if="capRegistartionList.length > 0">

      <div class="vs-table--content">
        <div class="vs-con-tbody">
          <table class="vs-table vs-table--tbody-table">
            <thead class="vs-table--thead">
              <tr>
                <th>
                  <div class="vs-table-text">
                    <a @click="sortMe('caseNo')"
                      v-bind:class="{ 'sort_ascending': sortKeys['caseNo'] == 1, 'sort_descending': sortKeys['caseNo'] != 1 }">Case
                      No
                    </a>
                  </div>
                </th>
                <th v-if="[50].indexOf(getUserRoleId) <= -1 && getTenantTypeId != 2">
                  <div class="vs-table-text">
                    <a @click="sortMe('companyName')"
                      v-bind:class="{ 'sort_ascending': sortKeys['companyName'] == 1, 'sort_descending': sortKeys['companyName'] != 1 }">Petitioner
                      Name</a>
                  </div>
                </th>
                <th v-if="[51].indexOf(getUserRoleId) <= -1">
                  <div class="vs-table-text">
                    <a @click="sortMe('beneficiaryName')"
                      v-bind:class="{ 'sort_ascending': sortKeys['beneficiaryName'] == 1, 'sort_descending': sortKeys['beneficiaryName'] != 1 }">Beneficiary
                      Name</a>
                  </div>
                </th>
                <th>
                  <div class="vs-table-text">
                    <a @click="sortMe('createdByName')"
                      v-bind:class="{ 'sort_ascending': sortKeys['createdByName'] == 1, 'sort_descending': sortKeys['createdByName'] != 1 }">Created
                      By</a>
                  </div>
                </th>
                <th>
                  <div class="vs-table-text">
                    <a @click="sortMe('createdOn')"
                      v-bind:class="{ 'sort_ascending': sortKeys['createdOn'] == 1, 'sort_descending': sortKeys['createdOn'] != 1 }">Created
                      On</a>
                  </div>
                </th>
                <th>
                  <div class="vs-table-text">
                    <a @click="sortMe('updatedOn')"
                      v-bind:class="{ 'sort_ascending': sortKeys['updatedOn'] == 1, 'sort_descending': sortKeys['updatedOn'] != 1 }">Last
                      Updated</a>
                  </div>
                </th>
                <th>
                  <div class="vs-table-text">
                    <a @click="sortMe('statusName')"
                      v-bind:class="{ 'sort_ascending': sortKeys['statusName'] == 1, 'sort_descending': sortKeys['statusName'] != 1 }">Status</a>
                  </div>
                </th>
              </tr>
            </thead>
            <tr class="vs-table--tr" v-for="(petition, index) in capRegistartionList" :key="index">
              <td class="td vs-table--td">
                <span>


                  <div class="cursor-pointer" @click="petitionlink(petition)"> {{ petition.caseNo }} </div>
                  <div class="IB_tooltip premium_tooltip" v-if="checkProperty(petition, 'premiumProcessing')">
                    <span>P</span>
                    <div class="tooltip_cnt">
                      <p>Premium Processing</p>
                    </div>
                  </div>

                </span>
              </td>
              <td class="td vs-table--td" v-if="[50].indexOf(getUserRoleId) <= -1 && getTenantTypeId != 2">
                <span :title="checkProperty(petition, 'companyDetails', 'name')">
                  <div class="cursor-pointer wrd-substr" @click="petitionlink(petition)"> {{
                    checkProperty(petition, 'companyDetails', 'name')
                  }} </div>
                </span>
              </td>
              <td class="td_label" v-if="[51].indexOf(getUserRoleId) <= -1">
                <span :title="checkProperty(petition, 'beneficiaryInfo', 'name')" class="wrd-substr cursor-pointer" @click="petitionlink(petition)">{{
                  checkProperty(petition, 'beneficiaryInfo', 'name')
                }}</span>
                <span class="cursor-pointer"  @click="petitionlink(petition)">
                  <small> {{ checkProperty(petition ,'beneficiaryInfo','email') }} </small>
                </span>
              </td>
              <td class="td vs-table--td">
                <span :title="checkProperty(petition, 'createdByDetails', 'name')"><span class="cursor-pointer wrd-substr" @click="petitionlink(petition)">{{
                  checkProperty(petition, 'createdByDetails', 'name')
                }}</span></span>
              </td>
              <td class="td vs-table--td"><span @click="petitionlink(petition)">{{ checkProperty(petition, 'createdOn') |
                formatDate }}</span></td>
              <td class="td vs-table--td"><span><span @click="petitionlink(petition)" class="cursor-pointer">{{
                checkProperty(petition, 'updatedOn') | formatDate }}</span></span>
              </td>
              <td class="td vs-table--td">
                <span @click="petitionlink(petition)">

                  <span
                    v-if="checkProperty(petition, 'intStatusDetails', 'id') && checkProperty(petition, 'intStatusDetails', 'id') == 2"
                    class="statusspan cursor-pointer" v-bind:class="{
                      ' status_inProcess ': checkProperty(petition, 'intStatusDetails', 'id') == 2
                    }">{{ checkProperty(petition, 'intStatusDetails', 'name') }}
                </span>
                <span
                  v-if="(!checkProperty(petition, 'intStatusDetails', 'id') || (checkProperty(petition, 'intStatusDetails', 'id') && checkProperty(petition, 'intStatusDetails', 'id') != 2))"
                  class="statusspan cursor-pointer" v-bind:class="{
                    ' status_created ': checkProperty(petition, 'statusDetails', 'id') == 1 || checkProperty(petition, 'statusDetails', 'id') == 11,
                    ' status_submited ': checkProperty(petition, 'statusDetails', 'id') == 2,
                    ' status_inProcess ': checkProperty(petition, 'statusDetails', 'id') == 3,
                    ' status_verified ': checkProperty(petition, 'statusDetails', 'id') == 4,
                    ' status_registered ': checkProperty(petition, 'statusDetails', 'id') == 5,
                    ' status_submited-USCIS ': checkProperty(petition, 'statusDetails', 'id') == 6,
                    ' status_selected': checkProperty(petition, 'statusDetails', 'id') == 7,
                    ' status_not_selected ': checkProperty(petition, 'statusDetails', 'id') == 8,
                    ' status_denied': checkProperty(petition, 'statusDetails', 'id') == 9,
                    ' status_payment_failed ': checkProperty(petition, 'statusDetails', 'id') == 10,
                  }">{{ checkProperty(petition, 'statusDetails', 'name') }}
                  </span>
                </span>
              </td>
            </tr>

          </table>
        </div>
      </div>
      <div class="table_footer">
        <div class="vx-col  con-select pages_select" v-if="capRegistartionList.length > 0">
          <label class="typo__label">Per Page</label>
          <multiselect @input="changeperPage()" v-model="perpage" :options="perPeges" :multiple="false"
            :close-on-select="true" :clear-on-select="false" :preserve-search="true" placeholder="Per Page"
            :preselect-first="true">

          </multiselect>
          <span class="totla_list_count" v-if="totalCount"> Total <em>{{totalCount}}</em></span>
        </div>
        <paginate v-if="capRegistartionList.length > 0" v-model="page" :page-count="totalpages" :page-range="3"
          :margin-pages="2" :click-handler="pageNate"
          prev-class="vs-pagination--buttons btn-prev-pagination vs-pagination--button-prev"
          next-class="vs-pagination--buttons btn-next-pagination vs-pagination--button-next" :prev-text="'<i></i>'"
          :next-text="'<i></i>'" :container-class="'pagination vs-pagination--nav'" :page-class="'page-item'">
        </paginate>
      </div>
    </div>
    <vs-popup class="holamundo main-popup" title="Invite Customer" :active.sync="invitepetitioner">
      <addBenewPet @closenewPetPopup="closenewPetPopup" v-if="invitepetitioner" />
    </vs-popup>

    <vs-popup class="holamundo main-popup" :class="{ 'openedNewpetpopup': invitepetitioner }" :title="'Add Beneficiary'"
      :active.sync="AddBeneficiary">
      <addBeneficiary ref="add_ben" @closeAddBenPopUp="closeAddBenPopUp" v-if="AddBeneficiary"
        :petitioner="selectedPetitioner" @openAddpetPopUp="openAddpetPopUp" />
    </vs-popup>
    <!-- <vs-popup class="holamundo main-popup" title="Bulk Beneficiary" :active.sync="bulkBeneficiary">
        <bulkBeneficiary @closenBulkBenPopup="closenBulkBenPopup" v-if="bulkBeneficiary"
        :petitioner="selectedPetitioner" @openAddpetPopUp="openAddpetPopUp" :selectedBranch="selectedBranch" />
      </vs-popup> -->

    <modal name="newCapCreationModal" classes="v-modal-sec" :min-width="200" :min-height="200" :scrollable="true"
      :reset="true" width="1000px" height="auto">
      <div class="v-modal">
        <div class="popup-header fromDetailsPage">
          <h2 class="popup-title">
            New Case   

          </h2>
          <span @click="$modal.hide('newCapCreationModal'); NewPetition = false; uploading = false">
            <em class="material-icons">close</em>
          </span>
        </div>
        <form data-vv-scope="newCapCreationform" @submit.prevent="''">
          <div class="form-container" @click="capCreationErrors = ''">
            <div class="vx-row">
              <div class="vx-col w-1/2">
                <div class="form_group">
                  <div class="con-select w-full select-large">
                    <label class="form_label">Select Law Firm Location<em>*</em></label>
                    <multiselect name="branch" data-vv-as="Law Firm Location" v-validate="'required'"
                      v-model="selectedBranch" :show-labels="false" track-by="_id" label="name"
                      placeholder="Select Law Firm Location" :options="branchList" :searchable="true" :allow-empty="false"
                      :multiple="false"
                      :disabled="(branchList.length == 1 && checkProperty(selectedBranch, '_id') != '') || disableOffice"
                      @input="formerrors.msg = ''">
                    </multiselect>
                    <span class="text-danger text-sm" v-show="errors.has('newCapCreationform.branch')">{{
                      errors.first("newCapCreationform.branch")
                    }}</span>
                  </div>
                </div>
              </div>
              <template v-if="getTenantTypeId != 2">
                <div class="vx-col w-1/2" v-if="([3, 4, 5, 6, 7, 8].indexOf(getUserRoleId) > -1) && getTenantTypeId != 2">
                  <div class="form_group">
                    <div class="con-select w-full select-large">
                      <label class="form_label">Select Petitioner<em>*</em></label>
                      <multiselect v-model="selectedPetitioner" :options="petitionersList" :multiple="false"
                        :hideSelected="false" :close-on-select="true" :clear-on-select="false" :preserve-search="true"
                        :select-label="'Search Petitioner'" placeholder="Select Petitioner" label="name" track-by="name"
                        :preselect-first="false" data-vv-as="Petitioner" v-validate="'required'"
                        tag-placeholder="Invite Petitioner" :taggable="false" @tag="addNewPet" :searchable="true"
                        @search-change="searchPet" @input="petitionerUpdated" name="Petitioner">

                        <template slot="selection" slot-scope="{ values, isOpen }">
                          <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                            options selected</span>
                          <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                        </template>
                      </multiselect>

                      <span class="text-danger text-sm" v-show="errors.has('newCapCreationform.Petitioner')">{{
                        errors.first("newCapCreationform.Petitioner")
                      }}</span>
                    </div>
                  </div>
                  <p class="createnew">Not found? <span @click="addNewPet()">Invite Petitioner</span></p>
                </div>
                <!-- :class="{ 'w-full': [50].indexOf(getUserRoleId) > -1 } -->
                <div class="vx-col w-1/2" v-if="([3, 4, 5, 6, 7, 8, 50].indexOf(getUserRoleId) > -1)">
                  <div class="form_group">
                    <div class="con-select w-full select-large">
                      <label class="form_label">Select Beneficiary<em v-if="!bulkBeneficiary">*</em></label>
                      <multiselect v-model="selectedBeneficiary" :options="beneficiaryMasterDataList" :multiple="false"
                        :hideSelected="false" :close-on-select="true" :clear-on-select="false" :preserve-search="true"
                        :select-label="'Search Beneficiary'" placeholder="Select Beneficiary" label="name" track-by="name"
                        :preselect-first="false" data-vv-as="Beneficiary" v-validate="bulkBeneficiary ? '' : 'required'"
                        :searchable="true" @search-change="getbeneficiaryMasterDataList" name="beneficiary"
                        @input="upDateBenef" tag-placeholder="Add New Beneficiary" :taggable="false"
                        :disabled="(!checkProperty(selectedPetitioner, '_id') && [50].indexOf(getUserRoleId) <= -1)">

                        <template slot="selection" slot-scope="{ values, isOpen }">
                          <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                            options selected</span>
                          <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                        </template>
                      </multiselect>

                      <span class="text-danger text-sm" v-show="errors.has('newCapCreationform.beneficiary')">{{
                        errors.first("newCapCreationform.beneficiary")
                      }}</span>
                    </div>

                  </div>
                  <p class="createnew mb-4">Not found?<span
                      @click="bulkBeneficiary = true; selectedBeneficiary = null; $validator.reset() ">Invite
                      Beneficiary</span>
                    <!-- <span @click="bulkBeneficiary = true; selectedBeneficiary = null;$validator.reset() ">Invite more Beneficiaries</span>
                    clearMoreBen()
                    -->
                  </p>
                </div>
              </template>
              <template v-if="getTenantTypeId == 2">
                <div class="vx-col w-1/2" v-if="([3, 4, 5, 6, 7, 8, 50].indexOf(getUserRoleId) > -1)">
                  <div class="form_group">
                    <div class="con-select w-full select-large">
                      <label class="form_label">Select Beneficiary<em v-if="!bulkBeneficiary">*</em></label>
                      <multiselect v-model="selectedBeneficiary" :options="beneficiaryMasterDataList" :multiple="false"
                        :hideSelected="false" :close-on-select="true" :clear-on-select="false" :preserve-search="true"
                        :select-label="'Search Beneficiary'" placeholder="Select Beneficiary" label="name" track-by="name"
                        :preselect-first="false" data-vv-as="Beneficiary" v-validate="bulkBeneficiary ? '' : 'required'"
                        :searchable="true" @search-change="getbeneficiaryMasterDataList" name="beneficiary"
                        @input="upDateBenef" tag-placeholder="Add New Beneficiary" :taggable="false">

                        <template slot="selection" slot-scope="{ values, isOpen }">
                          <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                            options selected</span>
                          <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                        </template>
                      </multiselect>

                      <span class="text-danger text-sm" v-show="errors.has('newCapCreationform.beneficiary')">{{
                        errors.first("newCapCreationform.beneficiary")
                      }}</span>
                    </div>

                  </div>
                  <p class="createnew mb-4">Not found?<span
                      @click="bulkBeneficiary = true; selectedBeneficiary = null; $validator.reset() ">Invite
                      Beneficiary</span>
                    <!-- <span @click="bulkBeneficiary = true; selectedBeneficiary = null;$validator.reset() ">Invite more Beneficiaries</span>
                    clearMoreBen()
                    -->
                  </p>
                </div>
              </template>
            </div>

            <div class="vx-row">
              <template v-if="bulkBeneficiary">
                <div class="vx-col pb-5">
                  <div class="custom-radio custom-radio_btns">

                    <vs-radio class="mr-6" v-model="withAccount" vs-value='true' @change="updateAccount()">Create Account
                      for Beneficiary</vs-radio>
                    <vs-radio v-model="withAccount" vs-value="false" @change="updateAccount()">Continue without
                      Account</vs-radio>
                  </div>
                </div>

                <div class="vx-col w-full">

                  <form data-vv-scope="newinvitepetitionerform">
                    <div class="form-container p-0 px-3 invite_more_beneficiaries">
                      <div class="vx-row" v-for="(item, indexx) in newBeneficiary ">
                        <immiInput :display="true" :fieldsArray="[]" :cid="'firstName' + indexx"
                          formscope="newinvitepetitionerform" v-model="item.firstName"
                          :wrapclass="withAccount == 'false' || withAccount == false ? 'md:w-1/3' : 'md:w-1/4 '"
                          :required="isSlg" :fieldName="'firstName' + indexx" label="First Name"
                          placeHolder="First Name" />

                        <immiInput v-if="!isSlg" :display="true" :fieldsArray="[]" :cid="'middleName' + indexx"
                          :wrapclass="withAccount == 'false' || withAccount == false ? 'md:w-1/3' : 'md:w-1/4 '"
                          formscope="newinvitepetitionerform" v-model="item.middleName" :required="false"
                          :fieldName="'middleName' + indexx" label="Middle Name" placeHolder="Middle Name" />

                        <immiInput :display="true" :fieldsArray="[]" :cid="'lastName' + indexx"
                          :wrapclass="withAccount == 'false' || withAccount == false ? 'md:w-1/3' : 'md:w-1/4 '"
                          formscope="newinvitepetitionerform" v-model="item.lastName" :required="true"
                          :fieldName="'lastName' + indexx" label="Last Name" placeHolder="Last Name" />

                        <template v-if="withAccount == true || withAccount == 'true'">
                          <immiInput :display="true" :fieldsArray="[]" datatype="email"
                            :wrapclass="'md:w-1/4 email_input'" :cid="'email' + indexx"
                            formscope="newinvitepetitionerform" v-model="item.email" :required="true"
                            :fieldName="'email' + indexx" label="Email" placeHolder="Email" />

                          <immiPhone v-if="isSlg" :display="true"
                            @updatephoneCountryCode="updatecellPhoneCountryCodee($event, indexx)" :fieldsArray="[]"
                            :wrapclass="'md:w-1/4 '" :countrycode="item.phoneCountryCode.countryCode"
                            :cid="'phone' + indexx" formscope="newinvitepetitionerform" v-model="item.phone"
                            :fieldName="'phone' + indexx" :required="false" label="Phone Number"
                            placeHolder="Phone Number" />
                        </template>
                        <div class="delete" v-if="newBeneficiary.length > 1" @click="removeBenField(indexx)">
                          <a>
                            <img src="@/assets/images/main/delete-row-img.svg" />
                          </a>
                        </div>
                      </div>
                      <vs-row class="more_btn_wrap">
                        <vs-col class="float-none pl-0 pt-0 pb-5 more_btn" vs-type="flex" vs-align="center">
                          <a @click="addMore()" class="add-more ml-0" type="filled">
                            <span>+</span> More
                          </a>
                        </vs-col>
                      </vs-row>
                    </div>
                  </form>

                </div>
              </template>


            </div>
            <div class="text-danger text-sm formerrors custom_margin" v-show="capCreationErrors">
              <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
                icon="IP-information-button" active="true">{{ capCreationErrors }}</vs-alert>
            </div>
          </div>

          <div class="popup-footer relative">
            <vs-button color="dark" @click="$modal.hide('newCapCreationModal')" class="cancel"
              type="filled">Cancel</vs-button>
            <!-- <vs-button color="success" class="save" type="filled" @click="createNewCap()">Submit
            </vs-button> -->
            <vs-button :disabled="newCapFormSubmited" color="success" class="save" type="filled" @click="createNewCap()">
              <figure v-if="newCapFormSubmited" class="loader loader-btn"><img src="@/assets/images/main/loader.gif" />
              </figure>
              Submit
            </vs-button>
          </div>
        </form>
      </div>
    </modal>

    <vs-popup class="holamundo main-popup  confirm_modal"  title="New registration" :active.sync="showCapErrorCreatioInfo">
      <div class="form-container">
        <div class="vx-row">
          <div class="vx-col w-full text-center">
          
          <vs-alert class="primary-alert mb-1" style="height: auto;">New registrations are not currently allowed.</vs-alert>
          
            
          </div>
          
        </div>

              
       
      </div>
      <div class="popup-footer relative">
       
        <template >
               
          <vs-button  color="success" @click="showCapErrorCreatioInfo=false;"  class="save"  type="filled"> Ok</vs-button>
        </template> 
        </div>
    </vs-popup>




  </div>
</template>
<script>
import immiPhone from "@/views/forms/fields/phonenumber.vue";
import immiInput from "@/views/forms/fields/simpleinput.vue";
//import bulkBeneficiary from "@/views/cap/bulkBeneficiaryInvite.vue"
import Paginate from "vuejs-paginate";
import moment from 'moment'
import _ from "lodash";
import Vue from 'vue'
import NoDataFound from "@/views/common/noData.vue";
import Multiselect from "vue-multiselect-inv";
import JQuery from "jquery";
import addBenewPet from "@/views/common/invitePet.vue"
import addBeneficiary from "@/views/common/addBeneficiary.vue"
//import addBeneficiary  from "@/views/common/addBeneficiary.vue" 
//import addPetitioner  from "@/views/common/addPetitioner.vue" 
import DateRangePicker from "vue2-daterange-picker";
import Datepicker from "vuejs-datepicker-inv";
import "vue2-daterange-picker/dist/vue2-daterange-picker.css";
//import JsonExcel from "vue-json-excel";
//Vue.component("downloadExcel", JsonExcel);
export default {
  provide() {
    return {
      parentValidator: this.$validator,
    };
  },
  watch: {
    "$store.state.manageCapRegistrations":function(value){
            this.showCapRegistrations =value;
        },
    searchtxt: function (value) {
      let text = value.trim();

      if (text.length > 3 || text == '') {
        this.getCapList(true, false);
      }

    },
  },
  data: function () {
    return {
      showCapRegistrations:false,
      debounce:null,
      canRegCap:null,
      showCapErrorCreatioInfo:false,
      isSlg: true,
      capCreationErrors: '',
      newCapFormSubmited: false,
      withAccount: 'true',
      newBeneficiary: [
        {
          firstName: '',
          middleName: '',
          lastName: '',
          name: "",
          email: "",
          phone: "",
          phoneCountryCode: { countryCode: '', countryCallingCode: '' }
        },
      ],
      bulkBeneficiary: false,
      jsonData: [
        { "name": "SR", "email": 'ravis@innvectra.com' },
        { "name": "Ravi Kumar", "email": 'ravi@innvectra.com' }
      ],
      formerrors: {
        msg: ''
      },
      headerSelectedCaseTypes: [],
      selectedSeasons: [],
      selectedpremiumProcessing: [],
      premiumProcessingList: [{ name: 'Yes', _id: true }, { name: 'No', _id: false }],
      selectedStatus: [],
      caseStatusList: [],
      selectedEducations: [],
      education_types: [],
      selectedtypeNames: [],
      headerTypeNames: [],
      autoApply: '',
      disableOffice: false,
      branchList: [],
      selectedBranch: null,
      premiumProcessing: false,
      petitionersList: [],
      beneficiaryMasterDataList: [],
      selectedPetitioner: null,
      selectedBeneficiary: null,
      selectedUsername: null,
      selectedUser: null,
      capRegistartionList: [],
      sortKeys: {},
      sortKey: {},
      page: 1,
      perpage: 25,
      totalpages: 0,
      totalCount:0,
      perPeges: [10, 25, 50, 75, 100],
      callFromSearch: false,
      isListloading: false,
      filter_searchtxt: '',
      searchtxt: '',
      header_selected_petitioners: [],
      selected_peritioners: [],
      final_selected_peritioners: [],
      encodedString: '',
      selected_createdDateRange: ["", ""],
      /////
      enableNextBtn: false,
      selectAllForArchive: false,
      selectedItem: false,
      value: null,
      values: null,
      capvalues: null,
      Petitioner: null,

      selected: null,
      selecte: null,
      AddBeneficiary: false,
      addPetitionerr: false,
      addcprbeneficiary: false,
      NewPetition: false,
      anonymousUser: false,
      options: ['10th / 12th Grade', 'Bachelors', 'Associate', 'Masters'],
      optionscase: ['Active', 'In active'],
      cap: [{ "name": 'Master Cap', "id": true, },
      { "name": 'Regular Cap', "id": false, }],
      Petitioneroptions: ['James', 'Michael'],
      caps: ['Master Cap', 'Regular Cap'],
      Petitioners: ['James', 'Michael'],
      season: [],
      fromUserList: ['Created', 'Sent for Petitioner Authorization', 'Petitioner Confirmation', 'Attorney Approval', 'Receipt of Payment Made', 'Submitted to USCIS', 'Selected', 'Petition Created'],
      //beneficiaryMasterDataList:['Rahul krishna' , 'Sathish'],
      PetitionerMasterDataList: ['Rahul krishna', 'Sathish'],

      selected_deadLineDateRange: ["", ""],
      wiseSelection: 'true',
    }
  },
  components: {
    immiPhone,
    immiInput,
    //bulkBeneficiary,
    Multiselect,
    Paginate,
    NoDataFound,
    addBeneficiary,
    addBenewPet,
    //addBeneficiary,
    //addPetitioner,
    Datepicker,
    DateRangePicker,

  },
  methods: {
    getglobalConfig(){

      this.$store.dispatch("commonAction", {data:{},path:'global-config/details'})
        .then((response) =>{ 
                if(this.checkProperty(response ,"config"  )){
                    this.showCapRegistrations = this.checkProperty(response ,'config','manageCapRegistrations')?true:false
                                        
                }
            })

    },
    openCreateCasePopup(action) {
      this.capCreationErrors = '';
      this.newCapFormSubmited = false;
      this.bulkBeneficiary = false;
      this.disableOffice = false;
      this.NewPetition = action;
      this.selectedPetitioner = null;
      this.selectedBeneficiary = null;
      this.selectedUsername = null;
      this.selectedUser = null;
      this.premiumProcessing = false;
      this.newBeneficiary = [
        {
          firstName: '',
          middleName: '',
          lastName: '',
          name: "",
          email: "",
          phone: "",
          phoneCountryCode: { countryCode: '', countryCallingCode: '' }
        },
      ];
      this.selectedBranch = null;
      if ([3, 4, 50].indexOf(this.getUserRoleId) <= -1) {
        if (this.checkProperty(this.getUserData, 'branchDetails')) {
          let branchDetails = this.checkProperty(this.getUserData, 'branchDetails')
          this.selectedBranch = { "name": '', '_id': '' };
          this.selectedBranch['name'] = branchDetails['name'];
          this.selectedBranch['_id'] = branchDetails['_id'];
          this.disableOffice = true;
        } else if (this.branchList && this.branchList.length == 1) {
          this.selectedBranch = this.branchList[0]
        }
      } else if (this.branchList && this.branchList.length == 1) {
        this.selectedBranch = this.branchList[0]
      }
      this.showCapErrorCreatioInfo = false;
      if(this.canRegCap ==false){
        this.showCapErrorCreatioInfo = true;
      }else{
        
      
      this.$modal.show('newCapCreationModal');
      this.$validator.reset();
     }
    },
    checkCapRegcase(callFrommounted=false){
      this.showCapErrorCreatioInfo =false;
      this.canRegCap = false;
      this.$store.dispatch("commonAction", { "data": {}, "path": "/cap-registrations/can-create-case" }).then((response) => {
        this.canRegCap = response;
        
          if (callFrommounted && this.$route.params && this.$route.params.openCreatePopup) {
          var _s = this;
          setTimeout(() => {
          _s.openCreateCasePopup(false);
          
          }, 600)
          }
        
        
        })
    },
    updateAccount() {
      let tempList = [];
      _.forEach(this.newBeneficiary, (item) => {
        item['email'] = ''
        item['phone'] = ''
        item['phoneCountryCode'] = {
          countryCode: '',
          countryCallingCode: ''
        }
        tempList.push(item)
      })
      if (tempList && this.checkProperty(tempList, 'length') > 0) {
        this.newBeneficiary = tempList
      }
    },
    getSeasonsYears(){
        // let currentYear = parseInt(moment().year());
        // let seasonYear = 2023
        // for (let i = seasonYear; i<= currentYear; i++) {
        //    let year = i+1
        //   this.season.push(year);
        // }
        // this.season = this.season.reverse()


        this.$store.dispatch("getList", {
                data: {  today: moment().format('YYYY-MM-DD') },
                path: "/cap-registrations/get-season-year-list",
            })
            .then((response) => {
                if(response && this.checkProperty(response,'length') >0 ){
                   
                  this.season = response
                }
            });
    },
    getCapList(callFromSearch = false, callFromFilter = false) {

      this.callFromSearch = callFromSearch
      if (this.callFromSearch) {
        this.capRegistartionList = []
      }
      //'623b3c3c75d58329b830cdcd','625e6857cadbc43c50c92ee7','628f6b6b096c8624d886648b'
      let Payload = {
        matcher: {
          searchString: this.searchtxt,
          petitionerIds: this.final_selected_peritioners,
          beneficiaryIds: [],
          statusIds: [],
          statusList: [],
          branchIds: [],
          typeNames: [],
          seasonList: [],
          capTypeList: [],
          premiumProcessing: [],
          intStatusIds: [],
          // getForReport:true
        },
        page: this.page,
        perpage: this.perpage,
        sorting: this.sortKey,
        today: moment().format('YYYY-MM-DD'),
      }
      if (this.selectedSeasons && this.checkProperty(this.selectedSeasons, 'length') > 0) {
        Payload['matcher']['seasonList'] = this.selectedSeasons
      }
      if (this.selectedpremiumProcessing && this.checkProperty(this.selectedpremiumProcessing, 'length') > 0) {
        Payload['matcher']['premiumProcessing'] = this.selectedpremiumProcessing.map((item) => item._id)
      }
      if (this.selectedStatus && this.checkProperty(this.selectedStatus, 'length') > 0) {
        // let templist = [];
        // templist = this.selectedStatus.map((item) => item.id)
        // _.forEach(templist, (item) => {
        //   if (parseInt(item) < 90) {
        //     Payload['matcher']['statusIds'].push(item)
        //   } else {
        //     Payload['matcher']['intStatusIds'].push(item)
        //   }
        // })
        Payload['matcher']['statusIds'] = this.selectedStatus.map((item) => item.id)
      };
      if (this.selectedtypeNames) {
        Payload['matcher']['capTypeList'] = this.selectedtypeNames.map((item) => item.id)
      }
      let tempObj={
        selectedStatus:this.selectedStatus,
        selectedtypeNames:this.selectedtypeNames,
        selectedSeasons:this.selectedSeasons,
        selectedpremiumProcessing:this.selectedpremiumProcessing,
        selected_peritioners:this.selected_peritioners,
        searchtxt:this.searchtxt,
        filter_searchtxt:this.filter_searchtxt,
        page: this.page,
        perpage: this.perpage,
        sortKey: this.sortKey,
      };
      this.setQueryString(tempObj);
      this.isListloading = true;
      this.updateLoading(true);
      this.$store.dispatch("commonAction", { "data": Payload, "path": "/cap-registrations/list" }).then((response) => {
        this.isListloading = false;
        this.updateLoading(false);
        this.capRegistartionList = response.list
        this.totalCount = this.checkProperty(response, 'totalCount')
        this.totalpages = Math.ceil(response.totalCount / this.perpage)
        setTimeout(() => {
          this.updateLoading(false);
        }, 10);
      })
        .catch((err) => {
          this.isListloading = false;
          this.updateLoading(false);
        })
    },
    setQueryString(obj){
      const string = JSON.stringify(obj) // convert Object to a String
      this.encodedString = btoa(string) // Base64 encode the String
      this.$route['query']['filter'] = this.encodedString;
    },
    filterQueryPreSelect(callFromMounted=false){
      if(this.checkProperty(this.$route ,'query' ,'filter')){
        try{
          let filter =this.$route['query']['filter']; this.checkProperty(this.$route ,'query' ,'filter')
          var actual = JSON.parse(atob(filter));
          let keys = Object.keys(actual);
          if(this.checkProperty(keys ,'length') >0 ){
            if(_.has(actual ,'page') && this.checkProperty(actual ,'page')){                                     
              this.page = this.checkProperty(actual ,'page');
            }
            if(_.has(actual ,'perpage') && this.checkProperty(actual ,'perpage')){                                     
              this.perpage = this.checkProperty(actual ,'perpage');
            }
            if(_.has(actual ,'sortKey') && this.checkProperty(actual ,'sortKey')){   
              if(this.sortKeys){
                this.sortKeys[actual['sortKey']['path']] = actual['sortKey']['order']
              }                                  
              this.sortKey = this.checkProperty(actual ,'sortKey');
            }
            if(_.has(actual ,'selectedStatus') && this.checkProperty(actual ,'selectedStatus') && this.checkProperty(actual ,'selectedStatus', 'length')>0){                                     
              this.selectedStatus = this.checkProperty(actual ,'selectedStatus');
            } 
            if(_.has(actual ,'selectedSeasons') && this.checkProperty(actual ,'selectedSeasons') && this.checkProperty(actual ,'selectedSeasons', 'length')>0){                                     
              this.selectedSeasons = this.checkProperty(actual ,'selectedSeasons');
            }
            if(_.has(actual ,'selected_peritioners') && this.checkProperty(actual ,'selected_peritioners') && this.checkProperty(actual ,'selected_peritioners', 'length')>0){                                     
              this.selected_peritioners = this.checkProperty(actual ,'selected_peritioners');
              this.changedperitioners();
            }
            if(_.has(actual ,'header_selected_petitioners') && this.checkProperty(actual ,'header_selected_petitioners') && this.checkProperty(actual ,'header_selected_petitioners', 'length')>0){                                     
              this.header_selected_petitioners = this.checkProperty(actual ,'header_selected_petitioners');
            }
            if(_.has(actual ,'selectedpremiumProcessing') && this.checkProperty(actual ,'selectedpremiumProcessing') && this.checkProperty(actual ,'selectedpremiumProcessing', 'length')>0){                                     
              this.selectedpremiumProcessing = this.checkProperty(actual ,'selectedpremiumProcessing');
            }
            if(_.has(actual ,'selectedtypeNames') && this.checkProperty(actual ,'selectedtypeNames') ){                                     
              this.selectedtypeNames = this.checkProperty(actual ,'selectedtypeNames');
            }
            if(_.has(actual ,'searchtxt') && this.checkProperty(actual ,'searchtxt') ){                                     
              this.searchtxt = this.checkProperty(actual ,'searchtxt');
            }
            if(_.has(actual ,'filter_searchtxt') && this.checkProperty(actual ,'filter_searchtxt') ){                                     
              this.filter_searchtxt = this.checkProperty(actual ,'filter_searchtxt');
            }
            this.set_filter();
          }else{
            this.set_filter();
          }
        }catch(e){
          if(callFromMounted){
            this.set_filter();
          }
        }   
      }
      else{
        if(callFromMounted){
            this.set_filter();
        }
      } 
    },
    addMore() {
      this.$validator.validateAll("newinvitepetitionerform").then((result) => {
        if (result) {
          let obj = {
            firstName: '',
            middleName: '',
            lastName: '',
            name: "",
            email: "",
            phone: "",
            phoneCountryCode: { countryCode: '', countryCallingCode: '' }
          }
          this.newBeneficiary.push(obj);
          this.$validator.reset("newinvitepetitionerform");
        }
      })
    },
    removeBenField: function (index) {
      this.newBeneficiary.splice(index, 1);
    },
    updatecellPhoneCountryCodee(data = '', index = '') {
      this.newBeneficiary[index]['phoneCountryCode'] = data
    },
   
    createNewCap() {
      if (this.bulkBeneficiary) {
        this.$validator.validateAll('newinvitepetitionerform').then(result => { })
      }
      this.$validator.validateAll('newCapCreationform').then(result => {
        if (result) {
          if (this.bulkBeneficiary) {
            this.$validator.validateAll('newinvitepetitionerform').then(result => {
              if (result) {
                let payLoad = {
                  beneficiariesList: [],
                  today: moment().format('YYYY-MM-DD'),
                  branchId: '',
                  petitionerId: '',
                };
                if (this.getTenantTypeId != 2) {
                  if ([50].indexOf(this.getUserRoleId) > -1) {
                    payLoad['petitionerId'] = this.$store.state.user._id

                  } else {
                    payLoad['petitionerId'] = this.checkProperty(this.selectedPetitioner, "userId")
                  }
                }
                if (this.selectedBranch && _.has(this.selectedBranch, "_id")) {
                  payLoad['branchId'] = this.selectedBranch['_id']
                }
                if (this.withAccount == 'true' || this.withAccount == true) {
                  _.forEach(this.newBeneficiary, (item) => {
                    if (_.has(item, 'name')) {
                      if (_.has(item, 'middleName') && this.checkProperty(item, 'middleName')) {
                        item['name'] = item['firstName'].trim() + " " + item['middleName'].trim() + " " + item['lastName'].trim();
                      }
                      else {
                        item['name'] = item['firstName'].trim() + " " + item['lastName'].trim();
                      }
                    }
                    payLoad['beneficiariesList'].push(item)
                  })
                }
                if (this.withAccount == 'false' || this.withAccount == false) {
                  _.forEach(this.newBeneficiary, (item) => {
                    if (_.has(item, 'name')) {
                      //item['name'] = item['firstName'].trim() + " " + item['middleName'].trim() + " " + item['lastName'].trim();
                      if (_.has(item, 'middleName') && this.checkProperty(item, 'middleName')) {
                        item['name'] = item['firstName'].trim() + " " + item['middleName'].trim() + " " + item['lastName'].trim();
                      }
                      else {
                        item['name'] = item['firstName'].trim() + " " + item['lastName'].trim();
                      }
                      item['email'] = ''
                      item['phone'] = ''
                      item['phoneCountryCode'] = {
                        countryCode: '',
                        countryCallingCode: ''
                      }
                    }
                    payLoad['beneficiariesList'].push(item)
                  })
                }
                this.newCapFormSubmited = true;
                let path = '/cap-registrations/bulk-create'
                this.$store.dispatch("commonAction", { "data": payLoad, "path": path })
                  .then((response) => {
                    this.newCapFormSubmited = false;
                    this.NewPetition = false;
                    this.$modal.hide('newCapCreationModal')
                    this.openCreateCasePopup(false)
                    this.getCapList()
                    this.showToster({ message: response.message, isError: false });
                  }).catch((err) => {
                    this.capCreationErrors = err;
                    this.newCapFormSubmited = false;
                  })
              }
            })
          }

          else {
            let Payload = {
              userId: "",
              userName: "",
              today: moment().format('YYYY-MM-DD'),
              branchId: "",
              petitionerId: "",
            }
            if (this.selectedUser) {
              Payload['userId'] = this.selectedUser
            }
            if (this.selectedUsername) {
              Payload['userName'] = this.selectedUsername
            }
            if (this.getTenantTypeId != 2) {
              if ([50].indexOf(this.getUserRoleId) > -1) {
                Payload['petitionerId'] = this.$store.state.user._id

              } else {
                Payload['petitionerId'] = this.checkProperty(this.selectedPetitioner, "userId")
              }
            }
            if (this.selectedBranch && _.has(this.selectedBranch, "_id")) {
              Payload['branchId'] = this.selectedBranch['_id']
            }
            this.newCapFormSubmited = true;
            let path = '/cap-registrations/create'
            this.$store.dispatch("commonAction", { "data": Payload, "path": path })
              .then((response) => {
                this.newCapFormSubmited = false;
                this.NewPetition = false;
                this.$modal.hide('newCapCreationModal')
                this.openCreateCasePopup(false)
                this.getCapList()
                this.showToster({ message: response.message, isError: false });
                if (this.checkProperty(response, '_id')) {
                  let routedId = this.checkProperty(response, '_id')
                  setTimeout(() => {
                    this.$router.push({ path: `/cap-registration-details/${routedId}`, query: { 'filter': this.encodedString } })
                  })
                }
              })
              .catch((err) => {
                this.newCapFormSubmited = false;
                this.capCreationErrors = err;
              })
          }

        }
      })
    },
    clearMoreBen() {
      this.bulkBeneficiary = false;
      this.newBeneficiary = [
        {
          firstName: '',
          lastName: '',
          name: "",
          email: "",
          phone: "",
          phoneCountryCode: { countryCode: '', countryCallingCode: '' }
        },
      ];

    },
    changedCaseTypes() {
      this.selectedtypeNames = this.headerTypeNames
      if (this.selectedtypeNames) {
        this.set_filter();
      }
    },
    pageNate(pageNum) {

      this.page = pageNum;
      this.getCapList();
    },
    changedperitioners() {
      this.$router.push({ query: {} })
      this.final_selected_peritioners = [];
      if (this.selected_peritioners.length > 0) {
        for (let i = 0; i < this.selected_peritioners.length; i++) {
          this.final_selected_peritioners.push(
            this.selected_peritioners[i]["userId"]
          );
        }
      }
      //this.get_peritioners_beneficiaries();
    },
    changedperitionersSearch() {
      this.selected_peritioners = this.header_selected_petitioners
      this.$router.push({ query: {} })
      this.final_selected_peritioners = [];
      if (this.selected_peritioners.length > 0) {
        for (let i = 0; i < this.selected_peritioners.length; i++) {
          this.final_selected_peritioners.push(
            this.selected_peritioners[i]["userId"]
          );
        }
      }
      this.set_filter();
    },
    peritioners_search_fun(searchText) {
      clearTimeout(this.debounce)
        this.debounce = setTimeout(() => {
          this.getPetitioners(true, searchText);
        }, 900)
      
      //this.peritioners_search_value = searchValue;
      //this.get_peritioners();
    },
    changeperPage() {
      this.page = 1;
      localStorage.setItem('petitions_perpage', this.perpage);
      this.getCapList(true);
    },
    sortMe(sort_key = '') {
      if (sort_key != '') {
        this.sortKeys[sort_key] = this.sortKeys[sort_key] == 1 ? -1 : 1
        this.sortKey = {};
        this.sortKey = { "path": sort_key, "order": this.sortKeys[sort_key] }
        localStorage.setItem('petitions_sort_key', sort_key);
        localStorage.setItem('petitions_sort_value', this.sortKey[sort_key]);
        this.getCapList();
      }
    },
    getBranchList() {

      this.branchList = [];
      let item = {
        filters: {
          "title": '',
          "createdDateRange": [],
          "statusList": [],
          "activeList": [],
          "countryIds": [],
          "stateIds": [],
          "locationIds": []
        },
        getMasterData: true,
        page: 1,
        perpage: 1000,
        sorting: { "path": "createdOn", "order": -1 },

      };
      this.$store
        .dispatch("getList", { "data": item, "path": "/branch/list" })
        .then(response => {

          this.branchList = response.list;
          if (this.branchList.length == 1) {
            this.selectedBranch = this.branchList[0];
          }
        }).catch((error) => {
          this.branchList = [];
        })
    },
    getSeasons() {
      this.set_filter()
    },
    upDateBenef() {
      this.clearMoreBen()
      if (this.checkProperty(this.selectedBeneficiary, 'name') && this.checkProperty(this.selectedBeneficiary, '_id')) {
        this.selectedUser = this.checkProperty(this.selectedBeneficiary, '_id');
        this.selectedUsername = this.checkProperty(this.selectedBeneficiary, 'name');
      }
    },
    set_filter: function () {
      this.searchtxt = this.filter_searchtxt;
      this.getCapList();
      this.headerTypeNames = this.selectedtypeNames;
      this.header_selected_petitioners = this.selected_peritioners
      this.$refs["filter_menu"].dropdownVisible = false;
    },
    clear_filter: function () {
      this.selectedSeasons = [];
      this.selectedStatus = [];
      this.selectedpremiumProcessing = [];
      this.selectedtypeNames = [];
      this.final_selected_peritioners = [];
      this.selected_peritioners = [];
      this.searchtxt = '';
      this.filter_searchtxt = '';
      this.getCapList();
      this.headerTypeNames = [];
      this.header_selected_petitioners = [];
      this.selected_createdDateRange["startDate"] = "";
      this.selected_createdDateRange["endDate"] = "";
      this.$refs["filter_menu"].dropdownVisible = false;
    },
    petitionerUpdated() {
      this.selectedBeneficiary = null;
      this.selectedUser = '';
      this.selectedUsername = '';
      this.getbeneficiaryMasterDataList();
    },
    getbeneficiaryMasterDataList(text = '') {
      let postData = {
        "matcher": {
          "title": text,
          "statusList": [],
          "branchIds": [],
          "companyIds": [], // Required only for Tenant Admin and Branch Manager to list Beneficiaries
          "createdByIds": [],
          "createdDateRange": [],
          "roleIds": [51],
          "statusIds": [],
          "petitionTypeIds": [],
          "petitionSubTypeIds": [],
          "petitionCreatedDateRange": [],
          "petitionStatusIds": [],
          "getPetitionStats": true
        },
        "sorting": {
          "path": "createdOn", // invitedByName, updatedOn, name, email, phone, statusName, roleName
          "order": 1
        },
        "page": 1,
        "perpage": 1000000,
        "getMasterData": true,
        "getBeneficiaryList": true, // Required only for Tenant Admin and Branch Manager to list Beneficiaries
        "branchId": "", // Required when 'getMasterData' is true and roleIds are [4, 5, 6, 7, 8, 9, 10, 11]
        "companyId": "" // Required when 'getMasterData' is true and roleIds are [50, 51]
      };

      this.enableAddNewBenTag = false;
      if (this.checkProperty(this.selectedPetitioner, "_id")) {

        postData['companyId'] = this.selectedPetitioner['_id']

      }
      if ([50, 51].indexOf(this.getUserRoleId) > -1) {

        postData['companyId'] = this.checkProperty(this.getUserData, "companyDetails", "_id")
      }
      //this.beneficiaryMasterDataList =[];
      this.$store
        .dispatch("petitioner/getbeneficiaries", postData)
        .then(response => {
          this.beneficiaryMasterDataList = response.list;

          let filteredData = [];
          _.forEach(this.beneficiaryMasterDataList, (item) => {
            if (item && (_.has(item, 'name') || _.has(item, 'email'))) {

              if ((_.has(item, 'name') && item['name'].includes(text)) || (_.has(item, 'email') && item['email'].includes(text))) {
                filteredData.push(item)
              } else {
                return false;
              }

            } else {
              return false;
            }


          })

          //  if(filteredData.length<=0){
          //    this.enableAddNewBenTag =true;
          //  }


        })

    },
    petitionlink(tr) {
      let routedId = this.checkProperty(tr, '_id')
      //this.$router.push('/cap-registration-details/'+this.checkProperty( tr,'_id'))ap-registration-questionnaire
      this.$router.push({ path: `/cap-registration-details/${routedId}`, query: { 'filter': this.encodedString } })
      //this.$router.push({path: `/cap-registration-questionnaire/${routedId}` ,query: {'filter':this.encodedString} })    
    },
    selectedForNext() {
      let selectedCaps = _.filter(this.capList, { "isSelected": true });
      if (selectedCaps && this.checkProperty(selectedCaps, 'length') > 0) {
        this.enableNextBtn = true;
        this.selectAllForArchive = false
      }

      else {
        this.enableNextBtn = false;
        this.selectAllForArchive = false
      }
    },
    selectedAllForNext() {
      if (this.selectAllForArchive) {
        _.map(this.capList, (item) => { item['isSelected'] = true })
        this.enableNextBtn = true;
      }
      else {
        _.map(this.capList, (item) => { item['isSelected'] = false })
        this.enableNextBtn = false;
      }
    },
    updatecellPhoneCountryCode(data) {
      this.beneficiary['phoneCountryCode'] = data
    },
    updateSelection() {

      if (this.wiseSelection == 'true') {
        this.anonymousUser = false;


      } else {
        this.anonymousUser = true;
        this.beneficiary.email = '';
        this.beneficiary.phone = ''
        this.beneficiary.phoneCountryCode = { countryCode: '', countryCallingCode: '' };
      }

      // this.resetForm();
    },
    setPetDetails(selectedPetitioner = null) {

      this.selectedPetitioner = selectedPetitioner
    },
    addNewBeneficiary() {
      this.selectedPetitioner = null;
      this.beneficiary = {
        firstName: '',
        lastName: '',
        name: "",
        email: "",
        phone: "",
        phoneCountryCode: { countryCode: '', countryCallingCode: '' }
      }
      Object.assign(this.formerrors, {
        msg: ''
      });

      this.AddBeneficiary = true;
      this.$validator.reset();
      this.isPhoneValid = true;
      this.saveBenbtn = false;


    },
    updatePhone(item) {

      this.isPhoneValid = true;

      if (item.isValid) {

        this.beneficiary.phoneCountryCode = { countryCode: item.countryCode, countryCallingCode: item.countryCallingCode };
        this.beneficiary.phone = item.nationalNumber;

      } else {
        if (this.count > 5)
          this.isPhoneValid = false;
      }
      this.count++;
    },
    savebeneficiary() {
      this.$validator.validateAll().then(result => {

        this.saveBenbtn = false;
        if (result) {
          let self = this;
          this.beneficiary = Object.assign(this.beneficiary, { "roleId": 51 });
          this.beneficiary['name'] = this.beneficiary['firstName'].trim() + " " + this.beneficiary['lastName'].trim();
          this.beneficiary['firstName'] = this.beneficiary['firstName'].trim();
          this.beneficiary['lastName'] = this.beneficiary['lastName'].trim();
          this.beneficiary['name'] = this.beneficiary['name'].trim();
          this.saveBenbtn = true;
          let postData = this.beneficiary;
          if (this.checkProperty(this.selectedIItem, '_id')) {
            postData['userId'] = this.checkProperty(this.selectedIItem, '_id')
            postData['accountType'] = "Individual"
          }
          if (this.selectedIItem == null) {
            if (self.selectedPetitioner && _.has(self.selectedPetitioner, "_id")) {
              postData = Object.assign(postData, { "companyId": self.selectedPetitioner['_id'] })
            }
          }
          let path = "/users/register"
          if (this.checkProperty(this.selectedIItem, '_id')) {
            path = "/users/invite-temp-user-to-individual"
          }

          this.$store
            .dispatch("commonAction", { "data": postData, "path": path })
            .then(response => {
              this.saveBenbtn = false;
              if (response.error) {

                Object.assign(this.formerrors, {
                  msg: response.error.message
                });
              } else {

                this.AddBeneficiary = false;
                this.selectedBeneficiary = response
                this.showToster({ message: response.message, isError: false });
                //this.closeAddBenPopUp();
              }

              // this.$router.go('/beneficiaries');
            })
            .catch((err) => {

              this.saveBenbtn = false;
              //this.showToster({message:err,isError:true })
              Object.assign(this.formerrors, {
                msg: err
              });

            });
        }
      });
    },
    searchPet(searchText) {
      let _self = this;

      this.enableAddNewpet = false;
      let filteredData = [];
      _.forEach(_self.petitionersList, (item) => {
        if (item && (_.has(item, 'name') || _.has(item, 'email'))) {

          if ((_.has(item, 'name') && item['name'].includes(searchText)) || (_.has(item, 'email') && item['email'].includes(searchText))) {
            filteredData.push(item)
          } else {
            return false;
          }

        } else {
          return false;
        }


      })
      if ((filteredData.length <= 0)) {

        //this.enableAddNewpet =true;
        // this   this.addNewPete = true;
        this.getPetitioners(true, searchText);
      }

    },
    getPetitioners(callFromSerch = false, searchText = '') {

      let _self = this;
      let query = {
        "matcher": {
          "searchString": searchText,
          "statusIds": [],
          "countryIds": [],
          "stateIds": [],
          "locationIds": [],
          "createdDateRange": []
        },
        "sorting": { "path": "createdOn", "order": 1 },
        "page": 1,
        "perpage": 100,
        getMasterData: true
      }


      this.$store.dispatch("getList", { data: query, path: '/company/list' }).then(response => {

        _self.petitionersList = response.list;

      }).catch((err) => {
        this.petitionersList = [];

      })
    },
    addNewPet(newPet = '', id) {
      this.newPetOpenFromben = false;
      this.openNewbenForm = false;
      this.addNewPete = true;
      this.invitePetitionPopupshow(true)
    },
    closenewPetPopup(selectedPetitioner = null) {
      this.getPetitioners();
      this.selectedPetitioner = selectedPetitioner;
      this.invitePetitionPopupshow(false);
      this.openNewbenFormPopup(true);
    },
    invitePetitionPopupshow(action = true) {
      this.invitepetitioner = action;

      if (!action) {
        this.selectedBeneficiary = null;
      }


    },
    openNewbenFormPopup(action = false) {
      this.saveBenbtn = false;
      if (action == true) {
        this.invitePetitionPopupshow(false);
      }
      if (action) {
        if (this.checkProperty(this.selectedPetitioner, 'userId')) {
          this.AddBeneficiary = true;
          try {
            setTimeout(() => {
              this.$refs['add_ben'].setPetDetails(this.selectedPetitioner)
            }, 50)
          } catch (e) {}
        } else {
          this.AddBeneficiary = false;
        }
      } else {
        this.AddBeneficiary = action;
      }
      this.$validator.reset();
    },
    // addNewPet(){
    //    this.$emit("openAddpetPopUp" );
    // },
    openAddpetPopUp() {

      this.selectedPetitioner = null;
      this.invitepetitioner = true;
    },
    closeAddBenPopUp(selectedBeneficiary = null) {

      this.AddBeneficiary = false;
      this.selectedBeneficiary = selectedBeneficiary;
      if (this.checkProperty(this.selectedBeneficiary, 'name') && this.checkProperty(this.selectedBeneficiary, '_id')) {
        this.selectedUser = this.checkProperty(this.selectedBeneficiary, '_id');
        this.selectedUsername = this.checkProperty(this.selectedBeneficiary, 'name');
      }
      this.getbeneficiaryMasterDataList();
    },
    // closeAddBenPopUp(){
    //   let self =this;
    //   if(this.checkProperty(this.selectedBeneficiary ,"_id")){

    //     this.selectedBeneficiary = Object.assign(this.selectedBeneficiary ,{"anonymousUser": self.anonymousUser});

    //   }
    //     this.$emit("closeAddBenPopUp" ,this.selectedBeneficiary);
    // },
    getMasterDataList() {
      this.caseStatusList = [];
      this.$store.dispatch("getmasterdata", "education_types").then((response) => {
        this.education_types = response;
      });
      this.$store.dispatch("getmasterdata", "cap_reg_status").then((response) => {
        this.caseStatusList = response;
        //let obj1 = {_id: "63f783dc7aca563b7e5865485", id: 90, name: "Active", sortName: "Active"};
        let obj2 = { _id: "63f783dc7aca2865dd5555855", id: 91, name: "Hold", sortName: "Hold" };
        //this.caseStatusList.push(obj1)
        this.caseStatusList.push(obj2)

      });
    },


  },
  mounted() {

   
    this.getglobalConfig();
    this.getSeasonsYears();
    if (this.checkProperty(this.getUserData, 'tenantDetails') && this.checkProperty(this.getUserData, 'tenantDetails', 'slug') != 'slg') {
      this.isSlg = false;
    }
    this.checkCapRegcase(true);
   
    this.sortKeys = {
      'caseNo': 1,
      'createdByName': 1,
      "typeName": 1,
      "subTypeName": 1,
      "statusName": 1,
      "createdOn": 1,
      "updatedOn": -1,
      "clientName": 1,
      "beneficiaryName": 1,
      companyName: 1

    },
      this.sortKey = { "path": 'updatedOn', "order": -1 };

    if (localStorage.getItem('petitions_sort_key') && localStorage.getItem('petitions_sort_value') && localStorage.getItem('petitions_sort_value') >= -1) {
      this.sortKey = {};
      this.sortKey = { "path": localStorage.getItem('petitions_sort_key'), "order": parseInt(localStorage.getItem('petitions_sort_value')) };
      this.sortKeys[localStorage.getItem('petitions_sort_key')] = parseInt(localStorage.getItem('petitions_sort_value'));
    }
    this.getMasterDataList()
    //caseStatusList
    this.getPetitioners();
    this.getbeneficiaryMasterDataList();
    this.getBranchList();
    this.filterQueryPreSelect(true);
    //this.getCapList();

    try{

        document.addEventListener("visibilitychange", ()=>{
          if (document.visibilityState === "visible") {
            // Tab has become active
            console.log("Tab is now active");
            this.getglobalConfig();
            // You can perform actions here when the tab becomes active
          } else {
            // Tab has become inactive
            console.log("Tab is now inactive");
            // You can perform actions here when the tab becomes inactive
          }
        });


        }catch(error){
          console.log(error);
        }
  },
  beforeDestroy(){
    try{

      document.removeEventListener("visibilitychange");

    }catch(error){
      console.log(error)
    }
  },
};
</script>