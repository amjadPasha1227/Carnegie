<template>
    <div>
      <div class="content-header">
        <div class="content-header-left">
          <div class="search petition-search">
            <vs-input icon-pack="feather" icon="icon-search" v-model="searchtxt"
              placeholder="Search by Name/Email" class="is-label-placeholder" />
          </div>
        </div>
        <div class="content-header-right">
          <vs-dropdown vs-custom-content vs-trigger-click>
            <vs-button color="primary" class="filter-btn" type="border" icon-pack="feather" icon="icon-chevron-down"
              icon-after>
              <img src="@/assets/images/main/icon-filter.svg" /> Filters
            </vs-button>
            <vs-dropdown-menu ref="filter_menu" class="filters-content">
  
              <div class="filters-form-fileds">
                <div class="form-container">
                  <div class="vx-row">
                    <div class="vx-col md:w-1/3 w-full con-select">
                      <label class="typo__label">Select Status</label>
  
                      <multiselect v-model="selected_statusids" :options="all_statusids" :multiple="true"
                        :hideSelected="true" :close-on-select="false" :clear-on-select="false" :select-label="''"
                        :preserve-search="true" placeholder="Select Status" label="name" track-by="name"
                        :preselect-first="false">
  
                        <template slot="selection" slot-scope="{ values, isOpen }">
                          <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                            option(s) selected</span>
                          <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                        </template>
                      </multiselect>
                    </div>
  
                    <div class="vx-col md:w-1/3 w-full con-select">
                      <label class="typo__label">Country</label>
                      <multiselect name="spouseaddresscountry" v-model="selectedCountry" @input="changedCountry"
                        :show-labels="false" track-by="id" label="name" data-vv-as="Country" placeholder="Select Country"
                        :options="countries" :searchable="true" :allow-empty="false">
                        <template slot="selection" slot-scope="{ values, isOpen }">
                          <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                            options selected</span>
                          <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                        </template>
                      </multiselect>
                    </div>
                    <div class="vx-col md:w-1/3 w-full con-select">
                      <label for class="typo__label">State</label>
                      <multiselect name="State" v-model="selectedState" @input="changedState" :show-labels="false"
                        track-by="id" label="name" data-vv-as="State" :multiple="false" placeholder="Select State"
                        :options="states" :searchable="true" :allow-empty="true">
                        <template slot="selection" slot-scope="{ values, isOpen }">
                          <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                            options selected</span>
                          <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                        </template>
                      </multiselect>
                    </div>
                    <div class="vx-col md:w-1/3 w-full con-select">
                      <label for class="typo__label">City</label>
                      <multiselect name="city" v-model="selectedCityes" @input="changedCity" :show-labels="false"
                        track-by="id" label="name" data-vv-as="City" placeholder="Select City" :options="locations"
                        :searchable="true" :allow-empty="true" :multiple="true" :hideSelected="true">
                        <template slot="selection" slot-scope="{ values, isOpen }">
                          <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                            options selected</span>
                          <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                        </template>
                      </multiselect>
                    </div>
                    <div class="vx-col md:w-1/3 w-full con-select" v-if="[3,4].indexOf(getUserRoleId)>-1">
                      <label class="typo__label">Deleted</label>
                      <multiselect v-model="selectedarchive"
                        :options="[{'name':'Delete' ,'_id':false} ,{'name':'Active' ,'_id':true}]" :multiple="true"
                        :hideSelected="true" :close-on-select="false" :clear-on-select="false" :preserve-search="true"
                        placeholder="Select" label="name" track-by="name" :preselect-first="false">
  
                        <template slot="selection" slot-scope="{ values, isOpen }">
                          <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                            Selected</span>
                          <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                        </template>
                      </multiselect>
                    </div>
  
                    <div class="vx-col md:w-1/3 w-full con-select">
                      <label class="typo__label">Created Date</label>
                      <date-range-picker :maxDate="new Date()" :autoApply="autoApply" :ranges="false"
                        v-model="selected_createdDateRange"></date-range-picker>
                    </div>
                  </div>
  
  
  
                </div>
              </div>
              <div class="filters-status">
                <div class="left-buttons">
  
                </div>
                <div class="right-buttons">
                  <vs-button color="success" class="save" type="filled" v-on:click="set_filter()">Apply</vs-button>
                  <vs-button color="dark" class="cancel" type="filled" v-on:click="clear_filter($event)">Clear
                  </vs-button>
                </div>
              </div>
            </vs-dropdown-menu>
          </vs-dropdown>
          <div class="Generate_buttons" @click="getExportList()">
          <button class="copy_link" v-bind:disabled="exportList">
            <img src="@/assets/images/main/share.png" />
            <small>Export</small>
          </button>
        </div>
        </div>
      </div>
      <NoDataFound ref="NoDataFoundRef" v-if="users.length == 0"
        :content="callFromSerch?'No Results Found':'No Petitioners signed up yet. Invite Petitioners to start using ImmiBox'"
        heading="No Petitioners Found" type='petitioner' />
      <div class="accordian-table relative cpr_table_v2" v-if="users.length > 0">
        <vs-table :data="users" :no-data-text="'No data found...!'">
          <template slot="thead">
  
  
            <vs-th>
  
              <a @click="sortMe('name')"
                v-bind:class="{'sort_ascending':sortKeys['name']==1, 'sort_descending':sortKeys['name']!=1}">
                Name
              </a>
            </vs-th>
            <vs-th>
              <a @click="sortMe('email')"
                v-bind:class="{'sort_ascending':sortKeys['email']==1, 'sort_descending':sortKeys['email']!=1}">
  
                Email
              </a>
            </vs-th>
            
            <vs-th>
              <a @click="sortMe('naicsCode')"
                v-bind:class="{'sort_ascending':sortKeys['naicsCode']==1, 'sort_descending':sortKeys['naicsCode']!=1}">
  
                NAICS
              </a>
            </vs-th>
            <vs-th>
              <a @click="sortMe('feiNumber')"
                v-bind:class="{'sort_ascending':sortKeys['feiNumber']==1, 'sort_descending':sortKeys['feiNumber']!=1}">
  
                FEIN
              </a>
            </vs-th>
            <vs-th>
              <a @click="sortMe('phone')"
                v-bind:class="{'sort_ascending':sortKeys['phone']==1, 'sort_descending':sortKeys['phone']!=1}">
  
                Phone Number
              </a>
            </vs-th>
            <vs-th>
              <a @click="sortMe('phone')"
                v-bind:class="{'sort_ascending':sortKeys['phone']==1, 'sort_descending':sortKeys['phone']!=1}">
  
                Authorized Signatory Name
              </a>
            </vs-th>
            <vs-th>
              <a @click="sortMe('phone')"
                v-bind:class="{'sort_ascending':sortKeys['phone']==1, 'sort_descending':sortKeys['phone']!=1}">
  
                Authorized Signatory Email
              </a>
            </vs-th>
            <vs-th>
              <a @click="sortMe('phone')"
                v-bind:class="{'sort_ascending':sortKeys['phone']==1, 'sort_descending':sortKeys['phone']!=1}">
  
                Authorized Signatory Phone Number
              </a>
            </vs-th>
            <vs-th>
              <a @click="sortMe('statusName')"
                v-bind:class="{'sort_ascending':sortKeys['statusName']==1, 'sort_descending':sortKeys['statusName']!=1}">
  
                Status
              </a>
            </vs-th>
            <vs-th>
              <a @click="sortMe('createdOn')"
                v-bind:class="{'sort_ascending':sortKeys['createdOn']==1, 'sort_descending':sortKeys['createdOn']!=1}">
                Created On
              </a>
            </vs-th>
            <vs-th>
              <a @click="sortMe('Address')"
                v-bind:class="{'sort_ascending':sortKeys['Address']==1, 'sort_descending':sortKeys['Address']!=1}">
  
                Address
              </a>
            </vs-th>
          </template>
          <template slot-scope="{data}">
            <vs-tr :data="tr" :key="indextr" v-for="(tr, indextr) in data">
              <vs-td :data="tr.name">
                <span class="cursor-pointer" @click="petitionlink(tr)">
                  <avatar :size="36" :backgroundColor="'#0E1D48'" :initials="avtarName(tr, 'name')"></avatar>
                  {{ tr.name }}
                </span>
              </vs-td>
              <vs-td>
                <span class="cursor-pointer" @click="petitionlink(tr)">{{ checkProperty( tr,'sortEmail' )}}</span>
              </vs-td>

              <vs-td :data="tr.naicsCode"><span class="cursor-pointer" @click="petitionlink(tr)">{{checkProperty(tr, 'naicsCode')}} </span>
              </vs-td>
              <vs-td :data="tr.feiNumber"><span class="cursor-pointer" @click="petitionlink(tr)">{{checkProperty(tr, 'feiNumber')}} </span>
              </vs-td>
              <vs-td :data="tr.phone"><span class="cursor-pointer" @click="petitionlink(tr)">
                <template
                v-if="checkProperty(tr, 'phoneCountryCode', 'countryCallingCode')">{{ checkProperty(tr, 'phoneCountryCode', 'countryCallingCode') + "&nbsp;" }}</template>
                {{checkProperty(tr, 'phone') | formatPhone }}
             </span>
              </vs-td>
              <vs-td :data="tr.feiNumber"><span class="cursor-pointer" @click="petitionlink(tr)">{{checkProperty(tr, 'authorizedSignatory', 'name')}} </span>
              </vs-td>
              <vs-td :data="tr.feiNumber"><span class="cursor-pointer" @click="petitionlink(tr)">{{checkProperty(tr, 'authorizedSignatory', 'email')}} </span>
              </vs-td>
              <vs-td :data="tr.feiNumber"><span class="cursor-pointer" @click="petitionlink(tr)">
                <template
                v-if="checkProperty(tr['authorizedSignatory'], 'phoneCountryCode', 'countryCallingCode')">{{ checkProperty(tr['authorizedSignatory'], 'phoneCountryCode', 'countryCallingCode') + "&nbsp;" }}</template>
                {{checkProperty(tr, 'authorizedSignatory', 'phone')}}
             </span>
              </vs-td>
              <vs-td :data="tr.statusDetails">
                <span @click="petitionlink(tr)" class="statusspan cursor-pointer"
                  :class="
                  {'status_pending':tr.statusDetails['id']==1,'status_active':tr.statusDetails['id']==2,'status_onHold':tr.statusDetails['id']==3,'status_rejected':tr.statusDetails['id']==4}">{{checkProperty(tr
                  ,"statusDetails" ,'name')}}</span>
  
  
              </vs-td>
              <vs-td :data="tr.createdOn">
                <span class="cursor-pointer"  @click="petitionlink(tr)">{{ tr.createdOn | formatDate }}</span>
              </vs-td>
              <vs-td :data="tr.fullAddress"><span class="cursor-pointer" @click="petitionlink(tr)">{{tr.fullAddress}} </span>
              </vs-td>
            </vs-tr>
          </template>
        </vs-table>
        <div class="table_footer">
        <div class="vx-col  con-select pages_select"  v-if="users.length>0">
          <label class="typo__label">Per Page</label>
          <multiselect @input="changeperPage()" v-model="perpage" :options="perPeges" :multiple="false"
              :close-on-select="true" :clear-on-select="false" :preserve-search="true" placeholder="Per Page"
              :preselect-first="true">
            </multiselect>
            <span class="totla_list_count" v-if="totalCount"> Total <em>{{totalCount}}</em></span>
          </div>
          <paginate v-if="users.length>0" v-model="page" :page-count="totalpages" :page-range="3" :margin-pages="2"
          :click-handler="pageNate" prev-class="vs-pagination--buttons btn-prev-pagination vs-pagination--button-prev"
          next-class="vs-pagination--buttons btn-next-pagination vs-pagination--button-next" :prev-text="'<i></i>'"
          :next-text="'<i></i>'" :container-class="'pagination vs-pagination--nav'" :page-class="'page-item'"></paginate>
      </div>
        
      </div>
    </div>
  </template>
  
  <script>
    import Datepicker from "vuejs-datepicker-inv";
    import Paginate from "vuejs-paginate";
  import DateRangePicker from "vue2-daterange-picker";
    import { FormWizard, TabContent } from "vue-form-wizard";
    import "vue-form-wizard/dist/vue-form-wizard.min.css";
     import moment from 'moment'
    import PhoneMaskInput from "vue-phone-mask-input";
    import JQuery from 'jquery'
    import { TheMask } from 'vue-the-mask'
    import { MoreVerticalIcon } from 'vue-feather-icons';
    import Avatar from 'vue-avatar'
    import NoDataFound from "@/views/common/noData.vue";
  
    import VuePhoneNumberInput from 'vue-phone-number-input';
   import 'vue-phone-number-input/dist/vue-phone-number-input.css';
  
    export default {
      components: {
        DateRangePicker,
        VuePhoneNumberInput,
        Datepicker,
        Paginate,
        MoreVerticalIcon,
        FormWizard,
        TabContent,
        PhoneMaskInput,
        TheMask,
        NoDataFound,
        Avatar
      },
  
      data: () => ({
        exportList: false,
        setPasswordErrorMsg:'',
       setPassword:false,
     newPassword:'',
     confPassword:'',
     updatingPassword:false,
     selectedItem:null,
  
  
        isPhoneValid:true,
        callFromSerch:false,
        selected_createdDateRange: ["", ""],
      autoApply: "",
       countries:[],
       states:[],
       locations:[],
       selectedCountry:null,
       selectedState:null,
       selectedCityes:[],
       vuePhone:{
          props:{
            translations:{
              phoneNumberLabel:"Phone Number"
            }
          }
  
        },
        sortKeys:{},
      sortKey:{},
         petitioner: {
                  name: "",
                  adminFirstName:"",
                  adminLastName:"",
                  email: "",
                  phoneCountryCode:{countryCode:'',countryCallingCode:''},
                  roleId:"1",
                  phone:"",
                  password: "",
                  confirm_password: "",
                  invite:true
                  
              },  
        selectedpetitioner:null,
        selectedStatus:2,
        actionText:"Do you want to approve?",
        formerrors: {
          msg: ""
        },
        date: null,
        visatype: {
          id: 1,
          name: "H1B"
        },
        visasubtype: null,
        visasubtype: null,
        selectedUser: null,
        selectedUsername: null,
        approveConformpopUp: false,
        selected_roleID:'1',
        new_user: {
          firstName: "",
          lastName:"",
          adminFirstName: "",
          adminLastName:"",
          roleId:12,
          email: "",
          phone:"",
          active:true,
          "accountType": "Corporate",
          address: {
            "line1": "",
            "line2": "",
            "locationId": "",
            "stateId": "",
            "countryId": 231,
            "zipcode": ""
          }
  
        },
        users: [],
        invitepetitioner: false,
        NewPetition: false,
        visatypes: [],
        visasubtypes: [],
        searchtxt: "",
        query: [],
        country_code: 231,
        all_statusids: [],
        selected_statusids: [],
        final_selected_statusids: [],
        filter_roleIds: [],
        final_filter_roleIds: [1,2,3,4,5,8,9,10,11 ,12],
  
        all_states: [],
        seleted_states: [],
        final_selected_states: [],
        locations: [],
        // locationIds
        all_locations: [],
        seleted_locations: [],
        final_selected_locations: [],
        date: "",
        date_range: [],
        page: 1,
      perPeges: [10,25,50,75,100],
      perpage: 25,
      totalCount:0,
      totalpages: 0,
        all_userroles: [],
  
        selected_userrole: '',
        switch2:true,
        users_status:{},
        popupbtnTxt:'',
        companyStatusList:[],
  
         selectedForArchiveList:[],
         archiving:false,
         selectedarchive:[],
         selectedAllForArchive:false,
         exportData:{}
      }),
      watch: {
        searchtxt: function (value) {
          this.getPetitioners(true);
        }
  
      },
      methods: {
        changeperPage(){
        this.page = 1;
        this.getPetitioners(true);
      },
        getExportList() {
            let Payload = {
                matcher: {},
                today: ''
            };
            Payload['matcher'] = this.exportData;
            Payload['today'] = moment().format('YYYY-MM-DD'),
                this.exportList = true;
            this.$store.dispatch("commonAction", { "data": Payload, "path": "/company/export-list" }).then((response) => {
                this.exportList = false;
                if (this.checkProperty(response, 'path')) {
                window.open(this.$globalgonfig._APIURL + "/common/viewfile?filename=Corporate_Customers_Report.xlsx&path=" + this.checkProperty(response, 'path'), "_blank");
                }
            }).catch((err) => {
                this.exportList = false;
            })
        },
         petitionlink(tr) {
          this.$router.push('/petitioner-details/'+tr._id)
        },
        changedCountry(){
        if( this.selectedCountry && _.has(this.selectedCountry , "id")){
            this.masterData('states');
        }
        
        },
        changedState(){
          
            this.locations =[];
            if( _.has(this.selectedState , "id")){
              this.masterData('locations');
          }
        },
      changedCity(){
  
        if( _.has(this.selectedCity , "id")){
              //this.updateTenantData.address.locationId = this.updateTenantData.address.selectedCity['id'];
              this.masterData('locations');
          }
  
      },
      masterData(category="countries"){
        let matcher ={};
          let postData = {
        matcher: matcher,
        page:1,
        perpage: 1000,
        category: category,
        
      };
      if(category =="states"){
  
          matcher = { "countryId": this.selectedCountry['id']}
      }
        if(category =="locations"){
  
          matcher = { "stateId": this.selectedState['id']  }
      }
        postData['matcher'] = matcher;
  
          this.$store.dispatch("getMasterData" , postData)
          .then((res)=>{
              //countries
              
              if(category == "countries"){
  
                  this.countries = res['list'];
                  
                  //alert(JSON.stringify(this.countries))
              }
              if(category =="states"){
  
  
                  this.states= res['list'];
                 
                  
                  
              }
            if(category =="locations"){
              
                this.locations= res['list'];
               
                
            }
          })
          .catch((err)=>{
             
              this[category] =[];
  
          })
  
      },
        getCompanyStatusList(){
          this.all_statusids =[];
           let postdata ={
          page:1,
          perpage: 1000,
          category: "company_status",
         
        };
          this.$store.dispatch("getMasterData" ,postdata)
          .then((res)=>{
            this.all_statusids = res['list'];
            this.all_statusids = _.filter(this.all_statusids ,(item)=>{
              return [1,2,3,4].indexOf(item['id'])>-1;
  
             });
  
                  if(this.checkProperty(this.$route ,'query' ,'filter')){
                  try{
                    let filter =this.$route['query']['filter']; this.checkProperty(this.$route ,'query' ,'filter')
                    var actual = JSON.parse(atob(filter));
                    let keys = Object.keys(actual);
                    if(this.checkProperty(keys ,'length') >0){
  
  
                      if(actual && (Object.keys(actual)).length>0 ){
                      _.forEach(actual ,(item ,key) => {
                          if(key=='matcher' ){
                            
                            if((Object.keys(item)).length>0 ){
  
                              if(_.has(item ,'statusIds')){
                                
                                this.selected_statusids = _.filter(this.all_statusids ,(status)=>{
                                    return item['statusIds'].indexOf(status['id'])>-1;
  
                              })
  
                              }
  
                              
                              
                            }
                          
                          }
                        
                          
                      
                      })
                    }
                      
                      
                    }
  
                  }catch(e){
                    
  
                  }
                    
                }
  
          })
          .catch(()=>{
  
          })
  
  
        },
        sortMe(sort_key=''){
  
        //   this.sortKeys = {
        //   'caseNo':1,
        //   'beneficiaryDetails.name':1,
        //   "typeDetails.name":1,
        //   "petitionerDetails.name":1,
        //   "updatedOn":1,
        //   "communicationDetailslength":1
  
        // }
  
        if(sort_key !=''){
            this.sortKeys[sort_key] = this.sortKeys[sort_key]==1?-1:1
            this.sortKey ={};
            this.sortKey = {"path":sort_key,"order":this.sortKeys[sort_key]};
  
            localStorage.setItem('company_sort_key', sort_key);
            localStorage.setItem('company_sort_value', this.sortKey[sort_key]);
            this.getPetitioners();
        }
        },
        getPetitioners(callFromSerch=false) {
          this.selectedAllForArchive =false;
         this.selectedForArchiveList =[]; 
          this.callFromSerch = callFromSerch;
          this.exportData = {};
          let matcher = {
            searchString: this.searchtxt,
            statusIds: [2],
            "countryIds": [],
            "stateIds": [],
            "locationIds": [],
            createdDateRange:[],
            statusList:[],
            getReports: true
          };
          if(this.final_selected_statusids && this.checkProperty(this.final_selected_statusids,'length')>0){
            matcher['statusIds'] = this.final_selected_statusids
          };
          //filter Country and staet and locations
           if(this.selectedCountry && _.has(this.selectedCountry ,"id")){
             matcher['countryIds'] = [this.selectedCountry['id']]
  
           }
           if(this.selectedState && _.has(this.selectedState ,"id")){
             matcher['stateIds'] = [this.selectedState['id']]
  
           }
  
           if(this.selectedCityes &&this.selectedCityes.length>0 ){
             // _.has(this.selectedCountry ,"id")
             _.forEach(this.selectedCityes,(item)=>{
  
                if( _.has(item ,"id")){
                    matcher['locationIds'].push(item['id']);
  
                }
  
  
             })
            
  
           }
  
           if (
          this.selected_createdDateRange["startDate"] &&
          this.selected_createdDateRange["startDate"] != "" &&
          this.selected_createdDateRange["endDate"] != "" &&
          this.selected_createdDateRange["endDate"]
        ) {
          matcher["createdDateRange"] = [
            this.selected_createdDateRange["startDate"],
            this.selected_createdDateRange["endDate"]
          ];
        }
  
          let query = {};
          query['page'] = this.page;
          query['perpage'] = this.perpage;
          query['matcher'] = matcher;
          query['sorting'] = this.sortKey;
          this.exportData = matcher;
          if(this.callFromSerch){
           
            this.users =[];
          }
  
           if(this.checkProperty(this.$route ,'query' ,'filter')){
          try{
             let filter =this.$route['query']['filter']; this.checkProperty(this.$route ,'query' ,'filter')
            var actual = JSON.parse(atob(filter));
            let keys = Object.keys(actual);
            if(this.checkProperty(keys ,'length') >0){
  
  
              if(actual && (Object.keys(actual)).length>0 ){
              _.forEach(actual ,(item ,key) => {
                  if(key=='matcher' ){
                    if((Object.keys(item)).length>0 ){
                      query['matcher'] = item
                    }
                  }
                 
                  if(callFromSerch){
                  if(key =='page' && item >0){
                    query['page'] = parseInt(item)
                    this.page = parseInt(item)
                  }
                  if(key =='perpage' && item >0){
                    query['perpage'] = parseInt(item)
                    
                    this.perpage = parseInt(item)
                  }
                  if(key=='sorting' ){
                    if((Object.keys(item)).length>0 ){
                      query['sorting'] = item
                    }
                  
                  }
                }
              
              })
            }
              
              
            }
  
          }catch(e){
             
  
          }
          
            
        }
  
        //query['matcher']["accountTypeList"]= ["Corporate"],
  
         
          this.updateLoading(true);
          this.$store
            .dispatch("getList",{data:query ,path:'/company/list'} )
            .then(response => {
               this.updateLoading(false);
              
  
               let tempList =[];
           let list = response.list
           _.forEach( list,(item) => {
              item =Object.assign(item,{ 'selectedForArchive':false});
             if(this.selectedForArchiveList.indexOf(item['_id'])>-1){
                item =Object.assign(item,{ 'selectedForArchive':true});
             }
             tempList.push(item)
             
           });
            this.users =tempList;
            this.totalCount = this.checkProperty(response,'totalCount')
              this.totalpages = Math.ceil(response.totalCount / this.perpage);
              //alert(this.perpage);
            }).catch((err)=>{
              this.users =[];
               this.updateLoading(false);
            })
        },
     
        set_filter: function () {
          this.$refs["filter_menu"].dropdownVisible = false;
          this.final_selected_statusids = [];
          if (this.selected_statusids.length > 0) {
            this.final_selected_statusids = [];
            for (let ind = 0; ind < this.selected_statusids.length; ind++) {
              let current_index = this.selected_statusids[ind];
              this.final_selected_statusids.push(current_index["id"]);
            }
          }
          /*
           countries:[],
       states:[],
       locations:[],
       selectedCountry:null,
       selectedState:null,
       selectedCityes:[],
          */
  
  
          this.getPetitioners(true);
        },
        clear_filter: function () {
          this.selectedarchive =[];
          this.selectedCountry =null
           this.selectedState =null;
           this.selectedCityes= [];
          this.$refs["filter_menu"].dropdownVisible = false;
          this.selected_statusids = [];
          this.final_selected_statusids = [];
           this.selected_createdDateRange["startDate"] = "";
           this.selected_createdDateRange["endDate"] = "";
        
          this.date = "";
          this.date_range = [];
           this.$router.push({ query: {} })
          this.getPetitioners();
        },
        pageNate(pageNum) {
         
          this.page = pageNum;
          this.getPetitioners(true);
        },
        
        changetPetitionerstatus( ){
          let post_data = {"companyId":this.selectedpetitioner['_id'], "statusId":this.selectedStatus };
          let sts = _.find(this.all_statusids ,{"id":this.selectedStatus});
          if(sts && _.has(sts,"name")){
            post_data['statusName'] = sts['name']
  
          }
          //alert(JSON.stringify(post_data));
  
          //post_data = Object.assign(post_data,{"petitionerId":this.selectedpetitioner['_id'] ,"statusId":this.selectedStatus})
        
            this.$store.dispatch("commonAction", {data:post_data ,"path":"/company/update-status"}).then((res) => {
                this.approveConformpopUp =false;
                   this.showToster({message:res.message,isError:false });
                  this.getPetitioners();
  
              }).catch((error) => {
                  this.showToster({message:error,isError:true });
                 
  
              });
  
        },
  
      },
      mounted() {
         this.masterData("countries");
        this.selected_statusids = [];
        this.final_selected_statusids = [];
        this.seleted_states = [];
        this.final_selected_states = [];
  
        this.seleted_locations = [];
        this.final_selected_locations = [];
        
  
        this.sortKeys = { "createdOn":1, "invitedByName":1, "createdByName":1, "name":1, "email":1, "phone":1, 'statusName':1, 'updatedOn':1 ,
        "customIdSNo":1, naicsCode:1,feiNumber:1,phone:1,Address:1},
     
      this.sortKey = {"path":'createdOn' ,"order":-1};
  
      if(localStorage.getItem('company_sort_key') && localStorage.getItem('company_sort_value')  && localStorage.getItem('company_sort_value') >=-1 ){
         this.sortKey = {};
  
        this.sortKey = {"path":localStorage.getItem('company_sort_key') ,"order":parseInt(localStorage.getItem('company_sort_value'))};
        this.sortKeys[localStorage.getItem('company_sort_key')] = parseInt(localStorage.getItem('company_sort_value'));
  
        //alert();
  
      }
      if(localStorage.getItem('petitioner_perpage')){
          this.perpage = parseInt(localStorage.getItem('petitioner_perpage'));
      }
        this.getCompanyStatusList();
        this.getPetitioners();
        setTimeout(()=>{ 
                      this.isPhoneValid=true;
                     
                 } ,100);
       
  
      },
      computed:{
    }
    };
  </script>
  