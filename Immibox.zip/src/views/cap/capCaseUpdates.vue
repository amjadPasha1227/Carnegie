<template>
   <div class="main-list-wrap petition_details_wrap">
      <div class="tab-inner-content tabs-nobg gc_emp_details_tab">
         <div class="tabs-content-panel tab-pad-wrap">
            <div class="tab-inner-content h-full">

               <div class="tabs-content-panel tab-pad-wrap mar0 pad0 h-full">
                  <div class="case-approved-detailes gc-case perm-caseupdates bg-white pt-5 pl-8 h-full pr-3">

                     <div class="case-approved-body case_approved_v2"
                        v-if="petition['completedActivities'].indexOf('CASE_CREATED') > -1 || checkProperty(petition, 'petitionDetails', '_id')">
                        <div class="left success">

                           <h5 class="success">Case Created</h5>
                           <ul>
                              <li v-if="checkProperty(petition, 'petitionDetails', 'caseNo')">
                                 <p>Case Number <span>{{ petition['petitionDetails']['caseNo'] }}</span></p>
                              </li>
                           </ul>
                           <ul>
                              <li v-if="checkProperty(petition, 'petitionDetails', 'createdOn')">
                                 <p>Created Date <span>{{ petition['petitionDetails']['createdOn'] | formatDateTime
                                 }}</span>
                                 </p>
                              </li>
                              <li v-if="checkProperty(petition, 'petitionDetails', 'createdByName')">
                                 <p>Created By <span> {{ petition['petitionDetails']['createdByName'] }}<small
                                          v-if="checkProperty(petition, 'petitionDetails', 'createdByRoleName')">({{
                                             petition['petitionDetails']['createdByRoleName'] }})</small></span>
                                 </p>
                              </li>
                           </ul>
                        </div>
                        <div class="right">
                           <ul v-if="checkProperty(petition, 'petitionDetails', '_id')">
                              <li @click="petitionLink(petition['petitionDetails']['_id'])" class="cursor"><a> View
                                    Details</a></li>
                           </ul>
                        </div>
                     </div>
                     <template v-if="isSlg" >
                        <div class="case-approved-body case_approved_v2"
                           v-if="petition['completedActivities'].indexOf('SELECTED') > -1">
                           <div class="left success">
                              <h5 class="case-heading d-flex align-center">Selected
                                 <button
                                    v-if="checkCurrentUrl && [50, 51].indexOf(getUserRoleId) <= -1 && petition['completedActivities'].indexOf('CASE_CREATED') < 0"
                                    class="cursor primary-btn Update_USCIS_btn" @click="createCaseRedirect()">
                                    <span class="viewdetails" target="_blank">
                                       <template>Create Case</template>
                                    </span>
                                 </button>
                              </h5>
                              <ul v-if="checkProperty(petition, 'rfeNotice', 'description')">
                                 <li class="w-full">
                                    <p class="comment-sec">Comments <span class="wrapall"
                                          v-html="checkProperty(petition, 'rfeNotice', 'description')"></span></p>
                                 </li>
                              </ul>
                              <ul v-if="isSlg == false">
                                 <li v-if="checkProperty(petition, 'rfeNotice', 'trackingNumber')">
                                 <p>Application Number <span>{{ checkProperty(petition, 'rfeNotice',
                                    'trackingNumber') }}</span></p>
                              </li>
                                 <li v-if="checkProperty(petition, 'rfeNotice', 'registeredDate')">
                                    <p>Registered Date <span>{{ petition['rfeNotice']['registeredDate'] | formatDate }}</span>
                                    </p>
                                 </li>
                                 <li v-if="checkProperty(petition, 'rfeNotice', 'uscisFeeStatus')">
                                    <p>USCIS Fee Status <span>{{ petition['rfeNotice']['uscisFeeStatus']}}</span>
                                    </p>
                                 </li>
                                 
                              </ul>
                              <div class="receipt_ackno"
                                 v-if="checkProperty(petition['rfeNotice'], 'documents') && checkProperty(petition['rfeNotice'], 'documents', 'length') > 0">
                                 <documentsView @download_or_view="downloadfile" :type="'documents'"
                                    :documentsList="petition['rfeNotice']['documents']" :petitionDetails="petition" />
                              </div>
                              <ul>
                                 <li v-if="checkProperty(petition, 'rfeNotice', 'updatedOn')">
                                    <p>Updated Date <span>{{ petition['rfeNotice']['updatedOn'] | formatDateTime }}</span>
                                    </p>
                                 </li>
                                 <li v-if="checkProperty(petition, 'rfeNotice', 'updatedByName')">
                                    <p>Updated By <span> {{ petition['rfeNotice']['updatedByName'] }}<small
                                       v-if="checkProperty(petition, 'rfeNotice', 'updatedByRoleName')">({{
                                       petition['rfeNotice']['updatedByRoleName'] }})</small></span>
                                    </p>
                                 </li>
                              </ul>
                           </div>
                        </div>
                        <div class="case-approved-body case_approved_v2" v-if="petition['completedActivities'].indexOf('DENIED') > -1 ||
                           petition['completedActivities'].indexOf('INVALIDATED') > -1 || petition['completedActivities'].indexOf('NOT_SELECTED') > -1
                        ">
                           <div class="left cross">
                              <template v-if="petition['completedActivities'].indexOf('DENIED') > -1">
                                 <h5 class="success">Denied</h5>
                              </template>
                              <template v-if="petition['completedActivities'].indexOf('INVALIDATED') > -1">
                                 <h5 class="success">Payment Failed</h5>
                              </template>
                              <template v-if="petition['completedActivities'].indexOf('NOT_SELECTED') > -1">
                                 <h5 class="success">Not Selected</h5>
                              </template>

                              <ul v-if="checkProperty(petition, 'rfeNotice', 'description')">
                                 <li class="w-full">
                                    <p class="comment-sec">Comments <span class="wrapall"
                                          v-html="checkProperty(petition, 'rfeNotice', 'description')"></span></p>
                                 </li>
                              </ul>
                              <div class="receipt_ackno"
                                 v-if="checkProperty(petition['rfeNotice'], 'documents') && checkProperty(petition['rfeNotice'], 'documents', 'length') > 0">
                                 <documentsView @download_or_view="downloadfile" :type="'usicsDocuments'"
                                    :documentsList="petition['rfeNotice']['documents']" :petitionDetails="petition" />
                              </div>
                              <ul>
                                 <li v-if="checkProperty(petition, 'rfeNotice', 'updatedOn')">
                                    <p>Updated Date <span>{{ petition['rfeNotice']['updatedOn'] | formatDateTime }}</span>
                                    </p>
                                 </li>
                                 <li v-if="checkProperty(petition, 'rfeNotice', 'updatedByName')">
                                    <p>Updated By <span> {{ petition['rfeNotice']['updatedByName'] }}<small
                                             v-if="checkProperty(petition, 'rfeNotice', 'updatedByRoleName')">({{
                                                petition['rfeNotice']['updatedByRoleName'] }})</small></span>
                                    </p>
                                 </li>
                              </ul>
                           </div>
                        </div>
                     </template>
                     <template v-else>
                        <template v-if="checkProperty(petition,'uscisRegisteredInfoLogs') && checkProperty(petition,'uscisRegisteredInfoLogs','length')>0 ">
                           <template v-for="(item,indexx) in petition['uscisRegisteredInfoLogs']">
                              <div class="case-approved-body case_approved_v2" v-if="checkProperty(item,'action')=='SELECTED'">
                           <div class="left success">
                              <h5 class="case-heading d-flex align-center">Selected
                                 <button
                                    v-if="checkCurrentUrl && [50, 51].indexOf(getUserRoleId) <= -1 && petition['completedActivities'].indexOf('CASE_CREATED') < 0"
                                    class="cursor primary-btn Update_USCIS_btn" @click="createCaseRedirect()">
                                    <span class="viewdetails" target="_blank">
                                       <template>Create Case</template>
                                    </span>
                                 </button>
                              </h5>
                              <ul v-if="checkProperty(item, 'description')">
                                 <li class="w-full">
                                    <p class="comment-sec">Comments <span class="wrapall"
                                          v-html="checkProperty(item, 'description')"></span></p>
                                 </li>
                              </ul>
                              <ul  v-if="checkProperty(item, 'trackingNumber')">
                                 <li v-if="checkProperty(item, 'trackingNumber')">
                                       <p>Application Number <span>{{ checkProperty(item, 
                                          'trackingNumber') }}</span></p>
                                    </li>
                              </ul>
                              <div class="receipt_ackno"
                                    v-if="checkProperty(item, 'documents') && checkProperty(item, 'documents', 'length') > 0">
                                    <documentsView @download_or_view="downloadfile" :type="'documents'"
                                       :documentsList="item['documents']" :petitionDetails="petition" />
                                 </div>
                              <ul>
                                 
                                 <li v-if="checkProperty(item, 'updatedOn')">
                                    <p>Updated Date <span>{{ item['updatedOn'] | formatDateTime }}</span>
                                    </p>
                                 </li>
                                 <li v-if="checkProperty(item, 'updatedByName')">
                                    <p>Updated By <span> {{ item['updatedByName'] }}<small
                                       v-if="checkProperty(item, 'updatedByRoleName')">({{
                                       item['updatedByRoleName'] }})</small></span>
                                    </p>
                                 </li>
                              </ul>
                           </div>
                              </div>
                              <div class="case-approved-body case_approved_v2" v-if="checkProperty(item,'action')=='NOT_SELECTED'">
                                 <div class="left cross">
                                    <h5 class="case-heading d-flex align-center">Not Selected</h5>
                                    <ul v-if="checkProperty(item, 'description')">
                                       <li class="w-full">
                                          <p class="comment-sec">Comments <span class="wrapall"
                                                v-html="checkProperty(item, 'description')"></span></p>
                                       </li>
                                    </ul>
                                    <ul>
                                 <li v-if="checkProperty(item, 'trackingNumber')">
                                       <p>Application Number <span>{{ checkProperty(item, 
                                          'trackingNumber') }}</span></p>
                                    </li>
                              </ul>
                              <div class="receipt_ackno"
                                    v-if="checkProperty(item, 'documents') && checkProperty(item, 'documents', 'length') > 0">
                                    <documentsView @download_or_view="downloadfile" :type="'documents'"
                                       :documentsList="item['documents']" :petitionDetails="petition" />
                                 </div>
                                    <ul>
                                       <li v-if="checkProperty(item, 'updatedOn')">
                                          <p>Updated Date <span>{{ item['updatedOn'] | formatDateTime }}</span>
                                          </p>
                                       </li>
                                       <li v-if="checkProperty(item, 'updatedByName')">
                                          <p>Updated By <span> {{ item['updatedByName'] }}<small
                                             v-if="checkProperty(item, 'updatedByRoleName')">({{
                                             item['updatedByRoleName'] }})</small></span>
                                          </p>
                                       </li>
                                    </ul>
                                 </div>
                              </div>
                              <div class="case-approved-body case_approved_v2" v-if="checkProperty(item,'action')=='FILING_FEE_UPDATE'">
                              <div class="left" >
                                 <h5 class="success">Registered with USCIS and Fee Paid</h5>
                                 <ul>
                                    <li v-if="checkProperty(item, 'uscisFeeStatus')">
                                          <p>Fee Status <span>{{ item['uscisFeeStatus']}}</span>
                                          </p>
                                       </li>

                                 </ul>
                                
                                 <ul>
                                       <li v-if="checkProperty(item, 'updatedOn')">
                                          <p>Updated Date <span>{{ item['updatedOn'] | formatDateTime }}</span>
                                          </p>
                                       </li>
                                       <li v-if="checkProperty(item, 'updatedByName')">
                                          <p>Updated By <span> {{ item['updatedByName'] }}<small
                                             v-if="checkProperty(item, 'updatedByRoleName')">({{
                                             item['updatedByRoleName'] }})</small></span>
                                          </p>
                                       </li>
                                    </ul>
                              </div>
                              </div>
                              <div class="case-approved-body case_approved_v2" v-if="checkProperty(item,'action')=='REGISTERED'">
                              <div class="left">
                                 <h5 class="success">Registered with USCIS</h5>
                                 <ul>
                                    <li v-if="checkProperty(item, 'registeredDate')">
                                          <p>Registered Date <span>{{ item['registeredDate'] | formatDate }}</span>
                                          </p>
                                       </li>
                                       <li v-if="checkProperty(item, 'trackingNumber')">
                                       <p>Application Number <span>{{ checkProperty(item, 
                                          'trackingNumber') }}</span></p>
                                    </li>

                                    <li v-if="checkProperty(item, 'uscisFeeStatus')">
                                       <p>USCIS Fee Status <span>{{ checkProperty(item, 
                                          'uscisFeeStatus') }}</span></p>
                                    </li>
                                 </ul>
                                 <div class="receipt_ackno"
                                    v-if="checkProperty(item, 'documents') && checkProperty(item, 'documents', 'length') > 0">
                                    <documentsView @download_or_view="downloadfile" :type="'documents'"
                                       :documentsList="item['documents']" :petitionDetails="petition" />
                                 </div>
                                 <ul>
                                       <li v-if="checkProperty(item, 'updatedOn')">
                                          <p>Updated Date <span>{{ item['updatedOn'] | formatDateTime }}</span>
                                          </p>
                                       </li>
                                       <li v-if="checkProperty(item, 'updatedByName')">
                                          <p>Updated By <span> {{ item['updatedByName'] }}<small
                                             v-if="checkProperty(item, 'updatedByRoleName')">({{
                                             item['updatedByRoleName'] }})</small></span>
                                          </p>
                                       </li>
                                    </ul>
                              </div>
                              </div>
                           </template>
                        </template>

                     </template>

                     <div class="case-approved-body case_approved_v2"
                        v-if="petition['completedActivities'].indexOf('RECEIPT_OF_PAYMENT_MADE') > -1 && petition['completedActivities'].indexOf('TRACKING_INFO_UPDATE') > -1 && false">
                        <div class="left">
                           <h5 class="success">Tracking Information Updated</h5>
                           <ul>
                              <li class="w-full" v-if="checkProperty(petition, 'trackingInfo', 'comments')">
                                 <p class="comment-sec">Comments <span class="wrapall"
                                       v-html="checkProperty(petition, 'trackingInfo', 'comments')"></span></p>
                              </li>
                              <li v-if="checkProperty(petition, 'trackingInfo', 'receiptName') && false">
                                 <p>Receipt Name <span>{{ checkProperty(petition, 'trackingInfo', 'receiptName') }}</span>
                                 </p>
                              </li>
                              <li v-if="checkProperty(petition, 'trackingInfo', 'trackingNumber')">
                                 <p>Application Number <span>{{ checkProperty(petition, 'trackingInfo',
                                    'trackingNumber') }}</span></p>
                              </li>
                           </ul>
                        </div>
                        <div class="right">
                           <ul
                              v-if="checkProperty(petition['trackingInfo'], 'documents') && checkProperty(petition['trackingInfo'], 'documents', 'length') > 0">
                              <!-- <li class="cursor"><a> View Details</a></li> -->
                              <li @click="downloadfile(petition['trackingInfo']['documents'][0])">
                                 <figure class="view-detailes_cnt"><img src="@/assets/images/download-white.svg"></figure>
                              </li>
                           </ul>
                        </div>

                        <ul>
                           <li v-if="checkProperty(petition, 'trackingInfo', 'updatedOn')">
                              <p>Updated Date <span> {{ petition['trackingInfo']['updatedOn'] | formatDateTime }}</span>
                              </p>
                           </li>
                           <li v-if="checkProperty(petition, 'trackingInfo', 'updatedByName')">
                              <p>Updated By <span> {{ petition['trackingInfo']['updatedByName'] }}<small
                                       v-if="checkProperty(petition, 'trackingInfo', 'updatedByRoleName')">({{
                                          petition['trackingInfo']['updatedByRoleName'] }})</small></span>
                              </p>
                           </li>
                        </ul>
                     </div>
                     <div class="case-approved-body case_approved_v2"
                        v-if="petition['completedActivities'].indexOf('RECEIPT_OF_PAYMENT_MADE') > -1 && isSlg ">
                        <div class="left">
                           <h5 class="success">Payment Information Updated</h5>
                           <ul>
                              <li v-if="checkProperty(petition, 'recOfPaymentMadeInfo', 'payAmount')">
                                 <p>Amount<span> {{ petition['recOfPaymentMadeInfo']['payAmount'] | formatprice }}</span>
                                 </p>
                              </li>
                              <li v-if="checkProperty(petition, 'trackingInfo', 'trackingNumber')">
                                 <p>Application Number <span>{{ checkProperty(petition, 'trackingInfo',
                                    'trackingNumber') }}</span></p>
                              </li>
                              <li v-if="checkProperty(petition, 'recOfPaymentMadeInfo', 'paymentDate')">
                                 <p>Payment Date<span> {{ petition['recOfPaymentMadeInfo']['paymentDate'] |
                                    formatDate }}</span></p>
                              </li>
                              <li v-if="checkProperty(petition, 'recOfPaymentMadeInfo', 'registeredDate')">
                                 <p>Registered Date<span> {{ petition['recOfPaymentMadeInfo']['registeredDate'] |
                                    formatDate }}</span></p>
                              </li>
                              <li v-if="checkProperty(petition, 'recOfPaymentMadeInfo', 'submittedDate')">
                                 <p>Submitted Date<span> {{ petition['recOfPaymentMadeInfo']['submittedDate'] |
                                    formatDate }}</span></p>
                              </li>
                           </ul>
                           <div class="receipt_ackno"
                              v-if="checkProperty(petition['recOfPaymentMadeInfo'], 'payReceipt') && checkProperty(petition['recOfPaymentMadeInfo'], 'payReceipt', 'length') > 0">
                              <documentsView @download_or_view="downloadfile" :type="'payReceipt'"
                                 :documentsList="petition['recOfPaymentMadeInfo']['payReceipt']"
                                 :petitionDetails="petition" />
                           </div>
                           <div class="receipt_ackno"
                              v-if="checkProperty(petition['trackingInfo'], 'documents') && checkProperty(petition['trackingInfo'], 'documents', 'length') > 0">
                              <documentsView @download_or_view="downloadfile" :type="'documents'"
                                 :documentsList="petition['trackingInfo']['documents']" :petitionDetails="petition" />
                           </div>
                           <ul>
                              <li v-if="checkProperty(petition, 'recOfPaymentMadeInfo', 'updatedOn')">
                                 <p>Updated Date <span> {{ petition['recOfPaymentMadeInfo']['updatedOn'] |
                                    formatDateTime }}</span></p>
                              </li>
                              <li v-if="checkProperty(petition, 'recOfPaymentMadeInfo', 'updatedByName')">
                                 <p>Updated By <span> {{ petition['recOfPaymentMadeInfo']['updatedByName'] }}<small
                                          v-if="checkProperty(petition, 'recOfPaymentMadeInfo', 'updatedByRoleName')">({{
                                             petition['recOfPaymentMadeInfo']['updatedByRoleName'] }})</small></span>
                                 </p>
                              </li>
                           </ul>
                        </div>
                        <!-- <div class="right">
                                    <ul v-if="checkProperty(petition['recOfPaymentMadeInfo'],'payReceipt') && checkProperty(petition['recOfPaymentMadeInfo'],'payReceipt', 'length')>0 ">
                                       <li @click="downloadfile(petition['recOfPaymentMadeInfo']['payReceipt'][0])" >
                                          <figure class="view-detailes_cnt"><img src="@/assets/images/download-white.svg"></figure>
                                       </li>
                                    </ul>
                                 </div> -->
                     </div>
                     <div class="case-approved-body case_approved_v2"
                        v-if="petition['completedActivities'].indexOf('REGISTERED') > -1 && checkProperty(petition, 'registeredInfo', 'updatedOn') && isSlg">
                        <div class="left">
                           <h5 class="success">Registered</h5>
                           <ul>
                              <li class="w-full" v-if="checkProperty(petition, 'registeredInfo', 'comments')">
                                 <p class="comment-sec">Comments <span class="wrapall"
                                       v-html="checkProperty(petition, 'registeredInfo', 'comments')"></span></p>
                              </li>
                              <li v-if="checkProperty(petition, 'registeredInfo', 'registeredDate')">
                                 <p>Registered Date<span> {{ petition['registeredInfo']['registeredDate'] |
                                    formatDate }}</span></p>
                              </li>
                             
                           </ul>
                           <ul>
                              <li v-if="checkProperty(petition, 'registeredInfo', 'updatedOn')">
                                 <p>Updated Date <span> {{ petition['registeredInfo']['updatedOn'] | formatDateTime }}</span>
                                 </p>
                              </li>
                              <li v-if="checkProperty(petition, 'registeredInfo', 'updatedByName')">
                                 <p>Updated By <span> {{ petition['registeredInfo']['updatedByName'] }}<small
                                          v-if="checkProperty(petition, 'registeredInfo', 'updatedByRoleName')">({{
                                             petition['registeredInfo']['updatedByRoleName'] }})</small></span>
                                 </p>
                              </li>
                           </ul>
                        </div>

                     </div>
                     <div class="case-approved-body case_approved_v2"
                        v-if="petition['completedActivities'].indexOf('CONFIRM_PETITIONER_PAYMENT_INFO') > -1 && checkProperty(petition, 'confirmPaymentInfo', 'updatedOn')">
                        <div class="left">
                           <h5 class="success">Receipt of Payment Information Confirmed</h5>
                           <ul v-if="checkProperty(petition, 'confirmPaymentInfo', 'comments')">
                              <li class="w-full" v-if="checkProperty(petition, 'confirmPaymentInfo', 'comments')">
                                 <p class="comment-sec">Comments <span class="wrapall"
                                       v-html="checkProperty(petition, 'confirmPaymentInfo', 'comments')"></span></p>

                              </li>
                           </ul>
                           <ul>
                              <li v-if="checkProperty(petition, 'confirmPaymentInfo', 'updatedOn')">
                                 <p>Updated Date <span> {{ petition['confirmPaymentInfo']['updatedOn'] | formatDateTime }}</span></p>
                              </li>
                              <li v-if="checkProperty(petition, 'confirmPaymentInfo', 'updatedByName')">
                                 <p>Updated By <span> {{ petition['confirmPaymentInfo']['updatedByName'] }}<small
                                          v-if="checkProperty(petition, 'confirmPaymentInfo', 'updatedByRoleName')">({{
                                             petition['confirmPaymentInfo']['updatedByRoleName'] }})</small></span>
                                 </p>
                              </li>
                           </ul>
                        </div>

                     </div>
                     <div class="case-approved-body case_approved_v2"
                        v-if="petition['completedActivities'].indexOf('VERIFY') > -1 && checkProperty(petition, 'verifiedInfo', 'updatedOn') && isSlg " >
                        <div class="left">
                           <h5 class="success">Verified</h5>
                           <ul v-if="checkProperty(petition, 'verifiedInfo', 'comments')">
                              <li class="w-full" v-if="checkProperty(petition, 'verifiedInfo', 'comments')">
                                 <p class="comment-sec">Comments <span class="wrapall"
                                       v-html="checkProperty(petition, 'verifiedInfo', 'comments')"></span></p>

                              </li>
                           </ul>
                           <ul>
                              <li v-if="checkProperty(petition, 'verifiedInfo', 'updatedOn')">
                                 <p>Updated Date <span> {{ petition['verifiedInfo']['updatedOn'] | formatDateTime }}</span></p>
                              </li>
                              <li v-if="checkProperty(petition, 'verifiedInfo', 'updatedByName')">
                                 <p>Updated By <span> {{ petition['verifiedInfo']['updatedByName'] }}<small
                                          v-if="checkProperty(petition, 'verifiedInfo', 'updatedByRoleName')">({{
                                             petition['verifiedInfo']['updatedByRoleName'] }})</small></span>
                                 </p>
                              </li>
                           </ul>
                        </div>

                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</template>
<script>
import * as _ from "lodash";
import documentsView from "@/views/common/documentsView.vue";
import moment from "moment";
export default {
   props: {
      petition: {
         type: [Object, Array],
         default: null,
      },

   },
   methods: {
      downloadfile(value) {
         this.$emit('download_or_view', value);
      },
      petitionLink(item) {
         let routeId = item;
         this.$router.push('/petition-details/' + routeId)
      },
      createCaseRedirect() {
         let data = {};
         if (this.checkProperty(this.petition, 'beneficiaryDetails')) {
            data['beneficiaryDetails'] = this.checkProperty(this.petition, 'beneficiaryDetails')
         }
         if (this.checkProperty(this.petition, 'branchDetails')) {
            data['branchDetails'] = this.checkProperty(this.petition, 'branchDetails')
         }
         if (this.checkProperty(this.petition, 'companyDetails')) {
            data['companyDetails'] = this.checkProperty(this.petition, 'companyDetails')
         }
         if (this.checkProperty(this.petition, '_id')) {
            data['capRegId'] = this.checkProperty(this.petition, '_id')
         }
         data['reqConsdnOfAdvDegreeExptn'] = this.checkProperty(this.petition, 'beneficiaryInfo', 'reqConsdnOfAdvDegreeExptn')

         this.$store.commit('updateCapCaseDetails', data)
         this.$router.push({ name: 'petitions', params: { 'capCaseCreate': true } })
      },
   },
   components: {
      documentsView
   },
   data: () => ({
      isSlg:true,
   }),
   mounted(){
      if(this.checkProperty(this.petition, 'questionnaireTplType') == "general"){
         this.isSlg = false
      }
   }

}

</script>