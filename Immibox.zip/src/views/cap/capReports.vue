<template>
  <div>
    <div class="content-header  primary_filters bulk-assign-btn ">
      <div class="content-header content-header-left pad0">
        <div class="filters-row">
          <div class="con-select">
            <div class="selection_search casetype ml-0">
              <div class="search">
                <div class="vs-component vs-con-input-label vs-input is-label-placeholder vs-input-primary">
                  <div class="vs-con-input">
                    <vs-input icon-pack="feather" icon="icon-search" :placeholder="'Beneficiary Name'"
                      class="is-label-placeholder" v-model.lazy="searchtxt" />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="con-select selection_search selection_search-v2 casetype pn_width"
            v-if="[3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13].indexOf(getUserRoleId) > -1 && getTenantTypeId != 2">
            <div class="search">
              <div class="vs-component vs-con-input-label vs-input is-label-placeholder vs-input-primary">
                <div class="vs-con-input">
                  <multiselect @input="changedperitionersSearch()" v-model="header_selected_petitioners"
                    :options="petitionersList" :multiple="true" :hideSelected="true" :close-on-select="false"
                    :clear-on-select="false" :preserve-search="true" placeholder="Petitioner" label="name" track-by="name"
                    :preselect-first="false" @search-change="peritioners_search_fun">
                    <template slot="selection" slot-scope="{ values, isOpen }">
                      <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                        Petitioner(s)</span>
                      <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                    </template>

                  </multiselect>
                  <!-- <multiselect  v-model="capvalues" :placeholder="'Petitioner'" :options="Petitioners"></multiselect> -->
                </div>
              </div>
            </div>
          </div>
          <div class="con-select  selection_search casetype mc_rc_width" v-if="[51].indexOf(getUserRoleId) <= -1">
            <multiselect @input="changedCaseTypes()" v-model="headerTypeNames" :options="cap" :multiple="true"
              :hideSelected="true" :close-on-select="false" :clear-on-select="false" :preserve-search="true"
              placeholder="Case Type" label="name" track-by="name" :preselect-first="false">
              <template slot="selection" slot-scope="{ values, isOpen }">
                <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                  Case Type(s)</span>
                <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
              </template>

            </multiselect>
          </div>
          <div class="con-select  selection_search casetype section_width" v-if="[51].indexOf(getUserRoleId) <= -1">
            <multiselect @input="getSeasons()" v-model="selectedSeasons" :options="season" :multiple="true"
              :hideSelected="true" :close-on-select="false" :clear-on-select="false" :preserve-search="true"
              placeholder="Season" :preselect-first="false">
              <template slot="selection" slot-scope="{ values, isOpen }">
                <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                  Season(s)</span>
                <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
              </template>
            </multiselect>
            <!-- <multiselect   v-model="values" :placeholder="'Season'" :options="season"></multiselect>  -->
          </div>
          <div class="con-select  selection_search casetype mc_rc_width" v-if="[51].indexOf(getUserRoleId) <= -1">


          </div>

        </div>
      </div>
      <div class="content-header-right">
        <!--filter dropdown-->
        <vs-dropdown vs-custom-content vs-trigger-click>
          <vs-button color="primary" class="filter-btn" type="border" icon-pack="feather" icon="icon-chevron-down"
            icon-after>
            <img src="@/assets/images/main/icon-filter.svg" /> Filters
          </vs-button>
          <vs-dropdown-menu ref="filter_menu" class="filters-content">
            <div class="filters-form-fileds">
              <div class="form-container">
                <div class="vx-row">
                  <div class="vx-col md:w-1/3 w-full con-select filters-search">
                    <label class="typo__label">Title</label>
                    <vs-input icon-pack="feather" icon placeholder="Search by Beneficiary"
                      class="is-label-placeholder" v-model="filter_searchtxt" />
                  </div>
                  <div class="vx-col md:w-1/3 w-full con-select"
                    v-if="[3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13].indexOf(getUserRoleId) > -1 && getTenantTypeId != 2">
                    <label class="typo__label">Petitioner</label>
                    <multiselect @input="changedperitioners()" v-model="selected_peritioners" :options="petitionersList"
                      :multiple="true" :hideSelected="true" :close-on-select="false" :clear-on-select="false"
                      :preserve-search="true" placeholder="Select Petitioner" label="name" track-by="name"
                      :preselect-first="false" @search-change="peritioners_search_fun">
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          Petitioner(s) Selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>

                    </multiselect>

                  </div>
                  <!-- <div class="vx-col md:w-1/3 w-full con-select filters-search">
                    <label class="typo__label">Petitioner</label>
                    <multiselect  v-model="Petitioner" :options="Petitioneroptions">
                    </multiselect> 
                  </div> -->
                  <div class="vx-col md:w-1/3 w-full con-select filters-search">
                    <label class="typo__label">Case Type</label>
                    <!-- <multiselect  v-model="selectedtypeNames" :options="cap">
                  </multiselect>  -->
                    <multiselect @input="changedperitioners()" v-model="selectedtypeNames" :options="cap" :multiple="true"
                      :hideSelected="true" :close-on-select="false" :clear-on-select="false" :preserve-search="true"
                      placeholder="Select Case Type" label="name" track-by="name" :preselect-first="false">
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          Case Type(s) Selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>

                    </multiselect>
                  </div>
                  <div class="vx-col md:w-1/3  w-full con-select filters-search" v-if="false">
                    <div class=" select-large">
                      <label for="" class="typo__label">Degree Level</label>
                      <multiselect v-model="selectedEducations" :options="education_types" :multiple="true"
                        :hideSelected="true" :close-on-select="false" :clear-on-select="false" :preserve-search="true"
                        placeholder="Select Degree Level" label="name" track-by="name" :preselect-first="false">
                        <template slot="selection" slot-scope="{ values, isOpen }">
                          <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                            Degree(s) Selected</span>
                          <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                        </template>

                      </multiselect>
                    </div>
                  </div>
                  <div class="vx-col md:w-1/3 w-full con-select" v-if="false">
                    <label class="typo__label">Graduation Period</label>
                    <date-range-picker :maxDate="new Date()" :autoApply="autoApply" :ranges="false" :opens="'left'"
                      v-model="selected_createdDateRange"></date-range-picker>
                  </div>
                  <div class="vx-col md:w-1/3  w-full con-select filters-search">
                    <div class=" select-large">
                      <label for="" class="typo__label">Case Status </label>
                      <multiselect v-model="selectedStatus" :options="caseStatusList" :multiple="true"
                        :hideSelected="true" :close-on-select="false" :clear-on-select="false" :preserve-search="true"
                        placeholder="Select status" label="name" track-by="name" :preselect-first="false">
                        <template slot="selection" slot-scope="{ values, isOpen }">
                          <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                            Status(s) Selected</span>
                          <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                        </template>

                      </multiselect>
                    </div>
                  </div>
                  <div class="vx-col md:w-1/3 w-full con-select" v-if="false">
                    <label class="typo__label">Premium Processing</label>
                    <multiselect @input="$router.push({ query: {} })" v-model="selectedpremiumProcessing"
                      :options="premiumProcessingList" :multiple="true" :hideSelected="true" :close-on-select="false"
                      :clear-on-select="false" :preserve-search="true" placeholder="Select Premium Processing"
                      label="name" track-by="name" :preselect-first="false">

                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          Premium Processing(s) Selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>
                </div>
              </div>
            </div>
            <div class="filters-status">
              <div class="left-buttons"></div>
              <div class="right-buttons">
                <vs-button color="success" class="save" type="filled" v-on:click="set_filter()">Apply</vs-button>
                <vs-button color="dark" class="cancel" type="filled" v-on:click="clear_filter($event)">Clear</vs-button>
              </div>
            </div>
          </vs-dropdown-menu>
        </vs-dropdown>
        <vs-button color="primary" type="border" class="light-blue-btn"
          v-if="checkCaseCreatePermisions && [50, 51].indexOf(getUserRoleId) <= -1 && false"
          @click="openCreateCasePopup(true)">New&nbsp;Case</vs-button>
        <div class="Generate_buttons" @click="getExportList()">
          <button class="copy_link" v-bind:disabled="exportList">
            <img src="@/assets/images/main/share.png" />
            <small>Export</small>
          </button>
        </div>
      </div>
    </div>
    <NoDataFound ref="NoDataFoundRef" :loading="isListloading" v-if="capRegistartionList.length == 0" content=""
      :heading="callFromSearch ? 'No Results Found' : 'No Cases Found'" type='petitions' />
    <div class="accordian-table custom-table cpr_table cpr_table_v2" v-if="capRegistartionList.length > 0">

      <div class="vs-table--content">
        <div class="vs-con-tbody">
          <table class="vs-table vs-table--tbody-table">
            <thead class="vs-table--thead">
              <tr>
                <th v-if="[50].indexOf(getUserRoleId) <= -1 && getTenantTypeId != 2">
                  <div class="vs-table-text">
                    <a @click="sortMe('companyName')"
                      v-bind:class="{ 'sort_ascending': sortKeys['companyName'] == 1, 'sort_descending': sortKeys['companyName'] != 1 }">Petitioner
                      Name</a>
                  </div>
                </th>
                <th v-if="[51].indexOf(getUserRoleId) <= -1">
                  <div class="vs-table-text">
                    <a @click="sortMe('beneficiaryName')"
                      v-bind:class="{ 'sort_ascending': sortKeys['beneficiaryName'] == 1, 'sort_descending': sortKeys['beneficiaryName'] != 1 }">Beneficiary
                      Name</a>
                  </div>
                </th>
                <th>
                  <div class="vs-table-text">
                    <a @click="sortMe('passportNumber')"
                      v-bind:class="{ 'sort_ascending': sortKeys['passportNumber'] == 1, 'sort_descending': sortKeys['passportNumber'] != 1 }">Passport
                      Number</a>
                  </div>
                </th>
                <th>
                  <div class="vs-table-text">
                    <a @click="sortMe('dateOfBirth')"
                      v-bind:class="{ 'sort_ascending': sortKeys['dateOfBirth'] == 1, 'sort_descending': sortKeys['dateOfBirth'] != 1 }">Date
                      of Birth</a>
                  </div>
                </th>
                <th>
                  <div class="vs-table-text">
                    <a @click="sortMe('countryOfCitizenshipName')"
                      v-bind:class="{ 'sort_ascending': sortKeys['countryOfCitizenshipName'] == 1, 'sort_descending': sortKeys['countryOfCitizenshipName'] != 1 }">Nationality</a>
                  </div>
                </th>
                <th>
                  <div class="vs-table-text">
                    <a @click="sortMe('reqConsdnOfAdvDegreeExptn')"
                      v-bind:class="{ 'sort_ascending': sortKeys['reqConsdnOfAdvDegreeExptn'] == 1, 'sort_descending': sortKeys['reqConsdnOfAdvDegreeExptn'] != 1 }">US
                      Masters Degree</a>
                  </div>
                </th>
                <th>
                  <div class="vs-table-text">
                    <a @click="sortMe('reqConsdnOfAdvDegreeExptn')"
                      v-bind:class="{ 'sort_ascending': sortKeys['reqConsdnOfAdvDegreeExptn'] == 1, 'sort_descending': sortKeys['reqConsdnOfAdvDegreeExptn'] != 1 }">
                      University Name</a>
                  </div>
                </th>

                <th>
                  <div class="vs-table-text">
                    <a @click="sortMe('graduatedYear')"
                      v-bind:class="{ 'sort_ascending': sortKeys['graduatedYear'] == 1, 'sort_descending': sortKeys['graduatedYear'] != 1 }">
                      <span v-if="isSlg"> Graduated Year/Date</span>
                      <span v-else>Graduated Year</span>
                    </a>
                  </div>
                </th>
                <th v-if="isSlg">
                  <div class="vs-table-text">
                    <a @click="sortMe('isAccredited')"
                      v-bind:class="{ 'sort_ascending': sortKeys['isAccredited'] == 1, 'sort_descending': sortKeys['isAccredited'] != 1 }">Accredited
                      University</a>
                  </div>
                </th>
                <th v-if="isSlg">
                  <div class="vs-table-text">
                    <a @click="sortMe('isForProfit')"
                      v-bind:class="{ 'sort_ascending': sortKeys['isForProfit'] == 1, 'sort_descending': sortKeys['isForProfit'] != 1 }">For-Profit
                      University</a>
                  </div>
                </th>
                <th>
                  <div class="vs-table-text">
                    <a @click="sortMe('statusName')"
                      v-bind:class="{ 'sort_ascending': sortKeys['statusName'] == 1, 'sort_descending': sortKeys['statusName'] != 1 }">Status</a>
                  </div>
                </th>
                <th v-if="isSlg">
                  <div class="vs-table-text">
                    <a @click="sortMe('reqConsdnOfAdvDegreeExptn')"
                      v-bind:class="{ 'sort_ascending': sortKeys['reqConsdnOfAdvDegreeExptn'] == 1, 'sort_descending': sortKeys['reqConsdnOfAdvDegreeExptn'] != 1 }">
                      University Address</a>
                  </div>
                </th>



              </tr>
            </thead>
            <tr class="vs-table--tr" v-for="(petition, index) in capRegistartionList" :key="index">
              <td class="td vs-table--td" v-if="[50].indexOf(getUserRoleId) <= -1 && getTenantTypeId != 2">
                <span>
                  <span class="cursor-pointer" @click="petitionlink(petition)"
                    v-tooltip="{ content: checkProperty(petition, 'companyDetails', 'name') }"> {{
                      checkProperty(petition, 'companyDetails', 'name') | CapSubString }} </span>
                </span>
              </td>
              <td class="td_label" v-if="[51].indexOf(getUserRoleId) <= -1">
               
                  <span class="cursor-pointer" @click="petitionlink(petition)"
                    v-tooltip="{ content: checkProperty(petition, 'beneficiaryInfo', 'name') }">{{
                      checkProperty(petition, 'beneficiaryInfo', 'name') | CapSubString }} </span>
                  <span class="cursor-pointer"  @click="petitionlink(petition)">
                    <small> {{ checkProperty(petition ,'beneficiaryInfo','email') }} </small>
                  </span>
                
              </td>
              <td class="td vs-table--td"><span class="cursor-pointer" @click="petitionlink(petition)">{{
                checkProperty(petition, 'beneficiaryInfo', 'passportNumber') }}</span>
              </td>
              <td class="td vs-table--td"><span class="cursor-pointer" @click="petitionlink(petition)">{{
                checkProperty(petition, 'beneficiaryInfo', 'dateOfBirth') |
                formatDate }}</span></td>
              <td class="td vs-table--td"><span class="cursor-pointer" @click="petitionlink(petition)">{{
                checkProperty(petition, 'beneficiaryInfo',
                  'countryOfCitizenshipName')
              }}</span></td>

              <td class="td_label">
                <div class="cursor-pointer" @click="petitionlink(petition)">
                  {{ checkProperty(petition, 'beneficiaryInfo', 'reqConsdnOfAdvDegreeExptn') | booleanFormat }} <br />
                  <!-- <small
                    v-if="checkProperty(petition, 'beneficiaryInfo', 'reqConsdnOfAdvDegreeExptn') == true || checkProperty(petition, 'beneficiaryInfo', 'reqConsdnOfAdvDegreeExptn') == 'true'">
                    {{ checkProperty(petition['beneficiaryInfo'], 'lastEducation', 'name') }} </small> -->
                </div>
                <!-- <span @click="petitionlink(petition)">{{checkProperty(petition,'reqConsdnOfAdvDegreeExptn')}}</span> -->
              </td>
              <td class="td vs-table--td"><span class="cursor-pointer"
                  v-if="checkProperty(petition, 'beneficiaryInfo', 'reqConsdnOfAdvDegreeExptn') == true || checkProperty(petition, 'beneficiaryInfo', 'reqConsdnOfAdvDegreeExptn') == 'true'"
                  @click="petitionlink(petition)">{{ checkProperty(petition['beneficiaryInfo'], 'lastEducation',
                    'name') }}</span>
                <span v-else>
                  -
                </span>
              </td>


              <td class="td vs-table--td">
                <span class="cursor-pointer"
                  v-if="checkProperty(petition, 'beneficiaryInfo', 'reqConsdnOfAdvDegreeExptn') == true || checkProperty(petition, 'beneficiaryInfo', 'reqConsdnOfAdvDegreeExptn') == 'true'"
                  @click="petitionlink(petition)">
                  <span
                    v-if="checkProperty(petition['beneficiaryInfo'], 'lastEducation', 'graduatedYear')">{{ checkProperty(petition['beneficiaryInfo'], 'lastEducation',
                      'graduatedYear') }}</span>
                  <span
                    v-if="checkProperty(petition['beneficiaryInfo'], 'lastEducation', 'graduatedDate')">{{ checkProperty(petition['beneficiaryInfo'], 'lastEducation',
                      'graduatedDate') | formatDate }}</span>
                </span>
                <span v-else>
                  -
                </span>
              </td>


              <td v-if="isSlg" class="td vs-table--td"><span class="cursor-pointer" @click="petitionlink(petition)">{{
                checkProperty(petition['beneficiaryInfo'],
                  'lastEducation', 'isAccredited') | booleanFormat }}</span></td>
              <td v-if="isSlg" class="td vs-table--td"><span class="cursor-pointer" @click="petitionlink(petition)">{{
                checkProperty(petition['beneficiaryInfo'],
                  'lastEducation', 'isForProfit') | booleanFormat }}</span></td>
              <td class="td vs-table--td">
                <span @click="petitionlink(petition)">

                  <span
                    v-if="checkProperty(petition, 'intStatusDetails', 'id') && checkProperty(petition, 'intStatusDetails', 'id') == 2"
                    class="statusspan cursor-pointer" v-bind:class="{
                      ' status_inProcess ': checkProperty(petition, 'intStatusDetails', 'id') == 2
                    }">{{ checkProperty(petition, 'intStatusDetails', 'name') }}
                  </span>
                  <span
                    v-if="(!checkProperty(petition, 'intStatusDetails', 'id') || (checkProperty(petition, 'intStatusDetails', 'id') && checkProperty(petition, 'intStatusDetails', 'id') != 2))"
                    class="statusspan cursor-pointer" v-bind:class="{
                      ' status_created ': checkProperty(petition, 'statusDetails', 'id') == 1 || checkProperty(petition, 'statusDetails', 'id') == 11,
                      ' status_submited ': checkProperty(petition, 'statusDetails', 'id') == 2,
                      ' status_inProcess ': checkProperty(petition, 'statusDetails', 'id') == 3,
                      ' status_verified ': checkProperty(petition, 'statusDetails', 'id') == 4,
                      ' status_registered ': checkProperty(petition, 'statusDetails', 'id') == 5,
                      ' status_submited-USCIS ': checkProperty(petition, 'statusDetails', 'id') == 6,
                      ' status_selected': checkProperty(petition, 'statusDetails', 'id') == 7,
                      ' status_not_selected ': checkProperty(petition, 'statusDetails', 'id') == 8,
                      ' status_denied': checkProperty(petition, 'statusDetails', 'id') == 9,
                      ' status_payment_failed ': checkProperty(petition, 'statusDetails', 'id') == 10,
                    }">{{ checkProperty(petition, 'statusDetails', 'name') }}</span>
                </span>
              </td>
              <td v-if="isSlg" class="td vs-table--td"><span class="cursor-pointer"
                  v-if="checkProperty(petition, 'beneficiaryInfo', 'reqConsdnOfAdvDegreeExptn') == true || checkProperty(petition, 'beneficiaryInfo', 'reqConsdnOfAdvDegreeExptn') == 'true'"
                  @click="petitionlink(petition)">{{ checkProperty(petition['beneficiaryInfo'], 'lastEducation',
                    'fullAddress') }}</span>
                <span v-else>
                  -
                </span>
              </td>


            </tr>

          </table>
        </div>
      </div>
      <div class="table_footer">
        <div class="vx-col  con-select pages_select" v-if="capRegistartionList.length > 0">
          <label class="typo__label">Per Page</label>
          <multiselect @input="changeperPage()" v-model="perpage" :options="perPeges" :multiple="false"
            :close-on-select="true" :clear-on-select="false" :preserve-search="true" placeholder="Per Page"
            :preselect-first="true">

          </multiselect>
          <span class="totla_list_count" v-if="totalCount"> Total <em>{{totalCount}}</em></span>
        </div>
        <paginate v-if="capRegistartionList.length > 0" v-model="page" :page-count="totalpages" :page-range="3"
          :margin-pages="2" :click-handler="pageNate"
          prev-class="vs-pagination--buttons btn-prev-pagination vs-pagination--button-prev"
          next-class="vs-pagination--buttons btn-next-pagination vs-pagination--button-next" :prev-text="'<i></i>'"
          :next-text="'<i></i>'" :container-class="'pagination vs-pagination--nav'" :page-class="'page-item'">
        </paginate>
      </div>
    </div>
    <vs-popup class="holamundo main-popup" title="Invite Customer" :active.sync="invitepetitioner">
      <addBenewPet @closenewPetPopup="closenewPetPopup" v-if="invitepetitioner" />
    </vs-popup>
    <vs-popup class="holamundo main-popup" :class="{ 'openedNewpetpopup': invitepetitioner }" :title="'Add Beneficiary'"
      :active.sync="AddBeneficiary">
      <addBeneficiary ref="add_ben" @closeAddBenPopUp="closeAddBenPopUp" v-if="AddBeneficiary"
        :petitioner="selectedPetitioner" @openAddpetPopUp="openAddpetPopUp" />
    </vs-popup>


    <vs-popup class="holamundo main-popup" :class="{ 'openedNewpetpopup': invitepetitioner || AddBeneficiary }"
      title="New Case" :active.sync="NewPetition">
      <form data-vv-scope="newCapCreationform">
        <div class="form-container">
          <div class="vx-row">
            <div class="vx-col w-full">
              <div class="form_group">
                <div class="con-select w-full select-large">
                  <label class="form_label">Select Branch<em>*</em></label>
                  <multiselect name="branch" data-vv-as="Branch" v-validate="'required'" v-model="selectedBranch"
                    :show-labels="false" track-by="_id" label="name" placeholder="Select Branch" :options="branchList"
                    :searchable="true" :allow-empty="false" :multiple="false"
                    :disabled="(branchList.length == 1 && checkProperty(selectedBranch, '_id') != '') || disableOffice"
                    @input="formerrors.msg = ''">
                  </multiselect>
                  <span class="text-danger text-sm" v-show="errors.has('newCapCreationform.branch')">{{
                    errors.first("newCapCreationform.branch")
                  }}</span>
                  <!-- <multiselect v-model="selectedBeneficiary" :options="beneficiaryMasterDataList">
                  </multiselect> -->
                </div>

              </div>
            </div>
            <div class="vx-col w-full pp-col">
              <vs-checkbox id="premium" name="premiumProcessing" v-model="premiumProcessing">Premium Processing
              </vs-checkbox>
            </div>
            <div class="vx-col w-1/2" v-if="([3, 4, 5, 6, 7, 8].indexOf(getUserRoleId) > -1)">
              <div class="form_group">
                <div class="con-select w-full select-large">
                  <label class="form_label">Select Petitioner<em>*</em></label>
                  <multiselect v-model="selectedPetitioner" :options="petitionersList" :multiple="false"
                    :hideSelected="false" :close-on-select="true" :clear-on-select="false" :preserve-search="true"
                    :select-label="'Search Petitioner'" placeholder="Select Petitioner" label="name" track-by="name"
                    :preselect-first="false" data-vv-as="Petitioner" v-validate="'required'"
                    tag-placeholder="Invite Petitioner" :taggable="false" @tag="addNewPet" :searchable="true"
                    @search-change="searchPet" @input="petitionerUpdated" name="Petitioner">

                    <template slot="selection" slot-scope="{ values, isOpen }">
                      <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                        options selected</span>
                      <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                    </template>
                  </multiselect>

                  <span class="text-danger text-sm" v-show="errors.has('newCapCreationform.Petitioner')">{{
                    errors.first("newCapCreationform.Petitioner")
                  }}</span>
                  <!-- <multiselect v-model="selectedPetitioner" :options="PetitionerMasterDataList">
                  </multiselect> -->
                </div>
              </div>
              <p class="createnew">Not found? <span @click="addNewPet()">Invite Petitioner</span></p>
            </div>
            <div class="vx-col w-1/2" :class="{ 'w-full': [50].indexOf(getUserRoleId) > -1 }"
              v-if="([3, 4, 5, 6, 7, 8, 50].indexOf(getUserRoleId) > -1)">
              <div class="form_group">
                <div class="con-select w-full select-large">
                  <label class="form_label">Select Beneficiary<em>*</em></label>
                  <multiselect v-model="selectedBeneficiary" :options="beneficiaryMasterDataList" :multiple="false"
                    :hideSelected="false" :close-on-select="true" :clear-on-select="false" :preserve-search="true"
                    :select-label="'Search Beneficiary'" placeholder="Select Beneficiary" label="name" track-by="name"
                    :preselect-first="false" data-vv-as="Beneficiary" v-validate="'required'" :searchable="true"
                    @search-change="getbeneficiaryMasterDataList" name="beneficiary" @input="upDateBenef"
                    tag-placeholder="Add New Beneficiary" :taggable="false"
                    :disabled="(!checkProperty(selectedPetitioner, '_id') && [50].indexOf(getUserRoleId) <= -1)">

                    <template slot="selection" slot-scope="{ values, isOpen }">
                      <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                        options selected</span>
                      <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                    </template>
                  </multiselect>

                  <span class="text-danger text-sm" v-show="errors.has('newCapCreationform.beneficiary')">{{
                    errors.first("newCapCreationform.beneficiary")
                  }}</span>
                  <!-- <multiselect v-model="selectedBeneficiary" :options="beneficiaryMasterDataList">
                  </multiselect> -->
                </div>

              </div>
              <p class="createnew">Not found? <span @click="AddBeneficiary = true; selectedBeneficiary = null ">Invite
                  Beneficiary</span>
              </p>
            </div>


          </div>
        </div>

        <div class="popup-footer relative">
          <vs-button color="dark" @click="openCreateCasePopup(false)" class="cancel" type="filled">Cancel</vs-button>
          <vs-button color="success" class="save" type="filled" @click="createNewCap()">Submit
          </vs-button>
        </div>
      </form>
    </vs-popup>


  </div>
</template>
<script>
import Paginate from "vuejs-paginate";
import moment from 'moment'
import _ from "lodash";
import Vue from 'vue'
import NoDataFound from "@/views/common/noData.vue";
import Multiselect from "vue-multiselect-inv";
import JQuery from "jquery";
import addBenewPet from "@/views/common/invitePet.vue"
import addBeneficiary from "@/views/common/addBeneficiary.vue"
//import addBeneficiary  from "@/views/common/addBeneficiary.vue" 
//import addPetitioner  from "@/views/common/addPetitioner.vue" 
import DateRangePicker from "vue2-daterange-picker";
import Datepicker from "vuejs-datepicker-inv";
import "vue2-daterange-picker/dist/vue2-daterange-picker.css";
//import JsonExcel from "vue-json-excel";
//Vue.component("downloadExcel", JsonExcel);
export default {
  watch: {
    searchtxt: function (value) {
      let text = value.trim();

      if (text.length > 3 || text == '') {
        this.getCapList(true, false);
      }

    },
  },
  data: function () {
    return {
      isSlg: true,
      exportList: false,
      jsonData: [
        { "name": "SR", "email": 'ravis@innvectra.com' },
        { "name": "Ravi Kumar", "email": 'ravi@innvectra.com' }
      ],
      formerrors: {
        msg: ''
      },
      exportData: {},
      headerSelectedCaseTypes: [],
      selectedSeasons: [],
      selectedpremiumProcessing: [],
      premiumProcessingList: [{ name: 'Yes', _id: true }, { name: 'No', _id: false }],
      selectedStatus: [],
      caseStatusList: [],
      selectedEducations: [],
      education_types: [],
      selectedtypeNames: [],
      headerTypeNames: [],
      autoApply: '',
      disableOffice: false,
      branchList: [],
      selectedBranch: null,
      premiumProcessing: false,
      petitionersList: [],
      beneficiaryMasterDataList: [],
      selectedPetitioner: null,
      selectedBeneficiary: null,
      selectedUsername: null,
      selectedUser: null,
      capRegistartionList: [],
      sortKeys: {},
      sortKey: {},
      page: 1,
      perpage: 25,
      totalpages: 0,
      totalCount:0,
      perPeges: [10, 25, 50, 75, 100],
      callFromSearch: false,
      isListloading: false,
      filter_searchtxt: '',
      searchtxt: '',
      header_selected_petitioners: [],
      selected_peritioners: [],
      final_selected_peritioners: [],
      encodedString: '',
      selected_createdDateRange: ["", ""],
      /////
      enableNextBtn: false,
      selectAllForArchive: false,
      selectedItem: false,
      value: null,
      values: null,
      capvalues: null,
      Petitioner: null,

      selected: null,
      selecte: null,
      AddBeneficiary: false,
      addPetitionerr: false,
      addcprbeneficiary: false,
      NewPetition: false,
      anonymousUser: false,
      options: ['10th / 12th Grade', 'Bachelors', 'Associate', 'Masters'],
      optionscase: ['Active', 'In active'],
      cap: [{ "name": 'Master Cap', "id": true, },
      { "name": 'Regular Cap', "id": false, }],
      Petitioneroptions: ['James', 'Michael'],
      caps: ['Master Cap', 'Regular Cap'],
      Petitioners: ['James', 'Michael'],
      season: [2023],
      fromUserList: ['Created', 'Sent for Petitioner Authorization', 'Petitioner Confirmation', 'Attorney Approval', 'Receipt of Payment Made', 'Submitted to USCIS', 'Selected', 'Petition Created'],
      //beneficiaryMasterDataList:['Rahul krishna' , 'Sathish'],
      PetitionerMasterDataList: ['Rahul krishna', 'Sathish'],

      selected_deadLineDateRange: ["", ""],
      wiseSelection: 'true',
    }
  },
  components: {
    Multiselect,
    Paginate,
    NoDataFound,
    addBeneficiary,
    addBenewPet,
    //addBeneficiary,
    //addPetitioner,
    Datepicker,
    DateRangePicker,

  },
  methods: {
    getCapList(callFromSearch = false, callFromFilter = false) {
      this.exportData = {};
      this.callFromSearch = callFromSearch
      if (this.callFromSearch) {
        this.capRegistartionList = []
      }
      //'623b3c3c75d58329b830cdcd','625e6857cadbc43c50c92ee7','628f6b6b096c8624d886648b'
      let Payload = {
        matcher: {
          searchString: this.searchtxt,
          petitionerIds: this.final_selected_peritioners,
          beneficiaryIds: [],
          statusIds: [],
          statusList: [],
          branchIds: [],
          typeNames: [],
          seasonList: [],
          capTypeList: [],
          premiumProcessing: [],
          getForReport: true,
        },
        page: this.page,
        perpage: this.perpage,
        sorting: this.sortKey,
        today: moment().format('YYYY-MM-DD'),
      }
      if (this.selectedSeasons && this.checkProperty(this.selectedSeasons, 'length') > 0) {
        Payload['matcher']['seasonList'] = this.selectedSeasons
      }
      if (this.selectedpremiumProcessing && this.checkProperty(this.selectedpremiumProcessing, 'length') > 0) {
        Payload['matcher']['premiumProcessing'] = this.selectedpremiumProcessing.map((item) => item._id)
      }
      if (this.selectedStatus && this.checkProperty(this.selectedStatus, 'length') > 0) {
        Payload['matcher']['statusIds'] = this.selectedStatus.map((item) => item.id)
      };
      if (this.selectedtypeNames) {
        Payload['matcher']['capTypeList'] = this.selectedtypeNames.map((item) => item.id)
      }
      this.exportData = Payload['matcher'];
      this.isListloading = true;
      this.updateLoading(true);
      this.$store.dispatch("commonAction", { "data": Payload, "path": "/cap-registrations/list" }).then((response) => {
        this.isListloading = false;
        this.updateLoading(false);
        this.capRegistartionList = response.list;
        this.totalCount = this.checkProperty(response, 'totalCount')
        this.totalpages = Math.ceil(response.totalCount / this.perpage)
        setTimeout(() => {
          this.updateLoading(false);
        }, 10);
      })
        .catch((err) => {
          this.isListloading = false;
          this.updateLoading(false);
        })
    },
    getExportList() {
      let Payload = {
        matcher: {},
        today: ''
      };
      Payload['matcher'] = this.exportData;
      Payload['today'] = moment().format('YYYY-MM-DD'),
        this.exportList = true;
      this.$store.dispatch("commonAction", { "data": Payload, "path": "/cap-registrations/export-list" }).then((response) => {
        this.exportList = false;
        if (this.checkProperty(response, 'path')) {
          window.open(this.$globalgonfig._APIURL + "/common/viewfile?filename=CAP_Registrations_Report.xlsx&path=" + this.checkProperty(response, 'path'), "_blank");
        }
      }).catch((err) => {
        this.exportList = false;
      })
    },
    openCreateCasePopup(action) {
      this.disableOffice = false;
      this.NewPetition = action;
      this.selectedPetitioner = null;
      this.selectedBeneficiary = null;
      this.selectedUsername = null;
      this.selectedUser = null;
      this.premiumProcessing = false;
      this.selectedBranch = null;
      if ([3, 4, 50].indexOf(this.getUserRoleId) <= -1) {
        if (this.checkProperty(this.getUserData, 'branchDetails')) {
          let branchDetails = this.checkProperty(this.getUserData, 'branchDetails')
          this.selectedBranch = { "name": '', '_id': '' };
          this.selectedBranch['name'] = branchDetails['name'];
          this.selectedBranch['_id'] = branchDetails['_id'];
          this.disableOffice = true;
        }
      }
      this.$validator.reset();
    },
    createNewCap() {
      this.$validator.validateAll('newCapCreationform').then(result => {
        if (result) {
          let Payload = {
            userId: "",
            userName: "",
            today: moment().format('YYYY-MM-DD'),
            branchId: "",
            petitionerId: "",
            premiumProcessing: this.premiumProcessing,
          }
          if (this.selectedUser) {
            Payload['userId'] = this.selectedUser
          }
          if (this.selectedUsername) {
            Payload['userName'] = this.selectedUsername
          }
          if (this.getTenantTypeId != 2) {
            if ([50].indexOf(this.getUserRoleId) > -1) {
              Payload['petitionerId'] = this.$store.state.user._id

            } else {
              Payload['petitionerId'] = this.checkProperty(this.selectedPetitioner, "userId")
            }
          }
          // if(this.checkProperty(this.selectedPetitioner, '_id')){
          //   Payload['petitionerId'] = this.checkProperty(this.selectedPetitioner, '_id')
          // }
          if (this.selectedBranch && _.has(this.selectedBranch, "_id")) {
            Payload['branchId'] = this.selectedBranch['_id']
          }
          let path = '/cap-registrations/create'
          this.$store.dispatch("commonAction", { "data": Payload, "path": path })
            .then((response) => {
              this.NewPetition = false;
              this.openCreateCasePopup(false)
              this.getCapList()
              this.showToster({ message: response.message, isError: false });
              if (this.checkProperty(response, '_id')) {
                let routedId = this.checkProperty(response, '_id')
                setTimeout(() => {
                  this.$router.push({ path: `/cap-registration-details/${routedId}`, query: { 'filter': this.encodedString } })
                })
              }
            })
            .catch((err) => {})
        }
      })
    },
    changedCaseTypes() {
      this.selectedtypeNames = this.headerTypeNames
      if (this.selectedtypeNames) {
        this.set_filter();
      }
    },
    pageNate(pageNum) {

      this.page = pageNum;
      this.getCapList();
    },
    changedperitioners() {
      this.$router.push({ query: {} })
      this.final_selected_peritioners = [];
      if (this.selected_peritioners.length > 0) {
        for (let i = 0; i < this.selected_peritioners.length; i++) {
          this.final_selected_peritioners.push(
            this.selected_peritioners[i]["userId"]
          );
        }
      }
      //this.get_peritioners_beneficiaries();
    },
    changedperitionersSearch() {
      this.selected_peritioners = this.header_selected_petitioners
      this.$router.push({ query: {} })
      this.final_selected_peritioners = [];
      if (this.selected_peritioners.length > 0) {
        for (let i = 0; i < this.selected_peritioners.length; i++) {
          this.final_selected_peritioners.push(
            this.selected_peritioners[i]["userId"]
          );
        }
      }
      this.set_filter();
    },
    peritioners_search_fun(searchValue) {
      //this.peritioners_search_value = searchValue;
      //this.get_peritioners();
    },
    changeperPage() {
      this.page = 1;
      localStorage.setItem('petitions_perpage', this.perpage);
      this.getCapList(true);
    },
    sortMe(sort_key = '') {
      if (sort_key != '') {
        this.sortKeys[sort_key] = this.sortKeys[sort_key] == 1 ? -1 : 1
        this.sortKey = {};
        this.sortKey = { "path": sort_key, "order": this.sortKeys[sort_key] }
        localStorage.setItem('petitions_sort_key', sort_key);
        localStorage.setItem('petitions_sort_value', this.sortKey[sort_key]);
        this.getCapList();
      }
    },
    getBranchList() {

      this.branchList = [];
      let item = {
        filters: {
          "title": '',
          "createdDateRange": [],
          "statusList": [],
          "activeList": [],
          "countryIds": [],
          "stateIds": [],
          "locationIds": []
        },
        getMasterData: true,
        page: 1,
        perpage: 1000,
        sorting: { "path": "createdOn", "order": -1 },

      };
      this.$store
        .dispatch("getList", { "data": item, "path": "/branch/list" })
        .then(response => {

          this.branchList = response.list;
          if (this.branchList.length == 1) {
            this.selectedBranch = this.branchList[0];
          }
        }).catch((error) => {
          this.branchList = [];
        })
    },
    getSeasons() {
      this.set_filter()
    },
    upDateBenef() {
      if (this.checkProperty(this.selectedBeneficiary, 'name') && this.checkProperty(this.selectedBeneficiary, '_id')) {
        this.selectedUser = this.checkProperty(this.selectedBeneficiary, '_id');
        this.selectedUsername = this.checkProperty(this.selectedBeneficiary, 'name');
      }
    },
    set_filter: function () {
      this.searchtxt = this.filter_searchtxt;
      this.getCapList();
      this.headerTypeNames = this.selectedtypeNames;
      this.header_selected_petitioners = this.selected_peritioners
      this.$refs["filter_menu"].dropdownVisible = false;
    },
    clear_filter: function () {
      this.selectedSeasons = [];
      this.selectedStatus = [];
      this.selectedpremiumProcessing = [];
      this.selectedtypeNames = [];
      this.final_selected_peritioners = [];
      this.selected_peritioners = [];
      this.searchtxt = '';
      this.filter_searchtxt = '';
      this.getCapList();
      this.headerTypeNames = [];
      this.header_selected_petitioners = [];
      this.selected_createdDateRange["startDate"] = "";
      this.selected_createdDateRange["endDate"] = "";
      this.$refs["filter_menu"].dropdownVisible = false;
    },
    petitionerUpdated() {
      this.selectedBeneficiary = null;
      this.selectedUser = '';
      this.selectedUsername = '';
      this.getbeneficiaryMasterDataList();
    },
    getbeneficiaryMasterDataList(text = '') {
      let postData = {
        "matcher": {
          "title": text,
          "statusList": [],
          "branchIds": [],
          "companyIds": [], // Required only for Tenant Admin and Branch Manager to list Beneficiaries
          "createdByIds": [],
          "createdDateRange": [],
          "roleIds": [51],
          "statusIds": [],
          "petitionTypeIds": [],
          "petitionSubTypeIds": [],
          "petitionCreatedDateRange": [],
          "petitionStatusIds": [],
          "getPetitionStats": true
        },
        "sorting": {
          "path": "createdOn", // invitedByName, updatedOn, name, email, phone, statusName, roleName
          "order": 1
        },
        "page": 1,
        "perpage": 1000000,
        "getMasterData": true,
        "getBeneficiaryList": true, // Required only for Tenant Admin and Branch Manager to list Beneficiaries
        "branchId": "", // Required when 'getMasterData' is true and roleIds are [4, 5, 6, 7, 8, 9, 10, 11]
        "companyId": "" // Required when 'getMasterData' is true and roleIds are [50, 51]
      };

      this.enableAddNewBenTag = false;
      if (this.checkProperty(this.selectedPetitioner, "_id")) {

        postData['companyId'] = this.selectedPetitioner['_id']

      }
      if ([50, 51].indexOf(this.getUserRoleId) > -1) {

        postData['companyId'] = this.checkProperty(this.getUserData, "companyDetails", "_id")
      }
      //this.beneficiaryMasterDataList =[];
      this.$store
        .dispatch("petitioner/getbeneficiaries", postData)
        .then(response => {
          this.beneficiaryMasterDataList = response.list;

          let filteredData = [];
          _.forEach(this.beneficiaryMasterDataList, (item) => {
            if (item && (_.has(item, 'name') || _.has(item, 'email'))) {

              if ((_.has(item, 'name') && item['name'].includes(text)) || (_.has(item, 'email') && item['email'].includes(text))) {
                filteredData.push(item)
              } else {
                return false;
              }

            } else {
              return false;
            }


          })

          //  if(filteredData.length<=0){
          //    this.enableAddNewBenTag =true;
          //  }


        })

    },
    petitionlink(tr) {
      let routedId = this.checkProperty(tr, '_id')
      //this.$router.push('/cap-registration-details/'+this.checkProperty( tr,'_id'))ap-registration-questionnaire
      this.$router.push({ path: `/cap-registration-details/${routedId}`, query: { 'filter': this.encodedString } })
      //this.$router.push({path: `/cap-registration-questionnaire/${routedId}` ,query: {'filter':this.encodedString} })    
    },
    selectedForNext() {
      let selectedCaps = _.filter(this.capList, { "isSelected": true });
      if (selectedCaps && this.checkProperty(selectedCaps, 'length') > 0) {
        this.enableNextBtn = true;
        this.selectAllForArchive = false
      }

      else {
        this.enableNextBtn = false;
        this.selectAllForArchive = false
      }
    },
    selectedAllForNext() {
      if (this.selectAllForArchive) {
        _.map(this.capList, (item) => { item['isSelected'] = true })
        this.enableNextBtn = true;
      }
      else {
        _.map(this.capList, (item) => { item['isSelected'] = false })
        this.enableNextBtn = false;
      }
    },
    updatecellPhoneCountryCode(data) {
      this.beneficiary['phoneCountryCode'] = data
    },
    updateSelection() {

      if (this.wiseSelection == 'true') {
        this.anonymousUser = false;


      } else {
        this.anonymousUser = true;
        this.beneficiary.email = '';
        this.beneficiary.phone = ''
        this.beneficiary.phoneCountryCode = { countryCode: '', countryCallingCode: '' };
      }

      // this.resetForm();
    },
    setPetDetails(selectedPetitioner = null) {

      this.selectedPetitioner = selectedPetitioner
    },
    addNewBeneficiary() {
      this.selectedPetitioner = null;
      this.beneficiary = {
        firstName: '',
        lastName: '',
        name: "",
        email: "",
        phone: "",
        phoneCountryCode: { countryCode: '', countryCallingCode: '' }
      }
      Object.assign(this.formerrors, {
        msg: ''
      });

      this.AddBeneficiary = true;
      this.$validator.reset();
      this.isPhoneValid = true;
      this.saveBenbtn = false;


    },
    updatePhone(item) {

      this.isPhoneValid = true;

      if (item.isValid) {

        this.beneficiary.phoneCountryCode = { countryCode: item.countryCode, countryCallingCode: item.countryCallingCode };
        this.beneficiary.phone = item.nationalNumber;

      } else {
        if (this.count > 5)
          this.isPhoneValid = false;
      }
      this.count++;
    },
    savebeneficiary() {
      this.$validator.validateAll().then(result => {

        this.saveBenbtn = false;
        if (result) {
          let self = this;
          this.beneficiary = Object.assign(this.beneficiary, { "roleId": 51 });
          this.beneficiary['name'] = this.beneficiary['firstName'].trim() + " " + this.beneficiary['lastName'].trim();
          this.beneficiary['firstName'] = this.beneficiary['firstName'].trim();
          this.beneficiary['lastName'] = this.beneficiary['lastName'].trim();
          this.beneficiary['name'] = this.beneficiary['name'].trim();
          this.saveBenbtn = true;
          let postData = this.beneficiary;
          if (this.checkProperty(this.selectedIItem, '_id')) {
            postData['userId'] = this.checkProperty(this.selectedIItem, '_id')
            postData['accountType'] = "Individual"
          }
          if (this.selectedIItem == null) {
            if (self.selectedPetitioner && _.has(self.selectedPetitioner, "_id")) {
              postData = Object.assign(postData, { "companyId": self.selectedPetitioner['_id'] })
            }
          }
          let path = "/users/register"
          if (this.checkProperty(this.selectedIItem, '_id')) {
            path = "/users/invite-temp-user-to-individual"
          }

          this.$store
            .dispatch("commonAction", { "data": postData, "path": path })
            .then(response => {
              this.saveBenbtn = false;
              if (response.error) {

                Object.assign(this.formerrors, {
                  msg: response.error.message
                });
              } else {

                this.AddBeneficiary = false;
                this.selectedBeneficiary = response
                this.showToster({ message: response.message, isError: false });
                //this.closeAddBenPopUp();
              }

              // this.$router.go('/beneficiaries');
            })
            .catch((err) => {

              this.saveBenbtn = false;
              //this.showToster({message:err,isError:true })
              Object.assign(this.formerrors, {
                msg: err
              });

            });
        }
      });
    },
    searchPet(searchText) {
      let _self = this;

      this.enableAddNewpet = false;
      let filteredData = [];
      _.forEach(_self.petitionersList, (item) => {
        if (item && (_.has(item, 'name') || _.has(item, 'email'))) {

          if ((_.has(item, 'name') && item['name'].includes(searchText)) || (_.has(item, 'email') && item['email'].includes(searchText))) {
            filteredData.push(item)
          } else {
            return false;
          }

        } else {
          return false;
        }


      })
      if ((filteredData.length <= 0)) {

        //this.enableAddNewpet =true;
        // this   this.addNewPete = true;
        this.getPetitioners(true, searchText);
      }

    },
    getPetitioners(callFromSerch = false, searchText = '') {

      let _self = this;
      let query = {
        "matcher": {
          "searchString": searchText,
          "statusIds": [],
          "countryIds": [],
          "stateIds": [],
          "locationIds": [],
          "createdDateRange": []
        },
        "sorting": { "path": "createdOn", "order": 1 },
        "page": 1,
        "perpage": 100,
        getMasterData: true
      }


      this.$store.dispatch("getList", { data: query, path: '/company/list' }).then(response => {

        _self.petitionersList = response.list;

      }).catch((err) => {
        this.petitionersList = [];

      })
    },
    addNewPet(newPet = '', id) {
      this.newPetOpenFromben = false;
      this.openNewbenForm = false;
      this.addNewPete = true;
      this.invitePetitionPopupshow(true)
    },
    closenewPetPopup(selectedPetitioner = null) {
      this.getPetitioners();
      this.selectedPetitioner = selectedPetitioner;
      this.invitePetitionPopupshow(false);
      this.openNewbenFormPopup(true);
    },
    invitePetitionPopupshow(action = true) {
      this.invitepetitioner = action;

      if (!action) {
        this.selectedBeneficiary = null;
      }


    },
    openNewbenFormPopup(action = false) {
      this.saveBenbtn = false;
      if (action == true) {
        this.invitePetitionPopupshow(false);
      }
      if (action) {
        if (this.checkProperty(this.selectedPetitioner, 'userId')) {
          this.AddBeneficiary = true;
          try {
            setTimeout(() => {
              this.$refs['add_ben'].setPetDetails(this.selectedPetitioner)
            }, 50)
          } catch (e) {}
        } else {
          this.AddBeneficiary = false;
        }
      } else {
        this.AddBeneficiary = action;
      }
      this.$validator.reset();
    },
    // addNewPet(){
    //    this.$emit("openAddpetPopUp" );
    // },
    openAddpetPopUp() {

      this.selectedPetitioner = null;
      this.invitepetitioner = true;
    },
    closeAddBenPopUp(selectedBeneficiary = null) {

      this.AddBeneficiary = false;
      this.selectedBeneficiary = selectedBeneficiary;
      if (this.checkProperty(this.selectedBeneficiary, 'name') && this.checkProperty(this.selectedBeneficiary, '_id')) {
        this.selectedUser = this.checkProperty(this.selectedBeneficiary, '_id');
        this.selectedUsername = this.checkProperty(this.selectedBeneficiary, 'name');
      }
      this.getbeneficiaryMasterDataList();
    },
    getMasterDataList() {
      this.caseStatusList = [];
      this.$store.dispatch("getmasterdata", "education_types").then((response) => {
        this.education_types = response;
      });
      this.$store.dispatch("getmasterdata", "cap_reg_status").then((response) => {
        this.caseStatusList = _.filter(response, (item) => {
          return [1].indexOf(item['id']) < 0
        })
        let obj2 = { _id: "63f783dc7aca2865dd5555855", id: 91, name: "Hold", sortName: "Hold" };
        this.caseStatusList.push(obj2)
        //this.caseStatusList = response;
      });
    },
  },
  mounted() {
    if (this.checkProperty(this.getUserData, 'tenantDetails') && this.checkProperty(this.getUserData, 'tenantDetails', 'slug') != 'slg') {
      this.isSlg = false;
    }
    this.sortKeys = {
      'caseNo': 1,
      'createdByName': 1,
      "typeName": 1,
      "subTypeName": 1,
      "statusName": 1,
      "createdOn": 1,
      "updatedOn": -1,
      "clientName": 1,
      "beneficiaryName": 1,
      companyName: 1,
      countryOfCitizenshipName: 1,
      passportNumber: 1,
      dateOfBirth: 1,
      reqConsdnOfAdvDegreeExptn: 1,
      isAccredited: 1,
      isForProfit: 1,
      graduatedYear: 1

    },
      this.sortKey = { "path": 'updatedOn', "order": -1 };
    if (localStorage.getItem('petitions_sort_key') && localStorage.getItem('petitions_sort_value') && localStorage.getItem('petitions_sort_value') >= -1) {
      this.sortKey = {};
      this.sortKey = { "path": localStorage.getItem('petitions_sort_key'), "order": parseInt(localStorage.getItem('petitions_sort_value')) };
      this.sortKeys[localStorage.getItem('petitions_sort_key')] = parseInt(localStorage.getItem('petitions_sort_value'));
     
    }
    this.getMasterDataList()
    //caseStatusList
    this.getPetitioners();
    this.getbeneficiaryMasterDataList();
    this.getBranchList();
    this.getCapList();
  }
};
</script>
