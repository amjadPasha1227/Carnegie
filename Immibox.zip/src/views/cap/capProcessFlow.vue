<template>
  <div class="tabs-layout-header-items padr0">
    <div class="items-left">
      <ul class="items-list"
        v-if="checkProperty(petition, 'companyDetails', 'name') || checkProperty(petition, 'beneficiaryDetails', 'name')">
        <li v-if=" [51].indexOf(getUserRoleId) <= -1" class="tabwidth">
          Beneficiary
          <span style="font-size:12px">{{ checkProperty(petition,'beneficiaryInfo','name') }}</span>
        </li>
        <li v-if="getTenantTypeId != 2 && [51].indexOf(getUserRoleId) <= -1" class="tabwidth">
          Petitioner
          <span style="font-size:12px">{{ checkProperty(petition,'companyDetails','name') }}</span>
        </li>
      </ul>
    </div>
    <div class="items-right capactions" v-if="checkCurrentUrl && !loadedFromPreview">
      <ul>
        <li v-if="checkProperty(petition, 'premiumProcessing')">
          <div class="IB_tooltip premium_tooltip eee">
            <div class="premium_tooltip_icon">
              <span>P</span>
              <!-- <img v-if="checkProperty( getPetitionDetails,'premiumProcessingDocuments' ,'length')>0" src="@/assets/images/main/doc.svg"/> -->
            </div>
            <div class="tooltip_cnt" v-if="!checkProperty(petition, 'premiumProcessingDocuments', 'length') > 0">
              <p>Premium Processing</p>
            </div>
            <div class="premium_documents" v-if="checkProperty(petition, 'premiumProcessingDocuments', 'length') > 0">
              <div class="premium_documents_cnt">
                <h5>Premium Processing</h5>
                <div class="premium_documents_list" @click="downloadfile(petition['premiumProcessingDocuments'][0])">
                  <docType :item="petition['premiumProcessingDocuments'][0]" />
                  <figcaption>{{ petition['premiumProcessingDocuments'][0]['name'] }}</figcaption>
                </div>
              </div>
            </div>
          </div>
        </li>
        <template v-if="checkProperty(petition, 'intStatusDetails', 'id') == '2' && checkProperty(petition, 'questionnaireTplType') == 'general'">
          <li>
          <div class="dropdown-button-container">
            <vs-button class="borderRadius20 status-btn"><span :class="{
                      ' status_denied ': true,
                    }">{{ checkProperty(petition,'intStatusDetails','name') }}</span></vs-button>
          </div>
        </li>
        </template>
        <template v-else>
        <li v-if="checkProperty(petition, 'statusDetails', 'name')">
          <div class="dropdown-button-container">
            <vs-button class="borderRadius20 status-btn"><span :class="{
                      ' status_created ': checkProperty(petition, 'statusDetails', 'id') == 1 || checkProperty(petition, 'statusDetails', 'id') == 11,
                      ' status_submited ': checkProperty(petition, 'statusDetails', 'id') == 2,
                      ' status_inProcess ': checkProperty(petition, 'statusDetails', 'id') == 3,
                      ' status_verified ': checkProperty(petition, 'statusDetails', 'id') == 4,
                      ' status_registered ': checkProperty(petition, 'statusDetails', 'id') == 5,
                      ' status_submited-USCIS ': checkProperty(petition, 'statusDetails', 'id') == 6,
                      ' status_selected': checkProperty(petition, 'statusDetails', 'id') == 7,
                      ' status_not_selected ': checkProperty(petition, 'statusDetails', 'id') == 8,
                      ' status_denied': checkProperty(petition, 'statusDetails', 'id') == 9,
                      ' status_payment_failed ': checkProperty(petition, 'statusDetails', 'id') == 10,
                    }">{{ checkProperty(petition,'statusDetails','name') }}</span></vs-button>
          </div>
        </li>
      </template>
        <li v-if="checkGenShareLink && [51].indexOf(getUserRoleId) <= -1 && checkProperty(petition, 'completedActivities') && checkProperty(petition, 'completedActivities','length') > 0  && petition.completedActivities.indexOf('UPDATE_USCIS_RESPONSE') < 0">
          <div class="Generate_buttons">
            <button class="copy_link" @click="genarateLink()">
              <img src="@/assets/images/main/link.svg" />
              <small>Share Link </small>
            </button>
          </div>
        </li>

        <li class="menu_dropdown actions_dropdown actions_dropdown-hover mar0" v-if="checkActionItem && checkToShowActiononGen">
          <div class="d-flex">
            <button class="actions_btn actions_btn_v2">Actions </button>
            <div class="menu_list_wrap new_actions_menu menu_v2 nextstep-shadow">
              <div class="menu_list">
                <template v-for="(menuItem, index) in menuItems">
                  <template v-if="checkActionRequired(menuItem)">
                    <div class="menu_item drop_menu_items" :code="menuItem['code']">
                        <a @click="openActionPopup(menuItem)">
                          <template v-if="'UPDATE_INTERNAL_STATUS'== menuItem['code']">
                            <template v-if="checkProperty(petition,'intStatusDetails','id')==1">Hold Case</template>
                            <template v-else> Active Case</template>
                          </template>
                          <template v-else>{{ menuItem.actionLable }}</template></a>   
                    </div>
                  </template>
                </template>
              </div>
            </div>
          </div>
        </li>
      </ul>
    </div>
   <!-- USCIS Fee Status -->
   <modal name="GEN_USCIS_FEE_STATUS" classes="v-modal-sec" :min-width="200" :min-height="200" :scrollable="true"
      :reset="true" width="500px" height="auto">
      <div class="v-modal">
        <div class="popup-header">
          <h2 class="popup-title">
            Update Fee Status
          </h2>
          <span @click="$modal.hide('GEN_USCIS_FEE_STATUS')">
            <em class="material-icons">close</em>
          </span>
        </div>
        <form @submit.prevent data-vv-scope="GEN_USCIS_FEE_STATUS">
          <div class="form-container" @click="capActionErrors = ''">
            <div class="vx-row">
              <!-- @input="clearUSCISfields" -->
              <selectField :listContainsId="true" :required="true" :formscope="'GEN_USCIS_FEE_STATUS'" :display="true"
                  :wrapclass="'md:w-full'" @input="clearFeefields" :optionslist="USCISfeesList" v-model="uscisResponse.fees" label="Fee Status"
                  fieldName="fees" placeHolder="Fee Status" />
              <template v-if="checkProperty(uscisResponse,'fees','id')=='Paid'">
                <selectField :listContainsId="true" :required="true" :formscope="'GEN_USCIS_FEE_STATUS'" :display="true"
                    :wrapclass="'md:w-full'"  :optionslist="genUSCISsatatus" v-model="uscisResponse.status" label="USCIS Case Status"
                    fieldName="status" placeHolder="USCIS Case Status" />
                <datepickerField :display="true" :dateEnableTo="new Date()"  :wrapclass="'md:w-full'"
                    v-model="paymentDate" :fieldName="'paymentDate'" formscope="GEN_USCIS_FEE_STATUS"
                    label="Fee Payment Date" />
              </template>
            </div>
            <div class="vx-col w-full">
                <div class="form_group">
                  <label class="form_label">Comments</label>
                  <ckeditor data-vv-as="Comments" v-model="uscisResponse.comments"
                    name="comments" class="w-full" :editor="editor" :config="editorConfig"></ckeditor>

                </div>
              </div>
           
           
            <div class="text-danger text-sm formerrors custom_margin" v-show="capActionErrors">
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
              icon="IP-information-button" active="true">{{ capActionErrors }}</vs-alert>
          </div>
          </div>
          <div class="popup-footer">
            <vs-button color="dark" @click="$modal.hide('GEN_USCIS_FEE_STATUS')" class="cancel"
              type="filled">Cancel</vs-button>
            <vs-button color="success" :disabled="capFormSubmited ||checkProperty(uscisResponse,'fees','id')=='Pending'"  @click="manageApprovalProcess('GEN_USCIS_FEE_STATUS')" class="save"
              type="filled">
              <figure v-if="capFormSubmited" class="loader loader-btn"><img src="@/assets/images/main/loader.gif" /></figure>
              Update</vs-button>
          </div>
        </form>
      </div>
    </modal>
    <!-- General Final Uscis Response -->
    <modal name="GEN_FINAL_SUBMIT_TO_USCIS" classes="v-modal-sec" :min-width="200" :min-height="200" :scrollable="true"
      :reset="true" width="500px" height="auto">
      <div class="v-modal">
        <div class="popup-header">
          <h2 class="popup-title"> Update USCIS Response </h2>
          <span @click="$modal.hide('GEN_FINAL_SUBMIT_TO_USCIS')">
            <em class="material-icons">close</em>
          </span>
        </div>
        <form @submit.prevent data-vv-scope="GEN_FINAL_SUBMIT_TO_USCIS">
          <div class="form-container" @click="capActionErrors = ''">
            <div class="vx-row">
            <selectField :listContainsId="true" :required="true" :formscope="'GEN_FINAL_SUBMIT_TO_USCIS'" :display="true"
              :wrapclass="'md:w-full'"  :optionslist="genUSCISsatatus" v-model="uscisResponse.status" label="Status"
              fieldName="status" placeHolder="Status" />
              <template v-if="checkProperty(petition,'registeredInfo','trackingNumber') == ''">
              <immiInput :maxCharacters="25" :display="true" :cid="'trackingNumber'" :formscope="'GEN_FINAL_SUBMIT_TO_USCIS'" :wrapclass="'md:w-full'"
                v-model="trackingNumber" :required="false" :fieldName="'trackingNumber'" label="Application Number"
                placeHolder="Application Number" />
              </template>
            </div>

              <div class="vx-row" v-if="checkProperty(petition,'registeredInfo','documents') && checkProperty(petition['registeredInfo'],'documents','length') == 0"  >
                <div class="vx-col w-full">
                  <div class="form_group file_group">
                    <div class="vs-component marb20">
                      <label class="form_label">Acknowledgement</label>
                      <div class="relative">
                        <file-upload v-model="value" class="file-upload-input upload_file justify-center"
                          :accept="allDocEntity"
                          :name="'documents'" :multiple="true" :hideSelected="true"
                          @input="upload(value, 'trackingDocuments')">
                          <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                          Upload
                        </file-upload>
                        <span v-if="uploading" class="loader"><img src="@/assets/images/main/loader.gif" /></span>
                      </div>
                      <input type="hidden" :name="'trackingDocuments'"  data-vv-as="PERM Documents"
                        v-model="trackingDocuments">
                    </div>

                    <ul class="uploaded-list note_uploads">
                      <template v-for="(item, index) in trackingDocuments">
                        <vs-chip @click="remove(item, trackingDocuments, index)" :key="index" closable>
                          {{ item.name }}
                        </vs-chip>
                      </template>
                    </ul>
                  </div>
                </div>
              </div>
    
            <div class="vx-col w-full">
              <div class="form_group">
                <label class="form_label">Comments</label>
                <ckeditor data-vv-as="Comments"  v-model="uscisResponse.comments" name="comments"
                  class="w-full" :editor="editor" :config="editorConfig"></ckeditor>
              </div>
            </div>
            <div class="text-danger text-sm formerrors custom_margin" v-show="capActionErrors">
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
              icon="IP-information-button" active="true">{{ capActionErrors }}</vs-alert>
          </div>
          </div>
          <div class="popup-footer">
            <vs-button color="dark" @click="$modal.hide('GEN_FINAL_SUBMIT_TO_USCIS')" class="cancel"
              type="filled">Cancel</vs-button>
            <vs-button color="success" :disabled="capFormSubmited"   @click="manageApprovalProcess('GEN_FINAL_SUBMIT_TO_USCIS')" class="save"
              type="filled">
              <figure v-if="capFormSubmited" class="loader loader-btn"><img src="@/assets/images/main/loader.gif" /></figure>
              Submit</vs-button>
          </div>
        </form>
      </div>
    </modal>
    <!-- Generate Link -->
    <modal name="capgenaratModal" classes="v-modal-sec" :min-width="200" :min-height="200" :scrollable="true"
      :reset="true" width="500px" height="auto">
      <div class="v-modal">
        <!---------Contanexdv--------->
        <div class="genarate_body">
          <span @click="$modal.hide('capgenaratModal')" class="closemodal">
            <em class="material-icons">close</em>
          </span>
          <!-- <h4>Your link has been<br/> generated Successfully</h4> -->
          <h6>Copy link.</h6>
          <div class="copysec" @click="copyLink()">
            <p>{{ anonymousAccesLink }}</p>
            <img src="@/assets/images/main/copy.svg">
            <small>Copy</small>
          </div>
          <div class="orshare"><span>OR</span></div>
          <h6>Share link.</h6>

          <div class="copysec">
            <vs-input placeholder="Enter comma separated emails " class="form-control"
              v-model="linkShareToemailsText" />
            <vs-button @click="shareLink()" :disabled="sharing || linkShareToemailsText == ''" class="primary-btn"
              type="filled">Share</vs-button>
          </div>
        </div>

      </div>
    </modal>
    <modal name="SUBMIT_CASE" classes="v-modal-sec" :min-width="200" :min-height="200" :scrollable="true" :reset="true"
      width="500px" height="auto">
      <div class="v-modal">
        <div class="popup-header">
          <h2 class="popup-title">
            Submit to Law Firm
          </h2>
          <span @click="$modal.hide('SUBMIT_CASE')">
            <em class="material-icons">close</em>
          </span>
        </div>
        <form @submit.prevent data-vv-scope="SUBMIT_CASE">
          <div class="form-container" @click="capActionErrors = ''">
            <div class="vx-row">

              <div class="vx-col w-full">
                <div class="form_group">
                  <label class="form_label">Comments </label>
                  <!-- <vs-textarea
                  data-vv-as="Comments"
                  v-validate="'required'"
                  v-model="comments"
                  name="comments"
               
                  class="w-full"
                /> -->
                  <ckeditor data-vv-as="Comments" v-model="comments" name="comments"
                    class="w-full" :editor="editor" :config="editorConfig"></ckeditor>

                  <span class="text-danger text-sm" v-show="errors.has('SUBMIT_CASE.comments')">{{
                    errors.first("SUBMIT_CASE.comments")
                  }}</span>
                </div>
              </div>
            </div>
            <div class="text-danger text-sm formerrors" v-show="capActionErrors">
              <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius"
                icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ capActionErrors }}</vs-alert>
            </div>
          </div>

          <div class="popup-footer">
            <vs-button color="dark" @click="$modal.hide('SUBMIT_CASE'); comments = '' " class="cancel"
              type="filled">Cancel</vs-button>
            <vs-button color="success" @click="manageApprovalProcess('SUBMIT_CASE')" class="save"
              type="filled">Submit</vs-button>
          </div>
        </form>
      </div>
    </modal>
    <!--- Tracking Info Modal  --->
    <modal name="GEN_SUBMIT_TO_USCIS" classes="v-modal-sec" :min-width="200" :min-height="200" :scrollable="true"
      :reset="true" width="500px" height="auto">
      <div class="v-modal">
        <div class="popup-header">
          <h2 class="popup-title">
            Register with USCIS 
          </h2>
          <span @click="$modal.hide('GEN_SUBMIT_TO_USCIS')">
            <em class="material-icons">close</em>
          </span>
        </div>
        <form @submit.prevent data-vv-scope="GEN_SUBMIT_TO_USCIS">
          <div class="form-container" @click="capActionErrors = ''">
            <div class="vx-row">
              <datepickerField :display="true" :dateEnableTo="new Date()" :validationRequired="true" :wrapclass="'md:w-full'"
                  v-model="registeredDate" :fieldName="'registeredDate'" formscope="GEN_SUBMIT_TO_USCIS"
                  label="Registered Date" />
              <!-- <selectField :listContainsId="true" :required="true" :formscope="'GEN_SUBMIT_TO_USCIS'" :display="true"
                  :wrapclass="'md:w-full'" @input="clearUSCISfields" :optionslist="genUSCISsatatus" v-model="uscisResponse.status" label="Status"
                  fieldName="status" placeHolder="Status" /> -->
              <!-- <selectField :listContainsId="true" :required="true" :formscope="'GEN_SUBMIT_TO_USCIS'" :display="true"
                  :wrapclass="'md:w-full'" :optionslist="USCISfeesList" v-model="uscisResponse.fees" label="USCIS Fee Status"
                  fieldName="fees" placeHolder="Fee Status" /> -->
              
              <immiInput :maxCharacters="25" :display="true" :cid="'trackingNumber'" :formscope="'GEN_SUBMIT_TO_USCIS'" :wrapclass="'md:w-full'"
                v-model="trackingNumber" :required="false" :fieldName="'trackingNumber'" label="Application Number"
                placeHolder="Application Number" />
            
            </div>
           
            <div class="vx-row"  >
              <div class="vx-col w-full">
                <div class="form_group file_group">
                  <div class="vs-component marb20">
                    <label class="form_label">Acknowledgement</label>
                    <div class="relative">
                      <file-upload v-model="value" class="file-upload-input upload_file justify-center"
                        :accept="allDocEntity"
                        :name="'documents'" :multiple="true" :hideSelected="true"
                        @input="upload(value, 'trackingDocuments')">
                        <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                        Upload
                      </file-upload>
                      <span v-if="uploading" class="loader"><img src="@/assets/images/main/loader.gif" /></span>
                    </div>
                    <input type="hidden" :name="'trackingDocuments'"  data-vv-as="PERM Documents"
                      v-model="trackingDocuments">
                  </div>

                  <ul class="uploaded-list note_uploads">
                    <template v-for="(item, index) in trackingDocuments">
                      <vs-chip @click="remove(item, trackingDocuments, index)" :key="index" closable>
                        {{ item.name }}
                      </vs-chip>
                    </template>
                  </ul>
                </div>
              </div>
            </div>
           
            <div class="text-danger text-sm formerrors custom_margin" v-show="capActionErrors">
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
              icon="IP-information-button" active="true">{{ capActionErrors }}</vs-alert>
          </div>
          </div>
          <div class="popup-footer">
            <vs-button color="dark" @click="$modal.hide('GEN_SUBMIT_TO_USCIS')" class="cancel"
              type="filled">Cancel</vs-button>
            <vs-button color="success" :disabled="capFormSubmited"  @click="manageApprovalProcess('GEN_SUBMIT_TO_USCIS')" class="save"
              type="filled">
              <figure v-if="capFormSubmited" class="loader loader-btn"><img src="@/assets/images/main/loader.gif" /></figure>
              Update</vs-button>
          </div>
        </form>
      </div>
    </modal>
   <!-- Verify Popoup -->
    <modal name="VERIFY" classes="v-modal-sec" :min-width="200" :min-height="200" :scrollable="true"
      :reset="true" width="500px" height="auto">
      <div class="v-modal">
        <div class="popup-header">
          <h2 class="popup-title" v-if="isSlg == false">Verify and Confirm</h2>
          <h2 class="popup-title" v-else> Verify </h2>
          <span @click="$modal.hide('VERIFY')">
            <em class="material-icons">close</em>
          </span>
        </div>
        <form @submit.prevent data-vv-scope="VERIFY">
          <div class="form-container" @click="capActionErrors = ''">
            <div class="vx-col w-full">
              <div class="form_group">
                <label class="form_label">Comments</label>
                <ckeditor data-vv-as="Comments"  v-model="comments" name="comments"
                  class="w-full" :editor="editor" :config="editorConfig"></ckeditor>
                <span class="text-danger text-sm" v-show="errors.has('VERIFY.comments')">*Comments are
                  required</span>
              </div>
            </div>
            <div class="text-danger text-sm formerrors custom_margin" v-show="capActionErrors">
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
              icon="IP-information-button" active="true">{{ capActionErrors }}</vs-alert>
          </div>
          </div>
          <div class="popup-footer">
            <vs-button color="dark" @click="$modal.hide('VERIFY')" class="cancel"
              type="filled">Cancel</vs-button>
            <vs-button color="success" :disabled="capFormSubmited"   @click="manageApprovalProcess('VERIFY')" class="save"
              type="filled">
              <figure v-if="capFormSubmited" class="loader loader-btn"><img src="@/assets/images/main/loader.gif" /></figure>
              Submit</vs-button>
          </div>
        </form>
      </div>
    </modal>
    <!-- Update Internal status -->
    <modal name="UPDATE_INTERNAL_STATUS" classes="v-modal-sec" :min-width="200" :min-height="200" :scrollable="true"
      :reset="true" width="500px" height="auto">
      <div class="v-modal">
        <div class="popup-header">
          <h2 class="popup-title" v-if="checkProperty(petition,'intStatusDetails','id')==1">Hold Case</h2>
          <h2 class="popup-title" v-else> Active Case </h2>
          <span @click="$modal.hide('UPDATE_INTERNAL_STATUS')">
            <em class="material-icons">close</em>
          </span>
        </div>
        <form @submit.prevent data-vv-scope="UPDATE_INTERNAL_STATUS">
          <div class="form-container" @click="capActionErrors = ''">
            <!-- <div class="vx-row">
              <selectField :listContainsId="true" :required="true" :formscope="'UPDATE_INTERNAL_STATUS'" :display="true"
                  :wrapclass="'md:w-full'" :optionslist="internalStatusList" v-model="internalStatus" label="Select Status"
                  fieldName="fees" placeHolder="Select Status" />
            </div> -->
            <div class="vx-col w-full">
              <div class="form_group">
                <label class="form_label">Comments</label>
                <ckeditor data-vv-as="Comments"  v-model="comments" name="Intcomments" 
                  class="w-full" :editor="editor"  :config="editorConfig"></ckeditor>
                <!-- <span class="text-danger text-sm" v-show="errors.has('UPDATE_INTERNAL_STATUS.Intcomments')">*Comments are
                  required</span> -->
              </div>
            </div>
            <div class="text-danger text-sm formerrors custom_margin" v-show="capActionErrors">
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
              icon="IP-information-button" active="true">{{ capActionErrors }}</vs-alert>
          </div>
          </div>
          <div class="popup-footer">
            <vs-button color="dark" @click="$modal.hide('UPDATE_INTERNAL_STATUS')" class="cancel"
              type="filled">Cancel</vs-button>
            <vs-button color="success" :disabled="capFormSubmited"   @click="updateInternalStatus('UPDATE_INTERNAL_STATUS')" class="save"
              type="filled">
              <figure v-if="capFormSubmited" class="loader loader-btn"><img src="@/assets/images/main/loader.gif" /></figure>
              Submit</vs-button>
          </div>
        </form>
      </div>
    </modal>
    <!-- Registered Popoup -->
    <modal name="REGISTERED" classes="v-modal-sec" :min-width="200" :min-height="200" :scrollable="true"
      :reset="true" width="500px" height="auto">
      <div class="v-modal">
        <div class="popup-header">
          <h2 class="popup-title">
            Registered
          </h2>
          <span @click="$modal.hide('REGISTERED')">
            <em class="material-icons">close</em>
          </span>
        </div>
        <form @submit.prevent data-vv-scope="REGISTERED">
          <div class="form-container" @click="capActionErrors = ''">
            <div class="vx-col w-full">
              <div class="vx-row">
                <datepickerField :display="true" :wrapclass="'md:w-full'" :dateEnableTo="new Date()" :validationRequired="true"
                    v-model="registeredDate" :fieldName="'registeredDate'" formscope="REGISTERED"
                    label="Registered Date" />
                </div>
              <div class="form_group">
                <label class="form_label">Comments</label>
                <ckeditor data-vv-as="Comments"  v-model="comments" name="comments"
                  class="w-full" :editor="editor" :config="editorConfig"></ckeditor>
                <span class="text-danger text-sm" v-show="errors.has('REGISTERED.comments')">*Comments are
                  required</span>
              </div>
            </div>
            <div class="text-danger text-sm formerrors" v-show="capActionErrors">
              <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius"
                icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ capActionErrors }}</vs-alert>
            </div>
          </div>
          <div class="popup-footer">
            <vs-button color="dark" @click="$modal.hide('REGISTERED')" class="cancel"
              type="filled">Cancel</vs-button>
            <vs-button color="success" :disabled="capFormSubmited" @click="manageApprovalProcess('REGISTERED')" class="save"
              type="filled">
              <figure v-if="capFormSubmited" class="loader loader-btn"><img src="@/assets/images/main/loader.gif" /></figure>
              Submit</vs-button>
          </div>
        </form>
      </div>
    </modal>
    <template>

      <modal name="PREMIUM_PROCESS" classes="v-modal-sec" :min-width="200" :min-height="200" :scrollable="true"
        :reset="true" width="500px" height="auto">
        <div class="v-modal">
          <div class="popup-header">
            <h2 class="popup-title">
              Update Premium Processing
            </h2>
            <span @click="$modal.hide('PREMIUM_PROCESS')">
              <em class="material-icons">close</em>
            </span>
          </div>
          <form @submit.prevent data-vv-scope="PREMIUM_PROCESS">
            <div class="form-container">
              <div class="vx-row">
                <div class="vx-col w-full">
                  <div class="form_group file_group">
                    <div class="vs-component marb20">
                      <label class="form_label">Documents<em
                          v-if="!checkProperty(petition, 'premiumProcessing') && [50].indexOf(getUserRoleId) <= -1">*</em></label>
                      <div class="relative">
                        <file-upload v-model="value" class="file-upload-input upload_file justify-center"
                          :accept="allDocEntity"
                          :name="'documents'" :multiple="true" :hideSelected="true"
                          @input="upload(value, 'premiumDocuments')">
                          <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                          Upload
                        </file-upload>
                        <span v-if="uploading" class="loader"><img src="@/assets/images/main/loader.gif" /></span>
                      </div>
                      <input type="hidden" :name="'premiumDocuments'"
                        v-validate="!checkProperty(petition, 'premiumProcessing') && [50].indexOf(getUserRoleId) <= -1 ? 'required' : ''"
                        data-vv-as="PERM Documents" v-model="premiumDocuments">
                      <span class="text-danger text-sm"
                        v-show="errors.has('PREMIUM_PROCESS.premiumDocuments')">*Documents are required</span>
                    </div>
                    <ul class="uploaded-list note_uploads">
                      <template v-for="(item, index) in premiumDocuments">
                        <vs-chip @click="remove(item, premiumDocuments, index)" :key="index" closable>
                          {{ item.name }}
                        </vs-chip>
                      </template>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="vx-col w-full">
                <div class="form_group">
                  <label class="form_label">Comments<em>*</em></label>
                  <!-- <vs-textarea
                  data-vv-as="Comments"
                  v-validate="'required'"
                  v-model="premiumProcessingComment"
                  name="comments"
                  class="w-full"
                /> -->
                  <ckeditor data-vv-as="Comments" v-validate="'required'" v-model="premiumProcessingComment"
                    name="comments" class="w-full" :editor="editor" :config="editorConfig"></ckeditor>
                  <span class="text-danger text-sm" v-show="errors.has('PREMIUM_PROCESS.comments')">*Comments are
                    required</span>
                </div>
              </div>
            </div>
            <div class="popup-footer">
              <vs-button color="dark" @click="$modal.hide('PREMIUM_PROCESS')" class="cancel"
                type="filled">Cancel</vs-button>
              <vs-button color="success" @click="submitForm()" class="save" type="filled">Update</vs-button>
            </div>
          </form>
        </div>
      </modal>
      <!--- Payment Info Modal  --->
      <modal name="RECEIPT_OF_PAYMENT_MADE" classes="v-modal-sec" :min-width="200" :min-height="200" :scrollable="true"
        :reset="true" width="500px" height="auto">
        <div class="v-modal">
          <div class="popup-header">
            <h2 class="popup-title">
              Update Payment Info
            </h2>
            <span @click="$modal.hide('RECEIPT_OF_PAYMENT_MADE')">
              <em class="material-icons">close</em>
            </span>
          </div>
          <form @submit.prevent data-vv-scope="RECEIPT_OF_PAYMENT_MADE">
            <div class="form-container" @click="capActionErrors = ''">
              <div class="vx-row">
                <!-- <immiInput  :display="true"  cid="receiptName" :formscope="'RECEIPT_OF_PAYMENT_MADE'" v-model="receiptName" :fieldName="'receiptName'"   :required="true"  label="Receipt Name" placeHolder="Receipt Name" /> -->
                <immiInput :maxCharacters="25" :display="true" :cid="'trackingNumber'"
                  :formscope="'RECEIPT_OF_PAYMENT_MADE'" v-model="trackingNumber" :required="false"
                  :fieldName="'trackingNumber'" label="Application Number" placeHolder="Application Number" />
                <immiInput :onlyNumbers="true" :display="true" :wrapclass="'md:w-1/2'" :cid="'payment'"
                  :formscope="'RECEIPT_OF_PAYMENT_MADE'" v-model="payment" :fieldName="'payment'" :required="true"
                  label="Amount($)" placeHolder="Amount" />
                <!-- <datepickerField :display="true" :dateEnableTo="new Date()" :validationRequired="true"
                  v-model="registeredDate" :fieldName="'registeredDate'" formscope="RECEIPT_OF_PAYMENT_MADE"
                  label="Registered Date" />
                <datepickerField :display="true" :dateEnableFrom="registeredDate" :dateEnableTo="new Date()"
                  :validationRequired="true" v-model="submittedDate" :fieldName="'submittedDate'"
                  formscope="RECEIPT_OF_PAYMENT_MADE" label="Submitted Date" /> -->
                <datepickerField wrapclass="md:w-full" :display="true" :dateEnableFrom="registeredDate" :dateEnableTo="new Date()"
                  :validationRequired="true" v-model="paymentDate" :fieldName="'paymentDate'"
                  formscope="RECEIPT_OF_PAYMENT_MADE" label="Payment Date" />
              </div>
              <div class="vx-row">
                <div class="vx-col w-full">
                  <div class="form_group file_group">
                    <div class="vs-component marb20">
                      <label class="form_label">Receipt</label>
                      <div class="relative">
                        <file-upload v-model="value" class="file-upload-input upload_file justify-center"
                          :accept="allDocEntity"
                          :name="'receiptDocuments'" :multiple="true" :hideSelected="true"
                          @input="upload(value, 'receiptDocuments')">
                          <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                          Upload
                        </file-upload>
                        <span v-if="uploading" class="loader"><img src="@/assets/images/main/loader.gif" /></span>
                      </div>
                      <input type="hidden" :name="'receiptDocuments'" 
                        data-vv-as="PERM Documents" v-model="receiptDocuments">
                      <span class="text-danger text-sm"
                        v-show="errors.has('RECEIPT_OF_PAYMENT_MADE.receiptDocuments')">*Receipt is required</span>
                    </div>
                    <ul class="uploaded-list note_uploads">
                      <template v-for="(item, index) in receiptDocuments">
                        <vs-chip @click="remove(item, receiptDocuments, index)" :key="index" closable>
                          {{ item.name }}
                        </vs-chip>
                      </template>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="vx-row">
                <div class="vx-col w-full">
                  <div class="form_group file_group">
                    <div class="vs-component marb20">
                      <label class="form_label">Acknowledgement</label>
                      <div class="relative">
                        <file-upload v-model="value" class="file-upload-input upload_file justify-center"
                          :accept="allDocEntity"
                          :name="'trackingDocuments'" :multiple="true" :hideSelected="true"
                          @input="upload(value, 'trackingDocuments')">
                          <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                          Upload
                        </file-upload>
                        <span v-if="trackingDocUpload" class="loader"><img
                            src="@/assets/images/main/loader.gif" /></span>
                      </div>
                      <input type="hidden" :name="'trackingDocuments'" 
                        data-vv-as="PERM Documents" v-model="trackingDocuments">
                      <span class="text-danger text-sm"
                        v-show="errors.has('RECEIPT_OF_PAYMENT_MADE.trackingDocuments')">*Acknowledgement is
                        required</span>
                    </div>

                    <ul class="uploaded-list note_uploads">
                      <template v-for="(item, index) in trackingDocuments">
                        <vs-chip @click="remove(item, trackingDocuments, index)" :key="index" closable>
                          {{ item.name }}
                        </vs-chip>
                      </template>
                    </ul>
                  </div>
                </div>
              </div>

              <div class="vx-col w-full">
                <div class="form_group">
                  <label class="form_label">Comments</label>
                  <ckeditor data-vv-as="Comments"  v-model="comments" name="comments"
                    class="w-full" :editor="editor" :config="editorConfig"></ckeditor>
                  <span class="text-danger text-sm" v-show="errors.has('RECEIPT_OF_PAYMENT_MADE.comments')">*Comments
                    are required</span>
                </div>
              </div>
              <div class="text-danger text-sm formerrors" v-show="capActionErrors">
              <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius"
                icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ capActionErrors }}</vs-alert>
            </div>
            </div>
            <div class="popup-footer">
              <vs-button color="dark" @click="$modal.hide('RECEIPT_OF_PAYMENT_MADE')" class="cancel"
                type="filled">Cancel</vs-button>
              <vs-button color="success" :disabled="capFormSubmited" @click="manageApprovalProcess('RECEIPT_OF_PAYMENT_MADE')" class="save"
                type="filled">
                <figure v-if="capFormSubmited" class="loader loader-btn"><img src="@/assets/images/main/loader.gif" /></figure>
                Update</vs-button>
            </div>
          </form>
        </div>
      </modal>
      <!--- Update USIC Response Modal  --->
      <modal name="SUBMIT_TO_USCIS" classes="v-modal-sec" :min-width="200" :min-height="200" :scrollable="true"
        :reset="true" width="500px" height="auto">
        <div class="v-modal">
          <div class="popup-header">
            <h2 class="popup-title">
              Update USCIS Response
            </h2>
            <span @click="$modal.hide('SUBMIT_TO_USCIS')">
              <em class="material-icons">close</em>
            </span>
          </div>
          <form @submit.prevent data-vv-scope="SUBMIT_TO_USCIS">
            <div class="form-container" @click="capActionErrors = ''">
              <div class="vx-row">
                <selectField :listContainsId="true" :required="true" :formscope="'SUBMIT_TO_USCIS'" :display="true"
                  :wrapclass="'md:w-full'" :optionslist="USCISstatus" v-model="uscisResponse.status" label="Status"
                  fieldName="status" placeHolder="Status" />
                <selectField :listContainsId="false" :required="true" :formscope="'SUBMIT_TO_USCIS'" :display="true"
                  :wrapclass="'md:w-full'" :optionslist="documentTypes" v-model="documentType" label="Document Type"
                  fieldName="documentType" placeHolder="Document Type" />
              </div>
              <div class="vx-row">
                <div class="vx-col w-full">
                  <div class="form_group file_group">
                    <div class="vs-component marb20">
                      <label class="form_label">Documents<em>*</em></label>
                      <div class="relative">
                        <file-upload v-model="value" class="file-upload-input upload_file justify-center"
                          :accept="allDocEntity"
                          :name="'documents'" :multiple="true" :hideSelected="true"
                          @input="upload(value, 'uscisDocuments')">
                          <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                          Upload
                        </file-upload>
                        <span v-if="uploading" class="loader"><img src="@/assets/images/main/loader.gif" /></span>
                      </div>
                      <input type="hidden" :name="'uscisDocuments'" v-validate="'required'" data-vv-as="PERM Documents"
                        v-model="uscisDocuments">
                      <span class="text-danger text-sm" v-show="errors.has('SUBMIT_TO_USCIS.uscisDocuments')">*Documents
                        are required</span>
                    </div>
                    <ul class="uploaded-list note_uploads">
                      <template v-for="(item, index) in uscisDocuments">
                        <vs-chip @click="remove(item, uscisDocuments, index)" :key="index" closable>
                          {{ item.name }}
                        </vs-chip>
                      </template>
                    </ul>
                  </div>
                </div>
              </div>

              <div class="vx-col w-full">
                <div class="form_group">
                  <label class="form_label">Comments</label>
                  <ckeditor data-vv-as="Comments" v-model="uscisResponse.comments"
                    name="comments" class="w-full" :editor="editor" :config="editorConfig"></ckeditor>

                  <span class="text-danger text-sm" v-show="errors.has('SUBMIT_TO_USCIS.comments')">*Comments are
                    required</span>
                </div>
              </div>
              <div class="text-danger text-sm formerrors" v-show="capActionErrors">
              <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius"
                icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ capActionErrors }}</vs-alert>
            </div>
            </div>
            <div class="popup-footer">
              <vs-button color="dark" @click="$modal.hide('SUBMIT_TO_USCIS')" class="cancel"
                type="filled">Cancel</vs-button>
              <vs-button color="success" :disabled="capFormSubmited" @click="manageApprovalProcess('SUBMIT_TO_USCIS')" class="save"
                type="filled">
                <figure v-if="capFormSubmited" class="loader loader-btn"><img src="@/assets/images/main/loader.gif" /></figure>
                Update</vs-button>
            </div>
          </form>
        </div>
      </modal>
    </template>
    <template>
      <!--- E file Modal Confirm Payment Information  ---> 
      <modal name="E_FILE" classes="v-modal-sec" :min-width="200" :min-height="200" :scrollable="true" :reset="true"
        width="500px" height="auto">
        <div class="v-modal">

          <div class="popup-header fromDetailsPage">
            <h2 class="popup-title">
              E-File
            </h2>
            <span @click="$modal.hide('E_FILE')">
              <em class="material-icons">close</em>
            </span>
          </div>
          <div class="form-container">


            <div class="modal-confirm-msg">
              <p>Using our Browser Extension CAP details can be filled automatically
              </p>
              <div class="popup-footer pl-0 pr-0">
                <a @click="$modal.hide('E_FILE');" href="https://my.uscis.gov/" target="_blank"> <vs-button
                    color="success" class="save" type="filled">Click here to proceed</vs-button>
                </a>
              </div>
            </div>
          </div>


        </div>
      </modal>
      <modal name="GEN_PTNR_PAYMENT_INFO" classes="v-modal-sec" :min-width="200" :min-height="200" :scrollable="true" :reset="true"
        width="500px" height="auto">
        <div class="v-modal">

          <div class="popup-header fromDetailsPage">
            <h2 class="popup-title">
              Confirm Payment Information
            </h2>
            <span @click="$modal.hide('GEN_PTNR_PAYMENT_INFO')">
              <em class="material-icons">close</em>
            </span>
          </div>
          <div class="form-container">


            <div class="modal-confirm-msg">
              <p>Are you sure that the Payment Information received?</p>
            </div>
            <div class="text-danger text-sm formerrors" v-show="capActionErrors">
              <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius"
                icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ capActionErrors }}</vs-alert>
            </div>
          </div>
          <div class="popup-footer">
              <vs-button color="dark" @click="$modal.hide('GEN_PTNR_PAYMENT_INFO')" class="cancel"
                type="filled">No</vs-button>
              <vs-button color="success" :disabled="capFormSubmited" @click="manageApprovalProcess('GEN_PTNR_PAYMENT_INFO')" class="save"
                type="filled">
                <figure v-if="capFormSubmited" class="loader loader-btn"><img src="@/assets/images/main/loader.gif" /></figure>
                Yes</vs-button>
            </div>
        </div>
      </modal>
    </template>
  </div>
</template>

<script>
import docType from "@/views/common/docType.vue"
import moment from "moment";
import immitextarea from "@/views/forms/fields/simpletextarea.vue";
import selectField from "@/views/forms/fields/simpleselect.vue";
import immiInput from "@/views/forms/fields/simpleinput.vue";
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import Vue from "vue";
import datepickerField from "@/views/forms/fields/datepicker.vue";
Vue.use(CKEditor);
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import FileUpload from "vue-upload-component/src";
export default {
  provide() {
    return {
      parentValidator: this.$validator,
    };
  },
  components: {
    datepickerField,
    docType,
    immitextarea,
    selectField,
    immiInput,
    FileUpload,
    VuePerfectScrollbar,
  },
  props: {
    petition: {
      type: [Object, Array],
      default: null,
    },
    loadedFromPreview: false,
  },
  computed: {
    checkGenShareLink(){
      let returnVal = true
      let isSlg = true;
      if(this.checkProperty(this.petition, 'questionnaireTplType') == "general"){
        if(this.checkProperty(this.petition,'intStatusDetails','id')==1){
          returnVal = true
        }else{
        returnVal = false
        }
      }
      return returnVal
    },
    checkActionItem() {
      let returnVal = true;
      let isSlg = true;
      if(this.checkProperty(this.petition, 'questionnaireTplType') == "general"){
        isSlg = false
      }
      if (this.checkProperty(this.petition, 'completedActivities') && this.checkProperty(this.petition, 'completedActivities', 'length') > 0) {
        if ([50, 51].indexOf(this.getUserRoleId) > -1) {
          if(isSlg == false){
            if(this.getUserRoleId == 51){
              if (this.petition.completedActivities.indexOf('CREATE') > -1 && this.petition.completedActivities.indexOf('SUBMIT_TO_LAW_FIRM') > -1) {
                returnVal = false;
              }
              else {
                returnVal = true;
              }
            }else{
              if (this.petition.completedActivities.indexOf('CREATE') > -1 && this.petition.completedActivities.indexOf('REGISTERED') > -1) {
                returnVal = false;
              }
              else {
                returnVal = true;
              }
            }
          }else{
            if (this.petition.completedActivities.indexOf('CREATE') > -1 && this.petition.completedActivities.indexOf('SUBMIT_TO_LAW_FIRM') > -1) {
                returnVal = false;
              }
              else {
                returnVal = true;
              }
          }
        }

        else {
          if ((this.petition.completedActivities.indexOf('CASE_CREATED') > -1 || this.petition.completedActivities.indexOf('NOT_SELECTED') > -1 || this.petition.completedActivities.indexOf('DENIED') > -1 ||
            this.petition.completedActivities.indexOf('INVALIDATED') > -1)) {
            returnVal = false;
          }
          else {
            returnVal = true;
          }
        }

      }
      return returnVal
    },
    checkShareLinkBtn(){
      if([50].indexOf(this.getUserRoleId)>-1){
        if(this.petition.completedActivities.indexOf('SUBMIT_TO_LAW_FIRM') > -1){
          return false
        }
        else{
          return true
        }
      }else{
        return false
      }
    },
    checkToShowActiononGen(){
      let returnVal = true;
      let isSlg = true;
      if(this.checkProperty(this.petition, 'questionnaireTplType') == "general"){
        isSlg = false
      }
      if(this.checkProperty(this.petition,'intStatusDetails','id')==2 && isSlg == false){
          if([50].indexOf(this.getUserRoleId)>-1){
            returnVal = true
          }
          else{
            returnVal = false
          }
      }
      return returnVal
    }
  },
  data: () => ({
    isSlg:true,
    capFormSubmited:false,
    capActionErrors:'',
    editor: ClassicEditor,
    editorConfig: {
      toolbar: ['bold', 'italic', '|', 'undo', 'redo', 'NumberedList', 'BulletedList',],
    },
    casetype: [
      { "name": 'H-1B', 'id': 'H-1B' }
    ],
    casesubtype: [
      { "name": 'Master Cap - Consular Processing', 'id': 'Master' },
      { "name": 'Regular Cap - Consular Processing', 'id': 'Regular' }
    ],
    //payReceipt:'',
    premiumProcessingFormErrors: '',
    premiumProcessing: false,
    premiumDocuments: [],
    premiumProcessingComment: '',
    documentTypes: ["Electronic", "Original"],
    documentType: null,
    selectedCaseType: null,
    selectedSubtype: null,
    BeneficiaryList: [],
    branchList: [],
    premiumProcessing: false,
    petitionersList: [],
    Petitionervalue: null,
    Beneficiaryvalue: null,
    branchvalue: null,
    uploading: false,
    trackingDocuments: [],
    receiptDocuments: [],
    uscisDocuments: [],
    uscisResponse: {
      comments: '',
      documets: '',
      status: null,
      fees:'',
    },
    trackingDocUpload: false,
    payment: '',
    registeredDate: null,
    submittedDate: null,
    paymentDate: null,
    receiptName: '',
    trackingNumber: '',
    formErrors: "",
    comments: '',
    selectedAction: '',
    genUSCISsatatus:[
    { "name": 'Selected', 'id': 'SELECTED' },
      { "name": 'Not Selected', 'id': 'NOT_SELECTED' },
    ],
    USCISstatus: [
      { "name": 'Selected', 'id': 'SELECTED' },
      { "name": 'Not Selected', 'id': 'NOT_SELECTED' },
      { "name": 'Denied', 'id': 'DENIED' },
      { "name": 'Invalidated-Failed Payment', 'id': 'INVALIDATED' }
    ],
    USCISfeesList:[{ "name": 'Pending', 'id': 'Pending' },
      { "name": 'Paid', 'id': 'Paid' },],
    //////////////////
    value: [],
    webBaseUrl: '',
    caseToken: '',
    linkShareToEmailList: [],
    linkShareToemailsText: '',
    anonymousAccesLink: '',
    sharing: false,
    linkGenareating: false,
    copyingLink: false,
    menuItems: [
    {
        code: "EDIT_QUESTIONNIRE",
        name: "Edit Questionnaire",
        actionLable: "Edit Questionnaire",
        forAdmins: true,
        roleIds: [3, 4],
        completedActivities: ["SUBMIT_BY_BENEFICIARY", "SUBMIT_TO_LAW_FIRM"]
      },
      {
        code: "SUBMIT_CASE",
        name: "Submit Case",
        actionLable: "Submit to Law Firm",
        forAdmins: true,
        roleIds: [3, 4],
        completedActivities: ["CREATE", "SUBMIT_BY_BENEFICIARY"]
      },
      {
        code: "VERIFY",
        name: "Verify",
        actionLable: "Verify",
        forAdmins: true,
        roleIds: [3, 4],
        completedActivities: ["CREATE", "SUBMIT_TO_LAW_FIRM"]
      },
      {
        code: "GEN_PTNR_PAYMENT_INFO",
        name: "Confirm Payment Information",
        actionLable: "Confirm Payment Information",
        forAdmins: true,
        roleIds: [3, 4],
        completedActivities: ["VERIFY"]
      },
      // {
      //   code: "GEN_USCIS_FEE_STATUS",
      //   name: "Update Fee Status",
      //   actionLable: "Update Fee Status",
      //   forAdmins: true,
      //   roleIds: [3, 4],
      //   completedActivities: ["REGISTERED"]
      // },//GEN_FINAL_SUBMIT_TO_USCIS
      {
        code: "GEN_FINAL_SUBMIT_TO_USCIS",
        name: "Update USCIS Response",
        actionLable: "Update USCIS Response",
        forAdmins: true,
        roleIds: [3, 4],
        completedActivities: ["REGISTERED"]
      },
      {
        code: "GEN_SUBMIT_TO_USCIS",
        name: "Register with USCIS",
        actionLable: "Register with USCIS",
        forAdmins: true,
        roleIds: [3, 4],
        completedActivities: ["RECEIPT_OF_PAYMENT_MADE"]
      },
      {
        code: "REGISTERED",
        name: "Registered",
        actionLable: "Registered",
        forAdmins: true,
        roleIds: [3, 4],
        completedActivities: ["CREATE", "VERIFY"]
      },
      {
        code: "RECEIPT_OF_PAYMENT_MADE",
        name: "Update Payment Info",
        actionLable: "Update Payment Info",
        forAdmins: true,
        roleIds: [3, 4],
        completedActivities: ["SUBMIT_TO_LAW_FIRM"]
      },
      {
        code: "E_FILE",
        name: "E-File",
        actionLable: "E-File",
        forAdmins: true,
        roleIds: [3, 4],
        completedActivities: ["RECEIPT_OF_PAYMENT_MADE"]
      },
      {
        code: "SUBMIT_TO_USCIS",
        name: "Update USCIS Response",
        actionLable: "Update USCIS Response",
        forAdmins: true,
        roleIds: [3, 4],
        completedActivities: ["TRACKING_INFO_UPDATE"]
      },
      {
        code: "CREATE_CASE",
        name: "Create Case",
        actionLable: "Create Case",
        forAdmins: true,
        roleIds: [3, 4],
        completedActivities: ["SELECTED"]
      },
      {
        code: "UPDATE_INTERNAL_STATUS",
        name:"Hold Case",
        actionLable:'Hold Case',
        forAdmins: true,
      },
    ],
    internalStatusList:[{_id: "637f7c565648c5150123duse", id: 2, name: "Hold"}],
    internalStatus:null,
  }),
  methods: {
    checkActionRequired(obj) {
      let item = obj;
      var $self = this;
      let caseCreatedPermision = true
      let createdBy = null;
      let isSlg = true;
      let paymentConfirmed = false;
      let paymentStatus = '';
      if(this.checkProperty(this.petition,'registeredInfo','uscisFeeStatus')){
        paymentStatus = this.checkProperty(this.petition,'registeredInfo','uscisFeeStatus')
      }
      if(this.checkProperty(this.petition, 'questionnaireTplType') == "general"){
        isSlg = false
      }
      if(this.checkProperty(this.petition,'ptnrPaymentInfoConfirmed')){
        paymentConfirmed = true
      }
      if (this.petition && this.checkProperty(this.petition, 'createdBy')) {
        createdBy = this.checkProperty(this.petition, 'createdBy')
        if (this.checkProperty(this.getUserData, 'userId') && (createdBy == this.checkProperty(this.getUserData, 'userId'))) {
          caseCreatedPermision = true
        } else {
          caseCreatedPermision = false
        }
      }
      if (this.checkProperty(this.petition, 'completedActivities')) {
        switch (item.code) {

          case "EDIT_QUESTIONNIRE":
            if ((isSlg && this.petition.completedActivities.indexOf('CREATE') > -1 && this.petition.completedActivities.indexOf('RECEIPT_OF_PAYMENT_MADE') < 0) || 
            (isSlg == false && this.checkProperty(this.petition,'intStatusDetails','id')==1 &&  this.petition.completedActivities.indexOf('CREATE') > -1 && this.petition.completedActivities.indexOf('REGISTERED') < 0)
            ) {
              if (this.petition.completedActivities.indexOf('SUBMIT_TO_LAW_FIRM') > -1 && [50,51].indexOf(this.getUserRoleId) > -1) {
                return false
              } else {
                return true
              }
            }
            return false;
            break;
          case "SUBMIT_CASE":
            if (this.petition.completedActivities.indexOf('SUBMIT_BY_BENEFICIARY') > -1 && this.checkProperty(this.petition,'intStatusDetails','id')==1 &&  [51].indexOf(this.getUserRoleId) <= -1 && this.petition.completedActivities.indexOf('SUBMIT_TO_LAW_FIRM') < 0) return true
            return false
            break;
            case "VERIFY":
            if (this.petition.completedActivities.indexOf('SUBMIT_TO_LAW_FIRM') > -1 && isSlg && [50,51].indexOf(this.getUserRoleId) <= -1 && this.petition.completedActivities.indexOf('VERIFY') < 0) return true
            return false
            break;
            case "REGISTERED":
            if (this.petition.completedActivities.indexOf('VERIFY') > -1 && isSlg && [50,51].indexOf(this.getUserRoleId) <= -1 && this.petition.completedActivities.indexOf('REGISTERED') < 0) return true
            return false
            break;
          case "RECEIPT_OF_PAYMENT_MADE":
            if (this.petition.completedActivities.indexOf('REGISTERED') > -1 && isSlg && [50,50].indexOf(this.getUserRoleId) <= -1  && this.petition.completedActivities.indexOf('RECEIPT_OF_PAYMENT_MADE') < 0) return true
            return false
            break;
          case "E_FILE":
            if (this.petition.completedActivities.indexOf('REGISTERED') > -1 && isSlg && [50,50].indexOf(this.getUserRoleId) <= -1  && this.petition.completedActivities.indexOf('RECEIPT_OF_PAYMENT_MADE') < 0) return true
            return false
            break;
          case "GEN_PTNR_PAYMENT_INFO": 
            if (this.petition.completedActivities.indexOf('SUBMIT_TO_LAW_FIRM') > -1 &&  isSlg == false && paymentConfirmed == false &&
             [50,51].indexOf(this.getUserRoleId) <= -1  && this.petition.completedActivities.indexOf('REGISTERED') < 0) return true
            return false
            break;
            case "GEN_SUBMIT_TO_USCIS":
            if ([50,51].indexOf(this.getUserRoleId) <= -1 && isSlg == false &&  paymentConfirmed &&  this.petition.completedActivities.indexOf('SUBMIT_TO_LAW_FIRM') > -1  && this.petition.completedActivities.indexOf('REGISTERED') < 0
              ) return true
            return false
            break;
            case "UPDATE_INTERNAL_STATUS":
            if ([50].indexOf(this.getUserRoleId) > -1 && isSlg == false  &&  this.petition.completedActivities.indexOf('CREATE') > -1  && this.petition.completedActivities.indexOf('REGISTERED') < 0
              ) return true
            return false
            break;
            // case "GEN_USCIS_FEE_STATUS":  UPDATE_INTERNAL_STATUS
            // if (this.petition.completedActivities.indexOf('REGISTERED') > -1 &&  isSlg == false && paymentConfirmed && paymentStatus == 'Pending' &&  [50,51].indexOf(this.getUserRoleId) <= -1  && this.petition.completedActivities.indexOf('UPDATE_USCIS_RESPONSE') < 0) return true
            // return false
            // break;
            case "GEN_FINAL_SUBMIT_TO_USCIS":
            if ([50,51].indexOf(this.getUserRoleId) <= -1 && isSlg == false &&  paymentConfirmed &&  this.petition.completedActivities.indexOf('REGISTERED') > -1  && this.petition.completedActivities.indexOf('UPDATE_USCIS_RESPONSE') < 0 &&
            ['SELECTED','NOT_SELECTED'].indexOf(this.petition.completedActivities)<=-1) return true
            return false
            break;
          case "SUBMIT_TO_USCIS":
            if ([50,51].indexOf(this.getUserRoleId) <= -1&& isSlg && this.petition.completedActivities.indexOf('RECEIPT_OF_PAYMENT_MADE') > -1  && this.petition.completedActivities.indexOf('UPDATE_USCIS_RESPONSE') < 0 &&
              (this.petition.completedActivities.indexOf('SELECTED') < 0 || this.petition.completedActivities.indexOf('NOT_SELECTED') < 0 || this.petition.completedActivities.indexOf('DENIED') < 0 ||
                this.petition.completedActivities.indexOf('INVALIDATED') < 0)) return true
            return false
            break;
          case "CREATE_CASE":
            if ([50,51].indexOf(this.getUserRoleId) <= -1&& this.petition.completedActivities.indexOf('UPDATE_USCIS_RESPONSE') > -1 && !this.checkProperty(this.petition, 'petitionDetails', '_id') &&
              this.petition.completedActivities.indexOf('SELECTED') > -1 && this.petition.completedActivities.indexOf('CASE_CREATED') < 0) return true
            return false
            break;
        }
      }
    },
    manageApprovalProcess(code = '') {
      let formscope = code
      let payload = {};
      this.$validator.validateAll(formscope).then((result) => {
        if (result) {
          payload['today'] = moment().format('YYYY-MM-DD')
            payload['petitionId'] = this.checkProperty(this.petition, '_id')
          if (code == 'SUBMIT_CASE') {
            payload['comment'] = this.comments;
            payload['action'] = 'SUBMIT_TO_LAW_FIRM'
          }
          if(code == 'VERIFY'){
            payload['comments'] = this.comments;
            payload['action'] = 'VERIFY'
          }
          if(code == 'REGISTERED'){
            payload['registeredDate'] = this.registeredDate;
            payload['comments'] = this.comments;
            payload['action'] = 'REGISTERED'
          }
          if (code == 'RECEIPT_OF_PAYMENT_MADE') {
            payload['paymentDate'] = this.paymentDate;
            payload['payAmount'] = this.payment;
            payload['payReceipt'] = this.receiptDocuments;
            payload['documents'] = this.trackingDocuments;
            payload['trackingNumber'] = this.trackingNumber;
            payload['comments'] = this.comments;
            payload['action'] = 'RECEIPT_OF_PAYMENT_MADE'
          }
          if(code == 'GEN_PTNR_PAYMENT_INFO'){
            payload['action'] = 'CONFIRM_PETITIONER_PAYMENT_INFO'
          }
          if (code == 'TRACKING_INFO_UPDATE') {
            payload['comment'] = this.comments;
            payload['trackingNumber'] = this.trackingNumber;
            payload['receiptName'] = this.receiptName;
            payload['documents'] = this.trackingDocuments;
            payload['action'] = 'TRACKING_INFO_UPDATE'
          }
          if(code == 'GEN_SUBMIT_TO_USCIS'){
              payload['trackingNumber'] = this.trackingNumber;
              payload['registeredDate'] = this.registeredDate;
              payload['documents'] = this.trackingDocuments;
              payload['action'] = 'REGISTERED';
              //payload['uscisFeeStatus'] = this.checkProperty(this.uscisResponse, 'fees', 'id')
          }
          if(code == 'GEN_FINAL_SUBMIT_TO_USCIS'){
            payload['action'] = this.checkProperty(this.uscisResponse, 'status', 'id')
            payload['description'] = this.uscisResponse.comments;
            if(this.checkProperty(this.petition,'registeredInfo','documents') && this.checkProperty(this.petition['registeredInfo'],'documents','length') == 0){
               payload['documents'] = this.trackingDocuments;
            }
            if(this.checkProperty(this.petition,'registeredInfo','trackingNumber') == ''){
              payload['trackingNumber'] = this.trackingNumber;
            }
          }
          if (code == 'SUBMIT_TO_USCIS') {
            payload['description'] = this.uscisResponse.comments;
            payload['documents'] = this.uscisDocuments;
            payload['action'] = this.checkProperty(this.uscisResponse, 'status', 'id')
            payload['documentType'] = this.documentType;
          }
          this.capFormSubmited = true;
          this.capActionErrors = '';
          let path = '/cap-registrations/manage-approval-process'
          this.$store.dispatch("commonAction", { "data": payload, "path": path }).then((response) => {
            this.$modal.hide(formscope);
            this.capFormSubmited = false;
            this.updatepetition()
            //alert(JSON.stringify(response))
          }).catch((error) => {
            this.capActionErrors = error;
            this.capFormSubmited = false;

          })

        }

      });
    },
    openActionPopup(item) {
      this.clearAllFields();
      this.comments = '';
      this.selectedAction = this.checkProperty(item, 'code');
      let routedId = this.checkProperty(this.petition, '_id');
      switch (item.code) {
        case "EDIT_QUESTIONNIRE":
          this.$router.push("/cap-registration-questionnaire/" + routedId)
          break;
        case "SUBMIT_CASE":
          this.$modal.show(item.code);
          break;
        case "VERIFY":
          this.$modal.show(item.code);
          break;
        case "GEN_PTNR_PAYMENT_INFO":
          this.$modal.show(item.code);
          break;
        case "UPDATE_INTERNAL_STATUS":
          this.changeinternalList();
          this.$modal.show(item.code);
          break;
        case "GEN_SUBMIT_TO_USCIS": 
        this.$modal.show(item.code);
          break;
        case "GEN_USCIS_FEE_STATUS":
          this.addUscisOption();
          this.$modal.show(item.code);
          break;
        case "GEN_FINAL_SUBMIT_TO_USCIS":
          this.removeUscisOption();
          this.$modal.show(item.code);
          break;
        case "REGISTERED":
          this.$modal.show(item.code);
          break;
        case "RECEIPT_OF_PAYMENT_MADE":
          this.$modal.show(item.code);
          break;
        case "E_FILE":
          this.$modal.show(item.code);
          break;
        case "SUBMIT_TO_USCIS":
          this.$modal.show(item.code);

          break;
        case "NORMAL_PROCESS":
          this.$modal.show('PREMIUM_PROCESS');
          break;
        case "PREMIUM_PROCESS":
          this.$modal.show(item.code);
          break;
        case "CREATE_CASE":
          this.createCaseRedirect();
          //this.$modal.show(item.code); 
          break;
      }
    },
    updateInternalStatus(code = ''){
      let formscope = code
      let payload = {};
      this.$validator.validateAll(formscope).then((result) => {
        if (result) {
          payload['today'] = moment().format('YYYY-MM-DD');
          payload['petitionIds'] = [this.checkProperty(this.petition, '_id')];
          payload['comments'] = this.comments;
          if(this.checkProperty(this.petition,'intStatusDetails','id')==1){
            payload['intStatusId'] = 2
          }
          else{
            payload['intStatusId'] = 1
          }
          //payload['intStatusId'] = this.checkProperty(this.internalStatus, 'id');
          this.capFormSubmited = true;
          this.capActionErrors = '';
          let path = '/cap-registrations/update-internal-status'
          this.$store.dispatch("commonAction", { "data": payload, "path": path }).then((response) => {
            this.$modal.hide(formscope);
            this.capFormSubmited = false;
            this.updatepetition()
          }).catch((error) => {
            this.capActionErrors = error;
            this.capFormSubmited = false;
          })
        }
      })
    },
    changeinternalList(){
      if(this.checkProperty(this.petition,'intStatusDetails','id')==1){
        this.internalStatusList = [{_id: "637f7c565648c5150123duse", id: 2, name: "Hold"}]
      }
      else{
        this.internalStatusList = [{_id: "637f7c565648c5150123deab", id: 1, name: "Active"}]
      }
    },
    addUscisOption(){
      this.uscisResponse.fees = this.USCISfeesList[0]
        let temArry = [];
        let obj = { "name": 'Registered', 'id': 'REGISTERED' }
        let fdObj = _.find(temArry,{'id':'REGISTERED'})
        if(!fdObj){
          temArry.push(obj)
        }
        this.genUSCISsatatus=[
    { "name": 'Selected', 'id': 'SELECTED' },
      { "name": 'Not Selected', 'id': 'NOT_SELECTED' },
    ],
        _.forEach(this.genUSCISsatatus,(item)=>{
          let filedObj = _.find(temArry,{'id':item['item']})
          if(!filedObj){
            temArry.push(item)
          }
        });
        this.genUSCISsatatus = temArry
        this.uscisResponse.status = this.genUSCISsatatus[0]

    },
    removeUscisOption(){
      let tempArr = _.filter(this.genUSCISsatatus,(item)=>{
        return item['id'] != 'REGISTERED'
      });
      if(tempArr){
        this.genUSCISsatatus = tempArr;
      }
    },
    goToQuestionnaire() {
      let routedId = this.checkProperty(this.petition, '_id')
      this.$router.push("/cap-registration-questionnaire/" + routedId)
    },
    clearFeefields(){
      this.paymentDate = null;
      this.uscisResponse.status = this.genUSCISsatatus[0];
    },
    clearUSCISfields(){
      this.trackingDocuments = [];
      this.uscisResponse.fees = '';
      this.trackingNumber = '';
      this.registeredDate ='';
    },
    submitForm() {
      this.$validator.validateAll('PREMIUM_PROCESS').then((result) => {
        let self = this;
        if (result) {
          let postData = {
            petitionId: self.checkProperty(self.petition, '_id'),
            documents: self.premiumDocuments,
            //today: moment().format("YYYY-MM-DD"),
            comment: self.premiumProcessingComment,
            premiumProcessing: !this.checkProperty(this.petition, 'premiumProcessing')

          }
          //this.updatingPremiumProcessing =true;            
          this.$store
            .dispatch("commonAction", { "data": postData, "path": "/cap-registrations/manage-premium-process" })
            .then(response => {
              this.$modal.hide('PREMIUM_PROCESS');
              this.updatepetition()
              this.showToster({ message: response.message, isError: false });
              //this.$emit("updatepetition", "Case Details");                 
            })
            .catch((error) => {
              this.premiumProcessingFormErrors = error;
              this.updatingPremiumProcessing = false;
            })
        }
      });
    },
    clearAllFields() {
      //this.payReceipt = '';
      this.internalStatus = null;
      this.capActionErrors = '';
      this.capFormSubmited = false;
      this.premiumProcessingFormErrors = '',
      //this.premiumProcessing = false,
      this.premiumDocuments = [],
      this.premiumProcessingComment = '',
      this.documentType = this.documentTypes[0]
      this.payment = '';
      this.registeredDate = null,
      this.submittedDate = null,
      this.paymentDate = null,
      this.receiptName = '';
      this.trackingNumber = '';
      this.comments = '';
      this.uscisResponse = {
        comments: '',
        documets: '',
        status: null,
        fees:'',
      }
      this.trackingDocuments = [];
      this.receiptDocuments = [];
      this.uscisDocuments = [];
    },
    downloadfile(value) {
      this.$emit('download_or_view', value);
    },
    createCaseRedirect() {
      let data = {};
      if (this.checkProperty(this.petition, 'beneficiaryDetails')) {
        data['beneficiaryDetails'] = this.checkProperty(this.petition, 'beneficiaryDetails')
      }
      if (this.checkProperty(this.petition, 'beneficiaryInfo') && this.checkProperty(this.petition, 'beneficiaryInfo', 'name') && this.checkProperty(this.petition, 'beneficiaryInfo', '_id')) {

        data['beneficiaryDetails'] = { "name": '', '_id': '' };
        data['beneficiaryDetails']['name'] = this.checkProperty(this.petition, 'beneficiaryInfo', 'name');
        data['beneficiaryDetails']['_id'] = this.checkProperty(this.petition, 'beneficiaryInfo', '_d');

      }
      if (this.checkProperty(this.petition, 'branchDetails')) {
        data['branchDetails'] = this.checkProperty(this.petition, 'branchDetails')
      }
      if (this.checkProperty(this.petition, 'companyDetails')) {
        data['companyDetails'] = this.checkProperty(this.petition, 'companyDetails')
      }
      if (this.checkProperty(this.petition, '_id')) {
        data['capRegId'] = this.checkProperty(this.petition, '_id')
      }
      data['reqConsdnOfAdvDegreeExptn'] = this.checkProperty(this.petition, 'beneficiaryInfo', 'reqConsdnOfAdvDegreeExptn')

      this.$store.commit('updateCapCaseDetails', data)
      this.$router.push({ name: 'petitions', params: { 'capCaseCreate': true } })
    },
    genarateLink() {
      this.webBaseUrl = window.location.origin;
      this.linkShareToEmailList = [];
      this.linkShareToemailsText = '';
      this.sharing = false;
      let petitionDetails = this.petition;
      if ((this.checkProperty(petitionDetails, 'token') == '' && (this.caseToken == '' || this.caseToken == null || this.caseToken == undefined))) {
        let postData = {
          "petitionId": ''
        };
        let path = "/cap-registrations/generate-link"
        postData['petitionId'] = petitionDetails['_id'];
        this.anonymousAccesLink = '';
        this.linkGenareating = true;

        this.$store.dispatch("commonAction", { "data": postData, "path": path })
          .then((res) => {
            this.linkGenareating = false;
            this.petition['token'] = this.checkProperty(res, 'token');
            this.caseToken = this.checkProperty(res, 'token');
            if (this.checkProperty(petitionDetails, 'questionnaireFilled')) {
              this.anonymousAccesLink = this.webBaseUrl + "/filled-cap-registration-details/" + petitionDetails['_id'] + "?token=" + this.checkProperty(res, 'token');
            } else {
              this.anonymousAccesLink = this.webBaseUrl + "/fill-cap-registration/" + petitionDetails['_id'] + "?token=" + this.checkProperty(res, 'token');
            }

            this.$modal.show('capgenaratModal');
          })
          .catch((err) => {
            this.linkGenareating = false;
            this.showToster({ message: err, isError: true });
          })
      } else {
        if (this.checkProperty(petitionDetails, 'questionnaireFilled')) {
          this.anonymousAccesLink = this.webBaseUrl + "/filled-cap-registration-details/" + petitionDetails['_id'] + "?token=" + this.checkProperty(petitionDetails, 'token');
        }
        this.$modal.show('capgenaratModal');
      }

    },
    showShareLink() {
      this.$modal.show('capgenaratModal')
    },
    upload(fils, category = '') {
      this.disablePWDstatus = false;
      this.pwdDocFormatError = '';
      let model = _.cloneDeep(fils);
      this.value = [];
      var _current = this;
      let efiles = [];
      efiles = _.filter(model, (e) => {
        return e.url != null && e.url != "";
      });
      let nfiles = _.filter(model, (e) => {
        return e.url == null || e.url == undefined;
      });

      let mapper = nfiles.map(
        (item) =>
        (item = {
          name: item.name,
          file: item.file ? item.file : null,
          url: item.url ? item.url : "",
          path: item.path ? item.path : "",
          status: true,
          mimetype: item.type ? item.type : item.mimetype,
        })
      );
      let tempFiles = [];
      if (mapper.length > 0) {
        if (category == 'trackingDocuments') {
          this.trackingDocUpload = true
        } else {
          this.uploading = true;
        }


        let count = 0;
        mapper.forEach((doc, index) => {
          let formData = new FormData();
          formData.append("files", doc.file);
          formData.append("secureType", "private");
          formData.append("getDetails", true);
          count++;
          this.$store.dispatch("uploadS3File", formData).then((response) => {
            response.data.result.forEach((urlGenerated) => {

              let obj = {
                uploadedBy: this.checkProperty(this.getUserData, 'userId'),
                uploadedByName: this.checkProperty(this.getUserData, 'name'),
                uploadedByRoleId: this.getUserRoleId,
                uploadedByRoleName: this.checkProperty(this.getUserData, 'loginRoleName'),
              }
              let tempUrl = urlGenerated
              tempUrl = Object.assign(tempUrl, { uploadedBy: this.checkProperty(this.getUserData, 'userId'), uploadedByName: this.checkProperty(this.getUserData, 'name'), uploadedByRoleId: this.getUserRoleId, uploadedByRoleName: this.checkProperty(this.getUserData, 'loginRoleName') });
              //alert(JSON.stringify(tempUrl))
              tempFiles.push(tempUrl["name"]);
              // trackingDocuments          
              if (category == 'trackingDocuments') {
                this.trackingDocuments.push(tempUrl);
              }
              if (category == 'receiptDocuments') {
                this.receiptDocuments.push(tempUrl);
              }
              if (category == 'uscisDocuments') {
                this.uscisDocuments.push(tempUrl);
              }
              if (category == 'premiumDocuments') {
                this.premiumDocuments.push(tempUrl);
              }
              doc.url = urlGenerated;
              doc.path = urlGenerated;
              doc["mimetype"] = urlGenerated["mimetype"];
              doc["type"] = urlGenerated["mimetype"];
              delete doc.file;
              mapper[index] = doc;
            });
            if (index >= mapper.length - 1) {
              this.uploading = false;
              this.trackingDocUpload = false;
              // _current.$vs.loading.close();
            }
          });
        });
        if (efiles.length > 0) efiles.push(...mapper);
        //this.CommentPayload["documents"] = efiles
      }
    },
    remove(item, data, filindex) {
      data.splice(filindex, 1);
      this.disablePWDstatus = false;


    },
    updatepetition() {
      this.$emit("updatepetition", "Case Details");
    },
    shareLink() {
      let self = this;
      let postData = {
        "petitionId": self.petition['_id'],
        "caseNo": self.petition['caseNo'],
        "link": self.anonymousAccesLink,
        "email": self.linkShareToemailsText,
        entityType: 'case'
      }
      this.sharing = true;
      this.$store.dispatch("commonAction", { "data": postData, "path": "/cap-registrations/share-link" })
        .then(response => {
          this.sharing = false;

          this.showToster({ message: response.message, isError: false });
          this.$modal.hide('genaratModal');
          this.linkShareToEmailList = [];
          this.linkShareToemailsText = '';
        }).catch((err) => {
          this.sharing = false;
          this.showToster({ message: err, isError: true });
        });
    },
    async copyLink() {
      let self = this;
      this.copyingLink = true;
      let petitionDetails = this.petition;
      if ((this.checkProperty(petitionDetails, "token") || this.anonymousAccesLink != '') || (this.checkProperty(petitionDetails, "lcaToken") || this.anonymousLcaAccesLink != '')) {
        try {
          await navigator.clipboard.writeText(this.anonymousAccesLink);
          this.showToster({ message: "Copied successfully ", isError: false, });
          this.showToolTip = true;
          this.copyingLink = false;
          setTimeout(() => {
            this.showToolTip = false;
            this.$modal.hide('genaratModal');
          }, 10)
        } catch ($e) {
          this.copyingLink = false
          //  filderPath = "";
          this.showToster({ message: "Can't Copied folder path! ", isError: true, });
        }
      }

    },
    getBranchList() {

      this.branchList = [];
      let item = {
        filters: {
          "title": '',
          "createdDateRange": [],
          "statusList": [],
          "activeList": [],
          "countryIds": [],
          "stateIds": [],
          "locationIds": []
        },
        getMasterData: true,
        page: 1,
        perpage: 1000,
        sorting: { "path": "createdOn", "order": -1 },

      };
      this.$store
        .dispatch("getList", { "data": item, "path": "/branch/list" })
        .then(response => {
          this.branchList = response.list;//branchvalue


        }).catch((error) => {
          this.branchList = [];
        })
    },
    getPetitioners(callFromSerch = false, searchText = '') {

      let _self = this;
      let query = {
        "matcher": {
          "searchString": searchText,
          "statusIds": [],
          "countryIds": [],
          "stateIds": [],
          "locationIds": [],
          "createdDateRange": []
        },
        "sorting": { "path": "createdOn", "order": 1 },
        "page": 1,
        "perpage": 100,
        getMasterData: true
      }
      this.$store.dispatch("getList", { data: query, path: '/company/list' }).then(response => {

        _self.petitionersList = response.list;

      }).catch((err) => {
        this.petitionersList = [];
      })
    },
    int() {
      //this.premiumProcessing = !this.petition.premiumProcessing;
    }

  },
  mounted() {
    this.int();
    this.getPetitioners();
    this.getBranchList();
    if(this.checkProperty(this.petition, 'questionnaireTplType') == "general"){
        this.isSlg = false
      }
    this.caseToken = this.checkProperty(this.petition, 'token');
    setTimeout(() => {
      this.caseToken = this.checkProperty(this.petition, 'token');

    }, 10)
    setTimeout(() => {
      if (this.checkProperty(this.petition, 'petitionerId')) {
        if (this.petitionersList && this.checkProperty(this.petitionersList, 'length') > 0) {
          let obj = _.find(this.petitionersList, { "_id": this.checkProperty(this.petition, 'petitionerId') })
          this.Petitionervalue = obj
        }
      }
      if (this.branchList && this.checkProperty(this.branchList, 'length') > 0) {
        let obj = _.find(this.petitionersList, { "_id": this.checkProperty(this.petition, 'branchId') })
        this.branchvalue = obj
      }
    }, 100)
    if (this.checkProperty(this.petition, 'beneficiaryDetails')) {
      this.Beneficiaryvalue = this.checkProperty(this.petition, 'beneficiaryDetails')
    }
    
  },
}
</script>