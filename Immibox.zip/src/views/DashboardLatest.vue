<template>
  <div>
    <div class="dashboard__section dashboard__sectionV2">
      <div
        class="dashboard_cnt"
        :class="{ fulldashboard: [1, 2, 50, 51].indexOf(getUserRoleId) > -1 }"
      >
        <div class="dashboard_left">
          <div class="grid_actions">
            <div>
              <div class="self_info">
                <label
                  >{{ generateGreetings }}
                  <b>
                    <template v-if="checkProperty(user, 'userName') != ''">
                      {{ user.userName }}
                    </template>
                    <template v-else>
                      {{ user.name }}
                    </template>
                  </b></label
                >
                <div class="tasks_count">
                <p v-if="pendingActionsCount > 0">
                  You have
                  <a @click="changedTab('todo')"
                    >{{ pendingActionsCount }} pending task(s)</a
                  >
                </p>
                <p v-if="pendingActionsCount == 0 && !isLodaing">
                  <a @click="changedTab('todo')">
                    You don't have pending task(s)
                  </a>
                </p>
                </div>
              </div>
              <ul>
                <!--  // all, todo activity changedTab -->

                <li
                  @click="changedTab('todo')"
                  :class="{ active: tabName == 'todo' }"
                >
                  <a>MY TASKS ({{ pendingActionsCount }})</a>
                </li>
                <li
                  @click="changedTab('activity')"
                  :class="{ active: tabName == 'activity' }"
                >
                  <a>UPDATES</a>
                </li>
                <li
                  @click="changedTab('all')"
                  :class="{ active: tabName == 'all' }"
                >
                  <a>ALL ACTIVITIES</a>
                </li>
              </ul>
            </div>

            <DatePickerCustom
              @ondateSelection="reloadWall"
              v-model="selected_createdDateRange"
            />
          </div>
          <div class="dashboard_left_cnt" >
            <!-- <div class="grid_title">
                    <span>TODAY </span>
                </div>  -->
                <VuePerfectScrollbar
            ref="mainSidebarPs"
            class="scroll-area--main-sidebar"
            :settings="settings"
            @ps-scroll-y="scroll"
          >
              <div class="dashboard_skelton" v-if="isLodaing">
                <div class="skelton_cards" v-for="index in 9" :key="index">
                  <div class="skline line1"></div>
                  <div class="skline line2"></div>
                  <div class="skline line3"></div>
                  <div class="user_skelton">
                    <div class="skline picture"></div>
                    <div>
                      <div class="skline line2"></div>
                      <div class="skline line3"></div>
                    </div>
                  </div>
                </div>
              </div>
              <div v-else-if="!isLodaing && list.length > 0">

              <toDoGridItem
                          :lableData="lableData"
                          :templateClass="templateClass"
                          :all_statusids="all_statusids"
                          :itemTemplate="itemTemplate"
                          @reloadWals="wallList"
                          :userRolelist="userRolelist"
                          :list="list"
                          ref="wallItem"
                        />
              <!----
                <div class="db_grid" id="infinite-list">
                  <template v-if="!isLodaing && list.length">
                    <template v-for="(item, ind) in list">
                      <div
                        class="grid_element"
                        :class="{
                          todoItem: item.type == 'todo',
                          activityItem: item.type != 'todo',
                          ['box' + (ind + 2)]: true,
                          ['box__' + (ind + 2)]: true,
                        }"
                        :key="'item' + ind"
                      >
                        <toDoGridItem
                          :lableData="lableData"
                          :templateClass="templateClass"
                          :all_statusids="all_statusids"
                          :key="ind"
                          :item="item"
                          :itemIndex="ind"
                          :itemTemplate="itemTemplate"
                          @reloadWals="wallList"
                          :userRolelist="userRolelist"
                        />
                      </div>
                    </template>
                  </template>
                </div>
                -->

               <!-- <span class="loader"><img src="@/assets/images/main/loader.gif"></span>-->
              </div>
              <div v-else-if="!isLodaing && list.length <= 0">
                <NoDataFound
                  ref="NoDataFoundRef"
                  :loading="false"
                  :heading="'No ' + tabDataName + ' Found'"
                  type="User Roles"
                />
              </div>

                </VuePerfectScrollbar>
          </div>
        </div>
      </div>
      <div class="dashboard_right" v-if="[1, 2, 50, 51].indexOf(getUserRoleId) < 0">
        <div class="d_activity_sec">
          <div class="d_activity_head">
            <h2>ACTIVE CASES</h2>
            <multiselect
              :allow-empty="false"
              v-model="caseListType"
              @input="filterCasesList"
              :options="caseListTypes"
            ></multiselect>
          </div>

          <template v-if="isListloading">
            <div class="loadingData">
              <div class="skelton_cards" v-for="index in 3" :key="index">
                <div class="skline line1"></div>
                <div class="skline line2"></div>
                <div class="skline line3"></div>
              </div>
            </div>
          </template>
          <template v-else>
            <template
              v-if="
                (caseListType == 'Latest' &&
                  checkProperty(allCaseList, 'length') > 0) ||
                (caseListType == 'Deadlines' &&
                  (checkProperty(missedDeadLineCaseList, 'length') > 0 ||
                    checkProperty(groupedlist, 'length') > 0 ))
              "
            >
              <template v-if="caseListType == 'Latest'">
                <div class="d_activity_cnt">
                  <div class="d_activity_title">
                    <h4>LATEST</h4>
                    <!---  <em>3 Cases</em>  -->
                  </div>
                  <div class="custom-table">
                    <table>
                      <tbody>
                        <template v-for="(petition, index) in allCaseList">
                          <caseItem
                            :caseListType="caseListType"
                            :petition="petition"
                            :key="index"
                          />
                        </template>
                      </tbody>
                    </table>
                  </div>
                </div>
              </template>
              <template v-else>
                <template
                  v-if="
                    checkProperty(missedDeadLineCaseList, 'length') > 0 ||
                    checkProperty(groupedlist, 'length') > 0
                  "
                >
                  <div
                    class="d_activity_cnt"
                    v-if="checkProperty(missedDeadLineCaseList, 'length') > 0"
                  >
                    <div class="d_activity_title">
                      <h4>MISSED DEADLINES</h4>
                      <em
                        >{{
                          checkProperty(missedDeadLineCaseList, "length")
                        }}
                        Cases</em
                      >
                    </div>
                    <div class="custom-table missed_activites">
                      <table>
                        <tbody>
                          <template
                            v-for="(petition, index) in missedDeadLineCaseList"
                          >
                            <caseItem
                              :caseListType="caseListType"
                              :petition="petition"
                              :key="index"
                            />
                          </template>
                          <!----
                            <tr>
                              <td>#H1-B-AMEN-2022-10005 <br/>H1B - Amendment</td>
                              <td>Ravi Kumar <br/>Berkshare LLP</td>
                              <td><p><img class="user-image" src="@/assets/images/main/check2.svg" />Sign</p></td> 
                              <td class="arrow"><a><img class="user-image" src="@/assets/images/main/rightarrow2.svg" /></a></td> 
                            </tr>
                            -->
                        </tbody>
                      </table>
                    </div>
                  </div>

                  <div
                    class="d_activity_cnt"
                    :key="index"
                    v-for="(group, index) in groupedlist"
                  >
                    <div class="d_activity_title">
                      <h4>{{group.date | formatDatetimeline}}</h4>
                      <em
                        >{{
                          checkProperty(group.items, "length")
                        }}
                        Cases</em
                      >
                    </div>
                    <div class="custom-table ">
                      <table>
                        <tbody>
                          <template
                            v-for="(petition, index) in group.items"
                          >
                            <caseItem
                              :caseListType="caseListType"
                              :petition="petition"
                              :key="index"
                            />
                          </template>
                          <!----
                            <tr>
                              <td>#H1-B-AMEN-2022-10005 <br/>H1B - Amendment</td>
                              <td>Ravi Kumar <br/>Berkshare LLP</td>
                              <td><p><img class="user-image" src="@/assets/images/main/check2.svg" />Sign</p></td> 
                              <td class="arrow"><a><img class="user-image" src="@/assets/images/main/rightarrow2.svg" /></a></td> 
                            </tr>
                            -->
                        </tbody>
                      </table>
                    </div>
                  </div>
                </template>
              </template>
            </template>
            <template v-else >
              <div class="no-data">
              
              <NoDataFound   ref="NoDataFoundRef" :loading="false"  :heading="'No Data Found'"  type="User Roles"/>
              
              </div></template
            >
          </template>
        </div>

        <div
          class="graphs_sec"
          v-if="[1, 2, 50, 51].indexOf(getUserRoleId) < 0"
        >
          <casesChart :wallsLoaded="true"   :caseStatusList="caseStatusList"   :allCaseTypes="allCaseTypes"/>
          <usersChart :wallsLoaded="true"   :caseStatusList="caseStatusList"   :allCaseTypes="allCaseTypes" />
          <lcaChart :wallsLoaded="true"     :caseStatusList="caseStatusList"   :allCaseTypes="allCaseTypes" />
          <invoiceChart :wallsLoaded="true" :caseStatusList="caseStatusList"   :allCaseTypes="allCaseTypes" />
        </div>
        <!---
            <div class="graph_block">
                <div class="graph_title">
                    <h4>USERS</h4>
                </div>
                <div class="graph_cnt">

                        <div>
                        <canvas id="planet-chart"></canvas>
                        </div>

                </div>
            </div>
            <div class="graph_block">
                <div class="graph_title">
                    <h4>LCA</h4>
                </div>
                <div class="graph_cnt">

                </div>
            </div>
             <div class="graph_block">
                <div class="graph_title">
                    <h4>INVOICE</h4>
                </div>
                <div class="graph_cnt">

                </div>
            </div>
            -->
      </div>
    </div>
  </div>
</template>
 
 
<script>
import VueApexCharts from "vue-apexcharts";
import Vue from "vue";
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import { MoreVerticalIcon } from "vue-feather-icons";
import DateRangePicker from "vue2-daterange-picker";
import Avatar from "vue-avatar";
import WallMessage from "../views/wall/message.vue";

import toDoGridItem from "./wall/templateOneItem";
//import activityItem from "./wall/activityItem.vue";
import _ from "lodash";
import NoDataFound from "@/views/common/noDataFound.vue";
import "vue2-daterange-picker/dist/vue2-daterange-picker.css";
Vue.use(VueApexCharts);
import Paginate from "vuejs-paginate";

import JQuery from "jquery";
Vue.component("apexchart", VueApexCharts);
import casesChart from "../views/wall/casesChart.vue";
import usersChart from "../views/wall/usersChart.vue";
import lcaChart from "../views/wall/lcaChart.vue";
import invoiceChart from "../views/wall/invoiceChart.vue";
import moment from "moment";
import Multiselect from "vue-multiselect-inv";
import VueSlimScroll from "vue-slimscroll";
import DatePickerCustom from "@/views/common/_date_picker_custom.vue";
import caseItem from "@/views/petition/caseItem.vue";

Vue.use(VueSlimScroll);
var _isotope;
export default {
  components: {
    caseItem,
    DatePickerCustom,
    Paginate,
    WallMessage,
    Avatar,
    VuePerfectScrollbar,
    MoreVerticalIcon,
    DateRangePicker,
    toDoGridItem,
  //  activityItem,
    NoDataFound,
    Multiselect,
    casesChart,
    usersChart,
    lcaChart,
    invoiceChart,
  },
  data: function () {
    return {
       settings: { 
        swipeEasing: false,
      },
      caseStatusList:[],
      allCaseTypes:[],
      userRolelist: [],
        all_statusids: [],


      lableData: [],
    
      wallsLoaded: false,
      pendingActionsCount: 0,
      tabDataName: "Tasks",
      isOpenDateFilter: false,
      subItem: false,
      selected_createdDateRange: [],
      autoApply: "",
      list: [],
      itemCount: 0,
      caseListTypes: ["Deadlines", "Latest"],
      caseListType: "Deadlines",
      scorlOptions: {
        height: "100%",
        size: 0,
      },
    
      templateClass: "box",
      windowHight: 0,
      callFromSerch: false,
      itemTemplate: [],
      isLodaing: true,
      tabName: "todo",
      perPage: 25,
      page: 1,

      gap: 0,
      frame: [
        [1, 1, 2, 2],
        [3, 3, 2, 2],
        [4, 4, 4, 5],
      ],
      rectSize: 0,
      useFrameFill: true,
      dateRange: {
        // startDate: '2019-12-26',
        // endDate: '2019-12-28',
      },
      username: "",
      activities: [],
      // options: {},
      series: [50, 102, 155, 141, 117],
      dashboard_data: {},
      lca_requests: [],
      new_petitioners: [],
      new_petitions: [],
      petitionersCount: {},
      beneficiaryStats: {},

      petitionsCount: {},
      rfe_petitions: [],

      //recent activity data
      recent_activitys: [],
      my_tasks: [],
      roleId: 0,
      wallFilterData: {
        filters: {
          types: ["todo"], // all, todo activity
          createdDateRange: [],
        },
        page: 1,
        perpage: 25,
        sorting: {
          path: "createdOn",
          order: -1,
        },
      },
      jaquery: null,
      filterText: "Today",
      isListloading: false,
      allCaseList: [],
      todayCaseList: [],
      tomorrowCaseList: [],
      groupedlist: [],
      missedDeadLineCaseList: [],
      getMissingDeadlines: false,
      deadlineDateRange: [],
      callFromTabChange:false,
    };
  },

  mounted() {

   /*
    this.getCaseStatusList(),
    this.getVisaTypes(); 
    this.getCompanyStatusList();
    this.getUserRoles();
    */
    this.$store.dispatch("commonAction" ,{data:{} ,path:"/masterdata/list-for-dashboard"}).then((res)=>{
       /*
        this.caseStatusList
        this.allCaseTypes 
        this.userRolelist
        this.all_statusids

       */
      // alert(JSON.stringify(res))
        this.allCaseTypes = this.checkProperty( res,'petitionTypeList');
        this.caseStatusList = this.checkProperty( res,'petitionStatusList');
        this.userRolelist = this.checkProperty( res,'userRoleList');
        this.all_statusids = this.checkProperty( res,'companyStatusList');
        this.all_statusids = _.filter(this.all_statusids, (item) => {
            return [1, 2, 3, 4].indexOf(item["id"]) > -1;
        });
        

    }).catch((error)=>{}) 



   
    this.isListloading = true;

    this.$store
      .dispatch("getList", {
        data: { category: "WORKFLOW" },
        path: "/messages/list",
      })
      .then((response) => {
        //alert(JSON.stringify(response))
        this.lableData = response.messages.WORKFLOW;
      });
    this.wallsLoaded = false;
    this.filterText = "";
    this.jaquery = JQuery;
    
    
    this.username = this.$store.state.user.name;
    //  this.roleId = this.$store.state.user['roleId'][0];

    this.petitionsCount = {
      petitionCount: 0,
      rfeCount: 0,
      totalCount: 0,
    };
    this.petitionersCount = {
      approvedCount: 0,
      pendingCount: 0,
      totalCount: 0,
    };
    this.beneficiaryStats = {
      total: 0,
      active: 0,
      inactive: 0,
    };

    //this.get_dashboardData();
    // this.get_recentActivitys();
    // this.get_mytasks();
    // this.getactivities();
    this.wallFilterData = {
      filters: {
        types: [this.tabName], // all, todo activity
        createdDateRange: [],
      },
      page: this.page,
      perpage: this.perPage,
      sorting: {
        path: "createdOn",
        order: -1,
      },
    };
    this.wallList();
    // this.myresizeEventHandler();
    this.filterCasesList();
  },

  created() {
    window.addEventListener("resize", this.myresizeEventHandler);
  },
  destroyed() {
    window.removeEventListener("resize", this.myresizeEventHandler);
  },
  methods: {

    

      getVisaTypes(){
      let item ={
      matcher:{
          "searchString":'',
          getWorkFlowConfig:false
          // "petitionType":

      },   
      page:1,
      perpage:100000,
      category: "petition_types",
      "sorting": {
        "path": "name",
        "order": 1
        }

      };

      this.$store
      .dispatch("getMasterData",item )
      .then(response => {
        this.allCaseTypes = response.list;
        
      });
      },

    getCaseStatusList() {
      

      this.$store
        .dispatch("get_petition_statusids")
        .then(response => {
          this.caseStatusList = response;
        });
    },
     getUserRoles() {
      let query = {};
      query["page"] = 1;
      query["perpage"] = 100;
      query["matcher"] = {};
      query["category"] = "user_roles";

      this.$store
        .dispatch("getMasterData", query)
        .then((response) => {
          this.userRolelist = response.list;
        })
        .catch(() => {});
    },
    getCompanyStatusList() {
      this.all_statusids = [];
      let postdata = {
        page: 1,
        perpage: 1000,
        category: "company_status",
      };
      this.$store
        .dispatch("getMasterData", postdata)
        .then((res) => {
          this.all_statusids = res["list"];
          this.all_statusids = _.filter(this.all_statusids, (item) => {
            return [1, 2, 3, 4].indexOf(item["id"]) > -1;
          });
        })
        .catch(() => {});
    },


    filterCasesList(type = "Deadlines") {
      /*
      caseListTypes: ['Latest', 'Deadlines'],
        caseListType:'Latest',
      */
      if (this.caseListType == "Latest") {
        this.deadlineDateRange = [];
        this.getMissingDeadlines = false;
      } else {
        let today = moment();
        let tomorrow = moment().add(7, "days");
        let yesterday = moment().add(-1, "days");
        this.deadlineDateRange = [today, tomorrow];
        this.getMissingDeadlines = true;
      }
      this.isListloading = true;
      this.getpetitions();
    },

    getpetitions() {
      let self = this;
      //  allCaseList:[],
      // todayCaseList:[],
      // tomorrowCaseList:[],
      //missedDeadLineCaseList

      let postData = {
        matcher: {
          //	"rfeCases": true,
          searchString: "",
          petitionerIds: [],
          beneficiaryIds: [],
          statusIds: [],
          typeIds: [],
          subTypeIds: [],
          genders: [],
          maritalStatusIds: [],
          countryIds: [],
          stateIds: [],
          locationIds: [],
          createdDateRange: [],
          getMasterDataOnly: false, // Send true when needs master data only
          lcaStatusIds: [],
          invoiceStatusIds: [],
          getMissingDeadlines: self.getMissingDeadlines,
          deadlineDateRange: self.deadlineDateRange,
        },
        page: 1,
        perpage: 20,
        sorting: {
          path: "createdOn", //deadlineDays, updatedOn, createdByName, typeName, subTypeName, caseNo, statusName, clientName, beneficiaryName
          order: 1,
        },
        today: moment().format("YYYY-MM-DD"),
      };
      this.isListloading = true;
      this.allCaseList = [];
      this.todayCaseList = [];
      this.tomorrowCaseList = [];
      this.missedDeadLineCaseList = [];

      this.$store
        .dispatch("petitioner/getpetitions", postData)
        .then((response) => {
          this.isListloading = false;

          this.allCaseList = _.cloneDeep(response.list);
          if (this.caseListType == "Deadlines") {
            //find todayCaseList  ,   tomorrowCaseList ,  missedDeadLineCaseList;
            var futurecases = _.filter(response.list, (item) => {
              let today = moment().startOf("day");
              let deadlineDate = moment(item["deadlineDate"]).startOf("day");
              return deadlineDate.isSameOrAfter(today);
            });

            this.missedDeadLineCaseList = _.filter(response.list, (item) => {
              let today = moment().startOf("day");
              let deadlineDate = moment(item["deadlineDate"]).startOf("day");
              return deadlineDate.isBefore(today);
            });

            var result = _.chain(futurecases)
              .groupBy((datum) =>
                moment(new Date(datum.deadlineDate)).startOf("day").format()
              )
              .map((items, id) => ({
                date: id,
                items: items,
              }))
              .value();

              this.groupedlist = _.sortBy(result, "date");
          }

          //alert(this.totalpages);
        })
        .catch((err) => {
          this.isListloading = false;
          this.allCaseList = [];
          this.todayCaseList = [];
          this.tomorrowCaseList = [];
          this.missedDeadLineCaseList = [];
        });
    },
   
    getStats() {
      //  this.statusCount =0;
      let payLoad = {
        categoryList: ["pending-actions-count"], //["case-stats-by-status", "pending-actions-count", "lca-stats-by-status", "invoice-stats-by-status", "petitioner-stats-by-status", "pending-cases-stats", "case-aging-stats"],
        matcher: {
          statusIds: [],
          typeIds: [],
          subTypeIds: [],
          createdDateRange: [],
        },
      };

      payLoad["matcher"]["createdDateRange"] =
        this.wallFilterData["filters"]["createdDateRange"];

      this.$store
        .dispatch("getStats", payLoad)
        .then((result) => {
          if (_.has(result, "pendingActionsCount")) {
            this.pendingActionsCount = result["pendingActionsCount"];
          }
        })
        .catch((err) => {
          this.pendingActionsCount = 0;
        });
    },

    togleDateFIlter() {
      this.isOpenDateFilter = !this.isOpenDateFilter;
      // if(this.isOpenDateFilter){
      //     document.addEventListener("click", ()=>{
      //         this.isOpenDateFilter =false;

      //     });
      // }
    },

    reloadWall(seleteddates) {
      if (seleteddates && seleteddates.startDate != null) {
        this.wallFilterData["filters"]["createdDateRange"] = [];
        this.wallFilterData["filters"]["createdDateRange"] = [
          seleteddates.startDate,
          seleteddates.endDate,
        ];
      } else {
        this.wallFilterData["filters"]["createdDateRange"] = [];
      }
      this.wallList();
    },
    generateDate(type = "") {
      let startDate = moment().startOf("day").format("YYYY-MM-DD");
      let endDate = moment().endOf("day").format("YYYY-MM-DD");
      this.filterText = "Today";
      this.isOpenDateFilter = true;
      if (type == "Today") {
        this.filterText = "Today";
        startDate = moment().startOf("day").format("YYYY-MM-DD");
        endDate = moment().endOf("day").format("YYYY-MM-DD");
      } else if (type == "This Week") {
        this.filterText = "This Week";
        startDate = moment().startOf("week").format("YYYY-MM-DD");
        endDate = moment().endOf("week").format("YYYY-MM-DD");
      } else if (type == "This Month") {
        this.filterText = "This Month";
        startDate = moment().startOf("month").format("YYYY-MM-DD");
        endDate = moment().endOf("month").format("YYYY-MM-DD");
      } else if (type == "Custom_date") {
        startDate = this.selected_createdDateRange["startDate"];
        endDate = this.selected_createdDateRange["endDate"];
        startDate = moment(startDate).format("YYYY-MM-DD");
        endDate = moment(endDate).format("YYYY-MM-DD");

        this.filterText = startDate + " - " + endDate;
      }

      this.isOpenDateFilter = false;
      this.wallFilterData["filters"]["createdDateRange"] = [];
      this.wallFilterData["filters"]["createdDateRange"] = [startDate, endDate];
      this.wallList();
    },
    scroll(e) {
      const { target } = e;
      if (
        !this.callFromTabChange &&
        Math.ceil(target.scrollTop) >=
        target.scrollHeight - target.offsetHeight
      ) {
        //this code will run when the user scrolls to the bottom of this div so
        //you could do an api call here to implement lazy loading
        //this.countTotalPages

        if (this.wallFilterData['page'] < this.countTotalPages) {
        //  this.page = this.page + 1;
          
           this.wallFilterData['page'] = this.wallFilterData['page']+1;
          this.wallList(true);
        }
      }
    },

    

    myresizeEventHandler() {
      this.windowHight = window.screen.height; // window.innerHeight;
    },

    pageNate(pageNum) {
      this.page = pageNum;

      this.wallFilterData = {
        filters: {
          types: [this.tabName], // all, todo activity
          createdDateRange: [],
        },
        page: this.page,
        perpage: this.perPage,
        sorting: {
          path: "createdOn",
          order: -1,
        },
      };
      this.wallList();
    },
    getRandomTemplate() {
      let tmp = [
        [
          "grid_1x",
          "grid_1x",
          "grid_3x",
          "grid_3x",
          "grid_3x",
          "grid_2x",
          "grid_1x",
          "grid_1x",
          "grid_1x",
          "grid_2x",
          "grid_1x",
          "grid_2x",
          "grid_2x",
          "grid_1x",
          "grid_1x",
          "grid_2x",
          "grid_3x",
          "grid_3x",
          "grid_3x",
          "grid_1x",
          "grid_2x",
          "grid_1x",
          "grid_2x",
          "grid_2x",
          "grid_1x",
          "grid_1x",
          "grid_2x",
        ],

        [
          "grid_2x",
          "grid_2x",

          "grid_2x",
          "grid_1x",
          "grid_1x",
          "grid_3x",
          "grid_3x",
          "grid_3x",
          "grid_2x",
          "grid_2x",
          "grid_1x",
          "grid_2x",
          "grid_1x",
          "grid_3x",
          "grid_3x",
          "grid_3x",
          "grid_1x",
          "grid_1x",
          "grid_2x",
          "grid_2x",
          "grid_2x",
          "grid_1x",
          "grid_2x",
          "grid_1x",
          "grid_3x",
          "grid_3x",
          "grid_3x",
        ],

        [
          "grid_1x",
          "grid_1x",
          "grid_1x",
          "grid_2x",
          "grid_1x",
          "grid_3x",
          "grid_3x",
          "grid_3x",
          "grid_2x",
          "grid_2x",
          "grid_2x",
          "grid_1x",
          "grid_1x",
          "grid_1x",
          "grid_2x",
          "grid_1x",
          "grid_3x",
          "grid_3x",
          "grid_3x",
          "grid_2x",
          "grid_2x",
          "grid_1x",
          "grid_1x",
          "grid_2x",
          "grid_3x",
          "grid_3x",
          "grid_3x",
        ],

        [
          "grid_2x",
          "grid_1x",
          "grid_1x",
          "grid_1x",
          "grid_1x",
          "grid_2x",
          "grid_2x",
          "grid_3x",
          "grid_3x",
          "grid_3x",
          "grid_2x",
          "grid_2x",
          "grid_2x",
          "grid_1x",
          "grid_1x",
          "grid_3x",
          "grid_3x",
          "grid_3x",
          "grid_1x",
          "grid_2x",
          "grid_1x",
          "grid_3x",
          "grid_3x",
          "grid_3x",
          "grid_1x",
          "grid_1x",
          "grid_2x",
          "grid_2x",
          "grid_2x",
          "grid_3x",
          "grid_3x",
          "grid_3x",
        ],
      ];
      let random = _.random(tmp.length - 1);

      return tmp[random];
    },
    updateLoading(value) {
      setTimeout(() => {
        try {
          if (this.$refs["NoDataFoundRef"]) {
            this.$refs["NoDataFoundRef"].updateLoading(value);
          }
        } catch (err) {
        }
      }, 100);
      return;
    },
    geAlltWallList({ callFromSerch = false, postData = {} }) {
      
     
      
    
      //this.$vs.loading();
      var _self = this;
       this.getStats();
       if(!callFromSerch){
          this.page = 1;
          this.wallFilterData['page'] = 1;
          
          
       }

        this.updateLoading(true);
        this.isLodaing = true;
       
       
     
      this.$store
        .dispatch("common/getWallList", postData)
        .then((response) => {
        
         // alert(callFromSerch)
           if( !callFromSerch){
            //  this.list = [];
              this.list = response;
              this.$refs['wallItem'].initIsotop()
          }else{
            let tempList = _.cloneDeep( this.list )
            _.forEach(response ,(item)=>{
              this.list.push(item) 
              tempList.push(item);
             

            })
            
          //  this.list = [];
          //  this.list = _.cloneDeep(tempList)
           

          }
         
           this.isLodaing = false;
           this.updateLoading(false);
            this.callFromTabChange =false;
          /*
          setTimeout(() => {
            jQuery(".db_grid").isotope({
              layoutMode: "packery",
              itemSelector: ".grid_element",
              masonry: {
                horizontalOrder: true,
              },
            });
            if (jQuery(".db_grid").height() <= 50) {
              jQuery(".db_grid").height("auto");
              var _h = jQuery(".db_grid").innerHeight();
              jQuery(".db_grid").height(_h);
            }

          
            // this.$vs.loading.close();
          }, 0);
          */
          
          this.wallsLoaded = true;
          //alert(this.perpage);
           this.updateLoading(false);
        })
        .catch(() => {
          this.wallsLoaded = true;
          // this.$vs.loading.close();
          this.updateLoading(false);
          jQuery(".db_grid").isotope({
            layoutMode: "packery",
            itemSelector: ".grid_element",
          });
          this.isLodaing = false;
           this.callFromTabChange =false;
        });
    },
    changedTab(tabName = "all") {
      var _prevtab = this.tabName;
      this.callFromTabChange =true;
      this.page = 1;
      this.tabName = tabName;
      this.wallFilterData = {
        filters: {
          types: [this.tabName], // all, todo activity
          createdDateRange: [],
        },
        page: 1,
        perpage: this.perPage,
        sorting: {
          path: "createdOn",
          order: -1,
        },
      };
      //this.tabDataName  = 'Activities ';
      // if('todo'==this.tabName || 'activity'==this.tabName){
      //       this.tabDataName  = 'Tasks ';
      // }

      this.tabDataName = "Activities ";
      if ("todo" == this.tabName || "activity" == this.tabName) {
        //   if('todo'==this.tabName){
        //        jQuery('.db_grid').isotope({ filter: '.todo' })

        //   }
        //    if('todo'==this.tabName){
        //         jQuery('.db_grid').isotope({ filter: '.activity' })

        //   }

        this.tabDataName = "Tasks ";
      }
    

      this.wallList();
    },
    wallList(isCallFromSerch=false) {
      
      this.geAlltWallList({ callFromSerch:isCallFromSerch,postData: this.wallFilterData });
    },
    get_dashboardData: function () {
      this.$store.dispatch("get_dashboard_data", {}).then((response) => {
        this.dashboard_data = response;
        this.lca_requests = this.dashboard_data["lca_requests"]
          ? this.dashboard_data["lca_requests"]
          : [];

        this.petitionsCount = this.dashboard_data["petitionsCount"]
          ? this.dashboard_data["petitionsCount"]
          : {
              petitionCount: 0,
              rfeCount: 0,
              totalCount: 0,
            };
        this.petitionersCount = this.dashboard_data["petitionersCount"]
          ? this.dashboard_data["petitionersCount"]
          : {
              approvedCount: 0,
              pendingCount: 0,
              totalCount: 0,
            };
        this.beneficiaryStats = this.dashboard_data["beneficiaryStats"]
          ? this.dashboard_data["beneficiaryStats"]
          : {
              total: 0,
              active: 0,
              inactive: 0,
            };

        this.new_petitioners = this.dashboard_data["new_petitioners"]
          ? this.dashboard_data["new_petitioners"]
          : [];
        this.new_petitions = this.dashboard_data["new_petitions"]
          ? this.dashboard_data["new_petitions"]
          : [];
        this.rfe_petitions = this.dashboard_data["rfe_petitions"]
          ? this.dashboard_data["rfe_petitions"]
          : [];
      });
    },
    get_recentActivitys: function () {
      this.$store.dispatch("get_recent_activitys", {}).then((response) => {
        this.recent_activitys = response.list;
      });
    },
    getactivities: function () {
      this.$store.dispatch("getactivities").then((response) => {
        this.activities = response;
      });
    },
    get_mytasks: function () {
      this.$store.dispatch("get_my_tasks", {}).then((response) => {
        this.my_tasks = response.list.map((element) => {
          //"navigationKey":

          element["data"]["navigation_link"] = "#";
          if (element["data"]["navigationKey"] == "USER_DETAILS")
            if (element["data"]["navigationKey"] == "COMPANY_DETAILS")
              // element["data"]['navigation_link'] ="#/company/details/"+element["data"]['companyId'];

              element["data"]["navigation_link"] =
                "/company/details/" + element["data"]["companyId"];

          if (element["data"]["navigationKey"] == "PETITION_DETAILS")
            element["data"]["navigation_link"] =
              "/petition-details/" + element["data"]["petitionId"];

          if (element["data"]["navigationKey"] == "LCA_DETAILS")
            element["data"]["navigation_link"] =
              "/lca-details/" + element["data"]["lcaId"];

          if (element["data"]["description"].includes("questionnaire "))
            element["data"]["navigation_link"] =
              "/questionnaire/" + element["data"]["petitionId"];

          return element;
        });
        //this.my_tasks = a//response.list;
      });
    },
    refresh() {
      // alert("REFERESH");
      this.get_recentActivitys();
    },
  },
  computed: {
    generateGreetings() {
      var currentHour = moment().format("HH");

      if (currentHour >= 3 && currentHour < 12) {
        return "Good Morning";
      } else if (currentHour >= 12 && currentHour < 15) {
        return "Good Afternoon";
      } else if (currentHour >= 15 && currentHour < 20) {
        return "Good Evening";
      } else if (currentHour >= 20 && currentHour < 3) {
        return "Good Night";
      } else {
        return "Hello";
      }
    },
    countTotalPages() {
      return (this.totalpages = Math.ceil(
        this.getWallList.totalCount / this.perPage
      ));
    },
    user() {
      return this.$store.state.user;
    },
    getToDoWallListCount() {
      let returnVal = 0;
      let todoList = _.filter(this.getWallList.list, { type: "todo" });
      if (todoList) {
        returnVal = todoList.length;
      }
      return returnVal;
    },
  },
};
</script>
