<template>
  <div>
    <div class="content-header">
      <div class="content-header-left">
        <div class="d-flex align-center">
        <h2 class="go_back" @click="gotoMainType()"><img src="@/assets/images/main/return_arrow.png" /></h2>
        <div class="search">
          <vs-input
            icon-pack="feather"
            icon="icon-search"
            v-model="searchtxt"
            placeholder="Search by Name"
            class="is-label-placeholder"
          />
        </div>
        </div>
      </div>
      
      <div class="content-header-right">
        <!--
        <vs-dropdown  vs-custom-content vs-trigger-click>
          <vs-button
            color="primary"
            class="filter-btn"
            type="border"
            icon-pack="feather"
            icon="icon-chevron-down"
            icon-after
          >
            <img src="@/assets/images/main/icon-filter.svg" /> Filters
          </vs-button>
          <vs-dropdown-menu ref="filter_menu" class="filters-content">

            <div class="filters-form-fileds">
              <div class="form-container">
                <div class="vx-row">

                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Select Type</label>
                    
                    <multiselect v-model="selected_typeids" :options="all_formTypes" :multiple="true" :hideSelected="true"
                      :close-on-select="false" :clear-on-select="false" :select-label="''" :preserve-search="true"
                      placeholder="Select Types" label="name" track-by="name" :preselect-first="false">
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">{{ values.length }}
                          options selected</span>
                      </template>
                    </multiselect>
                  </div>
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Select Status</label>
                    
                    <multiselect v-model="selected_statusids" :options="all_statusids" :multiple="true" :hideSelected="true"
                      :close-on-select="false" :clear-on-select="false" :select-label="''" :preserve-search="true"
                      placeholder="Select Status" label="name" track-by="name" :preselect-first="false">
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">{{ values.length }}
                          options selected</span>
                      </template>
                    </multiselect>
                  </div>

                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Created Date</label>
                    <date-range-picker
                      :autoApply="autoApply"
                      :ranges="false"
                      v-model="selected_createdDateRange"
                    ></date-range-picker>
                  </div>
                 </div>
                   
                   
     
              </div>
            </div>
            <div class="filters-status">
              <div class="left-buttons">

              </div>
              <div class="right-buttons">
                <vs-button color="success" class="save" type="filled" v-on:click="set_filter()">Apply</vs-button>
                <vs-button color="dark" class="cancel" type="filled" v-on:click="clear_filter($event)">Clear
                </vs-button>
              </div>
            </div>
          </vs-dropdown-menu>
        </vs-dropdown>
        -->
        <vs-button type="border" v-if="[1].indexOf(getUserRoleId)>-1" class="light-blue-btn" @click="createNew(true)"
          >Add Case Subtype
          <span>
            <img
              class="add-user-icon ml-2"
              src="@/assets/images/main/add-user.svg"
            />
          </span>
        </vs-button>
      </div>
    </div>
    <NoDataFound ref="NoDataFoundRef" v-if="list.length == 0" :content="''" :heading="callFromSerch?'No Results Found':'No Case Types Found'" type='Case Subtype' />
    
    <div class="accordian-table" v-if="list.length > 0">
      <vs-table :data="list" :no-data-text="'No data found..!'">
        <template slot="thead" v-if="list.length>0">
          <vs-th>
            <a
              @click="sortMe('name')"
              v-bind:class="{
                sort_ascending: sortKeys['name'] == 1,
                sort_descending: sortKeys['name'] != 1,
              }"
            >
              Name
            </a>
          </vs-th>
          <vs-th v-if="[3 ,4].indexOf(getUserRoleId)>-1">
          Custom Code
           </vs-th >
          <vs-th class="actions"   >
          <template  v-if="[1].indexOf(getUserRoleId)>-1">
          Actions
          </template>
          <template v-else>
          </template>
          
          </vs-th>
        </template>

        <template slot-scope="{ data }">
          <vs-tr :data="tr" :key="indextr" v-for="(tr, indextr) in data">
            <vs-td :data="tr.username">
              <!--
              <img class="user-image" src="@/assets/images/main/avatar2.svg" />
              v-if="checkProperty(tr ,'petitionConfigDetails') && tr['petitionConfigDetails'].length>0"
              -->

              {{ tr.name}}
            </vs-td>
            
           <vs-td v-if="[3 ,4].indexOf(getUserRoleId)>-1">
            
              
              {{checkProperty(tr ,'casenoConfigDetails' ,'code') }}
            </vs-td>
    

            <vs-td :data="tr.statusId" >
              <vs-dropdown class="msg_dropdown_icon" :vs-trigger-click="true"  v-if="[1].indexOf(getUserRoleId)>-1 || [3,4].indexOf(getUserRoleId)>-1 " >
                <a class="a-icon" href.prevent
                  ><more-vertical-icon
                    size="1.5x"
                    class="custom-class"
                  ></more-vertical-icon
                ></a>
                <vs-dropdown-menu class="loginx msg_dropdown"  >
         
                   <vs-dropdown-item  v-if="[3 ,4].indexOf(getUserRoleId)>-1" >

                       <span style="cursor:pionter;padding:3px 10px"   @click="openCaseCodePopup(tr)" >
                       
                       <template v-if="checkProperty(tr ,'casenoConfigDetails' ,'_id')">Edit Case Custom Code</template>
                       <template v-else>Case Custom Code</template>
                       </span>
                    </vs-dropdown-item>

        
                  <vs-dropdown-item v-if="[1].indexOf(getUserRoleId)>-1">
                    <a href.prevent> <p @click="editMe(tr)">Edit </p></a>
                  </vs-dropdown-item>
                </vs-dropdown-menu>
              </vs-dropdown>
            </vs-td>
          </vs-tr>
        </template>
      </vs-table>
      <div class="table_footer">
        <div class="vx-col  con-select pages_select"  v-if="list.length>0">
          <label class="typo__label">Per Page</label>
          <multiselect @input="changeperPage()" v-model="perpage" :options="perPeges" :multiple="false"
              :close-on-select="true" :clear-on-select="false" :preserve-search="true" placeholder="Per Page"
              :preselect-first="true">
            </multiselect>
            <span class="totla_list_count" v-if="totalCount"> Total <em>{{totalCount}}</em></span>
          </div>
          <paginate
        v-if="list.length > 0"
        v-model="page"
        :page-count="totalpages"
        :page-range="3"
        :margin-pages="2"
        :click-handler="pageNate"
        prev-class="vs-pagination--buttons btn-prev-pagination vs-pagination--button-prev"
        next-class="vs-pagination--buttons btn-next-pagination vs-pagination--button-next"
        :prev-text="'<i></i>'"
        :next-text="'<i></i>'"
        :container-class="'pagination vs-pagination--nav'"
        :page-class="'page-item'"
      ></paginate>
      </div>
      
    </div>

    <vs-popup
      class="holamundo main-popup"
      :title="editPetitionConfig?'Update Configuration':'Configuration'"
      v-if="addPopup"
      :active.sync="addPopup"
    >
      <form>
        <div class="form-container form_uploads">
          <div class="vx-row">
          
            <div class="vx-col w-full">
              <div class="form_group">
                <label class="form_label">Form</label>
                 <div class="con-select w-full"> 
                    <multiselect
                      class="w-full"
                      v-model="newConfig.formsIds"
                      :options="formsList"
                      :multiple="true" :hideSelected="true"
                      name="forms"
                      :close-on-select="false"
                      :clear-on-select="false"
                      :select-label="''"
                      :preserve-search="true"
                      :hide-on-select="true"
                      @input="changedDocType('Form')"
                      placeholder="Select Forms"
                      label="name"
                      track-by="_id"
                      :preselect-first="false"
                    >
                      <!-- <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                          class="multiselect__single"
                          v-if="values.length &amp;&amp; !isOpen"
                          >{{ values.length }} options selected</span
                        >
                      </template> -->
                      <template slot="selection" slot-scope="{ values, isOpen }">
                          <span
                          class="multiselect__selectcustom"
                          v-if="values.length && !isOpen"
                          >{{ values.length }} Form(s) selected</span
                          >
                          <span
                          class="multiselect__selectcustom"
                          v-if="values.length && isOpen"
                          ></span>
                      </template>
                    </multiselect>
                    <span class="text-danger text-sm" v-show="errors.has('forms')">{{
                      errors.first("forms")
                    }}</span>
                </div>
                <!-- <template v-for="(item, index) in newConfig.formsIds">
                  <div class="uploaded-list margin" :key="index">
                    <vs-chip
                      @click="remove(item, newConfig.formsIds, index)"
                      
                      closable
                    >
                      {{ item.name }}
                    </vs-chip>
                  </div>
              </template> -->
              </div>
              
            </div>
          </div>
          <div class="vx-row">
            
            <div class="vx-col w-full">
               <div class="form_group">
                 <label class="form_label">Letter</label>
                <div class="con-select w-full">
                  <multiselect
                    class="w-full"
                    v-model="newConfig.letterIds"
                    :options="lettersList"
                    :multiple="true" :hideSelected="true"
                    name="Letters"
                    :close-on-select="false"
                    :clear-on-select="false"
                    :select-label="''"
                    :preserve-search="true"
                    :hide-on-select="true"
                    @input="changedDocType('Letter')"
                    placeholder="Select Letters"
                    label="name"
                    track-by="_id"
                    :preselect-first="false"
                  >
                    <!-- <template slot="selection" slot-scope="{ values, isOpen }">
                      <span
                        class="multiselect__single"
                        v-if="values.length &amp;&amp; !isOpen"
                        >{{ values.length }} options selected</span
                      >
                    </template> -->
                    <template slot="selection" slot-scope="{ values, isOpen }">
                          <span
                          class="multiselect__selectcustom"
                          v-if="values.length && !isOpen"
                          >{{ values.length }} Letter(s) selected</span
                          >
                          <span
                          class="multiselect__selectcustom"
                          v-if="values.length && isOpen"
                          ></span>
                      </template>
                  </multiselect>
                  <span class="text-danger text-sm" v-show="errors.has('Letters')" >{{ errors.first("Letters") }}</span>
                </div>
                <!-- <template v-for="(item, index) in newConfig.letterIds">
                  <div class="uploaded-list margin" :key="index">
                    <vs-chip
                      @click="remove(item, newConfig.letterIds, index)"
                       
                      closable
                    >
                      {{ item.name }}
                    </vs-chip>
                  </div>
                </template> -->
               </div>
            </div>
          </div>

          <div class="vx-row">
            <div class="vx-col w-full">
            <div class="form_group">
                <label class="form_label">Template</label>
                <div class="con-select w-full">
                <multiselect
                  class="w-full"
                  v-model="newConfig.questionnaireTplId"
                  :options="questionnaireTemplates"
                  :multiple="false"
                  name="Tenants"
                  :close-on-select="true"
                  :clear-on-select="false"
                  :select-label="''"
                  :preserve-search="true"
                  placeholder="Select Questionnaire Template"
                  label="name"
                  track-by="_id"
                  :preselect-first="false"
                >
                  <template slot="selection" slot-scope="{ values, isOpen }">
                    <span
                      class="multiselect__single"
                      v-if="values.length &amp;&amp; !isOpen"
                      >{{ values.length }} options selected</span
                    >
                  </template>
                </multiselect>
                 </div>
            </div>
            </div>
          </div>

          <div
            class="text-danger text-sm formerrors"
            v-show="formerrors.msg"
            @click="formerrors.msg = ''"
          >
            <vs-alert
              color="warning"
              class="warning-alert reg-warning-alert no-border-radius"
              icon-pack="IntakePortal"
              icon="IP-information-button"
              active="true"
              >{{ formerrors.msg }}</vs-alert
            >
          </div>
        </div>
        <div class="popup-footer">
          <vs-button
            color="dark"
            @click="
              edit = false;
              addPopup = false;
              editPetitionConfig=false
              formerrors.msg = '';
            "
            class="cancel"
            type="filled"
            >Cancel</vs-button
          >
          <vs-button
            color="success"
            :disabled="validateForm"
            class="save"
            @click="
              formerrors.msg = '';
              createConfig();
            "
            type="filled"
            >{{editPetitionConfig?'Update':'Save'}}</vs-button
          >
        </div>
      </form>
    </vs-popup>

    <vs-popup
      class="holamundo main-popup"
      :title="
        editNewsubtyp ? 'Edit Case Subtype' : 'New Case Subtype'
      "
      v-if="addNewsubtypPopup"
      :active.sync="addNewsubtypPopup"
    >
      <form>
        <div class="form-container">
          <div class="vx-row">
            <div class="vx-col w-full">
              <div class="form_group"> 
              <label class="form_label">Name<em>*</em></label>
              <vs-input
                v-model="newSubType.name" 
                name="name"
                v-validate="'required'"
                class="w-full" 
                data-vv-as="name"
              />
              <span class="text-danger text-sm" v-show="errors.has('name')">{{
                errors.first("name")
              }}</span>
            </div>
            </div>
          </div>

          <div
            class="text-danger text-sm formerrors"
            v-show="formerrors.msg"
            @click="formerrors.msg = ''"
          >
            <vs-alert
              color="warning"
              class="warning-alert reg-warning-alert no-border-radius"
              icon-pack="IntakePortal"
              icon="IP-information-button"
              active="true"
              >{{ formerrors.msg }}</vs-alert
            >
          </div>
        </div>
        <div class="popup-footer">
          <vs-button
            color="dark"
            @click="
              edit = false;
              createNew(false);
            "
            class="cancel"
            type="filled"
            >Cancel</vs-button
          >
          <vs-button
            color="success"
            :disabled="validatesubTyprForm"
            class="save"
            v-if="editNewsubtyp"
            @click="updatesubType()"
            type="filled"
            >Update</vs-button
          >
          <vs-button
            color="success"
            :disabled="validatesubTyprForm"
            class="save"
            v-else
            @click="createsubtypeAction()"
            type="filled"
            >Save</vs-button
          >
        </div>
      </form>
    </vs-popup>
  </div>
</template>

<script>
import NoDataFound from "@/views/common/noData.vue";
import DateRangePicker from "vue2-daterange-picker";
import Datepicker from "vuejs-datepicker-inv";
import Paginate from "vuejs-paginate";

import "vue2-daterange-picker/dist/vue2-daterange-picker.css";

import _ from "lodash";
import { FormWizard, TabContent } from "vue-form-wizard";
import "vue-form-wizard/dist/vue-form-wizard.min.css";
import PhoneMaskInput from "vue-phone-mask-input";
import { TheMask } from "vue-the-mask";

import FileUpload from "vue-upload-component/src";
import VuePhoneNumberInput from "vue-phone-number-input";
import "vue-phone-number-input/dist/vue-phone-number-input.css";
import { MoreVerticalIcon } from "vue-feather-icons";
export default {
  props:{
    subTypeId:{
      default:''
    },
    caseTypeData:null
  },
  computed: {
    validatesubTyprForm() {
      if (this.newSubType.name && this.newSubType.name.trim() != "") {
        return false;
      } else {
        return true;
      }
    },
    validateForm() {
      //newConfig.questionnaireTplId
      if (
        //(this.newConfig.title && this.newConfig.title.trim() !='' )
        //&& (  _.has(this.newConfig ,"typeId") && this.newConfig['typeId']>0  )

        //_.has(this.newConfig, "questionnaireTplId") &&
        //this.newConfig["questionnaireTplId"] &&

        _.has(this.newConfig, "formsIds") &&
        this.newConfig["formsIds"].length > 0 &&
        _.has(this.newConfig, "letterIds") &&
        this.newConfig["letterIds"].length > 0
      ) {
        return false;
      } else {
        return true;
      }
    },
  },
  components: {
    NoDataFound,
    DateRangePicker,
    VuePhoneNumberInput,
    Datepicker,
    Paginate,
    FileUpload,
    FormWizard,
    TabContent,
    PhoneMaskInput,
    TheMask,
    MoreVerticalIcon,
  },

  data: () => ({
    callFromSerch:false,
    addNewsubtypPopup: false,
    selected_createdDateRange: ["", ""],
    autoApply: "",
    value: [],
    all_formTypes: [
      { name: "Form", id: "Form" },
      { name: "Letter", id: "Letter" },
    ],

    selectedItem: null,
    selectedStatus: 2,
    actionText: "Do you want to Delete?",
    formerrors: {
      msg: "",
    },
    date: null,
    approveConformpopUp: false,

    newConfig: {
      title: null,
      typeId: null,
      subTypeId: null,
      formsIds: [],
      letterIds: [],
      insertTo: false,
      questionnaireTplId: "",
    },
    list: [],
    addPopup: false,
    NewPetition: false,

    searchtxt: "",
    query: [],
    country_code: 231,
    all_statusids: [],
    selected_statusids: [],
    final_selected_statusids: [],
    filter_roleIds: [],
    final_filter_roleIds: [1, 2, 3, 4, 5, 8, 9, 10, 11],

    seleted_states: [],
    final_selected_states: [],
    locations: [],
    // locationIds
    final_selected_typesids: [],
    selected_typeids: [],

    //date: "",
    date_range: [],
    page: 1,
      perPeges: [10,25,50,75,100],
      perpage: 25,
      totalCount:0,
      totalpages: 0,

    switch2: true,
    users_status: {},
    edit: false,
    sortKeys: {},
    sortKey: {},
    details: null,
    petitionTypeId: null,
    formsLettersList: [],
    formsList: [],
    lettersList: [],
    questionnaireTemplates: [],
    newSubType: { name: "" },
    editNewsubtyp: false,
    editPetitionConfig:false,
    code:'',
  }),
  watch: {
    searchtxt: function () {
      this.getList(true);
    },
  },
  methods: {

    openCaseCodePopup(item){
      
        this.$emit('openCaseCodePopup' ,{"typeData":this.caseTypeData,"subTypeData":item})
      },

    gotoMainType(){
      this.$emit("gotoMainType")
    },
    
    getpetitionConfigDetails(item){
      //petition-config/details
      this.selectedItem = item;
      this.code =''
      if(this.checkProperty(this.selectedItem, "petitionConfigDetails") && this.selectedItem["petitionConfigDetails"].length>0 ){
        let postData ={"petitionConfigId":this.selectedItem['petitionConfigDetails'][0]['_id']};
       this.$store
            .dispatch("commonAction", {
              data: postData,
              path: "/petition-config/details",
            })
            .then((response) => {
               
              //newConfig.formsIds newConfig.letterIds Form Letter
              if(this.checkProperty(response ,'formAndLetterDetails') && response['formAndLetterDetails'].length>0 ){
                this.newConfig['formsIds'] = [];
                 this.newConfig['letterIds'] = [];
                _.forEach(response['formAndLetterDetails'] ,(doc)=>{
                  if(_.has(doc ,"type") && doc['type']=="Form"){
                    this.newConfig['formsIds'].push(doc);

                  }
                  if(_.has(doc ,"type") && doc['type']=="Letter"){
                    this.newConfig['letterIds'].push(doc);

                  }

                })
              }
              //questionnaireTplDetails
              if(this.checkProperty(response ,'questionnaireTplDetails' )){
                this.newConfig.questionnaireTplId = response['questionnaireTplDetails'];
              }
              this.newConfig['typeId'] = this.petitionTypeId;
              this.newConfig['subTypeId'] = this.selectedItem['id'];
             // this.showToster({ message: response.message, isError: false });
              //this.getList();
              this.addPopup = true;
              this.editPetitionConfig =true;
            })
            .catch((error) => {
              //alert(JSON.stringify(error));
              Object.assign(this.formerrors, {
                msg: error,
              });
            });
    }
    },
    createNew(action = false) {
      this.formerrors.msg = "";
       Object.assign(this.formerrors, {"msg":''})
      this.addNewsubtypPopup = action;
      this.editNewsubtyp = false;
      this.newSubType = { name: "" };
    },
    editMe(item) {
      this.formerrors.msg = "";
      Object.assign(this.formerrors, {"msg":''})
      this.selectedItem = item;
      this.editNewsubtyp = true;
      this.addNewsubtypPopup = true;
      this.newSubType = {
        name: this.selectedItem["name"],
        id: this.selectedItem["id"],
      };
    },

    createsubtypeAction() {
      this.$validator.validateAll().then((result) => {
        if (result) {
          let postData = {
            name: this.newSubType.name,
            category: "petition_sub_types",
            petitionType: this.petitionTypeId,
          };

          this.$store
            .dispatch("createMasterNewRole", postData)
            .then((response) => {
              this.showToster({ message: response.message, isError: false });
              this.getList();
              this.createNew(false);
            })
            .catch((error) => {
              Object.assign(this.formerrors, {
                msg: error,
              });
              //this.showToster({message:"Somthin went wrong..!",isError:true});
            });
        }
      });
    },
    changeperPage(){
        this.page = 1;
        this.getList(true);
      },
    updatesubType() {
      this.$validator.validateAll().then((result) => {
        if (result) {
          let postData = {
            name: this.newSubType.name,
            category: "petition_sub_types",
            petitionType: this.petitionTypeId,
          };

          postData = Object.assign(postData, {
            mDataId: this.selectedItem["id"],
          });
          this.$store
            .dispatch("updateMasetrRole", postData)
            .then((response) => {
              this.showToster({ message: response.message, isError: false });
              this.getList();
              this.addPopup = false;
              this.edit = false;
              this.editNewsubtyp = false;
              this.addNewsubtypPopup = false;
            })
            .catch((er) => {
              Object.assign(this.formerrors, {
                msg: er,
              });
              //this.showToster({message:"Somthin went wrong..!",isError:true});
            });
        }
      });
    },
    remove(item, data, filindex) {
      data.splice(filindex, 1);
    },
    goTodetails(item) {
      //alert()
      this.$router.push(
        "/petition-config-list/" + this.petitionTypeId + "/" + item["id"]
      );
    },
    getQuestionnaireList() {
      let item = {
        filters: {
          title: "",
          createdDateRange: [],
          statusList: [true],
          activeList: [true],
          configList: [true],
        },
        getMasterData: true,
        page: 1,
        perpage: 100000000000,
        // sorting:this.sortKey,
        //getMasterData:this.getMasterData
      };

      this.$store
        .dispatch("getList", { data: item, path: "/questionnaire/list" })
        .then((response) => {
          //alert(JSON.stringify(response));
          this.questionnaireTemplates = response.list;
        });
    },
    getFormandLetters() {
      let query = {};
      query['getMasterData'] =true;
      query["page"] = 1;
      query["perpage"] = 10000;
      query["filters"] = {
        title: "",
      };
      // query['sorting'] = this.sortKey;
      this.formsList = [];
      this.lettersList = [];

      this.$store
        .dispatch("getList", { data: query, path: "/form-letter/list" })
        .then((response) => {
          this.formsLettersList = response.list;
          _.forEach(this.formsLettersList, (item) => {
            if (item.type == "Form") {
              this.formsList.push(item);
            }
            if (item.type == "Letter") {
              this.lettersList.push(item);
            }
          });
        });
    },
    changedDocType() {
      // alert();
      //formsList , lettersList
    },
    sortMe(sort_key = "") {
      if (sort_key != "") {
        this.sortKeys[sort_key] = this.sortKeys[sort_key] == 1 ? -1 : 1;
        // this.sortKey[sort_key] = this.sortKeys[sort_key]
        this.sortKey = { path: sort_key, order: this.sortKeys[sort_key] };

        localStorage.setItem("formandLetter_sort_key", sort_key);
        localStorage.setItem(
          "formandLetter_sort_value",
          this.sortKey[sort_key]
        );
        this.getList();
      }
    },
    manageFormsletters(item) {
      this.formerrors.msg = "";
      this.selectedItem = item;
      this.newConfig = {
        title: null,
        typeId: parseInt(this.petitionTypeId),
        subTypeId: parseInt(this.selectedItem["id"]),
        formsIds: [],
        letterIds: [],
        insertTo: true,
        questionnaireTplId: item["questionnaireTplId"],
      }
      this.addPopup = true
      this.editPetitionConfig =false;
      this.code ='';
    },

    getList(callFromSerch=false) {
      this.callFromSerch = callFromSerch;
      let item = {
        matcher: {
          searchString: this.searchtxt,
          petitionType: parseInt(this.petitionTypeId),
          getWorkFlowConfig: true,
          getCasenoCodeConfig:false,
        },
        page: this.page,
        perpage: this.perpage,
        category: "petition_sub_types",
        sorting: this.sortKey,
      };
      if(this.callFromSerch){
         
          this.list  =[];
        }


        if([3 ,4].indexOf(this.getUserRoleId)>-1){
          item['matcher']['getWorkFlowConfig'] =false;
           item['matcher']['getCasenoCodeConfig'] =true;

        }

      this.updateLoading(true);
      this.$store.dispatch("getMasterData", item).then((response) => {
        this.list = response.list;
        this.totalCount = this.checkProperty(response, 'totalCount');
        this.totalpages = Math.ceil(response.totalCount / this.perpage);
        this.updateLoading(false);
      }).catch(()=>{
             this.list = [];
             this.updateLoading(false);
          })
    },

    createConfig() {
      // formsIds:[],letterIds:[]

      this.$validator.validateAll().then((result) => {
        if (result) {
          let postData = {
            title: this.newConfig.title,
            typeId: this.newConfig.typeId,
            subTypeId: this.newConfig.subTypeId,
            formAndLetterIds: [],
            
          };
          if((_.has(this.newConfig ,'questionnaireTplId') ) && (_.has(this.newConfig['questionnaireTplId'] ,'_id') ) ){
            postData = Object.assign(postData , {"questionnaireTplId": this.newConfig["questionnaireTplId"]["_id"]});
          }
         
          let formAndLetterIds = [];
          _.forEach(this.newConfig["formsIds"], (item) => {
            formAndLetterIds.push(item._id);
          });
          _.forEach(this.newConfig["letterIds"], (item) => {
            formAndLetterIds.push(item._id);
          });
          let actionPath ='/petition-config/create';
          if(this.editPetitionConfig){
            actionPath = '/petition-config/update'
            if(this.checkProperty(this.selectedItem, "petitionConfigDetails") && this.selectedItem["petitionConfigDetails"].length>0 ){
                
                postData = Object.assign(postData ,{"petitionConfigId":this.selectedItem['petitionConfigDetails'][0]['_id']});
            }
            postData = Object.assign(postData ,{"showPetitionAlert":false});
            if(this.code !='LINKED_WITH_PETITION' ){
              postData = Object.assign(postData ,{"showPetitionAlert":true});
            }
            
          }

          postData.formAndLetterIds = formAndLetterIds;
          this.$store
            .dispatch("commonAction", {
              data: postData,
              path: actionPath,
            })
            .then((response) => {
              this.showToster({ message: response.message, isError: false });
              this.getList();
              this.addPopup = false;
            })
            .catch((error) => {
              //alert(JSON.stringify(error));
              Object.assign(this.formerrors, {
                msg: error,
              });
            });
        }
      });
    },
    upload(files) {
      let model = _.cloneDeep(files);
      this.value = [];
      let fileType = "Form";
      if (_.has(this.newConfig["type"], "name")) {
        if (this.newConfig["type"]["name"] == "Form") {
          fileType = "Form";
        } else if (this.newConfig["type"]["name"] == "Letter") {
          fileType = "Letter";
        }
      }
      this.newConfig["document"] = null;
      this.newConfig["attachments"] = [];

      var _current = this;
      this.$vs.loading();
      let formData = new FormData();

      let tempFiles = [];
      if (model.length > 0) {
        model.forEach((doc) => {
          if (
            (fileType == "Form" && doc.type == "application/pdf") ||
            (fileType == "Letter" && doc.type == "application/msword")
          ) {
            formData.append("files", doc.file);
            formData.append("secureType", "private");
            formData.append("getDetails", true);

            this.$store.dispatch("uploadLocal", formData).then((response) => {
              response.data.result.forEach((urlGenerated) => {
                doc.url = urlGenerated;
                delete doc.file;
                let temp_file = urlGenerated;

                tempFiles.push(temp_file);
                let fl = {
                  name: temp_file["name"],
                  url: temp_file["path"],
                  mimetype: temp_file["mimetype"],
                };
                this.newConfig.document = urlGenerated;
                this.newConfig.attachments.push(fl);

                if (tempFiles.length >= model.length) {
                  _current.$vs.loading.close();
                }
              });
            });
          } else {
            _current.$vs.loading.close();
          }
        });
      }
      //  model.splice(0, mapper.length, ...mapper);
    },

    get_statusids() {
      const item = {
        page: 1,
        perpage: 10000,
        category: "form_letter_status",
      };

      this.$store.dispatch("getMasterData", item).then((response) => {
        this.all_statusids = response.list;
        // alert(JSON.stringify(response.list))
      });
    },

    set_filter: function () {
      this.$refs["filter_menu"].dropdownVisible = false;
      this.final_selected_statusids = [];
      if (this.selected_statusids.length > 0) {
        this.final_selected_statusids = [];
        for (let ind = 0; ind < this.selected_statusids.length; ind++) {
          let current_index = this.selected_statusids[ind];
          this.final_selected_statusids.push(current_index["id"]);
        }
      }

      this.final_selected_typesids = [];
      if (this.selected_typeids.length > 0) {
        this.final_selected_typesids = [];
        for (let ind = 0; ind < this.selected_typeids.length; ind++) {
          let current_index = this.selected_typeids[ind];
          this.final_selected_typesids.push(current_index["id"]);
        }
      }

      // alert(this.final_selected_typesids)

      this.getList(true);
    },
    clear_filter: function () {
       this.searchtxt ='';
      this.$refs["filter_menu"].dropdownVisible = false;
      this.selected_statusids = [];
      this.final_selected_statusids = [];
      this.final_selected_typesids = [];
      this.selected_typeids = [];

      this.date = "";
      this.date_range = [];
      this.selected_createdDateRange["startDate"] = "";
      this.selected_createdDateRange["endDate"] = "";
      this.getList();
    },
    pageNate(pageNum) {
      this.page = pageNum;
      this.getList();
    },
  },
  mounted() {
     this.petitionTypeId = parseInt(this.$route.params.id);
    if(this.subTypeId){
      this.petitionTypeId = parseInt(this.subTypeId);
    }
    this.getFormandLetters();
    this.getQuestionnaireList();
   
    this.selected_statusids = [];
    this.final_selected_statusids = [];
    this.seleted_states = [];
    this.final_selected_states = [];
    (this.sortKeys = {
      name: 1,
      type: 1,
      createdOn: -1,
      updatedOn: 1,
    }),
      (this.sortKey = { path: "createdOn", order: -1 });

    if (
      localStorage.getItem("formandLetter_sort_key") &&
      localStorage.getItem("userrole_sort_value") &&
      localStorage.getItem("userrole_sort_value") >= -1
    ) {
      this.sortKey = {};

      this.sortKey[localStorage.getItem("formandLetter_sort_key")] = parseInt(
        localStorage.getItem("userrole_sort_value")
      );
      this.sortKeys[localStorage.getItem("formandLetter_sort_key")] =
        this.sortKey[localStorage.getItem("formandLetter_sort_key")];

      //alert();
    }
    if (localStorage.getItem("formandLetter_perpage")) {
      this.perpage = parseInt(localStorage.getItem("formandLetter_perpage"));
    }

    this.get_statusids();
    this.getList();
  },
};
</script>
