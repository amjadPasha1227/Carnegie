<template>
<div class="block-layout questionnaire" id="scrollableques" :class="{'padt20':!checkCurrentUrl}">
    <div class="vx-col w-full wizard-container form_section  questionnairesection pad0 case-form-v2">
        <div class="questionnaire_page" id="questionnaire_page" v-if="petition && questionnaireDetails!=null">
            <div class="questionnaire_sec">
                <div class="questionnaire_titles" v-if="petition && questionnaireDetails!=null">
                    <div class="questionnaire_titles_info">
                        <h2  v-if="getCaseName" v-html="getCaseName">
                           
                        </h2>
                        <h2 v-else>
                            Questionnaire for {{petition.typeDetails.name}}
                            <small v-if="petition.subTypeDetails">{{petition.subTypeDetails.name}}</small>

                        </h2>
                        <p>
                            Please take a few moments to complete this short registration form

                          
                        </p>
                        <ul>
                            <template v-for="(item,index) in tabslist">
                                <li :key="index" :class="{'active':currentTab==item.key || (index<=checkActiveTab && currentTab!=item.key)} " @click="setActiveTab(item.key,true)">
                                    <span>{{index+1}}</span><a>{{item.name}}</a>
                                </li>

                            </template>

                        </ul>
                    </div>
                    <figure><img src="@/assets/images/main/content-bottom-image.svg" /></figure>
                </div>
                <div class="questionnaire_form">
                    
                   
                    <div v-if="currentTab=='casedetails'" id="case_details_dt">
                        <form data-vv-scope="casedetailsform" @submit.prevent="" @keydown.enter.prevent="">
                            <vs-col class="w-full p-0">
                                <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal" icon="IP-information-button" active="true">
                                    NOTE: This questionnaire should be filled out completely and
                                    accurately. Kindly read the instructions carefully.
                                </vs-alert>

                            </vs-col>

                            <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="10" vs-sm="12">
                                <div class="form-container pt-10">
                                    <div class="vx-row">


                                      


                                        <genderField :required="true" formScope="casedetailsform" :fieldsArray="questionnaireDetails" :gender="petition.beneficiaryInfo.gender" v-model="petition.beneficiaryInfo.gender" fieldName="gender" />
                                        <div class="divider full-divider mb-10"></div>
                                        
                                        <div class="vx-col w-full">
                                            <vx-input-group class="form-input-group FML">
                                                <immiInput :fieldsArray="questionnaireDetails" cid="benf" formscope="casedetailsform" v-model="petition.beneficiaryInfo.firstName" :required="true" fieldName="first_name" label="First Name" placeHolder="First Name" />
                                                <immiInput :fieldsArray="questionnaireDetails" cid="benm" formscope="casedetailsform" v-model="petition.beneficiaryInfo.middleName" :required="false" fieldName="middle_name" label="Middle Name" placeHolder="Middle Name" />
                                                <immiInput :fieldsArray="questionnaireDetails" cid="benl" formscope="casedetailsform" v-model="petition.beneficiaryInfo.lastName" :required="true" fieldName="last_name" label="Last Name" placeHolder="Last Name" />
                                            </vx-input-group>
                                        </div>

                                        <div class="vx-col w-full mb-10">
                                            <div class="d-flex align-center">
                                                <a class="mr-3">
                                                    Have you used any other names previously?
                                                </a>
                                                <vs-switch v-model="petition.beneficiaryInfo.hasOtherNames" @input="resetOtherNames(petition.beneficiaryInfo.hasOtherNames)">
                                                    <span slot="on">Yes</span>
                                                    <span slot="off">No</span>
                                                </vs-switch>
                                            </div>
                                        </div>

                                        <template v-if="petition.beneficiaryInfo && petition.beneficiaryInfo.hasOtherNames">
                                            <div class="vx-col w-full" v-for="(item, ind) in petition.beneficiaryInfo['otherNames']" :key="ind">
                                                <vx-input-group class="form-input-group delete-rows-cst">
                                                    <immiInput formscope="casedetailsform" :cid="'benf'+ind" v-model="item.firstName" :required="true" fieldName="first_name" label="First Name" placeHolder="First Name" />
                                                    <immiInput formscope="casedetailsform" :cid="'benm'+ind" v-model="item.middleName" :required="false" fieldName="middle_name" label="Middle Name" placeHolder="Middle Name" />
                                                    <immiInput formscope="casedetailsform" :cid="'benl'+ind" v-model="item.lastName" :required="item.firstName!=null && item.firstName!=''" fieldName="last_name" label="Last Name" placeHolder="Last Name" />
                                                    <div class="delete" v-if="ind > 0" @click="removeOtherName(ind)">
                                                        <a>
                                                            <trash-2-icon size="1.5x" name="deletebenflm" class="custom-class"></trash-2-icon>
                                                        </a>
                                                    </div>
                                                </vx-input-group>
                                                <a class="add-more add-more-names" v-if="petition.beneficiaryInfo['otherNames'].length - 1 ==ind" @click="addOtherNames()"><span>+</span>Add</a>
                                            </div>
                                        </template>
                                        
                                        <immiInput :fieldsArray="questionnaireDetails" datatype="email" wrapclass=" " cid="benfemail" formscope="casedetailsform" v-model="petition.beneficiaryInfo.email" :required="true" fieldName="email" label="Email" placeHolder="Email" />
                                        <immiPhone :fieldsArray="questionnaireDetails" @updatephoneCountryCode="updatecellPhoneCountryCode" :countrycode="petition.beneficiaryInfo.cellPhoneCountryCode.countryCode" cid="bencellPhoneNumber" formscope="casedetailsform" v-model="petition.beneficiaryInfo.cellPhoneNumber" :required="true" fieldName="cell_phone_number" label="Phone Number" placeHolder="Phone Number" />
                                        <immiPhone :fieldsArray="questionnaireDetails" @updatephoneCountryCode="updatehomePhoneCountryCode" :countrycode="petition.beneficiaryInfo.homePhoneCountryCode.countryCode" cid="benhomePhoneNumber" formscope="casedetailsform" v-model="petition.beneficiaryInfo.homePhoneNumber" fieldName="home_phone_number" label="Home Phone Number" placeHolder="Home Phone Number" />

                                        <datepickerField :fieldsArray="questionnaireDetails" :dateEnableTo="startEligibleDate" :validationRequired="true" v-model="petition.beneficiaryInfo.dateOfBirth" formscope="casedetailsform" fieldName="dateOfBirth" label="Date of Birth" />
                                        <selectField :fieldsArray="questionnaireDetails" @input="changeBfProvince" :required="true" :optionslist="countries" v-model="petition.beneficiaryInfo.countryOfBirthDetails" formscope="casedetailsform" fieldName="countryOfBirth" label="Country of Birth" placeHolder="Country of Birth" />
                                        <selectField :fieldsArray="questionnaireDetails" @input="petition.beneficiaryInfo.provinceOfBirth = petition.beneficiaryInfo.provinceOfBirthDetails.id" :required="true" :optionslist="bfeprovinceStates" v-model="petition.beneficiaryInfo.provinceOfBirthDetails" formscope="casedetailsform" fieldName="provinceOfBirth" label="Province of Birth" placeHolder="Province of Birth" />
                                        <immiInput :fieldsArray="questionnaireDetails" cid="benflocationOfBirth" formscope="casedetailsform" v-model="petition.beneficiaryInfo.locationOfBirth" :required="true" fieldName="locationOfBirth" label="Location of Birth" placeHolder="Location of Birth" />
                                        <selectField :fieldsArray="questionnaireDetails" @input="petition.beneficiaryInfo.countryOfCitizenship = petition.beneficiaryInfo.countryOfCitizenshipDetails.id" :required="true" :optionslist="countries" v-model="petition.beneficiaryInfo.countryOfCitizenshipDetails" formscope="casedetailsform" fieldName="countryOfCitizenship" label="Country of Citizenship" placeHolder="Country of Citizenship" />

                                        <immiMask :fieldsArray="questionnaireDetails" :patren="['### - ## - ####']" datatype="min:9|max:9" :wrapclass="canRenderField('ben_alienNumber',questionnaireDetails)?'md:w-1/2':' '" cid="benfSSN" formscope="casedetailsform" v-model="petition.beneficiaryInfo.SSN" :required="false" fieldName="SSN" label="Social Security number (if applicable)" vvas="Social Security number" placeHolder="123 - 45 - 6789" />
                                        <immiInput :fieldsArray="questionnaireDetails" datatype="alpha_num|max:9" cid="benfalienNumber" formscope="casedetailsform" v-model="petition.beneficiaryInfo.alienNumber" fieldName="ben_alienNumber" label="Your Alien Number (if applicable)" placeHolder="Alien Number " />


                                            <immiInput :display="true" :fieldsArray="questionnaireDetails"  cid="weight" formscope="casedetailsform" v-model="petition.beneficiaryInfo.weight" :required="true" fieldName="weight" label="Weight" placeHolder="Weight" />
                                            <selectField :display="true" :fieldsArray="questionnaireDetails"  :required="true" :optionslist="races_list" v-model="petition.beneficiaryInfo.race" formscope="casedetailsform" fieldName="race" label="Race" placeHolder="Race" />
                                            <selectField :display="true" :fieldsArray="questionnaireDetails"  :required="true" :optionslist="hair_colorsList" v-model="petition.beneficiaryInfo.hairColor" formscope="casedetailsform" fieldName="hairColor" label="Hair Color" placeHolder="Hair Color" />
                                            <selectField :display="true" :fieldsArray="questionnaireDetails"  :required="true" :optionslist="eye_colorList" v-model="petition.beneficiaryInfo.eyeColor" formscope="casedetailsform" fieldName="eyeColor" label="Eye Color" placeHolder="Eye Color" />
                                           

                                        <selectField :fieldsArray="questionnaireDetails" @input="petition.beneficiaryInfo.maritalStatus = petition.beneficiaryInfo.maritalStatusDetails.id;updateTablist()" :required="true" v-if="marital_statuses.length > 0" :optionslist="marital_statuses" v-model="petition.beneficiaryInfo.maritalStatusDetails" formscope="casedetailsform" fieldName="marital_status" label="Marital Status" placeHolder="Marital Status" />
                                             <!----485 Start-->
                                        <template v-if="checkProperty(petition ,'beneficiaryInfo','maritalStatus')==2 "  >   
                                            <immiInput  :onlyNumbers="true" :allowFloatingPoint="false" :maxLength="2" :display="true" :fieldsArray="questionnaireDetails"  cid="noOfChildrens" formscope="casedetailsform" v-model="petition.beneficiaryInfo.noOfChildrens" :required="true" fieldName="noOfChildrens" label="No of Childrens" placeHolder="No of Childrens" />
                                            <datepickerField  :display="true" :fieldsArray="questionnaireDetails"  :validationRequired="petition.beneficiaryInfo.I94!=null && petition.beneficiaryInfo.I94!=''" v-model="petition.beneficiaryInfo.dateOfMarriage" formscope="casedetailsform" :dateEnableTo="featureDates" fieldName="dateOfMarriage" label="Date of Marriage" />
                                            <selectField   :display="true" :fieldsArray="questionnaireDetails"   @input="changeCountryMarriage" :required="true" :optionslist="countries" v-model="petition.beneficiaryInfo.countryOfMarriageDetails" formscope="casedetailsform" fieldName="countryOfMarriage" label="Country of Marriage" placeHolder="Country of Marriage" />
                                            <selectField  :display="true" :fieldsArray="questionnaireDetails"  @input="petition.beneficiaryInfo.provinceOfMarriage = petition.beneficiaryInfo.provinceOfMarriageDetails.id" :required="true" :optionslist="statesOfMarriage" v-model="petition.beneficiaryInfo.provinceOfMarriageDetails" formscope="casedetailsform" fieldName="provinceOfMarriage" label="Province of Marriage" placeHolder="Province of Marriage" />
                                            <immiInput   :display="true" :fieldsArray="questionnaireDetails"  cid="locationOfMarriage" formscope="casedetailsform" v-model="petition.beneficiaryInfo.locationOfMarriage" :required="true" fieldName="locationOfMarriage" label="Location of Marriage" placeHolder="Location of Marriage" />
                                            <immiyesorno   :display="true" :fieldsArray="questionnaireDetails"  v-model="petition.beneficiaryInfo.doYouHaveMarriageCert" fieldName="doYouHaveMarriageCert" label="Do you have a Marriage Certificate?"></immiyesorno>
                                            
                                            <template v-if="petition.beneficiaryInfo.doYouHaveMarriageCert">
                                                <div class="vx-col w-full padb20" @click="value = []">
                                                    <div class="form_group file_group">
                                                        <div class="vs-component marb20">
                                                        <label class="form_label">Marriage Certificates<em>*</em></label>
                                                            <div class="relative">
                                                        <file-upload
                                                            v-model="value"
                                                            class="file-upload-input upload_file justify-center"
                                                            accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                                                            :name="'documents'"
                                                            :multiple="true"
                                                            
                                                            :hideSelected="true"
                                                            @input="upload(value)"
                                                            >
                                                            <img
                                                                class="file-icon"
                                                                src="@/assets/images/main/file-upload.svg"
                                                            />
                                                            Upload 
                                                            </file-upload>
                                                            <span  v-if="uploading" class="loader"   ><img src="@/assets/images/main/loader.gif"   /></span>
                                                            </div>
                                                            <input type="hidden" :name="'marriageCertDocs'" v-validate="'required'"  data-vv-as="PERM Documents"  v-model="petition.beneficiaryInfo.marriageCertDocs">
                                                            <span class="text-danger text-sm" v-show="errors.has('casedetailsform.marriageCertDocs')">* Marriage Certificates are required</span>
                                                        
                                                        </div>
                                                        <ul class="uploaded-list note_uploads">
                                                            <template v-for="(item, index) in petition['beneficiaryInfo']['marriageCertDocs']">
                                                            <vs-chip
                                                            @click="remove(item, petition['beneficiaryInfo']['marriageCertDocs'], index)"
                                                                :key="index"
                                                                closable
                                                            >
                                                            {{ item.name }}
                                                            </vs-chip>
                                                            </template>
                                                        </ul>
                                                    </div>
                                                </div>

                                                <immiyesorno  :display="true" :fieldsArray="questionnaireDetails" v-model="petition.beneficiaryInfo.have2AffidavitsAttestingToMarriage" fieldName="have2AffidavitsAttestingToMarriage" label="Do you have Two (2) Affidavits attesting to the Marriage?"></immiyesorno>

                                            </template>
                                            <!-- <selectField :display="true" :fieldsArray="questionnaireDetails"  :required="true" :optionslist="countries" v-model="petition.beneficiaryInfo.nationality" formscope="casedetailsform" fieldName="nationality" label="Nationality" placeHolder="Nationality" /> -->
                                             <immiswitchyesno   wrapclass=" "  :display="true" :fieldsArray="questionnaireDetails" formscope="casedetailsform" cid="nameDiffFromBirthCert"   v-model="petition.beneficiaryInfo.nameDiffFromBirthCert" fieldName="nameDiffFromBirthCert" label="if your name is different from that stated on your birth certificate, have you had it legally changes?"></immiswitchyesno>
                                            
                                            <immiswitchyesno   wrapclass=" " :display="true" :fieldsArray="questionnaireDetails" formscope="casedetailsform" cid="have2AffidavitsOfBirthFamily"  v-model="petition.beneficiaryInfo.have2AffidavitsOfBirthFamily" fieldName="have2AffidavitsOfBirthFamily" label="Do you have Two (2) Affidavits of Birth from family members?"></immiswitchyesno>
                                            <immiswitchyesno   wrapclass=" "  :display="true" :fieldsArray="questionnaireDetails" formscope="casedetailsform" cid="birthCertHaveNamePobDob"  v-model="petition.beneficiaryInfo.birthCertHaveNamePobDob" fieldName="birthCertHaveNamePobDob" label="if your name is different from that stated on your birth certificate, have you had it legally changes?"></immiswitchyesno>
                                            <immiswitchyesno   wrapclass=" " :display="true" :fieldsArray="questionnaireDetails" formscope="casedetailsform" cid="previouslyMarried"  v-model="petition.beneficiaryInfo.previouslyMarried" fieldName="previouslyMarried" label="Were you married previously?"></immiswitchyesno>
                                            
                                           
                                            <previousSpouseForm v-if="checkProperty(petition ,'beneficiaryInfo' ,'previouslyMarried')"  formscope="casedetailsform" v-model="petition.beneficiaryInfo.previousSpouse" :countries="countries" />
                                        </template>  

                                       
                                      
                                       

                                        <selectField :fieldsArray="questionnaireDetails" @input="petition.beneficiaryInfo.education.highestDegree = petition.beneficiaryInfo.education.highestDegreeDetails.id" :required="true" :optionslist="petition.highestDegreeList" v-model="petition.beneficiaryInfo.education.highestDegreeDetails" formscope="casedetailsform" fieldName="highestDegree" label="Highest Degree" />
                                        <immiInput :fieldsArray="questionnaireDetails" cid="benmajorFieldOfStudy" formscope="casedetailsform" v-model="petition.beneficiaryInfo.education.majorFieldOfStudy" :required="true" fieldName="majorFieldOfStudy" label="Major Field of Study" placeHolder="Major Field of Study" />
                                        <div class="vx-col w-full" 
                                        v-if="
                                            canRenderField('passportNumber',questionnaireDetails)
                                            ||  checkProperty(petition,'beneficiaryInfo' ,'passportNumber')
                                            || checkProperty(petition,'beneficiaryInfo' ,'passportExpiryDate')
                                            || checkProperty(petition,'beneficiaryInfo' ,'passportIssuedDate')
                                            || checkProperty(petition,'beneficiaryInfo' ,'curNonImmigrantVisaStatus')
                                            || checkProperty(petition,'beneficiaryInfo' ,'curVisaExpiryDate')
                                            || checkProperty(petition,'beneficiaryInfo' ,'sevisNumber')
                                            || checkProperty(petition,'beneficiaryInfo' ,'eadNumber')
                                            "
                                        >
                                        <div class="vx-col w-full">
                                            <div class="form_group w-full ">
                                                <label class="form_label"><h3 class="small-header">Passport</h3>
                                                <div class="IB_tooltip H1-140">
                                                    <span ><info-icon size="1.5x" class="custom-class"></info-icon ></span>
                                                        <div class="tooltip_cnt">
                                                            <p>Make sure you input the most recent passport information. Also, note that the passport must have more than 6 months validity.</p>
                                                        </div>
                                                </div>
                                            </label>
                                            </div>
                                        </div>
                                        </div>
                                        <immiInput :fieldsArray="questionnaireDetails" datatype="alpha_num|max:15" cid="benfpassportNumber" formscope="casedetailsform" v-model="petition.beneficiaryInfo.passportNumber" :required="true" fieldName="passportNumber" label="Passport Number" placeHolder="Passport Number" />
                                        <datepickerField :fieldsArray="questionnaireDetails" :validationRequired="true" v-model="petition.beneficiaryInfo.passportIssuedDate" formscope="casedetailsform" fieldName="passportIssuedDate" :dateEnableTo="featureDates" label="Passport Issued Date" />
                                        <datepickerField :fieldsArray="questionnaireDetails" :dateEnableFrom="featureDates" :validationRequired="true" v-model="petition.beneficiaryInfo.passportExpiryDate" formscope="casedetailsform" fieldName="passportExpiryDate" label="Passport Expiry Date" />
                                        <selectField :fieldsArray="questionnaireDetails" @input="petition.beneficiaryInfo.curNonImmigrantVisaStatus = petition.beneficiaryInfo.curNonImmigrantVisaStatusDetails.id" :required="petition.beneficiaryInfo.currentlyInUS" :optionslist="petition.visaStatusList" v-model="petition.beneficiaryInfo.curNonImmigrantVisaStatusDetails" formscope="casedetailsform" fieldName="curNonImmigrantVisaStatus" label="Current Non-Immigrant Status" vvas="Nonimmigrant Status" placeholder="Nonimmigrant Status" />
                                       
                                        <selectField  :fieldsArray="questionnaireDetails" @input="petition.beneficiaryInfo.passportIssuedCountry = petition.beneficiaryInfo.passportIssuedCountryDetails.id" :required="true" :optionslist="countries" v-model="petition.beneficiaryInfo.passportIssuedCountryDetails" cid="passportIssuedCountry" formscope="casedetailsform" fieldName="passportIssuedCountry" label="Country of Passport Issued" placeHolder="Country of Passport Issued" />

                                        <datepickerField :fieldsArray="questionnaireDetails" :dateEnableFrom="featureDates" :validationRequired="true" v-model="petition.beneficiaryInfo.curVisaExpiryDate" formscope="casedetailsform" fieldName="curVisaExpiryDate" label="Current Status Expiry Date" />

                                        <immiInput :fieldsArray="questionnaireDetails" datatype="alpha_num|max:15" cid="benfsevisNumber" formscope="casedetailsform" v-model="petition.beneficiaryInfo.sevisNumber" fieldName="sevisNumber" label="SEVIS  Number" placeHolder="SEVIS  Number" />
                                        <immiInput :fieldsArray="questionnaireDetails" datatype="alpha_num|min:9|max:9" cid="benfeadNumber" formscope="casedetailsform" v-model="petition.beneficiaryInfo.eadNumber" fieldName="eadNumber" label="EAD  Number" placeHolder="EAD  Number" />

                                 
                                        
                                        <immiInput :fieldsArray="questionnaireDetails" v-if="!petition.beneficiaryInfo.currentlyInUS" wrapclass=" " cid="benfconsulateNotifyAddress" formscope="casedetailsform" v-model="petition.beneficiaryInfo.consulateNotifyAddress" :required="true" fieldName="consulateNotifyAddress" label="Consulate to Notify upon Approval of your petition (if outside the USA)" vvas="Consulate Details" placeHolder="Consulate to Notify upon Approval of your petition" />

                                        <immiyesorno :fieldsArray="questionnaireDetails" v-model="petition.beneficiaryInfo.hasI140ImmPetitionFiled" fieldName="hasI140ImmPetitionFiled" label="Has an I-140 immigrant petition been filed on your behalf?"></immiyesorno>
                                        <immiuploader :fieldsArray="questionnaireDetails" v-if="petition.beneficiaryInfo.hasI140ImmPetitionFiled" formscope="casedetailsform" :required="petition.beneficiaryInfo.hasI140ImmPetitionFiled" fieldName="docs_i140_approval_notice" v-model="petition.documents.I140ApprovalNotice" label="I-140 Approval Notice, if any" vvas="I-140 Approval Notice"></immiuploader>


                                        <immiyesorno :fieldsArray="questionnaireDetails" @input="sethaveYouEverTravelledToUS"  v-model="petition.beneficiaryInfo.haveYouEverTravelledToUS" fieldName="ben_haveYouEverTravelledToUS" label="Have you ever travelled to the United States?"></immiyesorno>
                                        <template v-if="canRenderField('ben_haveYouEverTravelledToUS', questionnaireDetails)">
                                            <petitionsinformation :fieldsArray="questionnaireDetails" formscope="casedetailsform" v-if="petition.beneficiaryInfo.haveYouEverTravelledToUS"  fieldName="ben_nonImmPetitionsInfo" :petition="petition" v-model="petition.beneficiaryInfo.nonImmPetitionsInfo"></petitionsinformation>
                                        </template>
                                        <template v-else>
                                            <petitionsinformation :fieldsArray="questionnaireDetails" formscope="casedetailsform" v-if="petition && petition.visaStatusList && petition.visaStatusList.length > 0 " fieldName="ben_nonImmPetitionsInfo" :petition="petition" v-model="petition.beneficiaryInfo.nonImmPetitionsInfo"></petitionsinformation>
                                        </template>
                                        <immipriorstay :fieldsArray="questionnaireDetails" formscope="casedetailsform" v-if="petition && petition.visaStatusList && petition.visaStatusList.length > 0" fieldName="priorPeriodOfStayInUS" :petition="petition" v-model="petition.beneficiaryInfo.priorPeriodOfStayInUS"></immipriorstay>
                                        
                                        <template v-if="canRenderField('ben_anyImmPetitionFiled', questionnaireDetails) && petition.beneficiaryInfo.anyImmPetitionFiled">
                                            <div class="vx-col w-full mt-10" >

                                            <h3 class="small-header">Immigrant Petition Information</h3>
                                        </div>
                                            <immiswitchyesno :display="true" wrapclass=" " :fieldsArray="questionnaireDetails" :cid="'ben_anyImmPetitionFiled'" formscope="casedetailsform" v-model="petition.beneficiaryInfo.immPetitionInfo.anyOtherAlienFiled" fieldName="ben_anyOtherAlienFiled" label="Is any other Alien Employment Certification, a.k.a Labor Certification filed on your behalf? " placeHolder="" />
                                           
                                            <template v-if="petition.beneficiaryInfo.immPetitionInfo.anyOtherAlienFiled"> 
                                                <datepickerField wrapclass="md:w-1/2"  :display="true" :fieldsArray="questionnaireDetails" v-model="petition.beneficiaryInfo.immPetitionInfo.filedDate" formscope="casedetailsform" fieldName="filedDate" :dateEnableTo="featureDates" label="Date Filed" />
                                            <immiInput wrapclass="md:w-1/2"  :display="true" :fieldsArray="questionnaireDetails"  cid="benfalienNumber" formscope="casedetailsform" v-model="petition.beneficiaryInfo.immPetitionInfo.employerName" fieldName="ben_employerName" label="Name of the Employer" placeHolder="Name of the Employer" />
                                            <immiswitchyesno :display="true" wrapclass=" " :fieldsArray="questionnaireDetails" :cid="'ben_rirOrRegularProcessing'" formscope="casedetailsform" v-model="petition.beneficiaryInfo.immPetitionInfo.rirOrRegularProcessing" fieldName="ben_rirOrRegularProcessing" label="RIR or Regular Processing" placeHolder="" />

                                            <selectField :display="true"  :fieldsArray="questionnaireDetails" @input="petition.beneficiaryInfo.immPetitionInfo.filedStateId = petition.beneficiaryInfo.immPetitionInfo.filedStateDetails.id"  :optionslist="usastates" v-model="petition.beneficiaryInfo.immPetitionInfo.filedStateDetails" formscope="casedetailsform" fieldName="filedStateId" label="State where it was filed" placeHolder="State where it was filed" />
                                            <immiInput wrapclass="md:w-1/2"  :display="true" :fieldsArray="questionnaireDetails"  cid="applCurStatus" formscope="casedetailsform" v-model="petition.beneficiaryInfo.immPetitionInfo.applCurStatus" fieldName="applCurStatus" label="Current Status of the Application" placeHolder="Current Status of the Application"/>

                                            
                                            
                                            </template>



                                            <immiswitchyesno :display="true" wrapclass=" " :fieldsArray="questionnaireDetails" :cid="'ben_seekingFiledDateforETA750'" formscope="casedetailsform" v-model="petition.beneficiaryInfo.immPetitionInfo.seekingFiledDateforETA750" fieldName="ben_seekingFiledDateforETA750" label="Are you seeking to utilize the filing date from a previously submitted Application for Alien Employment Certification (ETA 750)?" placeHolder="" />
                                            <immiswitchyesno :display="true" wrapclass=" " :fieldsArray="questionnaireDetails" :cid="'ben_anyI140Filed'" formscope="casedetailsform" v-model="petition.beneficiaryInfo.immPetitionInfo.anyI140Filed" fieldName="ben_anyI140Filed" label="Is any I-140 filed on your behalf? " placeHolder="" />

                                            <template v-if="petition.beneficiaryInfo.immPetitionInfo.anyI140Filed"> 

                                            <datepickerField wrapclass="md:w-1/2"  :display="true" :fieldsArray="questionnaireDetails"  v-model="petition.beneficiaryInfo.immPetitionInfo.i140Info.fieldDate" formscope="casedetailsform" fieldName="i140InfofiledDate" :dateEnableTo="featureDates" label="Date Filed" />
                                            <immiInput wrapclass="md:w-1/2"  :display="true" :fieldsArray="questionnaireDetails"  cid="benfalienNumber" formscope="casedetailsform" v-model="petition.beneficiaryInfo.immPetitionInfo.i140Info.employerName" fieldName="i140Info_employerName" label="Name of the Employer" placeHolder="Name of the Employer" />
                                            <datepickerField wrapclass="md:w-1/2"  :display="true" :fieldsArray="questionnaireDetails"  v-model="petition.beneficiaryInfo.immPetitionInfo.i140Info.priorityDate" formscope="casedetailsform" fieldName="i140InfofiledDate" :dateEnableTo="featureDates" label="Priority Date" />
                                            <immiInput wrapclass="md:w-1/2"  :display="true" :fieldsArray="questionnaireDetails"  cid="applCurStatus" formscope="casedetailsform" v-model="petition.beneficiaryInfo.immPetitionInfo.i140Info.currentStatus" fieldName="i140currentStatus" label="Current Status of the I-140" placeHolder="Current Status of the I-140"/>

                                            <immiInput wrapclass="md:w-1/2"  :display="true" :fieldsArray="questionnaireDetails"  cid="applCurStatus" formscope="casedetailsform" v-model="petition.beneficiaryInfo.immPetitionInfo.i140Info.eb2orEb3" fieldName="i140Infoeb2orEb3" label="EB2/EB3" placeHolder="EB2/EB3"/>
                                        </template>
                                        </template>
                                        
                                        <template v-if="gettotalDays > 1095 && canRenderField('ben_confirm_stay_in_us_days', questionnaireDetails)">
                                            <div class="vx-col  w-full rspace-bottom">
                                                <div class="form_group pt-10">
                                                    <label class="form_label">It appears that you have spent {{gettotalDays}} of days in the US in H/L status. Please confirm if this is correct.?
                                                    </label>
                                                    <label class="form_label" for="confirmDaysStayInUS">
                                                        <input name="confirmDaysStayInUS" v-validate="'required'" type="checkbox" v-model="petition.beneficiaryInfo.confirmDaysStayInUS">

                                                        Yes</label>
                                                    <p v-show="errors.has('casedetailsform.confirmDaysStayInUS')" class="text-danger text-sm">Please confirm if this is correct.</p>

                                                </div>

                                                <div class="form_group mb-10">
                                                    <template v-if="gettotalDays > 2185">

                                                        <label class="form_label pb-5 pt-5">Note: Please note that you are allowed a maximum period of 6 years on your H-1B. To receive H-1B approval past 6 years you need to either have an approved I-140 or PERM application pending for more than 364 days. Please confirm if you have the following:</label>

                                                        <immiswitchyesno :display="true" wrapclass=" " :fieldsArray="questionnaireDetails" :cid="'hasApprovedI140'" formscope="casedetailsform" v-model="petition.beneficiaryInfo.hasApprovedI140" fieldName="hasApprovedI140" label="Approved I-140 (from any employer that has not been revoked within 180 days of its approval)" placeHolder="" />

                                                        <immiswitchyesno :display="true" wrapclass=" " :fieldsArray="questionnaireDetails" :cid="'hasPermPendingForMorethan365Days'" formscope="casedetailsform" v-model="petition.beneficiaryInfo.hasPermPendingForMorethan365Days" fieldName="hasPermPendingForMorethan365Days" label="PERM application pending for more than 365 days" placeHolder="" />

                                                    </template>

                                                </div>

                                            </div>

                                        </template>

                                    </div>
                                </div>
                            </vs-col>
                        </form>
                    </div>
                        <!----- (canRenderField('ben_educations', questionnaireDetails) && checkProperty(petition ,'subTypeDetails' ,'id') !=17) -->
                    <div v-if="currentTab=='education' || (  (checkProperty(petition ,'subTypeDetails' ,'id') ==17 && ['education' ,'employment'].indexOf(currentTab)>-1) )" id="education_details">
                        <form data-vv-scope="educationform" @submit.prevent="" @keydown.enter.prevent="">
                            <vs-col class="w-full p-0">
                                <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal" icon="IP-information-button" active="true">
                                    After your 10th Or 12th grade – Starting from the most recent degree first

                                </vs-alert>

                            </vs-col>

                            <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="10" vs-sm="12">
                                <div class="form-container pt-10">
                                    <div class="vx-row">

                                        <immieducations :petition="petition" :countries="countries" :fieldsArray="questionnaireDetails" fieldName="ben_educations" cid="ben_educations" formscope="educationform" v-model="petition.beneficiaryInfo.educations" />

                                    </div>

                                </div>
                            </vs-col>
                             <!----485 Start----->
                             <template>
                                    <div class="divider full-divider mb-0 mt-10"></div>

                                    <vs-col class="w-full p-0">
                                        <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal" icon="IP-information-button" active="true">
                                            Please write the following information about your current and past employment for the past five years in the U.S and aboard starting with your most current Job.
                                        </vs-alert>

                                    </vs-col>
                                
                                    <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="10" vs-sm="12">
                                        <div class="form-container pt-5">
                                            <h3 class="small-header">Employment Details</h3>
                                            <div class="vx-row">
                                                

                                                <immiemployment :petition="petition" :countries="countries" :fieldsArray="questionnaireDetails" fieldName="ben_prevEmploymentInfo" cid="ben_prevEmploymentInfo" formscope="educationform" v-model="petition.beneficiaryInfo.prevEmploymentInfo" />

                                            </div>

                                        </div>
                                    </vs-col>

                                    <div class="divider full-divider mb-0 mt-10"></div>
                                    <vs-col class="w-full p-0">
                                        <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal" icon="IP-information-button" active="true">
                                            Last Employer outside of the United States for more than one year.
                                        </vs-alert>

                                    </vs-col>
                                
                                    <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="10" vs-sm="12">
                                        <div class="form-container pt-5">
                                            <h3 class="small-header">Employment Details</h3>
                                            <div class="vx-row">
                                                

                                                <immiemployment :petition="petition" :countries="countries" :fieldsArray="questionnaireDetails" fieldName="ben_prevEmploymentInfo" cid="ben_prevEmploymentInfo" formscope="educationform" v-model="petition.beneficiaryInfo.prevEmploymentOutsideUS" />

                                            </div>

                                        </div>
                                    </vs-col>
                           </template>
                           <!---485 End ----->

                        </form>
                    </div>

                    <div v-if="currentTab=='employment' && checkProperty(petition ,'subTypeDetails' ,'id') !=17 && canRenderField('ben_prevEmploymentInfo', questionnaireDetails)" id="employment_details">
                        <form data-vv-scope="employmentform" @submit.prevent="" @keydown.enter.prevent="">
                            <vs-col class="w-full p-0">
                                <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal" icon="IP-information-button" active="true">
                                    Provide your current and previous employment details, starting from the most recent first.
                                </vs-alert>

                            </vs-col>
                            <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="10" vs-sm="12" v-if=" false && !checkProperty(petition ,'permId') && checkProperty(petition ,'subTypeDetails' ,'id') ==16 " >
                                <div class="form-container pt-10">
                                    <div class="vx-row">
                                        <h3 class="small-header">Job Details</h3>
                                        <div class="vx-col  w-full"  >
                                            <div class="form-container alt-rows-bg">
                                                <div class="vx-row">
                                                    
                                                    
                                                        <immiInput :display="true" :wrapclass="'vx-col md:w-1/2'" :required="true" :fieldsArray="questionnaireDetails" cid="permjobTitle" formscope="employmentform" v-model="petition['jobDetails']['jobTitle']"  fieldName="jobTitle" label="Job Title" placeHolder="Job Title" :maxLength="25" />
                                                        <immiInput :onlyNumbers="true" :wrapclass="'vx-col md:w-1/2'" :display="true" cid="permhoursPerWeek" :formscope="'employmentform'"  v-model="petition['jobDetails'].hoursPerWeek" :required="true" fieldName="hoursPerWeek" label="Hours per Week" placeHolder="Hours per Week"  :maxLength="3" />
                                                        <immiInput :onlyNumbers="true" :wrapclass="'vx-col md:w-1/2'" :display="true" cid="permwageRate" :formscope="'employmentform'" v-model="petition['jobDetails'].wageRate" :required="true" fieldName="wageRate" label=" Wage Rate" placeHolder="Wage Rate" :maxLength="5" />
                                                        <selectField :listContainsId="false" :wrapclass="'vx-col md:w-1/2'" :display="true" :required="true"  :formscope="'employmentform'" cid="permofferpayFrequency"  :optionslist="payFrequencyList" v-model="petition['jobDetails'].payFrequency"  fieldName="offerpayFrequency" label="Pay Frequency" placeHolder="Pay Frequency"   />  
                                                        <selectField :wrapclass="'md:w-1/2'" :required="true"  cid="socCode"  :formscope="'employmentform'" :optionslist="masterSocList" v-model="petition['jobDetails'].socDetails" @input="updatesocCode"   fieldName="socCod" label="Preferred SOC Code" placeHolder="Preferred SOC Code "   />  
 
                                                            <div class="vx-col  w-full"  >
                                                            <div class="form_group">
                                                            <label class="form_label">Description<em >*</em></label>
                                                            <!-- <vs-textarea name="perm-jobDescription" v-model="petition['jobDetails'].description" v-validate="'required'"  class="w-full" :data-vv-as="'Description'" /> -->
                                                            <ckeditor  name="perm-jobDescription" v-model="petition['jobDetails'].description" v-validate="'required'"  class="w-full" :data-vv-as="'Description'"  :editor="editor" :config="editorConfig"></ckeditor>
                                                            <p v-show="errors.has('employmentform.perm-jobDescription')" class="text-danger text-sm"><em>* </em>Description is required</p>
                                                            </div>
                                                            </div>
                                          
                                                         <br>
                                                        <immiswitchyesno :display="true" :wrapclass="'vx-col md:w-1/2'" :fieldsArray="questionnaireDetails" :cid="'fullTimePosition'" formscope="fullTimePosition" v-model="petition['jobDetails'].fullTimePosition" fieldName="fullTimePosition" label="Is this a full-time position? " placeHolder="" />
                                                        <immiswitchyesno :display="true"  :wrapclass="'vx-col md:w-1/2'" :fieldsArray="questionnaireDetails" :cid="'permanentPosition'" formscope="permanentPosition" v-model="petition['jobDetails'].permanentPosition" fieldName="permanentPosition" label="Is this a permanent position? " placeHolder="" />
                                                        <immiswitchyesno :display="true"  :wrapclass="'vx-col md:w-1/2'" :fieldsArray="questionnaireDetails" :cid="'newPosition'" formscope="newPosition" v-model="petition['jobDetails'].newPosition" fieldName="newPosition" label="Is this a new position? " placeHolder="" />


                                                    

                                                        <div class="vx-col w-full">


                                                        <div >
                                                        <h3 class="small-header">Address</h3>
                                                        <template v-for="(address ,index) in petition.jobDetails['workAddresses']">
                                                        <addressField :key="index" :display="true" :fieldsArray="questionnaireDetails" :disableCountry="petition.beneficiaryInfo.currentlyInUS" formscope="employmentform" :showaptType="true" :addFormContainerCls="false" :validationRequired="true" :countries="countries" v-model="petition.jobDetails['workAddresses'][index]" :cid="'beneficiaryInfoaddress'+index" />
                                                        </template>
                                                        </div>
                                                        </div>


                                                    
                                                </div>
                                            </div>
                                        </div>    

                                    </div>
                                </div>
                            </vs-col>        

                            <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="10" vs-sm="12">
                                <div class="form-container pt-5">
                                    <h3 class="small-header">Employment Details</h3>
                                    <div class="vx-row">

                                        <immiemployment :petition="petition" :countries="countries" :fieldsArray="questionnaireDetails" fieldName="ben_prevEmploymentInfo" cid="ben_prevEmploymentInfo" formscope="employmentform" v-model="petition.beneficiaryInfo.prevEmploymentInfo" />

                                    </div>

                                </div>
                            </vs-col>
                            
                           
                        </form>

                    </div>

                    <div v-if="currentTab=='dependentsinfo' " id="dependentsinfo_details">
                        <form data-vv-scope="dependentsinfoform" @submit.prevent="" @keydown.enter.prevent="">

                            <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="10" vs-sm="12">
                                <div class="form-container pt-10">
                                

                                     <!-------485  spouseSubTabs childSubTabs -->
                                     <template >

                                                <!-------------
                                                spouseSubTabs:[

                                                {  key: "personalInfo", name: "Basic Information" },
                                                {  key: "address", name: "Address" },
                                                {  key: "immigration", name: "Immigration" },
                                                {  key: "assets&financials", name: "Assets & Financials" },
                                                {  key: "education", name: "Education & Employment" },
                                                {  key: "parents", name: "Parents" },
                                                {  key: "documents", name: "Documents" },

                                                ]
                                                --->
                                        <div class="vx-row">
                                            
                                            <immiyesorno @input="spouseH4(true)" :fieldsArray="questionnaireDetails" v-model="petition.dependentsInfo.spouse.adjustmentStatusToPermResidenceI485" fieldName="spouse_h4_required" label="Adjustment of status to Permanent Residency (Form I-485) required for your Spouse?"></immiyesorno>

                                            <template v-if="petition.dependentsInfo && petition.dependentsInfo.spouse && petition.dependentsInfo.spouse.firstName!='' && petition.dependentsInfo.spouse.firstName!=null">
                                            <h3 class="small-header">Spouse Details</h3>
                                            <div class="w-full">

                                                <div class="dependent-block_wrap">

                                                    <template v-for="( item , undex) in spouseSubTabs">
                                                        <div class="dependent-block" >
                                                            <div class="dependent-title" >
                                                                <h3> {{item.name}}   </h3>
                                                                <ul>
                                                                    <li >
                                                                    <a @click="setectDependentsSubTabs(item ,'spouse')" ><img src="@/assets/images/main/edit_icon.svg" />
                                                                    </a>
                                                                    </li>
                                                                </ul>
                                                            </div>

                                                            <div class="dependent_details">
                                                                <ul>
                                                                    <li > Name <span>{{petition.dependentsInfo.spouse | formatFullname}}</span></li>
                                                                    <li v-if="petition.dependentsInfo.spouse.dateOfBirth"> Date of Birth <span>{{petition.dependentsInfo.spouse.dateOfBirth | formatDate}}</span></li>
                                                                    <li v-if="petition.dependentsInfo.spouse.physicalAddress && petition.dependentsInfo.spouse.physicalAddress.countryDetails && petition.dependentsInfo.spouse.physicalAddress.countryDetails.name"> Country <span>{{petition.dependentsInfo.spouse.physicalAddress.countryDetails.name}}</span></li>


                                                                </ul>

                                                        </div>
                                                    </div>

                                                    </template>

                                                </div>

                                            </div>


                                        </template>


                                        </div>
                                        <immiyesorno  @input="childH4()" :fieldsArray="questionnaireDetails" v-model="petition.adjustmentStatusToPermResidenceI485Child" :display="true" fieldName="spouse_h4_required" label="Adjustment of status to Permanent Residency (Form I-485) required for children?"></immiyesorno>

                                        <!-----Children -->
                                        <template v-if="petition.dependentsInfo.childrens && petition.dependentsInfo.childrens.length > 0 && petition.dependentsInfo.childrens[0].firstName!='' && petition.dependentsInfo.childrens[0].firstName!=null">
                                        <template v-for="(children ,index) in petition.dependentsInfo.childrens">


                                            <div class="form-container">
                                                <div class="vx-row">
                                                    <h3 class="small-header">Child {{ index+1| numToText}} Details</h3>
                                                    <ul class="personal-info-card pt-0">
                                                        <li class="dependent-block_wrap" v-for="( item , undex) in childSubTabs" :key="index">
                                                                <div class="dependent-block">
                                                                    <div class="dependent-title">
                                                                    <h3> {{checkProperty(item ,'name')}}  </h3>
                                                                    <ul>
                                                                        <li >
                                                                            <a @click="setectDependentsSubTabs(item ,'child')" ><img src="@/assets/images/main/edit_icon.svg" />
                                                                            </a>
                                                                        </li>
                                                                  </ul>
                                                                
                                                                </div>

                                                                    <div class="dependent_details">
                                                                        <ul>

                                                                             <li> Name <span>  {{children | formatFullname}}</span></li>
                                                                            <li v-if="children.dateOfBirth"> Date of Birth <span>{{children.dateOfBirth | formatDate}}</span></li>
                                                                            <li v-if="children.countryOfBirthDetails"> Country <span>{{children.countryOfBirthDetails.name}}</span></li>
                                                                            
                                                                            
                                                                        </ul>
                                                                    </div>
                                                            </div>
                                                        </li>
                                                        
                                                    </ul>
                                            </div>

                                            </div>
                                            
                                        <div class="divider full-divider mb-0 mt-10"></div>
                                        
                                            
                                        </template>
                                        </template>

                                      <!------------Add Child Button-->
                                
                                        <div class="form-container" v-if="petition.dependentsInfo.childrens.length >= 1  && petition.dependentsInfo.childrens[0].firstName!=''">
                                            <div class="vx-row">
                                                
                                                <ul class="personal-info-card pt-0">
                                               

                                                    <li class="dependent-block_wrap" >
                                                        <div class="dependent-block add-btn-center" >
                                                            <a class="add-more ml-0" @click="childH4(true)" ><span>+</span> Add</a>
                                                        </div>

                                                    </li>
                                                </ul>
                                           </div>

                                        </div>
                                        
                                    
                                </template>  

                                </div>
                            </vs-col>
                        </form>

                    </div>

                    <div v-if="currentTab=='documents'" id="documents_details">
                        <form data-vv-scope="documentsform" @submit.prevent="" @keydown.enter.prevent="">
                            <vs-col class="w-full p-0">
                                <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal" icon="IP-information-button" active="true">
                                    NOTE: This questionnaire should be filled out completely and
                                    accurately. Kindly read the instructions carefully.
                                </vs-alert>

                            </vs-col>

                            <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="10" vs-sm="12">
                                <div class="form-container pt-10">
                                    <div class="vx-row">
                                        <casedocumentslist :docslist="bendocslist" formscope="documentsform" :fieldsArray="questionnaireDetails" v-model="petition.documents"></casedocumentslist>
                                    </div>

                                </div>

                            </vs-col>

                        </form>

                    </div>

                    <!-------------485 Tabs-------------->

                    <div v-if="currentTab=='immigration' " id="immigrationDtails">
                        <form data-vv-scope="immigrationform" @submit.prevent="" @keydown.enter.prevent="">
                            <immigrationForm  v-model="petition.beneficiaryInfo"  :formscope="'immigrationform'" :countries="countries" :fieldsArray="questionnaireDetails" :petition="petition" > </immigrationForm>
                        </form>
                    </div>
                    
                    <div v-if="currentTab=='assets&financials' " id="assetsFinancialsDetails">
                        <form data-vv-scope="assets&financialsform" @submit.prevent="" @keydown.enter.prevent="">
                            <!-----financialForm,
     assestsForm,
     liabilitiesForm,
     publicBenefitsForm,-->
                           
                            <assestsForm  v-model="petition['beneficiaryInfo']['assets']" :assestsList="assestsList"  :formscope="'assets&financialsform'" :countries="countries" :fieldsArray="questionnaireDetails" :petition="petition" />
                            <financialForm  v-model="petition['beneficiaryInfo']['financials']"  :formscope="'assets&financialsform'" :countries="countries" :fieldsArray="questionnaireDetails" :petition="petition" />
                             
                            <liabilitiesForm  v-model="petition['beneficiaryInfo']['liabilitiesDebts']" :liability_list="liability_list" :formscope="'assets&financialsform'" :countries="countries" :fieldsArray="questionnaireDetails" :petition="petition" />
                            <publicBenefitsForm  v-model="petition['beneficiaryInfo']['publicBenefits']" :public_benefits="public_benefits"  :formscope="'assets&financialsform'" :countries="countries" :fieldsArray="questionnaireDetails" :petition="petition" />
                             
                            </form>
                    </div>
                    <div v-if="currentTab=='parents' " id="parentsDetails">
                        <form data-vv-scope="parentsform" @submit.prevent="" @keydown.enter.prevent="">
                           
                            <parentForm  v-model="petition['fatherInfo']"  :parentType="'Father'" :formscope="'parentsform'" :countries="countries" :fieldsArray="questionnaireDetails" :petition="petition" />
                            
                            
                            <div class="divider full-divider mb-10"></div>
                           
                           
                           <parentForm  v-model="petition['motherInfo']"  :parentType="'Mother'" :formscope="'parentsform'" :countries="countries" :fieldsArray="questionnaireDetails" :petition="petition" />
                           
                           </form>
                    </div>
                     <div v-if="currentTab=='address' " id="addressform_details">
                        <form data-vv-scope="addressform" @submit.prevent="" @keydown.enter.prevent="">
                            <addresscomponent v-model="petition['beneficiaryInfo']" :countries="countries" />
                        </form>
                    </div>


                </div>
            </div>
            <div class="questionnaire_footer">
                <div class="d-flex">
                    <vs-button v-if="getIndexOfActivetab!=1" @click="goBack()" class="questionnaire_btn" type="filled">Back</vs-button>
                </div>
                <div class="d-flex">
                    <vs-button @click="saveCase(true);" class="questionnaire_btn" type="filled">Save</vs-button>
                    <vs-button color="success" @click="submitCase();" class="save questionnaire_btn" type="filled">{{actiontype}}</vs-button>

                </div>
            </div>
        </div>

    </div>

    <div class="custom_modal_sec preview_questionarie" :class="{ modalopen: questionnairePreview }">
        <div class="custom_modal_overlay" ></div>

        <div class="custom_modal_cnt">
            <div class="modal_title">
                <h2>Questionnaire Review</h2>
                <span @click="questionnairePreview = false">
                    <x-icon size="1.5x" class="close"></x-icon>
                </span>
            </div>
            <div class="modal_cnt preview_content new_questionnaire_review">
                <VuePerfectScrollbar ref="mainSidebarPs1" :settings="settings">
                    <PetitionDetails v-if="questionnairePreview" :loadedFromPreview="true" />
                </VuePerfectScrollbar>
            </div>
            <div class="questionnaire_footer">
                <div class="d-flex">
                    <vs-button @click="questionnairePreview = false" class="cancel questionnaire_btn" type="filled">Cancel
                    </vs-button>
                    <vs-button @click="saveCase(false,false);" class="save questionnaire_btn" type="filled">Submit
                    </vs-button>
                </div>
            </div>
        </div>
    </div>

    <vs-popup class="holamundo success-popups" title="Your registration is complete." :active.sync="SuccessQuestionnaire">
        <figure>
            <img src="@/assets/images/main/icon-note.svg" alt="login" class="mx-auto" />
        </figure>
        <h2 class="title">Questionnaire submitted successfully!</h2>
        <p v-if="checkProperty(getUserData['tenantDetails']['typeDetails'],'id') == 1">
            It will be reviewed by the petitioner and appropriate actions will be
            taken soon.
        </p>
        <p v-if="checkProperty(getUserData['tenantDetails']['typeDetails'],'id') == 2">
          It will be reviewed by the Admin and appropriate actions will be
          taken soon.
      </p>
    </vs-popup>
    <vs-popup class="holamundo main-popup qcomment" title="Comment" :active.sync="commentPopUp">
        <form data-vv-scope="commentForm">
            <div class="form-container" @click="formerrors.msg = ''">
                <div class="vx-row">
                    <div class="vx-col w-full">
                        <div class="form_group">
                            <label class="form_label">Comments</label>
                            <!-- <vs-textarea data-vv-as="Comments" v-validate="'required'" v-model="comments" name="comments" class="w-full" /> -->
                            <ckeditor data-vv-as="Comments" v-validate="'required'" v-model="comments" name="comments" class="w-full"  :editor="editor" :config="editorConfig"></ckeditor>

                            <span class="text-danger text-sm" v-show="errors.has('commentForm.comments')">{{ errors.first("commentForm.comments") }}</span>
                        </div>
                    </div>
                </div>
                <div class="text-danger text-sm formerrors" v-show="formerrors.msg">
                    <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
                </div>
            </div>
            <div class="popup-footer relative">
                <span class="loader" v-if="submiTing"><img src="@/assets/images/main/loader.gif" /></span>

                <vs-button :disabled="comments == '' || comments.trim() == '' || submiTing" color="success" @click="formSubmitted(false)" class="save" type="filled">Submit</vs-button>
            </div>
        </form>
    </vs-popup>

    <div class="custom_modal_sec documents__modal" v-if="spouseModalForm" :class="{ modalopen: spouseModalForm }">
        <div class="custom_modal_overlay"></div>
        <div class="custom_modal_cnt">
            <div class="modal_title">
                <h2>Spouse Information</h2>
                <span class="close" @click="toggleSpouseForm(false)">
                    <em class="material-icons">close</em>
                </span>
            </div>
            <div class="modal_cnt">
                <VuePerfectScrollbar ref="mainSidebarPs" :settings="settings">
                    <form data-vv-scope="dependentsInfoformmodal">

                        <personalinfo :countries="countries" :races_list:="races_list" :liability_list="liability_list" :eye_colorList="eye_colorList" formscope="dependentsInfoformmodal" :petition="petition" :fieldsArray="questionnaireDetails" v-model="petition.dependentsInfo.spouse"></personalinfo>
                     
                    </form>
                </VuePerfectScrollbar>
            </div>
            <div class="popup-footer relative">
                <vs-button color="dark" :disabled="submiTing" @click="toggleSpouseForm(false)" class="cancel" type="filled">Cancel</vs-button>
                <vs-button color="success" :disabled="submiTing" @click="submitSpouse()" class="save" type="filled">Save
                </vs-button>
            </div>
            <div></div>
        </div>
    </div>

    <div class="custom_modal_sec documents__modal" v-if="childModalForm" :class="{ modalopen: childModalForm }">
        <div class="custom_modal_overlay"></div>
        <div class="custom_modal_cnt">
            <div class="modal_title">
                <h2>Child Information</h2>
                <span class="close" @click="toggleChildForm(false)">
                    <em class="material-icons">close</em>
                </span>
            </div>
            <div class="modal_cnt">
                <VuePerfectScrollbar ref="mainSidebarPschild" :settings="settings">
                    <form data-vv-scope="childInfoformmodal">
                        <childpersonalinfo :countries="countries" formscope="childInfoformmodal" :petition="petition" :fieldsArray="questionnaireDetails" v-model="petition.dependentsInfo.childrens[selectedchild]"></childpersonalinfo>
                      
                    </form>
                </VuePerfectScrollbar>
            </div>
            <div class="popup-footer relative">
                <vs-button color="dark" :disabled="submiTing" @click="toggleChildForm(false)" class="cancel" type="filled">Cancel</vs-button>
                <vs-button color="success" :disabled="submiTing" @click="submitChild()" class="save" type="filled">Save
                </vs-button>
            </div>
            <div></div>
        </div>
    </div>

    <vs-popup class="holamundo main-popup" title="Case Details" :active.sync="showPrefillPopup">
        <div class="form-container">
            <div class="vx-row">
                <div class="vx-col w-full">
                    <p style="line-height: 20px">
                        Do you want to pre-fill the basic information from the previous
                        case details?
                    </p>
                </div>
            </div>
        </div>
        <div class="popup-footer">
            <vs-button color="dark" class="cancel" type="filled" @click="setBasicData();showPrefillPopup = false">Cancel</vs-button>
            <vs-button color="success" class="save" type="filled" @click="
            prefilltheDetails();
            showPrefillPopup = false;
          ">Yes</vs-button>
        </div>
    </vs-popup>

    <!-----485 Spouse Dependant Info-->
   <div class="custom_modal_sec documents__modal" v-if="spouseTabsPopUp" :class="{ modalopen: spouseTabsPopUp }">
        <div class="custom_modal_overlay" ></div>
        <div class="custom_modal_cnt">
            <div class="modal_title">
                <h2>Spouse {{checkProperty(selectedDependentsTab ,'name')}}</h2>
                <span class="close" @click="spouseTabsPopUp =false">
                    <em class="material-icons">close</em>
                </span>
            </div>
            <!-------------
                
                spouseSubTabs:[
            
                {  key: "personalInfo", name: "Basic Information" },
                {  key: "address", name: "Address" },
                {  key: "immigration", name: "Immigration" },
                {  key: "assets&financials", name: "Assets & Financials" },
                {  key: "education", name: "Education & Employment" },
                {  key: "parents", name: "Parents" },
                {  key: "documents", name: "Documents" },
                
            ]
            --->
            <div class="modal_cnt">
                <VuePerfectScrollbar ref="mainSidebarPs" :settings="settings">
                    <form data-vv-scope="dependentsInfoformmodal">
                            <form data-vv-scope="spouse_personalInfoForm" v-if="checkProperty(selectedDependentsTab ,'key') =='personalInfo'">
                            <personalinfo  :countries="countries" :races_list:="races_list"  :hair_colorsList="hair_colorsList" :liability_list="liability_list" :eye_colorList="eye_colorList" formscope="spouse_personalInfoForm" :petition="petition" :fieldsArray="questionnaireDetails" v-model="petition.dependentsInfo.spouse"></personalinfo>
                            </form>   
                           <form v-if="checkProperty(selectedDependentsTab ,'key') =='address'" data-vv-scope="spouse_addressForm" @submit.prevent="" @keydown.enter.prevent="">
                                <addresscomponent v-model="petition.dependentsInfo.spouse"  :formscope="'spouse_addressForm'"  :countries="countries" />
                           </form>
                           <form v-if="checkProperty(selectedDependentsTab ,'key') =='immigration'"  data-vv-scope="spouse_immigrationForm" @submit.prevent="" @keydown.enter.prevent="">
                              <immigrationForm  v-model="petition.dependentsInfo.spouse"  :formscope="'spouse_immigrationForm'" :countries="countries" :fieldsArray="questionnaireDetails" :petition="petition" > </immigrationForm>
                           </form>
                            <form v-if="checkProperty(selectedDependentsTab ,'key') =='assets&financials'" data-vv-scope="spouse_assets&financialsForm" @submit.prevent="" @keydown.enter.prevent="">
                                <assestsForm  v-model="petition.dependentsInfo.spouse['assets']" :assestsList="assestsList"  :formscope="'spouse_assets&financialsForm'" :countries="countries" :fieldsArray="questionnaireDetails" :petition="petition" />
                                <financialForm  v-model="petition.dependentsInfo.spouse['financials']"  :formscope="'spouse_assets&financialsForm'" :countries="countries" :fieldsArray="questionnaireDetails" :petition="petition" />
                                
                                <liabilitiesForm  v-model="petition.dependentsInfo.spouse['liabilitiesDebts']" :liability_list="liability_list" :formscope="'spouse_assets&financialsForm'" :countries="countries" :fieldsArray="questionnaireDetails" :petition="petition" />
                                <publicBenefitsForm  v-model="petition.dependentsInfo.spouse['publicBenefits']" :public_benefits="public_benefits"  :formscope="'spouse_assets&financialsForm'" :countries="countries" :fieldsArray="questionnaireDetails" :petition="petition" />
                                
                            </form>

                            <form v-if="checkProperty(selectedDependentsTab ,'key') =='education'"  data-vv-scope="spouse_educationForm" @submit.prevent="" @keydown.enter.prevent="">
                                <vs-col class="w-full p-0">
                                    <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal" icon="IP-information-button" active="true">
                                        After your 10th Or 12th grade – Starting from the most recent degree first

                                    </vs-alert>

                                </vs-col>

                                <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="10" vs-sm="12">
                                    <div class="form-container pt-10">
                                        <div class="vx-row">

                                            <immieducations :petition="petition" :countries="countries" :fieldsArray="questionnaireDetails" fieldName="ben_educations" cid="ben_educations" formscope="spouse_educationForm" v-model="petition.dependentsInfo.spouse.educations" />

                                        </div>

                                    </div>
                                </vs-col>
                                
                                <template>
                                    <div class="divider full-divider mb-0 mt-10"></div>

                                    <vs-col class="w-full p-0">
                                        <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal" icon="IP-information-button" active="true">
                                            Please write the following information about your current and past employment for the past five years in the U.S and aboard starting with your most current Job.
                                        </vs-alert>

                                    </vs-col>
                                
                                    <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="10" vs-sm="12">
                                        <div class="form-container pt-5">
                                            <h3 class="small-header">Employment Details</h3>
                                            <div class="vx-row">
                                                

                                                <immiemployment :petition="petition" :countries="countries" :fieldsArray="questionnaireDetails" fieldName="ben_prevEmploymentInfo" cid="ben_prevEmploymentInfo" formscope="spouse_educationForm" v-model="petition.dependentsInfo.spouse.prevEmploymentInfo" />

                                            </div>

                                        </div>
                                    </vs-col>

                                    <div class="divider full-divider mb-0 mt-10"></div>
                                    <vs-col class="w-full p-0">
                                        <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal" icon="IP-information-button" active="true">
                                            Last Employer outside of the United States for more than one year.
                                        </vs-alert>

                                    </vs-col>
                                
                                    <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="10" vs-sm="12">
                                        <div class="form-container pt-5">
                                            <h3 class="small-header">Employment Details</h3>
                                            <div class="vx-row">
                                                

                                                <immiemployment :petition="petition" :countries="countries" :fieldsArray="questionnaireDetails" fieldName="ben_prevEmploymentInfo" cid="ben_prevEmploymentInfo" formscope="spouse_educationForm" v-model="petition.dependentsInfo.spouse.prevEmploymentOutsideUS" />

                                            </div>

                                        </div>
                                    </vs-col>
                               </template>
                           

                            </form>
                            
                           <vs-col v-if="checkProperty(selectedDependentsTab ,'key') =='documents'" class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12" >
                            <div class="form-container pt-10">
                                <div class="">
                                    <casedocumentslist :docslist="spousedoclist" formscope="documentsform" :fieldsArray="questionnaireDetails" v-model="petition.dependentsInfo.spouse.documents"></casedocumentslist>
                                </div>
                            </div>
                        </vs-col>
                    </form>
                </VuePerfectScrollbar>
            </div>
            <div class="popup-footer relative">
                <vs-button color="dark" :disabled="submiTing" @click="spouseTabsPopUp=false"  class="cancel" type="filled">Cancel</vs-button>
                <vs-button color="success" :disabled="submiTing"  class="save" @click="changeSpouseTab()" type="filled">Save
                </vs-button>
            </div>
            <div></div>
        </div>
    </div>
 <!-----485 Child Dependant Info-->
    <div class="custom_modal_sec documents__modal" v-if="childTabsPopUp" :class="{ modalopen: childTabsPopUp }">
        <div class="custom_modal_overlay" ></div>
        <div class="custom_modal_cnt">
            <div class="modal_title">
                <h2>Child {{checkProperty(selectedDependentsTab ,'name')}}</h2>
                <span class="close" @click="childTabsPopUp =false">
                    <em class="material-icons">close</em>
                </span>
            </div>
            <div class="modal_cnt">

                <VuePerfectScrollbar ref="mainSidebarPs" :settings="settings">
                    <form data-vv-scope="dependentsInfoformmodal">
                            <form data-vv-scope="spouse_personalInfoForm" v-if="checkProperty(selectedDependentsTab ,'key') =='personalInfo'">
                                <personalinfo  :countries="countries" :races_list:="races_list"  :hair_colorsList="hair_colorsList" :liability_list="liability_list" :eye_colorList="eye_colorList" formscope="spouse_personalInfoForm" :petition="petition" :fieldsArray="questionnaireDetails" v-model="petition.dependentsInfo.spouse"></personalinfo>
                            </form>   
                           <form v-if="checkProperty(selectedDependentsTab ,'key') =='address'" data-vv-scope="spouse_addressForm" @submit.prevent="" @keydown.enter.prevent="">
                                <addresscomponent v-model="petition.dependentsInfo.spouse"  :formscope="'spouse_addressForm'"  :countries="countries" />
                           </form>
                           <form v-if="checkProperty(selectedDependentsTab ,'key') =='immigration'"  data-vv-scope="spouse_immigrationForm" @submit.prevent="" @keydown.enter.prevent="">
                              <immigrationForm  v-model="petition.dependentsInfo.spouse"  :formscope="'spouse_immigrationForm'" :countries="countries" :fieldsArray="questionnaireDetails" :petition="petition" > </immigrationForm>
                           </form>
                            <form v-if="checkProperty(selectedDependentsTab ,'key') =='assets&financials'" data-vv-scope="spouse_assets&financialsForm" @submit.prevent="" @keydown.enter.prevent="">
                                <assestsForm  v-model="petition.dependentsInfo.spouse['assets']" :assestsList="assestsList"  :formscope="'spouse_assets&financialsForm'" :countries="countries" :fieldsArray="questionnaireDetails" :petition="petition" />
                                <financialForm  v-model="petition.dependentsInfo.spouse['financials']"  :formscope="'spouse_assets&financialsForm'" :countries="countries" :fieldsArray="questionnaireDetails" :petition="petition" />
                                
                                <liabilitiesForm  v-model="petition.dependentsInfo.spouse['liabilitiesDebts']" :liability_list="liability_list" :formscope="'spouse_assets&financialsForm'" :countries="countries" :fieldsArray="questionnaireDetails" :petition="petition" />
                                <publicBenefitsForm  v-model="petition.dependentsInfo.spouse['publicBenefits']" :public_benefits="public_benefits"  :formscope="'spouse_assets&financialsForm'" :countries="countries" :fieldsArray="questionnaireDetails" :petition="petition" />
                                
                            </form>

                            <form v-if="checkProperty(selectedDependentsTab ,'key') =='education'"  data-vv-scope="spouse_educationForm" @submit.prevent="" @keydown.enter.prevent="">
                                <vs-col class="w-full p-0">
                                    <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal" icon="IP-information-button" active="true">
                                        After your 10th Or 12th grade – Starting from the most recent degree first

                                    </vs-alert>

                                </vs-col>

                                <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="10" vs-sm="12">
                                    <div class="form-container pt-10">
                                        <div class="vx-row">

                                            <immieducations :petition="petition" :countries="countries" :fieldsArray="questionnaireDetails" fieldName="ben_educations" cid="ben_educations" formscope="spouse_educationForm" v-model="petition.dependentsInfo.spouse.educations" />

                                        </div>

                                    </div>
                                </vs-col>
                                
                                <template>
                                    <div class="divider full-divider mb-0 mt-10"></div>

                                    <vs-col class="w-full p-0">
                                        <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal" icon="IP-information-button" active="true">
                                            Please write the following information about your current and past employment for the past five years in the U.S and aboard starting with your most current Job.
                                        </vs-alert>

                                    </vs-col>
                                
                                    <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="10" vs-sm="12">
                                        <div class="form-container pt-5">
                                            <h3 class="small-header">Employment Details</h3>
                                            <div class="vx-row">
                                                

                                                <immiemployment :petition="petition" :countries="countries" :fieldsArray="questionnaireDetails" fieldName="ben_prevEmploymentInfo" cid="ben_prevEmploymentInfo" formscope="spouse_educationForm" v-model="petition.dependentsInfo.spouse.prevEmploymentInfo" />

                                            </div>

                                        </div>
                                    </vs-col>

                                    <div class="divider full-divider mb-0 mt-10"></div>
                                    <vs-col class="w-full p-0">
                                        <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal" icon="IP-information-button" active="true">
                                            Last Employer outside of the United States for more than one year.
                                        </vs-alert>

                                    </vs-col>
                                
                                    <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="10" vs-sm="12">
                                        <div class="form-container pt-5">
                                            <h3 class="small-header">Employment Details</h3>
                                            <div class="vx-row">
                                                

                                                <immiemployment :petition="petition" :countries="countries" :fieldsArray="questionnaireDetails" fieldName="ben_prevEmploymentInfo" cid="ben_prevEmploymentInfo" formscope="spouse_educationForm" v-model="petition.dependentsInfo.spouse.prevEmploymentOutsideUS" />

                                            </div>

                                        </div>
                                    </vs-col>
                               </template>
                           

                            </form>
                            
                           <vs-col v-if="checkProperty(selectedDependentsTab ,'key') =='documents'" class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12" >
                            <div class="form-container pt-10">
                                <div class="">
                                    <casedocumentslist :docslist="spousedoclist" formscope="documentsform" :fieldsArray="questionnaireDetails" v-model="petition.dependentsInfo.spouse.documents"></casedocumentslist>
                                </div>
                            </div>
                        </vs-col>
                    </form>
                </VuePerfectScrollbar>


             
            </div>
            <div class="popup-footer relative">
                <vs-button color="dark" :disabled="submiTing"  class="cancel" type="filled">Cancel</vs-button>
                <vs-button color="success" :disabled="submiTing"  class="save" type="filled">Save
                </vs-button>
            </div>
            <div></div>
        </div>
    </div>

</div>
</template>

<script>
import genderField from './fields/gender.vue'
import immiInput from "@/views/forms/fields/simpleinput.vue";

import {
    Trash2Icon
} from "vue-feather-icons";

import addressField from "@/views/forms/fields/address.vue";
import datepickerField from "@/views/forms/fields/datepicker.vue";
import selectField from "@/views/forms/fields/simpleselect.vue";
import immiPhone from "@/views/forms/fields/phonenumber.vue";
import immiMask from "@/views/forms/fields/maskinput.vue";
import immiyesorno from "@/views/forms/fields/yesorno.vue";
import immiuploader from "@/views/forms/fields/fileupload.vue";
import immipriorstay from "@/views/forms/fields/priorstay.vue";
import immitextarea from "@/views/forms/fields/simpletextarea.vue";
import immieducations from "@/views/forms/fields/educations.vue";
import immiswitchyesno from "@/views/forms/fields/switchyesno.vue";
import Datepicker from "vuejs-datepicker-inv";
import casedocumentslist from "@/views/common/casedocuments.vue";
import immiemployment from "@/views/forms/fields/employment.vue";
import moment from "moment";
import petitionsinformation from "@/views/forms/fields/petitionsinformation.vue";
import personalinfo from "@/views/forms/fields/personalinfogc.vue";
import childpersonalinfo from "@/views/forms/fields/personalinfogc.vue";
import { XIcon } from 'vue-feather-icons'
import JQuery from 'jquery';
import FileUpload from "vue-upload-component/src";
import _ from "lodash";
import PetitionDetails from "@/views/PetitionDetails.vue";
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import Vue from 'vue';
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import immitextfield from "@/views/forms/fields/simpleTextField.vue";

//485 Components

import previousSpouseForm from "@/views/petition/gc/previousSpouseForm.vue";
import immigrationForm from "@/views/petition/gc/immigrationForm.vue";
import financialForm from "@/views/petition/gc/financialForm.vue";
import assestsForm from "@/views/petition/gc/assestsForm.vue";
import liabilitiesForm  from "@/views/petition/gc/liabilitiesForm.vue";
import publicBenefitsForm  from "@/views/petition/gc/publicBenefitsForm.vue";
import addresscomponent  from "@/views/petition/gc/485addressForm.vue";
import parentForm from "@/views/petition/gc/parentForm.vue";


export default {
    props: {

    },
    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
    data() {
        return {
            editor: ClassicEditor,
            editorConfig: {
                toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
            },

            spouseTabsPopUp:false,
            childTabsPopUp:false,
            selectedDependentsType:'',
            selectedDependentsTab:null,
            spouseSubTabs:[
            
                {  key: "personalInfo", name: "Basic Information" },
                {  key: "address", name: "Address" },
                {  key: "immigration", name: "Immigration" },
                {  key: "assets&financials", name: "Assets & Financials" },
                {  key: "education", name: "Education & Employment" },
                //{  key: "parents", name: "Parents" },
                {  key: "documents", name: "Documents" },
                
            ],
            childSubTabs:[
                {  key: "personalInfo", name: "Basic Information" },
                {  key: "address", name: "Address" },
                {  key: "immigration", name: "Immigration" },
                {  key: "assets&financials", name: "Assets & Financials" },
                {  key: "education", name: "Education & Employment" },
                
            ],
            consularProcessingValidator:'',
            public_benefits:[],
            liability_list:[],
            assestsList:[],
            eye_colorList:[],
            hair_colorsList:[],
            races_list:[],
            uploading:false,
            value:[],
            payFrequencyList:[ "Hour","Week","Month","Year" ],
            settings: { 
                swipeEasing: true,
            },
            commentPopUp:false,
            petition: {
                tenantId: null,
                petitionerId: null,
                companyId: null,
                branchId: null,
                workflowId: null,
                customId: '',
                caseNo: '',
                caseNoOld: '',
                caseNoRef: '',
                caseNoSNo: 0,
                allowCustomCaseNo: false,
                caseNumber: null,
                type: null,
                subType: null,
                masterSocList:[], 
               // We need to ask above job details in case we don't have the beneficiary PERM info in our system
                jobDetails: {
                    socCode:'',
                    socDetails:null,
                    

                    jobTitle: '',

                    workAddresses: [
                    {
                            line1: null,
                            line2: null,
                            aptType: null,
                            locationId: null,
                            locationDetails: null,
                            stateId: null,
                            stateDetails: null,
                            countryId: null,
                            countryDetails: null,
                            zipcode: null
                        }
                    ],

                    fullTimePosition: false,

                    hoursPerWeek: '',

                    wageRate: '',

                    payFrequency: 'Month', // Year, Month, Bi-Weekly, Week, Hour

                    description: '',

                    permanentPosition: false,

                    newPosition: false

                },
                beneficiaryInfo: {
                    haveYouEverTravelledToUS:null,
                    currentlyInUS: null,
                    haveOwnershipInterest: null,
                    ownershipInterestDesc: '',
                    consulateInfo: {
                        locationId: null,
                        locationDetails: null,
                        stateId: null,
                        stateDetails: null,
                        countryId: null,
                        countryDetails: null
                    },
                    alienNumber: '',
                    lastArrivalNumber: null,
                    placeOfLastEntryInUS: '',
                    educations: [{
                        _id: 0,
                        name: null,
                        address: {
                            line1: null,
                            line2: null,
                            aptType: null,
                            locationId: null,
                            locationDetails: null,
                            stateId: null,
                            stateDetails: null,
                            countryId: null,
                            countryDetails: null,
                            zipcode: null
                        },
                        highestDegree: null,
                        highestDegreeDetails: null,
                        majorFieldOfStudy: null,
                        attendedFrom: null,
                        attendedTo: null,
                        graduatedYear: null,
                        degreereceived: null,
                        isAccredited: null,
                        isForProfit: null
                    }],
                    nonImmPetitionsInfo: [{
                        _id: 0,
                        visaStatus: null,
                        visaStatusDetails: null,
                        receiptNo: '',
                        petitionerName: ''
                    }],
                    anyImmPetitionFiled: null,
                    immPetitionInfo: {
                        anyOtherAlienFiled: null,
                        filedNumber: null,
                        employerName: '',
                        rirOrRegularProcessing: null,
                        filedStateId: null,
                        filedStateDetails: null,
                        applCurStatus: '',
                        seekingFilednullforETA750: null,
                        anyI140Filed: null,
                        i140Info: {
                            fieldNumber: null,
                            employerName: '',
                            priorityNumber: null,
                            eb2orEb3: '',
                            currentStatus: ''
                        }
                    },
                    prevEmploymentInfo: [{
                        _id: 0,
                        employerName: '',
                        address: {
                            line1: null,
                            line2: null,
                            aptType: null,
                            locationId: null,
                            locationDetails: null,
                            stateId: null,
                            stateDetails: null,
                            countryId: null,
                            countryDetails: null,
                            zipcode: null
                        },
                        businessType: null,
                        jobTitle: null,
                        jobDuties: null,
                        startDate: null,
                        endDate: null,
                        currentEmployer: false
                    }],
                    prevEmploymentOutsideUS: [{
                        _id: 0,
                        employerName: '',
                        address: {
                            line1: null,
                            line2: null,
                            aptType: null,
                            locationId: null,
                            locationDetails: null,
                            stateId: null,
                            stateDetails: null,
                            countryId: null,
                            countryDetails: null,
                            zipcode: null
                        },
                        businessType: null,
                        jobTitle: null,
                        jobDuties: null,
                        startDate: null,
                        endDate: null,
                        currentEmployer: false
                    }],
                    addressOutsideUSMoreThanYear:{
                        line1: null,
                        line2: null,
                        aptType: null,
                        locationId: null,
                        locationDetails: null,
                        stateId: null,
                        stateDetails: null,
                        countryId: null,
                        countryDetails: null,
                        zipcode: null,
                        startDate: null,
                        endDate: null
                    },
                    addressOfLastNYears:[{
                        line1: null,
                        line2: null,
                        aptType: null,
                        locationId: null,
                        locationDetails: null,
                        stateId: null,
                        stateDetails: null,
                        countryId: null,
                        countryDetails: null,
                        zipcode: null,
                        startDate: null,
                        endDate: null
                    }],
                    addressOutsideUS: {
                        line1: null,
                        line2: null,
                        aptType: null,
                        locationId: null,
                        locationDetails: null,
                        stateId: null,
                        stateDetails: null,
                        countryId: null,
                        countryDetails: null,
                        zipcode: null
                    },

                    name: '',
                    firstName: '',
                    middleName: '',
                    lastName: '',
                    hasOtherNames: false,
                    otherNames: [{
                        _id: 0,
                        name: '',
                        firstName: '',
                        middleName: '',
                        lastName: '',
                    }],
                    gender: '',
                    email: '',
                    education: {
                        highestDegree: null,
                        highestDegreeDetails: null,
                        majorFieldOfStudy: ''
                    },
                    maritalStatus: null,
                    // GC 485 fields start
                    noOfChildrens: '',
                    dateOfMarriage: '',
                    countryOfMarriage: '',
                    countryOfMarriageDetails: null,
                    provinceOfMarriage: '',
                    provinceOfMarriageDetails: null,
                    locationOfMarriage: '',
                    doYouHaveMarriageCert: false ,
                    marriageCertDocs: [],
                    have2AffidavitsAttestingToMarriage: false,
                    nameDiffFromBirthCert:false,
                    have2AffidavitsOfBirthFamily:false,
                    birthCertHaveNamePobDob:false,
                    previouslyMarried:false,
                    previousSpouse:{
                        firstName: '',
                        middleName: '',
                        lastName: '',
                        dateOfBirth: null,
                        dateOfMarriage:null,
                        dateOfMarriageEnd:null,

                          //Place of Marriage
                        countryOfMarriage: '',
                        countryOfMarriageDetails: null,
                        provinceOfMarriage: '',
                        provinceOfMarriageDetails: null,
                        locationOfMarriage: '',

                        //Place of Termination
                        countryOfMarriageTermination: '',
                        countryOfMarriageTerminationDetails: null,
                        provinceOfMarriageTermination: '',
                        provinceOfMarriageTerminationDetails: null,
                        locationOfMarriageTermination: '',
                        obtainPermResidenceThroughSpouse:false
                        
                      
                    },
                   
                    // GC 485 fields close
                    dateOfBirth: null,
                    countryOfBirth: null,
                    countryOfBirthDetails: null,
                    provinceOfBirth: null,
                    provinceOfBirthDetails: null,
                    locationOfBirth: null,
                    countryOfCitizenship: null,
                    countryOfCitizenshipDetails: null,
                    I94: null,
                    I94ExpiryDate: null,
                    I94StatusName:'',
                    //GC 485 fields start
                    height: {
                    feet: '',
                    inches: ''
                    },
                    weight: '',
                    race: {
                        id: '',
                        name: ''
                    },
                    eyeColor: {
                        id: '',
                        name: ''
                    },
                    hairColor: {
                        id: '',
                        name: ''
                    },
                    firstArrivalDate: null,
                    lastArrivalDate: null,
                    mannerOfLastArrival:null,

                    reasonOfLastArrival: '',
                    stateOfLastEntryInUS: '',
                    stateDetailsOfLastEntryInUS: null,
                    placeOfLastEntryInUS: '',
                    caseIssuedDate: null,
                    caseExpiryDate: null,
                    placeOfCaseIssued: '',
                    i140PriorityDate:null,
                    classification:'',
                    // GC 485 fields end
                    homePhoneNumber: null,
                    homePhoneCountryCode: {
                        countryCode: '',
                        countryCallingCode: ''
                    },
                    cellPhoneNumber: null,
                    cellPhoneCountryCode: {
                        countryCode: '',
                        countryCallingCode: ''
                    },
                    // GC 485 fields start
                    allIssuedPassportData: [{
                        countryId: '',
                        countryDetails: null,
                        number: '',
                        issuedDate: null,
                        expiryDate: null 
                    }],
                    curVisaExpiryDate:null,
                    dateFromWhichResideInUs:null,
                    inspectedByAnyImmOfficer:false,
                    issuedAnyEADFromUSCIS:false,
                    enterInUSUnderCaseWaiverProgram:false,
                    hasPermResidencyInOtherCountry:false,
                    permResidencyCountryId:'',
                    permResidencyCountryDetails:null,
                    // GC 485 fields end
                    //GC 485 fields start
                    publicBenefits:[],
                    assets: [{ 
                        typeId: '', 
                        typeDetails: null, 
                        nameOfHolder: '', 
                        amount: '' 
                    }],
                    financials: { 
                        deppositsInUSBanks: '', 
                        valueOfRealEstate:'', 
                        caseSurrenderOfLifeInsurance: '', 
                        reasonalValOfPersonalProp: '', 
                        marketValOfStoks: '', 
                        sumOfLifeInsurence: '', 
                        healthInsurancePremium: '', 
                        HealthInsuranceRenewalDate: null, 
                        creditScore: '', 
                        amtOfMortgageOnProperty: '', 
                    }, 
                    liabilitiesDebts: [{ 
                        typeId: '',                    
                        typeDetails: null, 
                        amount: '' 
                    }], 
                    //GC 485 fields ends
                    iAmFromUS: null,
                    mailingAddressIsSameAsAddress:false,
                      mailingAddress: {
                          line1: null,
                          line2: null,
                          aptType: null,
                          locationId: null,
                          locationDetails: null,
                          stateId: null,
                          stateDetails: null,
                          countryId: null,
                          countryDetails: null,
                          zipcode: null
                      },
                      currentAddress:{
                        line1: null,
                        line2: null,
                        aptType: null,
                        locationId: null,
                        locationDetails: null,
                        stateId: null,
                        stateDetails: null,
                        countryId: null,
                        countryDetails: null,
                        zipcode: null
                    },
                    address: {
                        line1: null,
                        line2: null,
                        aptType: null,
                        locationId: null,
                        locationDetails: null,
                        stateId: null,
                        stateDetails: null,
                        countryId: null,
                        countryDetails: null,
                        zipcode: null
                    },
                    consulateNotifyAddress: null,
                    SSN: '',
                    hasI140ImmPetitionFiled: null,
                    I140ImmPetitionFiledDetails: null,
                    passportNumber: null,
                    passportIssuedNumber: null,
                    passportExpiryNumber: null,
                    curNonImmigrantVisaStatus: null,
                    curNonImmigrantVisaStatusDetails: null,
                    curVisaExpiryNumber: null,
                    sevisNumber: null,
                    eadNumber: null,
                    priorPeriodOfStayInUS: [{
                        _id: 0,
                        enteredNumber: null,
                        departedNumber: null,
                        visaStatus: null,
                        visaStatusDetails: null,
                        noOfDays: null,
                        dateerror: false
                    }],
                    noOfDaysStayInUS: null,
                    confirmDaysStayInUS: false,
                    hasApprovedI140: false,
                    hasPermPendingForMorethan365Days: false,

                     //i140
                     passportIssuedCountry:null,
                     passportIssuedCountryDetails:null,
                    immPetitionPriorityDate: null, // list your Priority Date obtained from your previous immigrant petition
                    applyI485AdjOrConsuProcess: true, // Would you like to apply for adjustment of status (I-485) or consular processing? { type: Boolean, default: false },
                    adjustmentOfI485Status: false, //Adjustment of Status (I-485) //{ type: Boolean, default: false },
                    consularProcessing:false,// Consular Processing { type: Boolean, default: false },
                    areYouUnderRemoveOfIndOrUscis: false, // Are you currently under removal proceedings by the INS/USCIS? { type: Boolean, default: false },

                },
                //GC 485 fields starts
                fatherInfo: { 
                    name: '', 
                    firstName: '', 
                    middleName: '', 
                    lastName: '', 
                    hasOtherNames: false, 
                    otherNames: [{ 
                        _id: 0, 
                        name: '', 
                        firstName: '', 
                        middleName: '', 
                        lastName: '', 
                    }], 
                    dateOfBirth: null, 
                    countryOfBirth: '', 
                    countryOfBirthDetails: null, 
                    provinceOfBirth: '', 
                    provinceOfBirthDetails: null, 
                    locationOfBirth: '', 
                    currentAddress: [], 
                    isUSCitizen: false, 
                    dateFromUSCitizen: null
                },
                motherInfo: { 
                    name: '',                    
                    firstName: '', 
                    middleName: '', 
                    lastName: '', 
                    hasOtherNames: false , 
                    otherNames: [{ 
                        _id: 0, 
                        name: '', 
                        firstName: '', 
                        middleName: '', 
                        lastName: '', 
                    }], 
                    dateOfBirth: null, 
                    countryOfBirth: '', 
                    countryOfBirthDetails: null, 
                    provinceOfBirth: '', 
                    provinceOfBirthDetails: null, 
                    locationOfBirth: '', 
                    currentAddress: [],
                    isUSCitizen: false, 
                    dateFromUSCitizen: null 
                },  
                 //GC 485 fields ends
                dependentsInfo: {
                    spouse: {


                        relationship: '',
                        saved: false,
                        currentlyInUS: null,
                        hasOtherNames: false,
                        otherNames: [{
                            _id: 0,
                            name: '',
                            firstName: '',
                            middleName: '',
                            lastName: '',
                        }],
                        passportIssuedNumber: null,
                        alienNumber: '',
                        addressOutsideUS: {
                            line1: null,
                            line2: null,
                            aptType: null,
                            locationId: null,
                            locationDetails: null,
                            stateId: null,
                            stateDetails: null,
                            countryId: null,
                            countryDetails: null,
                            zipcode: null
                        },
                        priorPeriodOfStayInUS: [{
                            _id: 0,
                            enteredNumber: null,
                            departedNumber: null,
                            dateerror: false,
                            noOfDays: null,
                            visaStatus: null
                        }],

                        h4Required: null,
                        h4EADRequired: null,
                        name: '',
                        firstName: '',
                        middleName: '',
                        lastName: '',
                        email: '',
                        phoneNumber: '',
                        phoneCountryCode: {
                            countryCode: '',
                            countryCallingCode: ''
                        },
                        dateOfBirth: null,
                        countryOfBirth: null,
                        countryOfBirthDetails: null,
                        provinceOfBirth: null,
                        provinceOfBirthDetails: null,
                        locationOfBirth: '',
                        locationOfBirthDetails: null,
                        countryOfCitizenship: null,
                        countryOfCitizenshipDetails: null,
                        passportNumber: '',
                        passportExpiryNumber: null,
                        I94: '',
                        I94ExpiryNumber: null,
                        currentStatus: null,
                        currentStatusDetails: null,
                        statusExpiryNumber: null,
                        SSN: '',
                        lastArrivalNumber: null,
                        placeOfLastEntryInUS: '',
                        physicalAddress: {
                            line1: null,
                            line2: null,
                            aptType: null,
                            locationId: null,
                            locationDetails: null,
                            stateId: null,
                            stateDetails: null,
                            countryId: null,
                            countryDetails: null,
                            zipcode: null
                        },
                        documents: {
                            passport: [],
                            visa: [],
                            formI94: [],
                            formI797: [],
                            formI20: [],
                            payStubs: [],
                            marriageCertificate: [],
                            noticeOfApprovalOfH1Status: [],
                            approvalNoticeOfPrevH4: [],
                            other: []
                        },
                        //i140
                        adjustmentOfI485Status: false, //Adjustment of Status (I-485) //{ type: Boolean, default: false },
                        consularProcessing:false,// Consular Processing { type: Boolean, default: false },

                        //485 
                        prevEmploymentInfo: [{
                        _id: 0,
                        employerName: '',
                        address: {
                            line1: null,
                            line2: null,
                            aptType: null,
                            locationId: null,
                            locationDetails: null,
                            stateId: null,
                            stateDetails: null,
                            countryId: null,
                            countryDetails: null,
                            zipcode: null
                        },
                        businessType: null,
                        jobTitle: null,
                        jobDuties: null,
                        startDate: null,
                        endDate: null,
                        currentEmployer: false
                    }],
                    prevEmploymentOutsideUS: [{
                        _id: 0,
                        employerName: '',
                        address: {
                            line1: null,
                            line2: null,
                            aptType: null,
                            locationId: null,
                            locationDetails: null,
                            stateId: null,
                            stateDetails: null,
                            countryId: null,
                            countryDetails: null,
                            zipcode: null
                        },
                        businessType: null,
                        jobTitle: null,
                        jobDuties: null,
                        startDate: null,
                        endDate: null,
                        currentEmployer: false
                    }],
                    prevEmploymentInfo: [{
                        _id: 0,
                        employerName: '',
                        address: {
                            line1: null,
                            line2: null,
                            aptType: null,
                            locationId: null,
                            locationDetails: null,
                            stateId: null,
                            stateDetails: null,
                            countryId: null,
                            countryDetails: null,
                            zipcode: null
                        },
                        businessType: null,
                        jobTitle: null,
                        jobDuties: null,
                        startDate: null,
                        endDate: null,
                        currentEmployer: false
                    }],
                    prevEmploymentOutsideUS: [{
                        _id: 0,
                        employerName: '',
                        address: {
                            line1: null,
                            line2: null,
                            aptType: null,
                            locationId: null,
                            locationDetails: null,
                            stateId: null,
                            stateDetails: null,
                            countryId: null,
                            countryDetails: null,
                            zipcode: null
                        },
                        businessType: null,
                        jobTitle: null,
                        jobDuties: null,
                        startDate: null,
                        endDate: null,
                        currentEmployer: false
                    }],
                    addressOutsideUSMoreThanYear:{
                        line1: null,
                        line2: null,
                        aptType: null,
                        locationId: null,
                        locationDetails: null,
                        stateId: null,
                        stateDetails: null,
                        countryId: null,
                        countryDetails: null,
                        zipcode: null,
                        startDate: null,
                        endDate: null
                    },
                    addressOfLastNYears:[{
                        line1: null,
                        line2: null,
                        aptType: null,
                        locationId: null,
                        locationDetails: null,
                        stateId: null,
                        stateDetails: null,
                        countryId: null,
                        countryDetails: null,
                        zipcode: null,
                        startDate: null,
                        endDate: null
                    }],
                     mailingAddressIsSameAsAddress:false,
                      mailingAddress: {
                          line1: null,
                          line2: null,
                          aptType: null,
                          locationId: null,
                          locationDetails: null,
                          stateId: null,
                          stateDetails: null,
                          countryId: null,
                          countryDetails: null,
                          zipcode: null
                      },
                      currentAddress:{
                        line1: null,
                        line2: null,
                        aptType: null,
                        locationId: null,
                        locationDetails: null,
                        stateId: null,
                        stateDetails: null,
                        countryId: null,
                        countryDetails: null,
                        zipcode: null
                    },
                    address: {
                        line1: null,
                        line2: null,
                        aptType: null,
                        locationId: null,
                        locationDetails: null,
                        stateId: null,
                        stateDetails: null,
                        countryId: null,
                        countryDetails: null,
                        zipcode: null
                    },
                    publicBenefits:[],
                    assets: [{ 
                        typeId: '', 
                        typeDetails: null, 
                        nameOfHolder: '', 
                        amount: '' 
                    }],
                    financials: { 
                        deppositsInUSBanks: '', 
                        valueOfRealEstate:'', 
                        caseSurrenderOfLifeInsurance: '', 
                        reasonalValOfPersonalProp: '', 
                        marketValOfStoks: '', 
                        sumOfLifeInsurence: '', 
                        healthInsurancePremium: '', 
                        HealthInsuranceRenewalDate: null, 
                        creditScore: '', 
                        amtOfMortgageOnProperty: '', 
                    }, 
                    liabilitiesDebts: [{ 
                        typeId: '',                    
                        typeDetails: null, 
                        amount: '' 
                    }],
                    prevEmploymentInfo: [{
                        _id: 0,
                        employerName: '',
                        address: {
                            line1: null,
                            line2: null,
                            aptType: null,
                            locationId: null,
                            locationDetails: null,
                            stateId: null,
                            stateDetails: null,
                            countryId: null,
                            countryDetails: null,
                            zipcode: null
                        },
                        businessType: null,
                        jobTitle: null,
                        jobDuties: null,
                        startDate: null,
                        endDate: null,
                        currentEmployer: false
                    }],
                    prevEmploymentOutsideUS: [{
                        _id: 0,
                        employerName: '',
                        address: {
                            line1: null,
                            line2: null,
                            aptType: null,
                            locationId: null,
                            locationDetails: null,
                            stateId: null,
                            stateDetails: null,
                            countryId: null,
                            countryDetails: null,
                            zipcode: null
                        },
                        businessType: null,
                        jobTitle: null,
                        jobDuties: null,
                        startDate: null,
                        endDate: null,
                        currentEmployer: false
                    }], 
                    educations: [{
                        _id: 0,
                        name: null,
                        address: {
                            line1: null,
                            line2: null,
                            aptType: null,
                            locationId: null,
                            locationDetails: null,
                            stateId: null,
                            stateDetails: null,
                            countryId: null,
                            countryDetails: null,
                            zipcode: null
                        },
                        highestDegree: null,
                        highestDegreeDetails: null,
                        majorFieldOfStudy: null,
                        attendedFrom: null,
                        attendedTo: null,
                        graduatedYear: null,
                        degreereceived: null,
                        isAccredited: null,
                        isForProfit: null
                    }],
                    

                    },
                    childrens: [{
                        saved: false,
                        relationship: '',
                        currentlyInUS: null,
                        hasOtherNames: false,
                        otherNames: [{
                            _id: 0,
                            name: '',
                            firstName: '',
                            middleName: '',
                            lastName: '',
                        }],
                        alienNumber: '',
                        lastArrivalNumber: null,
                        placeOfLastEntryInUS: '',
                        physicalAddress: {
                            line1: null,
                            line2: null,
                            aptType: null,
                            locationId: null,
                            locationDetails: {
                                id: null,
                                name: null,
                                stateId: null,
                                countryId: null
                            },
                            stateId: null,
                            stateDetails: {
                                id: null,
                                name: null,
                                countryId: null
                            },
                            countryId: null,
                            countryDetails: {
                                id: null,
                                name: null,
                                shortName: null,
                                phoneCode: null,
                                countryId: null,
                                currencySymbol: null,
                                currencyCode: null,
                                zipcodeLength: null
                            },
                            zipcode: null
                        },
                        addressOutsideUS: {
                            line1: null,
                            line2: null,
                            aptType: null,
                            locationId: null,
                            locationDetails: {
                                id: null,
                                name: null,
                                stateId: null,
                                countryId: null
                            },
                            stateId: null,
                            stateDetails: {
                                id: null,
                                name: null,
                                countryId: null
                            },
                            countryId: null,
                            countryDetails: {
                                id: null,
                                name: null,
                                shortName: null,
                                phoneCode: null,
                                countryId: null,
                                currencySymbol: null,
                                currencyCode: null,
                                zipcodeLength: null
                            },
                            zipcode: null
                        },
                        passportIssuedNumber: null,
                        priorPeriodOfStayInUS: [{
                            _id: 0,
                            enteredNumber: null,
                            dateerror: false,
                            noOfDays: null,
                            departedNumber: null,
                            visaStatus: null
                        }],

                        h4Required: null,
                        name: '',
                        firstName: '',
                        middleName: '',
                        lastName: '',
                        dateOfBirth: null,
                        countryOfBirth: null,
                        countryOfBirthDetails: null,
                        provinceOfBirth: null,
                        provinceOfBirthDetails: null,
                        locationOfBirth: '',
                        locationOfBirthDetails: null,
                        countryOfCitizenship: null,
                        countryOfCitizenshipDetails: null,
                        passportNumber: '',
                        passportExpiryNumber: null,
                        I94: '',
                        I94ExpiryNumber: null,
                        currentStatus: null,
                        statusExpiryNumber: null,
                        documents: {
                            passport: [],
                            visa: [],
                            formI94: [],
                            birthCertificate: [],
                            approvalNotice: [],
                            approvalNoticeOfPrevH4: [],
                            other: []
                        },

                         //i140
                         adjustmentOfI485Status: false, //Adjustment of Status (I-485) //{ type: Boolean, default: false },
                        consularProcessing:false,// Consular Processing { type: Boolean, default: false },
                    
                    }]
                },
                documents: {
                    resume: [],
                    education: [],
                    expLetters: [],
                    INSNotices: [],
                    I140ApprovalNotice: [],
                    passport: [],
                    passportVisaI94: [],
                    formI20: [],
                    socialSecurityCardAndProfLicense: [],
                    other: [],
                    payStubs: [],
                    offerLetter: [],
                    clientLetter: [],
                    vendorLetter: [],
                    msa: [],
                    po: [],
                    beneficiaryDocs: [],
                    h1bRegSelectionNotice: [],
                    employmentAgreement: [],
                    primeVendor: [],
                    formI94: [],
                    priorFormI797: [],
                    I797NoticeofApprovalforI140: [],
                    ead: [],
                    slgResume: [],
                    slgCollegeDegreesCert: [],
                    slgTransScripts: [],
                    slgExpLetters: [],
                    slgPassportAndVisa: [],
                    slgI94: [],
                    slgPrevNonimmApprovalNotices: [],
                    slgI140OrPermNoties: [],
                    slgPrevLaborApplications: [],
                    slgAckOfPrevLaborApplications: [],
                    slgPaystubs: [],
                    slgI20: [],
                    slgEad: [],

                    // case i140
                    // w2:[],
                    // slgEvalOfEduCredentials:[],
                    // slgPrevImmApprovalNotices:[],
                },
                lcaRequested: false,
                questionnaireFilled: false,
                questionnaireFilled_temp: false,
                lcaId: null,
                statusId: 1,
                status: 1,
                questionnaireSent: true,
                questionnaireInstructions: '',
                assignOrSubmitRoleComment: '',
                curWorkflowActivity: 'CREATE_PETITION',
                nextWorkflowActivity: ['SUBMIT_BY_BENEFICIARY'],
                    //  relationships:[
                    //     {
                    //     "id":"Son",
                    //  "name":"Son"
                    //  },{
                    //     "id":"Daughter",
                    //  "name":"Daughter"
                    //  }
                    //  ]
                     relationships:['Son','Daughter']

            },
            currentTab: 'casedetails',// 'casedetails',
           
            countries: [],
            bfeprovinceStates: [],
            statesOfMarriage:[],
            usastates: [],
            visastatuses: [],
            marital_statuses: [],
            education_types: [],
            questionnaireDetails: null,
            showPrefillPopup: false,
            latestPetition: null,
            featureDates: null,
            tabslist: [{
                    key: "casedetails",
                    name: "Personal Info"
                }

            ],
            questionnairePreview: false,
            SuccessQuestionnaire: false,
            adjustmentStatusToPermResidenceI485Child: false,
            spouseModalForm: false,
            childModalForm: false,
            submiTing: false,
            comments: "",
            formerrors: {
                msg: ""
            },
            startEligibleDate: new Date().setFullYear(new Date().getFullYear() - 18),
            childdoclist: [{
                    required: false,
                    key: 'child_docs_passport',
                    fieldName: 'passport',
                    label: 'Passport- First page with photo, Visa page and last page with address'
                }, {
                    required: false,
                    key: 'child_docs_visa',
                    fieldName: 'visa',
                    label: 'Visa'
                },
                {
                    required: false,
                    key: 'child_docs_form_i94',
                    fieldName: 'formI94',
                    label: 'Form I-94'
                },
                {
                    required: false,
                    key: 'child_docs_approval_notice',
                    fieldName: 'approvalNotice',
                    label: 'Approval Notice'
                },
                {
                    required: false,
                    key: 'child_docs_birth_certificate',
                    fieldName: 'birthCertificate',
                    label: 'Birth Certificate'
                },
                {
                    required: false,
                    key: 'child_docs_other',
                    fieldName: 'other',
                    label: 'Others'
                }
            ],
            selectedchild: 0,
            spousedoclist: [{
                    required: false,
                    key: 'spouse_docs_passport',
                    fieldName: 'passport',
                    label: 'Passport- First page with photo, Visa page and last page with address'
                }, {
                    required: false,
                    key: 'spouse_docs_visa',
                    fieldName: 'visa',
                    label: 'Visa'
                }, {
                    required: false,
                    key: 'spouse_docs_formi94',
                    fieldName: 'formI94',
                    label: 'Form I-94'
                }, {
                    required: false,
                    key: 'spouse_docs_form_i797',
                    fieldName: 'formI797',
                    label: 'Latest I-797, Notice of Approval of the spouse (if spouse is on H-1B or L-1 status)'
                }, {
                    required: false,
                    key: 'spouse_docs_form_i20',
                    fieldName: 'formI20',
                    label: 'Spouse’s all Form I-20s (if spouse is on F-1 status)'
                }, {
                    required: false,
                    key: 'spouse_docs_pay_stubs',
                    fieldName: 'payStubs',
                    label: 'Three Recent Pay Stubs'
                }, {
                    required: false,
                    key: 'spouse_docs_mrg_certificate',
                    fieldName: 'marriageCertificate',
                    label: 'Marriage Certificate (if spouse is on H-1B, L-1, or F-1 status)'
                }, {
                    required: false,
                    key: 'spouse_docs_other',
                    fieldName: 'other',
                    label: 'Others'
                }

            ],
            bendocslist: [{
                    required: false,
                    key: 'docs_passport_visa_i94',
                    fieldName: 'passportVisaI94',
                    label: 'Passport- First page with photo, Visa page and last page with address'
                },
                {
                    key: 'docs_passport',
                    fieldName: 'passport',
                    required: false,
                    label: 'Passport- First page with photo and last page with address'
                },
                {
                    key: 'docs_visa',
                    fieldName: 'visa',
                    required: false,
                    label: 'Visa'
                },
                {
                    key: 'docs_formI94',
                    fieldName: 'formI94',
                    required: false,
                    label: 'Form I-94'
                },
                {
                    key: 'docs_formI797',
                    fieldName: 'formI797',
                    required: false,
                    label: 'Form I-797'
                },
                {
                    key: 'docs_marriageCertificate',
                    fieldName: 'marriageCertificate',
                    required: false,
                    label: 'Marriage Certificate (if spouse is on H-1B, L-1, or F-1 status)'
                },
                {
                    key: 'docs_birthCertificate',
                    fieldName: 'birthCertificate',
                    required: false,
                    label: 'Birth Certificate'
                },
                {
                    key: 'docs_resume',
                    fieldName: 'resume',
                    required: false,
                    label: 'Resume'
                },
                {
                    key: 'docs_education',
                    fieldName: 'education',
                    required: false,
                    label: 'Master’s/ Bachelor’s degree certificate, transcripts, 12th and 10th certificates'
                },
                {
                    key: 'docs_expLetters',
                    fieldName: 'expLetters',
                    required: false,
                    label: 'Experience Letters'
                },
                {
                    key: 'docs_INSNotices',
                    fieldName: 'INSNotices',
                    required: false,
                    label: 'I-797, Notice of Approval granting the current nonimmigrant status (if applicable)'
                },
                {
                    key: 'docs_formI20',
                    fieldName: 'formI20',
                    required: false,
                    label: 'All Form I-20s (if on F-1 or F2 status)'
                },
                {
                    required: false,
                    fieldName: 'socialSecurityCardAndProfLicense',
                    key: 'docs_socialSecurityCardAndProfLicense',
                    label: 'INS Notices'
                },
                {
                    required: false,
                    fieldName: 'I797NoticeofApprovalforI140',
                    key: 'docs_I797NoticeofApprovalforI140',
                    label: 'I-797, Notice of Approval for I-140 if available'
                },
                {
                    required: false,
                    key: 'docs_paystubs',
                    fieldName: 'payStubs',
                    label: 'Three Recent Pay Stubs'
                },
                {
                    required: false,
                    key: 'docs_offer_letters',
                    fieldName: 'offerLetter',
                    label: 'Employment Offer Letter'
                },
                {
                    required: false,
                    key: 'docs_employment_agreement',
                    fieldName: 'employmentAgreement',
                    label: 'Employment Agreement Letter'
                },
                {
                    required: false,
                    key: 'docs_client_letters',
                    fieldName: 'clientLetter',
                    label: 'Client Letter'
                },
                {
                    required: false,
                    key: 'docs_vendor_letters',
                    fieldName: 'vendorLetter',
                    label: 'Vendor Letter'
                },
                {
                    required: false,
                    key: 'docs_msa',
                    fieldName: 'msa',
                    label: 'MSA/Service Agreement and PO/SOW'
                },
                {
                    required: false,
                    key: 'docs_po',
                    fieldName: 'po',
                    label: 'PO'
                },
                {
                    required: false,
                    key: 'docs_approvalNotice',
                    fieldName: 'approvalNotice',
                    label: 'Approval Notice'
                },
                {
                    required: false,
                    key: 'docs_beneficiaryDocs',
                    fieldName: 'beneficiaryDocs',
                    label: 'Beneficiary Documents'
                },
                {
                    required: false,
                    key: 'docs_h1bRegSelectionNotice',
                    fieldName: 'h1bRegSelectionNotice',
                    label: 'H-1B Registration Selection Notice'
                },
                {
                    required: false,
                    key: 'docs_ead',
                    fieldName: 'ead',
                    label: 'EADs (if on OPT or STEM OPT Extension)'
                },
                {
                    required: false,
                    key: 'docs_prime_vendor',
                    fieldName: 'primeVendor',
                    label: 'Prime Vendor Letter'
                },
                {
                    required: false,
                    key: 'docs_formI94',
                    fieldName: 'formI94',
                    label: 'I-94'
                },
                {
                    required: false,
                    key: 'docs_prior_form_i797',
                    fieldName: 'priorFormI797',
                    label: 'All prior I-797, Notice of Approvals granting H-1B status'
                },
                {
                    required: false,
                    key: 'docs_noticeOfApprovalOfH1Status',
                    fieldName: 'noticeOfApprovalOfH1Status',
                    label: 'Spouse’s all Form I-20s (if spouse is on F-1 status)'
                },
                {
                    required: false,
                    key: 'docs_other',
                    fieldName: 'other',
                    label: 'Other Documents, if any'
                },
                {
                    required: true,
                    key: "slgResume",
                    fieldName: 'slgResume',
                    label: "Current Resume- Please mention the accurate names of the employer and periods of employment. Do not state the client names."
                },
                {
                    required: false,
                    key: "slgCollegeDegreesCert",
                    fieldName: 'slgCollegeDegreesCert',
                    label: "All College Degrees."
                },
                {
                    required: false,
                    key: "slgTransScripts",
                    fieldName: 'slgTransScripts',
                    label: "Transcripts/Marks memo’s."
                },
                {
                    required: false,
                    key: "slgExpLetters",
                    fieldName: 'slgExpLetters',
                    label: "Letters of Experience. <span>Each experience letter on company letterhead must document your professional experience and must include the (1) job title (2) duration of employment (beginning date and ending date), (3) full time (i.e., 40 hours) or part time position, and (4) the job duties.  If you had more than one position within the company, please list each position along with the job description.</span>"
                },
                {
                    required: false,
                    key: "slgPassportAndVisa",
                    fieldName: 'slgPassportAndVisa',
                    label: "Copy of New and Old Passport."
                },
                {
                    required: false,
                    key: "slgI94",
                    fieldName: 'slgI94',
                    label: "I-94."
                },
                {
                    required: false,
                    fieldName: 'slgPrevNonimmApprovalNotices',
                    key: "slgPrevNonimmApprovalNotices",
                    label: "Copy of all Previous Nonimmigrant Approval Notices (e.g., H-1B, H-4, L-1A, L-1B, L-2 etc.,)."
                },
                {
                    required: false,
                    key: "slgI140OrPermNoties",
                    fieldName: 'slgI140OrPermNoties',
                    label: "Copy of any I-140 approval notices or PERM filing Notices (if applicable)."
                },
                {
                    required: false,
                    key: "slgPrevLaborApplications",
                    fieldName: 'slgPrevLaborApplications',
                    label: "Copy of the previously filed Labor Application, if applicable."
                },
                {
                    required: false,
                    key: "slgAckOfPrevLaborApplications",
                    fieldName: 'slgAckOfPrevLaborApplications',
                    label: "Copy of the Acknowledgement letter for the previously filed Labor application, if applicable. "
                },
                {
                    required: false,
                    key: "slgPaystubs",
                    fieldName: 'slgPaystubs',
                    label: "Copies of Most recent paystubs (last 2 to 3 months)."
                },
                {
                    required: false,
                    key: "slgI20",
                    fieldName: 'slgI20',
                    label: "Copies of all I-20’s."
                },
                {
                    required: false,
                    key: "slgEad",
                    fieldName: 'slgEad',
                    label: "Copies of EAD cards."
                },
               
                   
                    
            
            ]
        };
    },
    computed: {
        checkActiveTab(){
          return  _.findIndex(this.tabslist ,{"key":this.currentTab});
        },  
        getCaseName(){
            //petition.typeDetails.name
            let s =this.checkProperty(this.petition ,'typeDetails','name');
           if(s){
            s='Questionnaire for '+s;
            if( this.checkProperty(this.petition ,'subTypeDetails','name') ){
                s=s+" <small>"+this.petition.subTypeDetails.name+"</small"
            }
            return s.replace(/(\d)/g, '<span class="number">$1</span>');
        }else{
            return '';
        }

        },
        gettotalDays() {
            var totaldays = 0;
            this.petition.beneficiaryInfo.priorPeriodOfStayInUS.forEach(function (item, index) {
                if (item.noOfDays > 0) {
                    totaldays = totaldays + item.noOfDays;

                }
            })
            return totaldays;
        },
        getIndexOfActivetab() {
            var $self = this;
            return _.findIndex(this.tabslist, (e) => {
                return e.key == $self.currentTab;
            }) + 1;
        },
        actiontype() {
            if (this.getIndexOfActivetab == this.tabslist.length) {
                if (this.petition.questionnaireFilled) {
                    return "Update";
                }
                if (!this.petition.questionnaireFilled) {
                    return "Review & Submit";
                }
                return "Submit";
            }
            return "Next";
        }

    },
    methods: {
        changeSpouseTab(){
           // spouseTabsPopUp:false,
          //  childTabsPopUp:false,
          //  selectedDependentsType:'',

          let scope ='spouse_'+this.checkProperty(this.selectedDependentsTab ,'key')+'Form';
         

          this.$validator.validateAll(scope).then((result) => {
            if(result){
                this.saveCase(true ,true);
            }
           

          })
            

        },
        setectDependentsSubTabs(item,dependentsType=''){
           
            this.spouseTabsPopUp =false;
            this.childTabsPopUp = false;
            if(dependentsType =='spouse'){
                this.spouseTabsPopUp =true;

            }
            if(dependentsType =='child'){
                this.childTabsPopUp = true;
            }
            this.selectedDependentsType = dependentsType;
            this.selectedDependentsTab = item;
          
        },
        prePopLatePublicBenefits(){
            //publicBenefits
           // petition['beneficiaryInfo']['publicBenefits']
            if(this.checkProperty(this.public_benefits ,'length' )>=0 && this.checkProperty( this.petition ,'beneficiaryInfo' ,'publicBenefits') &&this.checkProperty( this.petition['beneficiaryInfo'] ,'publicBenefits' ,'length')>0  ){
             
                _.map(this.public_benefits ,(item)=>{
                    item['isSelected'] =false;
                    if(this.petition['beneficiaryInfo']['publicBenefits'].indexOf(item.id) >=0){
                        item['isSelected'] =true;
                    }

                })
                

            }

        },
        upload(fils,) {
       
       let  model =_.cloneDeep(fils);
       this.value =[];
       var _current = this;
       // this.$vs.loading();
 
       let efiles = [];
       efiles = _.filter(model, (e) => {
         return e.url != null && e.url != "";
       });
       let nfiles = _.filter(model, (e) => {
         return e.url == null || e.url == undefined;
       });
 
       let mapper = nfiles.map(
         (item) =>
           (item = {
             name: item.name,
             file: item.file ? item.file : null,
             url: item.url ? item.url : "",
             path: item.path ? item.path : "",
             status: true,
             mimetype: item.type ? item.type : item.mimetype,
           })  
       );
       let tempFiles = [];
       if (mapper.length > 0) {
         this.uploading = true;
         let count = 0;
         mapper.forEach((doc, index) => {
           let formData = new FormData();
           formData.append("files", doc.file);
           formData.append("secureType", "private");
           formData.append("getDetails", true);
           count++;
 
           this.$store.dispatch("uploadS3File", formData).then((response) => {
             response.data.result.forEach((urlGenerated) => {
               //alert(JSON.stringify(urlGenerated))
               //  this.CommentPayload.documents.push(urlGenerated)
              // if (  _.has(urlGenerated, "name") &&  tempFiles.indexOf(urlGenerated["name"]) <= -1 ) {
                 tempFiles.push(urlGenerated["name"]);
                 this.petition['beneficiaryInfo']['marriageCertDocs'].push(urlGenerated);
            //   }
               doc.url = urlGenerated;
               doc.path = urlGenerated;
               doc["mimetype"] = urlGenerated["mimetype"];
               doc["type"] = urlGenerated["mimetype"];
               delete doc.file;
               mapper[index] = doc;
             });
             if (index >= mapper.length - 1) {
               this.uploading = false;
               // _current.$vs.loading.close();
             }
           });
         });
         if (efiles.length > 0) efiles.push(...mapper);
         //this.CommentPayload["documents"] = efiles
       }
     },
      remove(item, data, filindex) {
       data.splice(filindex, 1);
     },

     changedAdjustmentOfI485Status(val){
          
        if(this.petition.beneficiaryInfo.adjustmentOfI485Status){
            this.petition.beneficiaryInfo.consularProcessing = false;
            
        }
           this.consularProcessingValidator ='';
           this.petition.beneficiaryInfo.applyI485AdjOrConsuProcess =false;

           if(this.petition.beneficiaryInfo.adjustmentOfI485Status || this.petition.beneficiaryInfo.consularProcessing){
               this.consularProcessingValidator ='adjustmentOfI485Status';
               this.petition.beneficiaryInfo.applyI485AdjOrConsuProcess =true;
           }
       
       },
      
       changedConsularProcessing(val){
       
          
          if(this.petition.beneficiaryInfo.consularProcessing){
            this.petition.beneficiaryInfo.adjustmentOfI485Status = false
          }

           this.consularProcessingValidator ='';
          
           if(this.petition.beneficiaryInfo.adjustmentOfI485Status || this.petition.beneficiaryInfo.consularProcessing){
               this.consularProcessingValidator ='consularProcessingValidator';
               this.petition.beneficiaryInfo.applyI485AdjOrConsuProcess =true;
           }

       },
       
        
        updatesocCode(item){ 

        if(_.has( item ,'id')){
            this.petition['jobDetails']['socCode'] = item['id'];
        }
        },
        getMasterSocList(){

            let query = {};
            query["page"] = 1;
            query["perpage"] = 10000;
            query["matcher"] = { 
                // "getInactiveListAlso": true
                };
            query["category"] = "soc_codes";


            this.$store
            .dispatch("getMasterData", query)
            .then((response) => {
                this.masterSocList = response.list;
            


            //alert(this.perpage);
            })
            .catch(() => {
            this.masterSocList = [];

            });

        },
                setSameaddress(){
            setTimeout(()=>{
                if( this.petition.beneficiaryInfo.mailingAddressIsSameAsAddress){
                    this.petition.beneficiaryInfo['currentAddress'] = _.cloneDeep(this.petition.beneficiaryInfo['address']);
                }else{

                    this.petition.beneficiaryInfo['currentAddress'] =  {
                            line1: null,
                            line2: null,
                            aptType: null,
                            locationId: null,
                            locationDetails: null,
                            stateId: null,
                            stateDetails: null,
                            countryId: null,
                            countryDetails: null,
                            zipcode: null
                    }

                }

           });
            

        },
        updatecellPhoneCountryCode(data){
            this.petition.beneficiaryInfo.cellPhoneCountryCode =data;
           
        },
        updatehomePhoneCountryCode(data){
            this.petition.beneficiaryInfo.homePhoneCountryCode =data;
           
        },
        
        sethaveYouEverTravelledToUS(val){
            this.petition.beneficiaryInfo.haveYouEverTravelledToUS = val;
            if(!val){
                this.petition.beneficiaryInfo.nonImmPetitionsInfo = [{
                        _id: 0,
                        visaStatus: null,
                        visaStatusDetails: null,
                        receiptNo: '',
                        petitionerName: ''
                    }]
            }
            
        },
        toggleSpouseForm() {

            if (this.petition.dependentsInfo && this.petition.dependentsInfo.spouse.saved) {

            } else {
                this.petition.dependentsInfo.spouse = {
                    h4Required: false
                }
            }

            this.spouseModalForm = false;

        },
        toggleChildForm() {
            var savedone = false;
            this.petition.dependentsInfo.childrens.forEach((element, index) => {

                if (element.saved) {
                    savedone = true;
                }

            });
            if (!savedone) {
                this.petition.adjustmentStatusToPermResidenceI485Child = false;
                this.petition.dependentsInfo.childrens[0] = {
                    h4Required: false
                }
            }

            this.childModalForm = false;
        },
        editChildren(item, index) {
            this.childModalForm = true;
            this.selectedchild = index;

                     if(item){
                    var childocs = item.documents;
                    if(childocs && childocs.passport == null)  item.documents.passport =[];
                    if(childocs && childocs.visa == null)  item.documents.visa =[];
                    if(childocs && childocs.formI94 == null)  item.documents.formI94 =[];
                    if(childocs && childocs.birthCertificate == null)  item.documents.birthCertificate =[];
                    if(childocs && childocs.approvalNotice == null)  item.documents.approvalNotice =[];
                    if(childocs && childocs.approvalNoticeOfPrevH4 == null)  item.documents.approvalNoticeOfPrevH4 =[];
                    if(childocs && childocs.other == null)  item.documents.other =[];
              }      

           
            this.$validator.reset();
        },
        submitChild() {
            this.$validator.validateAll("childInfoformmodal").then((result) => {
                if (result) {
                    this.petition.dependentsInfo.childrens[this.selectedchild].saved = true;
                    this.petition.dependentsInfo.childrens[this.selectedchild].h4Required = true;

                    var childres = []
                    this.petition.dependentsInfo.childrens.forEach((element, index) => {

                        if (element.saved && element.firstName != '' && element.firstName != null) {
                            childres.push(element)
                        }

                    });
                    this.petition.dependentsInfo.childrens = childres;
                    this.saveCase(true, true)
                } else {

                    var $self = this;
                    const $ = JQuery;
                    var el = _.find(this.errors["items"], function (item) {
                        return item.scope == "childInfoformmodal"
                    })
                    if (el) {
                        const ele = $("[name=" + el.field + "]").parents(".vx-col");
                        var _top = 0;
                        if (ele) {
                            _top = ele.position().top;
                        }
                    }
                    this.$refs["mainSidebarPschild"].scrollTo({
                        top: _top,
                        left: 0,
                        behavior: 'smooth'
                    });

                }
            })

        },
        addchildren() {
            this.petition.adjustmentStatusToPermResidenceI485Child = true;
            this.childH4(true)
        },
        childH4(addmore = false) {

            var _child = this.getChildObject();

            if (addmore) {

                var savedone = false;
                this.petition.dependentsInfo.childrens.forEach((element, index) => {

                    if (element.saved) {
                        savedone = true;
                    }

                });

                if (savedone) {
                    /* If already saved children exists then push new object*/
                    var _childrens = this.petition.dependentsInfo.childrens;
                    _childrens.push(_child);
                    this.petition.dependentsInfo.childrens = _childrens;
                    this.petition.dependentsInfo.childrens[this.petition.dependentsInfo.childrens.length - 1].h4Required = false;
                    
                    this.selectedchild = this.petition.dependentsInfo.childrens.length - 1;


                    this.childModalForm = true;
                } else {
                    var _childrens = [];
                    _childrens.push(_child)
                    this.petition.dependentsInfo.childrens = _childrens;
                    this.childModalForm = true;
                }

            } else {
                if (this.petition.adjustmentStatusToPermResidenceI485Child) {
                    this.addchildren()
                } else {
                    this.childModalForm = false;
                    var _childrens = [];
                    _childrens.push(_child)
                    this.petition.dependentsInfo.childrens = _childrens;
                    this.petition.dependentsInfo.childrens[0].adjustmentStatusToPermResidenceI485 = false;

                }

            }

            if (!this.petition.adjustmentStatusToPermResidenceI485Child) {
                this.petition.dependentsInfo.childrens = []
                this.petition.dependentsInfo.childrens.push(_child)
            }


        },
        spouseH4(from485=false) {
            
            var _spouse = {
                adjustmentStatusToPermResidenceI485:true,
                saved: false,
                relationship: '',
                currentlyInUS: null,
                hasOtherNames: false,
                otherNames: [{
                    _id: 0,
                    name: '',
                    firstName: '',
                    middleName: '',
                    lastName: '',
                }],
                passportIssuedNumber: null,
                alienNumber: '',
                addressOutsideUS: {
                    line1: null,
                    line2: null,
                    aptType: null,
                    locationId: null,
                    locationDetails: null,
                    stateId: null,
                    stateDetails: null,
                    countryId: null,
                    countryDetails: null,
                    zipcode: null
                },
                priorPeriodOfStayInUS: [{
                    _id: 0,
                    enteredNumber: null,
                    departedNumber: null,
                    dateerror: false,
                    noOfDays: null,
                    visaStatus: null
                }],

                h4Required: true,
                h4EADRequired: null,
                name: '',
                firstName: '',
                middleName: '',
                lastName: '',
                email: '',
                phoneNumber: '',
                phoneCountryCode: {
                    countryCode: '',
                    countryCallingCode: ''
                },
                dateOfBirth: null,
                countryOfBirth: null,
                countryOfBirthDetails: null,
                provinceOfBirth: null,
                provinceOfBirthDetails: null,
                locationOfBirth: '',
                locationOfBirthDetails: null,
                countryOfCitizenship: null,
                countryOfCitizenshipDetails: null,
                passportNumber: '',
                passportExpiryNumber: null,
                I94: '',
                I94ExpiryNumber: null,
                currentStatus: null,
                currentStatusDetails: null,
                statusExpiryNumber: null,
                SSN: '',
                lastArrivalNumber: null,
                placeOfLastEntryInUS: '',
                physicalAddress: {
                    line1: null,
                    line2: null,
                    aptType: null,
                    locationId: null,
                    locationDetails: null,
                    stateId: null,
                    stateDetails: null,
                    countryId: null,
                    countryDetails: null,
                    zipcode: null
                },
                documents: {
                    passport: [],
                    visa: [],
                    formI94: [],
                    formI797: [],
                    formI20: [],
                    payStubs: [],
                    marriageCertificate: [],
                    noticeOfApprovalOfH1Status: [],
                    approvalNoticeOfPrevH4: [],
                    other: []
                }
            };
            if (this.petition.dependentsInfo.spouse.adjustmentStatusToPermResidenceI485) {
                this.petition.dependentsInfo.spouse = _spouse;
                if(from485){
                    this.selectedDependentsTab = {  key: 'personalInfo', name: 'Basic Information' } ;
                    this.selectedDependentsType ='child';
                    this.spouseTabsPopUp =true;
                    
                    
                }else{
                    this.spouseModalForm = true;
                }
               

            } else {
                this.spouseModalForm = false;
                this.petition.dependentsInfo.spouse = _spouse;
                this.petition.dependentsInfo.spouse.adjustmentStatusToPermResidenceI485 = false;
                this.spouseTabsPopUp =false;

            }

           

        },
        editSpouse(item) {
              if(item){
                    var childocs = item.documents;
                    if(childocs && childocs.passport == null)  item.documents.passport =[];
                    if(childocs && childocs.visa == null)  item.documents.visa =[];
                    if(childocs && childocs.formI94 == null)  item.documents.formI94 =[];
                    if(childocs && childocs.formI797 == null)  item.documents.formI797 =[];
                    if(childocs && childocs.formI20 == null)  item.documents.formI20 =[];
                    if(childocs && childocs.marriageCertificate == null)  item.documents.marriageCertificate =[];
                    if(childocs && childocs.noticeOfApprovalOfH1Status == null)  item.documents.noticeOfApprovalOfH1Status =[];
                    if(childocs && childocs.approvalNoticeOfPrevH4 == null)  item.documents.approvalNoticeOfPrevH4 =[];
                    if(childocs && childocs.other == null)  item.documents.other =[];

            }      

            this.spouseModalForm = true;
            this.$validator.reset();
        },
        submitSpouse() {
            this.$validator.validateAll("dependentsInfoformmodal").then((result) => {
                if (result) {
                    this.petition.dependentsInfo.spouse.saved = true;
                    this.saveCase(true, true)
                } else {

                    var $self = this;
                    const $ = JQuery;
                    var el = _.find(this.errors["items"], function (item) {
                        return item.scope == "dependentsInfoformmodal"
                    })
                    if (el) {
                        const ele = $("[name=" + el.field + "]").parents(".vx-col");
                        var _top = 0;
                        if (ele) {
                            _top = ele.position().top;
                        }
                    }
                    this.$refs["mainSidebarPs"].scrollTop = _top;

                }
            })

        },
        customvalidations() {
            var valid = true;
            this.petition.beneficiaryInfo.priorPeriodOfStayInUS.forEach((element, index) => {

                if (element.dateerror) {
                    valid = false;
                    return valid;
                }

            });

            return valid;
        },
        submitCase() {

            this.$validator.validateAll(this.currentTab + "form").then((result) => {

                if (result && this.customvalidations()) {
                    if (this.getIndexOfActivetab < this.tabslist.length) {
                        this.setActiveTab(this.tabslist[this.getIndexOfActivetab].key);

                        setTimeout(function () {
                            document.getElementById("scrollableques").scrollTo({
                                top: 0,
                                left: 0,
                                behavior: 'smooth'
                            })
                        }, 500)

                    } else {

                        this.$vs.loading();
                        this.saveCase(true, false)

                    }

                } else {
                    this.validateandScroll();

                }
            })
        },
        saveCase(temp_save, show_message = true) {
            this.$vs.loading();
            this.petition.noOfDaysStayInUS = this.gettotalDays;
         

            var postpetition = {
                submittedWithLink:false,
                petitionId: this.$route.params.itemId,
                userName: this.$store.state.user.name,
                typeName: this.petition.typeDetails.name,
                subTypeName: this.petition.subTypeDetails.name,
                action: temp_save ? "BENEFICIARY_INFO_UPDATE" : "SUBMIT_BY_BENEFICIARY",
                currentDate: moment().format("YYYY-MM-DD"),
                beneficiaryInfo: this.petition.beneficiaryInfo,
                dependentsInfo: this.petition.dependentsInfo,
                documents: this.petition.documents,
                temp_save: temp_save,
                questionnaireFilled: temp_save ? false : true
            };
            if(!this.checkProperty(this.petition ,'permId') && this.checkProperty(this.petition ,'subTypeDetails' ,'id') ==16 && this.checkProperty(this.petition ,'jobDetails') ){
                postpetition = Object.assign(postpetition , { 'jobDetails': this.petition['jobDetails']} );

            }
            if(!this.checkCurrentUrl){
                postpetition['submittedWithLink'] =true;
            }
            this.$store.dispatch("petitioner/petitionupdate", postpetition)
                .then((response) => {

                    if (this.checkProperty(response, "error")) {

                        if (show_message) {

                            this.showToster({
                                message: response.error.message,
                                isError: true,
                            });
                        } else {

                            this.$vs.loading.close();
                        }

                    } else {

                        this.spouseModalForm = false;
                        this.childModalForm = false;
                        if (show_message) {

                            if (!temp_save) {
                                this.SuccessQuestionnaire = true;
                            } else {

                                this.showToster({
                                    message: "Questionnaire saved successfully",
                                    isError: false,
                                });
                            }

                        } else {

                            if (this.petition.questionnaireFilled) {
                                this.showToster({
                                    message: "Questionnaire updated successfully",
                                    isError: false,
                                });

                            } else {

                                if (!temp_save) {
                                    this.questionnairePreview = false;
                                    this.$vs.loading.close();
                                    this.SuccessQuestionnaire = true;
                                    document.addEventListener("click", this.reloadthePage);

                                } else {
                                    this.questionnairePreview = true;
                                    this.$vs.loading.close();
                                }

                            }

                        }
                    }

                    this.$vs.loading.close();

                })

        },
        reloadthePage() {
            let routeTest = this.$route.params.itemId;

            var _self = this;
            if (this.SuccessQuestionnaire) {
                this.SuccessQuestionnaire = false;
            }
            setTimeout(() => {
                let currentRoute = _self.$route;

                if (
                    _.get(currentRoute, "name", "") == "fill-questionnaire" &&
                    _.has(currentRoute, "meta.getTokenFromUrl") &&
                    _.has(currentRoute, "query.token")
                ) {
                    let token = _.get(currentRoute, "query.token", "");
                    let url = "/filled-case-details/" + routeTest + "?token=" + token;
                    //   window.location.href = window.location.origin+'/app'+url
                    _self.$router.push(url);
                } else {
                    if (_self.checkProperty(_self.petition, "rfeCase")) {
                        _self.$router.push("/rfe-petition-details/" + routeTest);
                    } else {
                        _self.$router.push("/petition-details/" + routeTest);
                    }
                }
            }, 10);
        },
        goBack() {
            this.setActiveTab(this.tabslist[this.getIndexOfActivetab - 2].key)

        },
        updateTablist() {
            if (this.petition.beneficiaryInfo && this.petition.beneficiaryInfo.maritalStatusDetails && this.petition.beneficiaryInfo.maritalStatusDetails.id == 2) {

                var index = _.find(this.tabslist, function (item) {

                    return item.key == "dependentsinfo"
                })
                if (index) {

                } else {
                    this.tabslist.push({
                        key: "dependentsinfo",
                        name: "Dependents Info"
                    })
                }

            } else {

                this.tabslist = _.filter(this.tabslist, function (item) {

                    return item.key != "dependentsinfo"
                })
            }

        },
        formatName(item) {

            var _t = '';
            if (item.name != '' && item.name != null) return _t.name;
            if (item.first_name != null && item.first_name != '') _t = item.first_name;
            if (item.middle_name != null && item.middle_name != '') _t + " " + item.middle_name;
            if (item.last_name != null && item.last_name != '') _t + " " + item.last_name;

            return _t;
        },
        validateandScroll() {
            var $self = this;
            const $ = JQuery;
            var el = _.find(this.errors["items"], function (item) {
                return item.scope == $self.currentTab + "form"
            })
            if (el) {
                const ele = $("[name=" + el.field + "]").parents(".vx-col");
                var _top = 0;
                if (ele) {
                    _top = ele.position().top;
                }
            }
            document.getElementById("scrollableques").scrollTo({
                top: _top,
                left: 0,
                behavior: 'smooth'
            })

        },
        setActiveTab(item, validate = false) {
            this.currentTab = item;

            if (validate) {

                this.$validator.validateAll(this.currentTab + "form").then((result) => {

                    if (result) {

                        this.currentTab = item;
                        document.getElementById("scrollableques").scrollTo({
                            top: 0,
                            left: 0,
                            behavior: 'smooth'
                        })
                    } else {

                        this.validateandScroll()

                    }

                })
            } else {
                this.currentTab = item;

                setTimeout(function () {
                    document.getElementById("scrollableques").scrollTo({
                        top: 0,
                        left: 0,
                        behavior: 'smooth'
                    })
                }, 500)

            }

        },
        changeBfProvince(value) {
            this.petition.beneficiaryInfo.countryOfBirth = this.petition.beneficiaryInfo.countryOfBirthDetails.id;
            this.bfeprovinceStates = [];

            this.loadStatesByCountry('bfeprovinceStates', value.id)
        },
        changeCountryMarriage(value){

            this.petition.beneficiaryInfo.countryOfMarriage = this.petition.beneficiaryInfo.countryOfMarriageDetails.id;
            this.statesOfMarriage = [];

            this.loadStatesByCountry('statesOfMarriage', value.id)
        },
        setOutsideAddress() {

            if (this.petition.beneficiaryInfo.currentlyInUS) {
                this.petition.beneficiaryInfo.addressOutsideUS = {
                    line1: null,
                    line2: null,
                    aptType: null,
                    locationId: null,
                    locationDetails: null,
                    stateId: null,
                    stateDetails: null,
                    countryId: null,
                    countryDetails: null,
                    zipcode: null
                };
            } else {

                this.petition.beneficiaryInfo.addressOutsideUS = null;
            }

        },
        addOtherNames() {
            let item = {
                firstName: "",
                middleName: "",
                lastName: ""
            };
            this.petition.beneficiaryInfo["otherNames"].push(item);
        },
        removeOtherName(index) {
            this.petition.beneficiaryInfo["otherNames"].splice(index, 1);
        },
        resetOtherNames($event) {
            this.petition.beneficiaryInfo["otherNames"] = [];
            this.addOtherNames();

        },
        validateScope() {
            this.$validator.validateAll("casedetailsform").then((result) => {

                this.validateandScroll();
            })
        },
        loadStatesByCountry(model, countryId) {

            this.$store.dispatch("getstates", countryId).then((response) => {
                switch (model) {
                    case "bfeprovinceStates":
                        this.bfeprovinceStates = response;
                        break;
                    case "usastates":
                        this.usastates = response;
                    break;
                    case "statesOfMarriage":
                        this.statesOfMarriage = response;
                    break;    
                }

                var provinceOfBirth = this.petition.beneficiaryInfo.provinceOfBirth;
                if (provinceOfBirth != null) {
                    var item = _.find(this.bfeprovinceStates, function (item) {

                        return item.id == provinceOfBirth
                    })
                    if (!item) {
                        this.petition.beneficiaryInfo.provinceOfBirth = null;
                        this.petition.beneficiaryInfo.provinceOfBirthDetails = {};
                    }
                }

            });

        },
        setTheInitData() {
            if (this.petition.beneficiaryInfo.countryOfBirthDetails && this.petition.beneficiaryInfo.countryOfBirth != null) {

                this.loadStatesByCountry('bfeprovinceStates', this.petition.beneficiaryInfo.countryOfBirth)

            }
            let highestDegree = this.petition.beneficiaryInfo.education.highestDegree;
            if (highestDegree != null) {
                this.petition.beneficiaryInfo.education.highestDegreeDetails = _.find(this.petition.highestDegreeList, function (item) {

                    return item.id == highestDegree
                })
            }

            let curNonImmigrantVisaStatus = this.petition.beneficiaryInfo.curNonImmigrantVisaStatus;
            if (curNonImmigrantVisaStatus != null) {
                this.petition.beneficiaryInfo.curNonImmigrantVisaStatusDetails = _.find(this.petition.visaStatusList, function (item) {

                    return item.id == curNonImmigrantVisaStatus
                })
            }

            if (this.petition.beneficiaryInfo.priorPeriodOfStayInUS.length == 1 && this.petition.beneficiaryInfo.priorPeriodOfStayInUS[0].departedDate == null && this.petition.beneficiaryInfo.priorPeriodOfStayInUS[0].enteredDate == null) {

                this.petition.beneficiaryInfo.priorPeriodOfStayInUS = [{
                    _id: 0,
                    enteredNumber: null,
                    departedNumber: null,
                    visaStatus: null,
                    visaStatusDetails: null,
                    noOfDays: null,
                    dateerror: null
                }]
            }

            if (this.petition.beneficiaryInfo && this.petition.beneficiaryInfo.educations == null) {
                this.petition.beneficiaryInfo.educations = [{
                    _id: 0,
                    name: null,
                    address: {
                        line1: null,
                        line2: null,
                        aptType: null,
                        locationId: null,
                        locationDetails: null,
                        stateId: null,
                        stateDetails: null,
                        countryId: null,
                        countryDetails: null,
                        zipcode: null
                    },
                    highestDegree: null,
                    highestDegreeDetails: null,
                    majorFieldOfStudy: null,
                    attendedFrom: null,
                    attendedTo: null,
                    graduatedYear: null,
                    degreereceived: null,
                    isAccredited: null,
                    isForProfit: null
                }]
            }

            if (this.petition.beneficiaryInfo && this.petition.beneficiaryInfo.prevEmploymentInfo == null) {
                this.petition.beneficiaryInfo.prevEmploymentInfo = [{
                    _id: 0,
                    employerName: '',
                    address: {
                        line1: null,
                        line2: null,
                        aptType: null,
                        locationId: null,
                        locationDetails: null,
                        stateId: null,
                        stateDetails: null,
                        countryId: null,
                        countryDetails: null,
                        zipcode: null
                    },
                    businessType: null,
                    jobTitle: null,
                    jobDuties: null,
                    startDate: null,
                    endDate: null,
                    currentEmployer: false
                }]
            }
            if (this.petition.beneficiaryInfo && this.petition.beneficiaryInfo.consulateInfo == null) {

                this.petition.beneficiaryInfo.consulateInfo = {
                    locationId: null,
                    locationDetails: null,
                    stateId: null,
                    stateDetails: null,
                    countryId: null,
                    countryDetails: null
                }

            }

            if (this.canRenderField('ben_educations', this.questionnaireDetails)) {

                var index = _.find(this.tabslist, function (item) {

                    return item.key == "education"
                })
                if (index) {

                } else {
                    this.tabslist.push({
                        key: "education",
                        name: "Educational Info"
                    })
                }

            }
            if (this.canRenderField('ben_prevEmploymentInfo', this.questionnaireDetails)) {

                var employmentTab = _.find(this.tabslist, function (item) {

                    return item.key == "employment"
                })
                if (!employmentTab)  {
                     this.tabslist.push({  key: "employment", name: "Employment Info"  })
                }
              

            }

            var documentsTab = _.find(this.tabslist, function (item) { return item.key == "documents"  })
            if (!documentsTab) {
                this.tabslist.push({ key: "documents", name: "Documents" })

            } 
            if(this.checkProperty(this.petition ,'subTypeDetails' ,'id') ==17){
                this.tabslist = _.filter( this.tabslist , (tab)=>{
                    return tab.key !="employment"
                });  
            }

            //publicBenefits
            // petition['beneficiaryInfo']['publicBenefits']
            if(this.checkProperty( this.petition ,'beneficiaryInfo' ,'publicBenefits') &&this.checkProperty( this.petition['beneficiaryInfo'] ,'publicBenefits' ,'length')>=0  ){
                this.prePopLatePublicBenefits();
            }

            this.updateTablist()
            this.featureDates = new Date();

            if (this.petition.dependentsInfo.childrens && this.petition.dependentsInfo.childrens.length > 0 && this.petition.dependentsInfo.childrens[0].firstName != '' && this.petition.dependentsInfo.childrens[0].firstName != null) {
                this.petition.adjustmentStatusToPermResidenceI485Child = true;
            }

            this.petition.dependentsInfo.childrens.forEach((element, index) => {

                if (element.firstName != '' && element.firstName != null) {
                    this.petition.dependentsInfo.childrens[index].saved = true;
                }

            });

            if (this.petition.dependentsInfo.spouse.firstName != null && this.petition.dependentsInfo.spouse.firstName != '') {

                this.petition.dependentsInfo.spouse.saved = true;
            }

                var $self = this;
                if(this.checkProperty( this.petition.beneficiaryInfo ,'nonImmPetitionsInfo' ,'length')>0){
                this.petition.beneficiaryInfo.nonImmPetitionsInfo.forEach(function (item, index) {
                    
                    $self.petition.beneficiaryInfo.nonImmPetitionsInfo[index].visaStatusDetails = _.find($self.petition.visaStatusList, function (aitem) {

                        return aitem.id == item.visaStatus
                    })
                    })
               }

                 this.petition.beneficiaryInfo.priorPeriodOfStayInUS.forEach(function (item, index) {
                
               $self.petition.beneficiaryInfo.priorPeriodOfStayInUS[index].visaStatusDetails = _.find($self.petition.visaStatusList, function (aitem) {

                    return aitem.id == item.visaStatus
                })
                })
            this.$vs.loading.close();
        },
        init() {
            this.$store.dispatch("getcountries").then((response) => {
                this.countries = response;

            });

            this.$store.dispatch("getmasterdata", "visa_status").then((response) => {
                this.visastatuses = response;
            });
            this.$store.dispatch("getmasterdata", "eye_colors").then((response) => {
                this.eye_colorList = response;
            });
            this.$store.dispatch("getmasterdata", "hair_colors").then((response) => {
                this.hair_colorsList = response;
            });
            this.$store.dispatch("getmasterdata", "races").then((response) => {
                this.races_list = response;
            });
            this.$store.dispatch("getmasterdata", "asset_types").then((response) => {
                this.assestsList = response;
            });
            this.$store.dispatch("getmasterdata", "liabilities_debts").then((response) => {
                this.liability_list = response;
            });
            this.$store.dispatch("getmasterdata", "public_benefits").then((response) => {
                let list = response;
                _.forEach( list,(item) => {
                   item =Object.assign(item,{ 'isSelected':false});
                });
                this.public_benefits = _.cloneDeep(list);
                this.prePopLatePublicBenefits();
            });
            this.$store
                .dispatch("getmasterdata", "marital_status")
                .then((response) => {
                    this.marital_statuses = response;
                });

            this.$store
                .dispatch("getmasterdata", "education_types")
                .then((response) => {
                    this.education_types = response;
                    // this.upDatehighestDegree();
                });
            this.$store
                .dispatch("getpetition", this.$route.params.itemId)
                .then((response) => {
                    if(response && response.data && response.data.result){

                      if(this.checkProperty( response.data.result ,'subTypeDetails' ,'id') ==16){

                            let tempI140Data ={
                                    "beneficiaryInfo":{

                                        immPetitionPriorityDate: null, // list your Priority Date obtained from your previous immigrant petition
                                        applyI485AdjOrConsuProcess: false, // Would you like to apply for adjustment of status (I-485) or consular processing? { type: Boolean, default: false },
                                        adjustmentOfI485Status: false, //Adjustment of Status (I-485) //{ type: Boolean, default: false },
                                        consularProcessing:false,// Consular Processing { type: Boolean, default: false },
                                        areYouUnderRemoveOfIndOrUscis: false, // Are you currently under removal proceedings by the INS/USCIS? { type: Boolean, default: false },
                                       
                                    } 
                            }

                            var data = _.merge(this.petition, tempI140Data);
                           this.petition = data;
                           setTimeout(()=>{
                            if(  this.checkProperty(this.petition ,'beneficiaryInfo' ,'adjustmentOfI485Status') || this.checkProperty(this.petition,'beneficiaryInfo','consularProcessing')){
                               
                                this.consularProcessingValidator ='consularProcessingValidator';
                            }

                           });
                          
                           

                     //   alert(this.petition['beneficiaryInfo']['areYouUnderRemoveOfIndOrUscis'])
                    
                      }else{
                        this.consularProcessingValidator ='consularProcessingValidator';
                      }
                       let tempDocs=[];

                      _.forEach(this.bendocslist ,(docs)=>{
                        tempDocs.push(docs);
                        
                        
                      })
                      //gc 485 tabs
                      //currentTab=='employment' && checkProperty(petition ,'subTypeDetails' ,'id') !=17
                      if(this.checkProperty(this.petition ,'subTypeDetails' ,'id') ==17 || true ){

                        
                        

                           let tempTabs = [];
                           _.forEach(this.tabslist ,(tabItem)=>{
                             if(tabItem['key']=='casedetails'){
                                tempTabs.push(tabItem);
                                if(!_.find(this.tabslist ,{'key':"address"})){
                                    tempTabs.push({  key: "address", name: "Address" });
                                }  
                                
                                if(!_.find(this.tabslist ,{'key':"immigration"})){
                                    tempTabs.push({  key: "immigration", name: "Immigration" });
                                } 
                                if(!_.find(this.tabslist ,{'key':"assets&financials"})){
                                    tempTabs.push({  key: "assets&financials", name: "Assets & Financials" });
                                }
                                if(!_.find(this.tabslist ,{'key':"education"})){
                                    tempTabs.push({  key: "education", name: "Education & Employment" });
                                }  
                                
                                if(!_.find(this.tabslist ,{'key':"parents"})){
                                    tempTabs.push({  key: "parents", name: "Parents" });
                                }
                                     
                                
                           }else{
                            tempTabs.push(tabItem);
                           }
                           });
                           tempTabs = _.filter(tempTabs ,(tab)=>{
                            return tab.key !='employment';
                             
                           });
                           this.tabslist = _.cloneDeep(tempTabs)

                            // this.tabslist.push({
                            // key: "employment",
                            // name: "Employment Info"
                            // })


                            
                         
                               

                      }
                      if(this.checkProperty( response.data.result ,'subTypeDetails' ,'id') ==16){
                                tempDocs.push({
                                    required: false,
                                    key: "w2",
                                    fieldName: 'w2',
                                    label: "Copy of all w2.",
                                    display:true,
                                    }
                                );
                                tempDocs.push({
                                    required: false,
                                    key: "slgEvalOfEduCredentials",
                                    fieldName: 'slgEvalOfEduCredentials',
                                    label: "Evaluation of Education certification.",
                                    display:true,
                                });
                                tempDocs.push({
                                    required: false,
                                    key: "slgPrevImmApprovalNotices",
                                    fieldName: 'slgPrevImmApprovalNotices',
                                    label: "Copy of all Previous Immigrant Approval Notices (e.g., H-1B, H-4, L-1A, L-1B, L-2 etc.,).",
                                    display:true,
                                });


                     }
                     
                    
                      this.bendocslist =[];
                      this.bendocslist =tempDocs;


                          var data = _.merge(this.petition, response.data.result);
                          this.petition = data;

                          
                         


                 
                    this.$store
                        .dispatch("commonAction", {
                            data: {
                                questionnaireId: this.petition.questionnaireTplId
                            },
                            path: "/questionnaire/details",
                        })
                        .then((res) => {

                            let postData = {
                                userId: this.petition.userId,
                                getDocuments: true,
                            };
                            let pth="petition/get-recent-by-beneficiary";
                            pth ="petition-common/get-recent-by-beneficiary";
                            this.$store
                                .dispatch("commonAction", {
                                    data: postData,
                                    path: pth,
                                })
                                .then((response) => {
                                    if (response && response.caseDetails && response.caseDetails.beneficiaryInfo) {
                                        if (!this.petition.questionnaireFilled && (this.petition.beneficiaryInfo.email == null || this.petition.beneficiaryInfo.email == '')) {

                                            this.showPrefillPopup = true;

                                        }

                                        this.latestPetition = response["caseDetails"];
                                        
                                    }else if (response && response.userDetails && response.userDetails && (!this.petition.questionnaireFilled && (this.petition.beneficiaryInfo.email == null || this.petition.beneficiaryInfo.email == ''))){

                                        if(this.checkProperty(response ,'userDetails' ,'email' ) && !this.checkProperty(this.petition ,'beneficiaryInfo' ,'email')){

                                        this.petition['beneficiaryInfo']['email'] = this.checkProperty(response ,'userDetails' ,'email' )


                                        }
                                        if(this.checkProperty(response ,'userDetails' ,'firstName' ) && !this.checkProperty(this.petition ,'beneficiaryInfo' ,'firstName')){
                                        this.petition['beneficiaryInfo']['firstName'] = this.checkProperty(response ,'userDetails' ,'firstName' );
                                        }
                                        if(this.checkProperty(response ,'userDetails' ,'middleName' )  && !this.checkProperty(this.petition ,'beneficiaryInfo' ,'middleName') ){
                                            this.petition['beneficiaryInfo']['firstName'] = this.checkProperty(response ,'userDetails' ,'middleName' );
                                        }
                                        if(this.checkProperty(response ,'userDetails' ,'lastName' ) && !this.checkProperty(this.petition ,'beneficiaryInfo' ,'lastName') ){
                                        this.petition['beneficiaryInfo']['lastName'] = this.checkProperty(response ,'userDetails' ,'lastName' );
                                        }
                                    }

                                    this.questionnaireDetails = res.fields;
                                        this.setTheInitData()
                                });

                        })

                    }else{

                          this.$vs.loading.close();
                    }
                  
                })
        },
        getChildObject() {

            if(this.checkProperty( this.petition ,'subTypeDetails' ,'id') ==16){

            return {
                relationship: '',
                currentlyInUS: null,
                hasOtherNames: false,
                otherNames: [{
                    _id: 0,
                    name: '',
                    firstName: '',
                    middleName: '',
                    lastName: '',
                }],
                alienNumber: '',
                lastArrivalNumber: null,
                placeOfLastEntryInUS: '',
                physicalAddress: {
                    line1: null,
                    line2: null,
                    aptType: null,
                    locationId: null,
                    locationDetails: {
                        id: null,
                        name: null,
                        stateId: null,
                        countryId: null
                    },
                    stateId: null,
                    stateDetails: {
                        id: null,
                        name: null,
                        countryId: null
                    },
                    countryId: null,
                    countryDetails: {
                        id: null,
                        name: null,
                        shortName: null,
                        phoneCode: null,
                        countryId: null,
                        currencySymbol: null,
                        currencyCode: null,
                        zipcodeLength: null
                    },
                    zipcode: null
                },
                addressOutsideUS: {
                    line1: null,
                    line2: null,
                    aptType: null,
                    locationId: null,
                    locationDetails: {
                        id: null,
                        name: null,
                        stateId: null,
                        countryId: null
                    },
                    stateId: null,
                    stateDetails: {
                        id: null,
                        name: null,
                        countryId: null
                    },
                    countryId: null,
                    countryDetails: {
                        id: null,
                        name: null,
                        shortName: null,
                        phoneCode: null,
                        countryId: null,
                        currencySymbol: null,
                        currencyCode: null,
                        zipcodeLength: null
                    },
                    zipcode: null
                },
                passportIssuedNumber: null,
                priorPeriodOfStayInUS: [{
                    _id: 0,
                    enteredNumber: null,
                    dateerror: false,
                    noOfDays: null,
                    departedNumber: null,
                    visaStatus: null
                }],

                h4Required: true,
                name: '',
                firstName: '',
                middleName: '',
                lastName: '',
                dateOfBirth: null,
                countryOfBirth: null,
                countryOfBirthDetails: null,
                provinceOfBirth: null,
                provinceOfBirthDetails: null,
                locationOfBirth: '',
                locationOfBirthDetails: null,
                countryOfCitizenship: null,
                countryOfCitizenshipDetails: null,
                passportNumber: '',
                passportExpiryNumber: null,
                I94: '',
                I94ExpiryNumber: null,
                currentStatus: null,
                statusExpiryNumber: null,
                documents: {
                    passport: [],
                    visa: [],
                    formI94: [],
                    birthCertificate: [],
                    approvalNotice: [],
                    approvalNoticeOfPrevH4: [],
                    other: []
                },

                adjustmentOfI485Status: false, //Adjustment of Status (I-485) //{ type: Boolean, default: false },
                consularProcessing:false,// Consular Processing { type: Boolean, default: false },
            }
        }else{
            return {
                relationship: '',
                currentlyInUS: null,
                hasOtherNames: false,
                otherNames: [{
                    _id: 0,
                    name: '',
                    firstName: '',
                    middleName: '',
                    lastName: '',
                }],
                alienNumber: '',
                lastArrivalNumber: null,
                placeOfLastEntryInUS: '',
                physicalAddress: {
                    line1: null,
                    line2: null,
                    aptType: null,
                    locationId: null,
                    locationDetails: {
                        id: null,
                        name: null,
                        stateId: null,
                        countryId: null
                    },
                    stateId: null,
                    stateDetails: {
                        id: null,
                        name: null,
                        countryId: null
                    },
                    countryId: null,
                    countryDetails: {
                        id: null,
                        name: null,
                        shortName: null,
                        phoneCode: null,
                        countryId: null,
                        currencySymbol: null,
                        currencyCode: null,
                        zipcodeLength: null
                    },
                    zipcode: null
                },
                addressOutsideUS: {
                    line1: null,
                    line2: null,
                    aptType: null,
                    locationId: null,
                    locationDetails: {
                        id: null,
                        name: null,
                        stateId: null,
                        countryId: null
                    },
                    stateId: null,
                    stateDetails: {
                        id: null,
                        name: null,
                        countryId: null
                    },
                    countryId: null,
                    countryDetails: {
                        id: null,
                        name: null,
                        shortName: null,
                        phoneCode: null,
                        countryId: null,
                        currencySymbol: null,
                        currencyCode: null,
                        zipcodeLength: null
                    },
                    zipcode: null
                },
                passportIssuedNumber: null,
                priorPeriodOfStayInUS: [{
                    _id: 0,
                    enteredNumber: null,
                    dateerror: false,
                    noOfDays: null,
                    departedNumber: null,
                    visaStatus: null
                }],

                h4Required: true,
                name: '',
                firstName: '',
                middleName: '',
                lastName: '',
                dateOfBirth: null,
                countryOfBirth: null,
                countryOfBirthDetails: null,
                provinceOfBirth: null,
                provinceOfBirthDetails: null,
                locationOfBirth: '',
                locationOfBirthDetails: null,
                countryOfCitizenship: null,
                countryOfCitizenshipDetails: null,
                passportNumber: '',
                passportExpiryNumber: null,
                I94: '',
                I94ExpiryNumber: null,
                currentStatus: null,
                statusExpiryNumber: null,
                documents: {
                    passport: [],
                    visa: [],
                    formI94: [],
                    birthCertificate: [],
                    approvalNotice: [],
                    approvalNoticeOfPrevH4: [],
                    other: []
                },

               
            }

        }

        },

        setBasicData(){
            //this.latestPetition beneficiaryInfo
            //email  firstName middleName lastName
            if(this.checkProperty(this.latestPetition ,'beneficiaryInfo' ,'email' )){

                this.petition['beneficiaryInfo']['email'] = this.checkProperty(this.latestPetition ,'beneficiaryInfo' ,'email' )
                

            }
            if(this.checkProperty(this.latestPetition ,'beneficiaryInfo' ,'firstName' )){
                this.petition['beneficiaryInfo']['firstName'] = this.checkProperty(this.latestPetition ,'beneficiaryInfo' ,'firstName' );
            }
            if(this.checkProperty(this.latestPetition ,'beneficiaryInfo' ,'middleName' )){
                this.petition['beneficiaryInfo']['middleName'] = this.checkProperty(this.latestPetition ,'beneficiaryInfo' ,'middleName' );
            }
            if(this.checkProperty(this.latestPetition ,'beneficiaryInfo' ,'lastName' )){
                this.petition['beneficiaryInfo']['lastName'] = this.checkProperty(this.latestPetition ,'beneficiaryInfo' ,'lastName' );
            }


        },
        prefilltheDetails() {

            var childres = []
            this.latestPetition.dependentsInfo.childrens.forEach((element, index) => {

                if (element.firstName != null && element.firstName != "") {
                    childres.push(element)
                }

            });
            if (childres.length > 0) {
                this.latestPetition.dependentsInfo.childrens = childres;
            } else {
                this.latestPetition.dependentsInfo.childrens = this.getChildObject()
            }

            var data = _.merge(this.petition, this.latestPetition);

            this.petition = data;
            this.setTheInitData()
        }

    },
    beforeDestroy() {
        const $ = JQuery;
        document.removeEventListener("click", this.reloadthePage);

        $('body').removeClass('questionnairetpl')
    },
    mounted() {
        this.getMasterSocList();
        const $ = JQuery;
        this.$vs.loading();
        $('body').addClass('questionnairetpl')
        this.init();
        this.loadStatesByCountry('usastates', 231)

    },
    components: {
        FileUpload,
        Datepicker,
        immitextfield,
        XIcon,
        genderField,
        immiInput,
        addressField,
        Trash2Icon,
        datepickerField,
        selectField,
        immiPhone,
        immiMask,
        immiyesorno,
        immiuploader,
        immipriorstay,
        immitextarea,
        immieducations,
        immiswitchyesno,
        casedocumentslist,
        immiemployment,
        PetitionDetails,
        VuePerfectScrollbar,
        petitionsinformation,
        personalinfo,
        childpersonalinfo,

     // 485 Components
     previousSpouseForm ,
     immigrationForm,
    
     addresscomponent,
     financialForm,
     assestsForm,
     liabilitiesForm,
     publicBenefitsForm,
     parentForm,


    },
    watch: {

    }
};
</script>
