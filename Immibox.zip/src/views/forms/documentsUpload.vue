<template>
    <div>
        <form data-vv-scope="documentsform" @submit.prevent="" @keydown.enter.prevent="" v-if="showEdit">
            <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12">
                <div class="form-container pt-10 form-container-questionnaire">
                    <casedocumentslist @emitUploadingAction="emitUploadingAction" :docMainCategory="'documentslist'"
                     :docslist="documentslist" :petition="petition" formscope="documentsform" :showTitle="true" :callfromPetitionDocs="true"
                      :fieldsArray="fieldsArray" v-model="petition.documents" :tplsection="'documents'"  :fieldName="''" ></casedocumentslist>
                    <template v-if="showSpouseDocs">
                        <casedocumentslist @emitUploadingAction="emitUploadingAction" :docMainCategory="'spouseDocsList'" 
                            :title="'List of Spouse documents needs to be updated'"
                            :docslist="spouseDocsList" :petition="petition" formscope="documentsform" :showTitle="true" :callfromPetitionDocs="true"
                            :fieldsArray="fieldsArray" v-model="petition.dependentsInfo.spouse.documents" :tplsection="'dependentsInfo.spouse.documents'"  :fieldName="''" >
                        </casedocumentslist>
                    </template>
                </div>
            </vs-col>
            <template >
                <div @click="formerrors.msg = ''" class="text-danger text-sm formerrors" v-show="formerrors.msg">
                    <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
                    icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
                </div>

                <div class="popup-footer mt-4 relative">
                    <button class="btn cancel" @click="$emit('openEditDocs', false)">Cancel</button>
                    <button class="btn save" @click="updateDocumentsAction()" :disabled="documentUploading">
                    <figure class="loader" v-if="documentUploading"><img src="@/assets/images/main/loader.gif" /></figure>
                    <span>Update</span>
                    </button>
                </div>
            </template>
        </form>
    </div>
</template>
<script>
import _ from "lodash";
import moment from "moment";
import casedocumentslist from "@/views/common/casedocuments.vue";
export default {
    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
    data() {
        return {
            showEdit:false,
            spouseDocuments:{
                documents:null
            },
            formerrors:{
                msg:''
            },
            documentUploading:false,
            spouseDocsList:[],
            documentslist: [
                {
                    display:true,
                    required: false,
                    fileUploading:false,
                    key: 'copyOfRfe',
                    fieldName: 'copyOfRfe',
                    label: 'Copy of RFE'
                }, 
                {
                    display:true,
                    required: false,
                    fileUploading:false,
                    key: 'orgPetition',
                    fieldName: 'orgPetition',
                    label: 'Original Petition'
                }, 
                {
                    display:true,
                    required: false,
                    fileUploading:false,
                    key: 'petitionerDocs',
                    fieldName: 'petitionerDocs',
                    label: 'Petitioner Documents (if any)'
                }, 
                {
                    display:true,
                    required: false,
                    fileUploading:false,
                    key: 'beneficiaryDocs',
                    fieldName: 'beneficiaryDocs',
                    label: 'Beneficiary Documents'
                },  
                {
                    display:true,
                    required: false,
                    fileUploading:false,
                    key: 'employmentDocs',
                    fieldName: 'employmentDocs',
                    label: 'Employment Documents (if any)'
                }, 
                {
                    display:true,
                    required: false,
                    fileUploading:false,
                    key: 'other',
                    fieldName: 'other',
                    label: 'Others'
                }, 
            ]
        }
    },
    methods: {
        updateDocumentsAction() {
            Object.assign(this.formerrors, { msg: "" });
            this.$validator.validateAll('documentsform').then((result) => {
                if (result) {
                    let postData = {
                        "documents": {},
                        "typeName": "",
                        "subTypeName": "",
                        "petitionId": '',
                        "today": null
                    }
                    let documents = {}
                    let spouseDocs= {};
                    let isUploaded = false 
                    _.forEach(Object.entries(this.petition.documents), (val, key) => {
                        if (this.checkProperty(val, "length") > 1) {
                            let docKey = val[0];
                            let docs = val[1];
                            documents[docKey] = []
                            let newDocuments = _.filter(docs, { "isNew": true })
                            if (this.checkProperty(newDocuments, "length") > 0) {
                                isUploaded = true;
                                documents[docKey] = newDocuments
                            }
                        }
                    })
                    if(this.checkProperty(this.petition.dependentsInfo,'spouse')  && this.checkProperty(this.petition.dependentsInfo,'spouse', 'documents') && this.showSpouseDocs ){
                        _.forEach(Object.entries(this.petition.dependentsInfo.spouse.documents), (val, key) => {
                        if (this.checkProperty(val, "length") > 1) {
                            let docKey = val[0];
                            let docs = val[1];
                            spouseDocs[docKey] = []
                            let newDocuments = _.filter(docs, { "isNew": true })
                            if (this.checkProperty(newDocuments, "length") > 0) {
                                isUploaded = true;
                                spouseDocs[docKey] = newDocuments
                            }
                        }
                    })
                    }
                   
                    if (!isUploaded) {
                        Object.assign(this.formerrors, { msg: 'Atleast one document is required.' });
                        return true;
                    }
                    if(this.showSpouseDocs){
                        postData['spouseDocuments'] = _.cloneDeep(spouseDocs);
                    }
                    postData['documents'] = _.cloneDeep(documents);
                    postData['typeName'] = this.checkProperty(this.getPetitionDetails, "typeDetails", "name")
                    postData['subTypeName'] = this.checkProperty(this.getPetitionDetails, "subTypeDetails", "name")
                    postData['petitionId'] = this.checkProperty(this.getPetitionDetails, "_id");
                    postData['today'] = moment().format("YYYY-MM-DD")
                    this.documensUpdating = true;
                    let path = "/petition/add-additional-documents";
                    if (this.checkProperty(this.getPetitionDetails, 'type') == 3 && [15].indexOf(this.checkProperty(this.getPetitionDetails, 'subTypeDetails', 'id')) > -1) {
                        path = "/perm/add-additional-documents";
                    }
                    this.$store.dispatch("commonAction", { "data": postData, "path": path })
                    .then(response => {
                        //lca_request_msg
                        this.showToster({ message: response.message, isError: false });
                        this.documensUpdating = false;
                        this.$emit('reloadCaseDetails')
                    })
                    .catch((error) => {
                        Object.assign(this.formerrors, { msg: error });
                        this.documensUpdating = false;
                    })
                }
            })
        },
        emitUploadingAction(data){
            if(_.has(data,'docMainCategory')){
                _.map(this[data['docMainCategory']],(item)=>{
                    if(item['fieldName'] == data['fieldName']){
                        item = Object.assign( item ,{ "fileUploading": false})
                        item['fileUploading'] = data['action'] 
                    }
                })
            }
            this.checkSubmitBtn(data)
        },
        checkSubmitBtn(data){
            this.documentUploading = false;
            if(_.has(data,'docMainCategory')){
                _.forEach(this[data['docMainCategory']],(item)=>{
                    if(_.has(item,'fileUploading') && item['fileUploading']){
                        this.documentUploading = true;
                        return false;
                    }
                })
            }
        },
    },
    props:{
        showSpouseDocs:{
            type:Boolean,
            default:false
        },
        petition: {
            type: Object,
            default: null,
        },
        fieldsArray:{
            type: Array,
            default: [],
        },
        benDocumentList:{
            type: Array,
            default: [],
        },
        spouseDocumentList:{
            type: Array,
            default: [],
        },
    },
    components: {
        casedocumentslist,
    },
    computed: {

    },
    mounted() {
        if(this.checkProperty(this.benDocumentList, 'length')>0){
            this.documentslist = _.cloneDeep(this.benDocumentList);
        }
        if(this.checkProperty(this.spouseDocumentList, 'length')>0){
            this.spouseDocsList = _.cloneDeep(this.spouseDocumentList);
        }
        if(this.checkProperty(this.petition, 'dependentsInfo', 'spouse') && this.checkProperty(this.petition['dependentsInfo'],'spouse','documents') && this.showSpouseDocs){
            this.spouseDocuments['documents'] = _.cloneDeep(this.checkProperty(this.petition['dependentsInfo'],'spouse','documents'))
        }
        this.formerrors.msg = '';
        this.showEdit = true
    }
}

</script>