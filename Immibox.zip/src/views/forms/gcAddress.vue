<template>
    <div class="vx-row w-full ml-0">
        <div class="vx-col md:w-1/2 w-full">
            <div class="form_group">
                <label class="form_label">Street Address</label>
                <vs-input
                class="w-full"
                name="line1"
                data-vv-as="Street Address"
                />          
            </div>
        </div>
        <div class="vx-col md:w-1/2 w-full">
            <div class="form_group">
                <label class="form_label">Apt, Suite</label>             
                <div class="address-suite" >
                <ul class="custom-radio" vs-type="flex" vs-align="center" >
                    <li>                                 
                    <vs-checkbox v-model="checkBox1"
                        >Apt</vs-checkbox>
                    </li>
                    <li> 
                    <vs-checkbox v-model="checkBox1"
                        >Ste</vs-checkbox>
                    </li>
                    <li> 
                    <vs-checkbox v-model="checkBox1"
                        >Flr</vs-checkbox>
                    </li>
                </ul>
                    <vs-input
                    class="w-full"
                    name="line1"
                    data-vv-as="Street Address"
                    />  
                </div>
            </div>          
        </div>
        <div class="vx-col md:w-1/2 w-full">
            <div class="form_group">
                <label class="form_label">Country</label>
                <div class="con-select">
                <multiselect
                    v-model="value"
                    :options="options"
                ></multiselect>
                </div>
            </div>
        </div>
        <div class="vx-col md:w-1/2 w-full">
            <div class="form_group">
                <label class="form_label">State</label>
                <div class="con-select">
                <multiselect
                    v-model="value"
                    :options="options"
                ></multiselect>
                </div>
            </div>
        </div>
        <div class="vx-col md:w-1/2 w-full">
            <div class="form_group">
                <label class="form_label">City</label>
                <div class="con-select">
                <multiselect
                    v-model="value"
                    :options="options"
                ></multiselect>
                </div>
            </div>
        </div>
        <div class="vx-col md:w-1/2 w-full">
            <div class="form_group">
                <label class="form_label">Zip Code</label>
                <vs-input
                class="w-full"
                name="line1"
                data-vv-as="Street Address"
                />   
            </div>
        </div>
    </div>
</template>

<script>  
import Datepicker from "vuejs-datepicker-inv";
import moment from "moment";
import PhoneMaskInput from "vue-phone-mask-input";
import JQuery from "jquery";
import { TheMask } from "vue-the-mask";
import FileUpload from "vue-upload-component/src";
import _ from "lodash";
import Vue from "vue";
import VuePhoneNumberInput from "vue-phone-number-input";
import "vue-phone-number-input/dist/vue-phone-number-input.css";
import { Trash2Icon } from "vue-feather-icons";    
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import { XIcon } from "vue-feather-icons";
import DateRangePicker from "vue2-daterange-picker";
export default {
  provide() {
    return {
      parentValidator: this.$validator,
    };
  },
  data() {
    return {
      Employee: false,
      value: null,
      options: ["list", "of", "options"],

      settings: {
        swipeEasing: true,
      },
    };
  },

  components: {
    XIcon,
    VuePerfectScrollbar,  
    VuePhoneNumberInput,

    Datepicker,
    PhoneMaskInput,
    TheMask,
    FileUpload,
    Trash2Icon,
    DateRangePicker
  },
};
</script>
