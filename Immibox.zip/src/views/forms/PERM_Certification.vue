<template>
<div class="block-layout questionnaire" :class="{ anonymousloginForm: !checkCurrentUrl }">
    <div class="
        vx-col
        w-full
        wizard-container
        form_section
        questionnairesection
        pad0
      "  >
         
        <div class="questionnaire_page dd">
            <div class="questionnaire_sec">
                <div class="questionnaire_titles">
                    <div class="questionnaire_titles_info">
                        <h2>
                            PERM Certification
                            {{ checkProperty(petition, "typeDetails", "name") }}
                            <small>{{
                  checkProperty(petition, "subTypeDetails", "name")
                }}</small>
                        </h2>
                        <p>
                            Please take a few moments to complete this short registration
                            form
                        </p>
                        <!-- <ul>
                            <li :class="{
                    active:
                      selectedTab == 'caseDetails' ||
                      selectedTab == 'documents' ||
                      selectedTab == 'dependentsInfo',
                  }">
                                <span>1</span><a>Case Details</a>
                            </li>
                            <li :class="{
                    active:
                      selectedTab == 'documents' ||
                      selectedTab == 'dependentsInfo',
                  }">
                                <span>2</span><a>Documents</a>
                            </li>
                            <li v-if="
                    checkProperty(beneficiaryInfo, 'maritalStatus', 'id') == 2
                  " :class="{ active: selectedTab == 'dependentsInfo' }">
                                <span>3</span><a>Dependents Info</a>
                            </li> 
                        </ul> -->
                    </div>
                    <figure>
                        <img src="@/assets/images/main/content-bottom-image.svg" />
                    </figure>
                </div>
                 <div>
                    <div class="gcform_section">
      <form>
        <div class="form-container">
            <vs-col class="m-auto float-none" vs-lg="10" vs-sm="12">
                <div class="vx-row">
                    <div class="vx-col w-full mt-5">
                        <div class="form_group">
                            <div class="listitems listitems2">
                            <h6>Are you seeking to utilize the filing date from a previously submitted
                                <br>
                                Application for Alien Employment Certification (ETA 750)?
                            </h6>
                            <ul class="custom-radio">
                                <li>
                                <vs-checkbox v-model="checkBox1">Yes</vs-checkbox>                      
                                </li>
                                <li>
                                <vs-checkbox v-model="checkBox1">No</vs-checkbox>                      
                                </li>
                            </ul>
                            </div> 
                        </div>
                    </div>
                    <div class="vx-col w-full md:w-1/2">
                        <div class="form_group">
                            <label class="form_label"> If Yes, Enter the Previous Filing Date</label>
                            <datepicker v-model="date" name="uniquename"></datepicker>
                        </div>
                    </div>
                    <div class="vx-col w-full">
                        <div class="form_group">
                            <label class="form_label">  Indicate the previous SWA or local office case number OR if not available, specify state where case was
originally filed:</label>
                            <!-- <vs-textarea class="w-full" /> -->
                            <ckeditor  class="w-full" :editor="editor" :config="editorConfig"></ckeditor>

                        </div>
                    </div>
                    <div class="vx-col w-full">
                        <div class="form_group">
                            <div class="listitems listitems2">
                            <h6>Is this application in support of a Schedule A or Sheepherder Occupation?</h6>
                            <ul class="custom-radio">
                                <li>
                                <vs-checkbox v-model="checkBox1">Yes</vs-checkbox>                      
                                </li>
                                <li>
                                <vs-checkbox v-model="checkBox1">No</vs-checkbox>                      
                                </li>
                            </ul>
                            <h6><small>If Yes, do NOT send this application to the Department of Labor. All applications in support of Schedule A or
Sheepherder Occupations must be sent directly to the appropriate Department of Homeland Security office.</small>
                            </h6>
                            </div> 
                        </div>
                    </div>
                </div>
            </vs-col>
            <span class="form_devider"></span>
            <vs-col class="m-auto float-none" vs-lg="10" vs-sm="12">
                <h3 class="small-header">Employer Information</h3>
                <div class="vx-row">
                    <div class="vx-col w-full md:w-1/2">
                        <div class="form_group">
                            <label class="form_label"> Employer’s Name</label>
                            <vs-input class="w-full" />
                        </div>
                    </div>
                    <div class="vx-col md:w-1/2 w-full">
                    <div class="form_group ph_number">
                        <div class="vs-component">
                        <label class="form_label">Phone Number</label>
                        <VuePhoneNumberInput v-model="value" />
                        </div>
                    </div>
                    </div>
                    <gcAddress></gcAddress>
                    <div class="vx-col md:w-1/2 w-full">
                    <div class="form_group">
                        <label class="form_label">Number of Employees</label>
                        <vs-input class="w-full" />
                    </div>
                    </div>
                    <div class="vx-col md:w-1/2 w-full">
                    <div class="form_group">
                        <label class="form_label">Year Commenced Business</label>
                        <vs-input class="w-full" />
                    </div>
                    </div>
                    <div class="vx-col md:w-1/2 w-full">
                    <div class="form_group">
                        <label class="form_label">FEIN( Federal Employer Identification Number)</label>
                        <vs-input class="w-full" />
                    </div>
                    </div>
                    <div class="vx-col md:w-1/2 w-full">
                    <div class="form_group">
                        <label class="form_label">NAICS Code</label>
                        <vs-input class="w-full" />
                    </div>
                    </div>
                    <div class="vx-col w-full">
                        <div class="form_group">
                            <div class="listitems listitems2">
                            <h6>Is the employer a closely held corporation, partnership, or sole proprietorship in which
the alien has an ownership interest, or is there a familial relationship between the
owners, stockholders, partners, corporate officers, or incorporators, and the alien?
                            </h6>
                            <ul class="custom-radio">
                                <li>
                                <vs-checkbox v-model="checkBox1">Yes</vs-checkbox>                      
                                </li>
                                <li>
                                <vs-checkbox v-model="checkBox1">No</vs-checkbox>                      
                                </li>
                            </ul>
                            </div> 
                        </div>
                    </div>
                    </div>
                </vs-col>    
                <span class="form_devider"></span>

                <vs-col class="m-auto float-none" vs-lg="10" vs-sm="12">
                    <h3 class="small-header">Employer Contact Information</h3>
                    <div class="vx-row">
                        <div class="vx-col w-full">
                            <vx-input-group class="form-input-group">
                                <vs-input
                                name="firstname"
                                class="w-full"
                                data-vv-as="First Name"
                                label="First Name"
                                />
                                <vs-input
                                class="w-full"
                                name="middleName"
                                data-vv-as="Middle Name"
                                label="Middle Name"
                                />
                                <vs-input
                                class="w-full"
                                name="lastName"
                                data-vv-as="Last Name"
                                label="Last Name"
                                />
                            </vx-input-group>
                        </div>
                        <gcAddress></gcAddress>
                        <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group ph_number">
                            <div class="vs-component">
                            <label class="form_label">Phone Number</label>
                            <VuePhoneNumberInput v-model="value" />
                            </div>
                        </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                            <label class="form_label">E-mail</label>
                            <vs-input class="w-full" />
                        </div>
                        </div>
                    </div>
                </vs-col>

                <span class="form_devider"></span>

                <vs-col class="m-auto float-none" vs-lg="10" vs-sm="12">
                    <h3 class="small-header">Agent or Attorney Information (If applicable)</h3>
                    <div class="vx-row">
                        <div class="vx-col w-full">
                            <vx-input-group class="form-input-group">
                                <vs-input
                                name="firstname"
                                class="w-full"
                                data-vv-as="First Name"
                                label="First Name"
                                />
                                <vs-input
                                class="w-full"
                                name="middleName"
                                data-vv-as="Middle Name"
                                label="Middle Name"
                                />
                                <vs-input
                                class="w-full"
                                name="lastName"
                                data-vv-as="Last Name"
                                label="Last Name"
                                />
                            </vx-input-group>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                            <label class="form_label">Firm Name</label>
                            <vs-input class="w-full"/>
                        </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                            <label class="form_label">Firm EIN</label>
                            <vs-input class="w-full"/>
                        </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group ph_number">
                            <div class="vs-component">
                            <label class="form_label">Phone Number</label>
                            <VuePhoneNumberInput v-model="value" />
                            </div>
                        </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                            <label class="form_label">E-mail</label>
                            <vs-input class="w-full" />
                        </div>
                        </div>
                        <gcAddress></gcAddress>
                    </div>
                </vs-col>

                <span class="form_devider"></span>

                <vs-col class="m-auto float-none" vs-lg="10" vs-sm="12">
                    <h3 class="small-header">Prevailing Wage Information (as provided by the State Workforce Agency)</h3>
                    <div class="vx-row">
                        <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                            <label class="form_label">Prevailing Wage Tracking Number (if applicable)</label>
                            <vs-input class="w-full"/>
                        </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                            <label class="form_label">SOC/O*NET(OES) Code</label>
                            <vs-input class="w-full"/>
                        </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                            <label class="form_label">Occupation Title</label>
                            <vs-input class="w-full"/>
                        </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                            <label class="form_label">Skill Level</label>
                            <vs-input class="w-full"/>
                        </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                            <label class="form_label">Prevailing Wage</label>
                            <vs-input class="w-full"/>
                        </div>
                        </div>
                        <div class="vx-col w-full">
                        <div class="form_group">
                            <label class="form_label">Per: (Choose only one)</label>
                            <div class="listitems">
                            <ul class="custom-radio">
                                <li>
                                <vs-checkbox v-model="checkBox1">Hour</vs-checkbox>                      
                                </li>
                                <li>
                                <vs-checkbox v-model="checkBox1">Week</vs-checkbox>                      
                                </li>
                                <li>
                                <vs-checkbox v-model="checkBox1">Bi-Weekly</vs-checkbox>                      
                                </li>
                                <li>
                                <vs-checkbox v-model="checkBox1">Month</vs-checkbox>                      
                                </li>
                                <li>
                                <vs-checkbox v-model="checkBox1">Year</vs-checkbox>                      
                                </li>
                            </ul>
                            </div> 
                        </div>
                        </div>
                        <div class="vx-col w-full">
                        <div class="form_group">
                            <label class="form_label">Prevailing Wage Source (Choose only one)</label>
                            <div class="listitems">
                            <ul class="custom-radio">
                                <li>
                                <vs-checkbox v-model="checkBox1">OES</vs-checkbox>                      
                                </li>
                                <li>
                                <vs-checkbox v-model="checkBox1">CBA</vs-checkbox>                      
                                </li>
                                <li>
                                <vs-checkbox v-model="checkBox1">Employer Conducted Survey</vs-checkbox>                      
                                </li>
                                <li>
                                <vs-checkbox v-model="checkBox1">DBA</vs-checkbox>                      
                                </li>
                                <li>
                                <vs-checkbox v-model="checkBox1">SCA</vs-checkbox>                      
                                </li>
                                <li>
                                <vs-checkbox v-model="checkBox1">Other</vs-checkbox>                      
                                </li>
                            </ul>
                            </div> 
                        </div>
                        </div>
                        <div class="vx-col w-full">
                        <div class="form_group">
                            <label class="form_label">If Other is indicated in above, specify:</label>
                            <vs-input class="w-full"/>
                        </div>
                        </div>
                        <div class="vx-col w-full md:w-1/2">
                        <div class="form_group">
                            <label class="form_label">Determination Date</label>
                            <datepicker v-model="date" name="uniquename"></datepicker>
                        </div>
                        </div>
                        <div class="vx-col w-full md:w-1/2">
                            <div class="form_group">
                                <label class="form_label">Expiration Date</label>
                                <datepicker v-model="date" name="uniquename"></datepicker>
                            </div>
                        </div>
                        </div>
                </vs-col>

                <span class="form_devider"></span>

                <vs-col class="m-auto float-none" vs-lg="10" vs-sm="12">
                    <h3 class="small-header">Wage Offer Information</h3>
                    <div class="vx-row">
                        <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                            <label class="form_label"> Offered Wage From: </label>
                            <vs-input class="w-full"/>
                        </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                            <label class="form_label">To: (Optional)</label>
                            <vs-input class="w-full"/>
                        </div>
                        </div>
                        <div class="vx-col w-full">
                        <div class="form_group">
                            <label class="form_label">Per: (Choose only one)</label>
                            <div class="listitems">
                            <ul class="custom-radio">
                                <li>
                                <vs-checkbox v-model="checkBox1">Hour</vs-checkbox>                      
                                </li>
                                <li>
                                <vs-checkbox v-model="checkBox1">Week</vs-checkbox>                      
                                </li>
                                <li>
                                <vs-checkbox v-model="checkBox1">Bi-Weekly</vs-checkbox>                      
                                </li>
                                <li>
                                <vs-checkbox v-model="checkBox1">Month</vs-checkbox>                      
                                </li>
                                <li>
                                <vs-checkbox v-model="checkBox1">Year</vs-checkbox>                      
                                </li>
                            </ul>
                            </div> 
                        </div>
                        </div>
                        </div>
                </vs-col>
                
                <span class="form_devider"></span>

                <vs-col class="m-auto float-none" vs-lg="10" vs-sm="12">
                    <h3 class="small-header">Job Opportunity Information (Where work will be performed)</h3>
                    <div class="vx-row">
                        <gcAddress></gcAddress>
                        <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                            <label class="form_label">Job Title</label>
                            <vs-input class="w-full"/>
                        </div>
                        </div>
                        <div class="vx-col w-full">
                        <div class="form_group">
                            <label class="form_label">Education: minimum level required:</label>
                            <div class="listitems">
                            <ul class="custom-radio">
                                <li>
                                <vs-checkbox v-model="checkBox1">None</vs-checkbox>                      
                                </li>
                                <li>
                                <vs-checkbox v-model="checkBox1">High School</vs-checkbox>                      
                                </li>
                                <li>
                                <vs-checkbox v-model="checkBox1">Associate’s</vs-checkbox>                      
                                </li>
                                <li>
                                <vs-checkbox v-model="checkBox1">Bachelor’s</vs-checkbox>                      
                                </li>
                                <li>
                                <vs-checkbox v-model="checkBox1">Master’s</vs-checkbox>                      
                                </li>
                                <li>
                                <vs-checkbox v-model="checkBox1">Doctorate</vs-checkbox>                      
                                </li>
                                <li>
                                <vs-checkbox v-model="checkBox1">Other</vs-checkbox>                      
                                </li>
                            </ul>
                            </div> 
                        </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                            <label class="form_label"> If Other, specify the education required:</label>
                            <vs-input class="w-full"/>
                        </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                            <label class="form_label"> Major Field of Study</label>
                            <vs-input class="w-full"/>
                        </div>
                        </div>
                        <div class="vx-col w-full md:w-1/2">
                        <div class="form_group">
                            <label class="form_label">Is training required for the job opportunity?</label>
                            <div class="listitems">
                            <ul class="custom-radio">
                                <li>
                                <vs-checkbox v-model="checkBox1">Yes</vs-checkbox>                      
                                </li>
                                <li>
                                <vs-checkbox v-model="checkBox1">No</vs-checkbox>                      
                                </li>
                            </ul>
                            </div> 
                        </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                            <label class="form_label"> If Yes, number of months of training required:</label>
                            <vs-input class="w-full"/>
                        </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                            <label class="form_label"> Indicate the Field of Training:</label>
                            <vs-input class="w-full"/>
                        </div>
                        </div>
                        </div>
                        <div class="vx-row">
                        <div class="vx-col w-full md:w-1/2">
                        <div class="form_group">
                            <label class="form_label"> Is experience in the job offered required for the job?</label>
                            <div class="listitems">
                            <ul class="custom-radio">
                                <li>
                                <vs-checkbox v-model="checkBox1">Yes</vs-checkbox>                      
                                </li>
                                <li>
                                <vs-checkbox v-model="checkBox1">No</vs-checkbox>                      
                                </li>
                            </ul>
                            </div> 
                        </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                            <div class="form_group">
                                <label class="form_label">  If Yes, number of months experience required:</label>
                                <vs-input class="w-full"/>
                            </div>
                        </div>
                        <div class="vx-col w-full md:w-1/2">
                            <div class="form_group">
                                <label class="form_label">Is there an alternate field of study that is acceptable?</label>
                                <div class="listitems">
                                <ul class="custom-radio">
                                    <li>
                                    <vs-checkbox v-model="checkBox1">Yes</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">No</vs-checkbox>                      
                                    </li>
                                </ul>
                                </div> 
                            </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                            <label class="form_label">  If Yes, specify the major field of study:</label>
                            <vs-input class="w-full"/>
                        </div>
                        </div>
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label">Is there an alternate combination of education and experience that is acceptable?</label>
                                <div class="listitems">
                                <ul class="custom-radio">
                                    <li>
                                    <vs-checkbox v-model="checkBox1">Yes</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">No</vs-checkbox>                      
                                    </li>
                                </ul>
                                </div> 
                            </div>
                        </div>
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label">If Yes, specify the alternate level of education required:</label>
                                <div class="listitems">
                                <ul class="custom-radio">
                                    <li>
                                    <vs-checkbox v-model="checkBox1">None</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">High School</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">Associate’s</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">Bachelor’s</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">Master’s</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">Doctorate</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">Other</vs-checkbox>                      
                                    </li>
                                </ul>
                                </div> 
                            </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                            <div class="form_group">
                                <label class="form_label">  If Other is indicated in above question, indicate the alternate level of education required:</label>
                                <vs-input class="w-full"/>
                            </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                            <div class="form_group">
                                <label class="form_label">  If applicable, indicate the number of years experience acceptable in above question:</label>
                                <vs-input class="w-full"/>
                            </div>
                        </div>
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label"> Is a foreign educational equivalent acceptable?</label>
                                <div class="listitems">
                                <ul class="custom-radio">
                                    <li>
                                    <vs-checkbox v-model="checkBox1">Yes</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">No</vs-checkbox>                      
                                    </li>
                                </ul>
                                </div> 
                            </div>
                        </div>
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label"> Is experience in an alternate occupation acceptable? </label>
                                <div class="listitems">
                                <ul class="custom-radio">
                                    <li>
                                    <vs-checkbox v-model="checkBox1">Yes</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">No</vs-checkbox>                      
                                    </li>
                                </ul>
                                </div> 
                            </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                            <div class="form_group">
                                <label class="form_label">  If Yes, number of months experience in alternate occupation required:</label>
                                <vs-input class="w-full"/>
                            </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                            <div class="form_group">
                                <label class="form_label">  Identify the job title of the acceptable alternate occupation:</label>
                                <vs-input class="w-full"/>
                            </div>
                        </div>
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label">  Job duties – If submitting by mail, add attachment if necessary. Job duties description must begin in this space</label>
                                <!-- <vs-textarea
                                    class="w-full"
                                    /> -->
                                    <ckeditor  class="w-full"  :editor="editor" :config="editorConfig"></ckeditor>

                            </div>
                        </div>
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label"> Are the job opportunity’s requirements normal for the occupation? </label>
                                <div class="listitems listitems2">
                                    <ul class="custom-radio pt-0">
                                        <li>
                                        <vs-checkbox v-model="checkBox1">Yes</vs-checkbox>                      
                                        </li>
                                        <li>
                                        <vs-checkbox v-model="checkBox1">No</vs-checkbox>                      
                                        </li>
                                    </ul>
                                <em>If the answer to this question is No, the employer must be prepared to
                                    provide documentation demonstrating that the job requirements are
                                    supported by business necessity</em>
                                
                                </div> 
                            </div>
                        </div>
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label">  Is knowledge of a foreign language required to perform the job duties? </label>
                                <div class="listitems listitems2">
                                <ul class="custom-radio pt-0">
                                    <li>
                                    <vs-checkbox v-model="checkBox1">Yes</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">No</vs-checkbox>                      
                                    </li>
                                </ul>
                                <em>If the answer to this question is Yes, the employer must be prepared to
                                    provide documentation demonstrating that the language requirements
                                    are supported by business necessity.</em>                                
                                </div> 
                            </div>
                        </div>
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label">  Specific skills or other requirements – If submitting by mail, add attachment if necessary. Skills description must
                                begin in this space</label>
                                <!-- <vs-textarea
                                    class="w-full"
                                    /> -->
                                    <ckeditor  class="w-full"  :editor="editor" :config="editorConfig"></ckeditor>

                            </div>
                        </div>
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label">  Does this application involve a job opportunity that includes a combination of
                                                            occupations? </label>
                                <div class="listitems">
                                <ul class="custom-radio">
                                    <li>
                                    <vs-checkbox v-model="checkBox1">Yes</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">No</vs-checkbox>                      
                                    </li>
                                </ul>
                                </div> 
                            </div>
                        </div>
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label">  Is the position identified in this application being offered to the alien identified
                                                            in Section J?  </label>
                                <div class="listitems">
                                <ul class="custom-radio">
                                    <li>
                                    <vs-checkbox v-model="checkBox1">Yes</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">No</vs-checkbox>                      
                                    </li>
                                </ul>
                                </div> 
                            </div>
                        </div>
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label">  Does the job require the alien to live on the employer’s premises? </label>
                                <div class="listitems">
                                <ul class="custom-radio">
                                    <li>
                                    <vs-checkbox v-model="checkBox1">Yes</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">No</vs-checkbox>                      
                                    </li>
                                </ul>
                                </div> 
                            </div>
                        </div>
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label">  Is the application for a live-in household domestic service worker? </label>
                                <div class="listitems">
                                <ul class="custom-radio">
                                    <li>
                                    <vs-checkbox v-model="checkBox1">Yes</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">No</vs-checkbox>                      
                                    </li>
                                </ul>
                                </div> 
                            </div>
                        </div>
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label">   If Yes, have the employer and the alien executed the required employment
                                 contract and has the employer provided a copy of the contract to the alien? </label>
                                <div class="listitems">
                                <ul class="custom-radio">
                                    <li>
                                    <vs-checkbox v-model="checkBox1">Yes</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">No</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">NA</vs-checkbox>                      
                                    </li>
                                </ul>
                                </div> 
                            </div>
                        </div>
                    </div>
                </vs-col>

                <span class="form_devider"></span>

                <vs-col class="m-auto float-none" vs-lg="10" vs-sm="12">
                    <h3 class="small-header">Recruitment Information</h3>
                    <h4 class="mb-5">Occupation Type</h4>
                    <div class="vx-row">
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label">Is this application for a <strong>professional occupation</strong>, other than a college or
                                    university teacher? Professional occupations are those for which a bachelor’s
                                    degree (or equivalent) is normally required.</label>
                                <div class="listitems">
                                <ul class="custom-radio">
                                    <li>
                                    <vs-checkbox v-model="checkBox1">Yes</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">No</vs-checkbox>                      
                                    </li>
                                </ul>
                                </div> 
                            </div>
                        </div>
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label"> Is this application for a college or university teacher? 
                                    <strong>If Yes, complete questions below. </strong>
                                </label>
                                <div class="listitems">
                                <ul class="custom-radio">
                                    <li>
                                    <vs-checkbox v-model="checkBox1">Yes</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">No</vs-checkbox>                      
                                    </li>
                                </ul>
                                </div> 
                            </div>
                        </div>
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label"> Did you select the candidate using a competitive recruitment and
 selection process?
                                </label>
                                <div class="listitems">
                                <ul class="custom-radio">
                                    <li>
                                    <vs-checkbox v-model="checkBox1">Yes</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">No</vs-checkbox>                      
                                    </li>
                                </ul>
                                </div> 
                            </div>
                        </div>
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label">  Did you use the basic recruitment process for professional occupations?
                                </label>
                                <div class="listitems">
                                <ul class="custom-radio">
                                    <li>
                                    <vs-checkbox v-model="checkBox1">Yes</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">No</vs-checkbox>                      
                                    </li>
                                </ul>
                                </div> 
                            </div>
                        </div>
                    </div>
                    <h4 class="mb-5">Special Recruitment and Documentation Procedures for College and University Teachers</h4>
                    <div class="vx-row">
                        <div class="vx-col w-full md:w-1/2">
                            <div class="form_group">
                                <label class="form_label">Date Alien Selected: </label>
                                <vs-input class="w-full" />
                            </div>
                        </div>
                    </div>
                    <div class="vx-row">
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label"> Name and Date of national professional journal in which advertisement was placed: </label>
                                <vs-input class="w-full" />
                            </div>
                        </div>
                    </div>
                    <div class="vx-row">
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label"> Specify additional recruitment information in this space. Add an attachment if necessary.  </label>
                                <!-- <vs-textarea class="w-full"/> -->
                                <ckeditor  class="w-full" :editor="editor" :config="editorConfig"></ckeditor>

                            </div>
                        </div>
                    </div>
                </vs-col>

                <span class="form_devider"></span>
                <vs-col class="m-auto float-none" vs-lg="10" vs-sm="12">
                    <h3 class="small-header">Professional/Non-Professional Information</h3>
                    <div class="vx-row">
                        <div class="vx-col w-full md:w-1/2">
                            <div class="form_group">
                                <label class="form_label">Start Date for the SWA job order</label>
                                <datepicker v-model="date" name="uniquename"></datepicker>
                            </div>
                        </div>
                        <div class="vx-col w-full md:w-1/2">
                            <div class="form_group">
                                <label class="form_label">End Date for the SWA job order</label>
                                <datepicker v-model="date" name="uniquename"></datepicker>
                            </div>
                        </div>
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label">  Is there a Sunday edition of the newspaper in the area of intended employment?
                                </label>
                                <div class="listitems">
                                <ul class="custom-radio">
                                    <li>
                                    <vs-checkbox v-model="checkBox1">Yes</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">No</vs-checkbox>                      
                                    </li>
                                </ul>
                                </div> 
                            </div>
                        </div>
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label">Name of newspaper (of general circulation) in which the first advertisement was placed:</label>
                                <vs-input class="w-full" />
                            </div>
                        </div>
                        <div class="vx-col w-full md:w-1/2">
                            <div class="form_group">
                                <label class="form_label">Date of first advertisement identified in above question:</label>
                                <datepicker v-model="date" name="uniquename"></datepicker>
                            </div>
                        </div>
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label">  Name of newspaper or professional journal (if applicable) in which second advertisement was placed:
                                </label>
                                <div class="listitems">
                                <ul class="custom-radio">
                                    <li>
                                    <vs-checkbox v-model="checkBox1">Newspaper</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">Journal</vs-checkbox>                      
                                    </li>
                                </ul>
                                </div> 
                                <vs-input class="w-full" />
                            </div>
                        </div>
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label">Date of second newspaper advertisement or date of publication of journal identified in above question: </label>
                                <datepicker v-model="date" name="uniquename" class="w-full md:w-1/2"></datepicker>
                            </div>
                        </div>
                    </div>
                </vs-col>

                <span class="form_devider"></span>
                <vs-col class="m-auto float-none" vs-lg="10" vs-sm="12">
                    <h3 class="small-header"> Professional Recruitment Information</h3>
                    <div class="vx-row">
                        <div class="vx-col w-full md:w-1/2">
                            <div class="form_group">
                                <label class="form_label">Dates Advertised at Job Fair </label>
                                <date-range-picker
                                :maxDate="new Date()"
                                :autoApply="autoApply"
                                :ranges="false"
                                v-model="dateRangevalue"
                                ></date-range-picker>
                            </div>
                        </div>
                        <div class="vx-col w-full md:w-1/2">
                            <div class="form_group">
                                <label class="form_label"> Dates of On-campus Recruiting  </label>
                                <date-range-picker
                                :maxDate="new Date()"
                                :autoApply="autoApply"
                                :ranges="false"
                                v-model="dateRangevalue"
                                ></date-range-picker>
                            </div>
                        </div>
                        <div class="vx-col w-full md:w-1/2">
                            <div class="form_group">
                                <label class="form_label"> Dates Posted on Employer Web Site  </label>
                                <date-range-picker
                                :maxDate="new Date()"
                                :autoApply="autoApply"
                                :ranges="false"
                                v-model="dateRangevalue"
                                ></date-range-picker>
                            </div>
                        </div>
                        <div class="vx-col w-full md:w-1/2">
                            <div class="form_group">
                                <label class="form_label"> Dates Advertised with Trade or Professional Organization  </label>
                                <date-range-picker
                                :maxDate="new Date()"
                                :autoApply="autoApply"
                                :ranges="false"
                                v-model="dateRangevalue"
                                ></date-range-picker>
                            </div>
                        </div>
                        <div class="vx-col w-full md:w-1/2">
                            <div class="form_group">
                                <label class="form_label"> Dates Listed with Job Search Web Site  </label>
                                <date-range-picker
                                :maxDate="new Date()"
                                :autoApply="autoApply"
                                :ranges="false"
                                v-model="dateRangevalue"
                                ></date-range-picker>
                            </div>
                        </div>
                        <div class="vx-col w-full md:w-1/2">
                            <div class="form_group">
                                <label class="form_label">  Dates Listed with Private Employment Firm  </label>
                                <date-range-picker
                                :maxDate="new Date()"
                                :autoApply="autoApply"
                                :ranges="false"
                                v-model="dateRangevalue"
                                ></date-range-picker>
                            </div>
                        </div>
                        <div class="vx-col w-full md:w-1/2">
                            <div class="form_group">
                                <label class="form_label"> Dates Advertised with Employee Referral Program  </label>
                                <date-range-picker
                                :maxDate="new Date()"
                                :autoApply="autoApply"
                                :ranges="false"
                                v-model="dateRangevalue"
                                ></date-range-picker>
                            </div>
                        </div>
                        <div class="vx-col w-full md:w-1/2">
                            <div class="form_group">
                                <label class="form_label"> Dates Advertised with Campus Placement Office  </label>
                                <date-range-picker
                                :maxDate="new Date()"
                                :autoApply="autoApply"
                                :ranges="false"
                                v-model="dateRangevalue"
                                ></date-range-picker>
                            </div>
                        </div>
                        <div class="vx-col w-full md:w-1/2">
                            <div class="form_group">
                                <label class="form_label"> Dates Advertised with Local or Ethnic Newspaper  </label>
                                <date-range-picker
                                :maxDate="new Date()"
                                :autoApply="autoApply"
                                :ranges="false"
                                v-model="dateRangevalue"
                                ></date-range-picker>
                            </div>
                        </div>
                        <div class="vx-col w-full md:w-1/2">
                            <div class="form_group">
                                <label class="form_label"> Dates Advertised with Radio or TV Ads  </label>
                                <date-range-picker
                                :maxDate="new Date()"
                                :autoApply="autoApply"
                                :ranges="false"
                                v-model="dateRangevalue"
                                ></date-range-picker>
                            </div>
                        </div>
                    </div>
                </vs-col>

                <span class="form_devider"></span>
                <vs-col class="m-auto float-none" vs-lg="10" vs-sm="12">
                    <h3 class="small-header"> General Information</h3>
                    <div class="vx-row">
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label">  Has the employer received payment of any kind for the submission of this
                                    application?
                                </label>
                                <div class="listitems">
                                <ul class="custom-radio">
                                    <li>
                                    <vs-checkbox v-model="checkBox1">Yes</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">No</vs-checkbox>                      
                                    </li>
                                </ul>
                                </div> 
                            </div>
                        </div>
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label">   If Yes, describe details of the payment including the amount, date and purpose of the payment :
                                </label>
                                <vs-input class="w-full" />
                            </div>
                        </div>
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label">  Has the bargaining representative for workers in the occupation in which the
alien will be employed been provided with notice of this filing at least 30 days
but not more than 180 days before the date the application is filed? 
                                </label>
                                <div class="listitems">
                                <ul class="custom-radio">
                                    <li>
                                    <vs-checkbox v-model="checkBox1">Yes</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">No</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">NA</vs-checkbox>                      
                                    </li>
                                </ul>
                                </div> 
                            </div>
                        </div>
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label">   If there is no bargaining representative, has a notice of this filing been posted
 for 10 business days in a conspicuous location at the place of employment,
ending at least 30 days before but not more than 180 days before the date the
application is filed?
                                </label>
                                <div class="listitems">
                                <ul class="custom-radio">
                                    <li>
                                    <vs-checkbox v-model="checkBox1">Yes</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">No</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">NA</vs-checkbox>                      
                                    </li>
                                </ul>
                                </div>
                            </div>
                        </div>
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label">  Has the employer had a layoff in the area of intended employment in the
occupation involved in this application or in a related occupation within the six
months immediately preceding the filing of this application?
                                </label>
                                <div class="listitems">
                                <ul class="custom-radio">
                                    <li>
                                    <vs-checkbox v-model="checkBox1">Yes</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">No</vs-checkbox>                      
                                    </li>
                                </ul>
                                </div> 
                            </div>
                        </div>
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label">  If Yes, were the laid off U.S. workers notified and considered for the job
 opportunity for which certification is sought?
                                </label>
                                <div class="listitems">
                                <ul class="custom-radio">
                                    <li>
                                    <vs-checkbox v-model="checkBox1">Yes</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">No</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">NA</vs-checkbox>                      
                                    </li>
                                </ul>
                                </div> 
                            </div>
                        </div>
                    </div>
                </vs-col>

                <span class="form_devider"></span>
                <vs-col class="m-auto float-none" vs-lg="10" vs-sm="12">
                    <h3 class="small-header"> Alien Information </h3>
                    <div class="vx-row">
                        <div class="vx-col w-full">
                            <vx-input-group class="form-input-group">
                                <vs-input
                                name="firstname"
                                class="w-full"
                                data-vv-as="First Name"
                                label="First Name"
                                />
                                <vs-input
                                class="w-full"
                                name="middleName"
                                data-vv-as="Middle Name"
                                label="Middle Name"
                                />
                                <vs-input
                                class="w-full"
                                name="lastName"
                                data-vv-as="Last Name"
                                label="Last Name"
                                />
                            </vx-input-group>
                        </div>
                        <gcAddress></gcAddress>
                        <div class="vx-col md:w-1/2 w-full">
                            <div class="form_group ph_number">
                                <div class="vs-component">
                                <label class="form_label">Phone Number</label>
                                <VuePhoneNumberInput v-model="value" />
                                </div>
                            </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                            <div class="form_group">
                                <label class="form_label"> Country of Citizenship</label>
                                <vs-input class="w-full" />
                            </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                            <div class="form_group">
                                <label class="form_label"> Country of Birth</label>
                                <vs-input class="w-full" />
                            </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                            <div class="form_group">
                                <label class="form_label"> Alien’s Date of Birth</label>
                                <datepicker v-model="date" name="uniquename"></datepicker>
                            </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                            <div class="form_group">
                                <label class="form_label"> Class of Admission</label>
                                <vs-input class="w-full" />
                            </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                            <div class="form_group">
                                <label class="form_label"> Alien Number</label>
                                <vs-input class="w-full" />
                            </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                            <div class="form_group">
                                <label class="form_label"> Alien Admission Number (I-94)</label>
                                <vs-input class="w-full" />
                            </div>
                        </div>
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <div class="listitems">
                                    <ul class="custom-radio">
                                        <li>
                                        <vs-checkbox v-model="checkBox1">None</vs-checkbox>                      
                                        </li>
                                        <li>
                                        <vs-checkbox v-model="checkBox1">High School</vs-checkbox>                      
                                        </li>
                                        <li>
                                        <vs-checkbox v-model="checkBox1">Associate’s</vs-checkbox>                      
                                        </li>
                                        <li>
                                        <vs-checkbox v-model="checkBox1">Bachelor’s</vs-checkbox>                      
                                        </li>
                                        <li>
                                        <vs-checkbox v-model="checkBox1">Master’s</vs-checkbox>                      
                                        </li>
                                        <li>
                                        <vs-checkbox v-model="checkBox1">Doctorate</vs-checkbox>                      
                                        </li>
                                        <li>
                                        <vs-checkbox v-model="checkBox1">Other</vs-checkbox>                      
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                            <div class="form_group">
                                <label class="form_label">  If Other indicated in above question, specify</label>
                                <vs-input class="w-full" />
                            </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                            <div class="form_group">
                                <label class="form_label">  Specify major field(s) of study</label>
                                <vs-input class="w-full" />
                            </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                            <div class="form_group">
                                <label class="form_label">  Year relevant education completed</label>
                                <vs-input class="w-full" />
                            </div>
                        </div>
                        <div class="vx-col w-full md:w-1/2">
                            <div class="form_group">
                                <label class="form_label">  Institution where relevant education completed</label>
                                <vs-input class="w-full" />
                            </div>
                        </div>
                        <gcAddress></gcAddress>
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label">  Did the alien complete the training required for the requested job opportunity,
                                                            as indicated in  Job Opportunity Information?
                                </label>
                                <div class="listitems">
                                <ul class="custom-radio">
                                    <li>
                                    <vs-checkbox v-model="checkBox1">Yes</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">No</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">NA</vs-checkbox>                      
                                    </li>
                                </ul>
                                </div> 
                            </div>
                        </div>
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label">  Does the alien have the experience as required for the requested job
                                                            opportunity indicated in  Job Opportunity Information? 
                                </label>
                                <div class="listitems">
                                <ul class="custom-radio">
                                    <li>
                                    <vs-checkbox v-model="checkBox1">Yes</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">No</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">NA</vs-checkbox>                      
                                    </li>
                                </ul>
                                </div> 
                            </div>
                        </div>
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label">  Does the alien possess the alternate combination of education and experience
 as indicated in  Job Opportunity Information?
                                </label>
                                <div class="listitems">
                                <ul class="custom-radio">
                                    <li>
                                    <vs-checkbox v-model="checkBox1">Yes</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">No</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">NA</vs-checkbox>                      
                                    </li>
                                </ul>
                                </div> 
                            </div>
                        </div>
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label">  Does the alien have the experience in an alternate occupation specified in
  Job Opportunity Information? 
                                </label>
                                <div class="listitems">
                                <ul class="custom-radio">
                                    <li>
                                    <vs-checkbox v-model="checkBox1">Yes</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">No</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">NA</vs-checkbox>                      
                                    </li>
                                </ul>
                                </div> 
                            </div>
                        </div>
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label">  Did the alien gain any of the qualifying experience with the employer in a
position substantially comparable to the job opportunity requested? 
                                </label>
                                <div class="listitems">
                                <ul class="custom-radio">
                                    <li>
                                    <vs-checkbox v-model="checkBox1">Yes</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">No</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">NA</vs-checkbox>                      
                                    </li>
                                </ul>
                                </div> 
                            </div>
                        </div>
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label">   Did the employer pay for any of the alien’s education or training
 necessary to satisfy any of the employer’s job requirements for this position?
                                </label>
                                <div class="listitems">
                                <ul class="custom-radio">
                                    <li>
                                    <vs-checkbox v-model="checkBox1">Yes</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">No</vs-checkbox>                      
                                    </li>
                                </ul>
                                </div> 
                            </div>
                        </div>
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label">  Is the alien currently employed by the petitioning employer?
                                </label>
                                <div class="listitems">
                                <ul class="custom-radio">
                                    <li>
                                    <vs-checkbox v-model="checkBox1">Yes</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">No</vs-checkbox>                      
                                    </li>
                                </ul>
                                </div> 
                            </div>
                        </div>
                    </div>
                </vs-col>

                <span class="form_devider"></span>
                <vs-col class="m-auto float-none" vs-lg="10" vs-sm="12">
                    <h3 class="small-header"> Alien Work Experience </h3>
                    <h4 class="mb-5"><em>List all jobs the alien has held during the past 3 years. Also list any other experience that qualifies the alien for
the job opportunity for which the employer is seeking certification.</em></h4>
                    <div class="vx-row">
                        <div class="vx-col md:w-1/2 w-full">
                            <div class="form_group">
                                <label class="form_label">Employer Name</label>
                                <vs-input class="w-full" />
                            </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                            <div class="form_group">
                                <label class="form_label">Job Title</label>
                                <vs-input class="w-full" />
                            </div>
                        </div>
                        <gcAddress></gcAddress>
                        <div class="vx-col md:w-1/2 w-full">
                            <div class="form_group">
                                <label class="form_label">Type of Business</label>
                                <vs-input class="w-full" />
                            </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                            <div class="form_group">
                                <label class="form_label">Number of Hours Worked Per Week</label>
                                <vs-input class="w-full" />
                            </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                            <div class="form_group">
                                <label class="form_label">Start Date</label>
                                <datepicker v-model="date" name="uniquename"></datepicker>
                            </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                            <div class="form_group">
                                <label class="form_label">End Date</label>
                                <datepicker v-model="date" name="uniquename"></datepicker>
                            </div>
                        </div>
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label"> Job Details (duties performed, use of tools, machines, equipment, skills, qualifications, certifications, licenses, etc.
Include the phone number of the employer and the name of the alien’s supervisor.)</label>
                                <!-- <vs-textarea class="w-full" /> -->
                                <ckeditor class="w-full"  :editor="editor" :config="editorConfig"></ckeditor>

                            </div>
                            <button class="IB_primary-btn">Add More</button>
                        </div>
                    </div>
                </vs-col>

                <span class="form_devider"></span>
                <vs-col class="m-auto float-none" vs-lg="10" vs-sm="12">
                    <h3 class="small-header"> Alien Declaration </h3>
                    <p class="mb-5"><em><strong>I declare under penalty of perjury that Sections J and K are true and correct</strong>. I understand that to knowingly furnish
false information in the preparation of this form and any supplement thereto or to aid, abet, or counsel another to do so is
a federal offense punishable by a fine or imprisonment up to five years or both under 18 U.S.C. §§ 2 and 1001. Other
penalties apply as well to fraud or misuse of ETA immigration documents and to perjury with respect to such documents
under 18 U.S.C. §§ 1546 and 1621.</em></p>
<p class="mb-5"><em>In addition, I <strong>further declare</strong> under penalty of perjury that I intend to accept the position offered in Section H of this
application if a labor certification is approved and I am granted a visa or an adjustment of status based on this
application. </em></p>
                    <div class="vx-row">
                        <div class="vx-col w-full">
                            <vx-input-group class="form-input-group">
                                <vs-input
                                name="firstname"
                                class="w-full"
                                data-vv-as="First Name"
                                label="First Name"
                                />
                                <vs-input
                                class="w-full"
                                name="middleName"
                                data-vv-as="Middle Name"
                                label="Middle Name"
                                />
                                <vs-input
                                class="w-full"
                                name="lastName"
                                data-vv-as="Last Name"
                                label="Last Name"
                                />
                            </vx-input-group>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                            <div class="form_group">
                                <label class="form_label">Signature</label>
                                <vs-input class="w-full" />
                            </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                            <div class="form_group">
                                <label class="form_label">Date Signed</label>
                                <vs-input class="w-full" />
                            </div>
                        </div>
                    </div>
                    <small><em><strong>Note</strong> – The signature and date signed do not have to be filled out when electronically submitting to the Department of Labor for
processing, but must be complete when submitting by mail. If the application is submitted electronically, any resulting certification
MUST be signed immediately upon receipt from DOL before it can be submitted to USCIS for final processing.</em></small>
                </vs-col>

                <span class="form_devider"></span>
                <vs-col class="m-auto float-none" vs-lg="10" vs-sm="12">
                    <h3 class="small-header">Declaration of Preparer </h3>
                    <div class="vx-row">
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <div class="listitems">
                                    <h6>
                                         Was the application completed by the employer?
                                         <br>
                                         <small>If No, you must complete this section. </small>
                                    </h6>
                                <ul class="custom-radio">
                                    <li>
                                    <vs-checkbox v-model="checkBox1">Yes</vs-checkbox>                      
                                    </li>
                                    <li>
                                    <vs-checkbox v-model="checkBox1">No</vs-checkbox>                      
                                    </li>
                                </ul>
                                </div> 
                            </div>
                        </div>
                    </div>
                    <p class="mb-5"><em><strong>I hereby certify that I have prepared this application at the direct request of the employer listed in Section C and
that to the best of my knowledge the information contained herein is true and correct.</strong> I understand that to
knowingly furnish false information in the preparation of this form and any supplement thereto or to aid, abet, or counsel
another to do so is a federal offense punishable by a fine, imprisonment up to five years or both under 18 U.S.C. §§ 2 and
1001. Other penalties apply as well to fraud or misuse of ETA immigration documents and to perjury with respect to such
documents under 18 U.S.C. §§ 1546 and 1621. </em></p>
                    <div class="vx-row">
                        <div class="vx-col w-full">
                            <vx-input-group class="form-input-group">
                                <vs-input
                                name="firstname"
                                class="w-full"
                                data-vv-as="First Name"
                                label="First Name"
                                />
                                <vs-input
                                class="w-full"
                                name="middleName"
                                data-vv-as="Middle Name"
                                label="Middle Name"
                                />
                                <vs-input
                                class="w-full"
                                name="lastName"
                                data-vv-as="Last Name"
                                label="Last Name"
                                />
                            </vx-input-group>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                            <div class="form_group">
                                <label class="form_label">Title</label>
                                <vs-input class="w-full" />
                            </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                            <div class="form_group">
                                <label class="form_label">E-mail Address</label>
                                <vs-input class="w-full" />
                            </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                            <div class="form_group">
                                <label class="form_label">Signature</label>
                                <vs-input class="w-full" />
                            </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                            <div class="form_group">
                                <label class="form_label">Date Signed</label>
                                <vs-input class="w-full" />
                            </div>
                        </div>
                    </div>
                    <small><em><strong>Note</strong> –  The signature and date signed do not have to be filled out when electronically submitting to the Department of Labor for
processing, but must be complete when submitting by mail. If the application is submitted electronically, any resulting certification MUST
be signed immediately upon receipt from DOL before it can be submitted to USCIS for final processing.</em></small>
                </vs-col>

                <span class="form_devider"></span>
                <vs-col class="m-auto float-none" vs-lg="10" vs-sm="12">
                    <h3 class="small-header"> Employer Declaration </h3>
                    <p class="mb-5"><em>By virtue of my signature below, <strong>I HEREBY CERTIFY</strong> the following conditions of employment:</em></p>
                    <ol>
                        <li>The offered wage equals or exceeds the prevailing wage and I will pay at least the prevailing wage. </li>
                        <li>The wage is not based on commissions, bonuses or other incentives, unless I guarantees a wage paid on a
weekly, bi-weekly, or monthly basis that equals or exceeds the prevailing wage.</li>
                        <li>I have enough funds available to pay the wage or salary offered the alien. </li>
                        <li>I will be able to place the alien on the payroll on or before the date of the alien’s proposed entrance into the
United States.</li>
                        <li>The job opportunity does not involve unlawful discrimination by race, creed, color, national origin, age, sex,
religion, handicap, or citizenship.</li>
                        <li>The job opportunity is not:
                            <ol>
                                <li>Vacant because the former occupant is on strike or is being locked out in the course of a labor dispute
involving a work stoppage; or</li>
                                <li>At issue in a labor dispute involving a work stoppage.</li>
                            </ol>
                        </li>
                        <li>The job opportunity’s terms, conditions, and occupational environment are not contrary to Federal, state or local
law. </li>
                        <li>The job opportunity has been and is clearly open to any U.S. worker. </li>
                        <li>The U.S. workers who applied for the job opportunity were rejected for lawful job-related reasons.</li>
                        <li>The job opportunity is for full-time, permanent employment for an employer other than the alien. </li>
                    </ol>
                    <p class="mb-5 mt-5"><strong>I hereby designate</strong> the agent or attorney identified in section E (if any) to represent me for the purpose of labor
certification and, by virtue of my signature in Block 3 below, I take full responsibility for the accuracy of any
representations made by my agent or attorney. </p>
<p class="mb-5"><strong>I declare</strong> under penalty of perjury that I have read and reviewed this application and that to the best of my knowledge
the information contained herein is true and accurate. I understand that to knowingly furnish false information in the
preparation of this form and any supplement thereto or to aid, abet, or counsel another to do so is a federal offense
punishable by a fine or imprisonment up to five years or both under 18 U.S.C. §§ 2 and 1001. Other penalties apply as
well to fraud or misuse of ETA immigration documents and to perjury with respect to such documents under 18 U.S.C.
§§ 1546 and 1621.</p>
                    <div class="vx-row">
                        <div class="vx-col w-full">
                            <vx-input-group class="form-input-group">
                                <vs-input
                                name="firstname"
                                class="w-full"
                                data-vv-as="First Name"
                                label="First Name"
                                />
                                <vs-input
                                class="w-full"
                                name="middleName"
                                data-vv-as="Middle Name"
                                label="Middle Name"
                                />
                                <vs-input
                                class="w-full"
                                name="lastName"
                                data-vv-as="Last Name"
                                label="Last Name"
                                />
                            </vx-input-group>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                            <div class="form_group">
                                <label class="form_label">Title</label>
                                <vs-input class="w-full" />
                            </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                            <div class="form_group">
                                <label class="form_label">Signature</label>
                                <vs-input class="w-full" />
                            </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                            <div class="form_group">
                                <label class="form_label">Date Signed</label>
                                <vs-input class="w-full" />
                            </div>
                        </div>
                    </div>
                    <small><em><strong>Note</strong> – The signature and date signed do not have to be filled out when electronically submitting to the Department of
Labor for processing, but must be complete when submitting by mail. If the application is submitted electronically, any
resulting certification MUST be signed immediately upon receipt from DOL before it can be submitted to USCIS for final
processing.</em></small>
                </vs-col>

                <span class="form_devider"></span>
                <vs-col class="m-auto float-none" vs-lg="10" vs-sm="12">
                    <h3 class="small-header"> U.S. Government Agency Use Only  </h3>
                    <p class="mb-5">Pursuant to the provisions of Section 212 (a)(5)(A) of the Immigration and Nationality Act, as amended, I hereby certify
that there are not sufficient U.S. workers available and the employment of the above will not adversely affect the wages
and working conditions of workers in the U.S. similarly employed. </p>
                    <div class="vx-row">
                        <div class="vx-col md:w-1/2 w-full">
                            <div class="form_group">
                                <label class="form_label">This Certification is Valid</label>
                                <date-range-picker
                                :maxDate="new Date()"
                                :autoApply="autoApply"
                                :ranges="false"
                                v-model="dateRangevalue"
                                ></date-range-picker>
                            </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                            <div class="form_group">
                                <label class="form_label">Signature of Certifying Officer and Date</label>
                                <vs-input class="w-full" />
                            </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                            <div class="form_group">
                                <label class="form_label">Signed</label>
                                <vs-input class="w-full" />
                            </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                            <div class="form_group">
                                <label class="form_label">Case Number</label>
                                <vs-input class="w-full" />
                            </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                            <div class="form_group">
                                <label class="form_label">Filing Date</label>
                                <datepicker v-model="date" name="uniquename"></datepicker>
                            </div>
                        </div>
                    </div>
                </vs-col>

                <span class="form_devider"></span>
                <vs-col class="m-auto float-none" vs-lg="10" vs-sm="12">
                    <h3 class="small-header"> OMB Information </h3>
                    <p class="mb-5">Persons are not required to respond to this collection of information unless it displays a currently valid OMB
                        control number. </p>
                    <p class="mb-5">Respondent’s reply to these reporting requirements is required to obtain the benefits of permanent
employment certification (Immigration and Nationality Act, Section 212(a)(5)). Public reporting burden for this
collection of information is estimated to average 2 hours per response, including the time for reviewing
instructions, searching existing data sources, gathering and maintaining the data needed, and completing
and reviewing the collection of information. Send comments regarding this burden estimate to the 2IILFH of
Foreign Labor Certification * U.S. Department of Labor * 200 Constitution Ave. Box 12-200, NW
Washington, DC * 20210. 
                    <br>
                    <strong>Do NOT send the completed application to this address.</strong>
</p>  
                </vs-col>

                <span class="form_devider"></span>
                <vs-col class="m-auto float-none" vs-lg="10" vs-sm="12">
                    <h3 class="small-header">  Privacy Statement Information </h3>
                    <p class="mb-5">In accordance with the Privacy Act of 1974, as amended (5 U.S.C. 552a), you are hereby notified
that the information provided herein is protected under the Privacy Act. The Department of Labor
(Department or DOL) maintains a System of Records titled Employer Application and Attestation
File for Permanent and Temporary Alien Workers (DOL/ETA-7) that includes this record. </p>
                    <p class="mb-5">Under routine uses for this system of records, case files developed in processing labor
certification applications, labor condition applications, or labor attestations may be released as
follows: in connection with appeals of denials before the DOL Office of Administrative Law
Judges and Federal courts, records may be released to the employers that filed such
applications, their representatives, to named alien beneficiaries or their representatives, and to
the DOL Office of Administrative Law Judges and Federal courts; and in connection with
administering and enforcing immigration laws and regulations, records may be released to such
agencies as the DOL Office of Inspector General, Employment Standards Administration, the
Department of Homeland Security, and the Department of State.</p>
<p class="mb-5">Further relevant disclosures may be made in accordance with the Privacy Act and under the
following circumstances: in connection with federal litigation; for law enforcement purposes; to
authorized parent locator persons under Pub. L. 93-647; to an information source or public
authority in connection with personnel, security clearance, procurement, or benefit-related
matters; to a contractor or their employees, grantees or their employees, consultants, or
volunteers who have been engaged to assist the agency in the performance of Federal activities;
for Federal debt collection purposes; to the Office of Management and Budget in connection with
its legislative review, coordination, and clearance activities; to a Member of Congress or their staff
in response to an inquiry of the Congressional office made at the written request of the subject of
the record; in connection with records management; and to the news media and the public when
a matter under investigation becomes public knowledge, the Solicitor of Labor determines the
disclosure is necessary to preserve confidence in the integrity of the Department, or the Solicitor
of Labor determines that a legitimate public interest exists in the disclosure of information, unless
the Solicitor of Labor determines that disclosure would constitute an unwarranted invasion of
personal privacy.</p> 
                </vs-col>
        </div>
      </form>
    </div>

                 </div>
            </div>
            <div class="questionnaire_footer">
                <div class="d-flex">
                    <vs-button v-if="selectedTab != 'caseDetails'" @click="backStup()" class="questionnaire_btn" type="filled">Back</vs-button>
                </div>
                <div class="d-flex">
                    <vs-button @click="formSubmitted(true)" class="save questionnaire_btn" type="filled">Save</vs-button>
                    <vs-button color="success" v-if="selectedTab == 'dependentsInfo'" @click="openPreviewShow()" class="save questionnaire_btn" type="filled">Review & Submit
                    </vs-button>
                    <template v-else>
                        <vs-button color="success" v-if="
                  selectedTab == 'documents' &&
                  checkProperty(beneficiaryInfo, 'maritalStatus', 'id') != 2
                " @click="openPreviewShow()" class="save questionnaire_btn" type="filled">Review & Submit
                        </vs-button>
                        <vs-button v-else @click="nextStup()" class="questionnaire_btn" type="filled">Next</vs-button>
                    </template>
                </div>
            </div>
        </div>
    </div>



    <!-----showChildForm
    toggleChildForm(false)

    -->

   

</div>
</template>

<script>
import {
    FormWizard,
    TabContent
} from "vue-form-wizard";
import "vue-form-wizard/dist/vue-form-wizard.min.css";
import DateRangePicker from "vue2-daterange-picker";

import 'vue2-daterange-picker/dist/vue2-daterange-picker.css'
import Datepicker from "vuejs-datepicker-inv";
import moment from "moment";
import PhoneMaskInput from "vue-phone-mask-input";
import JQuery from "jquery";
import {
    TheMask
} from "vue-the-mask";
import FileUpload from "vue-upload-component/src";
import _ from "lodash";
import Vue from "vue";
import VuePhoneNumberInput from "vue-phone-number-input";
import "vue-phone-number-input/dist/vue-phone-number-input.css";
import {
    Trash2Icon
} from "vue-feather-icons";
import DatePickerField from "@/views/common/datePickerField.vue";
//import caseQuestionnaireDocs from "./caseQuestionnaireDocs.vue";
//import addressFields from "@/views/common/addressForm.vue";
//import PetitionDetails from "@/views/PetitionDetails.vue";
//import addressFields from "@/views/forms/fields/address.vue";
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import gcAddress from "@/views/forms/gcAddress.vue";
import {
    XIcon
} from "vue-feather-icons";

Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
export default {
    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
    data() {
        return {
            editor: ClassicEditor,
            editorConfig: {
                toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
            },
            autoApply:'',
             dateRangevalue:{"startDate":null,'endDate':null},
            Employee: false,
            value: null,
            date:null,
            options: ["list", "of", "options"],


 

            settings: {
                swipeEasing: true,
            },
              
        };
    },
   
   
    
    
    components: {
        XIcon,
        VuePerfectScrollbar,
      //  PetitionDetails,
        //addressFields, 
        VuePhoneNumberInput,
        DateRangePicker,
        Datepicker,
        PhoneMaskInput,
        TheMask,
        FileUpload,
        Trash2Icon,
        gcAddress,
    },
    
    
};
</script>
