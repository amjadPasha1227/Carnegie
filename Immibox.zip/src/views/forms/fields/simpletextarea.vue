<template>
<div class="vx-col  w-full" :class="wrapclass" v-if="canRenderField(tplkey,fieldsArray,display ,tplsection,fieldName)">
    <div class="form_group">
        <label class="form_label">{{label}}<em v-if="checkFieldIsRequired({'key':tplkey,'section':tplsection, 'fieldsArray':fieldsArray, 'required':required })">*</em></label>
        <vs-textarea :name="fieldName+cid" @input="updateData()" v-model="value" v-validate="checkFieldIsRequired({'key':tplkey,'section':tplsection, 'fieldsArray':fieldsArray, 'required':required })? 'required|'+datatype : datatype "  class="w-full" :data-vv-as="vvas?vvas:placeHolder" />
      <p v-show="errors.has((formscope!=''?formscope+'.':'')+fieldName+cid)" class="text-danger text-sm">{{ errors.first((formscope!=''?formscope+'.':'')+fieldName+cid) }}</p>
    </div>
</div>
</template>

<script>
export default {
    inject: ["parentValidator"],
    props: {
          display: {
            type: Boolean,
            default: false,
        },
         fieldsArray:Array,
        vvas:{
        type:String,
            default:""
        },
        wrapclass:{
        type:String,
            default:"md:w-1/2"
        },
        datatype:{
            type:String,
            default:""
        },
         cid: {
            type: String,
            default: null,
        },
        formscope: {
            type: String,
            default: null
        },
        value: null,
        label: {
            type: String,
            default: null,
        },
        fieldName: {
            type: String,
            default: null,
        },
        tplsection:{
            type: String,
            default: null,
        },
        tplkey:{
            type: String,
            default: null,
        },
        placeHolder: {
            type: String,
            default: null,
        },
        required: {
            type: Boolean,
            default: false,
        }
    },
    created() {
        this.$validator = this.parentValidator;
    },
    
  methods: {
    updateData() {
      this.$emit('input', this.value)
    }
  }
};
</script>
