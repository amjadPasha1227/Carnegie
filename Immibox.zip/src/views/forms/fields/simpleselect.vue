<template>
<div class="vx-col  w-full" :class="wrapclass" v-if="canRenderField(tplkey,fieldsArray,display ,tplsection,fieldName)">
    <div class="form_group">
        <label class="form_label">{{label}}<em v-if="checkFieldIsRequired({'key':tplkey,'section':tplsection, 'fieldsArray':fieldsArray, 'required':required,'notRequired':notRequired })">*</em></label>
        <div class="con-select w-full">

            <multiselect v-if="listContainsId" @input=updateData() :name="fieldName+cid"
                v-validate="checkFieldIsRequired({'key':tplkey,'section':tplsection, 'fieldsArray':fieldsArray, 'required':required ,'notRequired':notRequired })? 'required':'' "
                 v-model="value" :show-labels="false"
                  track-by="id" 
                  :label="selectLabelItem"
                :data-vv-as="vvas?vvas:placeHolder" 
                :placeholder="placeHolder" 
                :options="optionslist" 
                :disabled="isDisabled"
                :searchable="true" 
                :allow-empty="!required"
                :multiple="multiple"
                :close-on-select="closeOnSelect"
                >

                    <template  v-slot:option="{ option }">
                    <!-- You can access the option's properties and use them to display custom text -->
                    <div v-if="showOptionItemStatus && !checkProperty(option ,'status')" > {{ option.name }} <small class="option-item-status">(Old SOC Code)</small>
                    </div>
                    </template>
            </multiselect>
            <multiselect v-else @input=updateData() :name="fieldName+cid"
                v-validate="checkFieldIsRequired({'key':tplkey,'section':tplsection, 'fieldsArray':fieldsArray, 'required':required,'notRequired':notRequired })? 'required':'' "
                 v-model="value" :show-labels="false"
                 :disabled="isDisabled"
                :data-vv-as="vvas?vvas:placeHolder" 
                :placeholder="placeHolder" 
                :options="optionslist" 
                :searchable="true" 
                :allow-empty="!required"
                :multiple="multiple"
                >
            </multiselect>

        </div>
        <p v-show="errors.has((formscope!=''?formscope+'.':'')+fieldName+cid)" class="text-danger text-sm">{{ errors.first((formscope!=''?formscope+'.':'')+fieldName+cid) }}</p>
    </div>
</div>
</template>

<script>

import * as _ from "lodash";
export default {
    inject: ["parentValidator"],
   
    props: {
        closeOnSelect:{
            type: Boolean,
            default: true,
        },
        showOptionItemStatus:{
            type: Boolean,
            default: false,
        },
        multiple:{
            type: Boolean,
            default: false,
        },
        isDisabled:{
            type: Boolean,
            default: false,
        },
        listContainsId: {
            type: Boolean,
            default: true,
        },
          display: {
            type: Boolean,
            default: false,
        },
        notRequired:{
            type: Boolean,
            default: false,
        },
         fieldsArray:Array,
        vvas: {
            type: String,
            default: ""
        },
        optionslist: {
            type: Array,
            default () {
                return []
            }
        },
        wrapclass: {
            type: String,
            default: "md:w-1/2"
        },
        datatype: {
            type: String,
            default: ""
        },
        cid: {
            type: String,
            default: null,
        },
        formscope: {
            type: String,
            default: null
        },
        value: null,
        label: {
            type: String,
            default: null,
        },
        fieldName: {
            type: String,
            default: null,
        },
        tplsection:{
            type: String,
            default: null,
        },
        tplkey:{
            type: String,
            default: null,
        },
        placeHolder: {
            type: String,
            default: null,
        },
        required: {
            type: Boolean,
            default: false,
        },
        loaded: {
            type: Boolean,
            default: false,
        }
    },
    created() {
        this.$validator = this.parentValidator;
    },
    mounted() {

        this.setWatchers();

        let socoptionslist = _.filter(this.optionslist ,(item)=>{

            return _.has( item ,"socTiteleWithDesignation");
         });

         if(socoptionslist && socoptionslist.length>0){
            this.selectLabelItem ="socTiteleWithDesignation";
         }
         //alert(socoptionslist.length)


    },
    methods: {
updateData(){

      this.$emit('input', this.value)

},
        setWatchers() {
            this.$watch('value', function () {
                if (this.loaded) {
                    this.$emit('input', this.value)
                    this.$emit('changeselect', this.value)
                } else {

                    this.loaded = true
                }

            });

            if (this.value == null) {
                this.loaded = true
            }
        }

    },
    data:function () {
        return {
            selectLabelItem:'name'
        }
    }
    
};
</script>
