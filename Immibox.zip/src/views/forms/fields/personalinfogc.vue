<template>
<vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12">
    <div class="form-container pt-5">
        <div class="vx-row">

            

        
            <immiyesorno  wrapclass="rmb10 yesnomar" :fieldsArray="fieldsArray" v-model="value.adjustmentStatusToPermResidenceI485" fieldName="spouse_h4_ead_required" label="Adjustment of status to Permanent Residency (Form I-485) required for spouse?"></immiyesorno>
            <div class="divider full-divider mb-10"></div>

            <div class="vx-col w-full">
                <vx-input-group class="form-input-group">
                    <immiInput :fieldsArray="fieldsArray" cid="benf" :formscope="formscope" v-model="value.firstName" :required="true" fieldName="spouse_first_name" label="First Name" placeHolder="First Name" />
                    <immiInput :fieldsArray="fieldsArray" cid="benm" :formscope="formscope" v-model="value.middleName" :required="false" fieldName="spouse_middle_name" label="Middle Name" placeHolder="Middle Name" />
                    <immiInput :fieldsArray="fieldsArray" cid="benl" :formscope="formscope" v-model="value.lastName" :required="true" fieldName="spouse_last_name" label="Last Name" placeHolder="Last Name" />
                </vx-input-group>
            </div>

            <div class="vx-col w-full mb-10" >
                <div class="d-flex align-center">
                    <a class="mr-3">
                        Have you used any other names previously?
                    </a>
                    <vs-switch v-model="value.hasOtherNames" @input="resetOtherNames(value.hasOtherNames)">
                        <span slot="on">Yes</span>
                        <span slot="off">No</span>
                    </vs-switch>
                </div>
            </div>

            <template v-if="value && value.hasOtherNames ">
                <div class="vx-col w-full" v-for="(item, ind) in value['otherNames']" :key="ind">
                    <vx-input-group class="form-input-group delete-rows-cst">
                        <immiInput :formscope="formscope" :cid="'benf'+ind" v-model="item.firstName" :required="true" fieldName="spouse_last_name" label="First Name" placeHolder="First Name" />
                        <immiInput :formscope="formscope" :cid="'benm'+ind" v-model="item.middleName" :required="false" fieldName="spouse_middle_name" label="Middle Name" placeHolder="Middle Name" />
                        <immiInput :formscope="formscope" :cid="'benl'+ind" v-model="item.lastName" :required="item.firstName!=null && item.firstName!=''" fieldName="spouse_last_name" label="Last Name" placeHolder="Last Name" />
                        <div class="delete" v-if="ind > 0" @click="removeOtherName(ind)">
                            <a>
                                <trash-2-icon size="1.5x" name="deletebenflm" class="custom-class"></trash-2-icon>
                            </a>
                        </div>
                    </vx-input-group>
                    <a class="add-more add-more-names" v-if="value['otherNames'].length - 1 ==ind" @click="addOtherNames()"><span>+</span>Add</a>
                </div>
            </template>

            <immiInput :display="true" :fieldsArray="fieldsArray" datatype="email" cid="benfemail" :formscope="formscope" v-model="value.email" :required="true" fieldName="spouse_email" label="Email" placeHolder="Email" />


            <datepickerField :display="true" :fieldsArray="fieldsArray" :dateEnableTo="startEligibleDate" :validationRequired="true" v-model="value.dateOfBirth" :formscope="formscope" fieldName="spouse_dob" label="Date of Birth" />
            <selectField :display="true":fieldsArray="fieldsArray" @input="changeBfProvince" :required="true" :optionslist="countries" v-model="value.countryOfBirthDetails" :formscope="formscope" fieldName="spouse_cob" label="Country of Birth" placeHolder="Country of Birth" />
           
            <selectField :display="true" :fieldsArray="fieldsArray" @input="value.provinceOfBirth = value.provinceOfBirthDetails.id" :required="true" v-if="bfeprovinceStates.length > 0" :optionslist="bfeprovinceStates" v-model="value.provinceOfBirthDetails" :formscope="formscope" fieldName="spouse_provinceOfBirth" label="Province of Birth" placeHolder="Province of Birth" />
            <immiInput :display="true":fieldsArray="fieldsArray" cid="benflocationOfBirth" :formscope="formscope" v-model="value.locationOfBirth" :required="true" fieldName="spouse_locationOfBirth" label="Location of Birth" placeHolder="Location of Birth" />
            <selectField :display="true" :fieldsArray="fieldsArray" @input="value.countryOfCitizenship = value.countryOfCitizenshipDetails.id" :required="true" :optionslist="countries" v-model="value.countryOfCitizenshipDetails" :formscope="formscope" fieldName="spouse_nationality" label="Country of Citizenship" placeHolder="Country of Citizenship" />

            <immiInput  :display="true" :fieldsArray="fieldsArray" cid="benI94" datatype="max:15" :formscope="formscope" v-model="value.I94" :required="value.currentlyInUS?true:false" fieldName="spouse_i94" label="I-94 Number" placeHolder="I-94 Number" />
            <datepickerField :display="true" :fieldsArray="fieldsArray" :validationRequired="value.I94?true:false"  v-model="value.I94ExpiryDate" :formscope="formscope" :dateEnableFrom="featureDates" fieldName="spo_I94ExpiryDate" label="I-94 Expiry Date" />

            
            <immiPhone :display="true" @updatephoneCountryCode="updatephoneCountryCode" :fieldsArray="fieldsArray" :countrycode="value.phoneCountryCode.countryCode" cid="phoneCountryCode" :formscope="formscope" v-model="value.phoneNumber" :required="true" fieldName="spouse_phone_number" label="Phone Number" placeHolder="Phone Number" />

<immiInput :display="true" :fieldsArray="questionnaireDetails"  cid="weight"  :formscope="formscope" v-model="value.weight" :required="true" fieldName="weight" label="Weight" placeHolder="Weight" />
                                            <selectField :display="true" :fieldsArray="questionnaireDetails"  :required="true" :optionslist="races_list" v-model="value.race"  :formscope="formscope" fieldName="race" label="Race" placeHolder="Race" />
                                            <selectField :display="true" :fieldsArray="questionnaireDetails"  :required="true" :optionslist="hair_colorsList" v-model="value.hairColor"  :formscope="formscope" fieldName="hairColor" label="Hair Color" placeHolder="Hair Color" />
                                            <selectField :display="true" :fieldsArray="questionnaireDetails"  :required="true" :optionslist="eye_colorList" v-model="value.eyeColor"  :formscope="formscope" fieldName="eyeColor" label="Eye Color" placeHolder="Eye Color" />
                                           

            <div class="vx-col w-full" v-if="canRenderField('spouse_passport_number',fieldsArray) ||  canRenderField('spo_passportIssuedDate',fieldsArray) ||  canRenderField('spouse_passport_expiry_date',fieldsArray)  ">
                <h3 class="small-header">Passport</h3>
            </div>
            <immiInput  :display="true" :fieldsArray="fieldsArray" datatype="alpha_num|max:15" cid="benfpassportNumber" :formscope="formscope" v-model="value.passportNumber" :required="true" fieldName="spouse_passport_number" label="Passport Number" placeHolder="Passport Number" />
            <datepickerField :display="true" :fieldsArray="fieldsArray" :validationRequired="value.currentlyInUS || value.passportNumber" v-model="value.passportIssuedDate" :formscope="formscope" fieldName="spo_passportIssuedDate" :dateEnableTo="currentDate" label="Passport Issued Date" />
            <datepickerField :display="true" :fieldsArray="fieldsArray"  :validationRequired="value.currentlyInUS || value.passportNumber" v-model="value.passportExpiryDate" :formscope="formscope" :dateEnableFrom="value.passportIssuedDate"  fieldName="spouse_passport_expiry_date" label="Passport Expiry Date" />

            <datepickerField :display="true" :fieldsArray="fieldsArray" :dateEnableTo="currentDate" :validationRequired="false" v-model="value.lastArrivalDate" :formscope="formscope" fieldName="spouse_date_of_last_arrival" label="Date of Last Arrival" />

            <selectField :display="true" :fieldsArray="fieldsArray" @input="value.currentStatus = value.currentStatusDetails.id" :required="value.currentlyInUS || value.passportNumber" :optionslist="petition.visaStatusList" v-model="value.currentStatusDetails" :formscope="formscope" fieldName="spouse_current_status" label="Current Status" vvas="Current Status" placeholder="Current Status" />
            <datepickerField :display="true" :fieldsArray="fieldsArray" :dateEnableFrom="value.passportIssuedDate"  :validationRequired="value.currentlyInUS || value.passportNumber" v-model="value.statusExpiryDate" :formscope="formscope" fieldName="spouse_status_expiry_date" label="Current Status Expiry Date" />

      

            <immiMask :display="true" :fieldsArray="fieldsArray" :patren="['### - ## - ####']" datatype="min:9|max:9" wrapclass="md:w-1/2" cid="spouse_ssn" :formscope="formscope" v-model="value.SSN" :required="false" fieldName="spouse_ssn" label="Social Security number (if applicable)" vvas="Social Security number" placeHolder="123 - 45 - 6789" />
            <immiInput  :display="true" :fieldsArray="fieldsArray" datatype="alpha_num|max:9" cid="spo_alienNumber" :formscope="formscope" v-model="value.alienNumber" fieldName="spo_alienNumber" label="Your Alien Number (if applicable)" placeHolder="Alien Number" />


        </div>
    </div>
</vs-col>
</template>

<script>
import genderField from '@/views/forms/fields/gender.vue'
import immiInput from "@/views/forms/fields/simpleinput.vue";
import {
    Trash2Icon
} from "vue-feather-icons";
import addressField from "@/views/forms/fields/address.vue";
import datepickerField from "@/views/forms/fields/datepicker.vue";
import selectField from "@/views/forms/fields/simpleselect.vue";
import immiPhone from "@/views/forms/fields/phonenumber.vue";
import immiMask from "@/views/forms/fields/maskinput.vue";
import immiyesorno from "@/views/forms/fields/yesorno.vue";
import immiuploader from "@/views/forms/fields/fileupload.vue";
import immipriorstay from "@/views/forms/fields/priorstay.vue";
import immitextarea from "@/views/forms/fields/simpletextarea.vue";
import immieducations from "@/views/forms/fields/educations.vue";
import immiswitchyesno from "@/views/forms/fields/switchyesno.vue";
//import Datepicker from "vuejs-datepicker-inv";
import casedocumentslist from "@/views/common/casedocuments.vue";
import immiemployment from "@/views/forms/fields/employment.vue";
import moment from "moment";
import petitionsinformation from "@/views/forms/fields/petitionsinformation.vue";
export default {
    inject: ["parentValidator"],
    props: {
        petition: Object,
        countries: Array,
        display: {
            type: Boolean,
            default: false,
        },
        fieldsArray: Array,
        vvas: {
            type: String,
            default: ""
        },
        wrapclass: {
            type: String,
            default: "md:w-1/2"
        },
        datatype: {
            type: String,
            default: ""
        },
        cid: {
            type: String,
            default: null,
        },
        formscope: {
            type: String,
            default: null
        },
        value: null,
        label: {
            type: String,
            default: null,
        },
        fieldName: {
            type: String,
            default: null,
        },
        placeHolder: {
            type: String,
            default: null,
        },
        required: {
            type: Boolean,
            default: false,
        },
        races_list:Array,
        assestsList:Array,
        liability_list:Array,
        hair_colorsList:Array,
        eye_colorList:Array,
        visastatuses:Array

    },
    created() {
        this.$validator = this.parentValidator;
    },

    components: {
         //Datepicker,
        genderField,
        immiInput,
        addressField,
        Trash2Icon,
        datepickerField,
        selectField,
        immiPhone,
        immiMask,
        immiyesorno,
        immiuploader,
        immipriorstay,
        immitextarea,
        immieducations,
        immiswitchyesno,
        casedocumentslist,
        immiemployment,
        petitionsinformation
    },
    data() {
        return {
            consularProcessingValidator:'',
            featureDates:null,
                        startEligibleDate: new Date().setFullYear(new Date().getFullYear() - 18),
              currentDate: new Date(),
            bfeprovinceStates: []
        };
    },
    mounted() {
        this.value.relationship ="Spouse"
        if (this.value.countryOfBirthDetails && this.value.countryOfBirth != null) {

            this.loadStatesByCountry('bfeprovinceStates', this.value.countryOfBirth)

        }
            this.featureDates = new Date();

           let currentStatus = this.value.currentStatus;
            if (currentStatus != null) {
                this.value.currentStatusDetails = _.find(this.petition.visaStatusList, function (item) {

                    return item.id == currentStatus
                })
            }
            setTimeout(()=>{
                if(this.value['adjustmentOfI485Status'] || this.value['consularProcessing']){
                this.consularProcessingValidator ='consularProcessingValidator';
                }
               
            });
    },
    methods: {
        changedAdjustmentOfI485Status(val){
           
            if(this.value['adjustmentOfI485Status']){

                this.value.consularProcessing = false;
            }
            this.consularProcessingValidator ='';

            if(this.value['adjustmentOfI485Status'] || this.value['consularProcessing']){
                this.consularProcessingValidator ='adjustmentOfI485Status';
            }
            //this.value.consularProcessing = true;
           // this.value['adjustmentOfI485Status'] =false

        },
        changedConsularProcessing(val){
         
            //this.value.consularProcessing = true;
           // this.value['adjustmentOfI485Status'] =false
           if(this.value['consularProcessing']){
                this.value.adjustmentOfI485Status = false;
            }
            this.consularProcessingValidator ='';
            if(this.value['adjustmentOfI485Status'] || this.value['consularProcessing']){
                this.consularProcessingValidator ='adjustmentOfI485Status';
            }

        },
        
        updatephoneCountryCode(data){
            this.value.phoneCountryCode = data;
        },
        loadStatesByCountry(model, countryId) {

            this.$store.dispatch("getstates", countryId).then((response) => {
                switch (model) {
                    case "bfeprovinceStates":
                        this.bfeprovinceStates = response;
                        break;
                }

            });

        },
        changeBfProvince(value) {
            this.value.countryOfBirth = this.value.countryOfBirthDetails.id;
            this.bfeprovinceStates = [];
            this.value.provinceOfBirth = null;
            this.value.provinceOfBirthDetails = null;
            this.loadStatesByCountry('bfeprovinceStates', value.id)
        },
        setOutsideAddress() {

            if (this.value.currentlyInUS) {
                this.value.addressOutsideUS = {
                    line1: null,
                    line2: null,
                    aptType: null,
                    locationId: null,
                    locationDetails: null,
                    stateId: null,
                    stateDetails: null,
                    countryId: null,
                    countryDetails: null,
                    zipcode: null
                };
            } else {

                this.value.addressOutsideUS = null;
            }

        },
        addOtherNames() {
            let item = {
                firstName: "",
                middleName: "",
                lastName: ""
            };
            this.value["otherNames"].push(item);
        },
        removeOtherName(index) {
            this.value["otherNames"].splice(index, 1);
        },
        resetOtherNames($event) {
            this.value["otherNames"] = [];
            this.addOtherNames();

        },
        updateData() {
            this.$emit('input', this.value)
        }
    }
};
</script>
