<template>
<div>

    <div class="" :class="{'form-container':addFormContainerCls}" v-if="countries && countries.length > 0">

        <div class="vx-row">
            <div class="vx-col md:w-1/2 w-full" v-if="showLane1">
                <div class="form_group">
                    <vs-input :name="'line1' + cid" v-model="value.line1" class="w-full" data-vv-as="Street Address" :label="'Street Address'+( validationRequired?'*':'')" v-validate="{'required':validationRequired}" />

                    <span class="text-danger text-sm" v-show="errors.has((formscope!=''?formscope+'.':'')+'line1' + cid)">{{ errors.first((formscope!=''?formscope+'.':'')+"line1" + cid) }}</span>
                </div>
            </div>

            <div class="vx-col md:w-1/2 w-full" v-if="showLane2">
                <div class="form_group">
                    <label class="form_label">Apt, Suite</label>
                    <template v-if="showaptType">
                        <div class="address-suite">
                            <ul class="demo-alignment custom-radio" vs-type="flex" vs-align="center">
                                <li>
                                    <vs-checkbox :id="'workLocation_'+cid" name="aptType1" v-model="aptType1" @change="setaptType($event,'APT')">Apt</vs-checkbox>
                                </li>
                                <li>
                                    <vs-checkbox :id="'workLocation_'+cid" name="aptType2" @change="setaptType($event,'STE')" v-model="aptType2">Ste</vs-checkbox>
                                </li>
                                <li>
                                    <vs-checkbox :id="'workLocation_'+cid" name="aptType3" @change="setaptType($event,'FLR')" v-model="aptType3">Flr</vs-checkbox>
                                </li>
                            </ul>
                            <vs-input :name="'line2' + cid" v-model="value.line2" class="" data-vv-as="Apt, Suite" />
                        </div>
                    </template>
                    <template v-else>

                        <vs-input :name="'line2' + cid" v-model="value.line2" class="w-full" data-vv-as="Apt, Suite" />

                    </template>
                    <span class="text-danger text-sm" v-show="errors.has('line2'+cid)">{{ errors.first('line2'+cid) }}</span>

                </div>

                <span class="text-danger text-sm" v-show="errors.has((formscope!=''?formscope+'.':'')+'line2' + cid)">{{ errors.first((formscope!=''?formscope+'.':'')+"line2" + cid) }}</span>
            </div>

            <div class="vx-col md:w-1/2 w-full" v-if="showCountry">
                <div class="form_group">
                    <div class="con-select select-large">
                        <label v-if="!placeOnly" class="form_label">Country<em v-if="validationRequired">*</em></label>
                        <label v-if="placeOnly" class="form_label">{{
              placeOnlyTitle
            }}</label>

                        <multiselect :name="'country' + cid" v-model="value.countryDetails" :show-labels="false" track-by="id" label="name" :ref="'refcountry'+cid" data-vv-as="Country" placeholder="Select Country" :options="countries" :searchable="true" :allow-empty="false" :disabled="disableCountry" v-validate="{'required':validationRequired}" @select="selectedCountry($event)">
                            <span slot="noResult">No Country Found</span>
                        </multiselect>
                    </div>

                    <span class="text-danger text-sm" v-show="errors.has((formscope!=''?formscope+'.':'')+'country' + cid)">{{ errors.first((formscope!=''?formscope+'.':'')+"country" + cid) }}</span>
                </div>
            </div>

            <div class="vx-col md:w-1/2 w-full" v-if="showState">
                <div class="form_group">
                    <div class="con-select select-large">
                        <label v-if="!placeOnly" class="form_label">State<em v-if="validationRequired">*</em></label>
                        <label v-if="placeOnly" class="form_label">&nbsp;</label>

                        <multiselect :name="'state' + cid" v-model="value.stateDetails" :disabled="
                !value.countryDetails ||
                value.countryId == undefined ||
                states.length == 0
              " :show-labels="false" track-by="id" label="name" data-vv-as="State" placeholder="Select State" :options="states" :searchable="true" :allow-empty="false" @select="selectedState($event)" v-validate="{'required':validationRequired}">
                            <span slot="noResult">No Sate Found</span>
                        </multiselect>
                    </div>

                    <span class="text-danger text-sm" v-show="errors.has((formscope!=''?formscope+'.':'')+'state' + cid)">{{ errors.first((formscope!=''?formscope+'.':'')+"state" + cid) }}</span>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full" v-if="showCity">
                <div class="form_group city-form">
                    <div class="con-select select-large">
                        <label v-if="!placeOnly" class="form_label">City<em v-if="validationRequired">*</em></label>
                        <label v-if="placeOnly" class="form_label">&nbsp;</label>

                        <multiselect :name="'location' + cid" v-model="value.locationDetails" :disabled="
                !value.stateDetails ||
                value.stateId == undefined ||
                locations.length == 0
              " :show-labels="false" track-by="id" label="name" data-vv-as="City" tag-placeholder="Add" :taggable="true" @select="selectedLocation" @tag="addLocation" placeholder="Select City" :options="locations" :searchable="true" :allow-empty="false" v-validate="{'required':validationRequired}">
                            <span slot="noResult">No Locations Found</span>
                        </multiselect>
                    </div>

                    <span class="text-danger text-sm" v-show="errors.has((formscope!=''?formscope+'.':'')+'location' + cid)">{{ errors.first((formscope!=''?formscope+'.':'')+"location" + cid) }}</span>
                </div>
            </div>

            <div class="vx-col md:w-1/2 w-full" v-if="showZip">
                <div class="form_group">
                    <label class="form_label">Zip Code<em v-if="validationRequired">*</em></label>
                    <vs-input v-if="validationRequired" :name="'zipcode' + cid" v-model="value.zipcode" v-validate="'required|numeric|zipcodev:refcountry'+cid" class="w-full" data-vv-as="Zip Code" />
                    <vs-input v-else :name="'zipcode' + cid" v-model="value.zipcode" v-validate="'numeric|zipcodev:refcountry'+cid" class="w-full" data-vv-as="Zip Code" />

                    <span class="text-danger text-sm" v-show="errors.has((formscope!=''?formscope+'.':'')+'zipcode' + cid)">{{ errors.first((formscope!=''?formscope+'.':'')+"zipcode" + cid) }}</span>
                </div>
            </div>

        </div>
    </div>

</div>
</template>

<script>
import _ from "lodash";
export default {
    inject: ["parentValidator"],

    props: {
        value: Object,
        showLane1: {
            type: Boolean,
            default: true
        },
        showLane2: {
            type: Boolean,
            default: true
        },
        showCountry: {
            type: Boolean,
            default: true
        },
        showState: {
            type: Boolean,
            default: true
        },
        showCity: {
            type: Boolean,
            default: true
        },
        showZip: {
            type: Boolean,
            default: true
        },

        formscope: {
            type: String,
            default: ''
        },
        disableCountry: {
            type: Boolean,
            default: false
        },
        showaptType: {
            type: Boolean,
            default: true
        },
        validationRequired: {
            type: Boolean,
            default: false
        },
        addFormContainerCls: {
            type: Boolean,
            default: true
        },
        countries: Array,
        address: Object,
        cid: {
            type: String,
            default: "",
        },
        placeOnly: {
            type: Boolean,
            default: false,
        },
        placeOnlyTitle: String,
    },

    data() {
        return {
            states: [],
            locations: [],
            laddress: {
                line1: "",
                line2: "",
                zipcode: "",
                countryId: null,
                countryDetails: null,
                stateId: null,
                locationId: null,
                stateDetails: null,
                locationDetails: null,
                aptType: '',
            },
            aptType1: false,
            aptType2: false,
            aptType3: false,
        };
    },
    created() {
        this.$validator = this.parentValidator;
    },
    mounted() {
         this.value = Object.assign({
                line1: "",
                line2: "",
                zipcode: "",
                countryId: null,
                countryDetails: null,
                stateId: null,
                locationId: null,
                stateDetails: null,
                locationDetails: null,
                aptType: '',
            }, this.value);
         this.init();
    },
    methods: {

        setaptType(e, val) {
            if (e.target.name == 'aptType1') {
                this.aptType2 = false;
                this.aptType3 = false;
            }
            if (e.target.name == 'aptType2') {
                this.aptType1 = false;
                this.aptType3 = false;
            }
            if (e.target.name == 'aptType3') {
                this.aptType1 = false;
                this.aptType2 = false;
            }
            if (e.target.checked) {
                this.value.aptType = val;
            } else {
                this.value.aptType = '';

            }
        },
        init() {
           // this.laddress = this.address;
            if (this.value.aptType != '') {

                if (this.value.aptType == 'APT') {
                    this.aptType1 = true;
                    this.aptType2 = false;
                    this.aptType3 = false;
                }
                if (this.value.aptType == 'STE') {
                    this.aptType1 = false;
                    this.aptType2 = true;
                    this.aptType3 = false;
                }
                if (this.value.aptType == 'FLR') {
                    this.aptType1 = false;
                    this.aptType3 = true;
                    this.aptType2 = false;
                }

            }
            if (this.value && (this.checkProperty(this.value, 'countryDetails', 'id') || this.checkProperty(this.value, 'countryId'))) {

                if ((this.checkProperty(this.value, 'countryDetails', 'id') || this.checkProperty(this.value, 'countryId'))) {
                    let countryId = this.value.countryId;
                    if (!countryId && this.checkProperty(this.value, 'countryDetails', 'id')) {

                        countryId = this.checkProperty(this.value, 'countryDetails', 'id')
                        this.value['countryId'] = countryId;
                    }

                    this.$store
                        .dispatch("getstates", countryId)
                        .then((response) => {
                            this.states = response;
                        });
                }

                if (this.value.stateDetails && this.value.stateId) {
                    this.$store
                        .dispatch("getlocations", {
                            countryId: this.value.countryId,
                            stateId: this.value.stateId,
                        })
                        .then((response) => {
                            this.locations = response;
                        });
                }
            } else if (this.disableCountry) {
                this.value.countryDetails = {
                    "_id": "61408c9ed01ea1248cdcf6b7",
                    "id": 231,
                    "name": "United States",
                    "phoneCode": 1,
                    "order": 1,
                    "currencySymbol": "$",
                    "currencyCode": "USD",
                    "zipcodeLength": 5,
                    "sortName": "united states"
                }
                this.value.countryId = 231;
                this.$store
                    .dispatch("getstates", this.value.countryId)
                    .then((response) => {
                        this.states = response;
                    });
            }
            try {
                this.$validator.reset();
            } catch (e) {
                
            }

        },
        addLocation(newTag) {
            this.$store
                .dispatch("addLocations", {
                    name: newTag,
                    stateId: this.value.stateId,
                })
                .then((response) => {
                    var tag = response;

                    this.locations.push(response);
                    this.value.location = response;
                });
        },
        updateaddress(data) {
            if (data.line1 != null) this.value.line1 = data.line1;
            if (data.line2 != null) this.value.line2 = data.line2;
            if (data.zipcode != null) this.value.zipcode = data.zipcode;
            if (data.countryDetails && data.countryId) {
                if (data.countryDetails && data.countryId) {
                    this.value.countryDetails = _.find(this.countries, (e) => {
                        return e["id"] == data.countryId;
                    });

                    this.$store
                        .dispatch("getstates", data.countryId)
                        .then((response) => {
                            this.states = response;
                            this.value.stateDetails = _.find(this.states, (e) => {
                                return e["id"] == data.stateId;
                            });
                        });
                    this.$store
                        .dispatch("getlocations", {
                            countryId: data.countryId,
                            stateId: data.stateId,
                        })
                        .then((response) => {
                            this.locations = response;

                            this.value.locationstateId = _.find(this.locations, (e) => {
                                return e["id"] == data.locationId;
                            });
                        });
                }
            }
        },
        selectedCountry(selected) {
            this.locations = [];

            this.value = Object.assign(this.value, {
                'countryId': selected.id
            })
            this.value.countryId = selected.id;

            this.$store.dispatch("getstates", selected.id).then((response) => {
                this.states = response;
                this.value.stateId = null;
                this.value.stateDetails = null
                this.value.locationId = null;
                this.value.locationDetails = null
            });
        },
        selectedLocation(selected) {

            this.value = Object.assign(this.value, {
                'locationId': selected.id
            })
            this.value.locationId = selected.id;

        },
        selectedState(selected) {

            this.value = Object.assign(this.value, {
                'stateId': selected.id
            })
            this.value.stateId = selected.id;

            this.locations = [];
            this.$store
                .dispatch("getlocations", {
                    countryId: this.value.countryId,
                    stateId: selected.id,
                })
                .then((response) => {
                    this.locations = response;

                    this.value.locationId = null;
                    this.value.locationDetails = null
                });
        },
    },
    beforeDestroy() {},
};
</script>
