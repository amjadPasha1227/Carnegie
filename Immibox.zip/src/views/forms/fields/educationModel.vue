<template>
    <div class="vx-col  w-full">
        <div class="form-container pad20">
            <div class="vx-row">
                <div class="vx-col w-full">
                    <div class="vx-row delete-row">

                        <immiInput :cid="'benfcollegename'" :display="false" :fieldsArray="fieldsArray" :required="true"
                            :formscope="formscope" :tplkey="'name'" :tplsection="tplsection" :fieldName="'name'"
                            v-model="value.name" label="University/College/School Name"
                            placeHolder="University/College/School Name" />

                        <selectField :display="false" :fieldsArray="fieldsArray" :tplsection="tplsection"
                            :tplkey="'highestDegree'" @input="getHighestDegree($event)" :required="true"
                            :optionslist="temporaryDegreeList" v-model="value.highestDegreeDetails" :formscope="formscope"
                            :fieldName="'highestDegree'" label="Qualification" placeHolder="Qualification" />
                        <immiInput :display="false" :fieldsArray="fieldsArray" :tplsection="tplsection"
                            :tplkey="'majorFieldOfStudy'" :cid="'benmajorFieldOfStudy'" :formscope="formscope"
                            v-model="value.majorFieldOfStudy" :required="checkSLGAndRenderField"
                            :fieldName="'majorFieldOfStudy'" label="Major Field of Study"
                            placeHolder="Major Field of Study" />
                        <!-- <immiInput :display="true" :datatype="'digits:4'" :fieldsArray="fieldsArray" :cid="'bengraduatedYear'" :formscope="formscope" v-model="value.graduatedYear" :required="value.name!=null && value.name!=''" :fieldName="'graduatedYear'" label="Year Graduated" placeHolder="Year Graduated" /> -->

                        <selectField v-if="checkCanDisplayGradYear()" :display="false" :listContainsId="false"
                            :tplsection="tplsection" :tplkey="'graduatedYear'" :fieldsArray="fieldsArray"
                            :cid="'bengraduatedYear'" :required="true" :optionslist="graduatedYears"
                            v-model="value.graduatedYear" :formscope="formscope" :fieldName="'graduatedYear'"
                            label="Year of Graduation" placeHolder="Year of Graduation" />

                        <datepickerField v-if="!checkCanDisplayGradYear()" :dateEnableTo="featureDates"
                            :tplsection="tplsection" :tplkey="'graduatedDate'" wrapclass="md:w-1/2"
                            v-model="value.graduatedDate" :formscope="formscope" :fieldName="'graduatedDate'"
                            label="Date of Graduation" :display="false" :validationRequired="true" />
                        <template v-if="!callformCap">
                        <datepickerField  :dateEnableTo="featureDates" :tplsection="tplsection" :fieldsArray="fieldsArray"
                            :tplkey="'attendedFrom'" @input="updateAttendedFrom($event)" wrapclass="md:w-1/2"
                            v-model="value.attendedFrom" :formscope="formscope" :fieldName="'attendedFrom'"
                            label="Course Started On" :display="false" :validationRequired="true" />



                        <datepickerField  wrapclass="md:w-1/2" :tplsection="tplsection" :fieldsArray="fieldsArray"
                            :tplkey="'attendedTo'" :isDisabled="!value.attendedFrom" v-model="value.attendedTo" 
                            :dateEnableFrom="value.attendedFrom" :formscope="formscope" :fieldName="'attendedTo'" 
                            label="Course Completed On" :display="false" :validationRequired="true" />
                        </template>
                        <div class="vx-col w-full"
                            v-if="checkSLGAndRenderField && countrieslist.length > 0 && canRenderField('address', fieldsArray, display, tplsection)">
                            <h3 class="small-header">University/College/School Address</h3>

                            <addressField :isCap="true" wrapclass="educationaddress" :tplsection="tplsection"
                                :fieldsArray="fieldsArray" :formscope="formscope" :showaptType="true"
                                :addFormContainerCls="true" :validationRequired="true" :countries="countrieslist"
                                v-model="value.address" :cid="'benfcollegenameaddress'"
                                :fieldName="'benfcollegenameaddress'" />
                        </div>
                        <immiswitchyesno v-if="checkSLGAndRenderField && value.address.countryId == 231"
                            :tplsection="tplsection" :tplkey="'isAccredited'" :fieldsArray="fieldsArray"
                            :cid="'benisAccredited'" :formscope="formscope" v-model="value.isAccredited"
                            :required="value.name && value.name != ''" :display="display" :fieldName="'isAccredited'"
                            label="Was the University Accredited at the time of your graduation?" placeHolder="" />

                        <immiswitchyesno v-if="checkSLGAndRenderField && value.address.countryId == 231"
                            :tplsection="tplsection" :tplkey="'isForProfit'" :fieldsArray="fieldsArray"
                            :cid="'benisForProfit'" :formscope="formscope" v-model="value.isForProfit"
                            :required="value.name && value.name != ''" :display="display" :fieldName="'isForProfit'"
                            label="Is the University Profit University?" placeHolder="" />

                        <immitextarea v-if="false" :fieldsArray="fieldsArray" :tplsection="tplsection" :tplkey="'jobDuties'"
                            wrapclass=" " :formscope="formscope" v-model="value.jobDuties" :required="true" :display="false"
                            fieldName="jobDuties" label="Job Duties" placeHolder="Job Duties"></immitextarea>





                    </div>
                    <template v-if="callformCap">
                        <div class="vx-row">
                            <div class="vx-col w-full">
                                <h3 class="small-header">Documents</h3>
                                <casedocumentslist :showTitle="false" :docslist="docsList" :formscope="formscope"
                                    :fieldsArray="[]" v-model="value.documents" :tplsection="'documents'" :fieldName="''">
                                </casedocumentslist>
                            </div>
                        </div>
                    </template>
                </div>
            </div>


        </div>
    </div>
</template>

<script>
import _ from "lodash";
import casedocumentslist from "@/views/common/casedocuments.vue";
import immitextarea from "@/views/forms/fields/simpletextarea.vue";
import datepickerField from "@/views/forms/fields/datepicker.vue";
import immiInput from "@/views/forms/fields/simpleinput.vue";
import addressField from "@/views/forms/fields/address.vue";
import selectField from "@/views/forms/fields/simpleselect.vue";
import immiswitchyesno from "@/views/forms/fields/switchyesno.vue";
import moment from 'moment'

import Vue from "vue";

export default {
    inject: ["parentValidator"],
    props: {
        reqConsdnOfAdvDegreeExptn: {
            type: Boolean,
            default: false
        },
        callformCap: {
            type: Boolean,
            default: false
        },
        display: {
            type: Boolean,
            default: false,
        },
        fieldsArray: Array,
        formscope: {
            type: String,
            default: ''
        },
        tplsection: {
            type: String,
            default: 'beneficiaryInfo.educations',
        },
        value: {
            type: Object,
            default: {
                _id: 0,
                name: null,
                address: {
                    line1: null,
                    line2: null,
                    aptType: null,
                    locationId: null,
                    locationDetails: null,
                    stateId: null,
                    stateDetails: null,
                    countryId: null,
                    countryDetails: null,
                    zipcode: null
                },
                highestDegree: null,
                highestDegreeDetails: null,
                majorFieldOfStudy: null,
                attendedFrom: null,
                attendedTo: null,
                graduatedYear: null,
                degreereceived: null,
                isAccredited: null,
                isForProfit: null,
                graduatedDate: null
            }
        },
        petition: null,
        formscope: {
            type: String,
            default: ''
        },
        countries: Array
    },
    data() {
        return {
            checkSLGAndRenderField: true,
            featureDates: null,
            graduatedYears: [],
            masterDegreeList: [],
            temporaryDegreeList: [],
            docsList: [
                // {
                //     display: true,
                //     required: true,
                //     key: "passport",
                //     fieldName: 'passport',
                //     label: "Passport"

                // },
                {
                    display: true,
                    required: true,
                    key: "graduationCertificate",
                    fieldName: 'graduationCertificate',
                    label: "Certificate of Graduation"
                },
                {
                    display: true,
                    required: true,
                    key: "transcripts",
                    fieldName: 'transcripts',
                    label: "Transcripts/Marks Memo"
                }
            ],
            countrieslist: [],
        };
    },
    created() {
        this.$validator = this.parentValidator;
    },
    computed: {
        maxYear() {
            return new Date().getFullYear() + 10
        },
        minYear(education) {
            return moment(education.attendedFrom).year()
        },
    },
    mounted() {
        var $self = this;
        this.featureDates = new Date();
        if (this.callformCap) {
            if (this.checkProperty(this.petition, 'questionnaireTplType')
                && this.petition.questionnaireTplType != 'slg') {
                this.checkSLGAndRenderField = false
            }
        }

        this.getGraduatedYears()
        this.masterDegreeList = this.petition.highestDegreeList
        if (this.callformCap) {
            let highDegereeList = [];
            _.forEach(this.masterDegreeList, (item) => {
                if(this.checkSLGAndRenderField||(!this.checkSLGAndRenderField&&item.id<=this.petition.beneficiaryInfo.highestDegree)){
                if (this.checkProperty(this.petition, 'beneficiaryInfo', 'educations')
                    && this.checkProperty(this.petition['beneficiaryInfo'], 'educations', 'length') > 0) {
                    let selectedDegree = _.find(this.petition['beneficiaryInfo']['educations'], { 'highestDegree': item.id });
                    if (!selectedDegree) {
                        highDegereeList.push(item)
                    } else if (this.checkProperty(this.value, 'highestDegreeDetails')
                        && this.value['highestDegreeDetails']['id'] == item.id) {
                        highDegereeList.push(item)
                    }
                } else {
                    highDegereeList.push(item)
                }
            }
            })
            this.temporaryDegreeList = highDegereeList
            // this.temporaryDegreeList = this.masterDegreeList
        } else {
            this.temporaryDegreeList = this.masterDegreeList
        }

        if (!this.callformCap) {
            this.countrieslist = this.countries;
        } else {
            //  this.value['highestDegree'] = his.value.highestDegreeDetails.id
            this.getHighestDegree(this.value.highestDegreeDetails)
        }

    },
    methods: {
        getGraduatedYears() {
            let currentYear = parseInt(moment().year());
            let pastYear = currentYear - 100
            for (let i = pastYear; i <= currentYear; i += 1) {
                this.graduatedYears.push(i)
            }
            this.graduatedYears = this.graduatedYears.reverse()
        },
        updateAttendedFrom(val) {
            if (val) {
                let startDate = moment(val);
                if (this.value.attendedTo) {
                    let endDate = moment(this.value.attendedTo)
                    if (startDate.isAfter(endDate, 'day')) {
                        this.value['attendedTo'] = null
                    }
                }
            }
        },

        removeeducation: function (index) {
            Vue.delete(this.value, index);
        },
        getHighestDegree(val) {
            if (val) {
                this.value['highestDegree'] = val.id
                if (!this.callformCap) {

                }
                else if (this.callformCap) {
                    if (this.reqConsdnOfAdvDegreeExptn == true) {
                        this.countrieslist = [];
                        setTimeout(() => {
                            if (val.id == 6) {
                                this.countrieslist = [];
                                this.countrieslist = _.filter(this.countries, function (item) {
                                    return item.id == 231;
                                });

                                if (this.checkProperty(this.value, 'address', 'countryDetails')
                                    && this.value.address.countryDetails.id != 231) {
                                    this.value.address.countryDetails = null
                                    this.value.address.countryId
                                    this.value.address.stateDetails = null
                                    this.value.address.stateId = null
                                    this.value.address.locationDetails = null
                                    this.value.address.locationId = null
                                }
                            } else {
                                this.countrieslist = [];
                                this.countrieslist = this.countries;
                                if (this.checkProperty(this.value, 'address', 'countryDetails')
                                    && this.value.address.countryDetails.id == 231) {
                                    this.value.address.countryDetails = null
                                    this.value.address.countryId
                                    this.value.address.stateDetails = null
                                    this.value.address.stateId = null
                                    this.value.address.locationDetails = null
                                    this.value.address.locationId = null
                                }
                            }
                        });
                    } else {
                        this.countrieslist = [];
                        setTimeout(() => {
                            if (val.id == 6) {
                                this.countrieslist = [];
                                this.countrieslist = _.filter(this.countries, function (item) {
                                    return item.id !== 231;
                                });

                                if (this.checkProperty(this.value, 'address', 'countryDetails')
                                    && this.value.address.countryDetails.id == 231) {
                                    this.value.address.countryDetails = null
                                    this.value.address.countryId
                                    this.value.address.stateDetails = null
                                    this.value.address.stateId = null
                                    this.value.address.locationDetails = null
                                    this.value.address.locationId = null
                                }
                            } else {
                                this.countrieslist = this.countries;
                            }
                        })
                    }
                } else {
                    this.countrieslist = [];
                    setTimeout(() => {
                        this.countrieslist = this.countries;
                    });
                }

                if (this.checkCanDisplayGradYear()) {
                    this.value.graduatedDate = null
                } else {
                    this.value.graduatedYear = null
                }


            } else {
                this.countrieslist = this.countries;
            }
        },
        checkCanDisplayGradYear() {
            if ((this.reqConsdnOfAdvDegreeExptn == true && this.checkProperty(this.value, 'highestDegree') && this.value.highestDegree == 6
                && this.checkSLGAndRenderField)) {
                return false
            }
            return true
        }, updateDateOfGraduation(val) {
            if (val) {
                let startDate = moment(val);
            }
        },

    },
    components: {
        casedocumentslist,
        immitextarea,
        datepickerField,
        immiInput,
        selectField,
        addressField,
        immiswitchyesno
    }
};
</script>
