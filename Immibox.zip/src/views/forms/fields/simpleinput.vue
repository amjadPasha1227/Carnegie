<template>
<div class="vx-col  w-full" :class="wrapclass" v-if="canRenderField(tplkey,fieldsArray,display ,tplsection,fieldName)">
    <div class="form_group">
        <label class="form_label d-flex">{{label}}<em v-if="checkFieldIsRequired({'key':tplkey,'section':tplsection, 'fieldsArray':fieldsArray, 'required':required ,'mRequired':mRequired,'notRequired':notRequired })">*</em>
            <div class="IB_tooltip" :class="{'placement-right':callFromEmployment}" v-if="helpText" >
                <span
                    ><info-icon size="1.5x" class="custom-class"></info-icon
                ></span>
                <div class="tooltip_cnt">
                    <p>
                    {{helpText}}
                    </p>
                </div>
            </div>
        </label>
        <template v-if="onlyNumbers==true">
            <template v-if="allowFloatingPoint">
                <vs-input @keyup.enter.native="$emit('keyEnter')" oninput="this.value = this.value.replace(/[^0-9 .]/g, '').replace(/(\..*)\./g, '$1'); this.value = this.value.replace(/ /g,'');" :disabled="disabled" :name="fieldName+cid" @input="updateData()" v-model="value" v-validate="checkFieldIsRequired({'key':tplkey,'section':tplsection, 'fieldsArray':fieldsArray, 'required':required ,'mRequired':mRequired })? 'required|decimal:2':'decimal:2' "  :maxLength="maxLength" class="w-full" :data-vv-as="vvas?vvas:placeHolder"  />
        
            </template>
            <template v-else>
                <vs-input @keyup.enter.native="$emit('keyEnter')" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1'); this.value = this.value.replace(/ /g,'');" :disabled="disabled" :name="fieldName+cid" @input="updateData()" v-model="value" v-validate="checkFieldIsRequired({'key':tplkey,'section':tplsection, 'fieldsArray':fieldsArray, 'required':required,'mRequired':mRequired })? 'required|'+maxvalueData:'' "  :maxLength="maxLength" class="w-full" :data-vv-as="vvas?vvas:placeHolder"  />
        

            </template>

           
        </template>
        <template v-else>
            <vs-input  :class="{'text-upper': allowUpperCase}" @keyup.enter.native="changeToUpperCase();$emit('keyEnter')" :disabled="disabled" :name="fieldName+cid" @input="updateData()" v-model="value" v-validate="checkFieldIsRequired({'key':tplkey,'section':tplsection, 'fieldsArray':fieldsArray, 'required':required ,'mRequired':mRequired , 'notRequired':notRequired  })? 'required|'+datatype : datatype "  class="w-full" :data-vv-as="vvas?vvas:placeHolder" :maxLength="maxCharacters" />
        </template>
       
        <template v-if="formscope!=''">
          <p v-show="errors.has( formscope+'.'+fieldName+cid)" class="text-danger text-sm">{{ errors.first(formscope+'.'+fieldName+cid) }}</p>
       </template>
       <template v-else>

        <p v-show="errors.has(fieldName+cid)" class="text-danger text-sm">{{ errors.first(fieldName+cid) }}</p>
   

       </template>
    </div>
</div>
</template>

<script>
import { InfoIcon } from "vue-feather-icons";

export default {
    inject: ["parentValidator"],
    props: {
        notRequired:{
            type: Boolean,
            default: false,
        },
        maxvalueData:{
            type:String,
            default:'' 
        },
        allowUpperCase:{
            type: Boolean,
            default: false,
        },
        helpText:{
            type: String,
            default:'',
        },
        maxCharacters:{
            type: Number,
            default:200,
        },
        maxLength:{
            type: Number,
            default:25,
        },
        display: {
            type: Boolean,
            default: false,
        },
        mRequired:{
            type: Boolean,
            default: false,
        },
        disabled:{
            type: Boolean,
            default: false,
        },
        allowFloatingPoint:{
            type: Boolean,
            default: true,
        },
         fieldsArray:Array,
        vvas:{
        type:String,
            default:""
        },
        wrapclass:{
        type:String,
            default:"md:w-1/2"
        },
        datatype:{
            type:String,
            default:""
        },
         cid: {
            type: String,
            default: null,
        },
        formscope: {
            type: String,
            default: null
        },
        value: null,
        label: {
            type: String,
            default: null,
        },
        fieldName: {
            type: String,
            default: null,
        },
        tplsection:{
            type: String,
            default: null,
        },
        tplkey:{
            type: String,
            default: null,
        },
        callFromEmployment:{
            type:Boolean,
            default:false
        },
        placeHolder: {
            type: String,
            default: null,
        },
        required: {
            type: Boolean,
            default: false,
        },
        onlyNumbers: {
            type: Boolean,
            default: false,
        }
    },
    created() {
        this.$validator = this.parentValidator;
    },
    
  methods: {
    changeToUpperCase(){
        if(this.allowUpperCase){
            this.value = this.value.toUpperCase();
        }
    },
    updateData() {
        if(this.allowUpperCase){
            this.value = this.value.toUpperCase();
        }
       
      this.$emit('input', this.value)
    }
  },
  components: {
    InfoIcon,
  },
  mounted() {
    setTimeout(()=>{
        if(this.allowUpperCase){
            setTimeout(()=>{
                this.changeToUpperCase();
            } ,100)
           
        this.changeToUpperCase();
        }

      } ,100)
  },
};
</script>
