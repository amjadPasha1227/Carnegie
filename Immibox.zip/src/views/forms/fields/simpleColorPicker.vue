<template>
    <div class="vx-col  w-full" :class="wrapclass">
        <div class="form_group">
            <label class="form_label">{{label}}</label>

            <ul class="color_list">
                <li style="background-color: #D6ECD2;" :class="{'selected':internalValue == '#D6ECD2'}" @click="updateValue('#D6ECD2')"></li>
                <li style="background-color: #FBF2C0;" :class="{'selected':internalValue == '#FBF2C0'}" @click="updateValue('#FBF2C0')"></li>
                <li style="background-color: #F4D3CE;" :class="{'selected':internalValue == '#F4D3CE'}"  @click="updateValue('#F4D3CE')"></li>
                <li style="background-color: #FCE7C6;" :class="{'selected':internalValue == '#FCE7C6'}"  @click="updateValue('#FCE7C6')"></li>
                <li style="background-color: #EDDCF4;" :class="{'selected':internalValue == '#EDDCF4'}"  @click="updateValue('#EDDCF4')"></li>
                <li style="background-color: #BDDAEA;" :class="{'selected':internalValue == '#BDDAEA'}"  @click="updateValue('#BDDAEA')"></li>
                <li style="background-color: #BDECF3;" :class="{'selected':internalValue == '#BDECF3'}"  @click="updateValue('#BDECF3')"></li>
                <li style="background-color: #B3F1D0;" :class="{'selected':internalValue == '#B3F1D0'}"  @click="updateValue('#B3F1D0')"></li>
                <li style="background-color: #FFBABA;" :class="{'selected':internalValue == '#FFBABA'}"  @click="updateValue('#FFBABA')"></li>
                <li style="background-color: #C1C7D0;" :class="{'selected':internalValue == '#C1C7D0'}"  @click="updateValue('#C1C7D0')"></li>
                <li style="background-color: #C2E5A0;" :class="{'selected':internalValue == '#C2E5A0'}"  @click="updateValue('#C2E5A0')"></li>
                <li style="background-color: #AEB4F5;" :class="{'selected':internalValue == '#AEB4F5'}"  @click="updateValue('#AEB4F5')"></li>
                <li style="background-color: #E2B1A8;" :class="{'selected':internalValue == '#E2B1A8'}"  @click="updateValue('#E2B1A8')"></li>
                <li style="background-color: #A9D9D6;" :class="{'selected':internalValue == '#A9D9D6'}"  @click="updateValue('#A9D9D6')"></li>
                <!-- <li>
                    <span id="color_picker_label"></span>
                    <vs-input id="color_picker" type="color" v-model="internalValue" class="color_picker"/>
                </li> -->
            </ul>
            <input type="hidden" :name="fieldName+cid" v-validate="'required'"  data-vv-as="Documents"  v-model="internalValue">
            <p v-show="errors.has((formscope!=''?formscope+'.':'')+fieldName+cid)" class="text-danger text-sm">Label Color is required</p>
        </div>
    </div>
</template>

<script>
import JQuery from "jquery";
import Vue from 'vue';
import {ColorPicker, ColorPanel} from 'one-colorpicker'
Vue.use(ColorPanel)
Vue.use(ColorPicker)
export default {
    inject: ["parentValidator"],
    props: {
        wrapclass:{
                type: String,
                default: null
            },
            required:{
                type: Boolean,
                default: false,
            },
              display: {
                type: Boolean,
                default: false,
            },
            formscope: {
                type: String,
                default: null
            },
            value: null,
            label: {
                type: String,
                default: 'Select Color',
            },
            placeHolder: {
                type: String,
                default: null,
            },
            fieldName: {
                type: String,
                default: null,
            },
            cid: {
                type: String,
                default: null,
            },
    },
    data: () =>({
        internalValue: null,
        color: null,
        loaded: false
    }),
    created() {
        this.$validator = this.parentValidator;
    },
    mounted() {
        this.setWatchers();
        const $ = JQuery;
        $("#color_picker").change(function(event) {
            console.log($(this).val());
            $("#color_picker_label").css('background-color',$(this).val());
        });
        $("#color_picker_label").click(function(event) {
            $("#color_picker").click();
        });
    },
    methods: {
        updateValue(val){
            this.internalValue = val;
            console.log(this.internalValue)
            this.$emit('input', this.internalValue);
        },
        setWatchers() {
            this.$watch('internalValue', function () {
                if (this.loaded) {
                    this.$emit('input', this.internalValue)
                    this.$emit('changeselect', this.internalValue)
                } else {
                    this.loaded = true
                }
            });

            if (this.internalValue == null) {
                this.loaded = true
            }
        }
    },
    watch: {
        value: {
            immediate: true,
            handler(newValue) {
                this.internalValue = newValue;
            }
        }
    }
};
</script>