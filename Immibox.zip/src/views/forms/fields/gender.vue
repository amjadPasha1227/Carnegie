<template v-if="fieldName">

<div class="vx-col w-full mb-10 beneficiary-info-btns" v-if="canRenderField(tplkey,fieldsArray ,display ,tplsection,fieldName)">
 <vx-input-group class="form-input-group">
    <vs-button class="btn male-btn" @click="setGender('male')" v-bind:class="{isActivec: value == 'male'}" icon-pack="IntakePortal" icon=" IP-femenine-1" type="border">Male</vs-button>
    <vs-button v-bind:class="{ isActivec: value == 'female'}" class="btn female-btn" @click="setGender('female')" icon-pack="IntakePortal" icon=" IP-femenine-1" type="border">Female</vs-button>
    <vs-button v-bind:class="{isActivec: value == 'others'}" class="btn others-btn" @click="setGender('others')" icon-pack="feather" icon="icon-circle" type="border">Others</vs-button>
  

    </vx-input-group>
    <template v-if="checkFieldIsRequired({'key':tplkey,'section':tplsection, 'fieldsArray':fieldsArray, 'required':required })">
      <vs-input style="display: none" name="gender" type="hidden" data-vv-as="Gender" v-validate="checkFieldIsRequired({'key':tplkey,'section':tplsection, 'fieldsArray':fieldsArray, 'required':required })? 'required' : datatype" v-model="value" />
    <div class="input-group-error mt-0 mr-0" style="width: 100%">
        <p>
            <span v-if="formScope" class="error text-sm" v-show="errors.has(formScope+'.gender')">{{ errors.first(formScope+".gender") }}</span>
            <span v-else class="error text-sm" v-show="errors.has('gender')">{{ errors.first("gender") }}</span>
        </p>
    </div>
    </template>
</div>
</template>

<script>
export default {
    inject: ["parentValidator"],
    props: {
         fieldsArray:Array,
        gender: String,
        value:null,
        fieldName:String,
        required:false,
        formScope:'',
        tplsection:{
            type: String,
            default: null,
        },
        display: {
            type: Boolean,
            default: false,
        },
        tplkey:{
            type: String,
            default: null,
        },
        datatype:{
            type:String,
            default:""
        },

    },
    created() {
        this.$validator = this.parentValidator;
    },
    mounted() {


    },
    methods: {
       setGender(val){
        this.value = val;
              this.$emit('input', this.value)

       }
    }
}
</script>
