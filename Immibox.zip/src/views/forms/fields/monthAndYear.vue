<template>
    <div class="vx-col  w-full" :class="wrapclass" v-if="canRenderField(tplkey,fieldsArray,display ,tplsection,fieldName)">
        <div class="form_group">
          
            <label class="form_label">{{label}}<em v-if="checkFieldIsRequired({'key':tplkey,'section':tplsection, 'fieldsArray':fieldsArray, 'required':required ,'notRequired':notRequired })">*</em></label>
            <div class="con-select w-full month_year_select">
                <div class="vx-row">
                    <div class="vx-col md:w-1/2">
                        <multiselect  @input=updateDate :name="fieldName+cid"
                            v-validate="checkFieldIsRequired({'key':tplkey,'section':tplsection, 'fieldsArray':fieldsArray, 'required':required,'notRequired':notRequired })? 'required':'' "
                            v-model="month" :show-labels="false"
                            track-by="id" label="name"
                            :disabled="isDisabled"
                            :data-vv-as="label" 
                            :placeholder="'Month'" 
                            :options="graduatedMonths" 
                            :searchable="true" 
                            :allow-empty="!required"
                            :multiple="multiple"
                            >
                        </multiselect>
                    </div>
                    <div class="vx-col md:w-1/2">
                        <multiselect  @input=updateDate :name="fieldName+cid"
                            v-validate="checkFieldIsRequired({'key':tplkey,'section':tplsection, 'fieldsArray':fieldsArray, 'required':required ,'notRequired':notRequired})? 'required':'' "
                            v-model="year" :show-labels="false"
                            :disabled="isDisabled"
                            :data-vv-as="label" 
                            :placeholder="'Year'" 
                            :options="graduatedYears" 
                            :searchable="true" 
                            :allow-empty="!required"
                            :multiple="multiple"
                            >
                        </multiselect>
                    </div>
                </div>
            </div>
            <p v-show="errors.has((formscope!=''?formscope+'.':'')+fieldName+cid)" class="text-danger text-sm">{{ errors.first((formscope!=''?formscope+'.':'')+fieldName+cid) }}</p>
        </div>
    </div>
    </template>
    
    <script>
       import moment from "moment";
    export default {
        inject: ["parentValidator"],
       
        props: {
            notRequired:{
                type: Boolean,
                default: false,
            },
            multiple:{
                type: Boolean,
                default: false,
            },
            isDisabled:{
                type: Boolean,
                default: false,
            },
            listContainsId: {
                type: Boolean,
                default: true,
            },
              display: {
                type: Boolean,
                default: false,
            },
             fieldsArray:Array,
            vvas: {
                type: String,
                default: ""
            },
            optionslist: {
                type: Array,
                default () {
                    return []
                }
            },
            wrapclass: {
                type: String,
                default: "md:w-1/2"
            },
            datatype: {
                type: String,
                default: ""
            },
            cid: {
                type: String,
                default: null,
            },
            formscope: {
                type: String,
                default: null
            },
            value: null,
            label: {
                type: String,
                default: null,
            },
            fieldName: {
                type: String,
                default: null,
            },
            tplsection:{
                type: String,
                default: null,
            },
            tplkey:{
                type: String,
                default: null,
            },
            placeHolder: {
                type: String,
                default: null,
            },
            required: {
                type: Boolean,
                default: false,
            },
            loaded: {
                type: Boolean,
                default: false,
            }
        },
        created() {
            this.$validator = this.parentValidator;
        },
        mounted() {
            this.getDateUpdate();
            this.getGraduatedYears()
            this.setWatchers();
        },
        data() {
            return {
                selectedYear:null,
                selectedEndYear:null,
                year:null,
                month:null,
                graduatedYears:[],
                graduatedMonths:[{'id':'01','name':'Jan'},{'id':'02','name':'Feb'},{'id':'03','name':'Mar'},{'id':'04','name':'Apr'},{'id':'05','name':'May'},{'id':'06','name':'Jun'},
                {'id':'07','name':'Jul'},{'id':'08','name':'Aug'},{'id':'09','name':'Sept'},{'id':'10','name':'Oct'},{'id':'11','name':'Nov'},{'id':'12','name':'Dec'}]
            }
        },
        methods: {
            clearModels(){
                this.year=null
                this.month=null
            },
            updateCourseYears(val){
                this.selectedYear = val;
                this.getGraduatedYears()
            },
            updateCourseEndYears(year,endYear){
                this.selectedYear = year;
                this.selectedEndYear = endYear;
                this.getGraduatedYears()
            },
            getGraduatedYears() {
                let currentYear = null;
                if(this.selectedYear){
                    currentYear = parseInt(this.selectedYear);
                    this.graduatedYears = []
                }else{
                    currentYear = parseInt(moment().year());
                }
                let pastYear = null;
                pastYear = currentYear - 100
                if(this.selectedEndYear){
                    pastYear = this.selectedEndYear
                    this.graduatedYears = []
                }
                for (let i = pastYear; i <= currentYear; i += 1) {
                    this.graduatedYears.push(i)
                }
                this.graduatedYears = this.graduatedYears.reverse()
            },
            updateData(){
            
                this.$emit('input', this.value)
            
            },
            setWatchers() {
                this.$watch('value', function () {
                    if (this.loaded) {
                        this.$emit('input', this.value)
                        this.$emit('changeselect', this.value)
                    } else {
    
                        this.loaded = true
                    }
    
                });
    
                if (this.value == null) {
                    this.loaded = true
                }
            },
            updateDate(ev){
                //"YYYY-MM-DD"
                let dateModel =''
                if( this.month && this.checkProperty(this.month,'id') && this.year  ){
                    let df = this.year+"-"+this.month['id']+"-01"
                    this.value = moment(df).format("YYYY-MM-DD");
                    this.updateData();
                    

                }
                
            },
            getDateUpdate(){
                if(this.value){
                    
                    let date = moment(this.value).format("YYYY-MM-DD")
                    let splitDate = date.split("-");
                    if(splitDate && splitDate[0]){
                        this.year = splitDate[0]
                    }
                    if(splitDate && splitDate[1]){
                        let monthObj = _.find(this.graduatedMonths,{'id':splitDate[1]})
                        if(monthObj){
                            this.month = monthObj
                        }
                        
                    }
                    
                }
            }
    
        }
    };
    </script>
    