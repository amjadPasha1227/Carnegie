<template>
    <div class="vx-col  w-full">
        <div class="form-container">
            <div class="vx-row">


                <ul class="personal-info-card pt-0">
                    <template v-for="(education, index) in value">

                        <template v-if="checkProperty(education, 'name')">
                            <li class="dependent-block_wrap" :key="index">
                                <div class="dependent-block">
                                    <div class="dependent-title">
                                        <h3>
                                            {{ checkProperty(education,'name') }}
                                        </h3>
                                        <ul>
                                            <li @click="editEducation(education, index)">
                                                <a><img src="@/assets/images/main/edit_icon.svg" />
                                                </a>
                                            </li>
                                            <li @click="removeeducation(index)"><a><img
                                                        src="@/assets/images/main/delete-row-img.svg"></a></li>
                                        </ul>
                                    </div>

                                    <div class="dependent_details">
                                        <ul>
                                            <li v-if="checkProperty(education, 'highestDegree')"> Qualification
                                                <span> {{ checkProperty(education,'highestDegree') | formatML(petition.highestDegreeList) }}</span>
                                            </li>
                                            <li v-if="checkProperty(education, 'majorFieldOfStudy')"> Major Field of
                                                Study
                                                <span> {{ checkProperty(education,'majorFieldOfStudy') }}</span>
                                            </li>
                                            <li v-if="checkProperty(education, 'graduatedDate')"> Date of Graduation
                                                <span>
                                                    {{ checkProperty(education,'graduatedDate') | formatDate}}</span>
                                            </li>
                                            <li v-if="checkProperty(education, 'graduatedYear')"> Year of Graduation
                                                <span>
                                                    {{ checkProperty(education,'graduatedYear') }}</span></li> 
                                            <li v-if="!callformCap&&checkProperty(education, 'attendedFrom')">Course Started On<span>
                                                    {{ checkProperty(education,'attendedFrom') | formatMonthYear }}</span>
                                            </li>
                                            <li v-if="!callformCap&&checkProperty(education, 'attendedTo')"> Course Completed On
                                                <span> {{ checkProperty(education,'attendedTo') | formatMonthYear }}</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </li>
                        </template>
                    </template>
                  
                    <li v-if="(!value||(value&&value.length<petition.highestDegreeList.length))" class="dependent-block_wrap">
                        <div class="dependent-block add-btn-center" @click="addeducation(true)">
                            <a class="add-more ml-0"><span>+</span> Add</a>
                        </div>
                    </li>
                </ul>
            </div>

        </div>

        <div class="custom_modal_sec " v-if="educationForm" :class="{ modalopen: educationForm }">
            <div class="custom_modal_overlay"></div>
            <div class="custom_modal_cnt">
                <div class="modal_title">
                    <h2>{{ popupTitle }}</h2>
                    <span class="close" @click="addeducation(false)">
                        <x-icon size="1.5x"></x-icon>
                    </span>
                </div>
                <div class="modal_cnt">
                    <VuePerfectScrollbar ref="mainSidebarPs" :settings="settings">


                        <educationModel :callformCap="callformCap"
                            :reqConsdnOfAdvDegreeExptn="reqConsdnOfAdvDegreeExptn" :tplsection="tplsection"
                            :display="callformCap ? true : false" v-model="newEducation" :petition="petition"
                            :fieldsArray="fieldsArray" :formscope="formscope" :countries="countries" />

                    </VuePerfectScrollbar>
                </div>
                <div class="popup-footer relative">
                    <vs-button color="dark" class="cancel" type="filled" @click="addeducation(false)">Cancel</vs-button>
                    <vs-button v-if="!edit" color="success" @click="saveEduction()" class="save" type="filled">Save
                    </vs-button>
                    <vs-button v-if="edit" color="success" @click="updateEduction()" class="save" type="filled">Update
                    </vs-button>
                </div>
                <div></div>
            </div>
        </div>

    </div>
</template>

<script>
import JQuery from 'jquery';
import { XIcon } from 'vue-feather-icons'
import _ from "lodash";
import datepickerField from "@/views/forms/fields/datepicker.vue";
import immiInput from "@/views/forms/fields/simpleinput.vue";
import addressField from "@/views/forms/fields/address.vue";
import selectField from "@/views/forms/fields/simpleselect.vue";
import immiswitchyesno from "@/views/forms/fields/switchyesno.vue";
import moment from 'moment'
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import educationModel from "@/views/forms/fields/educationModel.vue"
import Vue from "vue";

export default {
    inject: ["parentValidator"],
    props: {
        reqConsdnOfAdvDegreeExptn: {
            type: Boolean,
            default: false
        },
        callformCap: {
            type: Boolean,
            default: false
        },
        popupTitle: {
            type: String,
            default: 'Educational Information',
        },
        tplsection: {
            type: String,
            default: 'beneficiaryInfo.educations',
        },
        fieldName: '',
        fieldsArray: Array,
        formscope: {
            type: String,
            default: ''
        },
        value: Array,
        petition: null,

        countries: Array
    },
    data() {
        return {
            selectedItem: -1,
            edit: false,
            newEducation: {
                _id: 0,
                name: null,
                address: {
                    line1: null,
                    line2: null,
                    aptType: null,
                    locationId: null,
                    locationDetails: null,
                    stateId: null,
                    stateDetails: null,
                    countryId: null,
                    countryDetails: null,
                    zipcode: null
                },
                highestDegree: null,
                highestDegreeDetails: null,
                majorFieldOfStudy: null,
                attendedFrom: null,
                attendedTo: null,
                graduatedYear: null,
                degreereceived: null,
                isAccredited: null,
                isForProfit: null
            },
            settings: {},
            educationForm: false,
            featureDates: null,
        };
    },
    created() {
        this.$validator = this.parentValidator;
    },
    computed: {
        maxYear() {
            return new Date().getFullYear() + 10
        },
        minYear(education) {

            return moment(education.attendedFrom).year()
        },

    },
    mounted() {

        var $self = this;
        this.featureDates = new Date();

        this.value.forEach(function (item, index) {

            let highestDegree = item.highestDegree;
            if (highestDegree != null) {
                var _t = _.find($self.petition.highestDegreeList, function (item) {

                    return item.id == highestDegree
                })

                $self.value[index]['highestDegreeDetails'] = _t
            }

        })
        if (this.callformCap) {
            this.newEducation = {
                _id: 0,
                name: null,
                address: {
                    line1: null,
                    line2: null,
                    aptType: null,
                    locationId: null,
                    locationDetails: null,
                    stateId: null,
                    stateDetails: null,
                    countryId: null,
                    countryDetails: null,
                    zipcode: null
                },
                highestDegree: null,
                highestDegreeDetails: null,
                majorFieldOfStudy: null,
                attendedFrom: null,
                attendedTo: null,
                graduatedYear: null,
                degreereceived: null,
                isAccredited: null,
                isForProfit: null,
                documents: {
                    passport: [],
                    graduationCertificate: [],
                    transcripts: [],
                }
            }
        }



    },
    methods: {
        editEducation(item, index) {
            this.selectedItem = index;
            if (this.callformCap) {
                this.newEducation = {
                    _id: 0,
                    name: null,
                    address: {
                        line1: null,
                        line2: null,
                        aptType: null,
                        locationId: null,
                        locationDetails: null,
                        stateId: null,
                        stateDetails: null,
                        countryId: null,
                        countryDetails: null,
                        zipcode: null
                    },
                    highestDegree: null,
                    highestDegreeDetails: null,
                    majorFieldOfStudy: null,
                    attendedFrom: null,
                    attendedTo: null,
                    graduatedYear: null,
                    degreereceived: null,
                    isAccredited: null,
                    isForProfit: null,
                    documents: {
                        passport: [],
                        graduationCertificate: [],
                        transcripts: [],
                    }
                }
            } else {
                this.newEducation = {
                    _id: 0,
                    name: null,
                    address: {
                        line1: null,
                        line2: null,
                        aptType: null,
                        locationId: null,
                        locationDetails: null,
                        stateId: null,
                        stateDetails: null,
                        countryId: null,
                        countryDetails: null,
                        zipcode: null
                    },
                    highestDegree: null,
                    highestDegreeDetails: null,
                    majorFieldOfStudy: null,
                    attendedFrom: null,
                    attendedTo: null,
                    graduatedYear: null,
                    degreereceived: null,
                    isAccredited: null,
                    isForProfit: null
                };
            }

            _.forEach(item, (val, key) => {
                if (_.has(this.newEducation, key)) {

                    this.newEducation[key] = _.cloneDeep(val);

                } else {
                    let newOne = {};
                    newOne[key] = val;
                    this.newEducation = Object.assign(this.newEducation, newOne);
                    this.newEducation[key] = _.cloneDeep(val);

                }
            })
            this.newEducation = _.cloneDeep(this.newEducation);
            this.edit = true
            this.educationForm = true;

        },
        updateEduction() {
            this.$validator.validateAll(this.formscope).then((result) => {
                if (result) {
                    _.forEach(this.value, (education, index) => {
                        //&& education['_id'] == this.newEducation['_id']
                        if (this.selectedItem == index ) {
                            _.forEach(this.newEducation, (val, key) => {
                                education[key] = _.cloneDeep(val);
                            })
                            try{
                            const $ = JQuery;
                            if ($('.text-danger:visible')) {
                                $('.modal_cnt').scrollTop($('.text-danger:visible').first().parent().offset().top - 30, 'slow');
                            }
                          }catch(err){

                          }
                        }
                        else {
                            
                        }

                    });
                    this.edit = false
                    this.educationForm = false;
                    this.selectedItem = -1;
                }


            });


        },
        saveEduction() {

            this.$validator.validateAll(this.formscope).then((result) => {
                //alert(result);

                if (result) {
                    this.value.push(_.cloneDeep(this.newEducation));
                    this.edit = false
                    this.educationForm = false;
                    this.selectedItem = -1;
                }
                else {
                    const $ = JQuery;
                    if ($('.text-danger:visible')) {
                        $('.modal_cnt').scrollTop($('.text-danger:visible').first().parent().offset().top - 30);
                    }
                }
            });
        },
        addeducation(action = false) {
            this.selectedItem = -1;
            if (this.callformCap) {
                this.newEducation = {
                    _id: 0,
                    name: null,
                    address: {
                        line1: null,
                        line2: null,
                        aptType: null,
                        locationId: null,
                        locationDetails: null,
                        stateId: null,
                        stateDetails: null,
                        countryId: null,
                        countryDetails: null,
                        zipcode: null
                    },
                    highestDegree: null,
                    highestDegreeDetails: null,
                    majorFieldOfStudy: null,
                    attendedFrom: null,
                    attendedTo: null,
                    graduatedYear: null,
                    degreereceived: null,
                    isAccredited: null,
                    isForProfit: null,
                    graduatedDate: null,
                    documents: {
                        passport: [],
                        graduationCertificate: [],
                        transcripts: [],
                    }
                }
            } else {
                this.newEducation = {
                    _id: 0,
                    name: null,
                    address: {
                        line1: null,
                        line2: null,
                        aptType: null,
                        locationId: null,
                        locationDetails: null,
                        stateId: null,
                        stateDetails: null,
                        countryId: null,
                        countryDetails: null,
                        zipcode: null
                    },
                    highestDegree: null,
                    highestDegreeDetails: null,
                    majorFieldOfStudy: null,
                    attendedFrom: null,
                    attendedTo: null,
                    graduatedYear: null,
                    degreereceived: null,
                    isAccredited: null,
                    isForProfit: null,
                    graduatedDate: null
                };
            }

            this.edit = false;
            this.educationForm = action;
        },
        removeeducation: function (index) {
            Vue.delete(this.value, index);
        }
    },
    components: {
        XIcon,
        VuePerfectScrollbar,
        datepickerField,
        immiInput,
        selectField,
        addressField,
        immiswitchyesno,
        educationModel
    }
};
</script>
