<template>
<div class="vx-col w-full" v-if="checkTemplateField(fieldName)">
    <vx-input-group class="form-input-group">
        <div class="form_group w-full">
            <label class="form_label">First Name<em>*</em></label>
            <vs-input name="firstname" @input="updateData()" v-model="firstName" v-validate="'required'" class="w-full" data-vv-as="First Name" />
        </div>
        <div class="form_group w-full">
            <label class="form_label">Middle Name</label>
            <vs-input class="w-full" @input="updateData()" name="middleName" v-model="middleName" data-vv-as="Middle Name" />
        </div>
        <div class="form_group w-full">
            <label class="form_label">Last Name<em>*</em></label>
            <vs-input class="w-full" @input="updateData()" name="lastName" v-model="lastName" v-validate="'required'" data-vv-as="Last Name" />
        </div>
    </vx-input-group>
    <div class="input-group-error">
        <p class="w-1/3">
            <span class="text-danger text-sm" v-show="errors.has('firstname')">{{errors.first("firstname")}}</span>
        </p>
        <p class="w-1/3"></p>
        <p class="w-1/3">
            <span class="text-danger text-sm" v-show="errors.has('lastName')">{{errors.first("lastName")}}</span>
        </p>
    </div>
</div>
</template>

<script>
export default {
    inject: ["parentValidator"],
    props: ['fieldName','name'],
  data() {
    return {
      firstName:null,
      lastName: null,
      middleName: null,
    };
  },
    created() {
        this.$validator = this.parentValidator;
    },
    mounted() {
        this.firstName = this.name.firstName;
        this.lastName = this.name.lastName;
        this.middleName = this.name.middleName;
    },
    methods: {
  updateData() {
      this.$emit('input', {
        firstName: this.firstName,
        lastName: this.lastName,
        middleName: this.middleName
      })
    }
    }
}
</script>
