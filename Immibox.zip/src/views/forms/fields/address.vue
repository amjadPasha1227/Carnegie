<template>
  <div>
   
    <div
      :class="addFormContainerCls ? 'form-container ' + wrapclass : wrapclass"
      v-if="countries && countries.length > 0"
    >
      <div class="vx-row">
        <div class="vx-col md:w-1/2 w-full" v-if="showLane1">
          <div class="form_group">
            <vs-input
              :name="'line1' + cid"
              v-model="value.line1"
              class="w-full"
              data-vv-as="Street Address"
              :label="'Street Address' + ((validationRequired) ? '*' : '')"
              v-validate="{ required: validationRequired}"
            />

            <span
              class="text-danger text-sm"
              v-show="
                errors.has(
                  (formscope != '' ? formscope + '.' : '') + 'line1' + cid
                )
              "
              >{{
                errors.first(
                  (formscope != "" ? formscope + "." : "") + "line1" + cid
                )
              }}</span
            >
          </div>
        </div>

        <div class="vx-col md:w-1/2 w-full" v-if="showLane2">
          <div class="form_group">
            <label class="form_label">Apt, Suite</label>
            <template v-if="showaptType">
              <div class="address-suite" :class="{'address-suite-start': !showAPTCheckBox}">
                <ul
                  class="custom-radio"
                  vs-type="flex"
                  vs-align="center"
                >
                  <li v-if="showAPTCheckBox">
                    <vs-checkbox
                      :id="'workLocation_' + cid"
                      name="aptType1"
                      v-model="aptType1"
                      @change="setaptType($event, 'APT')"
                      >Apt</vs-checkbox
                    >
                  </li>
                  <li>
                    <vs-checkbox
                      :id="'workLocation_' + cid"
                      name="aptType2"
                      @change="setaptType($event, 'STE')"
                      v-model="aptType2"
                      >Ste</vs-checkbox
                    >
                  </li>
                  <li>
                    <vs-checkbox
                      :id="'workLocation_' + cid"
                      name="aptType3"
                      @change="setaptType($event, 'FLR')"
                      v-model="aptType3"
                      >Flr</vs-checkbox
                    >
                  </li>
                </ul>
                <vs-input
                  :name="'line2' + cid"
                  v-model="value.line2"
                  class=""
                  data-vv-as="Apt, Suite"
                />
              </div>
            </template>
            <template v-else>
              <vs-input
                :name="'line2' + cid"
                v-model="value.line2"
                class="w-full"
                data-vv-as="Apt, Suite"
              />
            </template>
            <span
              class="text-danger text-sm"
              v-show="errors.has('line2' + cid)"
              >{{ errors.first("line2" + cid) }}</span
            >
          </div>

          <span
            class="text-danger text-sm"
            v-show="
              errors.has(
                (formscope != '' ? formscope + '.' : '') + 'line2' + cid
              )
            "
            >{{
              errors.first(
                (formscope != "" ? formscope + "." : "") + "line2" + cid
              )
            }}</span
          >
        </div>

        <div class="vx-col md:w-1/2 w-full" v-if="showCountry">
          <div class="form_group">
            <div class="con-select select-large">
              <label v-if="!placeOnly" class="form_label"
                >Country<em v-if="validationRequired">*</em></label
              >
              <label v-if="placeOnly" class="form_label">{{
                placeOnlyTitle
              }}</label>
        <!-- checkZipCodeFormat() -->
              <multiselect
                @input="
                  locations = [];
                  states = [];
                  value.zipcode = null;
                  
                "
                :name="'country' + cid"
                v-model="value.countryDetails"
                :show-labels="false"
                track-by="id"
                label="name"
                :ref="'refcountry' + cid"
                data-vv-as="Country"
                placeholder="Select Country"
                :options="countrieslist"
                :searchable="true"
                :allow-empty="false"
                :disabled="loading || (disableCountry && prefiilAddress) || disableCountryWithUS"
                v-validate="{ required: validationRequired }"
              >
                <span slot="noResult">No Country Found</span>
              </multiselect>
            </div>

            <span
              class="text-danger text-sm"
              v-show="
                errors.has(
                  (formscope != '' ? formscope + '.' : '') + 'country' + cid
                )
              "
              >{{
                errors.first(
                  (formscope != "" ? formscope + "." : "") + "country" + cid
                )
              }}</span
            >
          </div>
        </div>

        <div class="vx-col md:w-1/2 w-full" v-if="showState">
          <div class="form_group">
            <div class="con-select select-large">
              <label v-if="!placeOnly" class="form_label"
                >State<em v-if="validationRequired">*</em></label
              >
              <label v-if="placeOnly" class="form_label">&nbsp;</label>
              <multiselect
                @input="locations = []"
                :name="'state' + cid"
                v-model="value.stateDetails"
                :disabled="loading || states.length == 0 || value.countryDetails==null"
                :show-labels="false"
                track-by="id"
                label="name"
                data-vv-as="State"
                placeholder="Select State"
                :options="states"
                :searchable="true"
                :allow-empty="false"
                v-validate="{
                  required: validationRequired && states.length > 0,
                }"
              >
                <span slot="noResult">No State Found</span>
              </multiselect>
            </div>

            <span
              class="text-danger text-sm"
              v-show="
                errors.has(
                  (formscope != '' ? formscope + '.' : '') + 'state' + cid
                )
              "
              >{{
                errors.first(
                  (formscope != "" ? formscope + "." : "") + "state" + cid
                )
              }}</span
            >
          </div>
        </div>
        <div class="vx-col md:w-1/2 w-full" v-if="showCity">
          <div class="form_group city-form">
            <div class="con-select select-large addselect">
              <label v-if="!placeOnly" class="form_label"
                >City<em v-if="validationRequired">*</em></label
              >
              <label v-if="placeOnly" class="form_label">&nbsp;</label>
              <multiselect
                :name="'location' + cid"
                v-model="value.locationDetails"
                :disabled="loading  || value.countryDetails==null || value.stateDetails==null "
                :show-labels="false"
                track-by="id"
                label="name"
                data-vv-as="City"
                tag-placeholder="Add"
                :taggable=value.stateId?true:false
                @tag="addLocation"
                placeholder="Select City"
                :options="locations"
                :searchable="true"
                :allow-empty="false"
                v-validate="{
                  required: validationRequired && locations.length > 0,
                }"
              >
                <span slot="noResult">No Locations Found</span>
              </multiselect>
            </div>
            <span
              class="text-danger text-sm"
              v-show="
                errors.has(
                  (formscope != '' ? formscope + '.' : '') + 'location' + cid
                )
              "
              >{{
                errors.first(
                  (formscope != "" ? formscope + "." : "") + "location" + cid
                )
              }}</span
            >
          </div>
        </div>

        <div class="vx-col md:w-1/2 w-full" v-if="showZip">
          <div class="form_group">
            <label class="form_label"
              >Zip Code<em v-if="validationRequired">*</em></label
            >
            <vs-input
           
           
              v-if="validationRequired"
              :name="'zipcode' + cid"
              v-model="value.zipcode"
              @input="checkZipCodeFormat()"
              v-validate="'required|allowNumAndCharInZipcode:refcountry|zipcodev:refcountry' + cid"
              class="w-full"
              data-vv-as="Zip Code"
            />
            <vs-input
              v-else
              @input="checkZipCodeFormat()"
              :name="'zipcode' + cid"
              v-model="value.zipcode"
              v-validate="'allowNumAndCharInZipcode:refcountry|zipcodev:refcountry' + cid"
              class="w-full"
              data-vv-as="Zip Code"
            />

            <span
              class="text-danger text-sm"
              v-show="
                errors.has(
                  (formscope != '' ? formscope + '.' : '') + 'zipcode' + cid
                )
              "
              >{{
                errors.first(
                  (formscope != "" ? formscope + "." : "") + "zipcode" + cid
                )
              }}</span
            >
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import _ from "lodash";
export default {
  inject: ["parentValidator"],

  props: {
    disableCountryWithUS:{
      type:Boolean,
      default:false
    },
    wrapclass: {
      type: String,
      default: " ",
    },
    fieldsArray: Array,
    fieldName: {
      type: String,
      default: null,
    },
    value: Object,
    hideusa: {
      type: Boolean,
      default: false,
    },
    showLane1: {
      type: Boolean,
      default: true,
    },
    showLane2: {
      type: Boolean,
      default: true,
    },
    showCountry: {
      type: Boolean,
      default: true,
    },
    showState: {
      type: Boolean,
      default: true,
    },
    showCity: {
      type: Boolean,
      default: true,
    },
    showZip: {
      type: Boolean,
      default: true,
    },

    formscope: {
      type: String,
      default: "",
    },
    disableCountry: {
      type: Boolean,
      default: false,
    },
    showaptType: {
      type: Boolean,
      default: true,
    },
    
    isCap: {
      type: Boolean,
      default: false,
    },
    validationRequired: {
      type: Boolean,
      default: false,
    },
    addFormContainerCls: {
      type: Boolean,
      default: true,
    },
    countries: Array,
    address: Object,
    cid: {
      type: String,
      default: "",
    },
    placeOnly: {
      type: Boolean,
      default: false,
    }, 
    showAPTCheckBox: {
      type: Boolean,
      default: true,
    },
    prefiilAddress:{
      type: Boolean,
      default: true,
    },
    placeOnlyTitle: String,
  },

  data() {
    return {
      isItFirstTime:0,
      addLocationValue:false,
      taggableValue:false,
      
      mounted: false,
      loading: false,
      states: [],
      locations: [],
      aptType1: false,
      aptType2: false,
      aptType3: false,
      countrieslist: [],
    };
  },
  created() {
    this.$validator = this.parentValidator;
  },
  mounted() {
    this.isItFirstTime =0;
    setTimeout(() => {
      this.init();
    }); 
  },
  methods: {
    clearStatesList(){
      this.states = [];
    },
    checkZipCodeFormat(){
     
      //this.value = this.value.replace(/[^a-z A-Z 0-9]/g, '').replace(/(\..*)\./g, '$1'); this.value = this.value.replace(/ /g,'');
      if(_.has( this.value, "countryDetails" ) && _.has(this.value ,'zipcode') ){
          if(this.checkProperty(this.value ,'countryDetails' ,'allowNumAndCharInZipcode')==true){
            this.value.zipcode = this.value.zipcode.replace(/[^a-z A-Z 0-9]/g, '').replace(/(\..*)\./g, '$1');
          }else{
            this.value.zipcode = this.value.zipcode.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');
          }
      }

    },
    removeUSA(){
      this.states = [];
      this.countrieslist = _.filter(this.countries, function (item) {
          return item.id != 231;
        });
    },
    addUSA(){
      this.countrieslist = _.cloneDeep(this.countries)
    },
    applyWatchers() {
      this.loading = false;
      this.$watch("value.aptType", function () {
      
        this.aptType1 = false;
        this.aptType2 = false;
        this.aptType3 = false;
        if(this.value.aptType == 'APT'){
          this.aptType1= true;
      }
      if(this.value.aptType == 'STE'){
        this.aptType2= true;

      }
      if(this.value.aptType == 'FLR'){
        this.aptType3= true;

      }


      });
      this.$watch("value.countryDetails", function () {
        this.value.countryId = this.value.countryDetails.id;
        this.loadStatesByCountryId(!this.mounted);
      });
      this.$watch("value.stateDetails", function () {
        this.value.stateId = this.value.stateDetails.id;
        this.loadCitiesByStateId(!this.mounted);
      });
      this.$watch("value.locationDetails", function () {
        this.value.locationId = this.value.locationDetails.id;
      });
    },
    setaptType(e, val) {
      if (e.target.name == "aptType1") {
        this.aptType2 = false;
        this.aptType3 = false;
      }
      if (e.target.name == "aptType2") {
        this.aptType1 = false;
        this.aptType3 = false;
      }
      if (e.target.name == "aptType3") {
        this.aptType1 = false;
        this.aptType2 = false;
      }
      if (e.target.checked) {
        this.value.aptType = val;
      } else {
        this.value.aptType = "";
      }
    },
    loadStatesByCountryId(firstLoad = false) {
      this.loading = true;
      let countryId = this.value.countryId;
      if (this.value.countryDetails && this.value.countryDetails.id) {
        countryId = this.value.countryDetails.id;
      }
      if (firstLoad) {
        this.mounted = true;
      }
      if (!countryId) {
        countryId = -1;
      }
      this.$store
        .dispatch("getstates", countryId)
        .then((response) => {
          this.states = response;
          this.loading = false;

          var stateId = this.value.stateId;
          if (stateId != null) {
            var item = _.find(this.states, function (item) {
              return item.id == stateId;
            });

            if (!item) {
              this.value.stateId = null;
              this.value.stateDetails = null;
              this.value.locationId = null;
              this.value.locationDetails = null;
            }
          }

          if (firstLoad) {
            this.loadCitiesByStateId(true);
          }
          if(this.isItFirstTime<2){
            this.$validator.reset();
           

          }
          
          this.isItFirstTime =this.isItFirstTime+1;
        })
        .catch(() => {
          this.loading = false;
        });
    },
    loadCitiesByStateId(firstLoad = false) {
      this.loading = true;

      let countryId = this.value.countryId;
      if (this.value.countryDetails && this.value.countryDetails.id) {
        countryId = this.value.countryDetails.id;
      }
      let stateId = this.value.stateId;
      if (this.value.stateDetails && this.value.stateDetails.id) {
        stateId = this.value.stateDetails.id;
      }
      
      
      this.$store
        .dispatch("getlocations", {
          countryId: countryId,
          stateId: stateId,
        })
        .then((response) => {
          this.locations = response;
          this.loading = false;
       
          var location = this.value.locationId;
          if (location != null) {
            var item = _.find(this.locations, function (item) {
              return item.id == location;
            });
            if (!item) {
              this.value.locationDetails = null;
              this.value.locationId = null;
            }
          }
          if (firstLoad) {
            this.applyWatchers();
          }
          
        })
        .catch(() => {
          this.loading = false;
        });
    },
    init() {
      var _data = _.cloneDeep(this.value);
      if (this.value.aptType != "") {
        if (this.value.aptType == "APT") {
          this.aptType1 = true;
          this.aptType2 = false;
          this.aptType3 = false;
        }
        if (this.value.aptType == "STE") {
          this.aptType1 = false;
          this.aptType2 = true;
          this.aptType3 = false;
        }
        if (this.value.aptType == "FLR") {
          this.aptType1 = false;
          this.aptType3 = true;
          this.aptType2 = false;
        }
      }

      if (this.hideusa) {
        this.countrieslist = _.filter(this.countries, function (item) {
          return item.id != 231;
        });

        var countryId = this.value.countryId;
        if (countryId != null) {
          var item = _.find(this.countrieslist, function (item) {
            return item.id == countryId;
          });
          if (!item) {
            this.value.countryDetails = null;
            this.value.countryId = null;
          }
        }
      } else {
        this.countrieslist = this.countries;

        if ((this.disableCountry && this.prefiilAddress) || (this.value.countryId == null && this.prefiilAddress) || this.disableCountryWithUS) {
          this.value.countryDetails = {
            _id: "61408c9ed01ea1248cdcf6b7",
            id: 231,
            name: "United States",
            phoneCode: 1,
            order: 1,
            currencySymbol: "$",
            currencyCode: "USD",
            zipcodeLength: 5,
            sortName: "united states",
          };
          this.value.countryId = 231;
        }
      }

      this.loadStatesByCountryId(true);
    },
    addLocation(newTag=''){
      if(!newTag){
       return false;
      }
      this.loading = true;
      this.$store
        .dispatch("addLocations", {
          name: newTag,
          stateId: this.value.stateId,
        })
        .then((response) => {
          var tag = response;
          this.locations.push(response);
          this.value.location = response;
          this.loading = false;
         
        })
        .catch((error) => {
          this.loading = false;
         
          
        });
    },
  },
  beforeDestroy() {},
};
</script>
