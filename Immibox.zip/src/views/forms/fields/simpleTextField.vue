<template>
    <div class="vx-col  w-full" :class="wrapclass" v-if="canRenderField(fieldName,fieldsArray,display ,tplsection)">
        <div class="form_group">
            <label class="form_label">{{label}}<em v-if="required">*</em></label>
            <ckeditor :editor="editor" :config="editorConfig" :name="fieldName+cid" @input="updateData()" v-model="value" v-validate="required? 'required|'+datatype : datatype "  class="w-full" :data-vv-as="vvas?vvas:placeHolder" />
          <p v-show="errors.has((formscope!=''?formscope+'.':'')+fieldName+cid)" class="text-danger text-sm">{{ errors.first((formscope!=''?formscope+'.':'')+fieldName+cid) }}</p>
        </div>
    </div>
    </template>
    
    <script>
    import Vue from "vue";
    Vue.use( CKEditor );
    import CKEditor from '@ckeditor/ckeditor5-vue2';
    import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
    export default {
        data() {
        return {
            editor: ClassicEditor,
            editorConfig: {
             toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
            },
        };
        
    },
        inject: ["parentValidator"],
        props: {
              display: {
                type: Boolean,
                default: false,
            },
             fieldsArray:Array,
            vvas:{
            type:String,
                default:""
            },
            wrapclass:{
            type:String,
                default:"md:w-1/2"
            },
            datatype:{
                type:String,
                default:""
            },
             cid: {
                type: String,
                default: null,
            },
            formscope: {
                type: String,
                default: null
            },
            value: null,
            label: {
                type: String,
                default: null,
            },
            fieldName: {
                type: String,
                default: null,
            },
            
        tplsection:{
            type: String,
            default: null,
        },
            placeHolder: {
                type: String,
                default: null,
            },
            required: {
                type: Boolean,
                default: false,
            }
        },
        created() {
            this.$validator = this.parentValidator;
        },
        
      methods: {
        updateData() {
          this.$emit('input', this.value)
        }
      }
    };
    </script>
    