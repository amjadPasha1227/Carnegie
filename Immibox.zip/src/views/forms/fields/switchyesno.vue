<template>
<div class="vx-col  w-full immi_switch yesno-v2" :class="wrapclass" v-if="canRenderField(tplkey,fieldsArray,display ,tplsection,fieldName)">
    <div class="d-block align-center">
        <a class="switch-label mr-3">
            {{label}}<em v-if="required">*</em>
        </a>

        <!-- <vs-switch v-model="value" @input="updateData">
            <span slot="on">Yes</span>
            <span slot="off">No</span>
        </vs-switch>
        ---------------- -->
        <ul class="custom-radio custom-radio_v2 radio_check">
            <li>
                <vs-radio :ref="cid" v-model="value" :vs-name="cid" :vs-value="true"  @click="updateData()">Yes</vs-radio>
            </li>
            <li>
                <vs-radio :ref="cid" v-model="value" :vs-name="cid" :vs-value="false"  @click="updateData()" >No</vs-radio>
            </li> 
        </ul>
        <div class="form_group" v-if="required && formscope" >
            <input type="hidden" :name="fieldName+cid" v-validate="'required'"  data-vv-as="Field"  v-model="dataExists">
            <span v-show="errors.has( formscope+'.'+fieldName+cid)" class="text-danger text-sm" style="">*Field is required</span>
          
        </div>
       
    </div>
    
    
</div>
</template>

<script>
export default {
    inject: ["parentValidator"],
    props: {
          display: {
            type: Boolean,
            default: false,
        },
        fieldsArray: Array,
        vvas: {
            type: String,
            default: ""
        },
        wrapclass: {
            type: String,
            default: "md:w-1/2"
        },
        datatype: {
            type: String,
            default: ""
        },
        cid: {
            type: String,
            default: null,
        },
        formscope: {
            type: String,
            default: null
        },
        value: null,
        label: {
            type: String,
            default: null,
        },
        fieldName: {
            type: String,
            default: null,
        },
        tplsection:{
            type: String,
            default: null,
        },
        tplkey:{
            type: String,
            default: null,
        },
        placeHolder: {
            type: String,
            default: null,
        },
        required: {
            type: Boolean,
            default: false,
        }
    },
    watch:{
        value:function (newVal){
            if(newVal == true|| newVal == false){
                this.dataExists = 'valueExists'
            }
            this.updateData()
        }
    },
    created() {
        this.$validator = this.parentValidator;
    },

    methods: {
        updateData() {
            this.$emit('input', this.value)
        }
    },
    mounted(){
        if(this.value == true|| this.value == false){
            this.dataExists = 'valueExists'
        }
    },
    data(){
        return{
            dataExists:''
        }
    }
};
</script>
