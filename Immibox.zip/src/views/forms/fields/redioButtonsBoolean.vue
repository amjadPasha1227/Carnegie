<template>
  <div
    class="vx-col w-full"
    :class="wrapclass"
    v-if="canRenderField(tplkey,fieldsArray,display ,tplsection,fieldName)"
  >
      <div class="list-radio-wrap">
        <h6 class="d-flex">{{ formatedLabel }}
          <!-- <em v-if="required">*</em> -->
          <div class="IB_tooltip"  v-if="helpText"> <span><info-icon size="1.5x" class="custom-class"></info-icon></span>
            <div class="tooltip_cnt">
                <p>{{ helpText }}</p>
            </div>
          </div>
        </h6>
        
         <ul class="list-radio" vs-type="flex" vs-align="center">
         <li @click="setValue(true)" :class="{ 'active':value==true}"> <span    :ref="cid+'Yes'">Yes</span></li>
         <li @click="setValue(false)" :class="{ 'active':value==false}"> <span    :ref="cid+'No'">No</span></li>
         <li v-if="showNA && false"  @click="setValue('N/A')" :class="{ 'active':value=='N/A'}"> <span    :ref="cid+'N/A'">N/A</span></li>
        </ul>
        
      
      <template v-if="required">
      <input :name="cid" v-validate="'required'" type="hidden" v-model="value"  >
      <p
        v-show="errors.has((formscope ? formscope + '.' : '') + cid)"
        class="text-danger text-sm"
      ><template v-if="defaultError">*Field is required </template>
      <template v-else>{{ errors.first((formscope? formscope + "." : "") + cid) }}</template>
        
      </p>
    </template>
  </div>
  </div>
</template>
    
    <script>
export default {
  inject: ["parentValidator"],

  props: {
    helpText: {
      type: String,
      default:"",
    },
    defaultError:{
      type: Boolean,
      default: false,
    },
    showNA: {
      type: Boolean,
      default: false,
    },
    tplkey:{
        type: String,
        default: null,
    },
    tplsection:{
        type: String,
        default: null,
    },
    display: {
      type: Boolean,
      default: false,
    },
    fieldsArray: Array,
    vvas: {
      type: String,
      default: "",
    },
    wrapclass: {
      type: String,
      default: "md:w-1/2",
    },
    datatype: {
      type: String,
      default: "",
    },
    cid: {
      type: String,
      default: null,
    },
    formscope: {
      type: String,
      default: '',
    },
    value: null,
    label: {
      type: String,
      default: null,
    },
    fieldName: {
      type: String,
      default: null,
    },
    placeHolder: {
      type: String,
      default: null,
    },
    required: {
      type: Boolean,
      default: false,
    },
    callFromCap:{
      type:Boolean,
      default:false
    }
  },
  created() {
    this.$validator = this.parentValidator;
  },

  methods: {
    setValue(val){
      this.$emit("input", val);
    },
    updateData() {
      this.$emit("input", this.value);
    },
  },
  mounted(){
    if(this.required){
      this.formatedLabel = this.label+' *'
    }
    else{
      this.formatedLabel = this.label
    }
    setTimeout(()=>{
      this.everyThingLoaded=true;
    });
  let _self =this;
  try{
    setTimeout(()=>{
  // Free-Flow  Sequential
  
     let refId = _self.cid+_self.value;
     if(!_self.value){
      refId = _self.cid+'No';
     }
      const elem = _self.$refs[refId];
      //elem.click();
    } ,100);

  }catch(err){
   
  }


  },
  data: () => ({
    everyThingLoaded:false,
    formatedLabel:''
  })
};
</script>
    