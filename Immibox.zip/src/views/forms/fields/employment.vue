<template>
<div class="vx-col  w-full"  >
    <div class="form-container alt-rows-bg ">
        
        <h3 v-if="callFromSpouse && canRenderField('prevEmploymentInfo',fieldsArray ,false ,tplsection) " class="small-header spouse_immi_header">Employment</h3>
        <div class="vx-row">

            <div class="vx-col w-full pad0">
                <div class="vx-row delete-row emp-bg-info" :class="{'border_top':value.length > 1}" v-for="(emploment, index) in value" :key="index">
                    <immiInput :notRequired="notRequired" :callFromEmployment="true" :tplkey="'employerName'" :fieldsArray="fieldsArray" :tplsection="tplsection" :display="false" :required="true" :cid="'benfemployerName'+index+cid" :formscope="formscope" v-model="emploment.employerName" :fieldName="'benfemployerName'+index+fieldName" label="Employer Name" placeHolder="Employer Name"  :helpText="'Make sure to input your Employer information and not the Client details.'"/>
                    
                    <immiswitchyesno :notRequired="notRequired" @input="updateAllCurrentEmp(index)" :tplsection="tplsection" :tplkey="'currentEmployer'"  v-if="index == 0 && (tplsection!='beneficiaryInfo.prevEmploymentOutsideUS')" :display="false" :fieldsArray="fieldsArray"  :cid="'currentEmployer'+ index+cid" :formscope="formscope" v-model="emploment.currentEmployer"  :fieldName="'currentEmployer'+index+fieldName" :wrapclass="'mt-0 md:w-1/2 pt-8'"  label="Current Employer?" placeHolder="" />
              
                     <!-- :required="emploment.employerName!=null && emploment.employerName!=''" -->
                  <!----- 
                     <redioButtons   @input="updateAllCurrentEmp(index)" wrapclass="md:w-1/2 " v-if="index == 0" :display="true" :fieldsArray="fieldsArray"  :cid="'currentEmployer'+ index" :formscope="formscope" v-model="emploment.currentEmployer"  :fieldName="'currentEmployer'+index" label="Current Employer?" placeHolder="" />
                      -->                        
                    <immiInput  :notRequired="notRequired" :tplkey="'jobTitle'" :tplsection="tplsection" :display="false" :required="true"  :fieldsArray="fieldsArray" :cid="'benjobTitle'+ index+cid" :formscope="formscope" v-model="emploment.jobTitle"  :fieldName="'jobTitle'+index+fieldName" label="Job Title" placeHolder="Job Title" />
                    <!-- :required="emploment.businessType!=null && emploment.businessType!=''" -->
                    <immiInput :notRequired="notRequired"  :tplkey="'businessType'" :tplsection="tplsection"  :display="false" :required="true"  :fieldsArray="fieldsArray" :cid="'businessType'+ index+cid" :formscope="formscope" v-model="emploment.businessType"  :fieldName="'businessType'+index+fieldName" label="Employer Business E.g., IT" placeHolder="Employer Business" />
                    <!-- <immiInput :onlyNumbers="true" :allowFloatingPoint="true"  :maxLength="20" :tplkey="'salary'" :tplsection="tplsection"  :display="false" :required="true"  :fieldsArray="fieldsArray" :cid="'salary'+ index+cid" :formscope="formscope" v-model="emploment.salary"  :fieldName="'salary'+index+fieldName" label="Salary" placeHolder="Salary" /> -->




                    <div class="vx-col md:w-1/2 w-full d-flex align-items-start" v-if="canRenderField('salary',fieldsArray ,false ,tplsection) || canRenderField('payFrequency',fieldsArray ,false ,tplsection) ">
                        <div class="form_group custom_filed w-2/3" v-if="canRenderField('salary',fieldsArray ,false ,tplsection)">
                            <label class="form_label">Salary<em v-if="checkFieldIsRequired({'key':'salary','section':tplsection, 'fieldsArray':fieldsArray, 'required':true,'notRequired':notRequired })">*</em></label>
                            <vs-input maxLength="10" :name="'salary'+index" v-validate="checkFieldIsRequired({'key':'salary','section':tplsection, 'fieldsArray':fieldsArray, 'required':true ,'notRequired':notRequired })?'required|max:12':''" class="w-full"
                            data-vv-as="Salary" v-model="emploment.salary"
                            oninput="this.value = this.value.replace(/[^0-9 .]/g, '').replace(/(\..*)\./g, '$1'); this.value = this.value.replace(/ /g,'');" />
                            <template v-if="formscope">
                                <span class="text-danger text-sm nowrap" v-show="errors.has(formscope+'.salary'+index)">{{
                                errors.first(formscope+'.salary'+index) }}</span>
                            </template>
                            <template v-else>
                                <span class="text-danger text-sm nowrap" v-show="errors.has(formscope+'salary'+index)">{{
                                errors.first(formscope+'salary'+index) }}</span>
                            </template>
                        </div>
                        <div class="form_group custom_filed w-1/3" v-if="canRenderField('payFrequency',fieldsArray ,false ,tplsection)">
                            <label for class="form_label">&nbsp;</label>
                            <div class="con-select">
                            <multiselect :name="'payFrequency'+index" v-validate="checkFieldIsRequired({'key':'payFrequency','section':tplsection, 'fieldsArray':fieldsArray, 'required':true ,'notRequired':notRequired})"
                                v-model="emploment.payFrequency" :show-labels="false" data-vv-as="Pay Frequency"
                                placeholder="Frequency" :multiple="false" :options="payFrequencyList"
                                :searchable="true" :close-on-select="true" :preselect-first="true" :allow-empty="false"></multiselect>
                                <template v-if="formscope">
                                    <span class="text-danger text-sm" v-show="errors.has(formscope+'.payFrequency'+index)">{{
                                    errors.first(formscope+'.payFrequency'+index) }}</span>
                                </template>
                                <template>
                                    <span class="text-danger text-sm" v-show="errors.has(formscope+'payFrequency'+index)">{{
                                    errors.first(formscope+'payFrequency'+index) }}</span>
                                </template>
                                

                            </div>

                        </div>

                    </div>

                    <template v-if="forPermQiestionnaire">
               
                        <!-- <immiPhone :notRequired="notRequired"  :tplkey="'workPhoneNumber'" :tplsection="tplsection"   :itemArrayIndex="index" :display="false" :fieldsArray="fieldsArray" @updatephoneCountryCode="updateworkPhoneCountryCode" :countrycode="emploment.workPhoneCountryCode.countryCode" :cid="'empworkPhoneNumber'+index+cid" :formscope="formscope" v-model="emploment.workPhoneNumber" :required="true" fieldName="workPhoneNumber" label="Work Phone Number" placeHolder="Work Phone Number" /> -->
                        <!-- <immiPhone :notRequired="notRequired" :tplsection="tplsection" :tplkey="'fax'"  :itemArrayIndex="index" :display="false" :fieldsArray="fieldsArray" @updatephoneCountryCode="updatefaxCountryCode" :countrycode="emploment.faxCountryCode.countryCode" :cid="'empfaxPhoneNumber'+index+cid" :formscope="formscope" v-model="emploment.fax" fieldName="emp_fax_phone_number" label="Fax Number" placeHolder="Work Fax Number" /> -->

                        <immiInput :notRequired="notRequired"  :tplsection="tplsection" :tplkey="'hoursWorkedPerWeek'" :fieldsArray="fieldsArray"  :display="false" :maxLength="3"  :required="false" :cid="'hoursWorkedPerWeek'+index+cid" :onlyNumbers="true" :formscope="formscope" v-model="emploment.hoursWorkedPerWeek" :fieldName="'hoursWorkedPerWeek'" label="Work Hours per Week" placeHolder="Work Hours per Week" />  
                    </template>
                    <div class=" vx-col w-full" v-if="canRenderField('jobDuties',fieldsArray ,false ,tplsection)">
                        <div class="form_group w-full marb20">
                            <label class="form_label">Description of Duties Performed<em v-if="checkFieldIsRequired({'key':'jobDuties','section':tplsection, 'fieldsArray':fieldsArray, 'required':true,'notRequired':notRequired })">*</em>
                                <div class="IB_tooltip">
                                    <span
                                        ><info-icon size="1.5x" class="custom-class"></info-icon
                                    ></span>
                                    <div class="tooltip_cnt">
                                        <p>
                                            Please fill in your Job Duties only. Avoid inserting all project details.
                                        </p>
                                    </div>
                                </div>
                            </label>
                            
                            <ckeditor  data-vv-as=" Content"  :name="'descriptionOfDuties'+index" v-validate="checkFieldIsRequired({'key':'jobDuties','section':tplsection, 'fieldsArray':fieldsArray, 'required':true,'notRequired':notRequired })? 'required':''"   :editor="editor" v-model="emploment.jobDuties" :config="editorConfig"></ckeditor>
                            <span class="text-danger text-sm" v-show="errors.has(formscope+'.'+'descriptionOfDuties'+index)">*Description of Duties are  required</span>
                        </div>
                    </div> 
                    <datepickerField :notRequired="notRequired"  :fieldsArray="fieldsArray" :tplkey="'startDate'" :tplsection="tplsection" :display="false"  wrapclass="md:w-1/2" v-model="emploment.startDate" :formscope="formscope" :fieldName="'startDate' + index + fieldName" label="Start Date" @input="updatestartDate($event,index)" :validationRequired="emploment.employerName!=null && emploment.employerName!=''" />
                    <datepickerField :notRequired="notRequired" :isDisabled="!emploment.startDate" :tplkey="'endDate'" :fieldsArray="fieldsArray" v-if="!emploment.currentEmployer " :tplsection="tplsection" :display="false"  wrapclass="md:w-1/2" v-model="emploment.endDate" :dateEnableFrom="emploment.startDate" :formscope="formscope" :fieldName="'attendedTo' + index + fieldName" label="End Date" :validationRequired="emploment.employerName!=null && emploment.employerName!=''" />
                    <!-- <immiInput   :cid="'benfemployerName'+index" :formscope="formscope" v-model="emploment.supervisor.name" :fieldName="'benfemployerName'" label="Supervisor Name" placeHolder="Supervisor Name" />   
                    <immiPhone :display="true" :fieldsArray="['emp_work_phone_number']" :countrycode="emploment.supervisor.phoneCountryCode.countryCode" :cid="'supervisorPhoneNumber'+index" :formscope="formscope" v-model="emploment.supervisor.phoneNumber"  fieldName="emp_work_phone_number" label="Supervisor Phone Number" placeHolder="Supervisor Phone Number" /> -->
                    <div class="vx-row vx-col w-full  pad0 mar0" v-if="checkProperty(emploment ,'supervisor')">
                        <immiInput :notRequired="notRequired"  :required="false" :fieldsArray="fieldsArray" :cid="'benfemployerName'+index+cid" :tplsection="'beneficiaryInfo.prevEmploymentInfo.supervisor'" :tplkey="'name'" :formscope="formscope" v-model="emploment.supervisor.name" :fieldName="'benfemployerName'+fieldName" label="Supervisor Name" placeHolder="Supervisor Name" />   
                        <immiPhone :notRequired="notRequired" :itemArrayIndex="index" :fieldsArray="fieldsArray"  @updatephoneCountryCode="updateSupervisorphoneCountryCode" :tplkey="'phoneNumber'" :tplsection="'beneficiaryInfo.prevEmploymentInfo.supervisor'" :display="false"  :countrycode="emploment.supervisor.phoneCountryCode.countryCode" :cid="'supervisorPhoneNumber'+index+cid" :formscope="formscope" v-model="emploment.supervisor.phoneNumber" :required="false" :fieldName="'emp_work_phone_number'+fieldName" label="Supervisor Phone Number" placeHolder="Supervisor Phone Number" />
                    </div>
                    <!-----
                    <immitextarea :fieldsArray="fieldsArray" wrapclass=" "  v-model="emploment.jobDuties" :display="true" :fieldName="'ben_jobDuties'+index" label="Description of Duties Performed" placeHolder="Job Duties"></immitextarea>
                    --->
                   
                    <div class="vx-col w-full"  v-if="canRenderField('address',fieldsArray ,false ,tplsection) && (tplsection=='beneficiaryInfo.prevEmploymentInfo' || tplsection=='dependentsInfo.spouse.prevEmploymentInfo' || tplsection == 'dependentsInfo.childrens.prevEmploymentInfo') "><h3 v-if="tplsection != 'dependentsInfo.childrens.prevEmploymentInfo'" class="small-header">Work Address</h3>
                   <addressField :disableCountryWithUS="disableCountryWithUS" :hideusa="false" :prefiilAddress="prefillCountryInQuestionnaire" wrapclass="educationaddress" :tplkey="'address'" :fieldsArray="fieldsArray" :formscope="formscope" :showaptType="true" :addFormContainerCls="true" :validationRequired="checkFieldIsRequired({'key':'address','section':tplsection, 'fieldsArray':fieldsArray, 'required':true ,'notRequired':notRequired })" :countries="countries" v-model="emploment.address" :fieldName="'address' + index + fieldName" :cid="'employeraddress'+index+cid" />
                    </div>
                    <div class="vx-col w-full" v-if="canRenderField('address',fieldsArray ,false ,tplsection) && (tplsection=='beneficiaryInfo.prevEmploymentOutsideUS' || tplsection=='dependentsInfo.spouse.prevEmploymentOutsideUS')"><h3 class="small-header">Work Address</h3>
                   <addressField  :hideusa="true" :prefiilAddress="prefillCountryInQuestionnaire" wrapclass="educationaddress" :tplkey="'address'" :fieldsArray="fieldsArray" :formscope="formscope" :showaptType="true" :addFormContainerCls="true" :validationRequired="checkFieldIsRequired({'key':'address','section':tplsection, 'fieldsArray':fieldsArray, 'required':true, 'notRequired':notRequired })" :countries="countries" v-model="emploment.address" :fieldName="'address' + index + fieldName" :cid="'employeraddress'+index+cid" />
                    </div>
                    
                   
                    
                    
                    
                    <div class="delete" v-if="value.length > 1">
                        <a @click="removeemployment(index)">
                            <img src="@/assets/images/main/delete-row-img-white.svg" />
                        </a>
                    </div>

                   <!-- <div class="divider full-divider mb-0" v-if="value.length > 0 && index < (value.length- 1) "></div> -->

                </div>
            </div>
        </div>
        <div class="m-auto" v-if="value.length > 0" vs-type="flex" vs-align="center" vs-lg="2" vs-sm="2">
            <a @click="addemployment" class="add-more" type="filled">
                <span>+</span>Add another employer
            </a>
        </div>
    </div>
</div>
</template>

<script>
    
import immiPhone from "@/views/forms/fields/phonenumber.vue";
import _ from "lodash";
import datepickerField from "@/views/forms/fields/datepicker.vue";
import immiInput from "@/views/forms/fields/simpleinput.vue";
import addressField from "@/views/forms/fields/address.vue";
import selectField from "@/views/forms/fields/simpleselect.vue";
import immiswitchyesno from "@/views/forms/fields/switchyesno.vue";
import immitextarea from "@/views/forms/fields/simpletextarea.vue";
import JQuery from "jquery";

import redioButtons from "@/views/forms/fields/redioButtons.vue";
import Vue from "vue";
import moment from "moment";
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { InfoIcon } from "vue-feather-icons";
export default {
    inject: ["parentValidator"],
    props: {
        notRequired:{
            type: Boolean,
            default: false,
        },
        prefillCountryInQuestionnaire:{
            type: Boolean,
            default: true,
        },
        callFromSpouse:{
            type: Boolean,
            default: false
        },
        tplsection:{
            type: String,
            default: null,
        },
          fieldName: String,
        fieldsArray: Array,
        //   formscope: {
        //     type: String,
        //     default: ''
        // },
        value: Array,
        petition:{
            type:Object,
            default:null
       },
        formscope: {
            type: String,
            default: ''
        },
        cid: String,
        forPermQiestionnaire: {
            type: Boolean,
            default: false
        },
        hideusa: {
      type: Boolean,
      default: false,
    },
        datatype: {
            type: String,
            default: ""
        },
        countries: Array
    },
    data() {
        return {
            disableCountryWithUS:false,
            payFrequencyList: ["Hour", "Week", "Month", "Year"],
            featureDates:null,
            editor: ClassicEditor,
            editorConfig: {
             toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
            },
        };
        
    },
    created() {
        this.$validator = this.parentValidator;
    },
    mounted() {
        var $self = this;
         this.value.forEach(function (item, index) {             
            var _a = _.cloneDeep($self.value[index]);              
            $self.$set($self.value, index, _a);     
        })
        this.featureDates = new Date();
        this.$validator.reset();

    },
    methods: {
        updateUsaCountry(val = true){ 
            this.disableCountryWithUS = val;
        },
        updatestartDate(val,indx =''){
            
            if(val){
                let startDate = moment(val);
                if(this.value[indx].endDate){
                let endDate= moment(this.value[indx].endDate)
                if(startDate.isAfter(endDate , 'day')){
                    this.value[indx]['endDate'] = null
                }
                }
            }
            else{
                this.value[indx]['endDate'] = null
            }
            
        },

        updateSupervisorphoneCountryCode(data){

            if(_.has(data ,'itemArrayIndex') && _.get(data ,'itemArrayIndex')>-1){
                this.value[data['itemArrayIndex']].supervisor.phoneCountryCode =data;
            }

        },
        
        updateworkPhoneCountryCode(data){
            if(_.has(data ,'itemArrayIndex') && _.get(data ,'itemArrayIndex')>-1){
                this.value[data['itemArrayIndex']].workPhoneCountryCode =data;
            }
           
            //
        },
        updatefaxCountryCode(data){
           // emploment.faxCountryCode
           if(_.has(data ,'itemArrayIndex') && _.get(data ,'itemArrayIndex')>-1){
                this.value[data['itemArrayIndex']].faxCountryCode =data;
            }
        },
        updateAllCurrentEmp(index){
           
            _.map(this.value ,(emploment , ind)=>{
                if(emploment.currentEmployer && ind== index){

                }else{
                    emploment['currentEmployer']  =false; 
                }

            })

        },
        addemployment: function () {
            let item = {
                _id: 0,
                        employerName: '',
                        address: {
                            line1: null,
                            line2: null,
                            aptType: null,
                            locationId: null,
                            locationDetails: null,
                            stateId: null,
                            stateDetails: null,
                            countryId: null,
                            countryDetails: null,
                            zipcode: null
                        },
                        businessType: null,
                        jobTitle:null,
                        jobDuties: null,
                        startDate: null,
                        endDate: null,
                        payFrequency:null,
                        salary:null,
                        currentEmployer:null
            }
            if(this.forPermQiestionnaire){
                item = Object.assign(item ,{

                            workPhoneNumber: "",
                                workPhoneCountryCode: {
                                countryCode:null,
                                countryCallingCode: ''
                            },
                            fax: '',
                            faxCountryCode: {
                                countryCode:null,
                                countryCallingCode: ''
                            },
                            hoursWorkedPerWeek: null,
                            supervisor:{
                                name:'',
                                phoneNumber:'',
                                phoneCountryCode:{
                                    countryCode:'',
                                    countryCallingCode:''
                                },


                            }

                })

            }
            this.value.push(item);

            
            setTimeout(function(){
                JQuery(".questionnaire").scrollTop(JQuery('.emp-bg-info:last').position().top );

                
            },100)


        },
        removeemployment: function (index) {
            Vue.delete(this.value, index);
        }
    },
    components: {
        immiPhone,
        immitextarea,
        datepickerField,
        immiInput,
        selectField,
        addressField,
        immiswitchyesno,
        redioButtons,
        InfoIcon
    }
};
</script>
