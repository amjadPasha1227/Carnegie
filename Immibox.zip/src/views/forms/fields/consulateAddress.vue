<template>
    <div>
     
      <div
        :class="addFormContainerCls ? 'form-container ' + wrapclass : wrapclass"
        v-if="countries && countries.length > 0"
      >
        <div class="vx-row">
          <div class="vx-col md:w-1/2 w-full" v-if="showCountry">
            <div class="form_group">
              <div class="con-select select-large">
                <label v-if="!placeOnly" class="form_label"
                  >Country<em v-if="validationRequired">*</em></label>
                <label v-if="placeOnly" class="form_label">{{ placeOnlyTitle }}</label>
                <multiselect
                  @input="locations = []; "
                  :name="'country' + cid"
                  v-model="value.countryDetails"
                  :show-labels="false"
                  track-by="id"
                  label="name"
                  :ref="'refcountry' + cid"
                  data-vv-as="Country"
                  placeholder="Select Country"
                  :options="countrieslist"
                  :searchable="true"
                  :allow-empty="false"
                  :disabled="loading|| (disableCountry && prefiilAddress)"
                  v-validate="{ required: validationRequired }"
                >
                  <span slot="noResult">No Country Found</span>
                </multiselect>
              </div>
  
              <span
                class="text-danger text-sm"
                v-show="
                  errors.has(
                    (formscope != '' ? formscope + '.' : '') + 'country' + cid
                  )
                "
                >{{
                  errors.first(
                    (formscope != "" ? formscope + "." : "") + "country" + cid
                  )
                }}</span
              >
            </div>
          </div>
          <div class="vx-col md:w-1/2 w-full" v-if="showCity">
            <div class="form_group city-form">
              <div class="con-select select-large addselect">
                <label v-if="!placeOnly" class="form_label"
                  >City<em v-if="validationRequired">*</em></label
                >
                <label v-if="placeOnly" class="form_label">&nbsp;</label>
                <multiselect
                  :name="'location' + cid"
                  v-model="value.locationDetails"
                  :disabled="loading  || value.countryDetails==null"
                  :show-labels="false"
                  track-by="id"
                  label="name"
                  data-vv-as="City"
                  tag-placeholder="Add"
                  :taggable=false
                  @tag="addLocation"
                  placeholder="Select City"
                  :options="locations"
                  :searchable="true"
                  :allow-empty="false"
                  v-validate="{
                    required: validationRequired && locations.length > 0,
                  }"
                >
                  <span slot="noResult">No Locations Found</span>
                </multiselect>
              </div>
              <span
                class="text-danger text-sm"
                v-show="
                  errors.has(
                    (formscope != '' ? formscope + '.' : '') + 'location' + cid
                  )
                "
                >{{
                  errors.first(
                    (formscope != "" ? formscope + "." : "") + "location" + cid
                  )
                }}</span
              >
            </div>
          </div>
        </div>
      </div>
    </div>
  </template>
  
  <script>
  import _ from "lodash";
  export default {
    inject: ["parentValidator"],
  
    props: {
      wrapclass: {
        type: String,
        default: " ",
      },
      fieldsArray: Array,
      fieldName: {
        type: String,
        default: null,
      },
      value: Object,
      hideusa: {
        type: Boolean,
        default: false,
      },
      showCountry: {
        type: Boolean,
        default: true,
      },
      showCity: {
        type: Boolean,
        default: true,
      },
      formscope: {
        type: String,
        default: "",
      },
      disableCountry: {
        type: Boolean,
        default: false,
      },
      validationRequired: {
        type: Boolean,
        default: false,
      },
      addFormContainerCls: {
        type: Boolean,
        default: true,
      },
      countries: Array,
      address: Object,
      cid: {
        type: String,
        default: "",
      },
      placeOnly: {
        type: Boolean,
        default: false,
      }, 
      prefiilAddress:{
        type: Boolean,
        default: true,
      },
      placeOnlyTitle: String,
    },
  
    data() {
      return {
        isItFirstTime:0,
        addLocationValue:false,
        taggableValue:false,
        
        mounted: false,
        loading: false,
        states: [],
        locations: [],
        aptType1: false,
        aptType2: false,
        aptType3: false,
        countrieslist: [],
      };
    },
    created() {
      this.$validator = this.parentValidator;
    },
    mounted() {
      this.isItFirstTime =0;
      setTimeout(() => {
        this.init();
      }); 
    },
    methods: {
      applyWatchers() {
        this.loading = false;
        this.$watch("value.countryDetails", function () {
          this.value.countryId = this.value.countryDetails.id;
          this.loadCitesByCountryId(!this.mounted);
        });
        this.$watch("value.locationDetails", function () {
          this.value.locationId = this.value.locationDetails.id;
        });
      },
      loadCitesByCountryId(firstLoad = false) {
        this.loading = true;
        let countryId = this.value.countryId;
        if (this.value.countryDetails && this.value.countryDetails.id) {
          countryId = this.value.countryDetails.id;
        }
        if (firstLoad) {
          this.mounted = true;
        }
        if (!countryId) {
          countryId = -1;
        }
        let payLoad = {
            matcher:{
                countryId:countryId
            },
            "page": 1,
            "perpage": 1000,
            "category": "us_embassy_list", 
        }
        this.$store
          .dispatch("getList", {data:payLoad ,path:'/masterdata/list'})
          .then((response) => {
            this.locations = response.list;
            this.loading = false;
  
            var location = this.value.locationId;
          if (location != null) {
            var item = _.find(this.locations, function (item) {
              return item.id == location;
            });
            if (!item) {
              this.value.locationDetails = null;
              this.value.locationId = null;
            }
          }
            if (firstLoad) {
              this.applyWatchers();
            }
            if(this.isItFirstTime<2){
              this.$validator.reset();
             
  
            }
            
            this.isItFirstTime =this.isItFirstTime+1;
          })
          .catch(() => {
            this.loading = false;
          });
      },
      init() {
        var _data = _.cloneDeep(this.value);
  
        if (this.hideusa) {
          this.countrieslist = _.filter(this.countries, function (item) {
            return item.id != 231;
          });
  
          var countryId = this.value.countryId;
          if (countryId != null) {
            var item = _.find(this.countrieslist, function (item) {
              return item.id == countryId;
            });
            if (!item) {
              this.value.countryDetails = null;
              this.value.countryId = null;
            }
          }
        } else {
          this.countrieslist = this.countries;
  
          if ((this.disableCountry && this.prefiilAddress) || (this.value.countryId == null && this.prefiilAddress)) {
            this.value.countryDetails = {
              _id: "61408c9ed01ea1248cdcf6b7",
              id: 231,
              name: "United States",
              phoneCode: 1,
              order: 1,
              currencySymbol: "$",
              currencyCode: "USD",
              zipcodeLength: 5,
              sortName: "united states",
            };
            this.value.countryId = 231;
          }
        }
  
        this.loadCitesByCountryId(true);
      },
      addLocation(newTag=''){
        if(!newTag){
         return false;
        }
        this.loading = true;
        this.$store
          .dispatch("addLocations", {
            name: newTag,
            stateId: this.value.stateId,
          })
          .then((response) => {
            var tag = response;
            this.locations.push(response);
            this.value.location = response;
            this.loading = false;
           
          })
          .catch((error) => {
            this.loading = false;
           
            
          });
      },
    },
    beforeDestroy() {},
  };
  </script>
  