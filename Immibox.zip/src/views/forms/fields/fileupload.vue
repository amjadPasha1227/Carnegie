<template>
  
  
   
<div class="vx-col  w-full" :class="wrapclass" v-if="fieldName !=null && canRenderField(tplkey,fieldsArray, display,tplsection,fieldName)">
    <div class="form_group" @click="showFileTypeError = ''">
        <label class="form_label" ><span v-html="getLabel" style="display:inline"></span>      <div class="IB_tooltip" v-if="tooltip!=null">
                    <span>
                      <info-icon size="1.5x" class="custom-class"></info-icon>
                    </span>
                    <div class="tooltip_cnt">
                      <p>
                        {{tooltip}}
                      </p>
                    </div>
                  </div></label>
        <file-upload  :ref="fieldName+cid"  v-validate="checkFieldIsRequired({'key':tplkey,'section':tplsection, 'fieldsArray':fieldsArray, 'required':required })? 'required': datatype " :hideSelected="true" v-model="fvalue" class="file-upload-input file-upload-input-cs" :name="fieldName+cid+cid"  :data-vv-as="vvas?vvas:placeHolder" :multiple="multiple" :accept="docAcceptType" @input="upload(fvalue)">
            <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
            
            Upload
            <span class="loader" v-if="filesUploading" ><img src="@/assets/images/main/loader.gif"></span>
        </file-upload>

        <p v-show="errors.has((formscope!=''?formscope+'.':'')+fieldName+cid)" class="text-danger text-sm-doc">{{ errors.first((formscope!=''?formscope+'.':'')+fieldName+cid) }}</p>
        <p v-show="showFileTypeError" class="text-danger text-sm-doc" >{{ showFileTypeError }}</p>
            <p v-if="noteInfo" class="upload_noteinfo"><strong>Note:</strong> Letterhead document must contains either header or footer.</p>
            <!-- <a @click="viewFile()">Click here</a> to view sample document. --> 
        <ul class="uploaded-list">
            <template v-if="callfromPetitionDocs">
                <template v-for="(item, index) in getlist">
                    <template v-if="checkProperty(item,'uploadedByRoleId') &&  getUserRoleId == 51 && !showToBeneficiary  ">
                        <template v-if="checkProperty(item,'uploadedByRoleId') == 51">
                            <vs-chip v-if="checkProperty(item, 'status') && checkProperty(item, 'path')" @click="item.status=false;remove(index)"  :key="index" :closable="checkProperty(item, 'isNew') == true">
                                <img src="@/assets/images/main/down-arrow2.svg" @click="downloads3file(item)" />
                                {{ item.name }}
                            </vs-chip>
                        </template>
                    </template>
                    <template v-else>      
                        <vs-chip v-if="checkProperty(item, 'status') && checkProperty(item, 'path')" @click="item.status=false;remove(index)"  :key="index" :closable="checkProperty(item, 'isNew') == true">
                            <img src="@/assets/images/main/down-arrow2.svg" @click="downloads3file(item)" />
                            {{ item.name }}
                        </vs-chip>
                    </template>
                </template>
            </template>
            <template v-else>
                <template v-for="(item, index) in getlist">
                    <template v-if="checkProperty(item,'uploadedByRoleId') &&  getUserRoleId == 51 && !showToBeneficiary  ">
                        <template v-if="checkProperty(item,'uploadedByRoleId') == 51">
                            <vs-chip v-if="checkProperty(item, 'status') && checkProperty(item, 'path')" @click="item.status=false;remove(index)"  :key="index" closable>
                                <img src="@/assets/images/main/down-arrow2.svg" @click="downloads3file(item)" />
                                {{ item.name }}
                            </vs-chip>
                        </template>
                    </template>
                    <template v-else>
                        <vs-chip v-if="checkProperty(item, 'status') && checkProperty(item, 'path')" @click="item.status=false;remove(index)"  :key="index" closable>
                            <img src="@/assets/images/main/down-arrow2.svg" @click="downloads3file(item)" />
                            {{ item.name }}
                        </vs-chip>
                    </template>
                </template>
            </template>
        </ul>
    </div>
</div>
<!-- <vs-popup class="document_modal"  :title="checkProperty(selectedFile,'name')" :active.sync="docPrivew">
        <h2></h2>

        <div  class="">
            <img :class="{'pdf_view_download':docType == 'pdf', 'office_view_download':docType == 'office'  , 'image_view_download':docType =='image'}" class="download-button" @click="downloads3file(selectedFile)" src="@/assets/images/download.svg" />
            <span :class="{'pdf_view_close':docType == 'pdf', 'office_view_close':docType == 'office'  , 'image_view_close':docType =='image'}" class="close close2" @click="docPrivew= false"></span>
            <template v-if="docType=='office'">
                
                
                <div style="height:90vh">
 
                   <div id="officeDocView" style="height:100%"></div>
                </div>
            
            </template>
            <template v-else-if="docType == 'image'">
                <img :src="docValue">
            </template>
            <template v-else-if="docType == 'pdf'">
                <div class="pdf">
                    <object :data="docValue" type="application/pdf" width="1000" height="600" v-if="docPrivew">
                        alt : <a :href="docValue">PDF</a>
                    </object>
                </div>
            </template>
        </div>
    </vs-popup> -->
</template>

<script>
import VueDocPreview from 'vue-doc-preview'
import FileUpload from "vue-upload-component/src";
import { InfoIcon } from 'vue-feather-icons'
import { CheckIcon } from 'vue-feather-icons'
import _ from "lodash";
export default {
    inject: ["parentValidator"],
    props: {
        callfromPetitionDocs:{
            type:Boolean,
            default:false
        },
        noteInfo:{
            type: Boolean,
            default: false,
        },
        docMainCategory:{
            type: String,
            default: '',
        },
        showToBeneficiary:{
            type:Boolean,
            default:false
        },
        fileAcceptType: {
            type: String,
            default: ''
        },
        tplsection:{
            type: String,
            default: null,
        },
        tplkey:{
            type: String,
            default: null,
        },
        deleteDocPermenantly:{
            type:Boolean,
            default:false
        },
        tooltip:{
            type: String,
            default: null,
        },
        display: {
            type: Boolean,
            default: false,
        },
         fieldsArray:Array,
        multiple: {
            type: Boolean,
            default: false
        },
        vvas: {
            type: String,
            default: ""
        },
        wrapclass: {
            type: String,
            default: "md:w-1/2"
        },
        datatype: {
            type: String,
            default: ""
        },
        cid: {
            type: String,
            default: '',
        },
        formscope: {
            type: String,
            default: null
        },
        value: null,
        label: {
            type: String,
            default: null,
        },
        fieldName: {
            type: String,
            default: null,
        },
        placeHolder: {
            type: String,
            default: null,
        },
        required: {
            type: Boolean,
            default: false,
        },
        callExtract:{
            type: Boolean,
            default: false,
        },
        petition: null,
    },    
    data() {
        return {
            docPrivew: false,
            docValue: '',
            docType: "",
            selectedFile: null,
            showFileTypeError:'',
            fvalue: [],
            filesUploading:false,
            docAcceptType: "image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"

        };
    },
    mounted() {
       
        if(this.value){
            this.fvalue = _.cloneDeep(this.value);

        }
        if(this.fileAcceptType){
            if( this.fileAcceptType == 'MSWORD'){
                this.docAcceptType = 'application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document'
            }
        }
      
    
    },
    created() {
        this.$validator = this.parentValidator;
    },

    computed: {
        getLabel(){
            let label = _.cloneDeep(this.label);
            if(this.checkFieldIsRequired({'key':this.tplkey,'section':this.tplsection, 'fieldsArray':this.fieldsArray, 'required':this.required })){
                label = label+"<em>*</em>";
            }
           
            return label;

        },
        getlist() {
            
            return  _.filter(this.fvalue, function (item) {

                return item.status == true
            })

        }
    },
    methods: {
        viewFile(){
            let _APIURL = this.$globalgonfig._APIURL
            let item ={
                status:true,
                name:'letterhead-template.docx',
                path:_APIURL+"/common/viewfile?path=ref-docs/letterhead-template.docx",
                mimetype:"application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                "fromApi":true
            }
            this.download_or_view(item)
            // window.open(_APIURL+"/common/viewfile?path=ref-docs/letterhead-template.docx" ,"_blank");
        },
        download_or_view(docItem) {
           
           let value = _.cloneDeep(docItem);
           var _self = this;
           this.formSubmited =false;
           if (_.has(value, "path")) {
           value["url"] = value["path"];
           value["document"] = value["path"];
           }

           if (_.has(value, "url")) {
           value["path"] = value["url"];
           value["document"] = value["url"];
           }

           if (_.has(value, "document")) {
           value["path"] = value["document"];
           value["url"] = value["document"];
           }
           this.selectedFile = value;
           this.docValue = "";
           this.docPrivew = false;
           this.docType = false;
           this.docType = this.findmsDoctype(value);
           
    if ( (this.docType == "office" || this.docType == "image" || this.docType == "pdf")  ) {
    //if ( (this.docType == "office" || this.docType == "image" || this.docType == "pdf") && value.download == false ) {
      value.url = value.url.replace(this.$globalgonfig._S3URL, "");
      value.url = value.url.replace(this.$globalgonfig._S3URLAWS, "");
      let postdata = {
        keyName: value.url,
        "petitionId":value['petitionId'],
      };
      if((_.has(value, "fromApi") && value['fromApi'])){
        if (this.docType == "office") {
          document.getElementById("officeDocView").innerHTML= "  <div  id='officeDocViewTemplate' style='height:100%'></div>";
            let _editing= true;
          
            if([50,51].indexOf(this.getUserRoleId)>-1){
                  _editing= false;
            }

            if(value.viewmode){
              _editing= false;
            }
            var _ob  = {}
            if(value.editedDocument){
                   _ob ={
              
              petitionId:_self.checkProperty(_self.petition ,'_id'),
               name:value.name,
              _id:value._id,
                "extn": "docx",
              "formLetterType": "Letter",
                parentId:value.parentId
            }

            }else{

                   _ob ={
                     
                  name:value.name,
                       petitionId:_self.checkProperty(_self.petition ,'_id'),
              _id:value._id,
             "extn": "docx",
              "formLetterType": "Letter",
                parentId:value._id

            }

            }
        
            
            window.docEditor = new DocsAPI.DocEditor("officeDocViewTemplate",
          {
              
              "document": {
                 "c": "forcesave",
                  "fileType": "docx",
                  "key": value._id,
                   "userdata": JSON.stringify(_ob),
                  "title": value.name,
                  "url": response.data.result.data,
                   permissions: {
                  edit: _editing,
                  download: true,
                  reader:false,
                  review: false,
                  comment: false
                 }
              },
            
              "documentType": "word",
              "height": "100%",
              "width": "100%",
             
             "editorConfig": {
                 "userdata": JSON.stringify(_ob),
             "callbackUrl": "https://immibox.com/api/perm/post-edited-document?payload="+JSON.stringify(_ob)+"&token="+_self.$store.state.token+"&name="+value.name.replace('.docx',''),
      "customization": {
            "logo": {
              "image": "https://immibox.com/app/favicon.png",
              "imageDark": "https://immibox.com/app/favicon.png",
              "url": "https://immibox.com"
          },
        "anonymous": {
              "request": false,
              "label": "Guest"
          },
          "chat": false,
          "comments": false,
          "compactHeader": false,
          "compactToolbar": true,
          "compatibleFeatures": false,
          "feedback": {
              "visible": false
          },
          "forcesave": true,
          "help": false,
          "hideNotes": true,
          "hideRightMenu": true,
          "hideRulers": true,
            layout: { 
                toolbar: {
                   "collaboration": false,
                },
            },
          "macros": false,
          "macrosMode": "warn",
          "mentionShare": false,
          "plugins": false,
          "spellcheck": false,
          "toolbarHideFileName": true,
          "toolbarNoTabs": true,
          "uiTheme": "theme-light",
          "unit": "cm",
          "zoom": 100
      },
},          events: {
       onReady: function () {
     
          },
          onDocumentStateChange: function (event) {
            var url = event.data;
            if(!event.data){

              if(value.editedDocument){

               }

            }
          }

}
          });
          //this.docValue = encodeURIComponent(response.data.result.data);
        }
        this.docPrivew = true;
      }else{
      this.$store.dispatch("getSignedUrl", postdata).then((response) => {
        this.docValue = response.data.result.data;

        if (this.docType == "office") {
          document.getElementById("officeDocView").innerHTML= "  <div  id='officeDocViewTemplate' style='height:100%'></div>";
            let _editing= true;
          
            if([50,51].indexOf(this.getUserRoleId)>-1){
                  _editing= false;
            }

            if(value.viewmode){
              _editing= false;
            }
            var _ob  = {}
            if(value.editedDocument){
                   _ob ={
              
              petitionId:_self.checkProperty(_self.petition ,'_id'),
               name:value.name,
              _id:value._id,
                "extn": "docx",
              "formLetterType": "Letter",
                parentId:value.parentId
            }

            }else{

                   _ob ={
                     
                  name:value.name,
                       petitionId:_self.checkProperty(_self.petition ,'_id'),
              _id:value._id,
             "extn": "docx",
              "formLetterType": "Letter",
                parentId:value._id

            }

            }
        
            
            window.docEditor = new DocsAPI.DocEditor("officeDocViewTemplate",
          {
              
              "document": {
                 "c": "forcesave",
                  "fileType": "docx",
                  "key": value._id,
                   "userdata": JSON.stringify(_ob),
                  "title": value.name,
                  "url": response.data.result.data,
                   permissions: {
                  edit: _editing,
                  download: true,
                  reader:false,
                  review: false,
                  comment: false
                 }
              },
            
              "documentType": "word",
              "height": "100%",
              "width": "100%",
             
             "editorConfig": {
                 "userdata": JSON.stringify(_ob),
             "callbackUrl": "https://immibox.com/api/perm/post-edited-document?payload="+JSON.stringify(_ob)+"&token="+_self.$store.state.token+"&name="+value.name.replace('.docx',''),
      "customization": {
            "logo": {
              "image": "https://immibox.com/app/favicon.png",
              "imageDark": "https://immibox.com/app/favicon.png",
              "url": "https://immibox.com"
          },
        "anonymous": {
              "request": false,
              "label": "Guest"
          },
          "chat": false,
          "comments": false,
          "compactHeader": false,
          "compactToolbar": true,
          "compatibleFeatures": false,
          "feedback": {
              "visible": false
          },
          "forcesave": true,
          "help": false,
          "hideNotes": true,
          "hideRightMenu": true,
          "hideRulers": true,
            layout: { 
                toolbar: {
                   "collaboration": false,
                },
            },
          "macros": false,
          "macrosMode": "warn",
          "mentionShare": false,
          "plugins": false,
          "spellcheck": false,
          "toolbarHideFileName": true,
          "toolbarNoTabs": true,
          "uiTheme": "theme-light",
          "unit": "cm",
          "zoom": 100
      },
},          events: {
       onReady: function () {
     
          },
          onDocumentStateChange: function (event) {
            var url = event.data;
            if(!event.data){

              if(value.editedDocument){

               }

            }
          }

}
          });
          //this.docValue = encodeURIComponent(response.data.result.data);
        }

          if (this.docType == "pdf") {
            var _vid= value._id;
            if(value.parentId){
               _vid= value.parentId;
            }
            var  viewmode = 0; //1== edit , 0== Disble Edit
            let pdfViewUrl ='https://immibox.com/viewer/pdfjs-dist/web/viewerv2.html';            
            if(_.has(this.$globalgonfig, 'PDF_VIEW_URL')){
                pdfViewUrl = this.$globalgonfig['PDF_VIEW_URL']; //PDF_EDIT_URL
            }
                 

            if(_.has( value ,'viewmode')){
              if(value.viewmode){
               viewmode= 0;
            }else{
              viewmode= 1;
              if(_.has(this.$globalgonfig, 'PDF_EDIT_URL')){
                      pdfViewUrl = this.$globalgonfig['PDF_EDIT_URL'];
              }
            }

            }
            
          this.docValue = pdfViewUrl+"?view="+viewmode+"+&file="+encodeURIComponent(response.data.result.data);
        }
        this.docPrivew = true;
      });
    }
    } else {
     
     

      this.downloads3file(value);
    }
   
  },
        emitUploadingAction(data){
              this.$emit("emitUploadingAction" ,data );
        },
        upload(model) {

            let mapper = model.map(
                (item) =>{  
                item = {
                    name: item.name,
                    size:item.size ? item.size : null,
                    file: item.file ? item.file : null,
                    url: item.url ? item.url : "",
                    path: item.path ? item.path : "",
                    isNew: item.isNew ? item.isNew : false,
                    status: item.status === false || item.status === true ? item.status : true,
                    mimetype: item.type ? item.type : item.mimetype,
                    uploadedBy:item.uploadedBy?item.uploadedBy:this.checkProperty(this.getUserData,'userId')!=''?this.checkProperty(this.getUserData,'userId'):null,
                    uploadedByName:item.uploadedByName?item.uploadedByName:this.checkProperty(this.getUserData,'name')!=''?this.checkProperty(this.getUserData,'name'):'',
                    uploadedByRoleId:item.uploadedByRoleId?item.uploadedByRoleId:this.getUserRoleId?this.getUserRoleId:null,
                    uploadedByRoleName:item.uploadedByRoleName?item.uploadedByRoleName:this.checkProperty(this.getUserData,'loginRoleName'),
                    // uploadedBy:this.checkProperty(this.getUserData,'userId')!=''?this.checkProperty(this.getUserData,'userId'):null,
                    // uploadedByName:this.checkProperty(this.getUserData,'name')!=''?this.checkProperty(this.getUserData,'name'):'',
                    // uploadedByRoleId:this.getUserRoleId?this.getUserRoleId:null,
                    // uploadedByRoleName:this.checkProperty(this.getUserData,'loginRoleName'),
                    
                }

                
                const newName = item.name.replace(/[^\w.]/g, '');
                item.name = newName;
                return item;
            })
            
             let filterdItems = mapper.filter(obj => {
                    const fileExtension = obj.name.split('.').pop();
                    return fileExtension !== 'zip' && fileExtension !== 'rar' && fileExtension !== 'exe';
                });
            if(filterdItems.length > 0) {
               // this.filesUploading =true;
                let count =0;
                this.showFileTypeError =""
                filterdItems.forEach((doc, index) => {
                    if (doc.file) {
                        if(this.fileAcceptType !=''){
                            if(this.fileAcceptType && this.fileAcceptType =="MSWORD"){
                                if(doc.mimetype == 'application/pdf' || doc.mimetype == 'image/*' ){
                                    this.showFileTypeError ="Upload only word format document";
                                    filterdItems.splice(index ,1)
                                    this.filesUploading =false;
                                    return false;
                                }
                            }
                        }
                        let dta ={ "action":true,"fieldName":'',"docMainCategory":''};
                        dta['docMainCategory'] = this.docMainCategory;
                        dta['fieldName'] = this.tplkey;
                        this.emitUploadingAction(dta);
                        this.filesUploading =true;
                        let formData = new FormData();
                        formData.append("files", doc.file);
                        formData.append("secureType", "private");
                        formData.append("getDetails", true);
                        this.$store.dispatch("uploadS3File", formData).then((response) => {   
                            this.filesUploading =false;                        
                            response.data.result.forEach((urlGenerated) => {
                                doc.isNew = true;
                                doc.path = urlGenerated["path"];
                                if(_.has(urlGenerated ,'size' )){
                                doc['size'] = urlGenerated['size'];
                                }
                                delete doc.url;
                                delete doc.file;
                                delete doc.url;
                                filterdItems[index] = doc;
                                if(this.callExtract && this.fieldName == 'capSelectNotice'){
                                    this.extractDocument(doc.path)
                                }
                            });

                            count =count+1;
                            if(count >=filterdItems.length  ){
                                this.filesUploading =false;
                                dta['action'] = false;
                               this.emitUploadingAction(dta);                   

                            }
                        });
                    }else{
                        count++
                    }
                });
                model.splice(0, filterdItems.length, ...filterdItems);
            }else{
                this.filesUploading = false;
            }

            this.updateData()

        },
        remove(index) {
            this.fvalue[index].status = false;
           
            if(this.deleteDocPermenantly){
                this.fvalue.splice(index, 1); 
                this.$emit('input', this.fvalue)
            }
            else{
                this.fvalue.splice(index, 1); 
                //this.fvalue[index].status = false;
                this.$emit('input', this.fvalue)
            }  
                   
        },
        updateData() {
            this.fvalue =_.filter(this.fvalue, function (item) { return item.status == true })
            this.$emit('input', this.fvalue)
        },
        extractDocument(fileUrl=''){
            let self = this;
            let data = {
                category:'cap_notice',
                "lcaDocument": ''
            };
            this.filesUploading =false;
            data['lcaDocument'] = fileUrl;
            if(fileUrl){
                let path = "/petition/extract-lca-data-from-pdf"
                this.$store.dispatch('commonCaseAction', { "data": data, 'path': path })
                .then((response) => {
                    let res = response 
                    if(_.has(res,'beneficiaryCnfmNumber') && this.checkProperty(res,'beneficiaryCnfmNumber')){
                        if(this.checkProperty(this.petition,'beneficiaryInfo')){
                            this.petition['beneficiaryInfo']['beneficiaryCnfmNumber'] = this.checkProperty(res,'beneficiaryCnfmNumber')
                        }
                    }
                    if(_.has(res,'capType') && this.checkProperty(res,'capType')){
                        if(this.checkProperty(this.petition,'beneficiaryInfo')){
                            this.petition['beneficiaryInfo']['capType'] = this.checkProperty(res,'capType')
                        }
                    }
                    if(_.has(res,'serviceCenterName') && this.checkProperty(res,'serviceCenterName')){
                        if(this.checkProperty(this.petition,'beneficiaryInfo')){
                            this.petition['beneficiaryInfo']['serviceCenterName'] = this.checkProperty(res,'serviceCenterName')
                        }
                    }
                })
                .catch((err)=>{})
            }
        }
    },
    components: {
        FileUpload,
        InfoIcon,
        VueDocPreview
    }
};
</script>
