<template>
  <div>
     <div class="w-full" @click="sourceFile=[]">
      <div class="form_group custom_crop_sign" >
        <div class="vs-component" style="margin-bottom: 0 !important;">
          <file-upload v-model="sourceFile" :multiple="false" accept="image/*" :name="fieldName" class="file-upload-input upload_file justify-center"
              @input="fileChanged(sourceFile)">
              <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
              Upload
          </file-upload>
          <!---<span class="loader" v-if="elsUploading"><img src="@/assets/images/main/loader.gif" /></span>-->
          <span class="file-type mb-0">(File Type: JPEG,PNG,JPG. Max file size: 1MB)</span>
        </div>
      </div>
     </div>
     
     <!-- <div class="uploded-files_wrap mt-3" >
        <div class="w-full" v-for="(fil, fileindex) in uploadOriginalDocument" :key="fileindex">
        
            <div class="uploded-files">
                <vx-input-group class="form-input-group">
                    <vs-input v-on:keyup="filameChenged(fileindex)"  v-validate="'required'" class="w-full" :name="'fName'+fileindex" v-model="fil['name']" data-vv-as="File Name" />
                    <span class="text-danger text-sm" v-show="errors.has('fName'+fileindex)">{{ errors.first('fName'+fileindex) }}</span>

                    <div class="delete" style="z-index:999" @click="remove(fil, uploadOriginalDocument ,fileindex)">
                        <img src="@/assets/images/main/cross.svg" />
                    </div>
                </vx-input-group>
            </div>
        </div>
    </div> -->
    

              <modal
            style="z-index:999999"
            z-index="9999"
            name="cropImageModal"
            classes="v-modal-sec"
            :min-width="200"
            :min-height="200"
            :scrollable="true"
            :reset="true"
            width="750px"
            height="auto"
          >
          <div class="v-modal profile_details_modal error-modal-space" >
            <div class="popup-header fromDetailsPage">
              <h2 class="popup-title">
                <template >Crop Image</template>
               
              </h2>
              <span @click="showPopup=false;$modal.hide('cropImageModal');">
                <em class="material-icons">close</em>
              </span>
            </div>
            </div>
            <div class="row">
                <cropper v-if="sourceImg!=''"  ref="cropper" class="cropper"  :src="sourceImg" :stencil-props="stencilProps"  @change="change"></cropper>
             
                <div v-if="showPreview && false" class="img_preview">
                <img v-if="previewCanvas" :src="previewCanvas">
                </div>
                <div class="popup-footer relative">
                <span class="loader" v-if="uploading"><img src="@/assets/images/main/loader.gif"></span>
                  <vs-button color="dark" class="cancel mb-0" type="filled" @click="previewCanvas=''; $modal.hide('cropImageModal')"  style="margin-bottom: 0 !important;">Cancel</vs-button>
                  <vs-button v-if="false" color="dark" class="cancel" type="filled" @click="togglePreview()"  style="margin-left: 10px !important;margin-bottom: 0 !important;">
                    <template v-if="showPreview">Clear Crop</template>
                    <template v-else>Crop</template>
                    
                </vs-button>
                  <vs-button color="success" :disabled="uploading" @click="uploadFinalImageToS3()" class="save" type="filled" style="margin-left: 10px !important;margin-bottom: 0 !important;">
                   <!---- Upload-->Crop </vs-button>
                </div>

            </div>
        
        </modal>
       

  </div>
</template>

<script>


import FileUpload from "vue-upload-component/src";
    import { Cropper } from 'vue-advanced-cropper'
    import 'vue-advanced-cropper/dist/style.css';
   
import * as _ from "lodash"; 
    
        export default {
          name: 'App',
          inject: ["parentValidator"],
          props: {
       
       
        display: {
            type: Boolean,
            default: false,
        },
       
        disabled:{
            type: Boolean,
            default: false,
        },
        
        fieldsArray:Array,
        vvas:{
        type:String,
            default:""
        },
        wrapclass:{
        type:String,
            default:"md:w-1/2"
        },
        
         cid: {
            type: String,
            default: null,
        },
        formscope: {
            type: String,
            default: null
        },
        value: null,
        label: {
            type: String,
            default: null,
        },
        fieldName: {
            type: String,
            default: null,
        },
        tplsection:{
            type: String,
            default: null,
        },
        tplkey:{
            type: String,
            default: null,
        },
       required: {
            type: Boolean,
            default: false,
        },
       
    },
      components: {
        Cropper,
        FileUpload
      },
          data() {
            return {
              stencilProps:{
                class: 'cropper-stencil',
                previewClass: 'cropper-stencil__preview',
                draggingClass: 'cropper-stencil--dragging',
                minCropBoxWidth: 10,
                minCropBoxHeight:10,
                handlersClasses: {
                  default: 'cropper-handler',
                  eastNorth: 'cropper-handler--east-north',
                  westNorth: 'cropper-handler--west-north',
                  eastSouth: 'cropper-handler--east-south',
                  westSouth: 'cropper-handler--west-south',
                },
              },
                showPreview:false,
                selectedFileName:'',
                sourceImg:'',
                sourceImgTemp:'',
                sourceFile:[],
                uploading:false,
                previewCanvas:'',
                img: '' //'https://images.pexels.com/photos/226746/pexels-photo-226746.jpeg',
             
            }
          },
          computed: {
           
          },
          methods: {
            clearCrop(){
              this.sourceImg = _.cloneDeep(this.sourceImgTemp);
            },
            togglePreview(){
                if(this.showPreview){
                    this.showPreview =false;
                    this.clearCrop();
                }else{
                  this.sourceImg =this.previewCanvas;
                    this.showPreview =true;
                }
            },
            fileChanged(allFiles){
              //"type": "image/png",
              let model = _.filter(allFiles ,(doc)=>{
                return _.has(doc ,'type') && doc['type'].includes('image/')

              });
              if(!model  || this.checkProperty(model ,'length') <=0){
                this.showToster({message:"Upload only image files." ,isError: true});
                return false;
              }

                this.selectedFileName = '';
              let self = this;
               this.sourceImg =''
               this.sourceImgTemp =''
                model.forEach((doc) => {
                    this.selectedFileName = doc.name?doc.name:'';
                        
                        var reader = new FileReader();
                        reader.readAsDataURL(doc.file);
                        reader.onload =  ()=> {
                        self.sourceImg = reader.result;
                        this.sourceImgTemp = reader.result;
                       
                        self.$modal.show('cropImageModal')
                        };
                        reader.onerror =  (error)=> {
                            self.$modal.hide('cropImageModal')
                        
                        };

                    //  let formData = new FormData();
                    //  formData.append("files", doc.file);
                    // formData.append("secureType", "public");
                    // this.$store.dispatch("uploadS3File", formData).then((response) => {
                    //     response.data.result.forEach((urlGenerated) => {
                    //         self.sourceImg = urlGenerated;
                    //     })
                        
                    // })
   
              
                })

            },
            saveCropedImage(){
              this.previewCanvas ='';
              let cropedImage = this.$refs.cropper.getCanvas().toDataURL()
               this.previewCanvas =cropedImage
            //  document.getElementById("previewCanvas").innerHTML =cropedImage;
              //let cropedImage = this.$refs.cropper.getCroppedCanvas().toDataURL()
              //alert(cropedImage)
             
            },
            change(event){
            
              this.saveCropedImage();
            },
           async uploadFinalImageToS3(){

            /*
                const b64toBlob = (b64Data, contentType='', sliceSize=512) => {
                const byteCharacters = atob(b64Data);
                const byteArrays = [];

                for (let offset = 0; offset < byteCharacters.length; offset += sliceSize) {
                const slice = byteCharacters.slice(offset, offset + sliceSize);

                const byteNumbers = new Array(slice.length);
                for (let i = 0; i < slice.length; i++) {
                    byteNumbers[i] = slice.charCodeAt(i);
                }

                const byteArray = new Uint8Array(byteNumbers);
                byteArrays.push(byteArray);
                }

                const blob = new Blob(byteArrays, {type: contentType});
                return blob;
                }
                  const file = b64toBlob(this.previewCanvas, 'image/png');
                  */

                let previewCanvas  = this.previewCanvas
                const base64Response = await fetch(`${previewCanvas}`);
                base64Response.blob().then((file)=>{
               let self =this;
              

                  let formData = new FormData();
                     formData.append("files", file);
                    formData.append("secureType", "public");
                    formData.append("getDetails", true);
                    this.uploading =true;
                    this.$store.dispatch("uploadS3File", formData).then((response) => {
                        response.data.result.forEach((urlGenerated) => {
                            //self.sourceImg = urlGenerated;
                            urlGenerated['name'] =self.selectedFileName;
                            

                            urlGenerated['uploadedBy'] =self.checkProperty(self.getUserData,'userId');
                            urlGenerated['uploadedByRoleId'] =self.getUserRoleId
                            urlGenerated['uploadedByRoleName'] =self.checkProperty(self.getUserData,'loginRoleName')
                            self.$emit("input" ,urlGenerated)
                           
                            setTimeout(()=>{
                                self.uploading = false;
                                self.$modal.hide('cropImageModal');
                                
                            },10);
                        })
                        
                    })
                })
               

            },
            init(){
                this.selectedFileName = '';
                this.sourceImg = '';
                this.sourceFile = [],
                this.uploading = false,
                this.previewCanvas = '';
                this.img=  '' 
            }
          
          },
          mounted() {
            this.init();

          }
        }
      </script>
      