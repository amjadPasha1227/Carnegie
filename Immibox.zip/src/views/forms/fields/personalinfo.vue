<template>
    <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12">
        <div class="form-container pt-5">
            <div class="vx-row">
                <vs-col class="w-full p-0 mb-6" v-if="canRenderField('h4EadPhotoEmailStmt', fieldsArray ,false,tplsection)">
                  <vs-alert
                    color="warning"
                    class="warning-alert top-warning-alert"
                    icon-pack="IntakePortal"
                    icon="IP-information-button"
                    active="true"
                  >
                    NOTE: {{ h4EadPhotoEmailStmt }}
                  </vs-alert>
                </vs-col>
    
                
                <!-- @input="setOutsideAddress" -->
                <immiswitchyesno :required="checkFieldIsRequired({'key':'currentlyInUS','section':tplsection, 'fieldsArray':fieldsArray, 'required':true })" :display="false" :tplkey="'currentlyInUS'" :tplsection="tplsection"   wrapclass=" " :fieldsArray="fieldsArray" :cid="'spo_currentlyInUS'"  :formscope="formscope" v-model="value.currentlyInUS" fieldName="chi_currentlyInUS" label="Are you currently in USA?" placeHolder="Are you currently in USA" />
                <template v-if="checkProperty(petition ,'subTypeDetails' ,'id') ==16">
                   
                    <div class="vx-col w-full"  v-if="canRenderField('adjustmentOfI485Status', fieldsArray ,false,tplsection) || canRenderField('consularProcessing', fieldsArray ,false,tplsection) ">
                    <label class="switch-label">Would you like to apply for adjustment of status (I-485) or consular processing? </label>
                    </div>
                    <div class="vs-col mt-5" >
    
                    <div class="form_group custom-form-label custom-cx-box"
                    v-if="canRenderField('adjustmentOfI485Status', fieldsArray ,false,tplsection)"
                    >
    
                    <vs-checkbox
                    v-model="value.adjustmentOfI485Status"
                    data-vv-as="spouseadjustmentOfI485Status"
                    name="spouseadjustmentOfI485Status"
                    @change="changedAdjustmentOfI485Status"
                    >Adjustment of Status (I-485)
    
                    <p>When your Priority Date is current, and you have a valid status in the U.S. by then, you may file I-485 to get your Green Card</p>
    
                    </vs-checkbox>
    
                    </div>
    
                    </div>
                    <div class="vs-col " v-if="canRenderField('consularProcessing', fieldsArray ,false,tplsection)"  >
                    <div class="form_group custom-form-label custom-cx-box"  >
                        <vs-checkbox v-model="value.consularProcessing"  data-vv-as="spouseconsularProcessing"  name="spouseconsularProcessing"  @change="changedConsularProcessing"
                        >Consular Processing
    
                    <p>When your Priority Date is current, and you would like to go to a U.S. consulate 
                    abroad to apply for an immigrant visa to get your Green Card</p>
                    </vs-checkbox>
                    </div>
                    <input v-if="!value.consularProcessing &&  !value.adjustmentOfI485Status" type="hidden" :name="'spouseconsularProcessing'" v-validate="'required'"   v-model="consularProcessingValidator">
                    <span v-if="formscope" class="text-danger text-sm" v-show="errors.has(formscope+'.spouseconsularProcessing')">* Adjustment of Status (I-485)/Consular Processing is required</span>
                    <span v-else class="text-danger text-sm" v-show="errors.has('spouseconsularProcessing')">* Adjustment of Status (I-485)/Consular Processing is required</span>
                                                                                                      
                    </div>
                </template>
                <immiyesorno   :cid="'adjustmentStatusToPermResidenceI485'" :formscope="formscope" :required="checkFieldIsRequired({'key':'adjustmentStatusToPermResidenceI485','section':tplsection, 'fieldsArray':fieldsArray, 'required':true })"  :display="false" :tplkey="'adjustmentStatusToPermResidenceI485'" :tplsection="tplsection"   wrapclass="rmb10 yesnomar adj_i485" :fieldsArray="fieldsArray" v-model="value.adjustmentStatusToPermResidenceI485" fieldName="spouse_h4_ead_required" label="Adjustment of status to Permanent Residency (Form I-485) required for spouse?"></immiyesorno>
                <template v-if="checkProperty(petition,'beneficiaryInfo','hasI140ImmPetitionFiled') || checkProperty(petition,'beneficiaryInfo','anyImmPetitionFiled') ">
                <immiyesorno :cid="'h4EADRequired'"  :wrapclass="'h4_ead_v2'" :formscope="formscope" :required="checkFieldIsRequired({'key':'h4EADRequired','section':tplsection, 'fieldsArray':fieldsArray, 'required':true })" :display="false" :tplkey="'h4EADRequired'" :tplsection="tplsection"  :fieldsArray="fieldsArray" v-model="value.h4EADRequired" fieldName="spouse_h4_ead_required" label="H4 EAD required for spouse?"></immiyesorno>
                <immiyesorno v-if="value.h4EADRequired" :wrapclass="'h4_ead_v2'" :cid="'doYouAlreadyH4EAD'" :formscope="formscope" :required="checkFieldIsRequired({'key':'doYouAlreadyH4EAD','section':tplsection, 'fieldsArray':fieldsArray, 'required':true })" :display="false" :tplkey="'doYouAlreadyH4EAD'" :tplsection="tplsection"  :fieldsArray="fieldsArray" v-model="value.doYouAlreadyH4EAD" fieldName="spouse_h4_ead_required_already" label="Do you already have H4 EAD?"></immiyesorno>
                </template>
                <!-- :wrapclass="'h4_ead_label mb-0'" :wrapclass="'h4_ead_label mb-0'" -->
               <immiswitchyesno :required="checkFieldIsRequired({'key':'applyingWithYou','section':tplsection, 'fieldsArray':fieldsArray, 'required':true })" wrapclass=" " :display="false" :tplkey="'applyingWithYou'"  :fieldsArray="fieldsArray" :cid="'applyingWithYou'" :formscope="formscope" v-model="value.applyingWithYou" :tplsection="tplsection"  :fieldName="'applyingWithYou'"   label="Applying with you?" placeHolder="" />
               <genderField :required="true" :display="false" :formScope="formscope" :fieldsArray="fieldsArray" :gender="value.gender" v-model="value.gender" :tplsection="tplsection" :tplkey="'gender'" :fieldName="'gender'" />
               <div class="divider full-divider mb-10"></div>
    
                <div class="vx-col w-full">
                    
                    <vx-input-group class="form-input-group FML">
                        <immiInput :display="false" :tplkey="'firstName'" :tplsection="tplsection"   :fieldsArray="fieldsArray" cid="benf" :formscope="formscope" v-model="value.firstName" :required="true" fieldName="spouse_first_name" label="First Name" placeHolder="First Name" />
                        <immiInput :display="false" :tplkey="'middleName'" :tplsection="tplsection"  :fieldsArray="fieldsArray" cid="benm" :formscope="formscope" v-model="value.middleName" :required="true" fieldName="spouse_middle_name" label="Middle Name" placeHolder="Middle Name" />
                        <immiInput :display="false" :allowUpperCase="petition.tenantDetails && checkProperty(petition,'tenantDetails','slug') &&  checkProperty(petition,'tenantDetails','slug') == 'slg'" :tplkey="'lastName'" :tplsection="tplsection"  :fieldsArray="fieldsArray" cid="benl" :formscope="formscope" v-model="value.lastName" :required="true" fieldName="spouse_last_name" label="Last Name" placeHolder="Last Name" />
                    </vx-input-group>
                </div>
   
                <div class="vx-col w-full mb-5 yesno-v2" v-if="canRenderField('otherNames',fieldsArray ,false,tplsection)">
                    <div class="d-block align-center">
                        <a class="switch-label">
                            Have you ever used any other names previously?
                        </a><em v-if="checkFieldIsRequired({'key':'otherNames','section':tplsection, 'fieldsArray':fieldsArray, 'required':true })">*</em>
                        <!-- <vs-switch v-model="value.hasOtherNames" @input="resetOtherNames(value.hasOtherNames)">
                            <span slot="on">Yes</span>
                            <span slot="off">No</span>
                        </vs-switch> -->
                        <ul class="custom-radio custom-radio_v2">
                            <li>
                                <vs-radio ref="yes" v-model="value.hasOtherNames" vs-name="Spouse_hasOtherNames" :vs-value="true"  @input="resetOtherNames(value.hasOtherNames)">Yes</vs-radio>
                            </li>
                            <li>
                                <vs-radio ref="no" v-model="value.hasOtherNames" vs-name="Spouse_hasOtherNames" :vs-value="false"  @input="resetOtherNames(value.hasOtherNames)" >No</vs-radio>
                            </li> 
                        </ul>
                        <div class="form_group" v-if="checkFieldIsRequired({'key':'otherNames','section':tplsection, 'fieldsArray':fieldsArray, 'required':true })">
                            <input type="hidden" :name="'otherNames_spousedInfo'" v-validate="'required'"  data-vv-as="Field"  v-model="value.hasOtherNames">
                            <span v-show="errors.has( formscope+'.otherNames_spousedInfo')" class="text-danger text-sm" style="">*Field is required</span>
                        </div>
                        
                    </div>
                    <span class="inline_note pt-4">(NOTE: Please enter the name if you have a different name in the educational document other than passport.)</span>
                </div>
   
                <template v-if=" value.hasOtherNames && canRenderField('otherNames',fieldsArray ,false,tplsection)">
          
                    <div class="vx-col w-full" v-for="(item, ind) in value['otherNames']" :key="ind">
                        <vx-input-group class="form-input-group delete-rows-cst FML">
                            <immiInput :display="false" :tplkey="'firstName'" :tplsection="tplsection" :formscope="formscope" :cid="'benf'+ind" v-model="item.firstName" :required="false" fieldName="spouse_last_name" label="First Name" placeHolder="First Name" />
                            <immiInput :display="false" :tplkey="'middleName'" :tplsection="tplsection" :formscope="formscope" :cid="'benm'+ind" v-model="item.middleName" :required="false" fieldName="spouse_middle_name" label="Middle Name" placeHolder="Middle Name" />
                            <immiInput :display="false" :allowUpperCase="petition.tenantDetails && checkProperty(petition,'tenantDetails','slug') &&  checkProperty(petition,'tenantDetails','slug') == 'slg'" :tplkey="'lastName'" :tplsection="tplsection" :formscope="formscope" :cid="'benl'+ind" v-model="item.lastName" :required="false" fieldName="spouse_last_name" label="Last Name" placeHolder="Last Name" />
                            <div class="delete delete_spousechild" v-if="ind > 0" @click="removeOtherName(ind)">
                                <a>
                                    <img src="@/assets/images/main/delete-row-img.svg" />
                                </a>
                            </div>
                        </vx-input-group>
                        <a class="add-more add-more-names mb-10" v-if="value['otherNames'].length - 1 ==ind" @click="addOtherNames()"><span>+</span>Add</a>
                    </div>
                </template>
                <immiswitchyesno :required="checkFieldIsRequired({'key':'nameDiffFromBirthCert','section':tplsection, 'fieldsArray':fieldsArray, 'required':true })" wrapclass=" "  :display="false"  :fieldsArray="fieldsArray" :formscope="formscope" cid="nameDiffFromBirthCert"  v-model="value.nameDiffFromBirthCert" :tplkey="'nameDiffFromBirthCert'" :tplsection="tplsection" :fieldName="'nameDiffFromBirthCert'"  label="If your name is different from that stated on your birth certificate, have you had it legally changed?"></immiswitchyesno>
                <immiswitchyesno :required="checkFieldIsRequired({'key':'birthCertHaveNamePobDob','section':tplsection, 'fieldsArray':fieldsArray, 'required':true })"  wrapclass="yesno-v2_wrap"  :display="false" :fieldsArray="fieldsArray" :formscope="formscope" cid="birthCertHaveNamePobDob"  v-model="value.birthCertHaveNamePobDob" :tplkey="'birthCertHaveNamePobDob'" :tplsection="tplsection" :fieldName="'birthCertHaveNamePobDob'"  label="Does the birth certificate have your name, place of birth, date of birth, parents’ names mentioned, and the birth was registered around the time you were born?"></immiswitchyesno>
                <immiswitchyesno :required="checkFieldIsRequired({'key':'have2AffidavitsOfBirthFamily','section':tplsection, 'fieldsArray':fieldsArray, 'required':true })" wrapclass=" "  :display="false" :fieldsArray="fieldsArray" :formscope="formscope" cid="have2AffidavitsOfBirthFamily"  v-model="value.have2AffidavitsOfBirthFamily"  :tplkey="'have2AffidavitsOfBirthFamily'" :tplsection="tplsection"  :fieldName="'have2AffidavitsOfBirthFamily'" label="Do you have Two (2) Affidavits of Birth from family members?"></immiswitchyesno>

                <immiInput  :display="false" :tplkey="'email'" :tplsection="tplsection" :fieldsArray="fieldsArray" datatype="email" cid="benfemail" :formscope="formscope" v-model="value.email" :required="true" fieldName="spouse_email" label="Email" placeHolder="Email" />
    
                <immiInput  :display="false" :tplkey="'maidenName'" :tplsection="tplsection" :fieldsArray="fieldsArray" cid="maidenName_Maiden Name" :formscope="formscope" v-model="value.maidenName" :required="true" fieldName="spouse_maidenName" label="Maiden Name" placeHolder="Maiden Name" />
                <datepickerField  :display="false" :tplkey="'dateOfBirth'" :tplsection="tplsection" :fieldsArray="fieldsArray" :dateEnableTo="startEligibleDate" :validationRequired="true" v-model="value.dateOfBirth" :formscope="formscope" fieldName="spouse_dob" label="Date of Birth" />
                <selectField  :display="false" :tplkey="'countryOfBirth'" :tplsection="tplsection"   :fieldsArray="fieldsArray" @input="changeBfProvince" :required="true" :optionslist="countriesWithoutUS" v-model="value.countryOfBirthDetails" :formscope="formscope" fieldName="spouse_cob" label="Country of Birth" placeHolder="Country of Birth" />
               
                <selectField  :display="false" :tplkey="'provinceOfBirth'" :tplsection="tplsection"   :fieldsArray="fieldsArray" @input="value.provinceOfBirth = value.provinceOfBirthDetails.id" :required="true" v-if="canRenderField('provinceOfBirth', fieldsArray ,false,tplsection) && bfeprovinceStates.length > 0" :optionslist="bfeprovinceStates" v-model="value.provinceOfBirthDetails" :formscope="formscope" fieldName="spouse_provinceOfBirth" label="Province of Birth" placeHolder="Province of Birth" />
                <immiInput  :display="false" :tplkey="'locationOfBirth'" :tplsection="tplsection" :fieldsArray="fieldsArray" cid="benflocationOfBirth" :formscope="formscope" v-model="value.locationOfBirth" :required="true" fieldName="spouse_locationOfBirth" label="Location of Birth" placeHolder="Location of Birth" />
                <selectField  :display="false" :tplkey="'countryOfCitizenship'" :tplsection="tplsection" :fieldsArray="fieldsArray" @input="value.countryOfCitizenship = value.countryOfCitizenshipDetails.id" :required="true" :optionslist="countriesWithoutUS" v-model="value.countryOfCitizenshipDetails" :formscope="formscope" fieldName="spouse_nationality" label="Country of Citizenship" placeHolder="Country of Citizenship" />
                <selectField :multiple="true"  :display="false" :tplkey="'otherCountriesOfCitizenship'" :tplsection="tplsection" :fieldsArray="fieldsArray"  :required="true" :optionslist="countriesWithoutUS" v-model="value.otherCountriesOfCitizenshipDetails" :formscope="formscope" fieldName="otherCountriesOfCitizenship" label="Any other country(ies) of Citizenship" placeHolder="Any other country(ies) of Citizenship" />
    
                
                
                <immiPhone  :display="false" :tplkey="'phoneNumber'" :tplsection="tplsection" @updatephoneCountryCode="updatephoneCountryCode" :fieldsArray="fieldsArray" :countrycode="value.phoneCountryCode.countryCode" cid="phoneCountryCode" :formscope="formscope" v-model="value.phoneNumber" :required="true" fieldName="spouse_phone_number" label="Phone Number" placeHolder="Phone Number" />
                <template>
                
                <!-- @input="updateAnyotherCountries" <selectField :display="false" :fieldsArray="fieldsArray"  :required="true" :optionslist="visastatuses" v-model="value.curNonImmigrantVisaStatus" :tplsection="tplsection" cid="curNonImmigrantVisaStatus"  :fieldName="'curNonImmigrantVisaStatus'"  :formscope="formscope"  label="Current Nonimmigrant visa Status" placeHolder="Current Nonimmigrant visa Status" /> -->
                
                <selectField :fieldsArray="fieldsArray" :display="false" :tplkey="'maritalStatus'" @input="value.maritalStatus = value.maritalStatusDetails.id" cid="maritalStatus" :required="true"  :optionslist="fileredMartialList" v-model="value.maritalStatusDetails" :formscope="formscope" :tplsection="tplsection" :fieldName="'maritalStatus'" label="Marital Status" placeHolder="Marital Status" />
                <immiInput  :display="false" :tplkey="'currentSpouseName'" :tplsection="tplsection"    :fieldsArray="fieldsArray" cid="currentSpouseName" datatype="max:40" :formscope="formscope" v-model="value.currentSpouseName" :required="true" fieldName="currentSpouseName" label="Current Spouse Name" placeHolder="Current Spouse Name" />
                
                <datepickerField  :display="false" :fieldsArray="fieldsArray" :tplkey="'dateOfMarriage'" cid="dateOfMarriage" :validationRequired="true" v-model="value.dateOfMarriage" @input="clearDateOfMarriageEnd" :formscope="formscope" :dateEnableTo="featureDates"  :tplsection="tplsection"  :fieldName="'dateOfMarriage'"  label="Date of Marriage" />
                <datepickerField  :display="false" :fieldsArray="fieldsArray" :tplkey="'dateOfMarriageEnd'" :isDisabled="!value.dateOfMarriage"   cid="dateOfMarriageEnd" :validationRequired="true" v-model="value.dateOfMarriageEnd" :formscope="formscope" :dateEnableTo="featureDates" :dateEnableFrom="value.dateOfMarriage"  :tplsection="tplsection"  :fieldName="'dateOfMarriageEnd'"  label="Date of Marriage End" />

                <selectField   :display="false" :fieldsArray="fieldsArray" :tplkey="'countryOfMarriage'"  cid="countryOfMarriage"  @input="changeCountryMarriage" :required="true" :optionslist="countries" v-model="value.countryOfMarriageDetails" :formscope="formscope"  :tplsection="tplsection"  :fieldName="'countryOfMarriage'"  label="Country of Marriage" placeHolder="Country of Marriage" />
                <selectField  :display="false" :fieldsArray="fieldsArray" :tplkey="'provinceOfMarriage'" cid="provinceOfMarriage"  @input="value.provinceOfMarriage = value.provinceOfMarriageDetails.id" :required="true" :optionslist="statesOfMarriage" v-model="value.provinceOfMarriageDetails" :formscope="formscope"  :tplsection="tplsection"  :fieldName="'provinceOfMarriage'"  label="Province of Marriage" placeHolder="Province of Marriage" />
                
                <immiInput   :display="false" :fieldsArray="fieldsArray" :tplkey="'locationOfMarriage'"  cid="locationOfMarriage" :formscope="formscope" v-model="value.locationOfMarriage" :required="true"  :tplsection="tplsection"  :fieldName="'locationOfMarriage'"  label="Location of Marriage" placeHolder="Location of Marriage" />
                <div class="vx-col  w-full md:w-1/2" v-if="canRenderField('inches',fieldsArray, false, 'dependentsInfo.spouse.height' ) || canRenderField('feet',fieldsArray, false, 'dependentsInfo.spouse.height' )">
                    <div class="form_group mb-0">
                        <label class="form_label">Height</label>
                        <div class="height_field">
                            <selectField :display="false" :fieldsArray="fieldsArray"  :required="true"  :tplkey="'feet'" cid="depfeet" :optionslist="feetList" v-model="value.height.feet"  :tplsection="'dependentsInfo.spouse.height'"  :fieldName="'feet'" :listContainsId="false" :formscope="formscope"  label="" placeHolder="Feet" />
                            <selectField :display="false" :fieldsArray="fieldsArray"  :required="true"  :tplkey="'inches'" cid="depinches" :optionslist="inchesList" v-model="value.height.inches" :tplsection="'dependentsInfo.spouse.height'"  :fieldName="'inches'" :listContainsId="false"  :formscope="formscope"  label="" placeHolder="Inches" />
                        </div>
                    </div>
                </div>
                
                <!-- <immiInput  :onlyNumbers="true" :allowFloatingPoint="false" :maxLength="2"  :display="false" :fieldsArray="fieldsArray" :tplkey="'feet'"    cid="depfeet"   :formscope="formscope" v-model="value.height.feet" :required="true"  :tplsection="tplsection"  :fieldName="'depfeet'"  label="Feet" placeHolder="Feet" />
                <immiInput  :onlyNumbers="true" :allowFloatingPoint="false" :maxLength="2"  :display="false" :fieldsArray="fieldsArray" :tplkey="'inches'"  cid="depinches" :formscope="formscope" v-model="value.height.inches" :required="true"  :tplsection="tplsection"  :fieldName="'depinches'"  label="Inches" placeHolder="Inches" />  -->
                
                <immiInput :allowFloatingPoint="false" :maxLength="3" :onlyNumbers="true" :display="false" :fieldsArray="fieldsArray"  cid="weight" :formscope="formscope" v-model="value.weight" :tplsection="tplsection" :tplkey="'weight'" :fieldName="'weight'"  :required="true"  label="Weight (LBS)" placeHolder="Weight" />
                <selectField :display="false" :fieldsArray="fieldsArray" cid="'race'+cid" :required="true" :optionslist="races_list" v-model="value.race" :tplsection="tplsection" :tplkey="'race'" :fieldName="'race'+fieldName"  :formscope="formscope"  label="Race" placeHolder="Race" />
                <selectField :display="false" :fieldsArray="fieldsArray" cid="hairColor" :required="true" :optionslist="hair_colorsList" v-model="value.hairColor" :tplsection="tplsection" :tplkey="'hairColor'" :fieldName="'hairColor'"  :formscope="formscope"  label="Hair Color" placeHolder="Hair Color " />
                <selectField :display="false" :fieldsArray="fieldsArray" cid="eyeColor" :required="true" :optionslist="eye_colorList" v-model="value.eyeColor" :tplsection="tplsection" :tplkey="'eyeColor'" :fieldName="'eyeColor'"  :formscope="formscope"  label="Eye Color" placeHolder="Eye Color" />
                <immiswitchyesno :required="checkFieldIsRequired({'key':'enterInUSUnderCaseWaiverProgram','section':tplsection, 'fieldsArray':fieldsArray, 'required':true })" wrapclass=" "  :display="false" :fieldsArray="fieldsArray" :formscope="formscope" cid="enterInUSUnderCaseWaiverProgram"  v-model="value.enterInUSUnderCaseWaiverProgram" :tplsection="tplsection" :tplkey="'enterInUSUnderCaseWaiverProgram'" :fieldName="'enterInUSUnderCaseWaiverProgram'"  label="Did you enter the U.S. under the Visa waiver program?"></immiswitchyesno>
                
            <template v-if="false">
                <selectField :display="false" :fieldsArray="fieldsArray"  @input="value.stateOfLastEntryInUS =value.stateDetailsOfLastEntryInUS.id" :required="true" :optionslist="usastates" v-model="value.stateDetailsOfLastEntryInUS" :tplsection="tplsection"  :tplkey="'stateOfLastEntryInUS'" :fieldName="'stateOfLastEntryInUS'"  :formscope="formscope"  label="State of recent entry into the USA" placeHolder="State of recent entry into the USA" />
                <immiInput :display="false" :fieldsArray="fieldsArray"  cid="placeOfLastEntryInUS" :formscope="formscope" v-model="value.placeOfLastEntryInUS" :tplsection="tplsection" :tplkey="'placeOfLastEntryInUS'" :fieldName="'placeOfLastEntryInUS'"  :required="true"  label="Place of recent entry into the USA" placeHolder="Place of recent entry into the USA" />
                <datepickerField  :display="false" :fieldsArray="fieldsArray" :tplkey="'lastArrivalDate'"  :validationRequired="true" v-model="value.lastArrivalDate" :formscope="formscope" :dateEnableTo="featureDates"  :tplsection="tplsection"  :fieldName="'lastArrivalDate'"  label="Date of most recent entry into the USA" />
            </template>
                <immiswitchyesno :required="checkFieldIsRequired({'key':'inspectedByAnyImmOfficer','section':tplsection, 'fieldsArray':fieldsArray, 'required':true })" wrapclass=" "  :display="false" :fieldsArray="fieldsArray" :formscope="formscope" cid="inspectedByAnyImmOfficer"  v-model="value.inspectedByAnyImmOfficer" :tplsection="tplsection"  :tplkey="'inspectedByAnyImmOfficer'" :fieldName="'inspectedByAnyImmOfficer'"  label="Were you inspected by an immigration officer?"></immiswitchyesno>
                <immiswitchyesno :required="checkFieldIsRequired({'key':'issuedAnyEADFromUSCIS','section':tplsection, 'fieldsArray':fieldsArray, 'required':true })" wrapclass=" "  :display="false" :fieldsArray="fieldsArray" :formscope="formscope" cid="issuedAnyEADFromUSCIS"  v-model="value.issuedAnyEADFromUSCIS" :tplsection="tplsection" :tplkey="'issuedAnyEADFromUSCIS'"  :fieldName="'issuedAnyEADFromUSCIS'"  label=" Have you ever been issued an Employment Authorization Document (EAD) from the USCIS?"></immiswitchyesno>
                
                <template v-if="value.issuedAnyEADFromUSCIS">
                    <div class="vx-col w-full quest_485_v2">
                        <casedocumentslist :showTitle="false" :tplsection="'dependentsInfo.spouse.documents'" :docslist="eadCardList" :formscope="formscope" :fieldsArray="fieldsArray" v-model="value.documents" :fieldName="'eadCard'"></casedocumentslist>
                    </div>
                </template>
                <immiswitchyesno :required="checkFieldIsRequired({'key':'hasPermResidencyInOtherCountry','section':tplsection, 'fieldsArray':fieldsArray, 'required':true })" wrapclass=" "  :display="false" :fieldsArray="fieldsArray" :formscope="formscope" cid="hasPermResidencyInOtherCountry"  v-model="value.hasPermResidencyInOtherCountry" :tplsection="tplsection"  :tplkey="'hasPermResidencyInOtherCountry'" :fieldName="'hasPermResidencyInOtherCountry'"  label="Do you hold Permanent residence in any other country?"></immiswitchyesno>             
                <selectField v-if="value.hasPermResidencyInOtherCountry" :display="false" :fieldsArray="fieldsArray"  :required="true" :optionslist="countries" v-model="value.permResidencyCountryDetails" :tplsection="tplsection" :tplkey="'permResidencyCountryDetails'"  :fieldName="'permResidencyCountryDetails'"  :formscope="formscope"  label="Permanent Residency Country" placeHolder="Permanent Residency Country" />
                <immiswitchyesno :required="checkFieldIsRequired({'key':'everAppliedAOSInUS','section':tplsection, 'fieldsArray':fieldsArray, 'required':true })"  wrapclass="yesno-v2_wrap" :display="false" :fieldsArray="fieldsArray" :formscope="formscope" cid="everAppliedAOSInUS"  v-model="value.everAppliedAOSInUS" :tplsection="tplsection" :tplkey="'everAppliedAOSInUS'"  :fieldName="'everAppliedAOSInUS'"  label="Have you ever applied AOS in the United States or an immigrant visa at the US Embassy/Consulate to obtain permanent resident status before?"></immiswitchyesno>
                <template v-if="value.everAppliedAOSInUS">
                    <div class="vx-col w-full quest_485_v2">
                        <casedocumentslist :showTitle="false" :tplsection="tplsection" :docslist="appliedAOSInUSDocsList" :formscope="formscope" :fieldsArray="fieldsArray" v-model="value" :fieldName="'appliedAOSInUSDocs'"></casedocumentslist>
                    </div>
                </template>
                <immiswitchyesno :required="checkFieldIsRequired({'key':'haveYouArrestedBefore','section':tplsection, 'fieldsArray':fieldsArray, 'required':true })" wrapclass=" "  :display="false" :fieldsArray="fieldsArray" :formscope="formscope" cid="haveYouArrestedBefore"  v-model="value.haveYouArrestedBefore" :tplsection="tplsection" :tplkey="'haveYouArrestedBefore'"  :fieldName="'haveYouArrestedBefore'"  label=" Have you ever been arrested, cited, charged or detained for any reason by an law enforcement official?"></immiswitchyesno>
                
                <template v-if="value.haveYouArrestedBefore">
                    <div class="vx-col w-full quest_485_v2">
                        <casedocumentslist :wrapclass="'mart0'" :showTitle="false" :tplsection="tplsection" :docslist="haveYouArrestedBeforeDocsList" :formscope="formscope" :fieldsArray="fieldsArray" v-model="value" :fieldName="'haveYouArrestedBeforeDocs'"></casedocumentslist>
                    </div>
                    </template>
                <immiswitchyesno :required="checkFieldIsRequired({'key':'haveYouEverReceivedPublicAssistendeInUS','section':tplsection, 'fieldsArray':fieldsArray, 'required':true })" wrapclass="yesno-v2_wrap"  :display="false" :fieldsArray="fieldsArray" :formscope="formscope" cid="haveYouEverReceivedPublicAssistendeInUS"  v-model="value.haveYouEverReceivedPublicAssistendeInUS" :tplsection="tplsection" :tplkey="'haveYouEverReceivedPublicAssistendeInUS'"  :fieldName="'haveYouEverReceivedPublicAssistendeInUS'"  label="Have you ever received public assistance in the United States from any source, including the US government or any state, country, city or muncipality (other than emergency medical treatment)?"></immiswitchyesno>
                <immiswitchyesno :required="checkFieldIsRequired({'key':'haveYouEverlikelyReceivePublicAssistendeInUS','section':tplsection, 'fieldsArray':fieldsArray, 'required':true })" wrapclass="yesno-v2_wrap"  :display="false" :fieldsArray="fieldsArray" :formscope="formscope" cid="haveYouEverlikelyReceivePublicAssistendeInUS"  v-model="value.haveYouEverlikelyReceivePublicAssistendeInUS" :tplsection="tplsection" :tplkey="'haveYouEverlikelyReceivePublicAssistendeInUS'"  :fieldName="'haveYouEverlikelyReceivePublicAssistendeInUS'"  label="Have you ever likely to receive public assistance in the United States from any source, including the US government or any state, country, city or muncipality (other than emergency medical treatment)?"></immiswitchyesno>
                
                <immiswitchyesno :required="checkFieldIsRequired({'key':'isVisaDenieedTOUS','section':tplsection, 'fieldsArray':fieldsArray, 'required':true })" wrapclass=" "  :display="false" :fieldsArray="fieldsArray" :formscope="formscope" cid="isVisaDenieedTOUS"  v-model="value.isVisaDenieedTOUS" :tplsection="tplsection" :tplkey="'isVisaDenieedTOUS'"  :fieldName="'isVisaDenieedTOUS'"  label="Have you ever been denied a visa to the United States?"></immiswitchyesno>
                <immiInput v-if="value.isVisaDenieedTOUS" :display="false" :fieldsArray="fieldsArray"  cid="visaDeniedReason" :formscope="formscope" v-model="value.visaDeniedReason" :tplsection="tplsection" :tplkey="'visaDeniedReason'"  :fieldName="'visaDeniedReason'"  :required="true"  label="Reason" placeHolder="Reason" />
                <immiswitchyesno :required="checkFieldIsRequired({'key':'haveYoueverPresntUnlawfully','section':tplsection, 'fieldsArray':fieldsArray, 'required':true })" wrapclass=" "  :display="false" :fieldsArray="fieldsArray" :formscope="formscope" cid="haveYoueverPresntUnlawfully"  v-model="value.haveYoueverPresntUnlawfully" :tplsection="tplsection" :tplkey="'haveYoueverPresntUnlawfully'"  :fieldName="'haveYoueverPresntUnlawfully'"  label="Have you ever been present in the United States unlawfully for more than 180 days?"></immiswitchyesno>
                <immiInput v-if="value.haveYoueverPresntUnlawfully" :display="false" :fieldsArray="fieldsArray"  cid="presntUnlawfullyReason" :formscope="formscope" v-model="value.presntUnlawfullyReason" :tplsection="tplsection" :tplkey="'presntUnlawfullyReason'" :fieldName="'presntUnlawfullyReason'"  :required="true"  label="Reason" placeHolder="Reason" />
               
                </template>
                <template v-if="value && value.h4EADRequired">
                    <selectField :display="false" :fieldsArray="fieldsArray"  @input="value.stateOfLastEntryInUS =value.stateDetailsOfLastEntryInUS.id" :required="true" :optionslist="usastates" v-model="value.stateDetailsOfLastEntryInUS" :tplsection="tplsection"  :tplkey="'stateOfLastEntryInUS'" :fieldName="'stateOfLastEntryInUS'"  :formscope="formscope"  label="State of recent entry into the USA" placeHolder="State of recent entry into the USA" />
                    <immiInput :display="false" :fieldsArray="fieldsArray"  cid="placeOfLastEntryInUS" :formscope="formscope" v-model="value.placeOfLastEntryInUS" :tplsection="tplsection" :tplkey="'placeOfLastEntryInUS'" :fieldName="'placeOfLastEntryInUS'"  :required="true"  label="Place of recent entry into the USA" placeHolder="Place of recent entry into the USA" />
                    <datepickerField  :display="false" :fieldsArray="fieldsArray" :tplkey="'lastArrivalDate'"  :validationRequired="true" v-model="value.lastArrivalDate" :formscope="formscope" :dateEnableTo="featureDates"  :tplsection="tplsection"  :fieldName="'lastArrivalDate'"  label="Date of most recent entry into the USA" />
                </template>

                <div class="vx-col w-full" v-if="canRenderField('passportNumber', fieldsArray ,false,tplsection) || canRenderField('passportIssuedDate', fieldsArray ,false,tplsection) || canRenderField('passportExpiryDate', fieldsArray ,false,tplsection)  ">
                    <h3 class="small-header">Passport</h3>
                </div>
                <immiInput :allowUpperCase="true"  :display="false" :tplkey="'passportNumber'" :tplsection="tplsection" :fieldsArray="fieldsArray" datatype="alpha_num|max:15" cid="benfpassportNumber" :formscope="formscope" v-model="value.passportNumber" :required="true" fieldName="spouse_passport_number" label="Passport Number" placeHolder="Passport Number" />
                <datepickerField  :display="false" :tplkey="'passportIssuedDate'" :tplsection="tplsection" :fieldsArray="fieldsArray" :validationRequired="value.currentlyInUS || value.passportNumber" v-model="value.passportIssuedDate" :formscope="formscope" fieldName="spo_passportIssuedDate" :dateEnableTo="currentDate" label="Passport Issued Date" />
                <datepickerField   :display="false" :tplkey="'passportExpiryDate'" :tplsection="tplsection" :fieldsArray="fieldsArray"  :validationRequired="value.currentlyInUS || value.passportNumber" v-model="value.passportExpiryDate" :formscope="formscope" :dateEnableFrom="new Date()"  fieldName="spouse_passport_expiry_date" label="Passport Expiry Date" />
                <selectField   :display="false" :tplkey="'passportIssuedCountry'" :fieldsArray="fieldsArray" @input="value.passportIssuedCountry = value.passportIssuedCountryDetails.id" :required="true" :optionslist="countries" v-model="value.passportIssuedCountryDetails"  :tplsection="tplsection"  :fieldName="'passportIssuedCountry'" cid="passportIssuedCountry" :formscope="formscope"  label="Country of Passport Issued" placeHolder="Country of Passport Issued" />
                <immiInput :display="false" :onlyNumbers="true" :allowFloatingPoint="false" :maxLength="8" :fieldsArray="fieldsArray"  cid="curNonImmigrantVisaNumber" :formscope="formscope" v-model="value.curNonImmigrantVisaNumber" :tplsection="tplsection" :tplkey="'curNonImmigrantVisaNumber'" :fieldName="'curNonImmigrantVisaNumber'"  :required="true"  label="Current Non-Immigrant Visa Number" placeHolder="Current Non-Immigrant Visa Number" />
                
                <!-- <datepickerField :display="false" :tplkey="'lastArrivalDate'" :tplsection="tplsection" :fieldsArray="fieldsArray" :dateEnableTo="currentDate" :validationRequired="true" v-model="value.lastArrivalDate" :formscope="formscope" fieldName="spouse_date_of_last_arrival" label="Date of Last Arrival" /> -->
            <template v-if="(canRenderField('currentlyInUS',fieldsArray, false, tplsection ) && checkProperty(value,'currentlyInUS') || !canRenderField('currentlyInUS',fieldsArray, false, tplsection ) )">

                <div class="vx-col w-full" v-if="canRenderField('currentStatus',fieldsArray, false, tplsection ) || canRenderField('statusExpiryDate',fieldsArray, false, tplsection )||
                 canRenderField('I94',fieldsArray, false, tplsection )||canRenderField('I94ExpiryDate',fieldsArray, false, tplsection )||
                 canRenderField('eadNumber',fieldsArray, false, tplsection )||canRenderField('sevisNumber',fieldsArray, false, tplsection )">
                    <h3 class="small-header">Status in USA</h3>
                </div>
                <selectField  :display="false" :tplkey="'currentStatus'" :tplsection="tplsection" :fieldsArray="fieldsArray" @input="value.currentStatus = value.currentStatusDetails.id;checkDSExpireFields()" :required="value.currentlyInUS || value.statusExpiryDate != null" :optionslist="petition.visaStatusList" v-model="value.currentStatusDetails" :formscope="formscope" fieldName="spouse_current_status" label="Current Status" vvas="Current Status" placeholder="Current Status" />
                <div class="vx-col w-full md:w-1/2 relative"  v-if="(canRenderField('isDSExpiryDate',fieldsArray, false, tplsection )&& checkProperty(value,'currentStatusDetails')&& checkProperty(value,'currentStatusDetails','id') )|| canRenderField('statusExpiryDate',fieldsArray, false, tplsection )  ">
                    <div class="vs-col ds_check ds_check_v2"  v-if="canRenderField('isDSExpiryDate',fieldsArray, false, tplsection )&& checkProperty(value,'currentStatusDetails')&& checkProperty(value,'currentStatusDetails','id')  " >
                        <div class="form_group custom-form-label custom-cx-box">
                            <vs-checkbox v-model="value.isDSExpiryDate" :tplsection="'beneficiaryInfo'" :fieldName="'isDSExpiryDate'"  data-vv-as="isDSExpiryDate"  name="isDSExpiryDate" @input="clearCurrentStatusField"
                            >Check here if D/S
                            </vs-checkbox>
                        </div>
                    </div>
                    <datepickerField :wrapclass="'md:w-full'" :isDisabled="(canRenderField('isDSExpiryDate',fieldsArray, false, tplsection ) && value.isDSExpiryDate) || !value.currentStatus"  
                    :notRequired="canRenderField('isDSExpiryDate',fieldsArray, false, tplsection ) && value.isDSExpiryDate "  :display="false" :tplkey="'statusExpiryDate'" :tplsection="tplsection"  :fieldsArray="fieldsArray" :dateEnableFrom="featureDates"  :validationRequired="value.currentlyInUS || value.currentStatusDetails != null" v-model="value.statusExpiryDate" :formscope="formscope" fieldName="spouse_status_expiry_date" label="Current Status Expiry Date" />
                </div>
                <immiInput :allowUpperCase="true"  :display="false" :tplkey="'I94'" :tplsection="tplsection"    :fieldsArray="fieldsArray" cid="benI94" datatype="max:15" :formscope="formscope" v-model="value.I94" :required="value.currentlyInUS?true:false" @input="I94ValueCheck(value.I94)" fieldName="spouse_i94" label="I-94 Number" placeHolder="I-94 Number" />

                <div class="vx-col w-full md:w-1/2 relative" v-if="(canRenderField('isI94DSExpiryDate',fieldsArray, false, tplsection )&& checkProperty(value,'I94') ) || canRenderField('I94ExpiryDate',fieldsArray, false, tplsection )   ">
                    <div class="vs-col ds_check ds_check_v2"  v-if="canRenderField('isI94DSExpiryDate',fieldsArray, false, tplsection )&& checkProperty(value,'I94')" >
                        <div class="form_group custom-form-label custom-cx-box">
                            <vs-checkbox v-model="value.isI94DSExpiryDate" :tplsection="'beneficiaryInfo'" :fieldName="'isI94DSExpiryDate'"  data-vv-as="isI94DSExpiryDate"  name="isI94DSExpiryDate" @input="clearI94Field"
                            >Check here if D/S
                            </vs-checkbox>
                        </div>
                    </div>
                    <datepickerField :wrapclass="'md:w-full'" :isDisabled="(canRenderField('isI94DSExpiryDate',fieldsArray, false, tplsection ) && value.isI94DSExpiryDate) || !value.I94 " :notRequired="canRenderField('isI94DSExpiryDate',fieldsArray, false, tplsection ) && value.isI94DSExpiryDate "  :display="false" :tplkey="'I94ExpiryDate'" :tplsection="tplsection" :fieldsArray="fieldsArray" :validationRequired="value.I94?true:false"  v-model="value.I94ExpiryDate" :formscope="formscope" :dateEnableFrom="featureDates" fieldName="spo_I94ExpiryDate" label="I-94 Expiry Date" />
                </div>

                <immiInput :allowUpperCase="true" :display="false" :mRequired="[1,2].indexOf(checkProperty(value,'currentStatusDetails','id'))>-1?true:false" :tplkey="'sevisNumber'" :fieldsArray="fieldsArray" datatype="alpha_num|max:15" cid="benfsevisNumber" :formscope="formscope" v-model="value.sevisNumber" :tplsection="tplsection"  :fieldName="'sevisNumber'"    label="SEVIS  Number" placeHolder="SEVIS  Number" />
                <immiInput :allowUpperCase="true" :display="false" :tplkey="'eadNumber'"  :fieldsArray="fieldsArray" datatype="alpha_num|min:9|max:20" cid="benfeadNumber" :formscope="formscope" v-model="value.eadNumber" :maxCharacters="20" :tplsection="tplsection"  :fieldName="'eadNumber'"   label="EAD  Number" placeHolder="EAD  Number" />
            </template>
            
    
            <template v-if="(canRenderField('currentlyInUS',fieldsArray, false, tplsection ) && checkProperty(value,'currentlyInUS')) || !canRenderField('currentlyInUS',tplsection, false, tplsection ) ">
                <div class="vx-col w-full" v-if="canRenderField('currentAddress', fieldsArray ,false,tplsection)" >
                    <h3 class="small-header">Current Address</h3>
                    <div>
                        <addressField :prefiilAddress="prefillCountryInQuestionnaire == false||([10,8].indexOf(checkProperty(petition,'subTypeDetails','id'))>-1 && checkProperty(petition,'typeDetails','id')==1 )?false:true" 
                        :fieldsArray="fieldsArray" :disableCountry="value.currentlyInUS" :formscope="formscope" :showaptType="true" :addFormContainerCls="false" :validationRequired="checkFieldIsRequired({'key':'currentAddress','section':tplsection, 'fieldsArray':fieldsArray, 'required':true })" :countries="countries" v-model="value.currentAddress" :cid="'spo_Infoaddress'" />
    
                    </div>
                </div>
            </template>
            <div  class="vx-col w-full" v-if=" canRenderField('physicalAddress',fieldsArray, false, tplsection )" >                                                                                       
                <div class="vx-col w-full d-flex">
                    <h3 class="small-header">Mailing Address</h3>
                    <template v-if="canRenderField('currentlyInUS',fieldsArray, false, tplsection ) && checkProperty(value,'currentlyInUS')">
                        <vs-checkbox @change="setSameaddress(true)"  v-model="value.mailingAddressIsSameAsAddress" :tplsection="tplsection"  :fieldName="'mailingAddressIsSameAsAddress'" 
                        style="margin-left: 15px; margin-bottom:12px;">Same as Current Address </vs-checkbox
                        >
                    </template>
                </div>
                <template v-if=" countries.length>0">
                    
                
                <addressField :ref="'mailingAddresscomponent'"  :prefiilAddress="prefillCountryInQuestionnaire == false?false:true"  :display="true" :fieldsArray="fieldsArray" :disableCountry="value.currentlyInUS && checkProperty(value,'physicalAddress') && checkProperty(value,'physicalAddress','countryDetails')
                && checkProperty(value,'physicalAddress','countryId') && checkProperty(value,'currentAddress') && checkProperty(value,'currentAddress','countryDetails')
                && checkProperty(value,'currentAddress','countryId') && value.mailingAddressIsSameAsAddress && canRenderField('currentlyInUS',fieldsArray, false, tplsection ) "
                :formscope="formscope" :showaptType="true" :addFormContainerCls="false" :validationRequired="checkFieldIsRequired({'key':'physicalAddress','section':tplsection, 'fieldsArray':fieldsArray, 'required':true })" :countries="countries" v-model="value.physicalAddress" :tplsection="tplsection"  :fieldName="'physicalAddress'"  :cid="'spousemailInfoaddress'" />
                </template>
            </div>



                <div class="vx-col w-full"  v-if=" canRenderField('addressOutsideUS', fieldsArray ,false,tplsection)">
                    <h3 v-if="callFromPerm" class="small-header">Foreign Address</h3>
                    <h3 v-else class="small-header">Address Outside the U.S</h3>
                    <addressField :prefiilAddress="prefillCountryInQuestionnaire" :hideusa="true" :validationRequired="checkFieldIsRequired({'key':'addressOutsideUS','section':tplsection, 'fieldsArray':fieldsArray, 'required':true })" 
                     :fieldsArray="fieldsArray" :disableCountry="false" :formscope="formscope" :showaptType="true" :addFormContainerCls="false" :countries="countries" v-model="value.addressOutsideUS" fieldName="spo_addressOutsideUS" :cid="'spo_addressOutsideUS'" />
                </div>
                <template v-if=" canRenderField('addressOfLastNYears', fieldsArray ,false,tplsection) ||  canRenderField('addressOutsideUSMoreThanYear', fieldsArray ,false,tplsection)">
                    <div class="vx-col w-full" v-if="canRenderField('addressOfLastNYears',fieldsArray ,false,tplsection) && checkProperty(value,'addressOfLastNYears') && checkProperty(value,'addressOfLastNYears','length')>0">                                      
                        <template v-if="canRenderField('addressOfLastNYears',fieldsArray ,false,tplsection) && checkProperty(value,'addressOfLastNYears') && checkProperty(value,'addressOfLastNYears','length')>0">
                            <h3 class="small-header">Your Residence starting with most current for the Past Five Years in the U.S and Abroad </h3>
                            <div class="I-485-wrapper">
                                <div class="vx-row delete-row I-485-bg I-485-bg_custom_modal d-block" v-for="(lyearItem, index) in value['addressOfLastNYears']" :key="index">
                                    <addressField :tplkey="'addressOfLastNYears'" :fieldsArray="fieldsArray"  :disableCountry="false" :formscope="formscope" :showaptType="true" :addFormContainerCls="false" 
                                    :validationRequired="checkFieldIsRequired({'key':'addressOfLastNYears','section':tplsection,'fieldsArray':fieldsArray, 'required':true})" :countries="countries" v-model="value['addressOfLastNYears'][index]"
                                     :tplsection="tplsection" :id="'depaddressOfLastNYears'+index"  :fieldName="'depaddressOfLastNYears'+index"  :cid="'depaddressOfLastNYears'+index" />
                                    <div class="vx-row">
                                        <datepickerField  @input="clearDependentField(lyearItem)" :display="false" :fieldsArray="fieldsArray" :tplkey="'startDate'"  :validationRequired="true" v-model="lyearItem.startDate" :formscope="formscope" :dateEnableTo="featureDates"  :tplsection="'dependentsInfo.spouse.addressOfLastNYears'"  :fieldName="'startDate_addressOfLastNYears'+index" :cid="'startDate_addressOfLastNYears'+index"  label="Start Date" />
                                        <datepickerField   :display="false" :fieldsArray="fieldsArray" :tplkey="'endDate'" :isDisabled="!lyearItem.startDate"  :validationRequired="true" v-model="lyearItem.endDate" :dateEnableFrom="lyearItem.startDate" :formscope="formscope" :dateEnableTo="featureDates"  :tplsection="'dependentsInfo.spouse.addressOfLastNYears'" :cid="'endDate_addressOfLastNYears'+index"  :fieldName="'endDate_addressOfLastNYears'+index"  label="End Date" />
                                    </div> 
                                    <div class="delete" v-if="value['addressOfLastNYears'].length > 1">
                                        <a @click="removeNyears(index)">
                                            <img src="@/assets/images/main/delete-row-img-white.svg" />
                                        </a>
                                    </div>
                                </div>
                            </div> 
                        </template>
                        <div class="m-auto mt-3 mb-6" vs-type="flex" vs-align="center" vs-lg="2" vs-sm="2">
                                     <a @click="addNyears()" class="add-more ml-0" style="display:inline-block" type="filled">
                                        <span>+</span> More</a>
                        </div>
                </div>
                <div class="vx-col w-full" v-if="canRenderField('addressOutsideUSMoreThanYear',fieldsArray ,false,tplsection) && checkProperty(value,'addressOutsideUSMoreThanYear') && checkProperty(value,'addressOutsideUSMoreThanYear','length')>0">                                      
                        <template v-if="canRenderField('addressOutsideUSMoreThanYear',fieldsArray ,false,tplsection) && checkProperty(value,'addressOutsideUSMoreThanYear') && checkProperty(value,'addressOutsideUSMoreThanYear','length')>0">
                            <h3 class="small-header">Last Address outside Of the United States for more than one year </h3>
                            <div class="I-485-wrapper">
                                <div class="vx-row delete-row I-485-bg I-485-bg_custom_modal d-block" v-for="(lastYearItem, ind) in value['addressOutsideUSMoreThanYear']" :key="ind">
                                    <addressField :tplkey="'addressOutsideUSMoreThanYear'" :hideusa="true" :fieldsArray="fieldsArray"  :disableCountry="false" :formscope="formscope" :showaptType="true" :addFormContainerCls="false" :validationRequired="checkFieldIsRequired({'key':'addressOutsideUSMoreThanYear','section':tplsection,'fieldsArray':fieldsArray, 'required':true})" :countries="countries" v-model="value['addressOutsideUSMoreThanYear'][ind]" :tplsection="tplsection"  :fieldName="'addressOutsideUSMoreThanYear'+ind"  :cid="'addressOutsideUSMoreThanYear'+ind" />
                                    <div class="vx-row">
                                        <datepickerField  @input="clearEndDate(lastYearItem)" :display="false" :fieldsArray="fieldsArray" :tplkey="'startDate'"  :validationRequired="true" v-model="lastYearItem.startDate" :formscope="formscope" :dateEnableTo="featureDates"  :tplsection="'dependentsInfo.spouse.addressOutsideUSMoreThanYear'"  :fieldName="'startDate_addressOutsideUSMoreThanYear'+ind" :cid="'startDate_addressOutsideUSMoreThanYear'+ind"  label="Start Date" />
                                        <datepickerField   :display="false" :fieldsArray="fieldsArray" :tplkey="'endDate'" :isDisabled="!lastYearItem.startDate"  :validationRequired="true" v-model="lastYearItem.endDate" :dateEnableFrom="lastYearItem.startDate" :formscope="formscope" :dateEnableTo="featureDates"  :tplsection="'dependentsInfo.spouse.addressOutsideUSMoreThanYear'" :cid="'endDate_addressOutsideUSMoreThanYear'+ind"  :fieldName="'endDate_addressOutsideUSMoreThanYear'+ind"  label="End Date" /> 
                                    </div>
                                    <div class="delete" v-if="value['addressOutsideUSMoreThanYear'].length > 1">
                                        <a @click="removeLastYearItem(ind)">
                                            <img src="@/assets/images/main/delete-row-img-white.svg" />
                                        </a>
                                    </div>
                                </div>
                            </div> 
                        </template>
                        <!-- <div class="m-auto" vs-type="flex" vs-align="center" vs-lg="2" vs-sm="2">
                                     <a @click="addLastYearItem()" class="add-more ml-0" style="display:inline-block" type="filled">
                                        <span>+</span> More</a>
                        </div> -->
                </div>
                </template>
                <!-- <div class="vx-col w-full" v-if="canRenderField('addressOfLastNYears',fieldsArray ,false,tplsection) && checkProperty(value,'addressOfLastNYears') && checkProperty(value,'addressOfLastNYears','length')>0">
                    <div>
                        <h3 class="small-header">Your Residence starting with most current for the Past Five Years in the U.S and Abroad </h3>
                        <addressField :tplkey="'addressOfLastNYears'" :fieldsArray="fieldsArray"  :disableCountry="false" :formscope="formscope" :showaptType="true" :addFormContainerCls="false" :validationRequired="true" :countries="countries" v-model="value['addressOfLastNYears'][0]" :tplsection="tplsection"  :fieldName="'addressOfLastNYears'"  :cid="'depaddressOfLastNYears'" />
                    </div>
                </div>
                <template v-if="canRenderField('addressOfLastNYears',fieldsArray ,false,tplsection) && checkProperty(value,'addressOfLastNYears') &&  checkProperty(value,'addressOfLastNYears','length')>0">
                    <datepickerField  @input="clearDependentField(value.addressOfLastNYears)" :display="false" :fieldsArray="fieldsArray" :tplkey="'startDate'"  :validationRequired="true" v-model="value['addressOfLastNYears'][0].startDate" :formscope="formscope" :dateEnableTo="featureDates"  :tplsection="'dependentsInfo.spouse.addressOfLastNYears'"  :fieldName="'startDate_addressOfLastNYears'"  label="Start Date" />
                    <datepickerField  :display="false" :fieldsArray="fieldsArray" :isDisabled="!value['addressOfLastNYears'][0].startDate" :dateEnableFrom="value['addressOfLastNYears'][0].startDate" :tplkey="'endDate'"  :validationRequired="true" v-model="value['addressOfLastNYears'][0].endDate" :formscope="formscope" :dateEnableTo="featureDates"  :tplsection="'dependentsInfo.spouse.addressOfLastNYears'"  :fieldName="'endDate_addressOfLastNYears'"  label="End Date" /> 
                </template> -->
                <!-- <div class="vx-col w-full" v-if="canRenderField('addressOutsideUSMoreThanYear',fieldsArray ,false,tplsection) && checkProperty(value,'addressOutsideUSMoreThanYear') && checkProperty(value,'addressOutsideUSMoreThanYear','length')>0">
                    <div>
                        <h3 class="small-header">Last Address outside Of the United States for more than one year</h3>
                        <addressField :hideusa="true" :fieldsArray="fieldsArray" :tplkey="'addressOutsideUSMoreThanYear'" :formscope="formscope" :showaptType="true" :addFormContainerCls="false" :validationRequired="true" :countries="countries" v-model="value['addressOutsideUSMoreThanYear'][0]" :tplsection="tplsection"  :fieldName="'addressOutsideUSMoreThanYear'"  :cid="'depaddressOutsideUSMoreThanYear'" />
                    </div>
                </div>
                <template v-if="canRenderField('addressOutsideUSMoreThanYear',fieldsArray ,false,tplsection) && checkProperty(value,'addressOutsideUSMoreThanYear') && checkProperty(value,'addressOutsideUSMoreThanYear','length')>0">
                    <datepickerField  @input="clearEndDate(value.addressOutsideUSMoreThanYear)" :display="false" :fieldsArray="fieldsArray" :tplkey="'startDate'"  :validationRequired="true" v-model="value['addressOutsideUSMoreThanYear'][0].startDate" :formscope="formscope" :dateEnableTo="featureDates"  :tplsection="'dependentsInfo.spouse.addressOutsideUSMoreThanYear'"  :fieldName="'startDate_addressOutsideUSMoreThanYear'"  label="Start Date" />
                    <datepickerField  :display="false" :fieldsArray="fieldsArray" :isDisabled="!value['addressOutsideUSMoreThanYear'][0].startDate" :dateEnableFrom="value['addressOutsideUSMoreThanYear'][0].startDate" :tplkey="'endDate'"  :validationRequired="true" v-model="value['addressOutsideUSMoreThanYear'][0].endDate" :formscope="formscope" :dateEnableTo="featureDates"  :tplsection="'dependentsInfo.spouse.addressOutsideUSMoreThanYear'"  :fieldName="'endDate_addressOutsideUSMoreThanYear'"  label="End Date" />
                </template> -->
                <immiyesorno @input="checkssnNumber" :cid="'doYouHaveSSN'" :formscope="formscope" :required="checkFieldIsRequired({'key':'doYouHaveSSN','section':tplsection, 'fieldsArray':fieldsArray, 'required':true })" :wrapclass="'swicth-label_v2 yesno-v2 formgroup-mb0 h4_ead_label'" :display="false" :tplkey="'doYouHaveSSN'" :fieldsArray="fieldsArray"   v-model="value.doYouHaveSSN" :tplsection="tplsection"  :fieldName="'doYouHaveSSN'"   label="Do you have SSN?"></immiyesorno>
                <template v-if="(canRenderField('doYouHaveSSN',fieldsArray,false ,tplsection)  && checkProperty(value, 'doYouHaveSSN')) || !canRenderField('doYouHaveSSN',fieldsArray,false ,tplsection) ">
                    <immiMask :display="false" :tplkey="'SSN'" :tplsection="tplsection"  :fieldsArray="fieldsArray" :patren="['### - ## - ####']" datatype="min:9|max:9" :wrapclass="canRenderField('spo_alienNumber',fieldsArray)?'md:w-1/2':' '" cid="spouse_ssn" :formscope="formscope" v-model="value.SSN" :required="false" fieldName="spouse_ssn" label="Social Security number (if applicable)" vvas="Social Security number" placeHolder="123 - 45 - 6789" />
                </template>

                <template v-if="(canRenderField('doYouHaveSSN',fieldsArray,false ,tplsection)  && checkProperty(value, 'doYouHaveSSN') == false) ">
                    <immiyesorno  @input="checkssnNumber" :cid="'doYouWantTheSsaToIssueYouSS'" :formscope="formscope" :required="checkFieldIsRequired({'key':'doYouWantTheSsaToIssueYouSS','section':tplsection, 'fieldsArray':fieldsArray, 'required':true })" :wrapclass="'swicth-label_v2 yesno-v2 formgroup-mb0 h4_ead_label'" :display="false" :tplkey="'doYouWantTheSsaToIssueYouSS'" :fieldsArray="fieldsArray"   v-model="value.doYouWantTheSsaToIssueYouSS" :tplsection="tplsection"  :fieldName="'doYouWantTheSsaToIssueYouSS'"   label="Do you want the SSA to issue you a Social Security card?"></immiyesorno>
                </template>
                <template v-if="(canRenderField('doYouWantTheSsaToIssueYouSS',fieldsArray,false ,tplsection)  && checkProperty(value, 'doYouWantTheSsaToIssueYouSS') && !checkProperty(value, 'doYouHaveSSN'))">
                    <div class="vx-col w-full" v-if="canRenderField('familyName', fieldsArray ,false,'dependentsInfo.spouse.ssnFather') || canRenderField('givenName', fieldsArray ,false,'dependentsInfo.spouse.ssnFather') ">
                        <h5 class="names_title">Father Name</h5>
                    </div>
                    <immiInput :display="false" :fieldsArray="fieldsArray"  cid="familyName" :formscope="formscope" v-model="value.ssnFather.familyName" :tplsection="'dependentsInfo.spouse.ssnFather'" :tplkey="'familyName'" :fieldName="'familyName'"  :required="true"  label="Family Name" placeHolder="Family Name" />
                    <immiInput :display="false" :fieldsArray="fieldsArray"  cid="givenName" :formscope="formscope" v-model="value.ssnFather.givenName" :tplsection="'dependentsInfo.spouse.ssnFather'" :tplkey="'givenName'" :fieldName="'givenName'"  :required="true"  label="Given Name" placeHolder="Given Name" />
                    <div class="vx-col w-full" v-if="canRenderField('familyName', fieldsArray ,false,'dependentsInfo.spouse.ssnMother') || canRenderField('givenName', fieldsArray ,false,'dependentsInfo.spouse.ssnMother') ">
                        <h5 class="names_title">Mother Name</h5>
                    </div>
                    <immiInput :display="false" :fieldsArray="fieldsArray"  cid="familyName" :formscope="formscope" v-model="value.ssnMother.familyName" :tplsection="'dependentsInfo.spouse.ssnMother'" :tplkey="'familyName'" :fieldName="'familyName'"  :required="true"  label="Family Name" placeHolder="Family Name" />
                    <immiInput :display="false" :fieldsArray="fieldsArray"  cid="givenName" :formscope="formscope" v-model="value.ssnMother.givenName" :tplsection="'dependentsInfo.spouse.ssnMother'" :tplkey="'givenName'" :fieldName="'givenName'"  :required="true"  label="Given Name" placeHolder="Given Name" />
                </template>
                <immiyesorno @input="clearHaveYouEverTravel" :cid="'haveYouEverTravelledToUS'" :formscope="formscope" :required="checkFieldIsRequired({'key':'haveYouEverTravelledToUS','section':tplsection, 'fieldsArray':fieldsArray, 'required':true })" :wrapclass="'swicth-label_v2 yesno-v2 formgroup-mb0 h4_ead_label'" :display="false" :tplkey="'haveYouEverTravelledToUS'" :fieldsArray="fieldsArray"   v-model="value.haveYouEverTravelledToUS" :tplsection="tplsection"  :fieldName="'haveYouEverTravelledToUS'"   label="Have you ever travelled to the United States?"></immiyesorno>
                <immiInput v-if="value.haveYouEverTravelledToUS" :display="false" :fieldsArray="fieldsArray"  cid="immigStatusLastArrival" :formscope="formscope" v-model="value.immigStatusLastArrival" :tplsection="tplsection" :tplkey="'immigStatusLastArrival'" :fieldName="'immigStatusLastArrival'"  :required="true"  label="Immigration Status at Your Last Arrival" placeHolder="Immigration Status at Your Last Arrival" />


                <immiInput :display="false" :tplkey="'alienNumber'" :tplsection="tplsection"  :fieldsArray="fieldsArray" datatype="alpha_num|max:9" cid="spo_alienNumber" :formscope="formscope" v-model="value.alienNumber" fieldName="spo_alienNumber" label="Alien Number (if applicable) " placeHolder="Alien Number" />        
                  <template v-if="(canRenderField('haveYouEverTravelledToUS',fieldsArray,false ,tplsection)  && value.haveYouEverTravelledToUS && canRenderField('priorPeriodOfStayInUS', fieldsArray ,false,tplsection )) || (!canRenderField('haveYouEverTravelledToUS',fieldsArray,false ,tplsection) && canRenderField('priorPeriodOfStayInUS', fieldsArray ,false,tplsection )) ">
                <immipriorstay  :tplsection="getTplSection" :noday="false" :fieldsArray="fieldsArray" :formscope="formscope" v-if="canRenderField('priorPeriodOfStayInUS', fieldsArray ,false,tplsection ) && petition && petition.visaStatusList && petition.visaStatusList.length > 0" fieldName="spo_priorPeriodOfStayInUS" :petition="petition" v-model="value.priorPeriodOfStayInUS"></immipriorstay>
                    </template>
                
            </div>
        </div>
    </vs-col>
    </template>
    
    <script>
    import genderField from '@/views/forms/fields/gender.vue'
    import immiInput from "@/views/forms/fields/simpleinput.vue";
    import {
        Trash2Icon
    } from "vue-feather-icons";
    import addressField from "@/views/forms/fields/address.vue";
    import datepickerField from "@/views/forms/fields/datepicker.vue";
    import selectField from "@/views/forms/fields/simpleselect.vue";
    import immiPhone from "@/views/forms/fields/phonenumber.vue";
    import immiMask from "@/views/forms/fields/maskinput.vue";
    import immiyesorno from "@/views/forms/fields/yesorno.vue";
    import immiuploader from "@/views/forms/fields/fileupload.vue";
    import immipriorstay from "@/views/forms/fields/priorstay.vue";
    import immitextarea from "@/views/forms/fields/simpletextarea.vue";
    import immieducations from "@/views/forms/fields/educations.vue";
    import immiswitchyesno from "@/views/forms/fields/switchyesno.vue";
    //import Datepicker from "vuejs-datepicker-inv";
    import Vue from 'vue';
    import casedocumentslist from "@/views/common/casedocuments.vue";
    import immiemployment from "@/views/forms/fields/employment.vue";
    import moment from "moment";
    import petitionsinformation from "@/views/forms/fields/petitionsinformation.vue";
    import previousSpouseForm from "@/views/petition/gc/previousSpouseForm.vue";
    export default {
        inject: ["parentValidator"],
        props: {
            callFromPerm:{
                type: Boolean,
                default: false,
            },
            countriesWithoutUS:{
                type: Array,
                default: [],
            },
            races_list:{
                type: Array,
                default: [],
            },
            eye_colorList:{
                type: Array,
                default: [],
            },
            hair_colorsList:{
                type: Array,
                default: [],
            },
            feetList:{
                type: Array,
                default: [],
            },
            inchesList:{
                type: Array,
                default: [],
            },
            marital_statuses:{
                type: Array,
                default: [],
            },
            visastatuses:{
                type: Array,
                default: [],
            },
            prefillCountryInQuestionnaire:{
                type: Boolean,
                default: true,
            },
            tplsection:{
                type: String,
                default: null,
            },
            petition: Object,
            countries: Array,
            display: {
                type: Boolean,
                default: false,
            },
            fieldsArray: Array,
            vvas: {
                type: String,
                default: ""
            },
            wrapclass: {
                type: String,
                default: "md:w-1/2"
            },
            datatype: {
                type: String,
                default: ""
            },
            cid: {
                type: String,
                default: null,
            },
            formscope: {
                type: String,
                default: null
            },
            value: null,
            label: {
                type: String,
                default: null,
            },
            fieldName: {
                type: String,
                default: null,
            },
            placeHolder: {
                type: String,
                default: null,
            },
            required: {
                type: Boolean,
                default: false,
            }
        },
        created() {
            this.$validator = this.parentValidator;
        },
    
        components: {
            previousSpouseForm,
             //Datepicker,
            genderField,
            immiInput,
            addressField,
            Trash2Icon,
            datepickerField,
            selectField,
            immiPhone,
            immiMask,
            immiyesorno,
            immiuploader,
            immipriorstay,
            immitextarea,
            immieducations,
            immiswitchyesno,
            casedocumentslist,
            immiemployment,
            petitionsinformation
        },
        data() {
            return {
                fileredMartialList:[],
                disablefield:false,
                h4EadPhotoEmailStmt:'Two US style photographs are required for H4 EAD filing, please mail the copies to our office address: Somireddy Law Group PLLC, 20745 Williamsport Place, Suite 390, Ashburn, Virginia 20147.',
                usastates:[],
                presentDay : moment().subtract(1, 'day'),
                consularProcessingValidator:'',
                featureDates:null,
                            startEligibleDate: new Date().setFullYear(new Date().getFullYear() - 18),
                  currentDate: new Date(),
                bfeprovinceStates: [],
                statesOfMarriage:[],
                haveYouArrestedBeforeDocsList:[{
                    required: false,
                        key: 'docs_haveYouArrestedBeforeDocs',
                        fieldName: 'haveYouArrestedBeforeDocs',
                        label: 'Please provide documents, if any'
                }],  
                appliedAOSInUSDocsList:[{
                        required: false,
                        key: 'docs_appliedAOSInUSDocs',
                        fieldName: 'appliedAOSInUSDocs',
                        label: 'Documents'
                    }],
                 eadCardList:[{
                        required: false,
                        key: 'spouse_docs_eadCard',
                        fieldName: 'eadCard',
                        label: 'Please provide a copy of the EAD CARD(S), front and  back'
                 }], 
                 marriageCertDocsList:[{
                    required: false,
                        key: 'docs_marriageCertDocs',
                        fieldName: 'marriageCertDocs',
                        label: 'Marriage Certificates'
                 }],
            };
        },
        mounted() {
            this.fileredMartialList=[];
            this.fileredMartialList=_.filter(this.marital_statuses,(item)=>{
                return item.id !=1 
                })
            
            this.$store.dispatch("getstates", 231).then((response) => {
                this.usastates = response;
            })
            //this.loadStatesByCountry('usastates', 231)
            this.value.relationship ="Spouse"
            if(this.value.I94=='' && this.checkProperty(this.value,'isI94DSExpiryDate') ==false){
                this.value.I94ExpiryDate = null;
                this.disablefield = true;
              }
            if (this.value.countryOfBirthDetails && this.value.countryOfBirth != null) {
    
                this.loadStatesByCountry('bfeprovinceStates', this.value.countryOfBirth)
    
            }
            if (this.value.countryOfMarriageDetails && this.value.countryOfMarriage != null) {
                this.loadStatesByCountry('statesOfMarriage', this.value.countryOfMarriage)
            }
          
                this.loadStatesByCountry('usastates', 231)
                this.featureDates = new Date();
    
               let currentStatus = this.value.currentStatus;
                if (currentStatus != null) {
                    this.value.currentStatusDetails = _.find(this.petition.visaStatusList, function (item) {
    
                        return item.id == currentStatus
                    })
                }
                setTimeout(()=>{
                    if(this.value['adjustmentOfI485Status'] || this.value['consularProcessing']){
                    this.consularProcessingValidator ='consularProcessingValidator';
                    }
                   
                });
                //this.updateAnyotherCountries(true);
        },
        methods: {
            updateAnyotherCountries(callFomMOut = false){
                // if(callFomMOut){
                //     if(this.checkProperty(this.countries, 'length')>0 && this.checkProperty(this.value, 'otherCountriesOfCitizenship') &&  this.checkProperty(this.value, 'otherCountriesOfCitizenship', 'length')>0){
                //         countries
                //         _.forEach(this.value['otherCountriesOfCitizenship'], (it)=>{
                //             let findObj = _.find(this.countries,{'id':it});
                //             let tempobj =  _.find(this.value['otherCountriesOfCitizenshipDetails'],{'id':it});
                //             if(!tempobj){
                //                 this.value['otherCountriesOfCitizenshipDetails'].push(findObj)
                //             }
                //         })
                //     }else{
                //         this.value['otherCountriesOfCitizenshipDetails'] = [];
                //         this.value['otherCountriesOfCitizenship'] = []
                //     }
                // }else{
                //     if(this.checkProperty(this.value, 'otherCountriesOfCitizenshipDetails') && this.checkProperty(this.value, 'otherCountriesOfCitizenshipDetails','length')>0){
                //     this.value['otherCountriesOfCitizenship'] =   _.map(this.value['otherCountriesOfCitizenshipDetails'], 'id');
                //     }else{
                //         this.value['otherCountriesOfCitizenshipDetails'] = [];
                //         this.value['otherCountriesOfCitizenship'] = []
                //     }
                // }
                
            },
            clearHaveYouEverTravel(){
                if(!this.value.haveYouEverTravelledToUS ){
                    this.value['immigStatusLastArrival'] = '';
                }
            },
            checkssnNumber(){
                if(this.value.doYouHaveSSN == false){
                    this.value.SSN = '';
                }
                if(this.value.doYouHaveSSN){
                    this.value.doYouWantTheSsaToIssueYouSS = false;
                    this.value.ssnFather.familyName = '';
                    this.value.ssnFather.givenName = '';
                    this.value.ssnMother.familyName = '';
                    this.value.ssnMother.givenName = '';
                }
            },
            setSameaddress(callFromChecckBox =true){
                if( this.checkProperty(this.value,'currentlyInUS') 
                && this.canRenderField('currentlyInUS',this.fieldsArray, false, this.tplsection ) && this.value.mailingAddressIsSameAsAddress){
                    this.value['physicalAddress'] = _.cloneDeep(this.value['currentAddress']);
                }else{
                    if(callFromChecckBox){
                        this.value['physicalAddress'] =  {
                            line1: null,
                            line2: null,
                            aptType: null,
                            locationId: null,
                            locationDetails: null,
                            stateId: null,
                            stateDetails: null,
                            countryId: null,
                            countryDetails: null,
                            zipcode: null
                        }
                    }
                }
            },
            addNyears(){
                let obj ={
                        line1: null,
                        line2: null,
                        aptType: null,
                        locationId: null,
                        locationDetails: null,
                        stateId: null,
                        stateDetails: null,
                        countryId: null,
                        countryDetails: {
                            _id: "61408c9ed01ea1248cdcf6b7",
                            id: 231,
                            name: "United States",
                            phoneCode: 1,
                            order: 1,
                            currencySymbol: "$",
                            currencyCode: "USD",
                            zipcodeLength: 5,
                            sortName: "united states",
                        },
                        zipcode: null,
                        startDate: null,
                        endDate: null,
                }
                this.value['addressOfLastNYears'].push(obj);
                this.value['addressOfLastNYears'] = _.cloneDeep( this.value['addressOfLastNYears']);
            },
            removeNyears: function (index) {
                Vue.delete(this.value.addressOfLastNYears, index);
            },
            addLastYearItem(){
                let obj ={
                        line1: null,
                        line2: null,
                        aptType: null,
                        locationId: null,
                        locationDetails: null,
                        stateId: null,
                        stateDetails: null,
                        countryId: null,
                        countryDetails: {
                            _id: "61408c9ed01ea1248cdcf6b7",
                            id: 231,
                            name: "United States",
                            phoneCode: 1,
                            order: 1,
                            currencySymbol: "$",
                            currencyCode: "USD",
                            zipcodeLength: 5,
                            sortName: "united states",
                        },
                        zipcode: null,
                        startDate: null,
                        endDate: null,
                }
                    this.value['addressOutsideUSMoreThanYear'].push(obj);
                   this.value['addressOutsideUSMoreThanYear'] = _.cloneDeep( this.value['addressOutsideUSMoreThanYear']); 
            },
            removeLastYearItem: function (ind) {
                Vue.delete(this.value.addressOutsideUSMoreThanYear, ind);
            },
            clearDependentField(obj){
                        if(obj['startDate']==null){
                            obj.endDate = null;
                        }
                        if(obj.startDate > obj.endDate){
                            obj.endDate = null;
                        }   
            },
            clearDateOfMarriageEnd(val){
                if(val){
                    if(val > this.value.dateOfMarriageEnd){
                      this.value.dateOfMarriageEnd =null;
                    }
                }
                else{
                    this.value.dateOfMarriageEnd=null;
                }
            },
            clearEndDate(obj){
                        if(obj['startDate']==null){
                            obj.endDate = null;
                        }
                        if(obj.startDate > obj.endDate){
                            obj.endDate = null;
                        }
            },
            I94ValueCheck(val){
                if(!val){
                    this.value.isI94DSExpiryDate = false;
                }
               if(val.length<=0 && this.checkProperty(this.value,'isI94DSExpiryDate') ==false){
                this.value.I94ExpiryDate = null;
                this.disablefield = true;
              }
            },
            changeCountryMarriage(value){
            
            this.value.countryOfMarriage = this.value.countryOfMarriageDetails.id;
            this.statesOfMarriage = [];
            this.value.provinceOfMarriageDetails = null,
            this.value.provinceOfMarriage = null;
            this.loadStatesByCountry('statesOfMarriage', value.id)
        },
            clearCurrentStatusField(val){
                if(val){
                    this.value.statusExpiryDate = null;
                }
            },
            clearI94Field(val){
                if(val){
                    this.value.I94ExpiryDate = null;
                }
            },
            checkDSExpireFields(){
                if(this.checkProperty(this.value,'currentStatusDetails') && !this.checkProperty(this.value,'currentStatusDetails','id')
                ){
                    this.value.isDSExpiryDate = false;
                }
            },
            changedAdjustmentOfI485Status(val){
               
                if(this.value['adjustmentOfI485Status']){
    
                    this.value.consularProcessing = false;
                }
                this.consularProcessingValidator ='';
    
                if(this.value['adjustmentOfI485Status'] || this.value['consularProcessing']){
                    this.consularProcessingValidator ='adjustmentOfI485Status';
                }
                //this.value.consularProcessing = true;
               // this.value['adjustmentOfI485Status'] =false
    
            },
            changedConsularProcessing(val){
               
                //this.value.consularProcessing = true;
               // this.value['adjustmentOfI485Status'] =false
               if(this.value['consularProcessing']){
                    this.value.adjustmentOfI485Status = false;
                }
                this.consularProcessingValidator ='';
                if(this.value['adjustmentOfI485Status'] || this.value['consularProcessing']){
                    this.consularProcessingValidator ='adjustmentOfI485Status';
                }
    
            },
            
            updatephoneCountryCode(data){
                this.value.phoneCountryCode = data;
            },
            loadStatesByCountry(model, countryId) {
    
                this.$store.dispatch("getstates", countryId).then((response) => {
                    switch (model) {
                        case "bfeprovinceStates":
                            this.bfeprovinceStates = response;
                        break;
                        case "statesOfMarriage":
                            this.statesOfMarriage = response;  
                        break;
                        case "usastates":
                            this.usastates = response;
                        break;
                       
                    }
    
                });
    
            },
            changeBfProvince(value) {
                this.value.countryOfBirth = this.value.countryOfBirthDetails.id;
                this.bfeprovinceStates = [];
                this.value.provinceOfBirth = null;
                this.value.provinceOfBirthDetails = null;
                this.loadStatesByCountry('bfeprovinceStates', value.id)
            },
            setOutsideAddress() {
    
                if (this.value.currentlyInUS) {
                    this.value.addressOutsideUS = {
                        line1: null,
                        line2: null,
                        aptType: null,
                        locationId: null,
                        locationDetails: null,
                        stateId: null,
                        stateDetails: null,
                        countryId: null,
                        countryDetails: null,
                        zipcode: null
                    };
                } else {
    
                    this.value.addressOutsideUS = null;
                }
    
            },
            addOtherNames() {

                let item = {
                    firstName: "",
                    middleName: "",
                    lastName: ""
                };
              
                this.value["otherNames"].push(item);
            },
            removeOtherName(index) {
                this.value["otherNames"].splice(index, 1);
            },
            resetOtherNames($event) {
               
                this.value["otherNames"] = [];
                this.addOtherNames();
    
            },
            updateData() {
                this.$emit('input', this.value)
            }
        },
        computed:{
            getTplSection(){
    
            if(this.tplsection=='dependentsInfo.spouse'){
              return "dependentsInfo.spouse.priorPeriodOfStayInUS"
            }else{
                return this.tplsection;
    
            }
            },
            getTplSectionPrevious(){
        if(this.tplsection=='dependentsInfo.spouse'){
          return "dependentsInfo.spouse.previousSpouse"
        }else{
            return this.tplsection;
        }
            },
            getTplSectionfather(){
                if(this.tplsection=='dependentsInfo.spouse'){
                return "dependentsInfo.spouse.fatherInfo"
                }else{
                    return this.tplsection;
                }
            },
        }
    };
    </script>
    