<template>
  <div
    class="vx-col w-full"
    :class="wrapclass"
    v-if="canRenderField(tplkey, fieldsArray, display ,tplsection,fieldName)"
  >
    <div class="form_group mt-datepicker-wrap">
      <label class="form_label"
        >{{ label }}<em v-if="checkFieldIsRequired({'key':tplkey,'section':tplsection, 'fieldsArray':fieldsArray, 'required':validationRequired,'notRequired':notRequired  })">*</em></label
      >

      <date-picker
      v-if="validationRequired"
        :editable="true"
        @clear="clearValue()"
        :typeable="true"
        value-type="YYYY-MM-DD"
        format="MM/DD/YYYY"
        :name="'df' + fieldName"
        @change="setModel"
        :data-vv-as="vvas?vvas:label"
        v-model="value"
        v-validate="checkFieldIsRequired({'key':tplkey,'section':tplsection, 'fieldsArray':fieldsArray, 'required':validationRequired ,'notRequired':notRequired  })? 'required|'+datatype : datatype"
        :placeholder="placeHolder"
        :default-value="openDate"
        :disabled-date="checkDisabled"
        :disabled = "isDisabled"
        :open-date="dateOpenFrom"
      >
      </date-picker>
      <date-picker
      v-else
        :editable="true"
        @clear="clearValue()"
        :typeable="true"
        value-type="YYYY-MM-DD"
        format="MM/DD/YYYY"
        :name="'df' + fieldName"
        @change="setModel"
        :data-vv-as="vvas?vvas:label"
        v-model="value"
        :placeholder="placeHolder"
        :default-value="openDate"
        :disabled-date="checkDisabled"
        :disabled = "isDisabled"
        :open-date="dateOpenFrom"
      >
      </date-picker>
      <template v-if="formscope">
         <span  class="text-danger text-sm"  v-if="errors.has(formscope+'.df'+fieldName)" >{{ errors.first(formscope+".df" + fieldName) }} </span>
      </template>
      <template v-else>
         <span  class="text-danger text-sm"  v-if="errors.has('df' + fieldName)" >{{ errors.first( "df" + fieldName) }} </span>
      </template>
      <span
        class="text-danger text-sm"
        style="white-space: nowrap"
        v-show="invalidate"
        >{{ errormessage }}
      </span>
    </div>
  </div>
</template>

<script>
import DatePicker from "vue2-datepicker";
import "vue2-datepicker/index.css";
import moment from "moment";

export default {
  inject: ["parentValidator"],

  props: { 

    dateOpenFrom: null,
    isDisabled:{
      type: Boolean,
      default: false,
    },
    datatype:{
            type:String,
            default:""
        },
    fieldsArray: Array,
    display: {
      type: Boolean,
      default: false,
    },
    notRequired:{
      type: Boolean,
      default: false,
    },
    type: {
      type: String,
      defalt: "date",
    },
    invalidate: {
      type: Boolean,
      default: false,
    },
    errormessage: String,
    validationRequired: {
      type: Boolean,
      default: false,
    },
    wrapclass: {
      type: String,
      default: "md:w-1/2",
    },
    value: String,
    formscope: String,
    label: String,
    vvas: {
      type: String,
      default: "",
    },
    fieldName: String,
    tplsection:{
      type: String,
      default: null,
    },
    tplkey:{
        type: String,
        default: null,
    },
    placeHolder: {
      type: String,
      default: "MM/DD/YYYY",
    },
    dateEnableFrom: null,
    dateEnableTo: null,
    enableDays:null
     
  },
  components: {
    DatePicker,
  },
  data() {
    return {
      datestring: null,
    };
  },
  computed: {
    openDate() {
      if(this.dateOpenFrom){
        return moment(this.dateOpenFrom).format("YYYY-MM-DD");
      }else if (this.dateEnableTo) {
        return moment(this.dateEnableTo).format("YYYY-MM-DD");
      }else if (this.dateEnableFrom) {
        return moment(this.dateEnableFrom).format("YYYY-MM-DD");
      }
      return moment(new Date()).format("YYYY-MM-DD");
    },
  },
  methods: {
    clearValue() {
      this.value = null;
    },
    checkDisabled(val) {
      try {
        if (val && moment(val)) {
          if(this.enableDays &&  this.enableDays.length>0){
            let dayNumber = moment(val).day();
            if(this.enableDays.indexOf(dayNumber)>-1){
              return false;
            }else{
              return true;
             
            }

          }else{
            if (this.dateEnableTo && this.dateEnableFrom) {
              return moment(val) >= moment(this.dateEnableFrom) &&
                moment(val) <= moment(this.dateEnableTo)
                ? false
                : true;
            } else if (this.dateEnableTo) {
              return moment(this.dateEnableTo) <= moment(val);
            } else if (this.dateEnableFrom) {
              return moment(this.dateEnableFrom) >= moment(val);
            }
          }
        }
      } catch (e) {}

      // return true;
    },
    setModel() {
      if (this.value) {
      //  var _t = moment(this.value).startOf("day").format("YYYY-MM-DDTHH:mm:ss");
        var _t = moment(this.value).startOf("day").format("YYYY-MM-DD");
        this.$emit("input", _t);
      } else {
        this.$emit("input", null);
      }
    },
  },
  created() {
    this.$validator = this.parentValidator;
  },
  mounted() {
    setTimeout(() => {
      this.datestring = this.value;
    }, 10);
  },
};
</script>
