<template>
    <div class="text_editor" :class="wrapclass">
        <label v-if="label" class="editor-label">{{ label }} <em v-if="required">*</em></label>
        <quill-editor @keydown.native.enter="handleEnterKey" :name="fieldName + cid" :ref="fieldName" @input="updateData()"
            :data-vv-as="vvas ? vvas : placeHolder" :placeholder="placeHolder" v-validate="checkFieldIsRequired({
                'key': tplkey, 'section': tplsection, 'fieldsArray': fieldsArray,
                'required': required
            }) ? 'required|' + datatype : datatype" v-model="value" :options="editorOptions"></quill-editor>

        <template v-if="formscope">
            <span v-show="errors.has(formscope + '.' + fieldName + cid)" class="error_text">{{
                errors.first(formscope + '.' + fieldName + cid) }}</span>
        </template>
        <template v-else> 
            <span v-if="errors.has(fieldName + cid) && required" class="error_text">{{ errors.first(fieldName + cid) }}</span>
            <span v-else-if="checkValidation && required" class="error_text">*{{ vvas ? vvas : placeHolder }} is required</span>
        </template>
    </div>
</template>
<script>
import { quillEditor } from 'vue-quill-editor';
import 'quill/dist/quill.snow.css';
import 'quill/dist/quill.bubble.css';
import 'quill/dist/quill.core.css';
import Quill from 'quill';

const highlightBackgroundColor = '#fffb8e'; // Yellow background color
// Configure Quill to use <div> instead of <p>
let Block = Quill.import('blots/block');
Block.tagName = 'DIV';
Quill.register(Block, true);

export default {
    inject: ["parentValidator"],
    props: {
        customValidNotRequire:{
            type:Boolean,
            dafault:false
        },
        display: {
            type: Boolean,
            default: false,
        },
        fieldsArray: Array,
        vvas: {
            type: String,
            default: ""
        },
        wrapclass: {
            type: String,
            default: ""
        },
        datatype: {
            type: String,
            default: ""
        },
        cid: {
            type: String,
            default: null,
        },
        formscope: {
            type: String,
            default: null
        },
        value: null,
        label: {
            type: String,
            default: null,
        },
        fieldName: {
            type: String,
            default: 'editor_' + Date.now(),
        },
        tplsection: {
            type: String,
            default: null,
        },
        tplkey: {
            type: String,
            default: null,
        },
        placeHolder: {
            type: String,
            default: null,
        },
        cid: {
            type: String,
            default: null,
        },
        required: {
            type: Boolean,
            default: false,
        }
    },
    components: {
        quillEditor,
    },
    created() {
        this.$validator = this.parentValidator;
    },
    methods: {
        handleEnterKey(event) {

        },
        updateData() {
            this.$emit('input', this.value);
        },
    },
    data: () => ({
        editorOptions: {
            
            modules: {
                toolbar: [
                    ['bold', 'italic', 'underline', 'strike', 'highlight'],
                    [{ 'list': 'ordered' }, { 'list': 'bullet' }],
                    [{ 'color': ['#ffffff','#000000','#e6e6e6','#6699cc','#ffa500','#d9d9d9','#ffd700','#8080ff','#28a428',
                        '#990000','#ff0000','#ffa500','#ffff00','#80ff80','#339966','#6666ff','#66c2ff','#006bb3','#800080'
                    ] }, 
                    { 'background': ['#ffffff',
                    '#ffff00','#4dff4d','#00ffff','#ff00ff','#0000ff','#ff0000','#000099','#008B8B',
                    '#013220','#8B008B','#8B0000','#8B8000',
                       '#808080','#D3D3D3','#000000', 'transparent'] }], // Add color and background options
                   
                ],
            },
            // placeholder: "Type something in here!",
    }
    }),

    mounted() {

    },
    computed:{
        checkValidation(){
            let returnVal = false;
            if (this.value.trim() === '<div><br></div>' && !this.customValidNotRequire) {
                returnVal = true;
            }
            return returnVal
        }
    }
};
</script>

<style>
.ql-editor div {
    line-height: 20px;
}
</style>