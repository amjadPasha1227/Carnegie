<template>
    <div class="vx-col  w-full mb-5 yesno-v2" :class="wrapclass"
        v-if="canRenderField(tplkey, fieldsArray, display, tplsection, fieldName)">
        <div class="form_group">
            <label class="pt-0 form_label">{{ label }}<em v-if="required">*</em>
                <div class="IB_tooltip" :class="{'placement-down':callFromCap}" v-if="helpText"> <span><info-icon size="1.5x" class="custom-class"></info-icon></span>
                <div class="tooltip_cnt">
                    <p>{{ helpText }}</p>
                </div>
            </div>
            </label>
            
            <div class="form_radio_btns" style="margin-top:10px;">
                <vs-button @click="value = true; updateData()" :class="{ 'cactive': value }" class="yes mr-5"
                    color="success" type="border">Yes</vs-button>
                <vs-button @click="value = false; updateData()" :class="{ 'cactive': value == false }" class="no"
                    color="success" type="border">No</vs-button>
            </div>
            <template v-if="required">
                <input type="hidden" :name="fieldName+cid" v-validate="'required'"  data-vv-as="Field"  v-model="value">
                <p v-show="errors.has( formscope + '.'+ fieldName + cid)" class="text-danger text-sm">
                    *Field is required</p>
            </template>
        </div>
</div>
</template>

<script>
import { InfoIcon } from "vue-feather-icons";

export default {
    inject: ["parentValidator"],
    props: {
        tplkey: {
            type: String,
            default: null,
        },
        fieldsArray: Array,
        vvas: {
            type: String,
            default: ""
        },
        wrapclass: {
            type: String,
            default: ""
        },
        datatype: {
            type: String,
            default: ""
        },
        cid: {
            type: String,
            default: null,
        },
        formscope: {
            type: String,
            default: null
        },
        value: null,
        label: {
            type: String,
            default: null,
        },
        fieldName: {
            type: String,
            default: null,
        },
        tplsection: {
            type: String,
            default: null,
        },
        placeHolder: {
            type: String,
            default: null,
        },
        required: {
            type: Boolean,
            default: false,
        },
        display: {
            type: Boolean,
            default: false,
        },
        helpText: {
            type: String,
            default:"",
        },
        callFromCap:{
            type:Boolean,
            default:false
        }
    },
    created() {
        this.$validator = this.parentValidator;
    },

    methods: {
        updateData() {
            this.$emit('input', this.value)
        }
    }, 
    components: {
        InfoIcon,
    },
};
</script>
