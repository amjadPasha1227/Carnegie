<template>
    <div class="vx-col  w-full" >
        <!-- v-if="canRenderField(fieldName,fieldsArray ,true ,tplsection)" -->
        <div class="form-container">
            <div class="vx-row educational_info_bg">
          
                <div class="vx-col w-full educational_info_cnt">
                    <div class="vx-row delete-row emp-bg-info" v-for="(education, index) in value" :key="education.id">
                        <immiInput :notRequired="notRequired" :display="false" :fieldsArray="fieldsArray" :tplsection="tplsection" :tplkey="'name'" :required="true" :cid="'benfcollegename'+index" :formscope="formscope" v-model="education.name" :fieldName="'benfcollegename'+index" label="University/College/School Name" placeHolder="University/College/School Name" />

                        <selectField :notRequired="notRequired" :isDisabled="checkProperty(petition,'beneficiaryInfo','hasMasterDegreeInUS') && checkProperty(education,'highestDegreeDetails') && checkProperty(education,'highestDegreeDetails','id')==6 && false"
                          :display="false" :tplsection="tplsection" :tplkey="'highestDegree'" :fieldsArray="fieldsArray" @input="education.highestDegree = education.highestDegreeDetails.id ;changedEducation(education ,index);removeCountryUs()" :required="education.name!=null && education.name!=''" :optionslist="petition.highestDegreeList" v-model="education.highestDegreeDetails" :formscope="formscope" :fieldName="'highestDegree' + index" label="Qualification" placeHolder="Qualification" />
                        <immiInput :notRequired="notRequired"  :display="false" :tplsection="tplsection" :tplkey="'majorFieldOfStudy'" :fieldsArray="fieldsArray" :cid="'benmajorFieldOfStudy'+ index" :formscope="formscope" v-model="education.majorFieldOfStudy" :required="education.name!=null && education.name!=''" :fieldName="'majorFieldOfStudy'+index" label="Major Field of Study" placeHolder="Major Field of Study" />

                        <template  v-if="checkProperty(petition,'beneficiaryInfo','hasMasterDegreeInUS')&& education['highestDegree'] == 6  && canRenderField('hasMasterDegreeInUS', fieldsArray ,false,'beneficiaryInfo')">
                            <datepickerField :notRequired="notRequired" :display="false" :tplsection="tplsection" :tplkey="'graduatedDate'" wrapclass="md:w-1/2" v-model="education.graduatedDate"  :formscope="formscope" :fieldName="'graduatedDate' + index" label="Date of Graduation" :validationRequired="education.name!=null && education.name!=''" />
                        </template>
                        <template v-if="!(checkProperty(petition,'beneficiaryInfo','hasMasterDegreeInUS') && education['highestDegree'] == 6  && canRenderField('hasMasterDegreeInUS', fieldsArray ,false,'beneficiaryInfo'))">
                            <selectField :notRequired="notRequired" :display="false" :tplsection="tplsection" :tplkey="'graduatedYear'" :listContainsId="false" :fieldsArray="fieldsArray" :cid="'bengraduatedYear'+ index" :required="education.name!=null && education.name!=''" :optionslist="graduatedYears" @input="updatYearofGraduation($event,index)" v-model="education.graduatedYear" :formscope="formscope"  :fieldName="'graduatedYear'+index"  label="Year of Graduation" placeHolder="Year of Graduation"   />  
                            <monthAndYear :notRequired="notRequired" @input="updateEndYear($event,index);clearEnddate($event,index)" :ref="'start_beneficary'+index" :isDisabled="!education.graduatedYear"    :display="false" :tplkey="'attendedFrom'" :fieldsArray="fieldsArray" :required="true"  v-model="education.attendedFrom"  :tplsection="tplsection"  :fieldName="'attendedFrom' + index" cid="passportIssuedCountry" :formscope="formscope"  label="Course Started On" placeHolder="Course Started On" />
                            <monthAndYear :notRequired="notRequired" :ref="'end_beneficary'+index" :isDisabled="!education.graduatedYear || !education.attendedFrom"     :display="false" :tplkey="'attendedTo'" :fieldsArray="fieldsArray" :required="true"  v-model="education.attendedTo"  :tplsection="tplsection"  :fieldName="'attendedTo' + index" cid="passportIssuedCountry" :formscope="formscope"  label="Course Completed On" placeHolder="Course Completed On" />
                        </template>
                        <!--!showGraduatedYear({'indexx':index}) <datepickerField  :display="false" :tplsection="tplsection" :tplkey="'attendedFrom'" :dateEnableTo="education.attendedTo" wrapclass="md:w-1/2" v-model="education.attendedFrom" :formscope="formscope" :fieldName="'attendedFrom' + index" label="Course Started On" :validationRequired="education.name!=null && education.name!=''" />
                        <datepickerField  :display="false" :tplsection="tplsection" :tplkey="'attendedTo'" wrapclass="md:w-1/2" v-model="education.attendedTo" :dateEnableFrom="education.attendedFrom" :formscope="formscope" :fieldName="'attendedTo' + index" label="Course Completed On" :validationRequired="education.name!=null && education.name!=''" /> -->
                        <div class="vx-col w-full"  v-if="canRenderField('address',fieldsArray ,false ,tplsection)">
                            <h3 class="small-header">University/College/School Address</h3>
                                <addressField   :ref="'address_beneficary'+index"
                                :prefiilAddress="checkProperty(petition,'beneficiaryInfo','hasMasterDegreeInUS') && education['highestDegree'] == 6"  
                                :disableCountry="checkProperty(petition,'beneficiaryInfo','hasMasterDegreeInUS') && education['highestDegree'] == 6 && education.address && education.address['countryId']==231" 
                                :display="false" :tplsection="tplsection" :tplkey="'address'" wrapclass="educationaddress" :fieldsArray="fieldsArray" 
                                :formscope="formscope" :showaptType="true" :addFormContainerCls="true" :validationRequired="education.name!=null && education.name!='' && !notRequired"
                                :countries="countries" v-model="education.address" :cid="'benfcollegenameaddress'+index"  />
                        </div>
                        <immiswitchyesno :notRequired="notRequired" v-if="education.address.countryId == 231" :fieldsArray="fieldsArray" :cid="'benisAccredited'+ index" :formscope="formscope" v-model="education.isAccredited" :required="education.name && education.name!=''" :display="false" :tplsection="tplsection" :tplkey="'isAccredited'" :fieldName="'isAccredited'+index" :wrapclass="'w-full'" label="Was the University Accredited at the time of your graduation?" placeHolder="" />
                        <immiswitchyesno :notRequired="notRequired"  v-if=" education.address.countryId == 231" :fieldsArray="fieldsArray" :cid="'benisForProfit'+ index" :formscope="formscope" v-model="education.isForProfit" :required="education.name && education.name!=''" :display="false" :tplsection="tplsection" :tplkey="'isForProfit'" :fieldName="'isForProfit'+index" :wrapclass="'w-full'" label="Is the University a for-profit Organization?" placeHolder="" />
                        <div class="delete" v-if="value.length > 1">
                            <a @click="removeeducation(index)">
                                <img src="@/assets/images/main/delete-row-img-white.svg" />
                            </a>
                        </div>
                        <!-- <div class="divider full-divider mb-10" v-if="value.length > 0 && index < (value.length- 1) "></div> -->
                    </div>
                </div>
            </div>
            <div class="m-auto" vs-type="flex" vs-align="center" vs-lg="2" vs-sm="2">
                <a @click="addeducation" class="add-more ml-0" style="display:inline-block" type="filled">
                    <span>+</span> More
                </a>
            </div>
        </div>
    </div>
</template>

<script>
import _ from "lodash";
import monthAndYear from "@/views/forms/fields/monthAndYear.vue";
import datepickerField from "@/views/forms/fields/datepicker.vue";
import immiInput from "@/views/forms/fields/simpleinput.vue";
import addressField from "@/views/forms/fields/address.vue";
import selectField from "@/views/forms/fields/simpleselect.vue";
import immiswitchyesno from "@/views/forms/fields/switchyesno.vue";
import immitextarea from "@/views/forms/fields/simpletextarea.vue";
import moment from 'moment'

import Vue from "vue";

export default {
    inject: ["parentValidator"],
    props: {
        notRequired:{
            type: Boolean,
            default: false,
        },
        prefillCountryInQuestionnaire:{
            type: Boolean,
            default: true,
        },
        tplsection:{
            type: String,
            default: null,
        },
        fieldsArray: Array,
        formscope: {
            type: String,
            default: ''
        },
        value: Array,
        petition: null,
        // formscope: {
        //     type: String,
        //     default: ''
        // },
        countries: Array
    },
    data() {
        return {
            featureDates:null,
            graduatedYears:[],
            withOutUSACountrieslist:[],
        };
    },
    created() {
        this.$validator = this.parentValidator;
    },
    computed: {
        returnCountries(){
            return (data)=>{
               
                let returnVal = this.countries;
                if(_.has(data['item'],'highestDegree') && data['item']['highestDegree'] == 6 && this.canRenderField('hasMasterDegreeInUS',this.fieldsArray ,false ,'beneficiaryInfo')
                && this.petition.beneficiaryInfo.hasMasterDegreeInUS != true){
                   
                    returnVal = this.withOutUSACountrieslist;
                }
                return returnVal
            }
        },
        showGraduatedYear(){
            return (data)=>{
                let returnVal = false;
                if(this.checkProperty(this.petition,'beneficiaryInfo','hasMasterDegreeInUS') && this.checkProperty(this.petition,'beneficiaryInfo','educations') &&
                this.checkProperty(this.petition['beneficiaryInfo'],'educations','length')>0 && this.checkProperty(data,'indexx') == 0 && this.canRenderField('hasMasterDegreeInUS', this.fieldsArray ,false,'beneficiaryInfo')){
                    returnVal = false;
                }else{
                    returnVal = true;
                }
                return returnVal
            }
        },
        maxYear() {
            return new Date().getFullYear()+10
        },
        minYear(education){

            return moment(education.attendedFrom).year()
        }
    },
    mounted() {
        this.withOutUSACountrieslist = _.filter(this.countries, function (item) {
          return item.id != 231;
        });
        this.getGraduatedYears()
        var $self = this;
        this.featureDates = new Date();

        this.value.forEach(function (item, index) {
            var _a = _.cloneDeep($self.value[index]);
            _a.hideAddress =false;
            let highestDegree = item.highestDegree;
            if (highestDegree != null) {
                var _t = _.find( $self.petition.highestDegreeList, function (item) {
                    return item.id == highestDegree
                })
                _a.highestDegreeDetails = _t
            }
             $self.$set($self.value, index, _a);

        })


    },
    methods: {
        updatYearofGraduation(val,index){ 
            let yearVal = parseInt(val)
            let startRef = 'start_beneficary'+index
            let endRef = 'end_beneficary'+index
            this.$refs[startRef][0].updateCourseYears(val);
            this.$refs[endRef][0].updateCourseYears(val);
            if(this.value && this.value[index]['attendedFrom']){
                let startDate = moment(this.value[index]['attendedFrom'])
                let stDate =  parseInt(startDate.year())
                if(stDate && yearVal && (stDate > yearVal) ){
                    this.value[index]['attendedFrom'] = null
                    this.$refs[startRef][0].clearModels();
                    this.$refs[startRef][0].updateCourseYears(val);
                }
            }
            if(this.value && this.value[index]['attendedTo']){
                let endDate = moment(this.value[index]['attendedTo'])
                let edDate =  parseInt(endDate.year())
                if(edDate && yearVal && (edDate > yearVal) ){
                    this.value[index]['attendedTo'] = null
                    this.$refs[endRef][0].clearModels();
                    this.$refs[endRef][0].updateCourseYears(val);
                }
            }
        },
        updateEndYear(val,index){
            let endRef = 'end_beneficary'+index
            let startDate = moment(val)
            let stDate =  parseInt(startDate.year())
            this.$refs[endRef][0].updateCourseEndYears(this.value[index]['graduatedYear'],stDate);
        },
        clearEnddate(val,index){
            if(this.value[index]['attendedFrom'] && this.value[index]['attendedTo']){
                let endRef = 'end_beneficary'+index
                let startDate = moment(this.value[index]['attendedFrom']);
                let stDate =  parseInt(startDate.year())
                let endDate = moment(this.value[index]['attendedTo']);
                if(startDate.isAfter(endDate , 'day')){
                    this.value[index]['attendedTo'] = null
                    this.$refs[endRef][0].clearModels();
                    this.$refs[endRef][0].updateCourseEndYears(this.value[index]['graduatedYear'],stDate);
                }
            }
        },
        removeCountryUs(){
            let _self = this
            if(this.value &&this.checkProperty(this.value,'length')>0 
            && this.canRenderField('hasMasterDegreeInUS', this.fieldsArray ,false,'beneficiaryInfo') && !this.petition.beneficiaryInfo.hasMasterDegreeInUS){
                _.forEach(this.value,(item,inde)=>{
                    let refe = 'address_beneficary'+inde
                    let refer = String(refe)
                    if(item['highestDegree'] && item['highestDegree'] == 6){
                        _self.$refs[refer][0].removeUSA();
                        if(_self.checkProperty(item,'address','countryId') == 231){
                            item['address']= {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            }
                        }
                    }else{
                        _self.$refs[refer][0].addUSA();
                    }
                })
            }else{
                _.forEach(this.value,(item,inder)=>{
                    let refe = 'address_beneficary'+inder
                    let refer = String(refe)
                    _self.$refs[refer][0].addUSA();
                })
            }
        },
        changedEducation(item ,index){
            _.forEach(this.value ,(education ,ind)=>{
                if(index==ind && this.checkProperty(this.petition,'beneficiaryInfo','hasMasterDegreeInUS')&& this.checkProperty(education ,'highestDegree') == 6){
                   if(this.checkProperty(education ,'address' ,'countryId') !=231){
                       let address= {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: 231,
                                countryDetails: {
                                        _id: "61408c9ed01ea1248cdcf6b7",
                                        id: 231,
                                        name: "United States",
                                        phoneCode: 1,
                                        order: 1,
                                        currencySymbol: "$",
                                        currencyCode: "USD",
                                        zipcodeLength: 5,
                                        sortName: "united states",
                                    },
                                zipcode: null
                            }
                    
                       education.address = _.cloneDeep(address);
                       item.address      = _.cloneDeep(address);
                    }
                       
                }

            });

        },
        getGraduatedYears(){
                let currentYear = parseInt(moment().year());
                let pastYear = currentYear - 100
                for (let i = pastYear; i <= currentYear; i+=1) {
                    this.graduatedYears.push(i)
                }
                this.graduatedYears = this.graduatedYears.reverse()
        },
        addeducation: function () {
            let dt = {
                _id: 0,
                name: null,
                address: {
                    line1: null,
                    line2: null,
                    aptType: null,
                    locationId: null,
                    locationDetails: null,
                    stateId: null,
                    stateDetails: null,
                    countryId: 231,
                    countryDetails: {
                            _id: "61408c9ed01ea1248cdcf6b7",
                            id: 231,
                            name: "United States",
                            phoneCode: 1,
                            order: 1,
                            currencySymbol: "$",
                            currencyCode: "USD",
                            zipcodeLength: 5,
                            sortName: "united states",
                        },
                    zipcode: null
                },
                highestDegree: null,
                highestDegreeDetails: null,
                majorFieldOfStudy: null,
                attendedFrom: null,
                attendedTo: null,
                graduatedYear: null,
                degreereceived: null,
                isAccredited: null,
                isForProfit: null,
                graduatedDate:null
            }
            this.value.push(dt);
        },
        removeeducation: function (index) {
            Vue.delete(this.value, index);
        }
    },
    components: {
        monthAndYear,
        immitextarea,
        datepickerField,
        immiInput,
        selectField,
        addressField,
        immiswitchyesno
    }
};
</script>
