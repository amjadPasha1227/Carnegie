<template>
    <div class="vx-col  w-full mb-6" :class="wrapclass" >
    
        <div class="form-container form-container-v2">
            <div class="vx-row">
                <div class="vx-col w-full mb-5 mt-0">
                    <h3 class="small-header mt-0">Dates of Stay in USA</h3>
    
                    <p class="mb-0 subtitle">All prior periods of stay in the U.S. over the last seven years
                    </p>
    
                </div>
                <span v-if="hasDateError" class="text-danger text-sm date-range-error">Please enter valid dates</span>
    
                <div class="vx-col w-full prior-stay-list periods-nowrap">
                    <div class="vx-row delete-row" :class="{'invaliddates':priorstay.dateerror}" v-for="(priorstay, index) in value" :key="priorstay.id">
                        <selectField :notRequired="notRequired" :display="false" :tplkey="'visaStatus'" :tplsection="tplsection" v-if="petition.visaStatusList" :wrapclass="!noday?'':''" @input="priorstay.visaStatus = priorstay.visaStatusDetails?priorstay.visaStatusDetails.id:'';validateDate()" :required="priorstay.enteredDate!=null || priorstay.departedDate!=null" :optionslist="petition.visaStatusList" v-model="priorstay.visaStatusDetails" :formscope="formscope" :fieldName="'visaStatusDetails' + index" label="Visa Status" vvas="Visa Status" placeHolder="Visa Status" />
                        <datepickerField :notRequired="notRequired" :display="false" :tplkey="'enteredDate'" :tplsection="tplsection" :invalidate="priorstay.dateerror" errormessage="Conflict with other dates, Please enter valid stay dates" @input="validateDate(priorstay);clearDependentField(priorstay,index)" :wrapclass="!noday?'':''" :isDisabled="!priorstay.visaStatus"  v-model="priorstay.enteredDate" :required="priorstay.visaStatusDetails!=null" :dateEnableTo="featureDates"  :formscope="formscope"  :fieldName="'enterDate' + index" label="Date Entered" :validationRequired="priorstay.visaStatusDetails!=null" />
                        <datepickerField :notRequired="notRequired" :display="false" :tplkey="'departedDate'" :tplsection="tplsection"  @input="validateDate()" :wrapclass="!noday?'':''" v-model="priorstay.departedDate" :dateEnableTo="featureDates" :dateEnableFrom="priorstay.enteredDate" :formscope="formscope" :isDisabled="!priorstay.enteredDate" :required="false" :fieldName="'departDate' + index" label="Date Departed" :validationRequired="false"/>
                       
                       <template v-if="checkProperty(petition ,'typeDetails' ,'id') !=3 && priorstay.noOfDays>0">
                        <immiInput :notRequired="notRequired" :display="false" :tplkey="'noOfDays'" :tplsection="tplsection" v-if="noday" :disabled="true" wrapclass="" :cid="'priorstaydays'+index" :formscope="formscope" v-model="priorstay.noOfDays" :fieldName="'priorstaydays'+index" label="No. of Days" placeHolder="No. of Days" />
                        </template>
                        <!-- :dateEnableFrom="checkEnableDate" -->
    
                        <div class="delete" v-if="value.length > 1" @click="removepriorstay(index)">
                            <a>
                                <img src="@/assets/images/main/delete-row-img.svg" />
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    
        <div class="m-auto" vs-type="flex" vs-align="center" vs-lg="2" vs-sm="2">
            <a @click="addpriorstay" class="add-more ml-0 mt-0" style="display:inline-block" type="filled">
                <span>+</span> More
            </a>
            <template v-if="checkProperty(petition ,'typeDetails' ,'id') !=3">
    
            <div v-if="gettotalDays > 0" style="float:right" class="form_label"><strong>Total number of days of Stay on L1 and H-1B</strong> - {{gettotalDays}}</div>
            </template>
      </div>
    </div>
    </template>
    
    <script>
    import datepickerField from "@/views/forms/fields/datepicker.vue";
    import selectField from "@/views/forms/fields/simpleselect.vue";
    import immiInput from "@/views/forms/fields/simpleinput.vue";
    
    import Vue from "vue";
    import moment from 'moment'
    
    import _ from "lodash";
    export default {
        inject: ["parentValidator"],
    
        props: {
            notRequired:{
                type: Boolean,
                default: false,
            },
            fieldsArray: Array,
            value: Array,
            petition: Object,
            wrapclass:{
            type:String,
                default:""
            },
            noday: {
                type: Boolean,
                default: true,
            },
            formscope: {
                type: String,
                default: ''
            },
            cid: {
                type: String,
                default: "",
            },
            fieldName: {
                type: String,
                default: null,
            },
            tplsection:{
                type: String,
                default: null,
            },
            placeHolder: {
                type: String,
                default: null,
            },
            required: {
                type: Boolean,
                default: false,
            },
            display: {
                type: Boolean,
                default: false,
            }
        },
        data() {
            return {
                featureDates: null,
                dateerror: false,
                nodays: 0,
                startBeneficiaryDateEntered: new Date().setFullYear(new Date().getFullYear() - 7),
            };
        },
        created() {
            this.$validator = this.parentValidator;
        },
        computed: {
            checkEnableDate(){
                let startDate = moment()
                let updatedDate = startDate.subtract(7, "years");
                return updatedDate
            },
            hasDateError() {
                if(this.value && this.checkProperty(this.value, 'length')>0){
                    this.value.forEach(function (item, index) {
                    if (item.dateerror) {
                        return true;
                    }
                    })
                    return false;
                }
               
            },
            gettotalDays() {
                if(this.value && this.checkProperty(this.value, 'length')>0){
                    var totaldays = 0;
                    this.value.forEach(function (item, index) {
                        if (item.noOfDays && item.noOfDays > 0) {
                            totaldays = totaldays + item.noOfDays;
    
                        }
                    })
                    return totaldays;
                }
            }
    
        },
        watch: {
    
        },
        mounted() {
    
            this.featureDates = new Date();
            var $self = this;
            this.value.forEach(function (item, index) {
    
                $self.value[index].visaStatusDetails = _.find($self.petition.visaStatusList, function (aitem) {
    
                    return aitem.id == item.visaStatus
                })
    
            })
    
        },
        methods: {
            clearDependentField(obj,index){
                if(obj && this.value && this.value.length>0){  
                    if(!this.value[index]['enteredDate']){
                        this.value[index].departedDate = null;
                    }
                    if(this.value[index]['enteredDate']){
                        let startDate = moment(this.value[index]['enteredDate']);
                        let endDate = moment(this.value[index]['departedDate']);
                        if(startDate.isAfter(endDate , 'day')){
                            this.value[index]['departedDate']=null;
                        }
                    }
                   
                }
            },
    
            validateDate() {
                var $self = this;
                var totaldays = 0;
                this.value.forEach(function (item, index) {
                    var rt = false;
                    $self.value.forEach(function (sitem, iindex) {
                        if (index != iindex) {
                            if (moment(item.enteredDate).isSame(moment(sitem.enteredDate))) rt = true;
                            if (moment(item.enteredDate).isSame(moment(sitem.departedDate))) rt = true;
                            if (moment(item.enteredDate).isBetween(moment(sitem.enteredDate), moment(sitem.departedDate))) rt = true;
                            if (moment(item.departedDate).isSame(moment(sitem.enteredDate))) rt = true;
                            if (moment(item.departedDate).isSame(moment(sitem.departedDate))) rt = true;
                            if (moment(item.departedDate).isBetween(moment(sitem.enteredDate), moment(sitem.departedDate))) rt = true;
                        }
                    })
    
                    var edate = item.enteredDate;
                    var ddate = item.departedDate;
                     $self.value[index].noOfDays = null;
                    if (ddate && edate) {
                        var a = moment(ddate);
                        var b = moment(edate);
                       
                        let visaStatusId = $self.checkProperty(item ,'visaStatusDetails' ,'id' )
                        if ([5, 9, 10, 11, 12].indexOf(visaStatusId) > -1 || [3].indexOf($self.checkProperty($self.petition ,'typeDetails' ,'id'))>-1 ) {
                            var td = a.diff(b, 'days') + 1;
                            if (td > 0) {
                                totaldays = totaldays + td;
                                $self.value[index].noOfDays = td;
                            }
    
                        }
                    }
    
                    $self.value[index].dateerror = rt
    
                })
    
            },
            // validateDate() {
            //     var $self = this;
            //     var totaldays = 0;
            //     this.value.forEach(function (item, index) {
            //         var rt = false;
            //         $self.value.forEach(function (sitem, iindex) {
            //             if (index != iindex) {
            //                 if (moment(item.enteredDate).isSame(moment(sitem.enteredDate))) rt = true;
            //                 if (moment(item.enteredDate).isSame(moment(sitem.departedDate))) rt = true;
            //                 if (moment(item.enteredDate).isBetween(moment(sitem.enteredDate), moment(sitem.departedDate))) rt = true;
            //                 if (moment(item.departedDate).isSame(moment(sitem.enteredDate))) rt = true;
            //                 if (moment(item.departedDate).isSame(moment(sitem.departedDate))) rt = true;
            //                 if (moment(item.departedDate).isBetween(moment(sitem.enteredDate), moment(sitem.departedDate))) rt = true;
            //             }
            //         })
    
            //         var edate = item.enteredDate;
            //         var ddate = item.departedDate;
            //          $self.value[index].noOfDays = null;
            //         if (ddate && edate) {
            //             var a = moment(ddate);
            //             var b = moment(edate);
                       
            //             let visaStatusId = $self.checkProperty(item ,'visaStatusDetails' ,'id' )
            //             if ([5, 9, 10, 11, 12].indexOf(visaStatusId) > -1 || [3].indexOf($self.checkProperty($self.petition ,'typeDetails' ,'id'))>-1 ) {
            //                 var td = a.diff(b, 'days') + 1;
            //                 if (td > 0) {
            //                     totaldays = totaldays + td;
            //                     $self.value[index].noOfDays = td;
            //                 }
    
            //             }
            //         }
    
            //         $self.value[index].dateerror = rt
    
            //     })
    
            // },
            addpriorstay: function () {
                this.value.push({
                    enteredDate: null,
                    departedDate: null,
                    visaStatusDetails: null,
                    visaStatus: null,
                });
            },
            removepriorstay: function (index) {
                Vue.delete(this.value, index);
            }
        },
    
        components: {
            datepickerField,
            selectField,
            immiInput
        }
    };
    </script>
    