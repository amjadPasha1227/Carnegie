<template>
    <div class="vx-col  w-full mb-10"  >
    
        <div class="form-container ">
            <div class="vx-row">
                
                <template >
                    <div class="vx-col w-full mt-2 mb-5">
                        <h3 class="small-header" style="margin-top:0px;margin-bottom:0px;">Immigrant Petitions Information</h3>
                        <p class="mb-0">List all the petitions filed till date on your behalf</p>
                    </div>
                
                    <div class="vx-col w-full prior-stay-list immigration_prior_list">
                        <div class="vx-row delete-row" v-for="(item, index) in value" :key="item.id">
                        
                            <!-- <selectField :tplsection="tplsection" :tplkey="'visaStatus'" :dispaly="false" :required="false" v-if="petition.visaStatusList" wrapclass="md:w-1/3" @input="item.visaStatus = item.visaStatusDetails?item.visaStatusDetails.id:''"   :optionslist="petition.visaStatusList" v-model="item.visaStatusDetails" :formscope="formscope" :fieldName="'visaStatusDetailsStatusDetails' + index + index" label="Visa Status" vvas="Visa Status" placeHolder="Visa Status" /> -->
                            <selectField :notRequired="notRequired" :display="false" :tplkey="'visaStatus'" :tplsection="tplsection"  wrapclass="md:w-1/3" @input="item.typeId = item.typeDetails?item.typeDetails.id:''" :required="true" :optionslist="petitionType" v-model="item.typeDetails" :formscope="formscope" :fieldName="'typeDetails' + index+ index" label="Petition Type" vvas="Petition Type" placeHolder="Petition Type" />
                            <immiInput :notRequired="notRequired" :tplsection="tplsection" :tplkey="'receiptNo'" :dispaly="false" wrapclass="md:w-1/3" datatype="max:20"  :cid="'receiptNo'+index" :formscope="formscope" v-model="item.receiptNo" :required="item.visaStatus!=null" :fieldName="'receiptNo'+index+ index" label="Receipt Number" placeHolder="Receipt Number" />
                            <immiInput :notRequired="notRequired"  :tplsection="tplsection" :tplkey="'petitionerName'" :dispaly="false"  wrapclass="md:w-1/3" :cid="'petitionerName'+index" :formscope="formscope" v-model="item.petitionerName" :required="item.visaStatus!=null"  :fieldName="'petitionerName'+index+ index" label="Petitioner/Employer Name" placeHolder="Petitioner/Employer Name" />
                            <datepickerField :notRequired="notRequired" :display="false" :tplkey="'validFrom'" wrapclass="md:w-1/3" :tplsection="tplsection"  @input="clearDependentField()" v-model="item.validFrom" :required="true" :dateEnableTo="new Date()"  :formscope="formscope"  :fieldName="'validFrom' + index+ index" label="Valid From" :validationRequired="item.visaStatus!=null" />
                            <datepickerField :notRequired="notRequired" :display="false" :tplkey="'validTo'" wrapclass="md:w-1/3" :tplsection="tplsection"   v-model="item.validTo" :dateEnableFrom="item.validFrom" :formscope="formscope" :isDisabled="!item.validFrom" :required="false" :fieldName="'validTo' + index+ index" label="Valid To" :validationRequired="false"/>
                        
                        
    
                            <div class="delete" v-if="value.length > 1" @click="removeitem(index)">
                                <a >
                                    <img src="@/assets/images/main/delete-row-img.svg" />
                                </a>
                            </div>
                        </div>
                    </div>
                </template>
            </div>
        </div>
        <template v-if="(canRenderField('h1bImmPetitionsInfo',fieldsArray,false ,'beneficiaryInfo') && canRenderField('anyImmPetitionFiled',fieldsArray,false ,'beneficiaryInfo') && petition.beneficiaryInfo && petition.beneficiaryInfo.anyImmPetitionFiled) || (!canRenderField('anyImmPetitionFiled',fieldsArray,false ,'beneficiaryInfo') && canRenderField('h1bImmPetitionsInfo',questionnaireDetails,false ,'beneficiaryInfo')) ">
            <div class="m-auto" vs-type="flex" vs-align="center" vs-lg="2" vs-sm="2">
                <a @click="additem()" class="add-more ml-0 mt-4" style="display:inline-block" type="filled">
                    <span>+</span> More
                </a>
    
            </div>
        </template>
    
    </div>
    </template>
    
    <script>
    import datepickerField from "@/views/forms/fields/datepicker.vue";
    import selectField from "@/views/forms/fields/simpleselect.vue";
    import immiInput from "@/views/forms/fields/simpleinput.vue";
    import immiswitchyesno from "@/views/forms/fields/switchyesno.vue";
    import Vue from "vue";
    import moment from 'moment'
    
    import _ from "lodash";
    export default {
        inject: ["parentValidator"],
    
        props: {
            notRequired:{
                type: Boolean,
                default: false,
            },
            tplsection:{
                type: String,
                default: null,
            },
             fieldsArray:Array,
            value: Array,
            petition: Object,
            formscope: {
                type: String,
                default: ''
            },
            cid: {
                type: String,
                default: "",
            }, fieldName: {
                type: String,
                default: null,
            },
            placeHolder: {
                type: String,
                default: null,
            },
            required: {
                type: Boolean,
                default: false,
            }
        },
        data() {
            return {
                petitionType:[{id:1,'name':'PERM'},{id:2,'name':'I-140'},{id:3,'name':'I-485'}],
                featureDates:null,
                dateerror: false,
                nodays: 0,
                startBeneficiaryDateEntered: new Date().setFullYear(new Date().getFullYear() - 7),
            };
        },
        created() {
            this.$validator = this.parentValidator;
        },
        computed: {
            gettotalDays() {
                var totaldays = 0;
                this.value.forEach(function (item, index) {
                    var edate = item.enteredDate;
                    var ddate = item.departedDate;
                    if (ddate && edate) {
                        var a = moment(ddate);
                        var b = moment(edate);
                        totaldays = totaldays + a.diff(b, 'days') + 1
                    }
    
                })
                return totaldays;
            }
    
        },
        watch: {
    
        },
        mounted() {
    
            this.featureDates =  new Date();
            var $self = this;
             this.value.forEach(function (item, index) {
    
                   $self.value[index].visaStatusDetails = _.find($self.petition.visaStatusList, function (aitem) {
    
                        return aitem.id == item.visaStatus
                    })
    
    
             })
    
    
           
        },
        methods: {
            clearDependentField(){
                if(this.value && this.value.length>0){
                    if(this.checkProperty(this.petition,'beneficiaryInfo','nonImmPetitionsInfo')){
                        _.forEach(this.value,(item)=>{
                        if(item['validFrom']==null){
                                item.validTo = null;
                        }
                        if(item.validFrom > item.validTo){
                                  item.validTo=null;
                        }
                        })
                    }
                }
            },
            addPetitionerName(val){
                if(val && this.value && this.value.length>0 ){
                    if(this.checkProperty(this.petition,'petitionerDetails','name')){
                        _.forEach(this.value,(item)=>{
                            item['petitionerName'] = this.checkProperty(this.petition,'petitionerDetails','name')
                        })
                    }
                }
            },
            addMorePetitionerName(){
                if( this.petition.beneficiaryInfo && this.petition.beneficiaryInfo.didThisPtnrFliedImmPetitionEarlier && this.value && this.value.length>0 ){
                    if(this.checkProperty(this.petition,'petitionerDetails','name')){
                        _.forEach(this.value,(item)=>{
                            item['petitionerName'] = this.checkProperty(this.petition,'petitionerDetails','name')
                        })
                    }
                }
            },
            validateDate() {
                var $self = this;
                 var totaldays = 0;
              this.value.forEach(function (item, index) {
                 var rt = false;
                $self.value.forEach(function (sitem, iindex) {
                    if (index != iindex) {
                        if (moment(item.enteredDate).isSame(moment(sitem.enteredDate))) rt = true;
                        if (moment(item.enteredDate).isSame(moment(sitem.departedDate))) rt = true;
                        if (moment(item.enteredDate).isBetween(moment(sitem.enteredDate), moment(sitem.departedDate))) rt = true;
                        if (moment(item.departedDate).isSame(moment(sitem.enteredDate))) rt = true;
                        if (moment(item.departedDate).isSame(moment(sitem.departedDate))) rt = true;
                        if (moment(item.departedDate).isBetween(moment(sitem.enteredDate), moment(sitem.departedDate))) rt = true;
                    }
                })
                
                  var edate = item.enteredDate;
                    var ddate = item.departedDate;
                    if (ddate && edate) {
                        var a = moment(ddate);
                        var b = moment(edate);
                        totaldays = totaldays + a.diff(b, 'days') + 1
                    }
    
               $self.value[index].dateerror = rt
    
            })
            this.gettotalDays();
    
            },
            additem: function () {
                this.value.push({
                    enteredDate: null,
                    departedDate: null,
                    typeDetails: null,
                    typeId: null,
                    petitionerName:null,
                    receiptNo:null,
                    validFrom:null,
                    validTo:null
                });
            },
            removeitem: function (index) {
                Vue.delete(this.value, index);
            },
            changedfirstExtnWithPtnr(val){
                if(val){
                    if(this.petition.beneficiaryInfo.secOrSubSequentExtnWithPtnr){
                        this.petition.beneficiaryInfo.secOrSubSequentExtnWithPtnr = false;
                    }
                }
            },
            changeSecOrSubSequentExtnWithPtnr(val){   
                if(val){
                    if(this.petition.beneficiaryInfo.firstExtnWithPtnr){
                        this.petition.beneficiaryInfo.firstExtnWithPtnr = false;
                    }
                }
            },
        },
    
        components: {
            datepickerField,
            selectField,
            immiInput,
            immiswitchyesno
        }
    };
    </script>
    