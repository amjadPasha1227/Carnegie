<template>
  <form data-vv-scope="documentsInfoform" @submit.prevent>

    <vs-col class="w-full p-0" v-if="!callFromEdit">


      <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal"
        icon="IP-information-button" active="true">
        <p>Documents Needed</p>
        <ul class="uploaded-list">
          <li
            v-if="checkFieldIsRequired({ 'key': 'passport', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">
            <label> {{ "passport" | formatdoctype }} </label>
          </li>
          <li
            v-if="checkFieldIsRequired({ 'key': 'passportVisaI94', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">
            <label> {{ "passportVisaI94" | formatdoctype }} </label>
          </li>
          <li
            v-if="checkFieldIsRequired({ 'key': 'birthCertificate', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">
            <label>{{ "birthCertificate" | formatdoctype }}</label>
          </li>
          <!-- <li v-if="checkFieldIsRequired({'key':'beneficiaryDocs','section':'documents', 'fieldsArray':fieldsArray, 'required':false })">
                      <label>{{ "beneficiaryDocs" | formatdoctype }}</label>
                    </li> -->
          <li
            v-if="checkFieldIsRequired({ 'key': 'formI20', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">
            <label>{{ "formI20" | formatdoctype }}</label>
          </li>
          <li
            v-if="checkFieldIsRequired({ 'key': 'priorFormI797', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">
            <label>{{ "priorFormI797" | formatdoctype }}</label>
          </li>

          <li
            v-if="checkFieldIsRequired({ 'key': 'education', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">
            <label>{{ "education" | formatdoctype }} </label>
          </li>

          <li
            v-if="checkFieldIsRequired({ 'key': 'formI94', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">
            <label>{{ "formI94" | formatdoctype }}</label>
          </li>

          <li
            v-if="checkFieldIsRequired({ 'key': 'resume', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">
            <label>{{ "resume" | formatdoctype }}</label>
          </li>

          <li
            v-if="checkFieldIsRequired({ 'key': 'expLetters', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">
            <label>{{ "expLetters" | formatdoctype }}</label>
          </li>

          <li
            v-if="checkFieldIsRequired({ 'key': 'offerLetter', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">
            <label>{{ "offerLetter" | formatdoctype }} </label>
          </li>

          <li
            v-if="checkFieldIsRequired({ 'key': 'employmentAgreement', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">
            <label>{{ "employmentAgreement" | formatdoctype }}</label>
          </li>

          <li
            v-if="checkFieldIsRequired({ 'key': 'INSNotices', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">
            <label>{{ "INSNotices" | formatdoctype }}</label>
          </li>
          <!-- docs_ssc_licence -->
          <li
            v-if="checkFieldIsRequired({ 'key': 'socialSecurityCardAndProfLicense', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">
            <label>Social security card and state professional
              license</label>
          </li>
          <!-- docs_ead -->
          <li
            v-if="checkFieldIsRequired({ 'key': 'ead', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">
            <label>EADs (if on OPT or STEM OPT Extension)</label>
          </li>
          <!-- docs_paystubs -->
          <li
            v-if="checkFieldIsRequired({ 'key': 'payStubs', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">
            <label>Three Recent Pay Stubs </label>
          </li>

          <li
            v-if="checkFieldIsRequired({ 'key': 'I797NoticeofApprovalforI140', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">
            <label>{{ "I797NoticeofApprovalforI140" | formatdoctype }} </label>
          </li>

          <li
            v-if="checkFieldIsRequired({ 'key': 'clientLetter', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">
            <label>{{ "clientLetter" | formatdoctype }}</label>
          </li>

          <li
            v-if="checkFieldIsRequired({ 'key': 'vendorLetter', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">
            <label>{{ "vendorLetter" | formatdoctype }}</label>
          </li>

          <li
            v-if="checkFieldIsRequired({ 'key': 'msa', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">
            <label>{{ "msa" | formatdoctype }}</label>
          </li>

          <li
            v-if="checkFieldIsRequired({ 'key': 'h1bRegSelectionNotice', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">
            <label>{{
              "h1bRegSelectionNotice" | formatdoctype
            }}</label>
          </li>

          <li
            v-if="checkFieldIsRequired({ 'key': 'primeVendor', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">
            <label>{{ "primeVendor" | formatdoctype }}</label>
          </li>
          <!-- docs_other -->
          <li
            v-if="checkFieldIsRequired({ 'key': 'other', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">
            <label>Other documents, if any</label>
          </li>
          <!-- docs_po -->
          <li
            v-if="checkFieldIsRequired({ 'key': 'po', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">
            <label>PO</label>
          </li>
        </ul>
      </vs-alert>
    </vs-col>

    <vs-col class="m-auto float-none pt-12" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
      <div class="form-container w-full" @click="formerrors.msg = ''">
        <div class="vx-row documents_group case_documents">
          <h3 class="small-header">
            List of documents needs to be updated
            <span class="file-type">
              (File Type: PDF, DOC, JPEG, PNG. Max file size: 1MB)
            </span>
          </h3>
          <template v-if="[2, 10].indexOf(checkProperty(petitionDetails, 'typeDetails', 'id')) > -1">
            <!---H4 Documents
             priorH4Approvals: [],
         // passport:[],
          usVisa: [],
          mostRecentI94: [],
          ssnCard: [],
          eadCard: [],
          // marriageCertificate:[],
          
          // other:[],
          //h4 documents
            -->
            <div class="vx-col w-full"  v-if="canRenderField('priorH4Approvals', fieldsArray, false, 'documents', 'priorH4Approvals')">
              <label class="custom-label">
                {{ "priorH4Approvals" | formatdoctype }} <em
                  v-if="checkFieldIsRequired({ 'key': 'priorH4Approvals', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
              </label>

              <!--docs_birthCertificate-->
              <file-upload v-model="documents.priorH4Approvals" class="file-upload-input" name="priorH4Approvals_docs"
                data-vv-as="priorH4Approvals" :accept="allDocEntity" :multiple="true" :hideSelected="true"
                @input="upload(documents.priorH4Approvals, 'priorH4Approvals')">
                <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                Upload
                <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'priorH4Approvals')"><img
                    src="@/assets/images/main/loader.gif"></span>
              </file-upload>


              <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.priorH4Approvals_docs')">{{
                errors.first("documentsInfoform.priorH4Approvals_docs")
              }}</span>
              <ul class="uploaded-list">
                <template v-for="(item, index) in documents.priorH4Approvals"
                  v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">

                  <template v-if="callFromEdit">
                    <vs-chip @click="remove(item, documents.priorH4Approvals, index)" :key="index"
                      :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                      <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                      {{ item.name }} </vs-chip>
                  </template>
                  <template v-else>
                    <vs-chip @click="remove(item, documents.priorH4Approvals, index)" :key="index" closable
                      v-if="item.status !== false && item['path']">
                      <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />

                      {{ item.name }} </vs-chip>
                  </template>
                </template>
              </ul>
            </div>
            <div class="vx-col w-full" v-if="canRenderField('passport', fieldsArray, false, 'documents', 'passport')">
              <label class="custom-label">
                {{ "passport" | formatdoctype }} <em
                  v-if="checkFieldIsRequired({ 'key': 'passport', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
              </label>

              <!--docs_birthCertificate-->
              <file-upload v-model="documents.passport" class="file-upload-input" name="passport_docs" data-vv-as="passport"
                :accept="allDocEntity" :multiple="true" :hideSelected="true" @input="upload(documents.passport, 'passport')">
                <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                Upload
                <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'passport')"><img
                    src="@/assets/images/main/loader.gif"></span>
              </file-upload>


              <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.passport_docs')">{{
                errors.first("documentsInfoform.passport_docs")
              }}</span>
              <ul class="uploaded-list">
                <template v-for="(item, index) in documents.passport"
                  v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">

                  <template v-if="callFromEdit">
                    <vs-chip @click="remove(item, documents.passport, index)" :key="index"
                      :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                      <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                      {{ item.name }} </vs-chip>
                  </template>
                  <template v-else>
                    <vs-chip @click="remove(item, documents.passport, index)" :key="index" closable
                      v-if="item.status !== false && item['path']">
                      <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />

                      {{ item.name }} </vs-chip>
                  </template>
                </template>
              </ul>
            </div>
            <div class="vx-col w-full" v-if="canRenderField('usVisa', fieldsArray, false, 'documents', 'usVisa')">
              <label class="custom-label">
                {{ "usVisa" | formatdoctype }} <em
                  v-if="checkFieldIsRequired({ 'key': 'usVisa', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
              </label>

              <!--docs_birthCertificate-->
              <file-upload v-model="documents.usVisa" class="file-upload-input" name="usVisa_docs" data-vv-as="usVisa"
                :accept="allDocEntity" :multiple="true" :hideSelected="true" @input="upload(documents.usVisa, 'usVisa')">
                <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                Upload
                <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'usVisa')"><img
                    src="@/assets/images/main/loader.gif"></span>
              </file-upload>


              <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.usVisa_docs')">{{
                errors.first("documentsInfoform.usVisa_docs")
              }}</span>
              <ul class="uploaded-list">
                <template v-for="(item, index) in documents.usVisa"
                  v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">

                  <template v-if="callFromEdit">
                    <vs-chip @click="remove(item, documents.usVisa, index)" :key="index"
                      :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                      <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                      {{ item.name }} </vs-chip>
                  </template>
                  <template v-else>
                    <vs-chip @click="remove(item, documents.usVisa, index)" :key="index" closable
                      v-if="item.status !== false && item['path']">
                      <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />

                      {{ item.name }} </vs-chip>
                  </template>
                </template>
              </ul>
            </div>
            <div class="vx-col w-full" v-if="canRenderField('mostRecentI94', fieldsArray, false, 'documents', 'mostRecentI94')">
              <label class="custom-label">
                {{ "mostRecentI94" | formatdoctype }} <em
                  v-if="checkFieldIsRequired({ 'key': 'mostRecentI94', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
              </label>

              <!--docs_birthCertificate-->
              <file-upload v-model="documents.mostRecentI94" class="file-upload-input" name="mostRecentI94_docs"
                data-vv-as="mostRecentI94" :accept="allDocEntity" :multiple="true" :hideSelected="true"
                @input="upload(documents.mostRecentI94, 'mostRecentI94')">
                <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                Upload
                <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'mostRecentI94')"><img
                    src="@/assets/images/main/loader.gif"></span>
              </file-upload>


              <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.mostRecentI94_docs')">{{
                errors.first("documentsInfoform.mostRecentI94_docs")
              }}</span>
              <ul class="uploaded-list">
                <template v-for="(item, index) in documents.mostRecentI94"
                  v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">

                  <template v-if="callFromEdit">
                    <vs-chip @click="remove(item, documents.mostRecentI94, index)" :key="index"
                      :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                      <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                      {{ item.name }} </vs-chip>
                  </template>
                  <template v-else>
                    <vs-chip @click="remove(item, documents.mostRecentI94, index)" :key="index" closable
                      v-if="item.status !== false && item['path']">
                      <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />

                      {{ item.name }} </vs-chip>
                  </template>
                </template>
              </ul>
            </div>
            <div class="vx-col w-full" v-if="canRenderField('ssnCard', fieldsArray, false, 'documents', 'ssnCard')">
              <label class="custom-label">
                {{ "ssnCard" | formatdoctype }} <em
                  v-if="checkFieldIsRequired({ 'key': 'ssnCard', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
              </label>

              <!--docs_birthCertificate-->
              <file-upload v-model="documents.ssnCard" class="file-upload-input" name="ssnCard_docs" data-vv-as="ssnCard"
                :accept="allDocEntity" :multiple="true" :hideSelected="true"
                @input="upload(documents.ssnCard, 'ssnCard')">
                <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                Upload
                <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'ssnCard')"><img
                    src="@/assets/images/main/loader.gif"></span>
              </file-upload>


              <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.ssnCard_docs')">{{
                errors.first("documentsInfoform.ssnCard_docs")
              }}</span>
              <ul class="uploaded-list">
                <template v-for="(item, index) in documents.ssnCard"
                  v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">

                  <template v-if="callFromEdit">
                    <vs-chip @click="remove(item, documents.ssnCard, index)" :key="index"
                      :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                      <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                      {{ item.name }} </vs-chip>
                  </template>
                  <template v-else>
                    <vs-chip @click="remove(item, documents.ssnCard, index)" :key="index" closable
                      v-if="item.status !== false && item['path']">
                      <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />

                      {{ item.name }} </vs-chip>
                  </template>
                </template>
              </ul>
            </div>
            <div class="vx-col w-full" v-if="canRenderField('eadCard', fieldsArray, false, 'documents', 'eadCard')">
              <label class="custom-label">
                {{ "eadCard" | formatdoctype }} <em
                  v-if="checkFieldIsRequired({ 'key': 'eadCard', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
              </label>

              <!--docs_birthCertificate-->
              <file-upload v-model="documents.eadCard" class="file-upload-input" name="eadCard_docs" data-vv-as="eadCard"
                :accept="allDocEntity" :multiple="true" :hideSelected="true"
                @input="upload(documents.eadCard, 'eadCard')">
                <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                Upload
                <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'eadCard')"><img
                    src="@/assets/images/main/loader.gif"></span>
              </file-upload>


              <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.eadCard_docs')">{{
                errors.first("documentsInfoform.eadCard_docs")
              }}</span>
              <ul class="uploaded-list">
                <template v-for="(item, index) in documents.eadCard"
                  v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">

                  <template v-if="callFromEdit">
                    <vs-chip @click="remove(item, documents.eadCard, index)" :key="index"
                      :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                      <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                      {{ item.name }} </vs-chip>
                  </template>
                  <template v-else>
                    <vs-chip @click="remove(item, documents.eadCard, index)" :key="index" closable
                      v-if="item.status !== false && item['path']">
                      <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />

                      {{ item.name }} </vs-chip>
                  </template>
                </template>
              </ul>
            </div>
            <div class="vx-col w-full" v-if="canRenderField('marriageCertificate', fieldsArray, false, 'documents', 'marriageCertificate')">
              <label class="custom-label">
                {{ "marriageCertificate" | formatdoctype }} <em
                  v-if="checkFieldIsRequired({ 'key': 'marriageCertificate', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
              </label>

              <!--docs_birthCertificate-->
              <file-upload v-model="documents.marriageCertificate" class="file-upload-input"
                name="marriageCertificate_docs" data-vv-as="marriageCertificate" :accept="allDocEntity" :multiple="true"
                :hideSelected="true" @input="upload(documents.marriageCertificate, 'marriageCertificate')">
                <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                Upload
                <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'marriageCertificate')"><img
                    src="@/assets/images/main/loader.gif"></span>
              </file-upload>


              <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.marriageCertificate_docs')">{{
                errors.first("documentsInfoform.marriageCertificate_docs")
              }}</span>
              <ul class="uploaded-list">
                <template v-for="(item, index) in documents.marriageCertificate"
                  v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">

                  <template v-if="callFromEdit">
                    <vs-chip @click="remove(item, documents.marriageCertificate, index)" :key="index"
                      :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                      <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                      {{ item.name }} </vs-chip>
                  </template>
                  <template v-else>
                    <vs-chip @click="remove(item, documents.marriageCertificate, index)" :key="index" closable
                      v-if="item.status !== false && item['path']">
                      <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />

                      {{ item.name }} </vs-chip>
                  </template>
                </template>
              </ul>
            </div>
            
            <div class="vx-col w-full" v-if="canRenderField('other', fieldsArray, false, 'documents', 'other')">
              <label class="custom-label">
                {{ "other" | formatdoctype }} <em
                  v-if="checkFieldIsRequired({ 'key': 'other', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
              </label>

              <!--docs_birthCertificate-->
              <file-upload v-model="documents.other" class="file-upload-input" name="other_docs" data-vv-as="other"
                :accept="allDocEntity" :multiple="true" :hideSelected="true" @input="upload(documents.other, 'other')">
                <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                Upload
                <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'other')"><img
                    src="@/assets/images/main/loader.gif"></span>
              </file-upload>


              <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.other_docs')">{{
                errors.first("documentsInfoform.other_docs")
              }}</span>
              <ul class="uploaded-list">
                <template v-for="(item, index) in documents.other"
                  v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">

                  <template v-if="callFromEdit">
                    <vs-chip @click="remove(item, documents.other, index)" :key="index"
                      :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                      <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                      {{ item.name }} </vs-chip>
                  </template>
                  <template v-else>
                    <vs-chip @click="remove(item, documents.other, index)" :key="index" closable
                      v-if="item.status !== false && item['path']">
                      <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />

                      {{ item.name }} </vs-chip>
                  </template>
                </template>
              </ul>
            </div>

          </template>
          <template v-else>
            <!-- v-if="checkProperty(this.petitionDetails, 'subTypeDetails', 'id') != 15" -->
            <template>
              <!--new-->
              <div class="vx-col w-full"
                v-if="canRenderField('birthCertificate', fieldsArray, false, 'documents', 'birthCertificate')">
                <label class="custom-label">
                  {{ "birthCertificate" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'birthCertificate', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
                </label>

                <!--docs_birthCertificate-->
                <file-upload v-model="documents.birthCertificate" class="file-upload-input" name="birthCertificate_docs"
                  data-vv-as="birthCertificate" :accept="allDocEntity" :multiple="true" :hideSelected="true"
                  @input="upload(documents.birthCertificate, 'birthCertificate')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'birthCertificate')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>


                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.birthCertificate_docs')">{{
                  errors.first("documentsInfoform.birthCertificate_docs")
                }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.birthCertificate"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">

                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.birthCertificate, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.birthCertificate, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />

                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>
              <!-- <div
                            class="vx-col w-full"
                            v-if="canRenderField('beneficiaryDocs',fieldsArray, false,'documents','beneficiaryDocs') "
                          >
                            <label class="custom-label">
                              {{ "beneficiaryDocs" | formatdoctype }} <em v-if="checkFieldIsRequired({'key':'beneficiaryDocs','section':'documents', 'fieldsArray':fieldsArray, 'required':false })">*</em>
                            </label>

                          

                            <file-upload
                              v-model="documents.beneficiaryDocs"
                              class="file-upload-input"
                              name="bene_ficiaryDocs"
                              data-vv-as="Passport- First page with photo and last page with address"
                              accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                              :multiple="true"
                              
                            
                              :hideSelected="true"
                              @input="upload(documents.beneficiaryDocs ,'beneficiaryDocs')"
                            >
                              <img
                                class="file-icon"
                                src="@/assets/images/main/file-upload.svg"
                              />
                              Upload 
                              <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3 ,'beneficiaryDocs' )" ><img src="@/assets/images/main/loader.gif"></span>
                            </file-upload>
                          

                            <span
                              class="text-danger text-sm-doc"
                              v-show="errors.has('documentsInfoform.bene_ficiaryDocs')"
                              >{{
                                errors.first("documentsInfoform.bene_ficiaryDocs")
                              }}</span
                            >
                            <ul class="uploaded-list">
                              <template v-for="(item, index) in documents.beneficiaryDocs">
                              <template v-if="callFromEdit">
                                <vs-chip @click="remove(item, documents.beneficiaryDocs ,index)" :key="index" :closable="checkProperty(item ,'isNew')" v-if="item.status !== false"  >
                                  <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView' ,item)" />
                                  {{ item.name }} </vs-chip>
                              </template>
                              <template v-else>
                                <vs-chip @click="remove(item, documents.beneficiaryDocs ,index)" :key="index" closable v-if="item.status !== false"  > 
                                  <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView' ,item)" />
                                  
                                  {{ item.name }} </vs-chip>
                              </template>
                              </template>
                            </ul>
                          </div> 
                          <div
                            class="vx-col w-full"
                            v-if="canRenderField('passport',fieldsArray, false,'documents','passport') "
                          >
                            <label class="custom-label">
                              {{ "passport" | formatdoctype }} <em v-if="checkFieldIsRequired({'key':'passport','section':'documents', 'fieldsArray':fieldsArray, 'required':false })">*</em>
                            </label>

                          

                            <file-upload
                              v-model="documents.passport"
                              class="file-upload-input"
                              name="bendocsPassport"
                              data-vv-as="Passport- First page with photo and last page with address"
                              accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                              :multiple="true"
                              ref="bendocsPassport"
                            
                              :hideSelected="true"
                              @input="upload(documents.passport ,'passport')"
                            >
                              <img
                                class="file-icon"
                                src="@/assets/images/main/file-upload.svg"
                              />
                              Upload 
                              <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3 ,'passport' )" ><img src="@/assets/images/main/loader.gif"></span>
                            </file-upload>
                          

                            <span
                              class="text-danger text-sm-doc"
                              v-show="errors.has('documentsInfoform.bendocsPassport')"
                              >{{
                                errors.first("documentsInfoform.bendocsPassport")
                              }}</span
                            >
                            <ul class="uploaded-list">
                              <template v-for="(item, index) in documents.passport">
                              <template v-if="callFromEdit">
                                <vs-chip @click="remove(item, documents.passport ,index)" :key="index" :closable="checkProperty(item ,'isNew')" v-if="item.status !== false"  >
                                  <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView' ,item)" />
                                  {{ item.name }} </vs-chip>
                              </template>
                              <template v-else>
                                <vs-chip @click="remove(item, documents.passport ,index)" :key="index" closable v-if="item.status !== false"  > 
                                  <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView' ,item)" />
                                  
                                  {{ item.name }} </vs-chip>
                              </template>
                              </template>
                            </ul>
                          </div>-->
              <!--new-->

              <div class="vx-col w-full" v-if="canRenderField('passport', fieldsArray, false, 'documents', 'passport')">
                <label class="custom-label">
                  {{ "passport" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'passport', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
                </label>



                <file-upload v-model="documents.passport" class="file-upload-input" name="bendocsPassport"
                  data-vv-as="Passport- First page with photo and last page with address" :accept="allDocEntity"
                  :multiple="true" ref="bendocsPassport" :hideSelected="true"
                  @input="upload(documents.passport, 'passport')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'passport')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>


                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.bendocsPassport')">{{
                  errors.first("documentsInfoform.bendocsPassport")
                }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.passport"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />

                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>



              <div class="vx-col w-full"
                v-if="canRenderField('passportVisaI94', fieldsArray, false, 'documents', 'passportVisaI94')">
                <label class="custom-label">
                  {{ "passportVisaI94" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'passportVisaI94', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': true })">*</em>
                </label>
                <file-upload v-model="documents.passportVisaI94" class="file-upload-input"
                  name="benpassportVisaI94Document" data-vv-as="Passport, along with Case and Form I-94 (clearly showing the dates of
                            first and last entry into the United States)" :accept="allDocEntity" :multiple="true"
                  :hideSelected="true" @input="upload(documents.passportVisaI94, 'passportVisaI94')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'passportVisaI94')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>

                <span class="text-danger text-sm-doc" v-show="errors.has(
                  'documentsInfoform.benpassportVisaI94Document'
                )
                  ">{{ "passportVisaI94" | formatdoctype }} is
                  required</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.passportVisaI94"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>


              <div class="vx-col w-full" v-if="canRenderField('education', fieldsArray, false, 'documents', 'education')">
                <label class="custom-label">{{ "education" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'education', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em></label>
                <file-upload v-model="documents.education" class="file-upload-input" :accept="allDocEntity"
                  name="educationDocument"
                  data-vv-as="Master’s/ Bachelor’s degree certificate, transcripts, 12th and 10th certificates"
                  :multiple="true" :hideSelected="true" @input="upload(documents.education, 'education')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'education')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>

                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.educationDocument')
                  ">{{ "education" | formatdoctype }} is required</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.education"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>

              <div class="vx-col w-full" v-if="canRenderField('ssn', fieldsArray, false, 'documents', 'ssn')">
                <label class="custom-label">{{ "ssn" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'ssn', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em></label>
                <file-upload v-model="documents.ssn" class="file-upload-input" :accept="allDocEntity"
                  name="educationDocument"
                  data-vv-as="Master’s/ Bachelor’s degree certificate, transcripts, 12th and 10th certificates"
                  :multiple="true" :hideSelected="true" @input="upload(documents.ssn, 'ssn')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'ssn')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>

                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.educationDocument')
                  ">{{ "ssn" | formatdoctype }} is required</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.ssn"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>
              <div class="vx-col w-full"
                v-if="canRenderField('travelHistory', fieldsArray, false, 'documents', 'travelHistory')">
                <label class="custom-label">{{ "travelHistory" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'travelHistory', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em></label>
                <file-upload v-model="documents.travelHistory" class="file-upload-input" :accept="allDocEntity"
                  name="educationDocument"
                  data-vv-as="Master’s/ Bachelor’s degree certificate, transcripts, 12th and 10th certificates"
                  :multiple="true" :hideSelected="true" @input="upload(documents.travelHistory, 'travelHistory')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'travelHistory')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>

                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.educationDocument')
                  ">{{ "travelHistory" | formatdoctype }} is required</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.travelHistory"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>

              <div class="vx-col w-full"
                v-if="canRenderField('priorFormI797', fieldsArray, false, 'documents', 'priorFormI797')">
                <label class="custom-label">{{ "priorFormI797" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'priorFormI797', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em></label>
                <file-upload v-model="documents.priorFormI797" class="file-upload-input" name="docs_prior_form_i797"
                  data-vv-as="All prior I-797, Notice of Approvals granting H-1B status" :multiple="true"
                  :hideSelected="true" :accept="allDocEntity" @input="upload(documents.priorFormI797, 'priorFormI797')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'priorFormI797')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>

                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.docs_prior_form_i797')
                  ">{{
    errors.first("documentsInfoform.docs_prior_form_i797")
  }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.priorFormI797"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>

              <div class="vx-col w-full" v-if="canRenderField('payStubs', fieldsArray, false, 'documents', 'payStubs')">
                <label class="custom-label">Three Recent Pay Stubs <em
                    v-if="checkFieldIsRequired({ 'key': 'payStubs', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em></label>
                <file-upload v-model="documents.payStubs" class="file-upload-input" name="payStubs"
                  data-vv-as="Three Recent Pay Stubs" :multiple="true" :hideSelected="true" :accept="allDocEntity"
                  @input="upload(documents.payStubs, 'payStubs')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'payStubs')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>

                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.payStubs')">{{
                  errors.first("documentsInfoform.payStubs") }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.payStubs"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>

              <div class="vx-col w-full" v-if="canRenderField('formI94', fieldsArray, false, 'documents', 'formI94')">
                <label class="custom-label">{{ "formI94" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'formI94', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em></label>
                <file-upload v-model="documents.formI94" class="file-upload-input" name="docs_form_i94"
                  data-vv-as="Form I-94" :multiple="true" :hideSelected="true" :accept="allDocEntity"
                  @input="upload(documents.formI94, 'formI94')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'formI94')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>

                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.docs_form_i94')">{{
                  errors.first("documentsInfoform.docs_form_i94")
                }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.formI94"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>


              <div class="vx-col w-full" v-if="canRenderField('ead', fieldsArray, false, 'documents', 'ead')">
                <label class="custom-label">EADs (if on OPT or STEM OPT Extension) <em
                    v-if="checkFieldIsRequired({ 'key': 'ead', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
                </label>
                <file-upload v-model="documents.ead" class="file-upload-input" name="ead"
                  data-vv-as="EADs (if on OPT or STEM OPT Extension)" :multiple="true" :hideSelected="true"
                  :accept="allDocEntity" @input="upload(documents.ead, 'ead')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'ead')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>

                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.ead')">{{
                  errors.first("documentsInfoform.ead") }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.ead"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>



              <div class="vx-col w-full" v-if="canRenderField('formI20', fieldsArray, false, 'documents', 'formI20')">
                <label class="custom-label">{{
                  "formI20" | formatdoctype
                }} <em
                    v-if="checkFieldIsRequired({ 'key': 'formI20', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em></label>
                <file-upload v-model="documents.formI20" class="file-upload-input" name="formI20Document" data-vv-as=" "
                  :multiple="true" :hideSelected="true" :accept="allDocEntity"
                  @input="upload(documents.formI20, 'formI20')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'formI20')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>

                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.formI20Document')">{{
                  "formI20"
                  | formatdoctype }} is required</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.formI20"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">

                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>



              <div class="vx-col w-full"
                v-if="canRenderField('I797NoticeofApprovalforI140', fieldsArray, false, 'documents', 'I797NoticeofApprovalforI140')">
                <label class="custom-label">{{
                  "I797NoticeofApprovalforI140" | formatdoctype
                }} <em
                    v-if="checkFieldIsRequired({ 'key': 'I797NoticeofApprovalforI140', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em></label>
                <file-upload v-model="documents.I797NoticeofApprovalforI140" class="file-upload-input"
                  name="I797NoticeofApprovalforI140" data-vv-as="I-797 Notice-of Approvalfor I-140" :multiple="true"
                  :hideSelected="true" :accept="allDocEntity"
                  @input="upload(documents.I797NoticeofApprovalforI140, 'I797NoticeofApprovalforI140')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'I797NoticeofApprovalforI140')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>

                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.formI20Document')">{{
                  "I797NoticeofApprovalforI140" | formatdoctype }} is required</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.I797NoticeofApprovalforI140"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>


              <div class="vx-col w-full" v-if="canRenderField('resume', fieldsArray, false, 'documents', 'resume')">
                <label class="custom-label">{{
                  "resume" | formatdoctype
                }} <em
                    v-if="checkFieldIsRequired({ 'key': 'resume', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em></label>
                <file-upload v-model="documents.resume" class="file-upload-input" :accept="allDocEntity"
                  name="resumeDocument" data-vv-as="Resume" :multiple="true" :hideSelected="true"
                  @input="upload(documents.resume, 'resume')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'resume')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>

                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.resumeDocument')">{{
                  errors.first("documentsInfoform.resumeDocument")
                }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.resume"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>

              <div class="vx-col w-full"
                v-if="canRenderField('expLetters', fieldsArray, false, 'documents', 'expLetters')">
                <label class="custom-label">{{
                  "expLetters" | formatdoctype
                }} <em
                    v-if="checkFieldIsRequired({ 'key': 'expLetters', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em></label>
                <file-upload v-model="documents.expLetters" class="file-upload-input" name="experienceDocument"
                  :accept="allDocEntity" data-vv-as="Experience Letters" :multiple="true" :hideSelected="true"
                  @input="upload(documents.expLetters, 'expLetters')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'expLetters')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>

                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.experienceDocument')
                  ">{{
    errors.first("documentsInfoform.experienceDocument")
  }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.expLetters"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>

              <div class="vx-col w-full"
                v-if="canRenderField('offerLetter', fieldsArray, false, 'documents', 'offerLetter')">
                <label class="custom-label">{{ "offerLetter" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'offerLetter', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
                </label>
                <file-upload v-model="documents.offerLetter" class="file-upload-input" name="offerLetter" data-vv-as=" "
                  :multiple="true" :hideSelected="true" :accept="allDocEntity"
                  @input="upload(documents.offerLetter, 'offerLetter')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'offerLetter')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>

                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.offerLetter')">{{
                  errors.first("documentsInfoform.offerLetter")
                }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.offerLetter"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>
              <div class="vx-col w-full"
                v-if="canRenderField('employmentAgreement', fieldsArray, false, 'documents', 'employmentAgreement')">
                <label class="custom-label">{{
                  "employmentAgreement" | formatdoctype
                }} <em
                    v-if="checkFieldIsRequired({ 'key': 'employmentAgreement', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em></label>
                <file-upload v-model="documents.employmentAgreement" class="file-upload-input"
                  name="docs_employment_agreement" data-vv-as="Employment Agreement" :multiple="true" :hideSelected="true"
                  :accept="allDocEntity" @input="upload(documents.employmentAgreement, 'employmentAgreement')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'employmentAgreement')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>

                <span class="text-danger text-sm-doc" v-show="errors.has(
                  'documentsInfoform.docs_employment_agreement'
                )
                  ">{{
    errors.first(
      "documentsInfoform.docs_employment_agreement"
    )
  }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.employmentAgreement"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>
              <div class="vx-col w-full"
                v-if="canRenderField('INSNotices', fieldsArray, false, 'documents', 'INSNotices')">
                <label class="custom-label">{{
                  "INSNotices" | formatdoctype
                }} <em
                    v-if="checkFieldIsRequired({ 'key': 'INSNotices', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em></label>
                <file-upload v-model="documents.INSNotices" class="file-upload-input" name="insNoticeDocument"
                  data-vv-as=" " :multiple="true" :hideSelected="true" :accept="allDocEntity"
                  @input="upload(documents.INSNotices, 'INSNotices')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'INSNotices')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>

                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.insNoticeDocument')
                  ">{{
    errors.first("documentsInfoform.insNoticeDocument")
  }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.INSNotices"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>

              <div class="vx-col w-full"
                v-if="canRenderField('socialSecurityCardAndProfLicense', fieldsArray, false, 'documents', 'socialSecurityCardAndProfLicense')">
                <label class="custom-label">{{ 'socialSecurityCardAndProfLicense' | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'socialSecurityCardAndProfLicense', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em></label>
                <file-upload v-model="documents.socialSecurityCardAndProfLicense" class="file-upload-input"
                  name="socialSecurityCardAndProfLicenseDocument" data-vv-as="INS Notices" :multiple="true"
                  :hideSelected="true" :accept="allDocEntity" @input="
                    upload(documents.socialSecurityCardAndProfLicense, 'socialSecurityCardAndProfLicense')
                    ">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader"
                    v-if="checkProperty(doCumentsAreUploadingToS3, 'socialSecurityCardAndProfLicense')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>

                <span class="text-danger text-sm-doc" v-show="errors.has(
                  'documentsInfoform.socialSecurityCardAndProfLicenseDocument'
                )
                  ">{{
    errors.first(
      "documentsInfoform.socialSecurityCardAndProfLicenseDocument"
    )
  }}</span>
                <ul class="uploaded-list">
                  <template v-for="(
                                    item, index
                                  ) in documents.socialSecurityCardAndProfLicense"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>

              <!-- Client Letters -->
              <div class="vx-col w-full"
                v-if="canRenderField('clientLetter', fieldsArray, false, 'documents', 'clientLetter')">
                <label class="custom-label">{{
                  "clientLetter" | formatdoctype
                }} <em
                    v-if="checkFieldIsRequired({ 'key': 'clientLetter', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em></label>
                <file-upload v-model="documents.clientLetter" class="file-upload-input" name="clientLetter" data-vv-as=" "
                  :multiple="true" :hideSelected="true" :accept="allDocEntity"
                  @input="upload(documents.clientLetter, 'clientLetter')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'clientLetter')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>

                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.clientLetter')">{{
                  errors.first("documentsInfoform.clientLetter")
                }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.clientLetter"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>
              <!--vendorLetter--->
              <div class="vx-col w-full"
                v-if="canRenderField('vendorLetter', fieldsArray, false, 'documents', 'vendorLetter')">
                <label class="custom-label">{{
                  "vendorLetter" | formatdoctype
                }} <em
                    v-if="checkFieldIsRequired({ 'key': 'vendorLetter', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em></label>
                <file-upload v-model="documents.vendorLetter" class="file-upload-input" name="vendorLetter" data-vv-as=" "
                  :multiple="true" :hideSelected="true" :accept="allDocEntity"
                  @input="upload(documents.vendorLetter, 'vendorLetter')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'vendorLetter')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>

                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.vendorLetter')">{{
                  errors.first("documentsInfoform.vendorLetter")
                }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.vendorLetter"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>
              <!--msa--->
              <div class="vx-col w-full" v-if="canRenderField('msa', fieldsArray, false, 'documents', 'msa')">
                <label class="custom-label">{{
                  "msa" | formatdoctype
                }} <em
                    v-if="checkFieldIsRequired({ 'key': 'msa', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em></label>
                <file-upload v-model="documents.msa" class="file-upload-input" name="msa" data-vv-as=" " :multiple="true"
                  :hideSelected="true" :accept="allDocEntity" @input="upload(documents.msa, 'msa')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'msa')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>

                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.msa')">{{
                  errors.first("documentsInfoform.msa") }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.msa"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>

              <!--po--->
              <div class="vx-col w-full" v-if="canRenderField('po', fieldsArray, false, 'documents', 'po')">
                <label class="custom-label">PO <em
                    v-if="checkFieldIsRequired({ 'key': 'po', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em></label>
                <file-upload v-model="documents.po" class="file-upload-input" name="po" data-vv-as=" " :multiple="true"
                  :hideSelected="true" :accept="allDocEntity" @input="upload(documents.po, 'po')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'po')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>

                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.po')">{{
                  errors.first("documentsInfoform.po") }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.po"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>

              <!-----NEW DOCUMENTS---->
              <div class="vx-col w-full"
                v-if="canRenderField('h1bRegSelectionNotice', fieldsArray, false, 'documents', 'h1bRegSelectionNotice')">
                <label class="custom-label">{{
                  "h1bRegSelectionNotice" | formatdoctype
                }} <em
                    v-if="checkFieldIsRequired({ 'key': 'h1bRegSelectionNotice', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em></label>
                <file-upload v-model="documents.h1bRegSelectionNotice" class="file-upload-input"
                  name="docs_h1b_reg_selection_notice" data-vv-as="H-1B Registration Selection Notice" :multiple="true"
                  :hideSelected="true" :accept="allDocEntity"
                  @input="upload(documents.h1bRegSelectionNotice, 'h1bRegSelectionNotice')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'h1bRegSelectionNotice')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>

                <span class="text-danger text-sm-doc" v-show="errors.has(
                  'documentsInfoform.docs_h1b_reg_selection_notice'
                )
                  ">{{
    errors.first(
      "documentsInfoform.docs_h1b_reg_selection_notice"
    )
  }}</span>
                <ul class="uploaded-list">
                  <template v-for="(
                                    item, index
                                  ) in documents.h1bRegSelectionNotice">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>

              <div class="vx-col w-full"
                v-if="canRenderField('primeVendor', fieldsArray, false, 'documents', 'primeVendor')">
                <label class="custom-label">{{
                  "primeVendor" | formatdoctype
                }} <em
                    v-if="checkFieldIsRequired({ 'key': 'primeVendor', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em></label>
                <file-upload v-model="documents.primeVendor" class="file-upload-input" name="docs_prime_vendor"
                  data-vv-as="Prime Vendor Letter" :multiple="true" :hideSelected="true" :accept="allDocEntity"
                  @input="upload(documents.primeVendor, 'primeVendor')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'primeVendor')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>

                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.docs_prime_vendor')
                  ">{{
    errors.first("documentsInfoform.docs_prime_vendor")
  }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.primeVendor"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>

              <!----NEW DOCUMENTS END--->
              <div class="vx-col w-full" v-if="canRenderField('other', fieldsArray, false, 'documents', 'other')">
                <label class="custom-label">Other Documents, if any <em
                    v-if="checkFieldIsRequired({ 'key': 'other', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em></label>
                <file-upload v-model="documents.other" class="file-upload-input" name="otherDocument" data-vv-as=" "
                  :multiple="true" :hideSelected="true" :accept="allDocEntity" @input="upload(documents.other, 'other')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'other')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>

                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.otherDocument')">{{
                  errors.first("documentsInfoform.otherDocument")
                }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.other"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.passport, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>

              <div class="vx-col w-full" v-if="canRenderField('slgResume', fieldsArray, false, 'documents', 'slgResume')">
                <label class="custom-label">
                  {{ "slgResume" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'slgResume', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
                </label>



                <file-upload v-model="documents.slgResume" class="file-upload-input" name="slgResume"
                  data-vv-as="Current Resume- Please mention the accurate names of the employer and periods of employment. Do not state the client names"
                  :accept="allDocEntity" :multiple="true" ref="slgResume" :hideSelected="true"
                  @input="upload(documents.slgResume, 'slgResume')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'slgResume')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>


                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.slgResume')">{{
                  errors.first("documentsInfoform.slgResume")
                }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.slgResume"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.slgResume, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.slgResume, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>

              <!-- <div class="vx-col w-full"
                v-if="canRenderField('slgTransScripts', fieldsArray, false, 'documents', 'slgTransScripts')">
                <label class="custom-label">
                  {{ "slgTransScripts" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'slgTransScripts', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
                </label>



                <file-upload v-model="documents.slgTransScripts" class="file-upload-input" name="slgTransScripts"
                  data-vv-as="Transcripts/Marks memo’s" :accept="allDocEntity" :multiple="true" ref="slgTransScripts"
                  :hideSelected="true" @input="upload(documents.slgTransScripts, 'slgTransScripts')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'slgTransScripts')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>


                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.slgTransScripts')">{{
                  errors.first("documentsInfoform.slgTransScripts")
                }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.slgTransScripts"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.slgTransScripts, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.slgTransScripts, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>
 -->
              <div class="vx-col w-full"
                v-if="canRenderField('slgExpLetters', fieldsArray, false, 'documents', 'slgExpLetters')">
                <label class="custom-label">
                  {{ "slgExpLetters" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'slgExpLetters', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
                </label>



                <file-upload v-model="documents.slgExpLetters" class="file-upload-input" name="slgExpLetters"
                  data-vv-as="Letters of Experience" :accept="allDocEntity" :multiple="true" ref="slgExpLetters"
                  :hideSelected="true" @input="upload(documents.slgExpLetters, 'slgExpLetters')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'slgExpLetters')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>


                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.slgExpLetters')">{{
                  errors.first("documentsInfoform.slgExpLetters")
                }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.slgExpLetters"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.slgExpLetters, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.slgExpLetters, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>

              <div class="vx-col w-full"
                v-if="canRenderField('slgCollegeDegreesCert', fieldsArray, false, 'documents', 'slgCollegeDegreesCert')">
                <label class="custom-label">
                  {{ "slgCollegeDegreesCert" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'slgCollegeDegreesCert', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
                </label>



                <file-upload v-model="documents.slgCollegeDegreesCert" class="file-upload-input"
                  name="slgCollegeDegreesCert" data-vv-as="All College Degrees" :accept="allDocEntity" :multiple="true"
                  ref="slgCollegeDegreesCert" :hideSelected="true"
                  @input="upload(documents.slgCollegeDegreesCert, 'slgCollegeDegreesCert')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'slgCollegeDegreesCert')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>


                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.slgCollegeDegreesCert')">{{
                  errors.first("documentsInfoform.slgCollegeDegreesCert")
                }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.slgCollegeDegreesCert"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.slgCollegeDegreesCert, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.slgCollegeDegreesCert, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>

              <div class="vx-col w-full"
                v-if="canRenderField('slgPassportAndVisa', fieldsArray, false, 'documents', 'slgPassportAndVisa')">
                <label class="custom-label">
                  {{ "slgPassportAndVisa" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'slgPassportAndVisa', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
                </label>



                <file-upload v-model="documents.slgPassportAndVisa" class="file-upload-input" name="slgPassportAndVisa"
                  data-vv-as="Copy of New and Old Passport " :accept="allDocEntity" :multiple="true"
                  ref="slgPassportAndVisa" :hideSelected="true"
                  @input="upload(documents.slgPassportAndVisa, 'slgPassportAndVisa')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'slgPassportAndVisa')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>


                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.slgPassportAndVisa')">{{
                  errors.first("documentsInfoform.slgPassportAndVisa")
                }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.slgPassportAndVisa"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.slgPassportAndVisa, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.slgPassportAndVisa, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>
              <div class="vx-col w-full" v-if="canRenderField('slgI94', fieldsArray, false, 'documents', 'slgI94')">
                <label class="custom-label">
                  {{ "slgI94" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'slgI94', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
                </label>



                <file-upload v-model="documents.slgI94" class="file-upload-input" name="slgI94" data-vv-as="I-94"
                  :accept="allDocEntity" :multiple="true" ref="slgI94" :hideSelected="true"
                  @input="upload(documents.slgI94, 'slgI94')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'slgI94')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>


                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.slgI94')">{{
                  errors.first("documentsInfoform.slgI94")
                }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.slgI94"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.slgI94, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.slgI94, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>

              <div class="vx-col w-full"
                v-if="canRenderField('slgPrevNonimmApprovalNotices', fieldsArray, false, 'documents', 'slgPrevNonimmApprovalNotices')">
                <label class="custom-label">
                  {{ "slgPrevNonimmApprovalNotices" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'slgPrevNonimmApprovalNotices', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
                </label>



                <file-upload v-model="documents.slgPrevNonimmApprovalNotices" class="file-upload-input"
                  name="slgPrevNonimmApprovalNotices"
                  data-vv-as="Copy of all Previous Nonimmigrant Approval Notices (e.g., H-1B, H-4, L-1A, L-1B, L-2 etc.) "
                  :accept="allDocEntity" :multiple="true" ref="slgPrevNonimmApprovalNotices" :hideSelected="true"
                  @input="upload(documents.slgPrevNonimmApprovalNotices, 'slgPrevNonimmApprovalNotices')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader"
                    v-if="checkProperty(doCumentsAreUploadingToS3, 'slgPrevNonimmApprovalNotices')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>


                <span class="text-danger text-sm-doc"
                  v-show="errors.has('documentsInfoform.slgPrevNonimmApprovalNotices')">{{
                    errors.first("documentsInfoform.slgPrevNonimmApprovalNotices")
                  }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.slgPrevNonimmApprovalNotices"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.slgPrevNonimmApprovalNotices, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.slgPrevNonimmApprovalNotices, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>
              <div class="vx-col w-full"
                v-if="canRenderField('slgI140OrPermNoties', fieldsArray, false, 'documents', 'slgI140OrPermNoties')">
                <label class="custom-label">
                  {{ "slgI140OrPermNoties" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'slgI140OrPermNoties', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
                </label>



                <file-upload v-model="documents.slgI140OrPermNoties" class="file-upload-input" name="slgI140OrPermNoties"
                  data-vv-as="Copy of any I-140 approval notices or PERM filing Notices (if applicable)"
                  :accept="allDocEntity" :multiple="true" ref="slgI140OrPermNoties" :hideSelected="true"
                  @input="upload(documents.slgI140OrPermNoties, 'slgI140OrPermNoties')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'slgI140OrPermNoties')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>


                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.slgI140OrPermNoties')">{{
                  errors.first("documentsInfoform.slgI140OrPermNoties")
                }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.slgI140OrPermNoties"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.slgI140OrPermNoties, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.slgI140OrPermNoties, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>

              <div class="vx-col w-full"
                v-if="canRenderField('slgPrevLaborApplications', fieldsArray, false, 'documents', 'slgPrevLaborApplications')">
                <label class="custom-label">
                  {{ "slgPrevLaborApplications" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'slgPrevLaborApplications', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
                </label>



                <file-upload v-model="documents.slgPrevLaborApplications" class="file-upload-input"
                  name="slgPrevLaborApplications"
                  data-vv-as="Copy of the previously filed Labor Application, if applicable. " :accept="allDocEntity"
                  :multiple="true" ref="slgPrevLaborApplications" :hideSelected="true"
                  @input="upload(documents.slgPrevLaborApplications, 'slgPrevLaborApplications')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'slgPrevLaborApplications')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>


                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.slgPrevLaborApplications')">{{
                  errors.first("documentsInfoform.slgPrevLaborApplications")
                }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.slgPrevLaborApplications"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.slgPrevLaborApplications, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.slgPrevLaborApplications, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>
              <div class="vx-col w-full"
                v-if="canRenderField('slgAckOfPrevLaborApplications', fieldsArray, false, 'documents', 'slgAckOfPrevLaborApplications')">
                <label class="custom-label">
                  {{ "slgAckOfPrevLaborApplications" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'slgAckOfPrevLaborApplications', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
                </label>



                <file-upload v-model="documents.slgAckOfPrevLaborApplications" class="file-upload-input"
                  name="slgAckOfPrevLaborApplications"
                  data-vv-as="Copy of the Acknowledgement letter for the previously filed Labor application, if applicable"
                  :accept="allDocEntity" :multiple="true" ref="slgAckOfPrevLaborApplications" :hideSelected="true"
                  @input="upload(documents.slgAckOfPrevLaborApplications, 'slgAckOfPrevLaborApplications')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader"
                    v-if="checkProperty(doCumentsAreUploadingToS3, 'slgAckOfPrevLaborApplications')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>


                <span class="text-danger text-sm-doc"
                  v-show="errors.has('documentsInfoform.slgAckOfPrevLaborApplications')">{{
                    errors.first("documentsInfoform.slgAckOfPrevLaborApplications")
                  }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.slgAckOfPrevLaborApplications"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.slgAckOfPrevLaborApplications, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.slgAckOfPrevLaborApplications, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>

              <div class="vx-col w-full"
                v-if="canRenderField('slgPaystubs', fieldsArray, false, 'documents', 'slgPaystubs')">
                <label class="custom-label">
                  {{ "slgPaystubs" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'slgPaystubs', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
                </label>



                <file-upload v-model="documents.slgPaystubs" class="file-upload-input" name="slgPaystubs"
                  data-vv-as="Copies of Most recent paystubs (last 2 to 3 months)" :accept="allDocEntity" :multiple="true"
                  ref="slgPaystubs" :hideSelected="true" @input="upload(documents.slgPaystubs, 'slgPaystubs')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'slgPaystubs')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>


                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.slgPaystubs')">{{
                  errors.first("documentsInfoform.slgPaystubs")
                }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.slgPaystubs"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.slgPaystubs, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.slgPaystubs, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>

              <div class="vx-col w-full" v-if="canRenderField('slgI20', fieldsArray, false, 'documents', 'slgI20')">
                <label class="custom-label">
                  {{ "slgI20" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'slgI20', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
                </label>



                <file-upload v-model="documents.slgI20" class="file-upload-input" name="slgI20"
                  data-vv-as="Copies of all I-20’s" :accept="allDocEntity" :multiple="true" ref="slgI20"
                  :hideSelected="true" @input="upload(documents.slgI20, 'slgI20')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'slgI20')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>


                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.slgI20')">{{
                  errors.first("documentsInfoform.slgI20")
                }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.slgI20"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.slgI20, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.slgI20, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>

              <div class="vx-col w-full" v-if="canRenderField('slgEad', fieldsArray, false, 'documents', 'slgEad')">
                <label class="custom-label">
                  {{ "slgEad" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'slgEad', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
                </label>



                <file-upload v-model="documents.slgEad" class="file-upload-input" name="slgEad"
                  data-vv-as="Copies of EAD cards" :accept="allDocEntity" :multiple="true" ref="slgEad"
                  :hideSelected="true" @input="upload(documents.slgEad, 'slgEad')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'slgEad')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>


                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.slgEad')">{{
                  errors.first("documentsInfoform.slgEad")
                }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.slgEad"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.slgI20, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.slgEad, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>

              <div class="vx-col w-full"
                v-if="canRenderField('bnfSpouseLatestI797', fieldsArray, false, 'documents', 'bnfSpouseLatestI797')">
                <label class="custom-label">
                  {{ "bnfSpouseLatestI797" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'bnfSpouseLatestI797', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
                </label>



                <file-upload v-model="documents.bnfSpouseLatestI797" class="file-upload-input" name="bnfSpouseLatestI797"
                  data-vv-as="Latest I-797, Notice of Approval of the spouse (if spouse is on H-1B or L-1 status)"
                  :accept="allDocEntity" :multiple="true" ref="bnfSpouseLatestI797" :hideSelected="true"
                  @input="upload(documents.bnfSpouseLatestI797, 'bnfSpouseLatestI797')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'bnfSpouseLatestI797')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>


                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.bnfSpouseLatestI797')">{{
                  errors.first("documentsInfoform.bnfSpouseLatestI797")
                }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.bnfSpouseLatestI797"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.bnfSpouseLatestI797, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.bnfSpouseLatestI797, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>

              <div class="vx-col w-full"
                v-if="canRenderField('bnfSpousePassport', fieldsArray, false, 'documents', 'bnfSpousePassport')">
                <label class="custom-label">
                  {{ "bnfSpousePassport" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'bnfSpousePassport', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
                </label>



                <file-upload v-model="documents.bnfSpousePassport" class="file-upload-input" name="bnfSpousePassport"
                  data-vv-as="Spouse’s Passport- First page with photo, Visa page and last page with address"
                  :accept="allDocEntity" :multiple="true" ref="bnfSpousePassport" :hideSelected="true"
                  @input="upload(documents.bnfSpousePassport, 'bnfSpousePassport')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'bnfSpousePassport')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>


                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.bnfSpousePassport')">{{
                  errors.first("documentsInfoform.bnfSpousePassport")
                }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.bnfSpousePassport"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.bnfSpousePassport, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.bnfSpousePassport, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>

              <div class="vx-col w-full"
                v-if="canRenderField('bnfSpouseRecentPayStubs', fieldsArray, false, 'documents', 'bnfSpouseRecentPayStubs')">
                <label class="custom-label">
                  {{ "bnfSpouseRecentPayStubs" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'bnfSpouseRecentPayStubs', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
                </label>



                <file-upload v-model="documents.bnfSpouseRecentPayStubs" class="file-upload-input"
                  name="bnfSpouseRecentPayStubs" data-vv-as="Three recent pay stubs (if spouse is on H-1B or L-1 status)"
                  :accept="allDocEntity" :multiple="true" ref="bnfSpouseRecentPayStubs" :hideSelected="true"
                  @input="upload(documents.bnfSpouseRecentPayStubs, 'bnfSpouseRecentPayStubs')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'bnfSpouseRecentPayStubs')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>


                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.bnfSpouseRecentPayStubs')">{{
                  errors.first("documentsInfoform.bnfSpouseRecentPayStubs")
                }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.bnfSpouseRecentPayStubs"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.bnfSpouseRecentPayStubs, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.bnfSpouseRecentPayStubs, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>

              <div class="vx-col w-full"
                v-if="canRenderField('bnfSpouseFormAllI20', fieldsArray, false, 'documents', 'bnfSpouseFormAllI20')">
                <label class="custom-label">
                  {{ "bnfSpouseFormAllI20" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'bnfSpouseFormAllI20', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
                </label>



                <file-upload v-model="documents.bnfSpouseFormAllI20" class="file-upload-input" name="bnfSpouseFormAllI20"
                  data-vv-as="Spouse’s all Form I-20s (if spouse is on F-1 status)" :accept="allDocEntity"
                  :multiple="true" ref="bnfSpouseFormAllI20" :hideSelected="true"
                  @input="upload(documents.bnfSpouseFormAllI20, 'bnfSpouseFormAllI20')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'bnfSpouseFormAllI20')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>


                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.bnfSpouseFormAllI20')">{{
                  errors.first("documentsInfoform.bnfSpouseFormAllI20")
                }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.bnfSpouseFormAllI20"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.bnfSpouseFormAllI20, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.bnfSpouseFormAllI20, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>

              <!----
                          slgResume: [],
                slgCollegeDegreesCert: [],
                slgTransScripts: [],//Transcripts/Marks memo’s
                slgExpLetters: [],
                slgPassportAndVisa: [],
                slgI94: [],
                slgPrevNonimmApprovalNotices: [],
                slgI140OrPermNoties: [],
                slgPrevLaborApplications: [],
                slgAckOfPrevLaborApplications: [],
                slgPaystubs: [],
                slgI20: [],
                slgEad: [],
                        -->
            </template>
            <!-------New Documents 04/04/2023-->
            <!-- v-if="([7, 9].indexOf( checkProperty(petitionDetails ,'subTypeDetails' ,'id') )>-1&& checkProperty( petitionDetails,'beneficiaryInfo','curNonImmigrantVisaStatus') ==7)" -->
            <template>
              <div class="vx-col w-full"
                v-if="canRenderField('formI797H4ApprovalNotice', fieldsArray, false, 'documents', 'formI797H4ApprovalNotice') && checkImmigrantStatus">
                <label class="custom-label">
                  {{ "formI797H4ApprovalNotice" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'formI797H4ApprovalNotice', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
                </label>



                <file-upload v-model="documents.formI797H4ApprovalNotice" class="file-upload-input"
                  name="formI797H4ApprovalNotice" data-vv-as="Copies of EAD cards" :accept="allDocEntity" :multiple="true"
                  ref="formI797H4ApprovalNotice" :hideSelected="true"
                  @input="upload(documents.formI797H4ApprovalNotice, 'formI797H4ApprovalNotice')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'formI797H4ApprovalNotice')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>


                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.formI797H4ApprovalNotice')">{{
                  errors.first("documentsInfoform.formI797H4ApprovalNotice")
                }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.formI797H4ApprovalNotice"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.slgI20, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.formI797H4ApprovalNotice, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>

              <div class="vx-col w-full"
                v-if="canRenderField('formI797H1BApprovalNoticePrinNonCtzn', fieldsArray, false, 'documents', 'formI797H1BApprovalNoticePrinNonCtzn') && checkImmigrantStatus">
                <label class="custom-label">
                  {{ "formI797H1BApprovalNoticePrinNonCtzn" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'formI797H1BApprovalNoticePrinNonCtzn', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
                </label>


                <file-upload v-model="documents.formI797H1BApprovalNoticePrinNonCtzn" class="file-upload-input"
                  name="formI797H1BApprovalNoticePrinNonCtzn" data-vv-as="Copies of EAD cards" :accept="allDocEntity"
                  :multiple="true" ref="formI797H1BApprovalNoticePrinNonCtzn" :hideSelected="true"
                  @input="upload(documents.formI797H1BApprovalNoticePrinNonCtzn, 'formI797H1BApprovalNoticePrinNonCtzn')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader"
                    v-if="checkProperty(doCumentsAreUploadingToS3, 'formI797H1BApprovalNoticePrinNonCtzn')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>


                <span class="text-danger text-sm-doc"
                  v-show="errors.has('documentsInfoform.formI797H1BApprovalNoticePrinNonCtzn')">{{
                    errors.first("documentsInfoform.formI797H1BApprovalNoticePrinNonCtzn")
                  }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.formI797H1BApprovalNoticePrinNonCtzn"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.slgI20, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.formI797H1BApprovalNoticePrinNonCtzn, index)" :key="index"
                        closable v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>

              <div class="vx-col w-full"
                v-if="canRenderField('passportOfPrinNonCtzn', fieldsArray, false, 'documents', 'passportOfPrinNonCtzn') && checkImmigrantStatus">
                <label class="custom-label">
                  {{ "passportOfPrinNonCtzn" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'passportOfPrinNonCtzn', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
                </label>
                <file-upload v-model="documents.passportOfPrinNonCtzn" class="file-upload-input"
                  name="passportOfPrinNonCtzn" data-vv-as="Copies of EAD cards" :accept="allDocEntity" :multiple="true"
                  ref="passportOfPrinNonCtzn" :hideSelected="true"
                  @input="upload(documents.passportOfPrinNonCtzn, 'passportOfPrinNonCtzn')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'passportOfPrinNonCtzn')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>


                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.passportOfPrinNonCtzn')">
                  {{ errors.first("documentsInfoform.passportOfPrinNonCtzn") }}
                </span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.passportOfPrinNonCtzn"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.slgI20, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.passportOfPrinNonCtzn, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>

              <div class="vx-col w-full"
                v-if="canRenderField('last3MonthsPayslipsOfPrinNonCtzn', fieldsArray, false, 'documents', 'last3MonthsPayslipsOfPrinNonCtzn') && checkImmigrantStatus">
                <label class="custom-label">
                  {{ "last3MonthsPayslipsOfPrinNonCtzn" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'last3MonthsPayslipsOfPrinNonCtzn', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
                </label>
                <file-upload v-model="documents.last3MonthsPayslipsOfPrinNonCtzn" class="file-upload-input"
                  name="last3MonthsPayslipsOfPrinNonCtzn" data-vv-as="Copies of EAD cards" :accept="allDocEntity"
                  :multiple="true" ref="last3MonthsPayslipsOfPrinNonCtzn" :hideSelected="true"
                  @input="upload(documents.last3MonthsPayslipsOfPrinNonCtzn, 'last3MonthsPayslipsOfPrinNonCtzn')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader"
                    v-if="checkProperty(doCumentsAreUploadingToS3, 'last3MonthsPayslipsOfPrinNonCtzn')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>


                <span class="text-danger text-sm-doc"
                  v-show="errors.has('documentsInfoform.last3MonthsPayslipsOfPrinNonCtzn')">{{
                    errors.first("documentsInfoform.last3MonthsPayslipsOfPrinNonCtzn") }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.last3MonthsPayslipsOfPrinNonCtzn"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.slgI20, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.last3MonthsPayslipsOfPrinNonCtzn, index)" :key="index"
                        closable v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>
              <div class="vx-col w-full"
                v-if="canRenderField('marriageCertificate', fieldsArray, false, 'documents', 'marriageCertificate') && checkImmigrantStatus
                  && checkProperty(petitionDetails, 'beneficiaryInfo', 'maritalStatusDetails') && checkProperty(petitionDetails['beneficiaryInfo'], 'maritalStatusDetails', 'id') != 1">
                <label class="custom-label">
                  {{ "marriageCertificate" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'marriageCertificate', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
                </label>
                <file-upload v-model="documents.marriageCertificate" class="file-upload-input" name="marriageCertificate"
                  data-vv-as="Copies of EAD cards" :accept="allDocEntity" :multiple="true" ref="marriageCertificate"
                  :hideSelected="true" @input="upload(documents.marriageCertificate, 'marriageCertificate')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'marriageCertificate')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>
                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.marriageCertificate')">
                  {{ errors.first("documentsInfoform.marriageCertificate") }}
                </span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.marriageCertificate"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.slgI20, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.marriageCertificate, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>

              </div>
              <div class="vx-col w-full"
                v-if="canRenderField('h4Ead', fieldsArray, false, 'documents', 'h4Ead') && checkImmigrantStatus">
                <label class="custom-label">
                  {{ "h4Ead" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'h4Ead', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
                </label>
                <file-upload v-model="documents.h4Ead" class="file-upload-input" name="h4Ead"
                  data-vv-as="Copies of EAD cards" :accept="allDocEntity" :multiple="true" ref="h4Ead"
                  :hideSelected="true" @input="upload(documents.h4Ead, 'h4Ead')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'h4Ead')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>
                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.h4Ead')">
                  {{ errors.first("documentsInfoform.h4Ead") }}
                </span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.h4Ead"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.slgI20, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.h4Ead, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>

              </div>
            </template>
            <!-- v-else -->
            <template>
              <div class="vx-col w-full"
                v-if="canRenderField('marriageCertificate', fieldsArray, false, 'documents', 'marriageCertificate')">
                <label class="custom-label">
                  {{ "marriageCertificate" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'marriageCertificate', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
                </label>
                <file-upload v-model="documents.marriageCertificate" class="file-upload-input" name="marriageCertificate"
                  data-vv-as="Copies of EAD cards" :accept="allDocEntity" :multiple="true" ref="marriageCertificate"
                  :hideSelected="true" @input="upload(documents.marriageCertificate, 'marriageCertificate')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'marriageCertificate')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>
                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.marriageCertificate')">
                  {{ errors.first("documentsInfoform.marriageCertificate") }}
                </span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.marriageCertificate"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.slgI20, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.marriageCertificate, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>

              </div>

            </template>

            <!-- v-if="checkProperty(this.petitionDetails, 'subTypeDetails', 'id') == 15" -->
            <template>

              <!----  
                            slgEduCredentials:false, Education certification
                            slgEvalOfEduCredentials:false, Evaluation of Education certification
                          slgExpLetters:false Letters of Experience
                          
                            slgPassportAndVisa:false,
                            slgCurPrevH1BH4ApprovalsByINS:false, 
                            slgAdvancedDegrees:false
                            --->
              <div class="vx-col w-full" v-if="canRenderField('slgResume', fieldsArray, false, 'documents', 'slgResume')">
                <label class="custom-label">
                  {{ "slgResume" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'slgResume', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
                </label>



                <file-upload v-model="documents.slgResume" class="file-upload-input" name="slgResume"
                  data-vv-as="Current Resume- Please mention the accurate names of the employer and periods of employment. Do not state the client names"
                  :accept="allDocEntity" :multiple="true" ref="slgResume" :hideSelected="true"
                  @input="upload(documents.slgResume, 'slgResume')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'slgResume')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>


                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.slgResume')">{{
                  errors.first("documentsInfoform.slgResume")
                }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.slgResume"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.slgResume, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.slgResume, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>

              <div class="vx-col w-full"
                v-if="canRenderField('slgEduCredentials', fieldsArray, false, 'documents', 'slgEduCredentials')">
                <label class="custom-label">
                  {{ "slgEduCredentials" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'slgEduCredentials', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
                </label>



                <file-upload v-model="documents.slgEduCredentials" class="file-upload-input" name="slgEduCredentials"
                  data-vv-as="Education certification" :accept="allDocEntity" :multiple="true" ref="slgEduCredentials"
                  :hideSelected="true" @input="upload(documents.slgEduCredentials, 'slgEduCredentials')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'slgEduCredentials')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>


                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.slgEduCredentials')">{{
                  errors.first("documentsInfoform.slgEduCredentials")
                }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.slgEduCredentials"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.slgEduCredentials, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }}</vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.slgEduCredentials, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>


              <div class="vx-col w-full"
                v-if="canRenderField('slgEvalOfEduCredentials', fieldsArray, false, 'documents', 'slgEvalOfEduCredentials')">
                <label class="custom-label">
                  {{ "slgEvalOfEduCredentials" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'slgEvalOfEduCredentials', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
                </label>



                <file-upload v-model="documents.slgEvalOfEduCredentials" class="file-upload-input"
                  name="slgEvalOfEduCredentials" data-vv-as="Evaluation of Education certification" :accept="allDocEntity"
                  :multiple="true" ref="slgEvalOfEduCredentials" :hideSelected="true"
                  @input="upload(documents.slgEvalOfEduCredentials, 'slgEvalOfEduCredentials')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'slgEvalOfEduCredentials')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>


                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.slgEvalOfEduCredentials')">{{
                  errors.first("documentsInfoform.slgEvalOfEduCredentials")
                }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.slgEvalOfEduCredentials"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.slgEvalOfEduCredentials, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.slgEvalOfEduCredentials, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>
              <div class="vx-col w-full"
                v-if="canRenderField('slgEvalOfEduExpCredentials', fieldsArray, false, 'documents', 'slgEvalOfEduExpCredentials')">
                <label class="custom-label">
                  {{ "slgEvalOfEduExpCredentials" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'slgEvalOfEduExpCredentials', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
                </label>



                <file-upload v-model="documents.slgEvalOfEduExpCredentials" class="file-upload-input"
                  name="slgEvalOfEduExpCredentials" data-vv-as="Evaluation of Education certification."
                  :accept="allDocEntity" :multiple="true" ref="slgEvalOfEduExpCredentials" :hideSelected="true"
                  @input="upload(documents.slgEvalOfEduExpCredentials, 'slgEvalOfEduExpCredentials')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'slgEvalOfEduExpCredentials')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>


                <span class="text-danger text-sm-doc"
                  v-show="errors.has('documentsInfoform.slgEvalOfEduExpCredentials')">{{
                    errors.first("documentsInfoform.slgEvalOfEduExpCredentials")
                  }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.slgEvalOfEduExpCredentials"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.slgEvalOfEduExpCredentials, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.slgEvalOfEduExpCredentials, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>

              <div class="vx-col w-full"
                v-if="canRenderField('slgTransScripts', fieldsArray, false, 'documents', 'slgTransScripts')">
                <label class="custom-label">
                  {{ "slgTransScripts" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'slgTransScripts', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
                </label>



                <file-upload v-model="documents.slgTransScripts" class="file-upload-input" name="slgTransScripts"
                  data-vv-as="Transcripts/Marks memo’s" :accept="allDocEntity" :multiple="true" ref="slgTransScripts"
                  :hideSelected="true" @input="upload(documents.slgTransScripts, 'slgTransScripts')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'slgTransScripts')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>


                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.slgTransScripts')">{{
                  errors.first("documentsInfoform.slgTransScripts")
                }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.slgTransScripts"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.slgTransScripts, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.slgTransScripts, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>

              <div class="vx-col w-full"
                v-if="canRenderField('slgExpLetters', fieldsArray, false, 'documents', 'slgExpLetters')">
                <label class="custom-label">
                  {{ "slgExpLetters" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'slgExpLetters', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
                </label>



                <file-upload v-model="documents.slgExpLetters" class="file-upload-input" name="slgExpLetters"
                  data-vv-as="Letters of Experience" :accept="allDocEntity" :multiple="true" ref="slgExpLetters"
                  :hideSelected="true" @input="upload(documents.slgExpLetters, 'slgExpLetters')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'slgExpLetters')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>


                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.slgExpLetters')">{{
                  errors.first("documentsInfoform.slgExpLetters")
                }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.slgExpLetters"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.slgExpLetters, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.slgExpLetters, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>

              <div class="vx-col w-full"
                v-if="canRenderField('slgPassportAndVisa', fieldsArray, false, 'documents', 'slgPassportAndVisa')">
                <label class="custom-label">
                  {{ "slgPassportAndVisa" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'slgPassportAndVisa', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
                </label>



                <file-upload v-model="documents.slgPassportAndVisa" class="file-upload-input" name="slgPassportAndVisa"
                  data-vv-as="Copy of New and Old Passport " :accept="allDocEntity" :multiple="true"
                  ref="slgPassportAndVisa" :hideSelected="true"
                  @input="upload(documents.slgPassportAndVisa, 'slgPassportAndVisa')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'slgPassportAndVisa')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>


                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.slgPassportAndVisa')">{{
                  errors.first("documentsInfoform.slgPassportAndVisa")
                }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.slgPassportAndVisa"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.slgPassportAndVisa, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.slgPassportAndVisa, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>
              <!---- slgCurPrevH1BH4ApprovalsByINS:false, 
                slgAdvancedDegrees:false
                --->
              <div class="vx-col w-full"
                v-if="canRenderField('slgCurPrevH1BH4ApprovalsByINS', fieldsArray, false, 'documents', 'slgCurPrevH1BH4ApprovalsByINS')">
                <label class="custom-label">
                  {{ "slgCurPrevH1BH4ApprovalsByINS" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'slgCurPrevH1BH4ApprovalsByINS', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
                </label>



                <file-upload v-model="documents.slgCurPrevH1BH4ApprovalsByINS" class="file-upload-input"
                  name="slgCurPrevH1BH4ApprovalsByINS" data-vv-as="Previous H1B & H4 Approvals by INS"
                  :accept="allDocEntity" :multiple="true" ref="slgCurPrevH1BH4ApprovalsByINS" :hideSelected="true"
                  @input="upload(documents.slgCurPrevH1BH4ApprovalsByINS, 'slgCurPrevH1BH4ApprovalsByINS')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader"
                    v-if="checkProperty(doCumentsAreUploadingToS3, 'slgCurPrevH1BH4ApprovalsByINS')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>


                <span class="text-danger text-sm-doc"
                  v-show="errors.has('documentsInfoform.slgCurPrevH1BH4ApprovalsByINS')">{{
                    errors.first("documentsInfoform.slgCurPrevH1BH4ApprovalsByINS")
                  }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.slgCurPrevH1BH4ApprovalsByINS"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.slgCurPrevH1BH4ApprovalsByINS, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.slgCurPrevH1BH4ApprovalsByINS, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>
              <div class="vx-col w-full"
                v-if="canRenderField('slgAdvancedDegrees', fieldsArray, false, 'documents', 'slgAdvancedDegrees')">
                <label class="custom-label">
                  {{ "slgAdvancedDegrees" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'slgAdvancedDegrees', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
                </label>



                <file-upload v-model="documents.slgAdvancedDegrees" class="file-upload-input" name="slgAdvancedDegrees"
                  data-vv-as="Adavanced Degree Certificate" :accept="allDocEntity" :multiple="true"
                  ref="slgAdvancedDegrees" :hideSelected="true"
                  @input="upload(documents.slgAdvancedDegrees, 'slgAdvancedDegrees')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'slgAdvancedDegrees')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>


                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.slgAdvancedDegrees')">{{
                  errors.first("documentsInfoform.slgAdvancedDegrees")
                }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.slgAdvancedDegrees"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.slgAdvancedDegrees, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.slgAdvancedDegrees, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>


            </template>
            <!-- v-if="checkProperty(this.petitionDetails, 'subTypeDetails', 'id') == 16" -->
            <template>

              <!-- w2:[],
                            slgEvalOfEduCredentials:[],
                            slgPrevImmApprovalNotices:[], -->

              <div class="vx-col w-full" v-if="canRenderField('w2', fieldsArray, false, 'documents', 'w2')">
                <label class="custom-label">
                  {{ "w2" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'w2', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
                </label>



                <file-upload v-model="documents.w2" class="file-upload-input" name="w2" data-vv-as="Copy of all w2."
                  :accept="allDocEntity" :multiple="true" ref="w2" :hideSelected="true"
                  @input="upload(documents.w2, 'w2')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'w2')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>


                <span class="text-danger text-sm-doc" v-show="errors.has('documentsInfoform.w2')">{{
                  errors.first("documentsInfoform.w2")
                }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.w2"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.w2, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.w2, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>

              <div class="vx-col w-full"
                v-if="canRenderField('slgPrevImmApprovalNotices', fieldsArray, false, 'documents', 'slgPrevImmApprovalNotices')">
                <label class="custom-label">
                  {{ "slgPrevImmApprovalNotices" | formatdoctype }} <em
                    v-if="checkFieldIsRequired({ 'key': 'slgPrevImmApprovalNotices', 'section': 'documents', 'fieldsArray': fieldsArray, 'required': false })">*</em>
                </label>



                <file-upload v-model="documents.slgPrevImmApprovalNotices" class="file-upload-input"
                  name="slgPrevImmApprovalNotices"
                  data-vv-as="Copy of all Previous Immigrant Approval Notices (e.g., H-1B, H-4, L-1A, L-1B, L-2 etc.,)."
                  :accept="allDocEntity" :multiple="true" ref="slgPrevImmApprovalNotices" :hideSelected="true"
                  @input="upload(documents.slgPrevImmApprovalNotices, 'slgPrevImmApprovalNotices')">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                  Upload
                  <span class="loader" v-if="checkProperty(doCumentsAreUploadingToS3, 'slgPrevImmApprovalNotices')"><img
                      src="@/assets/images/main/loader.gif"></span>
                </file-upload>


                <span class="text-danger text-sm-doc"
                  v-show="errors.has('documentsInfoform.slgPrevImmApprovalNotices')">{{
                    errors.first("documentsInfoform.slgPrevImmApprovalNotices")
                  }}</span>
                <ul class="uploaded-list">
                  <template v-for="(item, index) in documents.slgPrevImmApprovalNotices"
                    v-if="(([51].indexOf(getUserRoleId) > -1 && item.uploadedByRoleId == 51) || ([51].indexOf(getUserRoleId) <= -1))">
                    <template v-if="callFromEdit">
                      <vs-chip @click="remove(item, documents.slgPrevImmApprovalNotices, index)" :key="index"
                        :closable="checkProperty(item, 'isNew')" v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                    <template v-else>
                      <vs-chip @click="remove(item, documents.slgPrevImmApprovalNotices, index)" :key="index" closable
                        v-if="item.status !== false && item['path']">
                        <img src="@/assets/images/main/down-arrow2.svg" @click="$emit('downloadOrView', item)" />
                        {{ item.name }} </vs-chip>
                    </template>
                  </template>
                </ul>
              </div>
            </template>
          </template>

        </div>
      </div>
    </vs-col>
    <template v-if="callFromEdit">
      <div @click="formerrors.msg = ''" class="text-danger text-sm formerrors" v-show="formerrors.msg">
        <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
          icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
      </div>

      <div class="popup-footer mt-4 relative">
        <button class="btn cancel" @click="$emit('openEditDocs', false)">Cancel</button>
        <button class="btn save" @click="updateDocumentsAction()" :disabled="checkFilesUploading">
          <figure class="loader" v-if="documensUpdating"><img src="@/assets/images/main/loader.gif" /></figure>
          <span>Update</span>
        </button>
      </div>
    </template>


  </form>
</template>

<script>
import _ from "lodash";

import moment from "moment";
import FileUpload from "vue-upload-component/src";
export default {
  inject: ["parentValidator"],

  props: {
    fieldsArray: [],
    petitionDetails: null,
    questionnaireDetails: null,
    callFromEdit: false,
    documents: {
      type: Object,
      default: {
        //h4 documents
         
          priorH4Approvals: [],
          passport:[],
          usVisa: [],
          mostRecentI94: [],
          ssnCard: [],
          eadCard: [],
          // marriageCertificate:[],
          
          // other:[],
          //h4 documents

        passportVisaI94: [],
        passport: [],
        resume: [],
        education: [],
        ssn: [],
        travelHistory: [],
        expLetters: [],
        INSNotices: [],

        formI20: [],
        I797NoticeofApprovalforI140: [],
        socialSecurityCardAndProfLicense: [],
        I140ApprovalNotice: [],
        payStubs: [],
        offerLetter: [],

        clientLetter: [],
        vendorLetter: [],
        ead: [],
        msa: [],
        po: [],
        h1bRegSelectionNotice: [],
        employmentAgreement: [],
        primeVendor: [],
        formI94: [],
        priorFormI797: [],
        other: [],


        slgPrevImmApprovalNotices: [],
        w2: [],
        slgResume: [],
        slgCollegeDegreesCert: [],
        slgExpLetters: [],
        slgPassportAndVisa: [],
        slgI94: [],
        slgPrevNonimmApprovalNotices: [],
        slgI140OrPermNoties: [],
        slgPrevLaborApplications: [],
        slgAckOfPrevLaborApplications: [],
        slgPaystubs: [],
        slgI20: [],
        slgEad: [],

        slgResume: [],
        slgEduCredentials: [],
        slgEvalOfEduCredentials: [],
        slgEvalOfEduExpCredentials: [],
        slgTransScripts: [],
        slgExpLetters: [],
        slgPassportAndVisa: [],
        slgCurPrevH1BH4ApprovalsByINS: [],
        slgAdvancedDegrees: [],

        //New Document 04/04/2023
        formI797H4ApprovalNotice: [],
        formI797H1BApprovalNoticePrinNonCtzn: [],
        passportOfPrinNonCtzn: [],
        last3MonthsPayslipsOfPrinNonCtzn: [],
        marriageCertificate: [],
        h4Ead: [],
        //New Document 04/04/2023 END
        // Spouse Added  Docs
        bnfSpouseLatestI797: [],
        bnfSpousePassport: [],
        bnfSpouseRecentPayStubs: [],
        bnfSpouseFormAllI20: [],
      }
    },

  },
  data() {
    return {
      newDocs: [],
      doCumentsAreUploadingToS3: {

       //h4 documents
        usVisa: false,
        mostRecentI94: false,
        ssnCard: false,
        eadCard: false,
        // marriageCertificate:false,
        priorH4Approvals: false,
        // other:false,
        //h4 documents  

        birthCertificate: false,
        passportVisaI94: false,
        passport: false,
        resume: false,
        education: false,
        ssn: false,
        travelHistory: false,
        expLetters: false,
        INSNotices: false,

        formI20: false,
        I797NoticeofApprovalforI140: false,
        socialSecurityCardAndProfLicense: false,
        I140ApprovalNotice: false,
        payStubs: false,
        offerLetter: false,

        clientLetter: false,
        vendorLetter: false,
        ead: false,
        msa: false,
        po: false,
        h1bRegSelectionNotice: false,
        employmentAgreement: false,
        primeVendor: false,
        formI94: false,
        priorFormI797: false,
        other: false,


        // slgResume: false,
        slgCollegeDegreesCert: false,
        slgPrevImmApprovalNotices: false,
        w2: false,
        // slgTransScripts: [],
        //slgExpLetters: [],
        //   slgPassportAndVisa: [],
        slgI94: false,
        slgPrevNonimmApprovalNotices: false,
        slgI140OrPermNoties: false,
        slgPrevLaborApplications: false,
        slgAckOfPrevLaborApplications: false,
        slgPaystubs: false,
        slgI20: false,
        slgEad: false,

        slgResume: false,
        slgEduCredentials: false,
        slgEvalOfEduCredentials: false,
        slgEvalOfEduExpCredentials: false,
        slgTransScripts: false,
        slgExpLetters: false,
        slgPassportAndVisa: false,
        slgCurPrevH1BH4ApprovalsByINS: false,
        slgAdvancedDegrees: false,

        //New Document 04/04/2023
        formI797H4ApprovalNotice: false,
        formI797H1BApprovalNoticePrinNonCtzn: false,
        passportOfPrinNonCtzn: false,
        last3MonthsPayslipsOfPrinNonCtzn: false,
        marriageCertificate: false,
        h4Ead: false,
        //New Document 04/04/2023 END
        // spouse Docs
        bnfSpouseLatestI797: false,
        bnfSpousePassport: false,
        bnfSpouseRecentPayStubs: false,
        bnfSpouseFormAllI20: false,


      },
      documensUpdating: false,
      formerrors: {
        "msg": ''
      },
      

    }
  },

  created() {
    this.$validator = this.parentValidator;
  },
  methods: {
    checkTemplateField(checkKey = "") {
      let return_value = true;
      if (checkKey != "" && _.has(this.questionnaireDetails, "fields")) {
        return_value =
          _.findIndex(this.questionnaireDetails.fields, (el) => {
            return el == checkKey;
          }) > -1
            ? true
            : false;
      }

      //this.$validator.reset();

      return return_value;
    },
    updateDocumentsAction() {

      Object.assign(this.formerrors, { msg: "" });
      this.$validator.validateAll('documentsInfoform').then((result) => {
        if (result) {
          this.creatingNew = true;
          let postData = {
            "documents": {},
            "typeName": "",
            "subTypeName": "",
            "petitionId": '',
            "today": null

          }

          let documents = {}
          let isUploaded = false
          _.forEach(Object.entries(this.documents), (val, key) => {

            if (this.checkProperty(val, "length") > 1) {
              let docKey = val[0];
              let docs = val[1];
              documents[docKey] = []
              let newDocuments = _.filter(docs, { "isNew": true })
              if (this.checkProperty(newDocuments, "length") > 0) {
                isUploaded = true;
                documents[docKey] = newDocuments
              }
            }
          })

          if (!isUploaded) {
            Object.assign(this.formerrors, { msg: 'Atleast one document is required.' });
            return true;

          }
          postData['documents'] = _.cloneDeep(documents);
          postData['typeName'] = this.checkProperty(this.getPetitionDetails, "typeDetails", "name")
          postData['subTypeName'] = this.checkProperty(this.getPetitionDetails, "subTypeDetails", "name")
          postData['petitionId'] = this.checkProperty(this.getPetitionDetails, "_id");
          postData['today'] = moment().format("YYYY-MM-DD")
          this.documensUpdating = true;
          let path = "/petition/add-additional-documents";
          if (this.checkProperty(this.getPetitionDetails, 'type') == 3 && [15].indexOf(this.checkProperty(this.getPetitionDetails, 'subTypeDetails', 'id')) > -1) {
            path = "/perm/add-additional-documents";
          }


          this.$store.dispatch("commonAction", { "data": postData, "path": path })
            .then(response => {

              //lca_request_msg

              this.showToster({ message: response.message, isError: false });
              this.documensUpdating = false;
              this.$emit('reloadCaseDetails')


            })
            .catch((error) => {
              Object.assign(this.formerrors, { msg: error });
              this.documensUpdating = false;
            })
        }
      })

    },
    remove(item, type, index = -1) {
      item.status = false;
      type[type.indexOf(item)] = item;
      if (this.checkProperty(item, 'isNew') && index > -1) {
        type.splice(index, 1)

      }
      return false;
    },
    upload(model, type = '') {

      let mapper = model.map(
        (item) =>
        (item = {
          name: item.name,
          file: item.file ? item.file : null,
          size: item.size ? item.size : 0,
          url: item.url ? item.url : "",
          path: item.path ? item.path : "",
          isNew: item.isNew ? item.isNew : false,
          uploadedBy: item.uploadedBy ? item.uploadedBy : this.checkProperty(this.getUserData, 'userId') != '' ? this.checkProperty(this.getUserData, 'userId') : null,
          uploadedByName: item.uploadedByName ? item.uploadedByName : this.checkProperty(this.getUserData, 'name') != '' ? this.checkProperty(this.getUserData, 'name') : '',
          uploadedByRoleId: item.uploadedByRoleId ? item.uploadedByRoleId : this.getUserRoleId ? this.getUserRoleId : null,
          uploadedByRoleName: item.uploadedByRoleName ? item.uploadedByRoleName : this.checkProperty(this.getUserData, 'loginRoleName'),

          // docTypeName : item.docTypeName?item.docTypeName:'',
          status:
            item.status === false || item.status === true
              ? item.status
              : true,
          mimetype: item.type ? item.type : item.mimetype,
        })
      );
      if (mapper.length > 0) {
        this.doCumentsAreUploadingToS3[type] = true;
        mapper.forEach((doc, index) => {
          if (doc.file) {
            let formData = new FormData();
            formData.append("files", doc.file);
            formData.append("secureType", "private");
            formData.append("getDetails", true);
            this.$store.dispatch("uploadS3File", formData).then((response) => {
              response.data.result.forEach((urlGenerated) => {
                doc.isNew = true;
                //  doc.docTypeName = docTypeName;
                doc.url = urlGenerated['path'];
                doc.path = urlGenerated['path'];
                if (_.has(urlGenerated, 'size')) {
                  doc['size'] = urlGenerated['size'];
                }
                delete doc.file;
                mapper[index] = doc;
              });
              this.doCumentsAreUploadingToS3[type] = false;
            });
          }
        });
        model.splice(0, mapper.length, ...mapper);
      }
    },

  },
  mounted() {


    if (this.checkProperty(this.petitionDetails, 'documents')) {
      // this.documents = this.checkProperty(this.getPetitionDetails ,'documents');
      _.forEach(Object.entries(this.petitionDetails['documents']), (val, key) => {


        if (this.checkProperty(val, "length") > 1) {

          let docKey = val[0];

          let docs = val[1];

          _.forEach(docs, (dcoItem) => {
            dcoItem['isNew'] = false

          })


          this.documents[docKey] = docs;


        }
      })

    }

    // this.documents = this.tempDocuments
    try {
      this.$validator.reset();
    } catch (e) {
      console.error(e)
    }

  },
  components: {
    FileUpload
  },
  computed: {
    checkImmigrantStatus() {
      let returnVal = false;
      if (this.petitionDetails && this.checkProperty(this.petitionDetails, 'beneficiaryInfo', 'curNonImmigrantVisaStatus') && this.checkProperty(this.petitionDetails, 'beneficiaryInfo', 'curNonImmigrantVisaStatus') == 7) {
        returnVal = true;
      }
      return returnVal
    },
    checkFilesUploading() {
      let returnVal = false;
      let loadingItems = []
      _.map(this.doCumentsAreUploadingToS3, (val, key) => {
        if (val) {

          loadingItems.push(key)
        }

      })
      if (this.checkProperty(loadingItems, 'length') > 0) {
        returnVal = true;
      }
      return returnVal;
    }
  }


}
</script>