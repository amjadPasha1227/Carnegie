<template>
    <div class="block-layout questionnaire" id="scrollableques" :class="{'padt20':!checkCurrentUrl}">
        <div class="vx-col w-full wizard-container form_section  questionnairesection pad0 case-form-v2">
            <div class="questionnaire_page" id="questionnaire_page" v-if="(petition && questionnaireDetails!=null ) || true">
                <div class="questionnaire_sec">
                    <div class="questionnaire_titles" v-if="(petition && questionnaireDetails!=null) || true">
                        <div class="questionnaire_titles_info">
                            <!---<h2 v-if="petition.typeDetails">  Questionnaire for {{petition.typeDetails.name}}
                                <small v-if="petition.subTypeDetails">{{petition.subTypeDetails.name}}</small>
                            </h2>
                          -->
                            <h2 > Questionnaire for PERM </h2>
  
                            <p>
                                Please take a few moments to complete this short registration form
                            </p>
                           
                            <ul>
                                <template v-for="(item,index) in tabslist">
                                    <li :key="index" :class="{'active':currentTab==item.key || (index<=checkActiveTab && currentTab!=item.key)} " @click="setActiveTab(item.key,true)">
                                        <span>{{index+1}}</span><a>{{item.name}} </a>
                                    </li>
    
                                </template>
    
                            </ul>
                        </div>
                        <figure><img src="@/assets/images/main/content-bottom-image.svg" /></figure>
                    </div>
                    
                   
                    <div class="questionnaire_form">
                     
                      <vs-col class="w-full p-0" v-if="checkProperty(petition ,'_id') && beneFiciaryDeytailsExists == false && ['permapplicationSuggession-questionnaire','permapplication-questionnaire'].indexOf(currentRouteName)<=-1">
                                      <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal" icon="IP-information-button" active="true">
                                          Note: You can enter certain beneficiary information which is different from the profile information or new information in the case application.
                                          However, you can decide at the time of application submission if you want those change information to be updated in the beneficiary profile.
                                      </vs-alert>
                                  </vs-col>
                       <div  v-if="currentTab=='permApplicationScope'" >
                          
  
                          <form @submit.prevent data-vv-scope="permApplicationScopeform" class="trackingform">
                          <vs-col class="w-full p-0">
                              <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal" icon="IP-information-button" active="true">
                              NOTE: This questionnaire should be filled out completely and
                              accurately. Kindly read the instructions carefully.
                              </vs-alert>
  
                          </vs-col>
                          <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="10" vs-sm="12">
                              <div class="form-container pt-10">
                              <h3 class="small-header">Alien Information</h3>
                              <div class="vx-row">
                                 
  
                              <div class="vs-col w-full"  >
                              <redioButtons
                              :wrapclass="''"
                              :cid="'isTrainigRequired'"
                               :tplsection="'alienInfo'"  :fieldName="'isTrainigRequired'" 
                              formscope="permApplicationScopeform"
                              v-model="petition.alienInfo.isTrainigRequired"
                              :tplkey="'isTrainigRequired'"
                              label="Is training required for the job opportunity?"
                              placeHolder=""
                              />
  
                              <redioButtons
                              :wrapclass="''"
                              :cid="'isExpRequired'"
                               :tplsection="'alienInfo'"  :fieldName="'isExpRequired'" 
                              formscope="permApplicationScopeform"
                              v-model="petition.alienInfo.isExpRequired"
                              :tplkey="'isExpRequired'"
                              label="Is experience in the job offered required for the job?"
                              placeHolder=""
                              />
  
                              <redioButtons
                              :wrapclass="''"
                              :cid="'isAltCombOfEduAndExpAccept'"
                               :tplsection="'alienInfo'"  :fieldName="'isAltCombOfEduAndExpAccept'" 
                              formscope="permApplicationScopeform"
                              v-model="petition.alienInfo.isAltCombOfEduAndExpAccept"
                              :tplkey="'isAltCombOfEduAndExpAccept'"
                              label="Is there an alternate combination of education and experience that is acceptable"
                              placeHolder=""
                              />
  
                              <redioButtons
                              :wrapclass="''"
                              :cid="'isExpInAltOccuAccept'"
                               :tplsection="'alienInfo'"  :fieldName="'isExpInAltOccuAccept'" 
                              formscope="permApplicationScopeform"
                              v-model="petition.alienInfo.isExpInAltOccuAccept"
                              :tplkey="'isExpInAltOccuAccept'"
                              label="Is experience in an alternate occupation acceptable?"
                              placeHolder=""
                              />
  
                              <redioButtons
                              :wrapclass="''"
                              :cid="'hasGainAnyExpWithEmplr'"
                               :tplsection="'alienInfo'"  :fieldName="'hasGainAnyExpWithEmplr'" 
                              formscope="permApplicationScopeform"
                              v-model="petition.alienInfo.hasGainAnyExpWithEmplr"
                              :tplkey="'hasGainAnyExpWithEmplr'"
                              label="Did the alien gain any of the qualifying experience with the employer in a position substantially comparable to the job opportunity requested?"
                              placeHolder=""
                              />
  
                              <redioButtons
                              :wrapclass="''"
                              :cid="'didEmplrPayForEdu'"
                               :tplsection="'alienInfo'"  :fieldName="'didEmplrPayForEdu'" 
                              formscope="permApplicationScopeform"
                              v-model="petition.alienInfo.didEmplrPayForEdu"
                              :tplkey="'didEmplrPayForEdu'"
                              label="Did the employer pay for any of the alien’s education or training necessary to satisfy any of the employer’s job requirements for this position?"
                              placeHolder=""
                              />
  
                              <redioButtons
                              :wrapclass="''"
                              :cid="'isWorkingWithPetngEmplr'"
                               :tplsection="'alienInfo'"  :fieldName="'isWorkingWithPetngEmplr'" 
                              formscope="permApplicationScopeform"
                              v-model="petition.alienInfo.isWorkingWithPetngEmplr"
                              :tplkey="'isWorkingWithPetngEmplr'"
                              label="Is the alien currently employed by the petitioning employer?"
                              placeHolder=""
                              />
  
  
  
                              </div>
                              </div>
                              <div class="divider"></div>
                              </div>
                          </vs-col> 
                          <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="10" vs-sm="12">
                              <div class="form-container pt-0">
                              <h3 class="small-header">Refiling Instructions</h3>
                              <div class="vx-row">
                              <div class="vs-col w-full">
  
                                  <!----
                                       refilingInstructions: {
            useFilingDateFromPrevSubtn: 'No',//String, // Yes/No // Are you seeking to utilize the filing date from a previously submitted Yes No Application for Alien Employment Certification (ETA 750)? 
            prevFilingDate: null ,//Date, // enter the previous filing date
            prevSWAOrLocalCaseNo: '',//String, // Indicate the previous SWA or local office case number OR if not available, specify state where case was originally filed
            caseFiledStateId: null,//Number, // Indicate the previous SWA or local office case number OR if not available, specify state where case was originally filed
            caseFiledStateDetails: null, //Object // Indicate the previous SWA or local office case number OR if not available, specify state where case was originally filed
        }
                                      ---->
                                    
                              <redioButtons
                              :wrapclass="''"
                              :cid="'refilingInstructions'"
                               :tplsection="'refilingInstructions'"  :fieldName="'useFilingDateFromPrevSubtn'" 
                              formscope="permApplicationScopeform"
                              v-model="petition.refilingInstructions.useFilingDateFromPrevSubtn"
                              :tplkey="'useFilingDateFromPrevSubtn'"
                              label="Are you seeking to utilize the filing date from a previously submitted application for Alien Employment Certification (ETA 750)?"
                              placeHolder=""
                              />
                              <datepickerField
                              v-if="checkProperty(petition['refilingInstructions'],'useFilingDateFromPrevSubtn')=='Yes'"
                              wrapclass="md:w-1/2"
                              :display="true"
                               :tplsection="'refilingInstructions'"  :fieldName="'prevFilingDate'" 
                              v-model="
                              petition['refilingInstructions'].prevFilingDate
                              "
                              :dateEnableTo="new Date()"
                              :formscope="'permApplicationScopeform'"
                              :tplkey="'prevFilingDate'"
                              label="Previous filing date"
                              :validationRequired="true"
                              />
  
                              <immiInput
                              v-if="checkProperty(petition['refilingInstructions'],'useFilingDateFromPrevSubtn')=='Yes'"
                              :wrapclass="'md:w-1/2 custom-form-label'"
                              :display="true"
                              cid="prevSWAOrLocalCaseNo"
                              :formscope="'permApplicationScopeform'"
                               :tplsection="'refilingInstructions'"  :fieldName="'prevSWAOrLocalCaseNo'" 
                              v-model="petition['refilingInstructions'].prevSWAOrLocalCaseNo"
                              :required="true"
                              :tplkey="'prevSWAOrLocalCaseNo'"
                              label="Indicate the previous SWA or local office case number OR if not available, specify state where case was originally filed."
                              placeHolder="Previous SWA or local office case number"
                              />
                              <!-- <selectField v-if="petition['refilingInstructions'].prevSWAOrLocalCaseNo" 
                                  :wrapclass="'md:w-1/2'" 
                                  :required="true"  
                                  cid="caseFiledStateId"  
                                  :formscope="'permApplicationScopeform'" 
                                  :optionslist="usStatusList" 
                                   :tplsection="'refilingInstructions'"  :fieldName="'caseFiledStateDetails'" 
                                  v-model="petition['refilingInstructions'].caseFiledStateDetails" 
                                  @input="updateState"   
                                 
                                  label="Specify state where case was originally filed" placeHolder="State"   />
                                 -->
  
                              </div>
  
  
                              </div>
  
                              </div>
                          </vs-col>      
  
  
                          </form>
                      </div>
                      
                        <div v-if="currentTab=='casedetails'" id="case_details_dt">
                            <form data-vv-scope="casedetailsform" @submit.prevent="" @keydown.enter.prevent="">
                                <vs-col class="w-full p-0">
                                    <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal" icon="IP-information-button" active="true">
                                        NOTE: This questionnaire should be filled out completely and
                                        accurately. Kindly read the instructions carefully.
                                    </vs-alert>
    
                                </vs-col>
  
  
                                
    
                                <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12">
                                    <div class="form-container pt-10 form-container-questionnaire">
                                        <div class="vx-row">
                                         
                                            <genderField :formScope="'casedetailsform'" :required="true" :display="false" :fieldsArray="questionnaireDetails" :gender="petition.beneficiaryInfo.gender" v-model="petition.beneficiaryInfo.gender" :tplsection="'beneficiaryInfo'" :tplkey="'gender'"  :fieldName="'gender'"  />
                                        
                                            <div class="divider full-divider mb-10"></div>
                                            
  
                                            <div class="vx-col w-full">
                                                <vx-input-group class="form-input-group FML">
                                                    <immiInput :display="false" :fieldsArray="questionnaireDetails" cid="benf" formscope="casedetailsform" v-model="petition.beneficiaryInfo.firstName" :tplsection="'beneficiaryInfo'" :tplkey="'firstName'"  :fieldName="'firstName'"  :required="false" label="First Name" placeHolder="First Name" />
                                                    <immiInput :display="false"  :fieldsArray="questionnaireDetails" cid="benm" formscope="casedetailsform" v-model="petition.beneficiaryInfo.middleName"  :tplsection="'beneficiaryInfo'" :tplkey="'middleName'"  :fieldName="'middleName'" :required="false" label="Middle Name" placeHolder="Middle Name" />
                                                    <immiInput :display="false"   :fieldsArray="questionnaireDetails" cid="benl" formscope="casedetailsform" v-model="petition.beneficiaryInfo.lastName"  :tplsection="'beneficiaryInfo'" :tplkey="'lastName'"  :fieldName="'lastName'" :required="false"  label="Last Name" placeHolder="Last Name" />
                                                </vx-input-group>
                                            </div>
                                           <template v-if="false">
                                              <div class="vx-col w-full mb-10">
                                                  <div class="d-flex align-center">
                                                      <a class="mr-3">
                                                          Have you ever used any other names previously?
                                                      </a>
                                                      <vs-switch v-model="petition.beneficiaryInfo.hasOtherNames" :tplsection="'beneficiaryInfo'" :tplkey="'hasOtherNames'"  :fieldName="'hasOtherNames'"  @input="resetOtherNames(petition.beneficiaryInfo.hasOtherNames)">
                                                          <span slot="on">Yes</span>
                                                          <span slot="off">No</span>
                                                      </vs-switch>
                                                  </div>
                                              </div>
                                              <template v-if="petition.beneficiaryInfo && petition.beneficiaryInfo.hasOtherNames">
                                                  <div class="vx-col w-full" v-for="(item, ind) in petition.beneficiaryInfo['otherNames']" :key="ind">
                                                      <vx-input-group class="form-input-group delete-rows-cst">
                                                          <immiInput  :display="false"   formscope="casedetailsform" :cid="'benf'+ind" v-model="item.firstName" :tplsection="'beneficiaryInfo.otherNames'" :tplkey="'firstName'"  :fieldName="'firstName'"  :required="true"  label="First Name" placeHolder="First Name" />
                                                          <immiInput :display="false"   formscope="casedetailsform" :cid="'benm'+ind" v-model="item.middleName" :tplsection="'beneficiaryInfo.otherNames'" :tplkey="'middleName'"  :fieldName="'middleName'"  :required="false"  label="Middle Name" placeHolder="Middle Name" />
                                                          <immiInput :display="false"   formscope="casedetailsform" :cid="'benl'+ind" v-model="item.lastName" :tplsection="'beneficiaryInfo.otherNames'" :tplkey="'lastName'"  :fieldName="'lastName'"  :required="item.firstName!=null && item.firstName!=''"  label="Last Name" placeHolder="Last Name" />
                                                          <div class="delete" v-if="ind > 0" @click="removeOtherName(ind)">
                                                              <a>
                                                                  <trash-2-icon size="1.5x" name="deletebenflm" class="custom-class"></trash-2-icon>
                                                              </a>
                                                          </div>
                                                      </vx-input-group>
                                                      <a class="add-more add-more-names" v-if="petition.beneficiaryInfo['otherNames'].length - 1 ==ind" @click="addOtherNames()"><span>+</span>Add</a>
                                                  </div>
                                              </template>
                                          </template>
                                          <immiInput  :display="false"   :fieldsArray="questionnaireDetails" datatype="email" wrapclass=" " cid="benfemail" formscope="casedetailsform" v-model="petition.beneficiaryInfo.email" :tplsection="'beneficiaryInfo'" :tplkey="'email'"  :fieldName="'email'"  :required="true"  label="Email" placeHolder="Email" /> 
                                            <immiPhone  :display="false" @updatephoneCountryCode="updatecellPhoneCountryCode"  :fieldsArray="questionnaireDetails" :countrycode="petition.beneficiaryInfo.cellPhoneCountryCode.countryCode" cid="bencellPhoneNumber" formscope="casedetailsform" v-model="petition.beneficiaryInfo.cellPhoneNumber" :tplsection="'beneficiaryInfo'" :tplkey="'cellPhoneNumber'"   :fieldName="'cellPhoneNumber'"   :required="true"  label="Phone Number" placeHolder="Phone Number" />
                                            <immiPhone :display="false" @updatephoneCountryCode="updatehomePhoneCountryCode" :fieldsArray="questionnaireDetails" :countrycode="petition.beneficiaryInfo.homePhoneCountryCode.countryCode" cid="benhomePhoneNumber" formscope="casedetailsform" v-model="petition.beneficiaryInfo.homePhoneNumber" :tplsection="'beneficiaryInfo'" :tplkey="'homePhoneNumber'"   :fieldName="'homePhoneNumber'"   label="Home Phone Number" placeHolder="Home Phone Number" />
                                            <immiPhone :display="false" @updatephoneCountryCode="updateworkPhoneCountryCode" :fieldsArray="questionnaireDetails" :countrycode="petition.beneficiaryInfo.workPhoneCountryCode.countryCode" cid="benworkPhoneNumber" formscope="casedetailsform" v-model="petition.beneficiaryInfo.workPhoneNumber" :tplsection="'beneficiaryInfo'" :tplkey="'workPhoneNumber'"   :fieldName="'workPhoneNumber'"    label="Work Phone Number" placeHolder="Work Phone Number" />
                                            <immiPhone :display="false" @updatephoneCountryCode="updatefaxCountryCode" :fieldsArray="questionnaireDetails" :countrycode="petition.beneficiaryInfo.faxCountryCode.countryCode" cid="benfaxPhoneNumber" formscope="casedetailsform" v-model="petition.beneficiaryInfo.fax"  :tplsection="'beneficiaryInfo'" :tplkey="'fax'"   :fieldName="'fax'"  label="Fax Number" placeHolder="Work Fax Number" />
                                            
                                            <datepickerField  :display="false"  :fieldsArray="questionnaireDetails" :dateEnableTo="startEligibleDate" :validationRequired="true" v-model="petition.beneficiaryInfo.dateOfBirth" :tplsection="'beneficiaryInfo'" :tplkey="'dateOfBirth'"  :fieldName="'dateOfBirth'"  formscope="casedetailsform"  label="Date of Birth" />
                                            <selectField  :display="false"  :fieldsArray="questionnaireDetails" @input="changeBfProvince" :required="true" :optionslist="countriesWithoutUS" v-model="petition.beneficiaryInfo.countryOfBirthDetails" :tplsection="'beneficiaryInfo'" :tplkey="'countryOfBirth'"   :fieldName="'countryOfBirth'"  formscope="casedetailsform"  label="Country of Birth" placeHolder="Country of Birth" />
                                            <selectField  :display="false" :fieldsArray="questionnaireDetails" @input="petition.beneficiaryInfo.provinceOfBirth = petition.beneficiaryInfo.provinceOfBirthDetails.id" :required="true" :optionslist="bfeprovinceStates" v-model="petition.beneficiaryInfo.provinceOfBirthDetails" :tplsection="'beneficiaryInfo'" :tplkey="'provinceOfBirth'"  :fieldName="'provinceOfBirth'"  formscope="casedetailsform"  label="Province of Birth" placeHolder="Province of Birth" />
                                            <immiInput  :display="false" :fieldsArray="questionnaireDetails" cid="benflocationOfBirth" formscope="casedetailsform" v-model="petition.beneficiaryInfo.locationOfBirth" :tplsection="'beneficiaryInfo'" :tplkey="'locationOfBirth'"  :fieldName="'locationOfBirth'"  :required="true"  label="Location of Birth" placeHolder="Location of Birth" />
                                            <selectField  :display="false" :fieldsArray="questionnaireDetails" @input="petition.beneficiaryInfo.countryOfCitizenship = petition.beneficiaryInfo.countryOfCitizenshipDetails.id" :required="true" :optionslist="countriesWithoutUS" v-model="petition.beneficiaryInfo.countryOfCitizenshipDetails" :tplsection="'beneficiaryInfo'" :tplkey="'countryOfCitizenship'"  :fieldName="'countryOfCitizenship'"  formscope="casedetailsform"  label="Country of Citizenship" placeHolder="Country of Citizenship" />
                                          
                                            <div v-if="false" class="divider full-divider mb-10"></div>
                                            <div class="vx-col w-full" v-if="false">
                                              <h3 class="small-header">Passport</h3>
                                          </div>
                                          
                                          <immiInput :allowUpperCase="true" :display="false" :helpText="'Make sure you input the most recent passport information. Also, note that the passport must have more than 6 months validity.'" :fieldsArray="questionnaireDetails" datatype="alpha_num|max:15" cid="benfpassportNumber" formscope="casedetailsform" v-model="petition.beneficiaryInfo.passportNumber" :tplsection="'beneficiaryInfo'" :tplkey="'passportNumber'"  :fieldName="'passportNumber'"  :required="true"  label="Passport" placeHolder="Passport" />
                                          
                                          <datepickerField :display="false" :fieldsArray="questionnaireDetails" :validationRequired="true" v-model="petition.beneficiaryInfo.passportIssuedDate" :tplsection="'beneficiaryInfo'" :tplkey="'passportIssuedDate'"  :fieldName="'passportIssuedDate'"  formscope="casedetailsform"  :dateEnableTo="featureDates" label="Passport Issued Date" />
                                      
                                          <datepickerField :display="false" :fieldsArray="questionnaireDetails" :dateEnableFrom="featureDates" :validationRequired="true" v-model="petition.beneficiaryInfo.passportExpiryDate" :tplsection="'beneficiaryInfo'" :tplkey="'passportExpiryDate'"  :fieldName="'passportExpiryDate'"  formscope="casedetailsform"  label="Passport Expiry Date" />
                                      
                                          <selectField :display="false" :fieldsArray="questionnaireDetails" @input="petition.beneficiaryInfo.curNonImmigrantVisaStatus = petition.beneficiaryInfo.curNonImmigrantVisaStatusDetails.id" :required="true" :optionslist="petition.visaStatusList" v-model="petition.beneficiaryInfo.curNonImmigrantVisaStatusDetails"  :tplsection="'beneficiaryInfo'" :tplkey="'curNonImmigrantVisaStatus'"  :fieldName="'curNonImmigrantVisaStatus'" formscope="casedetailsform"  label="Current Nonimmigrant Status" vvas="Nonimmigrant Status" placeHolder="Nonimmigrant Status" />
                                          <datepickerField :display="false" :fieldsArray="questionnaireDetails"  :validationRequired="true" v-model="petition.beneficiaryInfo.curVisaExpiryDate" :tplsection="'beneficiaryInfo'" :tplkey="'curVisaExpiryDate'"  :fieldName="'curVisaExpiryDate'"  formscope="casedetailsform"  :dateEnableFrom="new Date()" label="Current Status Expiry Date" />
                                          <immiInput :allowUpperCase="true" :display="false" :fieldsArray="questionnaireDetails" cid="benI94" datatype="max:15" formscope="casedetailsform" v-model="petition.beneficiaryInfo.I94" :tplsection="'beneficiaryInfo'"  :tplkey="'I94'"  :fieldName="'I94'"  :required="true"  label="I-94 Number" placeHolder="I-94 Number" />
                                          <datepickerField  :display="false"  :fieldsArray="questionnaireDetails" :dateEnableFrom="new Date()" :validationRequired="petition.beneficiaryInfo.I94!=null && petition.beneficiaryInfo.I94!=''" v-model="petition.beneficiaryInfo.I94ExpiryDate" :tplsection="'beneficiaryInfo'" :tplkey="'I94ExpiryDate'"  :fieldName="'I94ExpiryDate'"  formscope="casedetailsform"   label="I-94 Expiry Date" />                                        
                                           
                                          <datepickerField  :display="false"  :fieldsArray="questionnaireDetails" :validationRequired="true" v-model="petition.beneficiaryInfo.firstEntryDateOrApprovalInUsWithH1B" :tplsection="'beneficiaryInfo'"  :tplkey="'firstEntryDateOrApprovalInUsWithH1B'"  :fieldName="'firstEntryDateOrApprovalInUsWithH1B'"  formscope="casedetailsform" :dateEnableTo="featureDates"  label="First Entry Date or Approval in US With H1B" />                                        
                                          <datepickerField  :display="false"  :fieldsArray="questionnaireDetails" :validationRequired="true" v-model="petition.beneficiaryInfo.dateFifthYearOfHExpire" :tplsection="'beneficiaryInfo'"  :tplkey="'dateFifthYearOfHExpire'"  :fieldName="'dateFifthYearOfHExpire'"  formscope="casedetailsform" :dateEnableFrom="null"   label="Date Fifth Year of H1B Status Expires"  />                                        
                                          <immiMask :display="false"  :fieldsArray="questionnaireDetails" :patren="['### - ## - ####']" datatype="min:9|max:9" :wrapclass="canRenderField('ben_alienNumber',questionnaireDetails)?'md:w-1/2':' '" cid="benfSSN" formscope="casedetailsform" v-model="petition.beneficiaryInfo.SSN" :tplsection="'beneficiaryInfo'" :tplkey="'SSN'"  :fieldName="'SSN'"  :required="false"  label="Social Security Number (if applicable)" vvas="Social Security Number" placeHolder="123 - 45 - 6789" />
                                          <immiInput :display="false"  :fieldsArray="questionnaireDetails" datatype="alpha_num|max:9" cid="benfalienNumber" formscope="casedetailsform" v-model="petition.beneficiaryInfo.alienNumber"  :tplsection="'beneficiaryInfo'" :tplkey="'alienNumber'"  :fieldName="'alienNumber'"  label="Your Alien Number (if applicable)" placeHolder="Alien Number " />
                                           
                                        
                                          
                                                                                     
                                            <div class="vx-col w-full">
                                                
    
                                               
    
                                                <div v-if="canRenderField('currentAddress',questionnaireDetails,false ,'beneficiaryInfo') && countries.length>0">
                                                    <h3 class="small-header">Current Address</h3>
                                                    
                                                   
                                                    <addressField  :display="true"  :fieldsArray="questionnaireDetails" :disableCountry="false" formscope="casedetailsform" :showaptType="true" :addFormContainerCls="false" :countries="countries" v-model="petition.beneficiaryInfo.currentAddress" :tplsection="'beneficiaryInfo'"   :fieldName="'currentAddress'"  :validationRequired="checkFieldIsRequired({'key':'currentAddress','section':'beneficiaryInfo', 'fieldsArray':questionnaireDetails, 'required':true })" :cid="'currentAddress'" />
    
                                                </div>
                                                <div v-if="canRenderField('mailingAddress',questionnaireDetails,false ,'beneficiaryInfo')">
  
                                                  <div class="vx-col w-full d-flex">
                                                      <h3 class="small-header">Mailing Address</h3>
                                                      <vs-checkbox @change="setSameaddress()"  v-model="petition.beneficiaryInfo.mailingAddressIsSameAsAddress" :tplsection="'beneficiaryInfo'"  :fieldName="'mailingAddressIsSameAsAddress'" 
                                                      style="margin-left: 15px; margin-bottom:12px;">Same as Current Address </vs-checkbox
                                                      >
                                                  </div>
                                                  <template v-if="countries.length>0">
                                                      
                                                      <div>
                                                    <addressField   :display="true" :fieldsArray="questionnaireDetails" :disableCountry="petition.beneficiaryInfo.currentlyInUS" formscope="casedetailsform" :showaptType="true" :addFormContainerCls="false" :validationRequired="checkFieldIsRequired({'key':'mailingAddress','section':'beneficiaryInfo', 'fieldsArray':questionnaireDetails, 'required':true })" :countries="countries" v-model="petition.beneficiaryInfo.mailingAddress"  :tplsection="'beneficiaryInfo'"  :fieldName="'mailingAddress'" :cid="'beneficiarymailInfoaddress'" />
                                                    </div>
                                                  </template>
                                                </div>
                                            </div>
                                           
    
                                            <div class="vx-col w-full" v-if="canRenderField('ben_consulateInfo',questionnaireDetails) && false">
                                                <h3 class="small-header">Consulate you want to attend the visa interview</h3>
    
                                                <addressField  :display="true" fieldName="ben_consulateInfo" :fieldsArray="questionnaireDetails" :showLane1="false" :showLane2="false" :disableCountry="false" :showZip="false" formscope="casedetailsform" :showaptType="false" :addFormContainerCls="false" :countries="countries" v-model="petition.beneficiaryInfo.consulateInfo"  :tplsection="'beneficiaryInfo'"  :fieldName="'consulateInfo'" :cid="'consulateInfo'" />
    
                                            </div>
                                          
                                              <immipriorstay  :display="true" :fieldsArray="questionnaireDetails" formscope="casedetailsform"  fieldName="priorPeriodOfStayInUS" :petition="petition" v-model="petition.beneficiaryInfo.priorPeriodOfStayInUS" :tplsection="'beneficiaryInfo'"  :fieldName="'priorPeriodOfStayInUS'"  ></immipriorstay>
                                              <template v-if="canRenderField('anyOtherAlienFiled', questionnaireDetails ,false,'beneficiaryInfo.immPetitionInfo' )  && petition.beneficiaryInfo.immPetitionInfo">
                                                <div class="vx-col w-full" >
                                                    <h3 class="small-header">Immigrant Petition Information</h3>
                                                </div>
                                                <immiswitchyesno v-if="canRenderField('anyOtherAlienFiled', questionnaireDetails ,false,'beneficiaryInfo.immPetitionInfo' )" :required="checkFieldIsRequired({'key':'anyOtherAlienFiled','section':'beneficiaryInfo.immPetitionInfo', 'fieldsArray':questionnaireDetails, 'required':true })" :display="false" wrapclass=" " :fieldsArray="questionnaireDetails" :cid="'ben_ImmPetitionFiled'" formscope="casedetailsform" v-model="petition.beneficiaryInfo.immPetitionInfo.anyOtherAlienFiled" :tplsection="'beneficiaryInfo.immPetitionInfo'"  :fieldName="'anyOtherAlienFiled'"   label="Has any other Alien Employment Certification, a.k.a Labor Certification been filed on your behalf? " placeHolder="" />
                                                <template v-if="petition.beneficiaryInfo.immPetitionInfo.anyOtherAlienFiled">
                                                    <datepickerField :validationRequired="true" v-if="canRenderField('filedDate', questionnaireDetails ,false,'beneficiaryInfo.immPetitionInfo' )" wrapclass="md:w-1/2"  :display="false" :tplkey="'filedDate'" :fieldsArray="questionnaireDetails" v-model="petition.beneficiaryInfo.immPetitionInfo.filedDate"  :tplsection="'beneficiaryInfo.immPetitionInfo'"  :fieldName="'filedDate'"  formscope="casedetailsform"  :dateEnableTo="featureDates" label="Date Filed" />
                                                    <immiInput v-if="canRenderField('employerName', questionnaireDetails ,false,'beneficiaryInfo.immPetitionInfo' )" wrapclass="md:w-1/2"  :display="false" :tplkey="'employerName'" :fieldsArray="questionnaireDetails"  cid="benfalienNumber" formscope="casedetailsform" v-model="petition.beneficiaryInfo.immPetitionInfo.employerName" :tplsection="'beneficiaryInfo.immPetitionInfo'"  :fieldName="'employerName'"   label="Name of the Employer" placeHolder="Name of the Employer" />
                                                    <immiswitchyesno v-if="canRenderField('rirOrRegularProcessing', questionnaireDetails ,false,'beneficiaryInfo.immPetitionInfo' )" :required="checkFieldIsRequired({'key':'rirOrRegularProcessing','section':'beneficiaryInfo.immPetitionInfo', 'fieldsArray':questionnaireDetails, 'required':true })" :display="false" :tplkey="'rirOrRegularProcessing'" wrapclass=" " :fieldsArray="questionnaireDetails" :cid="'ben_rirOrRegularProcessing'" formscope="casedetailsform" v-model="petition.beneficiaryInfo.immPetitionInfo.rirOrRegularProcessing" :tplsection="'beneficiaryInfo.immPetitionInfo'"  :fieldName="'rirOrRegularProcessing'"   label="RIR or Regular Processing" placeHolder="" />
                                                    <selectField v-if="canRenderField('filedStateId', questionnaireDetails ,false,'beneficiaryInfo.immPetitionInfo' )" :display="false" :tplkey="'filedStateId'"  :fieldsArray="questionnaireDetails" @input="petition.beneficiaryInfo.immPetitionInfo.filedStateId = petition.beneficiaryInfo.immPetitionInfo.filedStateDetails.id"  :optionslist="usastates" v-model="petition.beneficiaryInfo.immPetitionInfo.filedStateDetails" :tplsection="'beneficiaryInfo.immPetitionInfo'"  :fieldName="'filedStateId'"  formscope="casedetailsform"  label="State where it was filed" placeHolder="State where it was filed" />
                                                    <immiInput v-if="canRenderField('applCurStatus', questionnaireDetails ,false,'beneficiaryInfo.immPetitionInfo' )" wrapclass="md:w-1/2"  :display="false" :tplkey="'applCurStatus'" :fieldsArray="questionnaireDetails"  cid="applCurStatus" formscope="casedetailsform" v-model="petition.beneficiaryInfo.immPetitionInfo.applCurStatus" :tplsection="'beneficiaryInfo.immPetitionInfo'"  :fieldName="'applCurStatus'"   label="Current Status of the Application" placeHolder="Current Status of the Application"/>
                                                </template>
                                                <immiswitchyesno  :required="checkFieldIsRequired({'key':'seekingFiledDateforETA750','section':'beneficiaryInfo.immPetitionInfo', 'fieldsArray':questionnaireDetails, 'required':true })" v-if="canRenderField('seekingFiledDateforETA750', questionnaireDetails ,false,'beneficiaryInfo.immPetitionInfo' ) && petition.beneficiaryInfo.immPetitionInfo.anyOtherAlienFiled" :display="false" :tplkey="'seekingFiledDateforETA750'" wrapclass=" " :fieldsArray="questionnaireDetails" :cid="'ben_seekingFiledDateforETA750'" formscope="casedetailsform" v-model="petition.beneficiaryInfo.immPetitionInfo.seekingFiledDateforETA750" :tplsection="'beneficiaryInfo.immPetitionInfo'"  :fieldName="'seekingFiledDateforETA750'" :wrapclass="'yesno-v1'"    label="Are you seeking to utilize the filing date from a previously submitted Application for Alien Employment Certification (ETA 750)?" placeHolder="" />
                                            </template>
                                            <immiyesorno :required="checkFieldIsRequired({'key':'previouslyMarried','section':'beneficiaryInfo', 'fieldsArray':questionnaireDetails, 'required':true })"  wrapclass=" "  :display="false" :fieldsArray="questionnaireDetails" formscope="casedetailsform" cid="previouslyMarried"  v-model="petition.beneficiaryInfo.previouslyMarried" :tplkey="'previouslyMarried'" :tplsection="'beneficiaryInfo'"  :fieldName="'previouslyMarried'"   label="Were you married previously?"></immiyesorno>
                                            <template v-if="checkProperty(petition,'beneficiaryInfo','previouslyMarried' ) && canRenderField('previousSpouse',questionnaireDetails, false, 'beneficiaryInfo.previousSpouse' ) && canRenderField('previouslyMarried',questionnaireDetails, false, 'beneficiaryInfo' )">
                                                <previousSpouseForm  :tplsection="'beneficiaryInfo.previousSpouse'" cid="ben_previousSpouse" formscope="casedetailsform" :countries="countries" :petition="petition" :fieldName="'previousSpouse'" :fieldsArray="questionnaireDetails" v-model="petition.beneficiaryInfo.previousSpouse"    />
                                            </template>
                                        </div>
                                    </div>
                                </vs-col>
                            </form>
                        </div>
  
                        <!-- (canRenderField('ben_educations', questionnaireDetails,) -->
                        <div v-if="currentTab=='education' && 
                        (canRenderField('educations', questionnaireDetails,false,'beneficiaryInfo.educations')|| canRenderField('vacationalOrTrainingInst', questionnaireDetails,false,'beneficiaryInfo.vacationalOrTrainingInst') ) " id="education_details">
                            <form   data-vv-scope="educationform" @submit.prevent="" @keydown.enter.prevent="">
                              
                              <vs-col class="w-full p-0">
                                    <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal" icon="IP-information-button" active="true">
                                        After your 12th grade – Starting from the most recent degree first
                                   
                                    </vs-alert>
    
                                </vs-col>
                                <template v-if="canRenderField('educations', questionnaireDetails,false,'beneficiaryInfo.educations')">
                                <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12">
                                 
                                    <div class="form-container pt-10 form-container-questionnaire">
                                      <h3 class="small-header">Educational Information</h3>
                                        <div class="vx-row mar0">
                                            <educationsList  :display="true"  :petition="petition" :countries="countries" :fieldsArray="questionnaireDetails"  cid="ben_educations"  sdsd="SR" formscope="educationform" v-model="petition.beneficiaryInfo.educations"  :tplsection="'beneficiaryInfo.educations'"  :fieldName="'educations'" />
    
                                        </div>
  
                                    </div>
                                </vs-col>
                              </template>
                                <template v-if="canRenderField('vacationalOrTrainingInst', questionnaireDetails,false,'beneficiaryInfo.vacationalOrTrainingInst')">
                                <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12">
                                  
                                  <div class="form-container pt-10 form-container-questionnaire">
                                      <div class="divider full-divider mb-10"></div>
                                      <h3 class="small-header">Vocational or Training</h3>
                                      <div class="vx-row mar0"> 
                                         
  
                                          <educationsList  :popupTitle="'Vocational or Training'" :display="true"  :petition="petition" :countries="countries" :fieldsArray="questionnaireDetails"  cid="ben_vacationalOrTrainingInst" formscope="educationform" v-model="petition.beneficiaryInfo.vacationalOrTrainingInst"  :tplsection="'beneficiaryInfo.vacationalOrTrainingInst'"  :fieldName="'vacationalOrTrainingInst'" />
  
                                      </div>
  
                                  </div>
                              </vs-col>
                          </template>
                                                       
                      </form>
                        </div>
                        <!-- ben_prevEmploymentInfo -->
                        <div v-if="currentTab=='employment' && (canRenderField('prevEmploymentInfo', questionnaireDetails, false, 'beneficiaryInfo.prevEmploymentInfo') ) " id="employment_details">
                            <form data-vv-scope="employmentform" @submit.prevent="" @keydown.enter.prevent="">
                                <vs-col class="w-full p-0">
                                    <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal" icon="IP-information-button" active="true">
                                        Provide your current and previous employment details, starting from the most recent first.
                                    </vs-alert>
    
                                </vs-col>
    
                                <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12">
                                    <div class="form-container form-container-questionnaire form-container-employment">
                                        <div class="vx-row">
    
                                            <immiemployment  :forPermQiestionnaire="true" :display="true"  :petition="petition" :countries="countries" :fieldsArray="questionnaireDetails"  cid="ben_prevEmploymentInfo" formscope="employmentform" v-model="petition.beneficiaryInfo.prevEmploymentInfo"  :tplsection="'beneficiaryInfo.prevEmploymentInfo'"  :fieldName="'prevEmploymentInfo'" />
    
                                        </div>
    
                                    </div>
                                </vs-col>
                            </form>
    
                        </div>
                        <div v-if="currentTab=='dependentsinfo' " id="dependentsinfo_details">
                            <form data-vv-scope="dependentsinfoform" @submit.prevent="" @keydown.enter.prevent="">
                                <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12">
                                    <div class="form-container pt-10 form-container-questionnaire">
                                        <div class="vx-row">
                                            <immiyesorno :cid="'hasSpouse'" formscope="dependentsinfoform" :required="checkFieldIsRequired({'key':'hasSpouse','section':'dependentsInfo.spouse', 'fieldsArray':questionnaireDetails, 'required':false })" :wrapclass="'h4_ead_label'"
                                             @input="spouseH4()" :display="false" :tplkey="'hasSpouse'" :fieldsArray="questionnaireDetails" v-model="petition.dependentsInfo.spouse.hasSpouse"  :tplsection="'dependentsInfo.spouse'"  :fieldName="'hasSpouse'"  label="Fill spouse information?"></immiyesorno>
                                            <div class="vx-col w-full">
                                                <div class="dependent-block_wrap" v-if="checkProperty(petition ,'dependentsInfo' ,'spouse' ) && petition.dependentsInfo && petition.dependentsInfo.spouse && petition.dependentsInfo.spouse.firstName!='' && petition.dependentsInfo.spouse.firstName!=null && checkProperty( petition['dependentsInfo'],'spouse', 'hasSpouse') ">
                                                    <div class="dependent-block">
                                                        <div class="dependent-title">
                                                            <h3> {{ formatFullname(petition.dependentsInfo.spouse) }}</h3>
                                                            <ul>
                                                                <li @click="editSpouse(petition.dependentsInfo.spouse)">
                                                                    <a><img src="@/assets/images/main/edit_icon.svg" />
                                                                    </a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                        <div class="dependent_details">
                                                            <ul>
                                                                <li v-if="petition.dependentsInfo.spouse.dateOfBirth"> Date of Birth <span>{{petition.dependentsInfo.spouse.dateOfBirth | formatDate}}</span></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <immiyesorno :cid="'hasChildren_hasChildren'" formscope="dependentsinfoform" :required="checkFieldIsRequired({'key':'hasChildren','section':'dependentsInfo.childrens', 'fieldsArray':questionnaireDetails, 'required':false })" @input="childH4()" :wrapclass="'h4_ead_label'" :display="false" :tplkey="'hasChildren'" :fieldsArray="questionnaireDetails" v-model="petition.hasRequiredForChildren" :tplsection="'dependentsInfo.childrens'"  :fieldName="'hasChildren'"    label="Do you have children?"></immiyesorno>
                                            <template v-if="petition.dependentsInfo.childrens && petition.dependentsInfo.childrens.length > 0 && petition.dependentsInfo.childrens[0].firstName!='' && petition.dependentsInfo.childrens[0].firstName!=null">
                                                <div class="vx-col w-full">
                                                    <div class="dependent-block_wrap">
                                                        <template v-for="(children, index) in petition.dependentsInfo.childrens">
                                                            <div class="dependent-block" v-if="children.saved" :key="index">
                                                                <div class="dependent-title" :key="index">
                                                                    <h3>
                                                                        {{ formatFullname(children) }}
                                                                    </h3>
                                                                    <ul>
                                                                        <li @click="editChildren(children,index)">
                                                                            <a><img src="@/assets/images/main/edit_icon.svg" />
                                                                            </a>
                                                                        </li>
                                                                    </ul>
                                                                </div>
    
                                                                <div class="dependent_details">
                                                                    <ul>
                                                                        <li v-if="children.dateOfBirth"> Date of Birth <span>{{children.dateOfBirth | formatDate}}</span></li>
                                                                         <li v-if="children.addressOutsideUS &&
                                                                        children.addressOutsideUS.countryDetails && children.addressOutsideUS.countryDetails.name
                                                                        
                                                                        "> Country <span>{{children.addressOutsideUS.countryDetails.name}}</span></li>
    
                                                                    </ul>
    
                                                                </div>
                                                            </div>
    
                                                        </template>
                                                    </div>
                                                </div>
                                            </template>
                                            <div style="margin-left:1rem;" vs-type="flex" vs-align="left" vs-lg="2" vs-sm="2" v-if="petition.hasRequiredForChildren">
                                                <a @click="addchildren" class="add-more ml-0" style="display:inline-block" type="filled">
                                                    <span>+</span> Add Child
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </vs-col>
                            </form>
                        </div>
                        <div v-if="currentTab=='documents'" id="documents_details">
                            <form data-vv-scope="documentsform" @submit.prevent="" @keydown.enter.prevent="">
                                <vs-col class="w-full p-0">
                                    <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal" icon="IP-information-button" active="true">
                                        NOTE: This questionnaire should be filled out completely and
                                        accurately. Kindly read the instructions carefully.
                                    </vs-alert>
    
                                </vs-col>
                               
                                <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12">
                                    <div class="form-container pt-10 form-container-questionnaire">
                                      <casedocumentslist @emitUploadingAction="emitUploadingAction" :docMainCategory="'bendocslist'"  :docslist="bendocslist" formscope="documentsform" :fieldsArray="questionnaireDetails" v-model="petition.documents" :tplsection="'documents'"  :fieldName="''" ></casedocumentslist>
    
                                    </div>
    
                                </vs-col>
    
                            </form>
    
                        </div>
                    </div>
                </div>
                <div class="questionnaire_footer">
                    <div class="d-flex">
                        <vs-button v-if="getIndexOfActivetab!=1" @click="goBack()" class="questionnaire_btn" type="filled">Back</vs-button>
                    </div>
                    <div class="d-flex">
                        <vs-button :disabled="documentUploading" v-if="(currentRouteName !='permapplication-questionnaire' && currentRouteName !='permapplicationSuggession-questionnaire')" @click="saveCase(true);" class="questionnaire_btn" type="filled">Save</vs-button>
                        <vs-button :disabled="documentUploading"  color="success" @click="submitCase();" class="save questionnaire_btn" type="filled">{{actiontype}}</vs-button>
    
                    </div>
                </div>
            </div>
    
        </div>
    
        <div class="custom_modal_sec preview_questionarie" :class="{ modalopen: questionnairePreview }">
            <div class="custom_modal_overlay" ></div>
    
            <div class="custom_modal_cnt">
                <div class="modal_title">
                    <h2>Questionnaire Review</h2>
                    <span @click="questionnairePreview = false">
                        <x-icon size="1.5x" class="close"></x-icon>
                    </span>
                </div>
                <div class="modal_cnt preview_content new_questionnaire_review">
                    <!-- <div v-if="beneFiciaryDeytailsExists == false">
                          <vs-col class="w-full p-0">
                              <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal" icon="IP-information-button" active="true">
                                  Note: You can enter certain beneficiary information which is different from the profile information or new information in the case application.
                                  However, you can decide at the time of application submission if you want those change information to be updated in the beneficiary profile.
                              </vs-alert>
  
                          </vs-col>
                      </div> -->
                    <VuePerfectScrollbar ref="mainSidebarPs1" :settings="settings">
                        <GCEmploymentdetailes v-if="questionnairePreview" :fieldsArrayDetails="questionnaireDetails" :loadedFromPreview="true"  :previewData="questionnairePreviewData"  />
                    </VuePerfectScrollbar>
                </div>
                <div class="questionnaire_footer">
                    <div class="d-flex">
                        <vs-button @click="questionnairePreview = false" class="cancel questionnaire_btn" type="filled">Cancel
                        </vs-button>
                        <vs-button v-if="false" @click="saveCase(false,false);" class="save questionnaire_btn" type="filled">Submit</vs-button>
                        <vs-button  @click="tempSave =false;showMessage = false; tempSave =false;showMessage = false; toggleBenProfileCOnformPopUp(true)" class="save questionnaire_btn" type="filled">Submit </vs-button>
                    </div>
                </div>
            </div>
        </div>
    
        <vs-popup class="holamundo success-popups" title="Your registration is complete." :active.sync="SuccessQuestionnaire">
            <figure>
                <img src="@/assets/images/main/icon-note.svg" alt="login" class="mx-auto" />
            </figure>
            <h2 class="title">Questionnaire submitted successfully!</h2>
            <template v-if="checkProperty($route ,'name') !='fill-questionnaire' && checkProperty($route ,'name') !='fill-perm-questionnaire' ">
            <p v-if="getUserData && checkProperty(getUserData['tenantDetails']['typeDetails'],'id') == 1">
                It will be reviewed by the petitioner and appropriate actions will be
                taken soon.
            </p>
            <p v-if="getUserData && checkProperty(getUserData['tenantDetails']['typeDetails'],'id') == 2">
              It will be reviewed by the Admin and appropriate actions will be
              taken soon.
          </p>
            </template>
        </vs-popup>
        <vs-popup class="holamundo main-popup qcomment" title="Comment" :active.sync="commentPopUp">
            <form data-vv-scope="commentForm">
                <div class="form-container" @click="formerrors.msg = ''">
                    <div class="vx-row">
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label">Comments</label>
                                <!-- <vs-textarea data-vv-as="Comments" v-validate="'required'" v-model="comments" name="comments" class="w-full" /> -->
                                <ckeditor data-vv-as="Comments" v-validate="'required'" v-model="comments" name="comments" class="w-full"  :editor="editor" :config="editorConfig"></ckeditor>
                                <span class="text-danger text-sm" v-show="errors.has('commentForm.comments')">{{ errors.first("commentForm.comments") }}</span>
                            </div>
                        </div>
                    </div>
                    <div class="text-danger text-sm formerrors" v-show="formerrors.msg">
                        <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
                    </div>
                </div>
                <div class="popup-footer relative">
                    <span class="loader" v-if="submiTing"><img src="@/assets/images/main/loader.gif" /></span>
    
                    <vs-button :disabled="comments == '' || comments.trim() == '' || submiTing" color="success" @click="formSubmitted(false)" class="save" type="filled">Submit</vs-button>
                </div>
            </form>
        </vs-popup>
    
       
    
        
    
        <vs-popup class="holamundo main-popup" title="Confirmation" :active.sync="showPrefillPopup">
            <div class="form-container">
                <div class="vx-row">
                  <div class="vx-col w-full" v-if="beneFiciaryDeytailsExists">
                          <p style="line-height: 20px">
                              Do you want to pre-fill the basic information from the Beneficiary Profile?
                          </p>
                      </div>
                      <div class="vx-col w-full" v-else>
                          <p style="line-height: 20px">
                              Do you want to pre-fill the basic information from the previous
                              case details?
                          </p>
                      </div>
                </div>
            </div>
            <div class="popup-footer">
                <vs-button color="dark" class="cancel" type="filled" @click="showPrefillPopup = false;setBasicData();prefillAction = false">Cancel</vs-button>
                <vs-button color="success" class="save" type="filled" @click="
                prefilltheDetails();prefillAction=true; showPrefillPopup = false;">Yes</vs-button>
            </div>
        </vs-popup>
        <vs-popup class="holamundo main-popup cls-btn" title="Case Details" :active.sync="showBenProfileSyncPopup">
              <div class="form-container">
                  <div class="vx-row">
                      <div class="vx-col w-full">
                          <p style="line-height: 20px">
                              Do you want to update the Beneficiary Profile with the new/change information entered in this case?
                          </p>
                      </div>
                  </div>
              </div>
              <div class="popup-footer">
                  <vs-button color="dark" class="cancel" type="filled" @click="conformBenProfile(false)">Cancel</vs-button>
                  <vs-button @click="conformBenProfile(true);" class="save questionnaire_btn" type="filled">Yes </vs-button>
              </div>
        </vs-popup>
        <template v-if="!checkCurrentUrl">
            <generatePin v-if="openGeneratePinPopUp" 
            @updateVerificationStatus="updateVerificationStatus"
            @hideMe="openGeneratePinPopUp = false"  
            :petitionDetails="petition" />
        
        </template>
        <div class="custom_modal_sec spouse_doc documents__modal" v-if="spouseModalForm" :class="{ modalopen: spouseModalForm }">
            <div class="custom_modal_overlay"></div>
            <div class="custom_modal_cnt">
                <div class="modal_title">
                    <h2>Spouse Information</h2>
                    <span class="close" v-if="!documentUploading" @click="toggleSpouseForm()">
                        <em class="material-icons">close</em>
                    </span>
                </div>
                <div class="modal_cnt">
                    <VuePerfectScrollbar ref="mainSidebarPs" :settings="settings">
                        <form data-vv-scope="dependentsInfoformmodal" @submit.prevent="" @keydown.enter.prevent="" >
                            <personalinfo :callFromPerm="true" :tplsection="'dependentsInfo.spouse'" :countriesWithoutUS="countriesWithoutUS" :marital_statuses="marital_statuses" 
                             :visastatuses="visastatuses" :countries="countries" formscope="dependentsInfoformmodal" :petition="petition" :inchesList="[]" :feetList="[]"
                              :fieldsArray="questionnaireDetails" v-model="spouse" :races_list="[]" :eye_colorList="[]" :hair_colorsList="[]"  ></personalinfo>
                            <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12" v-if="false" >
                                <div class="form-container mart10 padt20 child_case_docs_v2">
                                    <casedocumentslist  @emitUploadingAction="emitUploadingAction" :docMainCategory="'spousedoclist'" :tplsection="'dependentsInfo.spouse.documents'" :docslist="spousedoclist" formscope="dependentsInfoformmodal" :fieldsArray="questionnaireDetails" v-model="spouse.documents"></casedocumentslist>
                                </div>
                            </vs-col>
                        </form>
                    </VuePerfectScrollbar>
                </div>
                <div class="popup-footer relative">
                    <vs-button color="dark" :disabled="documentUploading" @click="toggleSpouseForm()" class="cancel" type="filled">Cancel</vs-button> 
                    <vs-button color="success" :disabled="documentUploading" @click="submitSpouse()" class="save" type="filled">Save
                    </vs-button>
                </div>
                <div></div>
            </div>
        </div>
        <div class="custom_modal_sec child_doc documents__modal" v-if="childModalForm" :class="{ modalopen: childModalForm }">
            <div class="custom_modal_overlay"></div>
            <div class="custom_modal_cnt">
                <div class="modal_title">
                    <h2>Child Information</h2>
                    <span class="close" @click="toggleChildForm(false)">
                        <em class="material-icons">close</em>
                    </span>
                </div>
                <div class="modal_cnt">
                    <VuePerfectScrollbar ref="mainSidebarPschild" :settings="settings">
                        <form data-vv-scope="childInfoformmodal" @submit.prevent="" @keydown.enter.prevent="">
                            <childpersonalinfo :callFromPerm="true" :countriesWithoutUS="countriesWithoutUS"  :marital_statuses="marital_statuses" :tplsection="'dependentsInfo.childrens'" :countries="countries" formscope="childInfoformmodal" :petition="petition" :fieldsArray="questionnaireDetails" v-model="petition.dependentsInfo.childrens[selectedchild]"></childpersonalinfo>
                            <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12" v-if="false" >
                                <div class="form-container padt20 child_case_docs_v2">
                                <casedocumentslist  @emitUploadingAction="emitUploadingAction" :docMainCategory="'childdoclist'" :tplsection="'dependentsInfo.childrens.documents'" :docslist="childdoclist" formscope="childInfoformmodal" :fieldsArray="questionnaireDetails" v-model="petition.dependentsInfo.childrens[selectedchild].documents"></casedocumentslist>
                            </div>
                            </vs-col>
                        </form>
                    </VuePerfectScrollbar>
                </div>
                <!-- :disabled="submiTing"  -->
                <div class="popup-footer relative">  
                    <vs-button color="dark" :disabled="documentUploading" @click="toggleChildForm(false)" class="cancel" type="filled">Cancel</vs-button>
                    <vs-button color="success" :disabled="documentUploading" @click="submitChild()" class="save" type="filled">Save
                    </vs-button>
                </div>
                <div></div>
            </div>
        </div>
    </div>
    
    </template>
    
    <script>
    import generatePin from "@/views/actionpopups/generatePin.vue";
    import genderField from './fields/gender.vue'
    import immiInput from "@/views/forms/fields/simpleinput.vue";
    import previousSpouseForm from "@/views/petition/gc/previousSpouseForm.vue";
    import {
        Trash2Icon
    } from "vue-feather-icons";
    import addressField from "@/views/forms/fields/address.vue";
    import datepickerField from "@/views/forms/fields/datepicker.vue";
    import selectField from "@/views/forms/fields/simpleselect.vue";
    import immiPhone from "@/views/forms/fields/phonenumber.vue";
    import immiMask from "@/views/forms/fields/maskinput.vue";
    import immiyesorno from "@/views/forms/fields/yesorno.vue";
    import immiuploader from "@/views/forms/fields/fileupload.vue";
    import immipriorstay from "@/views/forms/fields/priorstay.vue";
    import immitextarea from "@/views/forms/fields/simpletextarea.vue";
    import immieducations from "@/views/forms/fields/educations.vue";
    import educationsList from "@/views/forms/fields/educationsList.vue";
    import immiswitchyesno from "@/views/forms/fields/switchyesno.vue";
    import casedocumentslist from "@/views/common/casedocuments.vue";
    import immiemployment from "@/views/forms/fields/employment.vue";
    import moment from "moment";
    import petitionsinformation from "@/views/forms/fields/petitionsinformation.vue";
    import personalinfo from "@/views/forms/fields/personalinfo.vue";
    import childpersonalinfo from "@/views/forms/fields/childpersonalinfo.vue";
    import redioButtons from "@/views/forms/fields/redioButtons.vue";
    import JQuery from 'jquery';
    import _ from "lodash";
    import GCEmploymentdetailes from "@/views/GCEmploymentdetailes.vue";
    import VuePerfectScrollbar from "vue-perfect-scrollbar";
    import { XIcon } from 'vue-feather-icons' 
    import Vue from 'vue';
    Vue.use( CKEditor );
    import CKEditor from '@ckeditor/ckeditor5-vue2';
    import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
    export default {
        props: {
        },
        provide() {
            return {
                parentValidator: this.$validator,
            };
        },
        data() {
            return {
                prefillAction:false,
                openGeneratePinPopUp:false,
                tokenVerified:false, 
                documentUploading:false,
                newDocs:[],
                tempSave:false,
                showMessage:true,
                editor: ClassicEditor,
                editorConfig: {
                    toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
                },
                workFlowDetails:null,
                avertisementList:[
                    {
                        startDateKey:'startDateOfSundayNewsPaper',
                        endDateKey:'endDateOfSundayNewsPaper',
                        documentKey:'sunday'
                    },
                    {
                        startDateKey:'startDateOfAdvAtJobFair',
                        endDateKey:'endDateOfAdvAtJobFair',
                        documentKey:'jobFair'
                    },
                    {
                        startDateKey:'startDateOfNonCampusRecru',
                        endDateKey:'endDateOfNonCampusRecru',
                        documentKey:'campusRecruitment'
                    },
                    {
                        startDateKey:'startDateOfEmplrWebsitePosted',
                        endDateKey:'endDateOfEmplrWebsitePosted',
                        documentKey:'empWebsite'
                    },
                    {
                        startDateKey:'startDateOfAdvWithTradeOrProfOrg',
                        endDateKey:'startDateOfAdvWithTradeOrProfOrg',
                        documentKey:'profOrgOrTrade'
                    },
                    {
                        startDateKey:'startDateOfAdvEmpRefProgram',
                        endDateKey:'endDateOfAdvEmpRefProgram',
                        documentKey:'empRefProgram'
                    },
                    {
                        startDateKey:'startDateOfListedInJobSite',
                        endDateKey:'endDateOfListedInJobSite',
                        documentKey:'jobSearchWebsite'
                    },
                    {
                        startDateKey:'startDateOfListedInPrivateEmpFirm',
                        endDateKey:'endDateOfListedInPrivateEmpFirm',
                        documentKey:'pvtEmpmtFirm'
                    },
                    {
                        startDateKey:'startDateOfAdvCampusPlacOfc',
                        endDateKey:'endDateOfAdvCampusPlacOfc',
                        documentKey:'campusPlacement'
                    },
                    {
                        startDateKey:'startDateOfAdvLocalNewsPaper',
                        endDateKey:'endDateOfAdvLocalNewsPaper',
                        documentKey:'localNewsPaper'
                    },
                    {
                        startDateKey:'startDateOfAdvInTVOrRadio',
                        endDateKey:'endDateOfAdvInTVOrRadio',
                        documentKey:'tvAds'
                    },
                ],
                usStatusList:[],
                masterSocList:[],
                settings:{},
                commentPopUp:false,
                benProfileDetails:null,
                petition: {
                    visaStatusList:[],
                    tenantId: null,
                    petitionerId: null,
                    companyId: null,
                    branchId: null,
                    workflowId: null,
                    customId: '',
                    caseNo: '',
                    caseNoOld: '',
                    caseNoRef: '',
                    caseNoSNo: 0,
                    allowCustomCaseNo: false,
                    caseNumber: null,
                    type: null,
                    subType: null,
                    beneficiaryInfo: {
  
                      name: '',
                      firstName: '',
                      middleName: '',
                      lastName: '',
                      email: '',
                      gender:'',
                      homePhoneNumber: null,
                      homePhoneCountryCode: {
                          countryCode: '',
                          countryCallingCode: ''
                      },
                        cellPhoneNumber: null,
                        cellPhoneCountryCode: {
                            countryCode: '',
                            countryCallingCode: ''
                        },
                        workPhoneNumber:null,
                        workPhoneCountryCode:{countryCode: '', countryCallingCode: ''},
                        fax:null,
                        faxCountryCode:{countryCode: '', countryCallingCode: ''},
  
                        dateOfBirth: null,
                        countryOfBirth: null,
                        countryOfBirthDetails: null,
                        provinceOfBirth: null,
                        provinceOfBirthDetails: null,
                        locationOfBirth: null,
                        countryOfCitizenship: null,
                        countryOfCitizenshipDetails: null,
                        previouslyMarried:false,
                        previousSpouse:{
                            hasOtherNames:false,
                            otherNames: [{
                                _id: 0,
                                name: '',
                                firstName: '',
                                middleName: '',
                                lastName: '',
                            }],
                            maidenName:'',
                            marriageEndedDueTo:null,
                            marriageEndedOtherInfo:'',
                            firstName: '',
                            middleName: '',
                            lastName: '',
                            dateOfBirth: null,
                            dateOfMarriage:null,
                            dateOfMarriageEnd:null,
                              //Place of Marriage
                            countryOfMarriage: '',
                            countryOfMarriageDetails: null,
                            provinceOfMarriage: '',
                            provinceOfMarriageDetails: null,
                            locationOfMarriage: '',
    
                            //Place of Termination
                            countryOfMarriageTermination: '',
                            countryOfMarriageTerminationDetails: null,
                            provinceOfMarriageTermination: '',
                            provinceOfMarriageTerminationDetails: null,
                            locationOfMarriageTermination: '',
                            obtainPermResidenceThroughSpouse:false  
                          
                        },
                        mailingAddressIsSameAsAddress:false,
                        mailingAddress: {
                            line1: null,
                            line2: null,
                            aptType: null,
                            locationId: null,
                            locationDetails: null,
                            stateId: null,
                            stateDetails: null,
                            countryId: null,
                            countryDetails: null,
                            zipcode: null
                        },
                        address: {
                            line1: null,
                            line2: null,
                            aptType: null,
                            locationId: null,
                            locationDetails: null,
                            stateId: null,
                            stateDetails: null,
                            countryId: null,
                            countryDetails: null,
                            zipcode: null
                        },
                        currentAddress: {
                            line1: null,
                            line2: null,
                            aptType: null,
                            locationId: null,
                            locationDetails: null,
                            stateId: null,
                            stateDetails: null,
                            countryId: null,
                            countryDetails: null,
                            zipcode: null
                        },
                        haveYouEverTravelledToUS:null,
                        priorPeriodOfStayInUS: [{
                            _id: 0,
                           
                            visaStatus: null,
                            visaStatusDetails: null,
                            noOfDays: null,
                            enteredDate: null,
                            departedDate: null,
                           dateerror: false
                        }],
  
                        curNonImmigrantVisaStatus: null,
                        curNonImmigrantVisaStatusDetails: null,
                        curVisaExpiryNumber: null,
                        I94: '',
                       I94ExpiryDate: null,
                       firstEntryDateOrApprovalInUsWithH1B:null,
                       dateFifthYearOfHExpire:null,
  
  
                        alienNumber: '',
                        SSN: '',
                        educations: [
                        /* 
                        {
                            _id: 0,
                            name: null,
                            address: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                            highestDegree: null,
                            highestDegreeDetails: null,
                            majorFieldOfStudy: null,
                            attendedFrom: null,
                            attendedTo: null,
                            graduatedYear: null,
                            degreereceived: null,
                            isAccredited: null,
                            isForProfit: null
                          }
                          */
                        ],
                        vacationalOrTrainingInst: [
                        /* 
                        {
                            _id: 0,
                            name: null,
                            address: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                            highestDegree: null,
                            highestDegreeDetails: null,
                            majorFieldOfStudy: null,
                            attendedFrom: null,
                            attendedTo: null,
                            graduatedYear: null,
                            degreereceived: null,
                            isAccredited: null,
                            isForProfit: null
                          }
                          */
                        ],
  
                        prevEmploymentInfo: [{
                            _id: 0,
                            employerName: '',
                            address: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                            businessType: null,
                            jobTitle: null,
                            jobDuties: null,
                            startDate: null,
                            endDate: null,
                            currentEmployer: false,
                            workPhoneNumber: "",
                            workPhoneCountryCode: {
                              countryCode:null,
                              countryCallingCode: ''
                           },
                          fax: '',
                          faxCountryCode: {
                              countryCode:null,
                              countryCallingCode: ''
                          },
                          hoursWorkedPerWeek: '',
                          supervisor:{
                              name:'',
                              phoneNumber:'',
                              phoneCountryCode:{
                                  countryCode:'',
                                  countryCallingCode:''
                              },
  
  
                          }
  
                        }],
                        alienInfo: {
          isTrainigRequired: 'Yes',//String, // Yes/No // Is training required for the job opportunity?
          isExpRequired: 'No',//String, // Yes/No // Is experience in the job offered required for the job?
          isAltCombOfEduAndExpAccept:'No',// String, // Yes/No // Is there an alternate combination of education and experience that is acceptable
          isExpInAltOccuAccept:'No',// String, // Yes/No // Is experience in an alternate occupation acceptable?
          hasGainAnyExpWithEmplr: 'No',//String, // Yes/No // Did the alien gain any of the qualifying experience with the employer in a position substantially comparable to the job opportunity requested?
          didEmplrPayForEdu: 'No',//String, // Yes/No // Did the employer pay for any of the alien’s education or training necessary to satisfy any of the employer’s job requirements for this position?
          isWorkingWithPetngEmplr:'No',// String, // Yes/No // Is the alien currently employed by the petitioning employer?
                      },
                      refilingInstructions: {
                          useFilingDateFromPrevSubtn: 'No',//String, // Yes/No // Are you seeking to utilize the filing date from a previously submitted Yes No Application for Alien Employment Certification (ETA 750)? 
                          prevFilingDate: null ,//Date, // enter the previous filing date
                          prevSWAOrLocalCaseNo: '',//String, // Indicate the previous SWA or local office case number OR if not available, specify state where case was originally filed
                          caseFiledStateId: null,//Number, // Indicate the previous SWA or local office case number OR if not available, specify state where case was originally filed
                          caseFiledStateDetails: null, //Object // Indicate the previous SWA or local office case number OR if not available, specify state where case was originally filed
                      },
  
  
                        /*OLD */
                       
                        currentlyInUS: null,
                        haveOwnershipInterest: null,
                        ownershipInterestDesc: '',
                        consulateInfo: {
                            locationId: null,
                            locationDetails: null,
                            stateId: null,
                            stateDetails: null,
                            countryId: null,
                            countryDetails: null
                        },
                       
                        lastArrivalNumber: null,
                        placeOfLastEntryInUS: '',
                       
                        nonImmPetitionsInfo: [{
                            _id: 0,
                            visaStatus: null,
                            visaStatusDetails: null,
                            receiptNo: '',
                            petitionerName: ''
                        }],
                        anyImmPetitionFiled: null,
                        immPetitionInfo: {
                            anyOtherAlienFiled: null,
                            filedDate: null,
                            employerName: '',
                            rirOrRegularProcessing: null,
                            filedStateId: null,
                            filedStateDetails: null,
                            applCurStatus: '',
                            seekingFiledDateforETA750: null,
                        },
                        
                        addressOutsideUS: {
                            line1: null,
                            line2: null,
                            aptType: null,
                            locationId: null,
                            locationDetails: null,
                            stateId: null,
                            stateDetails: null,
                            countryId: null,
                            countryDetails: null,
                            zipcode: null
                        },
    
                      
                        hasOtherNames: false,
                        otherNames: [{
                            _id: 0,
                            name: '',
                            firstName: '',
                            middleName: '',
                            lastName: '',
                        }],
                        gender: '',
                     
                        
                        maritalStatus: null,
                    
                        iAmFromUS: null,
                       
                        consulateNotifyAddress: null,
                       
                        hasI140ImmPetitionFiled: null,
                        I140ImmPetitionFiledDetails: null,
                        passportNumber: null,
                        passportIssuedNumber: null,
                        passportExpiryNumber: null,
                       
                        sevisNumber: null,
                        eadNumber: null,
                       
                        noOfDaysStayInUS: null,
                        confirmDaysStayInUS: false,
                        hasApprovedI140: false,
                        hasPermPendingForMorethan365Days: false,
                        curVisaExpiryDate:null,
                        passportIssuedDate:null,
                        passportExpiryDate:null,
                    },
                    dependentsInfo: {
                        spouse: {
                            hasSpouse:false,
                            firstName: "",
                            middleName: '',
                            lastName: "",
                            maidenName: "",
                            gender: "",
                            email: "",
                            phoneNumber: null,
                            phoneCountryCode: {
                                countryCode: "",
                                countryCallingCode: ""
                            },
                            cellPhoneNumber: "",
                            cellPhoneCountryCode: {
                                countryCode: "",
                                countryCallingCode: ""
                            },
                            dateOfBirth: null,
                            countryOfBirth: null,
                            countryOfBirthDetails: null,
                            provinceOfBirth: null,
                            provinceOfBirthDetails:null, 
                            locationOfBirth: "",
                            passportNumber: null,
                            passportIssuedDate: null,
                            passportExpiryDate: null,
                            passportIssuedCountry: null,
                            passportIssuedCountryDetails: null,
                            SSN: "", 
                            currentStatus: null,
                            statusExpiryDate: null,
                            isDSExpiryDate: null,
                            countryOfCitizenship: null,
                            countryOfCitizenshipDetails: null,
                            otherCountriesOfCitizenship: [],
                            otherCountriesOfCitizenshipDetails: [],
                            addressOutsideUS: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            }
				        },
                        childrens: [{
                            firstName: "",
                            middleName: '',
                            lastName: "",
                            maidenName: "",
                            gender: "",
                            email: "",
                            phoneNumber: null,
                            phoneCountryCode: {
                                countryCode: "",
                                countryCallingCode: ""
                            },
                            cellPhoneNumber: "",
                            cellPhoneCountryCode: {
                                countryCode: "",
                                countryCallingCode: ""
                            },
                            dateOfBirth: null,
                            countryOfBirth: null,
                            countryOfBirthDetails: null,
                            provinceOfBirth: null,
                            provinceOfBirthDetails:null, 
                            locationOfBirth: "",
                            passportNumber: null,
                            passportIssuedDate: null,
                            passportExpiryDate: null,
                            passportIssuedCountry: null,
                            passportIssuedCountryDetails: null,
                            SSN: "", 
                            currentStatus: null,
                            statusExpiryDate: null,
                            isDSExpiryDate: null,
                            countryOfCitizenship: null,
                            countryOfCitizenshipDetails: null,
                            otherCountriesOfCitizenship: [],
                            otherCountriesOfCitizenshipDetails: [],
                            addressOutsideUS: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            }
				        }]
                    },
                    documents: {
                        slgResume: [],
                        slgEduCredentials:[],
                        slgEvalOfEduCredentials:[],
                        slgTransScripts:[],
                        slgPrevNonimmApprovalNotices:[],
                        slgPrevLaborApplications:[],
                        slgAckOfPrevLaborApplications:[],
                        slgExpLetters:[],
                        slgPassportAndVisa:[],
                        slgCurPrevH1BH4ApprovalsByINS:[], 
                        slgAdvancedDegrees:[],
                    },
                    jobDetails: {
                        jobId: '',
                        noOfPositions: null,
                        minDegree: null,
                        expInYears: '',
                        salary: '',
                        jobType: '', //Full Time Regular
                        jobShift: '', //First Shift (Day)
                        hoursPerWeek: null,
                        description: '',
                        applicationInfo: {
                            applyByMail: '',
                            jobStartsOn: null,
                            jobEndOn: null
                        }
                    },
                    refilingInstructions: {
                        useFilingDateFromPrevSubtn: 'No', // Yes/No // Are you seeking to utilize the filing date from a previously submitted Yes No Application for Alien Employment Certification (ETA 750)? 
                        prevFilingDate: null, // enter the previous filing date
                        prevSWAOrLocalCaseNo: '', // Indicate the previous SWA or local office case number OR if not available, specify state where case was originally filed
                        caseFiledStateId: null, // Indicate the previous SWA or local office case number OR if not available, specify state where case was originally filed
                        caseFiledStateDetails: {} // Indicate the previous SWA or local office case number OR if not available, specify state where case was originally filed
                        
                    },
                    wageInfo: {
                      trackingNumber: '',
                      socCode: null,
                      wageRate: '',
                      payFrequency: '', // Year, Month, Bi-Weekly, Week, Hour
                      wageSource: '', // OES, CBA, Employer Conducted Survey, DBA, SCA, Other
                      wageSourceOtherDesc: '',
                      determinationDate: null,
                      expirationDate: null
                    },
                    wageOfferInfo: {
                      minWage: '',
                      maxWage: '',
                      payFrequency: '', // Year, Month, Bi-Weekly, Week, Hour
                    },
                    jobOpportunityInfo: {
                        workAddresses: [],
                        jobTitle: '',
                        minDegree: null,
                        majorFieldsOfStudy: null,
                        isTrainigRequired: 'No', // Yes/No // Is training required for the job opportunity?
                        noOfTraningMonths: null, //  If Yes, number of months of training required
                        fieldOfTraining: '', // Indicate the field of training:
                        isExpRequired: 'No', // Yes/No // Is experience in the job offered required for the job?
                        noOfExpMonths: null, //  If Yes, number of months experience required
                        isAltFieldOfStudyAccept: 'No', // Yes/No // Is there an alternate field of study that is acceptable?
                        altMajorFieldOfStudy: '', //  If Yes, specify the major field of study
                        isAltCombOfEduAndExpAccept: 'No', // Yes/No // Is there an alternate combination of education and experience that is acceptable
                        altLevelOfEdu: null, // If Yes, specify the alternate level of education required
                        altAcceptExpInYears: null, // If applicable, indicate the number of years experience acceptable
                        foreignEduEqAccept: 'No', // Yes/No // Is a foreign educational equivalent acceptable?
                        isExpInAltOccuAccept: 'No', // Yes/No // Is experience in an alternate occupation acceptable?
                        noOfExpMonthsInAltOccu: null, // If Yes, number of months experience in alternate occupation required
                        jobTitleOfAcceptAltOccu: '', // Identify the job title of the acceptable alternate occupation
                        jobDuties: '', // Job duties – If submitting by mail, add attachment if necessary. Job duties description must begin in this space
                        jobOppoReqForNormalOccu: 'No', // Yes/No // Are the job opportunity’s requirements normal for the occupation?
                        isForiegnLangRequired: 'No', // Yes/No // Is knowledge of a foreign language required to perform the job duties?
                        skills: [], // Specific skills or other requirements – If submitting by mail, add attachment if necessary. Skills description must begin in this space. 
                        isApplInvolJobOppoInclCombOfOccu: 'No', // Yes/No // Does this application involve a job opportunity that includes a combination of occupations?
                        positionOfferToAlien: 'No', // Yes/No // Is the position identified in this application being offered to the alien identified in Section J?
                        alienReqToLiveEmplrPrimisis: 'No', // Yes/No //  Does the job require the alien to live on the employer’s premises?
                        applLiveInHouseDomWorker: 'No', // Yes/No // Is the application for a live-in household domestic service worker?
                        emplrProviedAlienCopyOfContract: 'NA' // Yes/No/NA // If Yes, have the employer and the alien executed the required employment contract and has the employer provided a copy of the contract to the alien?
                    },
                    refilingInstructions: {
                        useFilingDateFromPrevSubtn: 'No', // Yes/No // Are you seeking to utilize the filing date from a previously submitted Yes No Application for Alien Employment Certification (ETA 750)? 
                        prevFilingDate: null, // enter the previous filing date
                        prevSWAOrLocalCaseNo: '', // Indicate the previous SWA or local office case number OR if not available, specify state where case was originally filed
                        caseFiledStateId: null, // Indicate the previous SWA or local office case number OR if not available, specify state where case was originally filed
                        caseFiledStateDetails: {} // Indicate the previous SWA or local office case number OR if not available, specify state where case was originally filed
                    },
                    refilingInstructions: {
                        useFilingDateFromPrevSubtn: 'No',//String, // Yes/No // Are you seeking to utilize the filing date from a previously submitted Yes No Application for Alien Employment Certification (ETA 750)? 
                        prevFilingDate: null ,//Date, // enter the previous filing date
                        prevSWAOrLocalCaseNo: '',//String, // Indicate the previous SWA or local office case number OR if not available, specify state where case was originally filed
                        caseFiledStateId: null,//Number, // Indicate the previous SWA or local office case number OR if not available, specify state where case was originally filed
                        caseFiledStateDetails: null, //Object // Indicate the previous SWA or local office case number OR if not available, specify state where case was originally filed 
                    },
                    lcaRequested: false,
                    questionnaireFilled: false,
                    questionnaireFilled_temp: false,
                    lcaId: null,
                    statusId: 1,
                    status: 1,
                    questionnaireSent: true,
                    questionnaireInstructions: '',
                    assignOrSubmitRoleComment: '',
                    curWorkflowActivity: 'CREATE_PETITION',
                    nextWorkflowActivity: ['SUBMIT_BY_BENEFICIARY'],
                    relationships:[
                        { "id":"Son", "name":"Son" },
                        { "id":"Daughter", "name":"Daughter" }
                    ]
                },
                spouse: {
                    firstName: "",
                    middleName: '',
                    lastName: "",
                    maidenName: "",
                    gender: "",
                    email: "",
                    phoneNumber: null,
                    phoneCountryCode: {
                        countryCode: "",
                        countryCallingCode: ""
                    },
                    cellPhoneNumber: "",
                    cellPhoneCountryCode: {
                        countryCode: "",
                        countryCallingCode: ""
                    },
                    dateOfBirth: null,
                    countryOfBirth: null,
                    countryOfBirthDetails: null,
                    provinceOfBirth: null,
                    provinceOfBirthDetails:null, 
                    locationOfBirth: "",
                    passportNumber: null,
                    passportIssuedDate: null,
                    passportExpiryDate: null,
                    passportIssuedCountry: null,
                    passportIssuedCountryDetails: null,
                    SSN: "", 
                    currentStatus: null,
                    statusExpiryDate: null,
                    isDSExpiryDate: null,
                    countryOfCitizenship: null,
                    countryOfCitizenshipDetails: null,
                    otherCountriesOfCitizenship: [],
                    otherCountriesOfCitizenshipDetails: [],
                    addressOutsideUS: {
                        line1: null,
                        line2: null,
                        aptType: null,
                        locationId: null,
                        locationDetails: null,
                        stateId: null,
                        stateDetails: null,
                        countryId: null,
                        countryDetails: null,
                        zipcode: null
                    }
                },
                currentTab: 'casedetails',
                countries: [],
                countriesWithoutUS:[],
                bfeprovinceStates: [],
                usastates: [],
                visastatuses: [],
                marital_statuses: [],
                education_types: [],
                questionnaireDetails: null,
                showPrefillPopup: false,
                beneFiciaryDeytailsExists:null,
                showBenProfileSyncPopup:false,
                latestPetition: null,
                featureDates: null,
                tabslist: [{
                        key: "casedetails",
                        name: "Personal Info"
                    },
                  //   {
                  //           key: "education",
                  //           name: "Educational Info"
                  //       },
                      //   {
                      //       key: "employment",
                      //       name: "Employment Info"
                      //   },
                  //       {
                  //       key: "documents",
                  //       name: "Documents"
                  //   }
                        
    
                ],
               
                questionnairePreview: false,
                questionnairePreviewData: null,
                SuccessQuestionnaire: false,
                hasRequiredForChildren: false,
                spouseModalForm: false,
                childModalForm: false,
                submiTing: false,
                comments: "",
                formerrors: {
                    msg: ""
                },
                startEligibleDate: new Date().setFullYear(new Date().getFullYear() - 18),
                childdoclist: [
                    {
                        required: false,
                        key: 'child_docs_passport',
                        fieldName: 'passport',
                        label: 'Passport- First page with photo, Visa page and last page with address'
                    },
                    {
                        required: false,
                        key: 'child_docs_visa',
                        fieldName: 'visa',
                        label: 'Visa'
                    },
                    {
                        required: false,
                        key: 'child_docs_form_i94',
                        fieldName: 'formI94',
                        label: 'Form I-94'
                    },
                    {
                        required: false,
                        key: 'child_docs_approval_notice',
                        fieldName: 'approvalNotice',
                        label: 'Approval Notice'
                    },
                    {
                        required: false,
                        key: 'child_docs_birth_certificate',
                        fieldName: 'birthCertificate',
                        label: 'Birth Certificate'
                    },
                    {
                        required: false,
                        key: 'child_docs_other',
                        fieldName: 'other',
                        label: 'Others'
                    }
                ],
                selectedchild: 0,
                spousedoclist: [{
                        required: false,
                        key: 'spouse_docs_passport',
                        fieldName: 'passport',
                        label: 'Passport- First page with photo, Visa page and last page with address'
                    }, {
                        required: false,
                        key: 'spouse_docs_visa',
                        fieldName: 'visa',
                        label: 'Visa'
                    }, {
                        required: false,
                        key: 'spouse_docs_formi94',
                        fieldName: 'formI94',
                        label: 'Form I-94'
                    }, {
                        required: false,
                        key: 'spouse_docs_form_i797',
                        fieldName: 'formI797',
                        label: 'Latest I-797, Notice of Approval of the spouse (if spouse is on H-1B or L-1 status)'
                    }, {
                        required: false,
                        key: 'spouse_docs_form_i20',
                        fieldName: 'formI20',
                        label: 'Spouse’s all Form I-20s (if spouse is on F-1 status)'
                    }, {
                        required: false,
                        key: 'spouse_docs_pay_stubs',
                        fieldName: 'payStubs',
                        label: 'Three Recent Pay Stubs'
                    }, {
                        required: false,
                        key: 'spouse_docs_mrg_certificate',
                        fieldName: 'marriageCertificate',
                        label: 'Marriage Certificate (if spouse is on H-1B, L-1, or F-1 status)'
                    }, {
                        required: false,
                        key: 'spouse_docs_other',
                        fieldName: 'other',
                        label: 'Others'
                    }
    
                ],
                bendocslist: [
                {
                      fileUploading:false,
                        required: false,
                        key: "resume",
                        fieldName: 'resume',
                        label: "Resume"
                      
                    }, 
                    {
                      fileUploading:false,
                        required: false,
                        key: "expLetters",
                        fieldName: 'expLetters',
                        label: "Experience Letters"
                      
                    },
                    {
                      fileUploading:false,
                        required: false,
                        key: "passportVisaI94",
                        fieldName: 'passportVisaI94',
                        label: "Passport- First page with photo, Visa page and last page with address"
                      
                    },
                    {
                      fileUploading:false,
                        required: false,
                        key: "slgResume",
                        fieldName: 'slgResume',
                        label: "Latest Resume"
                      
                    },
                    {
                      fileUploading:false,
                        required: false,
                        key: "slgEduCredentials",
                        fieldName: 'slgEduCredentials',
                        label: "Educational Documents",
                        tooltip:"Degree certificates, transcripts/marksheets, and any training certificates"
                    },
                    {
                      fileUploading:false,
                        required: false,
                        key: "slgEvalOfEduCredentials",
                        fieldName: "slgEvalOfEduCredentials",
                        label: "Education evaluation"
                    },
                  //   Evaluation of Education Certification
                  //   {
                  //       display:true,
                  //       required: false,
                  //       key: "slgTransScripts",
                  //       fieldName: 'slgTransScripts',
                  //       label: "Transcripts/Marks Memo’s"
                  //   },
                    {
                      fileUploading:false,
                        required: false,
                        key: "slgExpLetters",
                        fieldName: 'slgExpLetters',
                        label: "Experience Letters/Employment Confirmation Letters from all previous employers",
                        tooltip:"The letters must be printed on the company’s letterhead. The letters should include details of the job duties performed, the skills utilized, start and end dates of employment, and position(s) held and must be duly signed and dated by an authorized representative of the company"
                    },
                    {
                      fileUploading:false,
                        required: false,
                        key: "slgPassportAndVisa",
                        fieldName: 'slgPassportAndVisa',
                        label: "Clear copy of passport",
                        tooltip:"All pages except blank ones"
                    },
                    {
                      fileUploading:false,
                        required: false,
                        key: "slgI94",
                        fieldName: 'slgI94',
                        label: "Current I-94"
                    },
                  //   I-94, Front and Back
                    {
                      fileUploading:false,
                        required: false,
                        key: "slgCurPrevH1BH4ApprovalsByINS",
                        fieldName: 'slgCurPrevH1BH4ApprovalsByINS',
                        label: "Copies of all approvals",
                        tooltip:"Copies of all approvals you have received so far, including H-1B, H-4, B-1/B-2, F-1/F-2, L-1/L-2, I-20’s, CPT/OPT cards, I-140's as applicable."
                    },
                    {
                      fileUploading:false,
                        required: false,
                        key: "slgTransScripts",
                        fieldName: 'slgTransScripts',
                        label: "Transcripts "
                    },
                    {
                      fileUploading:false,
                        required: false,
                        key: "slgPrevNonimmApprovalNotices",
                        fieldName: 'slgPrevNonimmApprovalNotices',
                        label: "Copy of all Previous Nonimmigrant Approval Notices (e.g., H-1B, H-4, L-1A, L-1B, L-2 and etc….) Please include a copy of your current H-1 petition, and H-1 support letter, that provides your current job description"
                    },
                    {
                      fileUploading:false,
                        required: false,
                        key: "slgPrevLaborApplications",
                        fieldName: 'slgPrevLaborApplications',
                        label: "Copy of the previously filed Labor Application, if applicable"
                    },
                    {
                      fileUploading:false,
                        required: false,
                        key: "slgAckOfPrevLaborApplications",
                        fieldName: 'slgAckOfPrevLaborApplications',
                        label: "Copy of the Acknowledgement letter for the previously filed Labor application, if applicable."
                    },

                    /*slgPrevLaborApplications:[],
                        slgAckOfPrevLaborApplications:[],*/
                     /*
                     {
                        display:true,
                        required: false,
                        key: "slgAdvancedDegrees",
                        fieldName: 'slgAdvancedDegrees',
                        label: "Adavanced Degree Certificate"
                    },
                   
                    {
                        required: false,
                        key: 'docs_other',
                        fieldName: 'other',
                        label: 'Other Documents, if any'
                    }
                    */
                ],
                executionCompleted:true,
                tempPetition: {
                    visaStatusList:[],
                    tenantId: null,
                    petitionerId: null,
                    companyId: null,
                    branchId: null,
                    workflowId: null,
                    customId: '',
                    caseNo: '',
                    caseNoOld: '',
                    caseNoRef: '',
                    caseNoSNo: 0,
                    allowCustomCaseNo: false,
                    caseNumber: null,
                    type: null,
                    subType: null,
                    beneficiaryInfo: {
  
                      name: '',
                      firstName: '',
                      middleName: '',
                      lastName: '',
                      email: '',
                      gender:'',
                      homePhoneNumber: null,
                      homePhoneCountryCode: {
                          countryCode: '',
                          countryCallingCode: ''
                      },
                        cellPhoneNumber: null,
                        cellPhoneCountryCode: {
                            countryCode: '',
                            countryCallingCode: ''
                        },
                        workPhoneNumber:null,
                        workPhoneCountryCode:{countryCode: '', countryCallingCode: ''},
                        fax:null,
                        faxCountryCode:{countryCode: '', countryCallingCode: ''},
  
                        dateOfBirth: null,
                        countryOfBirth: null,
                        countryOfBirthDetails: null,
                        provinceOfBirth: null,
                        provinceOfBirthDetails: null,
                        locationOfBirth: null,
                        countryOfCitizenship: null,
                        countryOfCitizenshipDetails: null,
                        previouslyMarried:false,
                        previousSpouse:{
                            hasOtherNames:false,
                            otherNames: [{
                                _id: 0,
                                name: '',
                                firstName: '',
                                middleName: '',
                                lastName: '',
                            }],
                            maidenName:'',
                            marriageEndedDueTo:null,
                            marriageEndedOtherInfo:'',
                            firstName: '',
                            middleName: '',
                            lastName: '',
                            dateOfBirth: null,
                            dateOfMarriage:null,
                            dateOfMarriageEnd:null,
                              //Place of Marriage
                            countryOfMarriage: '',
                            countryOfMarriageDetails: null,
                            provinceOfMarriage: '',
                            provinceOfMarriageDetails: null,
                            locationOfMarriage: '',
    
                            //Place of Termination
                            countryOfMarriageTermination: '',
                            countryOfMarriageTerminationDetails: null,
                            provinceOfMarriageTermination: '',
                            provinceOfMarriageTerminationDetails: null,
                            locationOfMarriageTermination: '',
                            obtainPermResidenceThroughSpouse:false  
                          
                        },
                        mailingAddressIsSameAsAddress:false,
                        mailingAddress: {
                            line1: null,
                            line2: null,
                            aptType: null,
                            locationId: null,
                            locationDetails: null,
                            stateId: null,
                            stateDetails: null,
                            countryId: null,
                            countryDetails: null,
                            zipcode: null
                        },
                        address: {
                            line1: null,
                            line2: null,
                            aptType: null,
                            locationId: null,
                            locationDetails: null,
                            stateId: null,
                            stateDetails: null,
                            countryId: null,
                            countryDetails: null,
                            zipcode: null
                        },
                        currentAddress: {
                            line1: null,
                            line2: null,
                            aptType: null,
                            locationId: null,
                            locationDetails: null,
                            stateId: null,
                            stateDetails: null,
                            countryId: null,
                            countryDetails: null,
                            zipcode: null
                        },
                        haveYouEverTravelledToUS:null,
                        priorPeriodOfStayInUS: [{
                            _id: 0,
                           
                            visaStatus: null,
                            visaStatusDetails: null,
                            noOfDays: null,
                            enteredDate: null,
                            departedDate: null,
                           dateerror: false
                        }],
  
                        curNonImmigrantVisaStatus: null,
                        curNonImmigrantVisaStatusDetails: null,
                        curVisaExpiryNumber: null,
                        I94: '',
                       I94ExpiryDate: null,
                       firstEntryDateOrApprovalInUsWithH1B:null,
                       dateFifthYearOfHExpire:null,
                       curVisaExpiryDate:null,
                        passportIssuedDate:null,
                        passportExpiryDate:null,
  
                        alienNumber: '',
                        SSN: '',
                        educations: [
                       
                        {
                            _id: 0,
                            name: null,
                            address: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                            highestDegree: null,
                            highestDegreeDetails: null,
                            majorFieldOfStudy: null,
                            attendedFrom: null,
                            attendedTo: null,
                            graduatedYear: null,
                            degreereceived: null,
                            isAccredited: null,
                            isForProfit: null
                          }
                       
                        ],
                        vacationalOrTrainingInst: [
                        
                        {
                            _id: 0,
                            name: null,
                            address: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                            highestDegree: null,
                            highestDegreeDetails: null,
                            majorFieldOfStudy: null,
                            attendedFrom: null,
                            attendedTo: null,
                            graduatedYear: null,
                            degreereceived: null,
                            isAccredited: null,
                            isForProfit: null
                          }
                         
                        ],
  
                        prevEmploymentInfo: [{
                            _id: 0,
                            employerName: '',
                            address: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                            businessType: null,
                            jobTitle: null,
                            jobDuties: null,
                            startDate: null,
                            endDate: null,
                            currentEmployer: false,
                            workPhoneNumber: "",
                            workPhoneCountryCode: {
                              countryCode:null,
                              countryCallingCode: ''
                           },
                          fax: '',
                          faxCountryCode: {
                              countryCode:null,
                              countryCallingCode: ''
                          },
                          hoursWorkedPerWeek: '',
                          supervisor:{
                              name:'',
                              phoneNumber:'',
                              phoneCountryCode:{
                                  countryCode:'',
                                  countryCallingCode:''
                              },
  
  
                          }
  
                        }],
                        alienInfo: {
                              isTrainigRequired: 'Yes',//String, // Yes/No // Is training required for the job opportunity?
                              isExpRequired: 'No',//String, // Yes/No // Is experience in the job offered required for the job?
                              isAltCombOfEduAndExpAccept:'No',// String, // Yes/No // Is there an alternate combination of education and experience that is acceptable
                              isExpInAltOccuAccept:'No',// String, // Yes/No // Is experience in an alternate occupation acceptable?
                              hasGainAnyExpWithEmplr: 'No',//String, // Yes/No // Did the alien gain any of the qualifying experience with the employer in a position substantially comparable to the job opportunity requested?
                              didEmplrPayForEdu: 'No',//String, // Yes/No // Did the employer pay for any of the alien’s education or training necessary to satisfy any of the employer’s job requirements for this position?
                              isWorkingWithPetngEmplr:'No',// String, // Yes/No // Is the alien currently employed by the petitioning employer?
                          },
  
  
                        /*OLD */
                       
                        currentlyInUS: null,
                        haveOwnershipInterest: null,
                        ownershipInterestDesc: '',
                        consulateInfo: {
                            locationId: null,
                            locationDetails: null,
                            stateId: null,
                            stateDetails: null,
                            countryId: null,
                            countryDetails: null
                        },
                        lastArrivalNumber: null,
                        placeOfLastEntryInUS: '',
                       
                        nonImmPetitionsInfo: [{
                            _id: 0,
                            visaStatus: null,
                            visaStatusDetails: null,
                            receiptNo: '',
                            petitionerName: ''
                        }],
                        anyImmPetitionFiled: null,
                        immPetitionInfo: {
                            anyOtherAlienFiled: null,
                            filedDate: null,
                            employerName: '',
                            rirOrRegularProcessing: null,
                            filedStateId: null,
                            filedStateDetails: null,
                            applCurStatus: '',
                            seekingFiledDateforETA750: null,
                        },
                        addressOutsideUS: {
                            line1: null,
                            line2: null,
                            aptType: null,
                            locationId: null,
                            locationDetails: null,
                            stateId: null,
                            stateDetails: null,
                            countryId: null,
                            countryDetails: null,
                            zipcode: null
                        },
                        hasOtherNames: false,
                        otherNames: [{
                            _id: 0,
                            name: '',
                            firstName: '',
                            middleName: '',
                            lastName: '',
                        }],
                        gender: '',
                        maritalStatus: null,
                        I94: null,
                        I94ExpiryDate: null,
                        iAmFromUS: null,
                        consulateNotifyAddress: null,
                        hasI140ImmPetitionFiled: null,
                        I140ImmPetitionFiledDetails: null,
                        passportNumber: null,
                        passportIssuedNumber: null,
                        passportExpiryNumber: null,
                        sevisNumber: null,
                        eadNumber: null,
                        noOfDaysStayInUS: null,
                        confirmDaysStayInUS: false,
                        hasApprovedI140: false,
                        hasPermPendingForMorethan365Days: false
                    },
                    dependentsInfo: {
                        spouse: {
                            firstName: "",
                            middleName: '',
                            lastName: "",
                            maidenName: "",
                            gender: "",
                            email: "",
                            phoneNumber: null,
                            phoneCountryCode: {
                                countryCode: "",
                                countryCallingCode: ""
                            },
                            cellPhoneNumber: "",
                            cellPhoneCountryCode: {
                                countryCode: "",
                                countryCallingCode: ""
                            },
                            dateOfBirth: null,
                            countryOfBirth: null,
                            countryOfBirthDetails: null,
                            provinceOfBirth: null,
                            provinceOfBirthDetails:null, 
                            locationOfBirth: "",
                            passportNumber: null,
                            passportIssuedDate: null,
                            passportExpiryDate: null,
                            passportIssuedCountry: null,
                            passportIssuedCountryDetails: null,
                            SSN: "", 
                            currentStatus: null,
                            statusExpiryDate: null,
                            isDSExpiryDate: null,
                            countryOfCitizenship: null,
                            countryOfCitizenshipDetails: null,
                            otherCountriesOfCitizenship: [],
                            otherCountriesOfCitizenshipDetails: [],
                            addressOutsideUS: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            }
				        },
                        childrens: [{
                            firstName: "",
                            middleName: '',
                            lastName: "",
                            maidenName: "",
                            gender: "",
                            email: "",
                            phoneNumber: null,
                            phoneCountryCode: {
                                countryCode: "",
                                countryCallingCode: ""
                            },
                            cellPhoneNumber: "",
                            cellPhoneCountryCode: {
                                countryCode: "",
                                countryCallingCode: ""
                            },
                            dateOfBirth: null,
                            countryOfBirth: null,
                            countryOfBirthDetails: null,
                            provinceOfBirth: null,
                            provinceOfBirthDetails:null, 
                            locationOfBirth: "",
                            passportNumber: null,
                            passportIssuedDate: null,
                            passportExpiryDate: null,
                            passportIssuedCountry: null,
                            passportIssuedCountryDetails: null,
                            SSN: "", 
                            currentStatus: null,
                            statusExpiryDate: null,
                            isDSExpiryDate: null,
                            countryOfCitizenship: null,
                            countryOfCitizenshipDetails: null,
                            otherCountriesOfCitizenship: [],
                            otherCountriesOfCitizenshipDetails: [],
                            addressOutsideUS: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            }
				        }]
                    },
                    documents: {
                        
                        slgResume: [],
                        slgEduCredentials:[],
                        slgEvalOfEduCredentials:[],
                        slgTransScripts:[],
                        slgPrevNonimmApprovalNotices:[],
                        slgExpLetters:[],
                        slgPassportAndVisa:[],
                        slgCurPrevH1BH4ApprovalsByINS:[], 
                        slgAdvancedDegrees:[],
                    },
                    refilingInstructions: {
                        useFilingDateFromPrevSubtn: 'No', // Yes/No // Are you seeking to utilize the filing date from a previously submitted Yes No Application for Alien Employment Certification (ETA 750)? 
                        prevFilingDate: null, // enter the previous filing date
                        prevSWAOrLocalCaseNo: '', // Indicate the previous SWA or local office case number OR if not available, specify state where case was originally filed
                        caseFiledStateId: null, // Indicate the previous SWA or local office case number OR if not available, specify state where case was originally filed
                        caseFiledStateDetails: {} // Indicate the previous SWA or local office case number OR if not available, specify state where case was originally filed
                        
                    },
                    lcaRequested: false,
                    questionnaireFilled: false,
                    questionnaireFilled_temp: false,
                    lcaId: null,
                    statusId: 1,
                    status: 1,
                    questionnaireSent: true,
                    questionnaireInstructions: '',
                    assignOrSubmitRoleComment: '',
                    curWorkflowActivity: 'CREATE_PETITION',
                    nextWorkflowActivity: ['SUBMIT_BY_BENEFICIARY'],
                    relationships:[
                    {
                    "id":"Son",
                    "name":"Son"
                    },{
                    "id":"Daughter",
                    "name":"Daughter"
                    }
                    ]
                },
                ignoreItems:['vacationalOrTrainingInst','prevEmploymentInfo','educations','alienInfo','refilingInstructions','countryOfBirth','countryOfBirthDetails','immPetitionInfo',
                'provinceOfBirth','provinceOfBirthDetails','countryOfCitizenship','countryOfCitizenshipDetails','priorPeriodOfStayInUS',
                'curNonImmigrantVisaStatusDetails','curNonImmigrantVisaStatus','previousSpouse'],
                
                spouseIgnoreItems:['countryOfBirthDetails','otherCountriesOfCitizenship','otherCountriesOfCitizenshipDetails',
                'countryOfBirth','passportIssuedCountryDetails','passportIssuedCountry','cellPhoneNumber','cellPhoneCountryCode','name','saved',
                'provinceOfBirth','provinceOfBirthDetails','countryOfCitizenship','countryOfCitizenshipDetails','phoneNumber','phoneCountryCode'],
                detailsItemsList:[
                    {
                        key:'countryOfMarriage',
                        detailsKey:'countryOfMarriageDetails',
                        section:'beneficiaryInfo.previousSpouse',
                        type:'details'
                    },
                    {
                        key:'provinceOfMarriage',
                        detailsKey:'provinceOfMarriageDetails',
                        section:'beneficiaryInfo.previousSpouse',
                        type:'details'
                    },
                    {
                        key:'countryOfMarriageTermination',
                        detailsKey:'countryOfMarriageTerminationDetails',
                        section:'beneficiaryInfo.previousSpouse',
                        type:'details'
                    },
                    {
                        key:'provinceOfMarriageTermination',
                        detailsKey:'provinceOfMarriageTerminationDetails',
                        section:'beneficiaryInfo.previousSpouse',
                        type:'details'
                    },
                  {
                      fileUploading:false,
                      key:'countryOfBirth',
                      detailsKey:'countryOfBirthDetails',
                      section:'beneficiaryInfo'
                  },
                  {
                      fileUploading:false,
                      key:'provinceOfBirth',
                      detailsKey:'provinceOfBirthDetails',
                      section:'beneficiaryInfo'
                  },
                  {
                      fileUploading:false,
                      key:'countryOfCitizenship',
                      detailsKey:'countryOfCitizenshipDetails',
                      section:'beneficiaryInfo'
                  },
                  {
                      fileUploading:false,
                      key:'curNonImmigrantVisaStatus',
                      detailsKey:'curNonImmigrantVisaStatusDetails',
                      section:'beneficiaryInfo'
                  },
                //   {
                //       fileUploading:false,
                //       key:'filedStateId',
                //       detailsKey:'filedStateDetails',
                //       section:'beneficiaryInfo.immPetitionInfo'
                //   },
                ],
                spouseDetailsItemsList:[
                    {
                        key:'countryOfBirth',
                        detailsKey:'countryOfBirthDetails',
                        section:'dependentsInfo.spouse',
                        type:'details'
                    },
                    {
                        key:'otherCountriesOfCitizenship',
                        detailsKey:'otherCountriesOfCitizenshipDetails',
                        section:'dependentsInfo.spouse',
                        type:'details'
                    },
                    {
                        key:'provinceOfBirth',
                        detailsKey:'provinceOfBirthDetails',
                        section:'dependentsInfo.spouse',
                        type:'details'
                    },
                    {
                        key:'countryOfCitizenship',
                        detailsKey:'countryOfCitizenshipDetails',
                        section:'dependentsInfo.spouse',
                        type:'details'
                    },
                    {
                        key:'passportIssuedCountry',
                        detailsKey:'passportIssuedCountryDetails',
                        section:'dependentsInfo.spouse',
                        type:'details'
                    },
                    {
                        key:'phoneNumber',
                        detailsKey:'phoneCountryCode',
                        section:'dependentsInfo.spouse',
                        type:'phone'
                    },
                    {
                        key:'cellPhoneNumber',
                        detailsKey:'cellPhoneCountryCode',
                        section:'dependentsInfo.spouse',
                        type:'phone'
                    },
                  
                ],
                previousSpouseIgnoreItems:['countryOfMarriage','countryOfMarriageDetails','provinceOfMarriage','provinceOfMarriageDetails','countryOfMarriageTermination',
                'countryOfMarriageTerminationDetails','provinceOfMarriageTermination','provinceOfMarriageTerminationDetails'],
            };
        },
        computed: {
          currentRouteName() {
          return this.$route.name;
          },
          checkActiveTab(){
            return  _.findIndex(this.tabslist ,{"key":this.currentTab});
          },  
            gettotalDays() {
                var totaldays = 0;
                if(this.petition.beneficiaryInfo && this.checkProperty(this.petition.beneficiaryInfo, 'priorPeriodOfStayInUS')  && this.checkProperty(this.petition.beneficiaryInfo, 'priorPeriodOfStayInUS', 'length')>0){
                  this.petition.beneficiaryInfo.priorPeriodOfStayInUS.forEach(function (item, index) {
                      if (item.noOfDays > 0) {
                          totaldays = totaldays + item.noOfDays;
      
                      }
                  })
                  return totaldays;
              }
            },
            getIndexOfActivetab() {
                var $self = this;
                return _.findIndex(this.tabslist, (e) => {
                    return e.key == $self.currentTab;
                }) + 1;
            },
            actiontype() {
                if (this.getIndexOfActivetab == this.tabslist.length) {
                    if (this.petition.questionnaireFilled) {
                        return "Update";
                    }
                    if (!this.petition.questionnaireFilled) {
                        return "Review & Submit";
                    }
                    return "Submit";
                }
                return "Next";
            }
    
        },
        methods: {
            formatFullname(item){
                let returnVal = ''
                if(this.checkProperty(item,'name')){
                    return returnVal = this.checkProperty(item,'name')
                }
                else{
                    if(this.checkProperty(item,'firstName')){
                        returnVal = this.checkProperty(item,'firstName')
                    }
                    if(this.checkProperty(item,'middleName')){
                         returnVal = returnVal +' '+ this.checkProperty(item,'middleName')
                    }
                    if(this.checkProperty(item,'lastName')){
                        returnVal =  returnVal +' '+this.checkProperty(item,'lastName')
                    }
                    return returnVal
                }
            },
            toggleSpouseForm(){
                if (this.spouse.saved) {
                } else {
                    this.spouse.hasSpouse = false
                    this.petition.dependentsInfo.spouse.hasSpouse = false;
                }
                this.spouseModalForm = false;
            },
            updateVerificationStatus(status=false){
                this.openGeneratePinPopUp =false;
                this.tokenVerified = status;
                this.init();
            },
            emitUploadingAction(data){
                if(_.has(data,'docMainCategory')){
                    _.map(this[data['docMainCategory']],(item)=>{
                        if(item['key'] == data['fieldName']){
                            item = Object.assign( item ,{ "fileUploading": false})
                            item['fileUploading'] = data['action'] 
                        }
                    })
                }
                this.checkSubmitBtn()
            },
            checkSubmitBtn(){
                
                this.documentUploading = false;
                let uploadingList =  _.filter(this.bendocslist,(docData)=>{
                    if((docData ,'fileUploading')){
                        if(docData['fileUploading']){
                            return true
                        }else{
                            return false
                        }
                    }else{
                        return false
                    }
                    

                })

                if(uploadingList && uploadingList.length>0){
                this.documentUploading = true;

            }
        
        
        return _.cloneDeep(this.documentUploading);
                
            },
            conformBenProfile(conform=false){
                this.toggleBenProfileCOnformPopUp(false);
                this.$vs.loading();
                if(conform){
                    this.updateBeneficiaryProfile();
                }
                
                this.saveCase(this.tempSave,this.showMessage);
            },
            toggleBenProfileCOnformPopUp(action=false){
                this.showBenProfileSyncPopup = action;
    
            },
            updateBeneficiaryProfile(){
                var postpetition = {
                    userId: this.checkProperty(this.petition,'userId'),
                    currentDate: moment().format("YYYY-MM-DD"),
                };
                if(_.has(this.benProfileDetails,'beneficiaryInfo')){
                    postpetition['beneficiaryInfo'] = this.benProfileDetails.beneficiaryInfo;
                }
                if(_.has(this.benProfileDetails,'documents')){
                    postpetition['documents'] = this.benProfileDetails.documents;
                }
                let path = '/beneficiary-profile/update-beneficiary-profile'
                this.$store.dispatch("commonAction", {data:postpetition,path:path}).then((res)=>{
                    this.showBenProfileSyncPopup = false;
                }).catch((err)=>{
                    
                })
            },
            prepopulateQuestionnaire(tplsection='beneficiaryInfo'){
                let questionnaireSection = tplsection;
                if(questionnaireSection == 'beneficiaryInfo' ){
                    _.forEach(this.petition[questionnaireSection], (item,key)=>{
                        if(this.canRenderField( key, this.questionnaireDetails ,false, questionnaireSection) && this.ignoreItems.indexOf(key)<=-1 && _.has(this.latestPetition, questionnaireSection+'.'+key) ){
                            this.petition[questionnaireSection][key] = _.cloneDeep(this.latestPetition[questionnaireSection][key]);
                        }
                    })
                }
                if(questionnaireSection == 'detailsItemsList' ){
                    _.forEach(this.detailsItemsList, (item)=>{
                        let tempSection = item['section']
                        let tempKey = item['key']
                        let tempdetailsKey = item['detailsKey']
                        if(tempSection == 'beneficiaryInfo.previousSpouse'){
                            if(this.checkProperty(this.latestPetition, 'beneficiaryInfo', 'previousSpouse')  && _.has(this.latestPetition['beneficiaryInfo']['previousSpouse'], tempKey)
                            && _.has(this.petition['beneficiaryInfo'],'previousSpouse' ) && _.has(this.petition['beneficiaryInfo']['previousSpouse'],tempKey)){
                                if(this.canRenderField( tempKey, this.questionnaireDetails ,false, tempSection) && _.has(this.latestPetition, tempSection+'.'+tempKey) && _.has(this.petition, tempSection+'.'+tempKey)){
                                    this.petition['beneficiaryInfo']['previousSpouse'] = this.latestPetition['beneficiaryInfo']['previousSpouse'][tempKey];
                                    this.petition['beneficiaryInfo']['previousSpouse'] = this.latestPetition['beneficiaryInfo']['previousSpouse'][tempdetailsKey];
                                }
                            }else{
                                this.petition['beneficiaryInfo']['previousSpouse'] = this.getPreviousSpouseObj();
                            }
                        }else{
                            if(this.canRenderField( tempKey, this.questionnaireDetails ,false, tempSection) && _.has(this.latestPetition, tempSection+'.'+tempKey) && _.has(this.petition, tempSection+'.'+tempKey)){
                                this.petition[tempSection][tempKey] = this.latestPetition[tempSection][tempKey];
                                this.petition[tempSection][tempdetailsKey] = this.latestPetition[tempSection][tempdetailsKey];
                            }
                        }
                    })
                }
                if(questionnaireSection == 'educations' || questionnaireSection == 'prevEmploymentInfo' || questionnaireSection == 'vacationalOrTrainingInst'){
                    let tempSection = 'beneficiaryInfo.prevEmploymentInfo'
                    if(questionnaireSection == 'educations'){
                        tempSection = 'beneficiaryInfo.educations'
                    }
                    if(this.canRenderField( questionnaireSection, this.questionnaireDetails ,false, tempSection)){
                        if(this.checkProperty(this.latestPetition['beneficiaryInfo'], questionnaireSection) && this.checkProperty(this.latestPetition['beneficiaryInfo'], questionnaireSection, 'length')>0 ){
                            // _.forEach(this.petition['beneficiaryInfo'][questionnaireSection], (item)=>{
                            //     _.forEach(item, (obj,key)=>{
                            //         if(this.canRenderField( key, this.questionnaireDetails ,false, tempSection) && key != 'supervisor' && _.has(this.latestPetition, tempSection+'.'+key)){
                            //             item[key] = _.cloneDeep(this.latestPetition['beneficiaryInfo'][questionnaireSection][0][key]);
                            //         }
                            //     }) 
                            // }) 
                            this.petition['beneficiaryInfo'][questionnaireSection] = _.cloneDeep(this.latestPetition['beneficiaryInfo'][questionnaireSection])
    
                        } 
                    } 
                }
                if(questionnaireSection == 'beneficiaryInfo.immPetitionInfo' ){
                    if(this.checkProperty(this.latestPetition,'beneficiaryInfo','immPetitionInfo')){
                        _.forEach(this.petition['beneficiaryInfo']['immPetitionInfo'], (item,key)=>{
                            if(this.canRenderField( key, this.questionnaireDetails ,false, questionnaireSection) && _.has(this.latestPetition, questionnaireSection+'.'+key)  && ['filedStateDetails','filedStateId'].indexOf(key)<=-1){
                                this.petition['beneficiaryInfo']['immPetitionInfo'][key] = _.cloneDeep(this.latestPetition['beneficiaryInfo']['immPetitionInfo'][key]);
                            }else{
                                if(this.canRenderField( key, this.questionnaireDetails ,false, questionnaireSection) &&['filedStateId'].indexOf(key)>-1 && _.has(this.latestPetition, questionnaireSection+'.'+key) && _.has(this.petition, questionnaireSection+'.'+key) && this.checkProperty(this.latestPetition['beneficiaryInfo']['immPetitionInfo'],key) ){
                                    this.petition['beneficiaryInfo']['immPetitionInfo'][key] = _.cloneDeep(this.latestPetition['beneficiaryInfo']['immPetitionInfo'][key]);
                                    if(this.checkProperty(this.latestPetition['beneficiaryInfo']['immPetitionInfo'], 'filedStateDetails') && _.has(this.petition, questionnaireSection+'.'+'filedStateDetails')){
                                        this.petition['beneficiaryInfo']['immPetitionInfo']['filedStateDetails'] = _.cloneDeep(this.latestPetition['beneficiaryInfo']['immPetitionInfo']['filedStateDetails']);
                                    }
                                    
                                }
                            }
                        })
                    }else{
                        this.petition['beneficiaryInfo']['immPetitionInfo'] = this.getImmipetitionObj();
                    }
                }
                if(questionnaireSection == 'priorPeriodOfStayInUS'){
                    let tempSection = 'beneficiaryInfo'
                    if(this.canRenderField( questionnaireSection, this.questionnaireDetails ,false, tempSection)){
                        if(this.checkProperty(this.latestPetition['beneficiaryInfo'], questionnaireSection) && this.checkProperty(this.latestPetition['beneficiaryInfo'], questionnaireSection, 'length')>0 ){
                            this.petition['beneficiaryInfo'][questionnaireSection] = _.cloneDeep(this.latestPetition['beneficiaryInfo'][questionnaireSection])
                        }else{
                        this.petition['beneficiaryInfo'][questionnaireSection] =
                            [{
                                _id: 0,
                                visaStatus: null,
                                visaStatusDetails: null,
                                noOfDays: null,
                                enteredDate: null,
                                departedDate: null,
                                dateerror: false
                            }]
                        }
                    }
                }
                if(questionnaireSection == 'documents'){
                    if(questionnaireSection == 'documents'){
                        _.forEach(this.petition['documents'], (item,key)=>{
                            if(this.canRenderField( key, this.questionnaireDetails ,false, 'documents') && _.has(this.latestPetition, 'documents'+'.'+key)){
                                this.petition['documents'][key] = this.latestPetition['documents'][key]; ;
                                
                            }
                        })
                    }
                }
            },
            questionnairePrefil(tplsection='beneficiaryInfo'){
                this.executionCompleted = false; 
                let questionnaireSection = tplsection;
                if(questionnaireSection == 'beneficiaryInfo' ){
                    _.forEach(this.petition[questionnaireSection], (item,key)=>{
                        if(!this.canRenderField( key, this.questionnaireDetails ,false, questionnaireSection) && this.ignoreItems.indexOf(key)<=-1 ){
                            this.petition[questionnaireSection][key] = _.cloneDeep(this.tempPetition[questionnaireSection][key]);
                            delete this.benProfileDetails[questionnaireSection][key]
                        }
                    })
                }
                if(questionnaireSection == 'detailsItemsList' ){
                    _.forEach(this.detailsItemsList, (item)=>{
                        let tempSection = item['section']
                        let tempKey = item['key']
                        let tempdetailsKey = item['detailsKey']
                        if(!this.canRenderField( tempKey, this.questionnaireDetails ,false, tempSection)){
                            this.petition[tempSection][tempKey] = null;
                            this.petition[tempSection][tempdetailsKey] = null;
                            delete this.benProfileDetails[tempSection][tempKey]
                            delete this.benProfileDetails[tempSection][tempdetailsKey]
                        }
                    })
                }
                if(questionnaireSection == 'educations' || questionnaireSection == 'prevEmploymentInfo'){
                    let tempSection = 'beneficiaryInfo.prevEmploymentInfo'
                    if(questionnaireSection == 'educations'){
                        tempSection = 'beneficiaryInfo.educations'
                    }
                    if(this.canRenderField( questionnaireSection, this.questionnaireDetails ,false, tempSection)){
                        if(this.checkProperty(this.petition['beneficiaryInfo'], questionnaireSection) && this.checkProperty(this.petition['beneficiaryInfo'], questionnaireSection, 'length')>0 ){
                            _.forEach(this.petition['beneficiaryInfo'][questionnaireSection], (item,inder)=>{
                                _.forEach(item, (obj,key)=>{
                                    if(!this.canRenderField( key, this.questionnaireDetails ,false, tempSection) && key != 'supervisor'){
                                        item[key] = _.cloneDeep(this.tempPetition['beneficiaryInfo'][questionnaireSection][0][key]);
                                        delete this.benProfileDetails['beneficiaryInfo'][questionnaireSection][inder][key]
    
                                    }
                                })
                            }) 
                        }else{
                            delete this.benProfileDetails['beneficiaryInfo'][questionnaireSection]
                        } 
                    }else{
                        delete this.benProfileDetails['beneficiaryInfo'][questionnaireSection]
                        this.petition['beneficiaryInfo'][questionnaireSection] = _.cloneDeep(this.tempPetition['beneficiaryInfo'][questionnaireSection])
                    }  
                }
                if(questionnaireSection == 'beneficiaryInfo.immPetitionInfo' ){
                    if(this.checkProperty(this.petition,'beneficiaryInfo','immPetitionInfo')){
                        _.forEach(this.petition['beneficiaryInfo']['immPetitionInfo'], (item,key)=>{
                            if(!this.canRenderField( key, this.questionnaireDetails ,false, 'beneficiaryInfo.immPetitionInfo') && ['filedStateDetails','filedStateId'].indexOf(key)<=-1){
                                delete this.benProfileDetails['beneficiaryInfo']['immPetitionInfo'][key]
                                this.petition['beneficiaryInfo']['immPetitionInfo'][key] = _.cloneDeep(this.tempPetition['beneficiaryInfo']['immPetitionInfo'][key]);
                            }
                        })
                    }
                }
                if(questionnaireSection == 'beneficiaryInfo.previousSpouse'){
                    if(this.checkProperty(this.petition['beneficiaryInfo'], 'previousSpouse')){
                        _.forEach(this.petition['beneficiaryInfo']['previousSpouse'], (item,key)=>{
                            if(!this.canRenderField( key, this.questionnaireDetails ,false, questionnaireSection) && this.previousSpouseIgnoreItems.indexOf(key)<=-1 ){
                                delete this.benProfileDetails['beneficiaryInfo']['previousSpouse'][key]
                                this.petition['beneficiaryInfo']['previousSpouse'][key] = _.cloneDeep(this.tempPetition['beneficiaryInfo']['previousSpouse'][key]);
                            }
                        })
                    }
                }
                if(questionnaireSection == 'prevEmploymentInfo.supervisor'){
                    let tempSection = 'beneficiaryInfo.prevEmploymentInfo.supervisor'
                    if(this.canRenderField( 'prevEmploymentInfo', this.questionnaireDetails ,false, 'beneficiaryInfo.prevEmploymentInfo')){
                        if(this.checkProperty(this.petition['beneficiaryInfo'], 'prevEmploymentInfo') && this.checkProperty(this.petition['beneficiaryInfo'], 'prevEmploymentInfo', 'length')>0 ){
                            _.forEach(this.petition['beneficiaryInfo']['prevEmploymentInfo'], (item,inder)=>{
                                _.forEach(item['supervisor'], (obj,key)=>{
                                    if(!this.canRenderField( key, this.questionnaireDetails ,false, 'beneficiaryInfo.prevEmploymentInfo.supervisor')){
                                        item['supervisor'][key] = _.cloneDeep(this.tempPetition['beneficiaryInfo']['prevEmploymentInfo'][0]['supervisor'][key]);
                                        delete this.benProfileDetails['beneficiaryInfo']['prevEmploymentInfo'][inder]['supervisor'][key]
                                    }
                                })
                            }) 
                        }else{
                            delete this.benProfileDetails['beneficiaryInfo']['prevEmploymentInfo']
                        }
                    }else{
                        delete this.benProfileDetails['beneficiaryInfo']['prevEmploymentInfo']
                        this.petition['beneficiaryInfo']['prevEmploymentInfo'] = _.cloneDeep(this.tempPetition['beneficiaryInfo']['prevEmploymentInfo'])
                    }  
                }
                if( questionnaireSection == 'vacationalOrTrainingInst'){
                    let tempSection = 'beneficiaryInfo.vacationalOrTrainingInst'
                    if(this.canRenderField( 'vacationalOrTrainingInst', this.questionnaireDetails ,false, tempSection)){
                        if(this.checkProperty(this.petition['beneficiaryInfo'], questionnaireSection) && this.checkProperty(this.petition['beneficiaryInfo'], questionnaireSection, 'length')>0 ){
                            _.forEach(this.petition['beneficiaryInfo'][questionnaireSection], (item,inder)=>{
                                _.forEach(item, (obj,key)=>{
                                    if(!this.canRenderField( key, this.questionnaireDetails ,false, tempSection) ){
                                        item[key] = _.cloneDeep(this.tempPetition['beneficiaryInfo'][questionnaireSection][0][key]);
                                        delete this.benProfileDetails['beneficiaryInfo'][questionnaireSection][inder][key]
                                    }
                                })
                            }) 
                        }else{
                            delete this.benProfileDetails['beneficiaryInfo']['vacationalOrTrainingInst']
                        }
                    }else{
                        delete this.benProfileDetails['beneficiaryInfo']['vacationalOrTrainingInst']
                        this.petition['beneficiaryInfo']['vacationalOrTrainingInst'] = _.cloneDeep(this.tempPetition['beneficiaryInfo']['vacationalOrTrainingInst'])
                    }
                }
                if(questionnaireSection == 'dependentsInfo.spouse'){
                    if(_.has(this.petition['dependentsInfo'], 'spouse') && this.checkProperty(this.petition['dependentsInfo'], 'spouse')){
                        _.forEach(this.petition['dependentsInfo']['spouse'], (item,key)=>{
                            if(!this.canRenderField( key, this.questionnaireDetails ,false, questionnaireSection) && this.spouseIgnoreItems.indexOf(key)<=-1 ){
                                delete this.benProfileDetails['dependentsInfo']['spouse'][key]
                                this.petition['dependentsInfo']['spouse'][key] = _.cloneDeep(this.tempPetition['dependentsInfo']['spouse'][key]);
                            }
                        })
                    }else{
                        this.petition['dependentsInfo']['spouse'] = this.getSpouseObj();
                    }
                }
                if(questionnaireSection == 'spouseDetailsItemsList' ){
                    _.forEach(this.spouseDetailsItemsList, (item)=>{
                        let tempSection = item['section']
                        let tempKey = item['key']
                        let tempdetailsKey = item['detailsKey']
                        let tempType = item['type']
                        if(_.has(this.petition['dependentsInfo'], 'spouse') && this.checkProperty(this.petition['dependentsInfo'], 'spouse')){
                            if(tempType == 'phone'){
                                if(tempSection == 'dependentsInfo.spouse'){
                                    if(!this.canRenderField( tempKey, this.questionnaireDetails ,false, tempSection)){
                                        this.petition['dependentsInfo']['spouse'][tempKey] = null;
                                        this.petition['dependentsInfo']['spouse'][tempdetailsKey] = {
                                            countryCode: '',
                                            countryCallingCode: ''
                                        };
                                        delete this.benProfileDetails['dependentsInfo']['spouse'][tempKey]
                                        delete this.benProfileDetails['dependentsInfo']['spouse'][tempdetailsKey]
                                    }
                                }
                            }else{
                                if(tempSection == 'dependentsInfo.spouse'){
                                    if(!this.canRenderField( tempKey, this.questionnaireDetails ,false, tempSection)){
                                        this.petition['dependentsInfo']['spouse'][tempKey] = null;
                                        this.petition['dependentsInfo']['spouse'][tempdetailsKey] = null;
                                        delete this.benProfileDetails['dependentsInfo']['spouse'][tempKey]
                                        delete this.benProfileDetails['dependentsInfo']['spouse'][tempdetailsKey]
                                    }
                                }
                            }
                        }
                    })
                }
                if(questionnaireSection == 'documents'){
                    if(questionnaireSection == 'documents'){
                        _.forEach(this.petition['documents'], (item,key)=>{
                            if(!this.canRenderField( key, this.questionnaireDetails ,false, 'documents')){
                                this.petition['documents'][key] = [];
                                delete this.benProfileDetails['documents'][key]
                                
                            }
                        })
                    }
                }
                this.executionCompleted = true;
            },
            workFlowDetailsConfig(){
                let payLoad = {
                path: "/workflow/details",
                data: { workflowId: this.petition['workflowId'] },
            };
            this.$store
                .dispatch("commonAction", payLoad)
                .then((res) => {
                this.workFlowDetails = res;
                //  this.checPreParePermApplicationRestriction();
    
                })
            },
            checPreParePermApplicationRestriction(){
                let advCoolingPeriod =0;
                if(this.checkProperty(this.petition,'advCoolingPeriod') >0){
                    advCoolingPeriod =parseInt(this.petition['advCoolingPeriod']);
                }
                
                if(this.currentRouteName =='permapplication-questionnaire'){
                        
                        
                    let allAvertise =[];
                    let today = moment().format("YYYY-MM-DD");
                    let preparePermApplicationActivity = _.find(this.workFlowDetails.config , {"code":'PREPARE_PERM_APPLICATION'});
                        // startDateKey:'startDateOfAdvAtJobFair',
                        //endDateKey:'endDateOfAdvAtJobFair',
                    _.forEach(this.avertisementList ,(item)=>{
                    let tempItem = {
                        startDateVal:'',
                        endDateVal:''
                    }
                    if(_.has(this.petition['recruitmentInfo'], item['startDateKey'] ) && this.checkProperty(this.petition['recruitmentInfo'] ,item['startDateKey'])  ){
                        try{
                            let startDateVal = this.petition['recruitmentInfo'][item['startDateKey']];
                            tempItem['startDateVal'] =moment(startDateVal).format("YYYY-MM-DD");
                            
                        }catch(err){}
                    }
                    if(_.has(this.petition['recruitmentInfo'], item['endDateKey'] ) && this.checkProperty(this.petition['recruitmentInfo'], item['endDateKey'])  ){
                        try{
                            let endDateVal = this.petition['recruitmentInfo'][item['endDateKey']];
                            tempItem['endDateVal'] =moment(endDateVal).format("YYYY-MM-DD");
    
                        }catch(err){}
                    }
                    if(tempItem['startDateVal'] && tempItem['endDateVal'] ){
                        allAvertise.push(tempItem);
                    }
    
                    });
    
                    allAvertise = _.orderBy(allAvertise ,['endDateVal'] ,['desc']);
                    if(this.checkProperty(allAvertise ,'length') >0){
                    let lastAdverStartDate = moment(allAvertise[0]['endDateVal']);
                    let dateDif = moment().diff(lastAdverStartDate, 'days') ;
    
    
                    if(dateDif<advCoolingPeriod){  
                        let remainingDays = advCoolingPeriod-dateDif;
                        let msg ="It is recommended that a cooling period of "+advCoolingPeriod+" days must be maintained before the PERM Draft is created"
            
                        if(dateDif<0){         
                            if(lastAdverStartDate.isAfter(moment() ,'day')){
    
                            remainingDays = advCoolingPeriod+(lastAdverStartDate.diff(moment(), 'days'))
    
                            }  
    
                            msg ="It is recommended that a cooling period of "+remainingDays+" days must be maintained before the PERM Draft is created";
                        }else if(dateDif>0){
                            msg ="It has been "+dateDif+" days since the last advertisement is placed. It is recommended that a cooling period of "+advCoolingPeriod+" days must be maintained before the PERM Draft is created"
    
                        }
                    if(preparePermApplicationActivity && this.checkProperty(preparePermApplicationActivity ,'restrictPermDraftByAdvConfig') =="Yes"){
                        
                        this.showToster({message:msg,isError:true });
                        this.$router.push({ name: 'gc-employment-details', params: { itemId:this.petition['_id']} }) 
                        //  return false;
                    }else{
                        //this.showToster({message:msg,isError:true });
                    // this.editQuestionnaire('PREPARE_PERM_APPLICATION');
                    }
                    }else{
                // this.editQuestionnaire('PREPARE_PERM_APPLICATION');
                    }
    
                    }else{
                    //this.editQuestionnaire('PREPARE_PERM_APPLICATION');
                    }
                }
    
    
    
        // 
            },
            updatecellPhoneCountryCode(data){
                this.petition.beneficiaryInfo.cellPhoneCountryCode = data
            },
            updatehomePhoneCountryCode(data){
                this.petition.beneficiaryInfo.homePhoneCountryCode = data
            },
            updateworkPhoneCountryCode(data){
                this.petition.beneficiaryInfo.workPhoneCountryCode = data
            },
            updatefaxCountryCode(data){
                this.petition.beneficiaryInfo.faxCountryCode = data
            },
            updateState(item){
                if(_.has( item ,'id')){
                    this.petition['refilingInstructions']['caseFiledStateId'] =item['id'];
                }
            },
            getUsStatusList(){
                    this.$store .dispatch("getstates", 231) .then((response) => {
                        this.usStatusList = response;
                    })
                    .catch(() => {
                    this.usStatusList = [];
                    });
            },
            getMasterSocList(){
    
                    let query = {};
                    query["page"] = 1;
                    query["perpage"] = 10000;
                    query["matcher"] = {};
                    query["category"] = "soc_codes";
    
    
                    this.$store
                    .dispatch("getMasterData", query)
                    .then((response) => {
                    this.masterSocList = response.list;
                    
                    //alert(this.perpage);
                    })
                    .catch(() => {
                    this.masterSocList = [];
    
                    });
    
            },
            setSameaddress( callFromCheckBox=true){
                
                if( this.petition.beneficiaryInfo.mailingAddressIsSameAsAddress){
                    this.petition.beneficiaryInfo['mailingAddress'] = _.cloneDeep(this.petition.beneficiaryInfo['currentAddress']);
                }else{
                    if(callFromCheckBox){
    
                    this.petition.beneficiaryInfo['mailingAddress'] =  {
                            line1: null,
                            line2: null,
                            aptType: null,
                            locationId: null,
                            locationDetails: null,
                            stateId: null,
                            stateDetails: null,
                            countryId: null,
                            countryDetails: null,
                            zipcode: null
                    }
                }
    
                }
        
    
            },
            sethaveYouEverTravelledToUS(val){
                this.petition.beneficiaryInfo.haveYouEverTravelledToUS = val;
                if(!val){
                    this.petition.beneficiaryInfo.nonImmPetitionsInfo = [{
                            _id: 0,
                            visaStatus: null,
                            visaStatusDetails: null,
                            receiptNo: '',
                            petitionerName: ''
                        }]
                }
                
            },
            customvalidations() {
                var valid = true;
                if(this.petition.beneficiaryInfo && this.checkProperty(this.petition.beneficiaryInfo, 'priorPeriodOfStayInUS')  && this.checkProperty(this.petition.beneficiaryInfo, 'priorPeriodOfStayInUS', 'length')>0){
                this.petition.beneficiaryInfo.priorPeriodOfStayInUS.forEach((element, index) => {
    
                    if (element.dateerror) {
                        valid = false;
                        return valid;
                    }
    
                });
              }
    
                return valid;
            },
            submitCase() {
    
                this.$validator.validateAll(this.currentTab + "form").then((result) => {
                  let self =this;
                    if (result && this.customvalidations()) {
                        if (this.getIndexOfActivetab < this.tabslist.length) {
                          
                            this.setActiveTab(this.tabslist[this.getIndexOfActivetab].key);
    
                            setTimeout(function () {
                                document.getElementById("scrollableques").scrollTo({
                                    top: 0,
                                    left: 0,
                                    behavior: 'smooth'
                                })
                            }, 500)
    
                        } else {
                          
                          if (this.petition.questionnaireFilled) {
                              self.tempSave =true;
                              self.showMessage = false
                              this.benProfileDetails = _.cloneDeep(this.petition);
                              this.toggleBenProfileCOnformPopUp(true);
                              // this.$vs.loading();
                              //     this.saveCase(true, false);
                          }else{
                              this.setSameaddress(false);
                              this.benProfileDetails = _.cloneDeep(this.petition);
                              this.questionnairePrefil('beneficiaryInfo'); //'prevEmploymentInfo.supervisor'  detailsItemsList 
                              this.checkImmipetition();
                              this.questionnairePrefil('detailsItemsList');
                              this.questionnairePrefil('vacationalOrTrainingInst');
                              this.questionnairePrefil('prevEmploymentInfo.supervisor');
                              this.questionnairePrefil('educations');
                              this.questionnairePrefil('prevEmploymentInfo');
                              this.questionnairePrefil('previousSpouse');
                              this.questionnairePrefil('documents'); 
                              this.removeEmptyEducations();
                              this.questionnairePrefil('dependentsInfo.spouse');
                              this.questionnairePrefil('spouseDetailsItemsList');
                              this.questionnairePrefil('beneficiaryInfo.immPetitionInfo');
                              this.checkPreviousSpouse();
                          let temp_save =false;
                          this.questionnairePreviewData = {
                          petitionId: this.$route.params.itemId,
                          userName: this.$store.state.user.name,
                          typeName: this.petition.typeDetails.name,
                          subTypeName: this.petition.subTypeDetails.name,
                          typeDetails:this.petition.typeDetails,
                          subTypeDetails:this.petition.subTypeDetails,
                          highestDegreeList:this.petition.highestDegreeList,
                          // action: temp_save ? "BENEFICIARY_INFO_UPDATE" : "SUBMIT_BY_BENEFICIARY",
                          "updateSection": "SUBMIT_BY_BENEFICIARY",
                          "action": "SUBMIT_BY_BENEFICIARY",
                          currentDate: moment().format("YYYY-MM-DD"),
                          beneficiaryInfo: this.petition.beneficiaryInfo,
                          dependentsInfo: this.petition.dependentsInfo,
                          documents: this.petition.documents,
                          temp_save: false,
                          questionnaireFilled: true,
                          today:moment().format("YYYY-MM-DD"),
                          };
                          this.questionnairePreviewData.noOfDaysStayInUS = this.gettotalDays;
  
                          if(this.currentRouteName =='permapplication-questionnaire' || this.currentRouteName =='permapplicationSuggession-questionnaire'){
                         
                          this.questionnairePreviewData['alienInfo'] = this.checkProperty( this.petition ,'alienInfo');
                          this.questionnairePreviewData['refilingInstructions'] = this.checkProperty( this.petition ,'refilingInstructions');
                          if(this.currentRouteName =='permapplication-questionnaire'){
                              this.questionnairePreviewData['action']="PREPARE_PERM_APPLICATION"; //PERM_DRAFT_SUGGESSION
                          }else{
                              this.questionnairePreviewData['action']="PERM_DRAFT_SUGGESSION"; //PREPARE_PERM_APPLICATION
                              this.questionnairePreviewData['permDraftSuggessionType']='perm_update'
  
                          }
                          this.questionnairePreviewData['temp_save'] =false;
  
                          }
                          this.questionnairePreview = true;
  
                  }
                          
    
                        }
    
                    } else {
                        this.validateandScroll();
    
                    }
                })
            },
            findNewDocs(){
                  this.newDocs =[];
                  _.forEach(this.petition.documents,(docs,category )=>{
                      if(docs && docs.length>0){
                          _.forEach(docs ,(document)=>{
                              if(_.has(document ,'isNew' ) && document['isNew'] ==true && _.get(document ,'path') && _.has(document ,'status' ) && document['status'] ==true ){
                                  this.newDocs.push(document)
                              }
  
                          })
  
                      }
  
                  });
  
            },
            saveCase(temp_save, show_message = true) {
              this.newDocs =[];
              this.findNewDocs();
  
                this.setSameaddress(false);
                this.$vs.loading();
                this.petition.noOfDaysStayInUS = this.gettotalDays;
                this.benProfileDetails = _.cloneDeep(this.petition);
            
                this.checkImmipetition();
                this.questionnairePrefil('beneficiaryInfo');
                this.questionnairePrefil('vacationalOrTrainingInst');
                this.questionnairePrefil('prevEmploymentInfo.supervisor');
                this.questionnairePrefil('educations');
                this.questionnairePrefil('prevEmploymentInfo');
                this.questionnairePrefil('previousSpouse');
                this.questionnairePrefil('documents');
                this.removeEmptyEducations();
                this.questionnairePrefil('dependentsInfo.spouse');
                this.questionnairePrefil('spouseDetailsItemsList');
                this.questionnairePrefil('beneficiaryInfo.immPetitionInfo');  
                this.checkPreviousSpouse();      
                var postpetition = {
                    petitionId: this.$route.params.itemId,
                    userName: this.$store.state.user.name,
                    typeName: this.petition.typeDetails.name,
                    subTypeName: this.petition.subTypeDetails.name,
                   // action: temp_save ? "BENEFICIARY_INFO_UPDATE" : "SUBMIT_BY_BENEFICIARY",
                    "updateSection": "SUBMIT_BY_BENEFICIARY",
                    "action": "SUBMIT_BY_BENEFICIARY",
                    currentDate: moment().format("YYYY-MM-DD"),
                    beneficiaryInfo: this.petition.beneficiaryInfo,
                    dependentsInfo: this.petition.dependentsInfo,
                    documents: this.petition.documents,
                    temp_save: temp_save,
                    questionnaireFilled: temp_save ? false : true,
                    today:moment().format("YYYY-MM-DD"),
                    newDocs:[]
                };
                postpetition['newDocs'] = this.newDocs;              
                let path ="/perm/update";
  
                if(this.currentRouteName =='permapplication-questionnaire' || this.currentRouteName =='permapplicationSuggession-questionnaire'){
                  path ="/perm/manage-perm-application";
                  postpetition['alienInfo'] = this.checkProperty( this.petition ,'alienInfo');
                  postpetition['refilingInstructions'] = this.checkProperty( this.petition ,'refilingInstructions');
                  if(this.currentRouteName =='permapplication-questionnaire'){
                      postpetition['action']="PREPARE_PERM_APPLICATION"; //PERM_DRAFT_SUGGESSION
                  }else{
                      postpetition['action']="PERM_DRAFT_SUGGESSION"; //PREPARE_PERM_APPLICATION
                      postpetition['permDraftSuggessionType']='perm_update'
                      
                  }
                  postpetition['temp_save'] =false;
                  
                }
                  if(!this.checkCurrentUrl){
                      postpetition['submittedWithLink'] =true;
                  }
  
                this.$store.dispatch('commonAction',{data:postpetition ,path:path })
                    .then((response) => {
  
                     
                      this.showBenProfileSyncPopup = false;
                        if (this.checkProperty(response, "error")) {
    
                            if (show_message) {
    
                                this.showToster({
                                    message: response.error.message,
                                    isError: true,
                                });
                            } else {
    
                                this.$vs.loading.close();
                            }
    
                        } 
                        else { 
                         
  
                              let currentRoute = this.$route;
    
                    if ( !show_message && !this.checkCurrentUrl &&   _.get(currentRoute, "name", "") == "fill-perm-questionnaire" &&  _.has(currentRoute, "meta.getTokenFromUrl") &&
                        _.has(currentRoute, "query.token")
                    ) {
                        let token = _.get(currentRoute, "query.token", "");
                        let url = "/filled-perm-case-details/" + this.$route.params.itemId + "?token=" + token;
                        //   window.location.href = window.location.origin+'/app'+url
  
                        this.showToster({  message: "Questionnaire saved successfully",  isError: false,  });
                              this.$router.push(url) //petitionId
                       
                    }else if(this.currentRouteName =='permapplication-questionnaire' || this.currentRouteName =='permapplicationSuggession-questionnaire'){
                              this.showToster({  message: "PERM Application saved successfully",  isError: false,  });
                              this.$router.push("/gc-employment-details/"+ this.$route.params.itemId) //petitionId
                           }else{
                           //success
                            this.spouseModalForm = false;
                            this.childModalForm = false;
                            if (show_message) {
    
                                if (!temp_save) {
                                    this.SuccessQuestionnaire = true;
                                } else {
                                  //success
                                  if(this.currentRouteName =='permapplication-questionnaire' || this.currentRouteName =='permapplicationSuggession-questionnaire'){
                                      this.showToster({  message: "PERM Application saved successfully",  isError: false,  });
                              
                                  }else{
                                      this.showToster({  message: "Questionnaire saved successfully",  isError: false,  });
                               
                                  }
                               }
                                //this.$router.push("/gc-employment-details/"+ this.$route.params.itemId) //petitionId
                            } else {
    
                                if (this.petition.questionnaireFilled) {
                                  if(this.currentRouteName =='permapplication-questionnaire' || this.currentRouteName =='permapplicationSuggession-questionnaire'){
                                      this.showToster({  message: "PERM Application saved successfully",  isError: false,  });
                              
                                  }else{
                                      this.showToster({  message: "Questionnaire updated successfully",  isError: false,});
                                   
                                  }
                                    this.$router.push("/gc-employment-details/"+ this.$route.params.itemId) //petitionId
                                
                                  } else {
    
                                    if (!temp_save) {
                                        this.questionnairePreview = false;
                                        this.$vs.loading.close();
                                        this.SuccessQuestionnaire = true;
                                        document.addEventListener("click", this.reloadthePage);
    
                                    } else {
                                      this.$vs.loading.close();
                                      this.questionnairePreview = false;
                                      if(this.currentRouteName =='permapplication-questionnaire' || this.currentRouteName =='permapplicationSuggession-questionnaire'){
                                          this.showToster({  message: "PERM Application saved successfully",  isError: false,  });
                              
                                       }else{
                                          this.showToster({  message: "Questionnaire updated successfully",  isError: false,});
                                   
                                      }
                                      
                                      this.$router.push("/gc-employment-details/"+ this.$route.params.itemId) //petitionId
                                
                                        
                                        
                                    }
    
                                }
    
                            }
                          }
                        }
    
                        this.$vs.loading.close();
    
                    }).catch((err)=>{
                      this.$vs.loading.close();
                      this.showToster({ message: err, isError: true,  });
                    })
    
            },
            reloadthePage() {
                let routeTest = this.$route.params.itemId;
    
                var _self = this;
                if (this.SuccessQuestionnaire) {
                    this.SuccessQuestionnaire = false;
                }
                setTimeout(() => { 
                    let currentRoute = _self.$route;
    
                    if (
                        _.get(currentRoute, "name", "") == "fill-questionnaire" &&
                        _.has(currentRoute, "meta.getTokenFromUrl") &&
                        _.has(currentRoute, "query.token")
                    ) {
                        let token = _.get(currentRoute, "query.token", "");
                        let url = "/filled-perm-case-details/" + routeTest + "?token=" + token;
                        //   window.location.href = window.location.origin+'/app'+url
                        _self.$router.push(url);
                    } else {
                        if (_self.checkProperty(_self.petition, "rfeCase")) {
                            _self.$router.push("/rfe-petition-details/" + routeTest);
                        } else {
                            _self.$router.push("/gc-employment-details/" + routeTest);
                        }
                    }
                }, 10);
            },
            goBack() {
                this.setActiveTab(this.tabslist[this.getIndexOfActivetab - 2].key)
    
            },
            updateTablist() {
                if (this.petition.beneficiaryInfo && this.petition.beneficiaryInfo.maritalStatusDetails && this.petition.beneficiaryInfo.maritalStatusDetails.id == 2) {
    
                    var index = _.find(this.tabslist, function (item) {
    
                        return item.key == "dependentsinfo"
                    })
                    if (index) {
    
                    } else {
                        this.tabslist.push({
                            key: "dependentsinfo",
                            name: "Dependents Info"
                        })
                    }
    
                } 
                // else {
    
                //     this.tabslist = _.filter(this.tabslist, function (item) {
    
                //         return item.key != "dependentsinfo"
                //     })
                // }
  
                //if route 
                if(this.currentRouteName =='permapplication-questionnaire' || this.currentRouteName =='permapplicationSuggession-questionnaire'){
                  //permapplication-questionnaire
                  let tempList = _.cloneDeep(this.tabslist);
                  let finalList =[{ key: "permApplicationScope", name: "PERM Application" }];
                  _.forEach(tempList ,(item)=>{
                      if(item['key'] !='permApplicationScope'){
                          finalList.push(item);
                      }
                    
                  })
                  this.tabslist =finalList;
                  this.currentTab ='permApplicationScope';
                };
    
            },
            formatName(item) {
    
                var _t = '';
                if (item.name != '' && item.name != null) return _t.name;
                if (item.first_name != null && item.first_name != '') _t = item.first_name;
                if (item.middle_name != null && item.middle_name != '') _t + " " + item.middle_name;
                if (item.last_name != null && item.last_name != '') _t + " " + item.last_name;
    
                return _t;
            },
            validateandScroll() {
                var $self = this;
                const $ = JQuery;
                var el = _.find(this.errors["items"], function (item) {
                    return item.scope == $self.currentTab + "form"
                })
                if (el) {
                    const ele = $("[name=" + el.field + "]").parents(".vx-col");
                    var _top = 0;
                    if (ele) {
                        _top = ele.position().top;
                    }
                }
                document.getElementById("scrollableques").scrollTo({
                    top: _top,
                    left: 0,
                    behavior: 'smooth'
                })
    
            },
            setActiveTab(item, validate = false) {
             //this.currentTab = item;
            
                if (validate) {
    
                    this.$validator.validateAll(this.currentTab + "form").then((result) => {
                        if (result) {
                            this.currentTab = item;
                            document.getElementById("scrollableques").scrollTo({
                                top: 0,
                                left: 0,
                                behavior: 'smooth'
                            })
                        } else {
    
                            this.validateandScroll()
    
                        }
    
                    })
                } else {
                    this.currentTab = item;
    
                    setTimeout(function () {
                        document.getElementById("scrollableques").scrollTo({
                            top: 0,
                            left: 0,
                            behavior: 'smooth'
                        })
                    }, 500)
    
                }
    
            },
            changeBfProvince(value) {
                this.petition.beneficiaryInfo.countryOfBirth = this.petition.beneficiaryInfo.countryOfBirthDetails.id;
                this.bfeprovinceStates = [];
    
                this.loadStatesByCountry('bfeprovinceStates', value.id)
            },
            addOtherNames() {
                let item = {
                    firstName: "",
                    middleName: "",
                    lastName: ""
                };
                this.petition.beneficiaryInfo["otherNames"].push(item);
            },
            removeOtherName(index) {
                this.petition.beneficiaryInfo["otherNames"].splice(index, 1);
            },
            resetOtherNames($event) {
                this.petition.beneficiaryInfo["otherNames"] = [];
                this.addOtherNames();
    
            },
            validateScope() {
                this.$validator.validateAll("casedetailsform").then((result) => {
    
                    this.validateandScroll();
                })
            },
            loadStatesByCountry(model, countryId) {
    
                this.$store.dispatch("getstates", countryId).then((response) => {
                    switch (model) {
                        case "bfeprovinceStates":
                            this.bfeprovinceStates = response;
                            break;
                        case "usastates":
                            this.usastates = response;
                        break;    
                    }
    
                  //   var provinceOfBirth = this.petition.beneficiaryInfo.provinceOfBirth;
                  //   if (provinceOfBirth != null) {
                  //       var item = _.find(this.bfeprovinceStates, function (item) {
    
                  //           return item.id == provinceOfBirth
                  //       })
                  //       if (item) {
                          
                  //       }
                  //       if (!item) {
                  //           this.petition.beneficiaryInfo.provinceOfBirth = null;
                  //           this.petition.beneficiaryInfo.provinceOfBirthDetails = {};
                  //       }
                  //   }
    
                });
    
            },
            setTheInitData() {
                if (this.petition.beneficiaryInfo.countryOfBirthDetails && this.petition.beneficiaryInfo.countryOfBirth != null) {
                  
                    this.loadStatesByCountry('bfeprovinceStates', this.petition.beneficiaryInfo.countryOfBirth)
    
                }
                
                let provinceOfBirth = this.checkProperty(this.petition ,'beneficiaryInfo' ,'provinceOfBirth');
                if (provinceOfBirth != null) { 
                  let provinceOfBirthDetails = _.find(this.bfeprovinceStates, function (item) {  return item.id == provinceOfBirth  })
                   if(provinceOfBirthDetails){
  
                      this.petition.beneficiaryInfo.provinceOfBirthDetails = provinceOfBirthDetails;
  
                   }
                   
                }
  
                let curNonImmigrantVisaStatus = this.checkProperty(this.petition ,'beneficiaryInfo' ,'curNonImmigrantVisaStatus');
                if (curNonImmigrantVisaStatus != null) {
                    this.petition.beneficiaryInfo.curNonImmigrantVisaStatusDetails = _.find(this.petition.visaStatusList, function (item) {
    
                        return item.id == curNonImmigrantVisaStatus
                    })
                }
              //   let highestDegree = this.petition.beneficiaryInfo.education.highestDegree;
              //   if (highestDegree != null) {
              //       this.petition.beneficiaryInfo.education.highestDegreeDetails = _.find(this.petition.highestDegreeList, function (item) {
    
              //           return item.id == highestDegree
              //       })
              //   }
  
              if(this.currentRouteName =='permapplication-questionnaire' || this.currentRouteName =='permapplicationSuggession-questionnaire'){
                  if(!_.has( this.petition ,'alienInfo')){
  
                      
                      this.petition['alienInfo']= {
          isTrainigRequired: 'Yes',//String, // Yes/No // Is training required for the job opportunity?
          isExpRequired: 'No',//String, // Yes/No // Is experience in the job offered required for the job?
          isAltCombOfEduAndExpAccept:'No',// String, // Yes/No // Is there an alternate combination of education and experience that is acceptable
          isExpInAltOccuAccept:'No',// String, // Yes/No // Is experience in an alternate occupation acceptable?
          hasGainAnyExpWithEmplr: 'No',//String, // Yes/No // Did the alien gain any of the qualifying experience with the employer in a position substantially comparable to the job opportunity requested?
          didEmplrPayForEdu: 'No',//String, // Yes/No // Did the employer pay for any of the alien’s education or training necessary to satisfy any of the employer’s job requirements for this position?
          isWorkingWithPetngEmplr:'No',// String, // Yes/No // Is the alien currently employed by the petitioning employer?
                   }
                  }
                  if(!_.has( this.petition ,'refilingInstructions')){
                   this.petition['refilingInstructions'] = {
                  useFilingDateFromPrevSubtn: 'No',//String, // Yes/No // Are you seeking to utilize the filing date from a previously submitted Yes No Application for Alien Employment Certification (ETA 750)? 
                  prevFilingDate: null ,//Date, // enter the previous filing date
                  prevSWAOrLocalCaseNo: '',//String, // Indicate the previous SWA or local office case number OR if not available, specify state where case was originally filed
                  caseFiledStateId: null,//Number, // Indicate the previous SWA or local office case number OR if not available, specify state where case was originally filed
                  caseFiledStateDetails: null, //Object // Indicate the previous SWA or local office case number OR if not available, specify state where case was originally filed
                  } 
            
                       
                  }
                  this.petition = _.cloneDeep(this.petition);
  
              }
    
            
                      
    
                if (this.petition.beneficiaryInfo.priorPeriodOfStayInUS && this.petition.beneficiaryInfo.priorPeriodOfStayInUS.length == 1 && this.petition.beneficiaryInfo.priorPeriodOfStayInUS[0].departedDate == null && this.petition.beneficiaryInfo.priorPeriodOfStayInUS[0].enteredDate == null) {
    
                    this.petition.beneficiaryInfo.priorPeriodOfStayInUS = [{
                            _id: 0,
                           
                            visaStatus: null,
                            visaStatusDetails: null,
                            noOfDays: null,
                            enteredDate: null,
                            departedDate: null,
                           dateerror: false
                        }]
                }
    
                if (this.petition.beneficiaryInfo && this.petition.beneficiaryInfo.educations == null) {
                    this.petition.beneficiaryInfo.educations = [
  
  
                  /*{
                      _id: 0,
                      name: null,
                      address: {
                          line1: null,
                          line2: null,
                          aptType: null,
                          locationId: null,
                          locationDetails: null,
                          stateId: null,
                          stateDetails: null,
                          countryId: null,
                          countryDetails: null,
                          zipcode: null
                      },
                      highestDegree: null,
                      highestDegreeDetails: null,
                      majorFieldOfStudy: null,
                      attendedFrom: null,
                      attendedTo: null,
                      graduatedYear: null,
                      degreereceived: null,
                      isAccredited: null,
                      isForProfit: null
                  }
                  */
  
  
                    ]
                }
    
                if (this.petition.beneficiaryInfo && this.petition.beneficiaryInfo.prevEmploymentInfo == null) {
                    this.petition.beneficiaryInfo.prevEmploymentInfo = [{
                        _id: 0,
                        employerName: '',
                        address: {
                            line1: null,
                            line2: null,
                            aptType: null,
                            locationId: null,
                            locationDetails: null,
                            stateId: null,
                            stateDetails: null,
                            countryId: null,
                            countryDetails: null,
                            zipcode: null
                        },
                        businessType: null,
                        jobTitle: null,
                        jobDuties: null,
                        startDate: null,
                        endDate: null,
                        currentEmployer: false
                    }]
                }
                if (this.petition.beneficiaryInfo && this.petition.beneficiaryInfo.consulateInfo == null) {
    
                    this.petition.beneficiaryInfo.consulateInfo = {
                        locationId: null,
                        locationDetails: null,
                        stateId: null,
                        stateDetails: null,
                        countryId: null,
                        countryDetails: null
                    }
    
                }
                //this.canRenderField('ben_educations', this.questionnaireDetails)        
                if (this.canRenderField('educations', this.questionnaireDetails ,false,'beneficiaryInfo.educations')) {
    
                    var index = _.find(this.tabslist, function (item) {
    
                        return item.key == "education"
                    })
                    if (index) {
    
                    } else {
                        this.tabslist.push({
                            key: "education",
                            name: "Educational Info"
                        })
                        
                    }
    
                }
                //this.canRenderField('ben_prevEmploymentInfo', this.questionnaireDetails)
                if (this.canRenderField('prevEmploymentInfo', this.questionnaireDetails,false,'beneficiaryInfo.prevEmploymentInfo')) {
    
                    var index = _.find(this.tabslist, function (item) {
    
                        return item.key == "employment"
                    })
                    if (index) {
    
                    } else {      
                        this.tabslist.push({
                            key: "employment",
                            name: "Employment Info"
                        })
                        
                    }
    
                }
                if(_.has(this.petition, 'beneficiaryInfo') && (!_.has(this.petition['beneficiaryInfo'], 'immPetitionInfo') || (this.checkProperty(this.petition['beneficiaryInfo'], 'immPetitionInfo') == null || this.checkProperty(this.petition['beneficiaryInfo'], 'immPetitionInfo') == ''))){
                    let tempImmipetitionObj = this.getImmipetitionObj();
                    this.petition['beneficiaryInfo']['immPetitionInfo'] = tempImmipetitionObj;
                }
                if(_.has(this.petition, 'beneficiaryInfo') && (!_.has(this.petition['beneficiaryInfo'], 'previousSpouse') || (_.has(this.petition['beneficiaryInfo'], 'previousSpouse') && !this.checkProperty(this.petition['beneficiaryInfo'], 'previousSpouse') ))){
                    this.petition['beneficiaryInfo']['previousSpouse'] = previousSpouseObj;
                }
    
                var index = _.find(this.tabslist, function (item) {
    
                    return item.key == "documents"
                })
                if (index) {
    
                } else {
                    this.tabslist.push({
                        key: "documents",
                        name: "Documents"
                    })
                }
                
                if(this.canRenderField('hasSpouse', this.questionnaireDetails,false,'dependentsInfo.spouse') || this.canRenderField('hasChildren', this.questionnaireDetails,false,'dependentsInfo.childrens')){
                    let dependentIndex = _.find(this.tabslist, function (item) {
                        return item.key == "dependentsinfo"
                    });
                    if(dependentIndex){

                    }else{
                        this.tabslist.push({
                            key: "dependentsinfo",
                            name: "Dependents Info"
                        })
                    };
                }
                this.updateTablist()
                this.featureDates = new Date();
    
                if(this.checkProperty(this.petition, 'dependentsInfo') && this.checkProperty(this.petition, 'dependentsInfo', 'childrens') && this.checkProperty(this.petition['dependentsInfo'], 'childrens', 'length')>0
                 && this.petition.dependentsInfo.childrens[0].firstName != '' && this.petition.dependentsInfo.childrens[0].firstName != null){
                    this.petition.hasRequiredForChildren = true;
                }
    
                if(this.checkProperty(this.petition, 'dependentsInfo') && this.checkProperty(this.petition, 'dependentsInfo', 'childrens') && this.checkProperty(this.petition['dependentsInfo'], 'childrens', 'length')>0){
                    this.petition.dependentsInfo.childrens.forEach((element, index) => {
                        if (element.firstName != '' && element.firstName != null) {
                            this.petition.dependentsInfo.childrens[index].saved = true;
                        }
                    });
                }
    
                if (this.petition.dependentsInfo.spouse.firstName != null && this.petition.dependentsInfo.spouse.firstName != '') {
    
                    this.petition.dependentsInfo.spouse.saved = true;
                }
                 
                    var $self = this;
                    if( this.checkProperty(this.petition ,'beneficiaryInfo' ,'nonImmPetitionsInfo' )){
                  this.petition.beneficiaryInfo.nonImmPetitionsInfo.forEach( (item, index)=> {
                    
                   $self.petition.beneficiaryInfo.nonImmPetitionsInfo[index].visaStatusDetails = _.find($self.petition.visaStatusList, function (aitem) {
    
                        return aitem.id == item.visaStatus
                    })
                    })
                  }
                  if(this.petition.beneficiaryInfo && this.checkProperty(this.petition.beneficiaryInfo, 'priorPeriodOfStayInUS')  && this.checkProperty(this.petition.beneficiaryInfo, 'priorPeriodOfStayInUS', 'length')>0){
                     this.petition.beneficiaryInfo.priorPeriodOfStayInUS.forEach( (item, index)=> {
                    
                   $self.petition.beneficiaryInfo.priorPeriodOfStayInUS[index].visaStatusDetails = _.find($self.petition.visaStatusList, function (aitem) {
    
                        return aitem.id == item.visaStatus
                    })
                    })
                  }
                this.$vs.loading.close();
            },
            init(callFromMounted=false) {
             
              let _self =this;
              this.loadStatesByCountry('bfeprovinceStates', 231);
                this.$store.dispatch("getcountries").then((response) => {
                    this.countries = response;
                    if(this.checkProperty(this.countries, 'length')>0){
                      this.countriesWithoutUS = _.filter(this.countries,(item)=> {
                          return item.id != 231;
                      });
                  }
    
                });
    
                this.$store.dispatch("getmasterdata", "visa_status").then((response) => {
                    this.visastatuses = response;
                    this.petition.visaStatusList =response;
                });
                this.$store.dispatch("getmasterdata", "marital_status").then((response) => {
                        this.marital_statuses = response;
                    });
    
                this.$store .dispatch("getmasterdata", "education_types").then((response) => {
                        this.education_types = response;
                        // this.upDatehighestDegree();
                    });
                    
                this.$store
                    .dispatch("commonAction", {data:{"petitionId":this.$route.params.itemId },path: "/perm/details"})
                    .then((response) => {
                      
                        if(response ){
                            var data = _.merge(this.petition ,response);
                            this.petition = data;
                            let _spouse = this.getSpouseObj();
                            let _child = this.getChildObject();
                            let tempImmipetitionObj = this.getImmipetitionObj();
                            let previousSpouseObj = this.getPreviousSpouseObj();
                            if(!_.has(this.petition, 'dependentsInfo')){
                                this.petition['dependentsInfo']={
                                    spouse:_.cloneDeep(_spouse),
                                    childrens:[]
                                };
                                this.petition['dependentsInfo']['childrens'].push(_child)
                            }
                            else if(_.has(this.petition, 'dependentsInfo') && ( !_.has(this.petition['dependentsInfo'], 'spouse') || (_.has(this.petition['dependentsInfo'], 'spouse') && (this.checkProperty(this.petition['dependentsInfo'], 'spouse') == null || this.checkProperty(this.petition['dependentsInfo'], 'spouse') == '') )) ){
                                this.petition['dependentsInfo']['spouse'] = _.cloneDeep(_spouse);
                            }
                            else if(_.has(this.petition, 'dependentsInfo') && _.has(this.petition['dependentsInfo'], 'spouse') && this.checkProperty(this.petition['dependentsInfo'], 'spouse')){
                                this.spouse = this.petition['dependentsInfo']['spouse'];
                            }
                            if(_.has(this.petition, 'beneficiaryInfo') && !_.has(this.petition['beneficiaryInfo'], 'immPetitionInfo')){
                                this.petition['beneficiaryInfo']['immPetitionInfo'] = tempImmipetitionObj;
                            }
                            if(_.has(this.petition, 'beneficiaryInfo') && (!_.has(this.petition['beneficiaryInfo'], 'previousSpouse') || (_.has(this.petition['beneficiaryInfo'], 'previousSpouse') && !this.checkProperty(this.petition['beneficiaryInfo'], 'previousSpouse') ))){
                                this.petition['beneficiaryInfo']['previousSpouse'] = previousSpouseObj;
                            }
                            // else if(_.has(this.petition, 'dependentsInfo') && (!_.has(this.petition['dependentsInfo'], 'childrens') || (_.has(this.petition['dependentsInfo'], 'childrens') && this.checkProperty(this.petition['dependentsInfo'], 'childrens', 'length')<=0 )) ){
                            //     this.petition['dependentsInfo']['childrens'] = [];
                            //     this.petition['dependentsInfo']['childrens'].push(_child);
                            // } this.getPreviousSpouseObj();
  
                        //pin verification functionality  
                         
                        if(!this.checkCurrentUrl && callFromMounted &&  this.checkProperty( this.petition ,'requiredPinForQuesSubmit') ){
                  
                          if(!this.openGeneratePinPopUp &&  this.checkProperty( this.petition  ,'qstPinSet')){
                              if(!this.tokenVerified){
                                  this.openGeneratePinPopUp =true;
                                  return false;
                              }
                              
                              
                          }else{
                      
                              this.openGeneratePinPopUp =true;
                              return false
  
                          }
                        }
  
  
                       this.workFlowDetailsConfig();
                       if(this.checkProperty(this.petition,'questionnaireFilled') && this.checkProperty(this.$route ,'name') =='fill-perm-questionnaire' ){
                          this.$router.push({ name: 'filled-perm-case-details', params: { itemId: this.petition._id } })
                       }
    
                      let questionnairePostData = { 'questionnaireId':''  };
                     questionnairePostData['questionnaireId'] = this.petition.questionnaireTplId;
                      
                        
                        this.$store.dispatch("commonAction", {data: questionnairePostData,path:"questionnaire/details" }).then((res) => {
                          
                                let postData = {
                                    userId: this.petition.userId,
                                    getDocuments: true,
                                };
                                let pth="perm/get-recent-by-beneficiary";
                                          pth ="petition-common/get-recent-by-beneficiary";
                                          //pth =  '/beneficiary-profile/get-profile-details'
                                this.$store .dispatch("commonAction", {  data: postData, path: pth, }) .then((response) => {
                                  this.beneFiciaryDeytailsExists =false
                                  // if(response.beneficiaryInfo){
                                  //     if (!this.petition.questionnaireFilled && (this.petition.beneficiaryInfo.email == null || this.petition.beneficiaryInfo.email == '')) {
                                  //         this.showPrefillPopup = true;
                                  //     }   
                                  //     let tempDetails = response;
                                  //     this.latestPetition = tempDetails;
                                  // }
                                      if (response && response.profileDetails && response.profileDetails.beneficiaryInfo  && this.checkProperty(response['profileDetails'],'beneficiaryInfo','firstName')) {
                                          if (!this.petition.questionnaireFilled && (this.petition.beneficiaryInfo.email == null || this.petition.beneficiaryInfo.email == '')) {
                                              this.beneFiciaryDeytailsExists  = true;
                                              this.showPrefillPopup = true;
                                              let tempDetails = response['profileDetails'];
                                              this.latestPetition = tempDetails;
      
                                          } 
                                      }
                                        else if (response && response.caseDetails && response.caseDetails.beneficiaryInfo) {
                                            if (!this.petition.questionnaireFilled && (this.petition.beneficiaryInfo.email == null || this.petition.beneficiaryInfo.email == '')) {
    
                                                this.showPrefillPopup = true;
    
                                            }
    
                                            this.latestPetition = response["caseDetails"];
                                            
                                        }else if (response && response.userDetails && response.userDetails && (!this.petition.questionnaireFilled && (this.petition.beneficiaryInfo.email == null || this.petition.beneficiaryInfo.email == ''))){
  
                                          if(this.checkProperty(response ,'userDetails' ,'email' ) && !this.checkProperty(this.petition ,'beneficiaryInfo' ,'email')){
  
                                          this.petition['beneficiaryInfo']['email'] = this.checkProperty(response ,'userDetails' ,'email' )
  
  
                                          }
                                          if(this.checkProperty(response ,'userDetails' ,'firstName' ) && !this.checkProperty(this.petition ,'beneficiaryInfo' ,'firstName')){
                                          this.petition['beneficiaryInfo']['firstName'] = this.checkProperty(response ,'userDetails' ,'firstName' );
                                          }
                                          if(this.checkProperty(response ,'userDetails' ,'middleName' )  && !this.checkProperty(this.petition ,'beneficiaryInfo' ,'middleName') ){
                                              this.petition['beneficiaryInfo']['firstName'] = this.checkProperty(response ,'userDetails' ,'middleName' );
                                          }
                                          if(this.checkProperty(response ,'userDetails' ,'lastName' ) && !this.checkProperty(this.petition ,'beneficiaryInfo' ,'lastName') ){
                                          this.petition['beneficiaryInfo']['lastName'] = this.checkProperty(response ,'userDetails' ,'lastName' );
                                          }
                                       }
    
                                        this.questionnaireDetails = res.fields;
                                            this.setTheInitData()
                                           this.$vs.loading.close();
                                    }).catch((err)=>{
                                      this.$vs.loading.close();
                                    });
    
                            }).catch((err)=>{
                                      this.$vs.loading.close();
                                    });
    
                        }else{
    
                              this.$vs.loading.close();
                        }
                      
                    }).catch((err)=>{
                      this.$vs.loading.close();
                    });
            },
            setBasicData(){
              //this.latestPetition beneficiaryInfo
              //email  firstName middleName lastName
              if(this.checkProperty(this.latestPetition ,'beneficiaryInfo' ,'email' )){
  
                  this.petition['beneficiaryInfo']['email'] = this.checkProperty(this.latestPetition ,'beneficiaryInfo' ,'email' )
                  
  
              }
              if(this.checkProperty(this.latestPetition ,'beneficiaryInfo' ,'firstName' )){
                  this.petition['beneficiaryInfo']['firstName'] = this.checkProperty(this.latestPetition ,'beneficiaryInfo' ,'firstName' );
              }
              if(this.checkProperty(this.latestPetition ,'beneficiaryInfo' ,'middleName' )){
                  this.petition['beneficiaryInfo']['middleName'] = this.checkProperty(this.latestPetition ,'beneficiaryInfo' ,'middleName' );
              }
              if(this.checkProperty(this.latestPetition ,'beneficiaryInfo' ,'lastName' )){
                  this.petition['beneficiaryInfo']['lastName'] = this.checkProperty(this.latestPetition ,'beneficiaryInfo' ,'lastName' );
              }
  
  
            },
            getChildObject(){
                let _child= {
                    firstName: "",
                    middleName: '',
                    lastName: "",
                    maidenName: "",
                    gender: "",
                    email: "",
                    phoneNumber: null,
                    phoneCountryCode: {
                        countryCode: "",
                        countryCallingCode: ""
                    },
                    cellPhoneNumber: "",
                    cellPhoneCountryCode: {
                        countryCode: "",
                        countryCallingCode: ""
                    },
                    dateOfBirth: null,
                    countryOfBirth: null,
                    countryOfBirthDetails: null,
                    provinceOfBirth: null,
                    provinceOfBirthDetails:null, 
                    locationOfBirth: "",
                    passportNumber: null,
                    passportIssuedDate: null,
                    passportExpiryDate: null,
                    passportIssuedCountry: null,
                    passportIssuedCountryDetails: null,
                    SSN: "", 
                    currentStatus: null,
                    statusExpiryDate: null,
                    isDSExpiryDate: null,
                    countryOfCitizenship: null,
                    countryOfCitizenshipDetails: null,
                    otherCountriesOfCitizenship: [],
                    otherCountriesOfCitizenshipDetails: [],
                    addressOutsideUS: {
                        line1: null,
                        line2: null,
                        aptType: null,
                        locationId: null,
                        locationDetails: null,
                        stateId: null,
                        stateDetails: null,
                        countryId: null,
                        countryDetails: null,
                        zipcode: null
                    }
                }
                return _child;
            },
            getSpouseObj(){
                let _spouse={
                    hasSpouse:false,
                    firstName: "",
                    middleName: '',
                    lastName: "",
                    maidenName: "",
                    gender: "",
                    email: "",
                    phoneNumber: null,
                    phoneCountryCode: {
                        countryCode: "",
                        countryCallingCode: ""
                    },
                    cellPhoneNumber: "",
                    cellPhoneCountryCode: {
                        countryCode: "",
                        countryCallingCode: ""
                    },
                    dateOfBirth: null,
                    countryOfBirth: null,
                    countryOfBirthDetails: null,
                    provinceOfBirth: null,
                    provinceOfBirthDetails:null, 
                    locationOfBirth: "",
                    passportNumber: null,
                    passportIssuedDate: null,
                    passportExpiryDate: null,
                    passportIssuedCountry: null,
                    passportIssuedCountryDetails: null,
                    SSN: "", 
                    currentStatus: null,
                    statusExpiryDate: null,
                    isDSExpiryDate: null,
                    countryOfCitizenship: null,
                    countryOfCitizenshipDetails: null,
                    otherCountriesOfCitizenship: [],
                    otherCountriesOfCitizenshipDetails: [],
                    addressOutsideUS: {
                        line1: null,
                        line2: null,
                        aptType: null,
                        locationId: null,
                        locationDetails: null,
                        stateId: null,
                        stateDetails: null,
                        countryId: null,
                        countryDetails: null,
                        zipcode: null
                    }
                }
                return _spouse;
            }, 
            getImmipetitionObj(){
                let immiInf={
                    anyOtherAlienFiled: null,
                    filedDate: null,
                    employerName: '',
                    rirOrRegularProcessing: null,
                    filedStateId: null,
                    filedStateDetails: null,
                    applCurStatus: '',
                    seekingFiledDateforETA750:null,
                };
                return immiInf
            },
            getPreviousSpouseObj(){
                let _preSpouse={
                    hasOtherNames:false,
                    otherNames: [{
                        _id: 0,
                        name: '',
                        firstName: '',
                        middleName: '',
                        lastName: '',
                    }],
                    maidenName:'',
                    marriageEndedDueTo:null,
                    marriageEndedOtherInfo:'',
                    firstName: '',
                    middleName: '',
                    lastName: '',
                    dateOfBirth: null,
                    dateOfMarriage:null,
                    dateOfMarriageEnd:null,
                    countryOfMarriage: '',
                    countryOfMarriageDetails: null,
                    provinceOfMarriage: '',
                    provinceOfMarriageDetails: null,
                    locationOfMarriage: '',
                    countryOfMarriageTermination: '',
                    countryOfMarriageTerminationDetails: null,
                    provinceOfMarriageTermination: '',
                    provinceOfMarriageTerminationDetails: null,
                    locationOfMarriageTermination: '',
                    obtainPermResidenceThroughSpouse:false  
                }
                return _preSpouse
            },

            prefilltheDetails() {
    
              //   var data = _.merge(this.petition, this.latestPetition);
              //   if (_.has(data, 'beneficiaryInfo') && _.has(data['beneficiaryInfo'], 'educations') && this.checkProperty(data, 'beneficiaryInfo', 'educations') && this.checkProperty(data['beneficiaryInfo'], 'educations', 'length') > 0) {
              //     let filterBenEducations = _.filter(data['beneficiaryInfo']['educations'], (item) => {
              //     if (this.checkProperty(item, 'name') && this.checkProperty(item, 'name') != null) {
              //         return item
              //     }
              //     })
              //     if (filterBenEducations && this.checkProperty(filterBenEducations, 'length') > 0) {
              //     data['beneficiaryInfo']['educations'] = filterBenEducations;
              //     } else {
              //     data['beneficiaryInfo']['educations'] = []; 
              //     }
  
              // }
              this.prepopulateQuestionnaire();
              this.prepopulateQuestionnaire('priorPeriodOfStayInUS');
              this.prepopulateQuestionnaire('vacationalOrTrainingInst');
              this.prepopulateQuestionnaire('detailsItemsList');
              this.prepopulateQuestionnaire('documents');
              this.prepopulateQuestionnaire('educations');
              this.prepopulateQuestionnaire('prevEmploymentInfo');
              this.prepopulateQuestionnaire('beneficiaryInfo.immPetitionInfo');
    
              //   this.petition = data;
                this.setTheInitData()
            },
            addchildren() {
                this.petition.hasRequiredForChildren = true;
                this.childH4(true)
            },
            childH4(addmore = false) {
                var _child = this.getChildObject();
                if (addmore) {
                    var savedone = false;
                    if(this.checkProperty(this.petition, 'dependentsInfo') && this.checkProperty(this.petition, 'dependentsInfo', 'childrens') && this.checkProperty(this.petition['dependentsInfo'], 'childrens', 'length')>0){
                        this.petition.dependentsInfo.childrens.forEach((element, index) => {
        
                            if (element.saved) {
                                savedone = true;
                            }
        
                        });
                    }
                    if (savedone) {
                        /* If already saved children exists then push new object*/
                        var _childrens = this.petition.dependentsInfo.childrens;
                        _childrens.push(_child);
                        this.petition.dependentsInfo.childrens = _childrens;
                        this.petition.dependentsInfo.childrens[this.petition.dependentsInfo.childrens.length - 1].hasChildren = false;
                        
                        this.selectedchild = this.petition.dependentsInfo.childrens.length - 1;
    
    
                        this.childModalForm = true;
                    } else {
                        var _childrens = [];
                        _childrens.push(_child)
                        this.petition.dependentsInfo.childrens = _childrens;
                        this.childModalForm = true;
                    }
    
                } else {
                    if (this.petition.hasRequiredForChildren) {
                        this.addchildren()
                    } else {
                        this.childModalForm = false;
                        var _childrens = [];
                        _childrens.push(_child)
                        this.petition.dependentsInfo.childrens = _childrens;
                        this.petition.dependentsInfo.childrens[0].hasChildren = false;
    
                    }
    
                }
    
                if (!this.petition.hasRequiredForChildren) {
                    this.petition.dependentsInfo.childrens = []
                    this.petition.dependentsInfo.childrens.push(_child)
                }
            },
            spouseH4() {
                let _spouse= this.getSpouseObj();
                if (this.checkProperty(this.petition, 'dependentsInfo') && this.checkProperty(this.petition, 'dependentsInfo', 'spouse') && this.petition.dependentsInfo.spouse.hasSpouse) { 
                    if(this.latestPetition && _.has(this.latestPetition,'dependentsInfo') && this.checkProperty(this.latestPetition,'dependentsInfo') && this.checkProperty(this.latestPetition,'dependentsInfo','spouse')
                        && this.checkProperty(this.latestPetition['dependentsInfo'],'spouse','firstName') && this.prefillAction){
                        this.spouse = _.cloneDeep(this.latestPetition.dependentsInfo.spouse);  
                    }
                    else if(this.petition && _.has(this.petition,'dependentsInfo') && this.checkProperty(this.petition,'dependentsInfo') && this.checkProperty(this.petition,'dependentsInfo','spouse')
                        && this.checkProperty(this.petition['dependentsInfo'],'spouse','firstName') && this.prefillAction == false ){
                        this.spouse = _.cloneDeep(this.petition.dependentsInfo.spouse);
                    }
                    else{
                        this.spouse = _spouse;
                    }
                    this.spouseModalForm = true;
                }else {
                    this.spouseModalForm = false;
                    this.spouse = _spouse;
                    this.petition.dependentsInfo.spouse  = _spouse;
                    this.petition.dependentsInfo.spouse.hasSpouse = false;
                }
            },
            toggleChildForm() {
                var savedone = false;
                this.petition.dependentsInfo.childrens.forEach((element, index) => {
                    if (element.saved) {
                        savedone = true;
                    }
                });
                if (!savedone) {
                    this.petition.hasRequiredForChildren = false;
                    this.petition.dependentsInfo.childrens[0] = {
                        hasChildren: null
                    }
                }
                this.childModalForm = false;
            },
            editChildren(item, index) {
                this.childModalForm = true;
                this.selectedchild = index;
                if(item){
                    var childocs = item.documents;
                    if(childocs && childocs.passport == null)  item.documents.passport =[];
                    if(childocs && childocs.visa == null)  item.documents.visa =[];
                    if(childocs && childocs.formI94 == null)  item.documents.formI94 =[];
                    if(childocs && childocs.birthCertificate == null)  item.documents.birthCertificate =[];
                    if(childocs && childocs.approvalNotice == null)  item.documents.approvalNotice =[];
                    if(childocs && childocs.approvalNoticeOfPrevH4 == null)  item.documents.approvalNoticeOfPrevH4 =[];
                    if(childocs && childocs.other == null)  item.documents.other =[];
                }      
                this.$validator.reset();
            },
            editSpouse(item) {      
                this.spouseModalForm = true;
                this.$validator.reset();
            },
            submitChild() {
                this.$validator.validateAll("childInfoformmodal").then((result) => {
                    if (result) {
                        this.petition.dependentsInfo.childrens[this.selectedchild].saved = true;
                        this.petition.dependentsInfo.childrens[this.selectedchild].hasChildren = true;
                        var childres = []
                        this.petition.dependentsInfo.childrens.forEach((element, index) => {
                            if (element.saved && element.firstName != '' && element.firstName != null) {
                                childres.push(element)
                            }
                        });
                        this.petition.dependentsInfo.childrens = childres;
                        this.saveCase(true, true)
                    } 
                    else{
                        const $ = JQuery;
                        if($('.text-danger:visible')){
                             $('.modal_cnt').scrollTop($('.text-danger:visible').first().parent().offset().top-30);
                        }
                    }
                })
            },
            submitSpouse() {
                this.$validator.validateAll("dependentsInfoformmodal").then((result) => {
                    if (result) {
                        this.petition.dependentsInfo.spouse = _.cloneDeep(this.spouse)
                        this.petition.dependentsInfo.spouse.hasSpouse = true;
                        this.spouse.saved = true;
                        this.saveCase(true, true)
                    } 
                    else{
                        const $ = JQuery;
                        if($('.text-danger:visible')){
                            $('.modal_cnt').scrollTop($('.text-danger:visible').first().parent().offset().top-30);
                        }
                    }
                })
            },
            removeEmptyEducations(){
                let self = this;
                if(this.canRenderField('educations', this.questionnaireDetails,false,'beneficiaryInfo.educations')){
                    if(this.checkProperty(this.petition, 'beneficiaryInfo', 'educations') && this.checkProperty(this.petition['beneficiaryInfo'], 'educations', 'length')>0){
                        let filteredEducations = [];
                        filteredEducations = _.filter(this.petition['beneficiaryInfo']['educations'], (item)=>{
                            if(_.has(item, 'name') && self.checkProperty(item, 'name')){
                                return item
                            }
                        });
                        this.petition['beneficiaryInfo']['educations'] = filteredEducations;
                    }
                }
                if(this.canRenderField('vacationalOrTrainingInst', this.questionnaireDetails,false,'beneficiaryInfo.vacationalOrTrainingInst')){
                    if(this.checkProperty(this.petition, 'beneficiaryInfo', 'vacationalOrTrainingInst') && this.checkProperty(this.petition['beneficiaryInfo'], 'vacationalOrTrainingInst', 'length')>0){
                        let filteredEducations = [];
                        filteredEducations = _.filter(this.petition['beneficiaryInfo']['vacationalOrTrainingInst'], (item)=>{
                            if(_.has(item, 'name') && self.checkProperty(item, 'name')){
                                return item
                            }
                        });
                        this.petition['beneficiaryInfo']['vacationalOrTrainingInst'] = filteredEducations;
                    }
                }
            },
            checkImmipetition(){
                if(!this.canRenderField('anyOtherAlienFiled', this.questionnaireDetails ,false,'beneficiaryInfo.immPetitionInfo') ||
                this.canRenderField('anyOtherAlienFiled', this.questionnaireDetails ,false,'beneficiaryInfo.immPetitionInfo') && !this.checkProperty(this.petition['beneficiaryInfo'], 'immPetitionInfo','anyOtherAlienFiled') ){
                    this.petition['beneficiaryInfo']['immPetitionInfo'] = this.getImmipetitionObj();
                }
            },
            checkPreviousSpouse(){
                if((this.checkProperty(this.petition.beneficiaryInfo ,'previouslyMarried') == null || this.checkProperty(this.petition.beneficiaryInfo ,'previouslyMarried') == false)  ){
                    this.petition.beneficiaryInfo.previousSpouse = this.getPreviousSpouseObj();
                }
            },
        },
        beforeDestroy() {
          try{
  
              const $ = JQuery;
              document.removeEventListener("click", this.reloadthePage);
             $('body').removeClass('questionnairetpl')
          }catch(err){
              
  
          }
            
        },
        mounted() {
            this.tabslist =[
                {
                    key: "casedetails",
                    name: "Personal Info"
            }];
            this.currentTab ='casedetails';
            if(this.currentRouteName =='permapplication-questionnaire' || this.currentRouteName =='permapplicationSuggession-questionnaire'){
                //permapplication-questionnaire
                this.tabslist =[
                { key: "permApplicationScope", name: "Perm Application" },    
                { key: "casedetails", name: "Personal Info" },
                // { key: "education",name: "Educational Info" },
                // {key: "employment", name: "Employment Info" },
                // {key: "documents", name: "Documents" }                     
                ],
                this.currentTab ='permApplicationScope';
            }
            this.getMasterSocList();
            this.getUsStatusList();
            const $ = JQuery;
            this.$vs.loading();
            $('body').addClass('questionnairetpl')
            this.init(true);
            this.loadStatesByCountry('usastates', 231)
        },
        components: {
          generatePin,
          previousSpouseForm,
          redioButtons,
             XIcon,
            educationsList,
            genderField,
            immiInput,
            addressField,
            Trash2Icon,
            datepickerField,
            selectField,
            immiPhone,
            immiMask,
            immiyesorno,
            immiuploader,
            immipriorstay,
            immitextarea,
            immieducations,
            immiswitchyesno,
            casedocumentslist,
            immiemployment,
            GCEmploymentdetailes,
            VuePerfectScrollbar,
            petitionsinformation,
            personalinfo,
            childpersonalinfo
        },
        watch: {
        }
    };
    </script>
    