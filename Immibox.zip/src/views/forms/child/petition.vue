<template>
 <div class="block-layout" >
  <div class="vx-col w-full mb-base wizard-container">
    <vx-card>
      <div class="wizard-content-heading">
        <h2>Questionnaire for {{petition.typeDetails.name}}  
          </h2>
          <h3>{{petition.subTypeDetails.name}} </h3>
        <p>Please take a few moments to complete this short registration form</p>
      </div>
      <form-wizard color="rgba(var(--vs-primary), 1)" :title="null" :subtitle="null" finishButtonText="Submit"
        @on-complete="formSubmitted"  >
        <tab-content title="Case Details" :before-change="beforeTabSwitch">
          <!-- tab 1 content -->
          <form data-vv-scope="beneficiaryInfoform" @submit.prevent="" @keydown.enter.prevent="">
            <vs-col class="w-full p-0">
              <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal"
                icon="IP-information-button" active="true">
                NOTE: This questionnaire should be filled out completely and accurately. Kindly read the instructions
                carefully. 
                <!-- All information is required, and if not applicable, please mention N/A. -->
              </vs-alert>
            </vs-col>
            <template v-if="checkTemplateField('gender')">
            <vs-col class="m-auto float-none demo-alignment beneficiary-info-btns pt-12 pb-6" vs-type="flex"
              vs-justify="space-between" vs-align="center" vs-lg="8" vs-sm="12"   >
              <vs-button class="btn male-btn" @click="setGender('male')" v-bind:class="{
                  isActivec: beneficiaryInfo.gender == 'male'
                }" icon-pack="IntakePortal" icon=" IP-femenine-1" type="border">Male</vs-button>
              <vs-button v-bind:class="{
                  isActivec: beneficiaryInfo.gender == 'female'
                }" class="btn female-btn" @click="setGender('female')" icon-pack="IntakePortal" icon=" IP-femenine-1"
                type="border">Female</vs-button>
              <vs-button v-bind:class="{
                  isActivec: beneficiaryInfo.gender == 'others'
                }" class="btn others-btn" @click="setGender('others')" icon-pack="feather" icon="icon-circle"
                type="border">Others</vs-button>
              <vs-input style="display:none" name="gender" type="hidden" data-vv-as="Gender" v-validate="'required'"
                v-model="beneficiaryInfo.gender" />
              <div class="mt-0 mr-0" style="width:100%;">
                <span class="text-danger text-sm"
                  v-show="errors.has('beneficiaryInfoform.gender')">{{ errors.first("beneficiaryInfoform.gender") }}</span>
              </div>
            </vs-col>

            <div class="divider"></div>
            </template>
             <template v-if="checkTemplateField('first_name') || checkTemplateField('middle_name')  || checkTemplateField('last_name') || 
             checkTemplateField('email') || checkTemplateField('dob') || checkTemplateField('marital_status')"  >
                <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
                  <div class="form-container">
                    <div class="vx-row">
                      <div class="vx-col w-full">
                        <vx-input-group class="form-input-group" >
                          <vs-input name="firstname" v-model="beneficiaryInfo.firstName" v-validate="'required'"
                            class="w-full" data-vv-as="First Name" label="First Name" v-if="checkTemplateField('first_name')" />

                          <vs-input class="w-full" name="middleName" v-model="beneficiaryInfo.middleName"
                            data-vv-as="Middle Name" label="Middle Name" v-if="checkTemplateField('middle_name')" />

                          <vs-input class="w-full" name="lastName"  v-model="beneficiaryInfo.lastName" v-validate="'required'"
                            data-vv-as="Last Name" label="Last Name" v-if="checkTemplateField('last_name')" />
                        </vx-input-group>
                        <div class="input-group-error" v-if="checkTemplateField('last_name') || checkTemplateField('first_name')" >
                          <p class="w-1/3" v-if="checkTemplateField('first_name')">
                            <span class="text-danger text-sm"
                              v-show="errors.has('beneficiaryInfoform.firstname')">{{ errors.first("beneficiaryInfoform.firstname") }}</span>
                          </p>
                          <p class="w-1/3">

                          </p>
                          <p class="w-1/3" v-if="checkTemplateField('last_name') ">
                            <span class="text-danger text-sm"
                              v-show="errors.has('beneficiaryInfoform.lastName')">{{ errors.first("beneficiaryInfoform.lastName") }}</span>
                          </p>
                        </div>
                      </div>
                      <div class="vx-col w-full"  v-if="checkTemplateField('email')" >
                        <vs-input name="email" v-model="beneficiaryInfo.email" v-validate="'required|email'" class="w-full"
                          data-vv-as="Email" label="Email" />

                        <span class="text-danger text-sm"
                          v-show="errors.has('beneficiaryInfoform.email')">{{ errors.first("beneficiaryInfoform.email") }}</span>
                      </div>
                      <div class="vx-col md:w-1/2 w-full" v-if="checkTemplateField('dob')" >
                        <label class="date-picker-label">Date of Birth</label>
                        <div class="main-placeholder right">
                          <datepicker  :typeable="true" name="dateOfBirth" 
                          :open-date="new Date(startEligibleDate)"
                          :disabled-dates="{from: new Date(startEligibleDate)}" data-vv-as="Date of Birth"
                            v-model="beneficiaryInfo.dateOfBirth" v-validate="'required'" placeholder="MM/DD/YYYY">
                          </datepicker>
                          <span class="text-danger text-sm"
                            v-show="errors.has('beneficiaryInfoform.dateOfBirth')">{{ errors.first("beneficiaryInfoform.dateOfBirth") }}</span>
                        </div>
                      </div>
                      <div class="vx-col md:w-1/2 w-full" v-if="checkTemplateField('marital_status')">
                        <vs-select v-validate="'required'" name="maritalStatus" v-model="beneficiaryInfo.maritalStatus"
                          class="w-full select-large" data-vv-as="Marital Status" label="Marital Status">
                          <vs-select-item :key="index" :value="item.id" :text="item.name"
                            v-for="(item,index) in marital_statuses" class="w-full" />
                        </vs-select>
                        <span class="text-danger text-sm"
                          v-show="errors.has('beneficiaryInfoform.maritalStatus')">{{ errors.first("beneficiaryInfoform.maritalStatus") }}</span>
                      </div>
                    </div>
                  </div>
                </vs-col>
                <div class="divider"></div>
            </template>
            <!--Phone Number Templaet--->
            <template v-if="checkTemplateField('cell_phone_number') || checkTemplateField('home_phone_number')">
            <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
              <div class="form-container">
                <div class="vx-row">
                  <div class="vx-col md:w-1/2 w-full" v-if="checkTemplateField('cell_phone_number')" >
 <!-- v-validate="'required|phonevalid'" -->
                          <vs-input
                          v-mask="'(###)-###-####'"
                          v-model="beneficiaryInfo.cellPhoneNumber"
                          name="cellPhoneNumber"
                         v-validate="'required|phonevalid'"
                          data-vv-as="Phone Number"
                          placeholder="(XXX)-XXX-XXXX"
                          wrapperClass="vs-con-input"
                          class="w-full"
                          inputClass="vs-inputx vs-input--input normal"
                          label="Phone Number"
                        />


               
                    <span class="text-danger text-sm"
                      v-show="errors.has('beneficiaryInfoform.cellPhoneNumber')">{{ errors.first("beneficiaryInfoform.cellPhoneNumber") }}</span>
                  </div>
                  <div class="vx-col md:w-1/2 w-full" v-if="checkTemplateField('home_phone_number')"  >
<!-- v-validate="'required|phonevalid'" -->

                    <vs-input
                          v-mask="'(###)-###-####'"
                          v-model="beneficiaryInfo.homePhoneNumber"
                          name="homePhoneNumber"
                          v-validate="'required|phonevalid'"
                          data-vv-as="Home Phone Number"
                          placeholder="(XXX)-XXX-XXXX"
                          wrapperClass="vs-con-input"
                          class="w-full"
                          inputClass="vs-inputx vs-input--input normal"
                          label="Home Phone Number"
                        />
 

            



                    <span class="text-danger text-sm"
                      v-show="errors.has('beneficiaryInfoform.homePhoneNumber')">{{ errors.first("beneficiaryInfoform.homePhoneNumber") }}</span>
                  </div>
                  <!-- <div class="vx-col md:w-1/2 w-full">


                    <div class="vs-component vs-con-input-label vs-input w-full vs-input-primary">
                      <label for="" class="vs-input--label">Work Phone Number</label>
                      <phone-mask-input v-model="beneficiaryInfo.workPhoneNumber" autoDetectCountry
                        name="workPhoneNumber" v-validate="'phoneNumber'" data-vv-as="Work Phone Number"
                        placeholder="+X(XXX)-XXX-XXXX" wrapperClass="vs-con-input"
                        inputClass="vs-inputx vs-input--input normal" label="Home Phone Numbe" />

                    </div>




                    <span class="text-danger text-sm"
                      v-show="errors.has('beneficiaryInfoform.workPhoneNumber')">{{ errors.first("beneficiaryInfoform.workPhoneNumber") }}</span>
                  </div> -->
                  <!-- <div class="vx-col md:w-1/2 w-full">



                    <div class="vs-component vs-con-input-label vs-input w-full vs-input-primary">
                      <label for="" class="vs-input--label">Fax Number</label>
                      <phone-mask-input v-model="beneficiaryInfo.faxNumber" autoDetectCountry name="faxNumber"
                        v-validate="'phoneNumber'" data-vv-as="Fax Number" placeholder="+X(XXX)-XXX-XXXX"
                        wrapperClass="vs-con-input" inputClass="vs-inputx vs-input--input normal" label="Fax Numbe" />

                    </div>




                    <span class="text-danger text-sm"
                      v-show="errors.has('beneficiaryInfoform.faxNumber')">{{ errors.first("beneficiaryInfoform.faxNumber") }}</span>
                  </div> -->
                </div>
              </div>
            </vs-col>
            <div class="divider"></div>
            </template>

          <!--Education Templaet--->
          <template v-if="checkTemplateField('highest_degree') || checkTemplateField('major_field_of_study')">
            <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
              <div class="form-container w-full">
                <h3 class="small-header">Education</h3>
                <div class="vx-row">
                  <div class="vx-col md:w-1/2 w-full"  v-if="checkTemplateField('highest_degree') ">
                    <vs-select v-validate="'required'" name="highestDegree"
                      v-model="beneficiaryInfo.education.highestDegree" class="w-full select-large"
                      data-vv-as="Highest Degree" label="Highest Degree">
                      <vs-select-item :key="index" :value="item.id" :text="item.name"
                        v-for="(item,index) in education_types" class="w-full" />
                    </vs-select>
                    <span class="text-danger text-sm"
                      v-show="errors.has('beneficiaryInfoform.highestDegree')">{{ errors.first("beneficiaryInfoform.highestDegree") }}</span>
                  </div>
                  <div class="vx-col md:w-1/2 w-full" v-if=" checkTemplateField('major_field_of_study')">
                    <vs-input v-validate="'required'" class="w-full" name="majorFieldOfStudy"
                      v-model="beneficiaryInfo.education.majorFieldOfStudy" data-vv-as="Major Field of Study"
                      label="Major Field of Study" />
                    <span class="text-danger text-sm"
                      v-show="errors.has('beneficiaryInfoform.majorFieldOfStudy')">{{ errors.first("beneficiaryInfoform.majorFieldOfStudy") }}</span>
                  </div>
                </div>
              </div>
            </vs-col>
            <div class="divider"></div>
          </template>
         <!--Address Templaet--->
          <template v-if="checkTemplateField('iam_from_us') || checkTemplateField('address')" >
            <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
              <div class="form-container">
                <h3 class="small-header">Address</h3>
                <div class="vx-row">
                  <div class="vx-col w-full" v-if="checkTemplateField('iam_from_us')" >
                    <ul class="demo-alignment custom-radio" vs-type="flex" vs-align="center">
                      <li>
                        <vs-radio @click="setDefaultcountry" v-model="beneficiaryInfo.iAmFromUS" vs-value='true'>I am in the United States
                        </vs-radio>
                      </li>
                      <li>
                        <vs-radio v-model="beneficiaryInfo.iAmFromUS" vs-value='false'>I am not in the United States
                        </vs-radio>
                      </li>
                    </ul>
                  </div>
                  <div class="vx-col md:w-1/2 w-full" v-if="checkTemplateField('address')" >
                    <vs-input v-validate="'required'" name="address1" v-model="beneficiaryInfo.address.line1" class="w-full"
                      data-vv-as="Street Address" label="Street Address" @blur="setDependentsInfoAddress(false)" />
                    <span class="text-danger text-sm"
                      v-show="errors.has('beneficiaryInfoform.address1')">{{ errors.first("beneficiaryInfoform.address1") }}</span>
                  </div>
                  <div class="vx-col md:w-1/2 w-full" v-if="checkTemplateField('address')"  >
                    <vs-input  name="address2" v-model="beneficiaryInfo.address.line2" @blur="setDependentsInfoAddress(true)"
                      class="w-full" data-vv-as="Apt, Suite" label="Apt, Suite" />
                    <span class="text-danger text-sm"
                      v-show="errors.has('beneficiaryInfoform.address2')">{{ errors.first("beneficiaryInfoform.address2") }}</span>
                  </div>
                  
                  <div class="vx-col md:w-1/2 w-full" v-if="checkTemplateField('address')">
                    <div class="con-select w-full select-large">
                      <label for class="vs-select--label">Country</label>
                      <multiselect name="country" v-validate="'required'" v-model="bncountryModel" :disabled="checkCountry === false  "
                        @select="selectCountry" :show-labels="false" ref="bncountry" track-by="id" label="name" data-vv-as="Country"
                        placeholder="Select Country" :options="countries" :searchable="true" :allow-empty="false">
                      </multiselect>
                    </div>

                    <span class="text-danger text-sm"
                      v-show="errors.has('beneficiaryInfoform.country')">{{ errors.first("beneficiaryInfoform.country") }}</span>
                  </div>
                  <div class="vx-col md:w-1/2 w-full" v-if="checkTemplateField('address')">
                    <div class="con-select w-full select-large">
                      <label for class="vs-select--label">State</label>
                      <multiselect name="state" v-validate="'required'" v-model="stateModel"
                        :disabled="states.length == 0" @select="selectState" :show-labels="false" label="name"
                        track-by="id" data-vv-as="State" placeholder="Select State" :options="states" :searchable="true"
                        :allow-empty="false"></multiselect>
                    </div>

                    <span class="text-danger text-sm"
                      v-show="errors.has('beneficiaryInfoform.state')">{{ errors.first("beneficiaryInfoform.state") }}</span>
                  </div>
                  <div class="vx-col md:w-1/2 w-full" v-if="checkTemplateField('address')">
                    <div class="con-select w-full select-large">
                      <label for class="vs-select--label">City</label>
                      <multiselect name="city" v-validate="'required'" v-model="locationModel" @select="selectLocation"
                        :show-labels="false" :disabled="locations.length == 0" track-by="id" data-vv-as="City"
                        label="name" placeholder="Select City" :options="locations" :searchable="true"
                        :allow-empty="false"></multiselect>
                    </div>

                    <span class="text-danger text-sm"
                      v-show="errors.has('beneficiaryInfoform.city')">{{ errors.first("beneficiaryInfoform.city") }}</span>
                  </div>
                  <div class="vx-col md:w-1/2 w-full" v-if="checkTemplateField('address')">
                    <vs-input name="zipcode" v-model="beneficiaryInfo.address.zipcode" @blur="setSpouseZipcode()"
                      v-validate="'numeric|required|zipcodev:bncountry'" class="w-full" data-vv-as="Zip Code"
                      label="Zip Code" />

                    <span class="text-danger text-sm"
                      v-show="errors.has('beneficiaryInfoform.zipcode')">{{ errors.first("beneficiaryInfoform.zipcode") }}</span>
                  </div>
                </div>
              </div>
            </vs-col>
            <div class="divider"></div>
          </template>

          <template v-if="checkTemplateField('ssn')">
            <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
              <div class="form-container">
                <div class="vx-row">
                  <div class="vx-col w-full">
                    <div class="main-placeholder right info-right">
                      <!-- <vx-tooltip color="primary" text="Text Here">
                        <img src="@/assets/images/main/info-icon.svg" />
                      </vx-tooltip> -->

                      <div class="vs-component vs-con-input-label vs-input w-full ssnnumber vs-input-primary">
                        <label class="vs-input--label">Social Security number (if applicable)</label>
                        <div class="vs-con-input">
                          <the-mask v-validate="'min:9|max:9'" name="ssn" data-vv-as="Social Security number (if applicable)" v-model="beneficiaryInfo.SSN"
                            placeholder="123 - 45 - 6789" class="vs-inputx vs-input--input normal"
                            :mask="['### - ## - ####']" />
                        </div>
                      </div>
                    </div>
                    <span class="text-danger text-sm"
                      v-show="errors.has('beneficiaryInfoform.ssn')">{{ errors.first(('beneficiaryInfoform.ssn')) }}
                    </span>
                  </div>
                </div>
              </div>
            </vs-col>
            <div class="divider" v-if="beneficiaryInfo.iAmFromUS == 'false'" ></div>
          </template>
          <template v-if="checkTemplateField('consulate_notify_address')">
            <vs-col v-if="beneficiaryInfo.iAmFromUS == 'false' && checkTemplateField('consulate_notify_address') " class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
              <div class="form-container">
                <div class="vx-row">
                  <div class="vx-col w-full" >
                    <label class="custom-label">
                      Consulate to Notify upon Approval of your petition (if outside the
                      USA)
                    </label>
                    <vs-textarea v-model="beneficiaryInfo.consulateNotifyAddress"  class="w-full" data-vv-as="Consulate to Notify upon Approval of your petition (if outside the
                      USA)" />
                  </div>
                </div>
              </div>
            </vs-col>
            <div class="divider"></div>
          </template>
          <template v-if="checkTemplateField('has_i140_immigration_petition') || checkTemplateField('docs_i140_approval_notice')">
            <vs-col class="m-auto float-none" vs-lg="8" vs-sm="12">
              <div class="alert-content-block">
                <p class="pt-2">Has an I-140 immigrant petition been filed on your behalf? Details</p>
                <vs-button v-bind:class="{
                  cactive: beneficiaryInfo.hasI140ImmPetitionFiled
                }" @click="beneficiaryInfo.hasI140ImmPetitionFiled = true" class="mr-5" color="success" type="border">
                  Yes</vs-button>
                <vs-button v-bind:class="{
                  cactive: !beneficiaryInfo.hasI140ImmPetitionFiled
                }" @click="beneficiaryInfo.hasI140ImmPetitionFiled = false" color="danger" type="border">No</vs-button>
                <div class="form-container mt-6" v-if="beneficiaryInfo.hasI140ImmPetitionFiled && checkTemplateField('docs_i140_approval_notice')"  >
                  <div class="vx-row">

<div class="vx-col w-full">
                  <label class="custom-label">I-140 Approval Notice, if any</label>
                  <file-upload v-model="documents.I140ApprovalNotice" class="file-upload-input"
                   name="I140ApprovalNoticeDocument" data-vv-as="INS Notices" :multiple="true" :hideSelected="true"
                   accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                    @input="upload(documents.I140ApprovalNotice)">
                    <img class="file-icon" src="@/assets/images/main/file-upload.svg"> Upload 
                  </file-upload>
                  
                  <span class="text-danger text-sm"
                  v-show="errors.has('I140ApprovalNoticeDocument')">{{ errors.first("I140ApprovalNoticeDocument") }}</span>
                  <ul  class="uploaded-list">
                    <vs-chip @click="remove(item, documents.I140ApprovalNotice)" v-for="(item, index) in documents.I140ApprovalNotice" v-if="item.status !== false" :key="index" closable> {{ item.name }} </vs-chip>
                  </ul>
                  <!-- <vs-upload text="Upload" class="file-upload" action="https://jsonplaceholder.typicode.com/posts/"
                    @on-success="successUpload" data-vv-as="Social security card and state professional license" /> -->
                </div>

                  </div>
                </div>
              </div>
            </vs-col>
            <div class="divider"></div>
          </template>

          <template  v-if="checkTemplateField('prior_stay_in_us')" >
            <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
              <div class="form-container">
                <div class="vx-row">
                  <div class="vx-col w-full mt-6">
                    <p class="mb-0">All prior periods of stay in the U.S. over the last seven years</p>
                  </div>

                  <div class="vx-col w-full">

                    <div class="vx-row delete-row" v-for="(priorstay, index) in priorPeriodOfStayInUS" :key="priorstay.id">
                      <div class="vx-col md:w-1/3 w-full">
                        <label class="date-picker-label">Date Entered</label>
                        <div class="main-placeholder right">

                          <datepicker  :typeable="true" data-vv-as="Date Entered" :name="'enterDate'+index" 
                           :disabled-dates="{to: new Date(startBeneficiaryDateEntered), from: new Date()}" v-model="priorstay.enteredDate"
                            placeholder="MM/DD/YYYY"></datepicker>
                            <span class="text-danger text-sm"
                              v-show="errors.has('beneficiaryInfoform.enterDate'+index)">{{ errors.first('beneficiaryInfoform.enterDate'+index)}}</span>
                        </div>
                      </div>
                      <div class="vx-col md:w-1/3 w-full">
                        <label class="date-picker-label">Date Departed</label>
                        <div class="main-placeholder right">

                          <datepicker  :typeable="true" :name="'departDate'+index" v-validate="{required: priorstay.enteredDate != null && !priorstay.departedDate }" data-vv-as="Date Departed"
                           :disabled="priorstay.enteredDate === null" :disabled-dates="{to: priorstay.enteredDate, from: new Date()}" v-model="priorstay.departedDate"
                            placeholder="MM/DD/YYYY"></datepicker>
                            <span class="text-danger text-sm"
                              v-show="errors.has('beneficiaryInfoform.departDate'+index)">{{ errors.first('beneficiaryInfoform.departDate'+index) }}</span>
                              
                        </div>
                      </div>
                      <div class="vx-col md:w-1/3 w-full">

                             <vs-input :disabled="priorstay.enteredDate === null" 
                              v-validate="{required: priorstay.enteredDate != null && !priorstay.visaStatus }"
                              v-model="priorstay.visaStatus" class="w-full" data-vv-as="Visa Status" label="Visa Status"
                        :name="'selectVisaStatus'+index"  />


                       
                        <span class="text-danger text-sm" 
                          v-show="errors.has('beneficiaryInfoform.selectVisaStatus'+index)">{{ errors.first('beneficiaryInfoform.selectVisaStatus'+index)}}</span>
                      </div>
                      <div class="delete" v-if="priorPeriodOfStayInUS.length > 1">
                        <a @click="removepriorstay(index)">
                          <img src="@/assets/images/main/delete-row-img.svg">
                        </a>
                      </div>
                    </div>
                  </div>
 
                </div>
              </div>

            </vs-col>
            <vs-col class="m-auto float-none" vs-type="flex" vs-align="center" vs-lg="8" vs-sm="12">
              <a @click="addpriorstay" class="add-more ml-0" type="filled">
                <span>+</span> More
              </a>
            </vs-col>
          </template>  

          </form>
        </tab-content>

        <!-- tab 3 content -->
        <tab-content title="Client Info" :before-change="beforeClient">
          <form data-vv-scope="clientInfoform" @submit.prevent="" @keydown.enter.prevent="">
            <template v-if="checkTemplateField('client_name')">
            <vs-col  class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
              <div class="form-container mt-6">
                <div class="vx-row">
                  <div class="vx-col w-full">
                    <vs-input class="w-full" data-vv-as="Client name" v-validate="'required'" name="clientname" v-model="clientInfo.name"
                      label="Name of the Client" />
                    <span class="text-danger text-sm"
                      v-show="errors.has('clientInfoform.clientname')">{{ errors.first("clientInfoform.clientname") }}</span>

                  </div>
                  <!-- <div class="vx-col md:w-1/2 w-full">
                    <vs-input class="w-full" v-validate="'required'" name="position" v-model="clientInfo.position"
                      label="Position" />
                    <span class="text-danger text-sm"
                      v-show="errors.has('clientInfoform.position')">{{ errors.first("clientInfoform.position") }}</span>
                  </div>

                  <div class="vx-col md:w-1/2 w-full">
                    <vx-input-group class="form-input-group">
                      <vs-input class="w-full" v-validate="'numeric|required|min:0'" name="salaryOffered"
                        v-model="clientInfo.salaryOffered" data-vv-as="Salary Offered" label="Salary Offered" />

                      <vs-select v-validate="'required'" name="salaryType" v-model="clientInfo.salaryFrequency"
                        class="w-full select-large" label="Salary Frequency">
                        <vs-select-item :key="index" :value="item.id" :text="item.name"
                          v-for="(item,index) in salaryOfferedType" class="w-full" />
                      </vs-select>


                    </vx-input-group>
                    <div class="input-group-error">
                      <p class="w-1/2">
                        <span class="text-danger text-sm"
                          v-show="errors.has('clientInfoform.salaryOffered')">{{ errors.first("clientInfoform.salaryOffered") }}</span>
                      </p>
                      
                    </div>
                  </div> -->
                </div>
              </div>
            </vs-col>
            <div class="divider"></div>
            </template>

          <template v-if="checkTemplateField('client_address')" >
            <vs-col class="m-auto float-none" vs-lg="8" vs-sm="12">
              <div class="form-container">
                <h3 class="small-header">Address</h3>
                <div class="vx-row">

                 <div class="vx-col md:w-1/2 w-full">
                    <vs-input v-validate="'required'" name="address1" v-model="clientInfo.address.line1" class="w-full"
                      data-vv-as="Street Address" label="Street Address" />
                    <span class="text-danger text-sm"
                      v-show="errors.has('clientInfoform.address1')">{{ errors.first("clientInfoform.address1") }}</span>
                  </div>
                  <div class="vx-col md:w-1/2 w-full">
                    <vs-input  name="address2" v-model="clientInfo.address.line2" class="w-full"
                      data-vv-as="Apt, Suite" label="Apt, Suite" />
                    <span class="text-danger text-sm"
                      v-show="errors.has('clientInfoform.address2')">{{ errors.first("clientInfoform.address2") }}</span>
                  </div>
                 
                  <div class="vx-col md:w-1/2 w-full">
                    <div class="con-select w-full select-large">
                      <label for class="vs-select--label">Country</label>
                      <multiselect name="clientcountry" v-validate="'required'" v-model="clientcountryModel" :disabled="clientInfo.address.countryId"
                        @select="selectclientCountry" :show-labels="false" track-by="id" label="name"
                        data-vv-as="Country" placeholder="Select Country" :options="countries" :searchable="true"
                        :allow-empty="false"></multiselect>
                    </div>

                    <span class="text-danger text-sm"
                      v-show="errors.has('clientInfoform.country')">{{ errors.first("clientInfoform.country") }}</span>
                  </div>
                  <div class="vx-col md:w-1/2 w-full">
                    <div class="con-select w-full select-large">
                      <label for class="vs-select--label">State</label>
                      <multiselect name="clientstate" v-validate="'required'" v-model="clientstateModel"
                        @select="selectclientState" :show-labels="false" track-by="id" label="name" data-vv-as="State"
                        placeholder="Select State" :options="clientstates" :searchable="true" :allow-empty="false">
                      </multiselect>
                    </div>

                    <span class="text-danger text-sm"
                      v-show="errors.has('clientInfoform.state')">{{ errors.first("clientInfoform.state") }}</span>
                  </div>
                  <div class="vx-col md:w-1/2 w-full">
                    <div class="con-select w-full select-large">
                      <label for class="vs-select--label">City</label>
                      <multiselect name="clientcity" v-validate="'required'" v-model="clientlocationModel"
                        @select="selectclientLocation" :show-labels="false" track-by="id" label="name" data-vv-as="City"
                        placeholder="Select City" :options="clientlocations" :searchable="true" :allow-empty="false">
                      </multiselect>
                    </div>

                    <span class="text-danger text-sm"
                      v-show="errors.has('clientInfoform.city')">{{ errors.first("clientInfoform.city") }}</span>
                  </div>
                  <div class="vx-col md:w-1/2 w-full">
                    <vs-input name="zipcode" v-model="clientInfo.address.zipcode"
                      v-validate="'numeric|required|min:5|max:6'" class="w-full" data-vv-as="Zip Code"
                      label="Zip Code" />

                    <span class="text-danger text-sm"
                      v-show="errors.has('clientInfoform.zipcode')">{{ errors.first("clientInfoform.zipcode") }}</span>
                  </div>





                  <div class="vx-col md:w-1/2 w-full">

                  </div>
                </div>
              </div>
            </vs-col>
          </template>  
          </form>
        </tab-content>


         <!-- tab 4 content -->
        <tab-content title="Documents">
          <vs-col class="w-full p-0">
            <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal"
              icon="IP-information-button" active="true">
              <p>Documents Needed</p>
              <ul  class="uploaded-list">
                <li>Resume</li>
                <li>10th / 12th Grade/Undergraduate/graduate degree(s) along with transcripts and any other certificates</li>
                <li>Experience letters</li>
                <li>USCIS I-797 Notices</li>
                <li>
                  Passport, along with Case and Form I-94 (clearly showing the dates of first and last entry into the
                  United States)
                </li>
                <li>3 Recent Pay Stubs and social security card</li>
                <li>Copies of all I-20’s and both sides of EAD card if currently on F-1 status</li>
              </ul>
              <p>If you are currently in H-4 status, please provide copies of the following for your spouse:</p>
              <ul  class="uploaded-list">
                <li>Notice of Approval of H-1 status, along with Passport Case, Form I-94, and 3 recent pay stubs</li>
                <li>Marriage Certificate</li>
              </ul>
            </vs-alert>
          </vs-col>

          <vs-col class="m-auto float-none pt-12" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8"
            vs-sm="12">
            <div class="form-container w-full">
              <h3 class="small-header">
                List of documents needs to be updated
                <span class="file-type">
                  (File Type: PDF,
                  DOC, JPEG, PNG. Max
                  file size: 1MB)
                </span>
              </h3>
              <div class="vx-row">
                <div class="vx-col w-full" v-if="checkTemplateField('docs_resume')">
                  <label class="custom-label">Resume</label>
                  <file-upload v-model="documents.resume" class="file-upload-input"
                  accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                    name="resumeDocument" data-vv-as="Resume" :multiple="true" :hideSelected="true"
                    @input="upload(documents.resume)" >
                    <img class="file-icon" src="@/assets/images/main/file-upload.svg">
                    Upload 
                  </file-upload>
                  
                  <span class="text-danger text-sm"
                  v-show="errors.has('resumeDocument')">{{ errors.first("resumeDocument") }}</span>
                  <ul  class="uploaded-list">
                    <vs-chip @click="remove(item, documents.resume)" v-for="(item, index) in documents.resume" :key="index" closable v-if="item.status !== false"> {{ item.name }} </vs-chip>
                  </ul>
                  
                </div>
                <div class="vx-col w-full" v-if="checkTemplateField('docs_education')" >
                  <label class="custom-label">
                    Education (10th / 12th Grade/Undergraduate/graduate degree(s) along with
                    transcripts and any other certificates)
                  </label>
                  <file-upload v-model="documents.education" class="file-upload-input" 
                  accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                   name="educationDocument" data-vv-as="Education (10th / 12th Grade/Undergraduate/graduate degree(s) along with
                    transcripts and any other certificates)" :multiple="true" :hideSelected="true" @input="upload(documents.education)">
                    <img class="file-icon" src="@/assets/images/main/file-upload.svg"> Upload 
                  </file-upload>
                  
                  <span class="text-danger text-sm"
                  v-show="errors.has('educationDocument')">{{ errors.first("educationDocument") }}</span>
                  <ul  class="uploaded-list">
                    <vs-chip @click="remove(item, documents.education)" v-for="(item, index) in documents.education" :key="index" closable v-if="item.status !== false"> {{ item.name }} </vs-chip>
                  </ul>
                  <!-- <vs-upload text="Upload" class="file-upload" action="https://jsonplaceholder.typicode.com/posts/"
                    @on-success="successUpload" data-vv-as="Education (10th / 12th Grade/Undergraduate/graduate degree(s) along with
                    transcripts and any other certificates)" /> -->
                </div>
                <div class="vx-col w-full" v-if="checkTemplateField('docs_exp_letters')">
                  <label class="custom-label">Experience Letters</label>
                  <file-upload v-model="documents.expLetters" class="file-upload-input" 
                  name="experienceDocument"
                  accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                   data-vv-as="Experience Letters" :multiple="true" :hideSelected="true" @input="upload(documents.expLetters)">
                   <img class="file-icon" src="@/assets/images/main/file-upload.svg"> Upload 
                  </file-upload>
                  
                  <span class="text-danger text-sm"
                  v-show="errors.has('experienceDocument')">{{ errors.first("experienceDocument") }}</span>
                  <ul  class="uploaded-list">
                    <vs-chip @click="remove(item, documents.expLetters)" v-for="(item, index) in documents.expLetters" :key="index" closable v-if="item.status !== false"> {{ item.name }} </vs-chip>
                  </ul>
                  <!-- <vs-upload text="Upload" class="file-upload" action="https://jsonplaceholder.typicode.com/posts/"
                    @on-success="successUpload" data-vv-as="Experience Letters" /> -->
                </div>
                <div class="vx-col w-full" v-if="checkTemplateField('docs_ins_notices')" >
                  <label class="custom-label">USCIS I-797 Notices</label>
                  <file-upload v-model="documents.INSNotices" class="file-upload-input"
                   name="insNoticeDocument" data-vv-as="INS Notices" :multiple="true" :hideSelected="true"
                   accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                    @input="upload(documents.INSNotices)" >
                    <img class="file-icon" src="@/assets/images/main/file-upload.svg"> Upload 
                  </file-upload>
                  
                  <span class="text-danger text-sm"
                  v-show="errors.has('insNoticeDocument')">{{ errors.first("insNoticeDocument") }}</span>
                  <ul  class="uploaded-list">
                    <vs-chip @click="remove(item, documents.INSNotices)" v-for="(item, index) in documents.INSNotices" :key="index" closable v-if="item.status !== false"> {{ item.name }} </vs-chip>
                  </ul>
                  <!-- <vs-upload text="Upload" class="file-upload" action="https://jsonplaceholder.typicode.com/posts/"
                    @on-success="successUpload" data-vv-as="INS Notices" /> -->
                </div>
                <div class="vx-col w-full" v-if="checkTemplateField('docs_passport_visa_i94')" >
                  <label class="custom-label">
                    Passport, along with Case and Form I-94 (clearly showing the dates of
                    first and last entry into the United States)
                  </label>
                  <file-upload v-model="documents.passportVisaI94" class="file-upload-input"
                   name="passportVisaI94Document" data-vv-as="Passport, along with Case and Form I-94 (clearly showing the dates of
                    first and last entry into the United States)" 
                    accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                    :multiple="true" :hideSelected="true" @input="upload(documents.passportVisaI94)">
                    <img class="file-icon" src="@/assets/images/main/file-upload.svg"> Upload 
                  </file-upload>
                  
                  <span class="text-danger text-sm"
                  v-show="errors.has('passportVisaI94Document')">{{ errors.first("passportVisaI94Document") }}</span>
                  <ul  class="uploaded-list">
                    <vs-chip @click="remove(item, documents.passportVisaI94)" v-for="(item, index) in documents.passportVisaI94" :key="index" closable v-if="item.status !== false"> {{ item.name }} </vs-chip>
                  </ul>
                  <!-- <vs-upload text="Upload" class="file-upload" action="https://jsonplaceholder.typicode.com/posts/"
                    @on-success="successUpload" data-vv-as="Passport, along with Visa and Form I-94 (clearly showing the dates of
                    first and last entry into the United States)" /> -->
                </div>
               
              <div class="vx-col w-full" v-if="checkTemplateField('docs_form_i20_ead')">
                <label class="custom-label">Form I –20 and EAD (if currently on F-1 status)</label>
                <file-upload v-model="documents.formI20" class="file-upload-input" 
                  name="formI20Document" data-vv-as="INS Notices" :multiple="true" :hideSelected="true"
                  accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document" 
                  @input="upload(documents.formI20)" >
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg"> Upload 
                </file-upload>
                
                <span class="text-danger text-sm"
                v-show="errors.has('formI20Document')">{{ errors.first("formI20Document") }}</span>
                <ul  class="uploaded-list">
                  <vs-chip @click="remove(item, documents.formI20)" v-for="(item, index) in documents.formI20" :key="index" closable v-if="item.status !== false"> {{ item.name }} </vs-chip>
                </ul>
              </div>

              <div class="vx-col w-full" v-if="checkTemplateField('docs_ssc_licence')"  >
                <label class="custom-label">Social security card and state professional license</label>
                <file-upload v-model="documents.socialSecurityCardAndProfLicense" class="file-upload-input"
                  name="socialSecurityCardAndProfLicenseDocument" data-vv-as="INS Notices" :multiple="true" :hideSelected="true"
                  accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                  @input="upload(documents.socialSecurityCardAndProfLicense)">
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg"> Upload 
                </file-upload>
                
                <span class="text-danger text-sm"
                v-show="errors.has('socialSecurityCardAndProfLicenseDocument')">{{ errors.first("socialSecurityCardAndProfLicenseDocument") }}</span>
                <ul  class="uploaded-list">
                  <vs-chip @click="remove(item, documents.socialSecurityCardAndProfLicense)" v-for="(item, index) in documents.socialSecurityCardAndProfLicense" v-if="item.status !== false" :key="index" closable> {{ item.name }} </vs-chip>
                </ul>
                <!-- <vs-upload text="Upload" class="file-upload" action="https://jsonplaceholder.typicode.com/posts/"
                  @on-success="successUpload" data-vv-as="Social security card and state professional license" /> -->
              </div>
                  

                

                <!----NEW DOCUMENTS--->

                <div class="vx-col w-full" v-if="checkTemplateField('docs_paystubs')" >
                <label class="custom-label">Pay Stubs </label>
                <file-upload v-model="documents.payStubs" class="file-upload-input" 
                  name="payStubs" data-vv-as="INS Notices" :multiple="true" :hideSelected="true"
                  accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document" 
                  @input="upload(documents.payStubs )" >
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg"> Upload 
                </file-upload>
                
                <span class="text-danger text-sm"
                v-show="errors.has('payStubs')">{{ errors.first("payStubs") }}</span>
                <ul  class="uploaded-list">
                  <vs-chip @click="remove(item, documents.payStubs)" v-for="(item, index) in documents.payStubs" :key="index" closable v-if="item.status !== false"> {{ item.name }} </vs-chip>
                </ul>
                </div>

                <div class="vx-col w-full" v-if="checkTemplateField('docs_offer_letters')"  >
                <label class="custom-label">Offer Letter/ Employment Agreement </label>
                <file-upload v-model="documents.offerLetter" class="file-upload-input" 
                  name="offerLetter" data-vv-as="INS Notices" :multiple="true" :hideSelected="true"
                  accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document" 
                  @input="upload(documents.offerLetter )" >
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg"> Upload 
                </file-upload>
                
                <span class="text-danger text-sm"
                v-show="errors.has('offerLetter')">{{ errors.first("offerLetter") }}</span>
                <ul  class="uploaded-list">
                  <vs-chip @click="remove(item, documents.offerLetter)" v-for="(item, index) in documents.offerLetter" :key="index" closable v-if="item.status !== false"> {{ item.name }} </vs-chip>
                </ul>
                </div>

                  <!-- Client Letters -->
                <div class="vx-col w-full" v-if="checkTemplateField('docs_client_letters')"  >
                <label class="custom-label">Client Letters</label>
                <file-upload v-model="documents.clientLetter" class="file-upload-input" 
                  name="clientLetter" data-vv-as="INS Notices" :multiple="true" :hideSelected="true"
                  accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document" 
                  @input="upload(documents.clientLetter )" >
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg"> Upload 
                </file-upload>
                
                <span class="text-danger text-sm"
                v-show="errors.has('clientLetter')">{{ errors.first("clientLetter") }}</span>
                <ul  class="uploaded-list">
                  <vs-chip @click="remove(item, documents.clientLetter)" v-for="(item, index) in documents.clientLetter" :key="index" closable v-if="item.status !== false"> {{ item.name }} </vs-chip>
                </ul>
                </div>
             
              
              <!--vendorLetter--->
              <div class="vx-col w-full" v-if="checkTemplateField('docs_vendor_letters')" >
                <label class="custom-label">Vendor Letters</label>
                <file-upload v-model="documents.vendorLetter" class="file-upload-input" 
                  name="vendorLetter" data-vv-as="INS Notices" :multiple="true" :hideSelected="true"
                  accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document" 
                  @input="upload(documents.vendorLetter )" >
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg"> Upload 
                </file-upload>
                
                <span class="text-danger text-sm"
                v-show="errors.has('vendorLetter')">{{ errors.first("vendorLetter") }}</span>
                <ul  class="uploaded-list">
                  <vs-chip @click="remove(item, documents.vendorLetter)" v-for="(item, index) in documents.vendorLetter" :key="index" closable v-if="item.status !== false"> {{ item.name }} </vs-chip>
                </ul>
              </div>


             <!--msa--->
              <div class="vx-col w-full" v-if="checkTemplateField('docs_msa')" >
                <label class="custom-label">MSA</label>
                <file-upload v-model="documents.msa" class="file-upload-input" 
                  name="msa" data-vv-as="INS Notices" :multiple="true" :hideSelected="true"
                  accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document" 
                  @input="upload(documents.msa )" >
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg"> Upload 
                </file-upload>
                
                <span class="text-danger text-sm"
                v-show="errors.has('msa')">{{ errors.first("msa") }}</span>
                <ul  class="uploaded-list">
                  <vs-chip @click="remove(item, documents.msa)" v-for="(item, index) in documents.msa" :key="index" closable v-if="item.status !== false"> {{ item.name }} </vs-chip>
                </ul>
                </div>

                <!--po--->
              <div class="vx-col w-full" v-if="checkTemplateField('docs_po')" >
                <label class="custom-label">PO</label>
                <file-upload v-model="documents.po" class="file-upload-input" 
                  name="po" data-vv-as="INS Notices" :multiple="true" :hideSelected="true"
                  accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document" 
                  @input="upload(documents.po )" >
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg"> Upload 
                </file-upload>
                
                <span class="text-danger text-sm"
                v-show="errors.has('po')">{{ errors.first("po") }}</span>
                <ul  class="uploaded-list">
                  <vs-chip @click="remove(item, documents.po)" v-for="(item, index) in documents.po" :key="index" closable v-if="item.status !== false"> {{ item.name }} </vs-chip>
                </ul>
              </div>

                 <!----NEW DOCUMENTS END--->

              <div class="vx-col w-full" v-if="checkTemplateField('docs_other')" >
              <label class="custom-label">Other documents, if any</label>
              <file-upload v-model="documents.other" class="file-upload-input"
                name="otherDocument" data-vv-as="INS Notices" :multiple="true" :hideSelected="true"
                accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                @input="upload(documents.other)">
                <img class="file-icon" src="@/assets/images/main/file-upload.svg"> Upload 
              </file-upload>

              <span class="text-danger text-sm"
              v-show="errors.has('otherDocument')">{{ errors.first("otherDocument") }}</span>
              <ul  class="uploaded-list">
                <vs-chip @click="remove(item, documents.other)" v-for="(item, index) in documents.other" v-if="item.status !== false" :key="index" closable> {{ item.name }} </vs-chip>
              </ul>
              <!-- <vs-upload text="Upload" class="file-upload" action="https://jsonplaceholder.typicode.com/posts/"
                @on-success="successUpload" data-vv-as="Social security card and state professional license" /> -->
              </div>


              </div>
            </div>
          </vs-col>
          <div class="text-danger text-sm formerrors" v-show="formerrors.msg">
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
              icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
          </div>
        </tab-content>


        <!-- tab 2 content -->
        <tab-content title="Dependents Info" v-if="beneficiaryInfo.maritalStatus !== 1" :before-change="beforeDependents" >
          <form data-vv-scope="dependentsInfoform" @submit.prevent="" @keydown.enter.prevent="">

            <vs-col class="w-full p-0">
              <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal"
                icon="IP-information-button" active="true">
                <p>
                  Your spouse and children will need to apply for H-4 status (only if they are currently in the USA on a
                  valid status).
                </p>
                <p>
                  That their status must be extended through a separate application, and is not automatically extended
                  upon approval of the H-1B petition.
                </p>
              </vs-alert>
            </vs-col>
            
           <div  class="spousedetails" v-if="beneficiaryInfo.maritalStatus == 2">
            <vs-col class="m-auto pt-6 float-none" vs-type="flex" vs-lg="8" vs-sm="12" v-if="checkTemplateField('spouse_h4_required')">
              <div class="alert-content-block">
                <p>H4 required for spouse?</p>
                <vs-button class="mr-5" v-bind:class="{
                  cactive: dependentsInfo.spouse.h4Required == true
                }" @click="dependentsInfo.spouse.h4Required = true" color="success" type="border">Yes</vs-button>
                <vs-button v-bind:class="{
                  cactive: dependentsInfo.spouse.h4Required == false
                }" @click="dependentsInfo.spouse.h4Required = false" color="danger" type="border">No</vs-button>
              </div>
            </vs-col>

            <div   v-if="dependentsInfo.spouse.h4Required && dependentsInfo.spouse.h4Required == true"  > 

            <div class="divider" v-if="dependentsInfo.spouse.h4Required && dependentsInfo.spouse.h4Required == true && checkTemplateField('spouse_h4_required')">
            </div>
            <vs-col v-if="dependentsInfo.spouse.h4Required && dependentsInfo.spouse.h4Required == true && checkTemplateField('spouse_h4_required') && checkTemplateField('spouse_h4_ead_required')"
              class="m-auto float-none" vs-type="flex" vs-lg="8" vs-sm="12">
              <div class="alert-content-block">
                <p>H4 EAD required for spouse?</p>
                <vs-button v-bind:class="{
                  cactive: dependentsInfo.spouse.h4Required === true && dependentsInfo.spouse.h4EADRequired === true
                }" @click="setH4EADValue(dependentsInfo.spouse.h4Required, true)" class="mr-5" color="success" type="border">Yes
                </vs-button>
                <vs-button v-bind:class="{
                  cactive: dependentsInfo.spouse.h4Required === true && dependentsInfo.spouse.h4EADRequired === false
                }" @click="setH4EADValue(dependentsInfo.spouse.h4Required, false)" color="danger" type="border">No</vs-button>

              </div>
              
            </vs-col>
            <div class="divider" v-if=" checkTemplateField('spouse_h4_required') ||  checkTemplateField('spouse_h4_ead_required')"></div>
            
            <template v-if="checkTemplateField('spouse_first_name') ||  checkTemplateField('spouse_middle_name') ||  checkTemplateField('spouse_last_name')
            || checkTemplateField('spouse_email') || checkTemplateField('spouse_phone_number') || checkTemplateField('spouse_dob') || checkTemplateField('spouse_country_of_birth')
            ">
            <vs-col   class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12"  >
              <div class="form-container">
                <div class="vx-row">
                   <template v-if="checkTemplateField('spouse_first_name') ||  checkTemplateField('spouse_middle_name') ||  checkTemplateField('spouse_last_name')" >
                      <div class="vx-col w-full">
                        
                        <vx-input-group class="form-input-group"  >
                          <vs-input class="w-full" data-vv-as="First Name" name="firstName"
                            v-model="dependentsInfo.spouse.firstName" v-validate="'required'" label="First Name" v-if="checkTemplateField('spouse_first_name')" />
                          <vs-input class="w-full" data-vv-as="Middle Name" name="middleName"
                            v-model="dependentsInfo.spouse.middleName"  label="Middle Name" v-if="checkTemplateField('spouse_middle_name')" />
                          <vs-input class="w-full" data-vv-as="Last Name" name="lastName"
                            v-model="dependentsInfo.spouse.lastName" v-validate="'required'" label="Last Name" v-if="checkTemplateField('spouse_last_name')" />
                        </vx-input-group>

                        <div class="input-group-error">
                          <p class="w-1/3">
                            <span class="text-danger text-sm"
                              v-show="errors.has('dependentsInfoform.firstName')">{{ errors.first("dependentsInfoform.firstName") }}</span>
                          </p>
                           <p class="w-1/3"></p>
                          <p class="w-1/3">
                            <span class="text-danger text-sm"
                              v-show="errors.has('dependentsInfoform.lastName')">{{ errors.first("dependentsInfoform.lastName") }}</span>
                          </p>
                        </div>
                        
                      </div>
                   </template>
                  <div class="vx-col md:w-1/2 w-full"  v-if="checkTemplateField('spouse_email')" >
                    <label class="date-picker-label">Spouse Email</label>
                     <vs-input name="Spouse Email" v-model="dependentsInfo.spouse.email" v-validate="'required|email'" class="w-full"
                      data-vv-as="Spouse Email"  />
                      <span class="text-danger text-sm"
                      v-show="errors.has('dependentsInfo.spouse.email')">{{ errors.first("dependentsInfo.spouse.email") }}</span>
                  </div>

                <div class="vx-col md:w-1/2 w-full" v-if="checkTemplateField('spouse_phone_number')">
                  <div class="vs-component vs-con-input-label vs-input w-full vs-input-primary"   >
                      <label for="" class="vs-input--label">Spouse Phone Number</label>
                      <!-- <phone-mask-input v-model="dependentsInfo.spouse.phoneNumber" autoDetectCountry
                        name="spousePhoneNumber" v-validate="'phoneNumber'" data-vv-as="Spouse Phone Number"
                        placeholder="+X(XXX)-XXX-XXXX" wrapperClass="vs-con-input"
                        inputClass="vs-inputx vs-input--input normal" label="Spouse Phone Numbe" /> -->

                        <!-- v-validate="'required|phonevalid'" -->


                        <vs-input
  v-mask="'(###)-###-####'"
  v-model="dependentsInfo.spouse.phoneNumber"
  name="spousePhoneNumber"
  v-validate="'required|phonevalid'"
  data-vv-as="Phone Number"
  placeholder="(XXX)-XXX-XXXX"
  wrapperClass="vs-con-input"
  class="w-full"
  inputClass="vs-inputx vs-input--input normal"
  
/>

                  </div>

                   <span class="text-danger text-sm"
                      v-show="errors.has('dependentsInfo.spouse.phoneNumber')">{{ errors.first("dependentsInfo.spouse.phoneNumber") }}</span>
                </div>    

                  <div class="vx-col md:w-1/2 w-full" v-if="checkTemplateField('spouse_dob')" >
                    <label class="date-picker-label">Spouse’s Date of Birth</label>
                    <div class="main-placeholder right">
                      <datepicker  :typeable="true" name="dateofbirth" :open-date="new Date(startEligibleDate)" :disabled-dates="{from: new Date(startEligibleDate)}" v-validate="'required'"
                        v-model="dependentsInfo.spouse.dateOfBirth" data-vv-as="Spouse’s Date of Birth"
                        placeholder="MM/DD/YYYY"></datepicker>
                      <span class="text-danger text-sm"
                        v-show="errors.has('dependentsInfoform.dateofbirth')">{{ errors.first("dependentsInfoform.dateofbirth") }}</span>

                    </div>
                  </div>
                  <div class="vx-col md:w-1/2 w-full" v-if="checkTemplateField('spouse_country_of_birth')" >
                    <div class="con-select w-full select-large">
                      <label for class="vs-select--label">Country Of Birth</label>
                      <multiselect  ref="spousecountry" name="country" v-validate="'required'" v-model="countrySelected"
                        @select="selectspouseCountry" :show-labels="false" track-by="id" label="name"
                        data-vv-as="Country" placeholder="Select Country" :options="countries" :searchable="true"
                        :allow-empty="false"></multiselect>
                    </div>
                    <span class="text-danger text-sm"
                      v-show="errors.has('dependentsInfoform.country')">{{ errors.first("dependentsInfoform.country") }}</span>
                  </div>
                </div>
              </div>
            </vs-col>
            <div class="divider"></div>
            </template>

          <template v-if="checkTemplateField('spouse_passport_number') || checkTemplateField('spouse_passport_expiry_date') ">
            <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
              <div class="form-container">
                <div class="vx-row">
                  <div class="vx-col lg:w-1/2 md:w-1/2 w-full" v-if="checkTemplateField('spouse_passport_number') ">
                    <vs-input  data-vv-as="Spouse Passport Number"  name="spousepassport" v-model="dependentsInfo.spouse.passportNumber"  v-validate="'passport:spousecountry|max:12'"  class="w-full"
                      label="Spouse’s Passport No" />

                                            <span class="text-danger text-sm"
                        v-show="errors.has('dependentsInfoform.spousepassport')">{{ errors.first("dependentsInfoform.spousepassport") }}</span>
                  </div>

                  <div class="vx-col lg:w-1/2 md:w-1/2 w-full" v-if=" checkTemplateField('spouse_passport_expiry_date') " >
                    <label class="date-picker-label">Passport Expiry Date</label>
                    <div class="main-placeholder right">

                      <datepicker  :typeable="true" v-model="dependentsInfo.spouse.passportExpiryDate" data-vv-as="Passport expiry date"
                        placeholder="MM/DD/YYYY"></datepicker>
                    </div>
                  </div>


                </div>
              </div>
            </vs-col>
            <div class="divider"></div>
          </template>

          <template v-if="checkTemplateField('spouse_i94') || checkTemplateField('spouse_country_of_citizenship')">
            <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
              <div class="form-container">
                <div class="vx-row">

                  <div class="vx-col lg:w-1/2 md:w-1/2 w-full" v-if="checkTemplateField('spouse_i94') "> 
                    <vs-input v-model="dependentsInfo.spouse.I94" class="w-full"
                      label="Spouse’s I-94 " />
                  </div>
                  <div class="vx-col lg:w-1/2 md:w-1/2 w-full" v-if="checkTemplateField('spouse_country_of_citizenship') " >

                    <div class="con-select w-full select-large">
                      <label for class="vs-select--label">Country Of Citizenship</label>
                      <multiselect  ref="spousecountry" name="citizenship" v-validate="'required'" v-model="countryOfCitizenshipSelected"
                        @select="selectspousecountryOfCitizenship" :show-labels="false" track-by="id" label="name"
                        data-vv-as="Country" placeholder="Select Country" :options="countries" :searchable="true"
                        :allow-empty="false"></multiselect>
                    </div>
                    <span class="text-danger text-sm"
                      v-show="errors.has('dependentsInfoform.citizenship')">{{ errors.first("dependentsInfoform.citizenship") }}</span>

                   
                  </div>
                </div>
              </div>
            </vs-col>
            <div class="divider"></div>
          </template>

          <template v-if="checkTemplateField('spouse_current_status') || checkTemplateField('spouse_status_expiry_date') 
          || checkTemplateField('spouse_ssn') || checkTemplateField('spouse_date_of_last_arrival')" >
            <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
              <div class="form-container">
                <div class="vx-row">
                  <div class="vx-col md:w-1/2 w-full" v-if="checkTemplateField('spouse_current_status') " >
                    <!-- <vs-select v-model="dependentsInfo.spouse.currentStatus" class="w-full select-large"
                      data-vv-as="Spouse’s current status " label="Spouse’s current status ">
                      <vs-select-item :key="index" :value="item.id" :text="item.name"
                        v-for="(item,index) in visastatuses" class="w-full" />
                    </vs-select> -->

                     <vs-input  data-vv-as="Spouse’s current status"  name="Spouses_current_status" v-model="dependentsInfo.spouse.currentStatus"   class="w-full"
                      label="Spouse’s current status" />

                    <!-- <span class="text-danger text-sm"  v-show="errors.has('dependentsInfo.spouse.currentStatus')">{{ errors.first("dependentsInfo.spouse.currentStatus") }}</span>
                   -->
                  </div>

                  <div class="vx-col md:w-1/2 w-full" v-if="checkTemplateField('spouse_status_expiry_date')">
                    <label class="date-picker-label">When does spouse’s status expires</label>
                    <div class="main-placeholder right">
<!-- v-model="dependentsInfo.spouse.statusExpiryDate"  -->
                      <datepicker  :typeable="true"  v-model="dependentsInfo.spouse.statusExpiryDate" data-vv-as="Spouse’s status expires" placeholder="MM/DD/YYYY"></datepicker>
                    </div>
                  </div>
                  <div class="vx-col md:w-1/2 w-full vs-con-input-label"  v-if="checkTemplateField('spouse_ssn')" >
                  <label for="" class="vs-input--label">Spouse’s social security (if Any)</label>
                  <div class="vs-con-input">
                    <the-mask v-validate="'min:9|max:9'" v-model="dependentsInfo.spouse.SSN"
                      placeholder="123 - 45 - 6789" class="vs-inputx vs-input--input normal"
                      :mask="['### - ## - ####']" />
                  </div>
                    <!-- <the-mask v-validate="'min:9|max:9'" v-model="dependentsInfo.spouse.SSN"
                      placeholder="123 - 45 - 6789" class="vs-inputx vs-input--input normal"
                      :mask="['### - ## - ####']" /> -->
                    
                  </div>
                  <div class="vx-col md:w-1/2 w-full" v-if="checkTemplateField('spouse_date_of_last_arrival')">
                    <label class="date-picker-label">Date of last arrival </label>
                    <div class="main-placeholder right">

                      <datepicker  :typeable="true"  v-model="dependentsInfo.spouse.lastArrivalDate"  data-vv-as="Date of last arrival" :disabled-dates="{from: new Date()}" placeholder="MM/DD/YYYY"></datepicker>
                    </div>
                  </div>
                </div>
              </div>
            </vs-col>
             <div class="divider"></div>
          </template>  

          <template v-if="checkTemplateField('spouse_physical_address')">        
            <vs-col class="m-auto float-none" vs-lg="8" vs-sm="12">
              <div class="form-container">
                <h3 class="small-header">Physical Address</h3>
                <div class="vx-row">

                 <div class="vx-col md:w-1/2 w-full"> 
                    <vs-input v-validate="'required'" name="address1" v-model="dependentsInfo.spouse.physicalAddress.line1" class="w-full"
                      data-vv-as="Street Address" label="Street Address" />
                    <span class="text-danger text-sm"
                      v-show="errors.has('dependentsInfoform.address1')">{{ errors.first("dependentsInfoform.address1") }}</span>
                  </div>

                  <div class="vx-col md:w-1/2 w-full">
                    <vs-input  name="address2" v-model="dependentsInfo.spouse.physicalAddress.line2" class="w-full"
                      data-vv-as="Apt, Suite" label="Apt, Suite" />
                    <span class="text-danger text-sm"
                      v-show="errors.has('dependentsInfoform.address2')">{{ errors.first("dependentsInfoform.address2") }}</span>
                  </div>
                 
                  <div class="vx-col md:w-1/2 w-full">
                    <div class="con-select w-full select-large">
                      <label for class="vs-select--label">Country</label>
                      <multiselect name="spouseaddresscountry" v-validate="'required'" v-model="spouseaddresscountryModel"
                        @select="selectspouseaddressCountry" :show-labels="false" track-by="id" label="name"
                        data-vv-as="Country" placeholder="Select Country" :options="countries" :searchable="true"
                        :allow-empty="false"></multiselect>
                    </div>

                    <span class="text-danger text-sm"
                      v-show="errors.has('dependentsInfoform.spouseaddresscountry')">{{ errors.first("dependentsInfoform.spouseaddresscountry") }}</span>
                  </div>
                  <div class="vx-col md:w-1/2 w-full">
                    <div class="con-select w-full select-large">
                      <label for class="vs-select--label">State</label>
                      <multiselect name="spouseaddressstate" v-validate="'required'" v-model="spouseaddressstateModel"
                        @select="selectspouseaddressState" :show-labels="false" track-by="id" label="name" data-vv-as="State"
                        placeholder="Select State" :options="suposestates" :searchable="true" :allow-empty="false">
                      </multiselect>
                    </div>

                    <span class="text-danger text-sm"
                      v-show="errors.has('dependentsInfoform.spouseaddressstate')">{{ errors.first("dependentsInfoform.spouseaddressstate") }}</span>
                  </div>
                  <div class="vx-col md:w-1/2 w-full">
                    <div class="con-select w-full select-large">
                      <label for class="vs-select--label">City</label>
                      <multiselect name="spouseaddresscity" v-validate="'required'" v-model="spouseaddresslocationModel"
                        @select="selectspouseaddresstLocation" :show-labels="false" track-by="id" label="name" data-vv-as="City"
                        placeholder="Select City" :options="souuselocations" :searchable="true" :allow-empty="false">
                      </multiselect>
                    </div>

                    <span class="text-danger text-sm"
                      v-show="errors.has('dependentsInfoform.spouseaddresscity')">{{ errors.first("dependentsInfoform.spouseaddresscity") }}</span>
                  </div>
                  <div class="vx-col md:w-1/2 w-full">
                    <vs-input name="zipcode" v-model="dependentsInfo.spouse.physicalAddress.zipcode"
                      v-validate="'numeric|required|min:5|max:6'" class="w-full" data-vv-as="Zip Code"
                      label="Zip Code" />

                    <span class="text-danger text-sm"
                      v-show="errors.has('dependentsInfoform.zipcode')">{{ errors.first("dependentsInfoform.zipcode") }}</span>
                  </div>


                  <div class="vx-col md:w-1/2 w-full">

                  </div>
                </div>
              </div>
            </vs-col>
            <div class="divider"></div>
          </template>
         
          <template v-if="checkTemplateField('spouse_docs_passport') || checkTemplateField('spouse_docs_visa') ||checkTemplateField('spouse_docs_formi94') 
         ||  checkTemplateField('spouse_docs_form_i797') || checkTemplateField('spouse_docs_mrg_certificate')
          || checkTemplateField('spouse_docs_other')
          " >
            <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
              <div class="form-container w-full">
                <div class="alert-content-block">
                  <vs-alert active="true" class="h-auto warning-alert mb-5" icon-pack="IntakePortal"
                    icon="IP-information-button">
                    Provide copies of the following spouse documents: Case, Form I-94, Form I-797, Marriage Certificate
                  </vs-alert>
                </div>
                <h3 class="small-header">
                  Spouse Documents
                  <span class="file-type">
                    (File Type: PDF, DOC, JPEG, PNG. Max
                    file size: 1MB)
                  </span>
                </h3>
                <div class="vx-row">
                  <div class="vx-col w-full" v-if="checkTemplateField('spouse_docs_passport')" >
                    <label class="custom-label">Passport</label>
                    <!-- check balu 1 -->
                    <file-upload v-model="dependentsInfo.spouse.documents.passport"
                      class="file-upload-input" name="passport" 
                      data-vv-as="Passport" :multiple="true" :hideSelected="true"
                      accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                      @input="upload(dependentsInfo.spouse.documents.passport)">
                        <img class="file-icon" src="@/assets/images/main/file-upload.svg"> 
                        Upload 
                    </file-upload>
                    <span class="text-danger text-sm"
                  v-show="errors.has('passport')">{{ errors.first("passport") }}</span>
                    <ul class="uploaded-list">
                      <vs-chip type="button" @click="remove(item, dependentsInfo.spouse.documents.passport)" v-for="(item, index) in dependentsInfo.spouse.documents.passport" :key="index" v-if="item.status !== false" closable>{{ item.name }} </vs-chip>
                    </ul>
                  </div>
                  
                   <div class="vx-col w-full"  v-if="checkTemplateField('spouse_docs_visa')" >
                    <label class="custom-label">Case</label>
                    <file-upload v-model="dependentsInfo.spouse.documents.visa" 
                    accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                    class="file-upload-input" name="visa" data-vv-as="Visa" 
                    :multiple="true" :hideSelected="true" @input="upload(dependentsInfo.spouse.documents.visa)" >
                      <img class="file-icon" src="@/assets/images/main/file-upload.svg"> 
                      Upload 
                    </file-upload>
                    
                    <span class="text-danger text-sm"
                  v-show="errors.has('visa')">{{ errors.first("visa") }}</span>
                    <ul class="uploaded-list">
                      <vs-chip @click="remove(item, dependentsInfo.spouse.documents.visa)" v-for="(item, index) in dependentsInfo.spouse.documents.visa" :key="index" closable v-if="item.status === true"> {{ item.name }} </vs-chip>
                    </ul>
                  </div>
                  <div class="vx-col w-full" v-if="checkTemplateField('spouse_docs_formi94')">
                    <label class="custom-label flex">
                      Form I-94
                      <!-- <vx-tooltip color="primary" text="Text Here">
                        <img class="ml-1" src="@/assets/images/main/info-icon.svg" />
                      </vx-tooltip> -->
                    </label>
                    <!-- check balu 2 -->
                    <file-upload v-model="dependentsInfo.spouse.documents.formI94" 
                    accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                    class="file-upload-input" name="formi94" data-vv-as="Form I-94" 
                    :multiple="true" :hideSelected="true" @input="upload(dependentsInfo.spouse.documents.formI94)" >
                      <img class="file-icon" src="@/assets/images/main/file-upload.svg"> 
                      Upload 
                    </file-upload>
                    
                    <span class="text-danger text-sm"
                  v-show="errors.has('formi94')">{{ errors.first("formi94") }}</span>
                    <ul  class="uploaded-list">
                      <vs-chip @click="remove(item, dependentsInfo.spouse.documents.formI94)" v-for="(item, index) in dependentsInfo.spouse.documents.formI94" :key="index" closable v-if="item.status !== false"> {{ item.name }} </vs-chip>
                    </ul>
                    <!-- <vs-upload text="Upload" class="file-upload" data-vv-as="Form I-94"
                      action="https://jsonplaceholder.typicode.com/posts/" @on-success="successUpload" /> -->
                  </div>
                  <div class="vx-col w-full" v-if="checkTemplateField('spouse_docs_form_i797')">
                    <label class="custom-label flex">
                      Form I-797
                      <!-- <vx-tooltip color="primary" text="Text Here">
                        <img class="ml-1" src="@/assets/images/main/info-icon.svg" />
                      </vx-tooltip> -->
                    </label>
                    <!-- check balu 3 -->
                    <file-upload v-model="dependentsInfo.spouse.documents.formI797" 
                    class="file-upload-input" name="formi797" data-vv-as="Form I-797" 
                    accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                    :multiple="true" :hideSelected="true" @input="upload(dependentsInfo.spouse.documents.formI797)">
                      <img class="file-icon" src="@/assets/images/main/file-upload.svg"> 
                        Upload 
                    </file-upload>
                    
                    <span class="text-danger text-sm"
                  v-show="errors.has('formi797')">{{ errors.first("formi797") }}</span>
                    <ul  class="uploaded-list">
                      <vs-chip @click="remove(item, dependentsInfo.spouse.documents.formI797)" v-for="(item, index) in dependentsInfo.spouse.documents.formI797" :key="index" closable v-if="item.status === true"> {{ item.name }} </vs-chip>
                    </ul>
                    <!-- <vs-upload text="Upload" class="file-upload" data-vv-as="Form I-797"
                      action="https://jsonplaceholder.typicode.com/posts/" @on-success="successUpload" /> -->
                  </div>
                  <div class="vx-col w-full" v-if="checkTemplateField('spouse_docs_mrg_certificate')">
                    <label class="custom-label">Marriage Certificate</label>
                    <!-- check balu 4 --> 
                    <file-upload v-model="dependentsInfo.spouse.documents.marriageCertificate" 
                    accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                    class="file-upload-input" name="marriageCertificate" data-vv-as="Marriage Certificate" 
                    :multiple="true" :hideSelected="true"  @input="upload(dependentsInfo.spouse.documents.marriageCertificate)" >
                      <img class="file-icon" src="@/assets/images/main/file-upload.svg"> 
                      Upload 
                    </file-upload>
                    
                    <span class="text-danger text-sm"
                  v-show="errors.has('marriageCertificate')">{{ errors.first("marriageCertificate") }}</span>
                    <ul  class="uploaded-list">
                      <vs-chip @click="remove(item, dependentsInfo.spouse.documents.marriageCertificate)" v-for="(item, index) in dependentsInfo.spouse.documents.marriageCertificate" :key="index" closable v-if="item.status === true"> {{ item.name }} </vs-chip>
                    </ul>
                    <!-- <vs-upload text="Upload" class="file-upload" data-vv-as="Marriage Certificate"
                      action="https://jsonplaceholder.typicode.com/posts/" @on-success="successUpload" /> -->
                  </div>

                  <div class="vx-col w-full" v-if="checkTemplateField('spouse_docs_other')" >
                    <label class="custom-label">Other documents, if any</label>
                    
                    <file-upload v-model="dependentsInfo.spouse.documents.other" 
                    accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                    class="file-upload-input" name="spouseOther" data-vv-as="Marriage Certificate" 
                    :multiple="true" :hideSelected="true"  @input="upload(dependentsInfo.spouse.documents.other)" >
                      <img class="file-icon" src="@/assets/images/main/file-upload.svg"> 
                      Upload 
                    </file-upload>
                    
                    <span class="text-danger text-sm"
                  v-show="errors.has('spouseOther')">{{ errors.first("spouseOther") }}</span>
                    <ul  class="uploaded-list">
                      <vs-chip @click="remove(item, dependentsInfo.spouse.documents.other)" v-for="(item, index) in dependentsInfo.spouse.documents.other" :key="index" closable v-if="item.status === true"> {{ item.name }} </vs-chip>
                    </ul>
                    
                  </div>
                 


                </div>
              </div>
            </vs-col>
          </template>  
 </div>



           </div>
            <div v-for="(children, index) in childrensarray" :key="children.id">
              <div class="divider divider-double"></div>
              <div class="delete-row delete-group" v-if="childrensarray.length > 1">
                <div class="delete">
                  <a @click="removechildren(index)">
                    <img src="@/assets/images/main/delete-row-img.svg">
                  </a>
                </div>
              </div>
              <vs-col class="m-auto float-none" vs-type="flex" vs-lg="8" vs-sm="12" v-if="checkTemplateField('child_h4_required')" >
                <div class="alert-content-block">
                  <p>H4 required for children?</p>
                  <vs-button v-bind:class="{
                  cactive: children.h4Required == true
                }" @click="children.h4Required = true" class="mr-5" color="success" type="border">Yes</vs-button>
                  <vs-button v-bind:class="{
                  cactive: children.h4Required == false
                }" @click="children.h4Required = false" color="danger" type="border">No</vs-button>
                </div>
              </vs-col>
                <div  v-if="children.h4Required == true " >
                <template v-if=" ( checkTemplateField('child_first_name') || checkTemplateField('child_middle_name') || checkTemplateField('child_last_name') 
                || checkTemplateField('child_dob') || checkTemplateField('child_country_of_birth') || checkTemplateField('child_passport_expiry_date')
                || checkTemplateField('child_i94') ||  checkTemplateField('child_country_of_citizenship') || checkTemplateField('child_visa_status')
                || checkTemplateField('child_status_expiry_date')
                )"  >
                  <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8"
                    vs-sm="12">
                    <div class="form-container">
                      <div class="vx-row">
                        <div class="vx-col w-full"  v-if="checkTemplateField('child_first_name') || checkTemplateField('child_middle_name') || checkTemplateField('child_last_name')" >
                          <vx-input-group class="form-input-group">
                            <vs-input v-model="children.firstName" class="w-full" label="First Name" />
                            <vs-input v-model="children.middleName" class="w-full" label="Middle Name" />
                            <vs-input v-model="children.lastName" class="w-full" label="Last Name" />
                          </vx-input-group>
                          <div class="input-group-error">
                            <p class="w-1/3">
                            </p>
                            <p class="w-1/3">
                            </p>
                            <p class="w-1/3">
                            </p>
                          </div>
                        </div>

                        <div class="vx-col md:w-1/2 w-full" v-if="checkTemplateField('child_dob')">
                          <label class="date-picker-label">Child’s Date of Birth</label>
                          <div class="main-placeholder right">

                            <datepicker  :typeable="true" v-model="children.dateOfBirth" :disabled-dates="{from: new Date()}" data-vv-as="Date of Birth" placeholder="MM/DD/YYYY">
                            </datepicker>
                          </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full" v-if="checkTemplateField('child_country_of_birth')"  >
                          <div class="con-select w-full select-large">
                            <label for class="vs-select--label">Country Of Birth</label>
                            <multiselect name="childcountry[]" :id="index" v-model="children.selectedcountryOfBirth" @select="selectchildCountry"
                              :show-labels="false" track-by="id" label="name" data-vv-as="Country"
                              placeholder="Select Country" :options="countries" :searchable="true" :allow-empty="false">
                            </multiselect>
                          </div>


                        </div>
                        <div class="vx-col md:w-1/2 w-full"   >
                          <vs-input v-model="children.passportNumber" class="w-full" label="Child’s Passport Number" />
                        </div>
                        <div class="vx-col md:w-1/2 w-full" v-if="checkTemplateField('child_passport_expiry_date')" >
                          <label class="date-picker-label">Passport Expiry Date</label>

                          <div class="main-placeholder right">

                            <datepicker  :typeable="true" v-model="children.passportExpiryDate" placeholder="MM/DD/YYYY"></datepicker>
                          </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full" v-if="checkTemplateField('child_i94')" >
                          <vs-input v-model="children.I94" class="w-full" label="Child’s I –94 " />
                        </div>
                        <div class="vx-col md:w-1/2 w-full" v-if="checkTemplateField('child_country_of_citizenship')" >
                        <div class="con-select w-full select-large">

                            <label for class="vs-select--label">Country Of Citizenship</label>
                            <multiselect name="childcitizenship[]" :id="index" v-model="children.selectedcitizenship" @select="selectchildCitizenship"
                              :show-labels="false" track-by="id" label="name" data-vv-as="Country"
                              placeholder="Select Country" :options="countries" :searchable="true" :allow-empty="false">
                            </multiselect>

                            </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full" v-if="checkTemplateField('child_visa_status')" >

                          <!-- <vs-select v-model="children.currentStatus" class="w-full select-large" data-vv-as="Visa Status"
                            label="Child’s Current Status ">
                            <vs-select-item :key="index" :value="item.id" :text="item.name"
                              v-for="(item,index) in visastatuses" class="w-full" />
                          </vs-select> -->
                          <vs-input  data-vv-as="Visa Status"  name="child_current_status" v-model="children.currentStatus"   class="w-full"
                          label="Child’s Current Status" />



                        </div>
                        <div class="vx-col md:w-1/2 w-full" v-if="checkTemplateField('child_status_expiry_date')" >
                          <label class="date-picker-label">When does child’s status expires </label>
                          <div class="main-placeholder right">

                            <datepicker  :typeable="true" v-model="children.statusExpiryDate" data-vv-as="Status expires"
                              placeholder="MM/DD/YYYY"></datepicker>
                          </div>
                        </div>
                      </div>
                    </div>
                  </vs-col>
                  <div class="divider"></div>
                </template> 
                <template v-if=" checkTemplateField('child_docs_passport') || checkTemplateField('child_docs_visa') 
                || checkTemplateField('child_docs_form_i94')  || checkTemplateField('child_docs_form_i797')
                || checkTemplateField('child_docs_birth_certificate') || checkTemplateField('child_docs_approval_notice')
                || checkTemplateField('child_docs_other')" >
                  <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8"
                    vs-sm="12">
                    <div class="form-container w-full">
                      <div class="alert-content-block">
                        <vs-alert active="true" class="h-auto warning-alert mb-5" icon-pack="IntakePortal"
                          icon="IP-information-button">
                          Provide copies of the following children documents: Case, Form I-94, Form I-797, Birth Certificate.
                        </vs-alert>
                      </div>
                      <h3 class="small-header">
                        Child's Documents
                        <span class="file-type">
                          (File Type: PDF, DOC, JPEG, PNG. Max
                          file size: 1MB)
                        </span>
                      </h3>
                      <div class="vx-row">
                        <div class="vx-col w-full" v-if="checkTemplateField('child_docs_passport')" >
                          <label class="custom-label">Passport</label>
                          <file-upload v-model="children.documents.passport" class="file-upload-input"
                          accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                          :name="'childPassport'+index" data-vv-as="Passport" :multiple="true" :hideSelected="true" 
                            @input="upload(children.documents.passport, index)" >
                            <img class="file-icon" src="@/assets/images/main/file-upload.svg"> 
                            Upload 
                          </file-upload>
                          <span class="text-danger text-sm"
                            v-show="errors.has('childPassport'+index)">{{ errors.first('childPassport'+index) }}</span>
                          <ul  class="uploaded-list">
                            <!-- child passport 1 -->
                            <vs-chip @click="remove(passport, children.documents.passport)" :name="'passportRemoveSelected'+index" v-for="(passport, passportValue) in children.documents.passport" :key="passportValue" close closable v-if="passport.status !== false"> {{ passport.name }} </vs-chip>
                          </ul>
                        </div>
                        <div class="vx-col w-full" v-if="checkTemplateField('child_docs_visa')" >
                          <label class="custom-label">Case</label>
                          <file-upload v-model="children.documents.visa"
                          class="file-upload-input" accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                          :name="'childVisa'+index" data-vv-as="Visa" :multiple="true" :hideSelected="true"
                          @input="upload(children.documents.visa, index)" >
                          <img class="file-icon" src="@/assets/images/main/file-upload.svg"> Upload 
                          </file-upload>
                          <span class="text-danger text-sm"
                            v-show="errors.has('childVisa'+index)">{{ errors.first('childVisa'+index) }}</span>
                          <ul  class="uploaded-list">
                            <vs-chip @click="remove(visa, children.documents.visa)" :name="'visaRemoveSelected'+index" v-for="(visa, visaValue) in children.documents.visa" :key="visaValue" closable v-if="visa.status !== false"> {{ visa.name }} </vs-chip>
                          </ul>
                        </div>
                        <div class="vx-col w-full" v-if="checkTemplateField('child_docs_form_i94')" >
                          <label class="custom-label flex">
                            Form I-94
                          
                          </label>
                          <file-upload v-model="children.documents.formI94" class="file-upload-input" 
                          accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                            :name="'childFormI94'+index" data-vv-as="Form I-94" :multiple="true" :hideSelected="true"
                            @input="upload(children.documents.formI94, index)" >
                            <img class="file-icon" src="@/assets/images/main/file-upload.svg">
                            Upload 
                          </file-upload>
                          <span class="text-danger text-sm"
                            v-show="errors.has('childFormI94'+index)">{{ errors.first('childFormI94'+index) }}</span>
                          <ul  class="uploaded-list">
                            <vs-chip @click="remove(formI94, children.documents.formI94)" :name="'formI94RemoveSelected'+index" v-for="(formI94, formI94Value) in children.documents.formI94" :key="formI94Value" v-if="formI94.status !== false" closable> {{ formI94.name }} </vs-chip>
                          </ul>
                        </div>
                        
                      <div class="vx-col w-full" v-if="checkTemplateField('child_docs_form_i797')">
                        <label class="custom-label flex">
                          Form I-797
                          
                        </label>
                        <!-- check balu 3 -->
                        <file-upload v-model="children.documents.formI797" class="file-upload-input" 
                          accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                            :name="'chilFormI797'+index" data-vv-as="Form I-797" :multiple="true" :hideSelected="true"
                            @input="upload(children.documents.formI797, index)" >
                            <img class="file-icon" src="@/assets/images/main/file-upload.svg">
                            Upload 
                          </file-upload>
                          <span class="text-danger text-sm"
                            v-show="errors.has('chilFormI797'+index)">{{ errors.first('chilFormI797'+index) }}</span>
                          <ul  class="uploaded-list">
                            <vs-chip @click="remove(formI797, children.documents.formI797)" :name="'formI94RemoveSelected'+index" v-for="(formI797, formI797Value) in children.documents.formI797" :key="formI797Value" v-if="formI797.status !== false" closable> {{ formI797.name }} </vs-chip>
                          </ul>
                      </div>

                        <div class="vx-col w-full" v-if="checkTemplateField('child_docs_birth_certificate')" >
                          <label class="custom-label">Birth Certificate</label>
                          <file-upload v-model="children.documents.birthCertificate" class="file-upload-input"
                          accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                            :name="'childBirthCertificate'+index" data-vv-as="Birth Certificate"
                            :multiple="true" :hideSelected="true" @input="upload(children.documents.birthCertificate, index)" >
                            <img class="file-icon" src="@/assets/images/main/file-upload.svg"> Upload 
                          </file-upload>
                          <span class="text-danger text-sm"
                            v-show="errors.has('childBirthCertificate'+index)">{{ errors.first('childBirthCertificate'+index) }}</span>
                          <ul  class="uploaded-list">
                            <vs-chip @click="remove(birthCertificate, children.documents.birthCertificate)" :name="'birthCertificateRemoveSelected'+index" v-for="(birthCertificate, birthCertificateValue) in children.documents.birthCertificate" :key="birthCertificateValue" v-if="birthCertificate.status !== false" closable> {{ birthCertificate.name }} </vs-chip>
                          </ul>
                        </div>


                        <div class="vx-col w-full" v-if="checkTemplateField('child_docs_approval_notice')" >
                          <label class="custom-label">Approval Notice</label>
                          <file-upload v-model="children.documents.approvalNotice" class="file-upload-input"
                          accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                            :name="'approval_notice'+index" data-vv-as="Birth Certificate"
                            :multiple="true" :hideSelected="true" @input="upload(children.documents.approvalNotice, index)" >
                            <img class="file-icon" src="@/assets/images/main/file-upload.svg"> Upload 
                          </file-upload>
                          <span class="text-danger text-sm"
                            v-show="errors.has('childother'+index)">{{ errors.first('childother'+index) }}</span>
                          <ul  class="uploaded-list">
                            <vs-chip @click="remove(approvalNotice, children.documents.approvalNotice)" :name="'birthCertificateRemoveSelected'+index" v-for="(approvalNotice, birthCertificateValue) in children.documents.approvalNotice" :key="birthCertificateValue" v-if="approvalNotice.status !== false" closable> {{ approvalNotice.name }} </vs-chip>
                          </ul>
                        </div>
                       
                        
                        <div class="vx-col w-full" v-if="checkTemplateField('child_docs_other')">
                          <label class="custom-label">Other documents, if any</label>
                          <file-upload v-model="children.documents.other" class="file-upload-input"
                          accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                            :name="'childother'+index" data-vv-as="Birth Certificate"
                            :multiple="true" :hideSelected="true" @input="upload(children.documents.other, index)" >
                            <img class="file-icon" src="@/assets/images/main/file-upload.svg"> Upload 
                          </file-upload>
                          <span class="text-danger text-sm"
                            v-show="errors.has('childother'+index)">{{ errors.first('childother'+index) }}</span>
                          <ul  class="uploaded-list">
                            <vs-chip @click="remove(other, children.documents.other)" :name="'birthCertificateRemoveSelected'+indx" v-for="(other, indx) in children.documents.other" :key="indx" v-if="other.status !== false" closable> {{ other.name }} </vs-chip>
                          </ul>
                        </div>


                      </div>
                    </div>
                  </vs-col>
              </template>
              </div>


      <vs-col v-if="children.h4Required == true && index == (childrensarray.length-1)" class="m-auto float-none" vs-type="flex" vs-align="center" vs-lg="8" vs-sm="12">
              <a @click="addchildren" class="add-more mt-5 ml-0" type="filled">
                <span>+</span> Add Child
              </a>
            </vs-col>
            
            </div>


      

          </form>
        </tab-content>
        
       
        <vs-popup class="holamundo success-popups" title="Your registration is complete."
          :active.sync="SuccessQuestionnaire">
          <figure>
            <img src="@/assets/images/main/icon-note.svg" alt="login" class="mx-auto" />
          </figure>
          <h2 class="title">Questionnaire submitted successfully!</h2>
          <p>It will be reviewed by the petitioner and appropriate actions will be taken soon.</p>
        </vs-popup>
      </form-wizard>
    </vx-card>  
  </div>

 </div>
</template>
<script>
  import { FormWizard, TabContent } from "vue-form-wizard";
  import "vue-form-wizard/dist/vue-form-wizard.min.css";
  import Datepicker from "vuejs-datepicker-inv";
  import moment from 'moment'
  import PhoneMaskInput from "vue-phone-mask-input";
  import JQuery from 'jquery';
  import { TheMask } from 'vue-the-mask';
  import FileUpload from "vue-upload-component/src";
  import _ from "lodash";
import Vue from 'vue'

  export default {
    // balu data
    data() {
      return {
        currentroute:this.$route.params.itemId,
        selectedcountryOfBirth:[],
        selectedcitizenship:[],
        salaryOfferedType: [],
        resumeDocs: [],
        educationDocs: [],
        experienceDocs: [],
        insNoticeDocs: [],
        passportVisaI94Docs: [],
        formI20Docs: [],
        socialSecurityCardAndProfLicenseDocs: [],
        childDocumentArray: [{
          childvisa: [],
          childpassport: [],
          childformI94: [],
          childbirthCertificate: [],
        }],
        childvisa: [],
        childpassport: [],
        childformI94: [],
        childbirthCertificate: [],
        visaDocuments: [],
        formI94: [],
        formI797Docs: [],
        marriageCertificateDocs: [],
        birthCertificate: [],
        // openDate: new Date().setFullYear(new Date().getFullYear() - 18),
        startEligibleDate: new Date().setFullYear(new Date().getFullYear() - 18),
        startBeneficiaryDateEntered: new Date().setFullYear(new Date().getFullYear() - 7),
        SuccessQuestionnaire: false,
        formerrors: {
          msg: ""
        },
        petition: [],
        beneficiaryInfo: {
          firstName: '',
          lastName:'',
          email: '',
          gender: null,
          maritalStatus: null,
          education: {
            highestDegree: "",
            majorFieldOfStudy: ""
          },
          address: {},
          hasI140ImmPetitionFiled: true,
          SSN: ''
        },
        clientInfo: {
          address: {}
        },
        dependentsInfo: {
          spouse: {
            email:'',
            phoneNumber:'',
            phoneCountryCode:"+1",
            h4Required: true,
            h4EADRequired: null,
            lastArrivalDate:null,
            statusExpiryDate:null,
            physicalAddress: {

            },
            documents: {
              passport: [],
              visa: [],
              formI94: [],
              formI797: [],
              marriageCertificate: [],
              birthCertificate: [],
              other:[]
            }
          },
          childrens: [{
            documents: {
              passport: [],
              visa: [],
              formI94: [],
              birthCertificate: [],
              other:[]
            }
          }]
        },
        documents: {
          resume: [],
          education: [],
          expLetters: [],
          INSNotices: [],
          passportVisaI94: [],
          formI20: [],
          socialSecurityCardAndProfLicense: [],
          I140ApprovalNotice:[],
          payStubs:[],
          offerLetter:[],
          clientLetter:[],
          vendorLetter:[],
          msa:[],
          po:[], 
          other:[],
           },
        bncountryModel: [],
        checkCountry: false,
        countries: [],
        states: [],
        clientstates: [],
        stateModel: [],
        locations: [],
        locationModel: [],
        marital_statuses: [],
        education_types: [],
        visastatuses: [],
        clientcountryModel: [],
        clientstateModel: [],
        clientlocationModel: [],
        clientlocations: [],
        spousecountryModel: [],
        suposestates:[],
        souuselocations:[],
        spouseaddresscountryModel:null,
        spouseaddressstateModel:null,
        spouseaddresslocationModel:null,

        chiildcountryModel: [],
        clientInfo_salaryFrequency_Details:[],
        priorstay: {
          enteredDate: null,
          departedDate: null,
          visaStatus: null
        },
        priorPeriodOfStayInUS: [],
        childrensarray: [],
        children: [{
          "h4Required": true,
          "firstName": null,
          "middleName": null,
          "lastName": null,
          "dateOfBirth": null,
          "countryOfBirth": null,
          "selectedcountryOfBirth":null,
          "selectedcitizenship":null,
          "passportNumber": null,
          "passportExpiryDate": null,
          "I94": null,
          "visaIssuedDate": null,
          "currentStatus": null,
          "statusExpiryDate": null,
          "documents": {
          }
        }],
        countrySelected: '',
        countryOfCitizenshipSelected: '',
        latestPetition: ''
      };
    },
    methods: {
      setSpouseZipcode(){
        if(!this.dependentsInfo.spouse.physicalAddress.zipcode && this.beneficiaryInfo.address.zipcode){
          this.dependentsInfo.spouse.physicalAddress.zipcode   = this.beneficiaryInfo.address.zipcode
        }
      },
      setDependentsInfoAddress(isStreetAddress=true){
       
        if(isStreetAddress && this.beneficiaryInfo.address.line2 !='' &&  !this.dependentsInfo.spouse.physicalAddress.line2){
           this.dependentsInfo.spouse.physicalAddress.line2 = this.beneficiaryInfo.address.line2
         
           
        }

        if(!isStreetAddress && this.beneficiaryInfo.address.line1 !='' &&  !this.dependentsInfo.spouse.physicalAddress.line1){
           this.dependentsInfo.spouse.physicalAddress.line1 = this.beneficiaryInfo.address.line1;
        }
        
         },
      assignHomePhonenumber(){
        //beneficiaryInfo.cellPhoneNumber  beneficiaryInfo.homePhoneNumber
       // this.beneficiaryInfo['homePhoneNumber'] = this.beneficiaryInfo['cellPhoneNumber']
       // alert(this.beneficiaryInfo.homePhoneNumber);
      },
      setH4EADValue(h4, value) {
        this.dependentsInfo.spouse.h4EADRequired = (h4) ? value : null;
      },
      setDefaultcountry(){
        this.bncountryModel = {
          _id: "5db7f7409419e34350f11024",
          id: 231,
          name: "United States"
        },
        this.selectCountry(this.bncountryModel);


 

      },
      isDisabled(model) {
        if (model && model.length == 1) return false;
        return true;
      },
      acceptNumber() {
        var x = this.value.replace(/\D/g, '').match(/(\d{0,3})(\d{0,3})(\d{0,4})/);
        this.value = !x[2] ? x[1] : '(' + x[1] + ') ' + x[2] + (x[3] ? '-' + x[3] : '');
      },
      selectLocation(option) {
        this.beneficiaryInfo.address.locationId = option.id;
       

       
             this.dependentsInfo.spouse.physicalAddress.locationId =option.id;
             this.spouseaddresslocationModel = option;
              this.getSuposeLocation();
        
       
        


      },
      selectclientLocation(option) {
        this.clientInfo.address.locationId = option.id;
      },
      selectclientState(option) {
        this.clientInfo.address.stateId = option.id;
        this.clientlocationModel = [];
        this.getclientLocation();
      },
      selectclientCountry(option) {
        this.clientInfo.address.countryId = option.id;
        this.getclientStates();

      },

      
      selectspouseaddresstLocation(option) {
        this.dependentsInfo.spouse.physicalAddress.locationId = option.id;
      },
      selectspouseaddressState(option) {
        this.dependentsInfo.spouse.physicalAddress.stateId = option.id;
       // this.spouseaddresslocationModel = [];
        this.getSuposeLocation();
      },
      selectspouseaddressCountry(option) {
        this.dependentsInfo.spouse.physicalAddress.countryId = option.id;
        this.getSuposeStates();

      },

      selectState(option) {
        this.beneficiaryInfo.address.stateId = option.id;
        this.locationModel = [];
        this.getLocation();

     
        this.spouseaddressstateModel   = option;
        this.dependentsInfo.spouse.physicalAddress.stateId = option.id;
        this.getSuposeLocation();
    
        

        
        
      },
      selectCountry(option) {
        this.beneficiaryInfo.address.countryId = option.id;
        this.getStates();

        
          this.spouseaddresscountryModel = option;
          this.dependentsInfo.spouse.physicalAddress.countryId = option.id;
          this.getSuposeStates();
          

        

      },
      getclientStates() {
        this.$store
          .dispatch("getstates", this.clientInfo.address.countryId)
          .then(response => {
            this.clientstates = response;

            

          });

      },
      getStates() {
        this.$store
          .dispatch("getstates", this.beneficiaryInfo.address.countryId)
          .then(response => {
            this.states = response; 
          });
      },
      getclientLocation() {
        var obj = {
          stateId: this.clientInfo.address.stateId,
          countryId: this.clientInfo.address.countryId
        };

        this.$store.dispatch("getlocations", obj).then(response => {
          this.clientlocations = response;

          if(!this.spouseaddresslocationModel){
            this.spouseaddresslocationModel =this.locationModel
            this.selectspouseaddresstLocation(this.spouseaddresslocationModel)
          }

        });
      },
      getLocation() {
        var obj = {
          stateId: this.beneficiaryInfo.address.stateId,
          countryId: this.beneficiaryInfo.address.countryId
        };

        this.$store.dispatch("getlocations", obj).then(response => {
          this.locations = response;
        });
      },
     
     getSuposeStates() {
        this.$store
          .dispatch("getstates", this.dependentsInfo.spouse.physicalAddress.countryId)
          .then(response => {
            this.suposestates = response;
            

            if(this.spouseaddressstateModel !=null){
              this.spouseaddressstateModel = this.stateModel;
              this.selectspouseaddressState(this.spouseaddressstateModel);

            }

          });

      },
     getSuposeLocation() {
        var obj = {
          stateId: this.dependentsInfo.spouse.physicalAddress.stateId,
          countryId: this.dependentsInfo.spouse.physicalAddress.countryId
        };

        this.$store.dispatch("getlocations", obj).then(response => {
          this.souuselocations = response;

          // if(!this.spouseaddresslocationModel){
          //   this.spouseaddresslocationModel =this.locationModel
          //   this.selectspouseaddresstLocation(this.spouseaddresslocationModel)
          // }

        });
      },
     
     beforeTabSwitch() {
         return this.validateStep("beneficiaryInfoform");
        // return true;
      },
      beforeClient() {
        return this.validateStep("clientInfoform");
        // return true;
      },
      beforeDependents() {
      //  this.dependentsInfo.childrens = this.childrensarray; 

        Object.assign(this.dependentsInfo.childrens,this.childrensarray)
        
        
        //  return true;
         return this.validateStep("dependentsInfoform");
      },
      async validateStep(step) {
        const result = await this.$validator.validateAll(step).then(result => {
          return result;
        });
        if (result) {
          this.$validator.reset();
          window.scroll({
            top: 0,
            left: 0,
            behavior: 'smooth'
          })
        } else {
          const $ = JQuery;
          const firstField = Object.keys(this.errors.collect())[0];
          const ele = $('[name=' + firstField + ']').parents('.vx-col');
          $('html, body').animate({ scrollTop: ele.offset().top }, 2000);
        }
        return result;
      },
      setGender(item) {
        this.beneficiaryInfo.gender = item;
      },
      addpriorstay: function () {
        this.priorstay = {
          enteredDate: null,
          departedDate: null,
          visaStatus: null
        }
        this.priorPeriodOfStayInUS.push(this.priorstay);
      },
      removepriorstay: function (index) {
        Vue.delete(this.priorPeriodOfStayInUS, index)
      },
      addchildren: function () {
        this.children = {
          "h4Required": true,
          "firstName": null,
          "middleName": null,
          "lastName": null,
          "dateOfBirth": null,
          "countryOfBirth": null,
          "passportNumber": null,
          "passportExpiryDate": null,
          "I94": null,
          "visaIssuedDate": null,
          "currentStatus": null,
          "statusExpiryDate": null,
          "documents": {
            "passport": [],
            "visa": [],
            "FormI94": [],
            "formI797":[],
            "birthCertificate": [],
            "approvalNotice":[],
            "other":[]
          }
        },
        this.childrensarray.push(this.children);
      },
      removechildren: function (index) {
        Vue.delete(this.childrensarray, index)
        return false;
      },
      reloadthePage() {
          let routeTest = this.$route.params.itemId;
         // alert(this.$route.params.itemId)
          this.$router.push({ name: 'petition-details', params: { routeTest } }).catch(err => {})
      },
      formSubmitted() {
        var postpetition = {
          petitionId: this.$route.params.itemId,
          questionnaireFilled: true,
          userName: this.$store.state.user.name,
          typeName: this.petition.typeDetails.name,
          subTypeName: this.petition.subTypeDetails.name,
          action: "SUBMIT_QUESTIONNAIRE",
          currentDate: moment().format('YYYY-MM-DD'),
          beneficiaryInfo: this.beneficiaryInfo,
          dependentsInfo: this.dependentsInfo,
          clientInfo: this.clientInfo,
          documents: this.documents
        }
        postpetition.beneficiaryInfo.priorPeriodOfStayInUS = this.priorPeriodOfStayInUS;
        this.$store
          .dispatch("petitioner/petitionupdate", postpetition)
          .then(response => {

            if (response.error) {
              Object.assign(this.formerrors, {
                msg: response.error.message
              });
            } else {
              this.$vs.notify({
                title: "Success",                
                position: "top-right",
                color: "primary",
                text: response.message
              });
              this.SuccessQuestionnaire = true;

              document.addEventListener('click', this.reloadthePage);
            }
          });
      },
      upload(model) {
        let formData = new FormData();
        let mapper = model.map(item => item = {
          name: item.name,
          file: (item.file) ? item.file : null,
          url: (item.url) ? item.url : "",
          status: (item.status === false || item.status === true) ? item.status : true,
          mimetype: (item.type) ? item.type : item.mimetype,
          uploadedBy:this.checkProperty(this.getUserData,'userId'),
          uploadedByName:this.checkProperty(this.getUserData,'name'),
          uploadedByRoleId:this.getUserRoleId,
          uploadedByRoleName:this.checkProperty(this.getUserData,'loginRoleName'),
        });
        if(mapper.length > 0){
          mapper.forEach((doc, index)=> {
            formData.append('files', doc.file);
            formData.append('secureType', 'private');
            this.$store.dispatch('uploadS3File', formData).then(response=> {
              response.data.result.forEach(urlGenerated=> {
                doc.url = urlGenerated;
                delete doc.file;
                mapper[index] = doc;
              })
            });
          })
          model.splice(0, mapper.length, ...mapper);
        }
      },
      remove(item, type) {
        item.status = false;
        type[type.indexOf(item)] = item;
        return false;
      },
      selectchildCountry(option,id){
      this.childrensarray[id].countryOfBirth = option.id;
      },
       selectchildCitizenship(option,id){
      this.childrensarray[id].countryOfCitizenship = option.id;
      },

      
      selectspouseCountry(option) {
        this.dependentsInfo.spouse.countryOfBirth = option.id;
      },
          selectspousecountryOfCitizenship(option) {
        this.dependentsInfo.spouse.countryOfCitizenship = option.id;
      },
      getSalary_frequencies() {
        this.$store
          .dispatch("get_salary_frequencies", this.clientInfo.address.countryId)
          .then(response => {
            this.salaryOfferedType = response;
          });
      },
      getLatestPetition() {
        this.$store
        .dispatch("getlatestpetition", this.petition.userId)
        .then(response=> {
          this.$store
          .dispatch("getpetition", response[0]._id)
          .then(details=> {
            this.latestPetition = details.data.result;
            if(this.latestPetition.beneficiaryInfo) {
              this.beneficiaryInfo = this.latestPetition.beneficiaryInfo;
              this.documents = this.latestPetition.documents;
              if(this.beneficiaryInfo && this.beneficiaryInfo.address && this.beneficiaryInfo.address.countryDetails) {
                this.selectCountry(this.beneficiaryInfo.address.countryDetails);
                this.selectState(this.beneficiaryInfo.address.stateDetails);
                this.bncountryModel = this.beneficiaryInfo.address.countryDetails;
                this.stateModel = this.beneficiaryInfo.address.stateDetails;
                this.locationModel =this.beneficiaryInfo.address.locationDetails;
              }
              this.priorPeriodOfStayInUS = this.beneficiaryInfo.priorPeriodOfStayInUS;
            }
          })  
        })
      },
   
     
      checkTemplateField(checkKey=''){
        let return_value = true;
        if( checkKey !='' && _.has(this.petition ,"templateFileds") ){
          return_value = _.findIndex( this.petition.templateFileds ,(el)=>{ return el==checkKey })>-1?true:false;
        }
        return return_value;
      },
      getAllCountryes(){
         this.$store.dispatch("getcountries").then(response => {
        this.countries = response;
        this.clientcountryModel = {
              _id: "5db7f7409419e34350f11024",
              id: 231,
              name: "United States"
            },

         this.selectclientCountry(this.clientcountryModel);

         

      });
     
      }
   },
    mounted() {
    JQuery('#btnSidebarToggler').click()

  // this.$store.commit('UPDATE_SIDEBAR_ITEMS_MIN', true);
// this.$store.dispatch('updateSidebarWidth', 'reduced')
      this.getAllCountryes();
      this.priorPeriodOfStayInUS = [
        {
          enteredDate: null,
          departedDate: null,
          visaStatus: null
        }
      ];
      this.childrensarray = [
        {
          "h4Required": true,
          "firstName": null,
          "middleName": null,
          "lastName": null,
          "dateOfBirth": null,
          "countryOfBirth": null,
          "passportNumber": null,
          "passportExpiryDate": null,
          "I94": null,
          "visaIssuedDate": null,
          "currentStatus": null,
          "statusExpiryDate": null,
          "documents": {
            "passport": [],
            "visa": [],
            "formI94": [],
            "birthCertificate": [],
            "other":[]
          }
        }
      ];
      this.beneficiaryInfo.firstName = this.$store.state.user.name;
      var bphone = this.$store.state.user.phone;
      if(this.$store.state.user.phone && this.beneficiaryInfo.cellPhoneNumber==undefined) {

        this.beneficiaryInfo.cellPhoneNumber = bphone;

      }
         if(this.$store.state.user.phone && this.beneficiaryInfo.homePhoneNumber==undefined) {
        
         this.beneficiaryInfo.homePhoneNumber = bphone;

      }
      setTimeout(function(){
           window.scroll({
            top: 0,
            left: 0,
            behavior: 'smooth'
          })

      },1500)
          
      this.beneficiaryInfo.email = this.$store.state.user.email;
      this.$store.dispatch("getmasterdata", "visa_status").then(response => {
        this.visastatuses = response;
      });
      this.$store.dispatch("getmasterdata", "marital_status").then(response => {
        this.marital_statuses = response;
      });

      this.$store.dispatch("getmasterdata", "education_types").then(response => {
        this.education_types = response;
      });
     
     this.$store.dispatch("getpetition", this.$route.params.itemId).then(response => {
      
        
        this.petition = response.data.result;
        
        if(!this.petition){

            this.$router.push({ name: 'petitions'})
        }

        if(this.petition.userId != this.$store.state.user._id){
            this.$router.push({ name: 'petitions'})
        }
       if( this.petition.questionnaireFilled  && this.petition.statusId > 1){
            this.$router.push({ name: 'petitions'})
        }
        if( !this.petition.questionnaireFilled  && this.petition.currentActivity && this.petition.currentActivity == 'QUESTIONNIRE_REJECTED'){
          let routeId = this.$route.params.itemId
          this.$router.push({ name: 'questionnaire', params: { routeId } })
        }


        
		
        if(this.$router.currentRoute.name === 'questionnaire' || this.$router.currentRoute.name === 'editquestionnaire') {  
          //countryOfCitizenship   
        //  alert(JSON.stringify(this.petition['dependentsInfo']['spouse']));
         // alert(JSON.stringify(this.petition['dependentsInfo']['spouse']['countryOfBirthDetails']));
          this.countryOfCitizenshipSelected = this.petition['dependentsInfo']['spouse']['countryOfCitizenshipDetails'];
          
          this.beneficiaryInfo = this.petition.beneficiaryInfo;
          
                if(this.beneficiaryInfo.iAmFromUS){
             this.beneficiaryInfo.iAmFromUS = "true";
          }else{
            this.beneficiaryInfo.iAmFromUS = "false";

          }
          this.dependentsInfo =this.petition.dependentsInfo;
          this.clientInfo =this.petition.clientInfo;
          this.documents = this.petition.documents;

          if(this.beneficiaryInfo && this.beneficiaryInfo.address && this.beneficiaryInfo.address.countryDetails) {
            this.selectCountry(this.beneficiaryInfo.address.countryDetails);
            this.selectState(this.beneficiaryInfo.address.stateDetails);
            this.bncountryModel = this.beneficiaryInfo.address.countryDetails;
            this.stateModel = this.beneficiaryInfo.address.stateDetails;
            this.locationModel =this.beneficiaryInfo.address.locationDetails;
            this.selectclientCountry(this.clientInfo.address.countryDetails);
            this.selectclientState(this.clientInfo.address.stateDetails);
            this.selectclientLocation(this.clientInfo.address.locationDetails);
            this.clientcountryModel = this.clientInfo.address.countryDetails
            this.clientstateModel = this.clientInfo.address.stateDetails
            this.clientlocationModel =this.clientInfo.address.locationDetails;
            this.countrySelected = this.dependentsInfo.spouse.countryOfBirthDetails;
            
          }
           this.priorPeriodOfStayInUS = this.beneficiaryInfo.priorPeriodOfStayInUS;
             this.childrensarray = this.dependentsInfo.childrens;
                 
         
          this.dependentsInfo.childrens.forEach((child, index)=> {
            this.childrensarray[index].selectedcountryOfBirth = child.countryOfBirthDetails;
          })
           //this.clientInfo.salaryFrequency = this.clientInfo.salaryFrequencyDetails.id;
           this.childrensarray.forEach((children ,index)=>{
            this.childrensarray[index]['selectedcitizenship'] =  _.find(this.dependentsInfo.childrensCountryOfCitizenshipDetails ,(e)=>{ return e['id'] == children['countryOfCitizenship']});


           });
        }

      //  this.getLatestPetition();
    });
    
        
      
    this.getSalary_frequencies();
    },
    components: {
      FormWizard,
      TabContent,
      Datepicker,
      PhoneMaskInput,
      TheMask,
      FileUpload
    },
    watch: {
      'beneficiaryInfo.iAmFromUS': function(value) {
        if(value === 'true') {
          this.checkCountry = false;
          this.setDefaultcountry();
        } else {
          this.checkCountry = true;
        }
      },
      'maritalStatusOpen': function(value) {} 
    },
  };
</script>