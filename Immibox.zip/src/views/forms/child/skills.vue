<template>
<div>
    <template>
        <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
            <div class="form-container">
                <h3 class="small-header">Education</h3>
                <div class="vx-row">
                    <div class="vx-col w-full">
                        <template v-for="(item, itemindex) in application.education">
                            <div class="vx-row border" :key="itemindex">
                                <div class="vx-col md:w-1/2 w-full">
                                    <div class="main-placeholder right info-right">
                                        <vs-input class="w-full" :name="'schoolName' + itemindex + '_' + mindex" v-model="item.schoolName"  data-vv-as="Name" label="School Name" />
                                    </div>
                                    <span class="text-danger text-sm" v-show="
                        errors.has(
                          'beneficiaryInfoform.schoolName' +
                            itemindex +
                            '_' +
                            mindex
                        )
                      ">{{
                        errors.first(
                          "beneficiaryInfoform.schoolName" +
                            itemindex +
                            "_" +
                            mindex
                        )
                      }}</span>
                                </div>

                                <div class="vx-col md:w-1/2 w-full">
                                    <div class="main-placeholder right info-right">
                                        <vs-input class="w-full" :name="'degree' + itemindex + '_' + mindex" v-model="item.degree"  data-vv-as="Degree" label="Degree" />
                                    </div>
                                    <span class="text-danger text-sm" v-show="
                        errors.has(
                          'beneficiaryInfoform.degree' +
                            itemindex +
                            '_' +
                            mindex
                        )
                      ">{{
                        errors.first(
                          "beneficiaryInfoform.degree" +
                            itemindex +
                            "_" +
                            mindex
                        )
                      }}</span>
                                </div>

                                <div class="vx-col md:w-1/3 w-full">
                                    <div class="main-placeholder right info-right">
                                        <vs-input class="w-full" :name="'fieldOfStudy' + itemindex + '_' + mindex" v-model="item.fieldOfStudy"  data-vv-as="Field of Study" label="Field of Study" />
                                    </div>
                                    <span class="text-danger text-sm" v-show="
                        errors.has(
                          'beneficiaryInfoform.fieldOfStudy' +
                            itemindex +
                            '_' +
                            mindex
                        )
                      ">{{
                        errors.first(
                          "beneficiaryInfoform.fieldOfStudy" +
                            itemindex +
                            "_" +
                            mindex
                        )
                      }}</span>
                                </div>

                                <div class="vx-col md:w-1/3 w-full">
                                    <label class="date-picker-label"> From Date</label>

                                    <div class="main-placeholder right info-right">
                                        <datepicker  :typeable="true"  :use-utc="true"   :format="customFormatter" :name="'fromDate' + itemindex + '_' + mindex" :open-date="new Date()" data-vv-as="Date" v-model="item.fromDate" placeholder="MM/DD/YYYY">
                                        </datepicker>
                                    </div>

                                    <span class="text-danger text-sm" v-show="
                        errors.has(
                          'beneficiaryInfoform.fromDate' +
                            itemindex +
                            '_' +
                            mindex
                        )
                      ">{{
                        errors.first(
                          "beneficiaryInfoform.fromDate" +
                            itemindex +
                            "_" +
                            mindex
                        )
                      }}</span>
                                </div>

                                <div class="vx-col md:w-1/3 w-full">
                                    <label class="date-picker-label"> To Date</label>

                                    <div class="main-placeholder right info-right right_calendar">
                                        <datepicker  :typeable="true"  :use-utc="true"   :format="customFormatter" :name="'toDate' + itemindex + '_' + mindex" :open-date="new Date()" data-vv-as="Date" v-model="item.toDate"  placeholder="MM/DD/YYYY">
                                        </datepicker>
                                    </div>

                                    <span class="text-danger text-sm" v-show="
                        errors.has(
                          'beneficiaryInfoform.toDate' +
                            itemindex +
                            '_' +
                            mindex
                        )
                      ">{{
                        errors.first(
                          "beneficiaryInfoform.toDate" +
                            itemindex +
                            "_" +
                            mindex
                        )
                      }}</span>
                                </div>

                                <div class="pspdelete delete" v-if="application.education.length > 1">
                                    <a @click="removename(itemindex, application.education)">
                                        <img src="@/assets/images/main/delete-row-img.svg" />
                                    </a>
                                </div>
                            </div>
                        </template>

                    </div>
                </div>
                <div class="vx-row w-full">
                    <div class="vx-col w-full">
                        <a @click="addEducation(application.education)" class="add-more ml-0 maxadd" type="filled">
                            <span>+</span> More
                        </a>
                    </div>
                </div>
            </div>
        </vs-col>
        <div class="divider"></div>
        <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
            <div class="form-container">
                              <div class="vx-row">

                <div class="vx-col md:w-1/2 w-full">
                    <div class="main-placeholder right info-right">
                        <vs-input class="w-full" :name="'currentJobTitle' + '_' + mindex" v-model="application.currentJobTitle" data-vv-as="Job Title" label="Current Job Title" />
                    </div>
                    <span class="text-danger text-sm" v-show="
                        errors.has(
                          'beneficiaryInfoform.currentJobTitle' +
                            
                            '_' +
                            mindex
                        )
                      ">{{
                        errors.first(
                          "beneficiaryInfoform.currentJobTitle" +
                            
                            "_" +
                            mindex
                        )
                      }}</span>
                </div>

                <div class="vx-col md:w-1/2 w-full">
                    <div class="main-placeholder right info-right">
                        <vs-input class="w-full" :name="'currentAnnualSalary' + '_' + mindex" v-model="application.currentAnnualSalary" data-vv-as="Annual Salary" label="Current Annual Salary" />
                    </div>
                    <span class="text-danger text-sm" v-show="
                        errors.has(
                          'beneficiaryInfoform.currentAnnualSalary' +
                            '_' +
                            mindex
                        )
                      ">{{
                        errors.first(
                          "beneficiaryInfoform.currentAnnualSalary" +
                            "_" +
                            mindex
                        )
                      }}</span>
                </div>
            </div>

            </div>
        </vs-col>
        <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
            <div class="form-container" v-if="application.employmentHistoryUSAbroad.length > 0">
                <h3 class="small-header">
                    Please write the following information about your current and past
                    employment for the past five years in the U.S and aboard starting
                    with your most current Job
                </h3>
                <div class="vx-row employee-skils">
                    <div class="vx-col w-full">
                        <template v-for="(item,
                itemindex) in application.employmentHistoryUSAbroad">
                            <div class="vx-row border" :key="itemindex">
                                <div class="vx-col md:w-1/4 w-full">
                                    <div class="main-placeholder right info-right">
                                        <vs-input class="w-full" :name="'employerName' + itemindex + '_' + mindex" v-model="item.employerName" data-vv-as="Name" label="Name of Employer" />
                                    </div>
                                    <span class="text-danger text-sm" v-show="
                        errors.has(
                          'beneficiaryInfoform.employerName' +
                            itemindex +
                            '_' +
                            mindex
                        )
                      ">{{
                        errors.first(
                          "beneficiaryInfoform.employerName" +
                            itemindex +
                            "_" +
                            mindex
                        )
                      }}</span>
                                </div>

                                <div class="vx-col md:w-1/4 w-full">
                                    <div class="main-placeholder right info-right">
                                        <vs-input class="w-full" :name="'occupation' + itemindex + '_' + mindex" v-model="item.occupation" data-vv-as="Occupation" label="Occupation" />
                                    </div>
                                    <span class="text-danger text-sm" v-show="
                        errors.has(
                          'beneficiaryInfoform.occupation' +
                            itemindex +
                            '_' +
                            mindex
                        )
                      ">{{
                        errors.first(
                          "beneficiaryInfoform.occupation" +
                            itemindex +
                            "_" +
                            mindex
                        )
                      }}</span>
                                </div>

                                <div class="vx-col md:w-1/4 w-full">
                                    <label class="date-picker-label"> From Date</label>

                                    <div class="main-placeholder right info-right right_calendar">
                                        <datepicker  :typeable="true"  :use-utc="true"   :format="customFormatter" :name="'occfromDate' + itemindex + '_' + mindex" :open-date="new Date()" data-vv-as="Date" v-model="item.fromDate" placeholder="MM/DD/YYYY">
                                        </datepicker>
                                    </div>

                                    <span class="text-danger text-sm" v-show="
                        errors.has(
                          'beneficiaryInfoform.occfromDate' +
                            itemindex +
                            '_' +
                            mindex
                        )
                      ">{{
                        errors.first(
                          "beneficiaryInfoform.occfromDate" +
                            itemindex +
                            "_" +
                            mindex
                        )
                      }}</span>
                                </div>

                                <div class="vx-col md:w-1/4 w-full" v-if="itemindex != 0">
                                    <label class="date-picker-label"> To Date</label>

                                    <div class="main-placeholder right info-right right_calendar">
                                        <datepicker  :typeable="true"  :use-utc="true"   :format="customFormatter" :name="'occtoDate' + itemindex + '_' + mindex" :open-date="new Date()" data-vv-as="Date" v-model="item.toDate" placeholder="MM/DD/YYYY">
                                        </datepicker>
                                    </div>

                                    <span class="text-danger text-sm" v-show="
                        errors.has(
                          'beneficiaryInfoform.occtoDate' +
                            itemindex +
                            '_' +
                            mindex
                        )
                      ">{{
                        errors.first(
                          "beneficiaryInfoform.occtoDate" +
                            itemindex +
                            "_" +
                            mindex
                        )
                      }}</span>
                                </div>

                                <div class="vx-row">
                                    <div class="vx-col w-full education_address">
                                        <locationFields :countries="countries" ref="employmentHistoryUSAbroadref" :address="item.address" :cid="
                          'employmentHistoryUSAbroadref' +
                          itemindex +
                          '_' +
                          mindex
                        " />
                                    </div>
                                </div>

                                <div class="pspdelete delete" v-if="application.employmentHistoryUSAbroad.length > 1">
                                    <a @click="
                        removename(
                          itemindex,
                          application.employmentHistoryUSAbroad
                        )
                      ">
                                        <img src="@/assets/images/main/delete-row-img.svg" />
                                    </a>
                                </div>
                            </div>
                        </template>
                    </div>
                </div>
                <div class="vx-row">
                    <div class="vx-col w-full">
                        <a @click="addmoreemployers(application.employmentHistoryUSAbroad)" class="add-more ml-0 maxadd" type="filled">
                            <span>+</span> More
                        </a>
                    </div>
                </div>
            </div>
        </vs-col>

        <div class="divider"></div>

        <vs-col class="m-auto float-none" v-if="application.lastEmployerOutsideUS" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
            <div class="form-container">
                <h3 class="small-header">
                    Last Employer outside of the United States for more than one year
                </h3>
                <div class="vx-row">
                    <div class="vx-col w-full">
                        <template>
                            <div class="vx-row border">
                                <div class="vx-col md:w-1/4 w-full">
                                    <div class="main-placeholder right info-right">
                                        <vs-input class="w-full" :name="'lemployerName' + '_' + mindex" v-model="application.lastEmployerOutsideUS.employerName" data-vv-as="Name" label="Name of Employer" />
                                    </div>
                                    <span class="text-danger text-sm" v-show="
                        errors.has(
                          'beneficiaryInfoform.lemployerName' + '_' + mindex
                        )
                      ">{{
                        errors.first(
                          "beneficiaryInfoform.lemployerName" + "_" + mindex
                        )
                      }}</span>
                                </div>

                                <div class="vx-col md:w-1/4 w-full">
                                    <div class="main-placeholder right info-right">
                                        <vs-input class="w-full" :name="'locpissuedPerson' + '_' + mindex" v-model="application.lastEmployerOutsideUS.occupation" data-vv-as="Occupation" label="Occupation" />
                                    </div>
                                    <span class="text-danger text-sm" v-show="
                        errors.has(
                          'beneficiaryInfoform.locpissuedPerson' + '_' + mindex
                        )
                      ">{{
                        errors.first(
                          "beneficiaryInfoform.locpissuedPerson" + "_" + mindex
                        )
                      }}</span>
                                </div>

                                <div class="vx-col md:w-1/4 w-full">
                                    <label class="date-picker-label"> From Date</label>

                                    <div class="main-placeholder right info-right right_calendar">
                                        <datepicker  :typeable="true"  :use-utc="true"   :format="customFormatter" :name="'loccfromDate' + '_' + mindex" :open-date="new Date()" data-vv-as="Date" v-model="application.lastEmployerOutsideUS.fromDate" placeholder="MM/DD/YYYY">
                                        </datepicker>
                                    </div>

                                    <span class="text-danger text-sm" v-show="
                        errors.has(
                          'beneficiaryInfoform.loccfromDate' + '_' + mindex
                        )
                      ">{{
                        errors.first(
                          "beneficiaryInfoform.loccfromDate" + "_" + mindex
                        )
                      }}</span>
                                </div>

                                <div class="vx-col md:w-1/4 w-full">
                                    <label class="date-picker-label"> To Date</label>

                                    <div class="main-placeholder right info-right right_calendar">
                                        <datepicker  :typeable="true"  :use-utc="true"   :format="customFormatter" :name="'localtoDate' + '_' + mindex" :open-date="new Date()" data-vv-as="Date" v-model="application.lastEmployerOutsideUS.toDate" placeholder="MM/DD/YYYY">
                                        </datepicker>
                                    </div>

                                    <span class="text-danger text-sm" v-show="
                        errors.has(
                          'beneficiaryInfoform.localtoDate' + '_' + mindex
                        )
                      ">{{
                        errors.first(
                          "beneficiaryInfoform.localtoDate" + "_" + mindex
                        )
                      }}</span>
                                </div>

                                <div class="vx-row">
                                    <div class="vx-col w-full education_address">
                                        <locationFields :countries="countries" ref="lastEmployerOutsideUS" :address="application.lastEmployerOutsideUS.address" :cid="'lastEmployerOutsideUS' + mindex" />
                                    </div>
                                </div>
                            </div>
                        </template>
                    </div>
                </div>
            
            </div>
        </vs-col>
    </template>
</div>
</template>

<script>
import {
    FormWizard,
    TabContent
} from "vue-form-wizard";
import "vue-form-wizard/dist/vue-form-wizard.min.css";
import Datepicker from "vuejs-datepicker-inv";
import moment from "moment";
import PhoneMaskInput from "vue-phone-mask-input";
import JQuery from "jquery";
import {
    TheMask
} from "vue-the-mask";
import FileUpload from "vue-upload-component/src";
import _ from "lodash";
import Vue from "vue";
import locationFields from "./location.vue";
export default {
    inject: ["parentValidator"],
    props: {
        application: Object,
        mindex: Number,
        countries: Array,
    },
    watch: {
        address: {
            handler(val) {
                this.$emit("compmodel", val);
            },
            deep: true,
        },
    },
    data() {
        return {
            raceslist: [],
            maritallist: [],
            eyecolorslist: [],
            haircolorlist: [],
            nationalitylist: [],
            genders: ["Male", "Female", "Other"],
            startEligibleDate: new Date().setFullYear(new Date().getFullYear() - 18),
            startBeneficiaryDateEntered: new Date().setFullYear(
                new Date().getFullYear() - 7
            ),
        };
    },
    created() {
        this.$validator = this.parentValidator;
    },
    mounted() {},
    methods: {
          customFormatter(date) {
          return moment.utc(date).startOf('day').format('MM-DD-YYYY');
      },
        addEducation: function (obj) {
            var name = {
                schoolName: "",
                degree: "",
                fieldOfStudy: "",
                fromDate: "",
                toDate: "",
            };
            obj.push(name);
        },
        addmoreemployers: function (obj) {
            var name = {
                employerName: null,
                address: {
                    line1: null,
                    zipcode: null,
                    line2: null,
                    location: null,
                    country: null,
                    state: null,
                },
                occupation: null,
                fromDate: null,
                toDate: null,
            };
            obj.push(name);
        },
        addlanguageSkills: function (obj) {
            var name = {
                name: "",
                issuedDate: "",
                issuedPerson: "",
            };
            obj.push(name);
        },
        removename: function (index, obj) {
            Vue.delete(obj, index);
        },
    },
    components: {
        FormWizard,
        TabContent,
        Datepicker,
        PhoneMaskInput,
        TheMask,
        FileUpload,
        locationFields,
    },
    beforeDestroy() {},
};
</script>
