<template>
    <div :key="application" >
      <div class="gc_steps_wrap" v-if="application.applicationRequired">
        <ul>
          <li
            v-bind:class="{
              current: toptab == 'step1_' + mindex,
              completed: totabnum > 10,
            }"
          >
            <span>1</span><label>Personal Info</label>
          </li>
          <li
            v-bind:class="{
              current: toptab == 'step2_' + mindex,
              completed: totabnum > 20,
            }"
          >
            <span>2</span><label>Addresses</label>
          </li>
          <li
            v-bind:class="{
              current: toptab == 'step3_' + mindex,
              completed: totabnum > 30,
            }"
          >
            <span>3</span><label>Immigration</label>
          </li>
          <li
            v-bind:class="{
              current: toptab == 'step4_' + mindex,
              completed: totabnum > 40,
            }"
          >
            <span>4</span
            ><label
              >Occupational<br />
              Skills</label
            >
          </li>
          <li
            v-bind:class="{
              current: toptab == 'step5_' + mindex,
              completed: totabnum > 50,
            }"
          >
            <span>5</span
            ><label
              >Assets &amp;<br />
              Financials</label
            >
          </li>
          <li
            v-bind:class="{
              current: toptab == 'step6_' + mindex,
              completed: totabnum > 60,
            }"
          >
            <span>6</span><label>Parents</label>
          </li>
          <li
            v-bind:class="{
              current: toptab == 'step7_' + mindex,
              completed: totabnum > 70,
            }"
          >
            <span>7</span><label>Documents</label>
          </li>
        </ul>
      </div>

      <div
        v-if="toptab == 'step1_' + mindex"
        :id="'application' + mindex + 'step1'"
      >
        <personalInfo
          :countries="countries"
          @maritalStatusChange="maritalStatusChange"
          :application="application"
          :mindex="mindex"
        />
        <div class="gc_tab_buttons">
          <div></div>
          <button @click="gotoTab('step2_' + mindex)">Next</button>
        </div>
      </div>

      <div
        v-if="toptab == 'step2_' + mindex"
        :id="'application' + mindex + 'step2'"
      >
        <Addresses
          :countries="countries"
          :application="application"
          :mindex="mindex"
        />
        <div class="gc_tab_buttons">
          <div>
            <button class="previous" @click="gotoTabp('step1_' + mindex)">
              Previous
            </button>
          </div>

          <button @click="gotoTab('step3_' + mindex)">Next</button>
        </div>
      </div>

      <div
        v-if="toptab == 'step3_' + mindex"
        :id="'application' + mindex + 'step2'"
      >
        <immigration
          :countries="countries"
          :application="application"
          :mindex="mindex"
        />
        <div class="gc_tab_buttons">
          <div>
            <button class="previous" @click="gotoTabp('step2_' + mindex)">
              Previous
            </button>
          </div>
          <button @click="gotoTab('step4_' + mindex)">Next</button>
        </div>
      </div>

      <div
        v-if="toptab == 'step4_' + mindex"
        :id="'application' + mindex + 'step2'"
      >
        <skills
          :countries="countries"
          :application="application"
          :mindex="mindex"
        />
        <div class="gc_tab_buttons">
          <div>
            <button class="previous" @click="gotoTabp('step3_' + mindex)">
              Previous
            </button>
          </div>
          <button @click="gotoTab('step5_' + mindex)">Next</button>
        </div>
      </div>

      <div
        v-if="toptab == 'step5_' + mindex"
        :id="'application' + mindex + 'step2'"
      >
        <assets
          :countries="countries"
          :application="application"
          :mindex="mindex"
        />
        <div class="gc_tab_buttons">
          <div>
            <button class="previous" @click="gotoTabp('step4_' + mindex)">
              Previous
            </button>
          </div>
          <button @click="gotoTab('step6_' + mindex)">Next</button>
        </div>
      </div>

      <div
        v-if="toptab == 'step6_' + mindex"
        :id="'application' + mindex + 'step2'"
      >
        <parents
          :countries="countries"
          :application="application"
          :mindex="mindex"
        />
        <div class="gc_tab_buttons">
          <div>
            <button class="previous" @click="gotoTabp('step5_' + mindex)">
              Previous
            </button>
          </div>
          <button @click="gotoTab('step7_' + mindex)">Next</button>
        </div>
      </div>
      <div
        v-if="toptab == 'step7_' + mindex"
        :id="'application' + mindex + 'step2'"
      >
        <documents
          :countries="countries"
          :application="application"
          :mindex="mindex"
        />
        <div class="gc_tab_buttons">
          <div>
            <button class="previous" @click="gotoTabp('step6_' + mindex)">
              Previous
            </button>
          </div>

          <button @click="gotoTab('step7_' + mindex)">Save</button>

          <button @click="submitapplication()">Submit</button>
        </div>
      </div>
    </div>
</template>


<script>
import { FormWizard, TabContent } from "vue-form-wizard";
import "vue-form-wizard/dist/vue-form-wizard.min.css";
import Datepicker from "vuejs-datepicker-inv";
import moment from "moment";
import PhoneMaskInput from "vue-phone-mask-input";
import JQuery from "jquery";
import { TheMask } from "vue-the-mask";
import FileUpload from "vue-upload-component/src";
import _ from "lodash";
import Vue from "vue";
import personalInfo from "./personalinfo.vue";
import Addresses from "./addresses.vue";

import immigration from "./immigration.vue";

import skills from "./skills.vue";

import assets from "./assets.vue";

import parents from "./parents.vue";

import documents from "./documents.vue";

export default {
  props: {
    application: Object,
    mindex: Number,
    countries:Array
  },
  provide() {
    return {
      parentValidator: this.$validator,
    };
  },
  // balu data
  data() {
    return {
      toptab: "step1_0",
      showprevious: false,
      currentapplication: 0,
      raceslist: [],
      maritallist: [],
      eyecolorslist: [],
      haircolorlist: [],
      nationalitylist: [],
      genders: ["Male", "Female", "Other"],
      bapplication: null,
      currentroute: this.$route.params.itemId,
      startEligibleDate: new Date().setFullYear(new Date().getFullYear() - 18),
      startBeneficiaryDateEntered: new Date().setFullYear(
        new Date().getFullYear() - 7
      ),
      SuccessQuestionnaire: false,
      formerrors: {
        msg: "",
      },
      petition: [],
      totabnum: 10,
    };
  },
  methods: {
    checktabcomplted(tab) {
      var test = tab.split("_")[0].replace("step");
      test = parseInt(test);
      var atest = this.toptab.split("_")[0].replace("step");
      if (atest > test) {
        return true;
      }
      return false;
    },
    gotoTabp(tab) {
      this.toptab = tab;
      window.scroll({
        top: 0,
        left: 0,
        behavior: "smooth",
      });
    },
    reloadthePage() {
      let routeTest = this.$route.params.itemId;
      this.$router.push({
        name: "gcapplication",
        params: {
          routeTest,
        },
      });
    },
    submitapplication() {
      var postpetition = {
        petitionId: this.$route.params.itemId,
        userName: this.$store.state.user.name,
        action: "BENEFICIARY_INFO_UPDATE",
        updateSection: "BENEFICIARY_INFO_UPDATE",
        questionnaireFilled: true,
        beneficiaryInfo: this.applications[0],
      };

      this.$store
        .dispatch("petitioner/updateapplication", postpetition)
        .then((response) => {
          this.SuccessQuestionnaire = true;

          document.addEventListener("click", this.reloadthePage);
        });
    },
    async gotoTab(tab) {
       this.toptab = tab;
      const result = await this.$validator
        .validateAll("beneficiaryInfoform")
        .then((result) => {
          return result;
        });

      if (result) {
        this.$validator.reset();
        window.scroll({
          top: 0,
          left: 0,
          behavior: "smooth",
        });

        var postpetition = {
          petitionId: this.$route.params.itemId,
          userName: this.$store.state.user.name,
          action: "BENEFICIARY_INFO_UPDATE",
          updateSection: "BENEFICIARY_INFO_UPDATE",
          questionnaireFilled: false,
          beneficiaryInfo: this.applications[0],
        };

        this.$store
          .dispatch("petitioner/updateapplication", postpetition)
          .then((response) => {});

       
      } else {
        const $ = JQuery;
        const firstField = Object.keys(this.errors.collect())[0];
        const ele = $("[name=" + firstField + "]").parents(".vx-col");
        $("html, body").animate(
          {
            scrollTop: ele.offset().top,
          },
          2000
        );
      }
    },
    setapplicationRequired(index, bool) {
      Vue.set(this.applications[index], "applicationRequired", bool);
    },
    beforeTabSwitch() {
    
    },
    async validateStep(step) {
      return true;
      const result = await this.$validator.validateAll(step).then((result) => {
        return result;
      });

      if (result) {
        this.$validator.reset();
        window.scroll({
          top: 0,
          left: 0,
          behavior: "smooth",
        });
      } else {
        const $ = JQuery;
        const firstField = Object.keys(this.errors.collect())[0];
        const ele = $("[name=" + firstField + "]").parents(".vx-col");
        $("html, body").animate(
          {
            scrollTop: ele.offset().top,
          },
          2000
        );
      }
      return result;
    },
    setGender(item, application) {
      application.gender = item;
    },
    addmorenames: function (obj) {
      var name = {
        firstName: "",
        middleName: "",
        lastName: "",
      };
      obj.push(name);
    },
    removename: function (index, obj) {
      Vue.delete(obj, index);
    },
    formSubmitted() {
      var postpetition = {
        petitionId: this.$route.params.itemId,
        questionnaireFilled: true,
        userName: this.$store.state.user.name,
        typeName: this.petition.typeDetails.name,
        subTypeName: this.petition.subTypeDetails.name,
        action: "SUBMIT_QUESTIONNAIRE",
        currentDate: moment().format("YYYY-MM-DD"),
        beneficiaryInfo: this.beneficiaryInfo,
        dependentsInfo: this.dependentsInfo,
        clientInfo: this.clientInfo,
        documents: this.documents,
      };
      postpetition.beneficiaryInfo.priorPeriodOfStayInUS = this.priorPeriodOfStayInUS;
      this.$store
        .dispatch("petitioner/petitionupdate", postpetition)
        .then((response) => {
          if (response.error) {
            Object.assign(this.formerrors, {
              msg: response.error.message,
            });
          } else {
            this.$vs.notify({
              title: "Success",              
              position: "top-right",
              color: "primary",
              text: response.message,
            });
            this.SuccessQuestionnaire = true;

            document.addEventListener("click", this.reloadthePage);
          }
        });
    },
    upload(model) {
      let formData = new FormData();
      let mapper = model.map(
        (item) =>
          (item = {
            name: item.name,
            file: item.file ? item.file : null,
            url: item.url ? item.url : "",
            status:
              item.status === false || item.status === true
                ? item.status
                : true,
            mimetype: item.type ? item.type : item.mimetype,
            uploadedBy:this.checkProperty(this.getUserData,'userId'),
            uploadedByName:this.checkProperty(this.getUserData,'name'),
            uploadedByRoleId:this.getUserRoleId,
            uploadedByRoleName:this.checkProperty(this.getUserData,'loginRoleName'),
          })
      );
      if (mapper.length > 0) {
        mapper.forEach((doc, index) => {
          formData.append("files", doc.file);
          formData.append("secureType", "private");
          this.$store.dispatch("uploadS3File", formData).then((response) => {
            response.data.result.forEach((urlGenerated) => {
              doc.url = urlGenerated;
              delete doc.file;
              mapper[index] = doc;
            });
          });
        });
        model.splice(0, mapper.length, ...mapper);
      }
    },
    remove(item, type) {
      item.status = false;
      type[type.indexOf(item)] = item;
      return false;
    },
    maritalStatusChange($event, mindex) {
          this.$emit("maritalStatusChange", $event, index);

    },

    getDefaultMasterdata() {
      this.$store.dispatch("getcountries").then((response) => {
        this.countries = response;
      });

      this.$store
        .dispatch("getmasterdata", "marital_status")
        .then((response) => {
          this.maritallist = response;
        });
      this.$store.dispatch("getmasterdata", "races").then((response) => {
        this.raceslist = response;
      });
      this.$store.dispatch("getmasterdata", "hair_colors").then((response) => {
        this.haircolorlist = response;
      });

      this.$store.dispatch("getmasterdata", "eye_colors").then((response) => {
        this.eyecolorslist = response;
      });

      this.$store.dispatch("getmasterdata", "nationality").then((response) => {
        this.nationalitylist = response;
      });
    },
  },
  
   beforeDestroy(){
              document.removeEventListener('click', this.reloadthePage);
   },
  mounted() {
    JQuery("#btnSidebarToggler").click();

    this.getDefaultMasterdata();
  },
  computed: {},
  components: {
    FormWizard,
    TabContent,
    Datepicker,
    PhoneMaskInput,
    TheMask,
    FileUpload,
    personalInfo,
    Addresses,
    immigration,
    skills,
    assets,
    parents,
    documents,
  },
  watch: {
    toptab: function (value) {
      var atest = value.split("_")[0].replace("step", "");

      var t = atest + value.split("_")[1];
      this.totabnum = parseInt(t);
    },
  },
};
</script>
