<template>
<div>
    <template>
        <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
            <div class="form-container">
                <h3 class="small-header">Immigration</h3>

                <div class="vx-row">

                    <div class="vx-col md:w-1/2 w-full">

                        <div class="main-placeholder right info-right">
                            <vs-input class="w-full" :name="'currentStatus' +mindex" v-model="application.currentStatus" data-vv-as="Current Status" label="Current Status" />
                        </div>
                        <span class="text-danger text-sm" v-show="
                        errors.has(
                          'beneficiaryInfoform.currentStatus' +mindex
                        )
                      ">{{
                        errors.first(
                          "beneficiaryInfoform.currentStatus" +mindex
                        )
                      }}</span>

                    </div>

                    <div class="vx-col md:w-1/2 w-full">
                        <label class="date-picker-label"> Status Expiry Date</label>

                        <div class="main-placeholder right info-right">
                            <datepicker  :typeable="true"  :use-utc="true"   :format="customFormatter" :name="'statusExpiryDate' +mindex" :open-date="new Date()" data-vv-as="Status Expiry Date" v-model="application.statusExpiryDate" placeholder="MM/DD/YYYY">
                            </datepicker>
                        </div>

                        <span class="text-danger text-sm" v-show="
                    errors.has('beneficiaryInfoform.statusExpiryDate' +mindex)
                  ">{{
                    errors.first("beneficiaryInfoform.statusExpiryDate" +mindex)
                  }}</span>
                    </div>

                </div>

                <div class="vx-row">
                    <div class="vx-col w-full">
                        <citystate :placeOnlyTitle="'Place of Last Entry into the USA'" :placeOnly="true" :address="application.lastEntryPlaceInUs" :cid="'lastEntryPlaceInUs' + mindex" />
                    </div>
                </div>

                <div class="vx-row">
                    <div class="vx-col w-full" v-if="countries && countries.length > 0">
                        All Countries that have Issued you a currently valid passport
                        <template v-for="(addressm,
                addindex) in application.allCountryIssuedPassports">
                            <div class="vx-row imm-width" :key="addindex">
                                <div class="vx-col md:w-1/4 w-full">
                                    <div class="con-select w-full select-large">
                                        <label class="vs-select--label">Country</label>
                                        <multiselect :name="'allCountryIssuedPassportsc' + addindex+'_'+mindex" v-model="addressm.country" :show-labels="false" track-by="id" label="name" :options-height="20" data-vv-as="Country" placeholder="Select " :options="countries" :searchable="true" :allow-empty="false">
                                        </multiselect>
                                    </div>

                                    <span class="text-danger text-sm" v-show="
                        errors.has(
                          'beneficiaryInfoform.allCountryIssuedPassportsc' +
                            addindex+'_'+mindex
                        )
                      ">{{
                        errors.first(
                          "beneficiaryInfoform.allCountryIssuedPassportsc" +
                            addindex+'_'+mindex
                        )
                      }}</span>
                                </div>

                                <div class="vx-col md:w-1/4 w-full">
                                    <div class="main-placeholder right info-right">
                                        <vs-input class="w-full" :name="'alppassportNumber' + addindex+'_'+mindex" v-model="addressm.number" v-validate="'max:12'" data-vv-as="Passport Number" label="Passport Number" />
                                    </div>
                                    <span class="text-danger text-sm" v-show="
                        errors.has(
                          'beneficiaryInfoform.alppassportNumber' + addindex+'_'+mindex
                        )
                      ">{{
                        errors.first(
                          "beneficiaryInfoform.alppassportNumber" + addindex+'_'+mindex
                        )
                      }}</span>
                                </div>

                                <div class="vx-col md:w-1/4 w-full">
                                    <label class="date-picker-label"> Issued Date</label>

                                    <div class="main-placeholder right info-right">
                                        <datepicker  :typeable="true"  :use-utc="true"   :format="customFormatter" :name="'alpissuedDate' + addindex+'_'+mindex" :open-date="new Date()" data-vv-as="Passport Issued Date" v-model="addressm.issuedDate" placeholder="MM/DD/YYYY">
                                        </datepicker>
                                    </div>

                                    <span class="text-danger text-sm" v-show="
                        errors.has(
                          'beneficiaryInfoform.alpissuedDate' + addindex+'_'+mindex
                        )
                      ">{{
                        errors.first(
                          "beneficiaryInfoform.alpissuedDate" + addindex+'_'+mindex
                        )
                      }}</span>
                                </div>

                                <div class="vx-col md:w-1/4 w-full">
                                    <label class="date-picker-label"> Expiration Date</label>

                                    <div class="main-placeholder right info-right right_calendar">
                                        <datepicker  :typeable="true"  :use-utc="true"   :format="customFormatter" :name="'alpexpiryDate' + addindex+'_'+mindex" :open-date="new Date()" data-vv-as="Passport Issued Date" v-model="addressm.expiryDate" placeholder="MM/DD/YYYY">
                                        </datepicker>
                                    </div>

                                    <span class="text-danger text-sm" v-show="
                        errors.has(
                          'beneficiaryInfoform.alpexpiryDate' + addindex+'_'+mindex
                        )
                      ">{{
                        errors.first(
                          "beneficiaryInfoform.alpexpiryDate" + addindex+'_'+mindex
                        )
                      }}</span>
                                </div>

                                <div class="pspdelete delete" v-if="application.allCountryIssuedPassports.length > 1">
                                    <a @click="
                        removename(
                          addindex,
                          application.allCountryIssuedPassports
                        )
                      ">
                                        <img src="@/assets/images/main/delete-row-img.svg" />
                                    </a>
                                </div>
                            </div>
                        </template>

                        <div class="vx-row">
                            <div class="vx-col w-full">
                                <a @click="addmorenames(application.allCountryIssuedPassports)" class="add-more ml-0 maxadd" type="filled">
                                    <span>+</span> More
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="vx-row">
                    <div class="vx-col md:w-1/3 w-full">
                        <label class="date-picker-label"> Case Issued Date</label>

                        <div class="main-placeholder right info-right">
                            <datepicker  :typeable="true"  :use-utc="true"   :format="customFormatter" :name="'visaIssuedDate' + mindex" :open-date="new Date()" data-vv-as="Case Issued Date" v-model="application.visaIssuedDate" placeholder="MM/DD/YYYY">
                            </datepicker>
                        </div>

                        <span class="text-danger text-sm" v-show="
                    errors.has('beneficiaryInfoform.visaIssuedDate' + mindex)
                  ">{{
                    errors.first("beneficiaryInfoform.visaIssuedDate" + mindex)
                  }}</span>
                    </div>
                    <div class="vx-col md:w-1/3 w-full">
                        <label class="date-picker-label"> Case Expiry Date</label>

                        <div class="main-placeholder right info-right">
                            <datepicker  :typeable="true"  :use-utc="true"   :format="customFormatter" :name="'visaExpiryDate' +mindex" :open-date="new Date()" data-vv-as="Case Expiry Date" v-model="application.visaExpiryDate" placeholder="MM/DD/YYYY">
                            </datepicker>
                        </div>

                        <span class="text-danger text-sm" v-show="
                    errors.has('beneficiaryInfoform.visaExpiryDate' +mindex)
                  ">{{
                    errors.first("beneficiaryInfoform.visaExpiryDate" +mindex)
                  }}</span>
                    </div>

                    <div class="vx-col md:w-1/3 w-full">

                        <div class="main-placeholder right info-right">
                            <vs-input class="w-full" :name="'visaIssuedAt' +mindex" v-model="application.visaIssuedAt" data-vv-as="Case Issued At" label="Case Issued At" />
                        </div>
                        <span class="text-danger text-sm" v-show="
                        errors.has(
                          'beneficiaryInfoform.visaIssuedAt' +mindex
                        )
                      ">{{
                        errors.first(
                          "beneficiaryInfoform.visaIssuedAt" +mindex
                        )
                      }}</span>

                    </div>
                </div>

                <div class="vx-row">
                    <div class="vx-col md:w-1/3 w-full">
                        <label class="date-picker-label"> Most Recent Entry into the USA</label>

                        <div class="main-placeholder right info-right">
                            <datepicker  :typeable="true"  :use-utc="true"   :format="customFormatter" :name="'mostRecentEntryDateInUs' +mindex" :open-date="new Date()" data-vv-as="Date" v-model="application.mostRecentEntryDateInUs" placeholder="MM/DD/YYYY">
                            </datepicker>
                        </div>

                        <span class="text-danger text-sm" v-show="
                    errors.has('beneficiaryInfoform.mostRecentEntryDateInUs' +mindex)
                  ">{{
                    errors.first("beneficiaryInfoform.mostRecentEntryDateInUs" +mindex)
                  }}</span>
                    </div>
                    <div class="vx-col md:w-1/3 w-full">
                        <label class="date-picker-label"> Initial (First) Entry into the USA</label>

                        <div class="main-placeholder right info-right">
                            <datepicker  :typeable="true"  :use-utc="true"   :format="customFormatter" :name="'initialEntryDateInUs' +mindex" :open-date="new Date()" data-vv-as="Date" v-model="application.initialEntryDateInUs" placeholder="MM/DD/YYYY">
                            </datepicker>
                        </div>

                        <span class="text-danger text-sm" v-show="
                    errors.has('beneficiaryInfoform.initialEntryDateInUs' +mindex)
                  ">{{
                    errors.first("beneficiaryInfoform.initialEntryDateInUs" +mindex)
                  }}</span>
                    </div>

                    <div class="vx-col md:w-1/3 w-full">

                        <div class="main-placeholder right info-right">
                            <vs-input class="w-full" :name="'mannerOfMostEntryInUs' +mindex" v-model="application.mannerOfMostEntryInUs" data-vv-as="Entry details" label="Manner of Most recent entry into the USA" />
                        </div>
                        <span class="text-danger text-sm" v-show="
                        errors.has(
                          'beneficiaryInfoform.mannerOfMostEntryInUs' +mindex
                        )
                      ">{{
                        errors.first(
                          "beneficiaryInfoform.mannerOfMostEntryInUs" +mindex
                        )
                      }}</span>

                    </div>
                </div>

                <div class="vx-row">
                    <div class="vx-col md:w-1/3 w-full">
                        <label class="date-picker-label"> Expiration Date on Form I-94</label>

                        <div class="main-placeholder right info-right">
                            <datepicker  :typeable="true"  :use-utc="true"   :format="customFormatter" :name="'formI94ExpiryDate' +mindex" :open-date="new Date()" data-vv-as="Expiration Date" v-model="application.formI94ExpiryDate" placeholder="MM/DD/YYYY">
                            </datepicker>
                        </div>

                        <span class="text-danger text-sm" v-show="
                    errors.has('beneficiaryInfoform.formI94ExpiryDate' +mindex)
                  ">{{
                    errors.first("beneficiaryInfoform.formI94ExpiryDate" +mindex)
                  }}</span>
                    </div>
                    <div class="vx-col md:w-1/3 w-full">
                        <label class="date-picker-label"> Priority Date of I-140</label>

                        <div class="main-placeholder right info-right">
                            <datepicker  :typeable="true"  :use-utc="true"   :format="customFormatter" :name="'i140PrioityDate' +mindex" :open-date="new Date()" data-vv-as="Priority Date" v-model="application.i140PrioityDate" placeholder="MM/DD/YYYY">
                            </datepicker>
                        </div>

                        <span class="text-danger text-sm" v-show="
                    errors.has('beneficiaryInfoform.i140PrioityDate' +mindex)
                  ">{{
                    errors.first("beneficiaryInfoform.i140PrioityDate" +mindex)
                  }}</span>
                    </div>

                    <div class="vx-col md:w-1/3 w-full">

                        <div class="main-placeholder right info-right">
                            <vs-input class="w-full" :name="'formI94CardNumber' +mindex" v-model="application.formI94CardNumber" data-vv-as="Card Number" label="Most Recent Form I-94 Card Number" />
                        </div>
                        <span class="text-danger text-sm" v-show="
                        errors.has(
                          'beneficiaryInfoform.formI94CardNumber' +mindex
                        )
                      ">{{
                        errors.first(
                          "beneficiaryInfoform.formI94CardNumber" +mindex
                        )
                      }}</span>

                    </div>
                </div>

                <div class="vx-row">

                    <div class="vx-col md:w-1/3 w-full">
                        <label class="date-picker-label"> Date From which you have reside in the USA

                        </label>

                        <div class="main-placeholder right info-right">
                            <datepicker  :typeable="true"  :use-utc="true"   :format="customFormatter" :name="'residedFromDateinUs' +mindex" :open-date="new Date()" data-vv-as="Date" v-model="application.residedFromDateinUs" placeholder="MM/DD/YYYY">
                            </datepicker>
                        </div>

                        <span class="text-danger text-sm" v-show="
                    errors.has('beneficiaryInfoform.residedFromDateinUs' +mindex)
                  ">{{
                    errors.first("beneficiaryInfoform.residedFromDateinUs" +mindex)
                  }}</span>
                    </div>

                    <div class="vx-col md:w-1/3 w-full">

                        <div class="main-placeholder right info-right">
                            <vs-input class="w-full" :name="'nonImmVisaNumber' +mindex" v-model="application.nonImmVisaNumber" data-vv-as="Case Number" label="Current Non Immigrant Case Number" />
                        </div>
                        <span class="text-danger text-sm" v-show="
                        errors.has(
                          'beneficiaryInfoform.nonImmVisaNumber' +mindex
                        )
                      ">{{
                        errors.first(
                          "beneficiaryInfoform.nonImmVisaNumber" +mindex
                        )
                      }}</span>

                    </div>

                    <div class="vx-col md:w-1/3 w-full">

                        <div class="con-select w-full select-large">
                            <label class="vs-select--label">Classification</label>
                            <multiselect :name="'classificationCategory' +mindex" v-model="application.classificationCategory" :show-labels="false" track-by="id" label="name" :options-height="20" data-vv-as="Country" placeholder="Select " :options="classificationlist" :searchable="true" :allow-empty="false">
                            </multiselect>
                        </div>

                        <span class="text-danger text-sm" v-show="
                        errors.has(
                          'beneficiaryInfoform.classificationCategory' +
                            mindex
                        )
                      ">{{
                        errors.first(
                          "beneficiaryInfoform.classificationCategory" +
                            mindex
                        )
                      }}</span>

                    </div>
                </div>

            </div>
        </vs-col>

        <vs-col class="m-auto float-none" vs-type="flex" vs-lg="8" vs-sm="12">
            <div class="alert-content-block">
                <p>Were you inspected by any Immigration Officer?
                </p>
                <vs-button class="mr-5" v-bind:class="{
                        cactive:
                          application.areYouInpectedByImmOfficer == 'Yes',
                      }" @click="application.areYouInpectedByImmOfficer = 'Yes'" color="success" type="border">Yes</vs-button>
                <vs-button v-bind:class="{
                        cactive:
                          application.areYouInpectedByImmOfficer == 'No',
                      }" @click="application.areYouInpectedByImmOfficer = 'No'" color="danger" type="border">No</vs-button>
            </div>
        </vs-col>

        <vs-col class="m-auto float-none" vs-type="flex" vs-lg="8" vs-sm="12">
            <div class="alert-content-block">
                <p>Have you ever Been Issued an Employment Authorization document (EAD) from the USCIS?
                </p>
                <vs-button class="mr-5" v-bind:class="{
                        cactive:
                          application.everIssuedEADFromUscis == 'Yes',
                      }" @click="application.everIssuedEADFromUscis = 'Yes'" color="success" type="border">Yes</vs-button>
                <vs-button v-bind:class="{
                        cactive:
                          application.everIssuedEADFromUscis == 'No',
                      }" @click="application.everIssuedEADFromUscis = 'No'" color="danger" type="border">No</vs-button>
            </div>
        </vs-col>

        <vs-col class="m-auto float-none" vs-type="flex" vs-lg="8" vs-sm="12">
            <div class="alert-content-block">
                <p>
                    Did You Enter in US Under Case Waiver Program </p>
                <vs-button class="mr-5" v-bind:class="{
                        cactive:
                          application.enterByVisaWaiverProgram == 'Yes',
                      }" @click="application.enterByVisaWaiverProgram = 'Yes'" color="success" type="border">Yes</vs-button>
                <vs-button v-bind:class="{
                        cactive:
                          application.enterByVisaWaiverProgram == 'No',
                      }" @click="application.enterByVisaWaiverProgram = 'No'" color="danger" type="border">No</vs-button>
            </div>
        </vs-col>

        <vs-col class="m-auto float-none" vs-type="flex" vs-lg="8" vs-sm="12">
            <div class="alert-content-block">
                <p>Do you hold "Permanent Residence" in other country?
                </p>
                <vs-button class="mr-5" v-bind:class="{
                        cactive:
                          application.holdPermResidenceInOtherCountry == 'Yes',
                      }" @click="application.holdPermResidenceInOtherCountry = 'Yes'" color="success" type="border">Yes</vs-button>
                <vs-button v-bind:class="{
                        cactive:
                          application.holdPermResidenceInOtherCountry == 'No',
                      }" @click="application.holdPermResidenceInOtherCountry = 'No'" color="danger" type="border">No</vs-button>
            </div>
        </vs-col>

        <vs-col class="m-auto float-none" v-if="application.holdPermResidenceInOtherCountry == 'Yes'" vs-type="flex" vs-lg="8" vs-sm="12">
            <div class="form-container">

                <div class="vx-col md:w-1/4 w-full">
                    <div class="con-select w-full select-large mart0">
                        <label class="vs-select--label">Country</label>
                        <multiselect :name="'permResidenceInOtherCountry' +mindex" v-model="application.permResidenceInOtherCountry" :show-labels="false" track-by="id" label="name" :options-height="20" data-vv-as="Country" placeholder="Select " :options="countries" :searchable="true" :allow-empty="false">
                        </multiselect>
                    </div>

                    <span class="text-danger text-sm" v-show="
                        errors.has(
                          'beneficiaryInfoform.permResidenceInOtherCountry' +
                            mindex
                        )
                      ">{{
                        errors.first(
                          "beneficiaryInfoform.permResidenceInOtherCountry" +
                            mindex
                        )
                      }}</span>
                </div>

            </div>
        </vs-col>

        <vs-col class="m-auto float-none" vs-type="flex" vs-lg="8" vs-sm="12">
            <div class="alert-content-block">
                <p>
                    Have you ever applied for AOS in the U.S. or an Immigrant Case at an U.S. Embassy/Consulate to obtain permanent resident status before?
                </p>
                <vs-button class="mr-5" v-bind:class="{
                        cactive:
                          application.everApplyPermResidentStatus == 'Yes',
                      }" @click="application.everApplyPermResidentStatus = 'Yes'" color="success" type="border">Yes</vs-button>
                <vs-button v-bind:class="{
                        cactive:
                          application.everApplyPermResidentStatus == 'No',
                      }" @click="application.everApplyPermResidentStatus = 'No'" color="danger" type="border">No</vs-button>
            </div>
        </vs-col>

        <div class="divider"></div>
    </template>
</div>
</template>

<script>
import {
    FormWizard,
    TabContent
} from "vue-form-wizard";
import "vue-form-wizard/dist/vue-form-wizard.min.css";
import Datepicker from "vuejs-datepicker-inv";
import moment from "moment";
import PhoneMaskInput from "vue-phone-mask-input";
import JQuery from "jquery";
import {
    TheMask
} from "vue-the-mask";
import FileUpload from "vue-upload-component/src";
import _ from "lodash";
import Vue from "vue";
import locationFields from "./location.vue";
import citystate from "./citystate.vue";

export default {
    inject: ["parentValidator"],
    props: {
        countries: Array,
        application: Object,
        mindex: Number,
    },
    watch: {
        address: {
            handler(val) {
                this.$emit("compmodel", val);
            },
            deep: true,
        },
    },
    data() {
        return {
            classificationlist: [{
                "id": 10,
                "name": "EB-1"
            }, {
                "id": 11,
                "name": "EB-2"
            }, {
                "id": 12,
                "name": "EB-3"
            }],
            raceslist: [],
            maritallist: [],
            eyecolorslist: [],
            haircolorlist: [],
            nationalitylist: [],
            genders: ["Male", "Female", "Other"],
            startEligibleDate: new Date().setFullYear(new Date().getFullYear() - 18),
            startBeneficiaryDateEntered: new Date().setFullYear(
                new Date().getFullYear() - 7
            ),
        };
    },
    created() {
        this.$validator = this.parentValidator;
    },
    mounted() {
        if (this.application.allCountryIssuedPassports == null) {
            this.application.allCountryIssuedPassports = [];
            this.application.allCountryIssuedPassports.push({
                country: null,
                number: null,
                issuedDate: null,
                expiryDate: null,
            });
        }
        if (this.application.lastEntryPlaceInUs == null || this.application.lastEntryPlaceInUs == '') {
            this.application.lastEntryPlaceInUs = {
                location: {},
                state: {}
            }
        }
    },
    methods: {
        customFormatter(date) {
          return moment.utc(date).startOf('day').format('MM-DD-YYYY');
      },
        addmorenames: function (obj) {
            var name = {
                country: "",
                number: "",
                issuedDate: "",
                expiryDate: "",
            };
            obj.push(name);
        },
        removename: function (index, obj) {
            Vue.delete(obj, index);
        },
    },
    components: {
        FormWizard,
        TabContent,
        Datepicker,
        PhoneMaskInput,
        TheMask,
        FileUpload,
        locationFields,
        citystate
    },
    beforeDestroy() {},
};
</script>
