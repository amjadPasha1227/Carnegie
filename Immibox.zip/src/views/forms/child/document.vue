<template>
<div>
    <file-upload v-model="value" class="file-upload-input" :accept="allDocEntity" :name="'resumeDocument' + mindex" :multiple="true" :hideSelected="true" 
    @input="upload(value)">
        <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
        Upload
    </file-upload>    <ul class="uploaded-list">
        <template v-for="(item, index) in value">
            <vs-chip @click="remove(item, value)" :key="index" closable v-if="item.status !== false  && item.name !== null  && item.url !== null  && item.url !== ''">
                {{ item.name }}
            </vs-chip>
        </template>
    </ul>

</div>
</template>

<script>
import FileUpload from "vue-upload-component/src";
import _ from "lodash";

export default {
    inject: ["parentValidator"],
    props: {
        value: Array,
        mindex: String,
    },
    data() {
        return {
            fileObject:this.value
        };
    },
    created() {
        this.$validator = this.parentValidator;
        this.fileObject = this.fileItem;
    },
    mounted() {

    },
    methods: {
        upload(model) {
            var _current = this;
            this.$vs.loading();
            let formData = new FormData();
            let efiles = [];
            efiles = _.filter(model, (e) => { return (e.url !=null && e.url !='') });
            let nfiles = _.filter(model, (e) => { return (e.url ==null || e.url ==undefined )});

            let mapper = nfiles.map(
                (item) =>
                (item = {
                    name: item.name,
                    file: item.file ? item.file : null,
                    url: item.url ? item.url : "",
                    status: item.status === false || item.status === true ?
                        item.status : true,
                    mimetype: item.type ? item.type : item.mimetype,
                    uploadedBy:this.checkProperty(this.getUserData,'userId'),
                    uploadedByName:this.checkProperty(this.getUserData,'name'),
                    uploadedByRoleId:this.getUserRoleId,
                    uploadedByRoleName:this.checkProperty(this.getUserData,'loginRoleName'),
                })
            );
            if (mapper.length > 0) {
                mapper.forEach((doc, index) => {
                    formData.append("files", doc.file);
                    formData.append("secureType", "private");
                    this.$store.dispatch("uploadS3File", formData).then((response) => {
                        response.data.result.forEach((urlGenerated) => {
                            doc.url = urlGenerated;
                            delete doc.file;
                            mapper[index] = doc;
                        });
                    if (index >= mapper.length - 1) {
                        _current.$vs.loading.close();
                    }
                    });
                
                });
               if(efiles.length > 0) efiles.push(...mapper)
                this.$emit('input', efiles)
              //  model.splice(0, mapper.length, ...mapper);
            }
        },
        remove(item, type) {
            item.status = false;
            type[type.indexOf(item)] = item;
            return false;
        },
    },
    components: {
        FileUpload
    },
    beforeDestroy() {},
};
</script>
