<template>
<div>

    <template>
        <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
            <div class="form-container">
                <h3 class="small-header">Father</h3>
                <div class="vx-row">

                    <div class="vx-col w-full">
                        <parent :countries="countries" :application="application.father" :cid="'applicationfather' + mindex"> </parent>
                    </div>

                </div>
            </div>
        </vs-col>
        <div class="divider"></div>
                <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
            <div class="form-container">
                <h3 class="small-header">Mother</h3>
                <div class="vx-row">

                    <div class="vx-col w-full">
                        <parent :father="false" :countries="countries" :application="application.mother" :cid="'applicationmother' + mindex"> </parent>
                    </div>

                </div>
            </div>
        </vs-col>
    </template>

</div>
</template>

<script>
import {
    FormWizard,
    TabContent
} from "vue-form-wizard";
import "vue-form-wizard/dist/vue-form-wizard.min.css";
import Datepicker from "vuejs-datepicker-inv";
import moment from "moment";
import PhoneMaskInput from "vue-phone-mask-input";
import JQuery from "jquery";
import {
    TheMask
} from "vue-the-mask";
import FileUpload from "vue-upload-component/src";
import _ from "lodash";
import Vue from "vue";
import parent from "./parent.vue";
export default {
    inject: ["parentValidator"],
    props: {
        application: Object,
        mindex: Number,
        countries: Array
    },
    watch: {
        address: {
            handler(val) {

                this.$emit("compmodel", val);

            },
            deep: true
        }

    },
    data() {
        return {
            raceslist: [],
            maritallist: [],
            eyecolorslist: [],
            haircolorlist: [],
            nationalitylist: [],
            genders: ["Male", "Female", "Other"],
            startEligibleDate: new Date().setFullYear(new Date().getFullYear() - 18),
            startBeneficiaryDateEntered: new Date().setFullYear(
                new Date().getFullYear() - 7
            ),
        };
    },
    created() {
        this.$validator = this.parentValidator;
    },
    mounted() {

    },
    methods: {

    },
    components: {
        FormWizard,
        TabContent,
        Datepicker,
        PhoneMaskInput,
        TheMask,
        FileUpload,
        parent,
    },
    beforeDestroy() {},
};
</script>
