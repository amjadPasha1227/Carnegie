


<template>
  <div>
    <vs-col class="m-auto float-none" vs-type="flex" vs-lg="8" vs-sm="12">
      <div class="form-container">
        <div class="vx-row">

            
      <div class="vx-col md:w-1/2 w-full">
                          <label class="date-picker-label">Date of Marriage</label>
                          <div class="main-placeholder right">
                            <datepicker  :typeable="true"
                              :name="'dateofMarriage' + mindex"
                      
                              data-vv-as="Date of Marriage"
                              v-model="application.dateOfBirth"
                              v-validate="'required'"
                              placeholder="MM/DD/YYYY"
                            >
                            </datepicker>

                            <span
                              class="text-danger text-sm"
                              v-show="
                                errors.has(
                                  'beneficiaryInfoform.dateofMarriage' + mindex
                                )
                              "
                              >{{
                                errors.first(
                                  "beneficiaryInfoform.dateofMarriage" + mindex
                                )
                              }}</span
                            >
                          </div>
                        </div>



                          </div>
                        </div>
    </vs-col>
  </div>
</template>