<template>
<div>

    <template>
        <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
            <div class="form-container">
                <h3 class="small-header padb0 marb0">Assets </h3>
                <div class="vx-row">
                    <div class="vx-col w-full mob_assets">

                        <template v-for="(asset,
                assetsindex) in application.assets">
                            <div class="vx-row" :key="assetsindex">
                                <div class="vx-col md:w-1/4 w-full">
                                    <div class="con-select w-full select-large">
                                        <label class="vs-select--label">Type</label>
                                        <multiselect  :name="'assettype' + assetsindex+'_'+mindex" v-model="asset.aType" :show-labels="false" track-by="id" label="name" :options-height="20" data-vv-as="Type" placeholder="Select " :options="assettypes" :searchable="true" :allow-empty="false">
                                        </multiselect>
                                    </div>

                                    <span class="text-danger text-sm" v-show="
                        errors.has(
                          'beneficiaryInfoform.assettype' +
                            assetsindex+'_'+mindex
                        )
                      ">{{
                        errors.first(
                          "beneficiaryInfoform.assettype" +
                            assetsindex+'_'+mindex
                        )
                      }}</span>
                                </div>

                                <div class="vx-col md:w-1/4 w-full">
                                    <div class="main-placeholder right info-right">
                                        <vs-input class="w-full" :name="'nameOfHolder' + assetsindex+'_'+mindex" v-model="asset.nameOfHolder"  data-vv-as="Name" label="Name of the Holder" />
                                    </div>
                                    <span class="text-danger text-sm" v-show="
                        errors.has(
                          'beneficiaryInfoform.nameOfHolder' + assetsindex+'_'+mindex
                        )
                      ">{{
                        errors.first(
                          "beneficiaryInfoform.nameOfHolder" + assetsindex+'_'+mindex
                        )
                      }}</span>
                                </div>

                                <div class="vx-col md:w-1/4 w-full">
                                    <div class="main-placeholder right info-right">
                                        <vs-input class="w-full" v-validate="'numeric'" :name="'amount' + assetsindex+'_'+mindex" v-model="asset.amount" data-vv-as="Amount" label="Amount" />
                                    </div>
                                    <span class="text-danger text-sm" v-show="
                        errors.has(
                          'beneficiaryInfoform.amount' + assetsindex+'_'+mindex
                        )
                      ">{{
                        errors.first(
                          "beneficiaryInfoform.amount" + assetsindex+'_'+mindex
                        )
                      }}</span>
                                </div>
                                <div class="vx-col md:w-1/4 w-full">
                                    <div class="pspdelete delete delete2" v-if="application.assets.length > 1">
                                        <a @click="
                                      removename(
                                        assetsindex,
                                        application.assets
                                      )
                                    ">
                                            <img src="@/assets/images/main/delete-row-img.svg" />
                                        </a>
                                    </div>
                                </div>

                            </div>
                        </template>

                        <div class="vx-row">
                            <div class="vx-col w-full">
                                <a @click="addmorenames(application.assets)" class="add-more ml-0 maxadd" type="filled">
                                    <span>+</span> More
                                </a>
                            </div>
                        </div>

                    </div>
                    <div class="divider"></div>
                    <div class="vx-col w-full">
                        <h3 class="small-header padb0 marb0">Financials</h3>

                        <div class="vx-row">

                            <div class="vx-col md:w-1/4 w-full">
                                <div class="main-placeholder right info-right">
                                    <vs-input class="w-full" v-validate="'numeric'" :name="'depositsInUSBank_'+mindex" v-model="application.depositsInUSBank"  data-vv-as="Deposits" label="Deposits in Bank in the USA" />
                                </div>
                                <span class="text-danger text-sm" v-show="
                        errors.has(
                          'beneficiaryInfoform.depositsInUSBank_'+mindex
                        )
                      ">{{
                        errors.first(
                          'beneficiaryInfoform.depositsInUSBank_'+mindex
                        )
                      }}</span>
                            </div>

                                <div class="vx-col md:w-1/4 w-full">
                                <div class="main-placeholder right info-right">
                                    <vs-input class="w-full" v-validate="'numeric'" :name="'valueOfRealEstate'+mindex" v-model="application.valueOfRealEstate" data-vv-as="Value" label="Value of Real Estate, If Owned" />
                                </div>
                                <span class="text-danger text-sm" v-show="
                        errors.has(
                          'beneficiaryInfoform.valueOfRealEstate'+mindex
                        )
                      ">{{
                        errors.first(
                          'beneficiaryInfoform.valueOfRealEstate'+mindex
                        )
                      }}</span>
                            </div>

                           



                            <div class="vx-col md:w-1/4 w-full">
                                <div class="main-placeholder right info-right">
                                    <vs-input class="w-full" v-validate="'numeric'" :name="'cashSurrenderValueOfLifeInsurance'+mindex" v-model="application.cashSurrenderValueOfLifeInsurance"  data-vv-as="Value" label="Cash Surrender Value of Life Insurance" />
                                </div>
                                <span class="text-danger text-sm" v-show="
                        errors.has(
                          'beneficiaryInfoform.cashSurrenderValueOfLifeInsurance'+mindex
                        )
                      ">{{
                        errors.first(
                          'beneficiaryInfoform.cashSurrenderValueOfLifeInsurance'+mindex
                        )
                      }}</span>
                            </div>

                         <div class="vx-col md:w-1/4 w-full">
                                <div class="main-placeholder right info-right">
                                    <vs-input class="w-full" v-validate="'numeric'" :name="'reasonableValueProperty'+mindex" v-model="application.reasonableValueProperty"  data-vv-as="Value" label="Reasonable Value of Personal Property" />
                                </div>
                                <span class="text-danger text-sm" v-show="
                        errors.has(
                          'beneficiaryInfoform.reasonableValueProperty'+mindex
                        )
                      ">{{
                        errors.first(
                          'beneficiaryInfoform.reasonableValueProperty'+mindex
                        )
                      }}</span>
                            </div>

                            <div class="vx-col md:w-1/3 w-full">
                                <div class="main-placeholder right info-right">
                                    <vs-input class="w-full" v-validate="'numeric'" :name="'marketValueOfStocksBonds'+mindex" v-model="application.marketValueOfStocksBonds"  data-vv-as="Value" label="Market Value of Stocks and Bons" />
                                </div>
                                <span class="text-danger text-sm" v-show="
                        errors.has(
                          'beneficiaryInfoform.marketValueOfStocksBonds'+mindex
                        )
                      ">{{
                        errors.first(
                          'beneficiaryInfoform.marketValueOfStocksBonds'+mindex
                        )
                      }}</span>
                            </div>



    <div class="vx-col md:w-1/3 w-full">
                                <div class="main-placeholder right info-right">
                                    <vs-input class="w-full" v-validate="'numeric'" :name="'sumOfLifeInsurance'+mindex" v-model="application.sumOfLifeInsurance"  data-vv-as="Value" label="Sum of Life Insurance" />
                                </div>
                                <span class="text-danger text-sm" v-show="
                        errors.has(
                          'beneficiaryInfoform.sumOfLifeInsurance'+mindex
                        )
                      ">{{
                        errors.first(
                          'beneficiaryInfoform.sumOfLifeInsurance'+mindex
                        )
                      }}</span>
                            </div>


                            


                             <div class="vx-col md:w-1/3 w-full">
                                <div class="main-placeholder right info-right">
                                    <vs-input class="w-full" v-validate="'numeric'" :name="'healthInsurance'+mindex" v-model="application.healthInsurance.premium"
                                     data-vv-as="Insurance Premium" label="Health Insurance Premium" />
                                </div>
                                <span class="text-danger text-sm" v-show="
                        errors.has(
                          'beneficiaryInfoform.healthInsurance'+mindex
                        )
                      ">{{
                        errors.first(
                          'beneficiaryInfoform.healthInsurance'+mindex
                        )
                      }}</span>
                            </div>


                             <div class="vx-col md:w-1/3 w-full">
                                <div class="main-placeholder right info-right">
                                  
                                             <label class="date-picker-label"> Health Insurance Renewal Date</label>

                        <div class="main-placeholder right info-right">
                            <datepicker  :typeable="true"  :use-utc="true"   :format="customFormatter"  :name="'healthrenewalDate' +mindex" :open-date="new Date()" 
                            data-vv-as="Renewal Date" v-model="application.healthInsurance.renewalDate" 
                             placeholder="MM/DD/YYYY">
                            </datepicker>
                        </div>

                                  
                                       </div>
                                <span class="text-danger text-sm" v-show="
                        errors.has(
                          'beneficiaryInfoform.healthrenewalDate'+mindex
                        )
                      ">{{
                        errors.first(
                          'beneficiaryInfoform.healthrenewalDate'+mindex
                        )
                      }}</span>
                            </div>




                            
                        


                            
                            <div class="vx-col md:w-1/3 w-full">
                                <div class="main-placeholder right info-right">
                                    <vs-input class="w-full" v-validate="'numeric'" :name="'creditScore'+mindex" v-model="application.creditScore"
                                      data-vv-as="Credit Score" label="Credit Score" />
                                </div>
                                <span class="text-danger text-sm" v-show="
                        errors.has(
                          'beneficiaryInfoform.creditScore'+mindex
                        )
                      ">{{
                        errors.first(
                          'beneficiaryInfoform.creditScore'+mindex
                        )
                      }}</span>
                            </div>


                            
                            <div class="vx-col md:w-1/3 w-full">
                                <div class="main-placeholder right info-right">
                                    <vs-input class="w-full" v-validate="'numeric'" :name="'amountOfMortgageOnProperty'+mindex" v-model="application.amountOfMortgageOnProperty" data-vv-as="Value" label="Amount of Mortgage on the Property" />
                                </div>
                                <span class="text-danger text-sm" v-show="
                        errors.has(
                          'beneficiaryInfoform.amountOfMortgageOnProperty'+mindex
                        )
                      ">{{
                        errors.first(
                          'beneficiaryInfoform.amountOfMortgageOnProperty'+mindex
                        )
                      }}</span>
                            </div>


                        </div>

                    </div>

                    <div class="divider"></div>
                    <div class="vx-col w-full">
                        <h3 class="small-header padb0 marb0">Your Liabilities/Debts</h3>

                        <template v-for="(asset,
                assetsindex) in application.liabilitiesDebts">
                            <div class="vx-row" :key="assetsindex">
                                <div class="vx-col md:w-1/3 w-full">
                                    <div class="con-select w-full select-large">
                                        <label class="vs-select--label">Type</label>
                                        <multiselect  :name="'libassettype' + assetsindex+'_'+mindex" v-model="asset.lType" :show-labels="false" track-by="id" label="name" :options-height="20" data-vv-as="Type" placeholder="Select " :options="liabilitiesdebtslist" :searchable="true" :allow-empty="false">
                                        </multiselect>
                                    </div>

                                    <span class="text-danger text-sm" v-show="
                        errors.has(
                          'beneficiaryInfoform.liassettype' +
                            assetsindex+'_'+mindex
                        )
                      ">{{
                        errors.first(
                          "beneficiaryInfoform.liassettype" +
                            assetsindex+'_'+mindex
                        )
                      }}</span>
                                </div>

                                <div class="vx-col md:w-1/4 w-full">
                                    <div class="main-placeholder right info-right">
                                        <vs-input class="w-full" v-validate="'numeric'" :name="'liamount' + assetsindex+'_'+mindex" v-model="asset.amount"  data-vv-as="Amount" label="Amount" />
                                    </div>
                                    <span class="text-danger text-sm" v-show="
                        errors.has(
                          'beneficiaryInfoform.liamount' + assetsindex+'_'+mindex
                        )
                      ">{{
                        errors.first(
                          "beneficiaryInfoform.liamount" + assetsindex+'_'+mindex
                        )
                      }}</span>
                                </div>
                                <div class="vx-col md:w-1/4 w-full">
                                    <div class="pspdelete delete delete2" v-if="application.liabilitiesDebts.length > 1">
                                        <a @click="
                                          removename(
                                            assetsindex,
                                            application.liabilitiesDebts
                                          )
                                        ">
                                            <img src="@/assets/images/main/delete-row-img.svg" />
                                        </a>
                                    </div>
                                </div>

                            </div>
                        </template>

                        <div class="vx-row">
                            <div class="vx-col w-full">
                                <a @click="addmorenameslib(application.liabilitiesDebts)" class="add-more ml-0 maxadd" type="filled">
                                    <span>+</span> More
                                </a>
                            </div>
                        </div>

                    </div>

                    <div class="divider"></div>
                    <div class="vx-col w-full">

                        <h3 class="small-header">Public Benefits</h3>

                        <div class="">
                            <ul class="checklist">
                                <li v-for="(publicbenefit,
                        pbindex) in publicbenefitslist" :key="pbindex">
                                    <vs-checkbox :vs-value="publicbenefit.id" v-model="application.publicBenefits">{{publicbenefit.name}}</vs-checkbox>
                                </li>
                            </ul>
                        </div>
                    </div>

                </div>
            </div>
        </vs-col>
        <!-- <div class="divider"></div> -->
    </template>

</div>
</template>

<script>
import {
    FormWizard,
    TabContent
} from "vue-form-wizard";
import "vue-form-wizard/dist/vue-form-wizard.min.css";
import Datepicker from "vuejs-datepicker-inv";
import moment from "moment";
import PhoneMaskInput from "vue-phone-mask-input";
import JQuery from "jquery";
import {
    TheMask
} from "vue-the-mask";
import FileUpload from "vue-upload-component/src";
import _ from "lodash";
import Vue from "vue";
import locationFields from "./location.vue";
export default {
    inject: ["parentValidator"],
    props: {
        application: Object,
        mindex: Number
    },
    watch: {
        address: {
            handler(val) {

                this.$emit("compmodel", val);

            },
            deep: true
        }

    },
    data() {
        return {
            raceslist: [],
            assettypes: [],
            liabilitiesdebtslist: [],
            publicbenefitslist: [],
            startEligibleDate: new Date().setFullYear(new Date().getFullYear() - 18),
            startBeneficiaryDateEntered: new Date().setFullYear(
                new Date().getFullYear() - 7
            ),
        };
    },
    created() {
        this.$validator = this.parentValidator;
    },
    mounted() {

        this.getDefaultMasterdata();

        if(this.application.healthInsurance == '' || this.application.healthInsurance == null){

          this.application.healthInsurance = {
            premium:'',
            renewalDate:''
          }
        }

    },
    methods: {
        customFormatter(date) {
          return moment.utc(date).startOf('day').format('MM-DD-YYYY');
      },
        addmorenames: function (obj) {
            var name = {
                aType: "",
                nameOfHolder: "",
                amount: "",
            };
            obj.push(name);
        },
        addmorenameslib: function (obj) {
            var name = {
                lType: "",
                amount: "",
            };
            obj.push(name);
        },
        removename: function (index, obj) {
            Vue.delete(obj, index);
        },
        getDefaultMasterdata() {

            this.$store
                .dispatch("getmasterdata", "public_benefits")
                .then(response => {
                    this.publicbenefitslist = response;
                });

            this.$store
                .dispatch("getmasterdata", "asset_types")
                .then(response => {
                    this.assettypes = response;
                });

            this.$store
                .dispatch("getmasterdata", "liabilities_debts")
                .then(response => {
                    this.liabilitiesdebtslist = response;
                });

            //assettypes
        }

    },
    components: {
        FormWizard,
        TabContent,
        Datepicker,
        PhoneMaskInput,
        TheMask,
        FileUpload,
        locationFields,
    },
    beforeDestroy() {},
};
</script>
