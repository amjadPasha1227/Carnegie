<template>
<div>
    <div>
        <vs-col class="w-full p-0">
            <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal" icon="IP-information-button" active="true">
                <p>Documents Needed</p>
                <ul class="uploaded-list">
                    <li>
                        ENLARGED COLOR COPY of Passports issued to all applicants including
                        all the case stamps and I-94 (all pages including blank pages).
                        Please make sure that the photo(s) and biographic information are
                        clearly visible.
                    </li>
                    <li>
                        The birth certificates should have your name and you parents’ names,
                        date and place of birth mentioned. Also, the date of registration of
                        birth should be around the time of birth. If one of these two is not
                        available, we require affidavits from two family members stating the
                        facts of birth. (format shall be provided if needed).
                    </li>
                    <li>
                        Four (4) Photographs of each applicant.
                        * NOTE: Eight (8) photographs will be need if applying for employment authorization and advance parole.
                    </li>
                </ul>
            </vs-alert>
        </vs-col>
    </div>
    <template>

        <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
            <div class="form-container w-full documents_wrap">


                <div class="vx-row">
                    <div class="vx-col w-full">
                        <label class="custom-label">Copies of birth certificates issued to all applicants </label>
                        <document v-model="application.birthCertificate" :mindex="'birthCertificate'+mindex"    />
                    </div>
                    <div class="divider"></div>
                </div>
                <!--passport-->
                <div class="vx-row">
                    <div class="vx-col w-full">
                        <label class="custom-label">Passport, along with Case and Form I-94 (clearly showing the dates of
                            first and last entry into the United States)</label>
                      
                       <document v-model="application.passport" :mindex="'passport'+mindex"    />

                    </div>
                    <div class="divider"></div>
                </div>
                <!-- END PASSPORT-->

                <!--I140ApprovalNotice-->
                <div class="vx-row">
                    <div class="vx-col w-full">
                        <label class="custom-label">Copy of I-140 Approval Notice</label>
                      
                  <document v-model="application.I140ApprovalNotice" :mindex="'I140ApprovalNotice'+mindex"    />

                    </div>
                    <div class="divider"></div>
                </div>
                <!-- END I140ApprovalNotice-->

                <!--underlyingLaborCertification-->
                <div class="vx-row">
                    <div class="vx-col w-full">
                        <label class="custom-label">Copy of the underlying Labor Certification (PERM) if applicable</label>
                      
                                        <document v-model="application.underlyingLaborCertification" :mindex="'underlyingLaborCertification'+mindex"    />


                    </div>
                    <div class="divider"></div>
                </div>
                <!-- END underlyingLaborCertification-->

                <!--photo-->
                <div class="vx-row">
                    <div class="vx-col w-full">
                        <label class="custom-label">Four (4) Photographs of each applicant. * NOTE: Eight (8) photographs will be need if applying for employment authorization and advance parole. </label>
                      
                      
                  <document v-model="application.photo" :mindex="'photo'+mindex"    />

                      
                     
                    </div>
                    <div class="divider"></div>
                </div>
                <!-- END photo-->

                <!--medicalExaminations-->
                <div class="vx-row">
                    <div class="vx-col w-full">
                        <label class="custom-label">Medical Examinations need to be done in the U.S. where applying for adjustment of status.</label>
                      
                      
                                        <document v-model="application.medicalExaminations" :mindex="'medicalExaminations'+mindex"    />

                      
                      
                    </div>
                    <div class="divider"></div>
                </div>
                <!-- END medicalExaminations-->

                <!--formI134-->
                <div class="vx-row">
                    <div class="vx-col w-full">
                        <label class="custom-label">Form I-134 (Affidavit of Support) needed for dependent(s) of principal applicant where principal applicant has an employment based Form I-140.</label>
                     <document v-model="application.formI134" :mindex="'formI134'+mindex"    />

                      
           
                    </div>
                    <div class="divider"></div>
                </div>
                <!-- END formI134-->

                <!--itReturns-->
                <div class="vx-row">
                    <div class="vx-col w-full">
                        <label class="custom-label">Copy of U. S. Income Tax Returns for the most recent tax year, where an Affidavit of Support in Form I-134 is to be submitted for dependent(s). </label>
                     
                                          <document v-model="application.itReturns" :mindex="'itReturns'+mindex"    />

                     
                      
                    </div>
                    <div class="divider"></div>
                </div>
                <!-- END itReturns-->

                <!--w2-->
                <div class="vx-row">
                    <div class="vx-col w-full">
                        <label class="custom-label">Copy of your form W-2 for the most recent tax year, as well as copies of recent pay stubs for most recent 6 months, if any</label>
                     
                   <document v-model="application.w2" :mindex="'w2'+mindex"    />

                     
                       
                    </div>
                    <div class="divider"></div>
                </div>
                <!-- END w2-->

                <!--bankStatement-->
                <div class="vx-row">
                    <div class="vx-col w-full">
                        <label class="custom-label">Bank Statements</label>
                    
                    
                                       <document v-model="application.bankStatement" :mindex="'bankStatement'+mindex"    />


                  
                    </div>
                    <div class="divider"></div>
                </div>
                <!-- END bankStatement-->

                <!--continuedValidStatus-->
                <div class="vx-row">
                    <div class="vx-col w-full">
                        <label class="custom-label">Evidence of continued valid status during the entire period of stay in the United States for the principal applicant, as well as for the dependent(s), regardless of any employment authorization document received. This involves copies of all cases, notices of approval, Form I-20s (e.g. H1B, H-4, L1B, B1, F1, F2) for continued permitted status, and Forms I-94. Copies of all EAD (front and back) are also required, if any. </label>
                    
         <document v-model="application.continuedValidStatus" :mindex="'continuedValidStatus'+mindex"    />

                    
                     
                    </div>
                    <div class="divider"></div>
                </div>
                <!-- END continuedValidStatus-->

                <!--evidenceOfFilingPetition-->
                <div class="vx-row">
                    <div class="vx-col w-full">
                        <label class="custom-label">Evidence of filing a petition on or before April 30, 2001 in cases where protection under Sec.245 (i) is to be sought.
                        </label>
                    
                    
         <document v-model="application.evidenceOfFilingPetition" :mindex="'evidenceOfFilingPetition'+mindex"    />

                    
                    </div>
                    <div class="divider"></div>
                </div>
                <!-- END evidenceOfFilingPetition-->

                <!--otherIncomeAssetProof-->
                <div class="vx-row">
                    <div class="vx-col w-full">
                        <label class="custom-label">Other proof of your income/asset</label>
                    
                             <document v-model="application.otherIncomeAssetProof" :mindex="'otherIncomeAssetProof'+mindex"    />

                    
                  
                    </div>
                    <div class="divider"></div>
                </div>
                <!-- END otherIncomeAssetProof-->

                <!--medicalInsuranceProof-->
                <div class="vx-row">
                    <div class="vx-col w-full">
                        <label class="custom-label">Proof of Medical Insurance</label>
                 
                 
                <document v-model="application.medicalInsuranceProof" :mindex="'medicalInsuranceProof'+mindex"    />

                 
                      
                    </div>
                    <div class="divider"></div>
                </div>
                <!-- END medicalInsuranceProof-->

                <!--creditReport-->
                <div class="vx-row">
                    <div class="vx-col w-full">
                        <label class="custom-label">Credit Report generated within the last 12 months prior to the date of filing</label>
               
                          <document v-model="application.creditReport" :mindex="'creditReport'+mindex"    />
     
               
                    </div>
                    <div class="divider"></div>
                </div>
                <!-- END creditReport-->

                <!--permResidentStatusDocs-->
                <div class="vx-row">
                    <div class="vx-col w-full">
                        <label class="custom-label">Permanent Residence</label>
                  
 <document v-model="application.permResidentStatusDocs" :mindex="'permResidentStatusDocs'+mindex"    />
      
                  
                  
                    </div>
                    <div class="divider"></div>
                </div>
                <!-- END permResidentStatusDocs-->

                <!--empAuthFrontbackDocs-->
                <div class="vx-row">
                    <div class="vx-col w-full">
                        <label class="custom-label">
                            Employment Authorization Document </label>
              
              
              
               <document v-model="application.empAuthFrontbackDocs" :mindex="'empAuthFrontbackDocs'+mindex"    />

              
                    </div>
                    <div class="divider"></div>
                </div>
                <!-- END empAuthFrontbackDocs-->

                <!--other-->
                <div class="vx-row">
                    <div class="vx-col w-full">
                        <label class="custom-label">Any Other Documents</label>
             
                         <document v-model="application.other" :mindex="'other'+mindex"    />
   
             
             
                      
                    </div>

                </div>
                <!-- END other-->

            </div>

        </vs-col>
    </template>
</div>
</template>

<script>
import document from './document'
import moment from "moment";
import FileUpload from "vue-upload-component/src";
import _ from "lodash";
export default {
    inject: ["parentValidator"],
    props: {
        application: Object,
        mindex: Number,
    },
    watch: {
        address: {
            handler(val) {
                this.$emit("compmodel", val);
            },
            deep: true,
        },
    },
    data() {
        return {
            raceslist: [],
            maritallist: [],
            eyecolorslist: [],
            haircolorlist: [],
            nationalitylist: [],
            genders: ["Male", "Female", "Other"],
            startEligibleDate: new Date().setFullYear(new Date().getFullYear() - 18),
            startBeneficiaryDateEntered: new Date().setFullYear(
                new Date().getFullYear() - 7
            ),
        };
    },
    created() {
        this.$validator = this.parentValidator;
    },
    mounted() {

    },
    methods: {
        upload(model) {
            let formData = new FormData();
            let mapper = model.map(
                (item) =>
                (item = {
                    name: item.name,
                    file: item.file ? item.file : null,
                    url: item.url ? item.url : "",
                    status: item.status === false || item.status === true ?
                        item.status : true,
                    mimetype: item.type ? item.type : item.mimetype,
                    uploadedBy:this.checkProperty(this.getUserData,'userId'),
                    uploadedByName:this.checkProperty(this.getUserData,'name'),
                    uploadedByRoleId:this.getUserRoleId,
                    uploadedByRoleName:this.checkProperty(this.getUserData,'loginRoleName'),
                })
            );
            if (mapper.length > 0) {
                mapper.forEach((doc, index) => {
                    formData.append("files", doc.file);
                    formData.append("secureType", "private");
                    this.$store.dispatch("uploadS3File", formData).then((response) => {
                        response.data.result.forEach((urlGenerated) => {
                            doc.url = urlGenerated;
                            delete doc.file;
                            mapper[index] = doc;
                        });
                    });
                });
                model.splice(0, mapper.length, ...mapper);
            }
        },
        remove(item, type) {
            item.status = false;
            type[type.indexOf(item)] = item;
            return false;
        },
    },
    components: {
        FileUpload,
        document
    },
    beforeDestroy() {},
};
</script>
