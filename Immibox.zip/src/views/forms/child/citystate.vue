<template>
<div>
    <div class="form-container" v-if="states && states.length > 0 ">
        <div class="vx-row">

            <div class="vx-col w-full" v-bind:class="{ 'md:w-1/2': !placeOnly, 'md:w-1/2': placeOnly }">
                <div class="con-select w-full select-large">
                    <label v-if="placeOnly" class="vs-select--label">{{placeOnlyTitle}}</label>
                    <multiselect :name="'state' + cid" 
                      v-model="laddress.state"
                       :disabled="states.length == 0
              " :show-labels="false" track-by="id" label="name" data-vv-as="State"
               placeholder="Select State" :options="states" :searchable="true" :allow-empty="false" @select="selectedState($event)">
                               <span slot="noResult" >No Sate Found</span>

                    </multiselect>
                </div>

                <span class="text-danger text-sm" v-show="errors.has('beneficiaryInfoform.state' + cid)">{{ errors.first("beneficiaryInfoform.state" + cid) }}</span>
            </div>
            <div class="vx-col w-full" v-bind:class="{ 'md:w-1/2': !placeOnly, 'md:w-1/2': placeOnly }">
                <div class="con-select w-full select-large addselect">
                    <label v-if="!placeOnly" class="vs-select--label">City</label>
                    <label v-if="placeOnly" class="vs-select--label">&nbsp;</label>

                    <multiselect  :name="'location' + cid" v-model="laddress.location" :disabled="
                !laddress.state ||
                laddress.state.id == undefined ||
                locations.length == 0" :show-labels="false" 
                     tag-placeholder="Add"
                  :taggable="true"
             @tag="addLocation"
                
                track-by="id" label="name" data-vv-as="City" placeholder="Select City" :options="locations" :searchable="true" :allow-empty="false">
                           <span slot="noResult" >No Locations Found</span>

                    </multiselect>
                </div>

                <span class="text-danger text-sm" v-show="errors.has('beneficiaryInfoform.location' + cid)">{{ errors.first("beneficiaryInfoform.location" + cid) }}</span>
            </div>

        </div>
    </div>
</div>
</template>

<script>
import _ from "lodash";
export default {
    inject: ["parentValidator"],
    props: {
        countries: Array,
        address: Object,
        cid: {
            type: String,
            default: "",
        },
        placeOnly: {
            type: Boolean,
            default: false,
        },
        placeOnlyTitle: String
    },
    data() {
        return {
            states: [],
            locations: [],
            laddress: {
                state: '',
                location: '',
            }
        };
    },
    created() {
        this.$validator = this.parentValidator;
    },
    mounted() {
     if(this.address !=null && this.address !=''){
       this.laddress = this.address
    }else{

    }
  
        this.$store
            .dispatch("getstates", 231)
            .then((response) => {
                this.states = response;
            });

        if (this.laddress.state && this.laddress.state.id) {

            this.$store
                .dispatch("getlocations", {
                    countryId: 231,
                    stateId: this.laddress.state.id,
                })
                .then((response) => {
                    this.locations = response;
                });

        }

    },
    methods: {
        selectedState(selected) {
            this.locations = [];

            this.$store
                .dispatch("getlocations", {
                    countryId: 231,
                    stateId: selected.id,
                })
                .then((response) => {
                    this.locations = response;
                });
        },
    },
    beforeDestroy() {},
};
</script>
