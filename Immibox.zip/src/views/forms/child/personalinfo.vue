<template>
<div>
    <vs-col v-if="mindex == 1" class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
        <div class="form-container">
            <div class="vx-row">
                <div class="vx-col w-full">
                    <vs-col class="m-auto padt20 float-none pad0" vs-type="flex" vs-lg="12" vs-sm="12">
                        <div class="alert-content-block">
                            <p>
                                Adjustment of status to Permanent Residency (Form I-485) required for your Spouse?
                            </p>
                            <vs-button class="mr-5" v-bind:class="{
                        cactive: application.applicationRequired == true,
                      }" @click="application.applicationRequired = true " color="success" type="border">Yes</vs-button>
                            <vs-button v-bind:class="{
                        cactive: application.applicationRequired == false,
                      }" @click="application.applicationRequired  = false" color="danger" type="border">No</vs-button>
                        </div>
                    </vs-col>
                </div>
            </div>
        </div>
    </vs-col>

    <vs-col v-if="mindex > 1" class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
        <div class="form-container">
            <div class="vx-row">
                <div class="vx-col w-full">

                    <vs-col class="m-auto padt20 float-none pad0" vs-type="flex" vs-lg="12" vs-sm="12">
                        <div class="alert-content-block">
                            <p>
                                Adjustment of status to Permanent Residency (Form I-485) required for your Child?
                            </p>
                            <vs-button class="mr-5" v-bind:class="{
                        cactive: application.applicationRequired == true,
                      }" @click="application.applicationRequired = true " color="success" type="border">Yes</vs-button>
                            <vs-button v-bind:class="{
                        cactive: application.applicationRequired == false,
                      }" @click="application.applicationRequired  = false" color="danger" type="border">No</vs-button>
                        </div>
                    </vs-col>
                </div>
            </div>
        </div>
    </vs-col>
    <template>
        <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
            <div class="form-container">
                <div class="vx-row">
                    <div class="vx-col w-full">
                        <vx-input-group class="form-input-group">
                            <vs-input :name="'firstname' + mindex" v-model="application.firstName" v-validate="'required'" class="w-full" data-vv-as="First Name" label="First Name" />

                            <vs-input class="w-full" :name="'middleName' + mindex" v-model="application.middleName" data-vv-as="Middle Name" label="Middle Name" />

                            <vs-input class="w-full" :name="'lastName' + mindex" v-model="application.lastName" v-validate="'required'" data-vv-as="Last Name" label="Last Name" />
                        </vx-input-group>
                        <div class="input-group-error">
                            <p class="w-1/3">
                                <span class="text-danger text-sm" v-show="
                                  errors.has(
                                    'beneficiaryInfoform.firstname' + mindex
                                  )
                                ">{{
                                  errors.first(
                                    "beneficiaryInfoform.firstname" + mindex
                                  )
                                }}</span>
                            </p>
                            <p class="w-1/3"></p>
                            <p class="w-1/3">
                                <span class="text-danger text-sm" v-show="
                                  errors.has(
                                    'beneficiaryInfoform.lastName' + mindex
                                  )
                                ">{{
                                  errors.first(
                                    "beneficiaryInfoform.lastName" + mindex
                                  )
                                }}</span>
                            </p>
                        </div>
                    </div>
                    <div class="vx-col md:w-1/3 w-full">
                        <vs-input v-if="mindex > 1" :name="'email' + mindex" v-model="application.email"  class="w-full" data-vv-as="Email" label="Email" />
                        <vs-input v-if="mindex <= 1" :name="'email' + mindex" v-model="application.email" v-validate="'required|email'" class="w-full" data-vv-as="Email" label="Email" />

                        <span class="text-danger text-sm" v-show="
                              errors.has('beneficiaryInfoform.email' + mindex)
                            ">{{
                              errors.first("beneficiaryInfoform.email" + mindex)
                            }}</span>
                    </div>

                    <div class="vx-col md:w-1/3 w-full">
                        <div class="con-select w-full select-large">
                            <label class="vs-select--label">Gender</label>
                            <multiselect v-validate="'required'" :name="'gender'+mindex" v-model="application.gender" :show-labels="false" data-vv-as="Gender" placeholder="Select" :options="genders" :searchable="false" :allow-empty="false">
                            </multiselect>
                        </div>

                        <span class="text-danger text-sm" v-show="
                              errors.has(
                                'beneficiaryInfoform.gender' + mindex
                              )
                            ">{{
                              errors.first(
                                "beneficiaryInfoform.gender" + mindex
                              )
                            }}</span>

                    </div>
                    <div class="vx-col md:w-1/3 w-full">
                        <label class="date-picker-label">Date of Birth</label>
                        <div class="main-placeholder right right_calendar">
                            <datepicker  :typeable="true"  :use-utc="false"   :format="customFormatter"  :name="'dateOfBirth' + mindex" 
                                :open-date="application.dateOfBirth?application.dateOfBirth:new Date()" :disabled-dates="{from: new Date()}"
                                data-vv-as="Date of Birth" v-model="application.dateOfBirth" v-validate="'required'" placeholder="MM/DD/YYYY">
                            </datepicker>

                            <span class="text-danger text-sm" v-show="
                                errors.has(
                                  'beneficiaryInfoform.dateOfBirth' + mindex
                                )
                              ">{{
                                errors.first(
                                  "beneficiaryInfoform.dateOfBirth" + mindex
                                )
                              }}</span>
                        </div>
                    </div>
                                       <div class="vx-col w-full">
                    <!-- {{application.placeOfBirth}} -->
                        <locationFields v-if="countries && countries.length > 0" :countries="countries" :address="application.placeOfBirth" :placeOnly="true" :placeOnlyTitle="'Place of Birth'" :cid="'placeofbirth'+mindex" />

                    </div>
                    <div v-if="mindex == 0" class="vx-col md:w-1/3 w-full">

                        <div class="con-select w-full select-large">
                            <label class="vs-select--label">Marital Status</label>
                            <multiselect v-validate="'required'" :name="'maritalStatus'+mindex" v-model="application.maritalStatus" :show-labels="false" data-vv-as="Marital Status" placeholder="Select" :options="maritallist" track-by="id" @select="maritalStatusChange($event,mindex)" label="name" :searchable="false" :allow-empty="false">
                            </multiselect>
                        </div>

                        <span class="text-danger text-sm" v-show="
                              errors.has(
                                'beneficiaryInfoform.maritalStatus' + mindex
                              )
                            ">{{
                              errors.first(
                                "beneficiaryInfoform.maritalStatus" + mindex
                              )
                            }}</span>
                    </div>
                    <div v-show="application.maritalStatus && application.maritalStatus.id == 2" class="vx-col md:w-1/3 w-full">
                        <vs-input :name="'childrencount' + mindex" v-model="childrenCount" v-validate="'max_value:4'" class="w-full" data-vv-as="Children Count" label="How many children do you have?" />

                        <span class="text-danger text-sm" v-show="
                              errors.has('beneficiaryInfoform.childrencount' + mindex)
                            ">{{
                              errors.first("beneficiaryInfoform.childrencount" + mindex)
                            }}</span>
                    </div>

                    <template v-if="application.maritalStatus && application.maritalStatus.id == 2">

                        <div class="vx-col md:w-1/3 w-full">
                            <label class="date-picker-label">Date of Marriage</label>
                            <div class="main-placeholder right">
                                <datepicker  :typeable="true"  :use-utc="true" :format="customFormatter" 
                                 :name="'dateOfMarriage' + mindex" data-vv-as="Date of Marriage" 
                                 v-model="application.dateOfMarriage"  placeholder="MM/DD/YYYY">
                                </datepicker>

                                <span class="text-danger text-sm" v-show="
                                errors.has(
                                  'beneficiaryInfoform.dateofMarriage' + mindex
                                )
                              ">{{
                                errors.first(
                                  "beneficiaryInfoform.dateofMarriage" + mindex
                                )
                              }}</span>
                            </div>
                        </div>

                        <div class="vx-col w-full">
                            <locationFields v-if="countries && countries.length > 0" :countries="countries" :address="application.placeOfMarriage" :placeOnlyTitle="'Place of Marriage'" :placeOnly="true" :cid="'placeOfMarriage'+mindex" />
                        </div>

                        <vs-col class="m-auto padt20 float-none" vs-type="flex" vs-lg="12" vs-sm="12">
                            <div class="alert-content-block">
                                <p>
                                    Do you have a Marriage Certificate?
                                </p>
                                <vs-button class="mr-5" v-bind:class="{
                        cactive: application.haveMarriageCertificate == 'Yes',
                      }" @click="application.haveMarriageCertificate = 'Yes'" color="success" type="border">Yes</vs-button>
                                <vs-button v-bind:class="{
                        cactive: application.haveMarriageCertificate == 'No',
                      }" @click="application.haveMarriageCertificate = 'No'" color="danger" type="border">No</vs-button>
                            </div>
                        </vs-col>

                        <vs-col class="m-auto padt20 float-none" v-if="application.haveMarriageCertificate == 'No'" vs-type="flex" vs-lg="8" vs-sm="12">
                            <div class="alert-content-block">
                                <p>
                                    Do you have Two (2) Affidavits attesting to the Marriage?

                                </p>
                                <vs-button class="mr-5" v-bind:class="{
                        cactive:
                          application.have2AffidavitsAttestingToMarriage == 'Yes',
                      }" @click="application.have2AffidavitsAttestingToMarriage = 'Yes'" color="success" type="border">Yes</vs-button>
                                <vs-button v-bind:class="{
                        cactive:
                          application.have2AffidavitsAttestingToMarriage == 'No',
                      }" @click="application.have2AffidavitsAttestingToMarriage = 'No'" color="danger" type="border">No</vs-button>
                            </div>
                        </vs-col>

                    </template>

                </div>
            </div>
        </vs-col>
        <div class="divider"></div>
    </template>

    <template v-if="application.applicationRequired">

        <template>
            <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
                <div class="form-container">
                    All other names you have used including maiden name and
                    last names from previous marriages

                    <div class="vx-row" v-for="(allOtherNamesUsed,
                        anindex) in application.allOtherNamesUsed" :key="anindex">
                        <div class="vx-col w-full">
                            <vx-input-group class="form-input-group">
                                <vs-input :name="'anfirstname' + anindex" v-model="allOtherNamesUsed.firstName" class="w-full" data-vv-as="First Name" label="First Name" />

                                <vs-input class="w-full" name="middleName" v-model="allOtherNamesUsed.middleName" data-vv-as="Middle Name" label="Middle Name" />

                                <vs-input class="w-full" :name="'anlastName' + anindex" v-model="allOtherNamesUsed.lastName" data-vv-as="Last Name" label="Last Name" />

                                <div class="namedelete delete" v-if="application.allOtherNamesUsed.length > 1">
                                    <a @click="
                                  removename(
                                    anindex,
                                    application.allOtherNamesUsed
                                  )
                                ">
                                        <img src="@/assets/images/main/delete-row-img.svg" />
                                    </a>
                                </div>
                            </vx-input-group>
                            <div class="input-group-error">
                                <p class="w-1/3">
                                    <span class="text-danger text-sm" v-show="
                                  errors.has(
                                    'beneficiaryInfoform.anfirstname' + anindex
                                  )
                                ">{{
                                  errors.first(
                                    "beneficiaryInfoform.anfirstname" + anindex
                                  )
                                }}</span>
                                </p>
                                <p class="w-1/3"></p>
                                <p class="w-1/3">
                                    <span class="text-danger text-sm" v-show="
                                  errors.has(
                                    'beneficiaryInfoform.anlastName' + anindex
                                  )
                                ">{{
                                  errors.first(
                                    "beneficiaryInfoform.anlastName" + anindex
                                  )
                                }}</span>
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="vx-row">
                        <div class="vx-col w-full">
                            <a @click="addmorenames(application.allOtherNamesUsed)" class="add-more ml-0 maxadd" type="filled">
                                <span>+</span> More
                            </a>
                        </div>
                    </div>
                </div>
            </vs-col>
            <div class="divider"></div>
        </template>

        <template>
            <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
                <div class="form-container">
                    <div class="vx-row">
                        <div class="vx-col md:w-1/2 w-full mart0-label">
                            <vs-input v-mask="'(###)-###-####'" v-model="application.dayTimePhoneNumber" :name="'cellPhoneNumber' + mindex" v-validate="'phonevalid'" data-vv-as="Daytime Telephone Number" placeholder="(XXX)-XXX-XXXX" wrapperClass="vs-con-input" class="w-full" inputClass="vs-inputx vs-input--input normal" label="Daytime Telephone Number" />

                            <span class="text-danger text-sm" v-show="
                              errors.has(
                                'beneficiaryInfoform.cellPhoneNumber' + mindex
                              )
                            ">{{
                              errors.first(
                                "beneficiaryInfoform.cellPhoneNumber" + mindex
                              )
                            }}</span>
                        </div>
                        <div class="vx-col md:w-1/2 w-full mart0-label">
                            <vs-input v-mask="'(###)-###-####'" :name="'homePhoneNumber' + mindex" v-model="application.phoneNumber" v-validate="'phonevalid'" data-vv-as="Mobile Telephone Number" placeholder="(XXX)-XXX-XXXX" wrapperClass="vs-con-input" class="w-full" inputClass="vs-inputx vs-input--input normal" label="Mobile Telephone Number" />

                            <span class="text-danger text-sm" v-show="
                              errors.has(
                                'beneficiaryInfoform.homePhoneNumber' + mindex
                              )
                            ">{{
                              errors.first(
                                "beneficiaryInfoform.homePhoneNumber" + mindex
                              )
                            }}</span>
                        </div>
                    </div>
                </div>
            </vs-col>
            <div class="divider"></div>
        </template>

        <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
            <div class="form-container">
                <div class="vx-row">
                    <div class="vx-col md:w-1/2 w-full mart0-label">
                        <div class="main-placeholder right info-right">
                            <div class="vs-component vs-con-input-label vs-input w-full ssnnumber vs-input-primary">
                                <label class="vs-input--label">Social Security number (if
                                    applicable)</label>
                                <div class="vs-con-input">
                                    <the-mask v-validate="'min:9|max:9'" :name="'ssn' + mindex" data-vv-as="Social Security number (if applicable)" v-model="application.SSN" placeholder="123 - 45 - 6789" class="vs-inputx vs-input--input normal" :mask="['### - ## - ####']" />
                                </div>
                            </div>
                        </div>
                        <span class="text-danger text-sm" v-show="
                            errors.has('beneficiaryInfoform.ssn' + mindex)
                          ">{{
                            errors.first("beneficiaryInfoform.ssn" + mindex)
                          }}</span>
                    </div>

                    <div class="vx-col md:w-1/2 w-full mart0-label">
                        <div class="main-placeholder right info-right">
                            <vs-input class="w-full" :name="'alienNumber' + mindex" v-model="application.alienNumber" data-vv-as="Your Alien Number" label="Your Alien Number (if applicable)" />
                        </div>
                        <span class="text-danger text-sm" v-show="
                            errors.has(
                              'beneficiaryInfoform.alienNumber' + mindex
                            )
                          ">{{
                            errors.first(
                              "beneficiaryInfoform.alienNumber" + mindex
                            )
                          }}</span>
                    </div>
                </div>
            </div>
        </vs-col>

        <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
            <div class="form-container">
                <div class="vx-row">
                    <div class="vx-col md:w-1/2 w-full">
                        <div class="main-placeholder right info-right">
                            <vs-input class="w-full" :name="'passportNumber' + mindex" v-model="application.passportNumber" v-validate="'max:12'" data-vv-as="Passport Number" label="Passport Number" />
                        </div>
                        <span class="text-danger text-sm" v-show="
                            errors.has(
                              'beneficiaryInfoform.passportNumber' + mindex
                            )
                          ">{{
                            errors.first(
                              "beneficiaryInfoform.passportNumber" + mindex
                            )
                          }}</span>
                    </div>

                    <div class="vx-col md:w-1/2 w-full">
                        <label class="date-picker-label">Passport Expiration Date</label>
                        <div class="main-placeholder right">
                            <datepicker  :typeable="true"  :use-utc="true" :format="customFormatter"  :name="'passportExpiryDate' + mindex" :open-date="application.passportExpiryDate?application.passportExpiryDate:new Date()" data-vv-as="Passport Expiration Date" v-model="application.passportExpiryDate"  placeholder="MM/DD/YYYY">
                            </datepicker>

                            <span class="text-danger text-sm" v-show="
                              errors.has(
                                'beneficiaryInfoform.passportExpiryDate' +
                                  mindex
                              )
                            ">{{
                              errors.first(
                                "beneficiaryInfoform.passportExpiryDate" +
                                  mindex
                              )
                            }}</span>
                        </div>
                    </div>
                </div>
            </div>
        </vs-col>

        <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
            <div class="form-container">
                <div class="vx-row">

 

                    <div class="vx-col md:w-1/3 w-full">
                        <div class="con-select w-full select-large">
                            <label class="vs-select--label">Nationality</label>
                            <multiselect :name="'nationality'+mindex" v-model="application.nationality" :show-labels="false" data-vv-as="Nationality" placeholder="Select" track-by="id" label="name" :options="nationalitylist" :searchable="false" :allow-empty="false">
                            </multiselect>
                        </div>

                        <span class="text-danger text-sm" v-show="
                              errors.has(
                                'beneficiaryInfoform.nationality' + mindex
                              )
                            ">{{
                              errors.first(
                                "beneficiaryInfoform.nationality" + mindex
                              )
                            }}</span>

                    </div>

                    <div class="vx-col md:w-1/3 w-full">
                        <div class="main-placeholder right info-right">
                            <div class="vx-row" style="padding: 0 1rem;">

                                <vs-input class="w-1/2" :name="'heightfeet' + mindex" v-model="application.height.feet"   v-validate="'max_value:21'" data-vv-as="Feet" placeholder="Feet" label="Height" />
                                <vs-input class="w-1/2" :name="'heightinches' + mindex" v-model="application.height.inches"  v-validate="'max_value:11'" data-vv-as="Inches" placeholder="Inches" label='-' />
                            </div>
                        </div>
                        <span class="text-danger text-sm" v-show="
                            errors.has(
                              'beneficiaryInfoform.heightfeet' + mindex
                            )
                          ">{{
                            errors.first(
                              "beneficiaryInfoform.heightfeet" + mindex
                            )
                          }}</span>
                            <span class="text-danger text-sm" v-show="
                            errors.has(
                              'beneficiaryInfoform.heightinches' + mindex
                            )
                          ">{{
                            errors.first(
                              "beneficiaryInfoform.heightinches" + mindex
                            )
                          }}</span>
                    </div>

                    <div class="vx-col md:w-1/3 w-full">
                        <div class="main-placeholder right info-right">
                            <vs-input class="w-full" :name="'weight' + mindex" v-model="application.weight" v-validate="'max_value:500'"  data-vv-as="Weight" label="Weight" />
                        </div>
                        <span class="text-danger text-sm" v-show="
                            errors.has(
                              'beneficiaryInfoform.weight' + mindex
                            )
                          ">{{
                            errors.first(
                              "beneficiaryInfoform.weight" + mindex
                            )
                          }}</span>
                    </div>

                    <div class="vx-col md:w-1/3 w-full">
                        <div class="con-select w-full select-large">
                            <label class="vs-select--label">Race</label>
                            <multiselect :name="'race'+mindex" v-model="application.race" :show-labels="false" data-vv-as="Race" placeholder="Select" track-by="id" label="name" :options="raceslist" :searchable="false" :allow-empty="false">
                            </multiselect>
                        </div>

                        <span class="text-danger text-sm" v-show="
                              errors.has(
                                'beneficiaryInfoform.race' + mindex
                              )
                            ">{{
                              errors.first(
                                "beneficiaryInfoform.race" + mindex
                              )
                            }}</span>

                    </div>

                    <div class="vx-col md:w-1/3 w-full">
                        <div class="con-select w-full select-large">
                            <label class="vs-select--label">Hair Color</label>
                            <multiselect :name="'haircolor'+mindex" v-model="application.hairColor" :show-labels="false" data-vv-as="Haircolor" placeholder="Select" track-by="id" label="name" :options="haircolorlist" :searchable="false" :allow-empty="false">
                            </multiselect>
                        </div>

                        <span class="text-danger text-sm" v-show="
                              errors.has(
                                'beneficiaryInfoform.haircolor' + mindex
                              )
                            ">{{
                              errors.first(
                                "beneficiaryInfoform.haircolor" + mindex
                              )
                            }}</span>

                    </div>

                    <div class="vx-col md:w-1/3 w-full">
                        <div class="con-select w-full select-large">
                            <label class="vs-select--label">Eye Color</label>
                            <multiselect :name="'eyeColor'+mindex" v-model="application.eyeColor" :show-labels="false" data-vv-as="Eye Color" placeholder="Select" track-by="id" label="name" :options="eyecolorslist" :searchable="false" :allow-empty="false">
                            </multiselect>
                        </div>

                        <span class="text-danger text-sm" v-show="
                              errors.has(
                                'beneficiaryInfoform.eyeColor' + mindex
                              )
                            ">{{
                              errors.first(
                                "beneficiaryInfoform.eyeColor" + mindex
                              )
                            }}</span>

                    </div>

                </div>
            </div>
        </vs-col>

        <vs-col class="m-auto padt20 float-none" vs-type="flex" vs-lg="8" vs-sm="12">
            <div class="alert-content-block">
                <p>
                    if your name is different from that stated on your birth
                    certificate, have you had it legally changes?
                </p>
                <vs-button class="mr-5" v-bind:class="{
                        cactive: application.birthCertHaveNamePobDob == 'Yes',
                      }" @click="application.birthCertHaveNamePobDob = 'Yes'" color="success" type="border">Yes</vs-button>
                <vs-button v-bind:class="{
                        cactive: application.birthCertHaveNamePobDob == 'No',
                      }" @click="application.birthCertHaveNamePobDob = 'No'" color="danger" type="border">No</vs-button>
            </div>
        </vs-col>

        <vs-col class="m-auto padt20 float-none" v-if="application.birthCertHaveNamePobDob == 'No'" vs-type="flex" vs-lg="8" vs-sm="12">
            <div class="alert-content-block">
                <p>
                    Do you have Two (2) Affidavits of Birth from family
                    members?
                </p>
                <vs-button class="mr-5" v-bind:class="{
                        cactive:
                          application.have2AffidavitsOfBirthFamily == 'Yes',
                      }" @click="application.have2AffidavitsOfBirthFamily = 'Yes'" color="success" type="border">Yes</vs-button>
                <vs-button v-bind:class="{
                        cactive:
                          application.have2AffidavitsOfBirthFamily == 'No',
                      }" @click="application.have2AffidavitsOfBirthFamily = 'No'" color="danger" type="border">No</vs-button>
            </div>
        </vs-col>

        <vs-col class="m-auto padt20 float-none" v-if="application.maritalStatus && application.maritalStatus.id >= 2 " vs-type="flex" vs-lg="8" vs-sm="12">
            <div class="alert-content-block">
                <p>Were you married previously?
                </p>
                <vs-button class="mr-5" v-bind:class="{
                        cactive:
                          application.previouslyMarried == 'Yes',
                      }" @click="application.previouslyMarried = 'Yes'" color="success" type="border">Yes</vs-button>
                <vs-button v-bind:class="{
                        cactive:
                          application.previouslyMarried == 'No',
                      }" @click="application.previouslyMarried = 'No'" color="danger" type="border">No</vs-button>
            </div>
        </vs-col>

        <vs-col class=" float-none mart0 m-lrauto" v-if="application.previouslyMarried == 'Yes'" vs-type="flex" vs-lg="8" vs-sm="12">
            <div class="form-container">
                <div class="vx-row">

                    <template>

                        <div class="vx-col w-full">
                            <h3 class="small-header" style="margin:20px 0px 0px;padding:0px;">Previous Spouse</h3>

                            <vx-input-group class="form-input-group">
                                <vs-input :name="'prevSpousefirstname' + mindex" v-model="application.prevSpouse.firstName" v-validate="'required'" class="w-full" data-vv-as="First Name" label="First Name" />

                                <vs-input class="w-full" :name="'prevSpousemiddleName' + mindex" v-model="application.prevSpouse.middleName" data-vv-as="Middle Name" label="Middle Name" />

                                <vs-input class="w-full" :name="'prevSpouselastName' + mindex" v-model="application.prevSpouse.lastName" v-validate="'required'" data-vv-as="Last Name" label="Last Name" />
                            </vx-input-group>
                            <div class="input-group-error">
                                <p class="w-1/3">
                                    <span class="text-danger text-sm" v-show="
                                  errors.has(
                                    'beneficiaryInfoform.prevSpousefirstname' + mindex
                                  )
                                ">{{
                                  errors.first(
                                    "beneficiaryInfoform.prevSpousefirstname" + mindex
                                  )
                                }}</span>
                                </p>
                                <p class="w-1/3"></p>
                                <p class="w-1/3">
                                    <span class="text-danger text-sm" v-show="
                                  errors.has(
                                    'beneficiaryInfoform.prevSpouselastName' + mindex
                                  )
                                ">{{
                                  errors.first(
                                    "beneficiaryInfoform.prevSpouselastName" + mindex
                                  )
                                }}</span>
                                </p>
                            </div>

                        </div>

                          <div class="vx-col md:w-1/3 w-full">
                        <label class="date-picker-label">Date of Birth</label>
                        <div class="main-placeholder right right_calendar">
                          
                            <datepicker  :typeable="true"  :use-utc="true" :format="customFormatter"  :name="'applicationprevSpousedateOfBirth' + mindex" :open-date="application.prevSpouse.dateOfBirth?application.prevSpouse.dateOfBirth:new Date()" :disabled-dates="{
                                from: new Date(),
                              }" data-vv-as="Date of Birth" v-model="application.prevSpouse.dateOfBirth" v-validate="'required'" placeholder="MM/DD/YYYY">
                            </datepicker>

                            <span class="text-danger text-sm" v-show="
                                errors.has(
                                  'beneficiaryInfoform.applicationprevSpousedateOfBirth' + mindex
                                )
                              ">{{
                                errors.first(
                                  "beneficiaryInfoform.applicationprevSpousedateOfBirth" + mindex
                                )
                              }}</span>
                        </div>
                    </div>
                      <div class="vx-col md:w-1/3 w-full">
                        <label class="date-picker-label">Date of Marriage</label>
                        <div class="main-placeholder right right_calendar">
                            <datepicker  :typeable="true"  :use-utc="true" :format="customFormatter"  :name="'applicationprevSpousedateOfMarriage' + mindex" :open-date="application.prevSpouse.dateOfMarriage?application.prevSpouse.dateOfMarriage:new Date()" :disabled-dates="{
                                from: new Date(),
                              }" data-vv-as="Date of Marriage" v-model="application.prevSpouse.dateOfMarriage" v-validate="'required'" placeholder="MM/DD/YYYY">
                            </datepicker>

                            <span class="text-danger text-sm" v-show="
                                errors.has(
                                  'beneficiaryInfoform.applicationprevSpousedateOfMarriage' + mindex
                                )
                              ">{{
                                errors.first(
                                  "beneficiaryInfoform.applicationprevSpousedateOfMarriage" + mindex
                                )
                              }}</span>
                        </div>
                    </div>
                      <div class="vx-col md:w-1/3 w-full">
                        <label class="date-picker-label">Date of Marriage Ended</label>
                        <div class="main-placeholder right right_calendar">
                            <datepicker  :typeable="true"  :use-utc="true" :format="customFormatter"  :name="'applicationprevSpousedateOfMarriageEnded' + mindex" :open-date="application.prevSpouse.dateOfMarriageEnded?application.prevSpouse.dateOfMarriageEnded:new Date()" :disabled-dates="{
                                from: new Date(),
                              }" data-vv-as="Date" v-model="application.prevSpouse.dateOfMarriageEnded"  placeholder="MM/DD/YYYY">
                            </datepicker>

                            <span class="text-danger text-sm" v-show="
                                errors.has(
                                  'beneficiaryInfoform.applicationprevSpousedateOfMarriageEnded' + mindex
                                )
                              ">{{
                                errors.first(
                                  "beneficiaryInfoform.applicationprevSpousedateOfMarriageEnded" + mindex
                                )
                              }}</span>
                        </div>
                    </div>

                    

                        <div class="vx-col w-full">

                            <locationFields v-if="countries && countries.length > 0 " :countries="countries" :address="application.prevSpouse.placeOfMarriage" :placeOnlyTitle="'Place of Marriage'" :placeOnly="true" :cid="'prevSpouseplaceOfMarriage'+mindex" />
                        </div>

                        <div class="vx-col w-full">

                            <locationFields v-if="countries && countries.length > 0 " :countries="countries" :address="application.prevSpouse.placeOfTermination" :placeOnlyTitle="'Place of Termination'" :placeOnly="true" :cid="'prevSpouseplaceOfTermination'+mindex" />
                        </div>

                    </template>

                </div>

            </div>

        </vs-col>

        <vs-col class="m-auto padt20 float-none" v-if="application.previouslyMarried == 'Yes'" vs-type="flex" vs-lg="8" vs-sm="12">
            <div class="alert-content-block">
                <p>Did you obtain U.S Permanent Residence Through Spouse?
                </p>
                <vs-button class="mr-5" v-bind:class="{
                        cactive:
                          application.obtainPermResidenceThroughSpouse == 'Yes',
                      }" @click="application.obtainPermResidenceThroughSpouse = 'Yes'" color="success" type="border">Yes</vs-button>
                <vs-button v-bind:class="{
                        cactive:
                          application.obtainPermResidenceThroughSpouse == 'No',
                      }" @click="application.obtainPermResidenceThroughSpouse = 'No'" color="danger" type="border">No</vs-button>
            </div>
        </vs-col>

    </template>

</div>
</template>

<script>
import {
    FormWizard,
    TabContent
} from "vue-form-wizard";
import "vue-form-wizard/dist/vue-form-wizard.min.css";
import Datepicker from "vuejs-datepicker-inv";
import moment from "moment";
import PhoneMaskInput from "vue-phone-mask-input";
import JQuery from "jquery";
import {
    TheMask
} from "vue-the-mask";
import FileUpload from "vue-upload-component/src";
import _ from "lodash";
import Vue from "vue";
import locationFields from "./location.vue";
export default {
    inject: ["parentValidator"],
    props: {
        application: Object,
        mindex: Number,
        countries: {
            type: Array,
            default: []
        }
    },
    watch: {
        'childrenCount': {
            handler(val, oldvalue) {
                if (val != oldvalue) {
                    this.application.childrenCount = val;
                    this.$emit("chiltabs", val);

                }

            }
        },
        address: {
            handler(val) {

                this.$emit("compmodel", val);

            },
            deep: true
        }

    },
    data() {
        return {

            raceslist: [],
            maritallist: [],
            eyecolorslist: [],
            haircolorlist: [],
            nationalitylist: [],
            childrenCount: this.application.childrenCount?this.application.childrenCount:null,
            genders: ["Male", "Female", "Other"],
            startEligibleDate: new Date().setFullYear(new Date().getFullYear() - 18),
            startBeneficiaryDateEntered: new Date().setFullYear(
                new Date().getFullYear() - 7
            ),
        };
    },
    created() {
        this.$validator = this.parentValidator;
    },
    mounted() {

        this.getDefaultMasterdata();

        if(this.application.placeOfMarriage == '' || this.application.placeOfMarriage == null ){
         
            this.application.placeOfMarriage = {
              country:null
            }
        }
        
        if(this.application.placeOfBirth == '' || this.application.placeOfBirth == null ){
            this.application.placeOfBirth = {
              country:null
            }
        }



    },
    methods: {
       customFormatter(date) {
          return moment(date).startOf('day').format('MM-DD-YYYY');
      },
        maritalStatusChange($event, index) {

            this.$emit("maritalStatusChange", $event, index);

        },
        addmorenames: function (obj) {
            var name = {
                firstName: "",
                middleName: "",
                lastName: "",
            };
            obj.push(name);
        },
        removename: function (index, obj) {
            Vue.delete(obj, index);
        },
        getDefaultMasterdata() {

            this.$store
                .dispatch("getmasterdata", "marital_status")
                .then(response => {
                    this.maritallist = response;
                });
            this.$store
                .dispatch("getmasterdata", "races")
                .then(response => {
                    this.raceslist = response;
                });
            this.$store
                .dispatch("getmasterdata", "hair_colors")
                .then(response => {
                    this.haircolorlist = response;
                });

            this.$store
                .dispatch("getmasterdata", "eye_colors")
                .then(response => {
                    this.eyecolorslist = response;
                });

            this.$store
                .dispatch("getmasterdata", "nationality")
                .then(response => {
                    this.nationalitylist = response;
                });

        }
    },
    components: {
        FormWizard,
        TabContent,
        Datepicker,
        PhoneMaskInput,
        TheMask,
        FileUpload,
        locationFields,
    },
    beforeDestroy() {},
};
</script>
