<template>
<div>
    <template>
        <vs-col class="m-auto float-none m-pad0" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
            <div class="form-container ">
                <div class="vx-row">
                    <div class="vx-col w-full pad0">
                        <vx-input-group class="form-input-group">
                            <vs-input :name="'firstname' + cid" v-model="application.firstName"  class="w-full" data-vv-as="First Name" label="First Name" />

                            <vs-input class="w-full" :name="'middleName' + cid" v-model="application.middleName" data-vv-as="Middle Name" label="Middle Name" />

                            <vs-input class="w-full" :name="'lastName' + cid" v-model="application.lastName"  data-vv-as="Last Name" label="Last Name" />

                            
                        </vx-input-group>
                        <div class="input-group-error">
                            <p class="w-1/3">
                                <span class="text-danger text-sm" v-show="errors.has('beneficiaryInfoform.firstname' + cid)">{{
                      errors.first("beneficiaryInfoform.firstname" + cid)
                    }}</span>
                            </p>
                            <p class="w-1/3"></p>
                            <p class="w-1/3">
                                <span class="text-danger text-sm" v-show="errors.has('beneficiaryInfoform.lastName' + cid)">{{
                      errors.first("beneficiaryInfoform.lastName" + cid)
                    }}</span>
                            </p>
                        </div>
                    </div>

                    
                </div>
            </div>
        </vs-col>
        <div class="divider"></div>
    </template>

    <template>
        <template>
            <vs-col class="m-auto float-none pad0" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
                <div class="form-container">
                    Name at Birth (if different from above)

                    <div class="vx-row">
                        <div class="vx-col w-full ">
                            <vx-input-group class="form-input-group">
                                <vs-input :name="'birthFirstName' + cid" v-model="application.birthFirstName" class="w-full" data-vv-as="First Name" label="First Name" />

                                <vs-input class="w-full" :name="'birthMiddleName' + cid" v-model="application.birthMiddleName" data-vv-as="Middle Name" label="Middle Name" />

                                <vs-input class="w-full" :name="'birthLastName' + cid" v-model="application.birthLastName" data-vv-as="Last Name" label="Last Name" />
                                
                            </vx-input-group>
                            <div class="input-group-error">
                                <p class="w-1/3">
                                    <span class="text-danger text-sm" v-show="
                        errors.has('beneficiaryInfoform.birthFirstName' + cid)
                      ">{{
                        errors.first("beneficiaryInfoform.birthFirstName" + cid)
                      }}</span>
                                </p>
                                <p class="w-1/3"></p>
                                <p class="w-1/3">
                                    <span class="text-danger text-sm" v-show="
                        errors.has('beneficiaryInfoform.birthLastName' + cid)
                      ">{{
                        errors.first("beneficiaryInfoform.birthLastName" + cid)
                      }}</span>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </vs-col>
            <div class="divider"></div>
        </template>

        <vs-col class="m-auto float-none pad0" v-if="countries && countries.length > 0" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="8" vs-sm="12">
            <div class="form-container">
                <div class="vx-row">
                    <div class="vx-col w-full palceofbirth">
                        <locationFields 
                        v-if="countries && countries.length > 0"
                         :countries="countries"
                         :address="application.placeOfBirth" :placeOnly="true" 
                         :placeOnlyTitle="'Place of Birth'" 
                        :cid="'placeofbirth' + cid" />
                    </div>

                    <div class="vx-col w-full">
                        <locationFields   v-if="countries && countries.length > 0" :countries="countries" :address="application.currentResidence" :placeOnly="true" :placeOnlyTitle="'Current Residence'" :cid="'currentResidence' + cid" />
                    </div>
                </div>
            </div>
        </vs-col>

        <vs-col class="pad0">
            <vs-row>
            <div class="vx-col md:w-1/3 w-full">
                        <label class="date-picker-label">Date of Birth</label>
                        <div class="main-placeholder right">
                            <datepicker  :typeable="true"  :use-utc="true"   :format="customFormatter" :name="'dateOfBirth' + mindex" :open-date="new Date(startEligibleDate)" :disabled-dates="{
                    from: new Date(startEligibleDate),
                  }" data-vv-as="Date of Birth" v-model="application.dateOfBirth"  placeholder="MM/DD/YYYY">
                            </datepicker>

                            <span class="text-danger text-sm" v-show="errors.has('beneficiaryInfoform.dateOfBirth' + cid)">{{
                    errors.first("beneficiaryInfoform.dateOfBirth" + cid)
                  }}</span>
                        </div>
            </div>
            </vs-row>
        </vs-col>

        <vs-col class="m-auto pt-6 float-none pad0" vs-type="flex" vs-lg="8" vs-sm="12">
            <div class="width50">
                <div class="alert-content-block marb0">
                <p v-if="father">Is Your Father now or was he ever A U.S Citizen?</p>
                <p v-if="!father">Is Your Mother now or was she ever A U.S Citizen?</p>

                <vs-button class="mr-5" v-bind:class="{
              cactive: application.everUSCitizen == 'Yes',
            }" @click="application.everUSCitizen = 'Yes'" color="success" type="border">Yes</vs-button>
                <vs-button v-bind:class="{
              cactive: application.everUSCitizen == 'No',
            }" @click="application.everUSCitizen = 'No'" color="danger" type="border">No</vs-button>
            </div>
            </div>
            <div class="width50">
                <div class="m-auto  float-none pad0" v-if="application.everUSCitizen == 'Yes'" vs-type="flex" vs-lg="8" vs-sm="12">
                    <div  >
                        <label class="date-picker-label mart0 marb0" v-if="father">From When Your Father now or was he ever A U.S Citizen </label>
                        <label class="date-picker-label mart0 marb0" v-if="!father">From When Your Mother now or was he ever A U.S Citizen </label>

                        <div class="main-placeholder right">
                            <datepicker  :typeable="true"  :use-utc="true"   :format="customFormatter" class="marb0" :name="'usCitizenSince' + cid" :open-date="new Date()" :disabled-dates="{
                        from: new Date(),
                    }" data-vv-as="Date of Birth" v-model="application.usCitizenSince"  placeholder="MM/DD/YYYY">
                            </datepicker>

                            <span class="text-danger text-sm" v-show="errors.has('beneficiaryInfoform.usCitizenSince' + cid)">{{
                        errors.first("beneficiaryInfoform.usCitizenSince" + cid)
                    }}</span>
                        </div>
                    </div>
                </div>
            </div>


            
        </vs-col>

        
    </template>
</div>
</template>

<script>
import {
    FormWizard,
    TabContent
} from "vue-form-wizard";
import "vue-form-wizard/dist/vue-form-wizard.min.css";
import Datepicker from "vuejs-datepicker-inv";
import moment from "moment";
import PhoneMaskInput from "vue-phone-mask-input";
import JQuery from "jquery";
import {
    TheMask
} from "vue-the-mask";
import FileUpload from "vue-upload-component/src";
import _ from "lodash";
import Vue from "vue";
import locationFields from "./location.vue";
export default {
    inject: ["parentValidator"],
    props: {
        application: Object,
        mindex: Number,
        countries:Array,
        cid:String,
        father: {
            type: Boolean,
            default: true
        }
    },
    watch: {
        address: {
            handler(val) {
                this.$emit("compmodel", val);
            },
            deep: true,
        },
    },
    data() {
        return {
            raceslist: [],
            maritallist: [],
            eyecolorslist: [],
            haircolorlist: [],
            nationalitylist: [],
            genders: ["Male", "Female", "Other"],
            startEligibleDate: new Date().setFullYear(new Date().getFullYear() - 18),
            startBeneficiaryDateEntered: new Date().setFullYear(
                new Date().getFullYear() - 7
            ),
        };
    },
    created() {
        this.$validator = this.parentValidator;
    },
    mounted() {
            
            
        

        
        //this.getDefaultMasterdata();
    },
    methods: {
              customFormatter(date) {
          return moment.utc(date).startOf('day').format('MM-DD-YYYY');
      },
        maritalStatusChange($event, index) {
            this.$emit("maritalStatusChange", $event, index);
        },
        addmorenames: function (obj) {
            var name = {
                firstName: "",
                middleName: "",
                lastName: "",
            };
            obj.push(name);
        },
        removename: function (index, obj) {
            Vue.delete(obj, index);
        }
    },
    components: {
        FormWizard,
        TabContent,
        Datepicker,
        PhoneMaskInput,
        TheMask,
        FileUpload,
        locationFields,
    },
    beforeDestroy() {},
};
</script>
