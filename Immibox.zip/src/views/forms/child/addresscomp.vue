<template>
  <div>
    <template>
      <vs-col
        class="m-auto float-none"
        vs-type="flex"
        vs-justify="center"
        vs-align="center"
        vs-lg="8"
        vs-sm="12"
      >
        <div class="form-container address_form">
          <h3 class="small-header">Current US Home Address</h3>
          <div class="vx-row">
            <div class="vx-col w-full">
              <locationFields
               :countries="countries"
                :address="application.address"
                :cid="'randaddress' + mindex"
              />
            </div>
          </div>

          <h3 class="small-header">
            Current Mailing Address
            <span>(if different from the home address)</span>
          </h3>
          <div class="vx-row">
            <div class="vx-col w-full">
              <vs-checkbox @click="setSameaddress()" v-model="application.mailingAddressIsSameAsAddress"
                >Same as Current US Home Address</vs-checkbox
              >
                
              <locationFields
                :countries="countries"
                ref="newchildref"
                :address="application.mailingAddress"
                :cid="'mailingAddress' + mindex"
              />
            </div>
          </div>
        </div>
      </vs-col>
      <div class="divider"></div>
    </template>

    <template>
      <vs-col
        class="m-auto float-none"
        vs-type="flex"
        vs-justify="center"
        vs-align="center"
        vs-lg="8"
        vs-sm="12"
      >
        <div class="form-container address_form">
          <h3 class="small-header">
            Last Address outside Of the United States for more than one year
          </h3>
          <div class="vx-row">
            <div class="vx-col w-full">
              <locationFields
                :countries="countries"
                :address="application.lastAddressOutsideUS"
                :cid="'lastAddressOutsideUS' + mindex"
              />
            </div>

            <div class="vx-col md:w-1/3 w-full">
              <label class="date-picker-label">From Date</label>
              <div class="main-placeholder right">
                <datepicker  :typeable="true"  :use-utc="true"   :format="customFormatter" 
                  :name="'application.lastAddressOutsideUS.fromDate' + mindex"
                  :open-date="new Date()"
                  data-vv-as="From Date"
                  v-model="application.lastAddressOutsideUS.fromDate"
                  placeholder="MM/DD/YYYY"
                >
                </datepicker>

                <span
                  class="text-danger text-sm"
                  v-show="
                    errors.has(
                      'beneficiaryInfoform.lastAddressOutsideUS.fromDate' + mindex
                    )
                  "
                  >{{
                    errors.first(
                      "beneficiaryInfoform.lastAddressOutsideUS.fromDate" + mindex
                    )
                  }}</span
                >
              </div>
            </div>

            <div class="vx-col md:w-1/3 w-full">
              <label class="date-picker-label">To Date</label>
              <div class="main-placeholder right">
                <datepicker  :typeable="true"  :use-utc="true"   :format="customFormatter" 
                  :name="'application.lastAddressOutsideUS.toDate' + mindex"
                  :open-date="new Date()"
                  data-vv-as="To Date"
                  v-model="application.lastAddressOutsideUS.toDate"
                  placeholder="MM/DD/YYYY"
                >
                </datepicker>

                <span
                  class="text-danger text-sm"
                  v-show="
                    errors.has(
                      'beneficiaryInfoform.lastAddressOutsideUS.toDate' + mindex
                    )
                  "
                  >{{
                    errors.first(
                      "beneficiaryInfoform.lastAddressOutsideUS.toDate" + mindex
                    )
                  }}</span
                >
              </div>
            </div>
          </div>
          <div class="divider divider2"></div>
          <h3 class="small-header">
            Your Residence starting with most current for the Past Five Years in
            the U.S and Aboard
          </h3>
          <div
            class="vx-row"
            v-for="(addressm, addindex) in application.residenceAddressUSAbroad"
            :key="addindex"
          >
            <div class="vx-col w-full">
              <div class="divider" v-if="addindex > 0"></div>

              <div
                class="addressdelete delete"
                v-if="application.residenceAddressUSAbroad.length > 1"
              >
                <a
                  @click="
                    removename(addindex, application.residenceAddressUSAbroad)
                  "
                >
                  <img src="@/assets/images/main/delete-row-img.svg" />
                </a>
              </div>

              <locationFields
                :countries="countries"
                :address="addressm"
                :cid="'residenceAddressUSAbroad' + mindex + addindex"
              />
            </div>

            <div class="vx-col md:w-1/3 w-full">
              <label class="date-picker-label">From Date</label>
              <div class="main-placeholder right">
                <datepicker  :typeable="true"  :use-utc="true"   :format="customFormatter" 
                  :name="'addressmfdate' + addindex"
                  :open-date="new Date()"
                  data-vv-as="From Date"
                  v-model="addressm.fromDate"
                  placeholder="MM/DD/YYYY"
                >
                </datepicker>

                <span
                  class="text-danger text-sm"
                  v-show="errors.has('beneficiaryInfoform.addressmfdate' + addindex)"
                  >{{ errors.first("beneficiaryInfoform.addressmfdate" + addindex) }}</span
                >
              </div>
            </div>

            <div class="vx-col md:w-1/3 w-full" v-if="addindex!=0" >
              <label class="date-picker-label">To Date</label>
              <div class="main-placeholder right">
                <datepicker  :typeable="true"  :use-utc="true"   :format="customFormatter" 
                  :name="'addressmtdate' + addindex"
                  :open-date="new Date()"
                  data-vv-as="To Date"
                  v-model="addressm.toDate"
                  placeholder="MM/DD/YYYY"
                >
                </datepicker>

                <span
                  class="text-danger text-sm"
                  v-show="errors.has('beneficiaryInfoform.addressmtdate' + addindex)"
                  >{{ errors.first("beneficiaryInfoform.addressmtdate" + addindex) }}</span
                >
              </div>
            </div>
          </div>

          <div class="vx-row">
            <div class="vx-col w-full">
              <a
                @click="addmoreaddresss(application.residenceAddressUSAbroad)"
                class="add-more ml-0 maxadd"
                type="filled"
              >
                <span>+</span> More
              </a>
            </div>
          </div>
        </div>
      </vs-col>
      <div class="divider"></div>
    </template>
  </div>
</template>

<script>
import { FormWizard, TabContent } from "vue-form-wizard";
import "vue-form-wizard/dist/vue-form-wizard.min.css";
import Datepicker from "vuejs-datepicker-inv";
import moment from "moment";
import PhoneMaskInput from "vue-phone-mask-input";
import JQuery from "jquery";
import { TheMask } from "vue-the-mask";
import FileUpload from "vue-upload-component/src";
import _ from "lodash";
import Vue from "vue";
import locationFields from "./location.vue";
export default {
  inject: ["parentValidator"],
  props: {
    application: Object,
    mindex: Number,
    countries:Array
  },
  watch: {
    address: {
      handler(val) {
        this.$emit("compmodel", val);
      },
      deep: true,
    },
  },
  data() {
    return {
      raceslist: [],
      maritallist: [],
      eyecolorslist: [],
      haircolorlist: [],
      nationalitylist: [],
      genders: ["Male", "Female", "Other"],
      startEligibleDate: new Date().setFullYear(new Date().getFullYear() - 18),
      startBeneficiaryDateEntered: new Date().setFullYear(
        new Date().getFullYear() - 7
      ),
    };
  },
  created() {
    this.$validator = this.parentValidator;
  },
  mounted() {},
  methods: {
     customFormatter(date) {
          return moment.utc(date).startOf('day').format('MM-DD-YYYY');
      },
    addmoreaddresss: function (obj) {
      var name = {
        line1: null,
        line2: null,
        location: null,
        state: null,
        country: null,
        zipcode: null,
        fromDate: null,
        toDate: null,
      };
      obj.push(name);
    },
    removename: function (index, obj) {
      Vue.delete(obj, index);
    },
    setSameaddress() {
      if (this.application.address.line1 != null) {
        this.$refs.newchildref.updateaddress(this.application.address);
      }
    },
  },
  components: {
    FormWizard,
    TabContent,
    Datepicker,
    PhoneMaskInput,
    TheMask,
    FileUpload,
    locationFields,
  },
  beforeDestroy() {},
};
</script>
