<template>
  <div>
    <div class="form-container"  v-if="countries  && countries.length > 0" >
      <div class="vx-row">
        <div
          class="vx-col "
          v-if="!placeOnly"
          v-bind:class="{ 'md:w-1/3 w-full': !placeOnly, 'md:w-1/3 w-full': placeOnly }"
        >
          <vs-input
            :name="'line1' + cid"
            v-model="laddress.line1"
            class="w-full"
            data-vv-as="Street Address"
            label="Street Address"
          />

          <span
            class="text-danger text-sm"
            v-show="errors.has('beneficiaryInfoform.line1' + cid)"
            >{{ errors.first("beneficiaryInfoform.line1" + cid) }}</span
          >
        </div>

        <div
          v-if="!placeOnly"
          class="vx-col"
          v-bind:class="{ 'md:w-1/3 w-full': !placeOnly, 'md:w-1/3 w-full': placeOnly }"
        >
          <vs-input
            :name="'line2' + cid"
            v-model="laddress.line2"
            class="w-full"
            data-vv-as="Apt, Suite"
            label="Apt, Suite"
          />

          <span
            class="text-danger text-sm"
            v-show="errors.has('beneficiaryInfoform.line2' + cid)"
            >{{ errors.first("beneficiaryInfoform.line2" + cid) }}</span
          >
        </div>

        <div
          class="vx-col"
          v-bind:class="{ 'md:w-1/3  w-full': !placeOnly, 'md:w-1/3  w-full': placeOnly }"
        >
          <div class="con-select select-large">
            <label v-if="!placeOnly" class="vs-select--label">Country</label>
            <label v-if="placeOnly" class="vs-select--label"
              >{{placeOnlyTitle}}</label
            >
            <multiselect
              :name="'country' + cid"
              v-model="laddress.country"
              :show-labels="false"
              track-by="id"
              label="name"
              :ref="'refcountry' + cid"
              data-vv-as="Country"
              placeholder="Select Country"
              :options="countries"
              :searchable="true"
              :allow-empty="false"
              @select="selectedCountry($event)"
            >
                        <span slot="noResult" >No Country Found</span>

            </multiselect>
          </div>

          <span
            class="text-danger text-sm"
            v-show="errors.has('beneficiaryInfoform.country' + cid)"
            >{{ errors.first("beneficiaryInfoform.country" + cid) }}</span
          >
        </div>

        <div
          class="vx-col"
          v-bind:class="{ 'md:w-1/3  w-full': !placeOnly, 'md:w-1/3  w-full': placeOnly }"
        >
          <div class="con-select select-large">
            <label v-if="!placeOnly" class="vs-select--label">State</label>
            <label v-if="placeOnly" class="vs-select--label">&nbsp;</label>

            <multiselect
              :name="'state' + cid"
              v-model="laddress.state"
              :disabled="
                !laddress.country ||
                laddress.country.id == undefined ||
                states.length == 0
              "
              :show-labels="false"
              track-by="id"
              label="name"
              data-vv-as="State"
              placeholder="Select State"
              :options="states"
              :searchable="true"
              :allow-empty="false"
              @select="selectedState($event)"
            >

            <span slot="noResult" >No Sate Found</span>
            </multiselect>
          </div>

          <span
            class="text-danger text-sm"
            v-show="errors.has('beneficiaryInfoform.state' + cid)"
            >{{ errors.first("beneficiaryInfoform.state" + cid) }}</span
          >
        </div>
        <div
          class="vx-col"
          v-bind:class="{ 'md:w-1/3  w-full': !placeOnly, 'md:w-1/3  w-full': placeOnly }"
        >
          <div class="con-select select-large addselect">
            <label v-if="!placeOnly" class="vs-select--label">City</label>
            <label v-if="placeOnly" class="vs-select--label">&nbsp;</label>

            <multiselect
              :name="'location' + cid"
              v-model="laddress.location"
              :disabled="
                !laddress.state ||
                laddress.state.id == undefined ||
                locations.length == 0"
              :show-labels="false"
              
              track-by="id"
              label="name"
              data-vv-as="City"
                  tag-placeholder="Add"
                  :taggable="true"
             @tag="addLocation"
              placeholder="Select City"
              :options="locations"
              :searchable="true"
              :allow-empty="false"
            >

  

           <span slot="noResult" >No Locations Found</span>
            </multiselect>
          </div>

          <span
            class="text-danger text-sm"
            v-show="errors.has('beneficiaryInfoform.location' + cid)"
            >{{ errors.first("beneficiaryInfoform.location" + cid) }}</span
          >
        </div>

        <div class="vx-col md:w-1/3 w-full" v-if="!placeOnly">
          <vs-input
            :name="'zipcode' + cid"
            v-model="laddress.zipcode"
            v-validate="'numeric|min:5|max:12'"
            class="w-full"
            data-vv-as="Zip Code"
            label="Zip Code"
          />

          <span
            class="text-danger text-sm"
            v-show="errors.has('beneficiaryInfoform.zipcode' + cid)"
            >{{ errors.first("beneficiaryInfoform.zipcode" + cid) }}</span
          >
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import _ from "lodash";
export default {
  inject: ["parentValidator"],
  props: {
    countries:Array,
    address:Object,
    cid: {
      type: String,
      default: "",
    },
    placeOnly: {
      type: Boolean,
      default: false,
    },
    placeOnlyTitle:String
  },
  
  data() {
    return {
      states: [],
      locations: [],
      laddress:{
        line1:'',
        line2:'',
        zipcode:'',
        country:null,
        state:'',
        location:'',
      }
    };
  },
  created() {
    this.$validator = this.parentValidator;
  },
  mounted() {
    if(this.address !=null && this.address !=''){
       this.laddress = this.address
    }
  
  if (this.laddress && this.laddress.country && this.laddress.country.id) {
  if(this.laddress.country && this.laddress.country.id){
                this.$store
          .dispatch("getstates", this.laddress.country.id)
          .then((response) => {
            this.states = response;
          });

      }

      if(this.laddress.state && this.laddress.state.id){

        this.$store
          .dispatch("getlocations", {
            countryId: this.laddress.country.id,
            stateId: this.laddress.state.id,
          })
          .then((response) => {
            this.locations = response;
          });

      }

      }

  },
  methods: {
    addLocation(newTag){


          this.$store
              .dispatch("addLocations", {
                name: newTag,
                stateId: this.laddress.state.id,
              })
              .then((response) => {
                  var tag = response

      this.locations.push(response)
      this.laddress.location = response;


              });

    },
    updateaddress(data) {
      if (data.line1 != null) this.laddress.line1 = data.line1;
      if (data.line2 != null) this.laddress.line2 = data.line2;
      if (data.zipcode != null) this.laddress.zipcode = data.zipcode;
      if (data.country && data.country.id) {
     if (data.country && data.country.id) {
            this.laddress.country = _.find(this.countries, (e) => {
              return e["id"] == data.country.id;
            });

            this.$store
              .dispatch("getstates", data.country.id)
              .then((response) => {
                this.states = response;
                this.laddress.state = _.find(this.states, (e) => {
                  return e["id"] == data.state.id;
                });
              });
            this.$store
              .dispatch("getlocations", {
                countryId: data.country.id,
                stateId: data.state.id,
              })
              .then((response) => {
                this.locations = response;

                this.laddress.location = _.find(this.locations, (e) => {
                  return e["id"] == data.location.id;
                });
              });
          }
      }
    },
    selectedCountry(selected) {
      this.locations = [];
      this.$store.dispatch("getstates", selected.id).then((response) => {
        this.states = response;
      });
    },
    selectedState(selected) {
      this.locations = [];
      this.$store
        .dispatch("getlocations", {
          countryId: this.laddress.country.id,
          stateId: selected.id,
        })
        .then((response) => {
          this.locations = response;
        });
    },
  },
  beforeDestroy() {},
};
</script>
