<template>
  <div class="block-layout questionnaire" :class="{'anonymousloginForm':!checkCurrentUrl}">
    <div
      class="
        vx-col
        w-full
        wizard-container
        form_section
        questionnairesection
        pad0
      "
    >
      <vs-button
        color="success"
        @click="
          comments = '';
          formSubmitted(true);
        "
        class="save questionnaire"
        type="filled"
        >Save</vs-button
      >

      <div class="case-details-link" v-if="editingForm">
        <router-link v-bind:to="'/petition-details/'+petition._id">
          <img src="@/assets/images/main/back_arrow.png" /> Back to Case Details
        </router-link>
        </div>

      <vx-card>
        <div class="wizard-content-heading">
          <h2 style="padding-bottom:0px;margin-bottom:0px;">
            Questionnaire for
            {{ checkProperty(petition, "typeDetails", "name") }}
          </h2>
          <h2 style="padding-top:0px;margin-top:0px;">
            <small>{{
              checkProperty(petition, "subTypeDetails", "name")
            }}</small>
          </h2>
          <p>
            Please take a few moments to complete this short registration form
          </p>
        </div>

        <form-wizard
          v-if="questionnaireDetails != null"
          color="rgba(var(--vs-primary), 1)"
          :title="null"
          :subtitle="null"
          finishButtonText="Submit"
          @on-complete="formSubmitted"
        >
          <tab-content
            title="Case Details"
            :before-change="beforeTabSwitch"
          >
            <!-- tab 1 content -->
            <form
              data-vv-scope="beneficiaryInfoform"
              @submit.prevent=""
              @keydown.enter.prevent=""
            >
              <vs-col class="w-full p-0">
                <vs-alert
                  color="warning"
                  class="warning-alert top-warning-alert"
                  icon-pack="IntakePortal"
                  icon="IP-information-button"
                  active="true"
                >
                  NOTE: This questionnaire should be filled out completely and
                  accurately. Kindly read the instructions carefully.
                  <!-- All information is required, and if not applicable, please mention N/A. -->
                </vs-alert>
              </vs-col>
              <template v-if="checkTemplateField('gender')">
                <vs-col
                  class="
                    m-auto
                    float-none
                    demo-alignment
                    beneficiary-info-btns
                    pt-10
                    pb-2
                  "
                  vs-type="flex"
                  vs-justify="space-between"
                  vs-align="center"
                  vs-lg="8"
                  vs-sm="12"
                >
                  <vs-button
                    class="btn male-btn"
                    @click="setGender('male')"
                    v-bind:class="{
                      isActivec: beneficiaryInfo.gender == 'male',
                    }"
                    icon-pack="IntakePortal"
                    icon=" IP-femenine-1"
                    type="border"
                    >Male</vs-button
                  >
                  <vs-button
                    v-bind:class="{
                      isActivec: beneficiaryInfo.gender == 'female',
                    }"
                    class="btn female-btn"
                    @click="setGender('female')"
                    icon-pack="IntakePortal"
                    icon=" IP-femenine-1"
                    type="border"
                    >Female</vs-button
                  >
                  <vs-button
                    v-bind:class="{
                      isActivec: beneficiaryInfo.gender == 'others',
                    }"
                    class="btn others-btn"
                    @click="setGender('others')"
                    icon-pack="feather"
                    icon="icon-circle"
                    type="border"
                    >Others</vs-button
                  >
                  <vs-input
                    style="display: none"
                    name="gender"
                    type="hidden"
                    data-vv-as="Gender"
                    v-validate="'required'"
                    v-model="beneficiaryInfo.gender"
                  />
                  <div class="input-group-error mt-0 mr-0" style="width: 100%">
                    <p>
                      <span
                        class="error text-sm"
                        v-show="errors.has('beneficiaryInfoform.gender')"
                        >{{ errors.first("beneficiaryInfoform.gender") }}</span
                      >
                    </p>
                  </div>
                </vs-col>

                <div class="divider"></div>
              </template>
              <template
                v-if="
                  checkTemplateField('first_name') ||
                  checkTemplateField('middle_name') ||
                  checkTemplateField('last_name') ||
                  checkTemplateField('email') ||
                  checkTemplateField('dateOfBirth') ||
                  checkTemplateField('marital_status')
                "
              >
                <vs-col
                  class="m-auto float-none"
                  vs-type="flex"
                  vs-justify="center"
                  vs-align="center"
                  vs-lg="8"
                  vs-sm="12"
                >
                  <div class="form-container">
                    <div class="vx-row">
                      <div class="vx-col w-full">
                        <vx-input-group class="form-input-group">
                          <div
                            class="form_group w-full"
                            v-if="checkTemplateField('first_name')"
                          >
                            <label class="form_label"
                              >First Name<em>*</em></label
                            >
                            <vs-input
                              name="firstname"
                              v-model="beneficiaryInfo.firstName"
                              v-validate="'required'"
                              class="w-full"
                              data-vv-as="First Name"
                            />
                          </div>
                          <div
                            class="form_group w-full"
                            v-if="checkTemplateField('middle_name')"
                          >
                            <label class="form_label">Middle Name</label>
                            <vs-input
                              class="w-full"
                              name="middleName"
                              v-model="beneficiaryInfo.middleName"
                              data-vv-as="Middle Name"
                            />
                          </div>
                          <div
                            class="form_group w-full"
                            v-if="checkTemplateField('last_name')"
                          >
                            <label class="form_label"
                              >Last Name<em>*</em></label
                            >
                            <vs-input
                              class="w-full"
                              name="lastName"
                              v-model="beneficiaryInfo.lastName"
                              v-validate="'required'"
                              data-vv-as="Last Name"
                            />
                          </div>
                          <!-- <div><a @click="resetOtherNames()"> Has Other Name?</a></div> -->
                        </vx-input-group>
                        <div
                          class="input-group-error"
                          v-if="
                            checkTemplateField('last_name') ||
                            checkTemplateField('first_name')
                          "
                        >
                          <p
                            class="w-1/3"
                            v-if="checkTemplateField('first_name')"
                          >
                            <span
                              class="text-danger text-sm"
                              v-show="
                                errors.has('beneficiaryInfoform.firstname')
                              "
                              >{{
                                errors.first("beneficiaryInfoform.firstname")
                              }}</span
                            >
                          </p>
                          <p
                            class="w-1/3"
                            v-if="checkTemplateField('middle_name')"
                          ></p>
                          <p
                            class="w-1/3"
                            v-if="checkTemplateField('last_name')"
                          >
                            <span
                              class="text-danger text-sm"
                              v-show="
                                errors.has('beneficiaryInfoform.lastName')
                              "
                              >{{
                                errors.first("beneficiaryInfoform.lastName")
                              }}</span
                            >
                          </p>
                        </div>
                      </div>
                      <div class="vx-col w-full mb-5">
                         <div class="d-flex align-center">
                            <a class="mr-3"> Have you used any other names previously? </a>
                           
                            <vs-switch v-model="beneficiaryInfo.hasOtherNames" @input="resetOtherNames()" >
                              <span slot="on">Yes</span>
                              <span slot="off">No</span>
                            </vs-switch>
                        </div>
                      </div>
                      <!-----------Other Names checkProperty( beneficiaryInfo , 'hasOtherNames')------------->
                    <template v-if="checkProperty( beneficiaryInfo , 'hasOtherNames')" >
                      <div class="vx-col w-full"  v-for="( item ,ind ) in beneficiaryInfo['otherNames']"  :key="ind">
                        <vx-input-group class="form-input-group">
                          <div  class="form_group w-full"  >
                            <label class="form_label"   >First Name<em>*</em></label >
                            <vs-input  :name="'firstname_other'+ind"  v-model="item.firstName" v-validate="'required'" class="w-full" data-vv-as="First Name" />
                          </div>
                          <div  class="form_group w-full"  >
                            <label class="form_label">Middle Name</label>
                            <vs-input  class="w-full"  :name="'middleName_other'+ind"   v-model="item.middleName"   data-vv-as="Middle Name"  />
                          </div>
                          <div  class="form_group w-full"  >
                            <label class="form_label" >Last Name</label >
                            <vs-input  class="w-full"  :name="'lastName_other'+ind" v-model="item.lastName"   data-vv-as="Last Name"  />

                            
                                <div class="delete" v-if="ind>0">
                                    <a @click="removeOtherName(ind)">

                                          <trash-2-icon
                                          size="1.5x"
                                          class="custom-class"
                                          ></trash-2-icon>
                                    </a>
                                </div>

                          </div>
                        </vx-input-group>
                        <div    class="input-group-error" >
                          <p  class="w-1/3"  >
                            <span class="text-danger text-sm" v-show="  errors.has('beneficiaryInfoform.firstname_other'+ind) ">{{  errors.first("beneficiaryInfoform.firstname_other"+ind)  }}</span>
                          </p>
                          <p  class="w-1/3"  ></p>
                          <p   class="w-1/3" >
                            <span  class="text-danger text-sm"  v-show="  errors.has('beneficiaryInfoform.lastName_other'+ind)  " >{{errors.first("beneficiaryInfoform.lastName_other"+ind)}}</span
                            >
                          </p>
                        </div>

                        <a class="add-more add-more-names" v-if="((beneficiaryInfo['otherNames'].length)-1)==ind" @click="addOtherNames()"><span>+</span>Add</a>
                      </div>
                    </template>

                      <div
                        class="vx-col w-full"
                        v-if="checkTemplateField('email')"
                      >
                        <div class="form_group">
                          <label class="form_label">Email<em>*</em></label>
                          <vs-input
                            name="email"
                            v-model="beneficiaryInfo.email"
                            v-validate="'required|email'"
                            class="w-full"
                            data-vv-as="Email"
                          />
                          <span
                            class="text-danger text-sm"
                            v-show="errors.has('beneficiaryInfoform.email')"
                            >{{
                              errors.first("beneficiaryInfoform.email")
                            }}</span
                          >
                        </div>
                      </div>
                      <div
                        class="vx-col md:w-1/2 w-full"
                        v-if="checkTemplateField('dateOfBirth')"
                      >
                        <div class="form_group">
                          <label class="form_label"
                            >Date of Birth <em>*</em></label
                          >
                          <date-picker-field :validationRequired="true" v-model="beneficiaryInfo.dateOfBirth" formscope="beneficiaryInfoform" fieldname="dateOfBirth" label="Date of Birth" />
                    
                        </div>
                      </div>

                      <div
                        class="vx-col md:w-1/2 w-full"
                        v-if="checkTemplateField('countryOfBirth')"
                      >
                        <div class="form_group">
                          <label for class="form_label"
                            >Country of Birth<em>*</em></label
                          >
                          <div class="con-select w-full">
                            <multiselect
                              name="countryOfBirth"
                              v-validate="'required'"
                              v-model="beneficiaryInfo.countryOfBirthDetails"
                              @select="selectcountryOfBirth"
                              :show-labels="false"
                              ref="bncnt"
                              track-by="id"
                              label="name"
                              data-vv-as="Country of Birth"
                              placeholder="Country of Birth"
                              :options="countries"
                              :searchable="true"
                              :allow-empty="false"
                            >
                            </multiselect>
                          </div>

                          <span
                            class="text-danger text-sm"
                            v-show="
                              errors.has('beneficiaryInfoform.countryOfBirth')
                            "
                            >{{
                              errors.first("beneficiaryInfoform.countryOfBitrh")
                            }}</span
                          >
                        </div>
                      </div>

                      <div
                        class="vx-col md:w-1/2 w-full"
                        v-if="checkTemplateField('provinceOfBirth')"
                      >
                        <div class="form_group">
                          <label for class="form_label"
                            >Province of Birth
                            <em v-if="provinceStates.length > 0">*</em></label
                          >

                          <div class="con-select w-full">
                            <multiselect
                              name="provinceState"
                              v-validate="{
                                required: provinceStates.length > 0,
                              }"
                              v-model="beneficiaryInfo.provinceOfBirthDetails"
                              :disabled="provinceStates.length == 0"
                              @select="selectProvinceOfBirth"
                              :show-labels="false"
                              label="name"
                              track-by="id"
                              data-vv-as="Province of Birth"
                              placeholder="Province of Birth"
                              :options="provinceStates"
                              :searchable="true"
                              :allow-empty="false"
                            ></multiselect>
                          </div>
                          <span
                            class="text-danger text-sm"
                            v-show="
                              errors.has('beneficiaryInfoform.provinceState')
                            "
                            >{{
                              errors.first("beneficiaryInfoform.provinceState")
                            }}</span
                          >
                        </div>
                      </div>

                      <div
                        class="vx-col md:w-1/2 w-full"
                      
                       v-if="checkTemplateField('locationOfBirth')"
                      >
                        <div class="form_group">
                          <label for class="form_label"
                            >Location of Birth
                            <em v-if="provinceLocations.length > 0"></em></label
                          >

                          <div class="con-select w-full">
                           <!--- <multiselect
                              name="Location"
                              v-validate="{
                                required: provinceLocations.length > 0,
                              }"
                              v-model="beneficiaryInfo.locationOfBirthDetails"
                              :disabled="provinceLocations.length == 0"
                              @select="selectLocationOfBirth"
                              :show-labels="false"
                              label="name"
                              track-by="id"
                              data-vv-as="Location of Birth"
                              placeholder="Location of Birth"
                              :options="provinceLocations"
                              :searchable="true"
                              :allow-empty="false"
                            ></multiselect>--->
                            <vs-input
                               v-validate="'max:50'"
                              class="w-full"
                              name="benLocation"
                              v-model="beneficiaryInfo.locationOfBirth"
                              data-vv-as="Location Of Birth"
                            />
                          </div>
                          <span
                            class="text-danger text-sm"
                            v-show="
                              errors.has('beneficiaryInfoform.benLocation')
                            "
                            >{{
                              errors.first("beneficiaryInfoform.benLocation")
                            }}</span
                          >
                        </div>
                         </div>

                      <div
                        class="vx-col md:w-1/2 w-full"
                        v-if="checkTemplateField('countryOfCitizenship')"
                      >
                        <div class="form_group">
                          <label for class="form_label"
                            >Country of Citizenship <em>*</em></label
                          >

                          <div class="con-select w-full">
                            <multiselect
                              name="countryOfCitizenship"
                              v-validate="'required'"
                              v-model="
                                beneficiaryInfo.countryOfCitizenshipDetails
                              "
                              @select="selectCountryOfCitizenship"
                              :show-labels="false"
                              ref="bncnt"
                              track-by="id"
                              label="name"
                              data-vv-as="Country of Citizenship"
                              placeholder="Country of Citizenship"
                              :options="countries"
                              :searchable="true"
                              :allow-empty="false"
                            >
                            </multiselect>
                          </div>
                          <span
                            class="text-danger text-sm"
                            v-show="
                              errors.has(
                                'beneficiaryInfoform.countryOfCitizenship'
                              )
                            "
                            >{{
                              errors.first(
                                "beneficiaryInfoform.countryOfCitizenship"
                              )
                            }}</span
                          >
                        </div>
                      </div>

                      <div
                        class="vx-col md:w-1/2 w-full"
                        v-if="checkTemplateField('I94')"
                      >
                        <div class="form_group">
                          <template
                            v-if="
                              [5, 8].indexOf(petition.subTypeDetails.id) < 0
                            "
                          >
                            <label class="form_label"
                              >I-94 Number<em>*</em></label
                            >
                            <vs-input
                              v-validate="'required'"
                              class="w-full"
                              name="I94"
                              v-model="beneficiaryInfo.I94"
                              data-vv-as="I-94"
                            />
                          </template>

                          <template
                            v-if="
                              [5, 8].indexOf(petition.subTypeDetails.id) >= 0
                            "
                          >
                            <label class="form_label">I-94 Number </label>
                            <vs-input
                              class="w-full"
                              name="I94"
                              v-model="beneficiaryInfo.I94"
                              data-vv-as="I-94"
                            />
                          </template>

                          <span
                            class="text-danger text-sm"
                            v-show="errors.has('beneficiaryInfoform.I94')"
                            >{{ errors.first("beneficiaryInfoform.I94") }}</span
                          >
                        </div>
                      </div>
                      <!-----'I94ExpiryDate'-->

                      <div  class="vx-col md:w-1/2 w-full"  v-if="checkTemplateField('I94ExpiryDate')"  >
                        <div class="form_group">
                        <label class="form_label" >I-94 Expiry Date </label>
                      
                       <date-picker-field  v-model="beneficiaryInfo.I94ExpiryDate" formscope="beneficiaryInfoform" fieldname="I-94ExpiryDate" label="I-94 Expiry Date" />
                      
                        
                        </div>
                        </div>



                      <div
                        class="vx-col md:w-1/2 w-full"
                        v-if="checkTemplateField('marital_status')"
                      >
                        <div class="form_group">
                          <label class="form_label"
                            >Marital Status<em>*</em></label
                          >
                          <div class="con-select">
                            <multiselect
                              v-validate="'required'"
                              name="maritalStatus"
                              v-model="beneficiaryInfo.maritalStatus"
                              data-vv-as="Marital Status"
                              :show-labels="false"
                              track-by="id"
                              label="name"
                              placeholder="Select Status"
                              :options="marital_statuses"
                              :searchable="true"
                              :allow-empty="false"
                            >
                            </multiselect>
                          </div>
                          <span
                            class="text-danger text-sm"
                            v-show="
                              errors.has('beneficiaryInfoform.maritalStatus')
                            "
                            >{{
                              errors.first("beneficiaryInfoform.maritalStatus")
                            }}</span
                          >
                        </div>
                      </div>
                    </div>
                  </div>
                </vs-col>
                <div class="divider"></div>
              </template>
              <!--Phone Number Templaet--->
              <template
                v-if="
                  checkTemplateField('cell_phone_number') ||
                  checkTemplateField('home_phone_number')
                "
              >
                <vs-col
                  class="m-auto float-none"
                  vs-type="flex"
                  vs-justify="center"
                  vs-align="center"
                  vs-lg="8"
                  vs-sm="12"
                >
                  <div class="form-container">
                    <div class="vx-row">
                      <div
                        class="vx-col md:w-1/2 w-full"
                        v-if="checkTemplateField('cell_phone_number')"
                      >
                        <div class="form_group ph_number">
                          <label class="form_label"
                            >Phone Number<em>*</em></label
                          >

                          <div class="vs-component">
                            <VuePhoneNumberInput
                              icon-pack="feather"
                              class="w-full no-icon-border"
                              :no-example="false"
                              v-validate="'required'"
                              v-bind="vuePhone.props"
                              data-vv-as="Phone Number"
                              name="cellPhoneNumber"
                              :default-country-code="
                                checkProperty(
                                  beneficiaryInfo['cellPhoneCountryCode'],
                                  'countryCode'
                                )
                              "
                              placeholder="Phone Number"
                              :no-country-selector="false"
                              v-model="beneficiaryInfo.cellPhoneNumber"
                              @update="updatePhone"
                            />
                            <span
                              class="text-danger text-sm"
                              v-if="
                                errors.has(
                                  'beneficiaryInfoform.cellPhoneNumber'
                                )
                              "
                              >{{
                                errors.first(
                                  "beneficiaryInfoform.cellPhoneNumber"
                                )
                              }}</span
                            >
                            <span
                              class="text-danger text-sm"
                              v-else-if="
                                !isPhoneValid &&
                                !errors.has(
                                  'beneficiaryInfoform.cellPhoneNumber'
                                )
                              "
                              >* Enter a valid phone number</span
                            >
                          </div>
                        </div>
                      </div>
                      <div
                        class="vx-col md:w-1/2 w-full"
                        v-if="checkTemplateField('home_phone_number')"
                      >
                        <div class="form_group ph_number">
                          <label class="form_label">Home Phone Number</label>

                          <div class="vs-component">
                            <VuePhoneNumberInput
                              icon-pack="feather"
                              class="w-full no-icon-border"
                              :no-example="false"
                              data-vv-as="Home Phone Number"
                              v-bind="vuePhone.props"
                              name="homePhoneNumber"
                              :default-country-code="
                                checkProperty(
                                  beneficiaryInfo['homePhoneCountryCode'],
                                  'countryCode'
                                )
                              "
                              placeholder="Phone Number"
                              :no-country-selector="false"
                              v-model="beneficiaryInfo.homePhoneNumber"
                              @update="updateHomePhone"
                            />
                            <span
                              class="text-danger text-sm"
                              v-if="
                                errors.has(
                                  'beneficiaryInfoform.homePhoneNumber'
                                )
                              "
                              >{{
                                errors.first(
                                  "beneficiaryInfoform.homePhoneNumber"
                                )
                              }}</span
                            >
                            <span
                              class="text-danger text-sm"
                              v-else-if="
                                !isHomePhoneValid &&
                                !errors.has(
                                  'beneficiaryInfoform.homePhoneNumber'
                                )
                              "
                              >* Enter a valid phone number</span
                            >
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </vs-col>
                <div class="divider"></div>
              </template>

              <!--Education Templaet--->
              <template
                v-if="
                  checkTemplateField('highest_degree') ||
                  checkTemplateField('major_field_of_study')
                "
              >
                <vs-col
                  class="m-auto float-none"
                  vs-type="flex"
                  vs-justify="center"
                  vs-align="center"
                  vs-lg="8"
                  vs-sm="12"
                >
                  <div class="form-container w-full">
                    <h3 class="small-header">Education</h3>
                    <div class="vx-row">
                      <div
                        class="vx-col md:w-1/2 w-full"
                        v-if="checkTemplateField('highest_degree')"
                      >
                        <div class="form_group">
                          <label class="form_label"
                            >Highest Degree<em>*</em></label
                          >

                          <div class="con-select">
                            <multiselect
                              v-validate="'required'"
                              name="highestDegree"
                              v-model="beneficiaryInfo.education.highestDegree"
                              data-vv-as="Highest Degree"
                              :show-labels="true"
                              track-by="id"
                              label="name"
                              placeholder="Select Highest Degree"
                              :options="education_types"
                              :searchable="true"
                              :allow-empty="false"
                            >
                            </multiselect>
                          </div>
                          <span
                            class="text-danger text-sm"
                            v-show="
                              errors.has('beneficiaryInfoform.highestDegree')
                            "
                            >{{
                              errors.first("beneficiaryInfoform.highestDegree")
                            }}</span
                          >
                        </div>
                      </div>
                      <div
                        class="vx-col md:w-1/2 w-full"
                        v-if="checkTemplateField('major_field_of_study')"
                      >
                        <div class="form_group">
                          <label class="form_label"
                            >Major Field of Study<em>*</em></label
                          >
                          <vs-input
                            v-validate="'required'"
                            class="w-full"
                            name="majorFieldOfStudy"
                            oninput="this.value = this.value.replace(/[^a-z A-Z !@#$%^&*()_+. ]/g, '');"
                            v-model="
                              beneficiaryInfo.education.majorFieldOfStudy
                            "
                            data-vv-as="Major Field of Study"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </vs-col>
                <div class="divider"></div>
              </template>

              <template
                v-if="
                  checkTemplateField('passportNumber') ||
                  checkTemplateField('passportIssuedDate') ||
                  checkTemplateField('passportExpiryDate') ||
                  checkTemplateField('curVisaExpiryDate') ||
                  checkTemplateField('curNonImmigrantVisaStatus') ||
                  checkTemplateField('sevisNumber') ||
                  checkTemplateField('eadNumber')
                "
              >
                <vs-col
                  class="m-auto float-none"
                  vs-type="flex"
                  vs-justify="center"
                  vs-align="center"
                  vs-lg="8"
                  vs-sm="12"
                >
                  <div class="form-container w-full">
                    <h3 class="small-header">Passport</h3>
                    <div class="vx-row">
                      <div class="vx-col w-full">
                        <div class="vx-row delete-row">
                          <div
                            class="vx-col lg:w-1/2 w-full"
                            v-if="checkTemplateField('passportNumber')"
                          >
                            <div class="form_group">
                              <label class="form_label"
                                >Passport Number<em>*</em></label
                              >
                              <vs-input
                                v-validate="'required|max:15'"
                                @keyup="benPassportUpdated()"
                                oninput="this.value = this.value.replace(/[^a-z A-Z 0-9]/g, '');"
                                data-vv-as="Passport Number"
                                name="benpassportNumber"
                                v-model="beneficiaryInfo.passportNumber"
                                class="w-full"
                              />
                              <span
                                class="text-danger text-sm"
                                v-show="
                                  errors.has(
                                    'beneficiaryInfoform.benpassportNumber'
                                  )
                                "
                                >{{
                                  errors.first(
                                    "beneficiaryInfoform.benpassportNumber"
                                  )
                                }}</span
                              >
                            </div>
                          </div>

                          <div
                            class="vx-col md:w-1/2 w-full"
                            v-if="checkTemplateField('passportIssuedDate')"
                          >
                            <div class="form_group">
                              <label class="form_label"
                                >Passport Issued Date<em
                                  v-if="
                                    checkProperty(
                                      beneficiaryInfo,
                                      'passportNumber'
                                    ) != '' &&
                                    checkProperty(
                                      beneficiaryInfo,
                                      'passportNumber'
                                    ) != null
                                  "
                                  >*</em
                                >
                              </label>

                       <date-picker-field  v-model="beneficiaryInfo.passportIssuedDate" formscope="beneficiaryInfoform" fieldname="passportIssuedDate" label="Passport Issued Date " />

                            </div>
                          </div>

                          <div
                            class="vx-col md:w-1/2 w-full"
                            v-if="checkTemplateField('passportExpiryDate')"
                          >
                            <div class="form_group">
                              <label class="form_label"
                                >Date of Passport Expires
                                <em
                                  v-if="
                                    checkProperty(
                                      beneficiaryInfo,
                                      'passportNumber'
                                    ) != '' &&
                                    checkProperty(
                                      beneficiaryInfo,
                                      'passportNumber'
                                    ) != null
                                  "
                                  >*</em
                                ></label
                              >
                       <date-picker-field  v-model="beneficiaryInfo.passportExpiryDate" formscope="beneficiaryInfoform" fieldname="benpassportExpiryDate" label="Date of Passport Expires " />

                            
                            
                            </div>
                          </div>
                          <div
                            class="vx-col md:w-1/2 w-full"
                            v-if="checkTemplateField('curVisaExpiryDate')"
                          >
                            <div class="form_group">
                              <label class="form_label"
                                >Current Status Expiry Date</label
                              >

                                       <date-picker-field  v-model="beneficiaryInfo.curVisaExpiryDate" formscope="beneficiaryInfoform" fieldname="curVisaExpiryDate" label="Current Status Expiry Date" />
                
                             
                            </div>
                          </div>
                          <div
                            class="vx-col md:w-1/2 w-full"
                            v-if="
                              checkTemplateField('curNonImmigrantVisaStatus')
                            "
                          >
                            <div class="form_group">
                              <label class="form_label"
                                >Current Nonimmigrant Status
                              </label>
                              <vs-input
                                v-model="
                                  beneficiaryInfo.curNonImmigrantVisaStatus
                                "
                                class="w-full"
                                data-vv-as="Current Nonimmigrant Status  "
                                placeholder="Current Nonimmigrant Status  "
                                :name="'curNonImmigrantVisaStatus'"
                              />
                              <span
                                class="text-danger text-sm"
                                v-show="
                                  errors.has(
                                    'beneficiaryInfoform.curNonImmigrantVisaStatus'
                                  )
                                "
                                >{{
                                  errors.first(
                                    "beneficiaryInfoform.curNonImmigrantVisaStatus"
                                  )
                                }}</span
                              >
                            </div>
                          </div>

                          <div
                            class="vx-col md:w-1/2 w-full"
                            v-if="checkTemplateField('sevisNumber')"
                          >
                            <div class="form_group">
                              <label class="form_label"
                                >SEVIS Number
                              </label>
                              <div class="vs-con-input">
                                <!--
                                        <the-mask  autocomplete="off" autocorrect="off"   :name="'sevisNumber'"  v-model="beneficiaryInfo.sevisNumber"  class="vs-inputx vs-input--input full"
                                        data-vv-as="SEVIS  Number" v-validate="'required|min:9|max:9'"  placeholder="### - ### - ####"   :mask="['### - ### - ###']"/>
                                       -->

                                <vs-input
                                  v-validate="'max:11|alpha_num'"
                                  v-model="beneficiaryInfo.sevisNumber"
                                  class="w-full"
                                  data-vv-as="SEVIS  Number"
                                  placeholder="SEVIS  Number"
                                  :name="'sevisNumber'"
                                  oninput="this.value = this.value.replace(/[^a-z A-Z 0-9]/g, '').replace(/(\..*)\./g, '$1'); this.value = this.value.replace(/ /g,'');"
                                />

                                <span
                                  class="text-danger text-sm"
                                  v-show="
                                    errors.has(
                                      'beneficiaryInfoform.sevisNumber'
                                    )
                                  "
                                  >{{
                                    errors.first(
                                      "beneficiaryInfoform.sevisNumber"
                                    )
                                  }}</span
                                >
                              </div>
                            </div>
                          </div>

                          <div
                            class="vx-col md:w-1/2 w-full"
                            style="margin-bottom: 20px"
                            v-if="checkTemplateField('eadNumber')"
                          >
                            <div class="form_group">
                              <label class="form_label">EAD Number</label>

                              <div class="vs-con-input">
                                <the-mask
                                  autocomplete="off"
                                  autocorrect="off"
                                  :name="'eadNumber'"
                                  v-model="beneficiaryInfo.eadNumber"
                                  class="vs-inputx vs-input--input full"
                                  data-vv-as="EAD  Number "
                                  v-validate="'min:9|max:9'"
                                  placeholder="### - ### - ####"
                                  :mask="['### - ### - ###']"
                                />

                                <span
                                  class="text-danger text-sm"
                                  v-show="
                                    errors.has('beneficiaryInfoform.eadNumber')
                                  "
                                  >{{
                                    errors.first(
                                      "beneficiaryInfoform.eadNumber"
                                    )
                                  }}</span
                                >
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </vs-col>
                <div class="divider"></div>
              </template>

              <!--Address Templaet--->
              <template
                v-if="
                  checkTemplateField('iam_from_us') ||
                  checkTemplateField('address') ||
                  checkTemplateField('iam_notfrom_us') ||
                  checkTemplateField('beneficiary_address_line1') ||
                  checkTemplateField('beneficiary_address_line2') ||
                  checkTemplateField('beneficiary_address_country') ||
                  checkTemplateField('beneficiary_address_state') ||
                  checkTemplateField('beneficiary_address_city') ||
                  checkTemplateField('beneficiary_address_zipcode')
                "
              >
                <vs-col
                  class="m-auto float-none"
                  vs-type="flex"
                  vs-justify="center"
                  vs-align="center"
                  vs-lg="8"
                  vs-sm="12"
                >
                  <div class="form-container">
                    <h3 class="small-header">Address</h3>
                    <div class="vx-row">
                      <div
                        class="vx-col w-full mb-5"
                        v-if="
                          (checkTemplateField('iam_from_us') ||
                            checkTemplateField('iam_notfrom_us')) &&
                          !onlyimFromUs
                        "
                      >
                        <ul
                          class="demo-alignment custom-radio"
                          vs-type="flex"
                          vs-align="center"
                        >
                          <li
                            v-if="checkTemplateField('iam_from_us')"
                            @click="setDefaultcountry()"
                          >
                            <vs-radio
                              v-model="beneficiaryInfo.iAmFromUS"
                              vs-value="true"
                              >I am in the United States
                            </vs-radio>
                          </li>
                          <li
                            v-if="checkTemplateField('iam_notfrom_us')"
                            @click="setDefaultcountry()"
                          >
                            <vs-radio
                              v-model="beneficiaryInfo.iAmFromUS"
                              vs-value="false"
                              >I am not in the United States
                            </vs-radio>
                          </li>
                        </ul>
                      </div>
                    
                      <!----beneficiaryInfo.address
                      
                       checkTemplateField('beneficiary_address_line1') ||
                  checkTemplateField('beneficiary_address_line2') ||
                  checkTemplateField('beneficiary_address_country') ||
                  checkTemplateField('beneficiary_address_state') ||
                  checkTemplateField('beneficiary_address_city') ||
                  checkTemplateField('beneficiary_address_zipcode')
                      -->
                       <addressFields 
                 v-if=" checkTemplateField('beneficiary_address_line1') ||
                  checkTemplateField('beneficiary_address_line2') ||
                  checkTemplateField('beneficiary_address_country') ||
                  checkTemplateField('beneficiary_address_state') ||
                  checkTemplateField('beneficiary_address_city') ||
                  checkTemplateField('beneficiary_address_zipcode')"

                        :showLane1="checkTemplateField('beneficiary_address_line1')"
                        :showLane2="checkTemplateField('beneficiary_address_line2')"
                        :showCountry="checkTemplateField('beneficiary_address_country')"
                        :showState=" checkTemplateField('beneficiary_address_state')"
                        :showCity="checkTemplateField('beneficiary_address_city')"
                        :showZip="checkTemplateField('beneficiary_address_zipcode')"
                       :formscope="'beneficiaryInfoform'" :disableCountry="checkProperty(beneficiaryInfo ,'iAmFromUS')?true:false" :showaptType="false" :addFormContainerCls='false' :validationRequired="true" :countries="countries"  v-model="beneficiaryInfo.address" :cid="'beneficiaryInfoaddress'" />
                      <template v-if="false">
                      <div
                        class="vx-col md:w-1/2 w-full"
                        v-if="checkTemplateField('beneficiary_address_line1')"
                      >
                        <div class="form_group">
                          <label class="form_label"
                            >Street Address<em>*</em></label
                          >
                          <vs-input
                            v-validate="'required'"
                            name="address1"
                            v-model="beneficiaryInfo.address.line1"
                            class="w-full"
                            data-vv-as="Street Address"
                            @blur="setDependentsInfoAddress(false)"
                          />
                          <span
                            class="text-danger text-sm"
                            v-show="errors.has('beneficiaryInfoform.address1')"
                            >{{
                              errors.first("beneficiaryInfoform.address1")
                            }}</span
                          >
                        </div>
                      </div>
                      <div
                        class="vx-col md:w-1/2 w-full"
                        v-if="checkTemplateField('beneficiary_address_line2')"
                      >
                        <div class="form_group">
                          <label class="form_label">Apt, Suite</label>
                          <vs-input
                            name="address2"
                            v-model="beneficiaryInfo.address.line2"
                            @blur="setDependentsInfoAddress(true)"
                            class="w-full"
                            data-vv-as="Apt, Suite"
                          />
                          <span
                            class="text-danger text-sm"
                            v-show="errors.has('beneficiaryInfoform.address2')"
                            >{{
                              errors.first("beneficiaryInfoform.address2")
                            }}</span
                          >
                        </div>
                      </div>

                      <div
                        class="vx-col md:w-1/2 w-full"
                        v-if="checkTemplateField('beneficiary_address_country')"
                      >
                        <div class="form_group">
                          <label for class="form_label"
                            >Country<em>*</em></label
                          > 
                          <div class="con-select w-full">
                            <multiselect
                              name="country"
                              v-validate="'required'"
                              v-model="bncountryModel"
                              :disabled="checkCountry === false"
                              @select="selectCountry"
                              :show-labels="false"
                              ref="bncnt"
                              track-by="id"
                              label="name"
                              data-vv-as="Country"
                              placeholder="Select Country"
                              :options="countries"
                              :searchable="true"
                              :allow-empty="false"
                            >
                            </multiselect>
                          </div>

                          <span
                            class="text-danger text-sm"
                            v-show="errors.has('beneficiaryInfoform.country')"
                            >{{
                              errors.first("beneficiaryInfoform.country")
                            }}</span
                          >
                        </div>
                      </div>
                      <div
                        class="vx-col md:w-1/2 w-full"
                        v-if="checkTemplateField('beneficiary_address_state')"
                      >
                        <div class="form_group">
                          <label for class="form_label"
                            >State<em v-if="states.length > 0">*</em></label
                          >
      
                          <div class="con-select w-full">
                            <multiselect
                              name="state"
                              v-validate="{ required: states.length > 0 }"
                              v-model="stateModel"
                              :disabled="states.length == 0"
                              @select="selectState"
                              :show-labels="false"
                              label="name"
                              track-by="id"
                              data-vv-as="State"
                              placeholder="Select State"
                              :options="states"
                              :searchable="true"
                              :allow-empty="false"
                            ></multiselect>
                          </div>
                          <span
                            class="text-danger text-sm"
                            v-show="errors.has('beneficiaryInfoform.state')"
                            >{{
                              errors.first("beneficiaryInfoform.state")
                            }}</span
                          >
                        </div>
                      </div>
                      <div
                        class="vx-col md:w-1/2 w-full"
                        v-if="checkTemplateField('beneficiary_address_city')"
                      >
                        <div class="form_group">
                          <label for class="form_label"
                            >City<em v-if="locations.length > 0">*</em></label
                          >
                          <div class="con-select w-full">
                            <multiselect
                              name="city"
                              v-validate="{ required: locations.length > 0 }"
                              v-model="locationModel"
                              @select="selectLocation"
                              :show-labels="false"
                              :disabled="locations.length == 0"
                              track-by="id"
                              data-vv-as="City"
                              label="name"
                              placeholder="Select City"
                              :options="locations"
                              :searchable="true"
                              :allow-empty="false"
                            ></multiselect>
                          </div>
                          <span
                            class="text-danger text-sm"
                            v-show="errors.has('beneficiaryInfoform.city')"
                            >{{
                              errors.first("beneficiaryInfoform.city")
                            }}</span
                          >
                        </div>
                      </div>
                      <div
                        class="vx-col md:w-1/2 w-full"
                        v-if="checkTemplateField('beneficiary_address_zipcode')"
                      >
                        <div class="form_group">
                          <label for class="form_label"
                            >Zip Code<em>*</em></label
                          >
                          <vs-input
                            name="zipcode"
                            v-model="beneficiaryInfo.address.zipcode"
                            @blur="setSpouseZipcode()"
                            oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1'); this.value = this.value.replace(/ /g,'');"
                            v-validate="'required|zipcodev:bncnt'"
                            class="w-full"
                            data-vv-as="Zip Code"
                          />

                          <span
                            class="text-danger text-sm"
                            v-show="errors.has('beneficiaryInfoform.zipcode')"
                            >{{
                              errors.first("beneficiaryInfoform.zipcode")
                            }}</span
                          >
                        </div>
                      </div>
                      </template>
                    </div>
                  </div>
                </vs-col>
                <div class="divider"></div>
              </template>

              <template v-if="checkTemplateField('SSN')">
                <vs-col
                  class="m-auto float-none"
                  vs-type="flex"
                  vs-justify="center"
                  vs-align="center"
                  vs-lg="8"
                  vs-sm="12"
                >
                  <div class="form-container">
                    <div class="vx-row">
                      <div class="vx-col w-full pb-8">
                        <!-- <vx-tooltip color="primary" text="Text Here">
                        <img src="@/assets/images/main/info-icon.svg" />
                      </vx-tooltip> -->

                        <div class="form_group">
                          <label class="form_label"
                            >Social Security number (if applicable)</label
                          >
                          <div class="vs-con-input">
                            <the-mask
                              v-validate="'min:9|max:9'"
                              name="SSN"
                              data-vv-as="Social Security number"
                              v-model="beneficiaryInfo.SSN"
                              placeholder="123 - 45 - 6789"
                              class="vs-inputx vs-input--input normal"
                              :mask="['### - ## - ####']"
                            />
                          </div>
                          <span
                            class="text-danger text-sm"
                            v-show="errors.has('beneficiaryInfoform.SSN')"
                            >{{ errors.first("beneficiaryInfoform.SSN") }}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </vs-col>
                <div
                  class="divider"
                  v-if="beneficiaryInfo.iAmFromUS == 'false'"
                ></div>
              </template>

              <template
                v-if="
                  beneficiaryInfo.iAmFromUS == false ||
                  beneficiaryInfo.iAmFromUS == 'false'
                "
              >
                <vs-col
                  class="m-auto float-none"
                  vs-type="flex"
                  vs-justify="center"
                  vs-align="center"
                  vs-lg="8"
                  vs-sm="12"
                >
                  <div class="form-container">
                    <div class="vx-row">
                      <div class="vx-col w-full">
                        <div class="form_group">
                        <label class="form_label">
                          Consulate to Notify upon Approval of your case (if
                          outside the USA)
                        </label>
                        <vs-input
                          v-model="beneficiaryInfo.consulateNotifyAddress"
                          maxlength="150"
                          class="w-full"
                          data-vv-as="Consulate to Notify upon Approval of your petition (if outside the
                      USA)"
                        />
                        </div>
                      </div>
                    </div>
                  </div>
                </vs-col>
                <div class="divider"></div>
              </template>
              <template
                v-if="
                  checkTemplateField('hasI140ImmPetitionFiled') ||
                  checkTemplateField('docs_i140_approval_notice')
                "
              >
                <vs-col class="m-auto float-none" vs-lg="8" vs-sm="12">
                  <div class="alert-content-block pt-3">
                    <template
                      v-if="checkTemplateField('hasI140ImmPetitionFiled')"
                    >
                      <p class="pt-0">
                        Has an I-140 immigrant petition been filed on your
                        behalf?
                      </p>
                      <div class="form_radio_btns">
                        <vs-button
                          v-bind:class="{
                            cactive: beneficiaryInfo.hasI140ImmPetitionFiled,
                          }"
                          @click="
                            beneficiaryInfo.hasI140ImmPetitionFiled = true
                          "
                          class="yes mr-5"
                          color="success"
                          type="border"
                        >
                          Yes</vs-button
                        >
                        <vs-button
                          class="no"
                          v-bind:class="{
                            cactive: !beneficiaryInfo.hasI140ImmPetitionFiled,
                          }"
                          @click="
                            beneficiaryInfo.hasI140ImmPetitionFiled = false
                          "
                          color="danger"
                          type="border"
                          >No</vs-button
                        >
                      </div>
                    </template>
                    <div
                      class="form-container mt-6"
                      v-if="beneficiaryInfo.hasI140ImmPetitionFiled"
                    >
                      <div class="vx-row">
                        <div class="vx-col w-full">
                          <label class="custom-label"
                            >I-140 Approval Notice, if any</label
                          >

                          <file-upload
                            v-model="documents.I140ApprovalNotice"
                            class="file-upload-input"
                            name="I140ApprovalNoticeDocument"
                            data-vv-as="INS Notices"
                            :multiple="true"
                            :hideSelected="true"
                            accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                            @input="upload(documents.I140ApprovalNotice)"
                          >
                            <img
                              class="file-icon"
                              src="@/assets/images/main/file-upload.svg"
                            />
                            Upload
                          </file-upload>

                          <span
                            class="text-danger text-sm"
                            v-show="errors.has('I140ApprovalNoticeDocument')"
                            >{{
                              errors.first("I140ApprovalNoticeDocument")
                            }}</span
                          >
                          <ul class="uploaded-list">
                            <template
                              v-for="(
                                item, index
                              ) in documents.I140ApprovalNotice"
                            >
                              <vs-chip
                                @click="
                                  remove(item, documents.I140ApprovalNotice)
                                "
                                v-if="item.status !== false"
                                :key="index"
                                closable
                              >
                                {{ item.name }}
                              </vs-chip>
                            </template>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </vs-col>
                <div class="divider"></div>
              </template>

              <template v-if="checkTemplateField('priorPeriodOfStayInUS')">
                <vs-col
                  class="m-auto float-none"
                  vs-type="flex"
                  vs-justify="center"
                  vs-align="center"
                  vs-lg="8"
                  vs-sm="12"
                >
                  <div class="form-container">
                    <div class="vx-row">
                      <div class="vx-col w-full mt-2 mb-5">
                        <p class="mb-0">
                          All prior periods of stay in the U.S. over the last
                          seven years
                        </p>
                      </div>

                      <div class="vx-col w-full">
                        <div
                          class="vx-row delete-row"
                          v-for="(priorstay, index) in priorPeriodOfStayInUS"
                          :key="priorstay.id"
                        >
                          <div class="vx-col md:w-1/3 w-full">
                            <div class="form_group">
                              <label class="form_label">Date Entered</label>
                              
                              <!----<datepicker  :typeable="true"  :use-utc="true"   :format="customFormatter"  data-vv-as="Date Entered"  :name="'enterDate' + index" 
                              :disabled-dates="{
                                  to: new Date(startBeneficiaryDateEntered),
                                  from: new Date(),
                                }"
                                v-model="priorstay.enteredDate"
                                placeholder="MM/DD/YYYY"
                              ></datepicker>-->
                              
                              <date-picker-field :validationRequired="false"
                              :disabled-dates="{ to: new Date(startBeneficiaryDateEntered),  from: new Date()}"
                               v-model="priorstay.enteredDate" formscope="beneficiaryInfoform" :fieldname="'enterDate'+index" label="Date Entered" />
                              <span
                                class="text-danger text-sm"
                                v-show="
                                  errors.has(
                                    'beneficiaryInfoform.enterDate' + index
                                  )
                                "
                                >{{
                                  errors.first(
                                    "beneficiaryInfoform.enterDate" + index
                                  )
                                }}</span
                              >
                            </div>
                          </div>
                          <div class="vx-col md:w-1/3 w-full">
                            <div class="form_group">
                              <label class="form_label">Date Departed</label>
                              <!-----<datepicker  :typeable="true"  :use-utc="true" 
                                :format="customFormatter"
                                :name="'departDate' + index"
                               
                                data-vv-as="Date Departed"
                                :disabled="priorstay.enteredDate === null"
                                :disabled-dates="{
                                  to: priorstay.enteredDate,
                                  from: new Date(),
                                }"
                                v-model="priorstay.departedDate"
                                placeholder="MM/DD/YYYY"
                              ></datepicker>
                              -->
                              <date-picker-field
                              
                              :validationRequired="false"
                              :disabled-dates="{
                                  to: priorstay.enteredDate,
                                  from: new Date(),
                                }"

                                :disabled="priorstay.enteredDate === null" v-model="priorstay.departedDate" formscope="beneficiaryInfoform" :fieldname="'departDate'+index" label="Date Departed" />
                              <span
                                class="text-danger text-sm"
                                v-show="
                                  errors.has(
                                    'beneficiaryInfoform.departDate' + index
                                  )
                                "
                                >{{
                                  errors.first(
                                    "beneficiaryInfoform.departDate" + index
                                  )
                                }}</span
                              >
                            </div>
                          </div>
                          <div class="vx-col md:w-1/3 w-full">
                            <div class="form_group">
                              <label class="form_label">Case Status</label>
                              <vs-input
                                :disabled="priorstay.enteredDate === null"
                                v-validate="{
                                  required:
                                    priorstay.enteredDate != null &&
                                    !priorstay.visaStatus,
                                }"
                                v-model="priorstay.visaStatus"
                                class="w-full"
                                data-vv-as="Case Status"
                                :name="'selectVisaStatus' + index"
                              />
                              <span
                                class="text-danger text-sm"
                                v-show="
                                  errors.has(
                                    'beneficiaryInfoform.selectVisaStatus' +
                                      index
                                  )
                                "
                                >{{
                                  errors.first(
                                    "beneficiaryInfoform.selectVisaStatus" +
                                      index
                                  )
                                }}</span
                              >
                            </div>
                          </div>
                          <div
                            class="delete"
                            v-if="priorPeriodOfStayInUS.length > 1"
                          >
                            <a @click="removepriorstay(index)">
                              <img
                                src="@/assets/images/main/delete-row-img.svg"
                              />
                            </a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </vs-col>
                <vs-col
                  class="m-auto float-none"
                  vs-type="flex"
                  vs-align="center"
                  vs-lg="8"
                  vs-sm="12"
                >
                  <a @click="addpriorstay" class="add-more ml-0" type="filled">
                    <span>+</span> More
                  </a>
                </vs-col>
              </template>
            </form>
          </tab-content>

          

          <!-- tab 4 content -->
          <tab-content
            title="Documents"
            :before-change="beforedocumentsTabSwitch"
          >

             <caseQuestionnaireDocs :questionnaireDetails="questionnaireDetails" :tempDocuments="documents" />
            <form v-if="false" data-vv-scope="documentsInfoform" @submit.prevent>
              <vs-col class="w-full p-0">
                <vs-alert
                  color="warning"
                  class="warning-alert top-warning-alert"
                  icon-pack="IntakePortal"
                  icon="IP-information-button"
                  active="true"
                >
                  <p>Documents Needed</p>
                  <ul class="uploaded-list">
                    <li v-if="checkTemplateField('docs_passport')">
                      <label> {{ "passport" | formatdoctype }} </label>
                    </li>
                    <li v-if="checkTemplateField('docs_passport_visa_i94')">
                      <label> {{ "passportVisaI94" | formatdoctype }} </label>
                    </li>

                    <li v-if="checkTemplateField('docs_form_i20_ead')">
                      <label>{{ "formI20" | formatdoctype }}</label>
                    </li>
                    <li v-if="checkTemplateField('docs_prior_form_i797')">
                      <label>{{ "priorFormI797" | formatdoctype }}</label>
                    </li>

                    <li v-if="checkTemplateField('docs_education')">
                      <label>{{ "education" | formatdoctype }} </label>
                    </li>

                    <li v-if="checkTemplateField('docs_form_i94')">
                      <label>{{ "formI94" | formatdoctype }}</label>
                    </li>

                    <li v-if="checkTemplateField('docs_resume')">
                      <label>{{ "resume" | formatdoctype }}</label>
                    </li>

                    <li v-if="checkTemplateField('docs_exp_letters')">
                      <label>{{ "expLetters" | formatdoctype }}</label>
                    </li>

                    <li v-if="checkTemplateField('docs_offer_letters')">
                      <label>{{ "offerLetter" | formatdoctype }} </label>
                    </li>

                    <li v-if="checkTemplateField('docs_employment_agreement')">
                      <label>{{ "employmentAgreement" | formatdoctype }}</label>
                    </li>

                    <li v-if="checkTemplateField('docs_ins_notices')">
                      <label>{{ "INSNotices" | formatdoctype }}</label>
                    </li>

                    <li v-if="checkTemplateField('docs_ssc_licence')">
                      <label
                        >Social security card and state professional
                        license</label
                      >
                    </li>
                    <li v-if="checkTemplateField('docs_ead')">
                      <label>EADs (if on OPT or STEM OPT Extension)</label>
                    </li>

                    <li v-if="checkTemplateField('docs_paystubs')">
                      <label>Three Recent Pay Stubs </label>
                    </li>

                     <li v-if="checkTemplateField('docs_I797NoticeofApprovalforI140')">
                      <label>{{  "I797NoticeofApprovalforI140" | formatdoctype }} </label>
                    </li>

                    <li v-if="checkTemplateField('docs_client_letters')">
                      <label>{{ "clientLetter" | formatdoctype }}</label>
                    </li>

                    <li v-if="checkTemplateField('docs_vendor_letters')">
                      <label>{{ "vendorLetter" | formatdoctype }}</label>
                    </li>

                    <li v-if="checkTemplateField('docs_msa')">
                      <label>{{ "msa" | formatdoctype }}</label>
                    </li>

                    <li
                      v-if="checkTemplateField('docs_h1b_reg_selection_notice')"
                    >
                      <label>{{
                        "h1bRegSelectionNotice" | formatdoctype
                      }}</label>
                    </li>

                    <li v-if="checkTemplateField('docs_prime_vendor')">
                      <label>{{ "primeVendor" | formatdoctype }}</label>
                    </li>

                    <li v-if="checkTemplateField('docs_other')">
                      <label>Other documents, if any</label>
                    </li>

                    <li v-if="checkTemplateField('docs_po')">
                      <label>PO</label>
                    </li>
                  </ul>
                </vs-alert>
              </vs-col>

              <vs-col
                class="m-auto float-none pt-12"
                vs-type="flex"
                vs-justify="center"
                vs-align="center"
                vs-lg="8"
                vs-sm="12"
              >
                <div class="form-container w-full">
                  <div class="vx-row documents_group">
                    <h3 class="small-header">
                      List of documents needs to be updated
                      <span class="file-type">
                        (File Type: PDF, DOC, JPEG, PNG. Max file size: 1MB)
                      </span>
                    </h3>

                    <div
                      class="vx-col w-full"
                      v-if="checkTemplateField('docs_passport')"
                    >
                      <label class="custom-label">
                        {{ "passport" | formatdoctype }} <em>*</em>
                      </label>

                     

                      <file-upload
                        v-model="documents.passport"
                        class="file-upload-input"
                        name="bendocsPassport"
                        data-vv-as="Passport- First page with photo and last page with address"
                        accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                        :multiple="true"
                        ref="bendocsPassport"
                        v-validate="'required|docsValidate'"
                        :hideSelected="true"
                        @input="upload(documents.passport)"
                      >
                        <img
                          class="file-icon"
                          src="@/assets/images/main/file-upload.svg"
                        />
                        Upload
                      </file-upload>

                      <span
                        class="text-danger text-sm-doc"
                        v-show="errors.has('documentsInfoform.bendocsPassport')"
                        >{{
                          errors.first("documentsInfoform.bendocsPassport")
                        }}</span
                      >
                      <ul class="uploaded-list">
                        <template v-for="(item, index) in documents.passport">
                          <vs-chip
                            @click="remove(item, documents.passport)"
                            :key="index"
                            closable
                            v-if="item.status !== false"
                          >
                            {{ item.name }}
                          </vs-chip>
                        </template>
                      </ul>
                    </div>

                    <div
                      class="vx-col w-full"
                      v-if="checkTemplateField('docs_passport_visa_i94')"
                    >
                      <label class="custom-label">
                        {{ "passportVisaI94" | formatdoctype }} <em>*</em>
                      </label>
                      <file-upload
                        v-model="documents.passportVisaI94"
                        class="file-upload-input"
                        name="benpassportVisaI94Document"
                        v-validate="'required|docsValidate'"
                        data-vv-as="Passport, along with Visa and Form I-94 (clearly showing the dates of
                    first and last entry into the United States)"
                        accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                        :multiple="true"
                        :hideSelected="true"
                        @input="upload(documents.passportVisaI94)"
                      >
                        <img
                          class="file-icon"
                          src="@/assets/images/main/file-upload.svg"
                        />
                        Upload
                      </file-upload>

                      <span
                        class="text-danger text-sm-doc"
                        v-show="
                          errors.has(
                            'documentsInfoform.benpassportVisaI94Document'
                          )
                        "
                        >{{ "passportVisaI94" | formatdoctype }} is
                        required</span
                      >
                      <ul class="uploaded-list">
                        <template
                          v-for="(item, index) in documents.passportVisaI94"
                        >
                          <vs-chip
                            @click="remove(item, documents.passportVisaI94)"
                            :key="index"
                            closable
                            v-if="item.status !== false"
                          >
                            {{ item.name }}
                          </vs-chip>
                        </template>
                      </ul>
                    </div>

                 
                    <div
                      class="vx-col w-full"
                      v-if="checkTemplateField('docs_education')"
                    >
                      <label class="custom-label"
                        >{{ "education" | formatdoctype }} <em>*</em></label
                      >
                      <file-upload
                        v-validate="'required|docsValidate'"
                        v-model="documents.education"
                        class="file-upload-input"
                        accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                        name="educationDocument"
                        data-vv-as="Master’s/ Bachelor’s degree certificate, transcripts, 12th and 10th certificates"
                        :multiple="true"
                        :hideSelected="true"
                        @input="upload(documents.education)"
                      >
                        <img
                          class="file-icon"
                          src="@/assets/images/main/file-upload.svg"
                        />
                        Upload
                      </file-upload>

                      <span
                        class="text-danger text-sm-doc"
                        v-show="
                          errors.has('documentsInfoform.educationDocument')
                        "
                        >{{ "education" | formatdoctype }} is required</span
                      >
                      <ul class="uploaded-list">
                        <template v-for="(item, index) in documents.education">
                          <vs-chip
                            @click="remove(item, documents.education)"
                            :key="index"
                            closable
                            v-if="item.status !== false"
                          >
                            {{ item.name }}
                          </vs-chip>
                        </template>
                      </ul>
                    </div>

                       <div
                      class="vx-col w-full"
                      v-if="checkTemplateField('docs_prior_form_i797')"
                    >
                      <label class="custom-label"
                        >{{ "priorFormI797" | formatdoctype }}</label
                      >
                      <file-upload
                        v-model="documents.priorFormI797"
                        class="file-upload-input"
                        v-validate="'docsValidate'"
                        name="docs_prior_form_i797"
                        data-vv-as="All prior I-797, Notice of Approvals granting H-1B status"
                        :multiple="true"
                        :hideSelected="true"
                        accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                        @input="upload(documents.priorFormI797)"
                      >
                        <img
                          class="file-icon"
                          src="@/assets/images/main/file-upload.svg"
                        />
                        Upload
                      </file-upload>

                      <span
                        class="text-danger text-sm-doc"
                        v-show="
                          errors.has('documentsInfoform.docs_prior_form_i797')
                        "
                        >{{
                          errors.first("documentsInfoform.docs_prior_form_i797")
                        }}</span
                      >
                      <ul class="uploaded-list">
                        <template
                          v-for="(item, index) in documents.priorFormI797"
                        >
                          <vs-chip
                            @click="remove(item, documents.priorFormI797)"
                            :key="index"
                            closable
                            v-if="item.status !== false"
                          >
                            {{ item.name }}
                          </vs-chip>
                        </template>
                      </ul>
                    </div>

                    <div
                      class="vx-col w-full"
                      v-if="checkTemplateField('docs_paystubs')"
                    >
                      <label class="custom-label"
                        >Three Recent Pay Stubs </label
                      >
                      <file-upload
                        v-model="documents.payStubs"
                        class="file-upload-input"
                        name="payStubs"
                        v-validate="'docsValidate'"
                        data-vv-as="Three Recent Pay Stubs"
                        :multiple="true"
                        :hideSelected="true"
                        accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                        @input="upload(documents.payStubs)"
                      >
                        <img
                          class="file-icon"
                          src="@/assets/images/main/file-upload.svg"
                        />
                        Upload
                      </file-upload>

                      <span
                        class="text-danger text-sm-doc"
                        v-show="errors.has('documentsInfoform.payStubs')"
                        >{{ errors.first("documentsInfoform.payStubs") }}</span
                      >
                      <ul class="uploaded-list">
                        <template v-for="(item, index) in documents.payStubs">
                          <vs-chip
                            @click="remove(item, documents.payStubs)"
                            :key="index"
                            closable
                            v-if="item.status !== false"
                          >
                            {{ item.name }}
                          </vs-chip>
                        </template>
                      </ul>
                    </div>

                     <div
                      class="vx-col w-full"
                      v-if="checkTemplateField('docs_form_i94')"
                    >
                      <label class="custom-label"
                        >{{ "formI94" | formatdoctype }} </label
                      >
                      <file-upload
                        v-model="documents.formI94"
                        class="file-upload-input"
                        name="docs_form_i94"
                        v-validate="'required|docsValidate'"
                        data-vv-as="Form I-94"
                        :multiple="true"
                        :hideSelected="true"
                        accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                        @input="upload(documents.formI94)"
                      >
                        <img
                          class="file-icon"
                          src="@/assets/images/main/file-upload.svg"
                        />
                        Upload
                      </file-upload>

                      <span
                        class="text-danger text-sm-doc"
                        v-show="errors.has('documentsInfoform.docs_form_i94')"
                        >{{
                          errors.first("documentsInfoform.docs_form_i94")
                        }}</span
                      >
                      <ul class="uploaded-list">
                        <template v-for="(item, index) in documents.formI94">
                          <vs-chip
                            @click="remove(item, documents.formI94)"
                            :key="index"
                            closable
                            v-if="item.status !== false"
                          >
                            {{ item.name }}
                          </vs-chip>
                        </template>
                      </ul>
                    </div>


                    <div
                      class="vx-col w-full"
                      v-if="checkTemplateField('docs_ead')"
                    >
                      <label class="custom-label"
                        >EADs (if on OPT or STEM OPT Extension)
                        </label
                      >
                      <file-upload
                        v-model="documents.ead"
                        class="file-upload-input"
                        name="ead"
                       
                        data-vv-as="EADs (if on OPT or STEM OPT Extension)"
                        :multiple="true"
                        :hideSelected="true"
                        accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                        @input="upload(documents.ead)"
                      >
                        <img
                          class="file-icon"
                          src="@/assets/images/main/file-upload.svg"
                        />
                        Upload
                      </file-upload>

                      <span
                        class="text-danger text-sm-doc"
                        v-show="errors.has('documentsInfoform.ead')"
                        >{{ errors.first("documentsInfoform.ead") }}</span
                      >
                      <ul class="uploaded-list">
                        <template v-for="(item, index) in documents.ead">
                          <vs-chip
                            @click="remove(item, documents.ead)"
                            :key="index"
                            closable
                            v-if="item.status !== false"
                          >
                            {{ item.name }}
                          </vs-chip>
                        </template>
                      </ul>
                    </div>


                   
                    <div
                      class="vx-col w-full"
                      v-if="checkTemplateField('docs_form_i20_ead')"
                    >
                      <label class="custom-label">{{
                        "formI20" | formatdoctype
                      }}</label>
                      <file-upload
                        v-model="documents.formI20"
                        class="file-upload-input"
                        name="formI20Document"
                        data-vv-as="INS Notices"
                        :multiple="true"
                        :hideSelected="true"
                        accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                        @input="upload(documents.formI20)"
                      >
                        <img
                          class="file-icon"
                          src="@/assets/images/main/file-upload.svg"
                        />
                        Upload
                      </file-upload>

                      <span
                        class="text-danger text-sm-doc"
                        v-show="errors.has('documentsInfoform.formI20Document')"
                        >{{ "formI20" | formatdoctype }} is required</span
                      >
                      <ul class="uploaded-list">
                        <template v-for="(item, index) in documents.formI20">
                          <vs-chip
                            @click="remove(item, documents.formI20)"
                            :key="index"
                            closable
                            v-if="item.status !== false"
                          >
                            {{ item.name }}
                          </vs-chip>
                        </template>
                      </ul>
                    </div>



                      <div
                      class="vx-col w-full"
                      v-if="checkTemplateField('docs_I797NoticeofApprovalforI140')"
                    >
                      <label class="custom-label">{{
                        "I797NoticeofApprovalforI140" | formatdoctype
                      }}</label>
                      <file-upload
                        v-model="documents.I797NoticeofApprovalforI140"
                        class="file-upload-input"
                        name="I797NoticeofApprovalforI140"
                        data-vv-as="I-797 Notice-of Approvalfor I-140"
                        :multiple="true"
                        :hideSelected="true"
                        accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                        @input="upload(documents.I797NoticeofApprovalforI140)"
                      >
                        <img
                          class="file-icon"
                          src="@/assets/images/main/file-upload.svg"
                        />
                        Upload
                      </file-upload>

                      <span
                        class="text-danger text-sm-doc"
                        v-show="errors.has('documentsInfoform.formI20Document')"
                        >{{ "I797NoticeofApprovalforI140" | formatdoctype }} is required</span
                      >
                      <ul class="uploaded-list">
                        <template v-for="(item, index) in documents.I797NoticeofApprovalforI140">
                          <vs-chip
                            @click="remove(item, documents.I797NoticeofApprovalforI140)"
                            :key="index"
                            closable
                            v-if="item.status !== false"
                          >
                            {{ item.name }}
                          </vs-chip>
                        </template>
                      </ul>
                    </div>


                    <div
                      class="vx-col w-full"
                      v-if="checkTemplateField('docs_resume')"
                    >
                      <label class="custom-label">{{
                        "resume" | formatdoctype
                      }}</label>
                      <file-upload
                        v-model="documents.resume"
                        class="file-upload-input"
                        accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                        name="resumeDocument"
                        data-vv-as="Resume"
                        :multiple="true"
                        :hideSelected="true"
                        @input="upload(documents.resume)"
                      >
                        <img
                          class="file-icon"
                          src="@/assets/images/main/file-upload.svg"
                        />
                        Upload
                      </file-upload>

                      <span
                        class="text-danger text-sm-doc"
                        v-show="errors.has('documentsInfoform.resumeDocument')"
                        >{{
                          errors.first("documentsInfoform.resumeDocument")
                        }}</span
                      >
                      <ul class="uploaded-list">
                        <template v-for="(item, index) in documents.resume">
                          <vs-chip
                            @click="remove(item, documents.resume)"
                            :key="index"
                            closable
                            v-if="item.status !== false"
                          >
                            {{ item.name }}
                          </vs-chip>
                        </template>
                      </ul>
                    </div>

                    <div
                      class="vx-col w-full"
                      v-if="checkTemplateField('docs_exp_letters')"
                    >
                      <label class="custom-label">{{
                        "expLetters" | formatdoctype
                      }}</label>
                      <file-upload
                        v-model="documents.expLetters"
                        class="file-upload-input"
                        name="experienceDocument"
                        accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                        data-vv-as="Experience Letters"
                        :multiple="true"
                        :hideSelected="true"
                        @input="upload(documents.expLetters)"
                      >
                        <img
                          class="file-icon"
                          src="@/assets/images/main/file-upload.svg"
                        />
                        Upload
                      </file-upload>

                      <span
                        class="text-danger text-sm-doc"
                        v-show="
                          errors.has('documentsInfoform.experienceDocument')
                        "
                        >{{
                          errors.first("documentsInfoform.experienceDocument")
                        }}</span
                      >
                      <ul class="uploaded-list">
                        <template v-for="(item, index) in documents.expLetters">
                          <vs-chip
                            @click="remove(item, documents.expLetters)"
                            :key="index"
                            closable
                            v-if="item.status !== false"
                          >
                            {{ item.name }}
                          </vs-chip>
                        </template>
                      </ul>
                    </div>

                    <div
                      class="vx-col w-full"
                      v-if="checkTemplateField('docs_offer_letters')"
                    >
                      <label class="custom-label"
                        >{{ "offerLetter" | formatdoctype }}
                      </label>
                      <file-upload
                        v-model="documents.offerLetter"
                        class="file-upload-input"
                        name="offerLetter"
                        data-vv-as="INS Notices"
                        :multiple="true"
                        :hideSelected="true"
                        accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                        @input="upload(documents.offerLetter)"
                      >
                        <img
                          class="file-icon"
                          src="@/assets/images/main/file-upload.svg"
                        />
                        Upload
                      </file-upload>

                      <span
                        class="text-danger text-sm-doc"
                        v-show="errors.has('documentsInfoform.offerLetter')"
                        >{{
                          errors.first("documentsInfoform.offerLetter")
                        }}</span
                      >
                      <ul class="uploaded-list">
                        <template
                          v-for="(item, index) in documents.offerLetter"
                        >
                          <vs-chip
                            @click="remove(item, documents.offerLetter)"
                            :key="index"
                            closable
                            v-if="item.status !== false"
                          >
                            {{ item.name }}
                          </vs-chip>
                        </template>
                      </ul>
                    </div>
                    <div
                      class="vx-col w-full"
                      v-if="checkTemplateField('docs_employment_agreement')"
                    >
                      <label class="custom-label">{{
                        "employmentAgreement" | formatdoctype
                      }}</label>
                      <file-upload
                        v-model="documents.employmentAgreement"
                        class="file-upload-input"
                        name="docs_employment_agreement"
                        data-vv-as="Employment Agreement"
                        :multiple="true"
                        :hideSelected="true"
                        accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                        @input="upload(documents.employmentAgreement)"
                      >
                        <img
                          class="file-icon"
                          src="@/assets/images/main/file-upload.svg"
                        />
                        Upload
                      </file-upload>

                      <span
                        class="text-danger text-sm-doc"
                        v-show="
                          errors.has(
                            'documentsInfoform.docs_employment_agreement'
                          )
                        "
                        >{{
                          errors.first(
                            "documentsInfoform.docs_employment_agreement"
                          )
                        }}</span
                      >
                      <ul class="uploaded-list">
                        <template
                          v-for="(item, index) in documents.employmentAgreement"
                        >
                          <vs-chip
                            @click="remove(item, documents.employmentAgreement)"
                            :key="index"
                            closable
                            v-if="item.status !== false"
                          >
                            {{ item.name }}
                          </vs-chip>
                        </template>
                      </ul>
                    </div>
                    <div
                      class="vx-col w-full"
                      v-if="checkTemplateField('docs_ins_notices')"
                    >
                      <label class="custom-label">{{
                        "INSNotices" | formatdoctype
                      }}</label>
                      <file-upload
                        v-model="documents.INSNotices"
                        class="file-upload-input"
                        name="insNoticeDocument"
                        data-vv-as="INS Notices"
                        :multiple="true"
                        :hideSelected="true"
                        accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                        @input="upload(documents.INSNotices)"
                      >
                        <img
                          class="file-icon"
                          src="@/assets/images/main/file-upload.svg"
                        />
                        Upload
                      </file-upload>

                      <span
                        class="text-danger text-sm-doc"
                        v-show="
                          errors.has('documentsInfoform.insNoticeDocument')
                        "
                        >{{
                          errors.first("documentsInfoform.insNoticeDocument")
                        }}</span
                      >
                      <ul class="uploaded-list">
                        <template v-for="(item, index) in documents.INSNotices">
                          <vs-chip
                            @click="remove(item, documents.INSNotices)"
                            :key="index"
                            closable
                            v-if="item.status !== false"
                          >
                            {{ item.name }}
                          </vs-chip>
                        </template>
                      </ul>
                    </div>

                    <div
                      class="vx-col w-full"
                      v-if="checkTemplateField('docs_ssc_licence')"
                    >
                      <label class="custom-label"
                        >Social security card and state professional
                        license</label
                      >
                      <file-upload
                        v-model="documents.socialSecurityCardAndProfLicense"
                        class="file-upload-input"
                        name="socialSecurityCardAndProfLicenseDocument"
                        data-vv-as="INS Notices"
                        :multiple="true"
                        :hideSelected="true"
                        accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                        @input="
                          upload(documents.socialSecurityCardAndProfLicense)
                        "
                      >
                        <img
                          class="file-icon"
                          src="@/assets/images/main/file-upload.svg"
                        />
                        Upload
                      </file-upload>

                      <span
                        class="text-danger text-sm-doc"
                        v-show="
                          errors.has(
                            'documentsInfoform.socialSecurityCardAndProfLicenseDocument'
                          )
                        "
                        >{{
                          errors.first(
                            "documentsInfoform.socialSecurityCardAndProfLicenseDocument"
                          )
                        }}</span
                      >
                      <ul class="uploaded-list">
                        <template
                          v-for="(
                            item, index
                          ) in documents.socialSecurityCardAndProfLicense"
                        >
                          <vs-chip
                            @click="
                              remove(
                                item,
                                documents.socialSecurityCardAndProfLicense
                              )
                            "
                            v-if="item.status !== false"
                            :key="index"
                            closable
                          >
                            {{ item.name }}
                          </vs-chip>
                        </template>
                      </ul>
                    </div>

                    <!-- Client Letters -->
                    <div
                      class="vx-col w-full"
                      v-if="checkTemplateField('docs_client_letters')"
                    >
                      <label class="custom-label">{{
                        "clientLetter" | formatdoctype
                      }}</label>
                      <file-upload
                        v-model="documents.clientLetter"
                        class="file-upload-input"
                        name="clientLetter"
                        data-vv-as="INS Notices"
                        :multiple="true"
                        :hideSelected="true"
                        accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                        @input="upload(documents.clientLetter)"
                      >
                        <img
                          class="file-icon"
                          src="@/assets/images/main/file-upload.svg"
                        />
                        Upload
                      </file-upload>

                      <span
                        class="text-danger text-sm-doc"
                        v-show="errors.has('documentsInfoform.clientLetter')"
                        >{{
                          errors.first("documentsInfoform.clientLetter")
                        }}</span
                      >
                      <ul class="uploaded-list">
                        <template
                          v-for="(item, index) in documents.clientLetter"
                        >
                          <vs-chip
                            @click="remove(item, documents.clientLetter)"
                            :key="index"
                            closable
                            v-if="item.status !== false"
                          >
                            {{ item.name }}
                          </vs-chip>
                        </template>
                      </ul>
                    </div>
                    <!--vendorLetter--->
                    <div
                      class="vx-col w-full"
                      v-if="checkTemplateField('docs_vendor_letters')"
                    >
                      <label class="custom-label">{{
                        "vendorLetter" | formatdoctype
                      }}</label>
                      <file-upload
                        v-model="documents.vendorLetter"
                        class="file-upload-input"
                        name="vendorLetter"
                        data-vv-as="INS Notices"
                        :multiple="true"
                        :hideSelected="true"
                        accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                        @input="upload(documents.vendorLetter)"
                      >
                        <img
                          class="file-icon"
                          src="@/assets/images/main/file-upload.svg"
                        />
                        Upload
                      </file-upload>

                      <span
                        class="text-danger text-sm-doc"
                        v-show="errors.has('documentsInfoform.vendorLetter')"
                        >{{
                          errors.first("documentsInfoform.vendorLetter")
                        }}</span
                      >
                      <ul class="uploaded-list">
                        <template
                          v-for="(item, index) in documents.vendorLetter"
                        >
                          <vs-chip
                            @click="remove(item, documents.vendorLetter)"
                            :key="index"
                            closable
                            v-if="item.status !== false"
                          >
                            {{ item.name }}
                          </vs-chip>
                        </template>
                      </ul>
                    </div>
                    <!--msa--->
                    <div
                      class="vx-col w-full"
                      v-if="checkTemplateField('docs_msa')"
                    >
                      <label class="custom-label">{{
                        "msa" | formatdoctype
                      }}</label>
                      <file-upload
                        v-model="documents.msa"
                        class="file-upload-input"
                        name="msa"
                        data-vv-as="INS Notices"
                        :multiple="true"
                        :hideSelected="true"
                        accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                        @input="upload(documents.msa)"
                      >
                        <img
                          class="file-icon"
                          src="@/assets/images/main/file-upload.svg"
                        />
                        Upload
                      </file-upload>

                      <span
                        class="text-danger text-sm-doc"
                        v-show="errors.has('documentsInfoform.msa')"
                        >{{ errors.first("documentsInfoform.msa") }}</span
                      >
                      <ul class="uploaded-list">
                        <template v-for="(item, index) in documents.msa">
                          <vs-chip
                            @click="remove(item, documents.msa)"
                            :key="index"
                            closable
                            v-if="item.status !== false"
                          >
                            {{ item.name }}
                          </vs-chip>
                        </template>
                      </ul>
                    </div>

                    <!--po--->
                    <div
                      class="vx-col w-full"
                      v-if="checkTemplateField('docs_po')"
                    >
                      <label class="custom-label">PO</label>
                      <file-upload
                        v-model="documents.po"
                        class="file-upload-input"
                        name="po"
                        data-vv-as="INS Notices"
                        :multiple="true"
                        :hideSelected="true"
                        accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                        @input="upload(documents.po)"
                      >
                        <img
                          class="file-icon"
                          src="@/assets/images/main/file-upload.svg"
                        />
                        Upload
                      </file-upload>

                      <span
                        class="text-danger text-sm-doc"
                        v-show="errors.has('documentsInfoform.po')"
                        >{{ errors.first("documentsInfoform.po") }}</span
                      >
                      <ul class="uploaded-list">
                        <template v-for="(item, index) in documents.po">
                          <vs-chip
                            @click="remove(item, documents.po)"
                            :key="index"
                            closable
                            v-if="item.status !== false"
                          >
                            {{ item.name }}
                          </vs-chip>
                        </template>
                      </ul>
                    </div>

                    <!-----NEW DOCUMENTS---->
                    <div
                      class="vx-col w-full"
                      v-if="checkTemplateField('docs_h1b_reg_selection_notice')"
                    >
                      <label class="custom-label">{{
                        "h1bRegSelectionNotice" | formatdoctype
                      }}</label>
                      <file-upload
                        v-model="documents.h1bRegSelectionNotice"
                        class="file-upload-input"
                        name="docs_h1b_reg_selection_notice"
                        data-vv-as="H-1B Registration Selection Notice"
                        :multiple="true"
                        :hideSelected="true"
                        accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                        @input="upload(documents.h1bRegSelectionNotice)"
                      >
                        <img
                          class="file-icon"
                          src="@/assets/images/main/file-upload.svg"
                        />
                        Upload
                      </file-upload>

                      <span
                        class="text-danger text-sm-doc"
                        v-show="
                          errors.has(
                            'documentsInfoform.docs_h1b_reg_selection_notice'
                          )
                        "
                        >{{
                          errors.first(
                            "documentsInfoform.docs_h1b_reg_selection_notice"
                          )
                        }}</span
                      >
                      <ul class="uploaded-list">
                        <template
                          v-for="(
                            item, index
                          ) in documents.h1bRegSelectionNotice"
                        >
                          <vs-chip
                            @click="
                              remove(item, documents.h1bRegSelectionNotice)
                            "
                            :key="index"
                            closable
                            v-if="item.status !== false"
                          >
                            {{ item.name }}
                          </vs-chip>
                        </template>
                      </ul>
                    </div>

                    <div
                      class="vx-col w-full"
                      v-if="checkTemplateField('docs_prime_vendor')"
                    >
                      <label class="custom-label">{{
                        "primeVendor" | formatdoctype
                      }}</label>
                      <file-upload
                        v-model="documents.primeVendor"
                        class="file-upload-input"
                        name="docs_prime_vendor"
                        data-vv-as="Prime Vendor Letter"
                        :multiple="true"
                        :hideSelected="true"
                        accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                        @input="upload(documents.primeVendor)"
                      >
                        <img
                          class="file-icon"
                          src="@/assets/images/main/file-upload.svg"
                        />
                        Upload
                      </file-upload>

                      <span
                        class="text-danger text-sm-doc"
                        v-show="
                          errors.has('documentsInfoform.docs_prime_vendor')
                        "
                        >{{
                          errors.first("documentsInfoform.docs_prime_vendor")
                        }}</span
                      >
                      <ul class="uploaded-list">
                        <template
                          v-for="(item, index) in documents.primeVendor"
                        >
                          <vs-chip
                            @click="remove(item, documents.primeVendor)"
                            :key="index"
                            closable
                            v-if="item.status !== false"
                          >
                            {{ item.name }}
                          </vs-chip>
                        </template>
                      </ul>
                    </div>

                    <!----NEW DOCUMENTS END--->
                    <div
                      class="vx-col w-full"
                      v-if="checkTemplateField('docs_other')"
                    >
                      <label class="custom-label"
                        >Other Documents, if any</label
                      >
                      <file-upload
                        v-model="documents.other"
                        class="file-upload-input"
                        name="otherDocument"
                        data-vv-as="INS Notices"
                        :multiple="true"
                        :hideSelected="true"
                        accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                        @input="upload(documents.other)"
                      >
                        <img
                          class="file-icon"
                          src="@/assets/images/main/file-upload.svg"
                        />
                        Upload
                      </file-upload>

                      <span
                        class="text-danger text-sm-doc"
                        v-show="errors.has('documentsInfoform.otherDocument')"
                        >{{
                          errors.first("documentsInfoform.otherDocument")
                        }}</span
                      >
                      <ul class="uploaded-list">
                        <template v-for="(item, index) in documents.other">
                          <vs-chip
                            @click="remove(item, documents.other)"
                            v-if="item.status !== false"
                            :key="index"
                            closable
                          >
                            {{ item.name }}
                          </vs-chip>
                        </template>
                      </ul>
                    </div>
                  </div>
                </div>
              </vs-col>
              <div
                class="text-danger text-sm formerrors"
                v-show="formerrors.msg"
              >
                <vs-alert
                  color="warning"
                  class="warning-alert reg-warning-alert no-border-radius"
                  icon-pack="IntakePortal"
                  icon="IP-information-button"
                  active="true"
                  >{{ formerrors.msg }}</vs-alert
                >
              </div>
            </form>
          </tab-content>

          <!-- tab 2 content 
        v-if="checkTemplateField('child_h4_required') || checkTemplateField('spouse_h4_required') " checkTemplateField('child_h4_required')
        -->
          <tab-content
            title="Dependents Info"
            v-if="
              [5, 8].indexOf(petition.subTypeDetails.id) < 0 &&
              (checkTemplateField('child_h4_required') ||
                checkTemplateField('spouse_h4_required')) &&
              checkProperty(beneficiaryInfo, 'maritalStatus') &&
              checkProperty(beneficiaryInfo, 'maritalStatus', 'id') &&
              checkProperty(beneficiaryInfo, 'maritalStatus', 'id') !== 1
            "
            :before-change="beforeDependents"
          >
            <form
              data-vv-scope="dependentsInfoform"
              @submit.prevent=""
              @keydown.enter.prevent=""
            >
              <vs-col class="w-full p-0">
                <vs-alert
                  color="warning"
                  class="warning-alert top-warning-alert"
                  icon-pack="IntakePortal"
                  icon="IP-information-button"
                  active="true"
                >
                  <p>
                    Your spouse and children will need to apply for H-4 status
                    (only if they are currently in the USA on a valid status),
                    or an extension of their current H-4 status.
                  </p>
                  <p>
                    That their status must be extended through a separate
                    application, and is not automatically extended upon approval
                    of the H-1B petition.
                  </p>
                </vs-alert>
              </vs-col>

              <div
                class="spousedetails"
                v-if="
                  checkProperty(beneficiaryInfo, 'maritalStatus', 'id') == 2
                "
              >
                <vs-col
                  class="m-auto pt-4 float-none"
                  vs-type="flex"
                  vs-lg="8"
                  vs-sm="12"
                  v-if="checkTemplateField('spouse_h4_required')"
                >
                  <div class="alert-content-block pb-3">
                    <p>H4 required for spouse?</p>

                    <div class="form_radio_btns">
                      <vs-button
                        class="mr-5 yes"
                        v-bind:class="{
                          'cactive ': dependentsInfo.spouse.h4Required == true,
                        }"
                        @click="dependentsInfo.spouse.h4Required = true"
                        color="success"
                        type="border"
                        >Yes</vs-button
                      >
                      <vs-button
                      class="no"
                        v-bind:class="{
                          cactive: dependentsInfo.spouse.h4Required == false,
                        }"
                        @click="dependentsInfo.spouse.h4Required = false"
                        color="danger"
                        type="border"
                        >No</vs-button
                      >
                    </div>
                  </div>
                </vs-col>
                <div
                  v-if="
                    dependentsInfo.spouse.h4Required &&
                    dependentsInfo.spouse.h4Required == true
                  "
                >
                  <div
                    class="divider"
                    v-if="
                      dependentsInfo.spouse.h4Required &&
                      dependentsInfo.spouse.h4Required == true &&
                      checkTemplateField('spouse_h4_required') &&
                      checkTemplateField('spouse_h4_ead_required')
                    "
                  ></div>
                  <vs-col
                    v-if="
                      dependentsInfo.spouse.h4Required &&
                      dependentsInfo.spouse.h4Required == true &&
                      checkTemplateField('spouse_h4_required') &&
                      checkTemplateField('spouse_h4_ead_required')
                    "
                    class="m-auto float-none"
                    vs-type="flex"
                    vs-lg="8"
                    vs-sm="12"
                  >
                    <div class="alert-content-block pt-2 pb-3">
                      <p>H4 EAD required for spouse?</p>
                      <div class="form_radio_btns yes">
                        <vs-button
                         
                          v-bind:class="{
                            cactive:
                              dependentsInfo.spouse.h4Required === true &&
                              dependentsInfo.spouse.h4EADRequired === true,
                          }"
                          @click="
                            setH4EADValue(
                              dependentsInfo.spouse.h4Required,
                              true
                            )
                          "
                          class="mr-5 yes"
                          color="success"
                          type="border"
                          >Yes
                        </vs-button>
                        <vs-button
                         class="no"
                          v-bind:class="{
                            cactive:
                              dependentsInfo.spouse.h4Required === true &&
                              dependentsInfo.spouse.h4EADRequired === false,
                          }"
                          @click="
                            setH4EADValue(
                              dependentsInfo.spouse.h4Required,
                              false
                            )
                          "
                          color="danger"
                          type="border"
                          >No</vs-button
                        >
                      </div>
                    </div>
                  </vs-col>
                  <div
                    class="divider"
                    v-if="
                      checkTemplateField('spouse_h4_required') ||
                      checkTemplateField('spouse_h4_ead_required')
                    "
                  ></div>

                  <template
                    v-if="
                      checkTemplateField('spouse_first_name') ||
                      checkTemplateField('spouse_middle_name') ||
                      checkTemplateField('spouse_last_name') ||
                      checkTemplateField('spouse_email') ||
                      checkTemplateField('spouse_phone_number') ||
                      checkTemplateField('spouse_dob') ||
                      checkTemplateField('spouse_cob')
                     || checkTemplateField('spouse_provinceOfBirth')
                     || checkTemplateField('spouse_locationOfBirth') 
                    "
                  >
                    <vs-col
                      class="m-auto float-none"
                      vs-type="flex"
                      vs-justify="center"
                      vs-align="center"
                      vs-lg="8"
                      vs-sm="12"
                    >
                      <div class="form-container">
                        <div class="vx-row">
                          <template
                            v-if="
                              checkTemplateField('spouse_first_name') ||
                              checkTemplateField('spouse_middle_name') ||
                              checkTemplateField('spouse_last_name')
                            "
                          >
                            <div class="vx-col w-full">
                              <vx-input-group class="form-input-group">
                                <div
                                  class="form_group w-full"
                                  v-if="checkTemplateField('spouse_first_name')"
                                >
                                  <label class="form_label"
                                    >First Name<em>*</em></label
                                  >
                                  <vs-input
                                    class="w-full"
                                    data-vv-as="First Name"
                                    name="firstName"
                                    v-model="dependentsInfo.spouse.firstName"
                                    v-validate="'required'"
                                  />
                                </div>
                                <div
                                  class="form_group w-full"
                                  v-if="
                                    checkTemplateField('spouse_middle_name')
                                  "
                                >
                                  <label class="form_label">Middle Name</label>
                                  <vs-input
                                    class="w-full"
                                    data-vv-as="Middle Name"
                                    name="middleName"
                                    v-model="dependentsInfo.spouse.middleName"
                                  />
                                </div>
                                <div
                                  class="form_group w-full"
                                  v-if="checkTemplateField('spouse_last_name')"
                                >
                                  <label class="form_label"
                                    >Last Name<em>*</em></label
                                  >
                                  <vs-input
                                    class="w-full"
                                    data-vv-as="Last Name"
                                    name="lastName"
                                    v-model="dependentsInfo.spouse.lastName"
                                    v-validate="'required'"
                                  />
                                </div>
                              </vx-input-group>

                              <div class="input-group-error">
                                <p
                                  class="w-1/3"
                                  v-if="checkTemplateField('spouse_first_name')"
                                >
                                  <span
                                    class="text-danger text-sm"
                                    v-show="
                                      errors.has('dependentsInfoform.firstName')
                                    "
                                    >{{
                                      errors.first(
                                        "dependentsInfoform.firstName"
                                      )
                                    }}</span
                                  >
                                </p>
                                <p
                                  class="w-1/3"
                                  v-if="
                                    checkTemplateField('spouse_middle_name')
                                  "
                                ></p>
                                <p
                                  class="w-1/3"
                                  v-if="checkTemplateField('spouse_last_name')"
                                >
                                  <span
                                    class="text-danger text-sm"
                                    v-show="
                                      errors.has('dependentsInfoform.lastName')
                                    "
                                    >{{
                                      errors.first(
                                        "dependentsInfoform.lastName"
                                      )
                                    }}</span
                                  >
                                </p>
                              </div>
                            </div>
                          </template>
                          <div
                            class="vx-col md:w-1/2 w-full"
                            v-if="checkTemplateField('spouse_email')"
                          >
                            <div class="form_group">
                              <label class="form_label"
                                >Spouse Email<em>*</em></label
                              >
                              <vs-input
                                name="SpouseEmail"
                                v-model="dependentsInfo.spouse.email"
                                v-validate="'required|email'"
                                class="w-full"
                                data-vv-as="Spouse Email"
                              />
                              <span
                                class="text-danger text-sm"
                                v-show="
                                  errors.has('dependentsInfoform.SpouseEmail')
                                "
                                >{{
                                  errors.first("dependentsInfoform.SpouseEmail")
                                }}</span
                              >
                            </div>
                          </div>

                          <div
                            class="vx-col md:w-1/2 w-full"
                            v-if="checkTemplateField('spouse_phone_number')"
                          >
                            <div class="form_group ph_number">
                              <label class="form_label"
                                >Spouse Phone Number<em>*</em></label
                              >

                              <div class="vs-component">
                                <VuePhoneNumberInput
                                  icon-pack="feather"
                                  class="w-full no-icon-border"
                                  :no-example="false"
                                  v-validate="'required'"
                                  data-vv-as="Phone Number"
                                  name="spousePhoneNumber"
                                  :default-country-code="
                                    checkProperty(
                                      dependentsInfo['spouse'][
                                        'phoneCountryCode'
                                      ],
                                      'countryCode'
                                    )
                                  "
                                  placeholder="Spouse Phone Number"
                                  :no-country-selector="false"
                                  v-bind="vuePhone.props"
                                  v-model="dependentsInfo.spouse.phoneNumber"
                                  @update="updateSpousePhone"
                                />
                              </div>
                              <span
                                class="text-danger text-sm"
                                v-if="
                                  errors.has(
                                    'dependentsInfoform.spousePhoneNumber'
                                  )
                                "
                                >{{
                                  errors.first(
                                    "dependentsInfoform.spousePhoneNumber"
                                  )
                                }}</span
                              >
                              <span
                                class="text-danger text-sm"
                                v-else-if="
                                  !isSpousePhoneValid &&
                                  !errors.has(
                                    'dependentsInfoform.spousePhoneNumber'
                                  )
                                "
                                >* Enter a valid phone number</span
                              >
                            </div>
                          </div>

                          <div
                            class="vx-col md:w-1/2 w-full"
                            v-if="checkTemplateField('spouse_dob')"
                          >
                            <div class="form_group">
                              <label class="form_label"
                                >Spouse’s Date of Birth<em>*</em></label
                              >

                      <date-picker-field :validationRequired="true" v-model="dependentsInfo.spouse.dateOfBirth" formscope="dependentsInfoform" fieldname="dateofbirth" label="Spouse’s Date of Birth" />

                        
                            </div>
                          </div>
                          <div
                            class="vx-col md:w-1/2 w-full"
                            v-if="checkTemplateField('spouse_cob')"
                          >
                            <div class="form_group">
                              <label for class="form_label"
                                >Spouse’s Country of Birth<em>*</em></label
                              >
                              <div class="con-select w-full">
                                <multiselect
                                  ref="spousecountry"
                                  name="country"
                                  v-validate="'required'"
                                  v-model="countrySelected"
                                  @select="selectspouseCountry"
                                  :show-labels="false"
                                  track-by="id"
                                  label="name"
                                  data-vv-as="Spouse’s Country of Birth"
                                  placeholder="Select Country"
                                  :options="countries"
                                  :searchable="true"
                                  :allow-empty="false"
                                ></multiselect>
                              </div>
                              <span
                                class="text-danger text-sm"
                                v-show="
                                  errors.has('dependentsInfoform.country')
                                "
                                >{{
                                  errors.first("dependentsInfoform.country")
                                }}</span
                              >
                            </div>
                          </div>

                           <div
                        class="vx-col md:w-1/2 w-full"
                      
                       v-if="checkTemplateField('spouse_cob') && checkTemplateField('spouse_provinceOfBirth')"
                      >
                        <div class="form_group">
                          <label for class="form_label"
                            >Province of Birth
                            <em v-if="spouseProvinceStates.length > 0">*</em></label
                          >

                          <div class="con-select w-full">
                            <multiselect
                              name="provinceState"
                              v-validate="{
                                required: provinceStates.length > 0,
                              }"
                              v-model="dependentsInfo.spouse.provinceOfBirthDetails"
                              :disabled="provinceStates.length == 0"
                              @select="selectSpouseProvinceOfBirth"
                              :show-labels="false"
                              label="name"
                              track-by="id"
                              data-vv-as="Province of Birth"
                              placeholder="Province of Birth"
                              :options="spouseProvinceStates"
                              :searchable="true"
                              :allow-empty="false"
                            ></multiselect>
                          </div>
                          <span
                            class="text-danger text-sm"
                            v-show="
                              errors.has('dependentsInfoform.provinceState')
                            "
                            >{{
                              errors.first("dependentsInfoform.provinceState")
                            }}</span
                          >
                        </div>
                         </div>
                         <!------spouse_locationOfBirth-->

                          <div
                        class="vx-col md:w-1/2 w-full"
                      
                       v-if="checkTemplateField('spouse_locationOfBirth')"
                      >
                        <div class="form_group">
                          <label for class="form_label"
                            >Location of Birth 
                            <em v-if="spouseProvinceLocations.length > 0"></em></label
                          >

                          <div class="con-select w-full">

                           <vs-input
                             v-validate="'max:50'"
                              class="w-full"
                              name="sLocation"
                              v-model="dependentsInfo.spouse.locationOfBirth"
                              data-vv-as="Location Of Birth"
                            />
                          <!----
                            <multiselect
                              name="Location"
                              v-validate="{
                                required: spouseProvinceLocations.length > 0,
                              }"
                              v-model="dependentsInfo.spouse.locationOfBirthDetails"
                              :disabled="spouseProvinceLocations.length == 0"
                              @select="selectSpouseLocationOfBirth"
                              :show-labels="false"
                              label="name"
                              track-by="id"
                              data-vv-as="Location of Birth"
                              placeholder="Location of Birth"
                              :options="spouseProvinceLocations"
                              :searchable="true"
                              :allow-empty="false"
                            ></multiselect>-->
                          </div>
                          <span
                            class="text-danger text-sm"
                            v-show="
                              errors.has('dependentsInfoform.sLocation')
                            "
                            >{{
                              errors.first("dependentsInfoform.sLocation")
                            }}</span
                          >
                        </div>
                         </div>
                        </div>
                      </div>
                    </vs-col>
                    <div class="divider"></div>
                  </template>

                  <template
                    v-if="
                      checkTemplateField('spouse_passport_number') ||
                      checkTemplateField('spouse_passport_expiry_date')
                    "
                  >
                    <vs-col
                      class="m-auto float-none"
                      vs-type="flex"
                      vs-justify="center"
                      vs-align="center"
                      vs-lg="8"
                      vs-sm="12"
                    >
                      <div class="form-container">
                        <div class="vx-row">
                          <div
                            class="vx-col lg:w-1/2 md:w-1/2 w-full"
                            v-if="checkTemplateField('spouse_passport_number')"
                          >
                            <div class="form_group">
                              <label class="form_label"
                                >Spouse’s Passport No</label
                              >
                              <vs-input
                                @keyup="spousePassportChanged()"
                                oninput="this.value = this.value.replace(/[^a-z A-Z 0-9]/g, '');"
                                data-vv-as="Spouse’s Passport No"
                                name="spousepassport"
                                v-model="dependentsInfo.spouse.passportNumber"
                                v-validate="'max:15'"
                                class="w-full"
                              />
                              <span
                                class="text-danger text-sm"
                                v-show="
                                  errors.has(
                                    'dependentsInfoform.spousepassport'
                                  )
                                "
                                >{{
                                  errors.first(
                                    "dependentsInfoform.spousepassport"
                                  )
                                }}</span
                              >
                            </div>
                          </div>

                          <div
                            class="vx-col lg:w-1/2 md:w-1/2 w-full"
                            v-if="
                              checkTemplateField('spouse_passport_expiry_date')
                            "
                          >
                            <div class="form_group">
                              <label class="form_label"
                                >Spouse’s Passport Expiry Date<em
                                  v-if="
                                    dependentsInfo.spouse.passportNumber !=
                                      '' &&
                                    dependentsInfo.spouse.passportNumber !=
                                      null &&
                                    dependentsInfo.spouse.passportNumber !=
                                      undefined
                                  "
                                  >*</em
                                ></label
                              >
                             <!---- <datepicker  :typeable="true"  :use-utc="true" 
                                :format="customFormatter"
                                name="spouse_passportExpiryDate"
                                v-validate="{
                                  required:
                                    dependentsInfo.spouse.passportNumber !=
                                      '' &&
                                    dependentsInfo.spouse.passportNumber !=
                                      null &&
                                    dependentsInfo.spouse.passportNumber !=
                                      undefined,
                                }"
                                v-model="
                                  dependentsInfo.spouse.passportExpiryDate
                                "
                                data-vv-as="Spouse’s Passport Expiry Date"
                                placeholder="MM/DD/YYYY"
                              ></datepicker>
                              -->
                               <date-picker-field :validationRequired="(dependentsInfo.spouse.passportNumber != '' &&
                                    dependentsInfo.spouse.passportNumber != null &&
                                    dependentsInfo.spouse.passportNumber != undefined)?true:false"
                                    v-model="dependentsInfo.spouse.passportExpiryDate" formscope="dependentsInfoform" fieldname="spouse_passportExpiryDate" label="Spouse’s Passport Expiry Date" />
                              <span
                                class="text-danger text-sm"
                                v-show="
                                  errors.has(
                                    'dependentsInfoform.spouse_passportExpiryDate'
                                  )
                                "
                                >{{
                                  errors.first(
                                    "dependentsInfoform.spouse_passportExpiryDate"
                                  )
                                }}</span
                              >
                            </div>
                          </div>
                        </div>
                      </div>
                    </vs-col>
                    <div class="divider"></div>
                  </template>

                  <template
                    v-if="
                      checkTemplateField('spouse_i94') ||
                      checkTemplateField('spouse_country_of_citizenship')
                    "
                  >
                    <vs-col
                      class="m-auto float-none"
                      vs-type="flex"
                      vs-justify="center"
                      vs-align="center"
                      vs-lg="8"
                      vs-sm="12"
                    >
                      <div class="form-container">
                        <div class="vx-row">
                          <div
                            class="vx-col lg:w-1/2 md:w-1/2 w-full"
                            v-if="checkTemplateField('spouse_i94')"
                          >
                            <div class="form_group">
                              <label class="form_label">Spouse’s I-94</label>
                              <vs-input
                                v-model="dependentsInfo.spouse.I94"
                                class="w-full"
                                v-validate="'max:15'"
                                name="spousei94"
                                data-vv-as="Spouse’s I-94"
                              />
                              <span
                                class="text-danger text-sm"
                                v-show="
                                  errors.has('dependentsInfoform.spousei94')
                                "
                                >{{
                                  errors.first("dependentsInfoform.spousei94")
                                }}</span
                              >
                            </div>
                          </div>
                          <div
                            class="vx-col lg:w-1/2 md:w-1/2 w-full"
                            v-if="
                              checkTemplateField(
                                'spouse_country_of_citizenship'
                              )
                            "
                          >
                            <div class="form_group">
                              <label for class="form_label"
                                >Spouse’s Country of Citizenship<em
                                  >*</em
                                ></label
                              >
                              <div class="con-select w-full">
                                <multiselect
                                  ref="spousecountry"
                                  name="citizenship"
                                  v-validate="'required'"
                                  v-model="countryOfCitizenshipSelected"
                                  @select="selectspousecountryOfCitizenship"
                                  :show-labels="false"
                                  track-by="id"
                                  label="name"
                                  data-vv-as="Spouse’s Country of Citizenship"
                                  placeholder="Select Country"
                                  :options="countries"
                                  :searchable="true"
                                  :allow-empty="false"
                                ></multiselect>
                              </div>
                              <span
                                class="text-danger text-sm"
                                v-show="
                                  errors.has('dependentsInfoform.citizenship')
                                "
                                >{{
                                  errors.first("dependentsInfoform.citizenship")
                                }}</span
                              >
                            </div>
                          </div>
                        </div>
                      </div>
                    </vs-col>
                    <div class="divider"></div>
                  </template>

                  <template
                    v-if="
                      checkTemplateField('spouse_current_status') ||
                      checkTemplateField('spouse_status_expiry_date') ||
                      checkTemplateField('spouse_ssn') ||
                      checkTemplateField('spouse_date_of_last_arrival')
                    "
                  >
                    <vs-col
                      class="m-auto float-none"
                      vs-type="flex"
                      vs-justify="center"
                      vs-align="center"
                      vs-lg="8"
                      vs-sm="12"
                    >
                      <div class="form-container">
                        <div class="vx-row">
                          <div
                            class="vx-col md:w-1/2 w-full"
                            v-if="checkTemplateField('spouse_current_status')"
                          >
                            <div class="form_group">
                              <label class="form_label"
                                >Spouse’s Current Status</label
                              >
                              <vs-input
                                data-vv-as="Spouse’s Current Status"
                                name="Spouses_current_status"
                                v-model="dependentsInfo.spouse.currentStatus"
                                class="w-full"
                                label=""
                              />

                              <span
                                class="text-danger text-sm"
                                v-show="
                                  errors.has(
                                    'dependentsInfoform.Spouses_current_status'
                                  )
                                "
                                >{{
                                  errors.first(
                                    "dependentsInfoform.Spouses_current_status"
                                  )
                                }}</span
                              >
                            </div>
                          </div>

                          <div
                            class="vx-col md:w-1/2 w-full"
                            v-if="
                              checkTemplateField('spouse_status_expiry_date')
                            "
                          >
                            <div class="form_group">
                              <label class="form_label"
                                >Spouse’s Current Status Expiry Date</label
                              >
                              <!-- 
                              <datepicker  :typeable="true"  :use-utc="true" 
                                :format="customFormatter"
                                v-validate="{
                                  required:
                                    dependentsInfo.spouse.currentStatus != '' &&
                                    dependentsInfo.spouse.currentStatus !=
                                      null &&
                                    dependentsInfo.spouse.currentStatus !=
                                      undefined,
                                }"
                                v-model="dependentsInfo.spouse.statusExpiryDate"
                                name="Spouses_statusExpiryDate"
                                data-vv-as="Spouse’s Current Status Expiry Date"
                                placeholder="MM/DD/YYYY"
                              ></datepicker>
                              -->
                              <date-picker-field :validationRequired="( dependentsInfo.spouse.currentStatus != '' &&
                                    dependentsInfo.spouse.currentStatus !=
                                      null &&
                                    dependentsInfo.spouse.currentStatus !=
                                      undefined)?true:false"
                                    v-model="dependentsInfo.spouse.statusExpiryDate" formscope="dependentsInfoform" fieldname="Spouses_statusExpiryDate" label="Spouse’s Current Status Expiry Date" />
                              <span
                                class="text-danger text-sm"
                                v-show="
                                  errors.has(
                                    'dependentsInfoform.Spouses_statusExpiryDate'
                                  )
                                "
                                >{{
                                  errors.first(
                                    "dependentsInfoform.Spouses_statusExpiryDate"
                                  )
                                }}</span
                              >
                            </div>
                          </div>
                          <div
                            class="vx-col md:w-1/2 w-full"
                            v-if="checkTemplateField('spouse_ssn')"
                          >
                            <div class="form_group">
                              <label for="" class="form_label"
                                >Spouse’s social security (if Any)</label
                              >
                              <div class="vs-con-input">
                                <the-mask
                                  name="spouse_ssn"
                                  v-validate="'min:9|max:9'"
                                  v-model="dependentsInfo.spouse.SSN"
                                  placeholder="123 - 45 - 6789"
                                  class="vs-inputx vs-input--input normal"
                                  :mask="['### - ## - ####']"
                                />
                              </div>
                              <!-- <the-mask v-validate="'min:9|max:9'" v-model="dependentsInfo.spouse.SSN"
                              placeholder="123 - 45 - 6789" class="vs-inputx vs-input--input normal"
                              :mask="['### - ## - ####']" /> -->
                            </div>
                          </div>
                          <div
                            class="vx-col md:w-1/2 w-full"
                            v-if="
                              checkTemplateField('spouse_date_of_last_arrival')
                            "
                          >
                            <div class="form_group">
                              <label class="form_label"
                                >Date of last arrival
                              </label>
                              <!---
                              <datepicker  :typeable="true"  :use-utc="true" 
                                :format="customFormatter"
                                v-model="dependentsInfo.spouse.lastArrivalDate"
                                data-vv-as="Date of last arrival"
                                :disabled-dates="{ from: new Date() }"
                                placeholder="MM/DD/YYYY"
                              ></datepicker>
                              -->
                    <date-picker-field :validationRequired="false" v-model="dependentsInfo.spouse.lastArrivalDate" formscope="dependentsInfoform" fieldname="last_arrival" label="Date of last arrival" />
                            </div>
                          </div>
                        </div>
                      </div>
                    </vs-col>
                    <div class="divider"></div>
                  </template>

                  <template
                    v-if="
                      checkTemplateField('spouse_address_line2') ||
                      checkTemplateField('spouse_address_line1') ||
                      checkTemplateField('spouse_address_country') ||
                      checkTemplateField('spouse_address_state') ||
                      checkTemplateField('spouse_address_city') ||
                      checkTemplateField('spouse_address_zipcode')
                    "
                  >
                    <vs-col class="m-auto float-none" vs-lg="8" vs-sm="12">
                      <div class="form-container">
                        <h3 class="small-header">Physical Address</h3>
                        
                        <div class="vx-row" >
                        <addressFields 

                        
                          v-if="
                          rernderApouseAddress&& (
                           checkTemplateField('spouse_address_line2') ||
                      checkTemplateField('spouse_address_line1') ||
                      checkTemplateField('spouse_address_country') ||
                      checkTemplateField('spouse_address_state') ||
                      checkTemplateField('spouse_address_city') ||
                      checkTemplateField('spouse_address_zipcode'))"

                        :showLane1="checkTemplateField('spouse_address_line2')"
                        :showLane2="checkTemplateField('spouse_address_line2')"
                        :showCountry="checkTemplateField('spouse_address_country')"
                        :showState=" checkTemplateField('spouse_address_state')"
                        :showCity="checkTemplateField('spouse_address_city')"
                        :showZip="checkTemplateField('spouse_address_zipcode')"
                        
                        :formscope="'dependentsInfoform'" :disableCountry="false" :showaptType="false" :addFormContainerCls='false' :validationRequired="true" :countries="countries"  v-model="dependentsInfo.spouse.physicalAddress" :cid="'spouse_address'" />

                        <template v-if="false" >
                          <div
                            class="vx-col md:w-1/2 w-full"
                            v-if="checkTemplateField('spouse_address_line2')"
                          >
                            <div class="form_group">
                              <label class="form_label"
                                >Street Address<em>*</em></label
                              >
                              <vs-input
                                v-validate="'required'"
                                name="address1"
                                v-model="
                                  dependentsInfo.spouse.physicalAddress.line1
                                "
                                class="w-full"
                                data-vv-as="Street Address"
                              />
                              <span
                                class="text-danger text-sm"
                                v-show="
                                  errors.has('dependentsInfoform.address1')
                                "
                                >{{
                                  errors.first("dependentsInfoform.address1")
                                }}</span
                              >
                            </div>
                          </div>

                          <div
                            class="vx-col md:w-1/2 w-full"
                            v-if="checkTemplateField('spouse_address_line1')"
                          >
                            <div class="form_group">
                              <label class="form_label">Apt, Suite</label>
                              <vs-input
                                name="address2"
                                v-model="
                                  dependentsInfo.spouse.physicalAddress.line2
                                "
                                class="w-full"
                                data-vv-as="Apt, Suite"
                              />
                              <span
                                class="text-danger text-sm"
                                v-show="
                                  errors.has('dependentsInfoform.address2')
                                "
                                >{{
                                  errors.first("dependentsInfoform.address2")
                                }}</span
                              >
                            </div>
                          </div>

                          <div
                            class="vx-col md:w-1/2 w-full"
                            v-if="checkTemplateField('spouse_address_country')"
                          >
                            <div class="form_group">
                              <label for class="form_label"
                                >Country<em>*</em></label
                              >
                              <div class="con-select w-full">
                                <multiselect
                                  name="spouseaddresscountry"
                                  v-validate="'required'"
                                  v-model="spouseaddresscountryModel"
                                  @select="selectspouseaddressCountry"
                                  :show-labels="false"
                                  track-by="id"
                                  label="name"
                                  data-vv-as="Country"
                                  placeholder="Select Country"
                                  :options="countries"
                                  :searchable="true"
                                  ref="spcnt"
                                  :allow-empty="false"
                                ></multiselect>
                              </div>

                              <span
                                class="text-danger text-sm"
                                v-show="
                                  errors.has(
                                    'dependentsInfoform.spouseaddresscountry'
                                  )
                                "
                                >{{
                                  errors.first(
                                    "dependentsInfoform.spouseaddresscountry"
                                  )
                                }}</span
                              >
                            </div>
                          </div>
                          <div
                            class="vx-col md:w-1/2 w-full"
                            v-if="checkTemplateField('spouse_address_state')"
                          >
                            <div class="form_group">
                              <label for class="form_label"
                                >State<em v-if="souuselocations.length > 0"
                                  >*</em
                                ></label
                              >
                              <div class="con-select w-full">
                                <multiselect
                                  name="spouseaddressstate"
                                  v-validate="{
                                    required: suposestates.length > 0,
                                  }"
                                  v-model="spouseaddressstateModel"
                                  @select="selectspouseaddressState"
                                  :show-labels="false"
                                  track-by="id"
                                  label="name"
                                  data-vv-as="State"
                                  placeholder="Select State"
                                  :options="suposestates"
                                  :searchable="true"
                                  :allow-empty="false"
                                >
                                </multiselect>
                              </div>

                              <span
                                class="text-danger text-sm"
                                v-show="
                                  errors.has(
                                    'dependentsInfoform.spouseaddressstate'
                                  )
                                "
                                >{{
                                  errors.first(
                                    "dependentsInfoform.spouseaddressstate"
                                  )
                                }}</span
                              >
                            </div>
                          </div>
                          <div
                            class="vx-col md:w-1/2 w-full"
                            v-if="checkTemplateField('spouse_address_city')"
                          >
                            <div class="form_group">
                              <label for class="form_label"
                                >City<em v-if="souuselocations.length > 0"
                                  >*</em
                                ></label
                              >
                              <div class="con-select w-full">
                                <multiselect
                                  name="spouseaddresscity"
                                  v-validate="{
                                    required: souuselocations.length > 0,
                                  }"
                                  v-model="spouseaddresslocationModel"
                                  @select="selectspouseaddresstLocation"
                                  :show-labels="false"
                                  track-by="id"
                                  label="name"
                                  data-vv-as="City"
                                  placeholder="Select City"
                                  :options="souuselocations"
                                  :searchable="true"
                                  :allow-empty="false"
                                >
                                </multiselect>
                              </div>

                              <span
                                class="text-danger text-sm"
                                v-show="
                                  errors.has(
                                    'dependentsInfoform.spouseaddresscity'
                                  )
                                "
                                >{{
                                  errors.first(
                                    "dependentsInfoform.spouseaddresscity"
                                  )
                                }}</span
                              >
                            </div>
                          </div>
                          <div
                            class="vx-col md:w-1/2 w-full"
                            v-if="checkTemplateField('spouse_address_zipcode')"
                          >
                            <div class="form_group">
                              <label for class="form_label"
                                >Zip Code<em>*</em></label
                              >
                              <vs-input
                                name="zipcode"
                                v-model="
                                  dependentsInfo.spouse.physicalAddress.zipcode
                                "
                                v-validate="'numeric|zipcodev:spcnt'"
                                class="w-full"
                                data-vv-as="Zip Code"
                              />

                              <span
                                class="text-danger text-sm"
                                v-show="
                                  errors.has('dependentsInfoform.zipcode')
                                "
                                >{{
                                  errors.first("dependentsInfoform.zipcode")
                                }}</span
                              >
                            </div>
                          </div>
                          </template>

                          <div class="vx-col md:w-1/2 w-full"></div>
                        </div>
                      </div>
                    </vs-col>
                    <div class="divider"></div>
                  </template>

                  <template
                    v-if="
                      checkTemplateField('spouse_docs_passport') ||
                      checkTemplateField('spouse_docs_visa') ||
                      checkTemplateField('spouse_docs_formi94') ||
                      checkTemplateField('spouse_docs_form_i797') ||
                      checkTemplateField('spouse_docs_mrg_certificate') ||
                      checkTemplateField('spouse_docs_other') ||
                      checkTemplateField('spouse_docs_pay_stubs') ||
                      checkTemplateField('spouse_docs_form_i20')
                    "
                  >
                    <vs-col
                      class="m-auto float-none"
                      vs-type="flex"
                      vs-justify="center"
                      vs-align="center"
                      vs-lg="8"
                      vs-sm="12"
                    >
                      <div class="form-container w-full">
                        <div class="alert-content-block pt-2 pb-3">
                          <vs-alert
                            active="true"
                            class="h-auto warning-alert mb-5"
                            icon-pack="IntakePortal"
                            icon="IP-information-button"
                          >
                            Provide copies of the following spouse documents:
                            <span
                              >Visa, Form I-94, Form I-797, Marriage
                              Certificate</span
                            >
                          </vs-alert>
                        </div>

                        <div class="vx-row documents_group">
                          <h3 class="small-header">
                            Spouse Documents
                            <span class="file-type">
                              (File Type: PDF, DOC, JPEG, PNG. Max file size:
                              1MB)
                            </span>
                          </h3>

                          <div
                            class="vx-col w-full"
                            v-if="checkTemplateField('spouse_docs_passport')"
                          >
                            <label class="custom-label"
                              >{{ 'passport'| formatdoctype}}<em>*</em></label
                            >

                            <file-upload
                              v-model="dependentsInfo.spouse.documents.passport"
                              class="file-upload-input"
                              name="passport"
                              data-vv-as="Passport"
                              v-validate="'required|docsValidate'"
                              :multiple="true"
                              :hideSelected="true"
                              accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                              @input="
                                upload(dependentsInfo.spouse.documents.passport)
                              "
                            >
                              <img
                                class="file-icon"
                                src="@/assets/images/main/file-upload.svg"
                              />
                              Upload
                            </file-upload>
                            <span
                              class="text-danger text-sm-doc"
                              v-show="errors.has('dependentsInfoform.passport')"
                              >{{
                                errors.first("dependentsInfoform.passport")
                              }}</span
                            >
                            <ul class="uploaded-list">
                              <template
                                v-for="(item, index) in dependentsInfo.spouse
                                  .documents.passport"
                              >
                                <vs-chip
                                  type="button"
                                  @click="
                                    remove(
                                      item,
                                      dependentsInfo.spouse.documents.passport
                                    )
                                  "
                                  :key="index"
                                  v-if="item.status !== false"
                                  closable
                                  >{{ item.name }}
                                </vs-chip>
                              </template>
                            </ul>
                          </div>

                          <div
                            class="vx-col w-full"
                            v-if="checkTemplateField('spouse_docs_form_i797')"
                          >
                            <label class="custom-label flex">
                              Latest I-797, Notice of Approval of the spouse (if
                              spouse is on H-1B or L-1 status)<em>*</em></label
                            >

                            <file-upload
                              v-model="dependentsInfo.spouse.documents.formI797"
                              class="file-upload-input"
                              name="formi797"
                              data-vv-as=" Latest I-797, Notice of Approval of the spouse"
                              v-validate="'required|docsValidate'"
                              accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                              :multiple="true"
                              :hideSelected="true"
                              @input="
                                upload(dependentsInfo.spouse.documents.formI797)
                              "
                            >
                              <img
                                class="file-icon"
                                src="@/assets/images/main/file-upload.svg"
                              />
                              Upload
                            </file-upload>

                            <span
                              class="text-danger text-sm-doc"
                              v-show="errors.has('dependentsInfoform.formi797')"
                              >{{
                                errors.first("dependentsInfoform.formi797")
                              }}</span
                            >
                            <ul class="uploaded-list">
                              <template
                                v-for="(item, index) in dependentsInfo.spouse
                                  .documents.formI797"
                              >
                                <vs-chip
                                  @click="
                                    remove(
                                      item,
                                      dependentsInfo.spouse.documents.formI797
                                    )
                                  "
                                  :key="index"
                                  closable
                                  v-if="item.status === true"
                                >
                                  {{ item.name }}
                                </vs-chip>
                              </template>
                            </ul>
                          </div>
                          <div
                            class="vx-col w-full"
                            v-if="
                              checkTemplateField('spouse_docs_mrg_certificate')
                            "
                          >
                            <label class="custom-label"
                              >Marriage Certificate (if spouse is on H-1B, L-1,
                              or F-1 status)<em>*</em></label
                            >

                            <file-upload
                              v-model="
                                dependentsInfo.spouse.documents
                                  .marriageCertificate
                              "
                              accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                              class="file-upload-input"
                              name="marriageCertificate"
                              data-vv-as="Marriage Certificate"
                              v-validate="'required|docsValidate'"
                              :multiple="true"
                              :hideSelected="true"
                              @input="
                                upload(
                                  dependentsInfo.spouse.documents
                                    .marriageCertificate
                                )
                              "
                            >
                              <img
                                class="file-icon"
                                src="@/assets/images/main/file-upload.svg"
                              />
                              Upload
                            </file-upload>

                            <span
                              class="text-danger text-sm-doc"
                              v-show="
                                errors.has(
                                  'dependentsInfoform.marriageCertificate'
                                )
                              "
                              >{{
                                errors.first(
                                  "dependentsInfoform.marriageCertificate"
                                )
                              }}</span
                            >
                            <ul class="uploaded-list">
                              <template
                                v-for="(item, index) in dependentsInfo.spouse
                                  .documents.marriageCertificate"
                              >
                                <vs-chip
                                  @click="
                                    remove(
                                      item,
                                      dependentsInfo.spouse.documents
                                        .marriageCertificate
                                    )
                                  "
                                  :key="index"
                                  closable
                                  v-if="item.status === true"
                                >
                                  {{ item.name }}
                                </vs-chip>
                              </template>
                            </ul>
                          </div>

                          <div
                            class="vx-col w-full"
                            v-if="checkTemplateField('spouse_docs_visa')"
                          >
                            <label class="custom-label">{{
                              "visa" | formatdoctype
                            }}</label>
                            <file-upload
                              v-model="dependentsInfo.spouse.documents.visa"
                              accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                              class="file-upload-input"
                              name="visa"
                              data-vv-as="Visa"
                              :multiple="true"
                              :hideSelected="true"
                              @input="
                                upload(dependentsInfo.spouse.documents.visa)
                              "
                            >
                              <img
                                class="file-icon"
                                src="@/assets/images/main/file-upload.svg"
                              />
                              Upload
                            </file-upload>

                            <span
                              class="text-danger text-sm-doc"
                              v-show="errors.has('dependentsInfoform.visa')"
                              >{{
                                errors.first("dependentsInfoform.visa")
                              }}</span
                            >
                            <ul class="uploaded-list">
                              <template
                                v-for="(item, index) in dependentsInfo.spouse
                                  .documents.visa"
                              >
                                <vs-chip
                                  @click="
                                    remove(
                                      item,
                                      dependentsInfo.spouse.documents.visa
                                    )
                                  "
                                  :key="index"
                                  closable
                                  v-if="item.status === true"
                                >
                                  {{ item.name }}
                                </vs-chip>
                              </template>
                            </ul>
                          </div>
                          <div
                            class="vx-col w-full"
                            v-if="checkTemplateField('spouse_docs_form_i20')"
                          >
                            <label class="custom-label"
                              >{{'noticeOfApprovalOfH1Status' | formatdoctype}}</label
                            >
                            <file-upload
                              v-model="
                                dependentsInfo.spouse.documents
                                  .noticeOfApprovalOfH1Status
                              "
                              class="file-upload-input"
                              name="spouse_docs_form_i20"
                              data-vv-as="Spouse’s all Form I-20s"
                              :multiple="true"
                              :hideSelected="true"
                              accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                              @input="
                                upload(
                                  dependentsInfo.spouse.documents
                                    .noticeOfApprovalOfH1Status
                                )
                              "
                            >
                              <img
                                class="file-icon"
                                src="@/assets/images/main/file-upload.svg"
                              />
                              Upload
                            </file-upload>

                            <span
                              class="text-danger text-sm-doc"
                              v-show="
                                errors.has(
                                  'dependentsInfoform.spouse_docs_form_i20'
                                )
                              "
                              >{{
                                errors.first(
                                  "dependentsInfoform.spouse_docs_form_i20"
                                )
                              }}</span
                            >
                            <ul class="uploaded-list">
                              <template
                                v-for="(item, index) in dependentsInfo.spouse
                                  .documents.noticeOfApprovalOfH1Status"
                              >
                                <vs-chip
                                  @click="
                                    remove(
                                      item,
                                      dependentsInfo.spouse.documents
                                        .noticeOfApprovalOfH1Status
                                    )
                                  "
                                  :key="index"
                                  closable
                                  v-if="item.status !== false"
                                >
                                  {{ item.name }}
                                </vs-chip>
                              </template>
                            </ul>
                          </div>

                          <div
                            class="vx-col w-full"
                            v-if="checkTemplateField('spouse_docs_pay_stubs')"
                          >
                            <label class="custom-label"
                              >Three recent pay stubs (if spouse is on H-1B or
                              L-1 status)</label
                            >

                            <file-upload
                              v-model="dependentsInfo.spouse.documents.payStubs"
                              accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                              class="file-upload-input"
                              name="spouse_docs_pay_stubs"
                              data-vv-as="Three recent pay stubs"
                              :multiple="true"
                              :hideSelected="true"
                              @input="
                                upload(dependentsInfo.spouse.documents.payStubs)
                              "
                            >
                              <img
                                class="file-icon"
                                src="@/assets/images/main/file-upload.svg"
                              />
                              Upload
                            </file-upload>

                            <span
                              class="text-danger text-sm-doc"
                              v-show="
                                errors.has(
                                  'dependentsInfoform.spouse_docs_pay_stubs'
                                )
                              "
                              >{{
                                errors.first(
                                  "dependentsInfoform.spouse_docs_pay_stubs"
                                )
                              }}</span
                            >
                            <ul class="uploaded-list">
                              <template
                                v-for="(item, index) in dependentsInfo.spouse
                                  .documents.payStubs"
                              >
                                <vs-chip
                                  @click="
                                    remove(
                                      item,
                                      dependentsInfo.spouse.documents.payStubs
                                    )
                                  "
                                  :key="index"
                                  closable
                                  v-if="item.status === true"
                                >
                                  {{ item.name }}
                                </vs-chip>
                              </template>
                            </ul>
                          </div>

                          <div
                            class="vx-col w-full"
                            v-if="checkTemplateField('spouse_docs_other')"
                          >
                            <label class="custom-label"
                              >Other documents, if any</label
                            >

                            <file-upload
                              v-model="dependentsInfo.spouse.documents.other"
                              accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                              class="file-upload-input"
                              name="spouseOther"
                              data-vv-as="Marriage Certificate"
                              :multiple="true"
                              :hideSelected="true"
                              @input="
                                upload(dependentsInfo.spouse.documents.other)
                              "
                            >
                              <img
                                class="file-icon"
                                src="@/assets/images/main/file-upload.svg"
                              />
                              Upload
                            </file-upload>

                            <span
                              class="text-danger text-sm"
                              v-show="errors.has('spouseOther')"
                              >{{ errors.first("spouseOther") }}</span
                            >
                            <ul class="uploaded-list">
                              <template
                                v-for="(item, index) in dependentsInfo.spouse
                                  .documents.other"
                              >
                                <vs-chip
                                  @click="
                                    remove(
                                      item,
                                      dependentsInfo.spouse.documents.other
                                    )
                                  "
                                  :key="index"
                                  closable
                                  v-if="item.status === true"
                                >
                                  {{ item.name }}
                                </vs-chip>
                              </template>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </vs-col>
                  </template>
                </div>
                <div
                  class="divider divider-double"
                  v-if="
                    childrensarray.length > 1 &&
                    checkTemplateField('child_h4_required')
                  "
                ></div>
              </div>

              <template v-if="checkTemplateField('child_h4_required')">
                <div
                  v-for="(children, index) in childrensarray"
                  :key="children.id"
                >
                  <div
                    class="delete-row delete-group"
                    v-if="childrensarray.length > 1"
                  >
                    <div class="delete">
                      <a @click="removechildren(index)">
                        <!-- <img src="@/assets/images/main/delete-row-img.svg"> -->
                        <trash-2-icon
                          size="1.5x"
                          class="custom-class"
                        ></trash-2-icon>
                      </a>
                    </div>
                  </div>
                  <vs-col
                    class="m-auto float-none"
                    vs-type="flex"
                    vs-lg="8"
                    vs-sm="12"
                    v-if="checkTemplateField('child_h4_required')"
                  >
                    <div class="alert-content-block">
                      <p>H4 required for children?</p>
                      <div class="form_radio_btns">
                        <vs-button
                          v-bind:class="{
                            cactive: children.h4Required == true,
                          }"
                          @click="children.h4Required = true"
                          class="yes mr-5"
                          color="success"
                          type="border"
                          >Yes</vs-button
                        >
                        <vs-button
                          class="no"
                          v-bind:class="{
                            cactive: children.h4Required == false,
                          }"
                          @click="children.h4Required = false"
                          color="danger"
                          type="border"
                          >No</vs-button
                        >
                      </div>
                    </div>
                  </vs-col>
                  <div v-if="children.h4Required == true">
                    <template
                      v-if="
                        checkTemplateField('child_first_name') ||
                        checkTemplateField('child_middle_name') ||
                        checkTemplateField('child_last_name') ||
                        checkTemplateField('child_dob') ||
                        checkTemplateField('child_cob') ||
                        checkTemplateField('child_passport_number') ||
                        checkTemplateField('child_passport_expiry_date') ||
                        checkTemplateField('child_i94') ||
                        checkTemplateField('child_country_of_citizenship') ||
                        checkTemplateField('child_current_status') ||
                        checkTemplateField('child_status_expiry_date')
                      "
                    >
                      <vs-col
                        class="m-auto float-none"
                        vs-type="flex"
                        vs-justify="center"
                        vs-align="center"
                        vs-lg="8"
                        vs-sm="12"
                      >
                        <div class="form-container">
                          <div class="vx-row">
                            <div
                              class="vx-col w-full"
                              v-if="
                                checkTemplateField('child_first_name') ||
                                checkTemplateField('child_middle_name') ||
                                checkTemplateField('child_last_name')
                              "
                            >
                              <vx-input-group class="form-input-group">
                                <div
                                  class="form_group w-full"
                                  v-if="checkTemplateField('child_first_name')"
                                >
                                  <label class="form_label"
                                    >First Name<em>*</em></label
                                  >
                                  <vs-input
                                    v-validate="{
                                      required: children.h4Required == true,
                                    }"
                                    v-model="children.firstName"
                                    class="w-full"
                                    :name="['childname' + index]"
                                    data-vv-as="Child First Name"
                                  />
                                </div>
                                <div
                                  class="form_group w-full"
                                  v-if="checkTemplateField('child_middle_name')"
                                >
                                  <label class="form_label">Middle Name</label>
                                  <vs-input
                                    v-model="children.middleName"
                                    class="w-full"
                                  />
                                </div>
                                <div
                                  class="form_group w-full"
                                  v-if="checkTemplateField('child_last_name')"
                                >
                                  <label class="form_label"
                                    >Last Name<em>*</em></label
                                  >
                                  <vs-input
                                    v-model="children.lastName"
                                    class="w-full"
                                    v-validate="{
                                      required: children.h4Required == true,
                                    }"
                                    :name="['last_childname' + index]"
                                    data-vv-as="Child Last Name"
                                  />
                                </div>
                              </vx-input-group>
                              <div class="input-group-error">
                                <p
                                  class="w-1/3"
                                  v-if="checkTemplateField('child_first_name')"
                                >
                                  <span
                                    class="text-danger text-sm"
                                    v-show="
                                      errors.has(
                                        'dependentsInfoform.childname' + index
                                      )
                                    "
                                  >
                                    {{
                                      errors.first(
                                        "dependentsInfoform.childname" + index
                                      )
                                    }}
                                  </span>
                                </p>
                                <p
                                  class="w-1/3"
                                  v-if="checkTemplateField('child_middle_name')"
                                ></p>
                                <p
                                  class="w-1/3"
                                  v-if="checkTemplateField('child_last_name')"
                                >
                                  <span
                                    class="text-danger text-sm"
                                    v-show="
                                      errors.has(
                                        'dependentsInfoform.last_childname' +
                                          index
                                      )
                                    "
                                  >
                                    {{
                                      errors.first(
                                        "dependentsInfoform.last_childname" +
                                          index
                                      )
                                    }}
                                  </span>
                                </p>
                              </div>
                            </div>

                            <div
                              class="vx-col md:w-1/2 w-full"
                              v-if="checkTemplateField('child_dob')"
                            >
                              <div class="form_group">
                                <label class="form_label"
                                  >Child’s Date of Birth<em>*</em></label
                                >
                                <!----
                                <datepicker  :typeable="true"  :use-utc="true" 
                                  :format="customFormatter"
                                  v-validate="{
                                    required: children.h4Required == true,
                                  }"
                                  :name="'dateOfBirth' + index"
                                  v-model="children.dateOfBirth"
                                  :disabled-dates="{ from: new Date() }"
                                  data-vv-as="Date of Birth"
                                  placeholder="MM/DD/YYYY"
                                >
                                </datepicker>
                                -->

                                <date-picker-field :validationRequired="children.h4Required == true" 
                                v-model="children.dateOfBirth" formscope="dependentsInfoform" :fieldname="'dateOfBirth' + index" label="Date of Birth" />
                                <span
                                  class="text-danger text-sm"
                                  v-show="
                                    errors.has(
                                      'dependentsInfoform.dateOfBirth' + index
                                    )
                                  "
                                >
                                  {{
                                    errors.first(
                                      "dependentsInfoform.dateOfBirth" + index
                                    )
                                  }}
                                </span>
                              </div>
                            </div>
                            <div
                              class="vx-col md:w-1/2 w-full"
                              v-if="checkTemplateField('child_cob')"
                            >
                              <div class="form_group">
                                <label for class="form_label"
                                  >Country of Birth<em>*</em></label
                                >
                                <div class="con-select w-full">
                                  <multiselect
                                    :name="'childcountry' + index"
                                    :id="index"
                                    v-model="children.selectedcountryOfBirth"
                                    @select="selectchildCountry"
                                    :show-labels="false"
                                    track-by="id"
                                    label="name"
                                    data-vv-as="Country of Birth"
                                    placeholder="Select Country"
                                    :options="countries"
                                    :searchable="true"
                                    :allow-empty="false"
                                    v-validate="{
                                      required: children.h4Required == true,
                                    }"
                                  >
                                  </multiselect>
                                </div>
                                <span
                                  class="text-danger text-sm"
                                  v-show="
                                    errors.has(
                                      'dependentsInfoform.childcountry' + index
                                    )
                                  "
                                >
                                  {{
                                    errors.first(
                                      "dependentsInfoform.childcountry" + index
                                    )
                                  }}
                                </span>
                              </div>
                            </div>
                            <div
                              class="vx-col md:w-1/2 w-full"
                              v-if="checkTemplateField('child_passport_number')"
                            >
                              <div class="form_group">
                                <label for class="form_label"
                                  >Child’s Passport Number</label
                                >
                                <vs-input
                                  @keyup="childPassportUpdated(children)"
                                  oninput="this.value = this.value.replace(/[^a-z A-Z 0-9]/g, '');"
                                  data-vv-as="Child Passport Number"
                                  name="childpassport"
                                  v-model="children.passportNumber"
                                  class="w-full"
                                  v-validate="'max:15'"
                                />
                                <span
                                  class="text-danger text-sm"
                                  v-show="
                                    errors.has(
                                      'dependentsInfoform.childpassport'
                                    )
                                  "
                                  >{{
                                    errors.first(
                                      "dependentsInfoform.childpassport"
                                    )
                                  }}</span
                                >
                              </div>
                            </div>
                            <div
                              class="vx-col md:w-1/2 w-full"
                              v-if="
                                checkTemplateField('child_passport_expiry_date')
                              "
                            >
                              <div class="form_group">
                                <label class="form_label"
                                  >Passport Expiry Date<em
                                    v-if="
                                      children.h4Required == true &&
                                      children.passportNumber != '' &&
                                      children.passportNumber != null &&
                                      children.passportNumber != undefined
                                    "
                                    >*</em
                                  ></label
                                >
                                <!--<datepicker  :typeable="true"  :use-utc="true" 
                                  v-validate="{
                                    required:
                                      children.h4Required == true &&
                                      children.passportNumber != '' &&
                                      children.passportNumber != null &&
                                      children.passportNumber != undefined,
                                  }"
                                  data-vv-as="Passport Expiry Date"
                                  :name="'passportExpiryDate' + index"
                                  v-model="children.passportExpiryDate"
                                  placeholder="MM/DD/YYYY"
                                ></datepicker>
                                -->
                             <date-picker-field :validationRequired="(
                                      children.h4Required == true &&
                                      children.passportNumber != '' &&
                                      children.passportNumber != null &&
                                      children.passportNumber != undefined)?true:false"
                                      v-model="children.passportExpiryDate" 
                                      formscope="dependentsInfoform" :fieldname="'passportExpiryDate' + index" label="Passport Expiry Date" />   
                                <span
                                  class="text-danger text-sm"
                                  v-show="
                                    errors.has(
                                      'dependentsInfoform.passportExpiryDate' +
                                        index
                                    )
                                  "
                                >
                                  {{
                                    errors.first(
                                      "dependentsInfoform.passportExpiryDate" +
                                        index
                                    )
                                  }}
                                </span>
                              </div>
                            </div>
                            <div
                              class="vx-col md:w-1/2 w-full"
                              v-if="checkTemplateField('child_i94')"
                            >
                              <div class="form_group">
                                <label class="form_label">Child’s I–94</label>
                                <vs-input
                                  v-model="children.I94"
                                  class="w-full"
                                  v-validate="'max:15'"
                                  name="childreni94"
                                  data-vv-as="Child’s I –94"
                                />
                                <span
                                  class="text-danger text-sm"
                                  v-show="
                                    errors.has('dependentsInfoform.childreni94')
                                  "
                                  >{{
                                    errors.first(
                                      "dependentsInfoform.childreni94"
                                    )
                                  }}</span
                                >
                              </div>
                            </div>
                            <div
                              class="vx-col md:w-1/2 w-full"
                              v-if="
                                checkTemplateField(
                                  'child_country_of_citizenship'
                                )
                              "
                            >
                              <div class="form_group">
                                <label for class="form_label"
                                  >Country of Citizenship</label
                                >
                                <div class="con-select w-full">
                                  <multiselect
                                    name="childcitizenship[]"
                                    :id="index"
                                    v-model="children.selectedcitizenship"
                                    @select="selectchildCitizenship"
                                    :show-labels="false"
                                    track-by="id"
                                    label="name"
                                    data-vv-as="Country of Citizenship"
                                    placeholder="Select Country"
                                    :options="countries"
                                    :searchable="true"
                                    :allow-empty="false"
                                  >
                                  </multiselect>
                                </div>
                              </div>
                            </div>
                            <div
                              class="vx-col md:w-1/2 w-full"
                              v-if="checkTemplateField('child_current_status')"
                            >
                              <!-- <vs-select v-model="children.currentStatus" class="w-full select-large" data-vv-as="Visa Status"
                          label="Child’s Current Status ">
                          <vs-select-item :key="index" :value="item.id" :text="item.name"
                            v-for="(item,index) in visastatuses" class="w-full" />
                        </vs-select> -->
                              <div class="form_group">
                                <label for class="form_label"
                                  >Child’s Current Status</label
                                >
                                <vs-input
                                  data-vv-as="Visa Status"
                                  name="child_current_status"
                                  v-model="children.currentStatus"
                                  class="w-full"
                                />
                              </div>
                            </div>
                            <div
                              class="vx-col md:w-1/2 w-full"
                              v-if="
                                checkTemplateField('child_status_expiry_date')
                              "
                            >
                              <div class="form_group">
                                <!-- :name ="'child_statusExpiryDate'+index" -->
                                <label class="form_label"
                                  >Child’s Current Status Expiry Date</label
                                >
                                <!----<datepicker  :typeable="true"  :use-utc="true" 
                                  :format="customFormatter"
                                  :name="'child_statusExpiryDate' + index"
                                  v-validate="{
                                    required:
                                      children.h4Required == true &&
                                      children.currentStatus != '' &&
                                      children.currentStatus != null &&
                                      children.currentStatus != undefined,
                                  }"
                                  v-model="children.statusExpiryDate"
                                  data-vv-as="Child’s Current Status Expiry Date"
                                  placeholder="MM/DD/YYYY"
                                ></datepicker>
                                -->
                                <date-picker-field :validationRequired="(
                                   children.h4Required == true &&
                                      children.currentStatus != '' &&
                                      children.currentStatus != null &&
                                      children.currentStatus != undefined
                                )?true:false"
                                     v-model="children.statusExpiryDate"
                                      formscope="dependentsInfoform" :fieldname="'child_statusExpiryDate' + index" label="Child’s Current Status Expiry Date" />  
                              </div>
                              <span
                                class="text-danger text-sm"
                                v-show="
                                  errors.has(
                                    'dependentsInfoform.child_statusExpiryDate' +
                                      index
                                  )
                                "
                              >
                                {{
                                  errors.first(
                                    "dependentsInfoform.child_statusExpiryDate" +
                                      index
                                  )
                                }}
                              </span>
                            </div>
                          </div>
                        </div>
                      </vs-col>
                      <div class="divider"></div>
                    </template>
                    <template
                      v-if="
                        checkTemplateField('child_docs_passport') ||
                        checkTemplateField('child_docs_visa') ||
                        checkTemplateField('child_docs_form_i94') ||
                        checkTemplateField('child_docs_form_i797') ||
                        checkTemplateField('child_docs_birth_certificate') ||
                        checkTemplateField('child_docs_approval_notice') ||
                        checkTemplateField('child_docs_other')
                      "
                    >
                      <vs-col
                        class="m-auto float-none"
                        vs-type="flex"
                        vs-justify="center"
                        vs-align="center"
                        vs-lg="8"
                        vs-sm="12"
                      >
                        <div class="form-container w-full">
                          <div class="alert-content-block pt-2 pb-3">
                            <vs-alert
                              active="true"
                              class="h-auto warning-alert mb-5"
                              icon-pack="IntakePortal"
                              icon="IP-information-button "
                            >
                              Provide copies of the following children
                              documents:
                              <span
                                >Case, Form I-94, Form I-797, Birth
                                Certificate.</span
                              >
                            </vs-alert>
                          </div>

                          <div class="vx-row documents_group">
                            <h3 class="small-header">
                              Child's Documents
                              <span class="file-type">
                                (File Type: PDF, DOC, JPEG, PNG. Max file size:
                                1MB)
                              </span>
                            </h3>
                            <div
                              class="vx-col w-full"
                              v-if="checkTemplateField('child_docs_passport')"
                            >
                              <label class="custom-label">{{ 'passport'| formatdoctype}}</label>
                              <file-upload
                                v-model="children.documents.passport"
                                class="file-upload-input"
                                accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                                :name="'childPassport' + index"
                                data-vv-as="Passport"
                                :multiple="true"
                                :hideSelected="true"
                                @input="
                                  upload(children.documents.passport, index)
                                "
                              >
                                <img
                                  class="file-icon"
                                  src="@/assets/images/main/file-upload.svg"
                                />
                                Upload
                              </file-upload>
                              <span
                                class="text-danger text-sm"
                                v-show="errors.has('childPassport' + index)"
                                >{{
                                  errors.first("childPassport" + index)
                                }}</span
                              >
                              <ul class="uploaded-list">
                                <template
                                  v-for="(passport, passportValue) in children
                                    .documents.passport"
                                >
                                  <vs-chip
                                    @click="
                                      remove(
                                        passport,
                                        children.documents.passport
                                      )
                                    "
                                    :name="'passportRemoveSelected' + index"
                                    :key="passportValue"
                                    close
                                    closable
                                    v-if="passport.status !== false"
                                  >
                                    {{ passport.name }}
                                  </vs-chip>
                                </template>
                              </ul>
                            </div>
                            <div
                              class="vx-col w-full"
                              v-if="checkTemplateField('child_docs_visa')"
                            >
                              <label class="custom-label">Visa</label>
                              <file-upload
                                v-model="children.documents.visa"
                                class="file-upload-input"
                                accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                                :name="'childVisa' + index"
                                data-vv-as="Case"
                                :multiple="true"
                                :hideSelected="true"
                                @input="upload(children.documents.visa, index)"
                              >
                                <img
                                  class="file-icon"
                                  src="@/assets/images/main/file-upload.svg"
                                />
                                Upload
                              </file-upload>
                              <span
                                class="text-danger text-sm"
                                v-show="errors.has('childVisa' + index)"
                                >{{ errors.first("childVisa" + index) }}</span
                              >
                              <ul class="uploaded-list">
                                <template
                                  v-for="(visa, visaValue) in children.documents
                                    .visa"
                                >
                                  <vs-chip
                                    @click="
                                      remove(visa, children.documents.visa)
                                    "
                                    :name="'visaRemoveSelected' + index"
                                    :key="visaValue"
                                    closable
                                    v-if="visa.status !== false"
                                  >
                                    {{ visa.name }}
                                  </vs-chip>
                                </template>
                              </ul>
                            </div>
                            <div
                              class="vx-col w-full"
                              v-if="checkTemplateField('child_docs_form_i94')"
                            >
                              <label class="custom-label flex">
                                Form I-94
                              </label>
                              <file-upload
                                v-model="children.documents.formI94"
                                class="file-upload-input"
                                accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                                :name="'childFormI94' + index"
                                data-vv-as="Form I-94"
                                :multiple="true"
                                :hideSelected="true"
                                @input="
                                  upload(children.documents.formI94, index)
                                "
                              >
                                <img
                                  class="file-icon"
                                  src="@/assets/images/main/file-upload.svg"
                                />
                                Upload
                              </file-upload>
                              <span
                                class="text-danger text-sm"
                                v-show="errors.has('childFormI94' + index)"
                                >{{
                                  errors.first("childFormI94" + index)
                                }}</span
                              >
                              <ul class="uploaded-list">
                                <template
                                  v-for="(formI94, formI94Value) in children
                                    .documents.formI94"
                                >
                                  <vs-chip
                                    @click="
                                      remove(
                                        formI94,
                                        children.documents.formI94
                                      )
                                    "
                                    :name="'formI94RemoveSelected' + index"
                                    :key="formI94Value"
                                    v-if="formI94.status !== false"
                                    closable
                                  >
                                    {{ formI94.name }}
                                  </vs-chip>
                                </template>
                              </ul>
                            </div>
                            <div
                              class="vx-col w-full"
                              v-if="checkTemplateField('child_docs_form_i797')"
                            >
                              <label class="custom-label flex">
                                Form I-797
                              </label>
                              <!-- check balu 3 -->
                              <file-upload
                                v-model="children.documents.formI797"
                                class="file-upload-input"
                                accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                                :name="'chilFormI797' + index"
                                data-vv-as="Form I-797"
                                :multiple="true"
                                :hideSelected="true"
                                @input="
                                  upload(children.documents.formI797, index)
                                "
                              >
                                <img
                                  class="file-icon"
                                  src="@/assets/images/main/file-upload.svg"
                                />
                                Upload
                              </file-upload>
                              <span
                                class="text-danger text-sm"
                                v-show="errors.has('chilFormI797' + index)"
                                >{{
                                  errors.first("chilFormI797" + index)
                                }}</span
                              >
                              <ul class="uploaded-list">
                                <template
                                  v-for="(formI797, formI797Value) in children
                                    .documents.formI797"
                                >
                                  <vs-chip
                                    @click="
                                      remove(
                                        formI797,
                                        children.documents.formI797
                                      )
                                    "
                                    :name="'formI94RemoveSelected' + index"
                                    :key="formI797Value"
                                    v-if="formI797.status !== false"
                                    closable
                                  >
                                    {{ formI797.name }}
                                  </vs-chip>
                                </template>
                              </ul>
                            </div>
                            <div
                              class="vx-col w-full"
                              v-if="
                                checkTemplateField(
                                  'child_docs_birth_certificate'
                                )
                              "
                            >
                              <label class="custom-label"
                                >Birth Certificate</label
                              >
                              <file-upload
                                v-model="children.documents.birthCertificate"
                                class="file-upload-input"
                                accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                                :name="'childBirthCertificate' + index"
                                data-vv-as="Birth Certificate"
                                :multiple="true"
                                :hideSelected="true"
                                @input="
                                  upload(
                                    children.documents.birthCertificate,
                                    index
                                  )
                                "
                              >
                                <img
                                  class="file-icon"
                                  src="@/assets/images/main/file-upload.svg"
                                />
                                Upload
                              </file-upload>
                              <span
                                class="text-danger text-sm"
                                v-show="
                                  errors.has('childBirthCertificate' + index)
                                "
                                >{{
                                  errors.first("childBirthCertificate" + index)
                                }}</span
                              >
                              <ul class="uploaded-list">
                                <template
                                  v-for="(
                                    birthCertificate, birthCertificateValue
                                  ) in children.documents.birthCertificate"
                                >
                                  <vs-chip
                                    @click="
                                      remove(
                                        birthCertificate,
                                        children.documents.birthCertificate
                                      )
                                    "
                                    :name="
                                      'birthCertificateRemoveSelected' + index
                                    "
                                    :key="birthCertificateValue"
                                    v-if="birthCertificate.status !== false"
                                    closable
                                  >
                                    {{ birthCertificate.name }}
                                  </vs-chip>
                                </template>
                              </ul>
                            </div>
                            <div
                              class="vx-col w-full"
                              v-if="
                                checkTemplateField('child_docs_approval_notice')
                              "
                            >
                              <label class="custom-label"
                                >Approval Notice</label
                              >
                              <file-upload
                                v-model="children.documents.approvalNotice"
                                class="file-upload-input"
                                accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                                :name="'approval_notice' + index"
                                data-vv-as="Birth Certificate"
                                :multiple="true"
                                :hideSelected="true"
                                @input="
                                  upload(
                                    children.documents.approvalNotice,
                                    index
                                  )
                                "
                              >
                                <img
                                  class="file-icon"
                                  src="@/assets/images/main/file-upload.svg"
                                />
                                Upload
                              </file-upload>
                              <span
                                class="text-danger text-sm"
                                v-show="errors.has('childother' + index)"
                                >{{ errors.first("childother" + index) }}</span
                              >
                              <ul class="uploaded-list">
                                <template
                                  v-for="(
                                    approvalNotice, birthCertificateValue
                                  ) in children.documents.approvalNotice"
                                >
                                  <vs-chip
                                    @click="
                                      remove(
                                        approvalNotice,
                                        children.documents.approvalNotice
                                      )
                                    "
                                    :name="
                                      'birthCertificateRemoveSelected' + index
                                    "
                                    :key="birthCertificateValue"
                                    v-if="approvalNotice.status !== false"
                                    closable
                                  >
                                    {{ approvalNotice.name }}
                                  </vs-chip>
                                </template>
                              </ul>
                            </div>
                            <div
                              class="vx-col w-full"
                              v-if="checkTemplateField('child_docs_other')"
                            >
                              <label class="custom-label"
                                >Other documents, if any</label
                              >
                              <file-upload
                                v-model="children.documents.other"
                                class="file-upload-input"
                                accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                                :name="'childother' + index"
                                data-vv-as="Birth Certificate"
                                :multiple="true"
                                :hideSelected="true"
                                @input="upload(children.documents.other, index)"
                              >
                                <img
                                  class="file-icon"
                                  src="@/assets/images/main/file-upload.svg"
                                />
                                Upload
                              </file-upload>
                              <span
                                class="text-danger text-sm"
                                v-show="errors.has('childother' + index)"
                                >{{ errors.first("childother" + index) }}</span
                              >
                              <ul class="uploaded-list">
                                <template
                                  v-for="(other, indx) in children.documents
                                    .other"
                                >
                                  <vs-chip
                                    @click="
                                      remove(other, children.documents.other)
                                    "
                                    :name="
                                      'birthCertificateRemoveSelected' + indx
                                    "
                                    :key="indx"
                                    v-if="other.status !== false"
                                    closable
                                  >
                                    {{ other.name }}
                                  </vs-chip>
                                </template>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </vs-col>
                    </template>
                  </div>
                  <div
                    class="divider divider-double"
                    v-if="
                      children.h4Required == true &&
                      index == childrensarray.length - 1
                    "
                  ></div>
                  <vs-col
                    v-if="
                      children.h4Required == true &&
                      index == childrensarray.length - 1
                    "
                    class="m-auto float-none"
                    vs-type="flex"
                    vs-align="center"
                    vs-lg="8"
                    vs-sm="12"
                  >
                    <a
                      @click="addchildren"
                      class="add-more mt-5 ml-0"
                      type="filled"
                      v-if="
                        children.h4Required == true &&
                        checkTemplateField('addMoreChild')
                      "
                    >
                      <!--   -->
                      <span>+</span> Add
                      {{ childrensarray.length > 0 ? "another" : "" }} child
                    </a>
                  </vs-col>
                </div>
              </template>
            </form>
          </tab-content>

          <vs-popup
            class="holamundo success-popups"
            title="Your registration is complete."
            :active.sync="SuccessQuestionnaire"
          >
            <figure>
              <img
                src="@/assets/images/main/icon-note.svg"
                alt="login"
                class="mx-auto"
              />
            </figure>
            <h2 class="title">Questionnaire submitted successfully!</h2>
            <p>
              It will be reviewed by the petitioner and appropriate actions will
              be taken soon.
            </p>
          </vs-popup>

          <vs-popup
            class="holamundo main-popup qcomment"
            title="Comment"
            :active.sync="commentPopUp"
          >
            <form data-vv-scope="commentForm">
              <div class="form-container" @click="formerrors.msg = ''">
                <div class="vx-row">
                  <div class="vx-col w-full">
                    <div class="form_group">
                      <label class="form_label">Comments</label>
                      <vs-textarea
                        data-vv-as="Comments"
                        v-validate="'required'"
                        v-model="comments"
                        name="comments"
                        class="w-full"
                      />

                      <span
                        class="text-danger text-sm"
                        v-show="errors.has('commentForm.comments')"
                        >{{ errors.first("commentForm.comments") }}</span
                      >
                    </div>
                  </div>
                </div>
                <div
                  class="text-danger text-sm formerrors"
                  v-show="formerrors.msg"
                >
                  <vs-alert
                    color="warning"
                    class="warning-alert reg-warning-alert no-border-radius"
                    icon-pack="IntakePortal"
                    icon="IP-information-button"
                    active="true"
                    >{{ formerrors.msg }}</vs-alert
                  >
                </div>
              </div>
              <div class="popup-footer relative">
                <span class="loader" v-if="submiTing"
                  ><img src="@/assets/images/main/loader.gif"
                /></span>

                <vs-button
                  :disabled="
                    comments == '' || comments.trim() == '' || submiTing
                  "
                  color="success"
                  @click="formSubmitted(callFromSave)"
                  class="save"
                  type="filled"
                  >Submit</vs-button
                >
              </div>
            </form>
          </vs-popup>
        </form-wizard>
      </vx-card>
    </div>

      <vs-popup class="holamundo main-popup" title="Case Details" :active.sync="showPrefillPopup">
      <div class="form-container">
        
        <div class="vx-row">
          <div class="vx-col w-full">
           <p style="line-height:20px;">Do you want to pre-fill the basic information from the previous case details? </p>
            
          </div>
          
        </div>
       
      </div>
      <div class="popup-footer">
        <vs-button color="dark" class="cancel" type="filled" @click="showPrefillPopup=false">Cancel</vs-button>
        <vs-button color="success" class="save" type="filled" @click="prefilltheDetails();showPrefillPopup=false">Yes</vs-button>
      </div>
    </vs-popup>

     


  </div>
</template>


<script>
import { FormWizard, TabContent } from "vue-form-wizard";
import "vue-form-wizard/dist/vue-form-wizard.min.css";
import Datepicker from "vuejs-datepicker-inv";
import moment from "moment";
import PhoneMaskInput from "vue-phone-mask-input";
import JQuery from "jquery";
import { TheMask } from "vue-the-mask";
import FileUpload from "vue-upload-component/src";
import _ from "lodash";
import Vue from "vue";
import VuePhoneNumberInput from "vue-phone-number-input";
import "vue-phone-number-input/dist/vue-phone-number-input.css";
import { Trash2Icon } from "vue-feather-icons";
import DatePickerField from '../common/datePickerField.vue'
import caseQuestionnaireDocs from "./caseQuestionnaireDocs.vue"
//import addressFields from "@/views/common/addressForm.vue";
import addressFields from "@/views/forms/fields/address.vue";
export default {
   provide() {
        return {
            parentValidator: this.$validator,
        };
    },
  data() {
    return {
      showPrefillPopup:false,
      showPrefilldetails:null,
      othernames:false,
      callFromSave: false,
      commentPopUp: false,
      submiTing: false,
      comments: "",
      editingForm:false,
      provinceStates: [],
      provinceLocations:[],
      spouseProvinceStates:[],
      spouseProvinceLocations:[],

      defaultDependentsInfo: {
        spouse: {
          email: "",
          phoneNumber: "",
          phoneCountryCode: { countryCode: "", countryCallingCode: "" },
          h4Required: true,
          h4EADRequired: null,
          lastArrivalDate: null,
          statusExpiryDate: null,
          physicalAddress: {

            
            line1:"" , 
            line2:"",
            countryId:'' ,
            stateId:'',
            locationId:'',
            zipcode:'',
            countryDetails:{ "_id": "626a8f03a972fa4d60681140", "id": 231, "name": "United States", "phoneCode": 1, "order": 1, "currencySymbol": "$", "currencyCode": "USD", "zipcodeLength": 5, "sortName": "united states" } ,
            stateDetails:null, 
            locationDetails:null 
         
          },
          documents: {
            passport: [],
            visa: [],
            formI94: [],
            formI797: [],
            marriageCertificate: [],
            birthCertificate: [],
            other: [],
          },
        },
        childrens: [
          {
            h4Required: true,
            firstName: null,
            middleName: null,
            lastName: null,
            dateOfBirth: null,
            countryOfBirth: null,
            passportNumber: null,
            passportExpiryDate: null,
            I94: null,
            visaIssuedDate: null,
            currentStatus: null,
            statusExpiryDate: null,
            documents: {
              passport: [],
              visa: [],
              FormI94: [],
              formI797: [],
              birthCertificate: [],
              approvalNotice: [],
              other: [],
            },
          },
        ],
      },
      onlyimFromUs: false,
      showAddchildren: false,
      loadingCompleted: true,
      currentroute: this.$route.params.itemId,
      selectedcountryOfBirth: [],
      selectedcitizenship: [],
      salaryOfferedType: [],
      resumeDocs: [],
      educationDocs: [],
      experienceDocs: [],
      insNoticeDocs: [],
      passportVisaI94Docs: [],
      formI20Docs: [],
      socialSecurityCardAndProfLicenseDocs: [],
      childDocumentArray: [
        {
          childvisa: [],
          childpassport: [],
          childformI94: [],
          childbirthCertificate: [],
        },
      ],
      childvisa: [],
      childpassport: [],
      childformI94: [],
      childbirthCertificate: [],
      visaDocuments: [],
      formI94: [],
      formI797Docs: [],
      marriageCertificateDocs: [],
      birthCertificate: [],
      // openDate: new Date().setFullYear(new Date().getFullYear() - 18),
      startEligibleDate: new Date().setFullYear(new Date().getFullYear() - 18),
      startBeneficiaryDateEntered: new Date().setFullYear(
        new Date().getFullYear() - 7
      ),
      SuccessQuestionnaire: false,
      formerrors: {
        msg: "",
      },
      vuePhone: {
        props: {
          translations: {
            phoneNumberLabel: "Phone Number",
          },
        },
      },
      petition: [],
      beneficiaryInfo: {
        firstName: "",
        lastName: "",
        email: "",
        "hasOtherNames": false,
        "otherNames": [{
        "firstName": "",
        "middleName": "",
        "lastName": ""
        }],
        cellPhoneCountryCode: { countryCode: "", countryCallingCode: "" },
        cellPhoneNumber: "",
        homePhoneNumber: "",
        homePhoneCountryCode: { countryCode: "", countryCallingCode: "" },
        gender: null,
        maritalStatus: "",
        education: {
          highestDegree: "",
          majorFieldOfStudy: "",
        },
        address: {
          line1:"" , 
          line2:"",
          countryId:'' ,
          stateId:'',
          locationId:'',
          zipcode:'',
          countryDetails:{ "_id": "626a8f03a972fa4d60681140", "id": 231, "name": "United States", "phoneCode": 1, "order": 1, "currencySymbol": "$", "currencyCode": "USD", "zipcodeLength": 5, "sortName": "united states" } ,
         stateDetails:null, 
         locationDetails:null 
         },
        
        hasI140ImmPetitionFiled: false,
        SSN: true,

        countryOfBirth: null,
        countryOfBirthDetails: null,
        provinceOfBirth: null,
        provinceOfBirthDetails: null,
        locationOfBirthDetails: null,
        locationOfBirth:null,
        countryOfCitizenship: null,
        countryOfCitizenshipDetails: null,
        I94: "",
        I94ExpiryDate:null,

        passportNumber: null,
        passportIssuedDate: null,
        passportExpiryDate: null,
        curNonImmigrantVisaStatus: "",
        curVisaExpiryDate: null,
        sevisNumber: "",
        fedNumber: "",
      },
      clientInfo: {
        address: {},
      },
      dependentsInfo: {
        spouse: {
          email: "",
          phoneNumber: "",
          phoneCountryCode: { countryCode: "", countryCallingCode: "" },
          h4Required: true,
          h4EADRequired: null,
          lastArrivalDate: null,
          statusExpiryDate: null,
          physicalAddress: {},
          provinceOfBirthDetails:null,
           locationOfBirthDetails: null,
           locationOfBirth:null,
          documents: {
            passport: [],
            visa: [],
            formI94: [],
            formI797: [],
            marriageCertificate: [],
            birthCertificate: [],
            noticeOfApprovalOfH1Status: [],
            payStubs: [],
            other: [],
          },
        },
        childrens: [
          {
            documents: {
              passport: [],
              visa: [],
              formI94: [],
              birthCertificate: [],
              other: [],
            },
          },
        ],
      },
      documents: {
        passportVisaI94: [],
        passport: [],
        resume: [],
        education: [],
        expLetters: [],
        INSNotices: [],

        formI20: [],
        I797NoticeofApprovalforI140:[],
        socialSecurityCardAndProfLicense: [],
        I140ApprovalNotice: [],
        payStubs: [],
        offerLetter: [],

        clientLetter: [],
        vendorLetter: [],
        ead: [],
        msa: [],
        po: [],
        h1bRegSelectionNotice: [],
        employmentAgreement: [],
        primeVendor: [],
        formI94: [],
        priorFormI797: [],
        other: [],
      },
      bncountryModel: {
          _id: "5db7f7409419e34350f11024",
          id: 231,
          name: "United States",
        },
      checkCountry: true,
      countries: [],
      states: [],
      clientstates: [],
      stateModel: [],
      locations: [],
      locationModel: [],
      marital_statuses: [],
      education_types: [],
      visastatuses: [],
      clientcountryModel: [],
      clientstateModel: [],
      clientlocationModel: [],
      clientlocations: [],
      spousecountryModel: [],
      suposestates: [],
      souuselocations: [],
      spouseaddresscountryModel: null,
      spouseaddressstateModel: null,
      spouseaddresslocationModel: null,

      chiildcountryModel: [],
      clientInfo_salaryFrequency_Details: [],
      priorstay: {
        enteredDate: null,
        departedDate: null,
        visaStatus: null,
      },
      priorPeriodOfStayInUS: [],
      childrensarray: [],
      children: [
        {
          h4Required: true,
          firstName: null,
          middleName: null,
          lastName: null,
          dateOfBirth: null,
          countryOfBirth: null,
          selectedcountryOfBirth: null,
          selectedcitizenship: null,
          passportNumber: null,
          passportExpiryDate: null,
          I94: null,
          visaIssuedDate: null,
          currentStatus: null,
          statusExpiryDate: null,
          documents: {},
        },
      ],
      countrySelected: "",
      countryOfCitizenshipSelected: "",
      latestPetition: "",

      //TEMPLATE CONFIGARATION START

      questionnaireTplId: null,
      questionnaireDetails: null,
      //TEMPLATE CONFIGARATION END
      isPhoneValid: true,
      isPhoneValidCount: 0,
      isHomePhoneValid: true,
      isHomePhoneValidCount: 0,
      isSpousePhoneValid: true,
      isSpousePhoneValidCount: 0,
      rernderApouseAddress:true
    };
  },
  computed: {
    checkReAssignRole() {
      let returnValue = false;
      if (this.pettion) {
        if ([50, 51].indexOf(this.getUserRoleId) > -1) {
          if ([50].indexOf(this.getUserRoleId) > -1) {
          } else if ([51].indexOf(this.getUserRoleId) > -1) {
          }
        }
      }
      return returnValue;
    },
  },
  methods: {

    setSpouseAddress(){
      // this.dependentsInfo.spouse.physicalAddress.countryDetails;
      //this.beneficiaryInfo.address
      /*
        line1:"" , 
        line2:"",
        countryId:'' ,
        stateId:'',
        locationId:'',
        zipcode:'',
        countryDetails:{ "_id": "626a8f03a972fa4d60681140", "id": 231, "name": "United States", "phoneCode": 1, "order": 1, "currencySymbol": "$", "currencyCode": "USD", "zipcodeLength": 5, "sortName": "united states" } ,
        stateDetails:null, 
        locationDetails:null 
      */
      if(
        this.checkProperty(this.beneficiaryInfo, "maritalStatus", "id") != 1 &&
       this.checkProperty(this.dependentsInfo , "spouse","physicalAddress" ) &&

       ( 
         this.checkProperty(this.beneficiaryInfo , "address","countryDetails" ) &&
         this.checkProperty(this.beneficiaryInfo , "address","stateDetails" )&&
         this.checkProperty(this.beneficiaryInfo , "address","locationDetails" )
        )
        &&( 

        
         this.checkProperty(this.dependentsInfo['spouse'] , "physicalAddress","stateId" ) ==''&&
         this.checkProperty(this.dependentsInfo['spouse'] , "physicalAddress","locationId" )=='' &&

         this.checkProperty(this.dependentsInfo['spouse'] , "physicalAddress","line1" ) ==''&&
         this.checkProperty(this.dependentsInfo['spouse'] , "physicalAddress","line2" )==''

        )
        
      ){
        this.rernderApouseAddress =false;

        this.dependentsInfo['spouse']['physicalAddress'] = _.cloneDeep(this.beneficiaryInfo['address'] )
        this.dependentsInfo = _.cloneDeep(this.dependentsInfo);
        setTimeout(()=>{
          this.rernderApouseAddress =true;
        } ,10)
        
        

      }


    },

    addOtherNames(){
     // "hasOtherNames": false,
     
     let item = { "firstName": "",  "middleName": "", "lastName": "" };
     this.beneficiaryInfo['otherNames'].push(item);
 
    
   },
   removeOtherName(index){
    
      this.beneficiaryInfo['otherNames'].splice(index ,1)

   },
   resetOtherNames(){

    this.petition
      
        this.beneficiaryInfo['otherNames'] = [];
        this.addOtherNames();
        if( this.checkProperty(this.beneficiaryInfo , 'hasOtherNames') ){
         // alert(JSON.stringify(this.petition['beneficiaryInfo']['otherNames']))
          if(this.checkProperty(this.petition ,'beneficiaryInfo' , 'otherNames')){
           

             // this.beneficiaryInfo['otherNames'] = this.petition['beneficiaryInfo']['otherNames'];

            

          }

         
        }
       
     
    
   },
        
    
    childPassportUpdated(item) {
      if (
        this.checkProperty(item, "passportNumber") == "" ||
        this.checkProperty(item, "passportNumber") == null ||
        this.checkProperty(item, "passportNumber") == undefined
      ) {
        item["passportExpiryDate"] = null;
      }
    },

    spousePassportChanged() {
      if (
        this.checkProperty(this.dependentsInfo, "spouse", "passportNumber") ==
          "" ||
        this.checkProperty(this.dependentsInfo, "spouse", "passportNumber") ==
          null ||
        this.checkProperty(this.dependentsInfo, "spouse", "passportNumber") ==
          undefined
      ) {
        this.dependentsInfo["spouse"]["passportExpiryDate"] = null;
      }
    },
    benPassportUpdated() {
      if (
        this.checkProperty(this.beneficiaryInfo, "passportNumber") == "" ||
        this.checkProperty(this.beneficiaryInfo, "passportNumber") == null
      ) {
        this.beneficiaryInfo["passportExpiryDate"] = null;
        this.beneficiaryInfo["passportIssuedDate"] = null;
        // this.beneficiaryInfo['curVisaExpiryDate'] =null;
      }
    },

    selectCountryOfCitizenship(item) {
      this.beneficiaryInfo.countryOfCitizenship = this.checkProperty(
        item,
        "id"
      );
    },
    selectcountryOfBirth(item, setDefault = false) {
      this.beneficiaryInfo.countryOfBirth = null;
      this.beneficiaryInfo.countryOfBirth = this.checkProperty(item, "id");
      if (!setDefault) {
        this.beneficiaryInfo.provinceOfBirth = null;
        this.beneficiaryInfo.provinceOfBirthDetails = null;
         //this.beneficiaryInfo.locationOfBirth =null
         this.beneficiaryInfo.locationOfBirthDetails =null
         this.provinceLocations = [];
      }

      this.provinceStates = [];
      if (this.beneficiaryInfo.countryOfBirth) {
        this.$store.dispatch("getstates", item["id"]).then((response) => {
          this.provinceStates = response;
        });
      }
    },
    selectProvinceOfBirth(item ,isInput=true) {
      this.beneficiaryInfo.provinceOfBirth = null;
      if (this.checkProperty(item, "id")) {
        this.beneficiaryInfo.provinceOfBirth = item["id"];
        this.getBenLocationsOfBirth(this.beneficiaryInfo.provinceOfBirth ,isInput)
      }
    },
    

     getBenLocationsOfBirth(stateId , isInput=false){

        this.provinceLocations = [];
      if (this.beneficiaryInfo.provinceOfBirth) {
      this.$store.dispatch("getlocations", {'stateId':stateId}).then((response) => {
      this.provinceLocations = response;
      
      if(isInput==true || isInput==null ){
        // this.beneficiaryInfo.locationOfBirth =null
         this.beneficiaryInfo.locationOfBirthDetails =null
        

       }
      
      });
      }

    },
    
     selectLocationOfBirth(item){
      
      this.beneficiaryInfo.locationOfBirth = null;
      if (this.checkProperty(item, "id")) {
        this.beneficiaryInfo.locationOfBirth = item["id"];
      }

    },
   
   

    submitreAssignAction() {
      let self = this;
      let petitionDetails = this.petition;
      let selectedAssignToReviewer = null;

      if ([50].indexOf(self.getUserRoleId) > -1) {
        selectedAssignToReviewer = self.checkProperty(
          self.petition,
          "ptnrReassignRefUserId"
        );
      } else if ([51].indexOf(self.getUserRoleId) > -1) {
        selectedAssignToReviewer = self.checkProperty(
          self.petition,
          "benfReassignRefUserId"
        );
      }
      if (
        self.checkProperty(self.petition, "benfReassignRefUserId") &&
        self.checkProperty(self.petition, "ptnrReassignRefUserId")
      ) {
        selectedAssignToReviewer = self.checkProperty(
          self.petition,
          "benfReassignRefUserId"
        );
      }

      let postData = {
        petitionId: "",
        userId: "",
        userName: "",
        roleId: "",
        typeName: "",
        subTypeName: "",
        comment: "",
        reviewQuestionnaire: true,
      };
      postData["petitionId"] = self.checkProperty(petitionDetails, "_id");
      postData["userId"] = selectedAssignToReviewer;
      //  postData['userName'] = self.checkProperty(selectedAssignToReviewer ,'roleName');
      //  postData['roleId'] = self.checkProperty(selectedAssignToReviewer ,'roleId');
      postData["typeName"] = self.checkProperty(
        petitionDetails,
        "typeDetails",
        "name"
      );
      postData["subTypeName"] = self.checkProperty(
        petitionDetails,
        "subTypeDetails",
        "name"
      );
      postData["comment"] = self.comments;

      this.$store
        .dispatch("commonAction", {
          data: postData,
          path: "/petition/reassign",
        })
        .then((response) => {
          this.showToster({ message: response.message, isError: false });

          this.commentPopUp = false;
          this.SuccessQuestionnaire = true;
          document.addEventListener("click", this.reloadthePage);
        })
        .catch((err) => {
          //alert(JSON.stringify(err))
          this.formerrors.msg = err;
        });
    },

    formSubmitted(callFromSave = false) {

     
      Object.assign(this.formerrors, { msg: "" });
      let self =this;
      if (
        (this.checkProperty(this.petition, "ptnrReassignRefUserId") ||
          this.checkProperty(this.petition, "benfReassignRefUserId")) &&
        [50, 51].indexOf(this.getUserRoleId) > -1 &&
        this.checkProperty(this.petition, "questionnaireFilled") &&
        this.comments.trim() == "" &&
        callFromSave == false
      ) {
        this.callFromSave = callFromSave;
        this.commentPopUp = true;
        this.$validator.reset("commentForm");
        return false;
      }

      if (this.childrensarray.length > 0) {
        this.dependentsInfo.childrens = this.childrensarray;
      }
      var postpetition = {
        petitionId: this.$route.params.itemId,
        questionnaireFilled: false,
        userName: this.$store.state.user.name,
        typeName: this.petition.typeDetails.name,
        subTypeName: this.petition.subTypeDetails.name,
        action: "BENEFICIARY_INFO_UPDATE",
        currentDate: moment().format("YYYY-MM-DD"),
        beneficiaryInfo: _.cloneDeep(this.beneficiaryInfo),
        dependentsInfo: this.dependentsInfo,
        clientInfo: this.clientInfo,
        documents: this.documents,
      };

      if (callFromSave == true) {
        postpetition["temp_save"] = true;
      } else {
        postpetition["action"] = "SUBMIT_BY_BENEFICIARY";
        postpetition["questionnaireFilled"] = true;

        if (
          this.checkProperty(this.beneficiaryInfo, "maritalStatus", "id") == 1
        ) {
          postpetition["dependentsInfo"] = this.defaultDependentsInfo;
          postpetition["dependentsInfo"]["childrens"] = [];
        }
      }
      postpetition.beneficiaryInfo.priorPeriodOfStayInUS =
        this.priorPeriodOfStayInUS;

      if (
        this.checkProperty(this.beneficiaryInfo, "education", "highestDegree")
      ) {
        if (_.has(this.beneficiaryInfo.education.highestDegree, "id")) {
          postpetition["beneficiaryInfo"]["education"]["highestDegree"] =
            this.beneficiaryInfo.education.highestDegree["id"];
        }
      }

      if (this.checkProperty(this.beneficiaryInfo, "maritalStatus", "id")) {
        postpetition["beneficiaryInfo"]["maritalStatus"] =
          this.beneficiaryInfo.maritalStatus["id"];
      }
      if (this.checkProperty(this.petition, "questionnaireFilled")) {
        postpetition = Object.assign(postpetition, {
          questionnaireUpdate: true,
          questionnaireFilled: false,
          temp_save: false,
          action: "BENEFICIARY_INFO_UPDATE",
          questionnaireFilled: false,
          comments: "",
        });
        postpetition["comments"] = this.comments;
      }

      if (
        this.checkProperty(postpetition, "beneficiaryInfo", "passportNumber") ==
          "" ||
        this.checkProperty(postpetition, "beneficiaryInfo", "passportNumber") ==
          null
      ) {
        postpetition["beneficiaryInfo"]["passportExpiryDate"] = null;
        postpetition["beneficiaryInfo"]["passportIssuedDate"] = null;
      }

      if (
        this.checkProperty(
          postpetition["dependentsInfo"],
          "spouse",
          "passportNumber"
        ) == "" ||
        this.checkProperty(
          postpetition["dependentsInfo"],
          "spouse",
          "passportNumber"
        ) == null
      ) {
        postpetition["dependentsInfo"]["spouse"]["passportExpiryDate"] = null;
      }
      if(!this.beneficiaryInfo.hasOtherNames){
        postpetition["beneficiaryInfo"]['otherNames'] =[];
      }
      if([5, 8].indexOf(this.petition.subTypeDetails.id) >-1){
        postpetition['dependentsInfo'] = {  'spouse':{}, 'childrens':[]};
      }
      let newDocuments =[];
      //newly added beneficiary Documents
       let checkNewlyAddedDocuments =function (documents ,category=''){
        // alert(category)
        _.forEach(documents ,(docs, key)=>{
         _.filter(docs ,{ isNew:true ,status:true} ).map((doc)=>{
           doc = Object.assign(doc, {'docType':''})
           doc['docType'] = category+(key.charAt(0).toUpperCase() + key.slice(1));
           newDocuments.push(doc);
           doc.isNew =false;

         })
      })


      }
      if(Object.entries(postpetition['documents'] ).length>0){
      
       checkNewlyAddedDocuments(postpetition['documents'] ,'');
      }

       
      if(Object.entries(this.dependentsInfo['spouse']['documents'] ).length>0){
       checkNewlyAddedDocuments(this.documents ,'spouse')
      }
      
     
     // childrens Newly add Documents
     if(this.checkProperty(this.dependentsInfo , 'childrens' ,"length")>0 ){

       _.forEach(this.dependentsInfo['childrens'] ,(child)=>{
          if(Object.entries(child['documents'] ).length>0){

              checkNewlyAddedDocuments(child.documents ,'child');

          }
       })

     }
      postpetition =Object.assign(postpetition,{'newDocs':newDocuments})

    
      this.$store
        .dispatch("petitioner/petitionupdate", postpetition)
        .then((response) => {
          if (this.checkProperty(response, "error")) {
            Object.assign(this.formerrors, {
              msg: response.error.message,
            });
            if (this.comment == "") {
              this.showToster({
                message: response.error.message,
                isError: true,
              });
            }
            this.comments = "";
            if (this.commentPopUp) {
              this.$validator.reset("commentForm");
            }
          } else {
            if (
              (this.checkProperty(this.petition, "ptnrReassignRefUserId") ||
                this.checkProperty(this.petition, "benfReassignRefUserId")) &&
              [50, 51].indexOf(this.getUserRoleId) > -1 &&
              this.checkProperty(this.petition, "questionnaireFilled") &&
              this.comments.trim() != "" &&
              callFromSave == false
            ) {
              this.submitreAssignAction();
            } else {
              this.commentPopUp = false;
              if (callFromSave == false) {
                this.SuccessQuestionnaire = true;

                document.addEventListener("click", this.reloadthePage);
              } else {
                this.showToster({
                  message: "Questionnaire saved successfully",
                  isError: false,
                });
              }
            }
          }
        })
        .catch((err) => {
          this.comments = "";
          if (err.error) {
            Object.assign(this.formerrors, {
              msg: err.error.message,
            });
          }
          //  alert(JSON.stringify(err))
          this.showToster({ message: err.error.message, isError: true });
        });
    },

    updateSpousePhone(item) {
      this.isSpousePhoneValid = true;

      if (item.isValid) {
        this.dependentsInfo["spouse"]["phoneCountryCode"] = {
          countryCode: item.countryCode,
          countryCallingCode: item.countryCallingCode,
        };
        this.dependentsInfo["spouse"]["phoneNumber"] = item.nationalNumber;
      } else {
        if (this.isSpousePhoneValidCount > 0) {
          this.isSpousePhoneValid = false;
        }
      }
      this.isSpousePhoneValidCount = this.isSpousePhoneValidCount + 1;
    },
    updatePhone(item) {
      this.isPhoneValid = true;

      if (item.isValid) {
        this.beneficiaryInfo.cellPhoneCountryCode = {
          countryCode: item.countryCode,
          countryCallingCode: item.countryCallingCode,
        };
        this.beneficiaryInfo.cellPhoneNumber = item.nationalNumber;
      } else {
        if (this.isPhoneValidCount > 0) {
          this.isPhoneValid = false;
        } else {
          this.$validator.reset("beneficiaryInfoform");
        }
      }
      this.isPhoneValidCount = this.isPhoneValidCount + 1;
    },
    updateHomePhone(item) {
      this.isHomePhoneValid = true;
      if (item.isValid) {
        this.beneficiaryInfo.homePhoneCountryCode = {
          countryCode: item.countryCode,
          countryCallingCode: item.countryCallingCode,
        };
        this.beneficiaryInfo.homePhoneNumber = item.nationalNumber;
      } else {
        if (this.isHomePhoneValidCount > 0) {
          this.isHomePhoneValid = false;
        } else {
          this.$validator.reset("beneficiaryInfoform");
        }
      }
      this.isHomePhoneValidCount = this.isHomePhoneValidCount + 1;
    },

    getquestionnaireDetails() {
      let postData = { questionnaireId: this.questionnaireTplId };
      this.$store
        .dispatch("commonAction", {
          data: postData,
          path: "/questionnaire/details",
        })
        .then((res) => {
          //alert(JSON.stringify(res.name));
          this.questionnaireDetails = res;
          let iam_from_us =
            _.findIndex(this.questionnaireDetails.fields, (el) => {
              return el == "iam_from_us";
            }) > -1
              ? true
              : false;
          let iam_notfrom_us =
            _.findIndex(this.questionnaireDetails.fields, (el) => {
              return el == "iam_notfrom_us";
            }) > -1
              ? true
              : false;
          this.onlyimFromUs = false;
          this.beneficiaryInfo.iAmFromUS = "false";

          if (iam_from_us && !iam_notfrom_us) {
            this.onlyimFromUs = true;
            this.beneficiaryInfo.iAmFromUS = "true";
            this.setDefaultcountry();
          }
          if (!iam_from_us && iam_notfrom_us) {
            this.onlyimFromUs = true;
            this.beneficiaryInfo.iAmFromUS = "false";
            this.setDefaultcountry();
          }
          if ( ([5, 8].indexOf(this.petition.subTypeDetails.id) < 0) ) {
            this.checkCountry = false;
             this.onlyimFromUs = true;
            this.beneficiaryInfo.iAmFromUS = "true";
            this.setDefaultcountry();
          }else{
              this.checkCountry = true;
          }

         
        });
    },
    setSpouseZipcode() {
      if (
        !this.dependentsInfo.spouse.physicalAddress.zipcode &&
        this.beneficiaryInfo.address.zipcode
      ) {
        this.dependentsInfo.spouse.physicalAddress.zipcode =
          this.beneficiaryInfo.address.zipcode;
      }
    },
    setDependentsInfoAddress(isStreetAddress = true) {
      if (
        isStreetAddress &&
        this.beneficiaryInfo.address.line2 != "" &&
        !this.dependentsInfo.spouse.physicalAddress.line2
      ) {
        this.dependentsInfo.spouse.physicalAddress.line2 =
          this.beneficiaryInfo.address.line2;
      }

      if (
        !isStreetAddress &&
        this.beneficiaryInfo.address.line1 != "" &&
        !this.dependentsInfo.spouse.physicalAddress.line1
      ) {
        this.dependentsInfo.spouse.physicalAddress.line1 =
          this.beneficiaryInfo.address.line1;
      }
    },

    setH4EADValue(h4, value) {
      this.dependentsInfo.spouse.h4EADRequired = h4 ? value : null;
    },
    setDefaultcountry() {
         this.bncountryModel = {
          _id: "5db7f7409419e34350f11024",
          id: 231,
          name: "United States",
        }
          this.selectCountry(this.bncountryModel);

      //this.$validator.reset('beneficiaryInfoform');
    },
    isDisabled(model) {
      if (model && model.length == 1) return false;
      return true;
    },
    acceptNumber() {
      var x = this.value
        .replace(/\D/g, "")
        .match(/(\d{0,3})(\d{0,3})(\d{0,4})/);
      this.value = !x[2]
        ? x[1]
        : "(" + x[1] + ") " + x[2] + (x[3] ? "-" + x[3] : "");
    },
    selectLocation(option) {
      this.beneficiaryInfo.address.locationId = option.id;

      this.dependentsInfo.spouse.physicalAddress.locationId = option.id;
      this.spouseaddresslocationModel = option;
      this.getSuposeLocation();
    },
    selectclientLocation(option) {
      this.clientInfo.address.locationId = option.id;
    },
    selectclientState(option) {
      this.clientlocations = [];
      this.clientInfo.address.stateId = option.id;
      this.clientlocationModel = [];
      this.getclientLocation();
    },
    selectclientCountry(option) {
      this.clientInfo.address.countryId = option.id;
      this.getclientStates();
    },

    selectspouseaddresstLocation(option) {
      this.dependentsInfo.spouse.physicalAddress.locationId = option.id;
    },
    selectspouseaddressState(option) {
      // this.spouseaddressstateModel=null;
      this.spouseaddresslocationModel = null;
      // this.suposestates =[];
      // this.souuselocations =[];
      this.dependentsInfo.spouse.physicalAddress.stateId = this.checkProperty(
        option,
        "id"
      );
      // this.spouseaddresslocationModel = [];
      this.getSuposeLocation();
    },
    editspouseaddressCountry(option, stateoption) {
      //this.spouseaddressstateModel=null;
      this.spouseaddresslocationModel = null;
      // this.suposestates =[];
      // this.souuselocations =[];
      this.dependentsInfo.spouse.physicalAddress.countryId = option.id;
      this.editgetSuposeStates();
    },
    selectspouseaddressCountry(option) {
      //this.spouseaddressstateModel=null;
      this.spouseaddresslocationModel = null;
      // this.suposestates =[];
      // this.souuselocations =[];
      this.dependentsInfo.spouse.physicalAddress.countryId = option.id;
      this.getSuposeStates();
    },

    selectState(option, callFromInit = false) {
      this.beneficiaryInfo.address.stateId = option.id;
      this.locationModel = null;
      this.locations = [];

          this.spouseaddressstateModel =  _.find(this.states, {
              id: option.id,
            });
            this.selectspouseaddressState(this.spouseaddressstateModel);


      this.getLocation(callFromInit);

      //this.spouseaddressstateModel   = option;
      this.dependentsInfo.spouse.physicalAddress.stateId = option.id;
      this.getSuposeLocation();
    },
    getLocation(callFromInit = false) {
      var obj = {
        stateId: this.beneficiaryInfo.address.stateId,
        countryId: this.beneficiaryInfo.address.countryId,
      };

      this.$store.dispatch("getlocations", obj).then((response) => {
        this.locations = response;
        setTimeout(() => {
          if (
            callFromInit &&
            _.has(this.beneficiaryInfo, "address", "locationDetails")
          ) {
            this.locationModel = _.find(this.locations, {
              id: this.beneficiaryInfo.address.locationDetails["id"],
            });

            this.spouseaddresslocationModel = this.locationModel;
          }
        }, 100);
      });
    },
    selectCountry(option, callFromInit = false) {
      this.beneficiaryInfo.address.countryId = option.id;

      this.locationModel = null;
      this.stateModel = null;
      this.locations = [];
      this.states = [];
      this.getStates(callFromInit);

      // alert(callFromInit);

      this.spouseaddresscountryModel = option;
      this.dependentsInfo.spouse.physicalAddress.countryId = option.id;
      this.getSuposeStates();
    },
    getStates(callFromInit) {
      this.$store
        .dispatch("getstates", this.beneficiaryInfo.address.countryId)
        .then((response) => {
          this.states = response;
          this.locationModel = null;
          this.stateModel = null;
          this.locations = [];
          if (
            callFromInit &&
            _.has(this.beneficiaryInfo, "address", "stateDetails")
          ) {
            this.stateModel = _.find(this.states, {
              id: this.beneficiaryInfo.address.stateDetails["id"],
            });
            this.spouseaddressstateModel =  _.find(this.states, {
              id: this.beneficiaryInfo.address.stateDetails["id"],
            });
            this.selectspouseaddressState(this.spouseaddressstateModel);

            this.selectState(this.stateModel, true);
          }
        });
    },
    getclientStates() {
      this.$store
        .dispatch("getstates", this.clientInfo.address.countryId)
        .then((response) => {
          this.clientstates = response;
        });
    },

    getclientLocation() {
      var obj = {
        stateId: this.clientInfo.address.stateId,
        countryId: this.clientInfo.address.countryId,
      };

      this.$store.dispatch("getlocations", obj).then((response) => {
        this.clientlocations = response;

        if (!this.spouseaddresslocationModel) {
          this.spouseaddresslocationModel = this.locationModel;
          this.selectspouseaddresstLocation(this.spouseaddresslocationModel);
        }
      });
    },

    editgetSuposeStates() {
      this.$store
        .dispatch(
          "getstates",
          this.dependentsInfo.spouse.physicalAddress.countryId
        )
        .then((response) => {
          this.suposestates = response;
          var obj = {
            stateId: this.dependentsInfo.spouse.physicalAddress.stateId,
            countryId: this.dependentsInfo.spouse.physicalAddress.countryId,
          };
          
          this.spouseaddressstateModel =
            this.dependentsInfo.spouse.physicalAddress.stateDetails;

          this.$store.dispatch("getlocations", obj).then((response) => {
            this.souuselocations = response;
            this.spouseaddresslocationModel =
              this.dependentsInfo.spouse.physicalAddress.locationDetails;
            // if(!this.spouseaddresslocationModel){
            //   this.spouseaddresslocationModel =this.locationModel
            //   this.selectspouseaddresstLocation(this.spouseaddresslocationModel)
            // }
          });
        });
    },
    getSuposeStates() {
      this.$store
        .dispatch(
          "getstates",
          this.dependentsInfo.spouse.physicalAddress.countryId
        )
        .then((response) => {
          this.suposestates = response;

          if (this.spouseaddressstateModel != null) {
            this.spouseaddressstateModel = this.stateModel;
            this.selectspouseaddressState(this.spouseaddressstateModel);
          }
        });
    },
    getSuposeLocation() {
      var obj = {
        stateId: this.dependentsInfo.spouse.physicalAddress.stateId,
        countryId: this.dependentsInfo.spouse.physicalAddress.countryId,
      };

      this.$store.dispatch("getlocations", obj).then((response) => {
        this.souuselocations = response;

        // if(!this.spouseaddresslocationModel){
        //   this.spouseaddresslocationModel =this.locationModel
        //   this.selectspouseaddresstLocation(this.spouseaddresslocationModel)
        // }
      });
    },
    beforedocumentsTabSwitch() {
      //this.$validator.reset();
      let _self =this;
      if (
        this.checkProperty(this.beneficiaryInfo, "maritalStatus", "id") != 1
      ) {
       
        this.setSpouseAddress();
        $("html, body").animate({ scrollTop: 0 }, 500);
      }


      if(

        [5, 8].indexOf(this.petition.subTypeDetails.id) < 0 &&
              (this.checkTemplateField('child_h4_required') ||
                this.checkTemplateField('spouse_h4_required')) &&
              this.checkProperty(this.beneficiaryInfo, 'maritalStatus') &&
              this.checkProperty(this.beneficiaryInfo, 'maritalStatus', 'id') &&
              this.checkProperty(this.beneficiaryInfo, 'maritalStatus', 'id') !== 1
            
      ){

      

      this.$validator.validateAll('documentsInfoform').then((result) => {

          if(result){
            _self.formSubmitted(true);
          }
        });
      }

      return this.validateStep("documentsInfoform");
      // return true;
    },
    beforeTabSwitch() {
      let _self =this;
      //this.$validator.reset();
      //checkTemplateField('cell_phone_number') || checkTemplateField('home_phone_number')
      if (
        (!this.isPhoneValid && this.checkTemplateField("cell_phone_number")) ||
        (!this.isHomePhoneValid && this.checkTemplateField("home_phone_number"))
      ) {
        const $ = JQuery;
        const firstField = "cellPhoneNumber";
        const ele = $("[name=" + firstField + "]").parents(".vx-col");
        $("html, body").animate({ scrollTop: ele.offset().top }, 500);
        return false;
      } else {
      
        this.$validator.validateAll('beneficiaryInfoform').then((result) => {

          if(result){
            _self.formSubmitted(true);
          }
        });
       
        return this.validateStep("beneficiaryInfoform")
      }

      // return true;
    },
    beforeClient() {
      //this.$validator.reset();
      return this.validateStep("clientInfoform");
      // return true;
    },
    beforeDependents() {
      //this.$validator.reset();
      this.dependentsInfo.childrens = this.childrensarray;

      



      //  return true;
      return this.validateStep("dependentsInfoform");
    },
    async validateStep(step) {
      const result = await this.$validator.validateAll(step).then((result) => {
        return result;
      });
      // to fix v mast as temp
      if (
        this.$validator &&
        this.$validator.errors &&
        this.$validator.errors.items &&
        this.$validator.errors.items.length == 1 &&
        this.$validator.errors.items[0].field == "spouse_ssn"
      ) {
        $("html, body").animate({ scrollTop: 0 }, 500);
        return true;
      }

      if (result) {
        this.$validator.reset();

        if (step != "dependentsInfoform") {
          $("html, body").animate({ scrollTop: 0 }, 500);
        }
      } else {
        const $ = JQuery;
        const firstField = Object.keys(this.errors.collect())[0];
        const ele = $("[name=" + firstField + "]").parents(".vx-col");
        var _top = 0;
        if (ele) {
          _top = ele.offset().top;
        }
        $("html, body").animate({ scrollTop: ele.offset().top }, 500);
      }
      return result;
    },
    setGender(item) {
      this.beneficiaryInfo.gender = item;
    },
    addpriorstay: function () {
      this.priorstay = {
        enteredDate: null,
        departedDate: null,
        visaStatus: null,
      };
      this.priorPeriodOfStayInUS.push(this.priorstay);
    },
    removepriorstay: function (index) {
      Vue.delete(this.priorPeriodOfStayInUS, index);
    },
    addchildren: function () {
      (this.children = {
        h4Required: true,
        firstName: null,
        middleName: null,
        lastName: null,
        dateOfBirth: null,
        countryOfBirth: null,
        passportNumber: null,
        passportExpiryDate: null,
        I94: null,
        visaIssuedDate: null,
        currentStatus: null,
        statusExpiryDate: null,
        documents: {
          passport: [],
          visa: [],
          FormI94: [],
          formI797: [],
          birthCertificate: [],
          approvalNotice: [],
          other: [],
        },
      }),
        this.childrensarray.push(this.children);
    },
    removechildren: function (index) {
      Vue.delete(this.childrensarray, index);
      return false;
    },
    reloadthePage() {
          let routeTest = this.$route.params.itemId
         
          var _self = this;
          if(  this.SuccessQuestionnaire ){
              this.SuccessQuestionnaire = false;
          }
         setTimeout(() =>{
          let currentRoute  = _self.$route;
             
          if( _.get( currentRoute,'name' ,'') =='fill-questionnaire' &&  _.has(currentRoute ,"meta.getTokenFromUrl") && (_.has(currentRoute, "query.token")) ){
           
               let token = _.get( currentRoute,"query.token",'')
              let url = "/filled-case-details/"+routeTest+"?token="+token;
            //   window.location.href = window.location.origin+'/app'+url
              _self.$router.push(url);
          }else{
            if(_self.checkProperty(_self.petition ,'rfeCase')){
              _self.$router.push("/rfe-petition-details/"+routeTest);


            }else{
               _self.$router.push("/petition-details/"+routeTest);

            }

           

          }
                  
       
        } ,10);
       
      },

    upload(model) {
   
      let mapper = model.map(
        (item) =>
          (item = {
            name: item.name,
            file: item.file ? item.file : null,
            url: item.url ? item.url : "",
            path: item.path ? item.path : "",
            isNew:item.isNew?item.isNew:false,
           // docTypeName : item.docTypeName?item.docTypeName:'',
            status:
              item.status === false || item.status === true
                ? item.status
                : true,
            mimetype: item.type ? item.type : item.mimetype,
          })
      );
      if (mapper.length > 0) {
        mapper.forEach((doc, index) => {
          if(doc.file){
          let formData = new FormData();
          formData.append("files", doc.file);
          formData.append("secureType", "private");
          this.$store.dispatch("uploadS3File", formData).then((response) => {
            response.data.result.forEach((urlGenerated) => {
              doc.isNew=true;
            //  doc.docTypeName = docTypeName;
              doc.url = urlGenerated;
              doc.path = urlGenerated;
              delete doc.file;
              mapper[index] = doc;
            });
          });
        }
        });
        model.splice(0, mapper.length, ...mapper);
      }
    },
    remove(item, type) {
      item.status = false;
      type[type.indexOf(item)] = item;
      return false;
    },
    selectchildCountry(option, id) {
      this.childrensarray[id].countryOfBirth = option.id;
    },
    selectchildCitizenship(option, id) {
      this.childrensarray[id].countryOfCitizenship = option.id;
    },
    getspouseProvinceStates(countryId , isInput=false){

        this.spouseProvinceStates = [];
      if (this.dependentsInfo.spouse.countryOfBirth) {
      this.$store.dispatch("getstates", countryId).then((response) => {
      this.spouseProvinceStates = response;
      if(isInput){
        this.dependentsInfo.spouse.provinceOfBirthDetails =null
         this.dependentsInfo.spouse.provinceOfBirth =null
        // this.dependentsInfo.spouse.locationOfBirth =null
     //    this.dependentsInfo.spouse.locationOfBirthDetails =null

       }
      
      });
      
      }

    },

     selectSpouseProvinceOfBirth(item) {
      this.dependentsInfo['spouse'].provinceOfBirth = null;
      if (this.checkProperty(item, "id")) {
        this.dependentsInfo['spouse'].provinceOfBirth = item["id"];
        
        this.getSpouseLocationsOfBirth(this.dependentsInfo['spouse'].provinceOfBirth  , true);
      }
    },

    //getlocations
    getSpouseLocationsOfBirth(stateId , isInput=false){

        this.spouseProvinceLocations = [];
      if (this.dependentsInfo.spouse.provinceOfBirth) {
      this.$store.dispatch("getlocations", {'stateId':stateId}).then((response) => {
      this.spouseProvinceLocations = response;
      
      if(isInput){
      //   this.dependentsInfo.spouse.locationOfBirth =null
       //  this.dependentsInfo.spouse.locationOfBirthDetails =null
        

       }
      
      });
      }

    },
    selectSpouseLocationOfBirth(item){
      
      this.dependentsInfo['spouse'].locationOfBirth = null;
      if (this.checkProperty(item, "id")) {
        this.dependentsInfo['spouse'].locationOfBirth = item["id"];
       
      }
    //   alert(this.dependentsInfo['spouse'].locationOfBirth)

    },

    selectspouseCountry(option) {
      this.dependentsInfo.spouse.countryOfBirth = option.id;

       if(this.dependentsInfo.spouse.countryOfBirth){
         this.getspouseProvinceStates(this.dependentsInfo.spouse.countryOfBirth, true);
        
       }
     
        this.spouseProvinceLocations =[];
       // this.dependentsInfo.spouse.locationOfBirth =null
       //  this.dependentsInfo.spouse.locationOfBirthDetails =null


    },
    selectspousecountryOfCitizenship(option) {
      this.dependentsInfo.spouse.countryOfCitizenship = option.id;
    },
    getSalary_frequencies() {
      this.$store
        .dispatch("get_salary_frequencies", this.clientInfo.address.countryId)
        .then((response) => {
          this.salaryOfferedType = response;
        });
    },
    getLatestPetition() {
      this.$store
        .dispatch("getlatestpetition", this.petition.userId)
        .then((response) => {
          this.$store
            .dispatch("getpetition", response[0]._id)
            .then((details) => {
              this.latestPetition = details.data.result;
              if (this.latestPetition.beneficiaryInfo) {
                this.beneficiaryInfo = this.latestPetition.beneficiaryInfo;
                this.documents = this.latestPetition.documents;
                if (
                  this.beneficiaryInfo &&
                  this.beneficiaryInfo.address &&
                  this.beneficiaryInfo.address.countryDetails
                ) {
                  this.bncountryModel =
                    this.beneficiaryInfo.address.countryDetails;
                  this.selectCountry(
                    this.beneficiaryInfo.address.countryDetails
                  );
                  this.selectState(this.beneficiaryInfo.address.stateDetails);
                  //this.stateModel = this.beneficiaryInfo.address.stateDetails;
                  // this.locationModel =this.beneficiaryInfo.address.locationDetails;
                }
                this.priorPeriodOfStayInUS =
                  this.beneficiaryInfo.priorPeriodOfStayInUS;
              }
            });
        });
    },

    checkTemplateField(checkKey = "") {
      let return_value = true;
      if (checkKey != "" && _.has(this.questionnaireDetails, "fields")) {
        return_value =
          _.findIndex(this.questionnaireDetails.fields, (el) => {
            return el == checkKey;
          }) > -1
            ? true
            : false;
      }

      //this.$validator.reset();

      return return_value;
    },
    getAllCountryes() {
      this.$store.dispatch("getcountries").then((response) => {
        this.countries = response;
        (this.clientcountryModel = {
          _id: "5db7f7409419e34350f11024",
          id: 231,
          name: "United States",
        }),
          this.selectclientCountry(this.clientcountryModel);
      });
    },
    prefilltheDetails(){

      if(this.showPrefilldetails){

        this.beneficiaryInfo = this.showPrefilldetails["beneficiaryInfo"];
 
          this.beneficiaryInfo.maritalStatus = "";

        this.beneficiaryInfo.education = {
          highestDegree: "",
          majorFieldOfStudy: "",
        }

      if (this.beneficiaryInfo.countryOfBirthDetails) {
        this.provinceStates = [];
        this.$store.dispatch("getstates", this.beneficiaryInfo.countryOfBirthDetails["id"]).then((response) => {
          this.provinceStates = response;
        });
      }

          this.beneficiaryInfo.address = {}
                   if(this.showPrefilldetails["dependentsInfo"]){
                this.dependentsInfo = this.showPrefilldetails["dependentsInfo"];

                }

      }

          

                
    },
    upDatehighestDegree() {
      if (
        this.education_types &&
        this.education_types.length > 0 &&
        this.checkProperty(this.petition, "beneficiaryInfo", "education")
      ) {
        if (
          this.checkProperty(
            this.petition["beneficiaryInfo"],
            "education",
            "highestDegree"
          )
        ) {
          if (
            this.checkProperty(
              this.petition["beneficiaryInfo"]["education"],
              "highestDegreeDetails"
            )
          ) {
            this.beneficiaryInfo.education.highestDegree =
              this.petition["beneficiaryInfo"]["education"][
                "highestDegreeDetails"
              ];
          }
        }
      }

      //update maritalStatus
      if (
        this.checkProperty(
          this.petition,
          "beneficiaryInfo",
          "maritalStatusDetails"
        )
      ) {
        this.beneficiaryInfo.maritalStatus =
          this.petition["beneficiaryInfo"]["maritalStatusDetails"];
      }
    },
  },
  beforeDestroy() {
  
    document.removeEventListener("click", this.reloadthePage);
  },
  mounted() {
    JQuery("#btnSidebarToggler").click();
    var _self = this;

    // this.$store.commit('UPDATE_SIDEBAR_ITEMS_MIN', true);
    // this.$store.dispatch('updateSidebarWidth', 'reduced')
    this.getAllCountryes();
    this.priorPeriodOfStayInUS = [
      {
        enteredDate: null,
        departedDate: null,
        visaStatus: null,
      },
    ];
    this.childrensarray = [
      {
        h4Required: true,
        firstName: null,
        middleName: null,
        lastName: null,
        dateOfBirth: null,
        countryOfBirth: null,
        passportNumber: null,
        passportExpiryDate: null,
        I94: null,
        visaIssuedDate: null,
        currentStatus: null,
        statusExpiryDate: null,
        documents: {
          passport: [],
          visa: [],
          formI94: [],
          birthCertificate: [],
          other: [],
        },
      },
    ];
    if (this.getUserRoleId == 51) {
      this.beneficiaryInfo.firstName = this.$store.state.user.firstName;
      this.beneficiaryInfo.lastName = this.$store.state.user.lastName;
      this.beneficiaryInfo.email = this.$store.state.user.email;

      var bphone = this.$store.state.user.phone;
      if (
        this.$store.state.user.phone 
      //&& this.beneficiaryInfo.cellPhoneNumber == undefined
      ) {
        this.beneficiaryInfo.cellPhoneNumber = bphone;
        if (this.$store.state.user.phoneCountryCode) {
          //homePhoneCountryCode cellPhoneCountryCode
          this.beneficiaryInfo["cellPhoneCountryCode"] =
            this.$store.state.user.phoneCountryCode;
        }
      }
      if (
        this.$store.state.user.phone 
     //   && this.beneficiaryInfo.homePhoneNumber == undefined
      ) {
        this.beneficiaryInfo.homePhoneNumber = bphone;
        if (this.$store.state.user.phoneCountryCode) {
          //homePhoneCountryCode cellPhoneCountryCode
          this.beneficiaryInfo["homePhoneCountryCode"] =
            this.$store.state.user.phoneCountryCode;
        }
      }
    }
    setTimeout(function () {
      window.scroll({
        top: 0,
        left: 0,
        behavior: "smooth",
      });
    }, 1500);

    this.$store.dispatch("getmasterdata", "visa_status").then((response) => {
      this.visastatuses = response;
    });
    this.$store.dispatch("getmasterdata", "marital_status").then((response) => {
      this.marital_statuses = response;
    });

    this.$store
      .dispatch("getmasterdata", "education_types")
      .then((response) => {
        this.education_types = response;
        this.upDatehighestDegree();
      });
    this.$store
      .dispatch("getpetition", this.$route.params.itemId)
      .then((response) => {
        this.petition = response.data.result;
        //this.petition = _.cloneDeep(response.data.result);
         
         let currentRoute  = this.$route;

        if (!this.petition && ( _.get( currentRoute,'name' ,'') !='fill-questionnaire')) {
          this.$router.push({ name: "petitions" });
        }
      
        if (this.petition) {
          
          if (this.$route.query != null && this.$route.query.fromedit) {
            this.editingForm = true;
          } else {
            if( ( _.get( currentRoute,'name' ,'') !='fill-questionnaire')){
                if ( this.checkProperty(this.petition, "accessUserIds", "length") > 0   ) {
                  let roleaArray = [];

                  roleaArray = this.petition["accessUserIds"];

                  let routeId = this.$route.params.itemId;
                  if (
                    roleaArray.indexOf(
                      this.checkProperty(this.getUserData, "userId")
                    ) <= -1
                  ) {
                    // alert(0);
                  this.reloadthePage();;
                  }
                } 
  
              
              if (
              
                this.petition.questionnaireFilled &&
                (([50].indexOf(this.getUserRoleId) > -1 &&
                  !this.checkProperty(this.petition, "ptnrReassignRefUserId")) ||
                  ([51].indexOf(this.getUserRoleId) > -1 &&
                    !this.checkProperty(this.petition, "benfReassignRefUserId")))
              ) {
                //alert(2);
                let routeId = this.$route.params.itemId;
              this.reloadthePage();
              }
            }else{
             
              this.tempLogin(this.petition)

            }
          }

          //if( ( this.petition.questionnaireFilled_temp) ) {
          if (_.has(this.petition, "beneficiaryInfo.firstName")) {
            //countryOfCitizenship
            //  alert(JSON.stringify(this.petition['dependentsInfo']['spouse']));
            // alert(JSON.stringify(this.petition['dependentsInfo']['spouse']['countryOfBirthDetails']));
            this.countryOfCitizenshipSelected =
              this.petition["dependentsInfo"]["spouse"][
                "countryOfCitizenshipDetails"
              ];

            this.beneficiaryInfo = this.petition.beneficiaryInfo;
            //this.beneficiaryInfo = _.cloneDeep(this.petition.beneficiaryInfo);

            if(!_.has(this.beneficiaryInfo ,"hasOtherNames" )  ){
              this.beneficiaryInfo = Object.assign(this.beneficiaryInfo , {'hasOtherNames':false ,'otherNames':[]})
            }
           

            if (this.getUserRoleId == 51) {
              if (!this.checkProperty(this.beneficiaryInfo, "firstName")) {
                this.beneficiaryInfo.firstName =
                  this.$store.state.user.firstName;
              }
              if (!this.checkProperty(this.beneficiaryInfo, "lastName")) {
                this.beneficiaryInfo.lastName = this.$store.state.user.lastName;
              }
              if (!this.checkProperty(this.beneficiaryInfo, "middleName")) {
                this.beneficiaryInfo.middleName =
                  this.$store.state.user.middleName;
              }
              if (!this.checkProperty(this.beneficiaryInfo, "email")) {
                this.beneficiaryInfo.email = this.$store.state.user.email;
              }
              if (!this.checkProperty(this.beneficiaryInfo, "gender")) {
                this.beneficiaryInfo.gender = this.$store.state.user.gender;
              }
               
              var bphone = this.$store.state.user.phone;
              if (
              this.$store.state.user.phone &&
               !this.checkProperty(this.beneficiaryInfo, 'cellPhoneNumber')
              ) {
              
                this.beneficiaryInfo.cellPhoneNumber = bphone;
                if (this.$store.state.user.phoneCountryCode) {
                  //homePhoneCountryCode cellPhoneCountryCode
                  this.beneficiaryInfo["cellPhoneCountryCode"] =
                    this.$store.state.user.phoneCountryCode;
                }
              }
              if (
                this.$store.state.user.phone &&
                !this.checkProperty(this.beneficiaryInfo, 'homePhoneNumber')
              ) {
                this.beneficiaryInfo.homePhoneNumber = bphone;
                if (this.$store.state.user.phoneCountryCode) {
                  //homePhoneCountryCode cellPhoneCountryCode
                  this.beneficiaryInfo["homePhoneCountryCode"] =
                    this.$store.state.user.phoneCountryCode;
                }
              }
            }
            this.upDatehighestDegree();
            if (
              this.checkProperty(this.beneficiaryInfo, "countryOfBirthDetails")
            ) {
              this.selectcountryOfBirth(
                this.checkProperty(
                  this.beneficiaryInfo,
                  "countryOfBirthDetails"
                ),
                true
              );
            }

            if (
              this.checkProperty(this.beneficiaryInfo, "provinceOfBirthDetails")
            ) {
              this.selectProvinceOfBirth(
                this.checkProperty(
                  this.beneficiaryInfo,
                  "provinceOfBirthDetails"
                ),
                false
              );
            }

            /*
              passportIssuedDate:null,
          passportExpiryDate:null,
             curVisaExpiryDate:null,
           */
            // if(this.checkProperty(this.beneficiaryInfo ,'passportIssuedDate')){
            //     this.beneficiaryInfo = Object.assign(this.beneficiaryInfo ,{passportIssuedDate: moment(_self.beneficiaryInfo['passportIssuedDate'])})
            //  }

            //  if(this.checkProperty(this.beneficiaryInfo ,'passportExpiryDate')){
            //     this.beneficiaryInfo = Object.assign(this.beneficiaryInfo ,{passportExpiryDate: moment(_self.beneficiaryInfo['passportExpiryDate'])})
            //  }
            //  if(this.checkProperty(this.beneficiaryInfo ,'curVisaExpiryDate')){
            //     this.beneficiaryInfo = Object.assign(this.beneficiaryInfo ,{curVisaExpiryDate: moment(_self.beneficiaryInfo['curVisaExpiryDate'])})
            //  }

            //beneficiaryInfo.provinceOfBirthDetails

            if (this.beneficiaryInfo.iAmFromUS) {
              this.beneficiaryInfo.iAmFromUS = "true";
            } else {
              this.beneficiaryInfo.iAmFromUS = "false";
            }
            this.dependentsInfo = this.petition.dependentsInfo;
            

            if (
              this.checkProperty(
                this.dependentsInfo,
                "spouse",
                "passportNumber"
              ) == "" ||
              this.checkProperty(
                this.dependentsInfo,
                "spouse",
                "passportNumber"
              ) == null
            ) {
              this.dependentsInfo["spouse"]["passportExpiryDate"] = null;
            }

            this.clientInfo = this.petition.clientInfo;
            this.documents = this.petition.documents;

            if (
              this.beneficiaryInfo &&
              this.beneficiaryInfo.address &&
              this.beneficiaryInfo.address.countryDetails
            ) {
              this.bncountryModel = this.beneficiaryInfo.address.countryDetails;
              setTimeout(() => {
                this.selectCountry(
                  this.beneficiaryInfo.address.countryDetails,
                  true
                );
              }, 100);
            }

            if (
              this.dependentsInfo.spouse &&
              this.dependentsInfo.spouse.countryOfBirthDetails
            ) {
              this.countrySelected =
                this.dependentsInfo.spouse.countryOfBirthDetails;
            }

            if (
              this.dependentsInfo.spouse &&
              this.dependentsInfo.spouse.physicalAddress.countryDetails
            ) {
              this.spouseaddresscountryModel =
                this.dependentsInfo.spouse.physicalAddress.countryDetails;
              _self.editspouseaddressCountry(
                this.dependentsInfo.spouse.physicalAddress.countryDetails,
                this.dependentsInfo.spouse.physicalAddress.stateDetails
              );
            }
            if (
              this.dependentsInfo.spouse &&
              this.dependentsInfo.spouse.physicalAddress.stateDetails
            ) {
              this.spouseaddressstateModel =
                this.dependentsInfo.spouse.physicalAddress.stateDetails;
            }

            if (
              this.checkProperty(
                this.beneficiaryInfo,
                "priorPeriodOfStayInUS",
                "length"
              ) > 0
            ) {
              this.priorPeriodOfStayInUS =
                this.beneficiaryInfo.priorPeriodOfStayInUS;
            } else {
              this.priorPeriodOfStayInUS = [];
              this.addpriorstay();
            }

             if(this.checkProperty(this.dependentsInfo,'spouse','countryOfBirth')){
                 this.getspouseProvinceStates(this.dependentsInfo.spouse.countryOfBirth, false)
            }
             if(this.checkProperty(this.dependentsInfo,'spouse','provinceOfBirth')){
                 this.getSpouseLocationsOfBirth(this.dependentsInfo.spouse.provinceOfBirth , false)
            }
           

            if (this.dependentsInfo.childrens.length > 0) {
              this.childrensarray = this.dependentsInfo.childrens;
            }
            this.dependentsInfo.childrensCountryOfBirthDetails.forEach(
              (child, index) => {
                this.childrensarray[index].selectedcountryOfBirth = child;
              }
            );
            //this.clientInfo.salaryFrequency = this.clientInfo.salaryFrequencyDetails.id;
            this.childrensarray.forEach((children, index) => {
              this.childrensarray[index]["selectedcitizenship"] = _.find(
                this.dependentsInfo.childrensCountryOfCitizenshipDetails,
                (e) => {
                  return e["id"] == children["countryOfCitizenship"];
                }
              );
            });
          }else{
        
               let postData ={"userId":this.petition.userId ,"getDocuments":true}

        this.$store.dispatch("commonAction", {"data":postData ,"path":"petition/get-recent-by-beneficiary"}).then(response => {
            
                if(response['caseDetails']!=null && response['caseDetails']["beneficiaryInfo"]){
                  this.showPrefilldetails = response['caseDetails']
                  this.showPrefillPopup = true;
               
                }

             
         
           
                
        });
           
          }
          if (_.has(this.petition, "questionnaireTplId")) {
            //alert(this.petition['questionnaireTplId']);
            this.questionnaireTplId = this.petition["questionnaireTplId"];
            this.getquestionnaireDetails();
          }
        }

        this.isPhoneValid = true;
        this.isHomePhoneValid = true;
        this.isSpousePhoneValid = true;

        setTimeout(() => {
          this.isPhoneValid = true;
          this.isHomePhoneValid = true;
          this.isSpousePhoneValid = true;

          this.$validator.reset();
        }, 500);

        //  this.getLatestPetition();
        this.$validator.reset();
      });

    this.getSalary_frequencies();
  },
  components: {
    addressFields,
    caseQuestionnaireDocs,
    DatePickerField,
    VuePhoneNumberInput,
    FormWizard,
    TabContent,
    Datepicker,
    PhoneMaskInput,
    TheMask,
    FileUpload,
    Trash2Icon,
  },
  watch: {
    "beneficiaryInfo.iAmFromUS": function (value) {

    },
    maritalStatusOpen: function (value) {},
  },
    provide() {
        return {
            parentValidator: this.$validator,
        };
    }
};
</script>