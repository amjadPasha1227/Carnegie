<template>
<div class="block-layout questionnaire">
    <div class="vx-col w-full mb-base wizard-container questionnairesection">
        <vx-card>
            <!-- <div class="wizard-content-heading">
                <h2>
                    Questionnaire for adjustment of status to Permanent Residency (Form
                    I-485)
                </h2>
                <p>Please take a few moments to complete this application form</p>

                <div class="que_tabs_list ddd">
                    <ul>
                        <template v-for="(application, mindex) in applications">
                            <li v-bind:class="{
                    active: currentapplication == mindex,
                  }" :key="mindex" @click="gotoSidetab(mindex)" v-if="application != null && application.tab == true">
                                <span v-if="mindex == 0"> Principal Applicant </span>
                                <span v-if="mindex == 1"> Spouse </span>
                                <span v-if="mindex >= 2"> Child {{ mindex - 1 }} </span>
                            </li>
                        </template>
                    </ul>
                </div>
            </div> -->
    <div class="questionnaire_page dd">
        <div class="questionnaire_sec">
          <div class="questionnaire_titles">
            <div class="questionnaire_titles_info">
              <h2>Questionnaire for adjustment of status to Permanent Residency (Form I-485)
              </h2>
              <p>Please take a few moments to complete this application form
              </p>
              <ul>
                <li  class="active"
                 @click="selectedTab = 'caseDetails'"
                  :class="{
                    active:
                      selectedTab == 'caseDetails' ||
                      selectedTab == 'clientDetails' ||
                      selectedTab == 'documents' ||
                      selectedTab == 'dependentsInfo',
                  }"
                >
                  <span>1</span><a>Personal Info</a>
                </li>
                <li
                 @click="selectedTab = 'clientDetails'"
                  :class="{
                    active:
                      selectedTab == 'clientDetails' ||
                      selectedTab == 'documents' ||
                      selectedTab == 'dependentsInfo',
                  }"
                >
                  <span>2</span><a>Addresses</a>
                </li>
                <li
                 @click="selectedTab = 'documents'"
                  :class="{
                    active:
                      selectedTab == 'documents' ||
                      selectedTab == 'dependentsInfo',
                  }"
                >
                  <span>3</span><a>Immigration</a>
                </li>
                <li
                 @click="selectedTab = 'documents'"
                  :class="{
                    active:
                      selectedTab == 'documents' ||
                      selectedTab == 'dependentsInfo',
                  }"
                >
                  <span>4</span><a>Education & Employment</a>
                </li>
                <li
                 @click="selectedTab = 'documents'"
                  :class="{
                    active:
                      selectedTab == 'documents' ||
                      selectedTab == 'dependentsInfo',
                  }"
                >
                  <span>5</span><a>Assets &amp; Financials</a>
                </li>
                <li
                 @click="selectedTab = 'documents'"
                  :class="{
                    active:
                      selectedTab == 'documents' ||
                      selectedTab == 'dependentsInfo',
                  }"
                >
                  <span>6</span><a>Parents</a>
                </li>
                <li
                 @click="selectedTab = 'documents'"
                  :class="{
                    active:
                      selectedTab == 'documents' ||
                      selectedTab == 'dependentsInfo',
                  }"
                >
                  <span>7</span><a>Documents</a>
                </li>
                <li 
                 @click="selectedTab = 'dependentsInfo'"
                    :class="{ active: selectedTab == 'dependentsInfo' }">
                                <span>8</span><a>Dependents Info</a>
                </li>
              </ul>
            </div>
            <figure>
              <img src="@/assets/images/main/content-bottom-image.svg" />
            </figure>
          </div>
          <div class="questionnaire_form pb-0">
             <div class="gctabs gctabslayout">
                <vs-col class="w-full p-0">
                    <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal" icon="IP-information-button" active="true">
                        NOTE: This questionnaire should be filled out completely and
                        accurately. Kindly read the instructions carefully.
                    </vs-alert>
                </vs-col>

                <div class="text-danger text-sm formerrors" v-show="formerrors.msg">
                    <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
                </div>

                <form v-if="loaded" @submit.prevent="" @keydown.enter.prevent="" data-vv-scope="beneficiaryInfoform">
                    <template v-for="(application, mindex) in applications">
                        <div :key="mindex" v-if="currentapplication == mindex && application.tab">
                            <!-- <div class="gc_steps_wrap" v-if="application.applicationRequired">
                                <ul>
                                    <li @click="gotoTab('step1_' + mindex)" v-bind:class="{ current: toptab == 'step1_' + mindex,
                      completed:totabnum > 10
                     }">
                                        <span>1</span><label>Personal Info</label>
                                    </li>
                                    <li @click="gotoTab('step2_' + mindex)" v-bind:class="{ current: toptab == 'step2_' + mindex,  
                    completed:totabnum > 20 }">
                                        <span>2</span><label>Addresses</label>
                                    </li>
                                    <li @click="gotoTab('step3_' + mindex)" v-bind:class="{ current: toptab == 'step3_' + mindex, 
                    completed:totabnum > 30 }">
                                        <span>3</span><label>Immigration</label>
                                    </li>
                                    <li @click="gotoTab('step4_' + mindex)" v-bind:class="{ current: toptab == 'step4_' + mindex,  
                    completed:totabnum > 40 }">
                                        <span>4</span><label>Education & Employment</label>
                                    </li>
                                    <li @click="gotoTab('step5_' + mindex)" v-bind:class="{ current: toptab == 'step5_' + mindex,  
                    completed:totabnum > 50 }">
                                        <span>5</span><label>Assets &amp;<br />
                                            Financials</label>
                                    </li>
                                    <li @click="gotoTab('step6_' + mindex)" v-bind:class="{ current: toptab == 'step6_' + mindex,  
                    completed:totabnum > 60 }">
                                        <span>6</span><label>Parents</label>
                                    </li>
                                    <li @click="gotoTab('step7_' + mindex)" v-bind:class="{ current: toptab == 'step7_' + mindex ,  
                    completed:totabnum > 70
                    }">
                                        <span>7</span><label>Documents</label>
                                    </li>
                                </ul>
                            </div> -->

                            <div v-if="toptab == 'step1_' + mindex" class="steps_wrap steps_wrap2">
                                <personalInfo v-if="loaded" v-bind:key="mindex" :countries="countries" @chiltabs="chiltabs" @maritalStatusChange="maritalStatusChange" :application="application" :mindex="mindex" />
                                <div class="gc_tab_buttons">
                                    <div>

                                    </div>
                                    <div class="d-flex">
                                        <button v-if="application.applicationRequired" @click="gotoTab('step2_' + mindex,mindex)">Save & Continue</button>
                                        <button v-if="!application.applicationRequired" @click="gotoNexttab(mindex)">Save & Continue</button>
                                        <button v-if="showornobtn() && petition.statusId == 1" @click="submitapplication(mindex,true)">Submit</button>
                                        <button v-if="showornobtn() && petition.statusId > 1" @click="submitapplication(mindex,false)">Update</button>
                                    </div>

                                </div>
                            </div>

                            <div v-if="toptab == 'step2_' + mindex">
                                <addresscomp v-if="loaded" v-bind:key="mindex" :countries="countries" :application="application" :mindex="mindex" />
                                <div class="gc_tab_buttons">
                                    <div>
                                        <button class="previous" @click="gotoTabp('step1_' + mindex)">Previous</button>
                                    </div>
                                    <div class="d-flex">
                                        <button @click="gotoTab('step3_' + mindex,mindex)">Save & Continue</button>
                                        <button v-if="showornobtn() && petition.statusId == 1" @click="submitapplication(mindex,true)">Submit</button>
                                        <button v-if="showornobtn() && petition.statusId > 1" @click="submitapplication(mindex,false)">Update</button>
                                    </div>
                                </div>
                            </div>

                            <div v-if="toptab == 'step3_' + mindex" id="immigration">
                                <immigration v-if="loaded" v-bind:key="mindex" :countries="countries" :application="application" :mindex="mindex" />
                                <div class="gc_tab_buttons">
                                    <div>
                                        <button class="previous" @click="gotoTabp('step2_' + mindex)">Previous</button>
                                    </div>
                                    <div class="d-flex">

                                        <button @click="gotoTab('step4_' + mindex,mindex)">Save & Continue</button>
                                        <button v-if="showornobtn() && petition.statusId == 1" @click="submitapplication(mindex,true)">Submit</button>
                                        <button v-if="showornobtn() && petition.statusId > 1" @click="submitapplication(mindex,false)">Update</button>

                                    </div>
                                </div>
                            </div>

                            <div v-if="toptab == 'step4_' + mindex">
                                <skills v-if="loaded" v-bind:key="mindex" :countries="countries" :application="application" :mindex="mindex" />
                                <div class="gc_tab_buttons">
                                    <div>
                                        <button class="previous" @click="gotoTabp('step3_' + mindex)">Previous</button>
                                    </div>
                                    <div class="d-flex">

                                        <button @click="gotoTab('step5_' + mindex,mindex)">Save & Continue</button>
                                        <button v-if="showornobtn() && petition.statusId == 1" @click="submitapplication(mindex,true)">Submit</button>
                                        <button v-if="showornobtn() && petition.statusId > 1" @click="submitapplication(mindex,false)">Update</button>

                                    </div>
                                </div>
                            </div>

                            <div v-if="toptab == 'step5_' + mindex">
                                <assets v-if="loaded" v-bind:key="mindex" :countries="countries" :application="application" :mindex="mindex" />
                                <div class="gc_tab_buttons">
                                    <div>
                                        <button class="previous" @click="gotoTabp('step4_' + mindex)">Previous</button>
                                    </div>
                                    <div class="d-flex">

                                        <button @click="gotoTab('step6_' + mindex,mindex)">Save & Continue</button>
                                        <button v-if="showornobtn() && petition.statusId == 1" @click="submitapplication(mindex,true)">Submit</button>
                                        <button v-if="showornobtn() && petition.statusId > 1" @click="submitapplication(mindex,false)">Update</button>

                                    </div>
                                </div>
                            </div>

                            <div v-if="toptab == 'step6_' + mindex">
                                <parents v-if="loaded" v-bind:key="mindex" :countries="countries" :application="application" :mindex="mindex" />
                                <div class="gc_tab_buttons">
                                    <div>
                                        <button class="previous" @click="gotoTabp('step5_' + mindex)">Previous</button>
                                    </div>
                                    <div class="d-flex">

                                        <button @click="gotoTab('step7_' + mindex,mindex)">Save & Continue</button>
                                        <button v-if="showornobtn() && petition.statusId == 1" @click="submitapplication(mindex,true)">Submit</button>
                                        <button v-if="showornobtn() && petition.statusId > 1" @click="submitapplication(mindex,false)">Update</button>

                                    </div>
                                </div>
                            </div>
                            <div v-if="toptab == 'step7_' + mindex">
                                <documents v-if="loaded" :countries="countries" :application="application.documents" :mindex="mindex" />
                                <div class="gc_tab_buttons">
                                    <div>
                                        <button class="previous" @click="gotoTabp('step6_' + mindex)">Previous</button>
                                    </div>
                                    <div class="d-flex">

                                        <button @click="gotoSidetab(mindex+1)">Save & Continue</button>
                                        <button v-if="showornobtn() && petition.statusId == 1" @click="submitapplication(mindex,true)">Submit</button>
                                        <button v-if="showornobtn() && petition.statusId > 1" @click="submitapplication(mindex,false)">Update</button>

                                    </div>

                                </div>
                            </div>
                        </div>
                    </template>
                </form>
            </div>
        </div>
        </div>
        
    </div>








           

            <vs-popup class="holamundo success-popups" title="Your registration is complete." :active.sync="SuccessQuestionnaire">
                <figure>
                    <img src="@/assets/images/main/icon-note.svg" alt="login" class="mx-auto" />
                </figure>
                <h2 class="title" v-if="petition.statusId == 1">Application submitted successfully!</h2>
                <h2 class="title" v-if="petition.statusId > 1">Application updated successfully!</h2>

                <p>
                    It will be reviewed by the Law Office and appropriate actions will
                    be taken soon.
                </p>
            </vs-popup>
        </vx-card>
    </div>
</div>
</template>

<script>
import moment from "moment";
import JQuery from "jquery";
import _ from "lodash";
import Vue from "vue";
import personalInfo from "./child/personalinfo";
import addresscomp from "./child/addresscomp";
import immigration from "./child/immigration";
import skills from "./child/skills";
import assets from "./child/assets";
import parents from "./child/parents";
import documents from "./child/documents";
import _Application from "./application";

export default {
    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
    data() {
        return {
            loaded: false,
            toptab: "step1_0",
            showprevious: false,
            currentapplication: 0,
            countries: [],
            raceslist: [],
            maritallist: [],
            eyecolorslist: [],
            haircolorlist: [],
            nationalitylist: [],
            genders: ["Male", "Female", "Other"],
            applications: _Application,
            bapplication: null,
            currentroute: this.$route.params.itemId,
            SuccessQuestionnaire: false,
            formerrors: {
                msg: "",
            },
            petition: [],
            totabnum: 10,
        };
    },
    methods: {
        async synchandStroe(submited) {
            var currentForm = this.currentapplication;
             this.$vs.loading.close();
            return true;
            const result = await this.$validator.validateAll('beneficiaryInfoform').then((result) => {
                return result;
            });

            if (result) {

                var submitType = "BENEFICIARY_INFO_UPDATE";
                if (currentForm == 0) submitType = "BENEFICIARY_INFO_UPDATE";
                if (currentForm == 1) submitType = "SPOUSE_INFO_UPDATE";
                if (currentForm > 1) submitType = "CHILDREN_INFO_UPDATE";
                //SUBMIT_QUESTIONNAIRE
                var postpetition = {
                    petitionId: this.$route.params.itemId,
                    userName: this.$store.state.user.name,
                    action: (submited && submited == true) ? "SUBMIT_QUESTIONNAIRE" : submitType,
                    updateSection: submitType,
                    questionnaireFilled: (submited && submited == true) ? true : false,
                    beneficiaryInfo: null,
                    documents: null,
                    dependentsInfo: null
                };
                if (currentForm == 0) {
                    postpetition.beneficiaryInfo = this.applications[0];
                    postpetition.documents = this.applications[0].documents
                }
                if (currentForm == 1) {
                    postpetition.dependentsInfo = {
                        spouse: this.applications[1]
                    }
                }
                if (currentForm > 1) {
                    var childresndata = [];

                    this.applications.forEach((doc, index) => {
                        if (index > 1 && doc && doc.tab && doc.firstName != null) {
                            childresndata.push(doc)
                        }
                    });
                    postpetition.dependentsInfo = {
                        childrens: childresndata
                    }
                }
                var check = await this.$store
                    .dispatch("petitioner/updateapplication", postpetition)
                    .then((response) => {
                        this.$vs.loading.close();
                        if (response.error) {
                            Object.assign(this.formerrors, {
                                msg: response.error.message
                            });

                            window.scroll({
                                top: 0,
                                left: 0,
                                behavior: "smooth",
                            });

                            return false;

                        } else {

                            this.$validator.reset();

                            window.scroll({
                                top: 0,
                                left: 0,
                                behavior: "smooth",
                            });

                            return true;
                        }

                    });

                return check;
            } else {
                /* CLOSE LOADING ON ERRORS */
                this.$vs.loading.close();

                const $ = JQuery;
                const firstField = Object.keys(this.errors.collect())[0];
                const ele = $("[name=" + firstField + "]").parents(".vx-col");
                if (ele && ele.offset()) {

                    $("html, body").animate({
                            scrollTop: ele.offset().top,
                        },
                        2000
                    );

                } else {
                    window.scroll({
                        top: 0,
                        left: 0,
                        behavior: "smooth",
                    });

                }

                return false;
            }

        },
        async gotoSidetab(currentIndex) {
            var tabs = 0;
            this.applications.forEach((doc, index) => {
                if (doc.tab == true) {
                    tabs++;
                }

            });

            if (tabs == currentIndex) {
                currentIndex = 0;
            }

            if (this.currentapplication != currentIndex) {
                const result = await this.synchandStroe(false);
                if (result) {
                    this.currentapplication = currentIndex;
                    this.toptab = 'step1_' + currentIndex
                }

            }

        },
        async gotoNexttab(currentIndex) {

            const result = await this.synchandStroe(false);

            if (result) {

                this.currentapplication = currentIndex + 1;
                this.toptab = 'step1_' + currentIndex
            }

        },
        showornobtn() {
            var showme = true;
            this.applications.forEach((doc, index) => {
                if (doc.tab == true && (doc.firstName == null || doc.lastName == null ||
                        doc.firstName == '' || doc.lastName == '')) {

                    showme = false;
                }

            })
            return showme;
        },
        checktabcomplted(tab) {
            var test = tab.split('_')[0].replace('step');
            test = parseInt(test);
            var atest = this.toptab.split('_')[0].replace('step');
            if (atest > test) {
                return true
            }
            return false;

        },
        gotoTabp(tab) {
            this.toptab = tab;
            window.scroll({
                top: 0,
                left: 0,
                behavior: "smooth",
            });

        },
        reloadthePage() {
            this.$router.push('/gcapplications').catch(err => {})
        },
        async submitapplication(index, bool) {
            
            if(bool) this.petition.statusId = 2;
            const result = await this.synchandStroe(bool);
            if (result) {
                // this.toptab = tab;
                this.SuccessQuestionnaire = true;
            }

        },
        async gotoTab(tab, index) {

            const result = await this.synchandStroe(false);
            if (result) {
                this.toptab = tab;
            }

        },
        chiltabs(val) {
            if (val != 0) {
                var i;
                this.applications.forEach((doc, index) => {
                    if (index > 1 && this.applications[index]) {
                        if (this.applications[index]) this.applications[index].tab = false;
                    }

                })

                for (i = 0; i < val; i++) {
                    if (this.applications[i + 2]) {
                        this.applications[i + 2].tab = true;
                        var $_this=this;
                        Object.keys(this.applications[i + 2].documents).forEach(function (key, sindex) {
                             if ($_this.applications[i + 2].documents[key] == null) {
                                        $_this.applications[i + 2].documents[key] = [{
                                            name: null,
                                            url: null,
                                            mimetype: null,
                                            uploadedOn: null
                                        }]

                                    }
                        })
                                
                    } 
                }
            }
        },
        maritalStatusChange($event, mindex) {
            if ($event.id == 2 && mindex == 0) {
                this.applications[1].tab = true;
            } else {
                this.applications[1].tab = false;
            }
        },

        async loadPetition() {
            const returnd = await this.$store
                .dispatch("getgcpetition", this.$route.params.itemId)
                .then((response) => {
                    this.petition = response.data.result;
                    if (response.data.result && response.data.result._id) {

                        if (this.petition.beneficiaryInfo.firstName != null) {
                            Object.assign(this.applications[0], this.petition.beneficiaryInfo);
                        }

                        this.applications[0].tab = true;

                        if (this.petition.beneficiaryInfo.email == null || this.petition.beneficiaryInfo.email == '') {

                            this.applications[0].email = this.$store.state.user.email;

                        }

                        if (this.petition.beneficiaryInfo.maritalStatus && this.petition.beneficiaryInfo.maritalStatus.id >= 2) {
                            this.applications[1].tab = true;

                        }

                        if (this.petition.dependentsInfo && this.petition.dependentsInfo.spouse && this.petition.dependentsInfo.spouse.firstName != null) {
                            this.applications[1].tab = true;
                            Object.assign(this.applications[1], this.petition.dependentsInfo.spouse);

                        }
                        if (this.petition.beneficiaryInfo.childrenCount && this.petition.beneficiaryInfo.childrenCount > 0) {
                            var i;

                            for (i = 0; i < this.petition.beneficiaryInfo.childrenCount; i++) {
                                this.applications[i + 2].tab = true;
                            }

                        }

                        if (this.petition.dependentsInfo && this.petition.dependentsInfo.childrens.length > 0) {

                            this.petition.dependentsInfo.childrens.forEach((doc, cindex) => {
                                if (doc && doc.firstName != null && doc.firstName != '') {
                                    this.applications[cindex + 2].tab = true;
                                    this.applications[cindex + 2]._id = doc._id;
                                    Object.assign(this.applications[cindex + 2], doc);

                                }
                                if (this.applications[cindex + 2]._id == null) {

                                    try {
                                        delete this.applications[cindex + 2]._id;
                                    } catch (err) {}

                                }

                            })

                        }

                        this.applications.forEach((doc, index) => {

                            /* Kumar Optimize this block */
                            if (index == 0 && this.petition.documents != null) {

                                doc.documents = this.petition.documents;
                                Object.keys(doc.documents).forEach(function (key, sindex) {

                                    if (doc.documents[key] == null) {
                                        doc.documents[key] = [{
                                            name: null,
                                            url: null,
                                            mimetype: null,
                                            uploadedOn: null
                                        }]

                                    }

                                })
                            }

                            if (index == 1 && this.petition.dependentsInfo.spouse && this.petition.dependentsInfo.spouse.documents != null) {

                                doc.documents = this.petition.dependentsInfo.spouse.documents;
                                Object.keys(doc.documents).forEach(function (key, sindex) {

                                    if (doc.documents[key] == null) {
                                        doc.documents[key] = [{
                                            name: null,
                                            url: null,
                                            mimetype: null,
                                            uploadedOn: null
                                        }]

                                    }

                                })
                            }

                            if (index > 1 && this.petition.dependentsInfo.childrens &&
                                this.petition.dependentsInfo.childrens[index - 2] != null &&
                                this.petition.dependentsInfo.childrens[index - 2].documents != null) {

                                doc.documents = this.petition.dependentsInfo.childrens[index - 2].documents;
                                Object.keys(doc.documents).forEach(function (key, sindex) {

                                    if (doc.documents[key] == null) {
                                        doc.documents[key] = [{
                                            name: null,
                                            url: null,
                                            mimetype: null,
                                            uploadedOn: null
                                        }]

                                    }

                                })
                            }

                            //application.healthInsurance

                            if (doc && (doc.healthInsurance == '' || doc.healthInsurance == null)) {

                                doc.healthInsurance = {
                                    premium: '',
                                    renewalDate: ''
                                }
                            }

                            if (doc && (doc.placeOfMarriage == '' || doc.placeOfMarriage == null || doc.placeOfBirth.country == null)) {

                                doc.placeOfMarriage = {
                                    country: null,
                                    state: null,
                                    location: null
                                }
                            }
                            if (doc && (doc.placeOfBirth == '' || doc.placeOfBirth == null || doc.placeOfBirth.country == null)) {
                                doc.placeOfBirth = {
                                    country: null,
                                    state: null,
                                    location: null
                                }
                            }

                            if (doc && (doc.father.placeOfBirth == '' || doc.father.placeOfBirth == null || doc.father.placeOfBirth.country == null)) {
                                doc.father.placeOfBirth = {
                                    country: null,
                                    state: null,
                                    location: null
                                }
                            }

                            if (doc && (doc.father.currentResidence == '' || doc.father.currentResidence == null || doc.father.currentResidence.country == null)) {
                                doc.father.currentResidence = {
                                    country: null,
                                    state: null,
                                    location: null
                                }
                            }

                            if (doc && (doc.mother.currentResidence == '' || doc.mother.currentResidence == null || doc.mother.currentResidence.country == null)) {
                                doc.mother.currentResidence = {
                                    country: null,
                                    state: null,
                                    location: null
                                }
                            }

                            if (doc && (doc.mother.placeOfBirth == '' || doc.mother.placeOfBirth == null || doc.mother.placeOfBirth.country == null)) {
                                doc.mother.placeOfBirth = {
                                    country: null,
                                    state: null,
                                    location: null
                                }
                            }

                            if (doc && (doc.allCountryIssuedPassports == null || doc.allCountryIssuedPassports == '')) {

                                doc.allCountryIssuedPassports = [{
                                    country: null,
                                    number: null,
                                    issuedDate: null,
                                    expiryDate: null
                                }]
                            }
                            if (doc && (doc.education == null || doc.education == '')) {

                                doc.education = [{
                                    schoolName: null,
                                    degree: null,
                                    fieldOfStudy: null,
                                    fromDate: null,
                                    toDate: null,
                                }]

                            }

                            if (doc && (doc.lastEmployerOutsideUS == null || doc.lastEmployerOutsideUS == '')) {
                                doc.lastEmployerOutsideUS = {
                                    employerName: null,
                                    address: {
                                        line1: null,
                                        zipcode: null,
                                        line2: null,
                                        location: null,
                                        country: null,
                                        state: null
                                    },
                                    occupation: null,
                                    fromDate: null,
                                    toDate: null
                                }
                            }
                            if (doc && (doc.employmentHistoryUSAbroad == null || doc.employmentHistoryUSAbroad == '')) {
                                doc.employmentHistoryUSAbroad = [{
                                    employerName: null,
                                    address: {
                                        line1: null,
                                        zipcode: null,
                                        line2: null,
                                        location: null,
                                        country: null,
                                        state: null
                                    },
                                    occupation: null,
                                    fromDate: null,
                                    toDate: null
                                }]
                            }

                        });

                        return true;
                    } else {

                        return false;
                    }

                });
            return returnd;
        },

        getDefaultMasterdata() {

            this.$store.dispatch("getcountries").then((response) => {
                this.countries = response;

            });

            this.$store
                .dispatch("getmasterdata", "marital_status")
                .then((response) => {
                    this.maritallist = response;
                });
            this.$store.dispatch("getmasterdata", "races").then((response) => {
                this.raceslist = response;
            });
            this.$store.dispatch("getmasterdata", "hair_colors").then((response) => {
                this.haircolorlist = response;
            });

            this.$store.dispatch("getmasterdata", "eye_colors").then((response) => {
                this.eyecolorslist = response;
            });

            this.$store.dispatch("getmasterdata", "nationality").then((response) => {
                this.nationalitylist = response;
            });
        },
    },
    mounted() {
        JQuery("#btnSidebarToggler").click();
        this.getDefaultMasterdata();
        const loadedpetiton = this.loadPetition();
        this.loaded = true;

    },
    components: {
        personalInfo,
        addresscomp,
        immigration,
        skills,
        assets,
        parents,
        documents,
    },
    watch: {
        SuccessQuestionnaire: function (value, old) {
            if (value != old) {
                if (!value) {
                    var check = this.$router;
                    setTimeout(function () {
                        check.push('/gcapplications').catch(err => {})
                    }, 100)
                }
            }

        },
        toptab: function (value) {
            var atest = value.split('_')[0].replace('step', '');
            var t = atest + value.split('_')[1];
            this.totabnum = parseInt(t);
        }

    },
};
</script>
