<template>
  <div
    class="block-layout questionnaire"
    :class="{ anonymousloginForm: !checkCurrentUrl }"
  >
    <div
      class="
        vx-col
        w-full
        wizard-container
        form_section
        questionnairesection
        pad0
      "
    >
      <div class="questionnaire_page dd">
        <div class="questionnaire_sec">
          <div class="questionnaire_titles">
            <div class="questionnaire_titles_info">
              <h2>Questionnaire For Prevailing Wage Determination
                {{ checkProperty(petition, "typeDetails", "name") }}
                <small>{{
                  checkProperty(petition, "subTypeDetails", "name")
                }}</small>
              </h2>
              <p>
                Please take a few moments to complete this short registration
                form
              </p>
              <ul>
                <li  
                 @click="selectedTab = 'caseDetails'"
                  :class="{
                    active:
                      selectedTab == 'caseDetails' ||
                      selectedTab == 'clientDetails' ||
                      selectedTab == 'documents' ||
                      selectedTab == 'dependentsInfo',
                  }"
                >
                  <span>1</span><a>Personal Info</a>
                </li>
                <li
                 @click="selectedTab = 'clientDetails'"
                  :class="{
                    active:
                      selectedTab == 'clientDetails' ||
                      selectedTab == 'documents' ||
                      selectedTab == 'dependentsInfo',
                  }"
                >
                  <span>2</span><a>Employment Info</a>
                </li>
                <li
                 @click="selectedTab = 'documents'"
                  :class="{
                    active:
                      selectedTab == 'documents' ||
                      selectedTab == 'dependentsInfo',
                  }"
                >
                  <span>3</span><a>Wage Determination</a>
                </li> 
              </ul>
            </div>
            <figure>
              <img src="@/assets/images/main/content-bottom-image.svg" />
            </figure>
          </div>
          <div>
            <div class="gcform_section">
              <div v-if="selectedTab == 'caseDetails'" id="case_details">
                <form>
                <div class="form-container pt-6">                  
                  <vs-col class="m-auto float-none" vs-lg="11" vs-sm="12">
                    <h3 class="small-header marb-0">Personal Information</h3>
                    <div class="vx-row">
                      <div class="vx-col w-full">
                        <vx-input-group class="form-input-group">
                          <vs-input
                            name="firstname"
                            class="w-full"
                            data-vv-as="First Name"
                            label="First Name"
                          />
                          <vs-input
                            class="w-full"
                            name="middleName"
                            data-vv-as="Middle Name"
                            label="Middle Name"
                          />
                          <vs-input
                            class="w-full"
                            name="lastName"
                            data-vv-as="Last Name"
                            label="Last Name"
                          />
                        </vx-input-group>
                        <!-- <div class="input-group-error">
                                <p class="w-1/3">
                                <span class="text-danger text-sm"
                                    v-show="errors.has('beneficiaryInfoform.firstname')">{{ errors.first("beneficiaryInfoform.firstname") }}</span>
                                </p>
                                <p class="w-1/3">
                                
                                </p>
                                <p class="w-1/3">
                                <span class="text-danger text-sm"
                                    v-show="errors.has('beneficiaryInfoform.lastName')">{{ errors.first("beneficiaryInfoform.lastName") }}</span>
                                </p>
                                </div> -->
                      </div>
                      <div class="vx-col w-full md:w-1/2">
                        <div class="form_group">
                          <label class="form_label">job Title</label>
                          <vs-input
                            class="w-full"
                            data-vv-as="DOL Reference Number"
                          />
                        </div>
                      </div>
                      <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                          <label class="form_label">E-Mail</label>
                          <vs-input
                            name="line2"
                            data-vv-as="Apt, Suite"
                            class="w-full"
                          />
                        </div>
                      </div>                       
                      <gcAddress></gcAddress>


                      <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                          <label class="form_label">
                            Province (if applicable)</label
                          >
                          <vs-input
                            name="line2"
                            data-vv-as="Apt, Suite"
                            class="w-full"
                          />
                        </div>
                      </div>
                      <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group ph_number">
                          <div class="vs-component">
                            <label class="form_label">Phone Number</label>
                            <VuePhoneNumberInput v-model="value" />
                          </div>
                        </div>
                      </div> 
                      <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                          <div class="vs-component">
                            <label class="form_label">Fax Number</label>
                            <VuePhoneNumberInput v-model="value" />
                          </div>
                        </div>
                      </div>
                      
                    </div>
                  </vs-col>
                </div>
                </form>
                
              </div>
              <div v-if="selectedTab == 'clientDetails'" id="employeeDetails">
                <div class="gcform_section">
                  <form> 

                    <div class="spousedetails dependent_info_wrap">  
                        <h2>Current</h2>                     
                       <div class="dependent-block_wrap">
                          <div class="dependent-block">
                              <div class="dependent-title">
                                  <h3>Innvectra info Solutions<label><span>Role:</span> Software Engineer</label></h3>
                                  <ul>
                                      <li>
                                          <a><img src="@/assets/images/main/edit_icon.svg" />
                                          </a>
                                      </li>
                                      <li ><a><img src="@/assets/images/main/delete-row-img.svg"></a></li>
                                  </ul>
                              </div>
                              <div class="dependent_details">
                                <p>Plot #815, 3rd Floor, BVL Complex Ayyappa Society, Madhapur Hyderabad – 81. INDIA.</p>
                                  <ul>
                                      <li>
                                          Phone Number
                                          <span>999-999-9999</span>
                                      </li>
                                      <li>
                                          Fax
                                          <span>999-999-9999</span>
                                      </li>
                                      <li>
                                          Email
                                          <span>info@iinnvectra.com</span>
                                      </li> 
                                  </ul>
                              </div>
                              <!-- <span class="text-danger text-sm" v-if="showSpouseError">* Required fields are missing</span> -->
                          </div>
                      </div>
                    </div>
                    <div class="spousedetails dependent_info_wrap">  
                        <h2>Previous</h2>                     
                       <div class="dependent-block_wrap">
                          <div class="dependent-block">
                              <div class="dependent-title">
                                  <h3>FaceBook</h3>
                                  <ul>
                                      <li>
                                          <a><img src="@/assets/images/main/edit_icon.svg" />
                                          </a>
                                      </li>
                                      <li ><a><img src="@/assets/images/main/delete-row-img.svg"></a></li>
                                  </ul>
                              </div>
                              <div class="dependent_details">
                                <p>Plot #815, 3rd Floor, BVL Complex Ayyappa Society, Madhapur Hyderabad – 81. INDIA.</p>
                                  <ul>
                                      <li>
                                          Date of Joining
                                          <span>Aug 16, 2015</span>
                                      </li>
                                      <li>
                                          Date of Relieving
                                          <span>May 11, 2017</span>
                                      </li>
                                  </ul>
                              </div>
                              <!-- <span class="text-danger text-sm" v-if="showSpouseError">* Required fields are missing</span> -->
                          </div>
                          <div class="dependent-block">
                              <div class="dependent-title">
                                  <h3>Google</h3>
                                  <ul>
                                      <li>
                                          <a><img src="@/assets/images/main/edit_icon.svg" />
                                          </a>
                                      </li>
                                      <li ><a><img src="@/assets/images/main/delete-row-img.svg"></a></li>
                                  </ul>
                              </div>
                              <div class="dependent_details">
                                  <p>Plot #815, 3rd Floor, BVL Complex Ayyappa Society, Madhapur Hyderabad – 81. INDIA.</p>
                                  <ul>
                                      <li>
                                          Date of Joining
                                          <span>June 10, 2013</span>
                                      </li>
                                      <li>
                                          Date of Relieving
                                          <span>Aug 14, 2015</span>
                                      </li>
                                  </ul>
                              </div>
                              <!-- <span class="text-danger text-sm" v-if="showSpouseError">* Required fields are missing</span> -->
                          </div>
                          <div class="dependent-block">
                              <div class="dependent-title">
                                  <h3>Twitter</h3>
                                  <ul>
                                      <li>
                                          <a><img src="@/assets/images/main/edit_icon.svg" />
                                          </a>
                                      </li>
                                      <li ><a><img src="@/assets/images/main/delete-row-img.svg"></a></li>
                                  </ul>
                              </div>
                              <div class="dependent_details">
                                <p>Plot #815, 3rd Floor, BVL Complex Ayyappa Society, Madhapur Hyderabad – 81. INDIA.</p>
                                  <ul>
                                      <li>
                                          Date of Joining
                                          <span>Aug 10, 2010</span>
                                      </li>
                                      <li>
                                          Date of Relieving
                                          <span>June 08, 2013</span>
                                      </li>
                                  </ul>
                              </div>
                              <!-- <span class="text-danger text-sm" v-if="showSpouseError">* Required fields are missing</span> -->
                          </div>
                      </div>
                    </div>
                  </form>
                </div>
              <form>
                <div class="form-container pt-6  d-none">
                    <vs-col class="m-auto float-none" vs-lg="11" vs-sm="12">
                    <h3 class="small-header">Employment Information</h3>
                    <div class="vx-row">
                      <div class="vx-col w-full md:w-1/2">
                        <div class="form_group">
                          <label class="form_label">Legal Business Name</label>
                          <vs-input
                            class="w-full"
                            data-vv-as="DOL Reference Number"
                          />
                        </div>
                      </div>
                      <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                          <label class="form_label"
                            >Trade name/Doing Business As (DBA), if applicable</label>
                          <vs-input
                            class="w-full"
                            name="line1"
                            data-vv-as="Street Address"
                          />
                        </div>
                      </div>
                       <gcAddress></gcAddress>
                      <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                          <label class="form_label">
                            Province (if applicable)</label
                          >
                          <vs-input
                            name="line2"
                            data-vv-as="Apt, Suite"
                            class="w-full"
                          />
                        </div>
                      </div>
                      <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group ph_number">
                          <div class="vs-component">
                            <label class="form_label">Phone Number</label>
                            <VuePhoneNumberInput v-model="value" />
                          </div>
                        </div>
                      </div> 
                      <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                          <label class="form_label"
                            >Federal Employer Identification Number (FEIN from
                            IRS)</label
                          >
                          <vs-input
                            name="line2"
                            data-vv-as="Apt, Suite"
                            class="w-full"
                          />
                        </div>
                      </div>
                      <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                          <label class="form_label"
                            >NAICS Code (must be at least 4-digits)</label
                          >
                          <vs-input
                            name="line2"
                            data-vv-as="Apt, Suite"
                            class="w-full"
                          />
                        </div>
                      </div>
                    </div>
                  </vs-col>
                  <span class="form_devider"></span>
                  <vs-col class="m-auto float-none" vs-lg="11" vs-sm="12">
                    <h3 class="small-header">Place of Employment Information</h3>
                    <div class="vx-row">
                         <gcAddress></gcAddress>
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <div class="listitems listitems2">
                                    <h6>Will work be performed in multiple worksites within an area of intended employment or a location(s) other than the address listed above?</h6>
                                    <ul class="custom-radio">
                                        <li>
                                            <vs-checkbox v-model="checkBox1"
                                            >Yes</vs-checkbox
                                            >
                                        </li>
                                        <li>
                                            <vs-checkbox v-model="checkBox1"
                                            >No</vs-checkbox>
                                        </li>
                                    </ul>
                                </div>                          
                            </div>
                        </div>
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label">If “Yes”, identify the geographic place(s) of employment indicating each metropolitan statistical area (MSA) or the
independent city(ies)/township(s)/county(ies) (borough(s)/parish(es)) and the corresponding state(s) where work will be
performed. If necessary, submit a second completed Form ETA-9141 with a listing of the additional anticipated
worksites. Please note that wages cannot be provided for unspecified/unanticipated locations.</label>
                                <!-- <vs-textarea v-model="textarea" class="w-full" /> -->
                                <ckeditor  v-model="textarea" class="w-full" :editor="editor" :config="editorConfig"></ckeditor>

                                
                            </div>
                        </div>
                    </div>
                  </vs-col>
                  <span class="form_devider"></span>
                  <vs-col class="m-auto float-none" vs-lg="11" vs-sm="12">
                    <h3 class="small-header">Job Description</h3>
                    <div class="vx-row">
                      <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                          <label class="form_label">Job Title</label>
                          <vs-input
                            name="Job Title"
                            data-vv-as="Job Title"
                            class="w-full"
                          />
                        </div>
                      </div>
                      <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                          <label class="form_label">Suggested SOC (ONET/OES) code</label>
                          <vs-input
                            name="SOC"
                            data-vv-as="SOC"
                            class="w-full"
                          />
                        </div>
                      </div>
                      <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                          <label class="form_label">Suggested SOC (ONET/OES) occupation title</label>
                          <vs-input
                            name="SOC"
                            data-vv-as="SOC"
                            class="w-full"
                          />
                        </div>
                      </div>
                      <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                          <label class="form_label">Job Title of Supervisor for this Position (if applicable)</label>
                          <vs-input
                            name="SOC"
                            data-vv-as="SOC"
                            class="w-full"
                          />
                        </div>
                      </div>
                      <div class="vx-col w-full">
                        <div class="form_group">
                          <div class="listitems listitems2">
                            <h6>Does this position supervise the work of other employees?</h6>
                            <ul class="custom-radio">
                              <li>
                                <vs-checkbox v-model="checkBox1"
                                  >Yes</vs-checkbox
                                >
                              </li>
                              <li>
                                <vs-checkbox v-model="checkBox1"
                                  >No</vs-checkbox
                                >
                              </li>
                            </ul>
                          </div>                          
                        </div>
                      </div>
                      <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                          <label class="form_label"> If ”Yes”, number of employees worker will supervise</label>
                          <vs-input
                            name="SOC"
                            data-vv-as="SOC"
                            class="w-full"
                          />
                        </div>
                      </div>
                      <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                          <label class="form_label">If “Yes”, please indicate the level of the employees to be supervised</label>
                          <div class="listitems mt-5 pb-0"> 
                            <ul class="custom-radio">
                              <li>
                                <vs-checkbox v-model="checkBox1"
                                  >Subordinate</vs-checkbox
                                >
                              </li>
                              <li>
                                <vs-checkbox v-model="checkBox1"
                                  >Peer</vs-checkbox
                                >
                              </li>
                            </ul>
                          </div>                          
                        </div>
                      </div>
                      <div class="vx-col w-full">
                        <div class="form_group">
                          <label class="form_label">Job Duties</label>
                          <!-- <vs-textarea v-model="textarea" class="w-full" /> -->
                          <ckeditor v-model="textarea" class="w-full"   :editor="editor" :config="editorConfig"></ckeditor>

                        </div>
                      </div>
                      <div class="vx-col w-full">
                        <div class="form_group">
                          <div class="listitems listitems2">
                            <h6>Will travel be required in order to perform the job duties?</h6>
                            <ul class="custom-radio">
                              <li>
                                <vs-checkbox v-model="checkBox1"
                                  >Yes</vs-checkbox
                                >
                              </li>
                              <li>
                                <vs-checkbox v-model="checkBox1"
                                  >No</vs-checkbox>
                              </li>
                            </ul>
                          </div>                          
                        </div>
                      </div>
                      <div class="vx-col w-full">
                        <div class="form_group">
                          <label class="form_label">If “Yes”, please provide details of the travel required, such as the area(s), frequency and nature of the travel. </label>
                          <vs-input
                            name="SOC"
                            data-vv-as="SOC"
                            class="w-50"
                          />
                        </div>
                      </div>
                    </div>
                  </vs-col>
                  <span class="form_devider"></span>
                  <vs-col class="m-auto float-none" vs-lg="11" vs-sm="12">
                    <h3 class="small-header">Minimum Job Requirements</h3>
                    <div class="vx-row">
                      <div class="vx-col w-full">
                         <div class="form_group">
                          <div class="listitems listitems2">
                            <h6>Education: minimum U.S. diploma/degree required</h6>
                            <ul class="custom-radio">
                              <li>
                                <vs-checkbox v-model="checkBox1">None</vs-checkbox>
                              </li>
                              <li>
                                <vs-checkbox v-model="checkBox1">High School/GED</vs-checkbox>
                              </li>
                              <li>
                                <vs-checkbox v-model="checkBox1">Associate's</vs-checkbox>
                              </li>
                              <li>
                                <vs-checkbox v-model="checkBox1">Bachelor's</vs-checkbox>
                              </li>
                              <li>
                                <vs-checkbox v-model="checkBox1">Master's</vs-checkbox>
                              </li>
                              <li>
                                <vs-checkbox v-model="checkBox1">Doctorate (PhD)</vs-checkbox>
                              </li>
                              <li>
                                <vs-checkbox v-model="checkBox1">Other degree (JD, MD, etc.)</vs-checkbox>
                              </li> 
                            </ul>
                          </div>                          
                        </div>
                      </div>
                      <div class="vx-col w-full">
                        <div class="form_group">
                          <label class="form_label">If “Other degree” in question 1, specify the diploma/degree required</label>
                          <vs-input
                            name="SOC"
                            data-vv-as="SOC"
                            class="w-full"
                          />
                        </div>
                      </div>
                      <div class="vx-col w-full">
                        <div class="form_group">
                          <label class="form_label">Indicate the major(s) and/or field(s) of study required (May list more than one related major and more than one field)</label>
                          <vs-input
                            name="SOC"
                            data-vv-as="SOC"
                            class="w-full"
                          />
                        </div>
                      </div>                       
                      <div class="vx-col w-full">
                        <div class="form_group">
                          <div class="listitems listitems2">
                            <h6>Does the employer require a second U.S. diploma/degree?</h6>
                            <ul class="custom-radio">
                              <li>
                                <vs-checkbox v-model="checkBox1"
                                  >Yes</vs-checkbox
                                >
                              </li>
                              <li>
                                <vs-checkbox v-model="checkBox1"
                                  >No</vs-checkbox
                                >
                              </li>
                            </ul>
                          </div>                          
                        </div>
                      </div>
                      <div class="vx-col w-full">
                        <div class="form_group">
                          <label class="form_label">If “Yes”, indicate the second U.S. diploma/degree and the major(s) and/or field(s) of study required </label>
                          <vs-input
                            name="SOC"
                            data-vv-as="SOC"
                            class="w-full"
                          />
                        </div>
                      </div>
                      <div class="vx-col w-full">
                        <div class="form_group">
                          <div class="listitems listitems2">
                            <h6>Is training for the job opportunity required?</h6>
                            <ul class="custom-radio">
                              <li>
                                <vs-checkbox v-model="checkBox1"
                                  >Yes</vs-checkbox
                                >
                              </li>
                              <li>
                                <vs-checkbox v-model="checkBox1"
                                  >No</vs-checkbox
                                >
                              </li>
                            </ul>
                          </div>                          
                        </div>
                      </div>
                      <div class="vx-col w-full">
                        <div class="form_group">
                          <label class="form_label">If “Yes”, specify the number of months of training required</label>
                          <vs-input
                            name="SOC"
                            data-vv-as="SOC"
                            class="w-50"
                          />
                        </div>
                      </div>
                      <div class="vx-col w-full">
                        <div class="form_group">
                          <label class="form_label">Indicate the field(s)/name(s) of training required (May list more than one related field and more than one type)</label>
                          <vs-input
                            name="SOC"
                            data-vv-as="SOC"
                            class="w-50"
                          />
                        </div>
                      </div>
                      <div class="vx-col w-full">
                        <div class="form_group">
                          <div class="listitems listitems2">
                            <h6>Is employment experience required?</h6>
                            <ul class="custom-radio">
                              <li>
                                <vs-checkbox v-model="checkBox1"
                                  >Yes</vs-checkbox
                                >
                              </li>
                              <li>
                                <vs-checkbox v-model="checkBox1"
                                  >No</vs-checkbox
                                >
                              </li>
                            </ul>
                          </div>                          
                        </div>
                      </div>
                      <div class="vx-col w-full">
                        <div class="form_group">
                          <label class="form_label">If “Yes”, specify the number of months of experience required</label>
                          <vs-input
                            name="SOC"
                            data-vv-as="SOC"
                            class="w-50"
                          />
                        </div>
                      </div>
                      <div class="vx-col w-full">
                        <div class="form_group">
                          <label class="form_label">Indicate the occupation required</label>
                          <vs-input
                            name="SOC"
                            data-vv-as="SOC"
                            class="w-50"
                          />
                        </div>
                      </div>
                      <div class="vx-col w-full">
                        <div class="form_group">
                          <label class="form_label">Special Requirements - List specific skills, licenses/certificates/certifications, and requirements of the job opportunity</label>
                          <!-- <vs-textarea v-model="textarea" class="w-full" /> -->
                          <ckeditor  v-model="textarea" class="w-full" :editor="editor" :config="editorConfig"></ckeditor>

                        </div>
                      </div> 
                    </div>
                  </vs-col>
                </div>
              </form>
               
              </div>
              <div v-if="selectedTab == 'documents'" id="documents">
                <form>
                  <div class="form-container pt-6">
                    <vs-col class="m-auto float-none" vs-lg="11" vs-sm="12">
                    <h3 class="small-header">Wage Processing Information</h3>
                    <div class="vx-row">
                      <div class="vx-col w-full">
                        <div class="form_group">
                          <div class="listitems listitems2">
                            <h6>Is the employer covered by ACWIA?</h6>
                            <ul class="custom-radio">
                              <li>
                                <vs-checkbox v-model="checkBox1"
                                  >Yes</vs-checkbox
                                >
                              </li>
                              <li>
                                <vs-checkbox v-model="checkBox1"
                                  >No</vs-checkbox
                                >
                              </li>
                            </ul>
                          </div>
                          <div class="listitems listitems2">
                            <h6>
                              Is the position covered by a Collective Bargaining
                              Agreement (CBA)?
                            </h6>
                            <ul class="custom-radio">
                              <li>
                                <vs-checkbox v-model="checkBox1"
                                  >Yes</vs-checkbox
                                >
                              </li>
                              <li>
                                <vs-checkbox v-model="checkBox1"
                                  >No</vs-checkbox
                                >
                              </li>
                            </ul>
                          </div>
                          <div class="listitems listitems2">
                            <h6>
                              Is the employer requesting consideration of
                              Davis-Bacon (DBA) or McNamara Service Contract
                              (SCA) Acts?
                            </h6>
                            <ul class="custom-radio">
                              <li>
                                <vs-checkbox v-model="checkBox1"
                                  >DBA</vs-checkbox
                                >
                              </li>
                              <li>
                                <vs-checkbox v-model="checkBox1"
                                  >SCA</vs-checkbox
                                >
                              </li>
                            </ul>
                          </div>
                          <div class="listitems listitems2">
                            <h6>
                              Is the employer requesting consideration of a
                              survey in determining the prevailing wage?
                            </h6>
                            <ul class="custom-radio">
                              <li>
                                <vs-checkbox v-model="checkBox1"
                                  >Yes</vs-checkbox
                                >
                              </li>
                              <li>
                                <vs-checkbox v-model="checkBox1"
                                  >No</vs-checkbox
                                >
                              </li>
                            </ul>
                          </div>
                        </div>
                      </div>
                      <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                          <label class="form_label">Survey Name</label>
                          <vs-input
                            class="w-full"
                            name="line1"
                            data-vv-as="Street Address"
                          />
                        </div>
                      </div>
                      <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                          <label class="form_label"
                            >Survey date of publication</label
                          >
                          <vs-input
                            class="w-full"
                            name="line1"
                            data-vv-as="Street Address"
                          />
                        </div>
                      </div>
                    </div>
                    </vs-col>
                    <span class="form_devider"></span>
                    <vs-col class="m-auto float-none" vs-lg="11" vs-sm="12">
                      <h3 class="small-header">Prevailing Wage Determination</h3>
                      <div class="vx-row">
                          <div class="vx-col md:w-1/2 w-full">
                              <div class="form_group">
                                  <label class="form_label">PW Tracking Number</label>
                                  <vs-input
                                      name="SOC"
                                      data-vv-as="SOC"
                                      class="w-100"
                                  />
                              </div>
                          </div>
                          <div class="vx-col md:w-1/2 w-full">
                              <div class="form_group">
                                  <label class="form_label">Date PW Request Received</label>
                                  <vs-input
                                      name="SOC"
                                      data-vv-as="SOC"
                                      class="w-100"
                                  />
                              </div>
                          </div>
                          <div class="vx-col md:w-1/2 w-full">
                              <div class="form_group">
                                  <label class="form_label">SOC (ONET/OES) Code</label>
                                  <vs-input
                                      name="SOC"
                                      data-vv-as="SOC"
                                      class="w-100"
                                  />
                              </div>
                          </div>
                          <div class="vx-col md:w-1/2 w-full">
                              <div class="form_group">
                                  <label class="form_label">SOC (ONET/OES) Cccupation Title</label>
                                  <vs-input
                                      name="SOC"
                                      data-vv-as="SOC"
                                      class="w-100"
                                  />
                              </div>
                          </div>
                          <div class="vx-col md:w-1/2 w-full">
                              <div class="form_group">
                                  <label class="form_label">Prevailing Wage</label>
                                  <vs-input
                                      name="SOC"
                                      data-vv-as="SOC"
                                      class="w-100"
                                  />
                              </div>
                          </div>
                          <div class="vx-col md:w-1/2 w-full">
                              <div class="form_group">
                                  <label class="form_label">OES Wage Level</label>                                 
                                  <div class="listitems listitems2"> 
                                      <ul class="custom-radio">
                                          <li>
                                              <vs-checkbox v-model="checkBox1"
                                              >I</vs-checkbox
                                              >
                                          </li>
                                          <li>
                                              <vs-checkbox v-model="checkBox1"
                                              >II</vs-checkbox>
                                          </li>
                                          <li>
                                              <vs-checkbox v-model="checkBox1"
                                              >III</vs-checkbox>
                                          </li>
                                          <li>
                                              <vs-checkbox v-model="checkBox1"
                                              >IV</vs-checkbox>
                                          </li>
                                          <li>
                                              <vs-checkbox v-model="checkBox1"
                                              >V</vs-checkbox>
                                          </li>
                                      </ul>
                                  </div>
                              </div>
                          </div>
                          <div class="vx-col w-full">
                              <div class="form_group">
                                  <label class="form_label">Per: (Choose only one)</label>                                 
                                  <div class="listitems listitems2"> 
                                      <ul class="custom-radio">
                                          <li>
                                              <vs-checkbox v-model="checkBox1"
                                              >Hour</vs-checkbox
                                              >
                                          </li>
                                          <li>
                                              <vs-checkbox v-model="checkBox1"
                                              >Week</vs-checkbox>
                                          </li>
                                          <li>
                                              <vs-checkbox v-model="checkBox1"
                                              >Bi-Weekly</vs-checkbox>
                                          </li>
                                          <li>
                                              <vs-checkbox v-model="checkBox1"
                                              >Month</vs-checkbox>
                                          </li>
                                          <li>
                                              <vs-checkbox v-model="checkBox1"
                                              >Year</vs-checkbox>
                                          </li>
                                          <li>
                                              <vs-checkbox v-model="checkBox1"
                                              >Piece Rate</vs-checkbox>
                                          </li>
                                      </ul>
                                  </div>
                              </div>
                          </div>
                          <div class="vx-col md:w-1/2 w-full">
                              <div class="form_group">
                                  <label class="form_label">Specify the wage offer requirements:</label>
                                  <vs-input
                                      name="SOC"
                                      data-vv-as="SOC"
                                      class="w-100"
                                  />
                              </div>
                          </div>
                          <div class="vx-col w-full">
                              <div class="form_group">
                                  <label class="form_label">Prevailing Wage Source (Choose only one)</label>                                 
                                  <div class="listitems listitems2"> 
                                      <ul class="custom-radio">
                                          <li>
                                              <vs-checkbox v-model="checkBox1"
                                              >OES (All Industries)</vs-checkbox
                                              >
                                          </li>
                                          <li>
                                              <vs-checkbox v-model="checkBox1"
                                              >OES (ACWIA – Higher Education)</vs-checkbox>
                                          </li>
                                          <li>
                                              <vs-checkbox v-model="checkBox1"
                                              >CBA</vs-checkbox>
                                          </li>
                                          <li>
                                              <vs-checkbox v-model="checkBox1"
                                              >DBA</vs-checkbox>
                                          </li>
                                          <li>
                                              <vs-checkbox v-model="checkBox1"
                                              >SCA</vs-checkbox>
                                          </li>
                                          <li>
                                              <vs-checkbox v-model="checkBox1"
                                              >Other/Alternate Survey</vs-checkbox>
                                          </li>
                                      </ul>
                                  </div>
                              </div>
                          </div>
                          <div class="vx-col  w-full">
                              <div class="form_group">
                                  <label class="form_label">If any "Other/Alternate Survey" in Prevailing wage source</label>
                                  <!-- <vs-textarea v-model="textarea" class="w-full" /> -->
                                  <ckeditor  v-model="textarea" class="w-full" :editor="editor" :config="editorConfig"></ckeditor>

                              </div>
                          </div>
                          <div class="vx-col  w-full">
                              <div class="form_group">
                                  <label class="form_label">Additional Notes Regarding Wage Determination</label>
                                  <!-- <vs-textarea v-model="textarea" class="w-full" /> -->
                                  <ckeditor  v-model="textarea" class="w-full" :editor="editor" :config="editorConfig"></ckeditor>
                                  
                                  <date-range-picker
                                    ref="startDatePicker"
                                    :opens="'left'"                                   
                                    :ranges="true"
                                    customRangeLabel="Custom Range"
                                    name="picker"
                                    :label="'Place Holder'"                                  
                                    v-model="selected_createdDateRange"
                                  ></date-range-picker> 
                              </div>
                          </div> 
                          
                      </div>
                    </vs-col>
                  </div>
                </form>
              </div>
              <form class="d-none">
                <div class="form-container pt-6">
                  <vs-col class="m-auto float-none" vs-lg="11" vs-sm="12">
                    <div class="vx-row">
                      <div class="vx-col w-full">
                        <vx-input-group class="form-input-group">
                          <vs-input
                            name="firstname"
                            class="w-full"
                            data-vv-as="First Name"
                            label="First Name"
                          />
                          <vs-input
                            class="w-full"
                            name="middleName"
                            data-vv-as="Middle Name"
                            label="Middle Name"
                          />
                          <vs-input
                            class="w-full"
                            name="lastName"
                            data-vv-as="Last Name"
                            label="Last Name"
                          />
                        </vx-input-group>
                        <!-- <div class="input-group-error">
                                <p class="w-1/3">
                                <span class="text-danger text-sm"
                                    v-show="errors.has('beneficiaryInfoform.firstname')">{{ errors.first("beneficiaryInfoform.firstname") }}</span>
                                </p>
                                <p class="w-1/3">
                                
                                </p>
                                <p class="w-1/3">
                                <span class="text-danger text-sm"
                                    v-show="errors.has('beneficiaryInfoform.lastName')">{{ errors.first("beneficiaryInfoform.lastName") }}</span>
                                </p>
                                </div> -->
                      </div>
                      <div class="vx-col w-full md:w-1/2">
                        <div class="form_group">
                          <label class="form_label">job Title</label>
                          <vs-input
                            class="w-full"
                            data-vv-as="DOL Reference Number"
                          />
                        </div>
                      </div>
                      <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                          <label class="form_label">E-Mail</label>
                          <vs-input
                            name="line2"
                            data-vv-as="Apt, Suite"
                            class="w-full"
                          />
                        </div>
                      </div>                       
                      <gcAddress></gcAddress>


                      <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                          <label class="form_label">
                            Province (if applicable)</label
                          >
                          <vs-input
                            name="line2"
                            data-vv-as="Apt, Suite"
                            class="w-full"
                          />
                        </div>
                      </div>
                      <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group ph_number">
                          <div class="vs-component">
                            <label class="form_label">Phone Number</label>
                            <VuePhoneNumberInput v-model="value" />
                          </div>
                        </div>
                      </div> 
                      <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                          <div class="vs-component">
                            <label class="form_label">Fax Number</label>
                            <VuePhoneNumberInput v-model="value" />
                          </div>
                        </div>
                      </div>
                      
                    </div>
                  </vs-col>
                  <span class="form_devider"></span>
                  <vs-col class="m-auto float-none" vs-lg="11" vs-sm="12">
                    <h3 class="small-header">Employer Information</h3>
                    <div class="vx-row">
                      <div class="vx-col w-full md:w-1/2">
                        <div class="form_group">
                          <label class="form_label">Legal Business Name</label>
                          <vs-input
                            class="w-full"
                            data-vv-as="DOL Reference Number"
                          />
                        </div>
                      </div>
                      <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                          <label class="form_label"
                            >Trade name/Doing Business As (DBA), if applicable</label>
                          <vs-input
                            class="w-full"
                            name="line1"
                            data-vv-as="Street Address"
                          />
                        </div>
                      </div>
                       <gcAddress></gcAddress>
                      <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                          <label class="form_label">
                            Province (if applicable)</label
                          >
                          <vs-input
                            name="line2"
                            data-vv-as="Apt, Suite"
                            class="w-full"
                          />
                        </div>
                      </div>
                      <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group ph_number">
                          <div class="vs-component">
                            <label class="form_label">Phone Number</label>
                            <VuePhoneNumberInput v-model="value" />
                          </div>
                        </div>
                      </div> 
                      <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                          <label class="form_label"
                            >Federal Employer Identification Number (FEIN from
                            IRS)</label
                          >
                          <vs-input
                            name="line2"
                            data-vv-as="Apt, Suite"
                            class="w-full"
                          />
                        </div>
                      </div>
                      <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                          <label class="form_label"
                            >NAICS Code (must be at least 4-digits)</label
                          >
                          <vs-input
                            name="line2"
                            data-vv-as="Apt, Suite"
                            class="w-full"
                          />
                        </div>
                      </div>
                    </div>
                  </vs-col>
                  <span class="form_devider"></span>
                  <vs-col class="m-auto float-none" vs-lg="11" vs-sm="12">
                    <h3 class="small-header">Wage Processing Information</h3>
                    <div class="vx-row">
                      <div class="vx-col w-full">
                        <div class="form_group">
                          <div class="listitems listitems2">
                            <h6>Is the employer covered by ACWIA?</h6>
                            <ul class="custom-radio">
                              <li>
                                <vs-checkbox v-model="checkBox1"
                                  >Yes</vs-checkbox
                                >
                              </li>
                              <li>
                                <vs-checkbox v-model="checkBox1"
                                  >No</vs-checkbox
                                >
                              </li>
                            </ul>
                          </div>
                          <div class="listitems listitems2">
                            <h6>
                              Is the position covered by a Collective Bargaining
                              Agreement (CBA)?
                            </h6>
                            <ul class="custom-radio">
                              <li>
                                <vs-checkbox v-model="checkBox1"
                                  >Yes</vs-checkbox
                                >
                              </li>
                              <li>
                                <vs-checkbox v-model="checkBox1"
                                  >No</vs-checkbox
                                >
                              </li>
                            </ul>
                          </div>
                          <div class="listitems listitems2">
                            <h6>
                              Is the employer requesting consideration of
                              Davis-Bacon (DBA) or McNamara Service Contract
                              (SCA) Acts?
                            </h6>
                            <ul class="custom-radio">
                              <li>
                                <vs-checkbox v-model="checkBox1"
                                  >DBA</vs-checkbox
                                >
                              </li>
                              <li>
                                <vs-checkbox v-model="checkBox1"
                                  >SCA</vs-checkbox
                                >
                              </li>
                            </ul>
                          </div>
                          <div class="listitems listitems2">
                            <h6>
                              Is the employer requesting consideration of a
                              survey in determining the prevailing wage?
                            </h6>
                            <ul class="custom-radio">
                              <li>
                                <vs-checkbox v-model="checkBox1"
                                  >Yes</vs-checkbox
                                >
                              </li>
                              <li>
                                <vs-checkbox v-model="checkBox1"
                                  >No</vs-checkbox
                                >
                              </li>
                            </ul>
                          </div>
                        </div>
                      </div>
                      <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                          <label class="form_label">Survey Name</label>
                          <vs-input
                            class="w-full"
                            name="line1"
                            data-vv-as="Street Address"
                          />
                        </div>
                      </div>
                      <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                          <label class="form_label"
                            >Survey date of publication</label
                          >
                          <vs-input
                            class="w-full"
                            name="line1"
                            data-vv-as="Street Address"
                          />
                        </div>
                      </div>
                    </div>
                  </vs-col>
                  <span class="form_devider"></span>
                  <vs-col class="m-auto float-none" vs-lg="11" vs-sm="12">
                    <h3 class="small-header">Job Description</h3>
                    <div class="vx-row">
                      <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                          <label class="form_label">Job Title</label>
                          <vs-input
                            name="Job Title"
                            data-vv-as="Job Title"
                            class="w-full"
                          />
                        </div>
                      </div>
                      <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                          <label class="form_label">Suggested SOC (ONET/OES) code</label>
                          <vs-input
                            name="SOC"
                            data-vv-as="SOC"
                            class="w-full"
                          />
                        </div>
                      </div>
                      <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                          <label class="form_label">Suggested SOC (ONET/OES) occupation title</label>
                          <vs-input
                            name="SOC"
                            data-vv-as="SOC"
                            class="w-full"
                          />
                        </div>
                      </div>
                      <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                          <label class="form_label">Job Title of Supervisor for this Position (if applicable)</label>
                          <vs-input
                            name="SOC"
                            data-vv-as="SOC"
                            class="w-full"
                          />
                        </div>
                      </div>
                      <div class="vx-col w-full">
                        <div class="form_group">
                          <div class="listitems listitems2">
                            <h6>Does this position supervise the work of other employees?</h6>
                            <ul class="custom-radio">
                              <li>
                                <vs-checkbox v-model="checkBox1"
                                  >Yes</vs-checkbox
                                >
                              </li>
                              <li>
                                <vs-checkbox v-model="checkBox1"
                                  >No</vs-checkbox
                                >
                              </li>
                            </ul>
                          </div>                          
                        </div>
                      </div>
                      <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                          <label class="form_label"> If ”Yes”, number of employees worker will supervise</label>
                          <vs-input
                            name="SOC"
                            data-vv-as="SOC"
                            class="w-full"
                          />
                        </div>
                      </div>
                      <div class="vx-col md:w-1/2 w-full">
                        <div class="form_group">
                          <label class="form_label">If “Yes”, please indicate the level of the employees to be supervised</label>
                          <div class="listitems mt-5 pb-0"> 
                            <ul class="custom-radio">
                              <li>
                                <vs-checkbox v-model="checkBox1"
                                  >Subordinate</vs-checkbox
                                >
                              </li>
                              <li>
                                <vs-checkbox v-model="checkBox1"
                                  >Peer</vs-checkbox
                                >
                              </li>
                            </ul>
                          </div>                          
                        </div>
                      </div>
                      <div class="vx-col w-full">
                        <div class="form_group">
                          <label class="form_label">Job Duties</label>
                          <!-- <vs-textarea v-model="textarea" class="w-full" /> -->
                          <ckeditor  v-model="textarea" class="w-full"  :editor="editor" :config="editorConfig"></ckeditor>

                        </div>
                      </div>
                      <div class="vx-col w-full">
                        <div class="form_group">
                          <div class="listitems listitems2">
                            <h6>Will travel be required in order to perform the job duties?</h6>
                            <ul class="custom-radio">
                              <li>
                                <vs-checkbox v-model="checkBox1"
                                  >Yes</vs-checkbox
                                >
                              </li>
                              <li>
                                <vs-checkbox v-model="checkBox1"
                                  >No</vs-checkbox>
                              </li>
                            </ul>
                          </div>                          
                        </div>
                      </div>
                      <div class="vx-col w-full">
                        <div class="form_group">
                          <label class="form_label">If “Yes”, please provide details of the travel required, such as the area(s), frequency and nature of the travel. </label>
                          <vs-input
                            name="SOC"
                            data-vv-as="SOC"
                            class="w-50"
                          />
                        </div>
                      </div>
                    </div>
                  </vs-col>
                  <span class="form_devider"></span>
                  <vs-col class="m-auto float-none" vs-lg="11" vs-sm="12">
                    <h3 class="small-header">Minimum Job Requirements</h3>
                    <div class="vx-row">
                      <div class="vx-col w-full">
                         <div class="form_group">
                          <div class="listitems listitems2">
                            <h6>Education: minimum U.S. diploma/degree required</h6>
                            <ul class="custom-radio">
                              <li>
                                <vs-checkbox v-model="checkBox1">None</vs-checkbox>
                              </li>
                              <li>
                                <vs-checkbox v-model="checkBox1">High School/GED</vs-checkbox>
                              </li>
                              <li>
                                <vs-checkbox v-model="checkBox1">Associate's</vs-checkbox>
                              </li>
                              <li>
                                <vs-checkbox v-model="checkBox1">Bachelor's</vs-checkbox>
                              </li>
                              <li>
                                <vs-checkbox v-model="checkBox1">Master's</vs-checkbox>
                              </li>
                              <li>
                                <vs-checkbox v-model="checkBox1">Doctorate (PhD)</vs-checkbox>
                              </li>
                              <li>
                                <vs-checkbox v-model="checkBox1">Other degree (JD, MD, etc.)</vs-checkbox>
                              </li> 
                            </ul>
                          </div>                          
                        </div>
                      </div>
                      <div class="vx-col w-full">
                        <div class="form_group">
                          <label class="form_label">If “Other degree” in question 1, specify the diploma/degree required</label>
                          <vs-input
                            name="SOC"
                            data-vv-as="SOC"
                            class="w-full"
                          />
                        </div>
                      </div>
                      <div class="vx-col w-full">
                        <div class="form_group">
                          <label class="form_label">Indicate the major(s) and/or field(s) of study required (May list more than one related major and more than one field)</label>
                          <vs-input
                            name="SOC"
                            data-vv-as="SOC"
                            class="w-full"
                          />
                        </div>
                      </div>                       
                      <div class="vx-col w-full">
                        <div class="form_group">
                          <div class="listitems listitems2">
                            <h6>Does the employer require a second U.S. diploma/degree?</h6>
                            <ul class="custom-radio">
                              <li>
                                <vs-checkbox v-model="checkBox1"
                                  >Yes</vs-checkbox
                                >
                              </li>
                              <li>
                                <vs-checkbox v-model="checkBox1"
                                  >No</vs-checkbox
                                >
                              </li>
                            </ul>
                          </div>                          
                        </div>
                      </div>
                      <div class="vx-col w-full">
                        <div class="form_group">
                          <label class="form_label">If “Yes”, indicate the second U.S. diploma/degree and the major(s) and/or field(s) of study required </label>
                          <vs-input
                            name="SOC"
                            data-vv-as="SOC"
                            class="w-full"
                          />
                        </div>
                      </div>
                      <div class="vx-col w-full">
                        <div class="form_group">
                          <div class="listitems listitems2">
                            <h6>Is training for the job opportunity required?</h6>
                            <ul class="custom-radio">
                              <li>
                                <vs-checkbox v-model="checkBox1"
                                  >Yes</vs-checkbox
                                >
                              </li>
                              <li>
                                <vs-checkbox v-model="checkBox1"
                                  >No</vs-checkbox
                                >
                              </li>
                            </ul>
                          </div>                          
                        </div>
                      </div>
                      <div class="vx-col w-full">
                        <div class="form_group">
                          <label class="form_label">If “Yes”, specify the number of months of training required</label>
                          <vs-input
                            name="SOC"
                            data-vv-as="SOC"
                            class="w-50"
                          />
                        </div>
                      </div>
                      <div class="vx-col w-full">
                        <div class="form_group">
                          <label class="form_label">Indicate the field(s)/name(s) of training required (May list more than one related field and more than one type)</label>
                          <vs-input
                            name="SOC"
                            data-vv-as="SOC"
                            class="w-50"
                          />
                        </div>
                      </div>
                      <div class="vx-col w-full">
                        <div class="form_group">
                          <div class="listitems listitems2">
                            <h6>Is employment experience required?</h6>
                            <ul class="custom-radio">
                              <li>
                                <vs-checkbox v-model="checkBox1"
                                  >Yes</vs-checkbox
                                >
                              </li>
                              <li>
                                <vs-checkbox v-model="checkBox1"
                                  >No</vs-checkbox
                                >
                              </li>
                            </ul>
                          </div>                          
                        </div>
                      </div>
                      <div class="vx-col w-full">
                        <div class="form_group">
                          <label class="form_label">If “Yes”, specify the number of months of experience required</label>
                          <vs-input
                            name="SOC"
                            data-vv-as="SOC"
                            class="w-50"
                          />
                        </div>
                      </div>
                      <div class="vx-col w-full">
                        <div class="form_group">
                          <label class="form_label">Indicate the occupation required</label>
                          <vs-input
                            name="SOC"
                            data-vv-as="SOC"
                            class="w-50"
                          />
                        </div>
                      </div>
                      <div class="vx-col w-full">
                        <div class="form_group">
                          <label class="form_label">Special Requirements - List specific skills, licenses/certificates/certifications, and requirements of the job opportunity</label>
                          <!-- <vs-textarea v-model="textarea" class="w-full" /> -->
                          <ckeditor  v-model="textarea" class="w-full" :editor="editor" :config="editorConfig"></ckeditor>

                        </div>
                      </div> 
                    </div>
                  </vs-col>
                  <span class="form_devider"></span>
                  <vs-col class="m-auto float-none" vs-lg="11" vs-sm="12">
                    <h3 class="small-header">Place of Employment Information</h3>
                    <div class="vx-row">
                         <gcAddress></gcAddress>
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <div class="listitems listitems2">
                                    <h6>Will work be performed in multiple worksites within an area of intended employment or a location(s) other than the address listed above?</h6>
                                    <ul class="custom-radio">
                                        <li>
                                            <vs-checkbox v-model="checkBox1"
                                            >Yes</vs-checkbox
                                            >
                                        </li>
                                        <li>
                                            <vs-checkbox v-model="checkBox1"
                                            >No</vs-checkbox>
                                        </li>
                                    </ul>
                                </div>                          
                            </div>
                        </div>
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label">If “Yes”, identify the geographic place(s) of employment indicating each metropolitan statistical area (MSA) or the
independent city(ies)/township(s)/county(ies) (borough(s)/parish(es)) and the corresponding state(s) where work will be
performed. If necessary, submit a second completed Form ETA-9141 with a listing of the additional anticipated
worksites. Please note that wages cannot be provided for unspecified/unanticipated locations.</label>
                                <!-- <vs-textarea v-model="textarea" class="w-full" /> -->
                                <ckeditor v-model="textarea" class="w-full"  :editor="editor" :config="editorConfig"></ckeditor>

                            </div>
                        </div>
                    </div>
                  </vs-col>
                  <span class="form_devider"></span>
                  <vs-col class="m-auto float-none" vs-lg="11" vs-sm="12">
                    <h3 class="small-header">Prevailing Wage Determination</h3>
                    <div class="vx-row">
                        <div class="vx-col md:w-1/2 w-full">
                            <div class="form_group">
                                <label class="form_label">PW Tracking Number</label>
                                <vs-input
                                    name="SOC"
                                    data-vv-as="SOC"
                                    class="w-100"
                                />
                            </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                            <div class="form_group">
                                <label class="form_label">Date PW Request Received</label>
                                <vs-input
                                    name="SOC"
                                    data-vv-as="SOC"
                                    class="w-100"
                                />
                            </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                            <div class="form_group">
                                <label class="form_label">SOC (ONET/OES) Code</label>
                                <vs-input
                                    name="SOC"
                                    data-vv-as="SOC"
                                    class="w-100"
                                />
                            </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                            <div class="form_group">
                                <label class="form_label">SOC (ONET/OES) Cccupation Title</label>
                                <vs-input
                                    name="SOC"
                                    data-vv-as="SOC"
                                    class="w-100"
                                />
                            </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                            <div class="form_group">
                                <label class="form_label">Prevailing Wage</label>
                                <vs-input
                                    name="SOC"
                                    data-vv-as="SOC"
                                    class="w-100"
                                />
                            </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                            <div class="form_group">
                                <label class="form_label">OES Wage Level</label>                                 
                                <div class="listitems listitems2"> 
                                    <ul class="custom-radio">
                                        <li>
                                            <vs-checkbox v-model="checkBox1"
                                            >I</vs-checkbox
                                            >
                                        </li>
                                        <li>
                                            <vs-checkbox v-model="checkBox1"
                                            >II</vs-checkbox>
                                        </li>
                                        <li>
                                            <vs-checkbox v-model="checkBox1"
                                            >III</vs-checkbox>
                                        </li>
                                        <li>
                                            <vs-checkbox v-model="checkBox1"
                                            >IV</vs-checkbox>
                                        </li>
                                        <li>
                                            <vs-checkbox v-model="checkBox1"
                                            >V</vs-checkbox>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label">Per: (Choose only one)</label>                                 
                                <div class="listitems listitems2"> 
                                    <ul class="custom-radio">
                                        <li>
                                            <vs-checkbox v-model="checkBox1"
                                            >Hour</vs-checkbox
                                            >
                                        </li>
                                        <li>
                                            <vs-checkbox v-model="checkBox1"
                                            >Week</vs-checkbox>
                                        </li>
                                        <li>
                                            <vs-checkbox v-model="checkBox1"
                                            >Bi-Weekly</vs-checkbox>
                                        </li>
                                        <li>
                                            <vs-checkbox v-model="checkBox1"
                                            >Month</vs-checkbox>
                                        </li>
                                        <li>
                                            <vs-checkbox v-model="checkBox1"
                                            >Year</vs-checkbox>
                                        </li>
                                        <li>
                                            <vs-checkbox v-model="checkBox1"
                                            >Piece Rate</vs-checkbox>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="vx-col md:w-1/2 w-full">
                            <div class="form_group">
                                <label class="form_label">Specify the wage offer requirements:</label>
                                <vs-input
                                    name="SOC"
                                    data-vv-as="SOC"
                                    class="w-100"
                                />
                            </div>
                        </div>
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label">Prevailing Wage Source (Choose only one)</label>                                 
                                <div class="listitems listitems2"> 
                                    <ul class="custom-radio">
                                        <li>
                                            <vs-checkbox v-model="checkBox1"
                                            >OES (All Industries)</vs-checkbox
                                            >
                                        </li>
                                        <li>
                                            <vs-checkbox v-model="checkBox1"
                                            >OES (ACWIA – Higher Education)</vs-checkbox>
                                        </li>
                                        <li>
                                            <vs-checkbox v-model="checkBox1"
                                            >CBA</vs-checkbox>
                                        </li>
                                        <li>
                                            <vs-checkbox v-model="checkBox1"
                                            >DBA</vs-checkbox>
                                        </li>
                                        <li>
                                            <vs-checkbox v-model="checkBox1"
                                            >SCA</vs-checkbox>
                                        </li>
                                        <li>
                                            <vs-checkbox v-model="checkBox1"
                                            >Other/Alternate Survey</vs-checkbox>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="vx-col  w-full">
                            <div class="form_group">
                                <label class="form_label">If any "Other/Alternate Survey" in Prevailing wage source</label>
                                <!-- <vs-textarea v-model="textarea" class="w-full" /> -->
                                <ckeditor v-model="textarea" class="w-full"   :editor="editor" :config="editorConfig"></ckeditor>

                            </div>
                        </div>
                        <div class="vx-col  w-full">
                            <div class="form_group">
                                <label class="form_label">Additional Notes Regarding Wage Determination</label>
                                <!-- <vs-textarea v-model="textarea" class="w-full" /> -->
                                <ckeditor v-model="textarea" class="w-full"  :editor="editor" :config="editorConfig"></ckeditor>

                                <date-range-picker
                                  ref="startDatePicker"
                                  :opens="'left'"                                   
                                  :ranges="true"
                                  customRangeLabel="Custom Range"
                                  name="picker"
                                  :label="'Place Holder'"                                  
                                  v-model="selected_createdDateRange"
                                ></date-range-picker> 
                            </div>
                        </div> 
                        
                    </div>
                  </vs-col>
                </div>
              </form>
            </div>
          </div>
        </div>
        <div class="questionnaire_footer">
          <div class="d-flex">
            <vs-button
              v-if="selectedTab != 'caseDetails'"
              @click="backStup()"
              class="questionnaire_btn"
              type="filled"
              >Back</vs-button
            >
          </div>
          <div class="d-flex">
            <vs-button
              @click="formSubmitted(true)"
              class="save questionnaire_btn"
              type="filled"
              >Save</vs-button
            >
            <vs-button
              color="success"
              v-if="selectedTab == 'dependentsInfo'"
              @click="openPreviewShow()"
              class="save questionnaire_btn"
              type="filled"
              >Review & Submit
            </vs-button>
            <template v-else>
              <vs-button
                color="success"
                v-if="
                  selectedTab == 'documents' &&
                  checkProperty(beneficiaryInfo, 'maritalStatus', 'id') != 2
                "
                @click="openPreviewShow()"
                class="save questionnaire_btn"
                type="filled"
                >Review & Submit
              </vs-button>
              <vs-button
                v-else
                @click="nextStup()"
                class="questionnaire_btn"
                type="filled"
                >Next</vs-button
              >
            </template>
          </div>
        </div>
      </div>
    </div>
    

    <!-----showChildForm
    toggleChildForm(false)

    -->
  </div>
</template>

<script>  
import Datepicker from "vuejs-datepicker-inv";
import moment from "moment";
import PhoneMaskInput from "vue-phone-mask-input";
import JQuery from "jquery";
import { TheMask } from "vue-the-mask";
import FileUpload from "vue-upload-component/src";
import _ from "lodash";
import Vue from "vue";
import VuePhoneNumberInput from "vue-phone-number-input";
import "vue-phone-number-input/dist/vue-phone-number-input.css";
import { Trash2Icon } from "vue-feather-icons";    
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import { XIcon } from "vue-feather-icons";
import DateRangePicker from "vue2-daterange-picker";
import gcAddress from "@/views/forms/gcAddress.vue";

Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';


export default {
  provide() {
    return {
      parentValidator: this.$validator,
    };
  },
  data() {
    return {
      editor: ClassicEditor,
 editorConfig: {
     toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
 },
      Employee: false,
      value: null,
      options: ["list", "of", "options"],

      settings: {
        swipeEasing: true,
      },
      selectedTab: "caseDetails", //'dependentsInfo',//'caseDetails',
    };
  },

  components: {
    XIcon,
    VuePerfectScrollbar,  
    VuePhoneNumberInput,

    Datepicker,
    PhoneMaskInput,
    TheMask,
    FileUpload,
    Trash2Icon,
    DateRangePicker,
    gcAddress
  },
};
</script>
