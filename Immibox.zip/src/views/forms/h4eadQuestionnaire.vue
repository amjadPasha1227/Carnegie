<template >
    <span>
      <div class="block-layout questionnaire" id="scrollableques" :class="{ 'padt20': !checkCurrentUrl }">
        <div class="vx-col w-full wizard-container form_section  questionnairesection pad0 case-form-v2">
          <div class="questionnaire_page" id="questionnaire_page">
            <div class="questionnaire_sec">
              <div class="questionnaire_titles">
                <div class="questionnaire_titles_info">
                  <h2>
                    <template v-if="checkProperty(petition, 'type')==10">Questionnaire for H4-EAD </template>
                    <template v-else>Questionnaire for H4</template><!-- <small v-if="petition.subTypeDetails">{{petition.subTypeDetails.name}}</small> -->
                  </h2>
                  <p>
                    Please take a few moments to complete this short registration form
                  </p>
  
                  <ul>
                    <template v-for="(item, index) in tabslist">
                      <li :key="index"
                        :class="{ 'active': currentTab == item.key || (index <= checkActiveTab && currentTab != item.key) }"
                        @click="setActiveTab(item.key, true)">
                        <span>{{ index + 1 }}</span><a>{{ item.name }} </a>
                      </li>
                    </template>
                  </ul>
                </div>
                <figure><img src="@/assets/images/main/content-bottom-image.svg" /></figure>
              </div>
             
              <div class="questionnaire_form">
                <div id="case_details_dt" v-if="currentTab == 'casedetails'">
                  <form data-vv-scope="casedetailsform">
                    <div class="vs-col w-full p-0 vs-xs- vs-sm- vs-lg-">
                      <div class="con-vs-alert warning-alert top-warning-alert con-vs-alert-warning con-icon">
                        <div class="vs-alert con-icon">
                          <i class="vs-icon notranslate icon-scale icon-alert IntakePortal IP-information-button null"></i>
                          NOTE: This questionnaire should be filled out completely and
                          accurately. Kindly read the instructions carefully.
                        </div>
                      </div>
                    </div>
                    <div class="vs-col m-auto float-none vs-xs- vs-sm-12 vs-lg-12">
                      <div class="form-container pt-10 form-container-questionnaire">
                        <div class="vx-row  pt-10">
                          <genderField :required="true" :display="false" formScope="casedetailsform" 
                          :fieldsArray="questionnaireDetails" :gender="petition.beneficiaryInfo.gender"
                           v-model="petition.beneficiaryInfo.gender" :tplsection="'beneficiaryInfo'" :tplkey="'gender'" :fieldName="'gender'" />
                          <div class="divider full-divider mb-10"></div>
                          <div class="vx-col w-full">
                            <vx-input-group class="form-input-group FML">
                              <immiInput :display="false" :fieldsArray="questionnaireDetails" cid="benf"
                                formscope="casedetailsform" v-model="petition.beneficiaryInfo.firstName"
                                :tplsection="'beneficiaryInfo'" :tplkey="'firstName'" :fieldName="'firstName'"
                                :required="false" label="First Name" placeHolder="First Name" />
                              <immiInput :display="false" :fieldsArray="questionnaireDetails" cid="benm"
                                formscope="casedetailsform" v-model="petition.beneficiaryInfo.middleName"
                                :tplsection="'beneficiaryInfo'" :tplkey="'middleName'" :fieldName="'middleName'"
                                :required="false" label="Middle Name" placeHolder="Middle Name" />
                              <immiInput :display="false" :fieldsArray="questionnaireDetails" cid="benl"
                                formscope="casedetailsform" v-model="petition.beneficiaryInfo.lastName"
                                :tplsection="'beneficiaryInfo'" :tplkey="'lastName'" :fieldName="'lastName'"
                                :required="false" label="Last Name" placeHolder="Last Name" />
                            </vx-input-group>
                          </div>
                          <immiInput :display="false" :fieldsArray="questionnaireDetails" datatype="email" wrapclass=" "
                            cid="benfemail" formscope="casedetailsform" v-model="petition.beneficiaryInfo.email"
                            :tplsection="'beneficiaryInfo'" :tplkey="'email'" :fieldName="'email'" :required="false"
                            label="Email" placeHolder="Email" />
                          <immiPhone :display="false" @updatephoneCountryCode="updatecellPhoneCountryCode"
                            :fieldsArray="questionnaireDetails"
                            :countrycode="petition.beneficiaryInfo.cellPhoneCountryCode.countryCode"
                            cid="bencellPhoneNumber" formscope="casedetailsform"
                            v-model="petition.beneficiaryInfo.cellPhoneNumber" :tplsection="'beneficiaryInfo'"
                            :tplkey="'cellPhoneNumber'" :fieldName="'cellPhoneNumber'" :required="false"
                            label="Phone Number" placeHolder="Phone Number" />

                          <immiPhone :fieldsArray="questionnaireDetails" :display="false" :tplkey="'homePhoneNumber'"
                            @updatephoneCountryCode="updatehomePhoneCountryCode" :countrycode="petition.beneficiaryInfo.homePhoneCountryCode.countryCode"
                            cid="benhomePhoneNumber" formscope="casedetailsform" v-model="petition.beneficiaryInfo.homePhoneNumber" 
                            :tplsection="'beneficiaryInfo'"  :fieldName="'homePhoneNumber'" label="Home Phone Number" placeHolder="Home Phone Number" />

                          <datepickerField :display="false" :fieldsArray="questionnaireDetails"
                            :dateEnableTo="startEligibleDate" :validationRequired="true"
                            v-model="petition.beneficiaryInfo.dateOfBirth" :tplsection="'beneficiaryInfo'"
                            :tplkey="'dateOfBirth'" :fieldName="'dateOfBirth'" formscope="casedetailsform"
                            label="Date of Birth" />
                          <selectField :display="false" :fieldsArray="questionnaireDetails" @input="changeBfProvince"
                            :required="false" :optionslist="countriesWithoutUS"
                            v-model="petition.beneficiaryInfo.countryOfBirthDetails" :tplsection="'beneficiaryInfo'"
                            :tplkey="'countryOfBirth'" :fieldName="'countryOfBirth'" formscope="casedetailsform"
                            label="Country of Birth" placeHolder="Country of Birth" />
                            <immiInput :display="false" :fieldsArray="questionnaireDetails" cid="benI94" datatype="max:15"
                              formscope="casedetailsform" v-model="petition.beneficiaryInfo.I94"
                              :tplsection="'beneficiaryInfo'" :tplkey="'I94'" :fieldName="'I94'" :required="false"
                              label="I-94 Number" placeHolder="I-94 Number" :maxLength="11" />
                              <datepickerField  :display="false"
                              :tplkey="'I94ExpiryDate'" :fieldsArray="questionnaireDetails"
                              :validationRequired="petition.beneficiaryInfo.I94!=null && petition.beneficiaryInfo.I94!=''"
                              v-model="petition.beneficiaryInfo.I94ExpiryDate"  :tplsection="'beneficiaryInfo'" 
                              :fieldName="'I94ExpiryDate'"  formscope="casedetailsform" :dateEnableFrom="featureDates"  label="I-94 Expiry Date" />
                              <selectField :fieldsArray="questionnaireDetails" :display="false" :tplkey="'maritalStatus'"
                               @input="petition.beneficiaryInfo.maritalStatus = petition.beneficiaryInfo.maritalStatusDetails.id" 
                               :required="true" v-if="marital_statuses.length > 0" 
                               :optionslist="marital_statuses" v-model="petition.beneficiaryInfo.maritalStatusDetails"
                                formscope="casedetailsform" :tplsection="'beneficiaryInfo'" :fieldName="'maritalStatus'"
                                 label="Marital Status" placeHolder="Marital Status" />
                              <template>
                                <div class="vx-col w-full">
                                    <div class="form_group w-full">
                                        <label class="form_label"><h3 class="small-header">Passport</h3>
                                        <div class="IB_tooltip H1-140">
                                            <span ><info-icon size="1.5x" class="custom-class"></info-icon ></span>
                                                <div class="tooltip_cnt">
                                                    <p>Make sure you input the most recent passport information. Also, note that the passport must have more than 6 months validity.</p>
                                                </div>
                                        </div>
                                    </label>
                                    </div>
                                </div>
                              </template>
                              <immiInput :allowUpperCase="true" :display="false" :tplkey="'passportNumber'" :fieldsArray="questionnaireDetails" datatype="alpha_num|max:15" cid="benfpassportNumber" formscope="casedetailsform" v-model="petition.beneficiaryInfo.passportNumber" :tplsection="'beneficiaryInfo'"  :fieldName="'passportNumber'"  :required="true"  label="Passport Number" placeHolder="Passport Number" />
                              <datepickerField :display="false" :tplkey="'passportIssuedDate'" :fieldsArray="questionnaireDetails" :validationRequired="true" v-model="petition.beneficiaryInfo.passportIssuedDate" :tplsection="'beneficiaryInfo'"  :fieldName="'passportIssuedDate'"  formscope="casedetailsform"  :dateEnableTo="new Date()" label="Passport Issued Date" />
                              <datepickerField :display="false" :tplkey="'passportExpiryDate'" :fieldsArray="questionnaireDetails" :dateEnableFrom="featureDates" :validationRequired="true" v-model="petition.beneficiaryInfo.passportExpiryDate" :tplsection="'beneficiaryInfo'"  :fieldName="'passportExpiryDate'"  formscope="casedetailsform"  label="Passport Expiry Date" />
                              <selectField   :display="false" :tplkey="'passportIssuedCountry'" :fieldsArray="questionnaireDetails" @input="petition.beneficiaryInfo.passportIssuedCountry = petition.beneficiaryInfo.passportIssuedCountryDetails.id" :required="true" :optionslist="countries" v-model="petition.beneficiaryInfo.passportIssuedCountryDetails"  :tplsection="'beneficiaryInfo'"  :fieldName="'passportIssuedCountry'" cid="passportIssuedCountry" formscope="casedetailsform"  label="Country of Passport Issued" placeHolder="Country of Passport Issued" />
                              <!-- <datepickerField  :display="false" :fieldsArray="questionnaireDetails" :tplkey="'lastArrivalDate'"   v-model="petition.beneficiaryInfo.lastArrivalDate" :formscope="'casedetailsform'" :dateEnableTo="featureDates"  :tplsection="'beneficiaryInfo'"  :fieldName="'lastArrivalDate'"  label="Date of most recent entry into the USA" /> -->
                              <selectField :display="false" :tplkey="'curNonImmigrantVisaStatus'" :fieldsArray="questionnaireDetails" @input="petition.beneficiaryInfo.curNonImmigrantVisaStatus = petition.beneficiaryInfo.curNonImmigrantVisaStatusDetails.id" :required="petition.beneficiaryInfo.currentlyInUS" :optionslist="petition.visaStatusList" v-model="petition.beneficiaryInfo.curNonImmigrantVisaStatusDetails" :tplsection="'beneficiaryInfo'"  :fieldName="'curNonImmigrantVisaStatus'"  formscope="casedetailsform"  label="Current Non-Immigrant Status" vvas="Nonimmigrant Status" placeholder="Nonimmigrant Status" />
                              <datepickerField  
                              :display="false"  :tplkey="'curVisaExpiryDate'" :fieldsArray="questionnaireDetails" :dateEnableFrom="featureDates" :validationRequired="true" v-model="petition.beneficiaryInfo.curVisaExpiryDate" :tplsection="'beneficiaryInfo'"  :fieldName="'curVisaExpiryDate'"  formscope="casedetailsform"  label="Current Status Expiry Date" />
                              <immiMask :display="false" :tplkey="'SSN'" :fieldsArray="questionnaireDetails" :patren="['### - ## - ####']" datatype="min:9|max:9" :wrapclass="canRenderField('ben_alienNumber',questionnaireDetails)?'md:w-1/2':' '" cid="benfSSN" formscope="casedetailsform" v-model="petition.beneficiaryInfo.SSN" :tplsection="'beneficiaryInfo'"  :fieldName="'SSN'"  :required="false"  label="Social Security number (if applicable)" vvas="Social Security number" placeHolder="123 - 45 - 6789" />

                              <selectField :tplkey="'stateOfLastEntryInUS'" :display="false" :fieldsArray="questionnaireDetails" @input="petition.beneficiaryInfo.stateOfLastEntryInUS = petition.beneficiaryInfo.stateDetailsOfLastEntryInUS.id" :required="true" :optionslist="usastates" v-model="petition.beneficiaryInfo.stateDetailsOfLastEntryInUS" :tplsection="'beneficiaryInfo'"  :fieldName="'stateOfLastEntryInUS'"  formscope="casedetailsform"  label="State of recent entry into the USA" placeHolder="State of recent entry into the USA" />                         
                              <immiInput :tplkey="'placeOfLastEntryInUS'" :display="false" :fieldsArray="questionnaireDetails"  cid="placeOfLastEntryInUS" formscope="casedetailsform" v-model="petition.beneficiaryInfo.placeOfLastEntryInUS" :tplsection="'beneficiaryInfo'"  :fieldName="'placeOfLastEntryInUS'"  :required="true"  label="Place of recent entry into the USA" placeHolder="Place of recent entry into the USA" />
                              <datepickerField  :display="false" :fieldsArray="questionnaireDetails" :tplkey="'lastArrivalDate'"  :validationRequired="true" v-model="petition.beneficiaryInfo.lastArrivalDate" formscope="casedetailsform" :dateEnableTo="featureDates"  :tplsection="'beneficiaryInfo'" :cid="'lastArrivalDate'"  :fieldName="'lastArrivalDate'"  label="Date of most recent entry into the USA" />
                              <immiInput :tplkey="'h1bSpouseApprNumber'" :display="false" :fieldsArray="questionnaireDetails"  cid="h1bSpouseApprNumber" formscope="casedetailsform" v-model="petition.beneficiaryInfo.h1bSpouseApprNumber" :tplsection="'beneficiaryInfo'" 
                                :onlyNumbers="true"  :fieldName="'h1bSpouseApprNumber'"  :required="true"  label="H-1B Spouse’s most recent approval number" placeHolder="H-1B Spouse’s most recent approval number" />
                                <div class="vx-col w-full">
                                  <immiyesorno :wrapclass="'yesnomar'"
                                  :cid="'haveYouEverEmployed'" 
                                  formscope="casedetailsform" 
                                  :required="checkFieldIsRequired({'key':'haveYouEverEmployed','section':'beneficiaryInfo', 'fieldsArray':questionnaireDetails, 'required':true })" 
                                  :display="false" :tplkey="'haveYouEverEmployed'" :fieldsArray="questionnaireDetails" 
                                  v-model="petition.beneficiaryInfo.haveYouEverEmployed" :tplsection="'beneficiaryInfo'" 
                                  :fieldName="'haveYouEverEmployed'"   label="Have you ever been employed?"></immiyesorno>
                                </div>
                                <template v-if="checkProperty(petition, 'beneficiaryInfo', 'haveYouEverEmployed')">
                                  <immiInput :tplkey="'empInUsIfANumber'" :display="false" :fieldsArray="questionnaireDetails"  cid="empInUsIfANumber" formscope="casedetailsform" v-model="petition.beneficiaryInfo.empInUsIfANumber" :tplsection="'beneficiaryInfo'" 
                                  :fieldName="'empInUsIfANumber'"  :required="true"  label="A-number, if any" placeHolder="A-number, if any" />
                                </template>

                              <div class="vx-col w-full">
                              <template v-if="countries.length>0">
                                <div v-if="canRenderField('address',questionnaireDetails, false, 'beneficiaryInfo' )">
                                  <h3 class="small-header">Current Address</h3>
                                  <addressField 
                                  :fieldsArray="questionnaireDetails" :disableCountry="false" formscope="casedetailsform" :showaptType="true" 
                                  :addFormContainerCls="false" :validationRequired="checkFieldIsRequired({'key':'address','section':'beneficiaryInfo', 'fieldsArray':questionnaireDetails, 'required':true })"
                                  :countries="countries" v-model="petition.beneficiaryInfo.address" :tplsection="'beneficiaryInfo'"  :fieldName="'address'"  :cid="'beneficiaryInfoaddress'" />
                                </div>
                              <!-- canRenderField('mailingAddressIsSameAsAddress',questionnaireDetails, false, 'beneficiaryInfo' ) && -->
                              <div v-if="( canRenderField('currentAddress',questionnaireDetails, false, 'beneficiaryInfo' ) )" >                                         
                                <div class="vx-col w-full d-flex">
                                    <h3 class="small-header">Mailing Address</h3>
                                    <template>
                                      <vs-checkbox @change="setSameaddress()"  v-model="petition.beneficiaryInfo.mailingAddressIsSameAsAddress" :tplsection="'beneficiaryInfo'"  :fieldName="'mailingAddressIsSameAsAddress'" 
                                      style="margin-left: 15px; margin-bottom:12px;">Same as Current Address </vs-checkbox >
                                    </template>
                                </div>
                                
                                <template >
                                  <addressField :ref="'mailingAddresscomponent'"  :display="true" :fieldsArray="questionnaireDetails" 
                                  formscope="casedetailsform" :showaptType="true" :addFormContainerCls="false" :validationRequired="checkFieldIsRequired({'key':'currentAddress','section':'beneficiaryInfo', 'fieldsArray':questionnaireDetails, 'required':true })" 
                                  :countries="countries" v-model="petition.beneficiaryInfo.currentAddress" :tplsection="'beneficiaryInfo'"  :fieldName="'currentAddress'"  :cid="'beneficiarymailInfoaddress'" />
                                </template>


                              </div>
                              <div v-if="canRenderField('addressOutsideUS',questionnaireDetails, false, 'beneficiaryInfo' )">
                                <h3 class="small-header">Address Outside the U.S</h3>
                                <addressField  :hideusa="true"
                                :validationRequired="checkFieldIsRequired({'key':'addressOutsideUS','section':'beneficiaryInfo', 'fieldsArray':questionnaireDetails, 'required':true })"
                                :fieldsArray="questionnaireDetails" :disableCountry="false" formscope="casedetailsform" :showaptType="true" :addFormContainerCls="false" :countries="countries"
                                v-model="petition.beneficiaryInfo.addressOutsideUS" :tplsection="'beneficiaryInfo'"  :fieldName="'addressOutsideUS'"  :cid="'addressOutsideUS'" />
                              </div>
                            </template>
                            </div>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
                <div v-if="currentTab=='documents'" id="documents_details">
                  <form data-vv-scope="documentsform" @submit.prevent="" @keydown.enter.prevent="">
                    <vs-col class="w-full p-0">
                      <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal" icon="IP-information-button" active="true">
                        NOTE: This questionnaire should be filled out completely and
                        accurately. Kindly read the instructions carefully.
                      </vs-alert>
                    </vs-col>
                    <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12">
                      <div class="form-container pt-10 form-container-questionnaire">
                        <casedocumentslist @emitUploadingAction="emitUploadingAction" :docMainCategory="'bendocslist'" :docslist="bendocslist" :petition="petition" :formscope="'documentsform'" :fieldsArray="questionnaireDetails" v-model="petition.documents" :tplsection="'documents'"  :fieldName="''" ></casedocumentslist>
                         </div>
                    </vs-col>
                    <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12">
                      <div class="form-container pt-10 form-container-questionnaire">
                        <casedocumentslist @emitUploadingAction="emitUploadingAction"  :docMainCategory="'spouseDocsList'" :docslist="spouseDocsList" :petition="petition" :formscope="'documentsform'" :fieldsArray="questionnaireDetails" v-model="petition.dependentsInfo.spouse.documents" :tplsection="'dependentsInfo.spouse.documents'"  :fieldName="'dependentsInfo-spouse-documents'" :title="'List of Spouse documents needs to be updated'"></casedocumentslist>
                      </div>
                    </vs-col>

                  </form>
                </div>
              </div>
            </div>
            <div class="questionnaire_footer">
              <div class="d-flex">
                <vs-button v-if="checkActiveTab == 1"   @click="goBack()" class="questionnaire_btn"
                  type="filled">Back</vs-button>
              </div>
              <div class="d-flex">
                <vs-button  :disabled="documentUploading" @click="saveCase(true, true, false);" class="questionnaire_btn" type="filled">Save</vs-button>
                <vs-button  :disabled="documentUploading" color="success" @click="submitCase();" class="save questionnaire_btn" type="filled">{{
                  actiontype
                }}</vs-button>
  
              </div>
            </div>
          </div>
        </div>
        <div class="custom_modal_sec preview_questionarie" :class="{ modalopen: questionnairePreview }">
          <div class="custom_modal_overlay"></div>
  
          <div class="custom_modal_cnt">
            <div class="modal_title">
              <h2>Questionnaire Review</h2>
              <span @click="questionnairePreview = false">
                <x-icon size="1.5x" class="close"></x-icon>
              </span>
            </div>
            <div class="modal_cnt preview_content new_questionnaire_review">
              <VuePerfectScrollbar ref="mainSidebarPs1" :settings="settings">
                <PetitionDetails v-if="questionnairePreview" :loadedFromPreview="true" :fieldsArrayDetails="questionnaireDetails" :previewData="questionnairePreviewData" />
              </VuePerfectScrollbar>
            </div>
            <div class="questionnaire_footer">
              <div class="d-flex">
                <vs-button @click="questionnaireLoader=false;questionnairePreview = false" class="cancel questionnaire_btn" type="filled">Cancel
                </vs-button>
                <vs-button @click="tempSave =false;showMessage = false; toggleBenProfileCOnformPopUp(true)" :disabled="questionnaireLoader"
                  class="save questionnaire_btn" type="filled">
                  <figure v-if="questionnaireLoader" class="loader loader-btn"><img src="@/assets/images/main/loader.gif" />
                  </figure>
                  Submit
                </vs-button>
              </div>
            </div>
          </div>
        </div>
  
        <vs-popup class="holamundo success-popups" title="Your registration is complete."
          :active.sync="SuccessQuestionnaire">
          <figure>
            <img src="@/assets/images/main/icon-note.svg" alt="login" class="mx-auto" />
          </figure>
          <h2 class="title">Questionnaire submitted successfully!</h2>
          <template v-if="checkProperty($route, 'name') != 'fill-cap-registration'">
            <p v-if="getUserData && checkProperty(getUserData['tenantDetails']['typeDetails'], 'id') == 1">
              It will be reviewed by the petitioner and appropriate actions will be
              taken soon.
            </p>
            <p v-if="getUserData && checkProperty(getUserData['tenantDetails']['typeDetails'], 'id') == 2">
              It will be reviewed by the Admin and appropriate actions will be
              taken soon.
            </p>
          </template>
        </vs-popup>
        <vs-popup class="holamundo main-popup cls-btn" title="Case Details" :active.sync="showPrefillPopup">
            <div class="form-container"> 
                <div class="vx-row">
                    <div class="vx-col w-full" v-if="beneFiciaryDeytailsExists">
                        <p style="line-height: 20px">
                            Do you want to pre-fill the basic information from the Beneficiary Profile?
                        </p>
                    </div>
                    <div class="vx-col w-full" v-else>
                        <p style="line-height: 20px">
                            Do you want to pre-fill the basic information from the previous
                            case details?
                        </p>
                    </div>
                </div>
            </div>
            <div class="popup-footer">
                <vs-button color="dark" class="cancel" type="filled" @click="setBasicData();showPrefillPopup = false">Cancel</vs-button>
                <vs-button color="success" class="save" type="filled" @click="
                prefilltheDetails();prefillAction = true;
                showPrefillPopup = false;
              ">Yes</vs-button>
            </div>
        </vs-popup>
        <vs-popup class="holamundo main-popup cls-btn" title="Confirmation" :active.sync="showBenProfileSyncPopup">
            <div class="form-container">
                <div class="vx-row">
                    <div class="vx-col w-full">
                        <p style="line-height: 20px">
                            Do you want to update the Beneficiary Profile with the new/change information entered in this case?
                        </p>
                    </div>
                </div>
            </div>
            <div class="popup-footer">
                <vs-button color="dark" class="cancel" type="filled" @click="conformBenProfile(false)">Cancel</vs-button>
                <vs-button @click="conformBenProfile(true);" class="save questionnaire_btn" type="filled">Yes </vs-button>
            </div>
        </vs-popup>
      </div>
    </span>
  </template>
  
  <script>
  //import petitionform from "./forms/petition.vue";
  //import petitionform from "./forms/case.vue";
  //import gcform from "./forms/gcform.vue";
  import { XIcon } from "vue-feather-icons";
  import VuePerfectScrollbar from "vue-perfect-scrollbar";
  import JQuery from 'jquery';
  import PetitionDetails from "@/views/PetitionDetails.vue";
  import moment from "moment";
  import immiswitchyesno from "@/views/forms/fields/switchyesno.vue";
  import educationsList from "@/views/forms/fields/educationsList.vue";
  import immieducations from "@/views/forms/fields/educations.vue";
  import immipriorstay from "@/views/forms/fields/priorstay.vue";
  import immiyesorno from "@/views/forms/fields/yesorno.vue";
  import addressField from "@/views/forms/fields/address.vue";
  import immiMask from "@/views/forms/fields/maskinput.vue";
  import selectField from "@/views/forms/fields/simpleselect.vue";
  import datepickerField from "@/views/forms/fields/datepicker.vue";
  import immiPhone from "@/views/forms/fields/phonenumber.vue";
  import immiInput from "@/views/forms/fields/simpleinput.vue";
  import genderField from '@/views/forms/fields/gender.vue'
  import DatePicker from 'vue2-datepicker';
  import 'vue2-datepicker/index.css';
  import PhoneMaskInput from "vue-phone-mask-input";
  import { TheMask } from 'vue-the-mask';
  import casedocumentslist from "@/views/common/casedocuments.vue";
  import { InfoIcon } from "vue-feather-icons";
    import { EyeIcon } from "vue-feather-icons";
  export default {
    provide() {
      return {
        parentValidator: this.$validator,
      };
    },
    components: {
      InfoIcon,
      EyeIcon,
      casedocumentslist,
      VuePerfectScrollbar,
      XIcon,
      PetitionDetails,
      immiswitchyesno,
      educationsList,
      immieducations,
      immipriorstay,
      immiyesorno,
      addressField,
      immiMask,
      selectField,
      datepickerField,
      immiPhone,
      immiInput,
      DatePicker,
      PhoneMaskInput,
      TheMask,
      genderField,
    },
    data: function () {
      return {
        showBenProfileSyncPopup:false,
        tempSave:false,
        showMessage:true,
        benProfileDetails:null,
        beneFiciaryDeytailsExists:false,
        usastates: [],
        documentUploading:false,
        bendocslist:[
        {
          required: false,
          fileUploading:false,
          key:'proofOfCurrentStatus',
          fieldName:"proofOfCurrentStatus",
          label:'Proof Of Current Status'
        },
        {
          required: false,
          fileUploading:false,
          key:'copyOfExistingVisa',
          fieldName:"copyOfExistingVisa",
          label:'Copy Of Existing visa'
        },
        {
          required: false,
          fileUploading:false,
          key:'approvalCopyOfi140',
          label:'Approval Copy Of I-140',
          fieldName:"approvalCopyOfi140",
        },
          {
            required: false,
            fileUploading:false,
            key: 'priorH4Approvals',
            fieldName: 'priorH4Approvals',
            label: 'All prior H4 approvals, if any'
          }, 
          {
            required: false,
            fileUploading:false,
            key: 'passport',
            fieldName: 'passport',
            label: 'Passport- First page with photo and last page with address'
          },  
          {
            required: false,
            fileUploading:false,
            key: 'usVisa',
            fieldName: 'usVisa',
            label: 'US Visa'
          },   
          {
            required: false,
            fileUploading:false,
            key: 'mostRecentI94',
            fieldName: 'mostRecentI94',
            label: 'Most recent I-94'
          },  
          {
            required: false,
            fileUploading:false,
            key: 'ssnCard',
            fieldName: 'ssnCard',
            label: 'SSN Card, if any'
          }, 
         
          {
            required: false,
            fileUploading:false,
            key: 'eadCard',
            fieldName: 'eadCard',
            label: 'Prior EAD Cards, if any '
          }, 
          
          {
            required: false,
            fileUploading:false,
            key: 'marriageCertificate',
            fieldName: 'marriageCertificate',
            label: 'Marriage Certificate'
          },
          {
              required: false,
              key: 'other',
              fieldName: 'other',
              label: 'Others'
          }   
        ],
        spouseDocsList:[
          {
            required: false,
            fileUploading:false,
            key: 'approvedI140',
            fieldName: 'approvedI140',
            cid: 'spouse_approvedI140',
            label: 'Approved I-140 or Pending Perm for more than 365 days'
          }, 
          {
            required: false,
            fileUploading:false,
            key: 'h1Bapprovals',
            fieldName: 'h1Bapprovals',
            cid: 'spouse_h1Bapprovals',
            label: 'All H-1B approvals, all the way to CAP '
          }, 
          {
            required: false,
            fileUploading:false,
            key: 'passport',
            fieldName: 'passport',
            cid: 'spouse_passport',
            label: 'Passport'
          }, 
          {
            required: false,
            fileUploading:false,
            key: 'usVisa',
            cid: 'spouse_usVisa',
            fieldName: 'usVisa',
            label: 'US Visa'
          },  
           
          {
            required: false,
            fileUploading:false,
            key: 'mostRecentI94',
            cid: 'spouse_mostRecentI94',
            fieldName: 'mostRecentI94',
            label: 'Most recent I-94'
          },  
          {
            required: false,
            fileUploading:false,
            key: 'travelHistory',
            cid: 'spouse_travelHistory',
            fieldName: 'travelHistory',
            label: 'Travel History'
          },  
          {
            required: false,
            fileUploading:false,
            key: 'mostRecentPayStubs',
            cid: 'spouse_mostRecentPayStubs',
            fieldName: 'mostRecentPayStubs',
            label: '3 most recent pay stubs '
          },
          // {
          //   required: false,
          //   fileUploading:false,
          //   key: 'mostRecentPayStubs',
          //   fieldName: 'mostRecentPayStubs',
          //   label: '3 most recent pay stubs '
          // }, 
          {
              required: false,
              key: 'other',
              cid:'spouse_other',
              fieldName: 'other',
              label: 'Others'
          } 
        ],
        questionnaireLoader: false,
        petitionLoaded: false,
        settings: {},
        SuccessQuestionnaire: false,
        showPrefillPopup: false,
        petition: null,
        featureDates: null,
        startEligibleDate: new Date().setFullYear(new Date().getFullYear() - 18),
        bfeprovinceStates: [],
        countries: [],
        countriesWithoutUS:[],
        marital_statuses:[],
        questionnaireDetails: null,
        petitionId: "",
        userName: "",
        typeName: "",
        subTypeName: "",
        temp_save: false,
        action: "", // BENEFICIARY_INFO_UPDATE /
        questionnaireFilled: true,// Set true when submit questionnaire
        questionnaireUpdate: true, // Set true when you are updating questionnaire
        visastatuses: [],
        ignoreItems:['countryOfBirth','countryOfBirthDetails','passportIssuedCountryDetails','passportIssuedCountry','maritalStatusDetails','maritalStatus','stateDetailsOfLastEntryInUS','stateOfLastEntryInUS',
        'curNonImmigrantVisaStatusDetails','curNonImmigrantVisaStatus','homePhoneCountryCode','homePhoneNumber','cellPhoneNumber','cellPhoneCountryCode','mailingAddressIsSameAsAddress'],
        detailsItemsList:[
          {
            key:'countryOfBirth',
            detailsKey:'countryOfBirthDetails',
            section:'beneficiaryInfo',
            type:'details'
          },
          {
            key:'passportIssuedCountry',
            detailsKey:'passportIssuedCountryDetails',
            section:'beneficiaryInfo',
            type:'details'
          },
          {
            key:'maritalStatus',
            detailsKey:'maritalStatusDetails',
            section:'beneficiaryInfo',
            type:'details'
          },
          {
            key:'stateOfLastEntryInUS',
            detailsKey:'stateDetailsOfLastEntryInUS',
            section:'beneficiaryInfo',
            type:'details'
          },
          {
            key:'curNonImmigrantVisaStatus',
            detailsKey:'curNonImmigrantVisaStatusDetails',
            section:'beneficiaryInfo',
            type:'details'
          },
          {
            key:'cellPhoneNumber',
            detailsKey:'cellPhoneCountryCode',
            section:'beneficiaryInfo',
            type:'phone'
          },
          {
            key:'homePhoneNumber',
            detailsKey:'homePhoneCountryCode',
            section:'beneficiaryInfo',
            type:'phone'
          },
        ],
        tempPetition: {
          visaStatusList: [],
          beneficiaryInfo: {
            gender:'',
            firstName: '',
            middleName: '',
            lastName: '',
            currentAddress: {
              line1: null,
              line2: null,
              aptType: null,
              locationId: null,
              locationDetails: null,
              stateId: null,
              stateDetails: null,
              countryId: null,
              countryDetails: null,
              zipcode: null
            },  
            mailingAddressIsSameAsAddress: false,
            address:  {
              line1: null,
              line2: null,
              aptType: null,
              locationId: null,
              locationDetails: null,
              stateId: null,
              stateDetails: null,
              countryId: null,
              countryDetails: null,
              zipcode: null
            },  
            addressOutsideUS:{
              line1: null,
              line2: null,
              aptType: null,
              locationId: null,
              locationDetails: null,
              stateId: null,
              stateDetails: null,
              countryId: null,
              countryDetails: null,
              zipcode: null
            },  
            countryOfBirth: null,
            countryOfBirthDetails:null,
            dateOfBirth: null,
            SSN: '',
            lastArrivalDate: null, 
            I94: '',
            I94ExpiryDate:null,
            passportNumber: '',
            passportIssuedDate: null,
            passportExpiryDate: null,
            stateOfLastEntryInUS: '',
            placeOfLastEntryInUS:'',
            passportIssuedCountry:null,
            passportIssuedCountryDetails:null,
            maritalStatusDetails:null,
            maritalStatus:null,
            stateDetailsOfLastEntryInUS: null,
            curNonImmigrantVisaStatus: null,
            curNonImmigrantVisaStatusDetails: null,
            curVisaExpiryDate: null,
            haveYouEverEmployed: false,
            empInUsIfANumber:'',
            h1bSpouseApprNumber:'',
            cellPhoneNumber: null,
            cellPhoneCountryCode: {
              countryCode: "",
              countryCallingCode: ""
            },
            homePhoneNumber: null,
            homePhoneCountryCode: {
              countryCode: '',
              countryCallingCode: ''
            },
            email: '', 
            
          },
          documents: {
            passport: [],
            usVisa: [],
            mostRecentI94:[],
            ssnCard:[],
            eadCard:[],
            marriageCertificate:[],
            priorH4Approvals:[],
            proofOfCurrentStatus:[],
            copyOfExistingVisa:[],
            approvalCopyOfi140:[],

            other:[]
          },
          dependentsInfo:{
            spouse:{
              documents: {
                passport: [],
                usVisa: [],
                mostRecentI94:[],
                travelHistory:[],
                mostRecentPayStubs:[],
                approvedI140:[],
                h1Bapprovals:[],
                other:[]
              },
            }
          }
        },
        petition: {
          visaStatusList: [],
          beneficiaryInfo: {
            gender:'',
            firstName: '',
            middleName: '',
            lastName: '',
            currentAddress: {
              line1: null,
              line2: null,
              aptType: null,
              locationId: null,
              locationDetails: null,
              stateId: null,
              stateDetails: null,
              countryId: null,
              countryDetails: null,
              zipcode: null
            },  
            mailingAddressIsSameAsAddress: false,
            address:  {
              line1: null,
              line2: null,
              aptType: null,
              locationId: null,
              locationDetails: null,
              stateId: null,
              stateDetails: null,
              countryId: null,
              countryDetails: null,
              zipcode: null
            },  
            addressOutsideUS:{
              line1: null,
              line2: null,
              aptType: null,
              locationId: null,
              locationDetails: null,
              stateId: null,
              stateDetails: null,
              countryId: null,
              countryDetails: null,
              zipcode: null
            },  
            countryOfBirth: null,
            countryOfBirthDetails:null,
            dateOfBirth: null,
            SSN: '',
            lastArrivalDate: null, 
            I94: '',
            I94ExpiryDate:null,
            passportNumber: '',
            passportIssuedDate: null,
            passportExpiryDate: null,
            stateOfLastEntryInUS: '',
            placeOfLastEntryInUS:'',
            passportIssuedCountry:null,
            passportIssuedCountryDetails:null,
            maritalStatusDetails:null,
            maritalStatus:null,
            stateDetailsOfLastEntryInUS: null,
            curNonImmigrantVisaStatus: null,
            curNonImmigrantVisaStatusDetails: null,
            curVisaExpiryDate: null,
            haveYouEverEmployed: false,
            empInUsIfANumber:'',
            h1bSpouseApprNumber:'',
            cellPhoneNumber: null,
            cellPhoneCountryCode: {
              countryCode: "",
              countryCallingCode: ""
            },
            homePhoneNumber: null,
            homePhoneCountryCode: {
              countryCode: '',
              countryCallingCode: ''
            },
            email: '', 
            
          },
          documents: {
            passport: [],
            usVisa: [],
            mostRecentI94:[],
            ssnCard:[],
            eadCard:[],
            marriageCertificate:[],
            priorH4Approvals:[],
            other:[]
          },
          dependentsInfo:{
            spouse:{
              documents: {
                passport: [],
                usVisa: [],
                mostRecentI94:[],
                travelHistory:[],
                mostRecentPayStubs:[],
                approvedI140:[],
                h1Bapprovals:[],
                other:[]
              },
            }
          }
        },
        questionnairePreview: false,
        questionnairePreviewData: null,
        education_types: [],
        showPrefillPopup: false,
        latestPetition: null,
        questionnaireTplType: 'general',
        currentTab: 'casedetails',
        tabslist: [
          {
            key: "casedetails",
            name: "Personal Info"
          },
          {
            key: "documents",
            name: "Documents"
          }
        ],
        tabName: 'PersonalInfo',
        showsideModal: false,
        country: ['India', 'canda'],
        countre: ['India', 'canda'],
        provice: ['Andra pradesh', 'Bihar'],
        citizenship: ['India', 'canda'],
        degree: ['10th / 12th Grade', 'Bachelors', 'Associate', 'Masters'],
        graduation: ['2022', '2021', '2020', '2019'],
        city: ['Hyderabad', 'Khammamm', 'Warangal'],
        state: ['Cokato', 'California', 'Colorado'],
        educationForm: false,
        docsList: [
          {
            display: true,
            required: true,
            key: "passport",
            fieldName: 'passport',
            label: "Passport Copy"
          },
        ],
        eduDocsList: [
          {
            display: true,
            required: false,
            key: "eduTranscripts",
            fieldName: 'eduTranscripts',
            label: "Upload a copy of U.S. Master's Degree Certificate and Transcripts. (Optional)"
          },
        ],
        temporaryDegreeList: [],
      }
    },
    methods: {
      prepopulateQuestionnaire(tplsection='beneficiaryInfo'){
        let questionnaireSection = tplsection;
        if(questionnaireSection == 'beneficiaryInfo' ){
          _.forEach(this.petition[questionnaireSection], (item,key)=>{
            if(this.canRenderField( key, this.questionnaireDetails ,false, questionnaireSection) && this.ignoreItems.indexOf(key)<=-1 && _.has(this.latestPetition, questionnaireSection+'.'+key) ){
              this.petition[questionnaireSection][key] = _.cloneDeep(this.latestPetition[questionnaireSection][key]);
            }
          })
        }
        if(questionnaireSection == 'detailsItemsList' ){
          _.forEach(this.detailsItemsList, (item)=>{
            let tempSection = item['section']
            let tempKey = item['key']
            let tempdetailsKey = item['detailsKey']
            if(this.canRenderField( tempKey, this.questionnaireDetails ,false, tempSection) && _.has(this.latestPetition, tempSection+'.'+tempKey)){
              this.petition[tempSection][tempKey] = this.latestPetition[tempSection][tempKey];
              this.petition[tempSection][tempdetailsKey] = this.latestPetition[tempSection][tempdetailsKey];
            }
          })
        }
        if(questionnaireSection == 'documents'){
          if(questionnaireSection == 'documents'){
            _.forEach(this.petition['documents'], (item,key)=>{
              if(this.canRenderField( key, this.questionnaireDetails ,false, 'documents') && _.has(this.latestPetition, 'documents'+'.'+key)){
                this.petition['documents'][key] = this.latestPetition['documents'][key]; ;
                  
              }
            })
          }
        }
        if(questionnaireSection == 'dependentsInfo.spouse.documents'){
          if(questionnaireSection == 'dependentsInfo.spouse.documents' &&  _.has(this.petition,'dependentsInfo') &&  _.has(this.petition['dependentsInfo'], 'spouse') &&  _.has(this.petition['dependentsInfo']['spouse'],'documents')){
            _.forEach(this.petition['dependentsInfo']['spouse']['documents'], (item,key)=>{
              if(this.canRenderField( key, this.questionnaireDetails ,false,'dependentsInfo.spouse.documents') && _.has(this.latestPetition, 'dependentsInfo.spouse.documents'+'.'+key)){
                this.petition['dependentsInfo']['spouse']['documents'][key] = this.latestPetition['dependentsInfo']['spouse']['documents'][key]; ;
                  
              }
            })
          }
        }
      },
      init() {
        let _self = this;
        this.loadStatesByCountry('bfeprovinceStates', 231);
        this.$store.dispatch("getcountries").then((response) => {
          this.countries = response;
          if(this.checkProperty(this.countries, 'length')>0){
              this.countriesWithoutUS = _.filter(this.countries,(item)=> {
                  return item.id != 231;
              });
          }
        });
        this.$store.dispatch("getmasterdata", "marital_status").then((response) => {
          this.marital_statuses = response;
        });
        this.$store.dispatch("getmasterdata", "visa_status").then((response) => {
          this.visastatuses = response;   
          this.petition.visaStatusList = response;
        });
        this.$store.dispatch("getmasterdata", "education_types").then((response) => {
          this.education_types = response;
        });
  
        this.petitionLoaded = false;
        this.$store.dispatch("getpetition", this.$route.params.itemId)
        .then((response) => {
          if(response && response.data && response.data.result){
              let tempDocs=[];
            _.forEach(this.bendocslist ,(docs)=>{
              tempDocs.push(docs);
            })
            if(this.checkProperty(response['data']['result'], 'questionnaireFilled') && this.checkProperty(this.$route ,'name') =='fill-questionnaire'){
              this.$router.push("/filled-case-details/" + this.$route.params.itemId);
            }
            if(true){
              let tempTabs = [];
              _.forEach(this.tabslist ,(tabItem)=>{
                if(tabItem['key']=='casedetails'){
                  tempTabs.push(tabItem);
                                
              }else{
              tempTabs.push(tabItem);
              }
              });
            }
            this.bendocslist =[];
            this.bendocslist =tempDocs;
            var data = _.merge(this.petition, response.data.result);      
          this.petition = data;
          if(!_.has(this.petition,'passportIssuedCountry')){
            this.petition['passportIssuedCountry'] = null;
            this.petition['passportIssuedCountryDetails'] = null;
          }
          if(!_.has(this.petition,'maritalStatus')){
            this.petition['maritalStatus'] = null;
            this.petition['maritalStatusDetails'] = null;
          }
          this.$store
              .dispatch("commonAction", {
                  data: {
                      questionnaireId: this.petition.questionnaireTplId
                  },
                  path: "/questionnaire/details",
              })
              .then((res) => {
                  let postData = {
                      userId: this.petition.userId,
                      getDocuments: true,
                  };
                  let pth="petition/get-recent-by-beneficiary";
                  pth ="petition-common/get-recent-by-beneficiary";
                  this.$store
                      .dispatch("commonAction", {
                          data: postData,
                          path: pth,
                      })
                      .then((response) => {
                          if (response && response.profileDetails && response.profileDetails.beneficiaryInfo  && this.checkProperty(response['profileDetails'],'beneficiaryInfo','firstName')) {
                              if (!this.petition.questionnaireFilled && (this.petition.beneficiaryInfo.email == null || this.petition.beneficiaryInfo.email == '')) {
                                  this.showPrefillPopup = true;
                              } 
                              this.beneFiciaryDeytailsExists  = true;
                              let tempDetails = response['profileDetails'];
                              this.latestPetition = tempDetails;
                          }
                          else if (response && response.caseDetails && response.caseDetails.beneficiaryInfo) {
                              if (!this.petition.questionnaireFilled && (this.petition.beneficiaryInfo.email == null || this.petition.beneficiaryInfo.email == '')) {
                                  this.showPrefillPopup = true;
                              }
                              this.beneFiciaryDeytailsExists  = false;   
                              let tempDetails = response["caseDetails"];
                              
                              this.latestPetition = tempDetails;
                              
                          }else if (response && response.userDetails && response.userDetails && (!this.petition.questionnaireFilled && (this.petition.beneficiaryInfo.email == null || this.petition.beneficiaryInfo.email == ''))){

                              if(this.checkProperty(response ,'userDetails' ,'email' ) && !this.checkProperty(this.petition ,'beneficiaryInfo' ,'email')){

                              this.petition['beneficiaryInfo']['email'] = this.checkProperty(response ,'userDetails' ,'email' )


                              }
                              if(this.checkProperty(response ,'userDetails' ,'firstName' ) && !this.checkProperty(this.petition ,'beneficiaryInfo' ,'firstName')){
                              this.petition['beneficiaryInfo']['firstName'] = this.checkProperty(response ,'userDetails' ,'firstName' );
                              }
                              if(this.checkProperty(response ,'userDetails' ,'middleName' )  && !this.checkProperty(this.petition ,'beneficiaryInfo' ,'middleName') ){
                                  this.petition['beneficiaryInfo']['firstName'] = this.checkProperty(response ,'userDetails' ,'middleName' );
                              }
                              if(this.checkProperty(response ,'userDetails' ,'lastName' ) && !this.checkProperty(this.petition ,'beneficiaryInfo' ,'lastName') ){
                              this.petition['beneficiaryInfo']['lastName'] = this.checkProperty(response ,'userDetails' ,'lastName' );
                              }
                              this.removeFields()
                          }
                          this.questionnaireDetails = res.fields;
                          this.setTheInitData()
                      });

              })

          }else{
            this.$vs.loading.close();
          }
        })
       
        this.featureDates = new Date();
          setTimeout(()=>{
            this.$store.dispatch("getcountries").then((response) => {
            this.countries = response;
            if(this.checkProperty(this.countries, 'length')>0){
                this.countriesWithoutUS = _.filter(this.countries,(item)=> {
                    return item.id != 231;
                });
            }
          });
          },100)
      },
      validateandScroll() {
        var $self = this;
        const $ = JQuery;
        var el = _.find(this.errors["items"], function (item) {
          return item.scope == $self.currentTab + "form"
        })
        if (el) {
          const ele = $("[name=" + el.field + "]").parents(".vx-col");
          var _top = 0;
          if (ele) {
            _top = ele.position().top;
          }
        }
        document.getElementById("scrollableques").scrollTo({
          top: _top,
          left: 0,
          behavior: 'smooth'
        })
  
      },
      conformBenProfile(conform=false){
            this.toggleBenProfileCOnformPopUp(false);
            this.$vs.loading();
            if(conform){
                this.updateBeneficiaryProfile();
            }
            
            this.saveCase(this.tempSave,this.showMessage);
        },
        toggleBenProfileCOnformPopUp(action=false){
            this.showBenProfileSyncPopup = action;

        },
        updateBeneficiaryProfile(){
          var postpetition = {
            userId: this.checkProperty(this.petition,'userId'),
            currentDate: moment().format("YYYY-MM-DD"),
          };
          if(_.has(this.benProfileDetails,'beneficiaryInfo')){
            postpetition['beneficiaryInfo'] = this.benProfileDetails.beneficiaryInfo;
          }
          if(_.has(this.benProfileDetails,'documents')){
            postpetition['documents'] = this.benProfileDetails.documents;
          }
          if(_.has(this.benProfileDetails,'dependentsInfo') && this.checkProperty(this.benProfileDetails,'dependentsInfo', 'spouse') && this.checkProperty(this.benProfileDetails['dependentsInfo'], 'spouse', 'documents') ){
            postpetition['dependentsInfo'] ={
              spouse:{
                documents:null
              }
            }

            postpetition['dependentsInfo']['spouse']['documents'] = this.checkProperty(this.benProfileDetails['dependentsInfo'], 'spouse', 'documents');
          }
          let path = '/beneficiary-profile/update-beneficiary-profile'
          this.$store.dispatch("commonAction", {data:postpetition,path:path}).then((res)=>{
              this.showBenProfileSyncPopup = false;
          }).catch((err)=>{
              
          })
        },
        questionnairePrefil(tplsection='beneficiaryInfo'){
          this.executionCompleted = false; 
          let questionnaireSection = tplsection;
          if(questionnaireSection == 'beneficiaryInfo' ){
              _.forEach(this.petition[questionnaireSection], (item,key)=>{
                  if(!this.canRenderField( key, this.questionnaireDetails ,false, questionnaireSection) && this.ignoreItems.indexOf(key)<=-1){
                      this.petition[questionnaireSection][key] = _.cloneDeep(this.tempPetition[questionnaireSection][key]);
                      delete this.benProfileDetails[questionnaireSection][key]
                  }
              })
          }
          if(questionnaireSection == 'detailsItemsList' ){
            _.forEach(this.detailsItemsList, (item)=>{
              let tempSection = item['section']
              let tempKey = item['key']
              let tempdetailsKey = item['detailsKey']
              let tempType = item['type']
              if(tempType == 'phone'){
                if(tempSection == 'beneficiaryInfo'){
                  if(!this.canRenderField( tempKey, this.questionnaireDetails ,false, tempSection)){
                    this.petition[tempSection][tempKey] = null;
                    this.petition[tempSection][tempdetailsKey] = {
                        countryCode: '',
                        countryCallingCode: ''
                    };
                    delete this.benProfileDetails[tempSection][tempKey]
                    delete this.benProfileDetails[tempSection][tempdetailsKey]
                  }
                }
              }else{
                if(tempSection == 'beneficiaryInfo'){
                  if(!this.canRenderField( tempKey, this.questionnaireDetails ,false, tempSection)){
                    this.petition[tempSection][tempKey] = null;
                    this.petition[tempSection][tempdetailsKey] = null;
                    delete this.benProfileDetails[tempSection][tempKey]
                    delete this.benProfileDetails[tempSection][tempdetailsKey]
                  }
                }
              }
            })
          }
          if(questionnaireSection == 'documents' || questionnaireSection == 'dependentsInfo.spouse.documents'){
            if(questionnaireSection == 'dependentsInfo.spouse.documents'){
              _.forEach(this.petition['dependentsInfo']['spouse']['documents'], (item,key)=>{
                if(!this.canRenderField( key, this.questionnaireDetails ,false, 'dependentsInfo.spouse.documents')){
                  this.petition['dependentsInfo']['spouse']['documents'][key] = [];
                  delete this.benProfileDetails['dependentsInfo']['spouse']['documents'][key]
                    
                }
              })
            }
            if(questionnaireSection == 'documents'){
              _.forEach(this.petition['documents'], (item,key)=>{
                if(!this.canRenderField( key, this.questionnaireDetails ,false, 'documents')){
                  this.petition['documents'][key] = [];
                  delete this.benProfileDetails['documents'][key]
                    
                }
              })
            }
          }
        },
      submitCase() {
        this.$validator.validateAll(this.currentTab + "form").then((result) => {
          let self =this;
          if (result) {
            if (this.checkActiveTab < this.tabslist.length - 1) {
              this.setActiveTab(this.tabslist[this.checkActiveTab + 1].key);
              setTimeout(function () {
                document.getElementById("scrollableques").scrollTo({
                  top: 0,
                  left: 0,
                  behavior: 'smooth'
                })
              }, 500)
            }
            else {
              if (this.petition.questionnaireFilled) {
                self.tempSave =true;
                self.showMessage = false
                this.benProfileDetails = _.cloneDeep(this.petition);
                this.toggleBenProfileCOnformPopUp(true);
                //this.saveCase(true, false, true);
              } else {
                this.benProfileDetails = _.cloneDeep(this.petition);
                this.callQuestionairePrefill();
                this.setSameaddress(false);
                let temp_save = false;
                this.questionnairePreviewData = {
                  petitionId: this.$route.params.itemId,
                  userName: this.$store.state.user.name,
                  typeName: this.petition.typeDetails.name,
                  subTypeDetails:this.petition.subTypeDetails,
                  typeDetails: this.petition.typeDetails,
                  subTypeDetails: this.petition.subTypeDetails,
                  highestDegreeList: this.petition.highestDegreeList,
                  action: temp_save ? "BENEFICIARY_INFO_UPDATE" : "SUBMIT_BY_BENEFICIARY",
                  currentDate: moment().format("YYYY-MM-DD"),
                  beneficiaryInfo: this.petition.beneficiaryInfo,
                  dependentsInfo: this.petition.dependentsInfo,
                  documents: this.petition.documents,
                  temp_save: false,
                  questionnaireFilled: true,
                  today: moment().format("YYYY-MM-DD"),
                  questionnaireTplType: this.petition.questionnaireTplType,
                };
                this.questionnairePreviewData.noOfDaysStayInUS = this.gettotalDays;
                this.questionnairePreview = true;
              }
  
            }
          }
          else {
            this.validateandScroll();
          }
        })
      },
      saveCase(temp_save, show_message = true, checkMasters) {
        this.setSameaddress(false);
        this.benProfileDetails = _.cloneDeep(this.petition);
        this.callQuestionairePrefill();
        var postpetition = {
          petitionId: this.$route.params.itemId,
          userName: this.$store.state.user.name,
          action: temp_save ? "BENEFICIARY_INFO_UPDATE" : "SUBMIT_BY_BENEFICIARY",
          type:this.checkProperty(this.petition,'typeDetails','id'),
          typeName: this.petition.typeDetails.name,
          subType: this.checkProperty(this.petition,'subTypeDetails','id'),
          subTypeName:this.checkProperty(this.petition,'subTypeDetails','name'),
          currentDate: moment().format("YYYY-MM-DD"),
          beneficiaryInfo: this.petition.beneficiaryInfo,
          dependentsInfo: this.petition.dependentsInfo,
          documents: this.petition.documents,
          temp_save: temp_save,
          questionnaireFilled: temp_save ? false : true,
          today: moment().format("YYYY-MM-DD"),
        };
        if (this.checkProperty(this.petition, 'questionnaireFilled')) {
          postpetition['questionnaireUpdate'] = true
        }
        this.$vs.loading();
          if (!this.checkCurrentUrl) {  
            postpetition['submittedWithLink'] = true;
          }
          this.questionnaireLoader = true
          this.$store.dispatch("petitioner/petitionupdate", postpetition)
                    .then((response) => {
                        this.showBenProfileSyncPopup = false;
                        if (this.checkProperty(response, "error")) {
    
                            if (show_message) {
    
                                this.showToster({
                                    message: response.error.message,
                                    isError: true,
                                });
                            } else {
    
                                this.$vs.loading.close();
                            }
    
                        } else {
    
                            this.spouseModalForm = false;
                            this.childModalForm = false;
                            if (show_message) {
                                
                              
                                if (!temp_save) {
                                    this.SuccessQuestionnaire = true;
                                } else {
    
                                    this.showToster({
                                        message: "Questionnaire saved successfully",
                                        isError: false,
                                    });
                                }
    
                            } else {


                                let currentRoute = this.$route;

                                if (  !this.checkCurrentUrl &&   _.get(currentRoute, "name", "") == "fill-questionnaire" &&  _.has(currentRoute, "meta.getTokenFromUrl") &&
                                _.has(currentRoute, "query.token")
                                ) {
                                    let token = _.get(currentRoute, "query.token", "");
                                     let url = "/filled-case-details/" +this.$route.params.itemId + "?token=" + token;
                                //   window.location.href = window.location.origin+'/app'+url

                                    this.showToster({  message: "Questionnaire saved successfully",  isError: false,  });
                                
                                     this.$router.push(url) //petitionId

                                }else if (this.petition.questionnaireFilled) {
                                    this.showToster({ message: "Questionnaire updated successfully",   isError: false,  });

                                    if (this.checkProperty(this.petition, "rfeCase")) {
                                        this.$router.push("/rfe-petition-details/" + this.$route.params.itemId);
                                   } else {
                                      this.$router.push("/petition-details/" + this.$route.params.itemId);
                                    }
    
                                } else {
                                    
    
                                    if (!temp_save) {
                              
                                        this.questionnairePreview = false;
                                        this.$vs.loading.close();
                                        this.SuccessQuestionnaire = true;
                                        document.addEventListener("click", this.reloadthePage);
    
                                    } else {
                                        
                                        this.questionnairePreview = false;
                                       this.showToster({ message: "Questionnaire updated successfully",   isError: false,  });
                                        this.$vs.loading.close();

                                        if (this.checkProperty(this.petition, "rfeCase")) {
                                            this.$router.push("/rfe-petition-details/" + this.$route.params.itemId);
                                        } else {
                                            this.$router.push("/petition-details/" + this.$route.params.itemId);
                                        }
                                    }
    
                                }
    
                            }
                        }
    
                        this.$vs.loading.close();
    
                }).catch((err) => {
              this.$vs.loading.close();
              this.questionnaireLoader = false;
              this.showToster({ message: err, isError: true, });
            })
     
      },
      callQuestionairePrefill(){
        this.questionnairePrefil('beneficiaryInfo');
        this.questionnairePrefil('documents');
        this.questionnairePrefil('dependentsInfo.spouse.documents');
      },
      reloadthePage() {
        let routeTest = this.$route.params.itemId;
        var _self = this;
        if (this.SuccessQuestionnaire) {
          this.SuccessQuestionnaire = false;
        }
        setTimeout(() => {
                    let currentRoute = _self.$route;
    
                    if (
                        _.get(currentRoute, "name", "") == "fill-questionnaire" &&
                        _.has(currentRoute, "meta.getTokenFromUrl") &&
                        _.has(currentRoute, "query.token")
                    ) {
                        let token = _.get(currentRoute, "query.token", "");
                        let url = "/filled-case-details/" + routeTest + "?token=" + token;
                        //   window.location.href = window.location.origin+'/app'+url
                        _self.$router.push(url);
                    } else {
                        if (_self.checkProperty(_self.petition, "rfeCase")) {
                            _self.$router.push("/rfe-petition-details/" + routeTest);
                        } else {
                            _self.$router.push("/petition-details/" + routeTest);
                        }
                    }
                }, 10);
      },
      prefilltheDetails() {
        // let tempPetition = _.cloneDeep(this.latestPetition);
        // var data = _.merge(this.petition, tempPetition);
        // this.petition = data;
        this.prepopulateQuestionnaire();
        this.prepopulateQuestionnaire('detailsItemsList');
        this.prepopulateQuestionnaire('documents');
        this.prepopulateQuestionnaire('dependentsInfo.spouse.documents');
        this.setTheInitData()
      },
      setBasicData() {
        if (this.checkProperty(this.latestPetition, 'beneficiaryInfo', 'email')) {
          this.petition['beneficiaryInfo']['email'] = this.checkProperty(this.latestPetition, 'beneficiaryInfo', 'email')
        }
        if (this.checkProperty(this.latestPetition, 'beneficiaryInfo', 'firstName')) {
          this.petition['beneficiaryInfo']['firstName'] = this.checkProperty(this.latestPetition, 'beneficiaryInfo', 'firstName');
        }
        if (this.checkProperty(this.latestPetition, 'beneficiaryInfo', 'middleName')) {
          this.petition['beneficiaryInfo']['middleName'] = this.checkProperty(this.latestPetition, 'beneficiaryInfo', 'middleName');
        }
        if (this.checkProperty(this.latestPetition, 'beneficiaryInfo', 'lastName')) {
          this.petition['beneficiaryInfo']['lastName'] = this.checkProperty(this.latestPetition, 'beneficiaryInfo', 'lastName');
        }
  
        this.petition['beneficiaryInfo']['homePhoneCountryCode'] = {
          "countryCode": "US",
          "countryCallingCode": "1"
        }
        this.petition['beneficiaryInfo']['cellPhoneCountryCode'] = {
          "countryCode": "US",
          "countryCallingCode": "1"
        }
        this.docsList[0]['required'] = this.checkSLGAndRenderField
      },
      setTheInitData() {
        if (this.checkProperty(this.petition, 'beneficiaryInfo', 'countryOfBirthDetails') && this.checkProperty(this.petition, 'beneficiaryInfo', 'countryOfBirth') != null) {
          this.loadStatesByCountry('bfeprovinceStates', this.petition.beneficiaryInfo.countryOfBirth)
        }
        let provinceOfBirth = this.checkProperty(this.petition, 'beneficiaryInfo', 'provinceOfBirth');
        if (provinceOfBirth != null) {
          let provinceOfBirthDetails = _.find(this.bfeprovinceStates, function (item) { return item.id == provinceOfBirth })
          if (provinceOfBirthDetails) {
            this.petition.beneficiaryInfo.provinceOfBirthDetails = provinceOfBirthDetails;
          }
        }
        let curNonImmigrantVisaStatus = this.checkProperty(this.petition, 'beneficiaryInfo', 'curNonImmigrantVisaStatus');
        if (curNonImmigrantVisaStatus != null) {
          this.petition.beneficiaryInfo.curNonImmigrantVisaStatusDetails = _.find(this.petition.visaStatusList, function (item) {
  
            return item.id == curNonImmigrantVisaStatus
          })
        }
        this.featureDates = new Date();
        var $self = this;
        this.$vs.loading.close();
      },
      changeBfProvince(value) {
        this.petition.beneficiaryInfo.countryOfBirth = this.petition.beneficiaryInfo.countryOfBirthDetails.id;
        // this.bfeprovinceStates = [];
        // this.loadStatesByCountry('bfeprovinceStates', value.id)
      },
      loadStatesByCountry(model, countryId) {
        this.$store.dispatch("getstates", countryId).then((response) => {
          switch (model) {
            case "bfeprovinceStates":
              this.bfeprovinceStates = response;
            break;
            case "usastates":
              this.usastates = response;
            break;
          }
        });
      },
      setSameaddress(callFromCheckBox = true) {
        if (this.petition.beneficiaryInfo.mailingAddressIsSameAsAddress) {
          this.petition.beneficiaryInfo['currentAddress'] = _.cloneDeep(this.petition.beneficiaryInfo['address']);
        } else {
          if (callFromCheckBox) {
            this.petition.beneficiaryInfo['currentAddress'] = {
              line1: null,
              line2: null,
              aptType: null,
              locationId: null,
              locationDetails: null,
              stateId: null,
              stateDetails: null,
              countryId: null,
              countryDetails: null,
              zipcode: null
            }
          }
        }
      },
      goBack() {
        this.setActiveTab(this.tabslist[this.checkActiveTab - 1].key)
      },
      updatecellPhoneCountryCode(data) {
        this.petition.beneficiaryInfo.cellPhoneCountryCode = data
      },
      updatehomePhoneCountryCode(data){
        this.petition.beneficiaryInfo.homePhoneCountryCode = data;     
      },
      setActiveTab(item, validate = false) {
        if (validate) {
          this.$validator.validateAll(this.currentTab + "form").then((result) => {
            if (result) {
              this.currentTab = item;
              document.getElementById("scrollableques").scrollTo({
                top: 0,
                left: 0,
                behavior: 'smooth'
              })
            } else {
              this.validateandScroll()
            }
          })
        } else {
          this.currentTab = item;
          setTimeout(function () {
            document.getElementById("scrollableques").scrollTo({
              top: 0,
              left: 0,
              behavior: 'smooth'
            })
          }, 500)
        }
  
      },
      lastNameToUpperCase(val) {
        if (val) {
          this.petition.beneficiaryInfo.lastName = val.toUpperCase();
        }
      },
      checkEducationDocuments(petitionDetails) {
        let returnValue = true
        if (this.checkProperty(petitionDetails['beneficiaryInfo'], 'educations')
          && this.checkProperty(petitionDetails['beneficiaryInfo'], 'educations', 'length') > 0) {
          let educationsList = this.checkProperty(petitionDetails['beneficiaryInfo'], 'educations')
          _.forEach(educationsList, (edu) => {
            let graduationCertificate = this.checkProperty(edu, 'documents', 'graduationCertificate')
            let transcripts = this.checkProperty(edu, 'documents', 'transcripts')
            if (!graduationCertificate || !transcripts) {
              returnValue = false;
            } else if (graduationCertificate && graduationCertificate.length == 0) {
              returnValue = false;
            } else if (transcripts && transcripts.length == 0) {
              returnValue = false;
            }
          })
        }
  
        return returnValue
      },
      checkMasterDegreeCountry(petitionDetails) {
        let returnValue = true
        if (this.checkProperty(petitionDetails['beneficiaryInfo'], 'educations')
          && this.checkProperty(petitionDetails['beneficiaryInfo'], 'educations', 'length') > 0) {
          let educationsList = this.checkProperty(petitionDetails['beneficiaryInfo'], 'educations')
          _.forEach(educationsList, (edu) => {
            if (this.checkProperty(edu, 'highestDegree') && this.checkProperty(edu, 'highestDegree') == 6
              && this.petition.beneficiaryInfo.reqConsdnOfAdvDegreeExptn == true
              && this.checkProperty(edu, 'address', 'countryId') != 231) {
              returnValue = false
            }
          })
        }
        return returnValue
      },
      getHighestDegree(val) {
        if (val) {
          this.petition['beneficiaryInfo']['highestDegree'] = val.id
        }
      },
      checkMasterDegreeYesorNo() {
        if (!this.checkSLGAndRenderField) {
          if (this.petition.beneficiaryInfo.reqConsdnOfAdvDegreeExptn) {
            // let mastedDegree = _.find(this.petition.highestDegreeList, { "id": 6 })
  
            // if (mastedDegree && this.checkProperty(this.petition, 'beneficiaryInfo', 'highestDegree')) {
            //   if (mastedDegree.id < this.petition.beneficiaryInfo['highestDegree']) {
            //     this.petition.beneficiaryInfo['highestDegree'] = 6
            //     this.petition.beneficiaryInfo.highestDegreeDetails = mastedDegree
            //   }
            // }
          } else {
            this.petition['documents']['eduTranscripts'] = [];
            this.petition.beneficiaryInfo.mastersUniversityName = '';
          }
        }
      },
      emitUploadingAction(data){
                if(_.has(data,'docMainCategory')){
                    _.map(this[data['docMainCategory']],(item)=>{
                        if(item['fieldName'] == data['fieldName']){
                            item = Object.assign( item ,{ "fileUploading": false})
                            item['fileUploading'] = data['action'] 
                        }
                    })
                }
                this.checkSubmitBtn(data)
            },
            checkSubmitBtn(data){
                this.documentUploading = false;
                if(_.has(data,'docMainCategory')){
                    _.forEach(this[data['docMainCategory']],(item)=>{
                        if(_.has(item,'fileUploading') && item['fileUploading']){
                            this.documentUploading = true;
                            return false;
                        }
                    })
                }
            },
    },
    beforeDestroy() {
      try {
        const $ = JQuery;
        document.removeEventListener("click", this.reloadthePage);
        $('body').removeClass('questionnairetpl')
      } catch (err) {
      }
    },
    computed: {
      checkEmailRequired(){
        let returnVal = true;
        if(this.checkProperty(this.petition,'tempUser') && this.checkProperty(this.petition,'questionnaireTplType') == 'general' ){
          returnVal = false;
        }
        return returnVal
      },
     
  
      checkActiveTab() {
        return _.findIndex(this.tabslist, { "key": this.currentTab });
      },
      actiontype() {
        if (this.checkActiveTab == (this.tabslist.length - 1)) {
          if (this.petition.questionnaireFilled) {
            return "Update";
          }
          if (!this.petition.questionnaireFilled) {
            return "Review & Submit";
          }
          return "Submit";
        }
        return "Next";
      },
      checkSLGAndRenderField() {
        if (this.checkProperty(this.petition, 'questionnaireTplType')
          && this.petition.questionnaireTplType == 'slg') {
          return true
        }
        return false
      },
  
      checkEduTranscriptsDocumentsRequired() {
        if (!this.checkSLGAndRenderField) {
          if (this.checkProperty(this.petition,'beneficiaryInfo', 'mastersUniversityName')) {
            this.eduDocsList[0]['required'] = false
            return false
          }else{
            this.eduDocsList[0]['required'] = false
            return true
          }
        }
        return true
      }, checkMastersUniversityNameRequired() {
        if (!this.checkSLGAndRenderField) {
          if (this.checkProperty(this.petition, 'documents', 'eduTranscripts')
            && this.petition['documents']['eduTranscripts'].length > 0)
            return false
        }
        return true
      },
  
    },
    mounted() {
  
      // this.masterDegreeList = this.petition.highestDegreeList
      
      const $ = JQuery;
      this.$vs.loading();
      $('body').addClass('questionnairetpl')
      this.init();
      this.loadStatesByCountry('usastates', 231)
  
    }
  };
  </script>