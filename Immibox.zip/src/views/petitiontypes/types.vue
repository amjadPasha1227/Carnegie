<template>
  <div class="settings_right">
    <div class="content-header">
      <div class="content-header-left">
        <div class="search">
          <vs-input icon-pack="feather" icon="icon-search" v-model="searchtxt" placeholder="Search by Name"
            class="is-label-placeholder" />
        </div>
      </div>
      <div class="content-header-right">
        
        
        <vs-button type="border" v-if="[1].indexOf(getUserRoleId)>-1" class="light-blue-btn" @click="createNew(true)">Add New <span>
          <img class="add-user-icon ml-2" src="@/assets/images/main/add-user.svg">
        </span>
        </vs-button>
        
        
      </div>
    </div>
    <NoDataFound ref="NoDataFoundRef" v-if="list.length == 0" :content="''" :heading="callFromSerch?'No Results Found':'No Case Types Found'" type='Case Types' />
   
    <div class="accordian-table" v-if="list.length >0" >
    <template>
      <vs-table :data="list" :no-data-text="'No data found..!'">
        <template slot="thead" v-if="list.length>0">
          <vs-th>
          <a @click="sortMe('name')"  v-bind:class="{'sort_ascending':sortKeys['name']==1, 'sort_descending':sortKeys['name']!=1}" >
             Name
              </a>
          </vs-th>
          <vs-th v-if="[3 ,4].indexOf(getUserRoleId)>-1">
          Custom Code
           </vs-th >
        
          <vs-th class="actions"  >Actions</vs-th>

        </template>

        <template slot-scope="{data}" v-if="list.length>0" >
          <vs-tr  :data="tr" :key="indextr" v-for="(tr, indextr) in data">
            <vs-td :data="tr.username">
            
              
              {{tr['name'] }}
            </vs-td>


            <vs-td v-if="[3 ,4].indexOf(getUserRoleId)>-1">
            
              
              {{checkProperty(tr ,'casenoConfigDetails' ,'code') }}
            </vs-td>
  
           
            <vs-td  >
              
             
              <vs-dropdown class="msg_dropdown_icon" :vs-trigger-click="true">
                  <a class="a-icon" href.prevent><more-vertical-icon size="1.5x" class="custom-class"></more-vertical-icon></a>
                 <vs-dropdown-menu class="loginx msg_dropdown">
                 <!--
                    <vs-dropdown-item>
                      <router-link style="cursor:pionter;padding:3px 10px" :to="'/petition-subtype-list/'+tr.id">Case Subtypes</router-link>
                    </vs-dropdown-item>
                    -->
                    

                    <vs-dropdown-item v-if="[3 ,4].indexOf(getUserRoleId)>-1">

                       <span style="cursor:pionter;padding:3px 10px"   @click="openCaseCodePopup(tr)" >
                       
                       <template v-if="checkProperty(tr ,'casenoConfigDetails' ,'_id')">Edit Case Custom Code</template>
                       <template v-else>Case Custom Code</template>
                       
                       
                       </span>
                    </vs-dropdown-item>

                    
                    <vs-dropdown-item>

                       <span style="cursor:pionter;padding:3px 10px"   @click="$emit('gotoSubType' ,tr)" >Case Subtypes</span>
                    </vs-dropdown-item>

                    <vs-dropdown-item v-if="[1].indexOf(getUserRoleId)>-1" >
                        <span style="cursor:pionter;padding:3px 10px"   @click="editMe(tr)" >Edit</span>
                    </vs-dropdown-item>
                    <template v-if="[3 ].indexOf(getUserRoleId)>-1">
                      <vs-dropdown-item v-if="(checkProperty(tr ,'workflowConfigDetails' ) && tr['workflowConfigDetails'].length<=0)">
                        <a style="cursor:pionter;padding:3px 10px"  href.prevent v-if="[3 ].indexOf(getUserRoleId)>-1" @click="openPetitionConfiguration(tr)"  >Configuration
                          
                        </a>
                      </vs-dropdown-item>
              
                    </template>

                    <template v-if="[1 ].indexOf(getUserRoleId)>-1">
                      <vs-dropdown-item v-if="(checkProperty(tr ,'petitionConfigDetails' ) && tr['petitionConfigDetails'].length<=0)">
                        <a style="cursor:pionter;padding:3px 10px"  href.prevent  @click="openPetitionConfiguration(tr)"  >Configuration
                          
                        </a>
                      </vs-dropdown-item>
                      <vs-dropdown-item  v-if="[1 ].indexOf(getUserRoleId)>-1 && (checkProperty(tr ,'petitionConfigDetails' ) && tr['petitionConfigDetails'].length>0 )">
                        <a style="cursor:pionter;padding:3px 10px"  href.prevent @click="editWorkPetitionConfig(tr ,tr['petitionConfigDetails'][0])"  >Edit Configuration
                          
                        </a>
                      </vs-dropdown-item>
                      
                    </template>

                     
                    
                    
                    
                   </vs-dropdown-menu>
                  
                </vs-dropdown>
              
            </vs-td>
            <!--
              <template class="expand-user" slot="expand">
                <div class="con-expand-users">
                  <div>
                    <vs-table :data="tr.workflowConfigDetails" :no-data-text="'Workflow config list is empty'">
                      <template slot="thead" v-if="tr.workflowConfigDetails.length>0" >
                        <vs-th>Workflow Name</vs-th>
                        <vs-th>Status</vs-th>
                        <vs-th class="actions">Actions</vs-th>
                        
                      </template>
                      <tbody>
                      <template v-if="checkProperty(tr ,'workflowConfigDetails' ) && tr['workflowConfigDetails'].length>0">
                        <vs-tr :key="indx" v-for="(conf, indx) in tr.workflowConfigDetails">
                            <vs-td>{{conf.workflowName}}</vs-td>
                            <vs-td>
                            <span class="statusspan " :class="{'status_pending':!conf.status,'status_active':conf.status}" >
                              {{conf.status?"Active":'Inactive'}}
                              </span>
                            </vs-td>
                            <vs-td class="td_actions">
                              <vs-dropdown class="msg_dropdown_icon" :vs-trigger-click="true">
                                <a class="a-icon" href.prevent><more-vertical-icon size="1.5x" class="custom-class"></more-vertical-icon></a>
                                <vs-dropdown-menu class="loginx msg_dropdown">
                                 <vs-dropdown-item>
                                    <a style="cursor:pionter;padding:3px 10px"  href.prevent v-if="[1 ,2,3 ].indexOf(getUserRoleId)>-1" @click="editWorkflowConfig(tr ,conf)"  >Edit workflow
                                      
                                    </a>
                                  </vs-dropdown-item>
                                </vs-dropdown-menu>
                              </vs-dropdown>  

                            </vs-td>
                            
                        </vs-tr>
                      </template>  
                      </tbody>
                    </vs-table>
                  </div>
                </div>
              </template>      
            -->


          </vs-tr>
        </template>
      </vs-table>
      <div class="table_footer">
        <div class="vx-col  con-select pages_select"  v-if="list.length>0">
          <label class="typo__label">Per Page</label>
          <multiselect @input="changeperPage()" v-model="perpage" :options="perPeges" :multiple="false"
              :close-on-select="true" :clear-on-select="false" :preserve-search="true" placeholder="Per Page"
              :preselect-first="true">
            </multiselect>
            <span class="totla_list_count" v-if="totalCount"> Total <em>{{totalCount}}</em></span>
          </div>
          <paginate  v-if="list.length>0"  v-model="page" :page-count="totalpages" :page-range="3" :margin-pages="2" :click-handler="pageNate"
        prev-class="vs-pagination--buttons btn-prev-pagination vs-pagination--button-prev"
        next-class="vs-pagination--buttons btn-next-pagination vs-pagination--button-next" :prev-text="'<i></i>'"
        :next-text="'<i></i>'" :container-class="'pagination vs-pagination--nav'" :page-class="'page-item'"></paginate>
      </div>
    </template>
     
      
    </div>
    <div>
      <vs-popup class="holamundo main-popup" :title="edit?'Edit Case Type':'New Case Type'" v-if="addPopup" :active.sync="addPopup">
      <form>
        <div class="form-container">
          <div class="vx-row">
            <div class="vx-col w-full">
              <div class="form_group">
                <label class="form_label">Name<em>*</em></label>
                <vs-input @click="formerrors.msg=''" @keyup="formerrors.msg=''" v-model="newform.name"  name="name" v-validate="'required'" class="w-full" data-vv-as="name"    />
                <span class="text-danger text-sm"
                  v-show="errors.has('name')">{{ errors.first("name") }}</span>
              </div>
            </div>  
          </div>
          <div class="text-danger text-sm formerrors" v-show="formerrors.msg" @click="formerrors.msg=''">
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
              icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
          </div>
        </div>
        <div class="popup-footer">
          <vs-button color="dark" @click="edit=false;createNew(false)" class="cancel" type="filled">Cancel</vs-button>
          <vs-button color="success"  :disabled="validateForm" class="save" v-if="edit" @click="updateformandLetter()" type="filled">Update</vs-button>
          <vs-button color="success" :disabled="validateForm" class="save" v-else @click="createformandLetter()" type="filled">Save</vs-button>
        </div>
      </form>
    </vs-popup>
     </div>
     <modal 
     
    name="petition-workflow-configuration" 
    classes="v-modal-sec visible-modal"
    :min-width="200"
    :min-height="200"
    :scrollable="true"
    :reset="true"
    width="500px"
    height="auto">
    <!-- <span class="im_overlay" @click="$modal.hide('petition-workflow-configuration'); configPopup=false;"></span> -->
    <div class="v-modal">
       
      <div class="popup-header">
        <h2 class="popup-title">{{editworkFlowConfigaration?'Update Case Configuration ':'Case Configuration'}}</h2>
        <span @click="$modal.hide('petition-workflow-configuration'); configPopup=false; formSubmited =false;">
          <em class="material-icons">close</em>
        </span>
      </div>
     
       <div   class="form-container"> 
        <div class="vx-row" v-if="[3].indexOf(getUserRoleId)>-1">
          <div class="vx-col w-full">
            <div class="form_group">              
              <div class="con-select w-full">
                <label class="form_label">Workflow</label>
              <multiselect name="Case Configuration"   v-model="selectedWorkFlow" 
                  placeholder="Select Workflow"
                  :multiple="false"
                  :show-labels="false"
                  :ref="'Petition workflow'"
                  track-by="_id" 
                  label="name"
                  data-vv-as="Workflow" 
                  :options="tempworkFlowList"
                  :searchable="true"
                  :allow-empty="false">
              </multiselect>
            </div>
            </div>
          </div>
          
        </div>
        <div class="vx-row" v-if="[1].indexOf(getUserRoleId)>-1">
          <div class="vx-col w-full">
            <div class="form_group">
              
              <div class="con-select w-full">
                <label class="form_label">Questionnaire Template</label>
              <multiselect name="Case Configuration"   v-model="selectedQuestionnaireTemplate" 
                    placeholder="Select Questionnaire"
                    :multiple="false"
                    :show-labels="false"
                    :ref="'questionnaire-templates'"
                    track-by="_id" 
                    label="name"
                    data-vv-as="Workflow" 
                    :options="questionnaireTemplatsList"
                    :searchable="true"
                    :allow-empty="false">
                </multiselect>
              </div>
            </div>
          </div>
        </div>    
          
      </div> 
       <div class="text-danger text-sm formerrors" v-show="formerrors.msg" @click="formerrors.msg=''">
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
              icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
          </div> 
      <div class="popup-footer">
        <vs-button class="cancel" @click="$modal.hide('petition-workflow-configuration');configPopup=false; formSubmited =false;">Cancel</vs-button>
        
        <vs-button v-if="getUserRoleId ==3" class="save" :disabled="selectedWorkFlow ==null || formSubmited" type="filled" @click="workFlowconfigAction()">
          {{editworkFlowConfigaration?'Update':'Save'}}
        </vs-button>
        <vs-button v-if="getUserRoleId ==1" class="save" :disabled="selectedQuestionnaireTemplate ==null || formSubmited" type="filled" @click="petitionConfigAction()">
          {{editpetitionTemplateConfigaration?'Update':'Save'}}
        </vs-button>
      </div>
     
    </div>
    </modal>

    <vs-popup
      class="holamundo main-popup"
      title="Complete Setup"
      v-if="showPetitionAlert"
      :active.sync="showPetitionAlert"
    >
      <div class="form-container">
        <div class="vx-row">
          <div class="vx-col w-full">
            <p>Are you sure of Create new Petetion Configuration?</p>
          </div>
        </div>
      </div>
      <div class="popup-footer">
        <vs-button
          color="dark"
          class="cancel"
          type="filled"
          @click="showPetitionAlert = false ,this.$modal.show('petition-workflow-configuration'); formSubmited =false;"
          >Cancel</vs-button
        >
        <vs-button
          color="success"
          class="save"
          type="filled"
          @click="petitionConfigAction()"
          >Create</vs-button
        >
      </div>
    </vs-popup>


  </div>
</template>

<script>

import NoDataFound from "@/views/common/noData.vue";
import DateRangePicker from "vue2-daterange-picker";
  import Datepicker from "vuejs-datepicker-inv";
  import Paginate from "vuejs-paginate";
  
import "vue2-daterange-picker/dist/vue2-daterange-picker.css";

  import _ from "lodash";
  import { FormWizard, TabContent } from "vue-form-wizard";
  import "vue-form-wizard/dist/vue-form-wizard.min.css";
   import moment from 'moment'
  import PhoneMaskInput from "vue-phone-mask-input";
  import JQuery from 'jquery'
  import { TheMask } from 'vue-the-mask'
  
import FileUpload from "vue-upload-component/src";
import VuePhoneNumberInput from 'vue-phone-number-input';
import 'vue-phone-number-input/dist/vue-phone-number-input.css';
import { MoreVerticalIcon } from 'vue-feather-icons';
  export default {
    computed:{
      validateForm(){
        if(
          (this.newform.name && this.newform.name.trim() !='' ) 
         
        
        ){

          return false;
        }else{
          return true;
        }

      },
      
    },
    components: {
      NoDataFound,
      DateRangePicker,
      VuePhoneNumberInput,
      Datepicker,
      Paginate,
      FileUpload,
      FormWizard,
      TabContent,
      PhoneMaskInput,
      TheMask,
      MoreVerticalIcon
    },

    data: () => ({ 
      formSubmited:false,
      callFromSerch:false,
      selectedQuestionnaireTemplate:null,
      questionnaireTemplatsList:[],
      detailsPopup:false,
      selectedWorkFlow:null,
      configPopup:false,
      workFlowList:[], 
      tempworkFlowList:[],
      petitionWorkFlowConfigDetails:[], 
      
    selected_createdDateRange: ["", ""],
    autoApply: "",
        value:[],
        all_formTypes:[{"name":"Form" ,"id":"Form"},{"name":"Letter" ,"id":"Letter"} ],
        
      selectedItem:null,
      selectedStatus:2,
      actionText:"Do you want to Delete?",
      formerrors: {
        msg: ""
      },
      date: null,
      approveConformpopUp: false,
     
     newform: {name:'' ,type:'' ,"document":null , attachments:[],"today":moment().format("YYYY-MM-DD")},
      list: [],
      addPopup: false,
      NewPetition: false,
      
     
      searchtxt: "",
      query: [],
      country_code: 231,
      all_statusids: [],
      selected_statusids: [],
      final_selected_statusids: [],
      filter_roleIds: [],
      final_filter_roleIds: [1,2,3,4,5,8,9,10,11,12],

      
      seleted_states: [],
      final_selected_states: [],
      locations: [],
      // locationIds
      final_selected_typesids:[],
      selected_typeids:[],
      
      
      date: "",
      date_range: [],
      page: 1,
      perPeges: [10,25,50,75,100],
      perpage: 25,
      totalCount:0,
      totalpages: 0,
      

     
      switch2:true,
      users_status:{},
      edit:false,
      sortKeys:{},
      sortKey:{},
      details:null,
      editworkFlowConfigaration:false,
      workflowConfigId:'',
      editpetitionTemplateConfigaration:false,
      showPetitionAlert:false,

    }),
    watch: {
      searchtxt: function (value) {
        this.getList(true);
      }

    },
    methods: {
      changeperPage(){
        this.page = 1;
        this.getList(true);
      },
      openCaseCodePopup(item){
      
        this.$emit('openCaseCodePopup' ,{"typeData":item,"subTypeData":null})
      },
      //questionnaireTemplatsList
       getQuestionnaireTemplatsList(){
         

   let  postData ={
          "filters":{},
          "getMasterData":true,
          getAll:true,
          "page":1,
          "perpage":25
          ,"sorting":{"path":"createdOn","order":-1}
        }

          this.$store.dispatch("commonAction" ,{ data:postData, path:"/questionnaire/list"})
          .then(response => {
            let tempList =[];
            let lst = response.list;
            _.forEach(lst ,(item)=>{
              
              item = Object.assign(item ,{"showMe":true});
              tempList.push(item);
            });
            this.questionnaireTemplatsList = tempList;
           
           
          })
          .catch((err)=>{
            
          })
      },

      processPetitionTypes(showDetailpopUp=false){
       this.detailsPopup =showDetailpopUp;
        //petitionWorkFlowConfigDetails
       // selectedWorkFlow:null,
       // workFlowList:[], 
       // tempworkFlowList:[],
       let postData = {
          "filters":{
            
            "statusList": [true ],
            "createdByList": [],
            "createdDateRange": [],
            "petitionTypeList": [this.selectedItem['id']],
          },
		
      "page": 1, // Optional when 'getAll' send as 'true'
      "perpage": 250000, // Optional when 'getAll' send as 'true'
      "getAll": true // Send as 'true' to get all list
	     }
       this.$store.dispatch("getList" ,{ data:postData, path:"/workflow/config-list"})
       .then((res)=>{
            
             this.petitionWorkFlowConfigDetails =res.list;
             //this.tempworkFlowList = this.workFlowList;
             if(this.petitionWorkFlowConfigDetails.length>0 && this.workFlowList.length>0) {
              

                this.tempworkFlowList =[];
                _.forEach(this.workFlowList ,(item)=>{
                  let findindex =  _.findIndex(this.petitionWorkFlowConfigDetails  ,{ "workflowId":item['_id']});
                  // alert(findindex + " === "+item.name)
                    if(findindex<=-1){
                        this.tempworkFlowList.push(item);
                    }

                })



             }else{
               this.tempworkFlowList = this.workFlowList;
             }
             
            })
           .catch((err)=>{
             //alert(err)
              
           });

      },
      openPetitionConfiguration(item){
        this.formerrors.msg="";
       this.selectedItem = item;
       this.tempworkFlowList = this.workFlowList;
       this.selectedWorkFlow =null;
       this.workFlowConfigDetails =[];
       this.configPopup =true;
       
       this.editworkFlowConfigaration =false;
       this.editpetitionTemplateConfigaration =false;
       this.workflowConfigId ='';
       this.processPetitionTypes();
       this.$modal.show('petition-workflow-configuration');
        this.formSubmited =false;

      },
       editWorkPetitionConfig(item ,workflowConfigDetails){
            this.formerrors.msg="";
        this.selectedItem = item;
        this.tempworkFlowList = this.workFlowList;
        this.selectedQuestionnaireTemplate =null ;
        this.workFlowConfigDetails =[];
        
        this.processPetitionTypes();
       //questionnaireTemplatsList
        
        if(this.checkProperty(this.selectedItem ,'petitionConfigDetails') && this.selectedItem['petitionConfigDetails'].length>0 ){
         
          if(this.checkProperty(workflowConfigDetails ,'questTplDetails') &&  this.checkProperty(workflowConfigDetails ,'questTplDetails' )){
            this.selectedQuestionnaireTemplate = { "_id": workflowConfigDetails['questTplDetails']['_id'], "name": workflowConfigDetails['questTplDetails']['name'], "showMe": true };
            this.workflowConfigId = workflowConfigDetails['_id']
          }
        }
         this.editpetitionTemplateConfigaration =true;
        this.configPopup =true;
        this.formSubmited =false;
        this.$modal.show('petition-workflow-configuration');
         

      },
      editWorkflowConfig(item ,workflowConfigDetails){
           this.formerrors.msg="";
        this.selectedItem = item;
        this.tempworkFlowList = this.workFlowList;
        this.selectedWorkFlow =null ;
        this.workFlowConfigDetails =[];
        
        this.processPetitionTypes();
       
        
        if(this.checkProperty(this.selectedItem ,'workflowConfigDetails') && this.selectedItem['workflowConfigDetails'].length>0 ){
         
          if(this.checkProperty(workflowConfigDetails ,'workflowId') &&  this.checkProperty(workflowConfigDetails ,'workflowName' )){
            this.selectedWorkFlow = { "_id": workflowConfigDetails['workflowId'], "name": workflowConfigDetails['workflowName'], "showMe": true };
            this.workflowConfigId = workflowConfigDetails['_id']
          }
        }
         this.editworkFlowConfigaration =true;
        this.configPopup =true;
        this.formSubmited =false;
        this.$modal.show('petition-workflow-configuration');

      },

      petitionConfigAction(){
        this.formerrors.msg ='';
         if( (this.selectedQuestionnaireTemplate !=null && this.getUserRoleId ==1 ) ){

          /*
          "typeId": 1,
          "subTypeId": 1,
          "formAndLetterIds": ["61174e22c00cba33b0a712b5"],
          "questionnaireTplId": "611c9e1db49a6e3b68d2ba00", 
          "insertTo": "All", // Tenant // Required for roles 1 and 2
          "tenantIds": ["611a29299e73421e6d7c1943"] // Required for only insertTo is 'Tenant' and for roles 1 and 2
          */
           let postData  = { "typeId": this.selectedItem['id'] ,
           "questionnaireTplId":this.selectedQuestionnaireTemplate['_id'] ,
           "insertTo":'All',
           "formAndLetterIds":[],
           'showPetitionAlert':false
           };
                 
           let actionPath ="/petition-config/create";
           if(this.editpetitionTemplateConfigaration){
             actionPath ="/petition-config/update";
             postData  = Object.assign(postData ,{ "petitionConfigId": this.workflowConfigId});
           /*
             if(this.showPetitionAlert ==false){
               postData['showPetitionAlert'] =true;

             }else{
                postData['showPetitionAlert'] =false;

             }
             */

           }
           
              this.formSubmited =true;
           this.$store.dispatch("commonAction" ,{ data:postData, path:actionPath})
           .then((res)=>{
             this.formSubmited =false;
             //LINKED_WITH_PETITION
             if( _.has(res ,'code') && res['code'] == "LINKED_WITH_PETITION"  && postData['showPetitionAlert'] && false){
                this.$modal.hide('petition-workflow-configuration');
                this.showPetitionAlert =true;

             }else{
                

                this.configPopup =false;
                this.$modal.hide('petition-workflow-configuration');
                this.editpetitionTemplateConfigaration =false;
                this.workflowConfigId ='';
                this.showToster({message:res.message ,isError:false});
                this.selectedQuestionnaireTemplate =null;
                this.workFlowConfigDetails =[];
                this.getList();
               
               

             }

             
             
            })
           .catch((err)=>{
             this.formSubmited =false;
             this.formerrors.msg =err;
              this.showToster({message:err ,isError:true});
               //alert(err)
           });

         }
      },


      workFlowconfigAction(){
         if((this.selectedWorkFlow !=null && this.getUserRoleId ==3 ) || (this.selectedQuestionnaireTemplate !=null && this.getUserRoleId ==1 ) ){
           let postData  = { "petitionTypeId": this.selectedItem['id']  };
           if(this.getUserRoleId ==1){
             postData  =Object.assign(postData , {"questionnaireId":this.selectedQuestionnaireTemplate['_id'] });
           }
           if(this.getUserRoleId ==3){

             postData  =Object.assign(postData , {"workflowId":this.selectedWorkFlow['_id'] });

           }
           let actionPath ="/workflow/config-save";
           if(this.editworkFlowConfigaration){
             actionPath ="/workflow/config-update";
             
             
              if(this.workflowConfigId ){
                postData = Object.assign(postData,{"workflowConfigId":this.workflowConfigId})
              }
        
           }
           this.formSubmited =true;
           this.$store.dispatch("commonAction" ,{ data:postData, path:actionPath})
           .then((res)=>{
             this.configPopup =false;
             this.$modal.hide('petition-workflow-configuration');
             this.editworkFlowConfigaration =false;
             this.workflowConfigId ='';
             this.showToster({message:res.message ,isError:false});
             this.selectedWorkFlow =null;
             this.workFlowConfigDetails =[];
             this.getList();
             this.formSubmited =false;
             
            })
           .catch((err)=>{
             this.formSubmited =false;
              this.showToster({message:err ,isError:true});
               //alert(err)
           });

         }
      },

      getworkFlowList(){
         

   let  postData ={
          "filters":{},
          "getMasterData":true,
          getAll:true,
          "page":1,
          "perpage":25
          ,"sorting":{"path":"createdOn","order":-1}
        }

          this.$store.dispatch("commonAction" ,{ data:postData, path:"/workflow/list"})
          .then(response => {
            let tempList =[];
            let lst = response.list;
            _.forEach(lst ,(item)=>{
              
              item = Object.assign(item ,{"showMe":true});
              tempList.push(item);
            });
            this.workFlowList = tempList;
           //alert(JSON.stringify(tempList) )
           
          })
          .catch((err)=>{
            
          })
      },

      
      changedDocType(){
         this.newform.attachments =[];
         this.newform.document = null;
         if(this.edit  ){
            this.newform.attachments =[this.selectedItem.document];
            this.newform.document = this.selectedItem.document;
         }

      },
       sortMe(sort_key=''){

      
      if(sort_key !=''){
          this.sortKeys[sort_key] = this.sortKeys[sort_key]==1?-1:1
          // this.sortKey[sort_key] = this.sortKeys[sort_key]
          this.sortKey = {"path":sort_key ,"order":this.sortKeys[sort_key]};

          localStorage.setItem('petitiin_sort_key', sort_key);
          localStorage.setItem('formandLetter_sort_value', this.sortKey[sort_key]);
          this.getList();
      }
          
      

      },
      editMe(item){
       
        this.edit =true;
        this.selectedItem = item;
        this.newform = {name:this.selectedItem.name }
        this.addPopup=true;
        this.formerrors.msg='';
        this.$modal.show('create-modal');
       
      },
     
     createNew(action =true){
       this.addPopup=action;
       this.formerrors.msg='';
       if(action){
         this.$modal.show('create-modal');
       }else{
          this.$modal.hide('create-modal');
       }
       this.edit =false;
       this.newform = {name:''}
      
     },
      
      
  
      getList(callFromSerch=false) {
       
        this.callFromSerch = callFromSerch;
        if(this.callFromSerch){
         
          this.list  =[];
        }
        this.updateLoading(true);
        let matcher = {
          title: this.searchtxt,
          statusIds: this.final_selected_statusids,
          typeIds:this.final_selected_typesids,
          createdDateRange:[],
         
          
        };
        if (
        this.selected_createdDateRange["startDate"] &&
        this.selected_createdDateRange["startDate"] != "" &&
        this.selected_createdDateRange["endDate"] != "" &&
        this.selected_createdDateRange["endDate"]
      ) {
        matcher["createdDateRange"] = [
          this.selected_createdDateRange["startDate"],
          this.selected_createdDateRange["endDate"]
        ];
      }

       
         let item ={
          matcher:{
              "searchString":this.searchtxt,
              getWorkFlowConfig:true,
               getCasenoCodeConfig:false
             // "petitionType":

          },   
          page:this.page,
          perpage: this.perpage,
          category: "petition_types",
         sorting: this.sortKey,
          
        };

        if([3 ,4].indexOf(this.getUserRoleId)>-1){
          item['matcher']['getWorkFlowConfig'] =false;
          item['matcher']['getCasenoCodeConfig'] =true;

        }

        this.$store
          .dispatch("getMasterData",item )
          .then(response => {
            this.list = response.list;
            this.totalCount = this.checkProperty(response, 'totalCount');
            this.totalpages = Math.ceil(response.totalCount / this.perpage);
             this.updateLoading(false);
          }).catch(()=>{
             this.list = [];
             this.updateLoading(false);
          })
      },
      updateformandLetter(){
        this.$validator.validateAll().then(result => {
          if (result) {
            let postData ={"name":this.newform.name ,category: "petition_types"}
         
         postData = Object.assign(postData ,{"mDataId":this.selectedItem['id']})
        this.$store.dispatch("updateMasetrRole", postData)
          .then(response => {
           
            this.showToster({message:response.message,isError:false});
            this.getList();
            this.addPopup =false;
            this.edit =false;


          }).catch((error)=>{
                  Object.assign(this.formerrors, {
                    msg:error
                  });
            //this.showToster({message:"Somthin went wrong..!",isError:true});
          
        });
         }
        });

      },
      createformandLetter() {

        
        this.$validator.validateAll().then(result => {
          if (result) {
            let postData ={"name":this.newform.name.trim() , category: "petition_types"}
            this.$store
              .dispatch("createMasterNewRole", postData)
              .then(response => {
                 this.showToster({message:response.message,isError:false });
                 this.getList();
                 this.addPopup =false;
                
              })
              .catch((error)=>{
                Object.assign(this.formerrors, {
                    msg:error
                  });
              })
          }
        });
      },
      upload(files ,type="") {
        let model = _.cloneDeep(files);
        this.value = [];
        let fileType = "Form";
        if(_.has(this.newform['type'] ,"name")){
        
        if(this.newform['type']['name'] =="Form" ){
             fileType = "Form";
        }else if(this.newform['type']['name'] =="Letter" ){
           fileType = "Letter";
        }

      }
      this.newform['document'] =null;
       this.newform['attachments'] = [];

            var _current = this;
            this.$vs.loading();
            let formData = new FormData();
           
            let tempFiles =[]
            if (model.length > 0) {
                
                model.forEach((doc, index) => {
                   
                    if((fileType == "Form" && doc.type=='application/pdf' ) || (fileType == "Letter" && doc.type=='application/msword' ) ){

                    
                    formData.append("files", doc.file);
                    formData.append("secureType", "private");
                    formData.append("getDetails", true);
                                        
                    this.$store.dispatch("uploadLocal", formData).then((response) => {
                        response.data.result.forEach((urlGenerated) => {
                            doc.url = urlGenerated;
                            delete doc.file;
                             let temp_file = urlGenerated;
                             
                           
                          tempFiles.push(temp_file);
                          let fl = { "name":temp_file['name'] ,"url":temp_file['path'] , "mimetype":temp_file['mimetype']} ;
                          this.newform.document =  urlGenerated ;
                          this.newform.attachments.push(fl);
                        
                         
                         if (tempFiles.length >= model.length) {
                              _current.$vs.loading.close();
                          }   
                       
                       });
                    
                    });

                  }else{
                     _current.$vs.loading.close();
                  }
               });
                
               
            }     
              //  model.splice(0, mapper.length, ...mapper);
            
    },
     remove(item, data ,filindex) {
            data.splice(filindex, 1);
            this.newform.document =null;
    
    },  
      
      get_statusids() {
        
        const item ={
          page:1,
          perpage: 10000,
          category: "form_letter_status",
          
        };

        this.$store.dispatch("getMasterData", item).then(response => {
          
          this.all_statusids = response.list;
         // alert(JSON.stringify(response.list))
        });
      },
      
      set_filter: function () {
        this.$refs["filter_menu"].dropdownVisible = false;
       
        this.final_selected_statusids = [];
        if (this.selected_statusids.length > 0) {
          this.final_selected_statusids = [];
          for (let ind = 0; ind < this.selected_statusids.length; ind++) {
            let current_index = this.selected_statusids[ind];
            this.final_selected_statusids.push(current_index["id"]);
          }
        }

        this.final_selected_typesids = [];
        if (this.selected_typeids.length > 0) {
          this.final_selected_typesids = [];
          for (let ind = 0; ind < this.selected_typeids.length; ind++) {
            let current_index = this.selected_typeids[ind];
            this.final_selected_typesids.push(current_index["id"]);
          }
        }

        
// alert(this.final_selected_typesids)
       

       

        this.getList(true);
      },
      clear_filter: function () {
        this.searchtxt ='';
        this.$refs["filter_menu"].dropdownVisible = false;
        
        this.selected_statusids = [];
        this.final_selected_statusids = [];
        this.final_selected_typesids = [];
        this.selected_typeids = [];
      
        this.date = "";
        this.date_range = [];
         this.selected_createdDateRange["startDate"] = "";
         this.selected_createdDateRange["endDate"] = "";
        this.getList();
      },
      pageNate(pageNum) {
        this.page = pageNum;
        this.getList();
      },
      
      
     
    },
    mounted() {
      this.getworkFlowList();
      this.getQuestionnaireTemplatsList();
      this.selected_statusids = [];
      this.final_selected_statusids = [];
      this.seleted_states = [];
      this.final_selected_states = [];
     
 this.sortKeys = {
      'name':1,
      'type':1,
      "createdOn":-1,
      "updatedOn":1
     
    },
     this.sortKey = {"path":'createdOn' ,"order":this.sortKeys['createdOn']};

    this.sortKey = {"path":"createdOn" ,"order":-1};

    if(localStorage.getItem('petitiin_sort_key') && localStorage.getItem('petitiin_sort_value')  && localStorage.getItem('petitiin_sort_value') >=-1 ){
       this.sortKey = {};

      this.sortKey[localStorage.getItem('petitiin_sort_key')] = parseInt(localStorage.getItem('petitiin_sort_value'));
      this.sortKeys[localStorage.getItem('petitiin_sort_key')] = this.sortKey[localStorage.getItem('petitiin_sort_key')];

      //alert();
      

    }
    if(localStorage.getItem('formandLetter_perpage')){
        this.perpage = parseInt(localStorage.getItem('formandLetter_perpage'));
    }
     
      this.get_statusids();
      this.getList();
     

    }
  };
</script>
