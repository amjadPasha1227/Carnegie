<template>
      <div class="settings_right">
      
            <template v-if="selectedSubType && selectedSubType !=null &&  checkProperty(selectedSubType ,'id')">
                <petitionSubTypeList ref="caseTypeList"  @gotoMainType="gotoMainType" :subTypeId="checkProperty(selectedSubType ,'id')"  @openCaseCodePopup="openCaseCodePopup" :caseTypeData="selectedSubType"/>
            </template>
            <template v-else>
                <caseTypes   @gotoSubType="gotoSubType" ref="caseTypeList" @openCaseCodePopup="openCaseCodePopup" />
            </template>


             <vs-popup class="holamundo main-popup casecustomcode" :title="customCodePopupText" v-if="caseCodePopup" :active.sync="caseCodePopup">
      <form  @submit.prevent>
        <div class="form-container" @click="formerrors.msg=''">
          <div class="vx-row">
            <div class="vx-col w-full">
              <div class="form_group">
                <label class="form_label">Custom Code<em>*</em></label>
                <vs-input
                 @click="formerrors.msg=''"
                  @keyup="formerrors.msg=''"
                   v-model="caseCode" 
                    name="caseCode" 
                    v-validate="'required|min:2|max:6'" 
                    class="w-full"
                    data-vv-as="Case Custom Code"   
                    oninput="this.value = this.value.replace(/[^a-z A-Z 0-9 -]/g, '');"
                 />
                <span class="text-danger text-sm"
                  v-show="errors.has('caseCode')">{{ errors.first("caseCode") }}</span>
              </div>
            </div>  
          </div>
          <div class="text-danger text-sm formerrors" v-show="formerrors.msg" >
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
              icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
          </div>
        </div>
        
        
        <div class="popup-footer">
          <vs-button color="dark" @click="isedit=false;openConfigPopup(false)" class="cancel" type="filled">Cancel</vs-button>
          <vs-button color="success"  :disabled="saving" class="save" v-if="isedit" @click="createCaseCode()" type="filled">Update</vs-button>
          <vs-button color="success" :disabled="saving" class="save" v-else @click="createCaseCode()" type="filled">Save</vs-button>
        </div>
      </form>
            </vs-popup>
      </div>
     
    
</template>

<script>
import caseTypes from "@/views/petitiontypes/types.vue"
import petitionSubTypeList from "@/views/petitionSubTypeList.vue"

 export default {
     components: {
         caseTypes,
         petitionSubTypeList

     },
     methods:{
       reloadme(){
         //caseSubTypeList
         try{
          
           this.$refs['caseTypeList'].getList();

         }catch(e){
          

         }

       },
         gotoSubType(item){
             
             this.selectedSubType =item;

         },
          gotoMainType(){
             this.selectedSubType =null;

         },

         openConfigPopup(action =false){
           let self =this;
             this.caseCodePopup =action;
             this.caseCode ='';
              this.saving =false;
              self.isedit =false;
              this.customCodePopupText ="Add Custom Code"
              //isedit?'Edit Custom Code':'Add Custom Code'  customCodePopupText
               if(self.checkProperty(self.typeData ,"id") && self.checkProperty(self.subTypeData ,"id") && self.checkProperty(self.subTypeData ,"casenoConfigDetails" ,"_id")  ){
                  
                 self.isedit =true;
                 self.caseCode = self.checkProperty(self.subTypeData ,"casenoConfigDetails" ,"code")
                  this.customCodePopupText ="Edit Custom Code"
                }else  if(self.checkProperty(self.typeData ,"id") && !self.checkProperty(self.subTypeData ,"id") && self.checkProperty(self.typeData ,"casenoConfigDetails" ,"_id")  ){
                    self.caseCode = self.checkProperty(self.typeData ,"casenoConfigDetails" ,"code")
                    self.isedit =true;
                    this.customCodePopupText ="Edit Custom Code"
                }

                if(self.checkProperty(self.typeData ,"id") && self.checkProperty(self.subTypeData ,"id")){
                  this.customCodePopupText  =this.customCodePopupText+ " "+(self.checkProperty(self.typeData ,"name"))+"/"+(self.checkProperty(self.subTypeData ,"name"))

                }else{
                  this.customCodePopupText  =this.customCodePopupText+ " "+(self.checkProperty(self.typeData ,"name"))

                }
                  
              
               


              Object.assign(this.formerrors, {  msg: ''  });
         },
         createCaseCode(){

            this.$validator.validateAll().then((result) => {
        
              if (result) {
                let self =this;
               
                let postData = {
                "casenoConfigId":null,
                "typeId": self.checkProperty(self.typeData ,"id"),
                "subTypeId": self.checkProperty(self.subTypeData ,"id"), // Required while configure for sub type
                "code": self.caseCode.trim()
                }

                if(self.checkProperty(self.typeData ,"id") && self.checkProperty(self.subTypeData ,"id") && self.checkProperty(self.subTypeData ,"casenoConfigDetails" ,"_id")  ){
                  
                  postData['casenoConfigId'] = self.checkProperty(self.subTypeData ,"casenoConfigDetails" ,"_id")
                }else  if(self.checkProperty(self.typeData ,"id") && !self.checkProperty(self.subTypeData ,"id") && self.checkProperty(self.typeData ,"casenoConfigDetails" ,"_id")  ){
                  
                  postData['casenoConfigId'] = self.checkProperty(self.typeData ,"casenoConfigDetails" ,"_id")
                }

                 this.saving =true

                 let path = "caseno-code-config/create";
                if(self.isedit){
                  path = "/caseno-code-config/update";
                }

                 this.$store.dispatch("commonAction", {"data":postData ,"path":path}).then((response) => {
                this.showToster({message:response.message,isError:false });
               this.openConfigPopup(false)
                this.reloadme();
               


                }).catch((error)=>{
                this.saving =false;
                Object.assign(this.formerrors, {  msg: error,  });

                })

              }
        })

         
         },
         
         openCaseCodePopup(data){
          
            this.typeData = data['typeData'];
            this.subTypeData = data['subTypeData'];
            this.openConfigPopup(true);

         }

     },
     data: () => ({
       customCodePopupText:'Add Custom Code',
         selectedSubType:null,
         formerrors:{msg:''},
         isedit:false,
         caseCode:'',
         caseCodePopup:false,
         saving:false,
         typeData:null,
         subTypeData:null
     })
 }
</script>