<template>
   <div class="main-tabs-content">
      <!-- header area-->
      <div class="tabs-layout-header">
         <div class="case-no-panel">
            <vs-dropdown>
               <a class="flex items-center" href.prevent>
                  <div class="drop-down-content">Case No<span>0508201900003</span></div>
                  <i class="material-icons">arrow_drop_down</i>
               </a>
               <vs-dropdown-menu class="caseno-dropdown">
                  <vs-dropdown-item to="/components/"> 0508201900003 </vs-dropdown-item>
                  <vs-dropdown-item> 0508201900004 </vs-dropdown-item>
                  <vs-dropdown-item> 0508201900005 </vs-dropdown-item>
               </vs-dropdown-menu>
            </vs-dropdown>
         </div>
         <div class="tabs-layout-header-items">
            <div class="items-left">
               <ul class="items-list">
                  <li>Case Type
                     <span>H1B</span>
                  </li>
                  <li>Last Updated
                     <span>05 Aug 2019</span>
                  </li>
                  <li>LCA
                     <span>021598942</span>
                  </li>
               </ul>
            </div>
            <div class="items-right">
               <ul>
                  <!-- <li><span class="status_inProcess">In Progress</span></li> -->
                  <li>
                     <div class="dropdown-button-container">
                        <vs-button class="borderRadius20 status-btn"><span class="status_inProcess">In Progress</span></vs-button>
                     </div>
                  </li>
               </ul>
            </div>
         </div>
      </div>
      <!-- content section start here-->
      <div class="tabs-content">
         <vs-tabs>
            <vs-tab>
               <vs-tabs position="left" color="danger">
                  <!-- Case Details start here -->
                  <vs-tab label="Case Details">
                     <div class="tab-inner-content">
                        <div class="tabs-content-panel tab-pad-wrap">
                           <div class="main-list-wrap">
                              <div class="vx-row m-0 main-list-panel">
                                 <div class="vx-col md:w-1/3 w-full p-0">
                                    <div class="main-list">
                                       <p>Full Name<span>Harry Mason</span></p>
                                    </div>
                                 </div>
                                 <div class="vx-col md:w-1/3 w-full p-0">
                                    <div class="main-list">
                                       <p>Gender<span>Male</span></p>
                                    </div>
                                 </div>
                                 <div class="vx-col md:w-1/3 w-full p-0">
                                    <div class="main-list">
                                       <p>Date of Birth<span>03 - 08 - 1981</span></p>
                                    </div>
                                 </div>
                              </div>
                              <div class="vx-row m-0 main-list-panel">
                                 <div class="vx-col md:w-1/3 w-full p-0">
                                    <div class="main-list">
                                       <p>Highest Degree<span>Masters</span></p>
                                    </div>
                                 </div>
                                 <div class="vx-col md:w-1/3 w-full p-0">
                                    <div class="main-list">
                                       <p>Major Field of Study<span>Finance</span></p>
                                    </div>
                                 </div>
                                 <div class="vx-col md:w-1/3 w-full p-0">
                                    <div class="main-list">
                                       <p>Social Security number<span>123 - 45 - 6789</span></p>
                                    </div>
                                 </div>
                              </div>
                              <div class="vx-row m-0 main-list-panel">
                                 <div class="vx-col md:w-1/3 w-full p-0">
                                    <div class="main-list">
                                       <p>Home Phone Number<span>+1-541-754-3010</span></p>
                                    </div>
                                 </div>
                                 <div class="vx-col md:w-1/3 w-full p-0">
                                    <div class="main-list">
                                       <p>Phone Number<span>+1-124-754-2578</span></p>
                                    </div>
                                 </div>
                                 <div class="vx-col md:w-1/3 w-full p-0">
                                    <div class="main-list">
                                       <p>Fax Number<span>N/A</span></p>
                                    </div>
                                 </div>
                              </div>
                              <div class="vx-row m-0 main-list-panel">
                                 <div class="vx-col md:w-1/3 w-full p-0">
                                    <div class="main-list">
                                       <p>Work Phone Number<span>+1-541-754-3010</span></p>
                                    </div>
                                 </div>
                                 <div class="vx-col md:w-1/3 w-full p-0">
                                    <div class="main-list">
                                       <p>Work Location<span>777 Brockton Avenue, Abington MA 2351</span></p>
                                    </div>
                                 </div>
                              </div>
                              <div class="vx-row m-0 main-list-panel">
                                 <div class="vx-col md:w-1/3 w-full p-0">
                                    <div class="main-list">
                                       <p><span><i class="material-icons check">
                                                check_circle
                                             </i> I am from United States</span>
                                       </p>
                                    </div>
                                 </div>
                                 <div class="vx-col md:w-1/3 w-full p-0">
                                    <div class="main-list">
                                       <p>Address<span>777 Brockton Avenue, Abington MA 2351</span></p>
                                    </div>
                                 </div>
                              </div>
                              <div class="vx-row m-0 main-list-panel">
                                 <div class="vx-col  w-full p-0">
                                    <div class="main-list">
                                       <p>Consulate to notify upon approval of your petition (if outside the
                                          USA)<span>Flat No. 100,
                                             Triveni Apartments, Pitam Pura, NEW DELH,110034, INDIA</span>
                                       </p>
                                    </div>
                                 </div>
                              </div>
                              <div class="vx-row m-0 main-list-panel">
                                 <div class="vx-col  w-full p-0">
                                    <div class="main-list">
                                       <p>As an I-140 immigrant petition been filed on your behalf? Details<span>Lorem
                                             Ipsum, giving
                                             information on its origins, Reference site about as well.</span>
                                       </p>
                                    </div>
                                 </div>
                              </div>
                              <div class="vx-row m-0 main-list-panel">
                                 <div class="vx-col w-full p-0">
                                    <div class="tabs-content-table">
                                       <vs-table :data="users">
                                          <template slot="header">
                                             <h3>
                                                All prior periods of stay in the U.S. over the last seven years
                                             </h3>
                                          </template>
                                          <template slot="thead">
                                             <vs-th>
                                                Date Entered U.S.
                                             </vs-th>
                                             <vs-th>
                                                Date Departed U.S.
                                             </vs-th>
                                             <vs-th>
                                                Case Status
                                             </vs-th>
                                          </template>
                                          <template slot-scope="{data}">
                                             <vs-tr :key="indextr" v-for="(tr, indextr) in data">
                                                <vs-td :data="data[indextr].email">
                                                   {{data[indextr].email}}
                                                </vs-td>
                                                <vs-td :data="data[indextr].username">
                                                   {{data[indextr].name}}
                                                </vs-td>
                                                <vs-td :data="data[indextr].id">
                                                   {{data[indextr].id}}
                                                </vs-td>
                                             </vs-tr>
                                          </template>
                                       </vs-table>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </vs-tab>
                  <!-- Dependents Info start here -->
                  <vs-tab label="Spouse">
                     <div class="tab-inner-content">
                        <div class="tabs-content-panel tab-pad-wrap">
                           <div class="main-list-wrap">
                              <div class="vx-row m-0 main-list-panel">
                                 <div class="vx-col md:w-1/3 w-full p-0">
                                    <div class="main-list">
                                       <p>Name of Spouse<span>Susan Patricia</span></p>
                                    </div>
                                 </div>
                                 <div class="vx-col md:w-1/3 w-full p-0">
                                    <div class="main-list">
                                       <p>Spouse’s date of birth<span>03 - 08 - 1984</span></p>
                                    </div>
                                 </div>
                                 <div class="vx-col md:w-1/3 w-full p-0">
                                    <div class="main-list">
                                       <p>Country of birth<span>India</span></p>
                                    </div>
                                 </div>
                              </div>
                              <div class="vx-row m-0 main-list-panel">
                                 <div class="vx-col md:w-1/3 w-full p-0">
                                    <div class="main-list">
                                       <p>Passport expiry date<span>14 June 2025</span></p>
                                    </div>
                                 </div>
                                 <div class="vx-col md:w-1/3 w-full p-0">
                                    <div class="main-list">
                                       <p>Spouse’s I-94 # (if in the United States)<span>69000888062</span></p>
                                    </div>
                                 </div>
                                 <div class="vx-col md:w-1/3 w-full p-0">
                                    <div class="main-list">
                                       <p>Date case issued (if applicable)<span>24 Aprill 2017</span></p>
                                    </div>
                                 </div>
                              </div>
                              <div class="vx-row m-0 main-list-panel">
                                 <div class="vx-col md:w-1/2 w-full p-0">
                                    <div class="main-list">
                                       <p>Spouse’s current status (if in the United States)<span>n/a</span></p>
                                    </div>
                                 </div>
                                 <div class="vx-col md:w-1/2 w-full p-0">
                                    <div class="main-list">
                                       <p>When does spouse’s status expires (if in the United States)<span>27 August
                                             2019</span></p>
                                    </div>
                                 </div>
                              </div>
                              <div class="vx-row m-0 main-list-panel">
                                 <div class="vx-col md:w-1/2 w-full p-0">
                                    <div class="main-list">
                                       <p>Spouse’s social security # (if in the United States)<span>123 - 45 -
                                             6789</span></p>
                                    </div>
                                 </div>
                                 <div class="vx-col md:w-1/2 w-full p-0">
                                    <div class="main-list">
                                       <p>Date of last arrival (if in the United Sates)<span>17 February 2018</span></p>
                                    </div>
                                 </div>
                              </div>

                              <h3 class="small-header mt-8">Documents</h3>
                              <!-- Form card html-->
                              <div class="card-panels">
                                 <vs-card>
                                    <div slot="header">
                                       <h3>
                                          Case
                                       </h3>
                                    </div>
                                    <div>
                                       <vs-list>
                                          <vs-list-item title="visa.pdf"
                                             subtitle="Last Updated 19 Jul 2019 | By: Supervisor">
                                             <template slot="avatar">
                                                <img src="@/assets/images/main/icon-pdf.svg">
                                             </template>
                                             <div class="vertical-menu">
                                                <i class="material-icons">
                                                   more_vert
                                                </i>
                                             </div>
                                          </vs-list-item>
                                       </vs-list>
                                    </div>
                                 </vs-card>
                                 <vs-card>
                                    <div slot="header">
                                       <h3>
                                          Form I-94
                                       </h3>
                                    </div>
                                    <div>
                                       <vs-list>
                                          <vs-list-item title="Form I-94.pdf"
                                             subtitle="Last Updated 19 Jul 2019 | By: Supervisor">
                                             <template slot="avatar">
                                                <img src="@/assets/images/main/icon-pdf.svg">
                                             </template>
                                             <div class="vertical-menu">
                                                <i class="material-icons">
                                                   more_vert
                                                </i>
                                             </div>
                                          </vs-list-item>
                                       </vs-list>
                                    </div>
                                 </vs-card>
                                 <vs-card>
                                    <div slot="header">
                                       <h3>
                                          Form I-797
                                       </h3>
                                    </div>
                                    <div>
                                       <vs-list>
                                          <vs-list-item title="Form I-797.pdf"
                                             subtitle="Last Updated 19 Jul 2019 | By: Supervisor">
                                             <template slot="avatar">
                                                <img src="@/assets/images/main/icon-pdf.svg">
                                             </template>
                                             <div class="vertical-menu">
                                                <i class="material-icons">
                                                   more_vert
                                                </i>
                                             </div>
                                          </vs-list-item>
                                       </vs-list>
                                    </div>
                                 </vs-card>
                                 <vs-card>
                                    <div slot="header">
                                       <h3>
                                          Marriage Certificate
                                       </h3>
                                    </div>
                                    <div>
                                       <vs-list>
                                          <vs-list-item title="Marriage Certificate.pdf"
                                             subtitle="Last Updated 19 Jul 2019 | By: Supervisor">
                                             <template slot="avatar">
                                                <img src="@/assets/images/main/icon-pdf.svg">
                                             </template>
                                             <div class="vertical-menu">
                                                <i class="material-icons">
                                                   more_vert
                                                </i>
                                             </div>
                                          </vs-list-item>
                                       </vs-list>
                                    </div>
                                 </vs-card>
                                 <vs-card>
                                    <div slot="header">
                                       <h3>
                                          Birth Certificate
                                       </h3>
                                    </div>
                                    <div>
                                       <vs-list>
                                          <vs-list-item title="Birth Certificate.pdf"
                                             subtitle="Last Updated 19 Jul 2019 | By: Supervisor">
                                             <template slot="avatar">
                                                <img src="@/assets/images/main/icon-pdf.svg">
                                             </template>
                                             <div class="vertical-menu">
                                                <i class="material-icons">
                                                   more_vert
                                                </i>
                                             </div>
                                          </vs-list-item>
                                       </vs-list>
                                    </div>
                                 </vs-card>
                              </div>
                           </div>
                        </div>
                     </div>
                  </vs-tab>
                  <!-- Cleint Info start here -->
                  <vs-tab label="Client Info">
                     <div class="tab-inner-content">
                        <div class="tabs-content-panel tab-pad-wrap" style="position: relative">
                           <button class="btn edit-button"><i class="icon IP-pencil-edit-button"></i> Edit</button>
                           <div class="main-list-wrap">
                              <div class="vx-row m-0 main-list-panel">
                                 <div class="vx-col md:w-1/2 w-full p-0">
                                    <div class="main-list">
                                       <p>Name of the Client<span>Wells Fargo India Solutions Private Ltd</span></p>
                                    </div>
                                 </div>
                              </div>
                              <div class="vx-row m-0 main-list-panel">
                                 <div class="vx-col md:w-1/2 w-full p-0">
                                    <div class="main-list">
                                       <p>Current Position<span>UX/UI Designer</span></p>
                                    </div>
                                 </div>
                                 <div class="vx-col md:w-1/2 w-full p-0">
                                    <div class="main-list">
                                       <p>Salary Offered<span>$ 80,000</span></p>
                                    </div>
                                 </div>
                              </div>
                              <div class="vx-row m-0 main-list-panel">
                                 <div class="vx-col md:w-1/2 w-full p-0">
                                    <div class="main-list">
                                       <p>Client Address<span>777 Brockton Avenue, Abington MA 2351</span></p>
                                    </div>
                                 </div>
                                 <div class="vx-col md:w-1/2 w-full p-0">
                                    <div class="main-list">
                                       <p>LCA Number<span>Initiated</span></p>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </vs-tab>
                  <!-- Documents Info start here -->
                  <vs-tab label="Documents">
                     <div class="tab-inner-content">
                        <div class="tabs-content-panel no-border-radius">
                           <vs-row>
                              <vs-col class="w-full p-0">
                                 <vs-alert color="warning" class="warning-alert top-warning-alert no-border-radius"
                                    icon-pack="IntakePortal" icon="IP-information-button" active="true">(File Type: PDF,
                                    DOC, JPEG, PNG. Max file size: 1MB)
                                 </vs-alert>
                              </vs-col>
                              <vs-col>
                                 <div class="card-panels">
                                    <vs-card>
                                       <div slot="header">
                                          <h3>
                                             Resume
                                          </h3>
                                       </div>
                                       <div>
                                          <vs-list>
                                             <vs-list-item title="damian_alexander_updated_cv.pdf"
                                                subtitle="Last Updated 19 Jul 2019 | By: Supervisor">
                                                <template slot="avatar">
                                                   <img src="@/assets/images/main/icon-pdf.svg">
                                                </template>
                                                <div class="vertical-menu">
                                                   <i class="material-icons">
                                                      more_vert
                                                   </i>
                                                </div>
                                             </vs-list-item>
                                          </vs-list>
                                       </div>
                                    </vs-card>
                                    <vs-card>
                                       <div slot="header">
                                          <h3 class="pt-5 pb-5">
                                             Education (Under Gaduate / Graduate Degree(s) along with Transcripts, as
                                             well as any Diploma(s), and Certificates, including Certificates for
                                             Pre-College Education)
                                          </h3>
                                       </div>
                                       <div>


                                          <vs-collapse>

                                             <vs-collapse-item>
                                                <div slot="header">
                                                   <vs-list>
                                                      <vs-list-item title="Graduate.pdf"
                                                         subtitle="Last Updated 19 Jul 2019 | By: Supervisor">
                                                         <template slot="avatar">
                                                            <img src="@/assets/images/main/icon-pdf.svg">
                                                         </template>
                                                      </vs-list-item>
                                                   </vs-list>
                                                </div>
                                                <vs-list>
                                                   <vs-list-item title="Year 1 Transcripts.pdf"
                                                      subtitle="Last Updated 19 Jul 2019 | By: Supervisor">
                                                      <template slot="avatar">
                                                         <img src="@/assets/images/main/icon-pdf.svg">
                                                      </template>
                                                      <div class="vertical-menu">
                                                         <i class="material-icons">
                                                            more_vert
                                                         </i>
                                                      </div>
                                                   </vs-list-item>
                                                   <vs-list-item title="Year 2 Transcripts.pdf"
                                                      subtitle="Last Updated 19 Jul 2019 | By: Supervisor">
                                                      <template slot="avatar">
                                                         <img src="@/assets/images/main/icon-pdf.svg">
                                                      </template>
                                                      <div class="vertical-menu">
                                                         <i class="material-icons">
                                                            more_vert
                                                         </i>
                                                      </div>
                                                   </vs-list-item>
                                                   <vs-list-item title="Year 3 Transcripts.pdf"
                                                      subtitle="Last Updated 19 Jul 2019 | By: Supervisor">
                                                      <template slot="avatar">
                                                         <img src="@/assets/images/main/icon-pdf.svg">
                                                      </template>
                                                      <div class="vertical-menu">
                                                         <i class="material-icons">
                                                            more_vert
                                                         </i>
                                                      </div>
                                                   </vs-list-item>
                                                   <vs-list-item title="Year 4 Transcripts.pdf"
                                                      subtitle="Last Updated 19 Jul 2019 | By: Supervisor">
                                                      <template slot="avatar">
                                                         <img src="@/assets/images/main/icon-pdf.svg">
                                                      </template>
                                                      <div class="vertical-menu">
                                                         <i class="material-icons">
                                                            more_vert
                                                         </i>
                                                      </div>
                                                   </vs-list-item>
                                                </vs-list>
                                             </vs-collapse-item>
                                          </vs-collapse>
                                       </div>
                                    </vs-card>
                                    <vs-card>
                                       <div slot="header">
                                          <h3>
                                             Experience Letters
                                          </h3>
                                       </div>
                                       <div>
                                          <vs-list>
                                             <vs-list-item title="Experience_1.pdf"
                                                subtitle="Last Updated 19 Jul 2019 | By: Supervisor">
                                                <template slot="avatar">
                                                   <img src="@/assets/images/main/icon-pdf.svg">
                                                </template>
                                                <div class="vertical-menu">
                                                   <i class="material-icons">
                                                      more_vert
                                                   </i>
                                                </div>
                                             </vs-list-item>
                                             <vs-list-item title="Experience_2.pdf"
                                                subtitle="Last Updated 19 Jul 2019 | By: Supervisor">
                                                <template slot="avatar">
                                                   <img src="@/assets/images/main/icon-pdf.svg">
                                                </template>
                                                <div class="vertical-menu">
                                                   <i class="material-icons">
                                                      more_vert
                                                   </i>
                                                </div>
                                             </vs-list-item>
                                          </vs-list>
                                       </div>
                                    </vs-card>
                                    <vs-card>
                                       <div slot="header">
                                          <h3>
                                             Prior notice(s) of approval issued by INS
                                          </h3>
                                       </div>
                                       <div>
                                          <vs-list>
                                             <vs-list-item title="Notice_letter_.pdf"
                                                subtitle="Last Updated 19 Jul 2019 | By: Supervisor">
                                                <template slot="avatar">
                                                   <img src="@/assets/images/main/icon-pdf.svg">
                                                </template>
                                                <div class="vertical-menu">
                                                   <i class="material-icons">
                                                      more_vert
                                                   </i>
                                                </div>
                                             </vs-list-item>
                                          </vs-list>
                                       </div>
                                    </vs-card>
                                    <vs-card>
                                       <div slot="header">
                                          <h3 class="pt-5 pb-5">
                                             Passport, along with Case and Form I-94
                                          </h3>
                                       </div>
                                       <div>


                                          <vs-collapse>

                                             <vs-collapse-item>
                                                <div slot="header">
                                                   <vs-list>
                                                      <vs-list-item title="Passport"
                                                         subtitle="Last Updated 19 Jul 2019 | By: Supervisor">
                                                         <template slot="avatar">
                                                            <img src="@/assets/images/main/icon-pdf.svg">
                                                         </template>
                                                      </vs-list-item>
                                                   </vs-list>
                                                </div>
                                                <vs-list>
                                                   <vs-list-item title="Front Page.pdf"
                                                      subtitle="Last Updated 19 Jul 2019 | By: Supervisor">
                                                      <template slot="avatar">
                                                         <img src="@/assets/images/main/icon-pdf.svg">
                                                      </template>
                                                      <div class="vertical-menu">
                                                         <i class="material-icons">
                                                            more_vert
                                                         </i>
                                                      </div>
                                                   </vs-list-item>
                                                   <vs-list-item title="Back Page.pdf"
                                                      subtitle="Last Updated 19 Jul 2019 | By: Supervisor">
                                                      <template slot="avatar">
                                                         <img src="@/assets/images/main/icon-pdf.svg">
                                                      </template>
                                                      <div class="vertical-menu">
                                                         <i class="material-icons">
                                                            more_vert
                                                         </i>
                                                      </div>
                                                   </vs-list-item>
                                                   <vs-list-item title="Visa.pdf"
                                                      subtitle="Last Updated 19 Jul 2019 | By: Supervisor">
                                                      <template slot="avatar">
                                                         <img src="@/assets/images/main/icon-pdf.svg">
                                                      </template>
                                                      <div class="vertical-menu">
                                                         <i class="material-icons">
                                                            more_vert
                                                         </i>
                                                      </div>
                                                   </vs-list-item>
                                                </vs-list>
                                             </vs-collapse-item>
                                             <vs-collapse-item>
                                                <div slot="header">
                                                   <vs-list>
                                                      <vs-list-item title="I-94"
                                                         subtitle="Last Updated 19 Jul 2019 | By: Supervisor">
                                                         <template slot="avatar">
                                                            <img src="@/assets/images/main/icon-pdf.svg">
                                                         </template>
                                                      </vs-list-item>
                                                   </vs-list>
                                                </div>
                                                <vs-list>
                                                   <vs-list-item title="Front Page.pdf"
                                                      subtitle="Last Updated 19 Jul 2019 | By: Supervisor">
                                                      <template slot="avatar">
                                                         <img src="@/assets/images/main/icon-pdf.svg">
                                                      </template>
                                                      <div class="vertical-menu">
                                                         <i class="material-icons">
                                                            more_vert
                                                         </i>
                                                      </div>
                                                   </vs-list-item>
                                                   <vs-list-item title="Back Page.pdf"
                                                      subtitle="Last Updated 19 Jul 2019 | By: Supervisor">
                                                      <template slot="avatar">
                                                         <img src="@/assets/images/main/icon-pdf.svg">
                                                      </template>
                                                      <div class="vertical-menu">
                                                         <i class="material-icons">
                                                            more_vert
                                                         </i>
                                                      </div>
                                                   </vs-list-item>
                                                   <vs-list-item title="Visa.pdf"
                                                      subtitle="Last Updated 19 Jul 2019 | By: Supervisor">
                                                      <template slot="avatar">
                                                         <img src="@/assets/images/main/icon-pdf.svg">
                                                      </template>
                                                      <div class="vertical-menu">
                                                         <i class="material-icons">
                                                            more_vert
                                                         </i>
                                                      </div>
                                                   </vs-list-item>
                                                </vs-list>
                                             </vs-collapse-item>
                                          </vs-collapse>
                                       </div>
                                    </vs-card>
                                    <vs-card>
                                       <div slot="header">
                                          <h3>
                                             Pay Stubs
                                          </h3>
                                       </div>
                                       <div>
                                          <vs-list>
                                             <vs-list-item title="Letter_1.pdf"
                                                subtitle="Last Updated 19 Jul 2019 | By: Supervisor">
                                                <template slot="avatar">
                                                   <img src="@/assets/images/main/icon-pdf.svg">
                                                </template>
                                                <div class="vertical-menu">
                                                   <i class="material-icons">
                                                      more_vert
                                                   </i>
                                                </div>
                                             </vs-list-item>
                                          </vs-list>
                                       </div>
                                    </vs-card>
                                    <vs-card>
                                       <div slot="header">
                                          <h3>
                                             Social Security Card
                                          </h3>
                                       </div>
                                       <div>
                                          <vs-list>
                                             <vs-list-item title="ID.pdf"
                                                subtitle="Last Updated 19 Jul 2019 | By: Supervisor">
                                                <template slot="avatar">
                                                   <img src="@/assets/images/main/icon-pdf.svg">
                                                </template>
                                                <div class="vertical-menu">
                                                   <i class="material-icons">
                                                      more_vert
                                                   </i>
                                                </div>
                                             </vs-list-item>
                                          </vs-list>
                                       </div>
                                    </vs-card>
                                    <vs-card>
                                       <div slot="header">
                                          <h3>
                                             State Professional License
                                          </h3>
                                       </div>
                                       <div>
                                          <vs-list>
                                             <vs-list-item title="License.pdf"
                                                subtitle="Last Updated 19 Jul 2019 | By: Supervisor">
                                                <template slot="avatar">
                                                   <img src="@/assets/images/main/icon-pdf.svg">
                                                </template>
                                                <div class="vertical-menu">
                                                   <i class="material-icons">
                                                      more_vert
                                                   </i>
                                                </div>
                                             </vs-list-item>
                                          </vs-list>
                                       </div>
                                    </vs-card>
                                    <vs-card>
                                       <div slot="header">
                                          <h3 class="pt-5 pb-5">
                                             I –20, if currently on F-1 status, and EAD
                                          </h3>
                                       </div>
                                       <div>


                                          <vs-collapse>

                                             <vs-collapse-item>
                                                <div slot="header">
                                                   <vs-list>
                                                      <vs-list-item title="I –20"
                                                         subtitle="Last Updated 19 Jul 2019 | By: Supervisor">
                                                         <template slot="avatar">
                                                            <img src="@/assets/images/main/icon-pdf.svg">
                                                         </template>
                                                      </vs-list-item>
                                                   </vs-list>
                                                </div>
                                                <vs-list>
                                                   <vs-list-item title="F-1 status.pdf"
                                                      subtitle="Last Updated 19 Jul 2019 | By: Supervisor">
                                                      <template slot="avatar">
                                                         <img src="@/assets/images/main/icon-pdf.svg">
                                                      </template>
                                                      <div class="vertical-menu">
                                                         <i class="material-icons">
                                                            more_vert
                                                         </i>
                                                      </div>
                                                   </vs-list-item>
                                                   <vs-list-item title="EAD.pdf"
                                                      subtitle="Last Updated 19 Jul 2019 | By: Supervisor">
                                                      <template slot="avatar">
                                                         <img src="@/assets/images/main/icon-pdf.svg">
                                                      </template>
                                                      <div class="vertical-menu">
                                                         <i class="material-icons">
                                                            more_vert
                                                         </i>
                                                      </div>
                                                   </vs-list-item>
                                                </vs-list>
                                             </vs-collapse-item>
                                          </vs-collapse>
                                       </div>
                                    </vs-card>

                                 </div>
                              </vs-col>
                           </vs-row>
                        </div>
                     </div>
                  </vs-tab>
               </vs-tabs>
            </vs-tab>
         </vs-tabs>
      </div>
   </div>
</template>
<script>
   export default {
      data: () => ({
         users: [
            {
               "id": "B-1",
               "name": "24 September 2013",
               "email": "12 June 2013",
            },
            {
               "id": "H-1B",
               "name": "08 March 2017",
               "email": "18 January 2014",
            }
         ],
         SubmitParalegal: false,
         SuccessQuestionnaire: false,
      })
   }
</script>