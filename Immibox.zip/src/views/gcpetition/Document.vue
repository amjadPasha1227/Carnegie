<template>
<div class="documents_view_list" v-if="checkEmptyorNullObj(documents) && documents !=null &&  documents.length>0 ">
    <h2>{{title}}</h2>
    <ul>
        <template v-for="(doc, docindx) in documents">
            <li v-if="doc.name !=null && doc.name != '' && doc.url!=null " :key="docindx">
                <p>{{doc.name}}</p>
                <a @click="downloads3file(doc)">Download</a>
            </li>

        </template>

    </ul>
</div>
</template>

<script>
export default {
    props: {
        documents: Array,
        title:String
    },
    created() {
    this.documents = _.filter(this.documents, (e) => { return (e.url !=null &&  e.url !='' )});
    }
}
</script>
