<template>
<vs-card class="no-card">
    <div v-if="pdfformslist.length > 0" class="forms_accordian">
        <vs-list-item class="cards-list-heading">
            <h2>{{title}}</h2>
            <label style="display:none" class="download-all" @click="downloadFormslatters()">
                Download All
                <img src="@/assets/images/main/download.svg" />
            </label>
        </vs-list-item>

        <div v-if="pdfformslist.length > 0">
            <template v-for="(forms, index) in pdfformslist">
                <template>

                    <vs-collapse accordion :key="index" :class="{ 'no-list': forms.list.length > 0}" :not-arrow="forms.list.length == 1" disabled>
                        <vs-collapse-item>
                            <div slot="header" class="ss">
                                <vs-list-item :title="forms.list[0].name" :subtitle="forms.list[0].formType">
                                    <template slot="avatar">
                                        <img src="@/assets/images/main/icon-pdf.svg" />
                                    </template>
                                    <div class="vertical-menu">
                                        <span class="menu-icon">
                                            <i class="material-icons">more_vert</i>
                                        </span>
                                        <ul>
                                            <li v-if="[1,2,4].indexOf(currentRole) >= 0" @click="selDoc($event,forms.list[0])">Upload</li>
                                            <li @click="fetchSignedUrl($event,forms.list[0])">Download</li>
                                        </ul>
                                    </div>
                                </vs-list-item>
                            </div>
                            <template v-if="forms.list.length > 1">
                                <template v-for="(sunform, sindex) in forms.list">

                                    <vs-list-item v-if="sindex != 0" :key="sindex" :title="sunform.name" :subtitle="sunform.formType">
                                        <template slot="avatar">
                                            <img src="@/assets/images/main/icon-pdf.svg" />
                                        </template>

                                        <span class="view_doc" @click="fetchSignedUrl($event,sunform)">Download</span>
                                    </vs-list-item>
                                </template>

                            </template>

                        </vs-collapse-item>
                    </vs-collapse>
                </template>

            </template>

        </div>
    </div>
</vs-card>
</template>

<script>
export default {
    props: {
        pdfformslist: Array,
        currentRole: Number,
        title: {
            type: String,
            default: ''
        }
    },
    methods: {
        selDoc(e, val) {
            this.$emit("uploadVersion", val);
            e.preventDefault();
            e.stopPropagation();
        },
        downloadallGCForms(type) {
            this.$vs.loading();
            let postdata = {
                petitionId: this.petition._id,
                caseNo: this.petition.caseNo
            };
            this.$store.dispatch("downloadgcforms", postdata).then(response => {
                // window.open(response.data.result.path, "_blank");
                window.open(this.$globalgonfig._BASEURL + "/common/viewfile?path=" + response.path, "_blank");
                this.$vs.loading.close();
                // this.generateList();
            });

        },
        fetchSignedUrl(e,value) {
            e.preventDefault();
            e.stopPropagation();
            this.downloads3file(value);
        }
    },
    mounted() {}
}
</script>
