<template>
  <div class="main-list-wrap">
    <div class="communication_list_wrap">
            <div  v-if="commenterror" class="eroormessage">{{commenterror}}</div>

      <div class="communication_input">



  
            <Mentionable
    :keys="['@']"
    :items="userslist"
    offset="6"  @open="getusers()"
    @onselect="selectedUsercallback"
  >
    <textarea  placeholder="@ Send Message" v-model="comment"/>
       
      <template #no-result>
          <div class="no_list">
              No Results found
          </div>
      </template>
      <template  #item-@="{ item }">        
          <div class="mentionList">
            <figure><img class="user-image" src="@/assets/images/main/avatar2.svg"></figure>
            <p>{{ item.name }}<span>{{ item.roleName }} </span></p>
          </div>         
      </template>
       


            <button :disabled="comment==null || comment==''"  @click="submitComment()" class="submit">Submit</button>



  </Mentionable>

    
      </div>

      <div class="communication_list" :key="item"  v-for="item in communicationlist"  >
        <figure>
          <img class="user-image" src="@/assets/images/main/avatar2.svg" />
        </figure>
        <div class="communication_details">
       
          <p>{{item.message}}</p>
          <label> {{item.fromDetails.name}}  - {{item.createdOn  | formatDateTime }}</label>
        </div>
      </div>
    </div>
  </div>
</template>

 
<script>
import Mentionable from "../../components/Mentionable";

export default {
      components: {
    Mentionable,
  },
      data() {
    return {
        communicationlist:[],
      comment:null,
      selecteduser:null,
        userslist:[],
        commenterror:''
    }},
  props: {
    allbtn: false,
    userId:null,
    petition: {
      type: Object,
      default: null
    }
  },
     mounted() {
       
         this.getmessages();
     },
  methods: {
selectedUsercallback(item){
  this.selecteduser = item._id;
               this.commenterror = null;

},
 submitComment(){
   this.commenterror = '';
      let postdata = {
        petitionId: this.petition._id,
        petitionCaseNo:this.petition.caseNo,
        message:this.comment,
        toUserId:this.selecteduser
      };
      // if(!this.selecteduser){
      //   this.commenterror  = 'Please Mention a User using @';
      // }
       if(!this.comment){
        this.commenterror  = 'Please enter your message';
      }
      if(this.commenterror!='') return false;
      this.$store.dispatch("submitcomment", postdata).then(response => {
            this.getmessages();
             this.commenterror = null;
             this.comment=null;
             this.selecteduser=null;
      });

 },
    getusers() {
      let postdata = {
        petitionId: this.petition._id,
        petitionType:"GC"
      };
      this.$store.dispatch("getcommunicationuserslist", postdata).then(response => {

            this.userslist = response;
      });
    },
    getmessages() {
      let postdata = {
        petitionId: this.petition._id,
        page:1,
        perpage:100000
      };
      this.$store.dispatch("getcommunicationbypetition", postdata).then(response => {

            this.communicationlist = response;
      });
    },
    downloadfile(value) {
      value.url = value.url.replace(this.$globalgonfig._S3URL,"");
      value.url = value.url.replace(this.$globalgonfig._S3URLAWS,"");
      let postdata = { keyName: value.url };
      this.$store.dispatch("getSignedUrl", postdata).then(response => {
        window.open(response.data.result.data, "_blank");
      });
    }
  }
};
</script>