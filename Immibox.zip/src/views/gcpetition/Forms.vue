<template>
<div class="tab-inner-content">
    <div class="tabs-content-panel ">
        <div class="gc_details-cnt">
            <div class="gc_details-header">
                <div class="gc_details-header-left">
                            <button class="view_application" v-if="[1,2,4].indexOf(currentRole) >= 0" 
                        @click="generateGCForms()">Generate PDF Forms</button>
         

                </div>

                <div class="gc_details-header-right">
                               <div class="download-all-forms" v-if="[1,2,4].indexOf(currentRole) >= 0 && pdfformslist.length > 0">

                        <p class="download-link">
                            <a @click="downloadallGCForms()">
                                Download All Forms
                            </a>
                        </p>

                    </div>
                </div>
            </div>

            <file-upload v-model="documentUploaded" class="file-upload-input mb-0" style="display:none !important" :name="'pdocuments'" :multiple="false" v-validate="'required'" label="Forms and Letters" data-vv-as="Forms and Letters" :accept="allDocEntity" @input="selectedDocuments(documentUploaded)">

                <span @click="fileuploadPopup=true" class="add_new">
                    <img src="@/assets/images/main/upload.svg" />Upload
                </span>

            </file-upload>

            <div class="card-panels" v-if="pdfformslist.length > 0">
                <Pdflist @uploadVersion="uploadVersion" :title="petition.beneficiaryInfo.name +' (Principal Applicant)'" :currentRole="currentRole" :pdfformslist="pdfformslist" />
            </div>

            <div class="card-panels" v-if="spousepdfformslist.length > 0">
                <Pdflist @uploadVersion="uploadVersion" :title="petition.dependentsInfo.spouse.name +' (Spouse)'" :currentRole="currentRole" :pdfformslist="spousepdfformslist" />
            </div>
            <div v-if="childpdfformslist.length > 0 && childloaded">
                <div v-for="(child,childindex)  in childpdfformslist" :key="childindex">
                    <div class="card-panels" v-if="child.length > 0">
                        <Pdflist @uploadVersion="uploadVersion" :title="petition.dependentsInfo.childrens[childindex].name +' (Child '+(childindex+1)+')'" :currentRole="currentRole" :pdfformslist="child" />
                    </div>
                </div>
            </div>
            <div>

            </div>

        </div>

    </div>
    <div class=""></div>
</div>
</template>

<script>
const formatter = new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 2
});

import FileUpload from "vue-upload-component/src";
import moment from "moment";
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import Pdflist from "./Pdflist"
export default {
    props: {
        currentRole: null,
        currentUser: null,
        petition: {
            type: Object,
            default: null
        }
    },
    components: {
        FileUpload,
        VuePerfectScrollbar,
        Pdflist
    },
    data: () => ({
        childloaded: false,
        selectedDoc: null,
        documentUploaded: null,
    }),
    methods: {
        uploadVersion(val) {
            document.getElementById("pdocuments").click();
            this.selectedDoc = val;
        },
        selectedDocuments(docs) {
            this.$vs.loading();
            docs = docs.map(
                item =>
                (item = {
                    name: item.name,
                    file: item.file,
                    document: "",
                    mimetype: item.type
                })
            );
            if (docs.length > 0) {
                let formData = new FormData();
                docs.forEach(doc => {
                    formData.append("files", doc.file);
                    formData.append("secureType", "private");
                    this.$store.dispatch("uploadS3File", formData).then(response => {

                        var saveversion = {
                            petitionId: this.petition._id,
                            caseNo: this.petition.caseNo,
                            formType: this.selectedDoc.formType,
                            userType: this.selectedDoc.userType,
                            url: response.data.result[0]
                        }

                        this.$store.dispatch("savegcpdflist", saveversion).then(response => {
                            // this.documentUploaded={};
                            this.generateList();
                            this.$vs.notify({
                                title: "Success",                                
                                position: "top-right",
                                color: "primary",
                                text: response.message
                            });
                            this.$vs.loading.close();

                        })

                    })

                })

            }

        },
        generateGCForms() {
            this.$vs.loading();
            let postdata = {
                petitionId: this.petition._id,
            };
            this.$store.dispatch("generategcpdf", postdata).then(response => {
                this.$vs.loading.close();
                this.generateList();

                this.$vs.notify({
                    title: "Success",                    
                    position: "top-right",
                    color: "primary",
                    text: response.message
                });

            });

        },
        downloadallGCForms() {
            this.$vs.loading();
            let postdata = {
                petitionId: this.petition._id,
                caseNo: this.petition.caseNo,
            };
            this.$store.dispatch("downloadgcforms", postdata).then(response => {
                // window.open(response.data.result.path, "_blank");
                window.open(this.$globalgonfig._BASEURL + "/api/viewfile?&filename=" + this.petition.caseNo + ".zip&path=" + response.path, "_blank");
                this.$vs.loading.close();
                // this.generateList();
            });

        },
        fetchSignedUrl(value) {
            value = value.replace(this.$globalgonfig._S3URL, "");
            value = value.replace(this.$globalgonfig._S3URLAWS, "");
            let postdata = {
                keyName: value
            };
            this.$store.dispatch("getSignedUrl", postdata).then(response => {
                window.open(response.data.result.data, "_blank");
            });
        },
        generateList() {
            let postdata = {
                petitionId: this.petition._id,
                userType: "self"
            };
            this.$store.dispatch("getgcpdflist", postdata).then(response => {
                this.pdfformslist = response;
            });
            postdata = {
                petitionId: this.petition._id,
                userType: "spouse"
            };
            this.$store.dispatch("getgcpdflist", postdata).then(response => {
                this.spousepdfformslist = response;
            });

            if (this.petition.dependentsInfo && this.petition.dependentsInfo.childrens && this.petition.dependentsInfo.childrens.length > 0) {

                this.petition.dependentsInfo.childrens.forEach((doc, index) => {

                    postdata = {
                        petitionId: this.petition._id,
                        userType: "child",
                        childrenId: doc._id
                    };
                    this.$store.dispatch("getgcpdflist", postdata).then(response => {
                        this.childpdfformslist[index] = response;
                        if (index == (this.petition.dependentsInfo.childrens.length - 1)) {

                            this.childloaded = true;
                        }
                    });

                })

            }

        }
    },
    data: () => ({
        pdfformslist: [],
        spousepdfformslist: [],
        childpdfformslist: []
    }),
    mounted() {

        this.generateList();

    }
};
</script>
