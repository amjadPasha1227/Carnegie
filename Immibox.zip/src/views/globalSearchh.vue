<template>
  <div>
    <!-- v-if="selectedCategoryList.index(tr) >-1" -->
    <div class="global_search" v-click-outside="onClickOutside" :class="{ 'searchopen': getisGlobalSearchOpened }">
      <div class="global_search_input">
        <input @click="showModel = true; togleGlobalSearch(true)" autocomplete="off" ref="gsearchinput" id="gsearchinput"
        @input="searchMe"  v-model="searchText" class="searchinput" :placeholder=globalSearchPlaceholder />
        <button class="search_btn">Search</button>

      </div>

      

      <div class="seach_results_sec" v-if="searchText">

        <div class="results_tab">
          <ul class="d-flex">
            <!-- <li>
                          <a @click="selectCategory('ALL')">All</a>
                      </li> -->
            <li :data="cat" :key="indextr" v-for="(cat, indextr) in categories" :class="{ 'active': selectedCat == cat }">
              <a @click="selectCategory(cat)">{{ cat }}</a>
            </li>
          </ul>
        </div>
        <template v-if="itemsCount > 0">
          <div class="results_list" @click="showModel = !showModel" :class="{ 'all_list': selectedCat == 'ALL' }">
            <VuePerfectScrollbar ref="mainSidebarPs" class="scroll-area--nofications-dropdown p-0" :settings="settings">



              <template>
                <ul class="tasks active">
                  <!------this.selectedCat
          categories:["CASE","TASK", "DOCUMENT","DEADLINE"],-->
                <template v-if="checkProperty(categoryData, 'CASE', 'length') > 0">
                    <li :key="ticket._id" v-for="(ticket, indextr) in categoryData['CASE']" class="task-list"
                      @click="clearText(); showModel = false; searchText = ''; togleGlobalSearch(); gotCaseDetails(ticket)">
                      <div class="elements">

                        <div>
                          <div class="info">
                            <h4 :title="checkProperty(ticket, 'caseNo')" v-if="checkProperty(ticket, 'caseNo')">
                              {{ checkProperty(ticket, 'caseNo') }}</h4>
                          </div>
                          <div class="list_items">
                            <ul>
                              <li v-if="checkProperty(ticket, 'typeName')">
                                <span>{{ checkProperty(ticket, 'typeName') }}<em>({{ checkProperty(ticket, 'subTypeName') }})</em></span>
                              </li>
                              <li v-if="checkProperty(ticket, 'beneficiaryName')">
                                <span>{{ checkProperty(ticket, 'beneficiaryName') }}<em>(Beneficiary)</em></span></li>
                            </ul>
                          </div>
                          <!-- <div class="due_date">                                  
                                    <small v-if="checkProperty(ticket, 'typeName') ">{{checkProperty(ticket,'typeName')}}<span> ({{checkProperty(ticket,'subTypeName')}})</span></small>
                                    <small v-if="checkProperty(ticket,'beneficiaryName')">Beneficiary: <span>{{checkProperty(ticket,'beneficiaryName')}}</span></small>
                                </div> -->
                        </div>
                        <div class="status">
                          <strong v-if="selectedCat == 'ALL'">
                            <template v-if="[15].indexOf(ticket['subType']) > -1">PERM Case</template>
                            <template v-else>Case</template>
                          </strong>
                          
                          <span class="statusspan" v-bind:class="{
                            'received_signed_forms': [32].indexOf(checkProperty(ticket, 'statusId')) > -1,
                            'status_created': checkProperty(ticket, 'statusId') == 1,
                            'status_submited': checkProperty(ticket, 'statusId') == 2,
                            'status_inProcess': checkProperty(ticket, 'statusId') == 3,
                            'status_waiting': checkProperty(ticket, 'statusId') == 4,
                            'status_ready_for_filing': [5, 8].indexOf(checkProperty(ticket, 'statusId')) > -1,
                            'status_sent_for_signatures': [6, 9,33].indexOf(checkProperty(ticket, 'statusId')) > -1,
                            'staus_filed_with_USCIS': [7, 18].indexOf(checkProperty(ticket, 'statusId')) > -1,
                            'status_approved': [10, 22].indexOf(checkProperty(ticket, 'statusId')) > -1,
                            'RFE_Received': [24, 11].indexOf(checkProperty(ticket, 'statusId')) > -1,
                            'status_submited-USCIS': checkProperty(ticket, 'statusId') == 12,
                            'response_to_RFE_Received': checkProperty(ticket, 'statusId') == 13,
                            'status_jobdescription': checkProperty(ticket, 'statusId') == 14,
                            'status_pwd_filed': checkProperty(ticket, 'statusId') == 15,
                            'status_pwd_response': checkProperty(ticket, 'statusId') == 16,
                            'staus_advertisements': checkProperty(ticket, 'statusId') == 17,
                            'Status_received_by_USCIS': checkProperty(ticket, 'statusId') == 19,
                            'Perm_drft_approved': checkProperty(ticket, 'statusId') == 20,
                            'Perm_submited_dol': checkProperty(ticket, 'statusId') == 21,
                            'status_denied': checkProperty(ticket, 'statusId') == 23,
                            'notice_supervisory_audit': checkProperty(ticket, 'statusId') == 27,
                            'status_supervisory_audit': checkProperty(ticket, 'statusId') == 28,
                            //'status_withdrawn': checkProperty(ticket, 'statusId') == 14,
                            'status_withdrawn': checkProperty(ticket, 'statusId') == 31
                          }">{{ checkProperty(ticket, 'statusName') }}

                          </span>
                          <!-- class="{
                                'status_created': checkProperty(ticket ,'statusId') == 1,
                                'status_submited': checkProperty(ticket ,'statusId') == 2,
                                'status_inProcess': checkProperty(ticket ,'statusId') == 3,
                                'status_waiting': checkProperty(ticket ,'statusId') == 4,
                                'status_ready_for_filing': checkProperty(ticket ,'statusId') == 5,
                                'status_sent_for_signatures': checkProperty(ticket ,'statusId') == 6,
                                'staus_filed_with_USCIS': checkProperty(ticket ,'statusId') == 7,
                                'Status_received_by_USCIS': checkProperty(ticket ,'statusId') == 8,
                                'RFE_Received': checkProperty(ticket ,'statusId') == 9,
                                'status_approved': checkProperty(ticket ,'statusId') == 10,
                  
                                
                                'status_denied': checkProperty(ticket ,'statusId') == 11 || checkProperty(ticket ,'statusId') == '11',
                                'response_to_RFE_Filed': checkProperty(ticket ,'statusId') == 12,
                                'response_to_RFE_Received': checkProperty(ticket ,'statusId') == 13,
                                'status_withdrawn': checkProperty(ticket ,'statusId') == 14,
                                
                              }" -->
                          <!-- <span 
                            v-else
                                class="statusspan"
                                v-bind:class="{
                                 'status_created': checkProperty(ticket ,'statusId') == 1,
                  'status_submited': checkProperty(ticket ,'statusId') == 2,
                  'status_inProcess': checkProperty(ticket ,'statusId') == 3,
                  'status_waiting': checkProperty(ticket ,'statusId') == 4,
                  'status_ready_for_filing': checkProperty(ticket ,'statusId') == 5,
                  'status_sent_for_signatures': checkProperty(ticket ,'statusId') == 6,
                  'staus_filed_with_USCIS': checkProperty(ticket ,'statusId') == 7,
                  'status_ready_for_filing': checkProperty(ticket ,'statusId') == 8,
                  'status_sent_for_signatures': checkProperty(ticket ,'statusId') == 9,
                  'status_denied': checkProperty(ticket ,'statusId') == 10,
                  'RFE_Received': ['11',11].indexOf(checkProperty(ticket ,'statusId')) >-1,
                  'status_submited-USCIS': checkProperty(ticket ,'statusId') == 12,
                  'response_to_RFE_Received': checkProperty(ticket ,'statusId') == 13,
                  'status_jobdescription': checkProperty(ticket ,'statusId') == 14,
                  'status_pwd_filed': checkProperty(ticket ,'statusId') == 15,
                  'status_pwd_response': checkProperty(ticket ,'statusId') == 16,
                  'staus_advertisements': checkProperty(ticket ,'statusId') == 17,
                  'staus_filed_with_USCIS': checkProperty(ticket ,'statusId') == 18,
                  'Status_received_by_USCIS': checkProperty(ticket ,'statusId') == 19,
                  'Perm_drft_approved': checkProperty(ticket ,'statusId') == 20,
                  'Perm_submited_dol': checkProperty(ticket ,'statusId') == 21,
                  'status_approved': checkProperty(ticket ,'statusId') == 22,
                  'status_denied': checkProperty(ticket ,'statusId') == 23,
                  'RFE_Received': checkProperty(ticket ,'statusId') == 24,
                  'notice_supervisory_audit': checkProperty(ticket ,'statusId') == 27,
                  'status_supervisory_audit': checkProperty(ticket ,'statusId') == 28,
                  'status_withdrawn': checkProperty(ticket ,'statusId') == 14,
                  'status_withdrawn': checkProperty(ticket ,'statusId') == 31,
                  ' ': checkProperty(ticket ,'statusId') == 15
                              }"
                              >{{checkProperty(ticket,'statusName')}}
                            
                            </span> -->


                        </div>
                      </div>
                    </li>

                </template>
                <template v-else-if="selectedCat == 'CASE'">
                  <li class="task-list">
                    <NoList ref="NoDataFoundRef" :loading="false" heading="No Results found!" type="globalSearch">
                    </NoList>
                  </li>
                </template>

                  <template v-if="checkProperty(categoryData, 'TASK', 'length') > 0">

                    <li class="task-list" :key="ticket._id" v-for="(ticket, indextr) in categoryData['TASK']"
                      @click="clearText(); showModel = false; searchText = ''; togleGlobalSearch(); goToPageDetails('/tasks-list?id=' + ticket['_id'])">
                      <div class="elements">

                        <div>
                          <div class="info">
                            <h4 :title="checkProperty(ticket, 'title')" v-if="checkProperty(ticket, 'title')">
                              {{ checkProperty(ticket, 'title') }}</h4>
                          </div>
                          <div class="list_items">
                            <ul>
                              <li v-if="checkProperty(ticket, 'dueDate')"><span>{{ ticket.dueDate | formatDateMMDD
                              }}</span></li>
                              <li v-if="checkProperty(ticket, 'customId')">
                                <span>{{ checkProperty(ticket, 'customId') }}</span></li>
                            </ul>
                          </div>
                          <!-- <div class="due_date">
                                  <small v-if="checkProperty(ticket, 'dueDate') ">Due Date: <span>{{ ticket.dueDate | formatDateMMDD }}</span></small>
                                  <em v-if="checkProperty(ticket,'customId')" >{{checkProperty(ticket,'customId')}}</em>
                                </div>   -->
                        </div>
                        <div class="status">
                          <strong v-if="selectedCat == 'ALL'">Task </strong>
                          <span class="statusspan" v-bind:class="{
                            'status_created': checkProperty(ticket, 'statusId') == 1,
                            'status_submited': checkProperty(ticket, 'statusId') == 2,
                            'status_inProcess': checkProperty(ticket, 'statusId') == 3,
                            'status_waiting': checkProperty(ticket, 'statusId') == 4,
                            'status_ready_for_filing': checkProperty(ticket, 'statusId') == 5,
                            'status_sent_for_signatures': checkProperty(ticket, 'statusId') == 6,
                            'staus_filed_with_USCIS': checkProperty(ticket, 'statusId') == 7,
                            'Status_received_by_USCIS': checkProperty(ticket, 'statusId') == 8,
                            'status_approved': checkProperty(ticket, 'statusId') == 9,
                            'status_denied': checkProperty(ticket, 'statusId') == 10,
                            'RFE_Received': ['11', 11].indexOf(checkProperty(ticket, 'statusId')) > -1,
                            'response_to_RFE_Filed': checkProperty(ticket, 'statusId') == 12,
                            'response_to_RFE_Received': checkProperty(ticket, 'statusId') == 13,
                            'status_withdrawn': checkProperty(ticket, 'statusId') == 14,
                            ' ': checkProperty(ticket, 'statusId') == 15
                          }">{{ checkProperty(ticket, 'statusName') }}</span>
                        </div>
                      </div>
                    </li>
                  </template>
                  <template v-else-if="selectedCat == 'TASK'">
                    <li class="task-list">
                      <NoList ref="NoDataFoundRef" :loading="false" heading="No Results found!" type="globalSearch">
                      </NoList>
                    </li>
                  </template>

                  <template v-if="checkProperty(categoryData, 'DOCUMENT', 'length') > 0">
                    <li class="task-list document-list" :key="ticket._id"
                      v-for="(ticket, indextr) in categoryData['DOCUMENT']" data-original-title="pdf"
                      @click="clearText(); showModel = false; searchText = ''; togleGlobalSearch(); downloads3file(ticket)">
                      <div class="elements ">

                        <docType :downloadMe="true" :item="ticket" />
                        <div class="w-full">
                          <div class="info">
                            <h4 v-if="checkProperty(ticket, 'name')">{{ checkProperty(ticket, "name") }}</h4>
                            <strong v-if="selectedCat == 'ALL'">Document </strong>
                          </div>
                          <div class="search_activities_list">
                            <label v-if="checkProperty(ticket, 'createdByName')"><span
                                v-if="checkProperty(ticket, 'createdByName')"> Created By
                                <b>{{ checkProperty(ticket, 'createdByName') }}</b></span> <span
                                v-if="checkProperty(ticket, 'createdOn')"> On <b>{{ checkProperty(ticket, 'createdOn') |
                                  formatDateTime }}</b></span> </label>

                          </div>
                        </div>
                      </div>
                    </li>

                  </template>
                  <template v-else-if="selectedCat == 'DOCUMENT'">
                    <li class="task-list document-list">
                      <NoList ref="NoDataFoundRef" :loading="false" heading="No Results found!" type="globalSearch">
                      </NoList>
                    </li>
                  </template>

                  <template v-if="checkProperty(categoryData, 'PETITIONER', 'length') > 0">
                    <li class="task-list petitioner_list" :key="indextr"
                      v-for="(ticket, indextr) in categoryData['PETITIONER']"
                      @click="clearText(); showModel = false; searchText = ''; togleGlobalSearch(); goToPageDetails('/petitioner-details/' + ticket['_id'])">
                      <div class="elements">
                        <div class="w-full">
                          <div class="info">
                            <div class="d-flex align-center">
                              <h4 :title="checkProperty(ticket, 'name')" v-if="checkProperty(ticket, 'name')">
                                {{ checkProperty(ticket, 'name') }} </h4>
                              <span class="pet-span">corporate</span>
                            </div>
                            <strong v-if="selectedCat == 'ALL'">Petitioner </strong>
                          </div>
                          <div class="list_items">
                            <ul>
                              <li v-if="checkProperty(ticket, 'email')"><span>{{ checkProperty(ticket, 'email') }}</span></li>
                              <li v-if="checkProperty(ticket, 'customId')">
                                <span>{{ checkProperty(ticket, 'customId') }}</span></li>
                            </ul>
                          </div>

                          <!-- <div class="email-custID">
                                  <label v-if="checkProperty(ticket,'email')"><span>{{checkProperty(ticket,'email')}}</span></label>
                                  <label v-if="checkProperty(ticket,'customId')">CustomId: <span>{{checkProperty(ticket,'customId')}}</span></label>
                                </div>   -->
                        </div>

                      </div>

                    </li>

                  </template>
                  <template v-else-if="selectedCat == 'PETITIONER'">
                    <li class="task-list">
                      <NoList ref="NoDataFoundRef" :loading="false" heading="No Results found!" type="globalSearch">
                      </NoList>
                    </li>
                  </template>

                  <template v-if="checkProperty(categoryData, 'BENEFICIARY', 'length') > 0">
                    <li class="task-list beneficiary-list" :key="ticket._id"
                      v-for="(ticket, indextr) in categoryData['BENEFICIARY']"
                      @click="clearText(); showModel = false; searchText = ''; togleGlobalSearch(); goToPageDetails('/beneficiaries-details/' + ticket['_id'])">
                      <div class="elements">
                        <div class="w-full">
                          <div class="info">
                            <h4 :title="checkProperty(ticket, 'name')" v-if="checkProperty(ticket, 'name')">
                              {{ checkProperty(ticket, 'name') }}</h4>
                            <strong v-if="selectedCat == 'ALL'">Beneficiary </strong>
                          </div>
                          <div class="list_items">
                            <ul>
                              <li v-if="checkProperty(ticket, 'email')"><span>{{ checkProperty(ticket, 'email') }}</span></li>
                              <li v-if="checkProperty(ticket, 'customId')">
                                <span>{{ checkProperty(ticket, 'customId') }}</span></li>
                            </ul>
                          </div>
                          <!-- <div class="email-custID">
                                  <label v-if="checkProperty(ticket,'email')">Email: <span>{{checkProperty(ticket,'email')}}</span></label>
                                  <label v-if="checkProperty(ticket,'customId')">Custom Id: <span>{{checkProperty(ticket,'customId')}}</span></label>
                                </div> -->
                        </div>
                      </div>
                    </li>

                  </template>
                  <template v-else-if="selectedCat == 'BENEFICIARY'">
                    <li class="task-list">
                      <NoList ref="NoDataFoundRef" :loading="false" heading="No Results found!" type="globalSearch">
                      </NoList>
                    </li>
                  </template>


                  

                  



                </ul>
              </template>


              <!----
                    <template v-if="checkProperty( categoryData ,'PETITIONER' , 'length')>0">
                      <ul class="tasks active"  >
                        <li class="task-list" :key="indextr" v-for="(ticket, indextr) in categoryData ['PETITIONER']"  @click="showModel = false;searchText='';togleGlobalSearch();goToPageDetails('/petitioner-details/'+ticket['_id'])" >
                          <div class="elements">
                            <strong v-if="selectedCat =='ALL'">Petitioner </strong>
                            <div>
                              <div class="info">
                                <h4 v-if="checkProperty(ticket,'name')">{{checkProperty(ticket,'name')}} </h4>
                                <span class="pet-span">corporate</span>
                              </div>
                              <div class="email-custID">
                                <label v-if="checkProperty(ticket,'email')"><span>{{checkProperty(ticket,'email')}}</span></label>
                                <label v-if="checkProperty(ticket,'customId')">CustomId: <span>{{checkProperty(ticket,'customId')}}</span></label>
                              </div>  
                            </div>
                             
                          </div>
                                                 
                        </li>
                      </ul> 
                    </template>
  
                    <template v-if="checkProperty( categoryData ,'BENEFICIARY' , 'length')>0">
                      <ul class="tasks active"  >
                        <li class="task-list" :key="indextr" v-for="(ticket, indextr) in categoryData ['BENEFICIARY']"  @click="showModel = false;searchText='';togleGlobalSearch();goToPageDetails('/beneficiaries-details/'+ticket['_id'])" >
                          <div class="elements">
                            <strong v-if="selectedCat =='ALL'">Beneficiary </strong>
                            <div>
                                <div class="info">
                                  <h4 v-if="checkProperty(ticket,'name')">{{checkProperty(ticket,'name')}}</h4>
                                </div>
                                <div class="email-custID">
                                  <label v-if="checkProperty(ticket,'email')">Email: <span>{{checkProperty(ticket,'email')}}</span></label>
                                  <label v-if="checkProperty(ticket,'customId')">CustomId: <span>{{checkProperty(ticket,'customId')}}</span></label>
                                </div>
                            </div>
                          </div>
                        </li>
                      </ul> 
                    </template>
  
                    <template v-if="checkProperty( categoryData ,'DOCUMENT' , 'length')>0">
                        <ul class="documents uploaded-files">
                          <li  :key="indextr" v-for="(ticket, indextr) in categoryData['DOCUMENT']"  data-original-title="pdf" class="has-tooltip v-tooltip-open" @click="showModel = false;searchText='';togleGlobalSearch();downloads3file(ticket)">
                            <div class="elements ">
                              <strong v-if="selectedCat =='ALL'">Document </strong>
                              <docType :downloadMe="true" :item="ticket" />
                              <div>
                              <div class="info">
                              <h4>{{checkProperty(ticket ,"name")}}</h4>
                              </div>
                              <div class="due_date">
                                  <small v-if="checkProperty(ticket, 'createdByName') ">Created By: <span>{{checkProperty(ticket,'createdByName')}}<em v-if="checkProperty(ticket ,'createdByRoleName')">({{checkProperty(ticket ,"createdByRoleName")}})</em></span></small>
                                  <small v-if="checkProperty(ticket ,'createdOn')">createdOn: {{checkProperty(ticket ,'createdOn')  | formatDate}}</small>
                              </div>
                              </div>
                            </div>
                          </li>
                      
                        </ul>
                    </template>
                    
                    <template v-if="checkProperty( categoryData ,'CASE' , 'length')>0" > 
                    <ul class="case">                
                      <li :key="indextr" v-for="(ticket, indextr) in categoryData['CASE']"  class="task-list"  @click="showModel = false;searchText='';togleGlobalSearch();goToPageDetails('/petition-details/'+ticket['_id'])"   >
                      <div class="elements">
                        <strong v-if="selectedCat =='ALL'">Cases </strong>
                        <div>
                          <div class="info">
                            <h4 v-if="checkProperty(ticket,'caseNo')">Case No: {{checkProperty(ticket,'caseNo')}}</h4>
                          </div>
                          <div class="due_date">
                              <small v-if="checkProperty(ticket, 'typeName') ">{{checkProperty(ticket,'typeName')}}<span> ({{checkProperty(ticket,'subTypeName')}})</span></small>
                              <small v-if="checkProperty(ticket,'beneficiaryName')">Beneficiary: <span>{{checkProperty(ticket,'beneficiaryName')}}</span></small>
                          </div>
                        </div>  
                        <div class="status">                      
                          <span
                          class="statusspan"
                          v-bind:class="{
                          'status_created': checkProperty(ticket ,'statusId') == 1,
                          'status_submited': checkProperty(ticket ,'statusId')  == 2,
                          'status_inProcess': checkProperty(ticket ,'statusId')  == 3,
                          'status_waiting': checkProperty(ticket ,'statusId')  == 4,
                          'status_ready_for_filing': checkProperty(ticket ,'statusId')  == 5,
                          'status_sent_for_signatures': checkProperty(ticket ,'statusId')  == 6,
                          'staus_filed_with_USCIS': checkProperty(ticket ,'statusId')  == 7,
                          'Status_received_by_USCIS': checkProperty(ticket ,'statusId')  == 8,
                          'status_approved': checkProperty(ticket ,'statusId')  == 9,
                          'status_denied':checkProperty(ticket ,'statusId')  == 10,
                          'RFE_Received': ['11',11].indexOf(checkProperty(ticket ,'statusId') ) >-1,
                          'response_to_RFE_Filed': checkProperty(ticket ,'statusId')  == 12,
                          'response_to_RFE_Received':checkProperty(ticket ,'statusId')  == 13,
                          'status_withdrawn': checkProperty(ticket ,'statusId')  == 14,
                          ' ': checkProperty(ticket ,'statusId')  == 15
                        }"
                        >{{checkProperty(ticket,'statusName')}}</span>
                        </div>
                      </div>
                      </li>
                    </ul> 
                    </template>
                    -->




            </VuePerfectScrollbar>
          </div>
        </template>
        <template v-if="itemsCount <= 0">
          <!-- <NoDataFound   ref="NoDataFoundRef"   :loading="false"   heading="No Results found!"  type="globalSearch"  /> -->


          <NoList ref="NoDataFoundRef" :loading="false" heading="No Results found!" type="globalSearch"></NoList>
        </template>



      </div>

    </div>

  </div>
</template>
  
<script>

import NoDataFound from "@/views/common/noData.vue";
import NoList from "@/views/common/noList.vue";
import Vue from 'vue';
import VTooltip from 'v-tooltip'; ``
import docType from "@/views/common/docType.vue";
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import VueDocPreview from "vue-doc-preview";
import _ from "lodash";
Vue.use(VTooltip);




import vOutsideEvents from 'vue-outside-events'
Vue.use(vOutsideEvents)


export default {
  name: "global-search",
  components: {
    VueDocPreview,
    docType,
    VuePerfectScrollbar,
    NoDataFound,
    NoList,
  },
  data: () => ({

   
    debounce: null,

    globalSearchPlaceholder: 'Search',
    categories: [],
    categoryData: [],
    searchText: '',
    tempCategoryData: [],
    selectedCategoryList: [],
    selectedCat: 'ALL',
    loading: true,
    postData: {
      categories: [],
      filters: {
        title: ""
      }
    },
    settings: {
      swipeEasing: true,
    },
    docValue: "",
    docPrivew: false,
    docType: '',
    showModel: false,

    itemsCount: 0
  }),
  methods: {

   searchMe(event){
    let self =this;

    
    
      clearTimeout(this.debounce)
      this.debounce = setTimeout(() => {
        self.getGlobalSearch(true);
      }, 900)

     //self.getGlobalSearch(true);

    
   },

    gotCaseDetails(ticket) {
      if ([15].indexOf(ticket['subType']) > -1) {

        this.goToPageDetails('/gc-employment-details/' + ticket['_id'])
      } else {
        this.goToPageDetails('/petition-details/' + ticket['_id'])

      }
      // this.goToPageDetails('/gc-employment-details/'+ticket['_id'])
    },

    clearText() {
      this.searchText = '';
      this.selectedCategoryList = [];
      this.selectedCat = 'ALL';

    },
    onClickOutside() {
      this.showModel = false;
    },
    textsearch() {
      this.categoryData = _.cloneDeep(this.tempCategoryData);
      if (this.searchText.trim() != '') {
        //let cat =_.cloneDeep(this.selectedCat);
        _.forEach(this.selectedCategoryList, (cat) => {

          if (cat == 'TASK' && this.checkProperty(this.categoryData, 'TASK', "length") > 0) {
            this.categoryData['TASK'] = _.filter(this.categoryData['TASK'], (item) => {
              return item
              //return item['title'].includes(this.searchText.trim());        
            })
          }
          if (cat == 'CASE' && this.checkProperty(this.categoryData, 'CASE', "length") > 0) {
            this.categoryData['CASE'] = _.filter(this.categoryData['CASE'], (item) => {
              // return item['caseNo'].includes(this.searchText.trim()) 
              // || item['typeName'].includes(this.searchText.trim()) 
              // || item['subTypeName'].includes(this.searchText.trim())    
              return item
            })
          }
          if (cat == 'DOCUMENT' && this.checkProperty(this.categoryData, 'DOCUMENT', "length") > 0) {
            this.categoryData['DOCUMENT'] = _.filter(this.categoryData['DOCUMENT'], (item) => {
              //return item['name'].includes(this.searchText.trim());   
              return item
            })
          }
          if (cat == 'PETITIONER' && this.checkProperty(this.categoryData, 'PETITIONER', "length") > 0) {
            this.categoryData['PETITIONER'] = _.filter(this.categoryData['PETITIONER'], (item) => {
              //return item['name'].includes(this.searchText.trim()) ||  item['email'].includes(this.searchText.trim())   
              return item
            })
          }
          if (cat == 'BENEFICIARY' && this.checkProperty(this.categoryData, 'BENEFICIARY', "length") > 0) {
            this.categoryData['BENEFICIARY'] = _.filter(this.categoryData['BENEFICIARY'], (item) => {
              //return item['name'].includes(this.searchText.trim()) ||  item['email'].includes(this.searchText.trim())  
              return item
            })
          }
        })

      }
    },
    selectCategory(category) {
      this.selectedCat = category;
      if (category == "ALL") {
        if (this.selectedCategoryList.indexOf('ALL') > -1) {
          this.selectedCategoryList = [];
        } else {
          this.selectedCategoryList = _.cloneDeep(this.categories);
        }
      }
      else {
        this.selectedCategoryList = [category];
        // if(this.selectedCategoryList.indexOf(category) == -1 ){
        //   this.selectedCategoryList.push(category) 

        // } 
        // else{
        //   this.selectedCategoryList = _.filter(this.selectedCategoryList ,(item)=>{
        //     return category !=item && item !="ALL"
        //   })
        // }
      }
      this.getGlobalSearch()
    },
    getGlobalSearch(callFromSearch = false) {

      let payLoad = _.cloneDeep(this.postData)
      if (this.searchText.trim() != '') {
        payLoad['filters']['title'] = this.searchText.trim();
      }
      payLoad['categories'] = _.filter(this.selectedCategoryList, (item) => {
        return item != 'ALL'
      })
      this.categoryData = [];
      if (this.checkProperty(this.selectedCategoryList, 'length') <= 0) {
        //return false;
      }
      this.loading = true;
      if (!callFromSearch) {
        this.itemsCount = 0;
        this.loading = false;
      }

      if (this.checkProperty(payLoad, 'categories', 'length') <= 0) {

        if ([3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14].indexOf(this.getUserRoleId) > -1) {
          if (this.getTenantTypeId == 2) {
            payLoad['categories'] = ["ALL", "CASE", "TASK", "DOCUMENT", "BENEFICIARY"];
            this.selectedCategoryList = ["ALL", "CASE", "TASK", "DOCUMENT", "BENEFICIARY"];
            this.selectedCat = "ALL";

          } else {
            payLoad['categories'] = ["ALL", "CASE", "TASK", "DOCUMENT", "PETITIONER", "BENEFICIARY"];
            this.selectedCategoryList = ["ALL", "CASE", "TASK", "DOCUMENT", "PETITIONER", "BENEFICIARY"];
            this.selectedCat = "ALL";
          }

        } else if ((this.getUserRoleId) == 50) {

          payLoad['categories'] = ["ALL", "CASE", "DOCUMENT", "BENEFICIARY"];
          this.selectedCategoryList = ["ALL", "CASE", "DOCUMENT", "BENEFICIARY"];
          this.selectedCat = "ALL";

        }
      }

      this.updateLoading(true);
      this.$store.dispatch("commonAction", { "data": payLoad, "path": "/global-search/list" })
        .then((response) => {
          this.itemsCount = 0;
          this.categoryData = response
          _.forEach(this.selectedCategoryList, (item) => {
            if (this.checkProperty(this.categoryData, item, 'length') > 0) {
              this.itemsCount = this.itemsCount + (this.categoryData[item].length)
            }


          })
          this.loading = false;

          this.tempCategoryData = _.cloneDeep(response);
          if (this.searchText.trim() != '') {
            this.textsearch();

          }
          setTimeout(() => {
            this.updateLoading(false);
          }, 10)

        }).catch(() => {
          this.loading = false;
          this.itemsCount = 0;
          setTimeout(() => {
            this.updateLoading(false);
          })

        })
    },
    download_or_view(value) {
      if (_.has(value, "path")) {
        value["url"] = value["path"];
        value["document"] = value["path"];
      }

      if (_.has(value, "url")) {
        value["path"] = value["url"];
        value["document"] = value["url"];
      }

      if (_.has(value, "document")) {
        value["path"] = value["document"];
        value["url"] = value["document"];
      }
      this.selectedFile = value;
      this.docValue = "";
      this.docPrivew = false;
      this.docType = false;
      this.docType = this.findmsDoctype(value);

      if (this.docType == "office" || this.docType == "image") {
        value.url = value.url.replace(this.$globalgonfig._S3URL, "");
        value.url = value.url.replace(this.$globalgonfig._S3URLAWS, "");
        let postdata = {
          keyName: value.url,
        };
        this.$store.dispatch("getSignedUrl", postdata).then((response) => {
          this.docValue = response.data.result.data;

          if (this.docType == "office") {
            this.docValue = encodeURIComponent(response.data.result.data);
          }
          this.docPrivew = true;
        });
      } else {
        this.downloads3file(value);
      }
    }
  },
  mounted() {
    if ([3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14].indexOf(this.getUserRoleId) > -1) {
      if (this.getTenantTypeId == 2) {

        this.globalSearchPlaceholder = "Search by Case/Task/Document/Beneficiary";
        this.categories = ["ALL", "CASE", "TASK", "DOCUMENT", "BENEFICIARY"];
        this.selectedCategoryList = ["ALL", "CASE", "TASK", "DOCUMENT", "BENEFICIARY"];
      }
      else {
        this.globalSearchPlaceholder = "Search by Case/Task/Document/Petitioner/Beneficiary";
        this.categories = ["ALL", "CASE", "TASK", "DOCUMENT", "PETITIONER", "BENEFICIARY"];
        this.selectedCategoryList = ["ALL", "CASE", "TASK", "DOCUMENT", "PETITIONER", "BENEFICIARY"];

      }
      this.getGlobalSearch();
    }
    if ((this.getUserRoleId) == 50) {
      this.globalSearchPlaceholder = "Search by Case/Document/Beneficiary";
      this.categories = ["ALL", "CASE", "DOCUMENT", "BENEFICIARY"];
      this.selectedCategoryList = ["ALL", "CASE", "DOCUMENT", "BENEFICIARY"];
      this.getGlobalSearch();
    }
  }

}
</script>
  
<style></style>