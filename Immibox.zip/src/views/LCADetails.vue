<template>
  <div :class="{ 'lca_details_wrap': showLcaActivity }">
    <template v-if="!checkLca">
     <div class="lca_alert_wrap" >
      <span class="lca_alert">LCA Draft was saved <template v-if=" checkProperty(lcaDetails,'createdByRoleName')"> by</template>
         {{ checkProperty(lcaDetails,'createdByName') }} <template v-if=" checkProperty(lcaDetails,'createdByRoleName')">
        <small>&nbsp({{ checkProperty(lcaDetails,'createdByRoleName') }})</small>
      </template></span>
    </div>
    </template>
    <template v-else>
    <div class="lca_header lca_header-v2">
      <div class="lca_header_list lcastatusbtnnew">    
        <template
          v-if="(checkProperty(lcaDetails, 'statusId') && [1, 2,3, 8,99].indexOf(checkProperty(lcaDetails, 'statusId')) > -1)">
          <template
            v-if="checkProperty($route, 'name') === 'fill-lca-anonymous-user' && checkProperty(petition, 'status') != false">

            <span class="edit-btn" @click="$emit('editLca', true)"><img
                src="@/assets/images/main/icon-edit.svg" />Edit</span>

          </template>
          <span class="edit-btn" @click="$emit('editLca', true)" v-else-if="((([50].indexOf(getUserRoleId) > -1 && checkPetitionsDetails && checkEditPermission )||checkIsLcaExcuitive || canLcaRequested || canLcaSubmit) && checkProperty(petition, 'status') != false)
          ">
            <img src="@/assets/images/main/icon-edit.svg" />Edit   
          </span>
        </template>
        <span v-if="showStatus" class="status-btn" v-bind:class="{
          'status_registered': checkProperty(lcaDetails, 'statusId') == 1,
          'status_filed': checkProperty(lcaDetails, 'statusId') == 2,
          'status_certified': checkProperty(lcaDetails, 'statusId') == 3,
          'status_denied': checkProperty(lcaDetails, 'statusId') == 4,
          'status_request_for_withdrawal': checkProperty(lcaDetails, 'statusId') == 5,
          'status_withdrawn': checkProperty(lcaDetails, 'statusId') == 6,
          'status_expired': checkProperty(lcaDetails, 'statusId') == 7,
          'status_lcarfe': checkProperty(lcaDetails, 'statusId') == 8,
          'status_draft': checkProperty(lcaDetails, 'statusId') == 99,
        }" style="white-space:nowrap;"> {{ checkProperty(lcaDetails, 'statusDetails', 'name') }}
        </span>

      </div>


      <template
        v-if="isFromLCAList && checkProperty(lcaDetails, 'petitionList') && checkProperty(lcaDetails, 'petitionList', 'length') > 0">
        <div class="lca-actions-list border">
          <label>
            Linked Case No(s)</label>
          <ul>
            <template v-for="(user, indx ) in checkProperty(lcaDetails, 'petitionList')">
              <li :key="indx" @click="navigateToCaseDetails(user)">{{ checkProperty(user, 'caseNo') }}</li>
            </template>
          </ul>
        </div>
      </template>


      <template v-if="!isFromLCAList && checkProperty(lcaDetails, 'caseNo')">
        <div class="lca-actions-list">
          <label>
            LCA No</label>
          <ul>
            <li :key="indx" @click="navigateToLCADetails(lcaDetails)">{{ checkProperty(lcaDetails, 'caseNo') }}</li>
          </ul>
        </div>
      </template>


      <div class="lca_header_list" v-if=" checkProperty(lcaDetails['documents']['certified'],'length' )> 0">
        <div class="list__cnt">
          <div class="lca_doc_sec">
            <label v-if="checkProperty(lcaDetails, 'certifiedDate')"><span>Certified Documents </span> <em>On</em>
              {{ lcaDetails.certifiedDate | formatDate }}</label>
          </div>
          <div class="lca_doclist">
            <ul>
              <template v-if="lcaDetails['documents']['certified'].length > 0">
                <template v-for="(certified, index) in lcaDetails['documents']['certified']">
                  <li :key="index" v-if="checkProperty(certified, 'status')  && checkProperty(certified, 'path')">
                    <div class="file__name" @click="fetchSignedUrl(certified)">
                      <figure>
                        <img v-if="checkFileFormat(certified['mimetype']) == 'pdf'" src="@/assets/images/main/pdf.svg" />
                        <img v-else-if="checkFileFormat(certified['mimetype']) == 'video_mime_types'"
                          src="@/assets/images/main/film.png" />
                        <img v-else-if="checkFileFormat(certified['mimetype']) == 'msDoc'"
                          src="@/assets/images/main/doc.svg" />
                        <img v-else-if="checkFileFormat(certified['mimetype']) == 'zip'"
                          src="@/assets/images/main/zip-file-format.png" />
                        <img v-else-if="checkFileFormat(certified['mimetype']) == 'msPpt'"
                          src="@/assets/images/main/ppt.svg" />
                        <img v-else-if="checkFileFormat(certified['mimetype']) == 'msXl'"
                          src="@/assets/images/main/xls.svg" />
                        <img v-else-if="checkFileFormat(certified['mimetype']) == 'image'"
                          src="@/assets/images/main/image.svg" />
                        <img v-else src="@/assets/images/main/icon-img.svg" />
                      </figure>
                      <a class="certified-name" :title="checkProperty(certified, 'name')">{{ certified.name }}</a>
                    </div>

                  </li>
                </template>
              </template>
            </ul>
          </div>
        </div>
      </div>
      <div class="lca_header_list" v-if=" checkProperty(lcaDetails['documents']['filed'],'length' )> 0">
        <div class="list__cnt">
          <div class="lca_doc_sec">
            <label v-if="checkProperty(lcaDetails, 'filedDate')"><span>Filed Documents </span> <em>On</em>
              {{ lcaDetails.filedDate | formatDate }}</label>
          </div>
          <div class="lca_doclist">
            <ul>
              <template v-if="lcaDetails['documents']['filed'].length > 0">
                <template v-for="(certified, index) in lcaDetails['documents']['filed']">
                  <li :key="index" v-if="checkProperty(certified, 'status') && checkProperty(certified, 'path')">
                    <div class="file__name" @click="fetchSignedUrl(certified)">
                      <figure>
                        <img v-if="checkFileFormat(certified['mimetype']) == 'pdf'" src="@/assets/images/main/pdf.svg" />
                        <img v-else-if="checkFileFormat(certified['mimetype']) == 'video_mime_types'"
                          src="@/assets/images/main/film.png" />
                        <img v-else-if="checkFileFormat(certified['mimetype']) == 'msDoc'"
                          src="@/assets/images/main/doc.svg" />
                        <img v-else-if="checkFileFormat(certified['mimetype']) == 'zip'"
                          src="@/assets/images/main/zip-file-format.png" />
                        <img v-else-if="checkFileFormat(certified['mimetype']) == 'msPpt'"
                          src="@/assets/images/main/ppt.svg" />
                        <img v-else-if="checkFileFormat(certified['mimetype']) == 'msXl'"
                          src="@/assets/images/main/xls.svg" />
                        <img v-else-if="checkFileFormat(certified['mimetype']) == 'image'"
                          src="@/assets/images/main/image.svg" />
                        <img v-else src="@/assets/images/main/icon-img.svg" />
                      </figure>
                      <a class="certified-name" :title="checkProperty(certified, 'name')">{{ certified.name }}</a>
                    </div>
                  </li>
                </template>
              </template>
            </ul>
          </div>
        </div>
      </div>
      <div class="lca_header_list" v-if="checkProperty(lcaDetails['documents'],'others') && checkProperty(lcaDetails['documents']['others'],'length' )> 0">
        <div class="list__cnt">
          <div class="lca_doc_sec">
            <label><span>Other Documents </span> </label>
              <!-- {{ lcaDetails.filedDate | formatDate }} -->
          </div>
          <div class="lca_doclist">
            <ul>
              <template v-if="lcaDetails['documents']['others'].length > 0">
                <template v-for="(certified, index) in lcaDetails['documents']['others']">
                  <li :key="index" v-if="checkProperty(certified, 'status') && checkProperty(certified, 'path') ">
                    <div class="file__name" @click="fetchSignedUrl(certified)">
                      <figure>
                        <img v-if="checkFileFormat(certified['mimetype']) == 'pdf'" src="@/assets/images/main/pdf.svg" />
                        <img v-else-if="checkFileFormat(certified['mimetype']) == 'video_mime_types'"
                          src="@/assets/images/main/film.png" />
                        <img v-else-if="checkFileFormat(certified['mimetype']) == 'msDoc'"
                          src="@/assets/images/main/doc.svg" />
                        <img v-else-if="checkFileFormat(certified['mimetype']) == 'zip'"
                          src="@/assets/images/main/zip-file-format.png" />
                        <img v-else-if="checkFileFormat(certified['mimetype']) == 'msPpt'"
                          src="@/assets/images/main/ppt.svg" />
                        <img v-else-if="checkFileFormat(certified['mimetype']) == 'msXl'"
                          src="@/assets/images/main/xls.svg" />
                        <img v-else-if="checkFileFormat(certified['mimetype']) == 'image'"
                          src="@/assets/images/main/image.svg" />
                        <img v-else src="@/assets/images/main/icon-img.svg" />
                      </figure>
                      <a class="certified-name" :title="checkProperty(certified, 'name')">{{ certified.name }}</a>
                    </div>
                  </li>
                </template>
              </template>
            </ul>
          </div>
        </div>
      </div>
    </div>
    
    <div class="lca-view-details lca_documents_list_wrap pad0">
      <div class="lca-view-details-bottom mt-0">
        <div class="lca-bottom-content">
          <template v-if="checkProperty(getUserData, 'tenantDetails', 'slug') == 'slg'">
            
            <div class="main-list-wrap">
              <div class="vx-row m-0 main-list-panel"
                v-if="checkProperty(lcaDetails, 'lcaDocCaseNo')">
                <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(lcaDetails, 'lcaDocCaseNo')">
                  <div class="main-list">
                    <p>
                      LCA Case No
                      <span>{{ checkProperty(lcaDetails, 'lcaDocCaseNo')}}</span>
                    

                    </p>
                  </div>
                </div>
              </div>
              <div class="vx-row m-0 main-list-panel" v-if="checkProperty(lcaDetails, 'petitionerDetails', 'name') && isFromLCAList">
                <div class="vx-col md:w-1/2 w-full p-0" >
                  <div class="main-list">
                    <p>
                      Petitioner Name
                      <span>{{ checkProperty(lcaDetails, 'petitionerDetails', 'name') }}</span>
                    </p>
                  </div>
                </div>
              </div>
              <div class="vx-row m-0 main-list-panel" v-if="checkProperty(lcaDetails, 'jobTitle')">
                <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(lcaDetails, 'jobTitle')">
                  <div class="main-list">
                    <p>
                      Job Title
                      <span>{{ lcaDetails.jobTitle | empty }}</span>
                    </p>
                  </div>
                </div>
                <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(lcaDetails, 'preferredSocDetails', 'name')">
                  <div class="main-list">
                    <p>
                      Preferred SOC Code
                      <span>{{ checkProperty(lcaDetails, 'preferredSocDetails', 'name') }}  ({{ checkProperty(lcaDetails, 'preferredSocDetails', 'designation') }})</span>
                    </p>
                  </div>
                </div>
                <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(lcaDetails, 'salary')">
                <div class="main-list">
                  <p>
                    Offered Wage
                    <span>{{ lcaDetails.salary | formatprice }}</span>
                  </p>
                </div>
                </div>
                <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(lcaDetails, 'empStartDate')">
                    <div class="main-list">
                      <p>
                        Employment Start Date
                        <span>{{ lcaDetails.empStartDate | formatDate }}</span>
                      </p>
                    </div>
                </div>
                <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(lcaDetails, 'empEndDate')">
                  <div class="main-list">
                    <p>
                      Employment End Date
                      <span>{{ lcaDetails.empEndDate | formatDate }}</span>
                    </p>
                  </div>
                </div>
                <div class="vx-col w-full p-0" v-if="checkProperty(lcaDetails, 'jobDuties')">
                    <div class="main-list pb-1 minhauto" >
                      <p>Job Duties </p>
                    </div>
                    <div class="editor_view lca_details_view" v-html="lcaDetails.jobDuties"></div>
                </div>
                <div class="vx-col w-full p-0" v-if="!checkProperty(lcaDetails, 'fullTimePosition') && checkProperty(lcaDetails, 'hoursPerWeek')">
                    <div class="main-list pb-1 minhauto" >
                      <p>Hours Per Week for the position</p>
                    </div>
                    <div class="editor_view lca_details_view"  ><p>{{ checkProperty(lcaDetails, 'hoursPerWeek') }}</p></div>
                </div>
              </div>
              <div class="vx-row m-0 main-list-panel">

                <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(lcaDetails,'everPetiWillfulViolator')">
                 <div class="main-list">
                    <p>
                      Has the petitioner ever been found to be a willful violator
                        <span >{{checkProperty(lcaDetails,'everPetiWillfulViolator')}}</span>
                    </p>
                </div>
               </div>
               <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(lcaDetails,'everBenefiWorkOffsiteAtCompOrOrg')">
                 <div class="main-list">
                    <p>
                      Will the beneficiary(ies) work for you off-site at another company or organization's location
                        <span >{{checkProperty(lcaDetails,'everBenefiWorkOffsiteAtCompOrOrg')}}</span>
                    </p>
                </div>
               </div>


                <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(lcaDetails,'invPosiServicesThridPartEntity')">
                 <div class="main-list">
                    <p>
                      Does the position involve providing services to a third party entity
                        <span >{{checkProperty(lcaDetails,'invPosiServicesThridPartEntity')}}</span>
                    </p>
                </div>
               </div>
               <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(lcaDetails,'invPosiBeneficiaryThridPartEntity')">
                 <div class="main-list">
                    <p>
                      Does the position involve beneficiary working for a third party entity
                        <span >{{checkProperty(lcaDetails,'invPosiBeneficiaryThridPartEntity')}}</span>
                    </p>
                </div>
               </div>
               <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(lcaDetails,'invPosiBeneficiaryThridPartEntity')=='Yes' && checkProperty(lcaDetails, 'clientName')">
                  <div class="main-list">
                    <p>
                      Client Name
                      <span>{{ lcaDetails.clientName }}</span>
                    </p>
                  </div>
                </div>
                <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(lcaDetails,'otherEntitiesInvPlacement')">
                 <div class="main-list">
                    <p>
                      Are there any other entities involved in this placement
                        <span >{{checkProperty(lcaDetails,'otherEntitiesInvPlacement')}}</span>
                    </p>
                </div>
               </div>
              </div>
              <div class="vx-col md:w-1/2 w-full p-0"
                  v-if="checkProperty(lcaDetails, 'fullTimePosition')">

                  <div class="main-list">
                    <p>
                      Hours Per Week for the position
                      <span> {{ checkProperty(lcaDetails, 'hoursPerWeek') }}</span>

                    </p>

                  </div>
                </div>
              <template v-if="checkProperty(lcaDetails, 'multiEduDetailsForLCA') == true " >
                <h3 class="small-header mt-0" v-if="checkEducationList">Educations</h3>
                <div v-for="(edu ,eduind) in lcaDetails['educations']" :key="eduind"  class="vx-row m-0 main-list-panel"
                v-if="checkProperty(edu, 'mastersDegree', 'schoolName') || checkProperty(edu, 'mastersDegree', 'major') || checkProperty(edu, 'highestDegreeDetails', 'name')">
                <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(edu, 'mastersDegree', 'schoolName')">
                  <ul class="main-list">
                    <li>
                      <p>University/College/School Name
                        <span>{{ edu.mastersDegree.schoolName | empty }}</span>
                      </p>
                    </li>
                  </ul>
                </div>
                <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(edu, 'highestDegreeDetails', 'name')">
                  <div class="main-list">
                    <p>
                    <!----  Highest Degree--->
                      Qualification
                      <span>{{ checkProperty(edu, 'highestDegreeDetails', 'name') | empty }}</span>
                    </p>
                  </div>
                </div>
                <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(edu, 'mastersDegree', 'major')">
                  <div class="main-list">
                    <p>
                      Major Field of Study
                      <span>{{ edu.mastersDegree.major | empty }}</span>
                    </p>
                  </div>
                </div>

                </div>
                                      
              </template>
              <template v-if="checkProperty(lcaDetails,'invPosiBeneficiaryThridPartEntity')=='Yes' &&  checkProperty(lcaDetails, 'clientName')
              &&  checkProperty(lcaDetails, 'otherEntitiesInvPlacement') == 'Yes'">
              <div class="ep lca"
                v-if="(checkProperty(petition, 'allowToAddLCALayers') || checkProperty(lcaDetails, 'allowToAddLCALayers')) && checkProperty(lcaDetails, 'layerInfo', 'length') > 0 && !checkProperty(lcaDetails, 'internalEmployee')">
                <h3 class="small-header mb-0">Client Relationship for Third Party Placements</h3>
                <div class="vx-row main-list-panel external_employees">
                  <template v-for="(lyer, indexx) in lcaDetails['layerInfo']">

                    <template>
                      <div class="external_employees_list default" :key="indexx"
                        :class="{ 'last-child': checkProperty(lyer, 'layerType') == 'End-client' }">
                        <div class="vx-col  w-full pl-0">
                          <div class="main-list w-full">
                            <p class="w-50">
                              <span>{{ checkProperty(lyer, 'employerName') }}
                                <em>(<template v-if="checkProperty(lyer, 'layerType') == 'Mid-Vendor'"> Mid
                                    Vendor</template>
                                  <template v-else-if="checkProperty(lyer, 'layerType') == 'Prime-Vendor'"> Prime
                                    Vendor</template>
                                  <template v-else>{{ checkProperty(lyer, 'layerType') }}</template>)
                                </em>
                              </span>
                            </p>
                          </div>
                        </div>
                      </div>
                    </template>


                  </template>

                </div>
              </div>
            </template>
              <h3 class="small-header pt-2" v-if="checkProperty(lcaDetails, 'workAddresses', 'length') > 0">Work Location</h3>
                <div class="vx-row m-0 main-list-panel" v-if="checkProperty(lcaDetails, 'workAddresses', 'length') > 0">
                  <div class="vx-col w-full p-0">
                    <div class="dependent-block_wrap address_info_wrap">
                      <div class="dependent-block" v-for="(item, inder) in lcaDetails['workAddresses']" :key="inder">
                        <div class="address_info">
                          <div v-if="checkProperty(item, 'companyName') && checkProperty(item, 'workLocation')" class="dependent-title">
                            <label  class="form_label">{{ checkProperty(item, 'companyName') }} </label>
                          </div>
                          <em v-if="['Employer','Client','Home','Other'].indexOf(checkProperty(item,'workLocation'))>-1">
                            {{formatWorkLocation(item['workLocation'])}} </em>
                          <span class="address" v-html="$options.filters.addressformat(item)"></span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
            </div>
          </template>
          <template v-else>

          
            <template v-if="checkProperty(lcaDetails, 'internalEmployee')">

              <span class="internalemployee">Internal Employee</span>
            </template>
            <div class="main-list-wrap">

              <div class="vx-row m-0 main-list-panel"
                v-if="checkProperty(lcaDetails, 'lcaDocCaseNo')">
                <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(lcaDetails, 'lcaDocCaseNo')">
                  <div class="main-list">
                    <p>
                      LCA Case No
                      <span>{{ checkProperty(lcaDetails, 'lcaDocCaseNo')}}</span>
                    

                    </p>
                  </div>
                </div>
              </div>

              <div class="vx-row m-0 main-list-panel"
                v-if="checkProperty(lcaDetails, 'clientName') || (checkProperty(lcaDetails, 'petitionerDetails', 'name')  && isFromLCAList )">
                <div class="vx-col md:w-1/2 w-full p-0"
                  v-if="checkProperty(lcaDetails, 'petitionerDetails', 'name') && isFromLCAList">

                  <div class="main-list">
                    <p>
                      Petitioner Name
                      <span>{{ checkProperty(lcaDetails,
                        'petitionerDetails', 'name') }}</span>
                    </p>
                  </div>
                </div>
                <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(lcaDetails, 'clientName')">
                  <div class="main-list">
                    <p>
                      End Client Name
                      <span v-if="checkProperty(lcaDetails, 'clientName')">{{ checkProperty(lcaDetails, 'clientName') |
                        empty }}</span>
                      <span v-if="lcaDetails.clientName == '' && (petition.clientInfo && petition.clientInfo.name)">{{
                        petition.clientInfo.name
                        | empty }}</span>

                    </p>
                  </div>
                </div>
              </div>

              <div class="ep lca"
                v-if="(checkProperty(petition, 'allowToAddLCALayers') || checkProperty(lcaDetails, 'allowToAddLCALayers')) && checkProperty(lcaDetails, 'layerInfo', 'length') > 0 && !checkProperty(lcaDetails, 'internalEmployee')">
                <h3 class="small-header mb-0">Client Relationship for Third Party Placements</h3>
                <div class="vx-row main-list-panel external_employees">
                  <template v-for="(lyer, indexx) in lcaDetails['layerInfo']">

                    <template>
                      <div class="external_employees_list default" :key="indexx"
                        :class="{ 'last-child': checkProperty(lyer, 'layerType') == 'End-client' }">
                        <div class="vx-col  w-full pl-0">
                          <div class="main-list w-full">
                            <p class="w-50">
                              <span>{{ checkProperty(lyer, 'employerName') }}
                                <em>(<template v-if="checkProperty(lyer, 'layerType') == 'Mid-Vendor'"> Mid
                                    Vendor</template>
                                  <template v-else-if="checkProperty(lyer, 'layerType') == 'Prime-Vendor'"> Prime
                                    Vendor</template>
                                  <template v-else>{{ checkProperty(lyer, 'layerType') }}</template>)
                                </em>
                              </span>
                            </p>
                          </div>
                        </div>
                      </div>
                    </template>


                  </template>

                </div>
              </div>
              <div class="vx-row m-0 main-list-panel" v-if="checkProperty(lcaDetails, 'jobTitle') || (checkCleintInfo())">

                <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(lcaDetails, 'jobTitle')">
                  <div class="main-list">
                    <p>
                      Job Title
                      <span>{{ lcaDetails.jobTitle | empty }}</span>
                    </p>
                  </div>
                </div>
                <!-- yearsOfExpRequiredForLCA -->
                <div class="vx-col md:w-1/2 w-full p-0"
                  v-if="(checkProperty(petition, 'yearsOfExpRequiredForLCA') != false||checkProperty(lcaDetails, 'yearsOfExpRequiredForLCA') != false ) && (checkProperty(lcaDetails, 'totalExpInYears'))">

                  <div class="main-list">
                    <p>
                      No of years of experience in related field
                      <span> {{ checkProperty(lcaDetails, 'totalExpInYears') }} year(s)</span>

                    </p>
                  </div>
                </div>
                <template v-if="checkProperty(lcaDetails, 'multipleJobDutiesForLCA') && checkProperty( lcaDetails ,'multiJobDuties' ,'length')>0">
                  <h6 class="job_duty_header">Job Duties </h6>
                  

                    <div class="vx-col w-full p-0" >
                      <div class="main-list">
                        <ul class="job_duties_list">
                          <template v-for="( JobDuti ,jind) in lcaDetails['multiJobDuties']" >
                            <li v-html="JobDuti.content"></li>
                          </template>
                        </ul>
                      </div>
                    </div>

                </template>
                <div class="vx-col w-full p-0" v-if="checkProperty(lcaDetails, 'jobDuties')">
                  <div class="main-list pb-1 minhauto" v-if="!checkProperty(lcaDetails, 'multipleJobDutiesForLCA')">
                    <p>Job Duties </p>
                  </div>
                  <div class="editor_view lca_details_view" v-html="lcaDetails.jobDuties"></div>
                </div>
                
                <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(lcaDetails, 'empStartDate')">
                  <div class="main-list">
                    <p>
                      Employment Start Date
                      <span>{{ lcaDetails.empStartDate | formatDate }}</span>
                    </p>
                  </div>
                </div>
                <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(lcaDetails, 'empEndDate')">
                  <div class="main-list">
                    <p>
                      Employment End Date
                      <span>{{ lcaDetails.empEndDate | formatDate }}</span>
                    </p>
                  </div>
                </div>
                <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(lcaDetails, 'wageLevelDetails', 'name')">

                  <div class="main-list">
                    <p>
                      Wage Level
                      <span> {{ checkProperty(lcaDetails, 'wageLevelDetails', 'name') }}</span>

                    </p>

                  </div>
                </div>

                <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(lcaDetails, 'salary')">

                  <div class="main-list">
                    <p>
                      Salary Offered
                      <span>{{ lcaDetails.salary | formatprice }} / {{ checkProperty(lcaDetails, 'payFrequency') }}</span>
                    </p>

                  </div>
                </div>

                
              </div>
              <template v-if="checkProperty(lcaDetails, 'multiEduDetailsForLCA') == true " >
                <h3 class="small-header mt-0" v-if="checkEducationList">Educations</h3>
                <div v-for="(edu ,eduind) in lcaDetails['educations']" :key="eduind"  class="vx-row m-0 main-list-panel"
                v-if="checkProperty(edu, 'mastersDegree', 'schoolName') || checkProperty(edu, 'mastersDegree', 'major') || checkProperty(edu, 'highestDegreeDetails', 'name')">
                <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(edu, 'mastersDegree', 'schoolName')">
                  <ul class="main-list">
                    <li>
                      <p>University/College/School Name
                        <span>{{ edu.mastersDegree.schoolName | empty }}</span>
                      </p>
                    </li>
                  </ul>
                </div>
                <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(edu, 'highestDegreeDetails', 'name')">
                  <div class="main-list">
                    <p>
                    <!----  Highest Degree--->
                      Qualification
                      <span>{{ checkProperty(edu, 'highestDegreeDetails', 'name') | empty }}</span>
                    </p>
                  </div>
                </div>
                <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(edu, 'mastersDegree', 'major')">
                  <div class="main-list">
                    <p>
                      Major Field of Study
                      <span>{{ edu.mastersDegree.major | empty }}</span>
                    </p>
                  </div>
                </div>

                </div>
                                      
              </template>
              <template v-else>
                <h3 class="small-header mt-0">Highest Education</h3>
              <div  class="vx-row m-0 main-list-panel"
                v-if="checkProperty(lcaDetails, 'mastersDegree', 'schoolName') || checkProperty(lcaDetails, 'mastersDegree', 'major') || checkProperty(lcaDetails, 'highestDegreeDetails', 'name')">
                <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(lcaDetails, 'mastersDegree', 'schoolName')">
                  <ul class="main-list">
                    <li>
                      <p>University/College/School Name
                        <span>{{ lcaDetails.mastersDegree.schoolName | empty }}</span>
                      </p>
                    </li>
                  </ul>
                </div>
                <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(lcaDetails, 'highestDegreeDetails', 'name')">
                  <div class="main-list">
                    <p>
                    <!----  Highest Degree--->
                      Qualification
                      <span>{{ checkProperty(lcaDetails, 'highestDegreeDetails', 'name') | empty }}</span>
                    </p>
                  </div>
                </div>
                <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(lcaDetails, 'mastersDegree', 'major')">
                  <div class="main-list">
                    <p>
                      Major Field of Study
                      <span>{{ lcaDetails.mastersDegree.major | empty }}</span>
                    </p>
                  </div>
                </div>

              </div>
            </template>

              <div class="vx-row m-0 main-list-panel"
                v-if="checkProperty(lcaDetails, 'preferredSocDetails', 'name') || checkProperty(lcaDetails, 'preferredSocDetails', 'name') || checkProperty(lcaDetails, 'docref')">

                <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(lcaDetails, 'preferredSocDetails', 'name')">
                  <div class="main-list">
                    <p>
                      Preferred SOC Code
                      <span>{{ checkProperty(lcaDetails, 'preferredSocDetails', 'name') }}  ({{ checkProperty(lcaDetails, 'preferredSocDetails', 'designation') }})</span>
                    </p>
                  </div>
                </div>
                <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(lcaDetails, 'socDetails', 'name')">
                  <div class="main-list">
                    <p>
                      SOC Code

                      <span>{{ checkProperty(lcaDetails, 'socDetails', 'name') }}  ({{ checkProperty(lcaDetails, 'socDetails', 'designation') }})</span>
                    </p>
                  </div>
                </div>

                <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(lcaDetails, 'number')">
                  <div class="main-list">
                    <p>
                      DOL Reference Number
                      <!--  lcaInfo.docref <span >{{lcaDetails.desiredSOCCode | empty}}</span>-->
                      <span>{{ checkProperty(lcaDetails, 'number') }}</span>
                    </p>
                  </div>
                </div>
                <div class="vx-col md:w-1/2 w-full p-0" v-else-if="checkProperty(lcaDetails, 'docref')">
                  <div class="main-list">
                    <p>
                      DOL Reference Number
                      <!--  lcaInfo.docref <span >{{lcaDetails.desiredSOCCode | empty}}</span>-->
                      <span>{{ checkProperty(lcaDetails, 'docref') }}</span>
                    </p>
                  </div>
                </div>
                <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(lcaDetails, 'noOfEmployeeOnYourPayroll')">

                  <div class="main-list">
                    <p>
                      Total No of Employees
                      <span> {{ checkProperty(lcaDetails, 'noOfEmployeeOnYourPayroll') }}</span>

                    </p>
                  </div>
                </div>
                <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(lcaDetails, 'noOfEmployeesOnH1bOrL1')">

                  <div class="main-list">
                    <p>
                      No of Employees On H1B Or L1
                      <span> {{ checkProperty(lcaDetails, 'noOfEmployeesOnH1bOrL1') }}</span>

                    </p>
                  </div>
                </div>

              </div>
              <h3 class="small-header pt-2" v-if="checkProperty(lcaDetails, 'workAddresses', 'length') > 0">Work Location</h3>
              <div class="vx-row m-0 main-list-panel" v-if="checkProperty(lcaDetails, 'workAddresses', 'length') > 0">
                <div class="vx-col w-full p-0">
                  <div class="dependent-block_wrap address_info_wrap">
                    <div class="dependent-block" v-for="(item, inder) in lcaDetails['workAddresses']" :key="inder">
                      <div class="address_info">
                        <div v-if="checkProperty(item, 'companyName') && checkProperty(item, 'workLocation')" class="dependent-title">
                          <label  class="form_label">{{ checkProperty(item, 'companyName') }} </label>
                        </div>
                        <em v-if="['Employer','Client','Home','Other'].indexOf(checkProperty(item,'workLocation'))>-1">
                          {{formatWorkLocation(item['workLocation'])}} </em>
                        <span class="address" v-html="$options.filters.addressformat(item)"></span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </template>
        </div>
      </div>
      <div class="lca-view-details-bottom"
        v-if="lcaDetails.clientName == '' && petition && petition.clientInfo && petition.clientInfo.name">
        <div class="lca-bottom-content">
          <div class="main-list-wrap">
            <div class="vx-row m-0 main-list-panel">
              <div class="vx-col md:w-1/2 w-full p-0">
                <div class="main-list">
                  <p>
                    Name of the Client
                    <span>{{ petition.clientInfo.name | empty }}</span>
                  </p>
                </div>
              </div>
            </div>
            <div class="vx-row m-0 main-list-panel">
              <div class="vx-col md:w-1/2 w-full p-0">
                <div class="main-list">
                  <p>
                    Client Address
                    <span v-html="$options.filters.addressformat(petition.clientInfo.address)"></span>
                  </p>
                </div>
              </div>
              <div class="vx-col md:w-1/2 w-full p-0"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <vs-col vs-type="flex" class="padr0 padl0 mob-right" style="width:350px; position:relative;"
      v-if="showLcaActivity && activityList.length > 0">
      <div class="history-sidebar petition_history">
        <div class="vs-sidebar">
          <div class="petition_updated">Last Updated - {{ checkProperty(lcaDetails, 'updatedOn') | formatDateTime }}</div>
          <div class="vs-sidebar--items">
            <VuePerfectScrollbar class="scroll-area maxheight">
              <div class="timeline-sidebar 2">
                <ul>
                  <li v-for="(history, index) in activityList" :key="index">
                    <div class="timeline-icon">
                      <i class="icon IP-tick-sign"></i>
                    </div>
                    <div class="timeline-info">
                      <button class="btn active-green ml-0">{{ history.createdByRoleName }}</button>
                      <ul>
                        <li>
                          <h3>{{ history.title }}
                            <div class="title_des" v-if="checkProperty(history, 'comment')"><small></small>
                              <div class="dec-content">
                                <p>{{ history.comment }}</p>
                              </div>
                            </div>
                          </h3>
                          <span>{{ history.description }}</span>

                          <span>{{ history.createdOn | formatDateTime }}</span>
                        </li>
                      </ul>
                    </div>
                  </li>
                </ul>
              </div>
            </VuePerfectScrollbar>
          </div>
        </div>
      </div>
    </vs-col>
  </template>
  </div>
</template>
<script>
import * as _ from "lodash";
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import Vue from 'vue'
import VTooltip from 'v-tooltip'
import lcaDocuments from '@/views/lcaDocuments'
import JQuery from "jquery";
Vue.use(VTooltip)

export default {
  components: {
    VuePerfectScrollbar,
    lcaDocuments
  },
  props: {
    workFlowDetails: null,
    showStatusButton: false,
    showLcaActivity: {
      type: Boolean,
      default: true
    },
    currentRole: null,
    lcaDetails: {
      type: Object,
      default: null
    },
    petition: {
      type: Object,
      default: null
    },
    isFromLCAList: {
      type: Boolean,
      default: false
    },
    showStatus: {
      type: Boolean,
      default: true
    },



  },
  computed: {
    checkEditPermission(){
      let returnVal = true;
      let self = this;
      if(self.checkProperty(self.petition, 'completedActivities') && self.checkProperty(self.petition, 'completedActivities', 'length')>0 && 
        self.petition['completedActivities'].indexOf('SUBMIT_TO_LAW_FIRM')>-1){ 
          returnVal = false;
      }
      return returnVal;
    },
    checkLca(){
      let returnVal = true;
      if(this.checkProperty(this.lcaDetails ,'statusDetails') && this.checkProperty(this.lcaDetails ,'statusDetails','id') == 99){
        if(this.checkProperty(this.lcaDetails,'createdBy') == this.checkProperty( this.getUserData ,'userId')){
          returnVal = true;
        }else{
          returnVal = false;
        }
      }
      return returnVal;
    },
    checkEducationList(){
      //lcaDetails['educations']  edu.mastersDegree.schoolName  checkProperty(edu, 'highestDegreeDetails', 'name') checkProperty(edu, 'mastersDegree', 'major')
      let returnValue =false;

      if( this.checkProperty(this.lcaDetails, "educations", 'length') >0){

        let filterData = _.filter(this.lcaDetails['educations'], (edu)=>{
          let schoolName =this.checkProperty(edu,'mastersDegree','schoolName') ;
          let highestDegree  = this.checkProperty(edu, 'highestDegreeDetails', 'name');
          let major = this.checkProperty(edu, 'mastersDegree', 'major');
          if( schoolName.trim() || highestDegree.trim() || major.trim()){
            returnValue = true;
          }

        });

      }

      return returnValue;

    },

    canLcaRequested() {
      let returnVal = false;
      let isAdmin = this.adminsList.indexOf(this.getUserRoleId) > -1


      let wf = _.cloneDeep(this.workFlowDetails);

      if (wf && _.has(wf, "config")) {
        let lcaRequired = _.find(wf["config"], { code: "LCA_REQUEST" });

        if (
          lcaRequired &&
          _.has(lcaRequired, "editors") &&
          _.has(lcaRequired, "actionRequired") &&
          lcaRequired["editors"].length > 0 &&
          lcaRequired.actionRequired == "Yes"
        ) {

          let allEditors = _.filter(lcaRequired["editors"], (ed) => {
            return ed['roleId'] != 50
          })
          let editors = _.map(allEditors, 'roleId');
          returnVal = editors.indexOf(this.getUserRoleId) > -1 || isAdmin;

        }


        return returnVal;
      }


    },
    canLcaSubmit() {
      let returnVal = false;
      let isAdmin = this.adminsList.indexOf(this.getUserRoleId) > -1


      let wf = _.cloneDeep(this.workFlowDetails);

      if (wf && _.has(wf, "config")) {
        let lcaRequired = _.find(wf["config"], { code: "LCA_SUBMIT" });

        if (
          lcaRequired &&
          _.has(lcaRequired, "editors") &&
          _.has(lcaRequired, "actionRequired") &&
          lcaRequired["editors"].length > 0

        ) {

          let allEditors = _.filter(lcaRequired["editors"], (ed) => {
            return ed['roleId'] != 50
          })
          let editors = _.map(allEditors, 'roleId');

          returnVal = editors.indexOf(this.getUserRoleId) > -1 || isAdmin;

        }


        return returnVal;
      }


    },
    checkIsLcaExcuitive() {
      let returnVal = false;
      if ([14].indexOf(this.getUserRoleId) > -1 && (this.checkProperty(this.petition, 'completedActivities', 'length') > 0 && this.petition.completedActivities.indexOf('ASSIGN_LCA_EXECUTIVE') > -1)) {
        returnVal = true;
      }
      return returnVal;
    },
    checkPetitionsDetails(){
      let returnVal = false;
      const currentUrl = window.location.href
      if(currentUrl.includes('/petition-details')){
        returnVal = true;
      }
      return returnVal;
    }
  },
  data: () => ({
    adminsList: [],
    lcaData: null,
    petitionDetails: null,

    msg: 'This is a button.',
    activityList: [],
    showFiles: true

  }),
  mounted() {
    const $ = JQuery;
    $("html, body").animate({ scrollTop: 0 }, 100);
    if (this.showLcaActivity) {

      this.fetchActivityList();
    }
    this.lcaData = this.lcaDetails;
    this.showFiles = false;
    setTimeout(() => {
      this.showFiles = true;
      if (this.workFlowDetails) {
        let adminsactiVityList = _.find(this.workFlowDetails.config, { "code": 'MANAGER_LIST' });
        if (adminsactiVityList && adminsactiVityList.editors) {
          this.adminsList = _.map(adminsactiVityList.editors, 'roleId');
        }
      }
    }, 1000)




  },
  methods: {
    formatWorkLocation(val){
      let returnVal = ''
      if(this.checkProperty(this.getUserData, 'tenantDetails', 'slug') == 'slg'){
        if(val == 'Employer'){
         returnVal = 'Employer Location'
        }
        if(val == 'Client'){
          returnVal = "Beneficiary's home location"
        }
        if(val == 'Other'){
         returnVal = 'Other work locations'
        }
      }else{
      if(val == 'Employer'){
        returnVal = 'Employer Office'
      }
      if(val == 'Client'){
        returnVal = 'Client Office'
      }
      if(val == 'Home'){
        returnVal = 'Home Office'
      }
      if(val == 'Other'){
        returnVal = 'Other'
      }
    }
      return returnVal
    },
    navigateToCaseDetails(item) {
      if (item['_id']) {
        let routedId = item['_id'];
        this.$router.push({ path: `/petition-details/${routedId}` }).catch(err => { })
      }

    },
    navigateToLCADetails(item) {
      if (item['_id']) {
        let routedId = item['_id'];
        this.$router.push({ path: `/lca-inventory-details/${routedId}` }).catch(err => { })
      }

    },
    checkClientName() {
      if (_.has(this.lcaDetails, "clientName") && this.lcaDetails.clientName != null && this.lcaDetails.clientName != '') {
        return true;
      } else {
        return false;
      }
    },

    scrollHandle(evt) {},
    fetchActivityList() {
      this.showLcaActivity = false;
      let postdata = {
        lcaId: this.$route.params.itemId,
        page: 1,
        perpage: 10
      };
      this.$store.dispatch("fetchLCAactivities", postdata).then(response => {
        this.activityList = response.data.result.list;
        this.showLcaActivity = true;
      });
    },
    checkCleintInfo() {
      //petition.clientInfo && petition.clientInfo.name
      if (_.has(this.petition, "clientInfo") && _.has(this.petition['clientInfo'], 'name')) {
        return true;
      } else {
        return false;
      }
    },
    fetchSignedUrl(value) {
      //@download_or_view="download_or_view"
      this.$emit("download_or_view", value);

    }
  }
};
</script>