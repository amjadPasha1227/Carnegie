<template>
  <div class="vx-col w-full mb-base wizard-container">
    <vx-card>
      <vs-popup
        class="popup-accounts"
        title="Your registration is complete."
        :active.sync="SetPassword"
      >
        <div class="popup-accounts-content  popupform">
          <div class="vx-card__title text-left">
            <h2 class="title">Set a Password</h2>
          </div>

          <form autocomplete="off" action="javascript:void(0)" >
            <div v-show="formerrors.msg">
              <p 
                color="warning"
                class="signup_text"
                icon-pack="IntakePortal"
                icon="IP-information-button"
                active="true"
              >
                {{ formerrors.msg }}
              </p>
            </div>

            <div class="login-inputs">

              <div
                class="main-placeholder right "
                style="border-bottom: 1px solid #E7E7E8 !important;"
              >
                <div class="errormsg-support">
                  <vs-input
                    type="password"
                    icon="icon IP-key-1"
                    icon-pack="feather"
                    label-placeholder="Password"
                    v-model="password"
                    class="w-full no-icon-border"
                    name="password"
                    ref="password"
                    v-validate="'required|min:6|max:15|strongpassword'"
                    @keyup.enter.native="updatePassword"
                  />

                </div>
              </div>
              <div class="main-placeholder right">
                <div class="errormsg-support">
                  <vs-input
                    type="password"
                    icon="icon IP-key-1"
                    icon-pack="feather"
                    label-placeholder="Confirm Password"
                    class="w-full no-icon-border"
                    v-validate="'required|min:6|max:15|confirmed:password'"
                    name="confirm_password"
                    data-vv-as="Confirm Password"
                    v-model="confirm_password"
                    @keyup.enter.native="updatePassword"
                  />

                </div>
              </div>
            </div>
            <div class="password_errors"> <span
              class="error-text"
              v-show="errors.has('confirm_password')"
            > Password and Confirm Password values do not match.</span >
              <span
                class="error-text"
                v-show="errors.has('confirm_password')"
              >{{ errors.first("confirm_password") }}</span
              >
            </div>
            <div class="vx-row sign-filled mt-12">
              <div class="vx-col w-full">
                <vs-button @click="updatePassword" class="w-full" type="filled"
                >Update</vs-button
                >
              </div>
            </div>
          </form>
        </div>

        <div class="popup-accounts-footer">
          <div class="password-count">
            <i class="icon IP-lock"></i> Password must contain 6 to 15
            characters
          </div>
          <div class="password-strength"></div>
        </div>
      </vs-popup>
    </vx-card>
  </div>
</template>
<script>
  import { CheckCircleIcon } from "vue-feather-icons";
  export default {
    data() {
      return {
        date: null,
        password: "",
       confirm_password: "",
        SetPassword: true,
        formerrors: {
          msg: ""
        }
      };
    },
    methods: {
      updatePassword() {

        this.$validator.validateAll().then(result => {
          if (result) {
            let Payload= {
              "pin": this.$route.query.key?this.$route.query.key:this.$route.query.forgotPasswordPin,
                //"tenantId": this.$route.query.userId,
              //forgotPasswordPin: this.$route.query.key?this.$route.query.key:this.$route.query.forgotPasswordPin,
                "newPassword":this.password,
                "confirmPassword":this.confirm_password,
                "userId": this.$route.query.userId,
                "action":"set-password"
            }
            if(this.checkProperty(this.$route.query, 'tenantId')){
                Payload = Object.assign(Payload, {tenantId: this.$route.query.tenantId})
            }
            this.$store
              .dispatch("petitioner/set_forgot_password", Payload)
              .then(response => {
                
                if (response.data.status=="Failed") {
                  Object.assign(this.formerrors, {
                    msg: response.data.message
                  });
                } else {
                  this.$vs.notify({
                    text: response.data.message,
                    title: "Success",
                    position:'top-right',
                    color:"success",
                    iconPack: 'feather',
                    icon:'icon-check',

                  });
                  this.SetPassword = false;
                  window.location = '/';
                }
              });



          }
        });
      }
    },
    components: {
      CheckCircleIcon
    }
  };
</script>
