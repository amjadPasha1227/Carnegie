<template>
    <div id="page-login">
       <div class="login_page">
            <div class="login-section"> 
                <div class="hidden md:block login-left">
                    <div class="login_left_cnt">
                        <div class="login_text">
                              <h4>Immigration Practice at Ease</h4>
                        <p>A one stop Case Management System to seamlessly manage your entire immigration practice as an Attorney, Law Firm or Corporate.

</p>
                        </div>
                        <figure><img src="@/assets/images/pages/login_img.svg" alt="login" class="mx-auto d-block"></figure> 
                    </div> 
                </div>
                <div class="login-right d-flex align-center justify-center">
                    <div class="w-full">
                      <div class="vx-card__title">
                          <h4>Resend Activation Link</h4>
                      </div>
                        <form>
                            <div class="text-danger text-sm formerrors" v-if="formerrors && formerrors.msg!=''">
                                <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal" icon="IP-information-button" active="true">
                                    {{ formerrors.msg }}
                                    <span v-if="formerrors.msg == 'Account is not yet activated.'"> Not received the activation email.? <router-link color="primary" to="/resend-link">Request again</router-link> </span>
                                </vs-alert>
                            </div>
                            <div class="text-success text-sm formerrors" v-if="formmessage && formmessage.msg!=''">
                                <vs-alert color="success" class="success-alert reg-success-alert no-border-radius" icon-pack="IntakePortal" icon="IP-information-button" active="true">
                                    {{ formmessage.msg }}
                                </vs-alert>
                            </div>
                            <div class="form-inputs">
                                <div class="errormsg-support">
                                    <label class="form-label">Email ID<em>*</em></label>
                                    <vs-input    
                                    autocomplete="off" autocorrect="off"
                                    v-model="email" class="w-full no-icon-border" data-vv-as="Email" name="email" v-validate="'required|email'" @keyup.enter.native="submitForm" />
                                    <span class="error-text" v-show="errors.has('email')">{{ errors.first("email") }}</span>
                                </div>
                            </div>
                            <vs-button class="w-full primary-btn" @click="submitForm" type="filled">Send</vs-button>
                            <p class="signup_text">Back to <router-link to="/login">Sign In</router-link></p>
                        </form>
                    </div> 
                </div>
            </div>                
       </div>        
    </div>
</template>


<script>
export default {
     data() {
      return {
          email: "",
         message:'',
        message_cls:'',
        formerrors: {
                msg: ""
            },
        formmessage: {
                msg: ""
            },
      };
    },
   methods: {
      changing(){
        this.message='';
          
        Object.assign(this.formerrors, {
          msg: ''
        });
      },
      clearfields() {
        this.email ="";
      },
      submitForm() {
        this.$validator.validateAll().then(result => {
          if(result){
          
            const obj = {
              //apiKey: "FV$HSE@JUGUUGU$J5L@HE",
             tenantId: '',
              email: this.email,
             };
             if(this.$store.getters['common/getTenantId']){
                 obj['tenantId'] =this.$store.getters['common/getTenantId']
             }
            //this.message_cls ="";
           // alert(JSON.stringify(obj))
           this.changing();
            this.$store
              .dispatch("resend", obj)
              .then(response => {
               //alert(JSON.stringify(response.data.message))
                //alert(JSON.stringify(response.error.userId))
               
                   if (response.error) {
                     this.message = response.error.message;
                  Object.assign(this.formerrors, {
                    msg: response.error.message
                  });
                } else {
                  // alert(JSON.stringify(response.data.message))
                  this.email ="";
                  this.$vs.notify({

                    title: "Success",                    
                    position: "top-right",
                    color: "primary",
                    text: response.data.message
                  });
                  this.$validator.reset();
                }
                // this.$router.go('/beneficiaries');
              })
              .catch((err)=>{
                //this.showToster({message:err ,isError:true});
               Object.assign(this.formerrors, { msg: err });

              });

            // if form have no errors
        }
          
        });
      }
    }
};
</script>
