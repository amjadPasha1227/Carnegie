<template>
    <div id="page-login">
      <div slot="no-body" class="login_page">
          <div class="login-section">
              <div class="hidden md:block login-left">
                  <div class="login_left_cnt">
                      <div class="login_text">
                      <h4>Immigration Practice at Ease</h4>
                        <p>A one stop Case Management System to seamlessly manage your entire immigration practice as an Attorney, Law Firm or Corporate.

</p>    </div>
                      <figure><img src="@/assets/images/pages/login_img.svg" alt="login" class="mx-auto"></figure>
                  </div>  
              </div>
              <div class="login-right d-flex align-center justify-center">

                  <div class="w-full">
                    <form action="javascript:void(0)">
                      
                      <div class="vx-card__title">
                        <figure class="IB_logo" v-if="checkProperty(getTenantLogo ,'logo')"><a href="#"><img :src="getTenantLogo['logo']"></a></figure>
                        <figure class="IB_logo IB_logoDefault" v-else ><a href="https://immibox.com/" target="_blank"><img src="@/assets/images/logo/immiBox_logo.svg"></a></figure>

                          <h4>Forgot Password</h4>
                      </div>
                      <div class="text-danger text-sm formerrors" v-show="formerrors.msg">

                          <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal" icon="IP-information-button" active="true">
                            <span v-html="formerrors.msg">  </span>
                          </vs-alert>

                      </div>
                      <div class="form-inputs">
                        <div class="errormsg-support">
                          <label  class="form-label">Email ID<em>*</em></label>
                          <vs-input   v-validate="'required|email'"
                              
                             
                              name='email'   v-model="email"
                               data-vv-as="Email"
                              class="w-full no-icon-border"
                                    v-on:keyup="changing;formerrors.msg=''"  @keyup.enter.native="formerrors.msg='';submitForm"  />
                              <span   class="error-text" v-show="errors.has('email')" >{{ errors.first("email") }}</span>
                        </div>
                        <vs-button class="w-full primary-btn" :disabled="isSubmited"  @click="submitForm" type="filled">Send</vs-button>
                         <p class="signup_text">Back to <router-link to="/login">Sign In</router-link></p> <br/>
                         <span v-bind:style="'color:'+message_cls" class="error-text" v-if="message" >{{ message }}</span>
                            <h6 v-if="getTenantLogo['logo'] != ''" class="powered_text">Powered By <a target="_blank" :href="getPoweredBy">ImmiBox</a></h6> 

                      </div>
                    </form>
                  </div>
                  <!--   -->
              </div>
          </div>
      </div>
    </div>
</template>
<script>
  export default {
    data() {
      return {
        isSubmited:false,
          email: "",
         message:'',
        message_cls:'',
        formerrors: {
                msg: ""
            },
        formmessage: {
                msg: ""
            },
      };
    },
    methods: {
      changing(){
        this.message='';
      },
      clearfields() {
        this.email ="";
        
      },
       
      submitForm() {
        this.$validator.validateAll().then(result => {
          if(result){

            const obj = {
              // apiKey: "FV$HSE@JUGUUGU$J5L@HE",
              // tenantId: this.getTenantId,
              email: this.email,
             };
             this.isSubmited = true;
            this.$store
              .dispatch("forgotpassword", obj)
              .then(response => {
                 this.isSubmited = false;
                   if (response.error) {
                  Object.assign(this.formerrors, {
                    msg: response.error.message
                  });
                } else {
                
                  this.showToster({ message: response.data.message, isError: false });
                  /*
                  this.$vs.notify({
                    title: "Success",                    
                    position: "top-right",
                    color: "primary",
                    text: response.data.message
                  });
                 */ 
                }
                  this.clearfields();
                  this.$validator.reset();
              })
              .catch((err)=>{
                 this.isSubmited = false;
                 Object.assign(this.formerrors, { msg: err });
              });

          
            
          }
              
            
            // if form have no errors
        });
      }
    }
  };
</script>

