<template>
<div id="page-login-wrap">
    
   <template v-if="tenantId">
       <PetitonerRegistration />
   </template>     
    <template v-else>
    <Registration />
   </template> 
</div>
</template>

<script>
import PetitonerRegistration from "./register/Register-Petitioner.vue";
import Registration from "./register/Register.vue";


export default {
    data() {
        return {
         tenantId:null
        };
    },
    methods: {
 
    },
    mounted(){
     this.tenantId = this.$store.getters['common/getTenantId'];


      
    },
    components: {
        PetitonerRegistration,
        Registration
    },
    
};
</script>
