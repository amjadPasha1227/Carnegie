<template>
  <div id="page-login">
    <div class="login_page">
      <div class="login-section">
        <div class="hidden md:block login-left">
          <div class="login_left_cnt">
            <div class="login_text">
              <h4>Immigration Practice at Ease</h4>
              <p>A one stop Case Management System to seamlessly manage your entire immigration practice as an Attorney,
                Law Firm or Corporate.</p>
            </div>
            <figure>
              <img src="@/assets/images/pages/login_img.svg" alt="login" class="mx-auto d-block" />
            </figure>
          </div>
        </div>

        <div class="login-right">
          <div class="login_loader" v-if="loadingLogin">
            <img src="@/assets/images/main/loader.gif">
          </div>
          <div>
            <div class="vx-card__title">
              <figure class="IB_logo" v-if="checkProperty(getTenantLogo, 'logo')"><a href="#"><img
                    :src="getTenantLogo['logo']"></a></figure>
              <figure class="IB_logo IB_logoDefault" v-else><a href="https://immibox.com/" target="_blank"><img
                    src="@/assets/images/logo/immiBox_logo.svg"></a></figure>
              <h4 v-if="tenantsList.length > 0 ||  customersList.length >0">Select Account </h4>
              <h4 v-else>Sign In</h4>

            </div>
            <form>
              <div class="text-danger text-sm formerrors" v-if="formerrors && formerrors.msg != ''">
                <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius"
                  icon-pack="IntakePortal" icon="IP-information-button" active="true">

                  <span v-if="errorCode == 'NOT_VERIFIED'" v-html="formerrors.msg">
                    You haven't set up the password. Please check your email and set up the password. Not received the
                    email.?
                    <!------ <router-link color="primary" to="/resend-link" >Request again</router-link >-->
                  </span>
                  <span v-html="formerrors.msg" v-else></span>
                </vs-alert>
              </div>
              <div class="text-success text-sm formerrors" v-if="formmessage && formmessage.msg != ''">
                <vs-alert color="success" class="success-alert reg-success-alert no-border-radius"
                  icon-pack="IntakePortal" icon="IP-information-button" active="true">
                  {{ formmessage.msg }}
                </vs-alert>
              </div>

              <div class="form-inputs">
                <template v-if="!(tenantsList.length > 0 || customersList.length > 0)">
                  <div class="errormsg-support">
                    <label class="form-label">Email ID<em>*</em></label>
                    <vs-input autocomplete="off" autocorrect="off" v-model="user.email" class="w-full no-icon-border"
                      name="email" v-validate="'required|email'" @keyup.enter.native="submitForm"
                      @keyup="formerrors.msg = ''; errorCode = ''" :disabled="tenantsList.length > 0 || customersList.length> 0 || loadingLogin"
                      data-vv-as="Email ID" />
                    <span class="error-text" v-show="errors.has('email')">{{
                      errors.first("email")
                    }}</span>
                  </div>

                  <div class="errormsg-support">
                    <label class="form-label">Password<em>*</em></label>
                    <vs-input data-vv-as="Password" :type="inputType" autocomplete="off" autocorrect="off"
                      v-model="user.password" class="w-full no-icon-border" name="password" v-validate="'required'"
                      @keyup.enter.native="submitForm" @keyup="formerrors.msg = ''; errorCode = ''"
                      :disabled="tenantsList.length > 0 || customersList.length> 0 ||  loadingLogin" />
                    <!-- <span @mouseover="inputType='text'" @mouseleave="inputType='password'">{{inputType=='text'?'Hide':"SHow"}}</span>-->
                    <span class="error-text" v-show="errors.has('password')">{{
                      errors.first("password")
                    }}</span>
                  </div>
                </template>

                <div class="errormsg-support" v-if="tenantsList.length > 0">
                  <!--<label class="form-label">Select Account<em>*</em></label>-->
                  <multiselect v-model="selectedTenant" :options="tenantsList" :multiple="false" :close-on-select="true"
                    :clear-on-select="false" :select-label="''" :preserve-search="true" placeholder="Select Account"
                    label="name" track-by="name" :preselect-first="false" v-validate="'required'" data-vv-as="Account"
                    name="Account" @input="submitForm">

                    <template slot="selection" slot-scope="{ values, isOpen }">
                      <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }} options
                        selected</span>
                      <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                    </template>
                  </multiselect>
                  <!-- <span @mouseover="inputType='text'" @mouseleave="inputType='password'">{{inputType=='text'?'Hide':"SHow"}}</span>-->
                  <span class="error-text" v-show="errors.has('Account')">{{
                    errors.first("Account")
                  }}</span>
                </div>
                <div class="errormsg-support" v-if="customersList.length > 0 ">
                  <!--<label class="form-label">Select Account<em>*</em></label>-->
                  <multiselect v-model="selectedCompany"
                   :options="customersList" 
                   :multiple="false"
                    :close-on-select="true"
                    :clear-on-select="false" 
                    :select-label="''" 
                    :preserve-search="true"
                     placeholder="Select Company"
                    label="name" 
                    track-by="name"
                     :preselect-first="false"
                      v-validate="'required'" 
                      data-vv-as="Company"
                    name="Company" 
                    @input="submitForm">

                    <template slot="selection" slot-scope="{ values, isOpen }">
                      <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }} options
                        selected</span>
                      <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                    </template>
                  </multiselect>
                  <!-- <span @mouseover="inputType='text'" @mouseleave="inputType='password'">{{inputType=='text'?'Hide':"SHow"}}</span>-->
                  <span class="error-text" v-show="errors.has('Company')">{{
                    errors.first("Company")
                  }}</span>
                </div>
              </div>
              <div v-if="!(tenantsList.length > 0 || customersList.length > 0)" class="flex flex-wrap justify-between my-5 remember-password"
                vs-align="center">
                <vs-checkbox v-model="checkbox_remember_me">Remember me</vs-checkbox>
                <router-link v-if="test" to="/forgot-password">Forgot Password?</router-link>
              </div>
              <!----
                <figure class="loader loader2"><img src="@/assets/images/main/loader.gif" /></figure>
                --->

              <vs-button v-if="tenantsList.length > 0 || customersList.length > 0" class="w-full primary-btn" @click="reloadLogin()"
                type="filled">Cancel</vs-button>

              <template v-if="!(tenantsList.length > 0 ||  customersList.length >0)">
                <vs-button :disabled="loadingLogin" class="w-full primary-btn" @click="submitForm" type="filled">Sign In
                </vs-button>
                <template v-if="getTenantId && getTenantType != 2">
                  <p class="signup_text">
                    Don’t have an account?<br />

                    <router-link to="/register">

                      Register as Customer

                    </router-link>

                  </p>
                </template>
                <template v-else>
                  <p class="signup_text" v-if="getTenantType != 2">
                    <router-link to="/register">Sign Up</router-link> as a Law Firm/Corporate
                  </p>

                </template>
              </template>
              <h6 v-if="getTenantLogo['logo'] != ''" class="powered_text">Powered By <a target="_blank"
                  :href="getPoweredBy">ImmiBox</a></h6>
            </form>
          </div>
          <!-- <div class="login-bottom">
                          <p>Don’t have an account?</p>
                          <router-link class="w-full" to="/register">
                              <vs-button class="w-full" type="border">Sign Up as a Tenant
                              </vs-button>
                          </router-link>
                      </div>
                      <div class="login-bottom">
                          <router-link class="w-full" to="/register-petitioner">
                              <vs-button class="w-full" type="border">Sign Up as a Petitioner
                              </vs-button>
                          </router-link>
                      </div> -->
        </div>
      </div>
    </div>
</div>
</template>

<script>
export default {
  data() {
    return {
      loadingLogin: false,
      selectedTenant: null,
      selectedCompany:null,
      tenantsList: [],
      customersList:[],
      companyId:null,
      tenantId: null,
      user: null,
      initCount: 0,
      errorCode: '',
      inputType: "password",
      test: true,
      user: {
        email: "",
        password: "",
      },
      checkbox_remember_me: false,
      formmessage: {
        msg: "",
      },
      formerrors: {
        msg: "",
      },
    };
  },
  methods: {
    reloadLogin() {
      
      this.selectedTenant = null;
      this.selectedCompany =null;
      this.tenantsList = [];
      this.customersList =[];
      this.user = {
        email: "",
        password: "",
      }
      this.formmessage = {
        msg: "",
      };
      this.formerrors = {
        msg: "",
      };

    },
    showPassword() {
      if (this.inputType == "password") {
      } else {
        this.inputType == "text";
      }
    },

    setCookie(cname = "", cvalue = "", exdays = 1) {
      const d = new Date();
      d.setTime(d.getTime() + exdays * 24 * 60 * 60 * 1000);
      let expires = "expires=" + d.toUTCString();
      document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
    },
    getCookie(cname) {
      let name = cname + "=";
      let decodedCookie = decodeURIComponent(document.cookie);
      let ca = decodedCookie.split(";");
      for (let i = 0; i < ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) == " ") {
          c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
          return c.substring(name.length, c.length);
        }
      }
      return "";
    },
    rememberMe(email = "", pwd = "") {
      
      const timestamp = new Date().getTime(); // current time
      const exp = timestamp + 60 * 60 * 24 * 1000 * 7;

      if (email != "" && pwd != "") {
        //remember_me
        // this.$cookies.set("remember_me", true, exp);
        let userData = { email: email, pwd: pwd, rememberMe: true };
        let encoded = JSON.stringify(userData);
        let enc = window.btoa(encoded);
        this.setCookie("server_Js", enc, 7);
        //let tokenData = JSON.parse(atob(enc))
        //alert(JSON.parse(atob(enc)));
      } else {
        this.setCookie("server_Js", "", 7);
      }

      //let email =this.CryptoJS.AES.decrypt(this.$cookies.get("email"),"FV$HSEDEEPV@JUG" ).toString(this.CryptoJS.enc.Utf8);
    },
    setRemember() {
      let enc = this.getCookie("server_Js");

      if (enc) {
        let tokenData = JSON.parse(atob(enc));

        if (tokenData.email) {
          this.user.email = tokenData.email;
        }
        if (tokenData.pwd) {
          this.user.password = tokenData.pwd;
        }

        if (
          tokenData.pwd &&
          tokenData.pwd != "" &&
          tokenData.email &&
          tokenData.email != "" &&
          (tokenData.rememberMe == true || tokenData.rememberMe == "true")
        ) {
          this.checkbox_remember_me = true;
        } else {
          this.setCookie("server_Js", "", 7);
        }
      }
    },

    clearfields() {
      Object.assign(this.user, {
        email: "",
        password: "",
      });
    },
    requestAgain() {
      this.$vs.loading();
      const obj = {
        apiKey: "FV$HSE@JUGUUGU$J5L@HE",
        tenantId: this.getTenantId,
        email: this.user.email,
      };

      Object.assign(this.formerrors, {
        msg: "",
      });
      Object.assign(this.formmessage, {
        msg: "",
      });
      this.$store
        .dispatch("petitioner/requestactivationEmail", obj)
        .then((response) => {
          this.$vs.loading.close();
          Object.assign(this.formerrors, {
            msg: "",
          });
          Object.assign(this.formmessage, {
            msg: "",
          });
          if (response.error) {
            Object.assign(this.formerrors, {
              msg: response.error.message,
            });
          } else {
            Object.assign(this.formmessage, {
              msg: response.data.result.message,
            });
          }
        })
        .catch(() => { });
    },
    submitForm() {

      this.errorCode = '';
      Object.assign(this.formerrors, {
        msg: "",
      });
      Object.assign(this.formmessage, {
        msg: "",
      });
      //this.customersList = [];
      this.$validator.validateAll().then((result) => {
        console.log(this.errors);
        let temPvalidator =false;
        if ((this.selectedTenant && _.has(this.selectedTenant, 'id')) || (this.selectedCompany && _.has(this.selectedCompany, 'companyId')) ) {
          if((this.selectedCompany && _.has(this.selectedCompany, 'companyId'))){
            if(this.selectedTenant && _.has(this.selectedTenant, 'id') && this.user.email && this.user.password){
              temPvalidator =true;
            }
          }else{
            if(this.selectedTenant && _.has(this.selectedTenant, 'id') &&  this.user.email && this.user.password){
              temPvalidator =true;
            }
          }
        }
        if (result || temPvalidator) {
          let _tid = this.$store.getters['common/getTenantId'];
          let obj;
          if (_tid != null) {
            obj = {
              apiKey: "FV$HSE@JUGUUGU$J5L@HE",
              email: this.user.email,
              password: this.user.password,
              tenantId: this.$store.getters['common/getTenantId'],
              companyId:'',
            };

          } else {
            obj = {
              apiKey: "FV$HSE@JUGUUGU$J5L@HE",
              email: this.user.email,
              password: this.user.password,
              companyId:'',
            };

          }
          if (this.selectedTenant && _.has(this.selectedTenant, 'id')) {
            obj = Object.assign(obj, { "tenantId": this.selectedTenant['id'] })

          }
           else {
            this.tenantsList = [];
          }
          if(this.selectedCompany && _.has(this.selectedCompany, 'companyId')){
            obj = Object.assign(obj, { "companyId": this.selectedCompany['companyId'] })
            
          }
          else {
            this.customersList = [];
          }
          this.loadingLogin = true;
          this.$store
            .dispatch("login", obj)
            .then((response) => {

              if (response.error) {
                this.tenantsList = [];
                this.customersList =[];
                this.selectedTenant = null;
                this.selectedCompany = null;
                if (_.has(response.error, "message")) {
                  Object.assign(this.formerrors, {
                    msg: response.error.message,
                  });
                } else {
                  Object.assign(this.formerrors, {
                    msg: response.error.error,
                  });
                }
                //this.errorCode ='';
                //alert(JSON.stringify(response.error['code']))
                if (_.has(response.error, 'code')) {
                  this.errorCode = response.error['code'];

                }

              } else {
                this.customersList =[];
                if (this.checkbox_remember_me) {
                  this.rememberMe(this.user.email, this.user.password);
                } else {
                  this.rememberMe("", "");
                }
                const user = response.data.result.data;
                if((_.has(user, 'accounts') && user.accounts.length > 0) || _.has(user, 'companies') && user.companies.length > 0){
                if (_.has(user, 'accounts') && user.accounts.length > 0) {
                  this.tenantsList = user.accounts;
                } 
                if(_.has(user, 'companies') && user.companies.length > 0){
                  this.customersList = user.companies;
                }
              }
                else {

                  let useData = this.checkProperty(response['data'], 'result', 'data');
                  let host = window.location.host;
                  let protocol = window.location.protocol;
                  const parts = host.split('.');


                  if (this.checkProperty(parts, 'length') == 2 && useData && [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14].indexOf(this.checkProperty(useData, 'roleId')) > -1 && this.checkProperty(useData, 'tenantDetails', 'slug')) {
                    //redirect to client domain
                    let app = 'immibox.com/login'
                    if (['anyclap'].indexOf(parts[0]) > -1) {
                      app = "anyclap.com/login";

                    }
                    let url = "https://" + useData['tenantDetails']['slug'] + '.' + app + "?accessToken=" + useData['accessToken'];
                    //let url ="https://"+useData['tenantDetails']['idPrefix']+"'.immibox.com/"+app+"accessToken="+useData['accessToken'];


                    this.$store.dispatch('logout').then((res) => {
                      window.location = url;

                    }).catch((err) => {
                      this.$router.push("/");
                    })

                  } else {
                    if ([51].indexOf(this.checkProperty(useData, 'roleId')) > -1
                      && this.checkProperty(useData, 'capCaseCount')
                      && useData.capCaseCount > 0) {
                      this.$router.push("/cap-registrations");
                    } else {
                      this.$router.push("/");
                    }
                    // this.$router.push("/");
                  }
                  //this.$router.push("/");

                }

              }
              this.loadingLogin = false;
            })
            .catch((err) => {
              this.loadingLogin = false;
              this.errorCode = '';
              Object.assign(this.formerrors, {
                msg: err,
              });
              this.tenantsList = [];
              this.customersList =[];
              this.selectedTenant = null;
              this.selectedCompany = null;
            });

          // if form have no errors
        } else {
          this.loadingLogin = false;
          // form have errors
        }
      });
    },
  },
  mounted() {

    
    //  this.$router.currentRoute['meta']['getTokenFromUrl'] =true;
    

    if (this.checkProperty(this.$route, 'query', 'accessToken')) {
      this.loadingLogin = true;
      setTimeout(() => {
        let postData = { 'accessToken': '' };
        postData['accessToken'] = this.checkProperty(this.$route, 'query', 'accessToken');
        this.$store.dispatch("loginFromAccessToken", postData).then((res) => {

          this.$router.push("/dashboard");



        }).catch((err) => {
          this.loadingLogin = false;
        });

      }, 1)
    } else {

      this.setRemember();

    }




  },
  watch: {
    checkbox_remember_me: function (value) {

      if (this.initCount > 0 && !value) {
        this.rememberMe()
      }
      this.initCount++;
    }

  }

};
</script>
