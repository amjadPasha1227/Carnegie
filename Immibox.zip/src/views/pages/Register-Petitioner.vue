<template>
    <div id="page-login">
        <div class="login-support-wrap">
            <div slot="no-body" class="login_page">
                <div class="login-section">
                    <div class="hidden md:block login-left">
                        <div class="login_left_cnt">
                            <div class="login_text">
                                <h4>Immigration Practice at Ease</h4>
                                <p>A one stop Case Management System to seamlessly manage your entire immigration
                                    practice as an Attorney, Law Firm or Corporate.

                                </p>
                            </div>
                            <figure><img src="@/assets/images/pages/login_img.svg" alt="login" class="mx-auto d-block">
                            </figure>
                        </div>
                    </div>
                    <div class="login-right">
                        <div>
                            <div class="vx-card__title">
                                <h4>Sign Up as a <br />Customer</h4>
                            </div>
                            <div class="text-danger text-sm formerrors" v-show="formerrors.msg">
                                <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius"
                                    icon-pack="IntakePortal" icon="IP-information-button" active="true">
                                    {{ formerrors.msg }}
                                </vs-alert>
                            </div>



                            <div class="form-inputs">
                                <div class="errormsg-support">
                                    <label class="form-label">Company Name<em>*</em></label>
                                    <vs-input autocomplete="off" autocorrect="off" type="text"
                                        class="w-full no-icon-border" name="name" data-vv-as="Company Name"
                                        v-model="petitioner.name" v-validate="'required'" />
                                    <span class="error-text" v-show="errors.has('name')">{{ errors.first("name")
                                        }}</span>
                                </div>
                                <div class="errormsg-support">
                                    <label class="form-label">Phone Number<em>*</em></label>
                                    <div class="vs-component vs-con-input-label vs-input w-full vs-input-primary">
                                        <div class="vs-con-input">
                                            <VuePhoneNumberInput icon-pack="feather" class="w-full no-icon-border"
                                                :disabled-fetching-country="true" :no-example="false"
                                                v-validate="'required'" name="phone" data-vv-as="Phone Number"
                                                v-bind="vuePhone.props" default-country-code="US"
                                                placeholder="Phone Number" :no-country-selector="false"
                                                v-model="petitioner.phone" @update="updatePhone" 
                                                :preferred-countries="['US', 'IN']"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="errormsg-support">
                                    <label class="form-label">Email ID<em>*</em></label>
                                    <vs-input autocomplete="off" autocorrect="off" v-model="petitioner.email"
                                        class="w-full no-icon-border" name="email" autocapitalize="none"
                                        v-validate="'required|email'" data-vv-as="Email" />
                                    <span class="error-text" v-show="errors.has('email')">{{ errors.first("email")
                                        }}</span>
                                </div>
                                <div class="errormsg-support">
                                    <label class="form-label">Password<em>*</em></label>
                                    <vs-input autocomplete="off" autocorrect="off" type="password"
                                        v-model="petitioner.password" class="w-full no-icon-border" name="password"
                                        ref="password" autocapitalize="none"
                                        v-validate="'required|min:6|max:15|strongpassword'" data-vv-as="Password" />
                                    <span class="error-text" v-show="errors.has('password')">{{ errors.first("password")
                                        }}</span>
                                </div>
                                <div class="errormsg-support">
                                    <label class="form-label">Confirm Password<em>*</em></label>
                                    <vs-input autocomplete="off" autocorrect="off" type="password"
                                        class="w-full no-icon-border"
                                        v-validate="'required|min:6|max:15|confirmed:password'" name="confirm_password"
                                        data-vv-as="Confirm Password" v-model="petitioner.confirm_password" />
                                    <span class="error-text static" v-show="errors.has('confirm_password')">Password and
                                        Confirm Password values do not match.</span>
                                </div>
                                <vs-button class="w-full primary-btn" type="filled" @click="submitForm">Sign Up
                                </vs-button>
                                <p class="signup_text">Already have an account?<router-link to="/login">Sign In
                                    </router-link>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <vs-popup class="holamundo success-popups" title="Lorem ipsum dolor sit amet" :active.sync="popupActive">
            <figure>
                <img src="@/assets/images/main/icon-sent.svg" alt="login" class="mx-auto" />
            </figure>
            <h2 class="title">Thank you for your interest in ImmiBox.</h2>
            <p>
                Please follow the instructions sent to your email to complete your account.
            </p>
            <a href="/login"><i class="IP-arrow-pointing-to-right"></i> Back to Sign In</a>
        </vs-popup>
    </div>
</template>

<script>
import VuePhoneNumberInput from 'vue-phone-number-input';
import 'vue-phone-number-input/dist/vue-phone-number-input.css';
import _ from "lodash";
export default {
    data() {
        return {
            petitioner: {
                name: "",
                adminFirstName:"",
                adminLastName:"",
                email: "",
                phoneCountryCode:{countryCode:'',countryCallingCode:''},
                phone:"",
                password: "",
                confirm_password: "",
                
            },
            vuePhone:{
                props:{
                translations:{
                    phoneNumberLabel:"Phone Number"
                }
             }

      },
            popupActive: false,
            petitionersignup: [],
            formerrors: {
                msg: ""
            }
        };
    },
    methods: {
         updatePhone(item) {
         
       
      if (item.isValid) {
        
       this.petitioner.phoneCountryCode = {countryCode:item.countryCode,countryCallingCode:item.countryCallingCode}; 
       this.petitioner.phone = item.nationalNumber;
       
      }
    },
            clearfields() {

            Object.assign(this.petitioner, {
                name:"",
                // adminFirstName: "",
                // adminLastName:"",
                phone:"",
                email: "",
                password: "",
                confirm_password:""
            });
            this.$validator.reset();
        },
        submitForm() {
            this.$validator.validateAll().then(result => {
                
                if (result) {
                    const obj = {
                        //apiKey: this.$globalgonfig._APIKEY,
                        //petitionerId: this.$globalgonfig._petitionerID,
                        name: this.petitioner.name,
                        email: this.petitioner.email,
                        password: this.petitioner.password,
                        //adminFirstName: this.petitioner.adminFirstName,
                        //adminLastName: this.petitioner.adminLastName,
                        phone: this.petitioner.phone,
                        phoneCountryCode:this.petitioner.phoneCountryCode,
                        roleId:12
                       

                    };
                    //alert(JSON.stringify(obj))
                    this.$store.dispatch("petitionerregister", obj).then(response => {
                        //alert(JSON.stringify(response))

                            if (response.error) {
                                Object.assign(this.formerrors, {
                                    msg: response.error.message
                                });
                            } else {
                                this.clearfields();
                                this.popupActive = true;
                            }
                        })
                        .catch(() => {});

                    // if form have no errors
                } else {
                    // form have errors
                }
            });
        }
    },
    components: {
        VuePhoneNumberInput
    },
    
};
</script>
