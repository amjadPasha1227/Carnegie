<template>
    <div id="page-login">
      <div slot="no-body" class="login_page">
        <div class="login-section">
          <div class="hidden md:block login-left">
            <div class="login_left_cnt">
              <div class="login_text">
                <h4>Immigration Practice at Ease</h4>
                <p>
                  A one stop Case Management System to seamlessly manage your entire immigration practice as an Attorney, Law Firm or Corporate.
                </p>
              </div>
              <figure>
                <img
                  src="@/assets/images/pages/login_img.svg"
                  alt="login"
                  class="mx-auto"
                />
              </figure>
            </div>
          </div>
          <div class="login-right d-flex align-center justify-center">
            <div class="w-full">
              <form action="javascript:void(0)">
                <div class="vx-card__title">
                  <figure
                    class="IB_logo text-center"
                    v-if="checkProperty(getTenantLogo, 'logo')"
                  >
                    <a href="#"><img :src="getTenantLogo['logo']" /></a>
                  </figure>
                  <figure class="IB_logo IB_logoDefault setpassword_logo" v-else>
                    <a href="https://immibox.com/" target="_blank"
                      ><img src="@/assets/images/logo/immiBox_logo.svg"
                    /></a>
                  </figure>
                  <h4 v-if="$route.query.createCase == 'true' || $route.query.createCase == true"> Create I-140</h4>
                  <h4 v-else >Reason for not filling I-140.</h4>
                </div>
              
                
               
                <template>
                  <div class="form-inputs">
                    <div class="errormsg-support">
                        <span>
                          
                          </span>
                     </div>
                     <template v-if="showNoTemplate" >
                      <form data-vv-scope="resonForm">
                        <div class="form_group">
                        <div class="form-inputs">
                          <div v-if="$route.query.createCase == 'true' || $route.query.createCase == true"  class="vx-col  w-full con-select">
                          
                            <label class="typo__label">Select Category<em>*</em></label>
                            <multiselect  v-model="selectedCategory" :options="categoryList" :multiple="false"
                              :hideSelected="true" :close-on-select="true" :clear-on-select="false" :preserve-search="true"
                              placeholder="Category" label="name" track-by="name" :preselect-first="false"
                              v-validate="'required'" data-vv-as="Category" name="Category">
                              
                              
                            </multiselect>
                            <span class="text-danger text-sm"  v-show="errors.has('resonForm.Category')"   >{{ errors.first("resonForm.Category") }}</span>
                          
                          </div>

                          <div v-else class="vx-col  w-full con-select">
                          
                            <label class="typo__label">Select Reason<em>*</em></label>
                            <multiselect  v-model="selectedReason" :options="reasonsList" :multiple="false"
                              :hideSelected="true" :close-on-select="true" :clear-on-select="false" :preserve-search="true"
                              placeholder="Reason" label="name" track-by="name" :preselect-first="false"
                              v-validate="'required'" data-vv-as="Reason" name="Reason">
                              
                              
                            </multiselect>
                            <span class="text-danger text-sm"  v-show="errors.has('resonForm.Reason')"   >{{ errors.first("resonForm.Reason") }}</span>
                          
                          </div>

                          

                         
                        
                      </div>
                      

                      <div class="form-inputs mt-5"   v-if="checkProperty(selectedReason ,'id') ==4"  >
                             <div class="vx-col  w-full " >
                           
                              <label class="form_label">Comments<em>*</em></label>
                              <!-- <vs-textarea name="Comments" v-model="otherComments"  v-validate="'required'"  class="w-full" :data-vv-as="'Comments'" /> -->
                              <ckeditor name="Comments" v-model="otherComments"  v-validate="'required'"  class="w-full" :data-vv-as="'Comments'"  :editor="editor" :config="editorConfig"></ckeditor>
                              <span  class="text-danger text-sm"  v-show="errors.has('resonForm.Comments')"   ><em>* </em>Comments are required</span>
                        
                            </div>
                      </div>

                      <div class="popup-footer">
                        
                          <vs-button color="dark" @click="gotoDetails()" class="cancel" type="filled">
                            Cancel
                            
                          </vs-button>
                            <vs-button  color="success"  v-if="$route.query.createCase == 'true' || $route.query.createCase == true"   class="save"     type="filled"   @click="updateI140('Yes')"    >Submit</vs-button>
                            <vs-button  color="success"   v-else  class="save"     type="filled"   @click="updateI140('No')"    >Submit</vs-button>
                            
                      </div>
                      
                      </div>
                      </form>
                     </template>
                     <div v-if="errorMessage != ''">
                     <div class="text-danger text-sm formerrors" v-if="isErrorMsg">
                      <vs-alert color="warning" class="primary-alert login_alert warning" icon-pack="IntakePortal"
                        icon="IP-information-button" active="true">{{ errorMessage }}</vs-alert>
                    </div>
                    <div class="text-danger text-sm formerrors" v-else>
                      <vs-alert color="warning" class="primary-alert login_alert" icon-pack="IntakePortal"
                        icon="IP-information-button" active="true">{{ errorMessage }}</vs-alert>
                    </div>
                  </div>
                     <p v-if="errorMessage != ''" class="signup_text cursor-pointer"> <a @click="gotoDetails()" >View Details</a></p> <br/>
                    <span v-bind:style="'color:'+message_cls" class="error-text" v-if="message" >{{ message }}</span>
                     <h6 v-if="getTenantLogo['logo'] != ''" class="powered_text">Powered By <a target="_blank" :href="getPoweredBy">ImmiBox</a></h6>
                  </div>
                </template>
               
              </form>
            </div>
           
          </div>
        </div>
      </div>
    </div>
  </template>
  
  <script>
  import _ from "lodash";
  import Vue from 'vue';
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';

 
  export default {
    data() {
      return {
        editor: ClassicEditor,
 editorConfig: {
     toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
 },
        categoryList:[],
        selectedCategory:null,
        errorMessage:'',
        isErrorMsg:false,
        otherComments:'',
        showNoTemplate:true,
        hideSubmit:false,
        selectedId:'',
        reasonsList:[],
        selectedReason:'',
        hideTemplate:true,
        showMe: false,
        message_cls:'',
        message:'',
        something:'',
        nothing:'',
        formerrors: {
          msg: "",
        },
        isItPetition:false,
       
     
      };
    },
    methods: {
      gotoDetails(){
        this.errorMessage = '';
        if(this.$route.query.createCase == 'true' || this.$route.query.createCase == true){
          this.$router.push({ name: 'petition-details', params: { itemId:this.selectedId} })
        }
        else{
          this.$router.push({ name: 'gc-employment-details', params: { itemId:this.selectedId} })
        }
        
      },
        updateI140(item){
          this.isItPetition = false;
          this.errorMessage = '';
            this.formerrors.msg ='';
            this.$validator.validateAll('resonForm').then((result) => {
             
              
              if(result ){
                let postData ={
              petitionId:'', //"614ac61a1a16001d5de5581c", // Perm Application ID
               createCase:true, // true, // false // Send 'true' for creating I-140 and send 'false' for not creating
               "otherComments":'',
            };
           
            if(item == 'No'){
              postData['createCase'] = false;
              postData['reason'] = this.checkProperty(this.selectedReason,'id');
              postData['reasonName'] = this.checkProperty(this.selectedReason,'name');
              postData['otherComments'] = this.otherComments;

              
            }else{
              postData['categoryId'] = this.checkProperty(this.selectedCategory,'id');

            }
           
            if(this.selectedId){
              postData['petitionId'] = this.selectedId;
            }
            this.$vs.loading();
            this.$store
              .dispatch("commonAction", {"data":postData ,"path":"perm/confirm-i140-creation"})
              .then(response => {
                this.$vs.loading.close();
                let responseId = null
                if(item == 'Yes'){
                  if(this.checkProperty(response,'_id')){
                    this.selectedId = this.checkProperty(response,'_id')
                    this.isErrorMsg = false
                    this.isItPetition = true
                    //this.$router.push({ name: 'petition-details', params: { itemId:responseId} })
                  }else{
                    this.isItPetition = false;
                    this.isErrorMsg = false
                    //this.$router.push({ name: 'gc-employment-details', params: { itemId:this.selectedId} })
                  }
                }
                else{
                  this.isItPetition = false;
                  this.isErrorMsg = false
                  //this.$router.push({ name: 'gc-employment-details', params: { itemId:this.selectedId} })
                }
                this.errorMessage = response.message
                this.isItPetition = false;
                //this.showToster({message:response.message,isError:false }); 
                this.isErrorMsg = false
                this.showMe=false;   
                this.showNoTemplate =false;          
              })
              .catch((error)=>{
                this.isItPetition = false;
                this.isErrorMsg = true
                this.$vs.loading.close();
                 this.errorMessage = error
                this.showMe=false;
                this.showNoTemplate =false;     
              })  

              }
            })

          
             
           },
      
        get_reasons(){
            let item ={
                  category: "i140_not_create_reason",
            };
            this.$store.dispatch("getMasterData",item ).then(response => {   
            this.reasonsList = response.list;
        });
       },
       getCategoryForCase(){
        let item ={
          page:1,
          perpage: 10000,
          category: "case_category",  
        }
        this.$store.dispatch("getMasterData",item ).then(response => {  
           this.categoryList = response.list;  
        })
       }
  },
  mounted() {
    this.getCategoryForCase();
      if(this.$route.query.petitionId){
        this.selectedId = this.$route.query.petitionId;
      }
      
        this.showNoTemplate = true;
        this.get_reasons();
       
      
      //if (_.has(this.$route.query, "createCase"))
      //alert(this.$route.query.createCase=true)
      
    },
  };
  </script>
  