<template>
  <div class="vx-col w-full mb-base wizard-container">
    <vx-card>

    
      <vs-popup class="holamundo success-popups" title="Lorem ipsum dolor sit amet" :active.sync="SetPassword">
        
        
           
              <figure>
                  <img src="@/assets/images/main/icon-sent.svg" alt="login" class="mx-auto" />
              </figure>
               <template v-if="!isError" >
                  <h2 class="title">Email is verified successfully.</h2>
                  <p>
                   We are currently reviewing your details and shall get in touch with you shortly.
                </p>
                 
             </template>

             <div class="text-danger text-sm formerrors"  v-if="isError">
              <vs-alert
                color="warning"
                class="warning-alert reg-warning-alert no-border-radius"
                icon-pack="IntakePortal"
                icon="IP-information-button"
                active="true"
              >
                {{ formerrors.msg }}
              </vs-alert>
            </div>
                          
                          <span @click="SetPassword=false;">  <router-link to="/login">

            <i class="IP-arrow-pointing-to-right"></i> Back to Sign In
                            </router-link></span>

    </vs-popup>
    </vx-card>
  </div>
</template>
<script>
  import { CheckCircleIcon } from "vue-feather-icons";
  export default {
    data() {
      return {
        date: null,
        password: "",
       confirm_password: "",
        SetPassword: false,
        isError:false,
        formerrors: {
          msg: ""
        }
      };
    },
    methods: {
      acicateEmail() {

        
            let Payload= {
             // apiKey: "FV$HSE@JUGUUGU$J5L@HE",
              tenantId: this.$route.query.tenantId,
              pin: this.$route.query.activationPin,
              userId: this.$route.query.userId,
              action:"set-password"
            }
            //alert(JSON.stringify(Payload));

            this.SetPassword =false;
            this.isError =false;
            Object.assign(this.formerrors, {
                    msg: ''
                  });
           

            this.$store
              .dispatch("verifyTenantEmail", Payload)
              .then(response => {
                this.$vs.loading.close();
                if (response.status=="Failed") {
                  Object.assign(this.formerrors, {
                    msg: response.message
                  });
                   this.isError =true;
                } else {
                   this.isError = false;
                  this.$vs.notify({
                    text: response.message,
                    title: "Success",
                    position:'top-right',
                    color:"success",
                    iconPack: 'feather',
                    icon:'icon-check',

                  });
                  
                 
                }
                this.SetPassword = true;
              })
              .catch((err) => {
                this.isError =true;
                 this.$vs.loading.close();
                  this.SetPassword = true;
                  Object.assign(this.formerrors, {
                    msg: err
                  });
              });



          
      }
    },
    components: {
      CheckCircleIcon
    },
    mounted(){
       this.$vs.loading();
       this.acicateEmail()
    }
  };
</script>
