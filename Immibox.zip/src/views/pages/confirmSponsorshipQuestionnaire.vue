<template>
    <div id="page-login">
      <div slot="no-body" class="login_page">
        <div class="login-section">
          <div class="hidden md:block login-left">
            <div class="login_left_cnt">
              <div class="login_text">
                <h4>Immigration Practice at Ease</h4>
                <p>
                  A one stop Case Management System to seamlessly manage your entire immigration practice as an Attorney, Law Firm or Corporate.
                </p>
              </div>
              <figure>
                <img
                  src="@/assets/images/pages/login_img.svg"
                  alt="login"
                  class="mx-auto"
                />
              </figure>
            </div>
          </div>
          <div class="login-right d-flex align-center justify-center">
            <div class="w-full">
              <form action="javascript:void(0)">
                <div class="vx-card__title">
                  <figure
                    class="IB_logo text-center"
                    v-if="checkProperty(getTenantLogo, 'logo')"
                  >
                    <a href="#"><img :src="getTenantLogo['logo']" /></a>
                  </figure>
                  <figure class="IB_logo IB_logoDefault setpassword_logo" v-else>
                    <a href="https://immibox.com/" target="_blank"
                      ><img src="@/assets/images/logo/immiBox_logo.svg"
                    /></a>
                  </figure>
  
                  <h4>Sponsorship  Confirmation</h4>
                </div>
               <template>
                  <div class="form-inputs">
                    <div class="errormsg-support">
                        <span>
                          confirm sponsorship questionnaire
                          </span>
                     </div>
                     <!-- v-if="isErrorMsg" -->
                     <div v-if="responseMsg != ''">
                     <div class="text-danger text-sm formerrors" v-if="isErrorMsg" >
                      <vs-alert color="warning" class="primary-alert login_alert warning" icon-pack="IntakePortal"
                        icon="IP-information-button" active="true">{{ responseMsg }}</vs-alert>
                    </div>
                    <div class="text-danger text-sm formerrors" v-else >
                      <vs-alert color="warning" class="primary-alert login_alert" icon-pack="IntakePortal"
                        icon="IP-information-button" active="true">{{ responseMsg }}</vs-alert>
                    </div>
                  </div> 
                   
                      <p v-if="responseMsg !=''" class="signup_text cursor-pointer "><a @click="goToLink()">View Details</a></p> <br/>
                     <span v-bind:style="'color:'+message_cls" class="error-text" v-if="message" >{{ message }}</span>
                     <h6 v-if="getTenantLogo['logo'] != ''" class="powered_text">Powered By <a target="_blank" :href="getPoweredBy">ImmiBox</a></h6>
                     </div>       
                </template>
              </form>
            </div>
           
          </div>
        </div>
      </div>
    </div>
  </template>
  
  <script>
  import _ from "lodash";

 
  export default {
    data() {
      return {
        selectedItem:'',
        message:'',
        responseMsg:'',
        isErrorMsg:false
      };
    },
    methods: {
      goToLink(){
        this.responseMsg ='';
        this.$router.push({ name: 'gc-employment-details', params: { itemId:this.selectedItem } })
      },
        approvePwd(item){
          this.responseMsg ='';
        let postData ={
          "petitionId":[],
          "sponsorshipQuestionnaireSubmitted":false,
        };
        
          postData['sponsorshipQuestionnaireSubmitted'] =  true;
        
        if( this.selectedItem ){
          postData['petitionId'] =  this.selectedItem;
        }
        this.$vs.loading();
          this.$store
          .dispatch("commonAction", {"data":postData ,"path":"/perm/confirm-sponsorship-questionnaire"})
          .then(response => {
            this.$vs.loading.close();
           this.responseMsg = response.message
           this.isErrorMsg = false
            //this.showToster({message:response.message,isError:false });  
            //this.$router.push({ name: 'gc-employment-details', params: { itemId:this.selectedItem} })         
          })
          .catch((error)=>{ 
            this.$vs.loading.close();
            this.responseMsg = error
            this.isErrorMsg = true
          // this.showToster({message:error,isError:true }); 
          //this.$router.push({ name: 'gc-employment-details', params: { itemId:this.selectedItem} })    
          })   
        },
      },
      mounted() {
       
        if(this.$route.query.petitionId){
          this.selectedItem = this.$route.query.petitionId;
          this.approvePwd();
        }
      },
  };
  </script>
  