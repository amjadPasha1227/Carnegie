<template>
  <div class="form_page">
    <!-- <div class="content-header">
      <div class="content-header-left">
        <div class="search">
          <vs-input icon-pack="feather" icon="icon-search" v-model="searchtxt" placeholder="Search"
            class="is-label-placeholder" />
           
        </div>
      </div>
      <div class="content-header-right">  
      </div>
    </div> --> 
    <span class="back_btn" v-if="!isLoadedFromUrl" @click="$store.dispatch('common/activateSettingTab' ,'branchList')"><img src="@/assets/images/main/return_arrow.png">Go to Brach List</span>
    <div class="form_page_cnt">
    
      <div class="form_section">
       
        <form v-if="loadedAll">
          <div class="form-container">
            <h3 class="small-header">General Information </h3>
            <div class="vx-row">
              <div class="vx-col md:w-1/2 w-full">
                <div class="form_group">
                  <label class="form_label">Branch Name<em>*</em></label>
                  <vs-input @click="formerrors.msg=''" v-model="newform.name"   name="Branch Name" v-validate="'required'" class="w-full"
                      data-vv-as="Branch Name"    />
                  <span class="text-danger text-sm"
                    v-show="errors.has('Branch Name')">{{ errors.first("Branch Name") }}</span>
              </div>
              </div>
              <div class="vx-col md:w-1/2 w-full"   >
                    <div class="form_group">
                      <div class="con-select w-full select-large">
                        <label for class="form_label">Branch Manager</label>
                   
                        <multiselect name="BranchManager"   v-model="newform.selectedBranchManager"
                        placeholder="Select Branch Manager"
                          @input="changedbranchManager" :show-labels="false" track-by="_id" label="name"
                          data-vv-as="Branch Manager"  :options="unUserBranchManagers" :searchable="true"
                          :allow-empty="true"></multiselect>
                      </div>
                        <span class="text-danger text-sm"
                        v-show="errors.has('BranchManager')">{{ errors.first("BranchManager") }}</span>
                      </div>
                    </div>
            </div>

            <div class="vx-row">
              <div class="vx-col md:w-1/2 w-full">
              <div class="form_group ph_number">
                <div class="vs-component">
                  <label class="form_label">Phone Number<em>*</em></label>            
                      <VuePhoneNumberInput
                                  icon-pack="feather"
                                  class="w-full no-icon-border"
                                  :no-example="false"
                                  v-validate="'required'"
                                  name="phone"
                                  data-vv-as="Phone Number"
                                  placeholder="Enter Mobile Number"
                                  :default-country-code="checkProperty(newform['phoneCountryCode'] ,'countryCode')"
                                    v-bind="vuePhone.props"                
                                  :no-country-selector="false"
                                    v-model="newform.phone"
                                    @update="updatePhone"
                                    :preferred-countries="['US', 'IN']"
                                  />
                                  <span class="text-danger text-sm"   v-show="!isPhoneValid && !errors.has('phone')" >*Invalid phone number - Please enter a valid one</span>
                                  <span class="text-danger text-sm" v-show="errors.has('phone')">{{ errors.first("phone") }}</span>
                              </div>
                
              </div>
              </div>
              <immiPhone :fieldsArray="[]" :display="true" :tplkey="''" @updatephoneCountryCode="updatehomePhoneCountryCode" :countrycode="newform.homePhoneCountryCode.countryCode" cid="branchPhoneNumber" formscope="" v-model="newform.homePhone" :tplsection="'beneficiaryInfo'"  :fieldName="'homePhoneNumber'" label="Mobile Telephone Number" placeHolder="Mobile Telephone Number" />
              <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
              <div class="vs-component">
                <label class="form_label">Fax Number</label>   
                                  <VuePhoneNumberInput
                                  icon-pack="feather"
                                  class="w-full no-icon-border"
                                  :no-example="false"
                                 
                                  name="fax"
                                  data-vv-as="Fax Number"
                                  v-bind="vuePhone1.props"
                                  :default-country-code="checkProperty(newform['faxCountryCode'],'countryCode')"
                                  :no-country-selector="false"
                                    v-model="newform.fax"
                                    @update="updateFax"
                                    :preferred-countries="['US', 'IN']"
                                  />
                                  <span class="text-danger text-sm"   v-show="!isFaxValid && !errors.has('fax')" >*Invalid fax number - Please enter a valid one</span>
                                  <span class="text-danger text-sm" v-show="errors.has('fax')">{{ errors.first("fax") }}</span>
                              </div>
                            </div>
                
              </div>
              
            </div>
          <div class="devider"></div>
          <h3 class="small-header">Contact Person </h3>
            <div class="vx-row">
              <div class="vx-col md:w-1/3 w-full" > 
                  <div class="form_group">
                    <label class="form_label">First Name<em>*</em></label>   
                      <vs-input   name="firstname" v-model="newform.contact.firstName" class="w-full"
                        v-validate="'required'" data-vv-as="First Name"   />
                      <span class="text-danger text-sm"
                        v-show="errors.has('firstname')">{{ errors.first("firstname") }}</span>
                    </div>
              </div>
                <div class="vx-col md:w-1/3 w-full" > 
                    <div class="form_group">
                      <label class="form_label">Middle Name</label>   
                      <vs-input   name="middleName"   v-model="newform.contact.middleName" class="w-full"
                       data-vv-as=" Middle Name"   />
                      <span class="text-danger text-sm"
                        v-show="errors.has('middleName')">{{ errors.first("middleName") }}</span>
                    </div>
              
            </div>
            <div class="vx-col md:w-1/3 w-full" > 
                    <div class="form_group">
                      <label class="form_label">Last Name<em>*</em></label>   
                      <vs-input   name="lastName"   v-model="newform.contact.lastName" class="w-full"
                      v-validate="'required'" data-vv-as="Last Name"   />
                      <span class="text-danger text-sm"
                        v-show="errors.has('lastName')">{{ errors.first("lastName") }}</span>
                    </div>
              
            </div>
            <div class="vx-col md:w-1/2 w-full" > 
                    <div class="form_group">
                      <label class="form_label"> Email<em>*</em></label>   
                      <vs-input   name="contactEmail"   v-model="newform.contact.email" class="w-full"
                      v-validate="'required|email'" data-vv-as="Email"   />
                      <span class="text-danger text-sm"
                        v-show="errors.has('contactEmail')">{{ errors.first("contactEmail") }}</span>
                    </div>
              
            </div>
            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group ph_number">
                <div class="vs-component">
                  <label class="form_label">Phone Number<em>*</em></label>  
                          
                      <VuePhoneNumberInput
                                  icon-pack="feather"
                                  class="w-full no-icon-border"
                                  :no-example="false"
                                  v-validate="'required'"
                                  name="contactPersonPhone"
                                  data-vv-as="Phone Number"
                                 
                                  placeholder="Enter Mobile Number"
                                  :default-country-code="checkProperty(newform['contact']['phoneCountryCode'] ,'countryCode')"
                                    v-bind="vuePhone.props"                
                                  :no-country-selector="false"
                                    v-model="newform['contact'].phone"
                                    @update="updatecontactPersonPhone"
                                    :preferred-countries="['US', 'IN']"
                                  />
                                   <span class="text-danger text-sm"   v-show="!isPersonPhoneValid && !errors.has('contactPersonPhone')" >*Invalid phone number - Please enter a valid one</span>
                                  <span class="text-danger text-sm"
                        v-show="errors.has('contactPersonPhone')">{{ errors.first("contactPersonPhone") }}</span>
                              </div>
                
              </div>
              </div>
            </div>
            <div class="devider"></div>
            <h3 class="small-header">Branch Address</h3>

                 <addressFields
                 v-if="countries.length>0"
                    :validationRequired="true"
                    :showaptType="true"
                    :countries="countries"
                    v-model="newform.address"
                    :cid="'branchAdde'"
                    ref="branchAdde"
        /> 

                  <div class="vx-row d-none" >
                  
                    <div class="vx-col md:w-1/2 w-full" > 
                    <div class="form_group">
                      <label class="form_label">Street Address<em>*</em></label> 
                      <vs-input   name="address1"  v-model="newform.address.line1" class="w-full"
                      v-validate="'required'" data-vv-as="Street Address" 
                       />
                      <span class="text-danger text-sm"
                        v-show="errors.has('address1')">{{ errors.first("address1") }}</span>
                    </div>
                    </div>

                    <div class="vx-col md:w-1/2 w-full" > 
                    <div class="form_group">
                      <label class="form_label">Apt, Suite</label> 
                      <vs-input   name="address2"  v-model="newform.address.line2" class="w-full"
                       data-vv-as="Apt, Suite" />
                      <span class="text-danger text-sm"
                        v-show="errors.has('address2')">{{ errors.first("address2") }}</span>
                    </div>
                    </div>

                    <div class="vx-col md:w-1/2 w-full"   >
                    <div class="form_group">
                      <div class="con-select w-full select-large">
                        <label for class="form_label">Country<em>*</em></label>
                      
                        <multiselect name="spouseaddresscountry"   v-model="newform.address.countryDetails"
                        placeholder="Select Country"
                          @input="changedCountry" :show-labels="false" track-by="id" label="name"
                          data-vv-as="Country" v-validate="'required'" :options="countries" :searchable="true"
                          :allow-empty="false"></multiselect>
                      </div>
                        <span class="text-danger text-sm"
                        v-show="errors.has('spouseaddresscountry')">{{ errors.first("spouseaddresscountry") }}</span>
                      </div>
                    </div>
                    <div class="vx-col md:w-1/2 w-full"  >
                    <div class="form_group">
                      <div class="con-select w-full select-large">
                        <label for class="form_label">State<em v-if="states.length>0">*</em></label>
                        <multiselect name="State"   v-model="newform.address.stateDetails"
                          @input="changedState" :show-labels="false" track-by="id" label="name" data-vv-as="State"
                          placeholder="Select State"  v-validate="{'required':states.length>0}" :options="states" :searchable="true" :allow-empty="false">
                        </multiselect>
                      </div>

                      <span class="text-danger text-sm" v-show="errors.has('State')">{{ errors.first("State") }}</span>
                    </div>
                    </div>
                    <div class="vx-col md:w-1/2 w-full"  >
                    <div class="form_group">
                      <div class="con-select w-full select-large">
                        <label for class="vs-select--label">City<em v-if="locations.length>0">*</em></label>
                        <multiselect name="city"   v-model="newform.address.locationDetails"
                        @input="changedCity"
                        :show-labels="false" track-by="id" label="name" data-vv-as="City" 
                          placeholder="Select City" :options="locations"  v-validate="{'required':locations.length>0}"  :searchable="true" :allow-empty="false">
                        </multiselect>
                      </div>

                      <span class="text-danger text-sm" v-show="errors.has('city')">{{ errors.first("city") }}</span>
                    </div>
                    </div>
                    <div class="vx-col md:w-1/2 w-full" >
                    <div class="form_group">
                      <label for class="form_label">Zip Code<em>*</em></label>
                      <vs-input name="zipcode"  v-model="newform.address.zipcode"
                        v-validate="'numeric|required|min:5|max:6'" class="w-full" data-vv-as="Zip Code"
                        oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1'); this.value = this.value.replace(/ /g,'');"
                        
                        />

                      <span class="text-danger text-sm" v-show="errors.has('zipcode')">{{ errors.first("zipcode") }}</span>
                    </div>
                    </div>

                  </div>  



              <div class="vx-col w-50">
               
                <div class="form_group">
                                <label class="form_label">Mailing Address same as above address?  </label>
                               <div class="table_switch pt-2">
                               
                                <vs-switch  @input="addresssame()" v-model="newform.mailingAddressSame">
                                  <span slot="on">Yes</span>
                                  <span slot="off">No</span>
                                </vs-switch>
                               </div>
                               
                               
                                
                              </div>                
            </div>
      
        <template v-if="!newform.mailingAddressSame">
        <h3 class="small-header">Mailing Address</h3>
       <addressFields
          :showaptType="true"
          :countries="countries"
          v-model="newform.mailingaddress"
          :cid="'mailingaddress'"
          ref="mailingaddress"
        /> 
        </template>



            <div class="text-danger text-sm formerrors" v-show="formerrors.msg" @click="formerrors.msg=''">
              <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
                icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
            </div>
          </div>
          <div class="form-footer">
            <vs-button color="save"  :disabled="submitForm" class="save" v-if="edit" @click=" updateBranchAction()" type="filled">Update</vs-button>
            <vs-button color="save" :disabled="submitForm" class="save" v-else @click=" createBranchAction()" type="filled">Save</vs-button>
          </div>
        </form>
        
      </div>
    </div>
    
  </div>
</template>

<script>
import DateRangePicker from "vue2-daterange-picker";
  import Datepicker from "vuejs-datepicker-inv";
  import Paginate from "vuejs-paginate";
  import immiPhone from "@/views/forms/fields/phonenumber.vue";
import "vue2-daterange-picker/dist/vue2-daterange-picker.css";

  import _ from "lodash";
  import { FormWizard, TabContent } from "vue-form-wizard";
  import "vue-form-wizard/dist/vue-form-wizard.min.css";
   import moment from 'moment'
  import PhoneMaskInput from "vue-phone-mask-input";
  import JQuery from 'jquery'
  import { TheMask } from 'vue-the-mask'
  
import FileUpload from "vue-upload-component/src";
import VuePhoneNumberInput from 'vue-phone-number-input';
import 'vue-phone-number-input/dist/vue-phone-number-input.css';
//import addressFields from "@/views/common/addressForm.vue";
import addressFields from "@/views/forms/fields/address.vue"; 

  export default {
     props: {
       isLoadedFromUrl:{ type: Boolean, default: true},
       selectedBranch:null
     },
       provide() {
        return {
            parentValidator: this.$validator,
        };
    },
    computed:{
      validateForm(){
        if(
          (this.newform.name && this.newform.name.trim() !='' ) 
        &(this.newform.phone && this.newform.phone != '')
        &(this.newform.fax && this.newform.fax != '')
        &(this.newform.contact.firstName && this.newform.contact.firstName.trim() != '')
        &(this.newform.contact.lastName && this.newform.contact.lastName.trim() != '')
        &(this.newform.address.line2 && this.newform.address.line2.trim() != '')
        &(this.newform.address.line1 && this.newform.address.line1.trim() != '')
        &(this.newform.address.countryId && this.newform.address.countryId != '')
        &(this.newform.address.stateId && this.newform.address.stateId != '')
        &(this.newform.address.locationId && this.newform.address.locationId != '')
        &(this.newform.address.zipcode && this.newform.address.zipcode != '')

        ){

          return false;
        }else{
          return true;
        }

      },
      
    },
    components: {
      immiPhone,
      DateRangePicker,
      VuePhoneNumberInput,
      Datepicker,
      Paginate,
      FileUpload,
      FormWizard,
      TabContent,
      PhoneMaskInput,
      TheMask,
      addressFields
    },

    data: () => ({ 
      loadedAll:true,
     unUserBranchManagers:[],
     isFaxValid:true,
     isPhoneValid:true,
     isPersonPhoneValid:true,
     submitForm:false,
     edit:false,
     branchId:null,
     branchDetails: '',  
     countries:[],
     states:[],
     locations:[],
     formerrors: {
        msg: ""
      },
      vuePhone:{
        props:{
          translations:{
            phoneNumberLabel:"Phone Number"
          }
        }

      },
      vuePhone1:{
        props:{
          translations:{
            phoneNumberLabel:"Fax Number"
          }
        }

      },
     newform: {
        name:'', 
        phone:"",
  	   	phoneCountryCode:{countryCode:'',countryCallingCode:''},
  	  	fax:"",
  	   	faxCountryCode:{countryCode:'',countryCallingCode:''},
        homePhone: "",
        homePhoneCountryCode: { countryCode: '', countryCallingCode: '' },
        userId:null,
        selectedBranchManager:null,
        mailingAddressSame:false,
        mailingaddress:{line1:"" , line2:"",countryId:'' , stateDetails:null, countryDetails:null ,stateId:'',stateDetails:null,locationId:'',locationDetails:null ,zipcode:''},
        address:{line1:"" , line2:"",countryId:'' ,   countryDetails:null ,stateId:'',stateDetails:null,locationId:'',locationDetails:null ,zipcode:''},
        contact: { 
            firstName: "",
            lastName: "",
            email: "",
            phone: "",
            phoneCountryCode: {countryCode:'',countryCallingCode:''}
  	    	}
      },
  }),
    watch: {
      searchtxt: function () {
        this.getList();
      }

    },
    methods: {
      updatehomePhoneCountryCode(data){
        this.newform.homePhoneCountryCode =data;
    },
      changedbranchManager(item){
        this.newform.selectedBranchManager = item;
        this.newform.userId =null;
        if(item  && _.has( item ,"_id" )){
          this.newform.userId = item['_id'];
        }
      }, 
      updatecontactPersonPhone(item){
        this.isPersonPhoneValid=true
           // phone: "",
           // phoneCountryCode: {countryCode:'',countryCallingCode:''}
            if (item.isValid) {  
                this.newform['contact'].phoneCountryCode = {countryCode:item.countryCode,countryCallingCode:item.countryCallingCode};
                this.newform['contact'].phone = item.nationalNumber;         
              }
              else{
                this.isPersonPhoneValid=false;
              }
        },

       updatePhone(item){
         
         this.isPhoneValid=true
            if (item.isValid) {  
                this.newform.phoneCountryCode = {countryCode:item.countryCode,countryCallingCode:item.countryCallingCode};
                this.newform.phone = item.nationalNumber;         
      }else{
          this.isPhoneValid=false
      }
      
        },

         updateFax(item){
           this.isFaxValid=true
            if (item.isValid) {  
                this.newform.faxCountryCode = {countryCode:item.countryCode,countryCallingCode:item.countryCallingCode};
                this.newform.fax = item.nationalNumber;         
            }else{
              this.isFaxValid=false
            }
        },
        
      getBranchdetails(){
        let postData = {
          branchId : this.branchId
        }
        this.$vs.loading();
        this.loadedAll =false;
        this.$store.dispatch("commonAction", {"data":postData ,"path":"/branch/details"})
              .then(response => {
                
                this.branchDetails= response
                if(_.has(this.branchDetails, 'name')){
                  this.newform.name = this.branchDetails.name
                  this.newform.phone = this.branchDetails.phone
                  this.newform.fax = this.branchDetails.fax
                  this.newform.phoneCountryCode = this.branchDetails.phoneCountryCode
                  this.newform.faxCountryCode = this.branchDetails.faxCountryCode
                  if(!_.has(this.branchDetails,'homePhoneCountryCode') || this.branchDetails['homePhoneCountryCode'] == null || this.branchDetails['homePhoneCountryCode'] == ''  ){
                    this.newform.homePhoneCountryCode = { countryCode: '', countryCallingCode: '' }
                    this.newform.homePhoneCountryCode = ''
                  }else{
                    this.newform.homePhoneCountryCode = this.branchDetails.homePhoneCountryCode
                    this.newform.homePhone = this.branchDetails.homePhone
                  }
                 
                 

                }
                if(_.has(this.branchDetails, 'contact')){
                  this.newform.contact =  this.branchDetails.contact

                }
                //address block
                // address:{line1:"" , line2:"",countryId:'' ,countryDetails:null ,stateId:'',stateDetails:null,locationId:'',locationDetails:null ,zipcode:''},
                if(_.has(this.branchDetails, 'address')){
                  //this.newform.address = this.branchDetails.address
                  


                  
                  

                  
                  
                  
                   _.forEach(this.branchDetails["address"],(val ,key)=>{
                       this.newform["address"][key] = val;

                    })
                }
                if(_.has(this.branchDetails, 'mailingaddress')){
                   this.newform.mailingAddressSame = this.branchDetails.mailingAddressSame;
                    _.forEach(this.branchDetails["mailingaddress"],(val ,key)=>{
                       this.newform["mailingaddress"][key] = val;

                    })
                 
                  
                }
                 if(_.has(this.branchDetails, 'userDetails')){
                   this.changedbranchManager(this.branchDetails['userDetails']);
                   if( !(_.find( this.unUserBranchManagers,{"_id":this.branchDetails.userId}))){
                      this.unUserBranchManagers.push(this.branchDetails['userDetails']);
                   }
                  
                }
                
                this.newform = _.cloneDeep(this.newform);
              
                 this.loadedAll =true
                 this.loadedAll =false
                this.loadedAll =true
                this.$vs.loading.close();
                 this.$validator.reset();
              

              })
               .catch(error => {
                  this.loadedAll =true
                  this.showToster({message:error,isError:true });
              })
      },
     
       createBranchAction() {
        this.$validator.validateAll().then(result => {
          if(result && this.isPhoneValid ){
             let postData =this.newform ;
             if(this.checkProperty(this.newform , 'selectedBranchManager' ,"_id")){
             postData = Object.assign(postData, { "userId":this.newform['selectedBranchManager']['_id'] })
             
           }
            this.submitForm =true;
            this.$store
              .dispatch("commonAction", {"data":postData ,"path":"/branch/create"})
              .then(response => {
                
                 this.showToster({message:response.message,isError:false });
                this.submitForm =false;
                
                 setTimeout(() => {
                   if(this.isLoadedFromUrl){
                      this.$router.push({'path':"/branch-list" });
                   }else{
                     this.$store.dispatch('common/activateSettingTab' ,'branchList')
                   }
                     
                 }, 10);
               
                
              })
              .catch((error)=>{
                this.submitForm =false;
                Object.assign(this.formerrors, {
                    msg:error
                  });
              })
          }
           
          
        });
      },

       updateBranchAction() {

        
        this.$validator.validateAll().then(result => {
          if(result && this.isPhoneValid ){
             this.submitForm =true;
             let postData =this.newform ;
           postData = Object.assign(postData,{branchId:this.branchId});
           if(this.checkProperty(this.newform , 'selectedBranchManager' ,"_id")){
             postData = Object.assign(postData, { "userId":this.newform['selectedBranchManager']['_id'] })
             
           }
          
            this.$store
              .dispatch("commonAction", {"data":postData ,"path":"/branch/update"})
              .then(response => {
                
                 this.showToster({message:response.message,isError:false });
                
                
                 setTimeout(() => {
                   if(this.isLoadedFromUrl){
                      this.$router.push({'path':"/branch-list" });
                   }else{
                     this.$store.dispatch('common/activateSettingTab' ,'branchList');
                   }
                     
                 }, 10);
               
                
              })
              .catch((error)=>{
                  this.submitForm = false;
                Object.assign(this.formerrors, {
                    msg:error
                  });
              })

          }
           
          
        });
      },

             
     // changedCountry  newform.address.countryDetails  changedState newform.address.stateDetails
    changedCountry(){
         this.states =[];
        this.locations =[];
        if( _.has(this.newform.address.countryDetails , "id")){
            this.newform.address.countryId = this.newform.address.countryDetails['id'];
           
            this.masterData('states');
        }
        
    },
    changedState(){
      //  alert(JSON.stringify('test'))
         this.locations =[];
         if( _.has(this.newform.address.stateDetails , "id")){
            this.newform.address.stateId = this.newform.address.stateDetails['id'];
           this.masterData('locations');
        }
    },
    //locationId
    changedCity(){
     
      if( _.has(this.newform.address.locationDetails , "id")){
            this.newform.address.locationId = this.newform.address.locationDetails['id'];
           //this.masterData('locations');
        }

    },
    masterData(category="countries"){

         /*
        countries:[]
        states:[],
        locations:[],
         */
        let matcher ={};
         let postData = {
        matcher: matcher,
        page:1,
        perpage: 1000,
        category: category,
       
      };
      if(category =="states"){

          matcher = { "countryId": this.newform.address.countryDetails['id']}
      }
       if(category =="locations"){

          matcher = { "stateId": this.newform.address.stateDetails['id']  }
      }
       postData['matcher'] = matcher;

         this.$store.dispatch("getMasterData" , postData)
         .then((res)=>{
             //countries
             
             if(category == "countries"){

                 this.countries = res['list'];
                 if(this.edit){
                   this.getBranchdetails()
                 }
                 //alert(JSON.stringify(this.countries))
             }
             if(category =="states"){


                  this.states= res['list'];
                  if(this.edit && this.newform.address.stateId){
                    this.newform.address.stateDetails = _.find(this.states, {
                      'id': this.newform.address.stateId

                    })
                    this.changedState();
                  }
             }
            if(category =="locations"){
              
                this.locations= res['list'];
                if(this.edit && this.newform.address.locationId){
                    this.newform.address.locationDetails = _.find(this.locations, {
                      'id': this.newform.address.locationId
                    })
                  }
            }
            if(category =='unassigned_branch_managers'){
              this.unUserBranchManagers = res['list'];
            }

         })
         .catch((err)=>{
             this[category] =[];

         })

    }
    
    },
    mounted() {

       
    
      if(this.checkProperty(this.$route.params, 'id') && this.isLoadedFromUrl){
        this.branchId = this.$route.params.id;
        this.edit = true;
        
      }else if(!this.isLoadedFromUrl && this.checkProperty(this.selectedBranch, '_id')){
        this.branchId = this.selectedBranch['_id'];
        this.edit = true;
      }
       this.newform.address.countryDetails = {
            _id: "5db7f7409419e34350f11024",
            id: 231,
            name: "United States"

          },
     this.changedCountry(); 
     //this.masterData("countries");    
    this.masterData('unassigned_branch_managers');

     let matcher ={};
         let postData = {
        matcher: matcher,
        page:1,
        perpage: 1000,
        category: 'countries',
       
      };
       this.$store.dispatch("getMasterData" , postData)
         .then((res)=>{

         this.countries = res['list'];
              if(this.edit){
                this.loadedAll =false;
                this.getBranchdetails()
              }else{
                this.loadedAll =true;
              }
         })
     
      this.$validator.reset();
       setTimeout(()=>{ 
                    this.isPhoneValid=true;
                    this.isFaxValid=true;
                    this.isPersonPhoneValid=true;
                   
               } ,100);
    }
  };
</script>
