<template>
<div class="main-tabs-content">
    <div class="tabs-layout-header">
        <div class="case-no-panel">
            <vs-dropdown>
                <a class="flex items-center">
                    <div class="drop-down-content">
                        Case No
                        <span>{{petition.caseNo}}</span>
                    </div>
                    <i class="material-icons">arrow_drop_down</i>
                </a>
                <vs-dropdown-menu class="caseno-dropdown" v-if="petitions">
                    <vs-dropdown-item @click="loadPetetion(petition._id)" v-for="(petition, index) in petitions" :key="index">{{ petition.caseNo }}</vs-dropdown-item>
                </vs-dropdown-menu>
            </vs-dropdown>
            <div class="actions_footer">

            </div>
        </div>


        <div>

        </div>

    </div>
    <!-- content section start here-->
    <div class="tabs-content">

        <vs-row vs-w="12" class="bg_white">
            <vs-col vs-type="flex" style="padding:0px; width:calc(100% - 350px) !important;">
                <VuePerfectScrollbar class="scroll-area">
                    <div v-if="petition.statusId == 1" class="no-activities">
                        <figure>
                            <img src="@/assets/images/main/no-activity-img.png" />
                        </figure>
                        <h3>Application Not submitted yet</h3>
                    </div>
                    <div v-bind:class="{ 'petitionTabs': currentRole!=7 }">

                        <div id="loading-bg" v-if="!loaded">
                            <div class="loading-logo">
                                <p>Loading Please Wait...</p>
                            </div>
                            <div class="loading">
                                <div class="effect-1 effects"></div>
                                <div class="effect-2 effects"></div>
                                <div class="effect-3 effects"></div>
                            </div>
                        </div>

                        <vs-tabs v-if="loaded">
                            <vs-tab class="petition_tabs petition_details_tab gc_app_content_details">
                                <vs-tabs position="left" color="danger" v-model="active_tab">

                                    <vs-tab label="Principal Applicant" @click="togleMainTab('principal_applicant');">
                                        <div class="tab-inner-content">
                                            <div class="tabs-content-panel ">
                                                <div class="gc_details-cnt">
                                                    <div class="gc_details-header">
                                                        <div class="gc_details-header-left">
                                                            <figure>
                                                                <figcaption>{{petition.beneficiaryInfo.name}}
                                                                    <span>{{petition.beneficiaryInfo.phoneNumber}}</span>

                                                                </figcaption>
                                                            </figure>
                                                        </div>

                                                        <div class="gc_details-header-right">
                                                            <button class="view_application" @click="bindTabpopData(petition.beneficiaryInfo);">View Application</button>
                                                            <button class="print_application" @click="divPrint();"><img src="@/assets/images/main/print.svg" alt="print">Print</button>
                                                        </div>
                                                    </div>
                                                    <div class="gc_updates_wrap">
                                                        <label class="gc_updates_title"> </label>
                                                        <div class="gc_updates_cnt">

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </vs-tab>

                                    <vs-tab label="Spouse" @click="togleMainTab('spouse');" v-if="petition.dependentsInfo.spouse['firstName'] !=null && petition.dependentsInfo.spouse['firstName'] !=''">
                                        <div class="tab-inner-content">
                                            <div class="tabs-content-panel">
                                                <div class="gc_details-cnt">
                                                    <div class="gc_details-header">
                                                        <div class="gc_details-header-left">

                                                            <figure>
                                                                <figcaption>{{petition.dependentsInfo.spouse.name}}
                                                                    <span>{{petition.dependentsInfo.spouse.phoneNumber}}</span>

                                                                </figcaption>
                                                            </figure>

                                                        </div>
                                                        <div class="gc_details-header-right">
                                                            <button class="view_application" @click="bindTabpopData(petition['dependentsInfo']['spouse']);">View Application</button>
                                                            <button class="print_application" @click="divPrint();"><img src="@/assets/images/main/print.svg" alt="print">Print</button>
                                                        </div>
                                                    </div>
                                                    <div class="gc_updates_wrap">
                                                        <label class="gc_updates_title">

                                                        </label>
                                                        <div class="gc_updates_cnt">

                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </vs-tab>

                                    <!---CHILD TABS--->
                                    <template v-for="( child ,cindex) in  petition.dependentsInfo['childrens']">
                                        <vs-tab v-if="child['firstName'] && child['firstName'] !='' " :ref="'Child '+cindex" :label="'Child '+(cindex+1)" @click="togleMainTab('child'+cindex ,cindex);" :key="cindex">
                                            <div class="tab-inner-content">
                                                <div class="tabs-content-panel">
                                                    <div class="gc_details-cnt">
                                                        <div class="gc_details-header">
                                                            <div class="gc_details-header-left">
                                                                <figure>
                                                                    <figcaption>{{child.name}}
                                                                        <span>{{child.phoneNumber}}</span>
                                                                    </figcaption>
                                                                </figure>
                                                            </div>
                                                            <div class="gc_details-header-right">
                                                                <button class="view_application" @click="bindTabpopData(child);">View Application</button>
                                                                <button class="print_application" @click="divPrint();"><img src="@/assets/images/main/print.svg" alt="print">Print</button>
                                                            </div>
                                                        </div>
                                                        <div class="gc_updates_wrap">

                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                        </vs-tab>
                                    </template>

                                    <vs-tab v-if=" ([1,2,4].indexOf(currentRole) >= 0) || ([7].indexOf(currentRole) >= 0 && petition.statusId > 4) " label="PDF Forms">
                                        <FormsandLetters :currentUser="currentUserId" v-bind:currentRole="currentRole" @updatepetition="reloadPetition" @showfilingFeesPopup="showfilingFeesPopup" v-bind:petition="petition" />
                                    </vs-tab>

                                    <vs-tab label="Communication">
                                        <Communication v-bind:petition="petition" v-bind:userId="currentUserId" />
                                    </vs-tab>

                                </vs-tabs>
                            </vs-tab>

                        </vs-tabs>

                    </div>
                </VuePerfectScrollbar>

            </vs-col>
            <vs-col vs-type="flex" class="padr0 padl0" style="width:350px; position:relative;">
                <div class="history-sidebar petition_history ">
                    <div class="vs-sidebar updates-h ">
                        <div class="petition_updated" v-if="petitionhistory.length == 0">Last Updated - {{petition.updatedOn | formatDate}}</div>
                        <div class="petition_updated" v-if="petitionhistory.length > 0">Last Updated - {{petitionhistory[0].createdOn | formatDate}}</div>

                        <div class="vs-sidebar--items">
                            <VuePerfectScrollbar class="scroll-area">
                                <div class="timeline-sidebar 2">
                                    <ul>
                                        <li v-for="(history, index) in petitionhistory" :key="index">
                                            <div class="timeline-icon">
                                                <i class="icon IP-tick-sign"></i>
                                            </div>
                                            <div class="timeline-info">
                                                <button class="btn active-green ml-0">{{history.createdByRoleName}}</button>
                                                <ul>
                                                    <li>
                                                        <h3>{{history.title}}
                                                            <div v-if="history.comment && history.comment!=''" class="title_des"><small></small>
                                                                <div class="dec-content">
                                                                    <p>{{history.comment}}</p>
                                                                </div>
                                                            </div>
                                                        </h3>

                                                        <span>{{history.description}}</span>

                                                        <span>{{history.createdOn | formatDateTime}}</span>
                                                    </li>
                                                </ul>
                                            </div>
                                        </li>
                                    </ul>
                                </div>

                            </VuePerfectScrollbar>
                        </div>
                    </div>
                </div>
            </vs-col>
        </vs-row>

    </div>

    <vs-popup class="holamundo success-popups" title="Your registration is complete." :active.sync="SuccessQuestionnaire">
        <figure>
            <img src="@/assets/images/main/icon-note.svg" alt="login" class="mx-auto" />
        </figure>
        <h2 class="title">
            USCIS receipt has been
            <br />sent to the Petitioner
        </h2>
    </vs-popup>

    <vs-popup :title="petition.caseNo" :active.sync="gcapplicationView" class="Change_petition_wrap view_gcapp_wrap">
        <div class="gc_appcontent">
            <div class="gc_appcontent_left">
                <div class="gc_title_list" :class="{'active':popMainTabs.principal_applicant}">
                    <label @click="togleMainTab('principal_applicant')">Principal Applicant</label>
                    <ul>

                        <li @click="togleSubTab('personal_info')" :class="{'active':popupSubTabs.personal_info}">Personal Info</li>
                        <li @click="togleSubTab('address')" :class="{'active':popupSubTabs.address}">Addresses</li>
                        <li @click="togleSubTab('immigration')" :class="{'active':popupSubTabs.immigration}">Immigration</li>
                        <li @click="togleSubTab('occupational_skills')" :class="{'active':popupSubTabs.occupational_skills}">Education & Employment</li>
                        <li @click="togleSubTab('assets_financials')" :class="{'active':popupSubTabs.assets_financials}">Assets &amp; Financials</li>
                        <li @click="togleSubTab('parents')" :class="{'active':popupSubTabs.parents}">Parents</li>
                        <li @click="togleSubTab('documents')" :class="{'active':popupSubTabs.documents}">Documents</li>

                    </ul>
                </div>
                <div class="gc_title_list" :class="{'active':popMainTabs.spouse}" v-if="petition.dependentsInfo && petition.dependentsInfo.spouse['firstName'] !=null && petition.dependentsInfo.spouse['firstName'] !=''">
                    <label @click="togleMainTab('spouse')">Spouse</label>
                    <ul>
                        <li @click="togleSubTab('personal_info')" :class="{'active':popupSubTabs.personal_info}">Personal Info</li>
                        <li v-if="petition.dependentsInfo.spouse && petition.dependentsInfo.spouse.applicationRequired" @click="togleSubTab('address')" :class="{'active':popupSubTabs.address}">Addresses</li>
                        <li v-if="petition.dependentsInfo.spouse && petition.dependentsInfo.spouse.applicationRequired" @click="togleSubTab('immigration')" :class="{'active':popupSubTabs.immigration}">Immigration</li>
                        <li v-if="petition.dependentsInfo.spouse && petition.dependentsInfo.spouse.applicationRequired" @click="togleSubTab('occupational_skills')" :class="{'active':popupSubTabs.occupational_skills}">Education & Employment</li>
                        <li v-if="petition.dependentsInfo.spouse && petition.dependentsInfo.spouse.applicationRequired" @click="togleSubTab('assets_financials')" :class="{'active':popupSubTabs.assets_financials}">Assets &amp; Financials</li>
                        <li v-if="petition.dependentsInfo.spouse && petition.dependentsInfo.spouse.applicationRequired" @click="togleSubTab('parents')" :class="{'active':popupSubTabs.parents}">Parents</li>
                        <li v-if="petition.dependentsInfo.spouse && petition.dependentsInfo.spouse.applicationRequired" @click="togleSubTab('documents')" :class="{'active':popupSubTabs.documents}">Documents</li>

                    </ul>
                </div>
                <template v-for="( child ,cindex) in  petition.dependentsInfo['childrens']">
                    <div v-if="child['firstName']" class="gc_title_list" :key="cindex" :class="{'active':popMainTabs['child'+cindex]}">
                        <label @click="togleMainTab('child'+cindex ,cindex)">Child {{cindex+1}}</label>
                        <ul>

                            <li @click="togleSubTab('personal_info' ,cindex )" :class="{'active':popupSubTabs.personal_info}">Personal Info</li>
                            <li v-if="child.applicationRequired" @click="togleSubTab('address',cindex)" :class="{'active':popupSubTabs.address}">Addresses</li>
                            <li v-if="child.applicationRequired" @click="togleSubTab('immigration',cindex)" :class="{'active':popupSubTabs.immigration}">Immigration</li>
                            <li v-if="child.applicationRequired" @click="togleSubTab('occupational_skills',cindex)" :class="{'active':popupSubTabs.occupational_skills}">Education & Employment</li>
                            <li v-if="child.applicationRequired" @click="togleSubTab('assets_financials',cindex)" :class="{'active':popupSubTabs.assets_financials}">Assets &amp; Financials</li>
                            <li v-if="child.applicationRequired" @click="togleSubTab('parents',cindex)" :class="{'active':popupSubTabs.parents}">Parents</li>
                            <li v-if="child.applicationRequired" @click="togleSubTab('documents',cindex)" :class="{'active':popupSubTabs.documents}">Documents</li>

                        </ul>
                    </div>
                </template>

            </div>

            <!-- personal_info Tab-->
            <div class="gc_appcontent_right" v-if="popupSubTabs['personal_info']">
                <div class="gc_app_details-cnt">
                    <VuePerfectScrollbar :ref="popupSubTabs['personal_info']" class="scroll-area--nofications-dropdown p-0" :settings="settings">
                        <div class="gc_scrool-cnt">

                            <ul>
                                <li v-if="tabpopData.firstName">
                                    <label>First Name</label>
                                    <p>{{tabpopData.firstName}}</p>
                                </li>
                                <li v-if="tabpopData['middleName']">
                                    <label>Middle Name</label>
                                    <p>{{tabpopData.middleName}}</p>
                                </li>
                                <li v-if="tabpopData['lastName']">
                                    <label>Last Name</label>
                                    <p>{{tabpopData['lastName']}}</p>
                                </li>

                                <li v-if="tabpopData['email']">
                                    <label>Email</label>
                                    <p>{{tabpopData['email']}}</p>
                                </li>
                                <li v-if="tabpopData['gender']">
                                    <label>Gender</label>
                                    <p>{{tabpopData['gender']}}</p>
                                </li>

                                <li v-if="tabpopData['dateOfBirth']">
                                    <label>Date of Birth</label>
                                    <p>{{tabpopData['dateOfBirth'] | formatDate }}</p>
                                </li>

                                <li v-if="tabpopData['maritalStatus']">
                                    <label>Marital Status</label>
                                    <p>{{tabpopData['maritalStatus']['name']}}</p>
                                </li>

                                <li v-if="tabpopData['childrenCount']">
                                    <label>How many children do you have?</label>
                                    <p>{{tabpopData['childrenCount']}}</p>
                                </li>

                                <li v-if="tabpopData['dateOfMarriage']">
                                    <label> Date of Marriage</label>
                                    <p>{{tabpopData['dateOfMarriage'] | formatDate }}</p>
                                </li>

                                <li v-if="tabpopData['placeOfMarriage']">
                                    <label> Place of Marriage</label>
                                    <p>
                                        {{ tabpopData.placeOfMarriage | addformat}}

                                    </p>
                                </li>

                            </ul>
                            <!-- <div class="gc_app_details-list list-items" v-if="allOtherNamesUsedValid && tabpopData.allOtherNamesUsed.length>0" >
                <label>All other names you have used including maiden name and last names from previous marriages</label>
                <template v-for="(allOtherNamesUsed,anindex) in tabpopData.allOtherNamesUsed"  >
                   <p v-if="allOtherNamesUsed.firstName || allOtherNamesUsed.lastName " :key="anindex">
                     <span>{{anindex+1}}.</span>{{allOtherNamesUsed.firstName  }} {{allOtherNamesUsed.middleName}} {{allOtherNamesUsed.lastName }}

                  </p>
                  </template>

              </div> -->
                            <ul>
                                <li v-if="tabpopData.homePhoneNumber">
                                    <label>Daytime Telephone Number</label>
                                    <p>{{tabpopData.homePhoneNumber}}</p>
                                </li>
                                <li v-if="tabpopData.cellPhoneNumber">
                                    <label>Mobile Telephone Number</label>
                                    <p>{{tabpopData.cellPhoneNumber}}</p>
                                </li>
                                <li v-if="tabpopData.SSN">
                                    <label>Social Security number (If any)</label>
                                    <p>{{tabpopData.SSN }}</p>
                                </li>
                                <li v-if="tabpopData.alienNumber">
                                    <label>Your Alien Number (if applicable)</label>
                                    <p>{{tabpopData.alienNumber }}</p>
                                </li>
                                <li v-if="tabpopData.passportNumber">
                                    <label>Passport Number</label>
                                    <p>{{tabpopData.passportNumber}}</p>
                                </li>
                                <li v-if="tabpopData.passportExpiryDate">
                                    <label>Passport Expiration Date</label>
                                    <p>{{ tabpopData.passportExpiryDate | formatDate}}</p>
                                </li>
                                <li class="col-2" v-if="tabpopData.placeOfBirth">
                                    <label>Place Of Birth</label>
                                    <p>{{ tabpopData.placeOfBirth | addformat}}</p>
                                </li>

                                <li v-if="tabpopData.dayTimePhoneNumber">
                                    <label>Daytime Telephone Number</label>
                                    <p>{{tabpopData.dayTimePhoneNumber}}</p>
                                </li>

                                <li v-if="tabpopData.phoneNumber">
                                    <label>Mobile Telephone Number</label>
                                    <p>{{tabpopData.phoneNumber}}</p>
                                </li>

                                <li v-if="tabpopData.SSN">
                                    <label>Social Security Number</label>
                                    <p>{{tabpopData.SSN}}</p>
                                </li>
                                <li v-if="tabpopData.alienNumber">
                                    <label>Alien Number</label>
                                    <p>{{tabpopData.alienNumber}}</p>
                                </li>

                                <li v-if="tabpopData.passportNumber">
                                    <label>Passport Number</label>
                                    <p>{{tabpopData.passportNumber}}</p>
                                </li>

                                <li v-if="tabpopData.passportExpiryDate">
                                    <label>Passport Expiration Date</label>
                                    <p>{{tabpopData.passportExpiryDate | formatDate}}</p>
                                </li>
                                <li v-if="tabpopData.nationality">
                                    <label>Nationality</label>
                                    <p>{{tabpopData.nationality.name}}</p>
                                </li>

                                <li v-if="tabpopData.height !=null && tabpopData.height.feet !=null &&  tabpopData.height.inches !=null">
                                    <label>Height</label>
                                    <p>{{tabpopData.height.feet}} feet {{tabpopData.height.inches}} inches</p>
                                </li>
                                <li v-if="tabpopData.weight">
                                    <label>Weight</label>
                                    <p>{{tabpopData.weight}}</p>
                                </li>
                                <li v-if="tabpopData.race">
                                    <label>Race</label>
                                    <p>{{tabpopData.race.name}}</p>
                                </li>
                                <li v-if="tabpopData.hairColor">
                                    <label>Hair Color</label>
                                    <p>{{ tabpopData.hairColor.name}}</p>
                                </li>
                                <li class="col-2" v-if="tabpopData.eyeColor">
                                    <label>Eye Color</label>
                                    <p>{{ tabpopData.eyeColor.name}}</p>
                                </li>

                            </ul>

                            <!-- //allOtherNamesUsed -->
                            <template v-if="checkEmptyorNullObj(tabpopData.allOtherNamesUsed) && tabpopData.allOtherNamesUsed !=null && tabpopData.allOtherNamesUsed.length>0">
                                <div class="gc_scrool-cnt">
                                    <h6>All other names you have used including maiden name and last names from previous marriages</h6>
                                    <ul v-for=" otn in tabpopData.allOtherNamesUsed" :key="otn">
                                        <li v-if="otn.firstName && otn.firstName !=''">
                                            <label>First Name</label>
                                            <p>{{otn.firstName}}</p>
                                        </li>
                                        <li v-if="otn.middleName && otn.middleName !=''">
                                            <label>Middle Name</label>
                                            <p>{{otn.middleName}}</p>
                                        </li>

                                        <li v-if="otn.lastName && otn.lastName !=''">
                                            <label>Last Name</label>
                                            <p>{{otn.lastName}}</p>
                                        </li>

                                    </ul>

                                </div>
                            </template>

                            <template v-if="tabpopData.previouslyMarried == 'Yes' && tabpopData['previouslyMarried']">

                                <div class="gc_scrool-cnt">
                                    <h6>Previous Spouse</h6>
                                    <ul>

                                        <li v-if="tabpopData['previouslyMarried']['firstName']">
                                            <label>First Name</label>
                                            <p>{{tabpopData['previouslyMarried']['firstName']}}</p>
                                        </li>
                                        <li v-if="tabpopData['previouslyMarried']['middleName']">
                                            <label>Middle Name</label>
                                            <p>{{tabpopData['previouslyMarried']['middleName']}}</p>
                                        </li>
                                        <li v-if="tabpopData['previouslyMarried']['lastName']">
                                            <label>Last Name</label>
                                            <p>{{tabpopData['previouslyMarried']['lastName']}}</p>
                                        </li>

                                        <li v-if="tabpopData['previouslyMarried']['placeOfMarriage']">
                                            <label>Place Of Marriage</label>
                                            <p>
                                                {{ tabpopData['previouslyMarried']['placeOfMarriage'] | addformat}}

                                            </p>
                                        </li>

                                        <li v-if="tabpopData['previouslyMarried']['dateOfMarriageEnded']">
                                            <label>Date Of Marriage Ended</label>
                                            <p>{{tabpopData['previouslyMarried']['dateOfMarriageEnded'] | fromDate}}</p>
                                        </li>

                                        <li v-if="tabpopData['previouslyMarried']['placeOfTermination']">
                                            <label>Place Of Termination</label>
                                            <p>{{tabpopData['previouslyMarried']['placeOfTermination'] }}</p>
                                        </li>

                                    </ul>
                                </div>
                            </template>

                            <div class="gc_app_details-list" v-if="applicationRequired && tabpopData.applicationRequired !=null &&  tabpopData.applicationRequired !=undefined">
                                <label>Adjustment of status to Permanent Residency (Form I-485) required for your Child?</label>
                                <p v-if="tabpopData.applicationRequired" class="yes_option">Yes</p>
                                <p v-if="!tabpopData.applicationRequired" class="no_option">No</p>
                            </div>

                            <div class="gc_app_details-list" v-if="tabpopData.haveMarriageCertificate">
                                <label>Have a Marriage Certificate?</label>
                                <p v-if="tabpopData.haveMarriageCertificate=='Yes'" class="yes_option">Yes</p>
                                <p v-if="tabpopData.haveMarriageCertificate !='Yes'" class="no_option">No</p>
                            </div>

                            <div class="gc_app_details-list" v-if="tabpopData.birthCertHaveNamePobDob">
                                <label>If your name is different from that stated on your birth certificate, have you had it legally changed?</label>
                                <p v-if="tabpopData.birthCertHaveNamePobDob=='Yes'" class="yes_option">Yes</p>
                                <p v-if="tabpopData.birthCertHaveNamePobDob !='Yes'" class="no_option">No</p>
                            </div>

                            <div class="gc_app_details-list" v-if="tabpopData.have2AffidavitsAttestingToMarriage">
                                <label>
                                    Do you have Two (2) Affidavits of Birth from family members?

                                </label>
                                <p v-if="tabpopData.have2AffidavitsAttestingToMarriage=='No'" class="no_option">No</p>
                                <p v-if="tabpopData.have2AffidavitsAttestingToMarriage=='Yes'" class="yes_option">Yes</p>
                            </div>

                            <div class="gc_app_details-list" v-if=" tabpopData.previouslyMarried =='Yes' ||  tabpopData.previouslyMarried=='No'">
                                <label>
                                    Married previously?

                                </label>
                                <p v-if="tabpopData.previouslyMarried=='No'" class="no_option">No</p>
                                <p v-if="tabpopData.previouslyMarried=='Yes'" class="yes_option">Yes</p>
                            </div>

                            <template v-if="tabpopData.previouslyMarried == 'Yes' && tabpopData['previouslyMarried']">

                                <div class="gc_app_details-list">
                                    <label>
                                        Obtain U.S Permanent Residence Through Spouse?

                                    </label>
                                    <p v-if=" tabpopData['previouslyMarried']['obtainPermResidenceThroughSpouse'] =='No'" class="no_option">No</p>
                                    <p v-if=" tabpopData['previouslyMarried']['obtainPermResidenceThroughSpouse'] =='Yes'" class="yes_option">Yes</p>
                                </div>

                            </template>

                        </div>
                    </VuePerfectScrollbar>
                </div>
            </div>
            <!-- End personal_info-->

            <!-- Address Tab--->
            <div class="gc_appcontent_right" v-if="popupSubTabs['address']">
                <div class="gc_app_details-cnt">
                    <VuePerfectScrollbar :ref="popupSubTabs['address']" class="scroll-area--nofications-dropdown p-0" :settings="settings">
                        <template v-if="
                   tabpopData['address'] &&
                   (tabpopData['address']['line1'] !=null && tabpopData['address']['line1'] !='')
                   || (tabpopData['address']['line2'] !=null && tabpopData['address']['line2'] !='')
                   ||  (tabpopData['address']['location'] !=undefined && tabpopData['address']['location'])
                   ||  tabpopData['address']['state'] !=null
                   ||  tabpopData['address']['country'] !=null
                   ||   tabpopData['address']['zipcode'] !=null
              ">

                            <div class="gc_scrool-cnt">
                                <h6>Current US Home Address</h6>
                                <ul>
                                    <li v-if="tabpopData.address && tabpopData['address']['line1'] !=null && tabpopData['address']['line1'] !='' ">
                                        <label>Street Address</label>

                                        <p>{{tabpopData.address.line1}}</p>

                                    </li>
                                    <li v-if="tabpopData.address && tabpopData['address']['line2'] !=null && tabpopData['address']['line2'] !=''">
                                        <label>Apt, Suite</label>
                                        <p>{{tabpopData.address.line2}}</p>
                                    </li>
                                    <li v-if="tabpopData.address && tabpopData.address['location'] !=undefined && tabpopData.address['location']">
                                        <label>Location</label>
                                        <p>{{tabpopData.address.location.name }}</p>
                                    </li>
                                    <li v-if="tabpopData['address'] && tabpopData['address']['state'] !=null">
                                        <label>State</label>
                                        <p>{{tabpopData.address.state.name}}</p>
                                    </li>

                                    <li v-if="tabpopData['address'] && tabpopData['address']['country'] !=null">
                                        <label>Country</label>
                                        <p>{{tabpopData.address.country.name}}</p>
                                    </li>
                                    <li v-if="tabpopData['address'] && tabpopData['address']['zipcode'] !=null">
                                        <label>Zip Code</label>
                                        <p>{{tabpopData.address.zipcode}}</p>
                                    </li>
                                </ul>
                            </div>
                        </template>

                        <template v-if="tabpopData['mailingAddress'] &&

                   (tabpopData['mailingAddress']['line1'] !=null && tabpopData['mailingAddress']['line1'] !='')
                   || (tabpopData['mailingAddress']['line2'] !=null && tabpopData['mailingAddress']['line2'] !='')
                   ||  (tabpopData['mailingAddress']['location'] !=undefined && tabpopData['mailingAddress']['location'])
                   ||  tabpopData['mailingAddress']['state'] !=null
                   ||  tabpopData['mailingAddress']['country'] !=null
                   ||   tabpopData['mailingAddress']['zipcode'] !=null
                ">
                            <div class="gc_scrool-cnt">
                                <h6>Current Mailing Address </h6>
                                <ul>

                                    <li v-if="tabpopData['mailingAddress']['line1'] !=null && tabpopData['mailingAddress']['line1'] !=''">
                                        <label>Street Address</label>

                                        <p>{{tabpopData.mailingAddress.line1}}</p>

                                    </li>
                                    <li v-if="(tabpopData['mailingAddress']['line2'] !=null && tabpopData['mailingAddress']['line2'] !='')">
                                        <label>Apt, Suite</label>
                                        <p>{{tabpopData.mailingAddress.line2}}</p>
                                    </li>
                                    <li v-if="tabpopData.mailingAddress && tabpopData.mailingAddress['location'] !=undefined && tabpopData.mailingAddress['location']">
                                        <label>Location</label>
                                        <p>{{tabpopData.mailingAddress.location.name }}</p>
                                    </li>
                                    <li v-if="tabpopData['mailingAddress'] && tabpopData['mailingAddress']['state'] !=null">
                                        <label>State</label>
                                        <p>{{tabpopData.mailingAddress.state.name}}</p>
                                    </li>

                                    <li v-if="tabpopData['mailingAddress'] && tabpopData['mailingAddress']['country'] !=null">
                                        <label>Country</label>
                                        <p>{{tabpopData.mailingAddress.country.name}}</p>
                                    </li>
                                    <li v-if="tabpopData['mailingAddress'] && tabpopData['mailingAddress']['zipcode'] !=null">
                                        <label>Zip Code</label>
                                        <p>{{tabpopData.mailingAddress.zipcode}}</p>
                                    </li>
                                </ul>
                            </div>

                        </template>

                        <template v-if="checkEmptyorNullObj(tabpopData['residenceAddressUSAbroad'])">
                            <div class="gc_scrool-cnt">
                                <h6>Your Residence starting with most current for the Past Five Years in the U.S and Aboard</h6>
                                <ul v-for="residenceAddressUSAbroad in tabpopData.residenceAddressUSAbroad" :key="residenceAddressUSAbroad">

                                    <li v-if="residenceAddressUSAbroad['line1'] !=null && residenceAddressUSAbroad['line1'] !=''">
                                        <label>Street Address</label>

                                        <p>{{residenceAddressUSAbroad.line1}}</p>

                                    </li>
                                    <li v-if="residenceAddressUSAbroad['line2'] !=null && residenceAddressUSAbroad['line2'] !=''">
                                        <label>Apt, Suite</label>
                                        <p>{{residenceAddressUSAbroad.line2}}</p>
                                    </li>
                                    <li v-if="residenceAddressUSAbroad && residenceAddressUSAbroad['location'] !=undefined && residenceAddressUSAbroad['location']">
                                        <label>Location</label>
                                        <p>{{residenceAddressUSAbroad.location.name }}</p>
                                    </li>
                                    <li v-if="residenceAddressUSAbroad && residenceAddressUSAbroad['state'] !=null">
                                        <label>State</label>
                                        <p>{{residenceAddressUSAbroad.state.name}}</p>
                                    </li>

                                    <li v-if="residenceAddressUSAbroad['country'] !=null">
                                        <label>Country</label>
                                        <p>{{residenceAddressUSAbroad.country.name}}</p>
                                    </li>
                                    <li v-if="residenceAddressUSAbroad['zipcode'] !=null">
                                        <label>Zip Code</label>
                                        <p>{{residenceAddressUSAbroad.zipcode}}</p>
                                    </li>
                                    <li v-if="residenceAddressUSAbroad && residenceAddressUSAbroad['fromDate'] !=null && residenceAddressUSAbroad['fromDate'] !=''">
                                        <label>From Date</label>
                                        <p>{{residenceAddressUSAbroad.fromDate | formatDate }}</p>
                                    </li>
                                    <li v-if="tabpopData['residenceAddressUSAbroad'] && residenceAddressUSAbroad['toDate'] !=null && residenceAddressUSAbroad['toDate'] !=''">
                                        <label>To Date</label>
                                        <p>{{residenceAddressUSAbroad.toDate | formatDate}}</p>
                                    </li>
                                </ul>
                            </div>

                        </template>

                        <template v-if="checkEmptyorNullObj(tabpopData['lastAddressOutsideUS'])">
                            <div class="gc_scrool-cnt">
                                <h6>Last Address outside Of the United States for more than one year</h6>
                                <ul>

                                    <li v-if="tabpopData['lastAddressOutsideUS'] && tabpopData['lastAddressOutsideUS']['line1'] !=null && tabpopData['lastAddressOutsideUS']['line1'] !=''">
                                        <label>Street Address</label>

                                        <p>{{tabpopData.lastAddressOutsideUS.line1}}</p>

                                    </li>
                                    <li v-if="tabpopData['lastAddressOutsideUS'] && tabpopData['lastAddressOutsideUS']['line2'] !=null && tabpopData['lastAddressOutsideUS']['line2'] !=''">
                                        <label>Apt, Suite</label>
                                        <p>{{tabpopData.lastAddressOutsideUS.line2}}</p>
                                    </li>
                                    <li v-if="tabpopData.lastAddressOutsideUS && tabpopData.lastAddressOutsideUS['location'] !=undefined && tabpopData.lastAddressOutsideUS['location']">
                                        <label>Location</label>
                                        <p>{{tabpopData.lastAddressOutsideUS.location.name }}</p>
                                    </li>
                                    <li v-if="tabpopData['lastAddressOutsideUS'] && tabpopData['lastAddressOutsideUS']['state'] !=null">
                                        <label>State</label>
                                        <p>{{tabpopData.lastAddressOutsideUS.state.name}}</p>
                                    </li>

                                    <li v-if="tabpopData['lastAddressOutsideUS'] && tabpopData['lastAddressOutsideUS']['country'] !=null">
                                        <label>Country</label>
                                        <p>{{tabpopData.lastAddressOutsideUS.country.name}}</p>
                                    </li>
                                    <li v-if="tabpopData['lastAddressOutsideUS'] && tabpopData['lastAddressOutsideUS']['zipcode'] !=null">
                                        <label>Zip Code</label>
                                        <p>{{tabpopData.lastAddressOutsideUS.zipcode}}</p>
                                    </li>
                                    <li v-if="tabpopData['lastAddressOutsideUS'] && tabpopData['lastAddressOutsideUS']['fromDate'] !=null">
                                        <label>From Date</label>
                                        <p>{{tabpopData.lastAddressOutsideUS.fromDate | formatDate}}</p>
                                    </li>
                                    <li v-if="tabpopData['lastAddressOutsideUS'] && tabpopData['lastAddressOutsideUS']['toDate'] !=null">
                                        <label>To Date</label>
                                        <p>{{tabpopData.lastAddressOutsideUS.toDate | formatDate }}</p>
                                    </li>
                                </ul>
                            </div>

                        </template>

                    </VuePerfectScrollbar>
                </div>
            </div>
            <!--End Address Tab--->

            <!---immigration--->
            <div class="gc_appcontent_right" v-if="popupSubTabs['immigration']">
                <div class="gc_app_details-cnt">
                    <VuePerfectScrollbar :ref="popupSubTabs['immigration']" class="scroll-area--nofications-dropdown p-0" :settings="settings">
                        <div class="gc_scrool-cnt">
                            <ul>
                                <li v-if="tabpopData['currentStatus']">
                                    <label>Current Status</label>
                                    <p>{{tabpopData['currentStatus']}}</p>

                                </li>

                                <li v-if="tabpopData['statusExpiryDate']">
                                    <label>Status Expiry Date</label>
                                    <p>{{tabpopData.statusExpiryDate | formatDate}}</p>
                                </li>
                                <li v-if="checkEmptyorNullObj(tabpopData['lastEntryPlaceInUs'])">
                                    <label>Place of Last Entry into the USA</label>
                                    <p>

                                        {{ tabpopData['lastEntryPlaceInUs'] | addformat}}

                                    </p>
                                </li>
                                <li v-if="tabpopData['visaIssuedDate'] !=null">
                                    <label>Case Issued Date</label>
                                    <p>{{tabpopData['visaIssuedDate'] | formatDate}}</p>
                                </li>

                                <li v-if="tabpopData['visaExpiryDate'] !=null">
                                    <label>Case Expiry Date</label>
                                    <p>{{tabpopData['visaExpiryDate'] | formatDate}}</p>
                                </li>

                                <li v-if="tabpopData['visaIssuedAt'] && tabpopData['visaIssuedAt'] !=null && tabpopData['visaIssuedAt'] !=undefined">
                                    <label>Case Issued At</label>
                                    <p>{{tabpopData['visaIssuedAt'] }}</p>
                                </li>
                                <!-- Most Recent Entry into the USA-->
                                <li v-if="tabpopData['mostRecentEntryDateInUs'] && tabpopData['mostRecentEntryDateInUs'] !=null && tabpopData['mostRecentEntryDateInUs'] !=undefined">
                                    <label>Most Recent Entry into the USA</label>
                                    <p>{{tabpopData['mostRecentEntryDateInUs'] | formatDate}}</p>
                                </li>

                                <li v-if="tabpopData['initialEntryDateInUs'] && tabpopData['initialEntryDateInUs'] !=null">
                                    <label>Initial (First) Entry into the USA</label>
                                    <p>{{tabpopData['initialEntryDateInUs'] | formatDate}}</p>
                                </li>
                                <!-- Manner of Most recent entry into the USA -->
                                <li v-if="tabpopData['mannerOfMostEntryInUs'] && tabpopData['mannerOfMostEntryInUs'] && tabpopData['mannerOfMostEntryInUs'] !=null">
                                    <label>Manner of Most recent entry into the USA</label>
                                    <p>{{tabpopData['mannerOfMostEntryInUs'] }}</p>
                                </li>

                                <!-- Expiration Date on Form I-94 -->
                                <li v-if="tabpopData['formI94ExpiryDate'] && tabpopData['formI94ExpiryDate'] !=null">
                                    <label>Expiration Date on Form I-94</label>
                                    <p>{{tabpopData['formI94ExpiryDate'] | formatDate}}</p>
                                </li>

                                <li v-if="tabpopData['i140PrioityDate'] && tabpopData['i140PrioityDate'] !=null">
                                    <label>Priority Date of I-140</label>
                                    <p>{{tabpopData['i140PrioityDate'] | formatDate}}</p>
                                </li>
                                <!-- Most Recent Form I-94 Card Number -->
                                <li v-if="tabpopData['formI94CardNumber'] && tabpopData['formI94CardNumber'] !=null">
                                    <label>Most Recent Form I-94 Card Number</label>
                                    <p>{{tabpopData['formI94CardNumber'] }}</p>
                                </li>

                                <li v-if="tabpopData['residedFromDateinUs'] && tabpopData['residedFromDateinUs'] !=null">
                                    <label>Date From which you have reside in the USA</label>
                                    <p>{{tabpopData['residedFromDateinUs'] | formatDate }}</p>
                                </li>
                                <!-- Current Non Immigrant Visa Number -->
                                <li v-if="tabpopData['nonImmVisaNumber'] && tabpopData['nonImmVisaNumber'] !=null">
                                    <label>Current Non Immigrant Case Number</label>
                                    <p>{{tabpopData['nonImmVisaNumber'] }}</p>
                                </li>

                                <li v-if="tabpopData['classificationCategory'] && tabpopData['classificationCategory'] !=null">
                                    <label>Classification</label>
                                    <p>{{tabpopData['classificationCategory']['name'] }}</p>
                                </li>

                            </ul>
                            <template v-if="checkEmptyorNullObj(tabpopData['allCountryIssuedPassports'])">
                                <span>All Countries that have Issued you a currently valid passport </span>
                                <ul class="list_items" v-for="cp in tabpopData['allCountryIssuedPassports']" :key="cp">
                                    <li v-if="cp['country']">
                                        <label>Country</label>
                                        <p>{{cp['country']['name']}}</p>
                                    </li>
                                    <li v-if="cp['number']">
                                        <label>Passport Number</label>
                                        <p>{{cp['number']}}</p>
                                    </li>
                                    <li v-if="cp['issuedDate']">
                                        <label>Issued Date</label>
                                        <p>{{cp['issuedDate'] | formatDate}}</p>
                                    </li>
                                    <li v-if="cp['expiryDate']">
                                        <label>Expiration Date</label>
                                        <p>{{cp['expiryDate'] | formatDate}}</p>
                                    </li>
                                </ul>
                            </template>

                            <div class="gc_app_details-list" v-if="tabpopData['areYouInpectedByImmOfficer']">
                                <label>Were you inspected by any Immigration Officer?</label>
                                <p class="yes_option" v-if="tabpopData['areYouInpectedByImmOfficer']=='Yes'">Yes</p>
                                <p class="no_option" v-if="tabpopData['areYouInpectedByImmOfficer']=='No'">No</p>
                            </div>
                            <div class="gc_app_details-list" v-if="tabpopData['everIssuedEADFromUscis']">
                                <label>Have you ever Been Issued an Employment Authorization document (EAD) from the USCIS?</label>
                                <p class="yes_option" v-if="tabpopData['everIssuedEADFromUscis']=='Yes'">Yes</p>
                                <p class="no_option" v-if="tabpopData['everIssuedEADFromUscis']=='No'">No</p>
                            </div>
                            <div class="gc_app_details-list" v-if="tabpopData['enterByVisaWaiverProgram']">
                                <label>Did You Enter in US Under Case Waiver Program</label>
                                <p class="yes_option" v-if="tabpopData['enterByVisaWaiverProgram']=='Yes'">Yes</p>
                                <p class="no_option" v-if="tabpopData['enterByVisaWaiverProgram']=='No'">No</p>
                            </div>
                            <template v-if="tabpopData['holdPermResidenceInOtherCountry']">
                                <div class="gc_app_details-list" v-if="tabpopData['holdPermResidenceInOtherCountry']">
                                    <label>Do you hold "Permanent Residence" in other country?</label>
                                    <p class="yes_option" v-if="tabpopData['holdPermResidenceInOtherCountry']=='Yes'">Yes</p>
                                    <p class="no_option" v-if="tabpopData['holdPermResidenceInOtherCountry']=='No'">No</p>
                                </div>
                                <div class="gc_app_details-list" v-if="tabpopData['permResidenceInOtherCountry']">
                                    <label>Country</label>
                                    <p>{{tabpopData['permResidenceInOtherCountry']['name']}}</p>
                                </div>
                            </template>
                            <div class="gc_app_details-list" v-if="tabpopData['everApplyPermResidentStatus']">
                                <label>Have you ever applied for AOS in the U.S. or an Immigrant case at an U.S. Embassy/Consulate to obtain permanent resident status before?</label>
                                <p class="yes_option" v-if="tabpopData['everApplyPermResidentStatus']=='Yes'">Yes</p>
                                <p class="no_option" v-if="tabpopData['everApplyPermResidentStatus']=='No'">No</p>
                            </div>
                        </div>

                    </VuePerfectScrollbar>
                </div>
            </div>
            <!--END immigration--->

            <!--occupational_skills--->
            <div class="gc_appcontent_right" v-if="popupSubTabs['occupational_skills']">
                <div class="gc_app_details-cnt">
                    <VuePerfectScrollbar :ref="popupSubTabs['occupational_skills']" class="scroll-area--nofications-dropdown p-0" :settings="settings">
                        <div class="gc_scrool-cnt">

                            <div class="gc_scrool-cnt">
                                <template v-if="tabpopData['education'] && tabpopData['education'].length>0">
                                    <h6>Education</h6>
                                    <ul class="education" v-for=" edu in tabpopData['education']" :key="edu">
                                        <li v-if="edu['schoolName']">
                                            <label>School Name</label>
                                            <p>{{ edu['schoolName']}}</p>

                                        </li>
                                        <li v-if="edu['degree']">
                                            <label>Degree</label>
                                            <p>{{ edu['degree']}}</p>
                                        </li>
                                        <li v-if="edu['fieldOfStudy']">
                                            <label>Field of Study</label>
                                            <p>{{ edu['fieldOfStudy']}}</p>
                                        </li>
                                        <li v-if="edu['fromDate']">
                                            <label>From Date</label>
                                            <p>{{ edu['fromDate'] | formatDate}}</p>
                                        </li>
                                        <li v-if="edu['toDate']">
                                            <label>To Date</label>
                                            <p>{{ edu['toDate'] | formatDate}}</p>
                                        </li>
                                    </ul>
                                </template>

                                <ul class="w-full" v-if=" (tabpopData['currentJobTitle'] != null && tabpopData['currentJobTitle'] !='' ) ||  ( tabpopData['currentJobTitle'] != null && tabpopData['currentJobTitle'] !='' ) || ( tabpopData['currentAnnualSalary'] != null && tabpopData['currentAnnualSalary'] !='' )">
                                    <li class="width50" v-if="tabpopData['currentJobTitle'] !=null && tabpopData['currentJobTitle'] !=''">
                                        <label>Current Job Title</label>
                                        <p>{{ tabpopData['currentJobTitle']}}</p>
                                    </li>
                                    <li class="width50" v-if="tabpopData['employerName']!= null && tabpopData['employerName']!=''">
                                        <label>Current Employer Name</label>
                                        <p>{{ tabpopData['currentJobTitle']}}</p>
                                    </li>

                                    <li class="width50" v-if="tabpopData['currentAnnualSalary'] != null && tabpopData['currentAnnualSalary'] !='' ">
                                        <label>Current Annual Salary</label>
                                        <p>{{ tabpopData['currentAnnualSalary'] | formatprice}}</p>
                                    </li>

                                    <li class="width50" v-if="tabpopData['employerAddress']">
                                        <label>Employer Address</label>
                                        <p>{{ tabpopData['employerAddress'] }}</p>
                                    </li>
                                </ul>
                                <template v-if="checkEmptyorNullObj(tabpopData['employmentHistoryUSAbroad']) && tabpopData['employmentHistoryUSAbroad'].length>0">

                                    <h6>The following information about your current and past employment for the past five years in the U.S and aboard starting with your most current Job</h6>
                                    <ul class="list_items" v-for="emp in tabpopData['employmentHistoryUSAbroad'] " :key='emp'>
                                        <li v-if=" emp['employerName'] !=null  && emp['employerName']">
                                            <label>Name of Employer</label>
                                            <p>{{emp['employerName']}}</p>
                                        </li>

                                        <li v-if=" emp['occupation'] !=null  && emp['occupation']">
                                            <label>Occupation</label>
                                            <p>{{emp['occupation']}}</p>
                                        </li>

                                        <li v-if=" emp['fromDate'] !=null  && emp['fromDate']">
                                            <label>From Date</label>
                                            {{emp['fromDate'] | formatDate}}
                                        </li>
                                        <li v-if=" emp['toDate'] !=null  && emp['toDate']">
                                            <label>To Date</label>
                                            <p>{{emp['toDate'] | formatDate}}</p>
                                        </li>
                                        <li v-if="emp['address'] &&  emp['address']['line1'] !=null && emp['address']['line1'] !=''">
                                            <label>Street Address</label>
                                            <p>{{ emp['address']['line1']}}</p>
                                        </li>
                                        <li v-if="emp['address'] &&  emp['address']['line2'] !=null && emp['address']['line2'] !=''">
                                            <label>Apt, Suite</label>
                                            <p>{{ emp['address']['line2']}}</p>
                                        </li>
                                        <!-- <li v-if="emp['address'] !=null || (emp['address']['city'] !=null) || emp['address']['state'] !=null || emp['address']['country'] !=null

                  " >
                    <label>Location</label>
                    <p>
                      {{emp['address']['city']['name']}}
                      {{ emp['address']['city']['name']&& emp['address']['state']? ', '+emp['address']['state']['name']:'' }}
                       {{ emp['address']['state']['name']&& emp['address']['country']? ' , '+emp['address']['country']['name']:'' }}

                    </p>
                  </li> -->
                                        <li v-if="emp['address'] && emp['address']['zipcode'] !=null && emp['address']['zipcode'] !='' ">
                                            <label>Zip Code</label>
                                            <p>{{ emp['address']['zipcode']}}</p>
                                        </li>
                                    </ul>

                                </template>
                                <template v-if="checkEmptyorNullObj(tabpopData['lastEmployerOutsideUS']) ">
                                    <h6>Last Employer outside of the United States for more than one year</h6>
                                    <ul class="list_items">
                                        <li v-if=" tabpopData['lastEmployerOutsideUS']['employerName'] !=null  && tabpopData['lastEmployerOutsideUS']['employerName']">
                                            <label>Name of Employer</label>
                                            <p>{{tabpopData['lastEmployerOutsideUS']['employerName']}}</p>
                                        </li>

                                        <li v-if=" tabpopData['lastEmployerOutsideUS']['occupation'] !=null  && tabpopData['lastEmployerOutsideUS']['occupation']">
                                            <label>Occupation</label>
                                            <p>{{tabpopData['lastEmployerOutsideUS']['occupation']}}</p>
                                        </li>

                                        <li v-if=" tabpopData['lastEmployerOutsideUS']['fromDate'] !=null  && tabpopData['lastEmployerOutsideUS']['fromDate']">
                                            <label>From Date</label>
                                            {{tabpopData['lastEmployerOutsideUS']['fromDate'] | formatDate}}
                                        </li>
                                        <li v-if=" tabpopData['lastEmployerOutsideUS']['toDate'] !=null  && tabpopData['lastEmployerOutsideUS']['toDate']">
                                            <label>To Date</label>
                                            <p>{{tabpopData['lastEmployerOutsideUS']['toDate'] | formatDate}}</p>
                                        </li>
                                        <li v-if="tabpopData['lastEmployerOutsideUS']['address'] &&  tabpopData['lastEmployerOutsideUS']['address']['line1'] !=null && tabpopData['lastEmployerOutsideUS']['address']['line1'] !=''">
                                            <label>Street Address</label>
                                            <p>{{ tabpopData['lastEmployerOutsideUS']['address']['line1']}}</p>
                                        </li>
                                        <li v-if="tabpopData['lastEmployerOutsideUS']['address'] &&  tabpopData['lastEmployerOutsideUS']['address']['line2'] !=null && tabpopData['lastEmployerOutsideUS']['address']['line2'] !=''">
                                            <label>Apt, Suite</label>
                                            <p>{{ tabpopData['lastEmployerOutsideUS']['address']['line2']}}</p>
                                        </li>
                                        <li v-if="tabpopData['lastEmployerOutsideUS']['address'] && tabpopData['lastEmployerOutsideUS']['address']['zipcode'] !=null && tabpopData['lastEmployerOutsideUS']['address']['zipcode'] !='' ">
                                            <label>Zip Code</label>
                                            <p>{{ tabpopData['lastEmployerOutsideUS']['address']['zipcode']}}</p>
                                        </li>
                                    </ul>

                                </template>

                            </div>

                        </div>

                    </VuePerfectScrollbar>
                </div>
            </div>
            <!-----END occupational_skills--->

            <!----assets_financials--->
            <div class="gc_appcontent_right" v-if="popupSubTabs['assets_financials']">
                <div class="gc_app_details-cnt">
                    <VuePerfectScrollbar :ref="popupSubTabs['assets_financials']" class="scroll-area--nofications-dropdown p-0" :settings="settings">
                        <div class="gc_scrool-cnt">
                            <template v-if=" tabpopData['assets'] !=undefined && tabpopData['assets']!=null && tabpopData['assets'].length>0  ">
                                <h6>Assets</h6>
                                <ul v-for=" ( asst , indx) in tabpopData['assets']" :key="indx">
                                    <li v-if="asst['aType'] && asst['aType'] !=null && asst['aType'] !=''">
                                        <label>Type</label>
                                        <p>{{asst['aType']['name']}}</p>
                                    </li>
                                    <li v-if="asst['nameOfHolder'] && asst['nameOfHolder'] !=null && asst['nameOfHolder'] !=''">
                                        <label>Name of the Holder</label>
                                        <p>{{asst['nameOfHolder']}}</p>
                                    </li>
                                    <li v-if="asst['amount'] && asst['amount'] !=null && asst['amount'] !=''">
                                        <label>Amount</label>
                                        <p>{{asst['amount'] | formatprice}}</p>
                                    </li>
                                </ul>
                            </template>
                            <h6>Financials</h6>
                            <ul class="list_items">
                                <li v-if="tabpopData['depositsInUSBank'] && tabpopData['depositsInUSBank'] !=null && tabpopData['depositsInUSBank'] !=''">
                                    <label>Deposits in Bank in the USA</label>
                                    <p>{{tabpopData['depositsInUSBank'] | formatprice}}</p>
                                </li>
                                <li v-if="tabpopData['valueOfRealEstate'] && tabpopData['valueOfRealEstate'] !=null && tabpopData['valueOfRealEstate'] !=''">
                                    <label>Value of Real Estate, If Owned</label>
                                    <p>{{tabpopData['valueOfRealEstate'] | formatprice}}</p>
                                </li>
                                <li v-if="tabpopData['cashSurrenderValueOfLifeInsurance'] && tabpopData['cashSurrenderValueOfLifeInsurance'] !=null && tabpopData['cashSurrenderValueOfLifeInsurance'] !=''">
                                    <label>Cash Surrender Value of Life Insurance</label>
                                    <p>{{ tabpopData['cashSurrenderValueOfLifeInsurance'] | formatprice}}</p>
                                </li>

                                <li v-if="tabpopData['reasonableValueProperty'] && tabpopData['reasonableValueProperty'] !='' && tabpopData['reasonableValueProperty'] !=null">
                                    <label>Reasonable Value of Personal Property</label>
                                    <p>{{ tabpopData['reasonableValueProperty'] | formatprice}}</p>
                                </li>
                                <li v-if="tabpopData['marketValueOfStocksBonds'] && tabpopData['marketValueOfStocksBonds'] !=null && tabpopData['marketValueOfStocksBonds'] !=''">
                                    <label>Market Value of Stocks and Bons</label>
                                    <p>{{ tabpopData['marketValueOfStocksBonds'] | formatprice}}</p>
                                </li>

                                <li v-if="tabpopData['creditScore'] && tabpopData['creditScore'] !=null && tabpopData['creditScore'] !=''">
                                    <label>Credit Score</label>
                                    <p>{{ tabpopData['creditScore'] | formatprice}}</p>
                                </li>

                                <li v-if="tabpopData['amountOfMortgageOnProperty'] && tabpopData['amountOfMortgageOnProperty'] !=null && tabpopData['amountOfMortgageOnProperty'] !=''">
                                    <label>Amount of Mortgage on the Property</label>
                                    <p>{{ tabpopData['amountOfMortgageOnProperty'] | formatprice}}</p>
                                </li>

                                <li v-if="tabpopData['sumOfLifeInsurance'] && tabpopData['sumOfLifeInsurance'] != null && tabpopData['sumOfLifeInsurance'] !=''">
                                    <label>Sum of Life Insurance</label>
                                    <p>{{ tabpopData['sumOfLifeInsurance'] | formatprice}}</p>
                                </li>
                                <template v-if="tabpopData['healthInsurance']">
                                    <li v-if="tabpopData['healthInsurance'] && tabpopData['healthInsurance']['premium'] && tabpopData['healthInsurance']['premium'] !=null && tabpopData['healthInsurance']['premium'] !=''">
                                        <label>Health Insurance Premium</label>
                                        <p>{{tabpopData['healthInsurance']['premium'] | formatprice }}</p>
                                    </li>
                                    <li v-if="tabpopData['healthInsurance'] && tabpopData['healthInsurance']['renewalDate'] && tabpopData['healthInsurance']['renewalDate'] !=null && tabpopData['healthInsurance']['renewalDate'] !=''">
                                        <label>Health Insurance Renewal Date</label>
                                        <p>{{tabpopData['healthInsurance']['renewalDate'] | formatDate}}</p>
                                    </li>
                                </template>
                            </ul>
                            <template v-if="tabpopData['liabilitiesDebts'] !=undefined && tabpopData['liabilitiesDebts'] !=null && tabpopData['liabilitiesDebts'].length>0">
                                <h6>Your Liabilities/Debts</h6>
                                <ul class="liabilities" v-for="liabilitiesDebt  in tabpopData['liabilitiesDebts']" :key="liabilitiesDebt">
                                    <li v-if="liabilitiesDebt['lType'] && liabilitiesDebt['lType']['name'] && liabilitiesDebt['lType']['name']!=null && liabilitiesDebt['lType']['name']!=''">
                                        <label>Type</label>
                                        <p>{{ liabilitiesDebt['lType']['name']}}</p>
                                    </li>
                                    <li v-if="liabilitiesDebt['amount'] && liabilitiesDebt['amount'] !='' && liabilitiesDebt['amount'] !=null">
                                        <label>Amount</label>
                                        <p>{{ liabilitiesDebt['amount'] | formatprice}}</p>
                                    </li>
                                </ul>
                            </template>
                            <template v-if="tabpopData['publicBenefits'] !=null && tabpopData['publicBenefits'] !=undefined && tabpopData['publicBenefits'].length>0">
                                <h6>Public Benefits</h6>
                                <ul class="benefits">
                                    <template v-for="benf  in tabpopData['publicBenefits']">

                                        <li v-if="getPubliBenfitName(benf)" :key="benf">
                                            <p>{{ getPubliBenfitName(benf)}}</p>
                                        </li>

                                    </template>

                                </ul>
                            </template>
                        </div>

                    </VuePerfectScrollbar>
                </div>
            </div>
            <!----END assets_financials---->

            <!----parents--->
            <div class="gc_appcontent_right" v-if="popupSubTabs['parents']">
                <div class="gc_app_details-cnt">
                    <VuePerfectScrollbar :ref="popupSubTabs['parents']" class="scroll-area--nofications-dropdown p-0" :settings="settings">
                        <div class="gc_scrool-cnt" v-if="tabpopData['father'] && (tabpopData['father']['firstName'] || tabpopData['father']['lastName'])">

                            <h6>Father</h6>
                            <ul class="parentname">
                                <li v-if="tabpopData['father']['firstName'] && tabpopData['father']['firstName'] !='' && tabpopData['father']['firstName']!=null">
                                    <label>First Name</label>
                                    <p>{{tabpopData['father']['firstName']}}</p>
                                </li>
                                <li v-if="tabpopData['father']['middleName'] && tabpopData['father']['middleName']!='' && tabpopData['father']['middleName']!=null">
                                    <label>Middle Name</label>
                                    <p>{{tabpopData['father']['middleName']}}</p>
                                </li>
                                <li v-if="tabpopData['father']['lastName'] && tabpopData['father']['lastName'] !='' && tabpopData['father']['lastName'] !=null">
                                    <label>Last Name</label>
                                    <p>{{tabpopData['father']['lastName']}}</p>
                                </li>
                                <li v-if="tabpopData['father']['birthFirstName'] || tabpopData['father']['birthLastName']">
                                    <label>Name at Birth</label>
                                    <p>{{tabpopData['father']['birthFirstName']}} {{tabpopData['father']['birthLastName']}} </p>
                                </li>
                            </ul>
                            <ul>
                                <li v-if="tabpopData['father']['placeOfBirth']">
                                    <label>Place of Birth</label>
                                    <p>
                                        {{ tabpopData['father']['placeOfBirth'] | addformat}}
                                    </p>
                                </li>
                                <li v-if="tabpopData['father']['currentResidence']">
                                    <label>Current Residence</label>
                                    <p>
                                        {{ tabpopData['father']['currentResidence'] | addformat}}

                                    </p>
                                </li>
                                <li v-if="tabpopData['father']['dateOfBirth']">
                                    <label>Date of Birth</label>
                                    <p>{{tabpopData['father']['dateOfBirth'] | formatDate}}</p>
                                </li>
                            </ul>

                            <div class="gc_app_details-list" v-if="tabpopData['father']['everUSCitizen']">
                                <label>Is Your Father now or was he ever A U.S Citizen?</label>
                                <p v-if="tabpopData['father']['everUSCitizen']=='Yes'" class="yes_option">Yes</p>
                                <p v-if="tabpopData['father']['everUSCitizen'] !='Yes'" class="no_option">No</p>

                                <template v-if="tabpopData['father']['everUSCitizen']=='Yes'">
                                    <label class="mart15">From When Your Father now or was he ever A U.S Citizen</label>
                                    <p>{{ tabpopData['father']['usCitizenSince'] | formatDate}}</p>
                                </template>
                            </div>
                        </div>
                        <div class="gc_scrool-cnt" v-if="tabpopData['mother'] && (tabpopData['mother']['firstName'] || tabpopData['mother']['lastName'])">

                            <h6>Mother</h6>
                            <ul class="parentname">
                                <li v-if="tabpopData['mother']['firstName']">
                                    <label>First Name</label>
                                    <p>{{tabpopData['mother']['firstName']}}</p>
                                </li>
                                <li v-if="tabpopData['mother']['middleName']">
                                    <label>Middle Name</label>
                                    <p>{{tabpopData['mother']['middleName']}}</p>
                                </li>
                                <li v-if="tabpopData['mother']['lastName']">
                                    <label>Last Name</label>
                                    <p>{{tabpopData['mother']['lastName']}}</p>
                                </li>

                                <li v-if="tabpopData['mother']['birthFirstName'] || tabpopData['mother']['birthLastName']">
                                    <label>Name at Birth</label>
                                    <p>{{tabpopData['mother']['birthFirstName']}} {{tabpopData['mother']['birthLastName']}} </p>
                                </li>
                            </ul>
                            <ul>
                                <li v-if="tabpopData['mother']['placeOfBirth']">
                                    <label>Place of Birth</label>
                                    <p>

                                        {{ tabpopData['mother']['placeOfBirth'] | addformat}}

                                    </p>
                                </li>
                                <li v-if="tabpopData['mother']['currentResidence']">
                                    <label>Current Residence</label>
                                    <p>

                                        {{ tabpopData['mother']['currentResidence'] | addformat}}

                                    </p>
                                </li>
                                <li v-if="tabpopData['mother']['dateOfBirth']">
                                    <label>Date of Birth</label>
                                    <p>{{tabpopData['mother']['dateOfBirth'] | formatDate}}</p>
                                </li>
                            </ul>
                            <div class="gc_app_details-list" v-if="tabpopData['mother']['everUSCitizen'] && tabpopData['mother']['everUSCitizen']=='Yes'">
                                <label>Is Your Mother now or was he ever A U.S Citizen?</label>
                                <p v-if="tabpopData['mother']['everUSCitizen'] =='Yes'" class="yes_option">Yes</p>
                                <p v-if="tabpopData['mother']['everUSCitizen'] !='Yes'" class="no_option">No</p>

                                <template v-if="tabpopData['mother']['everUSCitizen']=='Yes'">
                                    <label class="mart15">From When Your Father now or was he ever A U.S Citizen</label>
                                    <p>{{ tabpopData['mother']['usCitizenSince'] | formatDate}}</p>
                                </template>
                            </div>
                        </div>
                    </VuePerfectScrollbar>
                </div>
            </div>
            <!----END parents---->

            <!----documents--->
            <div class="gc_appcontent_right" v-if="popupSubTabs['documents']">
                <div class="gc_app_details-cnt">

                    <a class="downloadall"  v-if="!nodcos(tabpopData.documents)" @click="downloadAll()">Download All </a>
                    <div class="clear"></div>
                    <div v-if="nodcos(tabpopData.documents)" class="no_documents">
                       <img src="@/assets/images/main/no_data.svg" />
                        <figcaption>No files have been uploaded</figcaption>
                    </div>
                    <div class="gc_scrool-cnt_wrap" v-if="!nodcos(tabpopData.documents)">
                        <VuePerfectScrollbar  :ref="popupSubTabs['documents']" class="scroll-area--nofications-dropdown p-0" :settings="settings">
                            <div class="gc_scrool-cnt">

                                <div class="documents_view_wrap">

                                    <template v-for="(item ,itemIndex, keyindex) in documentList">
                                        <DocumentItem v-bind:key="keyindex" :documents="tabpopData.documents[itemIndex]" :title="item" />

                                    </template>
                                </div>

                            </div>

                        </VuePerfectScrollbar>
                    </div>
                </div>
            </div>
            <!----END documents---->

        </div>
        <!-- <div class="actions_footer">
        <button @click="gcapplicationView=false" class="btn cancel">Cancel</button>
      </div>  -->
    </vs-popup>

    <!-- Print DIv -->

    <div v-if="loadPrintDiv && loaded" id="printDiv" style="display:none">
        <div class="Change_petition_wrap view_gcapp_wrap">
            <div class="print_view_appication">

                <!-- <template v-for =" ( dt ) in printTemplateData"> -->
                <GCPetitionDetailsTemplate v-if="loadPrintDiv && loaded" :applicationRequired="applicationRequired" :allOtherNamesUsedValid='allOtherNamesUsedValid' :publicbenefits="publicbenefitslist" :isloaded="loadPrintDiv" :blockName="''" :dataTabpop="tabpopData" />

                <!-- </template> -->
            </div>
        </div>
    </div>

</div>
</template>

<script>
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import FormsandLetters from "./gcpetition/Forms";
import ScannedCopies from "./ScannedCopies";
import ProcessFlow from "./gcpetition/ProcessFlow";
import RequestLCA from "./RequestLCA";
import LCADetails from "./LCADetails";
import PetitionUpdates from "./petition/PetitionUpdates";
import ClientDetails from "./petition/ClientDetails";
import ChildDetails from "./petition/ChildDetails";
import SpouseDetails from "./petition/SpouseDetails";
import Documents from "./petition/Documents";
//import BeneficiaryDetails from "./petition/BeneficiaryDetails";
import Communication from "./gcpetition/Communication";
import Fees from "./petition/Fees";
import GCPetitionDetailsTemplate from "./GCPetitionDetailsTemplate.vue"
//import mainContent from "../assets/scss/vuesax/themes/IntakePortal/mainContent.scss"
import DocumentItem from './gcpetition/Document'
import JQuery from "jquery";

import VueHtmlToPaper from 'vue-html-to-paper';
import Vue from 'vue';
const options = {
    name: '_blank',
    specs: [
        'fullscreen=yes',
        'titlebar=no',
        'scrollbars=yes'
    ],
    styles: [
        //'https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css',
        // 'https://unpkg.com/kidlat-css/css/kidlat.css',

    ]
}

Vue.use(VueHtmlToPaper, options);

export default {
    components: {
        VuePerfectScrollbar,
        FormsandLetters,
        ScannedCopies,
        Documents,
        ProcessFlow,
        RequestLCA,
        LCADetails,
        ClientDetails,
        SpouseDetails,
        ChildDetails,
        // BeneficiaryDetails,
        Communication,
        PetitionUpdates,
        Fees,
        GCPetitionDetailsTemplate,
        DocumentItem
    },
    name: "app",
    data: () => ({
        loaded: false,
        currentRole: null,
        currentUserId: null,
        SuccessQuestionnaire: false,
        gcapplicationView: false,
        petition: [],
        petitions: [],
        petitionhistory: [],
        supervisorlist: [],
        active_tab: 0,
        tabs: [{
                index: 0
            },
            {
                index: 1
            },
            {
                index: 2
            },
            {
                index: 3
            },
            {
                index: 4
            },
            {
                index: 5
            },
            {
                index: 6
            }
        ],

        visa_status: {},
        visastatuses: {},
        spouse_currentStatusDetails: {},
        country_names: {},
        lcaDetails: null,
        allOtherNamesUsedValid: true,
        popMainTabs: {
            "principal_applicant": true,
            "spouse": false
        },

        popupSubTabs: {
            "personal_info": true,
            "address": false,
            "immigration": false,
            "occupational_skills": false,
            "assets_financials": false,
            "parents": false,
            "documents": false
        },
        tabpopData: null,
        settings: {
            //maxScrollbarLength: 60
        },
        publicbenefitslist: [],
        publicbLoaded: false,
        loadPrintDiv: false,
        printTemplateData: [],
        applicationRequired: false,
        documentList: {
            "birthCertificate": 'Date of Birth Certificate',
            "photo": "Photos",
            "passport": "Passport",
            "I140ApprovalNotice": "I140 Approval Notice",
            "underlyingLaborCertification": "Underlying Labor Certification",
            "medicalExaminations": "Medical Examinations",
            "formI134": "Form I-134",
            "itReturns": "IT Returns",
            "w2": "W2",
            "bankStatement": "Bank Statements",
            "continuedValidStatus": "Continued Valid Status",
            "evidenceOfFilingPetition": "Evidence Of ilingPetition",
            "otherIncomeAssetProof": "Other Income Asset Proof",
            "medicalInsuranceProof": "Medical Insurance Proof",
            "creditReport": "Credit Report",
            "creditReportDocs": "Credit Report Documents",
            "permResidentStatusDocs": "Permanent Resident Status  Documents",
            "empAuthFrontbackDocs": "Employee Authorization Front and Back Copies"
        }
    }),
    watch: {
        active_tab(val) {
            var self = this;
            setTimeout(function () {
                JQuery(".vs-tabs--li:contains(Communication)").addClass('comm');
            }, 5)

        }

    },

    methods: {
        nodcos(docs) {
            var nodcos = true;

            Object.keys(this.documentList).forEach(function (key, keyIndex) {
                var countcheck = _.filter(docs[key], (e) => {
                    return (e.url != null && e.url != '')
                });
                if (countcheck.length > 0) nodcos = false;

            })

            return nodcos;
        },
        downloadAll() {
            this.$vs.loading();
            const postdata = {
                petitionId: this.petition._id,
                userType: "",
                childrenId: null
            }
            if (this.active_tab == 0) postdata.userType = "self";
            if (this.active_tab == 1) postdata.userType = "spouse";
            if (this.active_tab > 1) {
                postdata.userType = "child";
                postdata.childrenId = this.tabpopData._id;
            }
            this.$store.dispatch("downloadallapplicantfiles", postdata).then(response => {

                window.location.href = this.$globalgonfig._BASEURL + "/api/viewfile?&filename=" + this.petition.caseNo + ".zip&path=" + response.path;

                this.$vs.loading.close();
            });
            //downloadallapplicantfiles

        },
        divPrint() {
            //alert();
            Vue.use(VueHtmlToPaper, options);

            this.gcapplicationView = true
            this.gcapplicationView = false

            this.loadPrintDiv = false;
            this.loadPrintDiv = true;
            this.$htmlToPaper('printDiv');

        },

        getPubliBenfitName(id) {

            let dt = _.find(this.publicbenefitslist, (obj) => {
                return obj['id'] = id
            })
            if (dt) {
                return dt['name'];

            } else {
                return '';
            }

        },

        getPubliBenfits() {

            this.$store
                .dispatch("getmasterdata", "public_benefits")
                .then(response => {
                    this.publicbenefitslist = response;
                    this.loadPrintDiv = true;
                    // alert(JSON.stringify(this.publicbenefitslist));

                });
        },

        download(value) {
            value.url = value.url.replace(this.$globalgonfig._S3URL, "");
            value.url = value.url.replace(this.$globalgonfig._S3URLAWS, "");
            let postdata = {
                keyName: value.url
            };
            this.$store.dispatch("getSignedUrl", postdata).then(response => {
                window.open(response.data.result.data, "_blank");
            });

        },
        bindTabpopData(data) {

            this.tabpopData = data;
            this.gcapplicationView = true

            this.loadPrintDiv = false;
            this.loadPrintDiv = true;

        },

        //popMainTabs:{"principal_applicant":true ,"spouse":false},
        togleMainTab(selectedkey = '', childIndex = -1) {

            _.forEach(this.popMainTabs, (el, key) => {
                this.popMainTabs[key] = false;

            });
            this.popMainTabs[selectedkey] = true
            this.applicationRequired = false;

            if (childIndex <= -1) {
                if (selectedkey == "principal_applicant") {
                    this.tabpopData = this.petition.beneficiaryInfo
                    this.active_tab = 0;
                } else if (selectedkey == "spouse") {
                    this.tabpopData = this.petition.dependentsInfo['spouse'];
                    this.applicationRequired = true;
                    this.active_tab = 1;
                }

            } else {

                this.tabpopData = this.petition.dependentsInfo['childrens'][childIndex];
                this.togleSubTab("child" + childIndex);
                this.applicationReqired = true;
                this.active_tab = (1 + childIndex + 1);
            }
            this.togleSubTab('personal_info', childIndex);
            this.loadPrintDiv = false;
            this.loadPrintDiv = true;

        },
        togleSubTab(selectedkey = '', childIndex = -1) {

            _.forEach(this.popupSubTabs, (el, key) => {
                this.popupSubTabs[key] = false;

            });
            this.popupSubTabs[selectedkey] = true

            if (childIndex >= 0) {
                this.tabpopData = this.petition.dependentsInfo['childrens'][childIndex];
                this.applicationRequired = true;

            }
            this.loadPrintDiv = false;
            this.loadPrintDiv = true;

        },
        reloadPetition() {
            this.loadPetetion(this.$route.params.itemId);
        },
        setActivetab() {
            this.active_tab = JQuery(".vs-tabs--li:contains(LCA)").index();
        },
        setActivetabstatus() {
            var self = this;
            setTimeout(function () {

                self.active_tab = JQuery(".vs-tabs--li:contains(Tracking)").index();
            }, 100)
        },
        showfilingFeesPopup() {
            this.$refs.ProcessFlow.showfilingFeesPopup();
        },
        loadPetetion(petitionId) {
            this.loaded = false;
            this.loadPrintDiv = false;
            this.$store.dispatch("getgcpetition", petitionId).then(response => {
                this.petition = response.data.result;

                if (this.petition.enableEditOption && this.petition.statusId == 1 && this.currentRole == 7) {
                    let routeId = this.$route.params.itemId
                    //  alert('ddd')
                    this.$router.push({
                        name: 'fillgcquestionnaire',
                        params: {
                            routeId
                        }
                    })
                }

                if (!_.has(this.petition.beneficiaryInfo, "documents")) {
                    this.petition.beneficiaryInfo['documents'] = this.petition['documents'];
                }

                _.forEach(this.petition.beneficiaryInfo.allOtherNamesUsed, (obj) => {
                    //middleName
                    if ((!obj['firstName'] && obj['firstName'] == '') && (!obj['lastName'] && obj['lastName'] == '') && (!obj['middleName'] && obj['middleName'] == '')) {
                        this.allOtherNamesUsedValid = false;
                    }

                });

                this.tabpopData = this.petition.beneficiaryInfo;
                this.loadPrintDiv = true;
                this.printTemplateData.push({
                    "blockName": 'Principal Applicant',
                    "blockData": this.petition.beneficiaryInfo
                });

                //  if(this.petition.dependentsInfo['spouse']['firstName'] !='' && this.petition.dependentsInfo['spouse']['firstName'] !=undefined){
                //    this.printTemplateData.push({"blockName":'Spouse' ,"blockData":this.petition.dependentsInfo['spouse']});
                //  }
                _.forEach(this.petition.dependentsInfo['childrens'], (obj, cindex) => {
                    this.popMainTabs['child' + cindex] = false;
                    let ind = cindex
                    // if(obj['firstName'] !='' && obj['firstName'] !=undefined && obj['firstName'] !=null){
                    //   this.printTemplateData.push({"blockName":'Child '+(ind+1) ,"blockData":obj});
                    // }
                });
                //petition.dependentsInfo['childrens']"

                this.petition.filingFeeDetails = [];
                this.$store
                    .dispatch("filingFeeDetails", {
                        invoiceId: this.petition.invoiceId
                    })
                    .then(response => {
                        this.loaded = true;
                        this.petition.filingFeeDetails = response;
                    }).catch((response) => {
                        this.loaded = true;
                    });

                if (this.petition.lcaId != null) {
                    this.$store
                        .dispatch("fetchLcaDetails", this.petition.lcaId)
                        .then(response => {
                            this.lcaDetails = response.data.result;
                        });
                }
                    let postDt = {userId:'' ,isRfeCase:false}
                    if(_.has(this.petition ,"rfeCase" )){
                    postDt['isRfeCase'] = this.petition['rfeCase']
                    }
                    postDt['userId'] = this.petition['userId'];
                this.$store
                    .dispatch("getpetitionsdropdown", postDt)
                    .then(response => {
                        this.petitions = response;
                    });
            });
            this.$store.dispatch("gcpetitionhistory", petitionId).then(response => {
                this.petitionhistory = response.result.list;
            });
        }
    },
    beforeDestroy() {
        //  JQuery('#btnSidebarToggler').click()

    },
    mounted() {

        this.getPubliBenfits();
        // this.$store.commit("TOGGLE_IS_SIDEBAR_ACTIVE", false);
        // this.$store.dispatch('updateSidebarWidth', 'reduced');
        //  this.$store.commit('UPDATE_SIDEBAR_ITEMS_MIN', true)

        setTimeout(function () {
            JQuery('#btnSidebarToggler').click()
            JQuery(".vs-tabs--li:contains(Communication)").addClass('comm');
        }, 500)
        this.currentRole = this.$store.state.user.loginRoleId;
        this.currentUserId = this.$store.state.user._id;
        this.loadPetetion(this.$route.params.itemId);
        this.$store.dispatch("getmasterdata", "visa_status").then(response => {
            this.visastatuses = response;
        });
        this.$store.dispatch("getusersByrole", 8).then(response => {
            this.paralegallist = response.list;
        });
        this.$store.dispatch("getusersByrole", 7).then(response => {
            this.supervisorlist = response.list;
        });
    }
};
</script>
