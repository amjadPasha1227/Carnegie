<template>
        <modal 
     
     name="createLabelModal" 
     classes="v-modal-sec createLabelModal"
     :min-width="200"
     :min-height="200"
     :scrollable="true"
     :reset="true"
     width="500px"
     height="auto">
   <div class="v-modal">
      
       <div class="popup-header fromDetailsPage">
        <h2 class="popup-title" v-if="callFromEdit && callFromList && editItem && checkProperty(editItem,'_id')">  Edit Label</h2>
         <h2 class="popup-title" v-else>  Create Label</h2>
         <span @click="$modal.hide('createLabelModal');hideMe()">
           <em class="material-icons">close</em>
         </span>
       </div>
       <form @submit.prevent data-vv-scope="newLabelform" >
       <div class="form-container" @click="formerrors.msg=''">
        <div class="vx-row">
           <div class="vx-col w-full">
             <div class="form_group">
               <label class="form_label">Please enter a new Label Name</label>
               <vs-input name="labelname" v-validate="'required'" class="w-full" data-vv-as="Label Name" v-model="labelName" />
               <span  class="text-danger text-sm" v-show="errors.has('newLabelform.labelname')" >{{ errors.first("newLabelform.labelname") }}</span >
             </div>
           </div>
        </div>
        <div class="vx-row">
          <simpleColorPicker v-model="selectColor" :formscope="'newLabelform'" :fieldName="'labelColor'" :cid="'labelColor'"
           :name="'labelColor'" :label="'Select the Label Color'" :required="true"/>
        </div>
        <div class="text-danger text-sm formerrors custom_margin" v-show="formerrors.msg">
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
              icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
          </div>
       
       <div class="popup-footer relative">
        <span class="loader" v-if="loadingLabel" ><img src="@/assets/images/main/loader.gif" /></span>
        <vs-button color="success" :disabled="loadingLabel" @click="createLabel"  class="save m-0" type="filled">
            <template v-if="callFromEdit && callFromList && editItem && checkProperty(editItem,'_id')">
                Update
            </template>
            <template v-else>
                Create
            </template>
            </vs-button>
       </div>
       </div>
     </form>
       
   
   </div>
   </modal>   
</template>
<script>
import simpleColorPicker from "@/views/forms/fields/simpleColorPicker.vue";
export default {
    components:{
        simpleColorPicker
    },
    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
    data: () => ({
        labelName:'',
        selectColor:'',
        loadingLabel:false,
        formerrors:{
            msg:''
        }
    }),
    props:{
        message:{
            type:Object,
            default:null
        },
        callFromEdit:{
            type:Boolean,
            default:false
        },
        callFromList:{
            type:Boolean,
            default:false
        },
        editItem:{
            type:Object,
            default:null
        }
    },
    methods:{
        createLabel(){

            this.$validator.validateAll('newLabelform').then(result => {
                if(result){
                let payLoad={
                    name: this.labelName,
                    color: this.selectColor,
                    tenantId: this.checkProperty(this.getUserData['tenantDetails'],'_id')
                }
                this.formerrors.msg = '';
                let path = '/message-label/create';
                if(this.callFromEdit && this.callFromList && this.editItem && this.checkProperty(this.editItem,'_id')){
                    payLoad['messageLabelId'] = this.checkProperty(this.editItem,'_id') ;
                    path = '/message-label/update'
                }
                
                this.loadingLabel = true;
                this.$store.dispatch("commonAction", { "data": payLoad, "path": path }).then((response)=>{
                    this.showToster({message:response.message ,isError:false});
                    if(this.checkProperty(this.message,'_id') && !this.callFromEdit && !this.callFromList ){
                    let temp = {
                        color:payLoad['color'],
                        name:payLoad['name'],
                        _id:response._id
                    }
                    if(_.has(this.message,'labels') && this.checkProperty(this.message,'labels','length')>0){
                        this.message['labels'].push(temp)
                    }else{
                        this.message['labels'] = [];
                        this.message['labels'].push(temp)
                    }
                    if(this.message['labels'] && this.checkProperty(this.message['labels'],'length')>0){
                        let payload={
                            messageId:this.checkProperty(this.message,'_id'),
                            labels:this.message['labels'],
                        }
                        let path='/communication/manage-labels'
                        this.$store.dispatch("commonAction", {'data':payload,'path':path}).then(response => { }).catch((err)=>{})
                    }
                    }
                    this.loadingLabel = false;
                    this.hideMe()
                }).catch((err)=>{
                    this.formerrors.msg =err;
                    this.loadingLabel = false;
                })
                }
            })
        },
        hideMe(){
            this.$modal.hide('createLabelModal');
            this.$emit('hideMe')
        }
    },
    mounted(){
        this.labelName='',
        this.selectColor='',
        this.loadingLabel=false,
        this.formerrors={
            msg:''
        }
        if(this.callFromEdit && this.callFromList && this.editItem && this.checkProperty(this.editItem,'_id')){
            this.labelName=this.checkProperty(this.editItem,'name');
            this.selectColor=this.checkProperty(this.editItem,'color');
        }
        this.$modal.show('createLabelModal');
    }
}
    
    
</script>