<template>
<div>
    <div class="content-header case-search-header">
        <div class="content-header-left">
            <div class="search">
                <vs-input icon-pack="feather" icon="icon-search"
                    placeholder="Search by Name"
                    class="is-label-placeholder" @input="searchLabel" v-model.lazy="searchtxt" />
            </div>
        </div>
        <div class="content-header-right">
            <vs-button color="primary" type="border" class="light-blue-btn" @click="createLabel(false)">  Create Label <span>
             </span></vs-button>

        </div>
    </div> 
    <div class="accordian-table custom-table no-wrap relative messages_labels_table">
        <NoDataFound ref="NoDataFoundRef" :loading="isListLoading" v-if="labelsList.length == 0" content=""
              :heading="callFromSerch?'No Results Found':'No Results Found'" type='petitions' />
          <div v-if="labelsList.length >  0">
                  
                  <vs-table :data="labelsList">
                  <template v-if="labelsList.length > 0" slot="thead">
                      <vs-th class="mw-280">
                      <a @click="sortMe('name')"
                          v-bind:class="{'sort_ascending':sortKeys['name']==1, 'sort_descending':sortKeys['name']!=1}">Name </a>            
                      </vs-th> 
                      <vs-th> <a 
                         >Color
                          </a>
                        </vs-th>
                      <vs-th> <a @click="sortMe('createdByName')"
                          v-bind:class="{'sort_ascending':sortKeys['createdByName']==1, 'sort_descending':sortKeys['createdByName']!=1}">Created By
                          </a>
                        </vs-th>
                      <vs-th> <a @click="sortMe('createdOn')"
                          v-bind:class="{'sort_ascending':sortKeys['createdOn']==1, 'sort_descending':sortKeys['createdOn']!=1}">
                          Created On</a>
                        </vs-th>
                        <vs-th> <a @click="sortMe('updatedOn')"
                          v-bind:class="{'sort_ascending':sortKeys['updatedOn']==1, 'sort_descending':sortKeys['updatedOn']!=1}">
                          Updated On</a>
                        </vs-th>
                        
                        <vs-th class="actions">Actions
                        </vs-th>

                     
                  </template>
                  <template slot-scope="{ data }">
                      <vs-tr :data="messge" :key="messge.index" v-for="messge in data" class="vs-table--tr">
                        <vs-td > <span>{{ checkProperty(messge,'name') }}</span> </vs-td>
                        <vs-td > <span class="color_span" :style="{'background-color':messge['color']}">{{ checkProperty(messge,'color') }}</span> </vs-td>
                        <vs-td class="td_label">
                          <div >
                          {{ checkProperty(messge ,'createdByName') }} <br />
                          <small> {{ checkProperty(messge ,'createdByRoleName') }} </small>
                          </div>
                      </vs-td>
                        
                        <vs-td>  <span> {{ messge.createdOn | formatDate }} </span>  </vs-td>
                        <vs-td>  <span> {{ messge.updatedOn | formatDate }} </span>  </vs-td>
                        <vs-td>
                            <div class="action-icons">
                                <a @click="createLabel(messge,true)" class="edit IB_tooltip">
                                    <div class="tooltip_cnt">
                                    <p>
                                        Edit
                                    </p>
                                    </div>
                                </a>
                            </div>
                        <!-- <vs-dropdown
                        class="msg_dropdown_icon" :vs-trigger-click="true">
                        <a class="a-icon" href.prevent>
                            <more-vertical-icon size="1.5x" class="custom-class cursor"></more-vertical-icon>
                        </a>
                        <vs-dropdown-menu class="loginx msg_dropdown">
                            <vs-dropdown-item>
                            <a href.prevent style="cursor:pionter;padding:3px 10px" @click="createLabel(messge,true)"><span>Edit
                            </span></a>
                            </vs-dropdown-item>
                        </vs-dropdown-menu>
                        </vs-dropdown> -->
                        </vs-td>
                      </vs-tr>
                  </template>
                  </vs-table>
                  <div class="table_footer">


                  <div class="vx-col  con-select pages_select" v-if="labelsList.length > 0">
                      <label class="typo__label">Per Page</label>
                      <multiselect @input="changeperPage()" v-model="perpage" :options="perPeges" :multiple="false"
                      :close-on-select="true" :clear-on-select="false" :preserve-search="true" placeholder="Per Page"
                      :preselect-first="true">

                      </multiselect>
                      <span class="totla_list_count" v-if="totalCount"> Total <em>{{totalCount}}</em></span>
                  </div>

                  <paginate v-if="labelsList.length > 0" v-model="page" :page-count="totalpages" :page-range="3"
                      :margin-pages="2" :click-handler="pageNate"
                      prev-class="vs-pagination--buttons btn-prev-pagination vs-pagination--button-prev"
                      next-class="vs-pagination--buttons btn-next-pagination vs-pagination--button-next" :prev-text="'<i></i>'"
                      :next-text="'<i></i>'" :container-class="'pagination vs-pagination--nav'" :page-class="'page-item'">
                  </paginate>
                  </div>
          </div>
    </div>
    <messageCreateLabel v-if="showCreate" :callFromEdit="callFromEdit" :callFromList="true" :editItem ="selectedItem" @hideMe="hideMe" />
</div>
</template>
<script>
import { XIcon, MoreVerticalIcon } from 'vue-feather-icons'
import messageCreateLabel from "@/views/messages/messageCreateLabel.vue";
import NoDataFound from "@/views/common/noData.vue"
import Paginate from "vuejs-paginate";
export default {
    data:()=> ({
        labelsList:[],
        page: 1,
        perpage: 25,
        totalpages: 0,
        searchtxt:'',
        debounce:null,
        showCreate:false,
        sortKeys:{},
        sortKey:{},
        isListLoading:false,
        perPeges: [10,25,50,75,100],
        totalCount:0,
        callFromSerch:false,
        selectedItem:null,
        callFromEdit:null

    }),
    methods:{
        getLabelsList(){
            let payLoad={
                matcher:{
                statusList:[],
                searchString:this.searchtxt
                },
                page:this.page,
                perpage:this.perpage,
                sorting:this.sortKey
            };
            this.isListLoading = true;
            this.updateLoading(true);
            let path='/message-label/list'
            this.$store.dispatch("getList", { "data": payLoad, "path": path }).then((response)=>{
                this.isListLoading = false;
                this.updateLoading(false);
                setTimeout(()=>{
                    this.updateLoading(false);
                },5)
                if(response.list){
                    let list = response.list;
                    let tempList = []
                    _.forEach(list,(item)=>{
                        if(!_.has(item,'id')){
                        item['id'] = item['_id'];
                        tempList.push(item)
                        }
                    })
                    if(this.checkProperty(tempList,'length')>0){
                        this.labelsList = tempList
                    }
                    this.totalCount = this.checkProperty(response,'totalCount')
                    this.totalpages = Math.ceil(response.totalCount / this.perpage);
                }
            }).catch((err)=>{

            })
        },
        changeperPage(){       
            this.page = 1;
            localStorage.setItem('petitions_perpage', this.perpage);
            this.getLabelsList(); 
        },
        searchLabel(){
            clearTimeout(this.debounce)
            this.debounce = setTimeout(() => {
                this.getLabelsList()
            }, 900)
        },
        createLabel(item = null,callFromedit = false){
            this.callFromEdit = callFromedit;
            if(this.callFromEdit){
                this.selectedItem = item;
            }
            this.showCreate= true;
        },
        hideMe(){
            this.showCreate = false;
            this.getLabelsList();
        },
        sortMe(sort_key=''){
            if(sort_key !=''){
                this.page = 1;
                this.sortKeys[sort_key] = this.sortKeys[sort_key]==1?-1:1
                this.sortKey ={};
                this.sortKey= {"path":sort_key,"order": this.sortKeys[sort_key] }
                localStorage.setItem('petitions_sort_key', sort_key);
                localStorage.setItem('petitions_sort_value', this.sortKey[sort_key]);
                this.getLabelsList();
            }
        },
        pageNate(pageNum) {
          this.page = pageNum;
          this.getLabelsList();
        },
    },
    mounted(){
        this.getLabelsList();
        this.sortKeys = {
            'name':1,
            'createdByName':1,
            'createdOn':1 , 
            'updatedOn':1,
        };
    },
    components:{
        Paginate,
        messageCreateLabel,
        NoDataFound,
        MoreVerticalIcon,
        XIcon
    }

}
</script>