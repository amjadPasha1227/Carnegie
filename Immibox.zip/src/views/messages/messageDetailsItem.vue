<template>
    <div class="messageDetailsItem" :id="detailsItem['_id']" :class="{'unread':checkProperty(detailsItem,'read') == false}">
      <div class="message_desc" v-if="checkProperty(detailsItem,'message')" >         
        <p   v-html="checkProperty(detailsItem,'message')"></p> 
        <div class="posted_by">
          <span v-if="checkProperty(detailsItem,'fromUserName')">Posted by <em>{{checkProperty(detailsItem,'fromUserName')}} 
            <template v-if="checkProperty(detailsItem,'fromUserRoleName')"> ({{ checkProperty(detailsItem,'fromUserRoleName') }}) </template></em> on <em>{{checkProperty(detailsItem,'createdOn') |formatDateTime}}</em></span>
        </div>
        <div class="message_actions_wrap">
          <messageLabel @updateLabels="updateLabels" @updateUserIds="updateUserIds" @openCreateLabel="openCreateLabel" 
             :labelsList="labelsList" :message="detailsItem" :callFromDetails="true" />
          <div class="message_actions"  >
            <span class="mark_as_read" v-if="checkProperty(detailsItem,'read')" @click="markAsRead(detailsItem,false)">
              Mark as Unread
            </span>
            <span class="mark_as_unread" v-else @click="markAsRead(detailsItem,true)">
              Mark as Read
            </span>
          </div>
        </div>             
        <div class="communication_details communication_details-v2 3"> 
          <template v-if="[50,51].indexOf(getUserRoleId) <=-1">
            <div class="new_msg_wrap" v-if="checkProperty(detailsItem,  'activityLogs' ,'length')>0">
              <div class="msg_description_newv2" v-if="checkProperty(detailsItem,  'activityLogs' ,'length')>0">
                <ul>
                  <li v-for="( aLog ,indx) in detailsItem['activityLogs']">
                    <span class="msg_desc" v-html=" aLog.comment "></span>
                    <span class="msg_date">On {{ aLog.createdOn | formatDateTime }}</span>
                  </li>
                </ul>
              </div>
            </div> 
          </template>
        </div>
      </div> 
      <template v-if="false">
      <div class="assined_removed_labels" v-if="checkProperty(detailsItem,'labels') && checkProperty(detailsItem,'labels','length')>0" >
          <span>Assigned Label(s) 
            <div class="message_sec">
              <div class="message_lables">
                <ul class="label_list" >
                  <template v-for="(labe,inde) in detailsItem['labels'] ">
                    <li :style="{'background-color':labe['color']}">
                      {{ checkProperty(labe,'name')  }}
                    </li>
                  </template>
                </ul> 
              </div>
            </div>
          <!-- on <em>Jul 15, 2023 03:41 AM</em> by <em>Mehta (LCA Manager)</em> -->
        </span>
      </div>
      <div class="assined_removed_labels assined_users" v-if="checkProperty(detailsItem,'toUserList') && checkProperty(detailsItem,'toUserList','length')>0">
          <span>Assigned User(s) <em>{{ getAssigneeName }}</em> 
            <!-- on <em>Jul 15, 2023 03:41 AM</em> by <em>Mehta (LCA Manager)</em> -->
          </span>
      </div>
      <div class="assined_removed_labels"  v-if="checkProperty(detailsItem,'removedLabels') && checkProperty(detailsItem,'removedLabels','length')>0">
          <span>Removed Label(s) 
            <div class="message_sec">
              <div class="message_lables">
                <ul class="label_list" >
                  <template v-for="(labl,inde) in detailsItem['removedLabels'] ">
                    <li :style="{'background-color':labl['color']}">
                      {{ checkProperty(labl,'name')  }}
                    </li>
                  </template>
                </ul> 
              </div>
            </div> 
          <!-- on <em>Jul 15, 2023 03:41 AM</em> by <em>Mehta (LCA Manager)</em> -->
        </span>
      </div>
    </template>
    </div>
</template>
<script>
import messageLabel from "@/views/messages/messagesLabels.vue";
export default {
    props:{
      detailsItem:{
        type:Object,
        default:null
      },
      labelsList:{
          type:Array,
          default:[]
      },
    },
    components:{
      messageLabel
    },
    data:()=>{

    },
    computed:{
      getAssigneeName(){
        let returnVal = ''
        if(this.checkProperty(this.detailsItem,'toUserList')){
          _.forEach(this.detailsItem['toUserList'],(dtItm)=>{
            if(_.has(dtItm,'name') && this.checkProperty(dtItm,'name')){
              if(returnVal == ''){
                returnVal = dtItm['name']
              }else{
                returnVal = returnVal+', '+ dtItm['name']
              }
              
            }
          })
        }
        return returnVal;
      }
    },
    methods:{
      updateLabels(val){
        this.$emit('updateLabels',val)
      },
      updateUserIds(val){
        this.$emit('updateUserIds',val)
      },
      openCreateLabel(val){
        this.$emit('openCreateLabel',val)
      },
      markAsRead(val,action,callfrom=false){
      let item = val
      let Payload ={
        messageId:this.checkProperty(item,'_id'),
        read:action
      };
      let path = 'communication/manage-read'
      this.$store.dispatch("commonAction", { "data": Payload, "path": path }).then((response)=>{
        this.detailsItem['read'] = action;
        if(!callfrom){
          this.showToster({message:response.message ,isError:false,duration:1000});
        }
        //this.$emit('reloadList')
        
        this.getMessageDetails()
      }).catch((err)=>{

      })
    },
    }
}
</script>