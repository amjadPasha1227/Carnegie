<template>
     <div class="workflow_view_sec message_details message_details_v2" :id="checkProperty(selectMessage,'_id')+'Message'" >
      <!-- <div class="workflow_view_sec message_details"> -->
        <template >
            <div class="message_head">
              <div class="case_details">
                <ul>
                  <li v-if="checkProperty(firstMessage,'petitionDetails','petitionerName')">Customer <em>{{checkProperty(firstMessage,'petitionDetails','petitionerName')}}</em></li>
                  <li v-if="checkProperty(firstMessage,'petitionDetails','beneficiaryName')">Beneficiary <em>{{checkProperty(firstMessage,'petitionDetails','beneficiaryName')}}</em></li>
                </ul>
                <ul>
                  <li v-if="checkProperty(firstMessage,'petitionDetails','typeName')">{{checkProperty(firstMessage,'petitionDetails','typeName')}}
                    <em v-if="checkProperty(firstMessage,'petitionDetails','subTypeName')">({{ checkProperty(firstMessage,'petitionDetails','subTypeName') }})</em></li>
                  <li v-if="checkProperty(firstMessage,'petitionDetails','caseNo')">Case No <em>{{checkProperty(firstMessage,'petitionDetails','caseNo')}}</em></li>
                </ul>
              </div>
              <div class="message_actions">
                <button class="export_btn" @click="exportPage(firstMessage)"><img src="@/assets/images/icons/share.png" />Export</button>
                <span class="reply_btn" @click="scrolltop()" >Reply</span>
                <template v-if="false">
                
                <span class="mark_as_read" v-if="checkProperty(firstMessage,'read')" @click="markAsRead(firstMessage,false)">
                  Mark as Unread
                </span>
                <span class="mark_as_unread" v-else @click="markAsRead(firstMessage,true)">
                  Mark as Read
                </span>
              </template>
                <span class="case_details_btn" @click="goToDetailsPage">Case Details</span>
              </div>
            </div>
            <div class="communication_list_wrap 11" >
              <div class="communication_input message_input">
                <div class="message-textarea" >       
                  <quillTextEditor  :wrapclass="'md:w-1/1 mb-0'" v-model="comment" :label="'Message'"
              :fieldName="'message'" :required="true" :cid="'message'" :placeHolder="'Message'" :customValidNotRequire="true" />    
                  <!-- <immitextfield  wrapclass="md:w-1/1"  :formscope="''"  v-model="comment" :required="true"
                   fieldName="message" rows="2" label="Message" placeHolder="Message"></immitextfield> -->
                  <multiselect
                  v-if="[51].indexOf(getUserRoleId) <=-1"
                    v-model="selecteduser"
                    :options="usersList"
                    :multiple="true"
                    :hideSelected="true" 
                    :close-on-select="false"
                    :clear-on-select="false" 
                    :preserve-search="true"
                    :select-label="'Select User'" 
                    placeholder="Select Users"
                    label="name"
                    track-by="name"
                    :preselect-first="false"
                    :searchable="true"
                    class="text-area-multiselect"
                    @input="setLawFirm"
                    >
                    <template slot="selection" slot-scope="{ values, isOpen }">
                      <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }} User(s)
                        selected</span>
                      <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                    </template>
                  </multiselect> 
                  <div class="btn-check">
                  <ul  class="demo-alignment custom-radio"  vs-type="flex"   vs-align="center" >
                    <li>
                      <vs-checkbox vs-name="notifyNow" v-model="notifyNow" class="message-check">
                        Notify Immediately
                      </vs-checkbox>
                    </li>
                    </ul>
                    
                  <button :disabled="comment==null || comment=='<div><br></div>' || comment=='' || submitingComment || comment.trim() ==''"  @click="submitComment()" class="submit">Submit</button>
                </div>
                </div>
              </div>
            </div>
            <div class="message_scroll_area" v-if="firstMessage">
            <template v-for="(detai,ind) in messageDetails ">
              <listItem @updateLabels="updateLabels" @updateUserIds="updateUserIds" @openCreateLabel="openCreateLabel"
                :detailsItem="detai" :labelsList="labelsList" @reloadList="getMessageDetails"/>
            </template>
            </div>
            
        </template>
    </div>
</template>
<script>
import quillTextEditor from "@/views/forms/fields/quillTextEditor.vue";
import immitextfield from "@/views/forms/fields/simpleTextField.vue";
import listItem from "@/views/messages/messageDetailsItem.vue";
import messageLabel from "@/views/messages/messagesLabels.vue";
import _ from "lodash";
import moment from "moment";
import JQuery from "jquery";
export default {
    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
    props:{
      labelsList:{
          type:Array,
          default:[]
      },
      selectMessage:{
            type:Object,
            default:null
        },
        details:{
            type:Object,
            default:null
        },
        loadedFromDashBoard:{
          type:Boolean,
          default:false
        },
    },
    components:{
      quillTextEditor,
      immitextfield,
      messageLabel,
      listItem
    },
    data:()=>({
        messageDetails:null,
        usersList:[],
        selecteduser:[],
        notifyNow:true,
        comment:'',
        commenterror:'',
        submitingComment:false,
        firstMessage:null,
        petition:null
    }),
    methods:{
      scrolltop(){ 
        const $ = JQuery
        let ele = '#'+this.checkProperty(this.selectMessage,'_id')+'Message'     
        $(ele).scrollTop(0);
      },
      setLawFirm(){
      if(this.checkProperty(this.selecteduser,'length')>0 && this.checkProperty(this.petition,'typeDetails','id')){
        let findLawFirm = _.find(this.selecteduser,{'userId':'Law_Firm'})
        if(findLawFirm){
          this.selecteduser = [];
          this.selecteduser.push(findLawFirm)
        }
      }
     
    },
      getPetitiondetail(){
          let payLoad={
            petitionId:this.checkProperty(this.selectMessage,'petitionId')
          }
          let path = '/petition/details'
          if(this.checkProperty(this.selectMessage,'petitionDetails','type') == 3 && this.checkProperty(this.selectMessage,'petitionDetails','subType') == 15 ){
            path = '/perm/details'
          }
          this.$store.dispatch("commonAction", {"data":payLoad ,"path":path}).then(response=>{
            this.petition = response;
            this.getusers()
          }).catch((ree)=>{
            this.getusers()
          })
        },
      markAsRead(val,action,callfrom=false){
      let item = val
      let Payload ={
        messageId:this.checkProperty(item,'_id'),
        read:action
      };
      let path = 'communication/manage-read'
      this.$store.dispatch("commonAction", { "data": Payload, "path": path }).then((response)=>{
        this.selectMessage['read'] = action;
        if(!callfrom){
          this.showToster({message:response.message ,isError:false,duration:1000});
        }
        if(callfrom){
          var elmnt = document.getElementById(this.checkProperty(item,'_id'));
          elmnt.scrollIntoView();
        }
        this.getMessageDetails()
      }).catch((err)=>{
        if(callfrom){
          var elmnt = document.getElementById(this.checkProperty(item,'_id'));
          elmnt.scrollIntoView();
        }
      })
      },
      openCreateLabel(val){
            this.$emit('openCreateLabel',val)
        },
        updateLabels(val){
            this.$emit('updateLabels',val);
            this.getMessageDetails();
            // setTimeout(()=>{
            //   this.firstMessage['labels'] = val['labels'];
            //   this.messageDetails[0]['labels'] = val['labels']
            // },5)
        },
        updateUserIds(val){
            this.$emit('updateUserIds',val);
            this.getMessageDetails();
            let returnVal = val
            // setTimeout(()=>{
            //   this.firstMessage['toUserIds'] = returnVal['userIds'];
            //   this.firstMessage['toUserList'] = returnVal['toUserList'];
            //   // this.firstMessage['labels'] = val['labels'];
            //   // this.messageDetails[0]['labels'] = val['labels']
            // },5)
            
        },
        goToDetailsPage(){
            this.$emit('goToDetailsPage',this.firstMessage)
        },
        exportPage(obj){
            let Payload= {
                  "filters": {
                    getPtnrAndOtherInfo:true,
                      "entityType": obj.entityType,
                      "petitionIds": [obj.petitionId],
                  },
                  "page": 1,
                  "perpage": 100
              }
              let path = '/petition/export-messages'; 
              this.$store.dispatch("commonAction", {'data':Payload,'path':path}).then(response => {
                
                let fileObj ={
                  name: this.checkProperty(response,'fileName'),
                  path:this.checkProperty(response,'s3UrlPath'),
                  status: true,
                }
                this.downloads3file(fileObj);
              })
              .catch(error => {
                this.showToster({ message: error, isError: true });
              })
        },
        getMessageDetails(callfromMount= false){
            let payLoad={
              filters:{
                messageId:'',
                searchString:'',
                petitionIds: [this.checkProperty(this.selectMessage,'petitionId')],
                petitionerIds:[],
                typeIds: [],
                subTypeIds: [],
                createdDateRange: [],
                getPtnrAndOtherInfo:true,
              },
              page: 1,
              perpage: 100,
              sorting:{"path":"createdOn" ,"order":-1},
                
            }
            let path = '/communication/list';
            this.messageDetails = [];
            //this.firstMessage = null;
            this.$store.dispatch("commonAction", {'data':payLoad,'path':path}).then(response => {
              let self = this
              let data = response.list;
          let toUsersList = [];
          if(response['toUserList'] && self.checkProperty(response, 'toUserList', 'length')>0){
            toUsersList = response['toUserList'];
          }
          toUsersList = response.toUserList;
          let temp_list = [];
          _.forEach(data, (obj) => {
            obj["is_expend"] = false;
            obj["all_comments"] = [];
            obj["newComment"] = { ticketId: "", statusId: "", description: "", documents: [], today: moment().format("YYYY-MM-DD"),  };
            if(_.has(obj, 'toUserIds') &&  self.checkProperty(obj, 'toUserIds','length')>0 && toUsersList && self.checkProperty(toUsersList, 'length')>0){
              obj['toUserList'] = [];
              _.forEach(obj['toUserIds'],(itd)=>{
                let findOb = _.find(toUsersList,{'_id':itd});
                if(findOb){
                  obj['toUserList'].push(findOb)
                }
                
              })
            }else{
              if(!_.has(obj, 'toUserList')){
                obj['toUserList'] = [];
              }
            }
            temp_list.push(obj);
          });
          this.messageDetails = temp_list;
          if(this.messageDetails && this.checkProperty(this.messageDetails,'length')>0){
            this.firstMessage = null;
            this.firstMessage = this.messageDetails[0];
            if(callfromMount){
              this.markAsRead(this.selectMessage,true, true)
            }
          }
          
                //this.messageDetails = response.list;
            })
        },
        getusers() {
            this.usersList = [];
            let postdata = {
                petitionId: this.checkProperty(this.selectMessage,'petitionId'),
                petitionType:"NORMAL"  //"GC" // 'RFE', 'NORMAL' ,'PERM'
            };
            if(( [3].indexOf(this.checkProperty(this.selectMessage['petitionDetails'],'type'))>-1 && [15].indexOf(this.checkProperty(this.selectMessage['petitionDetails'],'subType'))>-1)){
                postdata['petitionType'] = 'PERM'
            }
            this.$store.dispatch("getcommunicationuserslist", postdata).then(response => {
                let ignoreUsers =[]
                if([3,4,5,6,7,8,9,10,11,12,13,14].indexOf(this.getUserRoleId) >-1){
                  ignoreUsers =[3,4,5,6,7,8,9,10,11,12,13,14];
                    //ignoreUsers =[51];
                }else if([50].indexOf(this.getUserRoleId) >-1){
                    ignoreUsers =[];
                }else if([51].indexOf(this.getUserRoleId) >-1){
                    ignoreUsers =[3,4,5,6,7,8,9,10,11,12,13,14];
                }
                if(ignoreUsers.length>0 && response.length>0){
                    response  = _.filter(response , (usr)=>{
                        return ignoreUsers.indexOf(usr['roleId'] )<=-1
                    })
                }
                let tempList  = response
                let modifiedList = [];
              if(this.checkProperty(this.petition,'typeDetails','id')){
                if([50,51].indexOf(this.getUserRoleId) <=-1){
                  let lawOffice = {
                    _id: "Law_Firm",
                    roleId: 65,
                    branchId: "Law_Firm",
                    userId: "Law_Firm",
                    name: "Law Firm",
                    value: "Law Firm",
                    roleName: "Law Firm",
                    tempName: "Law Firm"
                  };
                  modifiedList.push(lawOffice);
                  let removedList = [];
                  let petitionerObj = _.find(tempList,{'roleId':50});
                  if(petitionerObj){
                    petitionerObj['name'] = 'Petitioner';
                    petitionerObj['tempName'] = 'Petitioner';
                    removedList =  _.filter(tempList,(item)=>{
                      return item['roleId'] != 50
                    });
                    modifiedList.push(petitionerObj);
                  }
                  if((this.checkCHildH4 || this.checkSPouseH4) || [10,2].indexOf(this.checkProperty(this.petition, 'typeDetails', 'id'))>-1){
                      let benObj = _.find(tempList,{'roleId':51});
                      if(benObj && _.has(benObj,'name')){
                        benObj['name'] = 'Beneficiary';
                        benObj['tempName'] = 'Beneficiary';
                        removedList =  _.filter(removedList,(item)=>{
                          return item['roleId'] != 51
                        });
                        modifiedList.push(benObj);
                      }
                  }
                  else{
                    if(removedList && this.checkProperty(removedList,'length')>0){
                      removedList =  _.filter(removedList,(item)=>{
                        return item['roleId'] != 51
                      });
                      //console.log(JSON.stringify(removedList))
                    }else{
                      removedList =  _.filter(tempList,(item)=>{
                        return [50,51].indexOf(item['roleId'])<=-1
                      });
                    }
                    
                  }
                  // if(removedList && this.checkProperty(removedList,'length')>0){
                  //   tempList = _.cloneDeep(removedList)
                  // }
                  tempList = _.cloneDeep(removedList)
                }
                if([50].indexOf(this.getUserRoleId) >-1){
                  let lawOffice = {
                    _id: "Law_Firm",
                    roleId: 65,
                    branchId: "Law_Firm",
                    userId: "Law_Firm",
                    name: "Law Firm",
                    value: "Law Firm",
                    roleName: "Law Firm",
                    tempName: "Law Firm"
                  };
                  modifiedList.push(lawOffice);
                  let removedList = [];
                  if((this.checkCHildH4 || this.checkSPouseH4) || [10,2].indexOf(this.checkProperty(this.petition, 'typeDetails', 'id'))>-1){
                      let benObj = _.find(tempList,{'roleId':51});
                      if(benObj && _.has(benObj,'name')){
                        benObj['name'] = 'Beneficiary';
                        benObj['tempName'] = 'Beneficiary';
                        removedList =  _.filter(tempList,(item)=>{
                          return item['roleId'] != 51
                        });
                        modifiedList.push(benObj);
                      }
                  }else{
                    if(removedList && this.checkProperty(removedList,'length')>0){
                      removedList =  _.filter(removedList,(item)=>{
                        return item['roleId'] != 51
                      });
                    }else{
                      removedList =  _.filter(tempList,(item)=>{
                        return [50,51].indexOf(item['roleId'])<=-1
                      });
                    }
                    
                  }
                  tempList = _.cloneDeep(removedList)
                }
              }
              if([50].indexOf(this.getUserRoleId) <=-1){
                _.forEach(tempList,(item)=>{
                  // let fidObj = _.find(modifiedList,{roleId:50})
                  //   if(!fidObj){
                  //     modifiedList.push(item);
                  //   }
                  modifiedList.push(item);
                })
              }
              this.usersList = modifiedList;
                // _.forEach(response ,(obj)=>{
                //       if(_.has(obj ,'roleName')){
                //         obj['tempName'] = obj['name']+" ("+obj['roleName']+")"
                //       }
                //         tempList.push(obj);
                //     })
                // this.usersList = tempList;
            });
        },
        submitComment(){
          this.commenterror = '';
          let postdata = {
            petitionId: this.checkProperty(this.firstMessage,'petitionId'),
            petitionCaseNo:this.checkProperty(this.firstMessage,'petitionDetails','caseNo'),
            message:this.comment,
            toUserIds:[],
            "entityType":'case',
            parentId:this.checkProperty(this.firstMessage,'_id')
          };
          if(( [3].indexOf(this.checkProperty(this.firstMessage['petitionDetails'],'type'))>-1 && [15].indexOf(this.checkProperty(this.firstMessage['petitionDetails'],'subType'))>-1)){
            postdata['entityType'] = 'perm'
          }
          if(this.selecteduser && this.checkProperty(this.selecteduser, 'length')>0){
            let findObj = _.find(this.selecteduser,{_id:'Law_Firm'})
            if(findObj){
              postdata['toUserIds'] = [];
            }else{
              postdata['toUserIds'] =  this.selecteduser.map(user =>user._id);
            }
          }else{
            postdata['toUserIds'] =  []
          }

          if(!this.comment){
          this.commenterror  = 'Please enter your message';
          }
          if(this.commenterror!='') return false;
          this.submitingComment =true;
          postdata['notifyNow'] = this.notifyNow;
          this.$store.dispatch("submitcomment", postdata).then(response => {
            this.submitingComment =false;
                this.notifyNow = true;
                this.notifyNow = true;
                this.getMessageDetails();
                //this.$emit('getNotes')
                  this.commenterror = null;
                  this.comment=null;
                  this.comment ='';
                  this.selecteduser=[];
                  this.$validator.reset();
                  this.$validator.reset();
          })
          .catch(error => {
            this.submitingComment =false;
            this.showToster({ message: error, isError: true });

          })

        },
       
    },
    mounted(){
      this.getPetitiondetail();
      this.getMessageDetails(true)
      //this.messageDetails =this.details;
      //this.getusers();
        
    },
    computed:{
        checkCHildH4(){
      let returnVal = false;
      if(this.checkProperty(this.petition,'dependentsInfo','childrens') && this.checkProperty(this.petition['dependentsInfo'],'childrens','length')>0 ){
        _.forEach(this.petition['dependentsInfo']['childrens'],(item)=>{
          if(_.has(item,'h4Required') && this.checkProperty(item,'h4Required') && _.has(item,'h4EADRequired') && this.checkProperty(item,'h4EADRequired') ){
            returnVal = true;
            return returnVal;
          }else if (this.checkProperty(item,'h4Required')){
            returnVal = true;
            return returnVal;
          }else if (this.checkProperty(item,'h4EADRequired')){
            returnVal = true;
            return returnVal;
          }
        })
      }
      return returnVal;
    },
    checkSPouseH4(){
      let returnVal = false;
      if(this.checkProperty(this.petition,'dependentsInfo','spouse')){
        if(this.checkProperty(this.petition['dependentsInfo'],'spouse','h4Required') && this.checkProperty(this.petition['dependentsInfo'],'spouse','h4EADRequired')){
          returnVal = true;
          return returnVal;
        }else if(this.checkProperty(this.petition['dependentsInfo'],'spouse','h4Required')){
          returnVal = true;
          return returnVal;
        }else if(this.checkProperty(this.petition['dependentsInfo'],'spouse','h4EADRequired')){
          returnVal = true;
          return returnVal;
        }
      }
      return returnVal;
    },
    }
}
</script>