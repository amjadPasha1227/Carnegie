<template>
    
    <vs-tr class="vs-table--tr" :class="{'unread':checkProperty(message,'read') == false && selectedMsgType == 'inbox'}">
        <vs-td>

            <div class="from_sec">
                <div class="from_top_sec">
                <label class="petitioner" v-if=" checkProperty(message,'fromUserName')">{{ checkProperty(message,'fromUserName') }} 
                    <template v-if="checkProperty(message,'fromUserRoleName') && checkProperty(message,'fromUserRoleId') != 51 ">({{ checkProperty(message,'fromUserRoleName') }})</template>
                </label>
                
                </div>
                <div class="from_bottom_sec">
                    <ul v-if="checkProperty(message,'petitionDetails')">
                        <li v-if="checkProperty(message,'petitionDetails','typeName')">{{checkProperty(message,'petitionDetails','typeName')}} 
                        <template v-if="checkProperty(message,'petitionDetails','subTypeName')">({{checkProperty(message,'petitionDetails','subTypeName')}})</template></li>
                        <li v-if="checkProperty(message,'petitionDetails','caseNo')">{{checkProperty(message,'petitionDetails','caseNo')}}</li>
                    </ul>
                    <span class="peti_date" v-if="checkProperty(message,'createdOn')">{{ checkProperty(message,'createdOn') | formatDateTime }}</span> 
                </div>
            </div>
        </vs-td>
        <vs-td>
            <messageLabel :loadedFromDashBoard="loadedFromDashBoard" trimcontent="true" @updateLabels="updateLabels" @openDetailsPage="openDetailsPage" @updateUserIds="updateUserIds" @openCreateLabel="openCreateLabel" :labelsList="labelsList" :message="message" />
            <div class="message_actions" v-if="!loadedFromDashBoard">
                <span class="reply_btn" @click="openDetailsPage(message)">Post a Response</span>
                <span class="case_details_btn" @click="goToDetailsPage(message)">Case Details</span>
            </div>
        </vs-td>
        <!-- <vs-td>
        <div class="message_actions" v-if="!loadedFromDashBoard">
            <span class="reply_btn" @click="openDetailsPage(message)">Post a Response</span>
            <span class="case_details_btn" @click="goToDetailsPage(message)">Case Details</span>
        </div>
        </vs-td> -->
    </vs-tr>

</template>
<script>
import messageLabel from "@/views/messages/messagesLabels.vue";
export default {
    components:{
        messageLabel,
    },
    props:{
        selectedMsgType:{
            type:String,
            default:''
        },
        labelsList:{
            type:Array,
            default:[]
        },
        message:{
            type:Object,
            default:null
        },
        loadedFromDashBoard:{
          type:Boolean,
          default:false
        },
    },
    methods:{
        openCreateLabel(val){
            this.$emit('openCreateLabel',val)
        },
        goToDetailsPage(val){
            this.$emit('goToDetailsPage',val)
        },
        openDetailsPage(val){
            this.$emit('openDetailsPage',val)
        },
        updateLabels(val){
            this.$emit('updateLabels',val)
        },
        updateUserIds(val){
            this.$emit('updateUserIds',val)
        },
    }
}
</script>