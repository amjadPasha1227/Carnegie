<template>
    <div>
        <modal
            name="createLabelPopupModal"
            classes="v-modal-sec linklca"
            :min-width="200"
            :min-height="200"
            :scrollable="true"
            :reset="true"
            width="1300px"
            height="auto"
        >
        <div class="v-modal">
            <div class="popup-header fromDetailsPage"> 
                <h2  class="popup-title"> Labels </h2>
                <span @click="$modal.hide('createLabelPopupModal');openLabelPopup(false)"> <em class="material-icons">close</em> </span>
            </div>
        </div>
        <form data-vv-scope="newLabelForm" @submit.prevent @keydown.enter.prevent>
          <div class="linklca_form new_label_form" @click="formErrors=''">
                <div class=" linklca_form_header">
                    <div class="vx-row">
                        <div class="vx-col">
                            <div class="form_group">
                            <label class="form_label">Name of the label</label>
                            <vs-input name="labelname" v-validate="'required'" class="" data-vv-as="Name of the label" v-model="labelName" />
                            <span  class="text-danger text-sm" v-show="errors.has('newLabelForm.labelname')" >{{ errors.first("newLabelForm.labelname") }}</span >
                            </div>
                        </div>
                        <simpleColorPicker v-model="selectColor" :formscope="'newLabelForm'" :fieldName="'labelColor'" :cid="'labelColor'"
                            :name="'labelColor'" :label="'Background color of the label'" :required="true"/>
                         
                        <div class="vx-col">
                            <button :disabled="loadingLabel"  class="light-blue-btn primary-btn" @click="createLabel" >Create</button>
                        </div>
                    </div>
                    <div class="text-danger text-sm formerrors custom_margin" v-show="formerrors.msg">
                        <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
                        icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
                    </div>
                </div>
                <div class="form-container pad0">
                    <div class="accordian-table custom-table no-wrap relative">
                        <NoDataFound ref="NoDataFoundRef" :loading="isListLoading" v-if="labelsList.length == 0" content=""
                        :heading="callFromSerch?'No Results Found':'No Results Found'" type='petitions' />
                        <div v-if="labelsList.length >  0">
                                <vs-table :data="labelsList">
                                <template v-if="labelsList.length > 0" slot="thead">
                                    <vs-th >
                                    <a @click="sortMe('name')"
                                        v-bind:class="{'sort_ascending':sortKeys['name']==1, 'sort_descending':sortKeys['name']!=1}">Name </a>            
                                    </vs-th> 
                                    <vs-th> <a 
                                        >Color
                                        </a>
                                        </vs-th>
                                    <vs-th> <a @click="sortMe('createdByName')"
                                        v-bind:class="{'sort_ascending':sortKeys['createdByName']==1, 'sort_descending':sortKeys['createdByName']!=1}">Created By
                                        </a>
                                        </vs-th>
                                    <vs-th> <a @click="sortMe('createdOn')"
                                        v-bind:class="{'sort_ascending':sortKeys['createdOn']==1, 'sort_descending':sortKeys['createdOn']!=1}">
                                        Created On</a>
                                        </vs-th>
                                        <vs-th> <a @click="sortMe('updatedOn')"
                                        v-bind:class="{'sort_ascending':sortKeys['updatedOn']==1, 'sort_descending':sortKeys['updatedOn']!=1}">
                                        Updated On</a>
                                        </vs-th>
                                        
                                        <vs-th class="actions">Actions
                                        </vs-th>

                                    
                                </template>
                                <template slot-scope="{ data }">
                                    <vs-tr :data="messge" :key="messge.index" v-for="messge in data" class="vs-table--tr">
                                        <vs-td > <span>{{ checkProperty(messge,'name') }}</span> </vs-td>
                                        <vs-td > <span class="color_span" :style="{'background-color':messge['color']}">{{ checkProperty(messge,'color') }}</span> </vs-td>
                                        <vs-td class="td_label">
                                        <div >
                                        {{ checkProperty(messge ,'createdByName') }} <br />
                                        <small> {{ checkProperty(messge ,'createdByRoleName') }} </small>
                                        </div>
                                    </vs-td>
                                        
                                        <vs-td>  <span > {{ messge.createdOn | formatDate }} </span>  </vs-td>
                                        <vs-td>  <span> {{ messge.updatedOn | formatDate }} </span>  </vs-td>
                                        <vs-td>
                                            <div class="action-icons">
                                                <a @click="editLabel(messge,true)" class="edit IB_tooltip">
                                                    <div class="tooltip_cnt">
                                                    <p>
                                                        Edit
                                                    </p>
                                                    </div>
                                                </a>
                                            </div>
                                        <!-- <vs-dropdown
                                        class="msg_dropdown_icon" :vs-trigger-click="true">
                                        <a class="a-icon" href.prevent>
                                            <more-vertical-icon size="1.5x" class="custom-class cursor"></more-vertical-icon>
                                        </a>
                                        <vs-dropdown-menu class="loginx msg_dropdown">
                                            <vs-dropdown-item>
                                            <a href.prevent style="cursor:pionter;padding:3px 10px" @click="editLabel(messge,true)"><span>Edit
                                            </span></a>
                                            </vs-dropdown-item>
                                        </vs-dropdown-menu>
                                        </vs-dropdown> -->
                                        </vs-td>
                                    </vs-tr>
                                </template>
                                </vs-table>
                                <div class="table_footer">


                                <div class="vx-col  con-select pages_select" v-if="labelsList.length > 0">
                                    <label class="typo__label">Per Page</label>
                                    <multiselect @input="changeperPage()" v-model="perpage" :options="perPeges" :multiple="false"
                                    :close-on-select="true" :clear-on-select="false" :preserve-search="true" placeholder="Per Page"
                                    :preselect-first="true">

                                    </multiselect>
                                </div>

                                <paginate v-if="labelsList.length > 0" v-model="page" :page-count="totalpages" :page-range="3"
                                    :margin-pages="2" :click-handler="pageNate"
                                    prev-class="vs-pagination--buttons btn-prev-pagination vs-pagination--button-prev"
                                    next-class="vs-pagination--buttons btn-next-pagination vs-pagination--button-next" :prev-text="'<i></i>'"
                                    :next-text="'<i></i>'" :container-class="'pagination vs-pagination--nav'" :page-class="'page-item'">
                                </paginate>
                                </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        </modal>
        <messageCreateLabel v-if="showCreate" :callFromEdit="callFromEdit" :callFromList="true" :editItem ="selectedItem" @hideMe="hideMe" />
    </div>
</template>
<script>
import Paginate from "vuejs-paginate";
import simpleColorPicker from "@/views/forms/fields/simpleColorPicker.vue";
import messageCreateLabel from "@/views/messages/messageCreateLabel.vue";
import NoDataFound from "@/views/common/noData.vue"
import { XIcon, MoreVerticalIcon } from 'vue-feather-icons'
export default {
    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
    data:()=>({
        callFromSerch:false,
        labelName:'',
        selectColor:'',
        searchtxt:'',
        labelsList:[],
        page: 1,
        perpage: 25,
        totalpages: 0,
        searchtxt:'',
        debounce:null,
        sortKeys:{},
        sortKey:{},
        isListLoading:false,
        perPeges: [10,25,50,75,100],
        showCreate:false,
        selectedItem:null,
        callFromEdit:false,
        formerrors: {
            msg: "",
        },
        loadingLabel:false
    }),
    components:{
        simpleColorPicker,
        messageCreateLabel,
        Paginate,
        NoDataFound,
        MoreVerticalIcon,
        XIcon
    },
    methods:{
        sortMe(sort_key=''){
            if(sort_key !=''){
                this.page = 1;
                this.sortKeys[sort_key] = this.sortKeys[sort_key]==1?-1:1
                this.sortKey ={};
                this.sortKey= {"path":sort_key,"order": this.sortKeys[sort_key] }
                localStorage.setItem('petitions_sort_key', sort_key);
                localStorage.setItem('petitions_sort_value', this.sortKey[sort_key]);
                this.getLabelsList();
            }
        },
        pageNate(pageNum) {
          this.page = pageNum;
          this.getLabelsList();
        },
        openLabelPopup(){
            this.$modal.hide('createLabelPopupModal');
            this.$emit('openLabelPopup',false)
        },
        getLabelsList(){
            let payLoad={
                matcher:{
                statusList:[],
                searchString:this.searchtxt
                },
                page:this.page,
                perpage:this.perpage,
                sorting:this.sortKey
            };
            this.isListLoading = true;
            this.updateLoading(true);
            let path='/message-label/list'
            this.$store.dispatch("getList", { "data": payLoad, "path": path }).then((response)=>{
                this.isListLoading = false;
                this.updateLoading(false);
                setTimeout(()=>{
                    this.updateLoading(false);
                },5)
                if(response.list){
                    let list = response.list;
                    let tempList = []
                    _.forEach(list,(item)=>{
                        if(!_.has(item,'id')){
                        item['id'] = item['_id'];
                        tempList.push(item)
                        }
                    })
                    if(this.checkProperty(tempList,'length')>0){
                        this.labelsList = tempList
                    }
                    this.totalpages = Math.ceil(response.totalCount / this.perpage);
                }
            }).catch((err)=>{

            })
        },
        editLabel(item = null,callFromedit = false){
            this.callFromEdit = callFromedit;
            if(this.callFromEdit){
                this.selectedItem = item;
            }
            this.showCreate= true;
        },
        hideMe(){
            this.showCreate = false;
            this.getLabelsList();
        },
        createLabel(){
        this.$validator.validateAll('newLabelForm').then(result => {
            if(result){
            let payLoad={
                name: this.labelName,
                color: this.selectColor,
                tenantId: this.checkProperty(this.getUserData['tenantDetails'],'_id')
            }
            this.formerrors.msg = '';
            let path = '/message-label/create';
            this.loadingLabel = true;
            this.$store.dispatch("commonAction", { "data": payLoad, "path": path }).then((response)=>{
                this.loadingLabel = false;
                this.getLabelsList();
                this.labelName = '';
                this.selectColor = '';
                this.$validator.reset();
                this.showToster({message:response.message ,isError:false});
            }).catch((err)=>{
                this.formerrors.msg =err;
                this.loadingLabel = false;
            })
            }
        })
    },
    },
    mounted(){
        this.$modal.show('createLabelPopupModal');
        this.getLabelsList();
        this.sortKeys = {
            'name':1,
            'createdByName':1,
            'createdOn':1 , 
            'updatedOn':1,
        };
        this.labelName = '';
        this.selectColor = '';
    },
    props:{
        loadedFromDashBoard:{
          type:Boolean,
          default:false
        },
    }
}
</script>