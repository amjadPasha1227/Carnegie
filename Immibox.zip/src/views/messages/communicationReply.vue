<template>
    <div id="page-login">
      <div slot="no-body" class="login_page">
        <div class="login-section">
          <!-- <div class="hidden md:block login-left">
            <div class="login_left_cnt">
              <div class="login_text">
                <h4>Immigration Practice at Ease</h4>
                <p>
                  A one stop Case Management System to seamlessly manage your entire immigration practice as an Attorney, Law Firm or Corporate.
                </p>
              </div>
              <figure>
                <img
                  src="@/assets/images/pages/login_img.svg"
                  alt="login"
                  class="mx-auto"
                />
              </figure>
            </div>
          </div> -->
          <div class="login-right reply_form">
            <div class="w-full">
              <form action="javascript:void(0)">
                <div class="vx-card__title">
                  <figure
                    class="IB_logo text-center"
                    v-if="checkProperty(tenantDetails, 'logo')"
                  >
                    <a :href="tenantDetails.webApp"><img :src="tenantDetails['logo']" /></a>
                  </figure>
                  <figure class="IB_logo IB_logoDefault setpassword_logo" v-else>
                    <a href="https://immibox.com/" target="_blank"
                      ><img src="@/assets/images/logo/immiBox_logo.svg"
                    /></a>
                  </figure>             
                </div>
                <template>
                  <div class="form-inputs">
                    <div class="errormsg-support">
                        <span> 
                          </span>
                     </div>
                     <template>
                      <form data-vv-scope="replyForm">
                        <div class="form_group">
                            <div class="form-inputs mt-5">
                                    <div class="vx-col  w-full">  
                                    <label class="form_label">Responding as {{userName}} ({{roleName}}) <em>*</em></label>
                                    <ckeditor name="reply" v-model="reply"  v-validate="'required'"  class="w-full" :data-vv-as="'reply'"  :editor="editor" :config="editorConfig"></ckeditor>
                                    <span  class="text-danger text-sm"  v-show="errors.has('replyForm.reply')"  ><em>* </em>Reply is required</span>
                                    </div>
                            </div>
                            <div class="popup-footer pr-0">                   
                                <vs-button  color="success"  class="save" type="filled"   @click="updateMessage()">Submit</vs-button>                  
                            </div>
                      </div>
                      </form>
                     </template>
                     <!-- <div v-if="errorMessage != ''">
                     <div class="text-danger text-sm formerrors">
                      <vs-alert color="warning" class="primary-alert login_alert warning" icon-pack="IntakePortal"
                        icon="IP-information-button" active="true">{{ errorMessage }}</vs-alert>
                    </div>
                  </div> -->
                  </div>
                </template>
               
              </form>
            </div>
            <div class="messageDetailsanom">
            Original message sent by {{checkProperty(messageDetails,'fromUserName')}} ({{checkProperty(messageDetails,'fromUserRoleName')}}) at {{checkProperty(messageDetails,'createdOn' | formatDateTime )}}
             <div class="msg"  v-html="checkProperty(messageDetails,'message')"> </div>

             <ul><li><strong>Beneficiary Name:</strong> {{checkProperty(petitionDetails,'beneficiaryInfo','name')}}</li>
            <li><strong>Case Type:</strong> {{checkProperty(petitionDetails,'typeDetails','name')}} {{checkProperty(petitionDetails,'subTypeDetails','name')}}</li>
            <li><strong>Case Number:</strong> {{checkProperty(petitionDetails,'caseNo')}} </li>
            </ul>
            </div>
           
          </div>
        </div>
      </div>
    </div>
  </template>
  
  <script>
  import _ from "lodash";
  import Vue from 'vue';
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';

 
  export default {
    data() {
      return {
        editor: ClassicEditor,
        editorConfig: {
            toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
        },
        errorMessage:'',   
        reply:'',
        tenantDetails:null,
        tenantId:'',
        messageId:'',
        petitionCaseNo:'',
        petitionId:'',
        entityType:'',
        messageDetails:null,
        petitionDetails:null,
        userName:null,
        roleName:null
      };
    },
    methods: {
      updateMessage(){
        this.errorMessage = '';
        this.$validator.validateAll('replyForm').then((result) => {
            if(result ){
                let postdata = {
                    petitionId: this.petitionId,
                    petitionCaseNo:this.petitionCaseNo,
                    message:this.reply,
                    toUserIds:[],
                    entityType:this.entityType,
                    parentId: this.messageId,
                    notifyNow:false,
                };
                // if(!this.reply){
                //     this.errorMessage  = 'Please enter reply';
                //     this.$vs.loading.close(); 
                // }
                this.$vs.loading();
                this.$store.dispatch("submitcomment", postdata).then(response => {
                  console.log(response)
                    this.$vs.loading.close(); 
                    this.reply = '';
                    
                    this.showToster({ message: response.message, isError: false });
                    
                    this.$validator.reset();
                    this.$validator.reset('replyForm');
                })
                .catch((error)=>{
                    this.showToster({ message: error, isError: true });
                    this.$vs.loading.close(); 
                })  
            }
        }) 
    },   
    getTenantDetails() {
        let postData = {
          tenantId:this.tenantId
        };
         this.$store.dispatch("commonAction", {"data":postData ,"path":"/tenant/details"})
         .then((response) => {
             this.tenantDetails = response;
         })
         .catch((err) =>{
              this.tenantDetails =null;
             this.showToster({message:err,isError:true });
         })
    },  
    getCaseDetails(){
      let postData = {
         petitionId: this.petitionId
        };
       
        let path ="/petition/details"
        if(this.entityType=='perm'){
          path= "/perm/details"
        }
        else{
          path ="/petition/details"
        }
         this.$store.dispatch("commonAction", {"data":postData ,"path":path})
         
         .then((response) => {
             this.petitionDetails = response;
         })
         .catch((err) =>{
              this.petitionDetails =null;
             this.showToster({message:err,isError:true });
         })
    } ,   
    getMessageDetails() {
        let postData = {
          messageId:this.messageId
        };
         this.$store.dispatch("commonAction", {"data":postData ,"path":"/communication/details"})
         .then((response) => {
             this.messageDetails = response;
         })
         .catch((err) =>{
              this.messageDetails =null;
             this.showToster({message:err,isError:true });
         })
    },    
  },
  mounted() {
      if(this.$route.query.key && this.$route.query.messageId){
        this.messageId=this.$route.query.messageId;
          this.petitionId=this.$route.query.petitionId;
      }
      if(this.$route.query.key && this.$route.query.petitionId){
        this.petitionId=this.$route.query.petitionId
      }
      if(this.$route.query.key && this.$route.query.petitionCaseNo){
        this.petitionCaseNo=this.$route.query.petitionCaseNo
      }
      if(this.$route.query.key && this.$route.query.entityType){
        this.entityType=this.$route.query.entityType
      }
      if(this.$route.query.key && this.$route.query.tenantId){
        this.tenantId=this.$route.query.tenantId
      }
      if(this.$route.query.key && this.$route.query.roleName){
        this.roleName=this.$route.query.roleName
      }
      if(this.$route.query.key && this.$route.query.userName){
        this.userName=this.$route.query.userName
      }
      this.getTenantDetails();
      this.getMessageDetails();
      this.getCaseDetails();
    },
  };
  </script>
  