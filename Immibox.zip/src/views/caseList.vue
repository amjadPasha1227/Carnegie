<template >
 
 <beneficiaryCases v-if="[51].indexOf(this.getUserRoleId)>-1"/>
 <petitions :isRfe="isRfe" v-else />
    
</template>



<script>
   // import petitions from "@/views/Petitions.vue"
    import beneficiaryCases from "@/views/beneficiaryCases.vue"
    import petitions from "@/views/Petitions-new-list.vue"

   export default {
        name:'caselist',
       components: {
            petitions,
            beneficiaryCases

        },
        mounted(){
            this.isRfe =false;
          // alert(this.$route.name);
           if(this.$route.name=='ref-cases'){
            this.isRfe =true;

           }
            
           
        },
        data: () => ({
            isRfe:false

        })

    }
</script>