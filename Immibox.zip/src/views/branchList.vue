<template>
  <div>
    <div class="content-header">
      <div class="content-header-left">
        <div class="search">
          <vs-input icon-pack="feather" icon="icon-search" v-model="searchtxt" placeholder="Search by Name"
            class="is-label-placeholder" />
        </div>
      </div>
      <div class="content-header-right">
         
        <vs-dropdown  vs-custom-content vs-trigger-click>
          <vs-button
            color="primary"
            class="filter-btn"
            type="border"
            icon-pack="feather"
            icon="icon-chevron-down"
            icon-after
          >
            <img src="@/assets/images/main/icon-filter.svg" /> Filters
          </vs-button>
          <vs-dropdown-menu ref="filter_menu" class="filters-content">

            <div class="filters-form-fileds">
              <div class="form-container">
                <div  class="vx-row">
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Country</label>
                    <multiselect name="spouseaddresscountry"   v-model="newform.address.selectedCountry"
                          @input="changedCountry" :show-labels="false" track-by="id" label="name"
                          data-vv-as="Country" placeholder="Select Country" :options="countries" :searchable="true"
                          :allow-empty="false">
                          <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} options selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template> 
                          </multiselect>
                  </div>
                  <div class="vx-col md:w-1/3 w-full con-select">
                     <label for class="typo__label">State</label>
                        <multiselect name="State"   v-model="newform.address.selectedState"
                          @input="changedState" :show-labels="false" track-by="id" label="name" data-vv-as="State" :multiple="false"
                          placeholder="Select State" :options="states" :searchable="true" :allow-empty="true">
                          <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} options selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template> 
                        </multiselect>
                  </div>
                  <div class="vx-col md:w-1/3 w-full con-select">
                     <label for class="typo__label">City</label>
                        <multiselect name="city"   v-model="newform.address.selectedCity"
                        @input="changedCity"
                        :show-labels="false" track-by="id" label="name" data-vv-as="City"
                          placeholder="Select City" :options="locations" :searchable="true" :allow-empty="true" :multiple="true" :hideSelected="true">
                          <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} options selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template> 
                        </multiselect>
                  </div>

                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Select Status</label>
                    
                    <multiselect v-model="selected_statusids" :options="all_status" :multiple="true" :hideSelected="true"
                      :close-on-select="false" :clear-on-select="false" :select-label="''" :preserve-search="true"
                      placeholder="Select Status" label="name" track-by="name" :preselect-first="false">
                     
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                          class="multiselect__selectcustom"
                          v-if="values.length && !isOpen"
                          >{{ values.length }} Status Selected</span
                          >
                          <span
                          class="multiselect__selectcustom"
                          v-if="values.length && isOpen"
                          ></span>
                        </template>
                    </multiselect>
                  </div>
                
                   

                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Created Date</label>
                    <date-range-picker
                       :maxDate="new Date()"
                      :autoApply="autoApply"
                      :ranges="false"
                      v-model="selected_createdDateRange"
                    ></date-range-picker>
                  </div>
                 </div>
              </div>
              <!-- </div> -->
            </div>
            <div class="filters-status">
              <div class="left-buttons">
              </div>
              <div class="right-buttons">
                <vs-button color="success" class="save" type="filled" v-on:click="set_filter()">Apply</vs-button>
                <vs-button color="dark" class="cancel" type="filled" v-on:click="clear_filter($event)">Clear
                </vs-button>
              </div>
            </div>
          </vs-dropdown-menu>
        </vs-dropdown>

  <!---Buttons-->
        <vs-button type="border"  class="light-blue-btn"  @click="goToCreateNewbranch()" v-if="[3 ].indexOf(getUserRoleId)>-1">
       
            Add New 
         <span>
          <img class="add-user-icon ml-2" src="@/assets/images/main/add-user.svg">
        </span>
       
        </vs-button>
        
        
        <!---<vs-button type="border" v-if="[1].indexOf(getUserRoleId)>-1" class="light-blue-btn" @click="createNew(true)">Add New <span>
          <img class="add-user-icon ml-2" src="@/assets/images/main/add-user.svg">
        </span>
        </vs-button>-->
        
      </div>
    </div>


  <NoDataFound ref="NoDataFoundRef" :loading="isListLoading" v-if="list.length == 0" :content="callFromSerch?'No Results Found':'You haven\'t  created any branches yet. Create a branch to start using the IMMIBOX'" heading="No Branches Found" type='branches' />
 
<!---"createdOn", createdByName, managerName, name, active, updatedOn----->
    <div class="accordian-table" v-if="list.length>0">
      <vs-table :data="list" >
        <template slot="thead" >
         <vs-th>
          <a @click="sortMe('name')"  v-bind:class="{'sort_ascending':sortKeys['name']==1, 'sort_descending':sortKeys['name']!=1}" >
             Name
              </a>
          </vs-th> 
           <vs-th>
           Branch Manager
          </vs-th>
          
          <vs-th>
          <a @click="sortMe('createdByName')"  v-bind:class="{'sort_ascending':sortKeys['createdByName']==1, 'sort_descending':sortKeys['createdByName']!=1}" >
           
           Created By
           </a>
              
          </vs-th>
          <vs-th>
          <a @click="sortMe('createdOn')"  v-bind:class="{'sort_ascending':sortKeys['createdOn']==1, 'sort_descending':sortKeys['createdOn']!=1}" >
             Created On
              </a>
          </vs-th>
          <vs-th>
          <a @click="sortMe('updatedOn')"  v-bind:class="{'sort_ascending':sortKeys['updatedOn']==1, 'sort_descending':sortKeys['updatedOn']!=1}" >
             Updated On
              </a>
          </vs-th>
            <vs-th>
            <a @click="sortMe('active')"  v-bind:class="{'sort_ascending':sortKeys['active']==1, 'sort_descending':sortKeys['active']!=1}" >
             Status
              </a>
            </vs-th>
          <vs-th class="actions">Actions</vs-th>

        </template>

        <template slot-scope="{data}">
          <vs-tr  :data="tr" :key="indextr" v-for="(tr, indextr) in data">
            <vs-td :data="tr.username">
              <!--
              <img class="user-image" src="@/assets/images/main/avatar2.svg" />
              branchDetails
              -->
              <router-link v-if="isLoadedFromUrl" :to="'branchdetails/'+ tr._id" > {{tr.name }} </router-link>
               <a class="cursor-pointer" v-else href.prevent @click="branchDetails(tr)"  > <span> {{tr.name }}  </span> </a>
              
            </vs-td>
             <vs-td class="td_label" >{{ checkProperty(tr , 'userDetails' ,"name")  }}
             <small v-if="checkProperty(tr , 'userDetails' ,'email')" >{{ checkProperty(tr , 'userDetails' ,"email")  }}</small>
             </vs-td >
            <vs-td >{{tr.createdByName  }}</vs-td >
            <vs-td >{{tr.createdOn | formatDate }}</vs-td >
            <vs-td >{{tr.updatedOn | formatDate }}</vs-td >
            

            <vs-td >
              <span class="statusspan " :class="{'status_inactive':!tr.active,'status_active':tr.active}" >
              
              </span>
              
               {{tr.active?"Active":"Inactive"}}
            </vs-td>
           
            <vs-td >
              <vs-dropdown class="msg_dropdown_icon" :vs-trigger-click="true">
                  <a class="a-icon" href.prevent><more-vertical-icon size="1.5x" class="custom-class"></more-vertical-icon></a>
                 <vs-dropdown-menu class="loginx msg_dropdown">
                    
                    <vs-dropdown-item>
                      <router-link :to="'/branch-edit/'+ tr._id"  v-if="isLoadedFromUrl">
                        Edit
                      </router-link>
                      <template v-else>
                      <a  href.prevent @click="editBranch(tr)"  > <span> Edit </span> </a>
                      </template>
                      
                    </vs-dropdown-item>

                    <template v-if="list.length==1 && !tr.active">

                    <vs-dropdown-item >
                     <a  href.prevent @click="openactivepopup(tr)"  > <span> {{ tr.active?'Inactivate':' Activate'}} </span> </a>
                    </vs-dropdown-item>
                    
                    </template>
                    <template v-if="list.length>1">

                    <vs-dropdown-item >
                     <a  href.prevent @click="openactivepopup(tr)"  > <span> {{ tr.active?'Inactivate':' Activate'}} </span> </a>
                    </vs-dropdown-item>
                    
                    </template>

                    
                     <vs-dropdown-item v-if=" tr.active">
                      <a  href.prevent @click="openquickBookconf(tr)"  >
                      QuickBooks Configuration
                    </a>
                    </vs-dropdown-item>
                    
                    <vs-dropdown-item>
                      <router-link v-if="isLoadedFromUrl" :to="'branchdetails/'+ tr._id" >
                        Details
                      </router-link>
                      <template v-else>
                      <a  href.prevent @click="branchDetails(tr)"  > <span> Details </span> </a>
                      </template>
                      
                    </vs-dropdown-item>
                   </vs-dropdown-menu> 

                </vs-dropdown>
            </vs-td>
          </vs-tr>
        </template>
      </vs-table>
      <div class="table_footer">
        <div class="vx-col  con-select pages_select"  v-if="list.length>0">
          <label class="typo__label">Per Page</label>
          <multiselect @input="changeperPage()" v-model="perpage" :options="perPeges" :multiple="false"
              :close-on-select="true" :clear-on-select="false" :preserve-search="true" placeholder="Per Page"
              :preselect-first="true">
            </multiselect>
            <span class="totla_list_count" v-if="totalCount"> Total <em>{{totalCount}}</em></span>
          </div>
          <paginate  v-if="list.length>0"  v-model="page" :page-count="totalpages" :page-range="3" :margin-pages="2" :click-handler="pageNate"
        prev-class="vs-pagination--buttons btn-prev-pagination vs-pagination--button-prev"
        next-class="vs-pagination--buttons btn-next-pagination vs-pagination--button-next" :prev-text="'<i></i>'"
        :next-text="'<i></i>'" :container-class="'pagination vs-pagination--nav'" :page-class="'page-item'"></paginate>
      </div>
      
    </div>

    <vs-popup class="holamundo main-popup" :title="edit?'Edit Branch':'Add Branch'" v-if="addPopup" :active.sync="addPopup">
      <form>
        <div class="form-container">
          <div class="vx-row">
            <div class="vx-col w-full">
              <vs-input @click="formerrors.msg=''" v-model="newform.name" placeholder="Branch Name" name="Branch Name" v-validate="'required'" class="w-full"
                label="Branch Name"   data-vv-as="Branch Name"    />
              <span class="text-danger text-sm"
                v-show="errors.has('Branch Name')">{{ errors.first("Branch Name") }}</span>
            </div>
          </div>

          <div class="vx-row">
            <div class="vx-col md:w-1/2 w-full">
              <vs-input @click="formerrors.msg=''" v-model="newform.phone" placeholder="Branch Phone" name="Branch Phone" v-validate="'required'" class="w-full"
                label="Branch Phone"   data-vv-as="Branch Phone"    />
              <span class="text-danger text-sm" v-show="errors.has('Branch Phone')">{{ errors.first("Branch Phone") }}</span>
            </div>
            <div class="vx-col md:w-1/2 w-full">
              <vs-input @click="formerrors.msg=''" v-model="newform.fax" placeholder="Branch Fax" name="Branch Fax" Fax v-validate="'required'" class="w-full"
                label="Branch Fax"   data-vv-as="Branch Fax"    />
              <span class="text-danger text-sm" v-show="errors.has('Branch Fax')">{{ errors.first("Branch Fax") }}</span>
            </div> 
          </div>

        <h3 class="small-header">Contact Person </h3>
          <div class="vx-row">
            <div class="vx-col w-full">
                    <vx-input-group class="form-input-group">
                      <vs-input name="firstName" v-model="newform.contact.firstName" v-validate="'required'"
                        class="w-full" data-vv-as="First Name" label="First Name" />

                      <!-- <vs-input class="w-full" name="middleName" v-model="newform.contact.middleName"
                        data-vv-as="Middle Name" label="Middle Name" v-validate="'required'" /> -->

                      <vs-input class="w-full" name="lastName" v-model="newform.contact.lastName"
                         data-vv-as="Last Name" label="Last Name"  />
                    </vx-input-group>
                    <div class="input-group-error">
                      <p class="w-1/3">
                        <span class="text-danger text-sm"  v-show="errors.has('firstName')">{{ errors.first("firstName") }}</span>
                      </p>
                      <p class="w-1/3">
                          <span class="text-danger text-sm"  v-show="errors.has('lastName')">{{ errors.first("lastName") }}</span>
                      </p>
                      <p class="w-1/3">
                        
                      </p>
                    </div>
                  </div>
             
          </div>
          
          <h3 class="small-header">Branch Address</h3>
                <div class="vx-row">

                   <div class="vx-col md:w-1/2 w-full" > 
                    <vs-input   name="address1" v-model="newform.line2" class="w-full"
                      data-vv-as="Street Address" label="Street Address" />
                    <span class="text-danger text-sm"
                      v-show="errors.has('address1')">{{ errors.first("address1") }}</span>
                  </div>

                  <div class="vx-col md:w-1/2 w-full" > 
                    <vs-input   name="address2" v-model="newform.line1" class="w-full"
                      data-vv-as="Apt, Suite" label="Apt, Suite" />
                    <span class="text-danger text-sm"
                      v-show="errors.has('address2')">{{ errors.first("address2") }}</span>
                  </div>

                  <div class="vx-col md:w-1/2 w-full"   >
                    <div class="con-select w-full select-large">
                      <label for class="vs-select--label">Country</label>
                    
                      <multiselect name="spouseaddresscountry"   v-model="newform.address.selectedCountry"
                        @input="changedCountry" :show-labels="false" track-by="id" label="name"
                        data-vv-as="Country" placeholder="Select Country" :options="countries" :searchable="true"
                        :allow-empty="false"></multiselect>
                    </div>


                    <span class="text-danger text-sm"
                      v-show="errors.has('spouseaddresscountry')">{{ errors.first("spouseaddresscountry") }}</span>
                  </div>
                  <div class="vx-col md:w-1/2 w-full"  >
                    <div class="con-select w-full select-large">
                      <label for class="vs-select--label">State</label>
                      <multiselect name="State"   v-model="newform.address.selectedState"
                        @input="changedState" :show-labels="false" track-by="id" label="name" data-vv-as="State"
                        placeholder="Select State" :options="states" :searchable="true" :allow-empty="false">
                      </multiselect>
                    </div>

                    <span class="text-danger text-sm" v-show="errors.has('State')">{{ errors.first("State") }}</span>
                  </div>
                  <div class="vx-col md:w-1/2 w-full"  >
                    <div class="con-select w-full select-large">
                      <label for class="vs-select--label">City</label>
                      <multiselect name="city"   v-model="newform.address.selectedCity"
                       @input="changedCity"
                       :show-labels="false" track-by="id" label="name" data-vv-as="City"
                        placeholder="Select City" :options="locations" :searchable="true" :allow-empty="false">
                      </multiselect>
                    </div>

                    <span class="text-danger text-sm" v-show="errors.has('city')">{{ errors.first("city") }}</span>
                  </div>
                  <div class="vx-col md:w-1/2 w-full" >
                    <vs-input name="zipcode" v-model="newform.address.zipcode"
                      v-validate="'numeric|required|min:5|max:6'" class="w-full" data-vv-as="Zip Code"
                      label="Zip Code" />

                    <span class="text-danger text-sm" v-show="errors.has('zipcode')">{{ errors.first("zipcode") }}</span>
                  </div>

                </div>  


          <div class="text-danger text-sm formerrors" v-show="formerrors.msg" @click="formerrors.msg=''">
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
              icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
          </div>
        </div>
      </form>
    </vs-popup>

    <vs-popup class="holamundo main-popup" :title="(checkProperty(selectedItem,'active')?'Inactivate ':' Activate')+' Branch'" v-if="activatePopUp"   :active.sync="activatePopUp" >
      <div class="form-container">
        
        <div class="vx-row">
          <div class="vx-col w-full">
          <p>Are you sure of {{checkProperty(selectedItem, 'active')?'In':''}}activating this Branch?</p>
            
          </div>
          
        </div>
       
      </div>
      <div class="popup-footer">
        <vs-button color="dark" class="cancel" type="filled" @click="activatePopUp=false">Cancel</vs-button>
        <vs-button color="success" class="save" type="filled"  v-on:click="activateBranch()">{{checkProperty(selectedItem,'active')?'Inactivate ':' Activate'}}</vs-button>
      </div>
    </vs-popup>

<vs-popup class="holamundo main-popup w50" title="QuickBooks Settings" v-if="openquickbooksConfig"   :active.sync="openquickbooksConfig" >
       
        
         <quickbooksConfig  v-bind:branchId="checkProperty(selectedItem ,'_id')" @closeMe="closeQuickbooksConfig" />
       
       
      
    </vs-popup>
    
  </div>
</template>

<script>
import DateRangePicker from "vue2-daterange-picker";
  import Datepicker from "vuejs-datepicker-inv";
  import Paginate from "vuejs-paginate";
  
import "vue2-daterange-picker/dist/vue2-daterange-picker.css";

  import _ from "lodash";
  import { FormWizard, TabContent } from "vue-form-wizard";
  import "vue-form-wizard/dist/vue-form-wizard.min.css";
   import moment from 'moment'
  import PhoneMaskInput from "vue-phone-mask-input";
  import JQuery from 'jquery'
  import { TheMask } from 'vue-the-mask'
  import NoDataFound from "@/views/common/noData.vue";

import FileUpload from "vue-upload-component/src";
import VuePhoneNumberInput from 'vue-phone-number-input';
import 'vue-phone-number-input/dist/vue-phone-number-input.css';
import { MoreVerticalIcon } from 'vue-feather-icons'
import quickbooksConfig from "@/views/settings/quickbooksConfig";

  export default {
     
    computed:{
      validateForm(){
        if(
          (this.newform.name && this.newform.name.trim() !='' )
         
         
        
        ){

          return false;
        }else{
          return true;
        }

      },
      
    },
    components: {
      DateRangePicker,
      VuePhoneNumberInput,
      MoreVerticalIcon,
      Datepicker,
      Paginate,
      FileUpload,
      FormWizard,
      TabContent,
      PhoneMaskInput,
      TheMask,
      NoDataFound,
      quickbooksConfig
    },

    data: () => ({ 
      isLoadedFromUrl:false,
      isListLoading:false,
      openquickbooksConfig:false,
      callFromSerch:false,
      selectedItem: null,
       activatePopUp:false,
      all_status:[{"name":"Active" ,"id":true} ,{"name":"Inactive" ,"id":false}],
     all_active_status:[{"name":"Active" ,"id":true} ,{"name":"Inactive" ,"id":false}],
     all_config_status:[{"name":"Completed" ,"id":true} ,{"name":"Pending" ,"id":false}],
     selected_active_statusids:[],
     final_active_statusids:[],    
    selected_createdDateRange: ["", ""],
    autoApply: "",
        value:[],
        all_formTypes:[{"name":"Form" ,"id":"Form"},{"name":"Letter" ,"id":"Letter"} ],
        
      selectedItem:null,
      selectedStatus:2,
      formerrors: {
        msg: ""
      },
      date: null,

      approveConformpopUp: false,
     countries:[],
     states:[],
     locations:[],
     newform: {
        name:'', 
        phone:"",
  	   	phoneCountryCode:{countryCode:'',countryCallingCode:''},
  	  	fax:"",
  	   	faxCountryCode:{countryCode:'',countryCallingCode:''},
        address:{line1:"" , line2:"",countryId:'' ,selectedCountry:null ,stateId:'',selectedState:null,locationId:'',selectedCity:null ,zipcode:''},
        contact: { 
            firstName: "",
            lastName: "",
            email: "",
            phone: "",
            phoneCountryCode: {countryCode:'',countryCallingCode:''}
  	    	}
    },

      list: [],
      addPopup: false,
      NewPetition: false,
      
     
      searchtxt: "",
      query: [],
      country_code: 231,
      all_statusids: [],
      selected_statusids: [],
      final_selected_statusids: [],
      filter_roleIds: [],
      final_filter_roleIds: [1,2,3,4,5,8,9,10,11,12,13],

      
      seleted_states: [],
      final_selected_states: [],
      locations: [],
      // locationIds
      final_selected_config_completed_statusids:[],
      selected_config_completed_statusids:[],
      
      
      date: "",
      date_range: [],
      page: 1,
      perPeges: [10,25,50,75,100],
      perpage: 25,
      totalCount:0,
      totalpages: 0,
      allQuestionnairefields:[],

     
      switch2:true,
      users_status:{},
      edit:false,
      sortKeys:{},
      sortKey:{},
      details:null,
      getMasterData:true,
      
    }),
    watch: {
      searchtxt: function (value) {
        this.getList(true);
      }

    },
    methods: {
      editBranch(selectedBranch){
         if(this.isLoadedFromUrl){
           this.$router.push('/branch-create/'+selectedBranch['_id'])
        }else{
          this.$emit('branchActions' ,{"branchActionType":"branchCreate" ,"selectedBranch":selectedBranch})

        }

      },
      branchDetails(selectedBranch){
         if(this.isLoadedFromUrl){
           this.$router.push('/branchdetails/'+selectedBranch['_id'])
        }else{
          this.$emit('branchActions' ,{"branchActionType":"branchDetails" ,"selectedBranch":selectedBranch})

        }

      },
      goToCreateNewbranch(){
        if(this.isLoadedFromUrl){
           this.$router.push('/branch-create')
        }else{
          this.$emit('branchActions' ,{"branchActionType":"branchCreate"})

        }
        
        
        },
      closeQuickbooksConfig(){
         this.openquickbooksConfig =false;
       // this.selectedItem = null;
       
      },
      openquickBookconf(item){
      
        this.selectedItem = item;
        this.openquickbooksConfig =true;
        this.openquickbooksConfig =false;
        this.openquickbooksConfig =true;
      },
      selectedCountry(option) {
        this.dependentsInfo.spouse.physicalAddress.countryId = option.id;
        this.getSuposeStates();

      },
       activateBranch(){
         let action =true;
        //  alert(this.selectedItem['active'])
         if(this.selectedItem['active'] ){
           action = false;
         }else{
           action =true;
         }
        let postData = {branchId:this.selectedItem['_id'] ,"active":action};
        this.$store.dispatch("commonAction" ,{"data":postData , "path":"/branch/manage-active-status"})
        .then((res)=>{
          this.activatePopUp = false;
          this.showToster({message:res.message ,isError:false});
          this.getList();

        })
        .catch((err)=>{

           this.showToster({message:err ,isError:true});
        })
      },

      sortMe(sort_key=''){

      
        if(sort_key !=''){
            this.sortKeys[sort_key] = this.sortKeys[sort_key]==1?-1:1
            // this.sortKey[sort_key] = this.sortKeys[sort_key]
            this.sortKey = {"path":sort_key ,"order":this.sortKeys[sort_key]};
            

            localStorage.setItem('branch_sort_key', sort_key);
            localStorage.setItem('branch_sort_value', this.sortKey[sort_key]);
            this.getList();
        }
          
      

      },
      editMe(item){
        this.edit =true;
        this.selectedItem = item;
        this.newform = {name:this.selectedItem.name }
        this.addPopup=true;
        
        

      },

               
     createNew(action =true){
        
       this.edit =false;
       
      //this.countries = []
     this.states = [];
     this.locations = [];
     this.newform= {
        name:'', 
        phone:"",
  	   	phoneCountryCode:{countryCode:'',countryCallingCode:''},
  	  	fax:"",
  	   	faxCountryCode:{countryCode:'',countryCallingCode:''},
        address:{line1:"" , line2:"",countryId:'' ,selectedCountry:null ,stateId:'',selectedState:null,locationId:'',selectedCity:null ,zipcode:''},
        contact: { 
            firstName: "",
            lastName: "",
            email: "",
            phone: "",
            phoneCountryCode:{countryCode:'',countryCallingCode:''}
  	    	}
    },
      this.addPopup=action;
      //this.$router.push("/questionnaire-config-add");
     },
      openactivepopup(item){
         this.selectedItem = item;
        this.activatePopUp =true;
        this.edit= false;
      },
      changeperPage(){
        this.page = 1;
        this.getList(true);
      },
      getList(callFromSerch=false) {
        this.callFromSerch = callFromSerch;
         if(this.callFromSerch){
         
          this.list =[];
        }
      //  alert(JSON.stringify(this.searchtxt)) final_selected_statusids
         let item ={
          filters:{
              "title":this.searchtxt.trim(),
             "createdDateRange":[],
             "statusList": this.final_active_statusids, 
             "activeList": this.final_selected_statusids ,
             "countryIds":[],
             "stateIds":[],
             "locationIds":[]
           

          },
          getMasterData:false,   
          page:this.page,
          perpage: this.perpage,
          sorting:this.sortKey,
          //getMasterData:this.getMasterData          
        };

         if (
        this.selected_createdDateRange["startDate"] &&
        this.selected_createdDateRange["startDate"] != "" &&
        this.selected_createdDateRange["endDate"] != "" &&
        this.selected_createdDateRange["endDate"]
      ) {
        item['filters']["createdDateRange"] = [
          this.selected_createdDateRange["startDate"],
          this.selected_createdDateRange["endDate"]
        ];
      }
     // alert(JSON.stringify(item)); newform.address.selectedCity newform.address.selectedState newform.address.selectedCountry
     if(this.newform.address.selectedCountry && _.has(this.newform.address.selectedCountry ,'id')){
       item['filters']['countryIds'] =[this.newform.address.selectedCountry['id']];

     }
     if(this.newform.address.selectedState && _.has(this.newform.address.selectedState ,'id')){
       item['filters']['stateIds'] =[this.newform.address.selectedState['id']];

     }
     if(this.newform.address.selectedCity ){
       item['filters']['locationIds'] = this.newform.address.selectedCity.map((item)=>{ return item.id});

     }
        this.updateLoading(true);
        this.isListLoading =true;
        this.$store
          .dispatch("getList",{"data":item ,"path":"/branch/list"} )
          .then(response => {
            
            this.list = response.list;
            this.totalCount = this.checkProperty(response, 'totalCount');
            this.totalpages = Math.ceil(response.totalCount / this.perpage);
            
            if(this.getUserData.loginRoleId ==3){
                let tenantId = this.getUserData.tenantId;
                let postData = {
                  tenantId : tenantId
                }
               
                this.$store.dispatch("getChecklist", postData )
            }
             this.isListLoading =false;
              this.updateLoading(false);
          }).catch((error)=>{
               this.isListLoading =false;
              this.updateLoading(false);
          })
      },      
      set_filter: function () {

        this.$refs["filter_menu"].dropdownVisible = false;
        this.final_selected_statusids = [];
        if (this.selected_statusids.length > 0) {
          this.final_selected_statusids = [];
          for (let ind = 0; ind < this.selected_statusids.length; ind++) {
            let current_index = this.selected_statusids[ind];
            this.final_selected_statusids.push(current_index["id"]);
          }
        }

        this.final_selected_config_completed_statusids = [];
        if (this.selected_config_completed_statusids.length > 0) {
          this.final_selected_config_completed_statusids = [];
          for (let ind = 0; ind < this.selected_config_completed_statusids.length; ind++) {
            let current_index = this.selected_config_completed_statusids[ind];
            this.final_selected_config_completed_statusids.push(current_index["id"]);
          }
        }
        
         this.final_active_statusids = [];
        if (this.selected_active_statusids.length > 0) {
          this.final_active_statusids = [];
          for (let ind = 0; ind < this.selected_active_statusids.length; ind++) {
            let current_index = this.selected_active_statusids[ind];
            this.final_active_statusids.push(current_index["id"]);
          }
        }

        
// alert(this.final_selected_config_completed_statusids)
       

       

        this.getList(true);
      },
      clear_filter: function () {
         this.final_active_statusids = [];
          this.newform.address.selectedCountry =null
         this.newform.address.selectedState =null;
         this.newform.address.selectedCity= [];
         this.selected_active_statusids =[];
        this.$refs["filter_menu"].dropdownVisible = false;
        this.selected_statusids = [];
        this.final_selected_statusids = [];
        this.final_selected_config_completed_statusids = [];
        this.selected_config_completed_statusids = [];
      
        this.date = "";
        this.date_range = [];
         this.selected_createdDateRange["startDate"] = "";
         this.selected_createdDateRange["endDate"] = "";
        this.getList();
      },
      pageNate(pageNum) {
        this.page = pageNum;
        this.getList();
      },
      
      // deleteBranch( ){
      //   let post_data = {"formAndLetterId":this.selectedItem['_id'] }
      //   this.$store.dispatch("deleteBranch", post_data)
      //     .then(response => {
      //      this.approveConformpopUp = false;
      //       this.showToster({message:response.message,isError:false});
      //       this.getList();
      //       this.edit =false;


      //     }).catch((er)=>{
      //       this.showToster({message:er,isError:true});
          
      //   });
      // },

       
     // changedCountry  newform.address.selectedCountry  changedState newform.address.selectedState
    changedCountry(){
         this.states =[];
        this.locations =[];
        if( _.has(this.newform.address.selectedCountry , "id")){
            this.newform.address.countryId = this.newform.address.selectedCountry['id'];
           
            this.masterData('states');
        }
        
    },
    changedState(){
         this.locations =[];
         if( _.has(this.newform.address.selectedState , "id")){
            this.newform.address.stateId = this.newform.address.selectedState['id'];
           this.masterData('locations');
        }
    },
    //locationId
    changedCity(){
      if( _.has(this.newform.address.selectedCity , "id")){
            this.newform.address.locationId = this.newform.address.selectedCity['id'];
           this.masterData('locations');
        }

    },
    masterData(category="countries"){

         /*
        countries:[]
        states:[],
        locations:[],
         */
        let matcher ={};
         let postData = {
        matcher: matcher,
        page:1,
        perpage: 1000,
        category: category,
       
      };
      if(category =="states"){

          matcher = { "countryId": this.newform.address.selectedCountry['id']}
      }
       if(category =="locations"){

          matcher = { "stateId": this.newform.address.selectedState['id']  }
      }
       postData['matcher'] = matcher;

         this.$store.dispatch("getMasterData" , postData)
         .then((res)=>{
             //countries
             
             if(category == "countries"){

                 this.countries = res['list'];
                 //alert(JSON.stringify(this.countries))
             }
             if(category =="states"){

                  this.states= res['list'];
             }
            if(category =="locations"){

                this.locations= res['list'];
            }
         })
         .catch((err)=>{
             this[category] =[];

         })

    }
    
    },
    mounted() {
      if(this.checkProperty(this.$route ,'name' ) =='Branches'){

        this.isLoadedFromUrl =true

      }
      
      
      this.selected_statusids = [];
      this.final_selected_statusids = [];
      this.seleted_states = [];
      this.final_selected_states = [];
      this.sortKeys = { "createdOn":-1, "createdByName":1, "managerName":1, "name":1, "active":1, "updatedOn":1  },
     this.masterData('countries');

    this.sortKey = {"path":"createdOn" ,"order":-1};

    if(localStorage.getItem('branch_sort_key') && localStorage.getItem('branch_sort_value')  && localStorage.getItem('branch_sort_value') >=-1 ){
       this.sortKey = {};

      this.sortKey[localStorage.getItem('branch_sort_key')] = parseInt(localStorage.getItem('branch_sort_value'));
      this.sortKeys[localStorage.getItem('branch_sort_key')] = this.sortKey[localStorage.getItem('branch_sort_key')];

      //alert();
      }
    if(localStorage.getItem('branch_perpage')){
        this.perpage = parseInt(localStorage.getItem('branch_perpage'));
    }
     
     
      this.getList();
     

    }
  };
</script>
