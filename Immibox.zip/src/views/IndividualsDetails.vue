<template>
<div class="main-tabs-content tabs_mob petetion__details_page">
    <!-- <div class="tabs-layout-header" >
        <div class="case-no-panel">
             <vs-dropdown>
                <a class="flex items-center">
                    <div class="drop-down-content" >
                        Case No
                        <span >{{checkProperty(petition ,'caseNo')}}</span>
                    </div>
                    <i class="material-icons" v-if="petition">arrow_drop_down</i>
                </a>
                <vs-dropdown-menu class="caseno-dropdown" v-if="petitions">
                    <vs-dropdown-item @click="petetionChange(petition._id)" v-for="(petition, index) in petitions" :key="index">{{ petition.caseNo }}</vs-dropdown-item>
                </vs-dropdown-menu>
            </vs-dropdown>  
        </div>

        
        <div></div>
    </div> -->
    <!-- content section start here  {{petition.questionnaireFilled}}   -->

     

    <div class="tabs-content detail_page_sec petetion__details">
  
        <vs-row vs-w="12" class="bg_white"  >
            <vs-col vs-type="flex" style="padding:0px; width:100%" class="mob-left">
                <section class="petition__details_section">
                    
                    <div class="pd_left">
                        <ul style="top:60px">
                       
                        <li :class="{'current_child':activeTab=='Case Details'}" @click="setActivetab('Case Details' ,true)"><a>Personal Info</a></li>
                        <li v-if="checkProperty(petition ,'dependentsInfo','spouse' ) 
                                    && (  petition.dependentsInfo.spouse.name!=null)
                                    && petition.dependentsInfo.spouse.name!=''"
                             :class="{'current_child':activeTab=='Dependents Info'}" @click="setActivetab('Dependents Info' ,true)"        
                                    >
                                    <a>Dependents Info</a>
                        </li>
                            <li v-if="checkProperty(petition ,'dependentsInfo' ,'childrens') && 
                                            petition.dependentsInfo.childrens.length > 0 && 
                                            petition.dependentsInfo.childrens[0].h4Required && checkProperty(petition.dependentsInfo.childrens[0] ,'name')"
                                 :class="{'current_child':activeTab=='Children Info'}" @click="setActivetab('Children Info' ,true)"               
                                            >
                                <a>Children Info</a>
                            </li>
                            
                            <li v-if="checkProperty(petition ,'documents' ) "
                                 :class="{'current_child':activeTab=='Documents'}" @click="setActivetab('Documents' ,true)"               
                                            >
                                <a>Documents</a>
                            </li>

                             <li 
                                 :class="{'current_child':activeTab=='petitions'}" @click="setActivetab('petitions' ,true)"               
                                            >
                                <a>Cases</a>
                            </li>

                            
                        </ul>
                    </div>
                   
                    <div class="pd_right" >
                        <div class="pd_right_cnt">

                        
                            <div v-if="checkProperty(petition,'beneficiaryInfo') && activeTab=='Case Details'">
                                 <BeneficiaryDetails v-bind:petition="petition" :visastatuses="visastatuses" />
                            </div>

                            <div class="pad20" v-else-if="activeTab=='Case Details'">
                                                       
                            <div class="main-list-wrap petition_details_wrap">
                                <div class="vx-row m-0 main-list-panel">
                                <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(userDetails ,'details' ,'firstName') || checkProperty(userDetails,'beneficiaryInfo','firstName')">
                                    <div class="main-list">
                                    <p>
                                        First Name
                                        <span v-if="checkProperty(userDetails ,'details' ,'firstName')">{{checkProperty(userDetails ,'details' ,'firstName')}}</span>
                                        <span v-if="checkProperty(userDetails,'beneficiaryInfo','firstName')">{{checkProperty(userDetails ,'beneficiaryInfo' ,'firstName')}}</span>
                                    </p>
                                    </div>
                                </div>

                                <div  class="vx-col md:w-1/3 w-full p-0"
                                   v-if="checkProperty(userDetails ,'details' ,'middleName') || checkProperty(userDetails,'beneficiaryInfo','middleName')"
                                >
                                    <div class="main-list">
                                    <p>
                                        Middle Name
                                        <span
                                        style="text-transform: capitalize;"  v-if="checkProperty(userDetails ,'details' ,'middleName')"
                                        >{{checkProperty(userDetails ,'details' ,'middleName')}}</span>
                                        <span
                                        style="text-transform: capitalize;" v-if="checkProperty(userDetails,'beneficiaryInfo','middleName')"
                                        >{{checkProperty(userDetails ,'details' ,'middleName')}}</span>
                                    </p>
                                    </div>
                                </div>

                                <div  class="vx-col md:w-1/3 w-full p-0"
                                   v-if="checkProperty(userDetails ,'details' ,'lastName') || checkProperty(userDetails,'beneficiaryInfo','lastName')"
                                >
                                    <div class="main-list">
                                    <p>
                                        Last Name
                                        <span
                                        style="text-transform: capitalize;" v-if="checkProperty(userDetails ,'details' ,'lastName')"
                                        >{{checkProperty(userDetails ,'details' ,'lastName')}}</span>
                                        <span
                                        style="text-transform: capitalize;" v-if="checkProperty(userDetails,'beneficiaryInfo','lastName')"
                                        >{{checkProperty(userDetails ,'beneficiaryInfo' ,'lastName')}}</span>
                                    </p>
                                    </div>
                                </div>
                                <div  class="vx-col md:w-1/3 w-full p-0"
                                     v-if="checkProperty(userDetails ,'details' ,'email') || checkProperty(userDetails ,'beneficiaryInfo' ,'email')"
                                >
                                    <div class="main-list">
                                    <p>
                                        Email
                                        <span v-if="checkProperty(userDetails ,'details' ,'email')">{{checkProperty(userDetails ,'details' ,'email')}}</span>
                                        <span v-if="checkProperty(userDetails ,'beneficiaryInfo' ,'email')">{{checkProperty(userDetails ,'beneficiaryInfo' ,'email')}}</span>
                                    </p>
                                    </div>
                                </div>

                                 <div  class="vx-col md:w-1/3 w-full p-0"
                                     v-if="checkProperty(userDetails ,'details' ,'phone') || checkProperty(userDetails['beneficiaryInfo'] ,'cellPhoneNumber')"
                                >
                                    <div class="main-list">
                                    <p>
                                        Phone Number
                                        <span v-if="checkProperty(userDetails ,'details' ,'phone')">{{checkProperty(userDetails ,'phoneCountryCode' ,'countryCallingCode')}} {{checkProperty(userDetails ,'details' ,'phone')}}</span>
                                        <span v-if="checkProperty(userDetails['beneficiaryInfo'] ,'cellPhoneNumber')">{{checkProperty(userDetails['beneficiaryInfo'] ,'cellPhoneCountryCode' ,'countryCallingCode')}} {{checkProperty(userDetails['beneficiaryInfo'] ,'cellPhoneNumber')}}</span>
                                    </p>
                                    </div>
                                </div>
                                </div>

                            </div>
                                                             
                            </div>

                            <div v-if="checkProperty(petition ,'dependentsInfo','spouse') 
                            && (checkProperty(petition['dependentsInfo'] ,'spouse','name'))
                                   
                             && activeTab=='Dependents Info' "> 
                                <SpouseDetails v-bind:petition="petition"  @download_or_view="download_or_view" />
                            </div>

                            <div class="pad20"
                            v-if="checkProperty(petition ,'dependentsInfo' ,'childrens') && (
                                            petition.dependentsInfo.childrens.length > 0 && 
                                            petition.dependentsInfo.childrens[0].h4Required && checkProperty(petition.dependentsInfo.childrens[0] ,'name')
                                           &&  activeTab=='Children Info')
                                            "
                            >
                                 <ChildDetails v-bind:petition="petition" @download_or_view="download_or_view"  :visastatuses="visastatuses"/>
                            </div>
                           <div v-if="checkProperty(petition, 'documents') &&  activeTab=='Documents'"  class="pad20">
                           <Documents @updatepetition="reloadPetition" :openTabes="false" @download_or_view="download_or_view" :documentsUploadbtn="true" :currentRole="currentRole" :allbtn="true" v-bind:petition="petition" />
                           </div>
                           
                           <div v-if="  activeTab=='petitions' && (checkProperty(petition ,'beneficiaryInfo') || checkProperty(userDetails ,'_id')) "  class="pad20">
                            
                                <petitions v-if="checkProperty(petition ,'beneficiaryInfo')" :beneficiaryId="petitionId" :beneficiaryInfo="checkProperty(petition ,'beneficiaryInfo')" :petitionerDetails="checkProperty(petition,'petitionerDetails')" />
                                <petitions v-else :beneficiaryId="petitionId" :beneficiaryInfo="userDetails" :petitionerDetails="checkProperty(userDetails,'petitionerDetails')"/>
                            
                           </div>
                        
                        </div>
                    </div>
                </section>
            </vs-col>   
        </vs-row>
    </div>
    <vs-popup class="document_modal" :title="checkProperty(selectedFile,'name')" :active.sync="docPrivew">
        <h2></h2>
        <div class="pad20">
            <img :class="{'pdf_view_download':docType == 'pdf', 'office_view_download':docType == 'office'  , 'image_view_download':docType =='image'}" class="download-button" @click="downloads3file(selectedFile)" src="@/assets/images/download.svg" />
            <!-- <span :class="{'pdf_view_close':docType == 'pdf', 'office_view_close':docType == 'office'  , 'image_view_close 33':docType =='image'}" class="close close2" @click="docPrivew= false"></span> -->
            <template v-if="docType=='office'">
                <VueDocPreview :value="docValue" type="office" />
            </template>
            <template v-else-if="docType == 'image'">
                <img :src="docValue">
            </template>
            <template v-else-if="docType == 'pdf'">
                <div class="pdf">
                    <object :data="docValue" type="application/pdf" width="1000" height="600" v-if="docPrivew">
                        alt : <a :href="docValue">PDF</a>
                    </object>
                </div>
            </template>
        </div>
    </vs-popup>

    

</div>
</template>

<script>
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import FormsandLetters from "./petition/FormsLetters";
import CompanyDocsTemplates from  "./petition/CompanyDocsTemplates";
import ScannedCopies from "./ScannedCopies";
import ProcessFlow from "./petition/ProcessFlow";
import RequestLCA from "./RequestLCA";
import LCADetails from "./LCADetails";
import PetitionUpdates from "./petition/PetitionUpdates";

import ClientDetails from "./petition/ClientDetails";
import ChildDetails from "./petition/ChildDetails";
import SpouseDetails from "./petition/SpouseDetails";
import Documents from "./petition/Documents";
import BeneficiaryDetails from "./petition/BeneficiaryDetails";
import Communication from "./petition/Communication";
import Fees from "./petition/Fees";
import petitions from "@/views/Petitions.vue";
  import _ from "lodash";
import moment from "moment";
import JQuery from "jquery";
import VueDocPreview from 'vue-doc-preview'


export default {
    components: {
        VueDocPreview,
        VuePerfectScrollbar,
        FormsandLetters,
        ScannedCopies,
        Documents,
        ProcessFlow,
        RequestLCA,
        LCADetails,
        ClientDetails,
        SpouseDetails,
        ChildDetails,
        BeneficiaryDetails,
        Communication,
        PetitionUpdates,
        Fees,
        CompanyDocsTemplates,
        petitions
    },
    name: "app",
    data: () => ({
        activeTab:'Case Details',
       formsAndLettersList:[],
        feeInvoicesPermessions:false,
        isLcaRequiredForPetition:true,
        isEveryThingLoaded:false,
        showProcessFlow:false,
        docPrivew: false,
        docValue: '',
        docType: "",
        selectedFile: null,

        loaded: false,
        currentRole: null,
        currentUserId: null,
        SuccessQuestionnaire: false,
        petition: [],
        petitions: [],
        petitionhistory: [],
        supervisorlist: [],
        
        tabs: [{
                index: 0
            },
            {
                index: 1
            },
            {
                index: 2
            },
            {
                index: 3
            },
            {
                index: 4
            },
            {
                index: 5
            },
            {
                index: 6
            }
        ],

        visa_status: {},
        visastatuses: [],
        spouse_currentStatusDetails: {},
        country_names: {},
        lcaDetails: null,
        workFlowId:null,
        workFlowDetails:null,
       //Filing Fee Veriables
        editFilngFee:false,
		filingFeeData:[
            {
            amount: null,
            invoice: false,
            description: "",
            },
            ],
	    filingFeesPopup:false,
		filingFeeformerrors:'',
		submitingFilingFee:false,
		filingFeeComment:'',
		emailInvoice:false,
        validatefilingFeeDescrition:true,
         //Filing Fee Veriables End
         userDetails:null

    }),
    watch: {
       $route:function(){
        if (this.$route.params && this.$route.params.itemId) {
            this.petitionId = this.$route.params.itemId;
            this.init();
        }
       }
    },
    methods: {
       
   
  
    download_or_view(value) {
        
        if (_.has(value, "path")) {
            value['url'] = value['path'];
            value['document'] = value['path'];
        }

        if (_.has(value, "url")) {
            value['path'] = value['url'];
            value['document'] = value['url'];
        }

        if (_.has(value, "document")) {
            value['path'] = value['document'];
            value['url'] = value['document'];
        }
        

        this.selectedFile = value;
        this.docValue = '';
        this.docPrivew = false;
        this.docType = false;
        this.docType = this.findmsDoctype(value);

        if (this.docType == "office" || this.docType == "image") {

            value.url = value.url.replace(this.$globalgonfig._S3URL, "");
            value.url = value.url.replace(this.$globalgonfig._S3URLAWS, "");
            let postdata = {
                keyName: value.url
            };
            this.$store.dispatch("getSignedUrl", postdata).then((response) => {
                this.docValue = response.data.result.data;

                if (this.docType == "office") {
                    this.docValue = encodeURIComponent(response.data.result.data);
                }
                this.docPrivew = true;
            });

        } else {

            this.downloads3file(value);
        }

    },

    
    reloadPetition(tab='Case Details') {
        
        
        if(tab !=''){
            
            this.$store.dispatch("setPetitionTab" , tab)
            .then(()=>{
                
                this.init();
                
            })
            .catch(()=>{
                this.init();
                
            })
        }else{
            this.$store.dispatch("setPetitionTab" , 'Case Details')
            this.init();
            

        }
        
        
            
        
    },
    setActivetab(stab='Case Details' ,callFromClick=false) {
        //Communication Company Docs Case Details Dependents Info  , Children Info , Fees/Invoices
       
        if(!stab){
             stab='Case Details'
        }
        this.activeTab= stab
          
        
    },
   
    
    loadPetetion(tab='') {
      
        if(tab==''){
            tab = this.activeTab;

        }
        
        
       // this.workFlowDetails =null;
      //this.petition =null;
      //  this.lcaDetails = null;
        // this.petition.filingFeeDetails = null;
     
        if(this.petition ==null){
             this.loaded = false;
             this.loaded = true;
            this.$vs.loading();

        }
       let postData ={"userId":"" ,"getDocuments":true}

            postData['userId'] = this.petitionId;
            let pth="petition/get-recent-by-beneficiary";
            pth ="petition-common/get-recent-by-beneficiary";
         this.$store.dispatch("commonAction", {"data":postData ,"path":pth}).then(response => {
            
                this.$vs.loading.close();
                this.loaded = false;
                this.loaded = true;
                this.petition = response['caseDetails'];
                if(this.checkProperty(response,'userDetails')){
                    this.userDetails = response['userDetails'];
                }
                if(this.checkProperty(response,'profileDetails')){
                    this.userDetails = response['profileDetails'];
                }
                
           
                         
                
        });
       
    },
    init(){
        
    // this.$store.commit("TOGGLE_IS_SIDEBAR_ACTIVE", false);
    // this.$store.dispatch('updateSidebarWidth', 'reduced');
    //  this.$store.commit('UPDATE_SIDEBAR_ITEMS_MIN', true)
        
        
   
    this.currentRole = this.$store.state.user.loginRoleId;
    this.currentUserId = this.$store.state.user._id;
    this.loadPetetion();

    
   
    },
    
    },
    beforeDestroy() {
        //  JQuery('#btnSidebarToggler').click()

    },
    mounted() {
         //this.$store.dispatch("setPetitionTab" , 'Case Details');
         this.$store.dispatch("getmasterdata", "visa_status").then((response) => {
           
           this.visastatuses = response;
       });
      
        if (this.$route.params && this.$route.params.itemId) {
            this.petitionId = this.$route.params.itemId;
            this.init();

        }
   
    },
    computed:{
       
      
        
    }
};
</script>
