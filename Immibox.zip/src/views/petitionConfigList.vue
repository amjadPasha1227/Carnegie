<template>
  <div class="settings_right">
    <div class="content-header">
      <div class="content-header-left">
        <div class="search">
         <!--
          <vs-input icon-pack="feather" icon="icon-search" v-model="searchtxt" placeholder="Search"
            class="is-label-placeholder" />
            -->
        </div>
      </div>
      <div class="content-header-right">
         
        <vs-dropdown  vs-custom-content vs-trigger-click>
          <vs-button
            color="primary"
            class="filter-btn "
            type="border"
            icon-pack="feather"
            icon="icon-chevron-down"
            icon-after
          
          >
            <img src="@/assets/images/main/icon-filter.svg"   @click="toggleFilter()" /> Filters
          </vs-button>
          <vs-dropdown-menu ref="filter_menu" class="filters-content settings_filters">

            <div class="filters-form-fileds">
              <div class="form-container">
                <div class="vx-row">

                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Select Case Type</label>
                    <!----
                    
                    petitionTypesList:[],
      selectedPetitionType:null,
      petitionSubTypesList:[],
      selectedPetitionSubType:null,
      selectedPetitionType
      selectedPetitionSubType
                    ---->
                    
                    <multiselect v-model="selectedPetitionType" :options="petitionTypesList" :multiple="false"
                      :close-on-select="true" :clear-on-select="false" :select-label="''" :preserve-search="true"
                      @input="changedPetitionType" 
                      placeholder="Select Case Type" label="name" track-by="id" :preselect-first="false">
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">{{ values.length }}
                          options selected</span>
                      </template>
                    </multiselect>
                  </div>
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Select Case Subtype</label>
                    <!----
                    
                    petitionTypesList:[],
      selectedPetitionType:null,
      petitionSubTypesList:[],
      selectedPetitionSubType:null,
                    ---->
                    
                    <multiselect v-model="selectedPetitionSubType" :options="petitionSubTypesList" :multiple="false"
                      :close-on-select="true" :clear-on-select="false" :select-label="''" :preserve-search="true"
                      @input="changedPetitionSubType"
                      placeholder="Select Petition Sub Type" label="name" track-by="id" :preselect-first="false">
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">{{ values.length }}
                          options selected</span>
                      </template>
                    </multiselect>
                  </div>
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Select Status</label>
                   
                    <multiselect v-model="selected_statusids" :options="all_statusids" :multiple="true" :hideSelected="true"
                      :close-on-select="false" :clear-on-select="false" :select-label="''" :preserve-search="true"
                      placeholder="Select Status" label="name" track-by="name" :preselect-first="false">
                      <!-- <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">{{ values.length }}
                          options selected</span>
                      </template> -->
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} Status Selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template> 
                    </multiselect>
                  </div>

                  <div class="vx-col md:w-1/3 w-full con-select" v-if="[1].indexOf(getUserRoleId)>-1">
                    <label class="typo__label">Select  Customers</label>
                    
                   
                          <multiselect
                          v-model="filteredTenants"
                          :options="tenantList"
                          :multiple="true" :hideSelected="true"
                          :close-on-select="true"
                          :clear-on-select="false"
                          :preserve-search="true"
                          placeholder="Select Customers"
                          label="name"
                          track-by="_id"
                          :preselect-first="false"
                          > 
                          <template slot="selection" slot-scope="{ values, isOpen }">
                            <span
                            class="multiselect__selectcustom"
                            v-if="values.length && !isOpen"
                            >{{ values.length }} Customer(s) Selected</span
                            >
                            <span
                            class="multiselect__selectcustom"
                            v-if="values.length && isOpen"
                            ></span>
                          </template>
                          </multiselect>
            
                  </div>

                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Created Date</label>
                    <date-range-picker
                      :maxDate="new Date()"
                      :autoApply="autoApply"
                      :ranges="false"
                      v-model="selected_createdDateRange"
                    ></date-range-picker>
                  </div>
                 </div>
                   
                   
     
              </div>
            </div>
            <div class="filters-status">
              <div class="left-buttons">

              </div>
              <div class="right-buttons">
                <vs-button color="success" class="save" type="filled" v-on:click="set_filter()">Apply</vs-button>
                 <vs-button color="dark" class="cancel" type="filled" v-on:click="clear_filter($event)">Clear</vs-button>                
              </div>
            </div>
          </vs-dropdown-menu>
        </vs-dropdown>
        <!--   -->
        <vs-button type="border" class="light-blue-btn" v-if="[1,3].indexOf(getUserRoleId)>-1" @click="addoreditPopup=false;addoreditPopup=true;toggleModal(true)">Add Configuration<span>
          <img class="add-user-icon ml-2" src="@/assets/images/main/add-user.svg">
        </span>
        </vs-button>
     
        
        
      </div>
    </div>

     

    <div class="accordian-table" v-if="list.length > 0">
     
    
      <vs-table :data="list"  >
        <template slot="thead" v-if="list.length>0" >
        <!--
        'tenantName':1,
      'createdByName':1,
      "typeName":1,
      "subTypeName":1,
      "createdOn":-1,
      "updatedOn":1
        --->
         
         <vs-th>
        
          <a @click="sortMe('typeName')"  v-bind:class="{'sort_ascending':sortKeys['typeName']==1, 'sort_descending':sortKeys['typeName']!=1}" >
              Case Type
              </a>
         </vs-th>
         <vs-th>
         <a @click="sortMe('subTypeName')"  v-bind:class="{'sort_ascending':sortKeys['subTypeName']==1, 'sort_descending':sortKeys['subTypeName']!=1}" >
              Case Subtype
              </a>
         </vs-th>
         <vs-th v-if="[1].indexOf(getUserRoleId)>-1 && filteredTenants.length>0 ">
            <a @click="sortMe('tenantName')"  v-bind:class="{'sort_ascending':sortKeys['tenantName']==1, 'sort_descending':sortKeys['tenantName']!=1}" >
             Customer
              </a>
             </vs-th>
         <vs-th>
         
         <a @click="sortMe('createdByName')"  v-bind:class="{'sort_ascending':sortKeys['createdByName']==1, 'sort_descending':sortKeys['createdByName']!=1}" >
             Created By
              </a>
         </vs-th>
         <vs-th>
          <a @click="sortMe('createdOn')"  v-bind:class="{'sort_ascending':sortKeys['createdOn']==1, 'sort_descending':sortKeys['createdOn']!=1}" >
             Created On
              </a>
         </vs-th>
         <vs-th>
         
         <a @click="sortMe('updatedOn')"  v-bind:class="{'sort_ascending':sortKeys['updatedOn']==1, 'sort_descending':sortKeys['updatedOn']!=1}" >
            
         Updated On
          </a>
         
         </vs-th> 
         <vs-th class="actions">Actions</vs-th> 
        

        </template>

        <template slot-scope="{data}">
          <vs-tr  :data="tr" :key="indextr" v-for="(tr, indextr) in data">
            
            <vs-td class="td_label">
            {{checkProperty(tr ,"typeDetails" ,"name")}}

              <small v-if="checkProperty(tr , 'refId') !=''">(Global)</small>
            
            </vs-td>
            <vs-td>{{checkProperty(tr ,"subTypeDetails" ,"name")}}</vs-td>
             <vs-td v-if="[1].indexOf(getUserRoleId)>-1 && filteredTenants.length>0">{{checkProperty(tr ,'tenantDetails' ,'name')}}</vs-td>
            <vs-td>{{checkProperty(tr ,"createdByName")}}</vs-td>
            <vs-td>{{tr["createdOn"] | formatDate}}</vs-td>
             <vs-td>
            <span v-if="checkProperty(tr ,'updatedOn')"> {{tr["updatedOn"] | formatDate}} </span>
             <!---
             <span class="statusspan " :class="{'status_pending':!tr.active,'status_active':tr.active}" >
              {{tr.active?"Active":'Inactive'}}
              </span>
              -->
             </vs-td>
             
           <vs-td>
              
            
              <vs-dropdown class="msg_dropdown_icon"  :vs-trigger-click="true">
                 <template
                 v-if="(tr.statusId!==1 && ( [1,3].indexOf(getUserRoleId)>-1 ))
                
                 || ( checkProperty(tr ,'tenantDetails') && [3].indexOf(getUserRoleId)>-1 )
                 
                 "
                  >
                  <a class="a-icon" href.prevent><more-vertical-icon size="1.5x" class="custom-class"></more-vertical-icon></a>
                 <vs-dropdown-menu class="loginx msg_dropdown" >
                  
                   <vs-dropdown-item v-if="tr.statusId!==1 && ( [1,3].indexOf(getUserRoleId)>-1 )">
                    <a href="#" >
                        <p style="cursor:pionter" @click="openPopUp(tr)" >
                        <template v-if="tr['active']">Inactivate</template>
                        <template v-if="!tr['active']"> Activate</template>
                        </p>
                    </a>
                   </vs-dropdown-item>
                   

                    <vs-dropdown-item v-if="  ( [1].indexOf(getUserRoleId)>-1 )">
                      <a href="#" >
                      <p style="cursor:pionter" @click="editMe(tr)" >Edit</p>
                      </a>
                     </vs-dropdown-item>
                 
                   
                    
                    
                  </vs-dropdown-menu>
                 </template>
                 <template v-else>
                 <a class="a-icon" href.prevent><more-vertical-icon size="1.5x" class="custom-class disbleMenu"></more-vertical-icon></a>
                 </template> 
                  
                </vs-dropdown>
            
              
            </vs-td>
            


          </vs-tr>
        </template>
      </vs-table>
      <paginate  v-if="list.length>0"  v-model="page" :page-count="totalpages" :page-range="3" :margin-pages="2" :click-handler="pageNate"
        prev-class="vs-pagination--buttons btn-prev-pagination vs-pagination--button-prev"
        next-class="vs-pagination--buttons btn-next-pagination vs-pagination--button-next" :prev-text="'<i></i>'"
        :next-text="'<i></i>'" :container-class="'pagination vs-pagination--nav'" :page-class="'page-item'"></paginate>
    </div>


    <vs-popup class="holamundo main-popup" :title="'Manage Forms/Letters'" v-if="addPopup" :active.sync="addPopup">
      <form>
        <div class="form-container">
          <div class="vx-row">
            <div class="vx-col w-full">
              <vs-input v-model="newConfig.title" placeholder="Title" name="Title" v-validate="'required'" class="w-full"
                label="Title"   data-vv-as="Title"    />
              <span class="text-danger text-sm"
                v-show="errors.has('Title')">{{ errors.first("Title") }}</span>
            </div> 
             <div class="vx-col w-full">
             
               <multiselect
               class="w-full"
                v-model="newConfig.formAndLetterIds" :options="formsLettersList" :multiple="true" :hideSelected="true" name="forms and letters"
                      :close-on-select="false" :clear-on-select="false" :select-label="''" :preserve-search="true"
                      @input="changedDocType()"
                      placeholder="Select forms and letters" label="name" track-by="name" :preselect-first="false">
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">{{ values.length }}
                          options selected</span>
                      </template>
                    </multiselect>
                    <span class="text-danger text-sm" v-show="errors.has('forms and letters')">{{ errors.first("forms and letters") }}</span>
             </div>
             <div class="vx-col w-full"  v-if="[1,2].indexOf(getUserRoleId) >-1" >
             
               <multiselect
               class="w-full"
                v-model="newConfig.tenantIds" :options="tenantList" :multiple="true" :hideSelected="true" name="Tenants"
                      :close-on-select="false" :clear-on-select="false" :select-label="''" :preserve-search="true"
                     
                      placeholder="Select Tenants" label="Tenants" track-by="name" :preselect-first="false">
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">{{ values.length }}
                          options selected</span>
                      </template>
                    </multiselect>
                    <!--<span class="text-danger text-sm" v-show="errors.has('Tenants')">{{ errors.first("Tenants") }}</span>-->
             </div>
     
             <div class="vx-col w-full">
             <vs-checkbox v-model="newConfig.insertTo"  class="padl6">Insert to all</vs-checkbox>
             </div>
            
                   
            
          </div>


          <div class="text-danger text-sm formerrors" v-show="formerrors.msg" @click="formerrors.msg=''">
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
              icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
          </div>
        </div>
        <div class="popup-footer">
          <vs-button color="dark" @click="edit=false;createNew(false)" class="cancel" type="filled">Cancel</vs-button>
          <vs-button color="success"  :disabled="validateForm" class="save" v-if="edit" @click="updateformandLetter()" type="filled">Update</vs-button>
          <vs-button color="success" :disabled="validateForm" class="save" v-else @click="createAction()" type="filled">Save</vs-button>
        </div>
      </form>
    </vs-popup>

    

    <vs-popup class="holamundo main-popup"  :title="(checkProperty(selectedItem,'active')?'Inactivate ':' Activate')+' Configuration'" :active.sync="approveConformpopUp">
      <div class="form-container">
        
        <div class="vx-row">
          <div class="vx-col w-full">
          <p>Are you sure of {{checkProperty(selectedItem, 'active')?'inactivating':'activating '}} this Configuration?</p>
            
          </div>
          
        </div>
       
      </div>
      <div class="popup-footer"> 
        <vs-button color="dark" class="cancel" type="filled" @click="approveConformpopUp=false">Cancel</vs-button>
        <vs-button color="success" class="save" type="filled" @click="toggleActivate()">{{checkProperty(selectedItem,'active')?'Inactivate ':' Activate'}}</vs-button>
      </div>
    </vs-popup>

 <NoDataFound ref="NoDataFoundRef" :loading="listLoading" v-if="list.length == 0 && rload" content="" :heading="callFromSerch?'No Results Found':'No Case Configuration Found'" type='Forms and Letters' />
    
  <peitionConfig  ref="peitionConfigModal" @hideMe='addoreditPopup=false'  @refreshList="clear_filter"  />


  </div>
</template>

<script>
import DateRangePicker from "vue2-daterange-picker";
  import Datepicker from "vuejs-datepicker-inv";
  import Paginate from "vuejs-paginate";
  
import "vue2-daterange-picker/dist/vue2-daterange-picker.css";

  import _ from "lodash";
  import { FormWizard, TabContent } from "vue-form-wizard";
  import "vue-form-wizard/dist/vue-form-wizard.min.css";
  import PhoneMaskInput from "vue-phone-mask-input";
  import { TheMask } from 'vue-the-mask'
  
import FileUpload from "vue-upload-component/src";
import VuePhoneNumberInput from 'vue-phone-number-input';
import 'vue-phone-number-input/dist/vue-phone-number-input.css';
import { MoreVerticalIcon } from 'vue-feather-icons';

import peitionConfig from './settings/peitionConfig';
  import NoDataFound from "@/views/common/noData.vue";


  export default {
    computed:{
      validateForm(){
        if(
          (this.newConfig.title && this.newConfig.title.trim() !='' ) 
          && (  _.has(this.newConfig ,"typeId") && this.newConfig['typeId']>0  )
          && (  _.has(this.newConfig ,"subTypeId") && this.newConfig['subTypeId']>0  )
          && ( _.has(this.newConfig ,"formAndLetterIds") && this.newConfig['formAndLetterIds'].length>0  )
         
        ){

          return false;
        }else{
          return true;
        }

      },
     
    },
    components: {
      DateRangePicker,
      VuePhoneNumberInput,
      Datepicker,
      Paginate,
      FileUpload,
      FormWizard,
      TabContent,
      PhoneMaskInput,
      TheMask,
      MoreVerticalIcon,
      peitionConfig,
      NoDataFound
    },

    data: () => ({

       tenantsList:[],
    filteredTenants:[],
    finalFilteredTenants:[],

      callFromSerch:false, 
      contentLoaded:false,
      addoreditPopup:false,
      petitionTypesList:[],
      selectedPetitionType:null,
      petitionSubTypesList:[],
      selectedPetitionSubType:null,

    selected_createdDateRange: ["", ""],
    autoApply: "",
        value:[],
        all_formTypes:[{"name":"Form" ,"id":"Form"},{"name":"Letter" ,"id":"Letter"} ],
        
      selectedItem:null,
      selectedStatus:2,
      actionText:"Do you want to Delete?",
      formerrors: {
        msg: ""
      },
      date: null,
      approveConformpopUp: false,
     
     newConfig: {title:null ,typeId:null ,subTypeId:null , formAndLetterIds:'',insertTo:false ,tenantIds:[]},
      list: [],
      addPopup: false,
      NewPetition: false,
      
     
      searchtxt: "",
      query: [],
      country_code: 231,
      all_statusids: [{"id":true,"name":"Active"},{"id":false,"name":"Inactive"}],
      selected_statusids: [],
      final_selected_statusids: [],
      filter_roleIds: [],
      final_filter_roleIds: [1,2,3,4,5,8,9,10,11,12],

      
      seleted_states: [],
      final_selected_states: [],
      locations: [],
      // locationIds
      final_selected_typesids:[],
      selected_typeids:[],
      
      
      date_range: [],
      page: 1,
      perpage: 25,
      totalpages: 0,
      

     
      switch2:true,
      users_status:{},
      edit:false,
      sortKeys:{},
      sortKey:{},
      itemDetails:null,
      petitionTypeId:null,
      formsLettersList:[],
      tenantList:[],
      petitionSubTypeId:0,
      allPetitionTypes:[],
      selectedPetitionTypes:[],
      selectedPetitionSubTypes:[],
      allPetitionSubTypes:[],
      listLoading:false,
      rload:false
    }),
    watch: {
      searchtxt: function () {
        this.getList();
      },
      addoreditPopup:function(value){
        this.toggleModal(value);

      }

    },
    methods: {
      caseSelectionChanged(caseItem ){

      let path="/petition-config/manage-case-types";
      if( this.checkProperty(caseItem,'subTypeId')>0){
        path ="/petition-config/manage-case-sub-types";
      }
      let postData ={

        selList:[],
        tenantCustomId:''

      };
    let itm=  {
      "id": null,
      "selected": null, // Send 'false' to disable
      "isCaseTypeSelected":null

   }

  itm['id'] = caseItem['id']
  itm['selected'] = caseItem['active'] ? false:true;
  itm['isCaseTypeSelected'] = caseItem['active'] ? false:true;


  if(this.checkProperty(caseItem ,'tenantDetails' ,"customId")){
    postData['tenantCustomId'] = this.checkProperty(caseItem ,'tenantDetails' ,"customId");
  }

   postData['selList'].push(itm);

      this.$store
        .dispatch("commonAction", {
          data: postData,
          path: path,
        })
        .then((res) => {
          this.approveConformpopUp =false;
                 //this.showToster({message:res.message,isError:false });
                this.getList();
                if(this.getUserData.loginRoleId ==3){
                let tenantId = this.getUserData.tenantId;
                let postData = {
                  tenantId : tenantId
                }
               
                this.$store.dispatch("getChecklist", postData )
            }
        }).catch((err) => {
         // this.showToster({message:err ,isError:true});
        })




    },

      updateLoading(value){

          this.rload = false
          this.listLoading =value ; 
          this.rload = true
    
    
     
        setTimeout(()=>{
           try{
          this.$refs['NoDataFoundRef'].updateLoading(value);
           }catch(err){
     
                  
       
        
            }

        } , 10)
        


     
    },
      toggleFilter() {

         //$refs["filter_menu"].dropdownVisible = false;
         /*
         try{
           alert(this.$refs["filter_menu"].dropdownVisible);
         }catch(e){
           
         }
        */ 
         },
      editMe(item){
        this.selectedItem =item;

       
        this.$refs['peitionConfigModal'].getpetitionConfigDetails( this.selectedItem);
      },
       
      toggleModal(show=false){
        
       this.$refs['peitionConfigModal'].toggleModal(show)
      },
      
      openPopUp(item){
        this.selectedItem =item;
        this.approveConformpopUp =true;
        

      },
      toggleActivate() {
            let payLoad = {
               "petitionConfigId":this.selectedItem['_id'],
                "active": this.selectedItem['active'] ? false:true
            };
            if(this.checkProperty(this.selectedItem ,'tenantId') && this.checkProperty(this.selectedItem ,'tenantDetails' ,"customId")){
            // this.caseSelectionChanged(this.selectedItem); 
            }
           // else{
            //petition-config/manage-active-status
            this.$store.dispatch("commonAction", {data:payLoad ,"path":"/petition-config/manage-active-status"}).then((res) => {
              this.approveConformpopUp =false;
                 this.showToster({message:res.message,isError:false });
                this.getList();
                if(this.getUserData.loginRoleId ==3){
                let tenantId = this.getUserData.tenantId;
                let postData = {
                  tenantId : tenantId
                }
               
                this.$store.dispatch("getChecklist", postData )
            }

            }).catch((error) => {
                this.showToster({message:error,isError:true });
               

            });
        // }

        },
      changedPetitionType(item){
        this.selectedPetitionType = item,
        this.petitionTypeId =0;
        
        this.petitionSubTypesList = [];
        this.selectedPetitionSubType =null;
        this.petitionSubTypeId =0;
        if(this.selectedPetitionType && _.has(this.selectedPetitionType,"id")){
          this.petitionTypeId =this.selectedPetitionType['id'];
          this.getPetitionSubTypes();
          
        }

        /*
         petitionTypesList:[],
        
        ,
        selectedPetitionSubType:null,
        */

      },
      changedPetitionSubType(item){

        this.selectedPetitionSubType = item,
        this.petitionSubTypeId =0;
        if(this.selectedPetitionSubType && _.has(this.selectedPetitionSubType,"id")){
          this.petitionSubTypeId =this.selectedPetitionSubType['id'];
         
          
        }

      },
      getPetitionTypes(){
       

         let item ={
          matcher:{},   
          page:1,
          perpage: 100000,
          category: "petition_types",
          
        };

        this.$store
          .dispatch("getMasterData",item )
          .then(response => {
            this.petitionTypesList = response.list;
            this.selectedPetitionType = _.find(this.petitionTypesList, {"id":this.petitionTypeId});
            this.petitionSubTypesList = [];
          });
      },
      getPetitionSubTypes(){
       

         let item ={
          matcher:{
            "petitionType":parseInt(this.petitionTypeId)
          },   
          page:1,
          perpage: 100000,
          category: "petition_sub_types",
          
        };

        this.$store
          .dispatch("getMasterData",item )
          .then(response => {
            this.petitionSubTypesList = response.list;
            this.selectedPetitionSubType = _.find(this.petitionSubTypesList, {"id":this.petitionSubTypeId});
            
          });
      },
        details(){
            //this.$route.push("/petition-config-details/"+this.petitionTypeId+"/"+item['id']);
        
        },
        getTenantList(){
             let query = {};
        query['page'] = 1;
        query['perpage'] = 10000;
        query['filters'] = {};
        query['getMasterData'] = true;
       // query['sorting'] = this.sortKey;

        this.$store
          .dispatch("getList",{data:query ,path:'/tenant/list'} )
          .then(response => {
              
              this.tenantList = response.list;
           
          });

        },
      
      changedDocType(){
       // alert();

      },
       sortMe(sort_key=''){

      
      if(sort_key !=''){
          this.sortKeys[sort_key] = this.sortKeys[sort_key]==1?-1:1
          // this.sortKey[sort_key] = this.sortKeys[sort_key]
          this.sortKey = {"path":sort_key ,"order":this.sortKeys[sort_key]};

          localStorage.setItem('petitionConfig_sort_key', sort_key);
          localStorage.setItem('petitionConfig_sort_value', this.sortKey[sort_key]);
          this.getList();
      }
          
      

      },
      manageFormsletters(item){
          
        this.selectedItem = item;
        this.newConfig =  {title:null ,typeId:parseInt(this.petitionTypeId) ,subTypeId:parseInt(this.selectedItem['id']) , formAndLetterIds:'',insertTo:false ,tenantIds:[]},
        this.addPopup=true;

      },
     
     createNew(action =true){
       this.edit =false;
        this.newConfig =  {title:null ,typeId:null ,subTypeId:null , formAndLetterIds:'',insertTo:false ,tenantIds:[]},
        
        this.addPopup=action;
     },
     getList() {
      
        this.contentLoaded = false;
         let postData ={
          filters:{
              "title":this.searchtxt,
             "tenantIds":[],
             "typeIds":[],
             "subTypeIds":[],
             "statusList":[],//this.final_selected_statusids,
             "activeList":this.final_selected_statusids,
             "createdDateRange":[],
              "tenantIds":this.finalFilteredTenants

          },   
          page:this.page,
          perpage: this.perpage,
          sorting:this.sortKey
          
        };
        if(this.petitionTypeId){
          postData['filters']['typeIds'] =[this.petitionTypeId];
        }

        if(this.petitionSubTypeId){
          postData['filters']['subTypeIds'] =[this.petitionSubTypeId];
        }

        if (
        this.selected_createdDateRange["startDate"] &&
        this.selected_createdDateRange["startDate"] != "" &&
        this.selected_createdDateRange["endDate"] != "" &&
        this.selected_createdDateRange["endDate"]
      ) {
        postData['filters']["createdDateRange"] = [
          this.selected_createdDateRange["startDate"],
          this.selected_createdDateRange["endDate"]
        ];
      }
      this.updateLoading(true);
        this.$store
          .dispatch("getList",{"data":postData ,"path":'/petition-config/list'} )
          .then(response => {
              this.updateLoading(false);
            this.list = response.list;
            this.contentLoaded = true;
            this.totalpages = Math.ceil(response.totalCount / this.perpage);
            this.updateLoading(false);
           
          }).catch((err)=>{
             this.updateLoading(false);
          })
      },
      updateformandLetter(){
        this.$validator.validateAll().then(result => {
          if (result) {
            let postData ={"name":this.newConfig.title ,type:this.newConfig.type.name, document:this.newConfig.document}
         
         postData = Object.assign(postData ,{"formAndLetterId":this.selectedItem['_id']})
        this.$store.dispatch("updateformandLetter", postData)
          .then(response => {
           
            this.showToster({message:response.message,isError:false});
            this.getList();
            this.addPopup =false;
            this.edit =false;


          }).catch((error)=>{
                  Object.assign(this.formerrors, {
                    msg:error
                  });
            //this.showToster({message:"Somthin went wrong..!",isError:true});
          
        });
         }
        });

      },
      createAction() {

        
        this.$validator.validateAll().then(result => {
          if (result) {
            let postData ={"title":this.newConfig.title ,typeId:this.newConfig.typeId, subTypeId:this.newConfig.subTypeId ,formAndLetterIds:[] ,tenantIds:[]}
            let formAndLetterIds = [];
            _.forEach(this.newConfig['formAndLetterIds'],(item)=>{
                formAndLetterIds.push(item._id);
            });

            postData.formAndLetterIds = formAndLetterIds;
             let tenantIds = [];
             if([1,2].indexOf(this.getUserRoleId)){

                   _.forEach(this.newConfig['tenantIds'],(item)=>{
                        tenantIds.push(item._id);
                     });
                 postData.tenantIds = tenantIds;

                 if(this.newConfig['insertTo']){
                     postData = Object.assign(postData,{"insertTo":"All"})
                 }

             }
          
            this.$store
              .dispatch("commonAction", {data:postData ,path:"/petition-config/create"})
              .then(response => {
                
                 this.showToster({message:response.message,isError:false });
                 this.getList();
                 this.addPopup =false;
                
              })
              .catch((error)=>{
                  
                Object.assign(this.formerrors, {
                    msg:error
                  });
              })
          }
        });
      },
        
           
      set_filter: function () {
        this.$refs["filter_menu"].dropdownVisible = false;
       
        this.final_selected_statusids = [];
        if (this.selected_statusids.length > 0) {
          this.final_selected_statusids = [];
          for (let ind = 0; ind < this.selected_statusids.length; ind++) {
            let current_index = this.selected_statusids[ind];
            this.final_selected_statusids.push(current_index["id"]);
          }
        }

        this.final_selected_typesids = [];
        if (this.selected_typeids.length > 0) {
          this.final_selected_typesids = [];
          for (let ind = 0; ind < this.selected_typeids.length; ind++) {
            let current_index = this.selected_typeids[ind];
            this.final_selected_typesids.push(current_index["id"]);
          }
        }
         this.finalFilteredTenants = [];
        if(this.filteredTenants.length>0) {
          this.finalFilteredTenants = _.map(this.filteredTenants, '_id');
        }
        


        
// alert(this.final_selected_typesids)
       

       

        this.getList();
      },
      clear_filter: function () {
        this.searchtxt ='';
        this.filteredTenants = [];
        this.finalFilteredTenants =[];
        this.$refs["filter_menu"].dropdownVisible = false;
        
        this.selected_statusids = [];
        this.final_selected_statusids = [];
        this.final_selected_typesids = [];
        this.selected_typeids = [];
        this.selectedPetitionType =[];
        this.selectedPetitionSubType=[];
      
      
        this.date = "";
        this.date_range = [];
         this.selected_createdDateRange["startDate"] = "";
         this.selected_createdDateRange["endDate"] = "";
        this.getList();
      },
      pageNate(pageNum) {
        this.page = pageNum;
        this.getList();
      },
      
      deleteformandLetter( ){
        let post_data = {"formAndLetterId":this.selectedItem['_id'] }
        this.$store.dispatch("deleteformandLetter", post_data)
          .then(response => {
          
           this.approveConformpopUp = false;
            this.showToster({message:response.message,isError:false});
            this.getList();
            this.edit =false;


          }).catch((er)=>{
            this.showToster({message:er,isError:true});
          
        });
      },

    },
    mounted() {
      
      this.getPetitionTypes();
      
      
      this.getTenantList();
      this.petitionTypeId = parseInt(this.$route.params.petitiontypeid);
      this.petitionSubTypeId = parseInt(this.$route.params.petitionsubtypeid);
      this.selected_statusids = [];
      this.final_selected_statusids = [];
      this.seleted_states = [];
      this.final_selected_states = [];
 this.sortKeys = {
      'tenantName':1,
      'createdByName':1,
      "typeName":1,
      "subTypeName":1,
      "createdOn":-1,
      "updatedOn":1
     
    },
    
    this.sortKey = {"path":"createdOn" ,"order":-1};

    if(localStorage.getItem('petitionConfig_sort_key') && localStorage.getItem('petitionConfig_sort_value')  && localStorage.getItem('petitionConfig_sort_value') >=-1 ){
       this.sortKey = {};

      
      this.sortKeys[localStorage.getItem('petitionConfig_sort_key')] = this.sortKey[localStorage.getItem('petitionConfig_sort_key')];
      this.sortKey = {"path":localStorage.getItem('petitionConfig_sort_key') ,"order":parseInt(localStorage.getItem('petitionConfig_sort_value'))};
      //alert();
     
    }
    if(localStorage.getItem('formandLetter_perpage')){
        this.perpage = parseInt(localStorage.getItem('formandLetter_perpage'));
    }
     
      //this.get_statusids();
      this.getList();
     

    }
  };
</script>
