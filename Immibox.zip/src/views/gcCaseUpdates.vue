<template>
<div class="main-list-wrap  ">
    <div class="case-approved-detailes gc-affter-dot" v-if="tabStep>10" >
        <h2 class="case-heading">PERM Certification</h2>
        <div class="case-approved-body">
           <div class="left ">
              <ul >
                 <li class="success">Approved</li>
                 <li>
                    <p>Updated Date <span> Aug 16,2022 05:14pm</span></p>
                 </li>
                 <li>
                    <p>Receipt <span> 11111</span></p>
                 </li>
              </ul>
           </div>
           <div class="right">
              <ul >
                 <li><a href="#" @click="downloadfile(petition.rfeNotice.documents[0])"> View Details</a></li>
                 <li @click="downloadfile(petition.rfeNotice.documents[0])">
                    <figure class="view-detailes_cnt"><img src="@/assets/images/download-white.svg"></figure>
                 </li>
              </ul>
           </div>
        </div>
        <div class="case-approved-body">
            <div class="left">
               <ul >
                  <li v-if="tabStep<=9" class="success">Submited</li>
                  <li v-if="tabStep>9" class="success">Certified</li>
                  <li>
                     <p>Updated Date <span> Aug 16,2022 05:14pm</span></p>
                  </li>
                  <li>
                     <p>Receipt <span> 11111</span></p>
                  </li>
               </ul>
            </div>
            <div class="right">
               <ul >
                  <li><a href="#" @click="downloadfile(petition.rfeNotice.documents[0])"> View Details</a></li>
                  <li @click="downloadfile(petition.rfeNotice.documents[0])">
                     <figure class="view-detailes_cnt"><img src="@/assets/images/download-white.svg"></figure>
                  </li>
               </ul>
            </div>
         </div>
     </div>
    <div class="case-approved-detailes gc-affter-dot" v-if="tabStep !=11" >
        <h2 class="case-heading">PERM Certification</h2>
        <div class="case-approved-body">
           <div class="left">
              <ul >
                 <li class="success">Submited</li>
                 <li>
                    <p>Updated Date <span> Aug 16,2022 05:14pm</span></p>
                 </li>
                 <li>
                    <p>Receipt <span> 11111</span></p>
                 </li>
              </ul>
           </div>
           <div class="right">
              <ul >
                 <li><a href="#" @click="downloadfile(petition.rfeNotice.documents[0])"> View Details</a></li>
                 <li @click="downloadfile(petition.rfeNotice.documents[0])">
                    <figure class="view-detailes_cnt"><img src="@/assets/images/download-white.svg"></figure>
                 </li>
              </ul>
           </div>
        </div>
     </div>
    <div class="case-approved-detailes gc-affter-dot"   >
      <h2 class="case-heading">Prevailing Wage Determination</h2>
      <div class="case-approved-body">
         <div class="left">
            <ul >
               <li v-if="tabStep<=9" class="success">Submited</li>
               <li v-if="tabStep>9" class="success">Certified</li>
               <li>
                  <p>Updated Date <span> Aug 16,2022 05:14pm</span></p>
               </li>
               <li>
                  <p>Receipt <span> 11111</span></p>
               </li>
            </ul>
         </div>
         <div class="right">
            <ul >
               <li><a href="#" @click="downloadfile(petition.rfeNotice.documents[0])"> View Details</a></li>
               <li @click="downloadfile(petition.rfeNotice.documents[0])">
                  <figure class="view-detailes_cnt"><img src="@/assets/images/download-white.svg"></figure>
               </li>
            </ul>
         </div>
      </div>
   </div>
  
 </div>

</template>
<script>
export default {
    data: () => ({
        tabStep:0
    }),
    mounted(){
        if(this.$route.query && this.$route.query.tabStep){
        this.tabStep =parseInt(this.$route['query']['tabStep']);
    }

    }
    
}

</script>  