<template>
<form  class="invitewraper">
          <div class="form-container">
            <div class="text-danger text-sm formerrors" v-show="formerrors.msg">

                <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal" icon="IP-information-button" active="true">
                {{ formerrors.msg }}
                </vs-alert>

            </div>
            <div class="vx-row" @keyup="formerrors.msg=''"> 
          
                <div class="login-inputs " style="width:100% !important">
                    <div class="errormsg-support">
                        <vs-input type="text"  label-placeholder="Full legal name of Petitioner " class="w-full no-icon-border" name="name" data-vv-as="Company name" v-model="petetioner.name" v-validate="'required'" />
                        <span class="error-text"  v-show="errors.has('name')">{{ errors.first("name") }}</span>
                    </div>
                </div>
           </div>
            <div class="vx-row"  @keyup="formerrors.msg=''">

               


                <div class="login-inputs " style="width:100% !important">
                    <div class="errormsg-support">
                        <vs-input type="text"  label-placeholder="Email"  class="w-full no-icon-border" name="email" data-vv-as="Email" v-model="petetioner.email" v-validate="'required|email'" />
                        <span class="error-text"  v-show="errors.has('email')">{{ errors.first("email") }}</span>
                    </div>
                </div>

            </div>
          </div>
          <div class="popup-footer">
            <vs-button color="success" @click="submitForm" class="save" type="filled">Submit</vs-button>
          </div>
        </form>
</template>

<script>
export default {
    data() {
        return {
            petetioner: {
                name: "",
                email: "",
                
            },
           
            popupActive: false,
            petitionersignup: [],
            formerrors: {
                msg: ""
            }
        };
    },
    methods: {
        clearfields() {

            this.petetioner = {
                name: "",
                email: "",
               
            },
           
            this.formerrors= { msg: "" }

        },
        clearfields(){

        },
        submitForm() {
            this.formerrors = { msg: ""};
            this.$validator.validateAll().then(result => {
                if (result) {
                    const obj = {
                        apiKey: "FV$HSE@JUGUUGU$J5L@HE",
                        tenantId: "5db7d79d6032453bd060ed9c",
                        name: this.petetioner.name,
                        email: this.petetioner.email,
                        roleId: 6
                    };

                    this.$store
                        .dispatch("petitioner/invite", obj)
                        .then(response => {
                            if (response.error) {
                                this.invitepetitioner = false;
                                
                                
                                Object.assign(this.formerrors, {
                                    msg: response.error.message
                                });
                            } else {
                                this.clearfields();
                                this.invitepetitioner = false;
                                let message ="Invitation has been sent!";

                            this.$vs.notify({
                                    title: "Success",
                                    position: "top-right",
                                    color: "primary",
                                    iconPack: "feather",
                                    icon: "icon-check",
                                    text: message
                                });
                                this.$emit('close_invitePopup');

                            }
                        })
                        .catch(() => {});

                    // if form have no errors
                } else {
                   // alert("sdfsdgfhsdg");
                    // form have errors
                }
            });
        }
    }
};
</script>

