<template>
  <div>
    <ul class="uploaded-list">
      <template v-for="(item, index) in filealUploadedFiles">
        <vs-chip @click="item.status=false;remove(index)"  :key="index" closable>
            <img src="@/assets/images/main/down-arrow2.svg" @click="downloads3file(item)" />
            {{ item.name }} --- {{ item.resourceId  }}
        </vs-chip>
      </template>
     </ul>

   <h2>Bred Crumbs</h2>
    <ul class="bredcumbs"  >
      <li class="cursor" v-for="( item ,index) in dropBoxBredCrumbs"
       @click="getDropBoxFiles(item['path'])"
       :class="{'current':index== (dropBoxBredCrumbs.length)-1}"
      >
      <span v-if="index>0">/</span>
      <p>{{ item['name'] }} </p>
    </li>
    </ul>

<h2 v-if="selectedDropBoxFiles.length>0" @click="downloadFromDropBoxFileUploadTos3()">Upload -{{ selectedDropBoxFiles.length }}</h2>
    -------------------------------------------
    <ul>
      <li v-for="(entry ,index) in dropBoxentries" :key="entry.path_display" >
           <p class="cursor" @click="getDropBoxFiles(entry.path_lower)">
              {{ entry.path_display }}
              <br></br>
              <small>PATH: {{ entry.path_lower }}</small>
           </p>
           <p class="cursor" v-if="entry['.tag']=='file'" >
            <vs-checkbox  @input="selectDropBoxFileForUpload(entry)"  :name="'dropBoxItem'+index"  v-model="entry['selectedForUpload']" class="">{{ entry['selectedForUpload'] }}</vs-checkbox>
           
          </p>
           
      </li>
    </ul>
   
  </div>
</template>

<script>
//import Dropbox from 'dropbox';
var Dropbox = require('dropbox').Dropbox;

export default {
  data() {
    return {
      dropBoxBredCrumbs:[],
      selectedDropBoxFiles:[],
      filealUploadedFiles:[],
      dropBoxentries: [],
      dropBoxAccessToken: 'sl.Bfck_YKIXN-KX4TAmPmgwg764VSc_dKwwkhB-79aj2lwSz7aXYiSYG4Lnnmn1gAHlUc_ioVgED2VwpP-5SSkaQiO_qfhbgkAYlsdXP8qh7-FUBvZcnfW-gJdpZtWqA48fn8sJZKUj3sA'
    };
  },
  mounted() {
    var ACCESS_TOKEN = this.dropBoxAccessToken;
     this.dbx = new Dropbox({
      accessToken: ACCESS_TOKEN//'sl.BfYWd7iOuXDL0Dna3lMNskjuLBq3t5oPZE3LSv57OkeaRkeAIelZ7KOvwD_OvripemPkDTfqgHBArn0MGCLOxwVXI-u8nUJ9tUpBROJHXp_p0o385kD22CYH2im2XFmXvkHNFuSawDl6'
    });

    this.getDropBoxFiles()
   
  },
  methods: {
    generateAccessKey(){
      // Dropbox SDK setup
      const DROPBOX_APP_KEY = '3zk6iirnpzs5csc';
      let dbx = new Dropbox({ clientId: DROPBOX_APP_KEY });
      
      // // Authenticate with Dropbox
      dbx.auth.oauth2TokenAuth()
        .then(response => {
          this.dropBoxAccessToken = response.accessToken;
          var ACCESS_TOKEN = this.dropBoxAccessToken;
          this.dbx = new Dropbox({
              accessToken: ACCESS_TOKEN//'sl.BfYWd7iOuXDL0Dna3lMNskjuLBq3t5oPZE3LSv57OkeaRkeAIelZ7KOvwD_OvripemPkDTfqgHBArn0MGCLOxwVXI-u8nUJ9tUpBROJHXp_p0o385kD22CYH2im2XFmXvkHNFuSawDl6'
            });
          
        })
        .catch(error => {
          console.error('Error authenticating with Dropbox:', error);
        });
    },
    selectDropBoxFileForUpload(item){
      
      let self = this;
      item['fileObject'] =null;
      let isExists = _.find(this.selectedDropBoxFiles ,{"id":item['id']})
      setTimeout(()=>{
       if(item['selectedForUpload']){
          if(!isExists){
            
            
            this.selectedDropBoxFiles.push(_.cloneDeep(item));
          }
        
       }else{
        self.selectedDropBoxFiles = _.filter(self.selectedDropBoxFiles ,(fl)=>{
            return fl['id'] !=item['id']
        }) ;

       }
      },10);
      
    },
    getDropBoxFiles(path=''){
      let self =this;
      this.dropBoxBredCrumbs =[];
      let PathData = {"path":'/' ,"name":'/'};
      this.dropBoxBredCrumbs.push(PathData)
      if(path){
        let lst = path.split("/");
        _.forEach(lst ,( item ,index)=>{
            if(index==0){
              
            }else{
              let tpath =''
              _.forEach(lst ,(p ,pind)=>{
                
                if(pind<index){
                  alert(JSON.stringify(p))
                  tpath =  tpath+p['path']
                }
              })
              let PathData = {"path":tpath+"/" ,"name":item};
               this.dropBoxBredCrumbs.push(PathData)
            }
        });
        
      }
    
    
      let tmpPath=path
      if (path=='/'){
        tmpPath ='';
      }
        
        this.dbx.filesListFolder({ path: tmpPath })
      .then(response => {
        let list =response['result']['entries'];
        let tempList = [];
        _.forEach(list ,(item)=>{
          item =  Object.assign( item ,{ "selectedForUpload":false ,"uploadingToS3":false,"downLoadingFromSource":false,fileObject:null ,"resourceType":'dropBox' ,"s3Data":null})
          if(item['id']){
            let alreadySelected = _.find(self.selectedDropBoxFiles ,{"id":item['id'] });
            if(alreadySelected){
              item['selectedForUpload'] =true;
            }
          }
           tempList.push(item);
        });
        this.dropBoxentries = tempList
      })
      .catch(error => {
        //aler(JSON.stringify(error));
        console.error(error);
      });

    },
    downloadFromDropBoxFile(dropBoxItem) {
      dropBoxItem['fileObject'] =null;
      dropBoxItem['uploadingToS3'] = false;
      dropBoxItem['downLoadingFromSource'] =true;
        let self = this;
        this.dbx.filesDownload({ path: dropBoxItem['path_lower']})
        .then((response)=>{
       
         let  result = response['result'];
          const fileData = result.fileBlob;
          const contentType = response.headers.get('Content-Type');
         // const file = new File([fileData], 'file.wmv', { type: fileData.type });
          const file = new File([fileData], dropBoxItem['name'], { type: contentType });
          
          dropBoxItem['fileObject'] =file;
          dropBoxItem['downLoadingFromSource'] =false;
          dropBoxItem['selectedForUpload']=true;
          
          let formData = new FormData();
          formData.append("files", file);
          formData.append("secureType", "public");
          formData.append("getDetails", true);
       
          this.$store.dispatch("uploadS3File", formData).then((s3Response) => {
            s3Response.data.result.forEach((urlGenerated) => {
            urlGenerated['status'] =true; 
            urlGenerated['name'] =dropBoxItem['name'];
            urlGenerated['uploadedBy'] =self.checkProperty(self.getUserData,'userId');
            urlGenerated['uploadedByRoleId'] =self.getUserRoleId
            urlGenerated['uploadedByRoleName'] =self.checkProperty(self.getUserData,'loginRoleName');
            self.filealUploadedFiles.push(urlGenerated);
            dropBoxItem['selectedForUpload'] = true;
            dropBoxItem['uploadingToS3'] = false;
            
            //self.$emit("input" ,urlGenerated)
            
            setTimeout(()=>{
                //self.uploading = false;
              //  self.$modal.hide('cropImageModal');
                
            },10);
        })

          })
        })
        .catch(function (error) {
        console.error(error);
    });
    return false;
    },
    async downloadFromDropBoxFileUploadTos3(){
      let _self = this;
      let downLoadedCount =-1;
      _.forEach(_self.selectedDropBoxFiles, (sitem, index)=>{
        let item = sitem;
         item['fileObject'] =null;
         item['downLoadingFromSource'] = true;
         item['uploadingToS3'] = false;
         item['resourceId'] = item['id'];
        
         
        
         _self.dbx.filesDownload({ path: item['path_lower']})
        .then((response)=>{
          
          let  result = response['result'];
          let fileData = result.fileBlob;
          let contentType = response.headers.get('Content-Type');
         // const file = new File([fileData], 'file.wmv', { type: fileData.type });
         item['fileObject'] = new File([fileData], item['name'], { type: contentType });
         item['downLoadingFromSource'] = false;
        
          
            let formData = new FormData();
            formData.append("files", item['fileObject']);
            formData.append("secureType", "public");
            formData.append("getDetails", true); 
            this.$store.dispatch("uploadS3File", formData).then((s3Response) => {
             
              s3Response.data.result.forEach((urlGenerated) => {
              urlGenerated['status'] =true; 
              urlGenerated['name'] =item['name'];
              urlGenerated['uploadedBy'] =_self.checkProperty(_self.getUserData,'userId');
              urlGenerated['uploadedByRoleId'] =_self.getUserRoleId
              urlGenerated['uploadedByRoleName'] =_self.checkProperty(_self.getUserData,'loginRoleName');
              urlGenerated['resourceId'] = item['id'];
              
              //item['uploadingToS3'] = false;
             // item['selectedForUpload'] = true;
             _self.filealUploadedFiles.push(urlGenerated);
              downLoadedCount =downLoadedCount+1
             
             
              })
             
            })

         

         

         
         
         
         

        }).catch((err)=>{
          downLoadedCount = downLoadedCount+1

        });
          
         

      })

      //bulk files uploadTo s3;
     

    }
    
   
  }
};
</script>
