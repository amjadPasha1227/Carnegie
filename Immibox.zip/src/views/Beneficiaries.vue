<template>
  <div>
    <div class="content-header case-search-header">
      <div class="content-header-left">
        <div class="search">
          <vs-input icon-pack="feather" icon="icon-search" v-model.lazy="searchtxt" placeholder="Search by Name/Email/Phone"
            class="is-label-placeholder" />
        </div>
        <div class="con-select selection_search" v-if="getTenantTypeId!=2 && [1,2,50,51].indexOf(loginRoleId)<=-1">
          <multiselect v-model="selectedPetitionerforFilter" :options="petitionersList" :multiple="true"
            :hideSelected="false" :close-on-select="false" :clear-on-select="false" :preserve-search="true"
            :select-label="'Select Petitioner'" placeholder="Select Petitioner" label="name" track-by="name"
            :preselect-first="false" :searchable="true" @input="set_filter()" @search-change="peritioners_search_fun" >
            <template slot="selection" slot-scope="{ values, isOpen }">
              <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }} Petitioner(s)
                selected</span>
              <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
            </template>
          </multiselect>
        </div>
      </div>
      <!-- getTenantTypeId!=2 && -->

      <div class="content-header-right">
        <!--filter dropdown-->
        <vs-dropdown vs-custom-content vs-trigger-click>
          <vs-button color="primary" class="filter-btn" type="border" icon-pack="feather" icon="icon-chevron-down"
            icon-after>
            <img src="@/assets/images/main/icon-filter.svg" /> Filters
          </vs-button>
          <vs-dropdown-menu ref="filter_menu" class="filters-content">

            <div class="filters-form-fileds">
              <div class="form-container">
                <div class="vx-row">
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Status</label>
                    <multiselect v-model="selected_statusids" :options="all_statusids" :multiple="true"
                      :hideSelected="true" :close-on-select="true" :clear-on-select="false" :preserve-search="true"
                      :select-label="''" placeholder="Select Status" label="name" track-by="name"
                      :preselect-first="false">
                      <!-- <template slot="selection" slot-scope="{ values, search, isOpen }">
                        <span
                          class="multiselect__single"
                          v-if="values.length &amp;&amp; !isOpen"
                        >{{ values.length }} options selected</span>
                      </template> -->
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          options selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>


                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Case Type </label>
                    <multiselect @input="changedVsaType" v-model="filteredVisaType" :options="visatypes"
                      :multiple="false" :close-on-select="true" :clear-on-select="false" :preserve-search="true"
                      placeholder="Select Case Type" label="name" track-by="name" :preselect-first="false">
                      <template slot="selection" slot-scope="{ values,  isOpen }"><span class="multiselect__single"
                          v-if="values.length &amp;&amp; !isOpen">{{ values.length }} Case Type
                          selected</span></template>
                    </multiselect>
                  </div>

                  <div class="vx-col md:w-1/3 w-full con-select" >
                    <label class="typo__label">Case Subtype</label>
                    <!--                  <multiselect  v-model="filteredVisaSubTypes" :options="allsubTyps"  :multiple="true" :hideSelected="true"
                    :close-on-select="false" :clear-on-select="false" :preserve-search="true" placeholder="Select Visa Sub Types" label="name" track-by="name" :preselect-first="false">
                    <template slot="selection" slot-scope="{ values,  isOpen }"><span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">{{ values.length }} Visa Sub Type selected</span></template>
                  </multiselect>
                  -->

                    <multiselect v-model="filteredVisaSubTypes" :options="allsubTyps" :multiple="true"
                      :hideSelected="true" :close-on-select="false" :clear-on-select="false" :preserve-search="true"
                      :select-label="''" placeholder="Select Case Subtypes" label="name" track-by="name"
                      :preselect-first="false">

                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          options selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>



                  <!--
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Country</label>
                    <multiselect  @input="changedCountry()" v-model="selected_country_obj" :options="all_countries"  :multiple="false"
                     :close-on-select="true" :clear-on-select="false" :preserve-search="true" placeholder="Select Country" label="name" track-by="name" :preselect-first="false">
                      <template slot="selection" slot-scope="{ values,  isOpen }"><span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">{{ values.length }} options selected</span></template>
                    </multiselect>
                  </div>

                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">States</label>
                    <multiselect 
                      @input="changedState()"
                      v-model="seleted_states"
                      :options="all_states"
                      :multiple="false"
                      :close-on-select="true"
                      :select-label="''"
                      :clear-on-select="true"
                      :preserve-search="true"
                      placeholder="Select States"
                      label="name"
                      track-by="name"
                      :preselect-first="false"
                    >
                     
                      <template slot="selection" slot-scope="{ values, isOpen }">
                          <span
                          class="multiselect__selectcustom"
                          v-if="values.length && !isOpen"
                          >{{ values.length }} States selected</span
                          >
                          <span
                          class="multiselect__selectcustom"
                          v-if="values.length && isOpen"
                          ></span>
                        </template>
                    </multiselect>
                  </div>
                  
                  <div class="vx-col md:w-1/3 w-full con-select">
                    

                    <label class="typo__label">Locations</label>
                    <multiselect
                      
                      v-model="seleted_locations"
                      :options="all_locations"
                      :multiple="true" :hideSelected="true"
                      :close-on-select="true"
                      :clear-on-select="false"
                      :preserve-search="true"
                       :select-label="''"
                      placeholder="Select Locations"
                      label="name"
                      track-by="name"
                      :preselect-first="false"
                    >
                      
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} Locations selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template>
                    </multiselect>
                  </div>
                  -->
                  <div class="vx-col md:w-1/3 w-full con-select"
                    v-if="getTenantTypeId!=2 && [1,2,50,51].indexOf(loginRoleId)<=-1">
                    <label class="typo__label">Select Petitioner</label>
                    <multiselect v-model="selectedPetitionerforFilter" :options="petitionersList" :multiple="true"
                      :hideSelected="false" :close-on-select="false" :clear-on-select="false" :preserve-search="true"
                      :select-label="'Search Petitioner'" placeholder="Select Petitioner" label="name" track-by="name"
                      :preselect-first="false" :searchable="true">

                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          Petitioner(s) selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label"> Petition Created Date</label>
                    <date-range-picker :autoApply="autoApply" :ranges="false" :maxDate="new Date()"
                      v-model="selected_createdDateRange"></date-range-picker>
                  </div>
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Created Date</label>
                    <date-range-picker :autoApply="autoApply" :ranges="false" :maxDate="new Date()"
                      v-model="selected_normcreatedDateRange"></date-range-picker>
                  </div>
                </div>
              </div>
            </div>
            <div class="filters-status">
              <div class="left-buttons">

              </div>
              <div class="right-buttons">
                <vs-button color="success" class="save" type="filled" v-on:click="set_filter()">Apply</vs-button>
                <vs-button color="dark" class="cancel" type="filled" v-on:click="clear_filter($event)">Clear</vs-button>
              </div>
            </div>
          </vs-dropdown-menu>
        </vs-dropdown>
        <!-- end -->
        <vs-button color="primary" type="border" class="light-blue-btn" @click="addNewBeneficiary();selectedIten=null;selectedPetitioner =null;inviteBeneficiary=false;editMode =false"
          v-if="checkBeneficaryInvitePermisions">Add Beneficiary <span>
            <img class="add-user-icon ml-2" src="@/assets/images/main/add-user.svg">
          </span></vs-button>
      </div>
    </div>

    <NoDataFound ref="NoDataFoundRef" :loading="isListloading" v-if="users.length == 0"
      :content="callFromSerch?'No Results Found':'You haven\'t created any Beneficiaries. Create the Beneficiaries to start using the ImmiBox'"
      heading="No Beneficiaries Found" type='Beneficiaries' />
    <div class="accordian-table accordian-overley" v-if="users.length>0">
      <vs-table :data="users" :no-data-text="'No data found...!'">
        <template slot="thead">
          <!--  
        
        "createdOn", // invitedByName, updatedOn, name, email, phone, statusName, roleName--->
          <vs-th><a @click="sortMe('name')" v-bind:class="{
            sort_ascending: sortKeys['name'] == 1,
            sort_descending: sortKeys['name'] != 1,
          }">Name</a>
        </vs-th>
          
          <vs-th v-if="[1,2,50].indexOf(loginRoleId)<=-1 &&  checkProperty(loginUserData['tenantDetails']['typeDetails'],'id') != 2">
            Petitioner
          </vs-th>
          <vs-th><a @click="sortMe('email')" v-bind:class="{
            sort_ascending: sortKeys['email'] == 1,
            sort_descending: sortKeys['email'] != 1,
          }">Email</a></vs-th>
          <vs-th>Total Cases</vs-th>
          <vs-th>Active Cases</vs-th>
          <vs-th class="actions">Actions</vs-th>
        </template>
 
        <template slot-scope="{data}">

          <vs-tr :data="tr" :key="indextr" v-for="(tr, indextr) in data" class="cursor-pointer">
            <vs-td :data="tr.username" >
              <img class="user-image" src="@/assets/images/main/avatar2.svg" />
              <!-- <a href="">{{tr.name}}</a> -->
              <div class="td_label">
              {{tr.name}}<br />
              <small v-if=" checkProperty(tr, 'accountType') == 'Individual'">(Customer)</small>  
            </div>
            </vs-td>
            <vs-td v-if="[1,2,50].indexOf(loginRoleId)<=-1 && checkProperty(loginUserData['tenantDetails']['typeDetails'],'id')!=2">
              {{checkProperty(tr,'petitionerDetails','name')}}

            </vs-td>

            <vs-td :data="tr.email">
              <template v-if="!tr.isTempAccount">
                {{tr.email}}
              </template>
            </vs-td>

            <vs-td :data="tr.totalPetitionCount">
              <span class="count">{{tr.totalPetitionCount}}</span>
            </vs-td>

            <vs-td :data="tr.activePetitionCount">
              <span class="count">{{tr.activePetitionCount}}</span>
            </vs-td>
            <vs-td>

              <div class="menu_dropdown flexible_actions">
                <a class="a-icon" href.prevent>
                  <more-vertical-icon size="1.5x" class="custom-class"></more-vertical-icon>
                </a>
                <div class="menu_list_wrap">
                   <ul class="menu_list">
                    <li class="menu_item" v-if="tr.statusId !=3 && tr.statusId !=4"
                      @click="editMe(true,tr);formerrors.msg='';NewPetition=false;">
                      Edit
                    </li>
                    <li class="menu_item"
                      @click="editMode = false ;opneDetails(tr);formerrors.msg='';NewPetition=false;selectedUser=tr._id;selectedUseremail=tr.email;selectedUsername=tr.name">
                      Details
                    </li>
                    <li class="menu_item" v-if="checkCaseCreatePermisions && tr.statusId !=3 && tr.statusId !=4  && !tr.isTempAccount"
                      @click="editMode = false; openNewPetitionPopUp(true ,tr);formerrors.msg='';NewPetition=true;selectedUser=tr._id;selectedUseremail=tr.email;selectedUsername=tr.name;uploading=false;prefillJobDetailsError=''">
                      New Case
                    </li>
                    <li class="menu_item" v-if="[3,4,5,7].indexOf(loginRoleId)>-1 && tr.statusId !=3 && tr.statusId !=4 && !tr.isTempAccount"
                      @click="editMode = false;showSetPassword(true ,tr);formerrors.msg='';NewPetition=false">
                      Set Password
                    </li>
                    <li class="menu_item"
                      v-if="[3,4,5,7,50].indexOf(loginRoleId)>-1 && checkProperty(tr ,'statusDetails','id') <=1 && tr.statusId !=3 && tr.statusId !=4 && !tr.isTempAccount"
                      @click="editMode = false;resend(tr);formerrors.msg='';NewPetition=false">
                      Resend Activation Link
                    </li>
                    <li class="menu_item"
                      v-if="[3, 4, 5, 7].indexOf(loginRoleId) > -1 && !(checkProperty(tr,'accountType')) && !(checkProperty(tr,'tempUser'))  && tr.statusId !=3 && tr.statusId !=4 && !tr.isTempAccount"
                      @click="editMode = false;openMoveToIndiduals(true ,tr);formerrors.msg='';NewPetition=false">
                      Convert as Customer
                    </li>
                    <li class="menu_item"
                      v-if="[3, 4, 5, 7].indexOf(loginRoleId) > -1 && (checkProperty(tr,'tempUser')) && !(checkProperty(tr,'accountType')) && tr.statusId !=3 && tr.statusId !=4 && !tr.isTempAccount"
                      @click="editMode = false;openInviteToCreateAccount(true ,tr);formerrors.msg='';NewPetition=false;inviteEmail=''">
                      Invite to Create Account
                    </li>
                    <li class="menu_item"
                      v-if="[3].indexOf(loginRoleId) > -1 && tr.statusId==3 && tr.statusId !=2 && !tr.isTempAccount"
                      @click="editMode = false;conformDeleteBene(tr ,2);errorMsg='';NewPetition=false">
                      Active
                    </li>
                    <li class="menu_item"
                      v-if="[3].indexOf(loginRoleId) > -1 && tr.statusId==2 && tr.statusId !=3 && !tr.isTempAccount"
                      @click="editMode = false;conformDeleteBene(tr ,3);errorMsg='';NewPetition=false">
                      Inactive
                    </li>
                    <li class="menu_item"
                      v-if="[3].indexOf(loginRoleId) > -1 && tr.statusId !=4 && !tr.isTempAccount "
                      @click="editMode = false;conformDeleteBene(tr ,4);errorMsg='';NewPetition=false">
                      Delete 
                    </li>
                  </ul>
                </div> 
              </div>


            </vs-td>
            <template class="expand-user" slot="expand">
              <div class="con-expand-users">
                <div>
                  
                  <vs-table :data="tr.petitions" :no-data-text="'No Cases are filed'">
                    <template slot="thead">
                      <vs-th>Case No</vs-th>
                      <vs-th>Case Type</vs-th>
                      <vs-th>Client</vs-th>
                      <vs-th>Start Date</vs-th>
                      <vs-th>Status</vs-th>
                    </template>

                    <template>
                      <vs-tr :key="ind" v-for="(petition, ind) in tr.petitions">
                        <vs-td :data="petition.caseNo">
                          <span style="cursor:pointer" @click="gotoDetailsPage(petition['_id'] ,petition['subType'])">
                            {{petition.caseNo}}

                            <button v-if="(checkProperty(petition ,'subTypeDetails','id') ==15 && checkProperty(petition ,'statusDetails','id') < 9 ) || (checkProperty(petition ,'subTypeDetails','id') !=15 && checkProperty(petition ,'statusDetails','id') < 7 )" class="btn active-green">
                              <template v-if="checkProperty(petition ,'subTypeDetails','id') ==15">
                                <template v-if="checkProperty(petition ,'statusDetails','id') < 9">Active</template>
                              </template>
                              <template v-else>
                                <template v-if="checkProperty(petition ,'statusDetails','id') < 7">Active</template>
                              </template>

                             

                            </button>
                          </span>
                        </vs-td>

                        <vs-td class="td_label">{{ checkProperty(petition ,'typeDetails','name')}}
                          <small> {{ checkProperty(petition ,'subTypeDetails','name') }} </small>
                        </vs-td>

                        <vs-td>
                          <span v-if="checkProperty(petition ,'clientInfo' ,'name')">
                            {{petition.clientInfo.name}}
                          </span>
                        </vs-td>
                        <vs-td>{{petition.createdOn | formatDate}}</vs-td>

                        <vs-td>
                          <!----
                          <span class="status_active">{{checkProperty(petition ,'statusDetails','name')}}</span>
                        -->
                        <template v-if="checkProperty(petition ,'subTypeDetails','id') == 15">
                  <span class="statusspan "  v-bind:class="{
                  'status_created': checkProperty(petition ,'statusId') == 1,
                  'status_submited': checkProperty(petition ,'statusId') == 2,
                  'status_inProcess': checkProperty(petition ,'statusId') == 3,
                  'status_waiting': checkProperty(petition ,'statusId') == 4,
                  'status_ready_for_filing': checkProperty(petition ,'statusId') == 5,
                  'staus_advertisements': checkProperty(petition ,'statusDetails','id') == 6,
                  'staus_filed_with_USCIS': checkProperty(petition ,'statusId')  == 7,
                  'Perm_drft_approved': checkProperty(petition ,'statusId') == 8,
                  'status_sent_for_signatures': checkProperty(petition ,'statusId') == 9,
    
                  
                  'status_certified': checkProperty(petition ,'statusId') == 11 || checkProperty(petition ,'statusId') == '11',
                  'status_submited-USCIS': checkProperty(petition ,'statusId') == 12,
                  'response_to_RFE_Received': checkProperty(petition ,'statusId') == 13,
                  'status_jobdescription': checkProperty(petition ,'statusId') == 14,
                  'status_pwd_filed': checkProperty(petition ,'statusDetails','id') == 15,
                  'status_pwd_response': checkProperty(petition ,'statusDetails','id') == 16,
                  'staus_advertisements': checkProperty(petition ,'statusDetails','id') == 17,
                  'staus_filed_with_USCIS': checkProperty(petition ,'statusId')  == 18,
                  'Status_received_by_USCIS': checkProperty(petition ,'statusDetails','id') == 19,
                  'Perm_drft_approved': checkProperty(petition ,'statusDetails','id') == 20,
                  'Perm_submited_dol': checkProperty(petition ,'statusDetails','id') == 21,
                  'status_approved': checkProperty(petition ,'statusDetails','id') == 22,
                  'status_denied': checkProperty(petition ,'statusDetails','id') == 23,
                  'RFE_Received': checkProperty(petition ,'statusDetails','id') == 24,
                  'status_supervisory_audit': checkProperty(petition ,'statusDetails','id') == 27,
                  'notice_supervisory_audit': checkProperty(petition ,'statusDetails','id') == 28,
                  'status_withdrawn': checkProperty(petition ,'statusDetails','id') == 31,
                  
                }">{{ checkProperty(petition ,'statusDetails','name') }}</span>
                        </template>   
                      <template v-else>
                        <span
                                  class="statusspan"
                                  v-bind:class="{
                                  'status_created': checkProperty(petition ,'statusId') == 1,
                                  'status_submited': checkProperty(petition ,'statusId')  == 2,
                                  'status_inProcess': checkProperty(petition ,'statusId')  == 3,
                                  'status_waiting': checkProperty(petition ,'statusId')  == 4,
                                  'status_ready_for_filing': checkProperty(petition ,'statusId')  == 5,
                                  'staus_filed_with_USCIS': checkProperty(petition ,'statusId')  == 7,
                                  'Status_received_by_USCIS': checkProperty(petition ,'statusDetails','id') == 8,
                                  'status_sent_for_signatures': checkProperty(petition ,'statusId')  == 9,
                                  'RFE_Received': ['11',11].indexOf(checkProperty(petition ,'statusId') ) >-1,
                                  'status_submited-USCIS': checkProperty(petition ,'statusId')  == 12,
                                  'response_to_RFE_Received':checkProperty(petition ,'statusId')  == 13,
                                  'status_jobdescription': checkProperty(petition ,'statusId')  == 14,
                                  'status_pwd_filed': checkProperty(petition ,'statusDetails','id') == 15,
                                  'status_pwd_response': checkProperty(petition ,'statusDetails','id') == 16,
                                  'staus_advertisements': checkProperty(petition ,'statusDetails','id') == 17,
                                  'staus_filed_with_USCIS': checkProperty(petition ,'statusId')  == 18,
                                  'Perm_drft_approved': checkProperty(petition ,'statusDetails','id') == 20,
                                  'Perm_submited_dol': checkProperty(petition ,'statusDetails','id') == 21,
                                  'status_approved': checkProperty(petition ,'statusDetails','id') == 22,
                                  'status_denied': checkProperty(petition ,'statusDetails','id') == 23,
                                  'RFE_Received': checkProperty(petition ,'statusDetails','id') == 24,
                                  'status_withdrawn': checkProperty(petition ,'statusDetails','id') == 31,
                                  'status_supervisory_audit': checkProperty(petition ,'statusDetails','id') == 27,
                                  'notice_supervisory_audit': checkProperty(petition ,'statusDetails','id') == 28,
                                  ' ': checkProperty(petition ,'statusId')  == 15
                                }"
                                >{{checkProperty(petition,'statusDetails','name')}}</span>
                      </template>


                        </vs-td>
                      </vs-tr>
                    </template>
                  </vs-table>
                </div>
              </div>
            </template>
          </vs-tr>
        </template>
      </vs-table>
      <div class="table_footer">
        <div class="vx-col  con-select pages_select" v-if="users.length > 0">
          <label class="typo__label">Per Page</label>
          <multiselect @input="changeperPage()" v-model="perpage" :options="perPeges" :multiple="false"
              :close-on-select="true" :clear-on-select="false" :preserve-search="true" placeholder="Per Page"
              :preselect-first="true">
            </multiselect>
            <span class="totla_list_count" v-if="totalCount"> Total <em>{{totalCount}}</em></span>
          </div>
      <paginate v-if="users.length>0" v-model="page" :page-count="totalpages" :page-range="3" :margin-pages="2"
        :click-handler="pageNate" prev-class="vs-pagination--buttons btn-prev-pagination vs-pagination--button-prev"
        next-class="vs-pagination--buttons btn-next-pagination vs-pagination--button-next" :prev-text="'<i></i>'"
        :next-text="'<i></i>'" :container-class="'pagination vs-pagination--nav'" :page-class="'page-item'">
      </paginate>
    </div>
    </div>




<!--   
    <vs-popup class="holamundo main-popup" :class="{'openedNewpetpopup':invitepetitioner || AddBeneficiary}"
      title="New Case" :active.sync="NewPetition" v-if="false">
      <form data-vv-scope="newpetitionform">
        <div class="form-container">
          <div class="vx-row" @keyup="formerrors.msg=''" @click="formerrors.msg=''">

            <template v-if="([3,4].indexOf(loginRoleId)>-1 && getTenantTypeId !=2 ) && false">
              <div class="vx-col w-1/2">
                <div class="form_group">
                  <div class="con-select w-full select-large">
                    <label class="form_label">Select Petitioner<em>*</em></label>
                    <multiselect v-model="selectedPetitioner" :options="petitionersList" :multiple="false"
                      :hideSelected="false" :close-on-select="true" :clear-on-select="false" :preserve-search="true"
                      :select-label="'Search Petitioner'" placeholder="Select Petitioner" label="name" track-by="name"
                      :preselect-first="false" data-vv-as="Petitioner" v-validate="'required'"
                      tag-placeholder="Invite Petitioner" :taggable="false" @tag="addNewPet" :searchable="true"
                      @search-change="searchPet" @input="petitionerUpdated" name="Petitioner">

                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          options selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>
                  <span class="text-danger text-sm" v-show="errors.has('newpetitionform.Petitioner')">{{
                  errors.first("newpetitionform.Petitioner") }}</span>
                </div>
                <p v-if="checkPetInvitePermisions" class="createnew">Not found Petitioner?<span
                    @click="addNewPet()">Invite Petitioner</span> </p>
              </div>

              <div class="vx-col w-1/2">
                <div class="form_group">
                  <div class="con-select w-full select-large">
                    <label class="form_label">Select Beneficiary<em>*</em></label>
                    <multiselect v-model="selectedBeneficiary" :options="beneficiaryMasterDataList" :multiple="false"
                      :hideSelected="false" :close-on-select="true" :clear-on-select="false" :preserve-search="true"
                      :select-label="'Search Beneficiary'" placeholder="Select Beneficiary" label="name" track-by="name"
                      :preselect-first="false" data-vv-as="Beneficiary" v-validate="'required'" :searchable="true"
                      @search-change="getbeneficiaryMasterDataList" name="beneficiary" @input="upDateBenef"
                      tag-placeholder="Add New Beneficiary" :taggable="false" @tag="addNewBenFromTag"
                      :disabled="!checkProperty(selectedPetitioner ,'_id')">

                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          options selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>

                  <span class="text-danger text-sm" v-show="errors.has('newpetitionform.beneficiary')">{{
                  errors.first("newpetitionform.beneficiary") }}</span>

                </div>
                <p class="createnew" v-if="checkBeneficaryInvitePermisions">Not found?<span
                    @click="addNewBenFromTag()">Invite Beneficiary</span> </p>
              </div>
            </template>
            <template>
              <div class="vx-col w-1/2">
                <div class="form_group">
                  <div class="con-select w-full select-large">
                    <label for="" class="form_label">Case Type<em>*</em></label>
                    <multiselect name="visatype" data-vv-as="Case Type" v-validate="'required'" v-model="visatype"
                      :show-labels="false" track-by="id" label="name" placeholder="Select Case Type"
                      :options="activeVisatypes" :searchable="true" :allow-empty="false" @input="getvisasubtypes">
                    </multiselect>
                  </div>
                  <span class="text-danger text-sm" v-show="errors.has('newpetitionform.visatype')">{{
                  errors.first("newpetitionform.visatype") }}</span>
                </div>
              </div>

              <div class="vx-col w-1/2">
                <div class="form_group">
                  <div class="con-select w-full select-large">
                    <label for="" class="form_label">Case Subtype<em>*</em></label>
                    <multiselect name="visasubtype" data-vv-as="Case Subtype" v-validate="'required'"
                      v-model="visasubtype" :show-labels="false" track-by="id" label="name"
                      placeholder="Select Case Subtype" :options="visasubtypes" :searchable="true" :allow-empty="false"
                      @input="checkBenPermStatus">
                    </multiselect>
                  </div>
                  <span class="text-danger text-sm" v-show="errors.has('newpetitionform.visasubtype')">{{
                  errors.first("newpetitionform.visasubtype") }}</span>
                </div>
              </div>

              <div class="vx-col w-full pp-col">
                <vs-checkbox id="premium" name="premiumProcessing" v-model="premiumProcessing">Premium Processing
                </vs-checkbox>

               <span class="text-danger text-sm"  v-show="errors.has('finalDeterminationFromDOL')">{{ errors.first("finalDeterminationFromDOL") }}</span>

              </div>
              <div class="vx-col  w-full" v-if="getTenantTypeId !=2">
                <div class="form_group">
                  <div class="con-select w-full select-large">
                    <label for="" class="form_label">Branch<em>*</em></label>
                    <multiselect name="branch" v-validate="'required'" v-model="selectedBranch" :show-labels="false"
                      track-by="_id" label="name" placeholder="Select branch" :options="branchList" :searchable="true"
                      :allow-empty="false" :multiple="false" :disabled="branchList.length==1"
                      @input="formerrors.msg=''">
                    </multiselect>
                  </div>
                  <span class="text-danger text-sm" v-show="errors.has('newpetitionform.branch')">{{
                  errors.first("newpetitionform.branch") }}</span>
                </div>
              </div>
              <template v-if="permDocRequired">
                <div class="vx-col w-full padb20" @click="value = []">
                <div class="form_group file_group">
                  <div class="vs-component marb20">
                   <label class="form_label">PERM Documents<em>*</em></label>
                   <div class="relative">
                    <file-upload
                      v-model="value"
                      class="file-upload-input upload_file justify-center"
                      accept="image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                      :name="'permDocuments'"
                      :multiple="true"
                      :hideSelected="true"
                      @input="upload(value, 'permDocuments')"
                    >
                      <img
                        class="file-icon"
                        src="@/assets/images/main/file-upload.svg"
                      />
                      Upload 
                    </file-upload>
                    <span v-if="uploading" class="loader"
                      ><img src="@/assets/images/main/loader.gif"
                    /></span>
                    </div>
                   
                    <input type="hidden" v-model="newTask.documents"  data-vv-as="Documents"  v-validate="'required'" name="tdocs">
                    <span  class="text-danger text-sm" v-show="errors.has('tdocs')"   >{{ errors.first('tdocs') }}</span >
                   
                    <input type="hidden" v-model="permDolDocs"    v-validate="'required'" name="tdocs"></input>
                    <span class="text-danger text-sm" v-show="errors.has('newpetitionform.tdocs')">
                    <em>* </em>PERM Documents are required</span>
                  </div>


                  <ul class="uploaded-list note_uploads">
                    <template v-for="(item, index) in permDolDocs">
                      <vs-chip
                      @click="remove(item, permDolDocs, index)"
                        :key="index"
                        closable
                      >
                      {{ item.name }}
                      </vs-chip>
                    </template>
                  </ul>
                </div>
                </div>
              </template>
              <div class="vx-col " v-if="checkProperty(visatype,'id')==3 && checkProperty(visasubtype,'id')==16 " :class="{'w-full':getTenantTypeId ==2 ,'w-1/2':!( getTenantTypeId ==2)}">
                <div class="form_group">
                  <div class="con-select w-full select-large">
                    <label for="" class="form_label">Classification<em>*</em></label>
                    <multiselect name="classification" data-vv-as="Classification" v-validate="'required'" v-model="classification"
                      :show-labels="false"   placeholder="Classification" 
                      :options="classificationList" :searchable="true" :allow-empty="false" >
                    </multiselect>
                  </div>
                  <span class="text-danger text-sm" v-show="errors.has('newpetitionform.classification')">{{
                    errors.first("newpetitionform.classification") }}</span>
                </div>
              </div>
            </template>


          </div>


          <div class="text-danger text-sm formerrors" v-show="formerrors.msg">
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
              icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
          </div>
        </div>

        <div class="popup-footer">
          <vs-button color="dark" @click="NewPetition=false ;formerrors.msg=''" class="cancel" type="filled">Cancel
          </vs-button>
          <vs-button color="success" :disabled="!selectedBranch || !enableSubmitBtn || newPetitionFormSubmited " @click="createNewPetition(false)"
            class="save" type="filled">Submit</vs-button>
        </div>
      </form>



    </vs-popup> -->
    
    <modal
        name="benCaseCreationModal"
        classes="v-modal-sec"
        :min-width="200"
        :min-height="200"
        :scrollable="true"
        :reset="true"
        width="750px"
        height="auto"
        >
        <div class="v-modal">
        <div class="popup-header fromDetailsPage"> 
        <h2 class="popup-title">
          New Case

        </h2>
        <span @click="$modal.hide('benCaseCreationModal');usciscUpdateStatusError='';NewPetition=false;prefillJobDetailsError=''">
          <em class="material-icons">close</em>
        </span>
        </div>
        <form @submit.prevent data-vv-scope="newpetitionform" >
        <div class="form-container errorScroll">
          <div class="vx-row" @keyup="formerrors.msg=''" @click="formerrors.msg=''">

            <template v-if="([3,4].indexOf(loginRoleId)>-1 && getTenantTypeId !=2 ) && false">
              <div class="vx-col w-1/2">
                <div class="form_group">
                  <div class="con-select w-full select-large">
                    <label class="form_label">Select Petitioner<em>*</em></label>
                    <multiselect v-model="selectedPetitioner" :options="petitionersList" :multiple="false"
                      :hideSelected="false" :close-on-select="true" :clear-on-select="false" :preserve-search="true"
                      :select-label="'Search Petitioner'" placeholder="Select Petitioner" label="name" track-by="name"
                      :preselect-first="false" data-vv-as="Petitioner" v-validate="'required'"
                      tag-placeholder="Invite Petitioner" :taggable="false" @tag="addNewPet" :searchable="true"
                      @search-change="searchPet" @input="petitionerUpdated" name="Petitioner">

                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          options selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>
                  <span class="text-danger text-sm" v-show="errors.has('newpetitionform.Petitioner')">{{
                  errors.first("newpetitionform.Petitioner") }}</span>
                </div>
                <p v-if="checkPetInvitePermisions" class="createnew">Not found Petitioner?<span
                    @click="addNewPet()">Invite Petitioner</span> </p>
              </div>

              <div class="vx-col w-1/2">
                <div class="form_group">
                  <div class="con-select w-full select-large">
                    <label class="form_label">Select Beneficiary<em>*</em></label>
                    <multiselect v-model="selectedBeneficiary" :options="beneficiaryMasterDataList" :multiple="false"
                      :hideSelected="false" :close-on-select="true" :clear-on-select="false" :preserve-search="true"
                      :select-label="'Search Beneficiary'" placeholder="Select Beneficiary" label="name" track-by="name"
                      :preselect-first="false" data-vv-as="Beneficiary" v-validate="'required'" :searchable="true"
                      @search-change="getbeneficiaryMasterDataList" name="beneficiary" @input="upDateBenef"
                      tag-placeholder="Add New Beneficiary" :taggable="false" @tag="addNewBenFromTag"
                      :disabled="!checkProperty(selectedPetitioner ,'_id')">

                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          options selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>

                  <span class="text-danger text-sm" v-show="errors.has('newpetitionform.beneficiary')">{{
                  errors.first("newpetitionform.beneficiary") }}</span>

                </div>
                <p class="createnew" v-if="checkBeneficaryInvitePermisions">Not found?<span
                    @click="addNewBenFromTag()">Invite Beneficiary</span> </p>
              </div>
            </template>
            <template>
              <div class="vx-col w-1/2" :class="{'w-full--':[2,10].indexOf(checkProperty(visatype,'id')) >-1}">
                <div class="form_group">
                  <div class="con-select w-full select-large">
                    <label for="" class="form_label">Case Type<em>*</em></label>
                    <multiselect name="visatype" data-vv-as="Case Type" v-validate="'required'" v-model="visatype"
                      :show-labels="false" track-by="id" label="name" placeholder="Select Case Type"
                      :options="activeVisatypes" :searchable="true" :allow-empty="false" @input="getvisasubtypes">
                    </multiselect>
                  </div>
                  <span class="text-danger text-sm" v-show="errors.has('newpetitionform.visatype')">{{
                  errors.first("newpetitionform.visatype") }}</span>
                </div>
              </div>

              <div class="vx-col w-1/2"  >
                <div class="form_group">
                  <div class="con-select w-full select-large">
                    <label for="" class="form_label">Case Subtype<em>*</em></label>
                    <multiselect name="visasubtype" data-vv-as="Case Subtype" v-validate="'required'"
                      v-model="visasubtype" :show-labels="false" track-by="id" label="name"
                      placeholder="Select Case Subtype" :options="visasubtypes" :searchable="true" :allow-empty="false"
                      @input="checkBenPermStatus">
                    </multiselect>
                  </div>
                  <span class="text-danger text-sm" v-show="errors.has('newpetitionform.visasubtype')">{{
                  errors.first("newpetitionform.visasubtype") }}</span>
                </div>
              </div>

              <div class="vx-col w-full pp-col" v-if="[2,9,10].indexOf(checkProperty(visatype,'id')) <=-1 && checkProperty(visasubtype,'id') !=15 ">
                <vs-checkbox id="premium" name="premiumProcessing" v-model="premiumProcessing">Premium Processing
                </vs-checkbox>

                <!-- <span class="text-danger text-sm"  v-show="errors.has('finalDeterminationFromDOL')">{{ errors.first("finalDeterminationFromDOL") }}</span> -->

              </div>
              <div class="vx-col  w-full" v-if="getTenantTypeId !=2">
                <div class="form_group">
                  <div class="con-select w-full select-large">
                    <label for="" class="form_label">Branch<em>*</em></label>
                    <multiselect name="branch" v-validate="'required'" v-model="selectedBranch" :show-labels="false"
                      track-by="_id" label="name" placeholder="Select branch" :options="branchList" :searchable="true"
                      :allow-empty="false" :multiple="false" :disabled="branchList.length==1"
                      @input="formerrors.msg=''">
                    </multiselect>
                  </div>
                  <span class="text-danger text-sm" v-show="errors.has('newpetitionform.branch')">{{
                  errors.first("newpetitionform.branch") }}</span>
                </div>
              </div>
              <template v-if="checkProperty(visatype,'id')==3 && checkProperty(visasubtype,'id')==16 ">
                <selectField :listContainsId="false" :display="true" :wrapclass="'md:w-1/2 '" :formscope="'newpetitionform'" :required="true"  cid="classification"   :optionslist="classificationList" v-model="classification" label="Classification"  fieldName="classification" placeHolder="Classification"   /> 
                <selectField  :display="true" :wrapclass="'md:w-1/2 '" :formscope="'newpetitionform'" :required="true"  cid="category"   :optionslist="categoryList" v-model="category" label="Category"  fieldName="category" placeHolder="Category"   /> 
              </template>
              <template v-if="permDocRequired">
                <div class="vx-col w-full padb20" @click="value = []">
                <div class="form_group file_group">
                  <div class="vs-component marb20">
                   <label class="form_label">PERM Documents<em>*</em></label>
                   <div>
                    <file-upload
                      v-model="value"
                      class="file-upload-input upload_file justify-center"
                      :accept="allDocEntity"
                      :name="'permDocuments'"
                      :multiple="true"
                      :hideSelected="true"
                      @input="upload(value, 'permDocuments')"
                    >
                      <img
                        class="file-icon"
                        src="@/assets/images/main/file-upload.svg"
                      />
                      Upload 
                    </file-upload>
                    <span v-if="uploading" class="loader"
                      ><img src="@/assets/images/main/loader.gif"
                    /></span>
                    </div>
                    <!---
                    <input type="hidden" v-model="newTask.documents"  data-vv-as="Documents"  v-validate="'required'" name="tdocs">
                    <span  class="text-danger text-sm" v-show="errors.has('tdocs')"   >{{ errors.first('tdocs') }}</span >
                    -->
                    <input type="hidden" v-model="permDolDocs"    v-validate="'required'" name="tdocs"></input>
                    
                    <span v-if="permDocFormatError" class="text-danger text-sm" >{{ permDocFormatError }}</span>
                    <span v-else class="text-danger text-sm" v-show="errors.has('newpetitionform.tdocs')">
                    <em>* </em>PERM Documents are required</span>
                  </div>


                  <ul class="uploaded-list note_uploads mt-5">
                    <template v-for="(item, index) in permDolDocs">
                      <vs-chip
                      @click="skillTextError=false;resetPermData(true);remove(item, permDolDocs, index)"
                        :key="index"
                        closable
                      >
                      {{ item.name }}
                      </vs-chip>
                    </template>
                  </ul>
                </div>
                </div>
                <!----PERM Details -->
                <div class="form-container alt-rows-bg perm_creation">
                  <div class="vx-row">



                      <immiInput :disabled="permDocPreFilledKyes.indexOf('jobTitle')>-1" :display="true" :wrapclass="'vx-col md:w-1/2'" :required="true" :fieldsArray="[]"
                      cid="permjobTitle" formscope="newpetitionform" v-model="permDetails['jobTitle']" fieldName="prm-jobTitle"
                      label="Job Title" placeHolder="Job Title" :maxLength="25" /> 

                      <immiInput :disabled="permDocPreFilledKyes.indexOf('hoursPerWeek')>-1" :onlyNumbers="true" @input="changedHoursPerWeek" :wrapclass="'vx-col md:w-1/2'" :display="true" cid="permhoursPerWeek"
                      :formscope="'newpetitionform'" v-model="permDetails.hoursPerWeek" :required="true" fieldName="perm-hoursPerWeek"
                      label="Hours per Week" placeHolder="Hours per Week" :maxLength="3" />
                      <immiInput :disabled="permDocPreFilledKyes.indexOf('wageRate')>-1" :onlyNumbers="true" :wrapclass="'vx-col md:w-1/2'" :display="true" cid="permwageRate"
                      :formscope="'newpetitionform'" v-model="permDetails.wageRate" :required="true" fieldName="wageRate"
                      label=" Wage Rate" placeHolder="Wage Rate" :maxLength="10" />
                      <selectField :isDisabled="permDocPreFilledKyes.indexOf('payFrequency')>-1"  :listContainsId="false" :wrapclass="'vx-col md:w-1/2'" :display="true" :required="true"
                      :formscope="'newpetitionform'" cid="permofferpayFrequency" :optionslist="payFrequencyList"
                      v-model="permDetails.payFrequency" fieldName="offerpayFrequency" label="Pay Frequency"
                      placeHolder="Pay Frequency" />
                      <selectField :multiple="false" :isDisabled="permDocPreFilledKyes.indexOf('socDetails')>-1" :showOptionItemStatus="true"  :wrapclass="'md:w-1/2'" :required="true" cid="socCode" :formscope="'newpetitionform'"
                      :optionslist="masterSocList" v-model="permDetails.socDetails" @input="updatesocCode" fieldName="socCod"
                      label="SOC Code" placeHolder="SOC Code " />
                      


                      <selectField :isDisabled="permDocPreFilledKyes.indexOf('minDegree')>-1" :wrapclass="'md:w-1/2'" :required="true"  cid="Education"  :formscope="'newpetitionform'" :optionslist="educationTypes" v-model="permDetails.minDegreeDetails" @input="permDetails.minDegree=permDetails.minDegreeDetails['id']"   fieldName="Education" label="Minimum Education" placeHolder="Minimum Education"   />  
                      <immiInput :disabled="permDocPreFilledKyes.indexOf('majorFieldsOfStudy')>-1" :wrapclass="'md:w-1/2'" :display="true" :cid="'majorFieldsOfStudy'" :formscope="'newpetitionform'"  v-model="permDetails.majorFieldsOfStudy" :required="true" fieldName="majorFieldsOfStudy" label="Major Field of Study" placeHolder="Major Field of Study"   />
                      <immiInput :disabled="permDocPreFilledKyes.indexOf('expInYears')>-1" :onlyNumbers="true" @input="updatedexpInYears" :allowFloatingPoint="false" :wrapclass="'md:w-1/2 custom_form_group'" :display="true" cid="expInYears" :formscope="'newpetitionform'"  v-model="permDetails.expInYears" :required="true" fieldName="expInYears" label="Experience in Months" placeHolder="Experience"  :maxLength="5" />
      
                        <template >
          <div class="vx-col w-full mt-2">
              <div class="skilladdsec">
                  <label>Skills Required</label>
                  <ul>
                      <li v-for="(skil , index ) in permDetails['skills']" :key="index">
                          <span class="skill-label">{{skil}}</span>                                  
                          <span  @click="removePermSkill(index)" v-if="permDocPreFilledKyes.indexOf('skills')<=-1" class="row_btn">
                              <img src="@/assets/images/main/delete-row-img.svg">
                          </span>
                      </li>
                  </ul>
                  <div class="add-input-sec" >
                      
                      <div  @keyup="addSkill=true;skillTextError=false" class="skill-text" :class="{'skill-text-error':skillTextError&& permDocPreFilledKyes.indexOf('skills')<=-1}">
                          <immiInput :disabled="permDocPreFilledKyes.indexOf('skills')>-1"  @keyEnter="addSkill=true;skillTextError=false;addPermNewSkill()" :wrapclass="'w-full'"  :display="true" cid="addSkill" :formscope="'jobOpptInfo'"  v-model="newSkill" :required="false" fieldName="altAcceptExpInYears" placeHolder=""  />
                           <!-- v-if="addSkill" -->
                          <span :class="{'skilsbtn-disable':permDocPreFilledKyes.indexOf('skills')>-1}"   @click="addPermNewSkill()" class="add-more">Add</span>
                      </div>
                  </div>
              </div>
          </div>
                 </template> 

                      <div class="vx-col  w-full mb-10">
                      <div class="form_group">
                      <label class="form_label">Description<em>*</em></label>
                      <ckeditor :disabled="permDocPreFilledKyes.indexOf('description')>-1 && permDetails.description" name="perm-jobDescription" v-model="permDetails.description" v-validate="'required'" class="w-full"
                        :data-vv-as="'Description'" :editor="editor" :config="editorConfig"></ckeditor>

                      <p v-show="errors.has('newpetitionform.perm-jobDescription')" class="text-danger text-sm"><em>*
                        </em>Description is required</p>
                      </div>
                      </div>

                    <br>
                    <immiswitchyesno :display="true" :wrapclass="'vx-col md:w-1/2'" :fieldsArray="[]"
                      :cid="'fullTimePosition'" formscope="fullTimePosition" v-model="permDetails.fullTimePosition"
                      fieldName="fullTimePosition" label="Is this a full-time position? " placeHolder="" />
                    <immiswitchyesno :display="true" :wrapclass="'vx-col md:w-1/2'" :fieldsArray="[]"
                      :cid="'permanentPosition'" formscope="permanentPosition" v-model="permDetails.permanentPosition"
                      fieldName="permanentPosition" label="Is this a permanent position? " placeHolder="" />
                    <immiswitchyesno v-if="false" :display="true" :wrapclass="'vx-col md:w-1/2'" :fieldsArray="[]"
                      :cid="'newPosition'" formscope="newPosition" v-model="permDetails.newPosition" fieldName="newPosition"
                      label="Is this a new position? " placeHolder="" />




                    <div class="vx-col w-full">


                      <div>
                        <h3 class="small-header">Address</h3>
                        <template v-for="(address ,index) in permDetails['workAddresses']">
                          <addressField :key="index" :display="true" :fieldsArray="questionnaireDetails" formscope="newpetitionform" :showaptType="true"
                            :addFormContainerCls="false" :validationRequired="true" :countries="all_countries"
                            v-model="permDetails['workAddresses'][index]" :cid="'beneficiaryInfoaddress'+index" />
                        </template>
                      </div>
                    </div>



                  </div>
                </div>



              </template>
              <template v-if="Doc140Required && checkProperty(visatype,'id')==3 && checkProperty(visasubtype,'id')==17 ">
                <div class="vx-col w-full" @click="value = []">
                    <div class="form_group file_group">
                      <div class="vs-component marb20">
                        <label class="form_label">I-140 Documents<em>*</em></label>
                        <div class="relative"> 
                        <file-upload
                          v-model="value"
                          class="file-upload-input upload_file justify-center"
                          :accept="allDocEntity"
                          :name="'documents'"
                          :multiple="true"
                          
                          :hideSelected="true"
                          @input="upload(value , '140Documents')"
                        >
                          <img
                            class="file-icon"
                            src="@/assets/images/main/file-upload.svg"
                          />
                          Upload 
                        </file-upload>
                        <span  v-if="uploading" class="loader"   ><img src="@/assets/images/main/loader.gif"   /></span>
                        </div>
                        <input type="hidden" :name="'140Documents'" v-validate="'required'"  data-vv-as="140 Documents"  v-model="Dol140Docs">
                        <span class="text-danger text-sm" v-show="errors.has('newpetitionform.140Documents')">*I-140 Documents are required</span>
                    
                      </div>
                      

                      <ul class="uploaded-list note_uploads">
                        <template v-for="(item, index) in Dol140Docs">
                          <vs-chip
                          @click="remove(item, Dol140Docs, index)"
                            :key="index"
                            closable
                          >
                          {{ item.name }}
                          </vs-chip>
                        </template>
                      </ul>
                    </div>
                </div>
            </template>
              <!-- <div class="vx-col " v-if="checkProperty(visatype,'id')==3 && checkProperty(visasubtype,'id')==16 " :class="{'w-full':getTenantTypeId ==2 ,'w-1/2':!( getTenantTypeId ==2)}">
                <div class="form_group">
                  <div class="con-select w-full select-large">
                    <label for="" class="form_label">Classification<em>*</em></label>
                    <multiselect name="classification" data-vv-as="Classification" v-validate="'required'" v-model="classification"
                      :show-labels="false"   placeholder="Classification" 
                      :options="classificationList" :searchable="true" :allow-empty="false" >
                    </multiselect>
                  </div>
                  <span class="text-danger text-sm" v-show="errors.has('newpetitionform.classification')">{{
                    errors.first("newpetitionform.classification") }}</span>
                </div>
              </div> -->

              <template v-if="checkProperty(visatype,'id')==3 && checkProperty(visasubtype,'id')==15" >
                <!-- <div  class="vx-row w-full ml-0">
                  <immiswitchyesno :display="true" :wrapclass="'md:w-1/2 PWD-switch'" @input="setPwdFilled(true)" :fieldsArray="questionnaireDetails" :cid="'isPwdFiled'"  formscope="newpetitionform" v-model="isPwdFiled" fieldName="isPwdFiled" label="PWD Filed/Certified document available?" placeHolder="" />  
                </div> -->
                <div class="vx-col w-full pwd-link">
                  <div class="form_group custom-radio_wrap ">
                    <ul class="custom-radio" vs-type="flex" vs-align="center">
                      <li> <vs-checkbox    name="radioPWDhavingPWD"   @input="changePwdDoc" v-model="isPwdFiled" class="w-full"
                      ><span ref="Free-Flow">Upload Filed/Certified Document</span></vs-checkbox > </li>
                      <li><vs-checkbox   ref="Sequential"  name="radioPWDlinkPWD"   @input="linkExistingPwd"   v-model="isLinkPwd" class="w-full"
                      > <span ref="Sequential">Link Existing PWD</span></vs-checkbox > 
                      </li>
                      <!-- <li><vs-radio   ref="Sequential"  name="radioPWD"  vs-value="noPWD" @input="assignPwdValue"   v-model="isLinkPwd" class="w-full"
                      > <span ref="Sequential">No PWD</span></vs-radio ></li> -->
                    </ul>
                    <!-- <input type="hidden" :name="'radioPWD'" v-validate="'required'" data-vv-as="PWD Selection"  v-model="isLinkPwd">
                    <span class="text-danger text-sm " style="top:46px" v-show="errors.has('newpetitionform.radioPWD')">{{errors.first('newpetitionform.radioPWD') }}</span> -->
                  </div>
                </div>
                <!----pwdStatus:'',  pwdStatusList:["Filed" ,"Certified"],-->
                <template v-if="isPwdFiled" >
                  
                                    
                  <div class="vx-col w-full" @click="value = [];pwdDocFormatError='';prefillJobDetailsError='';disablePWDstatus=false" >

                        


                    <div class="form_group file_group">
                      <div class="vs-component marb20">
                      <label class="form_label">PWD Documents<em>*</em></label>
                        <div class="relative">
                      <file-upload
                          v-model="value"
                          class="file-upload-input upload_file justify-center"
                          :accept="pdfDocEntity"
                          :name="'documents'"
                          :multiple="false"
                          :hideSelected="true"
                          @input="upload(value,'PWD')"
                        >
                          <img
                            class="file-icon"
                            src="@/assets/images/main/file-upload.svg"
                          />
                          Upload 
                        </file-upload>
                        <span  v-if="uploading" class="loader"   ><img src="@/assets/images/main/loader.gif"   /></span>
                        </div>
                        <!---
                          
                        <input type="hidden" v-model="newTask.documents"  data-vv-as="Documents"  v-validate="'required'" name="tdocs">
                        <span  class="text-danger text-sm" v-show="errors.has('tdocs')"   >{{ errors.first('tdocs') }}</span >
                        -->
                       
                        <input type="hidden" :name="'pwdDocs'" v-validate="'required'"  data-vv-as="PERM Documents"  v-model="pwdResponse['documents']">
                        <span v-if="pwdDocFormatError" class="text-danger text-sm" >{{pwdDocFormatError}}</span>
                        <span class="text-danger text-sm" v-else-if="errors.has('newpetitionform.pwdDocs')">*PWD Documents are required</span>
                     
                      </div>
                    

                      <ul class="uploaded-list note_uploads">
                        <template v-for="(item, index) in pwdResponse['documents']">
                          <vs-chip
                          @click="remove(item, pwdResponse['documents'], index);resetPrefedKyes()"
                            :key="index"
                            closable
                          >
                          {{ item.name }}
                          </vs-chip>
                        </template>
                      </ul>
                    </div>
                  </div>
                  <div @click="prefillJobDetailsError=''" class="text-danger text-sm formerrors" v-if="prefillJobDetailsError!=''">
                    <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ prefillJobDetailsError }}</vs-alert>
                    </div>
                    
                    <selectField v-if="isPwdFiled" :isDisabled="disablePWDstatus" @input="resetPwdResponse(true);loadingFields($event)"  :listContainsId="false" :wrapclass="'md:w-1/2'" cid="pwdStatus"  :required="true" :optionslist="pwdStatusList" v-model="pwdStatus" :formscope="'newpetitionform'"  fieldName="pwdStatus"  label="PWD Status" placeHolder="PWD Status"  />  
                      <div  class="vx-col md:w-1/2" :class="{'md:w-1/2':pwdStatus !='Certified','md:w-1/2': pwdStatus =='Certified','disabledPwdDocCaseNo':prefilledKyes.indexOf('pwdDocCaseNo')>-1}">

                      <div class="form_group">

                      <label class="form_label">PWD Case Number<em>*</em></label>

                      <vs-input :disabled="prefilledKyes.indexOf('pwdDocCaseNo')>-1"  v-model="pwdResponse.pwdDocCaseNo"   name="pwdDocCaseNo" v-validate="'required'" class="w-full"  data-vv-as="PWD Case Number"    />

                      <span class="text-danger text-sm" v-show="errors.has('newpetitionform.pwdDocCaseNo')">{{ errors.first("newpetitionform.pwdDocCaseNo") }}</span>

                      </div>

                      </div>
                    
                    <template v-if="pwdStatus ==='Certified'">
                  <datepickerField 
                  :isDisabled="(prefilledKyes.indexOf('issuedDate')>-1 && pwdResponse.issuedDate !==null && pwdStatus =='Certified')"
                              wrapclass="md:w-1/2"
                              @input="updateissuedDate($event)"
                              :display="true"  
                              v-model="pwdResponse.issuedDate" 
                              :formscope="'newpetitionform'"  
                              fieldName="issuedDate" 
                              :dateEnableTo="new Date()" 
                              label="Receipt Date" 
                              :validationRequired="true" 
                                />

                        <datepickerField 
                            wrapclass="md:w-1/2" 
                            :isDisabled="(prefilledKyes.indexOf('receivedDate')>-1 && pwdResponse.receivedDate !==null && pwdStatus =='Certified')"
                            :display="true"  
                            v-model="pwdResponse.receivedDate" 
                            :formscope="'newpetitionform'"  
                            fieldName="receivedDate" 
                            :dateEnableTo="new Date()" 
                            label="Recieved Date" 
                            :validationRequired="true"
                           />

                        <datepickerField 
                        :isDisabled="(!pwdResponse.issuedDate) || (prefilledKyes.indexOf('dueDate')>-1 && pwdResponse.dueDate !==null && pwdStatus =='Certified')"
                        wrapclass="md:w-1/2" 
                        :display="true"  
                        v-model="pwdResponse.dueDate" 
                        :formscope="'newpetitionform'"  
                        fieldName="dueDate" 
                        :dateEnableFrom="pwdResponse.issuedDate" 
                        label="Expiration Date" 
                        :validationRequired="true" 
                          />

                          <div class="vx-col w-full" v-if="false">
                    <div class="form_group">
                      <label class="form_label">Comments</label>
                       <ckeditor  data-vv-as="Comments"  v-model="pwdResponse.description" name="usciscomments"
                       class="w-full"  :editor="editor" :config="editorConfig"></ckeditor>
                      <span
                        class="text-danger text-sm"
                        v-show="errors.has('newpetitionform.usciscomments')"
                      ><em>*</em> Comments are required</span>
                    </div>
                    </div>
                          


                    
                          <div class="vx-col w-full" v-if="false">
                      <div class="form_group">
                        <label class="form_label">Document Type<em>*</em></label>
                        <div class="con-select w-full DT_multiselect">  
                        <!-- {{documentType}}                 -->
                          <multiselect
                            :name="'documentType'"
                            v-validate="'required'"
                            v-model="pwdResponse.documentType"
                            :show-labels="false"
                            
                            data-vv-as="Document Type"
                            placeholder="Document Type"
                            :options="['Original' ,'Electronic' ]"
                            :searchable="true"
                            :allow-empty="false"
                          >
                          </multiselect>
                        
                          <span  class="text-danger text-sm"  v-show="errors.has('uscisstatus.documentType')"  >{{ errors.first('uscisstatus.documentType') }}</span>
                        </div>
                      </div>
                         </div> 
                  </template>  
                  <immiswitchyesno v-if="false"  @input="setJobDetails($event)" :display="true" wrapclass=" " :fieldsArray="questionnaireDetails" :cid="'hasJobDetails'"  :formscope="'newpetitionform'" v-model="hasJobDetails" fieldName="hasJobDetails" label="Is Job Description available?" placeHolder="" />
                  <template v-if="hasJobDetails ">
                    <permJobCreationForm ref="jobComponent" v-model="jobDetails"  :formscope="'newpetitionform'" :countries="all_countries" />
                  </template>
                </template>
                <template v-if="isLinkPwd">
                  <linkPwdPopup :selectedPetitioner="selectedPetitioner" :callFormCasePopup="true" @emitPwd="emitPwd" />
                </template>
                <template v-if="selectedPwdId && isLinkPwd ">
                  <div class="d-flex" style="align-items: center;">
                    <div class="linked_pwd mr-2">
                    <p v-if="checkProperty(selectedPwdId,'pwdDocCaseNo')">
                      {{ checkProperty(selectedPwdId,'pwdDocCaseNo') }}<template v-if="checkProperty(selectedPwdId,'caseNo')">({{ checkProperty(selectedPwdId,'caseNo') }}) </template>
                    </p>
                    <p v-else>
                      {{ checkProperty(selectedPwdId,'caseNo') }}                        
                    </p>
                    <span @click="moveToTrash(selectedPwdId)" class="remove_pwd cursor-pointer" >
                        <img src="@/assets/images/main/delete-row-img.svg" />
                      </span>
                    </div>
                      
                  </div>
              </template>
              </template>
              
            </template>
            <template v-if="checkProperty(visatype,'id')==9 && (checkProperty(selectedBeneficiary ,'_id') || beneficiaryId )" >
                           
              <div class="vx-col w-full pwd-link"  >
                <div class="form_group custom-radio_wrap mb-4">
                  <label class="form_label mt-2 pb-1">Original Petition</label>
                  <ul class="custom-radio" vs-type="flex" vs-align="center">
                   <li> 
                    <vs-radio @change="resetRfeData()"   name="rfeInternalCase"  vs-value="internalCase" v-model="rfeData.rfeInternalCase" class="w-full" >
                      <span ref="Free-Flow">Internal Case</span>
                    </vs-radio >
                     </li>
                    <li>
                       <vs-radio  @change="resetRfeData()"  name="rfeInternalCase"  vs-value="externalCase"   v-model="rfeData.rfeInternalCase" class="w-full">
                           <span ref="Sequential">Filed Separately</span>
                        </vs-radio > 
             
                    </li>
                    
                  </ul>
                   </div>
              </div>

              <selectField v-if="rfeData.rfeInternalCase=='internalCase'" 
              
               :wrapclass="'md:w-full'" 
               cid="h1bCaseId" 
                :required="true
                " :optionslist="benficiaryH1BCases"
                 v-model="rfeData.h1bCaseId"
                  :formscope="'newpetitionform'" 
                   fieldName="h1bCaseId" 
                    label="Select Existing H-1B Case"
                     placeHolder="Select Existing H-1B Case"/>  
              
<!----- :dateEnableFrom="pwdResponse.issuedDate" -->
              <!-- <div class="vx-col w-full" v-if="rfeData.rfeInternalCase=='externalCase'" @click="value = [] ;formerrors.msg='';pwdDocFormatError=''" >
                 <div class="form_group file_group mb-0">
                  <div class="vs-component marb20">
                  <label class="form_label">Copy of RFE<em>*</em></label>
                    <div class="relative">
                  <file-upload
                      v-model="value"
                      class="file-upload-input upload_file justify-center"
                      :accept="pdfDocEntity"
                      :name="'documents'"
                      :multiple="false"
                      :hideSelected="true"
                      @input="upload(value,'RFE')"
                    >
                      <img
                        class="file-icon"
                        src="@/assets/images/main/file-upload.svg"
                      />
                      Upload 
                    </file-upload>
                    <span  v-if="uploading" class="loader"   ><img src="@/assets/images/main/loader.gif"   /></span>
                    </div>
                    -
                      
                    <input type="hidden" v-model="newTask.documents"  data-vv-as="Documents"  v-validate="'required'" name="tdocs">
                    <span  class="text-danger text-sm" v-show="errors.has('tdocs')"   >{{ errors.first('tdocs') }}</span >
                    
                  
                    <input  type="hidden" :name="'rfeDocs'" v-validate="'required'"  data-vv-as="Copy of RFE"  v-model="rfeData['documents']">
                    <span v-if="pwdDocFormatError" class="text-danger text-sm" >{{pwdDocFormatError}}</span>
                    <span v-else-if="errors.has('newpetitionform.rfeDocs')" class="text-danger text-sm" >*Copy of RFE are required</span>
                    
                  </div>


                  <ul class="uploaded-list note_uploads mt-5">
                    <template v-for="(item, index) in rfeData['documents']">
                      <vs-chip
                      @click="remove(item, rfeData['documents'], index);resetPrefedKyes()"
                        :key="index"
                        closable
                      >
                      {{ item.name }}
                      </vs-chip>
                    </template>
                  </ul>
                </div>
              </div> -->

              <div class="vx-col w-full RFE_popup_case_doc" v-if="rfeData.rfeInternalCase=='externalCase'" @click="value = [] ;formerrors.msg='';pwdDocFormatError=''" >
                    <div class="form-container mart20 casedocuments__">
                      <div class="documents_group case_documents">
                        <div class="vx-row delete-row">
                          <div class="vx-col w-full">
                            <div class="form_group">
                              <label class="form_label">
                                <span style="display:inline;">Copy of RFE<em>*</em></span>
                              </label>
                              <div class="relative">
                                <file-upload
                                    v-model="value"
                                    class="file-upload-input upload_file justify-center"
                                    :accept="pdfDocEntity"
                                    :name="'documents'"
                                    :multiple="false"
                                    :hideSelected="true"
                                    @input="upload(value,'RFE')"
                                  >
                                    <img
                                      class="file-icon"
                                      src="@/assets/images/main/file-upload.svg"
                                    />
                                    Upload 
                                  </file-upload>
                                  <span  v-if="uploading" class="loader"   ><img src="@/assets/images/main/loader.gif"   /></span>
                                  </div>
                                  <!---
                                    
                                  <input type="hidden" v-model="newTask.documents"  data-vv-as="Documents"  v-validate="'required'" name="tdocs">
                                  <span  class="text-danger text-sm" v-show="errors.has('tdocs')"   >{{ errors.first('tdocs') }}</span >
                                  --> 
                                
                                  <input  type="hidden" :name="'rfeDocs'" v-validate="'required'"  data-vv-as="Copy of RFE"  v-model="rfeData['documents']">
                                  <span v-if="pwdDocFormatError" class="text-danger text-sm" >{{pwdDocFormatError}}</span>
                                  <span v-else-if="errors.has('newpetitionform.rfeDocs')" class="text-danger text-sm" >*Copy of RFE is required</span>
                                  <ul class="uploaded-list note_uploads m-0">
                                    <template v-for="(item, index) in rfeData['documents']">
                                      <vs-chip
                                      @click="remove(item, rfeData['documents'], index);resetPrefedKyes()"
                                        :key="index"
                                        closable
                                      >
                                      <img src="@/assets/images/main/down-arrow2.svg" @click="downloads3file(ditem)" />
                                      {{ item.name }}
                                      </vs-chip>
                                    </template>
                                  </ul>
                              </div>
                          </div>
                        </div>
                      </div>
                    </div>
                </div>


              <div class="vx-col w-full RFE_popup_case_doc" v-if="rfeData.rfeInternalCase=='externalCase'" >
                <casedocumentslist :showTitle="false" @emitUploadingAction="emitUploadingAction" :docMainCategory="'rfeDocslist'" :docslist="rfeDocslist" formscope="newpetitionform" :fieldsArray="[]" v-model="rfeData.docs" :tplsection="'documents'"  :fieldName="''" ></casedocumentslist>
              </div>
              <template>
          <immiInput :disabled="prefilledKyes.indexOf('uscisReceiptNumber')>-1 " v-if="rfeData.rfeInternalCase=='externalCase'" :wrapclass="'md:w-1/2'" :display="true" cid="uscisReceiptNumber" :formscope="'newpetitionform'" v-model="rfeData.uscisReceiptNumber" :required="true" fieldName="uscisReceiptNumber" label="USCIS  Receipt Number" placeHolder="USCIS  Receipt Number" />
          
            <datepickerField  v-if="rfeData.rfeInternalCase=='externalCase'" 
                      :isDisabled="prefilledKyes.indexOf('rfeIssuedDate')>-1 "
                      wrapclass="md:w-1/2" 
                      :display="true"  
                      v-model="rfeData.rfeIssuedDate" 
                      :formscope="'newpetitionform'"  
                      fieldName="rfeIssuedDate" 
                      :dateEnableTo="new Date()" 
                      label="RFE Issued Date" 
                      :validationRequired="true" 
                      @input="clearReceivedDate"
                        />
                        <datepickerField  v-if="rfeData.rfeInternalCase=='externalCase'" 
                      :isDisabled="prefilledKyes.indexOf('rfeReceivedDate')>-1 || rfeData.rfeIssuedDate == null "
                      wrapclass="md:w-1/2" 
                      :display="true"  
                      v-model="rfeData.rfeReceivedDate" 
                      :formscope="'newpetitionform'"  
                      fieldName="rfeReceivedDate" 
                      :dateEnableFrom="rfeData.rfeIssuedDate"
                      :dateEnableTo="new Date()" 
                      label="RFE Received Date" 
                      :validationRequired="false" 
                        />
            <datepickerField  v-if="rfeData.rfeInternalCase=='externalCase'" 
                      :isDisabled="prefilledKyes.indexOf('rfeCaseUscisDeadlineDate')>-1 "
                      wrapclass="md:w-1/2" 
                      :display="true"  
                      :dateEnableFrom="new Date()" 
                      v-model="rfeData.rfeCaseUscisDeadlineDate" 
                      :formscope="'newpetitionform'"  
                      fieldName="rfeCaseUscisDeadlineDate" 
                     
                      label="RFE Due Date" 
                      :validationRequired="true" 
                        />
          </template>


             
                

              </template>
             

          </div>


          <div class="text-danger text-sm formerrors" v-show="formerrors.msg">
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
              icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
          </div>
        </div>

        <div class="popup-footer relative">
          <span class="loader" v-if="newPetitionFormSubmited" ><img src="@/assets/images/main/loader.gif" /></span>
         
          <vs-button color="dark" @click="$modal.hide('benCaseCreationModal');NewPetition=false ;formerrors.msg=''" class="cancel" type="filled">Cancel
          </vs-button>
          <vs-button color="success" :disabled="!selectedBranch || !enableSubmitBtn || newPetitionFormSubmited || documentUploading " @click="fileNewCase"
            class="save" type="filled">Submit</vs-button>
        </div>
      </form>
        </div>
    </modal>
    <vs-popup
      class="Change_petition_wrap"
      title="Create Case Confirmation"
      :active.sync="classificationpopup"
    >
      <div class="Change_petition">
        <div class="form-container py-0">
          <div class="vx-row">
            <div class="vx-col w-full">
              <p class="text-center p-0">{{i140CreationMessage }}</p>
            </div>
          </div>
        </div>
      </div>
      <div class="popup-footer relative">
          <span class="loader" v-if="newPetitionFormSubmited" ><img src="@/assets/images/main/loader.gif" /></span>
          
          <vs-button color="dark" @click="classificationpopup=false ;formerrors.msg='';" class="cancel" type="filled">No
          </vs-button>
          <vs-button color="success" :disabled=" newPetitionFormSubmited || !enableSubmitBtn" @click="classificationpopup =false ;createNewPetition(true)"
            class="save" type="filled">Yes</vs-button>
        </div>
    </vs-popup>
    <vs-popup class="holamundo main-popup" title="Invite Petitioner" :active.sync="invitepetitioner">

      <addBenewPet @closenewPetPopup="closenewPetPopup" v-if="invitepetitioner" />
    </vs-popup>

    <vs-popup class="holamundo main-popup" :class="{'openedNewpetpopup':invitepetitioner}" :title="editMode?'Edit Beneficiary':inviteBeneficiary ? 'Invite Beneficiary' : 'Add Beneficiary'"
      :active.sync="AddBeneficiary"> 
      
      <addNewbeneficiary ref="add_ben" @closeAddBenPopUp="closeAddBenPopUp" v-if="AddBeneficiary" :selectedIItem="selectedIten"
        :petitioner="selectedPetitioner" @openAddpetPopUp="openAddpetPopUp" :beneDetails="userDetails" />
    </vs-popup>

    <vs-popup class="holamundo main-popup" title="Set Password" :active.sync="setPassword">
      <form @submit.prevent>
        <div class="popup-accounts-content edit_password" v-if="setPassword">

          <div class="form-container" @click="setPasswordErrorMsg=''">
            <div class="form_group">
              <!-- <i class="placeholder-icon IP-hide-1"></i> -->
              <label class="form_label">New Password<em>*</em></label>
              <vs-input type="password" v-validate="'required|min:6|max:15|strongpassword'" data-vv-as="New Password"
                name="currentPassword" v-model="newPassword" class="w-full no-icon-border" ref="password" />
              <span class="text-danger text-sm" v-show="errors.has('currentPassword')">{{
              errors.first("currentPassword") }}<br /></span>
            </div>
            <div class="form_group">
              <!-- <i class="placeholder-icon IP-hide-1"></i> -->
              <label class="form_label">Confirm Password<em>*</em></label>
              <vs-input type="password" v-validate="'required|confirmed:password'" data-vv-as="Confirm Password"
                v-model="confPassword" name="newPassword" class="w-full no-icon-border" />
              <span class="text-danger text-sm" v-show="errors.has('newPassword')">{{
              errors.first("newPassword")
              }}</span>
            </div>

            <div v-if="setPasswordErrorMsg ">
              <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius"
                icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ setPasswordErrorMsg}}</vs-alert>
            </div>

          </div>
          <div class="popup-footer justify-between relative">
            <div class="password-count">
              <i class="icon IP-lock"></i> Password must contain 6 to 15 characters
            </div>

            <div class="d-flex">
              <vs-button color="dark" @click="setPassword=false ;updatingPassword=false" class="cancel" type="filled">
                Cancel</vs-button>

              <vs-button class="save w-auto" type="filled" @click="changePassword" :disabled="updatingPassword">
                <figure v-if="updatingPassword" class="loader"><img src="@/assets/images/main/loader.gif" /></figure>
                <template v-if="checkProperty(selectedIten ,'statusDetails','id') ==1">
                  Set Password
                </template>
                <template v-else>Update</template>


              </vs-button>
            </div>
          </div>
        </div>
      </form>
    </vs-popup>

    <vs-popup class="holamundo main-popup" :title="'Convert as Customer'" :active.sync="moveToIndiduals">
      <form @submit.prevent>
        <div class="popup-accounts-content" v-if="moveToIndiduals">
          <div class="form-container padb20" @click="moveToIndidualsErrorMsg=''">
            <div class="form_group">
              <div class="vx-row">

                <div class="vx-col w-full">
                  <p>Are you sure want to convert as customer?</p>
                </div>
              </div>
            </div>
            <div v-if="moveToIndidualsErrorMsg ">
              <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius"
                icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ moveToIndidualsErrorMsg}}
              </vs-alert>
            </div>
          </div>
          <div class="popup-footer">
            <div class="d-flex">
              <vs-button color="dark" class="cancel" type="filled" @click="moveToIndiduals =false">Cancel
              </vs-button>
              <vs-button color=" success" class="save" type="filled" @click="migrateToIndividuals"
                :disabled="updatingPassword">
                Yes
              </vs-button>
            </div>
          </div>
        </div>

      </form>
    </vs-popup>
   
    <vs-popup class="holamundo main-popup" :title="popUpTitle " :active.sync="deleteBeneficiaryPopup">
        <div class="form-container">
          <div class="vx-row"  >
            <div class="vx-col w-full">

              <!------  this.popUpText  =callFrom; active inactive delete-->
              
              <!-- <p>{{ popUpText }} </p> -->
              <p>Are you sure to continue?</p>
            </div>
                      
          </div>
          <div class="text-danger text-sm formerrors" v-show="errorMsg">
                <vs-alert
                  color="warning"
                  class="warning-alert reg-warning-alert no-border-radius"
                  icon-pack="IntakePortal"
                  icon="IP-information-button"
                  active="true"
                >{{ errorMsg }}</vs-alert>
          </div>
        </div>
        <div class="popup-footer relative">
           <span class="loader" v-if="loading" ><img src="@/assets/images/main/loader.gif"/></span>
          <vs-button color="dark" class="cancel" type="filled" v-on:click.stop.prevent="deleteBeneficiaryPopup=false;">Cancel</vs-button>
          <vs-button v-if="selectedStatus==2" color="success" class="save" :disabled="loading" type="filled" v-on:click.stop.prevent="deleteBeneficiary(2)">
               
                Activate
        </vs-button>
        <vs-button v-else-if="selectedStatus==4" color="success" class="save" :disabled="loading" type="filled" v-on:click.stop.prevent="deleteBeneficiary(4)">
              
              Delete
              
       </vs-button>
       <vs-button v-else-if="selectedStatus==3" color="success" class="save" :disabled="loading" type="filled" v-on:click.stop.prevent="deleteBeneficiary(3)">
              
        Inactivate
              
       </vs-button>
        </div>
    </vs-popup>



  </div>
</template>

<script>
import addressField from "@/views/forms/fields/address.vue";

import casedocumentslist from "@/views/common/casedocuments.vue";
import immiInput from "@/views/forms/fields/simpleinput.vue";

import datepickerField from "@/views/forms/fields/datepicker.vue";
import selectField from "@/views/forms/fields/simpleselect.vue";
import linkPwdPopup from "@/views/actionpopups/linkPwdPopup.vue"
import permJobCreationForm from "@/views/actionpopups/perm/permJobCreationForm.vue"
import immiswitchyesno from "@/views/forms/fields/switchyesno.vue";
import FileUpload from "vue-upload-component/src";
import NoDataFound from "@/views/common/noData.vue";
import Datepicker from "vuejs-datepicker-inv";
import Paginate from "vuejs-paginate";
import DateRangePicker from "vue2-daterange-picker";
import "vue2-daterange-picker/dist/vue2-daterange-picker.css";
import moment from 'moment'
import PhoneMaskInput from "vue-phone-mask-input";
import * as _ from "lodash";
import VuePhoneNumberInput from 'vue-phone-number-input';
import 'vue-phone-number-input/dist/vue-phone-number-input.css'; 
import addNewbeneficiary  from "@/views/common/addBeneficiary.vue" 
import addBenewPet  from "@/views/common/invitePet.vue" 
import { MoreVerticalIcon } from 'vue-feather-icons'
import Vue from 'vue';
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';


import JQuery from "jquery";
export default {
  provide() {
      return {
          parentValidator: this.$validator, 
      };
  },
  components: {
    casedocumentslist,
    addressField,
    immiInput,
    linkPwdPopup,
    datepickerField,
    selectField,

    immiswitchyesno,
    permJobCreationForm,
    FileUpload,
    addNewbeneficiary,
    addBenewPet,
    NoDataFound,
    VuePhoneNumberInput,
    Datepicker,
    Paginate,
    DateRangePicker,
    moment,
    PhoneMaskInput,
    MoreVerticalIcon
  },
  data: () => ({
    benficiaryH1BCases:[],
   
    rfeDocslist:[

{
  required: true,
  fileUploading:false,
  key: 'orgPetition',
  fieldName: 'orgPetition',
  label:'Original Petition'
},
{
  required: false,
  fileUploading:false,
  key: 'petitionerDocs',
  fieldName: 'petitionerDocs',
  label:'Petitioner Documents (if any)'
},
{
  required: false,
  fileUploading:false,
  key: 'beneficiaryDocs',
  fieldName: 'beneficiaryDocs',
  label:'Beneficiary Documents'
},
{
  required: false,
  fileUploading:false,
  key: 'employmentDocs',
  fieldName: 'employmentDocs',
  label:'Employment Documents (if any)'
},
{
  required: false,
  fileUploading:false,
  key: 'other',
  fieldName: 'other',
  label:'Others'
},

],
documentUploading:false,
rfeData:{
rfeIssuedDate:null,
    rfeReceivedDate:null,
rfeCaseUscisDeadlineDate:null,
uscisReceiptNumber:'',
rfeInternalCase:'internalCase',//'externalCase',//'internalCase',
"documents":[],
"docs":{
"copyOfRfe":[],
  "orgPetition":[],
  "petitionerDocs":[],
  "employmentDocs":[],
  "beneficiaryDocs":[],
  "other":[]

},
h1bCaseId:null
},

    educationTypes:[],
    draftExtractInfo:null,
    skillTextError:false,
    newSkill:'',
    addSkill:true,
    payFrequencyList: ["Hour", "Week", "Month", "Year"],
  masterSocList:[],
  permDocFormatError:'',
  permDetails: {
          socCode:'',
          socDetails:null,
          jobTitle: '',

          minDegreeDetails:null,
          minDegree:null,
          skills:[],
          majorFieldsOfStudy:'',
          expInYears:null,

           workAddresses: [
          {
                  line1: null,
                  line2: null,
                  aptType: null,
                  locationId: null,
                  locationDetails: null,
                  stateId: null,
                  stateDetails: null,
                  countryId: null,
                  countryDetails: null,
                  zipcode: null
              }
          ],

          fullTimePosition: false,

          hoursPerWeek: '',

          wageRate: '',

          payFrequency: 'Month', // Year, Month, Bi-Weekly, Week, Hour

          description: '',

          permanentPosition: false,

          newPosition: false

      },
  permDocPreFilledKyes:[],

    isLinkPwd:false,
    selectedPwdId:null,
   // actionPopupText:"",
    editor: ClassicEditor,
    editorConfig: {
        toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
    },
    i140CreationMessage:'',
    classificationpopup: false,
    classificationResultList:[],
    prefilledKyes:[],
    disablePWDstatus:false,
    prefillJobDetailsError:'',
    pwdDocFormatError:'',
    searchText :'',
    jobDetails: {
      wageRate: "",
      socOccuTitle: "",
      preferredSocOccuTitle:"",
      
      socCode: "",
            jobTitle: "",
            preferredSocCode: '',
      preferredSocCodeDetails:null,
            classification: "",
            description: "",
            skills: [],
            minDegree: '',
            majorFieldsOfStudy: "",
            expInYears: "",
            altJobRequirements: {

            // Are alternate sets of Education, Training, and/or Experience accepted? "Yes", "No"

            areAltSetsOfEducation:"",// { type: String},
            altevelOfEducation: null,//{ type: Schema.Types.ObjectId, default: null  }, //0bjectId
            altevelOfEducationDetails:null,
            usDiplomaOrDegreeAccepted:'', //{type: String},
            majorsOrFieldsOfStudyAccepted: '',//{type: String},
            isAltTrainingForTheJobOpporAccepted: '',//"Yes" Or "No"
            noOfMonthsOfAltTrainingAccepted: null,//{type: String},
            filedsOrNamesOfTrainingAccepted: "",//{ type: String },
            altEmpExpAccepted: "", //"Yes" Or "No"
            noOfMonthsAltEmpExpAccepted:null,
            splSkillOrOtherRequi:'',
            ForeignLanguage:'',
            LicenseCertification:'',
            residencyFellowship:'',
            otherSplSkillsOrRequi:''

            },
            workAddresses: [{
                "companyName": "",
                "line1" : "",
                "line2" : "",
                "aptType": "",
                "locationId" :'' ,
                "stateId" :'' ,
                "countryId" :'' ,
                "zipcode" : "",
                "locationDetails" : {
                    "id" : '',
                    "name" : "",
                    "stateId" : '',
                    "countryId" :'' 
                },
                "stateDetails" : {
                    "id" :'' ,
                    "name" : "",
                    "shortName" : "",
                    "countryId" : ''
                },
                "countryDetails" : {
                    "id" : 231,
                    "shortName" : "US",
                    "name" : "United States",
                    "phoneCode" : 1,
                    "order" : 1,
                    "currencySymbol" : "$",
                    "currencyCode" : "USD",
                    "zipcodeLength" : 5
                },
                "workLocation": true
            }]
        },
    pwdStatusList:["Filed" ,"Certified"],
    pwdResponse:{
      "issuedDate": null,
      "receivedDate": null,
      "dueDate": null,
      "description": "",
      "documents": [],
      "documentType": "",

    },
    pwdStatus:'',

    questionnaireDetails:null,
    pwdDocs:[],
    hasJobDetails:false,
    isPwdFiled:false,
    value:[],
    uploading:false,
    selectedBeneficiaryId:'',
    permDolDocs :[],
    responsePermId :'',
    Dol140Docs:[],
    Doc140Required:false,
    response140Id:'',
    permDocRequired : false,
    category:'',
    categoryList:[],
    classification:'',
    classificationList:['EB2','EB3','EB3S'],
    inviteBeneficiary: false,
    setPassword: false,
    moveToIndiduals:false,
    
    updatingInviteAcoount:false,
    inviteEmail:'',
   newPassword:'',
   confPassword:'',
   updatingPassword:false,
    setPasswordErrorMsg: '',
    moveToIndidualsErrorMsg:'',
    
    approveConformpopUp:false,

    premiumProcessing:false,
    newPetOpenFromben:false,
    enableAddNewBenTag:false,
    invitepetitioner:false,
    openNewbenForm:false,
    selectedBeneficiary:null,
    beneficiaryMasterDataList:[],
    selectedIten:null,
                     

    addNewPete:false,
    isPetitionerPhoneValid:true,
    newPetitioner: {
        firstName: "",
        lastName:"",
        adminFirstName: "",
        adminLastName:"",
        roleId:50,
        email: "",
        phone:"",
        active:true,
        address: {
          "line1": "",
          "line2": "",
          "locationId": "",
          "stateId": "",
          "countryId": 231,
          "zipcode": ""
        }
      },
    selectedPetitioner:null,
    petitionersList:[],
    selectedPetitionerforFilter:[],
    enableAddNewpet:false,
    isListloading:false,
    sortKeys: {},
    sortKey: {},
    filteredVisaType:null,
    filteredVisaSubTypes:[],
    allsubTyps:[],
    isPhoneValid:true,
    callFromSerch:false,
    newPetitionFormSubmited:false,
    formerrors: {
      msg: ""
    },
    date: null,
    activeVisatypes:[],
    visatype:{
        id: 1,
        name: "H-1B"
      },
      vuePhone:{
        props:{
          translations:{
            phoneNumberLabel:"Phone Number"
          }
        }

      },
    visasubtype:null,
    selectedBranch:null,
    branchList:[],
    //visasubtype:null,
    selectedUser:null,
    selectedUsername:null,
    selectedUseremail:null,
    beneficiary: {
      name: "",
      email: "",
      phone:"",
      phoneCountryCode :{countryCode:'',countryCallingCode:''}
    },
    users: [],
    AddBeneficiary: false,
    NewPetition: false,
    visatypes:[],
    visasubtypes:[],
    searchtxt: "",
    query: [],
    country_code: 231,

    all_countries : [],
    selected_country_obj:'',
    filtered_country:'',

    all_statusids: [],
    selected_statusids: [],
    final_selected_statusids: [],

    all_states: [],
    seleted_states: [],
    final_selected_states: [],
    singel_final_selected_state:'',
    // locationIds
    all_locations: [],
    seleted_locations: [],
    final_selected_locations: [],
    //date: "",
    date_range: [],
    page: 1,
    perPeges: [10,25,50,75,100], // [  {name:10 ,perPage:10} , {name:25 ,perPage:25} ,{name:50 ,perPage:50},{name:100 ,perPage:100}],
    perpage: 50,
    totalCount:0,
    totalpages: 0,
    selected_createdDateRange: {},
    selected_normcreatedDateRange:{},
    autoApply: "",
    saveBenbtn: false,
    enableSubmitBtn:true,
    deleteBeneficiaryPopup: false,
    selectedBeneficiaryItem:null,
    errorMsg:'',
    popUpText:'',
    popUpTitle:'',
    selectedStatus:null,
    loginUserData:null,
    loginRoleId: null,
    loading:false,
    userDetails:null,
    //petition: [],
    editMode:false,
    debounce: null,
    encodedString:'',
  }),
  watch: {
    searchtxt: function(value) {
      this.searchMe();
  
    }
  },
  methods: {
    changeperPage(){       
          this.page = 1;
          this.getbeneficiaries(true); 
        },
    clearReceivedDate(val){
      if(val){
        let startDate = moment(val);
        if(this.rfeData.rfeReceivedDate){
          let endDate= moment(this.rfeData.rfeReceivedDate)
          if(startDate.isAfter(endDate , 'day')){
            this.rfeData.rfeReceivedDate = null
          }
        }
      }
      // else{
      //   this.rfeData.rfeReceivedDate = null
      // }
    },
    peritioners_search_fun(searchValue) {
      clearTimeout(this.debounce)
      this.debounce = setTimeout(() => {
        this.getPetitioners(false, searchValue );
      }, 900)
    },
    resetRfeData(setrfeInternalCase=false){
      this.prefilledKyes =[];
      this.documentUploading =false;
    //alert("ssd fsd");
  //   rfeData:{
  //   rfeCaseUscisDeadlineDate:null,
  //uscisReceiptNumber:'',
  //   rfeInternalCase:'externalCase',//'internalCase',
  //   "documents":[],
  //   "docs":{
  //     "copyOfRfe":[],
  //       "orgPetition":[],
  //       "petitionerDocs":[],
  //       "employmentDocs":[],
  //       "beneficiaryDocs":[],
  //       "other":[]

  //   },
  //   h1bCaseId:null
  // }
  
  if(setrfeInternalCase){
    this.rfeData['rfeInternalCase'] ='internalCase'
    this.premiumProcessing =false;
  }
  this.rfeData['h1bCaseId'] =null
   //rfeIssuedDate:null,rfeReceivedDate:null
   this.rfeData['rfeIssuedDate'] =null
  this.rfeData['rfeReceivedDate'] =null
  this.rfeData['rfeCaseUscisDeadlineDate'] =null
  this.rfeData['uscisReceiptNumber'] ='';
  
  this.rfeData['documents'] =[];
  this.rfeData['docs'] ={
      "copyOfRfe":[],
        "orgPetition":[],
        "petitionerDocs":[],
        "employmentDocs":[],
        "beneficiaryDocs":[],
        "other":[]

    }
  this.rfeData['h1bCaseId'] =null
 

  },
    emitUploadingAction(data){
              if(_.has(data,'docMainCategory')){
                  _.map(this[data['docMainCategory']],(item)=>{
                      if(item['fieldName'] == data['fieldName']){
                          item = Object.assign( item ,{ "fileUploading": false})
                          item['fileUploading'] = data['action'] 
                      }
                  })
              }
              this.checkSubmitBtn(data)
          },
          checkSubmitBtn(data){
              this.documentUploading = false;
              if(_.has(data,'docMainCategory')){
                  _.forEach(this[data['docMainCategory']],(item)=>{
                      if(_.has(item,'fileUploading') && item['fileUploading']){
                          this.documentUploading = true;
                          return false;
                      }
                  })
              }
          },
    prefillRfeNoticeDoc(){
    this.draftExtractInfo = null;
    var _dt;
    this.prefilledKyes =[];
    this.$validator.reset();
    if(this.checkProperty(this.rfeData,"documents", 'length' )>0){
      let path ="/petition/extract-lca-data-from-pdf";
      path ="/common/extract-data-from-pdf";
      //  9014077715 --- 325
    
  
      let postData ={
        "category": "rfe_notice",
        "docType": "rfe_notice",
        documents:[],
        "lcaDocument":''
      };
    
      let doc = this.rfeData['documents'][0];
      postData['lcaDocument'] = doc.path;
      postData['documents'].push(doc.path);
      //return doc.path;
  
  this.$vs.loading();
  this.$store.dispatch('commonAction', {"data":postData ,"path":path})
      .then((response)=>{
        this.$vs.loading.close();
        this.uploading = false;  
        this.draftExtractInfo =response;
        if(this.checkProperty(this.draftExtractInfo ,'uscisDeadlineDate')){
          this.rfeData['rfeCaseUscisDeadlineDate'] = this.draftExtractInfo['uscisDeadlineDate']; //moment(this.draftExtractInfo['uscisDeadlineDate']).format("MM/DD/YYYY");
          this.prefilledKyes.push('rfeCaseUscisDeadlineDate');
        }

        //rfeIssuedDate:null,
    //rfeReceivedDate:null,

       if(this.checkProperty(this.draftExtractInfo ,'rfeIssuedDate')){
          this.rfeData['rfeIssuedDate'] = this.draftExtractInfo['rfeIssuedDate']; 
          this.prefilledKyes.push('rfeIssuedDate');
        }
        if(this.checkProperty(this.draftExtractInfo ,'rfeReceivedDate')){
          this.rfeData['rfeReceivedDate'] = this.draftExtractInfo['rfeReceivedDate']; 
          this.prefilledKyes.push('rfeReceivedDate');
        }

        if(this.checkProperty(this.draftExtractInfo ,'uscisReceiptNumber')){
          this.rfeData['uscisReceiptNumber'] = this.draftExtractInfo['uscisReceiptNumber'];
          this.prefilledKyes.push('uscisReceiptNumber');
        }
       
        

      }).catch((errr)=>{
        this.$vs.loading.close();
        this.pwdDocFormatError = errr
        this.uploading = false;  
      });
    }

    },
    getBenficiaryH1BCases(){
    this.rfeData.h1bCaseId =null;
    this.benficiaryH1BCases =[];
    let postData ={
      "matcher":{
        "getMasterDataOnly": true,
        "rfeCases":false,
      "searchString":"",
      "statusIds":[24],
      "beneficiaryIds":[],
      "premiumProcessing":[],
      "stateIds":[],
      "locationIds":[],
      "petitionerIds":[],
      "branchIds":[],
      "typeIds":[1],
      "subTypeIds":[],
      //"getActiveCases":true,
      "deadlineDateRange":[],
      "getMissingDeadlines":false,
      "statusList":[], //get only rfe
      "intStatusIds":[],
      "assignedUserIds":[],
      "getFiledCases":false,
      "countryIds":[]
    },
    "page":1,"perpage":25,
    "sorting":{"path":"updatedOn","order":-1},
   
    
  }
  //this.checkProperty(this.visasubtype,'id') == 9 &&
  //alert(JSON.stringify(this.visatype));
 console.log(JSON.stringify(this.selectedBeneficiary));
  if( this.checkProperty(this.visatype,'id') == 9 && (this.checkProperty(this.selectedBeneficiary ,'_id') || this.beneficiaryId )){


    if(this.checkProperty(this.selectedBeneficiary ,'_id')){
          postData['matcher']['beneficiaryIds']=[];
          postData['matcher']['beneficiaryIds'].push(this.checkProperty(this.selectedBeneficiary ,'_id'));
          
        }else if(this.beneficiaryId){
          postData['matcher']['beneficiaryIds']=[];
          postData['matcher']['beneficiaryIds'].push(this.beneficiaryId);
          
        }

  
  this.$store.dispatch("commonAction", { "data": postData,"path":"/petition-common/list"}).then(response => {  
    let list = [];
   // caseNo
   if(this.checkProperty(response,'list','length') >0){
    list = response.list;
    list =  _.map(list,(item)=>{
      if(_.has(item, 'caseNo')){
        item['name'] = item['caseNo'];
        item['id'] = item['_id'];
        return item;

      }
    })

   }
    this.benficiaryH1BCases =list ;

  })
  }

  },
    updatedexpInYears(){
      if(this.checkProperty( this.permDetails, 'expInYears' )){
        this.permDetails.expInYears = parseInt(this.permDetails.expInYears);
      }
      

    }, 
    addPermNewSkill(){
    
    
    this.skillTextError =false;
    if(this.newSkill && this.newSkill.trim() !=''){

        let skil = this.newSkill.trim();
        if(this.permDetails['skills'].indexOf(skil) <=-1){
            this.permDetails['skills'].push(skil);
        }

        
        this.newSkill ='';
        this.addSkill =false;
    }else{
        this.skillTextError =true;
    }
    },
  removePermSkill(index ){
      
      this.permDetails['skills'].splice(index ,1);
    // this.$emit('input', this.value);
  },
    getEducationList(){
          this.$store
              .dispatch("getmasterdata", "education_types")
              .then((response) => {
                  this.educationTypes = response;
                                   
              })
              },

  changedHoursPerWeek(){
   
    if(this.checkProperty( this.permDetails, 'hoursPerWeek')){

      this.permDetails['hoursPerWeek'] = parseInt(this.permDetails['hoursPerWeek']);
      
    }


  },
  resetPermData(callFromPermDocDelete=false){
    this.draftExtractInfo= null;
    
    let defaultPermDetails = {
          socCode:'',
          socDetails:null,
          jobTitle: '',
          minDegreeDetails:null,
          minDegree:null,
          skills:[],
          majorFieldsOfStudy:'',
          expInYears:null,
          workAddresses: [ {line1: null,  line2: null, aptType: null, locationId: null, locationDetails: null,stateId: null, stateDetails: null,   countryId: null,  countryDetails: null, zipcode: null }
          ],
          fullTimePosition: false,
           hoursPerWeek: '',
            wageRate: '',
           payFrequency: 'Month', // Year, Month, Bi-Weekly, Week, Hour
          description: '',
          permanentPosition: false,
          newPosition: false

      }

      if(callFromPermDocDelete){
      _.forEach(this.permDetails , (item ,key)=>{
          if(_.has(defaultPermDetails ,key) && this.permDocPreFilledKyes.indexOf(key)>-1 ){

            this.permDetails[key] = defaultPermDetails[key];
           


          }

        });
      }else{

        this.permDetails =_.cloneDeep(defaultPermDetails);

      }
      this.permDocPreFilledKyes =[];
      this.$validator.reset();



  },

  updatesocCode(item){ 

    if(_.has( item ,'id')){
      this.permDetails['socCode'] = item['id'];
    }
  },
  getMasterSocList(){

  let query = {};
  query["page"] = 1;
  query["perpage"] = 10000;
  query["matcher"] = { 
   "getInactiveListAlso": true
    };
  query["category"] = "soc_codes";


  this.$store
  .dispatch("getMasterData", query)
  .then((response) => {
    this.masterSocList = response.list;



  //alert(this.perpage);
  })
  .catch(() => {
  this.masterSocList = [];

  });

  },
  //permDocPreFilledKyes
  prefillPermDocData(){
    this.draftExtractInfo =null;
    let _self =this;
    this.formerrors.msg ='';
    this.permDocFormatError ="";
    var _dt;
    this.permDocPreFilledKyes =[];
    this.$validator.reset();
  if(this.permDolDocs.length>0){
  this.uploading = true;  
  let path ="/common/extract-data-from-pdf";
  let postData ={
    "docType": "perm",
    documents:[],
  };
  //postData['documents'] = this.pwdResponse['documents']
  _.forEach(this.permDolDocs ,(doc)=>{
    postData['documents'].push(doc.path)
      //return doc.path;
  })
  this.$vs.loading();
  this.$store.dispatch('commonAction', {"data":postData ,"path":path})
      .then((response)=>{
        this.uploading = false;  
        let responseData = response['jobDetails'];
        _dt = _.cloneDeep(response['jobDetails']);
        this.draftExtractInfo = response;
      _.forEach(this.permDetails , (item ,key)=>{
          if(_.has(responseData ,key) && responseData[key]){
            
            
            if(key=="wageRate" && responseData[key]){
              let wageRate = responseData[key];
              const specialCharsRegex = /[^0-9.]/g;
               // Use the replace() method to replace all special characters with an empty string
               wageRate = wageRate.replace(specialCharsRegex, "");

              this.permDetails['wageRate'] = parseFloat(wageRate);
            }else if(key=="socCode"){
              this.permDocPreFilledKyes.push("socDetails");
              this.permDetails['socDetails'] = _.find(this.masterSocList, {"id":parseInt(responseData[key])});
             
            }else  if( key=="minDegree" , this.checkProperty(responseData ,'minDegree' )){
                  this.permDetails['minDegree'] = responseData['minDegree'];
                  this.permDetails['minDegreeDetails'] = _.find(this.educationTypes, {"id": parseInt(responseData['minDegree'])});
                  this.permDocPreFilledKyes.push("minDegree")
            }else if(key=="skills") {

              

              let skils = responseData[key].split(',');
              this.permDetails['skills'] = _.map(skils,(skil)=>skil.trim())
              if(this.checkProperty(this.permDetails, 'skills', 'length' )>0){
                this.permDocPreFilledKyes.push(key);
              }

          }else{
            this.permDetails[key] = responseData[key];
            this.permDocPreFilledKyes.push(key);
          }
          this.updatedexpInYears();


          }

        });
      
        this.permDetails =_.cloneDeep(this.permDetails);
        

        setTimeout(function(){
        _self.permDetails.workAddresses[0].locationId = responseData.workAddresses[0].locationId;
        _self.permDetails.workAddresses[0].locationDetails = responseData.workAddresses[0].locationDetails;
        },800)
        
        this.$vs.loading.close();

      }).catch((errr)=>{
        this.$vs.loading.close();
        this.permDocFormatError =errr;
       // this.formerrors.msg =errr
       // this.prefillJobDetailsError = errr
        //this.showToster({message:errr,isError:true });
        this.uploading = false;  
      });
    }

  },


    moveToTrash(val){
    if (val) {
      this.selectedPwdId = null;
      this.isLinkPwd = false;
    }
  },
    changePwdDoc(val){
    if(val){
      this.isLinkPwd = false;
      this.selectedPwdId = null;
    }
    this.setPwdFilled(true)
  },
  linkExistingPwd(val){
    if(val){
      this.isPwdFiled = false;
    }
  },
    assignPwdValue(val){
    if( val == 'havingPWD'){
      this.isPwdFiled = true;
      this.hasJobDetails  = true;
    }else{
      this.isPwdFiled = false;
      this.hasJobDetails  = false;
    }
    this.pwdStatus ='';
    this.resetPwdResponse();
   // this.hasJobDetails=false
    this.setJobDetails(false)
    this.selectedPwdId = null;
  },
  emitPwd(val){
    if(this.checkProperty(val,'_id')){
      this.selectedPwdId = val;
    }else{
      this.isLinkPwd = false;
      this.selectedPwdId = null;
    }
  },
    searchMe(){
      let self =this;
      clearTimeout(this.debounce)
        this.debounce = setTimeout(() => {
          self.page = 1;
          self.getbeneficiaries(true);
        }, 900)
    },
    conformDeleteBene(item ,statusId=0){
      this.selectedStatus = statusId
       this.popUpText  =''; 
       this.popUpTitle ='';
       if(this.selectedStatus ==2){
        this.popUpText  =' Are you sure Active this Beneficiary?'; 
        this.popUpTitle ="Active ";
       }
       if(this.selectedStatus ==3){
        this.popUpText  ='Are you sure Inactive this Beneficiary?';
        this.popUpTitle ="Inactive ";
       }

       if(this.selectedStatus ==4){
        this.popUpText  ='Are you sure Delete this Beneficiary?'; 
        this.popUpTitle =" Delete";
       }
       
        this.loading =false;
        this.deleteBeneficiaryPopup =true;
        this.selectedBeneficiaryItem = item;
        this.errorMsg ='';
    },
    deleteBeneficiary(statusId=0){
       let  postData = {};
       postData['userId'] =this.selectedBeneficiaryItem._id;
        postData['statusId'] = this.selectedStatus
        postData['statusName']= '';
        if(this.selectedStatus ==2){
          postData['statusName']  ='Active'
       }
       if(this.selectedStatus ==3){
        postData['statusName']  ='Inactive' 
       }

       if(this.selectedStatus ==4){
        postData['statusName']  ='Delete' 
       }
       let path ="users/manage-status"
          this.loading =true;
          this.$store.dispatch("commonAction", {"data":postData ,"path":path})
        .then(response => {
          this.showToster({message:response.message,isError:false });
          this.loading =false;
          this.deleteBeneficiaryPopup =false;
          this.selectedBeneficiaryItem =null;
          this.getbeneficiaries(true);    
          this.errorMsg ='';                            
        }).catch((error)=>{
          //this.showToster({message:error,isError:true });
          this.loading =false;
          this.errorMsg =error;
        })
      },
    classificationfun(){  
       let Payload ={
         "matcher": {
           "searchString":"",
           "typeIds": [3],//[3],
           "subTypeIds": [16],// [16],
           "classificationList":[],// ["EB3"],
           "petitionerIds": [],
           "beneficiaryIds": [],
           "statusIds": [],
           "createdDateRange": [],
           "premiumProcessing": []
         }
       }
      //  if(this.visatype.id && this.visasubtype.id){
      //    Payload["matcher"]["typeIds"] = [this.visatype.id];
      //    Payload["matcher"]["subTypeIds"] = [this.visasubtype.id];  
      //  }
      //  if(this.selectedPetitioner && _.has(this.selectedPetitioner,'_id')){
      //    Payload["matcher"]["petitionerIds"] = [this.selectedPetitioner._id]
      //  }
       if(this.selectedBeneficiary && _.has(this.selectedBeneficiary,'_id')){
         Payload["matcher"]["beneficiaryIds"] = [this.selectedBeneficiary._id]
       }
       if(this.classification){
         Payload["matcher"]["classificationList"] = [this.classification]
       }

       this.newPetitionFormSubmited =true;
          this.$store.dispatch("getList",{data:Payload ,path:'/petition-common/get-case-count'} )
           .then(response => {
             this.classificationResultList = response;
             
             if(this.classificationResultList>0){
              this.classificationpopup = true;
              this.newPetitionFormSubmited =false;
            }else{
              this.classificationpopup = false;
              this.newPetitionFormSubmited =false;
              this.createNewPetition(true)
            }
             
           }).catch((err)=>{
            this.classificationpopup = false;
            this.newPetitionFormSubmited =false;
           })
             
 
      
     },
     getCommonMessages(){
      let payLoad={
        "category": [ "COMMON_MESSAGES"]
      }
      this.$store.dispatch("commonAction", {"data":payLoad ,"path":"/messages/list"}).then((response)=>{
        if( _.has(response['messages']['COMMON_MESSAGES'] , 'i140DuplicateCase')){
          this.i140CreationMessage = response['messages']['COMMON_MESSAGES']['i140DuplicateCase']
        }
      }).catch((error)=>{})
    },
    getCategoryForCase(){
      let item ={
          matcher:{
           
          },   
          page:this.page,
          perpage: 10000,
          category: "case_category",  
      };
      this.$store.dispatch("getMasterData",item ).then(response => {   
        this.categoryList = response.list;   
       
      });
    },
    loadingFields(item){
      this.$refs['jobComponent'].checkVislibilty(item)
    },
    resetPrefedKyes(){
      // this.pwdStatus = ''
      this.disablePWDstatus = false
      let tempJobDetails = {
      wageRate: "",
      socOccuTitle: "",
      preferredSocOccuTitle:"",
      
      socCode: "",
            jobTitle: "",
            preferredSocCode: '',
      preferredSocCodeDetails:null,
            classification: "",
            description: "",
            skills: [],
            minDegree: '',
            majorFieldsOfStudy: "",
            expInYears: "",
            altJobRequirements: {

              // Are alternate sets of Education, Training, and/or Experience accepted? "Yes", "No"

              areAltSetsOfEducation:"",// { type: String},
              altevelOfEducation: null,//{ type: Schema.Types.ObjectId, default: null  }, //0bjectId
              altevelOfEducationDetails:null,
              usDiplomaOrDegreeAccepted:'', //{type: String},
              majorsOrFieldsOfStudyAccepted: '',//{type: String},
              isAltTrainingForTheJobOpporAccepted: '',//"Yes" Or "No"
              noOfMonthsOfAltTrainingAccepted: null,//{type: String},
              filedsOrNamesOfTrainingAccepted: "",//{ type: String },
              altEmpExpAccepted: "", //"Yes" Or "No"
              noOfMonthsAltEmpExpAccepted:null,
              splSkillOrOtherRequi:'',
              ForeignLanguage:'',
              LicenseCertification:'',
              residencyFellowship:'',
              otherSplSkillsOrRequi:''

              },
            workAddresses: [{
                "companyName": "",
                "line1" : "",
                "line2" : "",
                "aptType": "",
                "locationId" :'' ,
                "stateId" :'' ,
                "countryId" :'' ,
                "zipcode" : "",
                "locationDetails" : {
                    "id" : '',
                    "name" : "",
                    "stateId" : '',
                    "countryId" :'' 
                },
                "stateDetails" : {
                    "id" :'' ,
                    "name" : "",
                    "shortName" : "",
                    "countryId" : ''
                },
                "countryDetails" : {
                    "id" : 231,
                    "shortName" : "US",
                    "name" : "United States",
                    "phoneCode" : 1,
                    "order" : 1,
                    "currencySymbol" : "$",
                    "currencyCode" : "USD",
                    "zipcodeLength" : 5
                },
                "workLocation": true
            }]
        }
      _.forEach(this.jobDetails , (item ,key)=>{
            if(this.prefilledKyes.indexOf(key)>-1){
              this.jobDetails[key] = null;
              if(_.has(tempJobDetails , key)){
                this.jobDetails[key] = tempJobDetails[key];
              }else{
                this.jobDetails[key] = null;
              }
            }
        }); 
        
        if(  this.prefilledKyes.indexOf('issuedDate')>-1){
          this.pwdResponse['issuedDate'] = null;
        }
        if( this.prefilledKyes.indexOf('receivedDate')>-1){
          this.pwdResponse['receivedDate'] = null;
        }
        if( this.prefilledKyes.indexOf('dueDate')>-1){
          this.pwdResponse['dueDate'] = null;
        }
        if( this.prefilledKyes.indexOf('pwdDocCaseNo')>-1){
          this.pwdResponse['pwdDocCaseNo'] = null;
        }
        
        this.prefilledKyes =[];
        this.$validator.reset();

    },
    prefillJobDetails(){
      this.draftExtractInfo =null;
      var _dt;
      this.$validator.reset();
      this.pwdStatus = ''
      this.prefilledKyes =[];
    if(this.pwdResponse.documents.length>0){
    this.uploading = true;  
    let path ="/common/extract-data-from-pdf";
    let postData ={
      "docType": "pwd",
      documents:[],
    };
    //postData['documents'] = this.pwdResponse['documents']
    _.forEach(this.pwdResponse['documents'] ,(doc)=>{
      postData['documents'].push(doc.path)
        //return doc.path;
    })
    this.$store.dispatch('commonAction', {"data":postData ,"path":path})
        .then((response)=>{
          this.uploading = false;  
          let responseData = response['jobDetails'];
          this.draftExtractInfo =response;
          _.forEach(this.jobDetails , (item ,key)=>{
            if(_.has(responseData ,key) && responseData[key]){
             
              this.jobDetails[key] = responseData[key];
              this.prefilledKyes.push(key);


            }

          });
          _.forEach(this.pwdResponse , (item ,key)=>{
          if(_.has(responseData ,key) && responseData[key]){
            this.pwdResponse[key] = responseData[key];
            this.prefilledKyes.push(key);
          }

        });

          if(this.checkProperty(responseData,'pwdStatus')){
            this.pwdStatus = this.checkProperty(responseData,'pwdStatus')
            this.disablePWDstatus = true
            this.loadingFields(this.pwdStatus)
          }
          else{
            this.disablePWDstatus = false
          }

          var _self = this;

              setTimeout(function(){

                  if(_.has(responseData,'issuedDate')){
                  _self.pwdResponse['issuedDate'] = _.cloneDeep(responseData['issuedDate']);
                  }
                  if(_.has(responseData,'receivedDate')){
                  _self.pwdResponse['receivedDate'] = _.cloneDeep(responseData['receivedDate']);
                  }
                  if(_.has(responseData,'dueDate')){
                  _self.pwdResponse['dueDate'] = _.cloneDeep(responseData['dueDate']);
                  }

                  if(_.has(responseData,'pwdDocCaseNo')){
                  _self.pwdResponse['pwdDocCaseNo'] = _.cloneDeep(responseData['pwdDocCaseNo']);
                  _self.prefilledKyes.push('pwdDocCaseNo');
                  }

                  _self.jobDetails.workAddresses[0].stateDetails = responseData.workAddresses[0].stateDetails;
                  _self.jobDetails.workAddresses[0].stateId = responseData.workAddresses[0].stateId;


                },500)

                setTimeout(function(){
                  _self.jobDetails.workAddresses[0].locationId = responseData.workAddresses[0].locationId;
                  _self.jobDetails.workAddresses[0].locationDetails = responseData.workAddresses[0].locationDetails;
                },800)

          


          this.jobDetails =_.cloneDeep(this.jobDetails);
        }).catch((errr)=>{
          this.prefillJobDetailsError = errr
          //this.showToster({message:errr,isError:true });
          this.uploading = false;  
        });
      }

    },
   updateissuedDate(val){
      if(val){
        if(this.pwdResponse['receivedDate']){
        let startData = moment(val);
        let endData= moment(this.pwdResponse['receivedDate'])
        if(startData.isAfter(endData , 'day')){
          this.pwdResponse['receivedDate'] = null
        }
      }
      if(this.pwdResponse['dueDate']){
        let startDate = moment(val);
        let endDate= moment(this.pwdResponse['dueDate'])
        if(startDate.isAfter(endDate , 'day')){
          this.pwdResponse['dueDate'] = null
        }
      }
      }else{
        this.pwdResponse.dueDate = null  
      }
    },
    resetPwdResponse(fromInput=false){
    
      if(fromInput){

        this.pwdResponse['issuedDate'] = null;
        this.pwdResponse['receivedDate'] = null;
        this.pwdResponse['dueDate'] = null;
        this.pwdResponse['description'] = '';
        this.pwdResponse['pwdDocCaseNo'] = '';
        this.pwdResponse['documentType'] = "Original";

     
      }else{

        this.pwdResponse = {
        "issuedDate": null,
        "receivedDate": null,
        "dueDate": null,
        "description": "",
        "documents": [],
        "documentType": "Original",
        'pwdDocCaseNo':'',

      }
      }
    

  },
    setPwdFilled(callFromCheckBox=false){

      if(!callFromCheckBox){
        this.isPwdFiled = false;
        
      }
      this.pwdStatus ='';
      this.resetPwdResponse();
      this.hasJobDetails=false
      this.setJobDetails(false)
      this.hasJobDetails = this.isPwdFiled;
      this.$validator.reset();
    },
    setJobDetails(item){
      if(!item){
       this.jobDetails={
        wageRate:'',
        jobTitle: "",
        socCode:'',
        socCodeDetails:null,
        preferredSocCode: '',
        socOccuTitle: "",
        preferredSocOccuTitle:"",
        preferredSocCodeDetails:null,
        classification: "",
        description: "",
        skills: [],
        minDegree: '',
        majorFieldsOfStudy: "",
        expInYears: "",
        altJobRequirements: {

          // Are alternate sets of Education, Training, and/or Experience accepted? "Yes", "No"

          areAltSetsOfEducation:"",// { type: String},
          altevelOfEducation: null,//{ type: Schema.Types.ObjectId, default: null  }, //0bjectId
          altevelOfEducationDetails:null,
          usDiplomaOrDegreeAccepted:'', //{type: String},
          majorsOrFieldsOfStudyAccepted: '',//{type: String},
          isAltTrainingForTheJobOpporAccepted: '',//"Yes" Or "No"
          noOfMonthsOfAltTrainingAccepted: null,//{type: String},
          filedsOrNamesOfTrainingAccepted: "",//{ type: String },
          altEmpExpAccepted: "", //"Yes" Or "No"
          noOfMonthsAltEmpExpAccepted:null,
          splSkillOrOtherRequi:'',
          ForeignLanguage:'',
          LicenseCertification:'',
          residencyFellowship:'',
          otherSplSkillsOrRequi:''

          },
        workAddresses: [{
          "companyName": "",
          "line1" : "",
          "line2" : "",
          "aptType": "",
          "locationId" :'' ,
          "stateId" :'' ,
          "countryId" :'' ,
          "zipcode" : "",
          "locationDetails" : {
            "id" : '',
            "name" : "",
            "stateId" : '',
            "countryId" :'' 
          },
          "stateDetails" : {
            "id" :'' ,
            "name" : "",
            "shortName" : "",
            "countryId" : ''
          },
          "countryDetails" : {
            "id" : 231,
            "shortName" : "US",
            "name" : "United States",
            "phoneCode" : 1,
            "order" : 1,
            "currencySymbol" : "$",
            "currencyCode" : "USD",
            "zipcodeLength" : 5
          },
          "workLocation": true
            }]
           }
      }
    },
    checkBenPermStatus(){
      this.resetPermData();
      if(this.checkProperty(this.visasubtype,'id') != 15){
        this.isPwdFiled = false;
        this.setPwdFilled();
      }
      this.permDolDocs = [];
      this.responsePermId =''
      this.permDocRequired = false;
      this.formerrors.msg ='';
      this.enableSubmitBtn =true;
      this.Doc140Required =false,
      this.response140Id=''
      this.Dol140Docs=[];
      if(this.checkProperty(this.visatype,'id')== 3 &&
        this.checkProperty(this.visasubtype,'id')== 16 &&
        this.checkProperty(this.selectedBeneficiary ,'_id')){

          let postData={
            userId:this.checkProperty(this.selectedBeneficiary ,'_id')
          }
          this.$store.dispatch('commonAction', {"data":postData ,"path":"/perm/get-perm-filed-docs"})
          .then((response)=>{
            let responseData = response;

            

            if(this.checkProperty(responseData,'code') == "REQUIRED_PERM_DOCS"){
              this.permDocRequired  = true;
              this.enableSubmitBtn =true;
            }
            else{
              if(this.checkProperty(responseData,'permId')){
                if(  this.checkProperty(responseData,'permDocs','length')>0){
                  this.responsePermId = this.checkProperty(responseData,'permId')
                  this.permDolDocs =this.checkProperty(responseData,'permDocs');
                  this.enableSubmitBtn =true;
                } 
                else{  
                  this.formerrors.msg ="Unable to create the I-140 Case";
                  this.enableSubmitBtn =false;
                }
                if(this.checkProperty(responseData,'jobDetails','classification')){
                  this.classification = this.checkProperty(responseData,'jobDetails','classification')
                }
              }
              else{
                this.formerrors.msg ="Unable to create the I-140 Case";
                this.enableSubmitBtn =false;
              }
            }
          }).catch((error)=>{
            this.formerrors.msg = error;
            this.enableSubmitBtn =false;
          })
      }
      if(this.checkProperty(this.visatype,'id')== 3 && this.checkProperty(this.visasubtype,'id')== 17 && this.checkProperty(this.selectedBeneficiary ,'_id')){
      this.Dol140Docs =[];
      this.Doc140Required =false,
      this.formerrors.msg ='';
      this.enableSubmitBtn =true;
      let postData={
          userId:this.checkProperty(this.selectedBeneficiary ,'_id'),
          type:this.checkProperty(this.visatype ,'id') ,
          subType:this.checkProperty(this.visasubtype ,'id'),
        }
        this.$store.dispatch('commonAction', {"data":postData ,"path":"/petition/get-i140-filed-docs"})
        .then((response)=>{
          let responseData = response;
          if(this.checkProperty(responseData,'code') == "REQUIRED_DOCS"){
            this.Doc140Required  = true;
            this.enableSubmitBtn =true;
          }
          else{
            if(this.checkProperty(responseData,'i140Id')){
              if(this.checkProperty(responseData,'i140Docs','length')>0){
                this.response140Id = this.checkProperty(responseData,'i140Id')
                this.Dol140Docs =this.checkProperty(responseData,'i140Docs');
                this.enableSubmitBtn =true;
              } 
              else{  
                this.formerrors.msg ="Unable to create the I-485 Case";
                this.enableSubmitBtn =false;
              }
            }
            else{
              this.formerrors.msg ="Unable to create the I-485 Case";
              this.enableSubmitBtn =false;
            }
          }
        }).catch((error)=>{
          this.formerrors.msg = error;
          this.enableSubmitBtn =false;
        
        })
        
    }
    },
    upload(fils, category='') {
       this.draftExtractInfo =null;
       this.pwdDocFormatError ='';
       let  model =_.cloneDeep(fils);
       this.value =[];
       var _current = this;
       // this.$vs.loading();
 
       let efiles = [];
       efiles = _.filter(model, (e) => {
         return e.url != null && e.url != "";
       });
       let nfiles = _.filter(model, (e) => {
         return e.url == null || e.url == undefined;
       });
 
       let mapper = nfiles.map(
         (item) =>
           (item = {
             name: item.name,
             file: item.file ? item.file : null,
             url: item.url ? item.url : "",
             path: item.path ? item.path : "",
             status:
               item.status === false || item.status === true
                 ? item.status
                 : true,
             mimetype: item.type ? item.type : item.mimetype,
           })  
       );
       let tempFiles = [];
       if (mapper.length > 0) {
         this.uploading = true;
         let count = 0;
         mapper.forEach((doc, index) => {
          if((category == 'RFE' ||  category == 'PWD' || category =='permDocuments') && !( doc.mimetype=='application/pdf' )  ){
            this.pwdDocFormatError ="Upload only pdf documents";
            if(category =='permDocuments'){
                this.formerrors.msg = "Upload only pdf documents";
                this.permDocFormatError = "Upload only pdf documents";
            }
            
            this.uploading = false;
                       
            return false;

          }
           let formData = new FormData();
           formData.append("files", doc.file);
           formData.append("secureType", "private");
           formData.append("getDetails", true);
           count++;
 
           this.$store.dispatch("uploadS3File", formData).then((response) => {
             response.data.result.forEach((urlGenerated) => {
               //alert(JSON.stringify(urlGenerated))
               //  this.CommentPayload.documents.push(urlGenerated)
              // if (  _.has(urlGenerated, "name") &&  tempFiles.indexOf(urlGenerated["name"]) <= -1 ) {
                 tempFiles.push(urlGenerated["name"]);
                 if(category == 'RFE'){
                    this.rfeData['documents'] =[];
                    this.rfeData['documents'].push(urlGenerated);
                    this.prefillRfeNoticeDoc();
                  }
                 if(category == 'PWD'){
                  this.pwdResponse['documents'] =[];
                  this.pwdResponse['documents'].push(urlGenerated);
                  this.prefillJobDetails();
                  _current.$validator.reset();
                 
                 }
                 if(category == 'permDocuments'){
                  this.permDolDocs =[];
                  this.permDolDocs.push(urlGenerated);
                  this.prefillPermDocData();
                 }
                 if(category == '140Documents'){
                    this.Dol140Docs.push(urlGenerated);
                 }
                 
            //   }
               doc.url = urlGenerated;
               doc.path = urlGenerated;
               doc["mimetype"] = urlGenerated["mimetype"];
               doc["type"] = urlGenerated["mimetype"];
               delete doc.file;
               mapper[index] = doc;
               
             });
             if (index >= mapper.length - 1) {
               this.uploading = false;
               // _current.$vs.loading.close();
             }
           });
         });
         if (efiles.length > 0) efiles.push(...mapper);
         //this.CommentPayload["documents"] = efiles
       }
     },
    remove(item, data, filindex) {
      this.draftExtractInfo =null;
       data.splice(filindex, 1);
       this.disablePWDstatus = false
       

    },
  
    getvisaforNewCase(){


let item ={
    matcher:{
       // "searchString":this.searchtxt,
      
       getActiveList:true,

    },   
    page:1,
    perpage: this.perpage,
    category: "petition_types",
   
    
  };
  this.visatype =null;
  this.$store.dispatch("getMasterData",item ).then(response => {
      if([51].indexOf(this.loginRoleId)>-1){
          this.activeVisatypes = _.filter(response.list ,(item)=>{
         return item.id !=3
        })
        }else{
    this.activeVisatypes = response.list; 
        }
   
    if(this.checkProperty(this.activeVisatypes ,'length')>0){
      this.visatype = this.activeVisatypes[0];
      this.getvisasubtypes(this.visatype)



  }
  
  
  
  });

  this.setPwdFilled(false);

},
    migrateToIndividuals() {
     
      this.$validator.validateAll().then((result) => {
        this.moveToIndidualsErrorMsg = '';
        if (result) {
          let Payload={
            "userId":this.checkProperty(this.selectedIten,'_id')
           
          };
     this.$store.dispatch("commonAction", { "data": Payload,"path":"/users/migrate-to-individual"}).then((res) => {
       this.getbeneficiaries();

        this.moveToIndiduals = false;
        this.showToster({ message: res.message, isError: false });


      }).catch((error) => {
        this.formerrors.msg = error;
        //this.showToster({message:error,isError:true });
        this.selectedUser = null
      })
        }
      })
    },
    openMoveToIndiduals(action = false, selectedItem = null) {
      this.$validator.reset();
      this.selectedIten = selectedItem;
      this.moveToIndiduals = action;

      this.moveToIndidualsErrorMsg = "";
    },
    openInviteToCreateAccount(action = false, selectedItem = null) {
     
      this.inviteBeneficiary = action
      this.AddBeneficiary=action
      
      this.$validator.reset();
      this.selectedIten = selectedItem;
    },
    editMe(action = false, selectedItem = null) {
        this.selectedIten = selectedItem;
        if(this.checkProperty(this.selectedIten,'_id')){
          let routeId = this.checkProperty(this.selectedIten,'_id');
          this.$router.push({ name: "beneficiary-edit", params: { itemId: routeId } });
        }
    },
    // editMe(action = false, selectedItem = null) {
    //    this.editMode =false;
    //     this.selectedIten = selectedItem;
    //     let postData ={"userId":"", } 
    //     postData['userId'] = this.selectedIten['_id'];
    //     let path ="users/details"
    //     this.$store.dispatch("commonAction", {"data":postData ,"path":path}).then(response => {
    //     this.userDetails = response 
       
    //       // if(this.userDetails){
    //       //   this.AddBeneficiary=true;
    //       // }
    //       this.AddBeneficiary=action
    //       if(action){
    //         this.editMode = true
    //       }
    //     });

    // },
     showSetPassword(action =false ,selectedItem=null){
     
        this.newPassword ='';
        this.confPassword = '';
        this.$validator.reset();
        this.selectedIten = selectedItem;
        
        this.setPassword =action;
        
         this.setPasswordErrorMsg = "";
          

    },
   
       changePassword() {
      this.$validator.validateAll().then((result) => {
        this.setPasswordErrorMsg ='';
        if (result) {
           
           let self =this;
          let postData = {
            newPassword: self.newPassword,
            currentPassword: self.confPassword,
            userId: self.selectedIten['_id'],
            //email: this.loginUserData.email,
           // roleId: this.loginRoleId,
         
          };
          ///auth/change-password,
          this.updatingPassword =true;
          this.$store.dispatch("commonAction", {"data":postData ,"path":"/auth/change-password"}).then((response) => {
              this.showToster({message:response.message,isError:false });
           
              // this.$vs.notify({ text: response.data.message, });
              this.setPassword = false;
              this.formerrors.msg = null;
              this.updatingPassword =false;
            
          }).catch((error)=>{
               this.setPasswordErrorMsg = error;
              this.updatingPassword =false;
          })
        }
      });
      },

    resend(item){
        this.selectedIten = item;
        
        let obj = { "email": this.selectedIten['email'] ,"tenantId":''};
        obj['tenantId'] = this.checkProperty(this.loginUserData ,"tenantDetails","_id");
        this.$store
              .dispatch("resend", obj)
              .then(response => {
                //alert(JSON.stringify(response.data.message))
                   if (response.error) {
                  
                     this.showToster({message:response.error.message ,isError:true})
                } else {
                  this.showToster({message:response.data.message ,isError:false})
                  
                }
                
              })
              .catch((err)=>{
                this.showToster({message:err ,isError:true});

              });

      },
    openAddpetPopUp(){
      this.newPetOpenFromben =true;
      this.selectedPetitioner =null;
      this.invitepetitioner =true;
    },
    closenewPetPopup(selectedPetitioner=null){

   
       
      this.getPetitioners();
       this.selectedPetitioner =selectedPetitioner;
       this.invitePetitionPopupshow(false);
    
       if( this.checkProperty(this.selectedPetitioner ,"userId")){
          this.openNewbenFormPopup(true);
       }else{
         
          this.openNewbenFormPopup(false);
          

       }
     

    },
    upDateBenef(){
      if(this.checkProperty(this.selectedBeneficiary ,'name') && this.checkProperty(this.selectedBeneficiary ,'_id') ){
        this.selectedUser =this.checkProperty(this.selectedBeneficiary ,'_id');
        this.selectedUsername = this.checkProperty(this.selectedBeneficiary ,'name');
     }
     
     this.getBenficiaryH1BCases();

    },
   closeAddBenPopUp(selectedBeneficiary=null){
     this.newPetOpenFromben =false;
      this.AddBeneficiary =false;
      this.selectedBeneficiary =selectedBeneficiary;
     if(this.checkProperty(this.selectedBeneficiary ,'name') && this.checkProperty(this.selectedBeneficiary ,'_id') ){
        this.selectedUser =this.checkProperty(this.selectedBeneficiary ,'_id');
        this.selectedUsername = this.checkProperty(this.selectedBeneficiary ,'name');
     }
    this.AddBeneficiary =false;
    this.getBenficiaryH1BCases();
     this.getbeneficiaries();
   },
    opneDetails(tr){
      let itId = tr
      this.$router.push({ path: `/beneficiaries-details/${itId['_id']}` ,query: {'filter':this.encodedString} }).catch(err => {})
      //this.$router.push("/beneficiaries-details/"+tr['_id'])
    }, 
    petitionerUpdated(){
      this.selectedBeneficiary = null;
      this.selectedUser ='';
      this.selectedUsername = '';
      this.getbeneficiaryMasterDataList();
      this.getBenficiaryH1BCases();
    },
    getbeneficiaryMasterDataList(text=''){
      let postData = {
          "matcher": {
            "title": text,
            "statusList": [],
            "branchIds": [],
            "companyIds": [], // Required only for Tenant Admin and Branch Manager to list Beneficiaries
            "createdByIds": [],
            "createdDateRange": [],
            "roleIds": [51],
            "statusIds": [],
            "petitionTypeIds": [],
            "petitionSubTypeIds": [],
            "petitionCreatedDateRange": [],
            "petitionStatusIds": [],
            "getPetitionStats": true
          },
        "sorting": {
          "path": "createdOn", // invitedByName, updatedOn, name, email, phone, statusName, roleName
          "order": 1
        },
        "page": 1,
        "perpage": 1000000,
        "getMasterData": true,
        "getBeneficiaryList": true, // Required only for Tenant Admin and Branch Manager to list Beneficiaries
        "branchId": "", // Required when 'getMasterData' is true and roleIds are [4, 5, 6, 7, 8, 9, 10, 11]
        "companyId": "" // Required when 'getMasterData' is true and roleIds are [50, 51]
    };
  this.enableAddNewBenTag =false;
    if(this.checkProperty(this.selectedPetitioner ,"_id")){

      postData['companyId'] = this.selectedPetitioner['_id']

    }else if([50,51].indexOf(this.getUserRoleId)>-1 && this.checkProperty(this.getUserData ,"companyDetails" ,"_id")){

        postData['companyId'] = this.checkProperty(this.getUserData ,"companyDetails" ,"_id")
    }else{
       postData['matcher']['accountType'] = 'Individual';
    }
       //this.beneficiaryMasterDataList =[];
       this.$store
        .dispatch("petitioner/getbeneficiaries", postData)
        .then(response => {
          this.beneficiaryMasterDataList = response.list;

          let filteredData =[];
       _.forEach(this.beneficiaryMasterDataList ,(item)=>{
                if( item && ( _.has(item ,'name') || _.has(item ,'email')  )){

                         if((_.has(item ,'name') && item['name'].includes(text)) || (_.has(item ,'email') && item['email'].includes(text)) ){
                          filteredData.push(item)
                         }else{
                            return false;
                         }

                }else{
                  return false;
                }
              
           
         })

         if(filteredData.length<=0){
           this.enableAddNewBenTag =true;
         }


          })

    },

    addNewBenFromTag(newBen=''){
      this.beneficiary['email'] =newBen;
      this.invitePetitionPopupshow(false)
      this.openNewbenFormPopup(true);

    },

    

     searchPet(searchText){
          let _self =this;
     
      this.enableAddNewpet =false;
      this.selectedBeneficiary =null;
      this.selectedPetitioner =null;
      this.selectedUser ='';
      this.selectedUsername = '';
      this.newPetitioner.email =searchText;
      let filteredData =[];
       _.forEach(_self.petitionersList ,(item)=>{
                if( item && ( _.has(item ,'name') || _.has(item ,'email')  )){

                         if((_.has(item ,'name') && item['name'].includes(searchText)) || (_.has(item ,'email') && item['email'].includes(searchText)) ){
                          filteredData.push(item)
                         }else{
                            return false;
                         }

                }else{
                  return false;
                }
              
           
         })
       if( (filteredData.length<=0 )){

          //this.enableAddNewpet =true;
       // this   this.addNewPete = true;
         this.getPetitioners( true , searchText);
       }
         
     },
     addNewPet(newPet='' ,id){
       this.newPetOpenFromben =false;
       this.openNewbenForm =false;
       this.addNewPete =true;
       this.invitePetitionPopupshow(true)
     },

      updatePetitionerPhone(item) {
         
       this.isPetitionerPhoneValid =true;
      if (item.isValid) {
        
       this.newPetitioner.phoneCountryCode = {countryCode:item.countryCode,countryCallingCode:item.countryCallingCode};
       this.newPetitioner.phone = item.nationalNumber;
       
       Object.assign(this.formerrors , {msg:''});
       this.selectedPwdId = null;
          this.isLinkPwd = false;
          this.isPwdFiled = false;
      if(this.visatype && _.has(this.visatype ,"id")){
         this.visasubtypes =[];
        this.visasubtype = null;
       
      
          let item ={
            matcher:{
               // "searchString":this.searchtxt,
               "petitionType":parseInt(this.visatype['id']),
               getActiveList:true
  
            },   
            page:1,
            perpage: this.perpage,
            category: "petition_sub_types",
            
          };
  
          this.$store.dispatch("getMasterData",item ).then(response => { 
            this.visasubtypes = response.list
            // if(response['list']){
            //   this.visasubtypes = _.filter(response['list'] ,(item)=>{
            //  return item.id !=15
            // }) 
            // }
            if(parseInt(this.visatype['id'])==2 && this.checkProperty(this.visasubtypes, 'length') >0){
              this.visasubtype =this.visasubtypes[0];
              
            }
          });
          this.$validator.reset();
      }else{
        this.isPetitionerPhoneValid =false;
      }
     }
    },
     openNewbenFormPopup(action =false){
       this.saveBenbtn =false;
       if(action==true){
         this.invitePetitionPopupshow(false);
       }
       if(action){

         if(this.checkProperty(this.selectedPetitioner ,'userId')){
          
            this.AddBeneficiary =true;
            try{
              setTimeout(()=>{
                this.$refs['add_ben'].setPetDetails(this.selectedPetitioner)

              } ,50)
            }catch(e){}
          }else{
            this.$validator.validateAll('newpetitionform').then((res)=>{

            });
             this.AddBeneficiary =false;
          }

       }else{
          this.AddBeneficiary =action;

       }
       
      
       
       this.$validator.reset();
     },

     invitePetitionPopupshow(action =true){
    
       this.newPetitioner['name'] =  "";
       this.newPetitioner['adminFirstName'] =  "";
       this.newPetitioner['adminLastName'] =  "";
       this.newPetitioner['phoneCountryCode'] =  {countryCode:'',countryCallingCode:''};
       this.newPetitioner['roleId'] =  50;
       this.newPetitioner['phone'] =  "";
       this.newPetitioner['invite'] =  true;
       this.invitepetitioner=action;
      this.isPetitionerPhoneValid=true;
      this.$validator.reset();
      
     },
    
      

      getPetitioners(callFromSerch=false,searchText='' ) {
      
        this.enableAddNewpet =false
        let _self =this;
        if(this.callFromSerch){
         
         // this.petitionersList =[];
        }
        let query ={
          "matcher":{
            "searchString": searchText,
            "statusIds": [],
            "countryIds": [],
            "stateIds": [],
            "locationIds": [],
            "createdDateRange": []
          },
        "sorting": { 	"path": "createdOn", 	"order": 1 	},
        "page": 1,
        "perpage": 100,
        getMasterData:true
    }
       
      
        this.$store
          .dispatch("getList",{data:query ,path:'/company/list'} )
          .then(response => {
            
            _self.petitionersList = response.list;

            let filteredData =  _.filter(_self.petitionersList ,(item)=>{
                if( item&& ( _.has(item ,'name') || _.has(item ,'email')  )){

                         if((_.has(item ,'name')&& item['name'].includes(searchText)) || (_.has(item ,'email') && item['email'].includes(searchText)) ){
                           return true;
                         }else{
                            return false;
                         }

                }else{
                  return false;
                }
              
           
         })
       
        if( callFromSerch && (!filteredData || (filteredData && filteredData.length<=0 ))  ){
         
          this.enableAddNewpet =true;
          this.addNewPete = true;
        }
         
      
      
           
            //alert(this.perpage);
          }).catch((err)=>{
            this.petitionersList =[];
          })
      },
   
    gotoDetailsPage(petitionId='' ,subType=0){
     
     
      if(petitionId !=''){
        if([15].indexOf(subType)>-1){
          
          this.$router.push("/gc-employment-details/"+petitionId);
        
        }else{
          this.$router.push("/petition-details/"+petitionId);
        }
       
      }

    },
    sortMe(sort_key = "") {
       this.sortKey = {
            "path": "createdOn", // invitedByName, updatedOn, name, email, phone, statusName, roleName
            "order": 1
        }
      if (sort_key != "") {
        this.sortKeys[sort_key] = this.sortKeys[sort_key] == 1 ? -1 : 1;
        localStorage.setItem("tickets_sort_key", sort_key);
        localStorage.setItem("tickets_sort_value", this.sortKey[sort_key]);

        this.sortKey ={"path":sort_key ,"order":parseInt(this.sortKeys[sort_key])};
        this.getbeneficiaries();
      }
    },
    
    changedVsaType(item){
      this.filteredVisaSubTypes = [] ;
      this.allsubTyps =[];
      this.filteredVisaType =item;
      if(this.filteredVisaType && _.has(this.filteredVisaType ,"id")){
       this.allsubTyps =[];
     
     
    
        let item ={
          matcher:{
             // "searchString":this.searchtxt,
             "petitionType":parseInt(this.filteredVisaType['id'])

          },   
          page:1,
          perpage: 10000,
          category: "petition_sub_types",
          
        };

        this.$store.dispatch("getMasterData",item ).then(response => { this.allsubTyps = response.list;  });
       
        }
    },
     
    openNewPetitionPopUp(action=false ,item=null){ 

      this.permDocFormatError ='';
      this.disablePWDstatus = false;
      this.setPwdFilled(false);
      this.isPwdFiled = false;
      this.permDocRequired = false;
      this.permDolDocs = [];
      this.classification='';
      this.isLinkPwd = false;
      this.selectedPwdId = null;
      this.category = '';
      this.newPetOpenFromben =false;
      this.invitepetitioner =false;
      this.openNewbenForm =false;
      this.selectedPetitioner =null;
      this.selectedBeneficiary =item;
      if(this.checkProperty(this.selectedBeneficiary,'_id')){
        this.selectedBeneficiaryId = this.checkProperty(this.selectedBeneficiary,'_id')
      }
      //alert(JSON.stringify(this.selectedBeneficiary))
       if(this.checkProperty(item ,'petitionerDetails')){
          this.selectedPetitioner =item['petitionerDetails'];
          this.getbeneficiaryMasterDataList();

       }
      
      
       this.getPetitioners( true , '');
      
      this.visatype = {
        id: 1,
        name: "H-1B"
      }
           
      this.getvisaforNewCase();
      Object.assign(this.formerrors, {
                  msg: ''
                })
      this.newPetitionFormSubmited =false;
      this.NewPetition=action;
      if(this.NewPetition){
        this.$modal.show('benCaseCreationModal');
      }
      else{
        this.$modal.hide('benCaseCreationModal');
      }

      this.draftExtractInfo =null
      this.benficiaryH1BCases =[];
      this.documentUploading =false;
      this.rfeData = {
        rfeIssuedDate:null,
        rfeReceivedDate:null,
        rfeCaseUscisDeadlineDate:null,
        uscisReceiptNumber:'',
      rfeInternalCase:'internalCase',//'externalCase',//'internalCase',
      "documents":[],
      "docs":{
        "copyOfRfe":[],
        "orgPetition":[],
        "petitionerDocs":[],
        "employmentDocs":[],
        "beneficiaryDocs":[],
        "other":[]

       },
       h1bCaseId:null
      }
      
      this.getBenficiaryH1BCases()
      this.$validator.reset();
      },
    addNewBeneficiary(){
      this.newPetOpenFromben =false;
      this.invitepetitioner =false;
      this.openNewbenForm=false;
      this.beneficiary = {
      firstName:'',
      lastName:'',  
      name: "",
      email: "",
      phone:"",
      phoneCountryCode :{countryCode:'',countryCallingCode:''}
    }
    Object.assign(this.formerrors, {
                  msg: ''  });
   
    this.AddBeneficiary = true;
   this.$validator.reset();
   this.isPhoneValid =true;
   this.saveBenbtn =false;
   this.getPetitioners( true , '');

    },
    updatePhone(item) {
         
       this.isPhoneValid =true;
      if (item.isValid) {
        
       this.beneficiary.phoneCountryCode = {countryCode:item.countryCode,countryCallingCode:item.countryCallingCode};
       this.beneficiary.phone = item.nationalNumber;
       
      }else{
        this.isPhoneValid =false;
      }
     },

    getBranchList(){
       this.selectedBranch = null;
       this.branchList = [];
       let postData = {
         "filters":{
           "title":"",
            "createdDateRange":[],
            "statusList":[],
            "activeList":[]
          },
       "getMasterData":true,
       "page":1,
       "perpage":25000,
       "sorting":{"path":"createdOn","order":-1}
       }
       this.$store.dispatch("getList" ,{data:postData,path:"/branch/list"})
       .then(response => {
         this.branchList = response.list;
         if(this.branchList.length ==1){
           this.selectedBranch = this.branchList[0];
         }
       })
       .catch(error => {

       })

    },
    goto(Id){
     
          this.$router.push({ name: 'petition-details', params: { itemId:Id } }).catch(err => {})
    },
    fileNewCase(){
      this.pwdDocFormatError ='';
      if(this.checkProperty(this.visasubtype ,'id' )==15){
        this.createNewPerm()
      }else{

        this.createNewPetition(false)
      }

    },
    createNewPerm(){
      Object.assign(this.formerrors, {
                  msg: ''
                })

            this.$validator.validateAll('newpetitionform').then(result => {
        if (result) {
          let self =this;
          // premiumProcessing:this.premiumProcessing,
      var postdata ={
        type: this.visatype.id,
        userId:this.selectedUser,
        userName:this.selectedUsername,
        typeName:this.visatype.name,
        subType:this.visasubtype.id,
        subTypeName:this.visasubtype.name,
        petitionerId:null,
        branchId:'',
        today: moment().format('YYYY-MM-DD'),
        isPwdFiled:this.isPwdFiled,
        hasJobDetails:this.hasJobDetails
      };
      if(this.getTenantTypeId !=2){
        if([50].indexOf(this.loginRoleId) > -1){
           postdata['petitionerId'] = this.$store.state.user._id

        }else{
           postdata['petitionerId'] = this.checkProperty(this.selectedPetitioner ,"userId")
        }
       

      }

      // if(this.checkProperty(this.beneficiaryInfo ,"name") && this.beneficiaryId){
      //   postdata['userId'] = this.beneficiaryId;
      //   postdata['userName'] =this.beneficiaryInfo['name']

      // }
     
     
      if(this.selectedBranch && _.has(this.selectedBranch ,"_id")){
        postdata['branchId'] =this.selectedBranch['_id']
      }
      if(this.isPwdFiled){
        postdata['isPwdFiled'] = this.isPwdFiled
        if(!_.has(postdata ,'pwdResponse' )){
                postdata = Object.assign( postdata , {'pwdResponse':{}})
            }

            if(this.pwdResponse['pwdDocCaseNo']){
                postdata['pwdDocCaseNo'] = this.pwdResponse['pwdDocCaseNo'];
            }
           
        if(this.pwdStatus =='Certified'){
          postdata['pwdResponse']['documentType'] = "";

          if(this.pwdResponse['issuedDate']){
            postdata['pwdResponse']['issuedDate'] = moment(this.pwdResponse['issuedDate']).format("YYYY-MM-DD");
          }
          if(this.pwdResponse['receivedDate']){
            postdata['pwdResponse']['receivedDate'] = moment(this.pwdResponse['receivedDate']).format("YYYY-MM-DD");
          }

          if(this.pwdResponse['dueDate']){
            postdata['pwdResponse']['dueDate'] = moment(this.pwdResponse['dueDate']).format("YYYY-MM-DD");
          }
         
          postdata['pwdResponse']['description'] = this.pwdResponse['description'];

        }
        
        postdata['pwdStatus'] = this.pwdStatus;
        postdata['pwdResponse']['documents'] = this.pwdResponse['documents'];
        postdata['draftExtractInfo']= this.draftExtractInfo; 
      }
      if(this.isLinkPwd && this.checkProperty(this.selectedPwdId,'_id')){
        postdata['pwdId'] =  this.checkProperty(this.selectedPwdId, '_id')
      }
      if(this.hasJobDetails){
        postdata['hasJobDetails'] = this.hasJobDetails
        postdata['jobDetails'] = _.cloneDeep(this.jobDetails)
      }
      if(!this.newPetitionFormSubmited){
        this.newPetitionFormSubmited =true;

      
        this.$store.dispatch("commonAction", {"data":postdata ,"path":"/perm/create"})
        .then(response => {
              this.premiumProcessing = false;
                 if (response.error) {
                Object.assign(this.formerrors, {
                  msg: response.error.message
                });
                this.newPetitionFormSubmited =false;
              } else {

                   let dt ={
                  petitionId: response._id,
                  userName: this.selectedUsername,
                  email: this.selectedUseremail,
                  typeName: this.visatype.name,
                  subTypeName: this.visasubtype.id,
                  instructions: null
                }
              //   if(this.isLinkPwd  && this.checkProperty(this.selectedPwdId,'_id') && this.checkProperty(response,'caseNo') && this.checkProperty(response,'_id')){
              //   let obj={
              //     caseNo:this.checkProperty(response,'caseNo'),
              //     _id:this.checkProperty(response,'_id'),
              //   }
              //   this.linkPwd(obj)
              // }
                //this.addNewCase(false);
                        this.NewPetition =false; 
                         this.newPetitionFormSubmited =false;
                         this.getPetitioners();
                      //this.$vs.notify({title: "Success",text: response.message });

                        this.visatype = {
                        id: 1,
                        name: "H-1B"
                        }
                        this.getvisasubtypes(this.visatype);
                       this.showToster({message:response.message ,isError:false});
                       this.openNewPetitionPopUp(false);
                       setTimeout(()=>{
                         if(self.checkProperty(self.selectedBeneficiary ,"anonymousUser" )){
                          this.$router.push({ name: 'gc-employment-details', params: { itemId: response._id } }).catch(err => { })
                         }else{
                          this.$router.push({ name: 'gc-employment-details', params: { itemId: response._id } }).catch(err => { })
                          // this.clear_filter();

                         }
                          
                           
                       } ,10)

                      
                     
              }

        })
        .catch((error)=>{
          //this.showToster({message:error,isError:true});
          this.newPetitionFormSubmited =false;
         
          Object.assign(this.formerrors, {
                  msg: error
                });
        
        });

      }
      
      
 }else{
  const $ = JQuery;
              if($('.errorScroll .text-danger:visible')){

                  var _t = $('.errorScroll .text-danger:visible').first().parent().offset().top;

                  if(_t < 0) _t = -(_t)

                  $('.scrollable:visible').scrollTop(_t-50);

              }
             
 }

});
    },
    linkPwd(val){
    let self = this
    let postData ={
      caseNo:val['caseNo'],
      petitionIds :[val['_id']] ,
      comments:'',
      pwdId: self.checkProperty(self.selectedPwdId, '_id')
    };
    let path = "/pwd/manage-pwd-linking";
    this.$store .dispatch("commonAction", { "data": postData, "path": path }) .then(response => {
      this.showToster({ message: response.message, isError: false });
    }).catch((error) => {
     
    })
  },
    createNewPetition(callFromConform=false){
      Object.assign(this.formerrors, {
                  msg: ''
                })

            this.$validator.validateAll('newpetitionform').then(result => {
        if (result) {
          if(this.checkProperty(this.visasubtype ,'id' )==16 && !callFromConform  ){
          this.classificationfun();
          this.newPetitionFormSubmited =true;
          return false;
        }
          let self =this;
      var postdata ={
        type: this.visatype.id,
        userId:this.selectedUser,
        userName:this.selectedUsername,
        typeName:this.checkProperty(this.visatype, 'name'),
        subType:this.checkProperty(this.visasubtype, 'id'),
        subTypeName:this.checkProperty(this.visasubtype, 'name'),
        premiumProcessing:false,
        petitionerId:null,
        branchId:'',
        today: moment().format('YYYY-MM-DD'),
      };

      //h4 case sub types
      if(this.checkProperty(this.visatype,'id') == 2){
        postdata['subType'] = 12;
        postdata['subTypeName'] = '';
      }
      //h4 Ead  sub types
      if(this.checkProperty(this.visatype,'id') == 10){
        postdata['subType'] = 13;
        postdata['subTypeName'] = '';
      }

      if(this.checkProperty(this.visatype,'id') != 2){
        postdata['premiumProcessing'] =this.premiumProcessing
      }
      if(this.checkProperty(this.visatype,'id')== 3 && this.checkProperty(this.visasubtype,'id')== 16 &&
         this.checkProperty(this.permDolDocs,'length')>0 && this.classification !=''){
        postdata['classification'] = this.classification
        postdata['categoryId'] = this.checkProperty(this.category, 'id')
        postdata['permId'] = this.responsePermId

        if(this.permDocRequired){
        postdata['jobDetails'] = _.cloneDeep(this.permDetails);
       
        postdata['draftExtractInfo']= this.draftExtractInfo;
        
        }
        postdata['permDocs'] = this.permDolDocs

        
        
      }
      if(this.checkProperty(this.visatype,'id')== 3 && this.checkProperty(this.visasubtype,'id')== 17 &&
          this.checkProperty(this.Dol140Docs,'length')>0){
          postdata['i140Id'] = this.response140Id
          postdata['i140Docs'] = this.Dol140Docs
         
     }
      if(this.getTenantTypeId !=2){
        if([50].indexOf(this.loginRoleId) > -1){
           postdata['petitionerId'] = this.$store.state.user._id

        }else{
           postdata['petitionerId'] = this.checkProperty(this.selectedPetitioner ,"userId")
        }
       

      }
     
     
      if(this.selectedBranch && _.has(this.selectedBranch ,"_id")){
        postdata['branchId'] =this.selectedBranch['_id']
      }

       //rfe case creation
    if(this.checkProperty(this.visatype,'id')== 9){
      postdata['premiumProcessing'] =false;
       
      postdata['rfeIntExtOption'] =this.checkProperty(this.rfeData ,"rfeInternalCase" )  =='internalCase'?'internal':'filed_separately'
      postdata['documents'] = this.rfeData['docs'];
      if(this.checkProperty(this.rfeData ,"rfeInternalCase" )  =='internalCase'){
        postdata['h1bCaseId'] = this.checkProperty(this.rfeData ,"h1bCaseId"  ,"_id");  
        if(this.checkProperty(this.rfeData ,"rfeCaseUscisDeadlineDate")){
        postdata['rfeDueDate'] =moment(this.rfeData['rfeCaseUscisDeadlineDate']).format("YYYY-MM-DD");
        }

      }else {
        if(this.checkProperty(this.rfeData ,"rfeCaseUscisDeadlineDate")){
        postdata['rfeDueDate'] =moment(this.rfeData['rfeCaseUscisDeadlineDate']).format("YYYY-MM-DD");
        }
        if(this.draftExtractInfo ){
          postdata['draftExtractInfo']= this.draftExtractInfo;
        }
        postdata['uscisReceiptNumber']= this.checkProperty(this.rfeData ,"uscisReceiptNumber" ); 
        postdata['rfeIssuedDate']= this.checkProperty(this.rfeData ,"rfeIssuedDate" );  
        postdata['rfeReceivedDate']= this.checkProperty(this.rfeData ,"rfeReceivedDate" ); 

        if(this.checkProperty(this.rfeData ,"documents", 'length') >0 && this.checkProperty(this.rfeData ,"rfeInternalCase" )  !='internalCase'){
        postdata['documents']['copyOfRfe'] = this.rfeData['documents'];
      }
    }
      

    }


      if(!this.newPetitionFormSubmited){
        this.newPetitionFormSubmited =true;
        this.$store.dispatch("petitioner/createnewpetition", postdata)
        .then(response => {
          this.premiumProcessing = false;
                 if (response.error) {
                Object.assign(this.formerrors, {
                  msg: response.error.message
                });
                this.newPetitionFormSubmited =false;
              } else {

                   let dt ={
                  petitionId: response._id,
                  userName: this.selectedUsername,
                  email: this.selectedUseremail,
                  typeName: this.visatype.name,
                  subTypeName:this.checkProperty(this.visasubtype,'name'),
                  instructions: null
                }
                      this.$store.dispatch("petitioner/sendquestionnaire", dt).then(response => { })
                       this.NewPetition =false; 
                      //this.$vs.notify({title: "Success",text: response.message });
                       this.showToster({message:response.message ,isError:false});
                       this.openNewPetitionPopUp(false);
                       setTimeout(() =>{
                        
                         if(self.checkProperty(self.selectedBeneficiary ,"anonymousUser" )){
                             self.goto(response._id);
                         }else{
                            self.goto(response._id);
                          // this.getbeneficiaries();

                         }
                       },50)
                     
              }

        })
        .catch((error)=>{
          //this.showToster({message:error,isError:true});
          this.newPetitionFormSubmited =false;
         
          Object.assign(this.formerrors, {
                  msg: error.message
                });
        
        });

      }
      
      
        }else{
          const $ = JQuery;
              if($('.errorScroll .text-danger:visible')){

                  var _t = $('.errorScroll .text-danger:visible').first().parent().offset().top;

                  if(_t < 0) _t = -(_t)

                  $('.scrollable:visible').scrollTop(_t-50);

              }
             
 }

});
    },
    getbeneficiaries(callFromSerch=false) {
      this.callFromSerch = callFromSerch;

      if(this.callFromSerch){
            this.users  =[];
        }
  


      let postData ={
         matcher:{
            roleIds: [51],
            title: this.searchtxt,
            searchString: this.searchtxt,
            statusIds: this.final_selected_statusids,
            "petitionTypeIds": [],
            "petitionSubTypeIds": [],
            "petitionSearchString": "",
            "petitionCreatedDateRange": [],
            "petitionStatusIds": [], 
            "getPetitionStats": true,
            "beneficiaryType": "beneficiary-list", // beneficiary or individual-list or beneficiary-list,
            "companyIds":[],
            "createdDateRange":[],

         },
         sorting:this.sortKey,
         page: this.page,
         perpage: this.perpage,
         getBeneficiaryList:false
        

      }


      // if(this.checkProperty(this.$route ,'query' ,'filter')){
      //   try{
      //      let filter =this.$route['query']['filter']; this.checkProperty(this.$route ,'query' ,'filter')
      //     var actual = JSON.parse(atob(filter));
      //     let keys = Object.keys(actual);
      //     if(this.checkProperty(keys ,'length') >0){


      //       if(actual && (Object.keys(actual)).length>0 ){
      //       _.forEach(actual ,(item ,key) => {
      //           if(key=='matcher' ){
      //             if((Object.keys(item)).length>0 ){
      //               postData['matcher'] = item
      //             }
                
      //           }
               
      //           if(callFromSerch){
      //           if(key =='page' && item >0){
      //             postData['page'] = parseInt(item)
      //             this.page = parseInt(item)
      //           }
      //           if(key =='perpage' && item >0){
      //             postData['perpage'] = parseInt(item)
                  
      //             this.perpage = parseInt(item)
      //           }
      //           if(key=='sorting' ){
      //             if((Object.keys(item)).length>0 ){
      //               postData['sorting'] = item
      //             }
                
      //           }
      //         }
            
      //       })
      //     }
            
            
      //     }

      //   }catch(e){
           

      //   }
        
          
      // }



       
    
      if((this.selected_createdDateRange['startDate'] && this.selected_createdDateRange['startDate'] !=''  ) && (this.selected_createdDateRange['endDate'] !='' && this.selected_createdDateRange['endDate'] ) ){
        postData['matcher']['petitionCreatedDateRange'] = [this.selected_createdDateRange['startDate'], this.selected_createdDateRange['endDate']]

      }
      if((this.selected_normcreatedDateRange['startDate'] && this.selected_normcreatedDateRange['startDate'] !=''  ) && (this.selected_normcreatedDateRange['endDate'] !='' && this.selected_normcreatedDateRange['endDate'] ) ){
        postData['matcher']['createdDateRange'] = [this.selected_normcreatedDateRange['startDate'], this.selected_normcreatedDateRange['endDate']]

      }
      /*
      this.filteredVisaType =null;
      this.filteredVisaSubTypes = [] ; filteredVisaSubTypes
      */
      if(this.filteredVisaType && _.has(this.filteredVisaType ,"id")){
        postData['matcher']['petitionTypeIds'] = [this.filteredVisaType['id']];

      }

      if(this.filteredVisaSubTypes && this.filteredVisaSubTypes.length>0 ){
        postData['matcher']['petitionSubTypeIds'] = this.filteredVisaSubTypes.map((item)=>{return item['id']})

      }
      if(this.selectedPetitionerforFilter && this.selectedPetitionerforFilter.length>0 ){
        postData['matcher']['companyIds'] = this.selectedPetitionerforFilter.map((item)=>{return item['_id']})

      }
      postData['getBeneficiaryList'] =true;
      let tempObj={
        selectedPetitionerforFilter:this.selectedPetitionerforFilter,
        filteredVisaSubTypes:this.filteredVisaSubTypes,
        filteredVisaType:this.filteredVisaType,
        selected_statusids:this.selected_statusids,
        searchtxt:this.searchtxt,
        sortKey:this.sortKey,
        page: this.page,
        perpage: this.perpage,
      };
      if((this.selected_createdDateRange['startDate'] && this.selected_createdDateRange['startDate'] !=''  ) && (this.selected_createdDateRange['endDate'] !='' && this.selected_createdDateRange['endDate'] ) ){
        tempObj['petitionstartDate'] = this.selected_createdDateRange['startDate'];
        tempObj['petitionendDate'] = this.selected_createdDateRange['endDate']
      }
      if((this.selected_normcreatedDateRange['startDate'] && this.selected_normcreatedDateRange['startDate'] !=''  ) && (this.selected_normcreatedDateRange['endDate'] !='' && this.selected_normcreatedDateRange['endDate'] ) ){
        tempObj['normalstartDate'] = this.selected_normcreatedDateRange['startDate']
        tempObj['normalendDate'] =  this.selected_normcreatedDateRange['endDate']
      }
      this.setQueryString(tempObj);
   
     this.isListloading =true;
      this.updateLoading(true);
      this.$store
        .dispatch("petitioner/getbeneficiaries", postData)
        .then(response => {
          let tempList =response.list;
         // this.users = response.list;
          // _.forEach(response.list ,(item)=>{
          //   if(this.checkProperty(item ,'activePermCount') >0){
          //     item['activePetitionCount'] =item['activePetitionCount']+item['activePermCount'];
          //   }
          //   //totalPetitionCount
          //   if(this.checkProperty(item ,'totalPermCount')>0){
          //     item['totalPetitionCount'] =item['totalPetitionCount']+item['totalPermCount'];
          //   }

           

          //   if(!this.checkProperty(item ,'petitions' ,'length')>0){
          //     item['petitions'] =[];
          //   }

          //   if(this.checkProperty(item ,'perms' ,'length')>0){
          //     _.forEach(item['perms'] ,(permItem)=>{
          //       item['petitions'].push(permItem);


          //     });
          //     _.map(item['petitions'] ,(pitem)=>{
          //       if(_.has(pitem ,'createdOn')){
          //         pitem['createdOn'] = moment(pitem['createdOn']);
          //       }
          //       if(_.has(pitem ,'updatedOn')){
          //         pitem['updatedOn'] = moment(pitem['updatedOn']);
          //       }

          //     })
          //     item['petitions'] =  _.orderBy(item['petitions'] ,['createdOn'] , ['desc'])
          //   }
          //   //perms

          //   tempList.push(item);

          // });
          _.forEach(tempList ,(user)=>{
            user =  Object.assign(user ,{ "isTempAccount":false});
            if(_.has( user ,'email')){
              let parts = user.email.split("@");

              if(this.checkProperty(parts ,"length")>0){
              let domain = parts[(parts.length)-1]
              if(['temp-account.com'].indexOf(domain)>-1){
                user['isTempAccount'] =  true
              }

            }

            }

          });

    
          this.users = _.cloneDeep(tempList);
          this.totalCount = this.checkProperty(response, 'totalCount')
          this.totalpages = Math.ceil(response.totalCount / this.perpage);
          this.isListloading =false;
          this.updateLoading(false);
          setTimeout(() =>{
            this.updateLoading(false);
          } ,10)
          
        }).catch((err)=>{
         this.users = [];
           this.isListLoading =false;
           this.updateLoading(false);
           setTimeout(() =>{
            this.updateLoading(false);
          } ,10)
         
        })
    },
    filterQueryPreSelect(callFromMounted=false){
      if(this.checkProperty(this.$route ,'query' ,'filter')){
        try{
          let filter =this.$route['query']['filter']; this.checkProperty(this.$route ,'query' ,'filter')
          var actual = JSON.parse(atob(filter));
          let keys = Object.keys(actual);
          if(this.checkProperty(keys ,'length') >0 ){
            if(_.has(actual ,'page') && this.checkProperty(actual ,'page')){                                     
              this.page = this.checkProperty(actual ,'page');
            }
            if(_.has(actual ,'perpage') && this.checkProperty(actual ,'perpage')){                                     
              this.perpage = this.checkProperty(actual ,'perpage');
            }
            if(_.has(actual ,'sortKey') && this.checkProperty(actual ,'sortKey')){                                     
              this.sortKey = this.checkProperty(actual ,'sortKey');
              if(this.sortKeys){
                this.sortKeys[actual['sortKey']['path']] = actual['sortKey']['order']
              }
            }
            if(_.has(actual ,'selectedPetitionerforFilter') && this.checkProperty(actual ,'selectedPetitionerforFilter') && this.checkProperty(actual ,'selectedPetitionerforFilter', 'length')>0){                                     
              this.selectedPetitionerforFilter = this.checkProperty(actual ,'selectedPetitionerforFilter');
            }
            if(_.has(actual ,'filteredVisaSubTypes') && this.checkProperty(actual ,'filteredVisaSubTypes') && this.checkProperty(actual ,'filteredVisaSubTypes', 'length')>0){                                     
              this.filteredVisaSubTypes = this.checkProperty(actual ,'filteredVisaSubTypes');
            }
            if(_.has(actual ,'filteredVisaType') && this.checkProperty(actual ,'filteredVisaType') ){                                     
              this.filteredVisaType = this.checkProperty(actual ,'filteredVisaType');
            }
            if(_.has(actual ,'endDate') && this.checkProperty(actual ,'endDate') ){                                     
              this.selected_createdDateRange["endDate"] = this.checkProperty(actual ,'endDate');
            }
            if(_.has(actual ,'searchtxt') && this.checkProperty(actual ,'searchtxt') ){                                     
              this.searchtxt = this.checkProperty(actual ,'searchtxt');
            }
            if(_.has(actual ,'selected_statusids') && this.checkProperty(actual ,'selected_statusids') && this.checkProperty(actual ,'selected_statusids', 'length')>0){                                     
              this.selected_statusids = this.checkProperty(actual ,'selected_statusids');
            }
            if(_.has(actual ,'petitionstartDate') && this.checkProperty(actual ,'petitionstartDate') ){                                     
              this.selected_createdDateRange['startDate'] = this.checkProperty(actual ,'petitionstartDate');
            }
            if(_.has(actual ,'petitionendDate') && this.checkProperty(actual ,'petitionendDate') ){                                     
              this.selected_createdDateRange['endDate'] = this.checkProperty(actual ,'petitionendDate');
            }
            if(_.has(actual ,'normalstartDate') && this.checkProperty(actual ,'normalstartDate') ){                                     
              this.selected_normcreatedDateRange['startDate'] = this.checkProperty(actual ,'normalstartDate');
            }
            if(_.has(actual ,'normalendDate') && this.checkProperty(actual ,'normalendDate') ){                                     
              this.selected_normcreatedDateRange['endDate'] = this.checkProperty(actual ,'normalendDate');
            }
            this.set_filter();
          }else{
            this.set_filter();
          }
        }catch(e){
          if(callFromMounted){
            this.set_filter();
          }
        }   
      }
      else{
        this.set_filter();
      } 
    },
    setQueryString(obj){
      const string = JSON.stringify(obj) // convert Object to a String
      this.encodedString = btoa(string) // Base64 encode the String
      this.$route['query']['filter'] = this.encodedString;
    },
    savebeneficiary() {
      this.$validator.validateAll().then(result => {

        this.saveBenbtn =false;
        if (result) {
          let self =this;
          this.beneficiary = Object.assign(this.beneficiary,{"roleId":51});
          this.beneficiary['name'] =  this.beneficiary['firstName'].trim()+" "+this.beneficiary['lastName'].trim();
          this.beneficiary['firstName'] =  this.beneficiary['firstName'].trim();
          this.beneficiary['lastName'] =  this.beneficiary['lastName'].trim();
          this.beneficiary['name'] =  this.beneficiary['name'].trim();
          this.saveBenbtn =true;
          let postData = this.beneficiary;
          if(self.selectedPetitioner && _.has(self.selectedPetitioner ,"_id")){
              postData = Object.assign(postData,{ "companyId": self.selectedPetitioner['_id']})
          }
          this.$store
            .dispatch("beneficiaryregister", postData)
            .then(response => {
              this.saveBenbtn =false;
              if (response.error) {
                Object.assign(this.formerrors, {
                  msg: response.error.message
                });
              } else {
                this.AddBeneficiary =false;
                this.selectedBeneficiary =response.data['result']
                this.showToster({message:response.data.message,isError:false });
                this.openNewbenForm =false;
               // this.$router.go("/beneficiaries");
                this.getbeneficiaries();
              }

              // this.$router.go('/beneficiaries');
            })
            .catch((err)=>{
              this.saveBenbtn =false;
                //this.showToster({message:err,isError:true })
                Object.assign(this.formerrors, {
                  msg: err
                });

            });
        }
      });
    },

    get_statusids() {
      let postData = {
          page:1,
          perpage: 10000,
          category: "user_status",
         // tenantId: "5db7d79d6032453bd060ed9c",
        }

      this.$store.dispatch("getMasterData", postData).then(response => {
        this.all_statusids =  _.filter(response.list,function(i){
    return i['id']!=1;
});
      });
    },

    //get all_states
    get_all_states() {
      this.$store.dispatch("getstates", this.filtered_country).then(response => {
        this.all_states = response;
      });
    },
    getvisatypes(){
      this.$store.dispatch("getvisatypes").then(response => {
        this.visatypes = response;
      });
    },
    getvisasubtypes(vsType){
     
      
     
     Object.assign(this.formerrors , {msg:''});
     this.selectedPwdId = null;
        this.isLinkPwd = false;
        this.isPwdFiled = false;
    if(this.visatype && _.has(this.visatype ,"id")){
       this.visasubtypes =[];
      this.visasubtype = null;
     
    
        let item ={
          matcher:{
             // "searchString":this.searchtxt,
             "petitionType":parseInt(this.visatype['id']),
             getActiveList:true

          },   
          page:1,
          perpage: this.perpage,
          category: "petition_sub_types",
          
        };

        this.$store.dispatch("getMasterData",item ).then(response => { 
          this.visasubtypes = response.list
          // if(response['list']){
          //   this.visasubtypes = _.filter(response['list'] ,(item)=>{
          //  return item.id !=15
          // }) 
          // }
        });
        this.$validator.reset();
        }

        if(this.checkProperty(this.visatype ,"id") ==9){
          this.getBenficiaryH1BCases();
        }else{
          this.resetRfeData(true);
        }
        this.$validator.reset();
       
    },
    getAllLocations() {
      Object.assign(this.query, {
        countryId: this.filtered_country,
        stateId: this.singel_final_selected_state//this.final_selected_states //3922
      });

      this.$store.dispatch("getlocations", this.query).then(response => {
        this.all_locations = response;
      });
    },
    changedState(){
      this.singel_final_selected_state = '';
      this.final_selected_locations = [];
      this.singel_final_selected_state= this.seleted_states["id"];
      this.final_selected_states.push(this.seleted_states["id"]);
      this.getAllLocations();
    },
    multiple_changedState: function() {

      if (this.seleted_states.length > 0) {
        this.final_selected_states = [];
        for (let ind = 0; ind < this.seleted_states.length; ind++) {
          let current_index = this.seleted_states[ind];
          this.final_selected_states.push(current_index["id"]);
        }
        this.getAllLocations();
      } else {
        this.final_selected_states = [];
        this.final_selected_locations = [];
      }
    },
    set_filter: function() {
      this.final_selected_statusids = [];
      if (this.selected_statusids.length > 0) {
        this.final_selected_statusids = [];
        for (let ind = 0; ind < this.selected_statusids.length; ind++) {
          let current_index = this.selected_statusids[ind];
          this.final_selected_statusids.push(current_index["id"]);
        }
      }

      //states
      this.final_selected_states = [];
      if (this.seleted_states.length > 0) {
        this.final_selected_states = [];
        for (let ind = 0; ind < this.seleted_states.length; ind++) {
          let current_index = this.seleted_states[ind];
          this.final_selected_states.push(current_index["id"]);
        }
      }

     this.final_selected_locations = [];
      if (this.seleted_locations.length > 0) {
        for (let ind = 0; ind < this.seleted_locations.length; ind++) {
          let current_index = this.seleted_locations[ind];
          this.final_selected_locations.push(current_index["id"]);
        }
      }

      this.getbeneficiaries(true);
      this.$refs["filter_menu"].dropdownVisible = false;
    },
    clear_filter: function() {
      
      this.searchtxt ='';
      this.selected_statusids = [];
      this.final_selected_statusids = [];
      this.seleted_states = [];
      this.final_selected_states = [];
      this.singel_final_selected_state ='';
      this.seleted_locations = [];
      this.final_selected_locations = [];
      this.date = "";
      this.date_range = [];
      this.selected_country_obj='';

      this.selected_createdDateRange['startDate']=null;
      this.selected_createdDateRange['endDate']=null;
      this.selected_createdDateRange = [];
      this.selected_normcreatedDateRange['startDate']=null;
      this.selected_normcreatedDateRange['endDate']=null;
      this.selected_normcreatedDateRange = [];
      this.filtered_country = ''
      this.filteredVisaType =null;
      this.filteredVisaSubTypes = [] ;
      this.selectedPetitionerforFilter =[];
    
      this.$refs["filter_menu"].dropdownVisible = false;
       this.$router.push({ query: {} })
        this.getbeneficiaries();


    },
    pageNate(pageNum) {
      this.page = pageNum;
      this.getbeneficiaries(true);
    },
    selectCreatedDateRange(option) {
        option.startDate = moment(option.startDate).format("YYYY-MM-DD");
        option.endDate = moment(option.endDate).format("YYYY-MM-DD");
        this.selected_createdDateRange = [option.startDate, option.endDate];
      },
     
    changedCountry(){
      this.filtered_country = this.selected_country_obj['id'];
      this.get_all_states();
    }
  },
  mounted() {
    this.getEducationList();
    this.getMasterSocList();
    this.getCommonMessages();
    this.getCategoryForCase()
    this.getPetitioners();
    this.getvisaforNewCase();
    this.loginUserData = this.$store.state.user  // this.checkProperty(this.$store,'state','user');
    this.loginRoleId = this.$store.state.user.roleId //this.checkProperty(this.$store['state'],'user','roleId');
    this.sortKey = {
            "path": "createdOn", // invitedByName, updatedOn, name, email, phone, statusName, roleName
            "order": 1
        }

    this.sortKeys = {
      invitedByName:1,
      updatedOn:1,
      name:1,
      email:1,
      phone:1,
      statusName: 1,
      createdOn: -1,
      roleName:1,
      
    }
      let postData = {
        matcher: {},
        page:1,
        perpage: 1000,
        category: 'countries',
       
      }
      this.getBranchList();
    this.$store.dispatch("getMasterData" ,postData).then(response => {
      this.all_countries = response.list;
    });

    this.selected_statusids = [];
    this.final_selected_statusids = [];
    this.seleted_states = [];
    this.final_selected_states = [];

    this.seleted_locations = [];
    this.final_selected_locations = [];
    this.get_statusids();

    this.getvisatypes();
    this.getvisasubtypes();
    this.filterQueryPreSelect();
    //this.getbeneficiaries();
  }
};
</script>