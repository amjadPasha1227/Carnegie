<template >
  

<div class="tab-inner-content">
    <div class="tabs-content-panel tab-pad-wrap">
      <div class="card-panels">
        
        <vs-row vs-justify="center" >


        <vs-col class="p-0" type="flex" vs-justify="center" vs-align="center" vs-w="12">
            <div class="forms_letters">
              <vs-tabs>
                <vs-tab label="Documents"  >
                    <div class="main-list-wrap pad0">
                    <div  class="tab-inner-content">
                      <div class="doc_header pt-0 d" v-if="checkProperty( petition,'permDocs' ,'length')>0" >
                        <h3 class="small-header mart25"  >
                          <template >
                               Documents
                          </template>
                        </h3>
                            <div class="d-flex" v-if="false">   

                            <button   class="download_all">Download Documents</button>
                            </div>
                      </div>
                                                
                                              
                    <template   >
                        <div >
                        <vs-row  >
                            <vs-col class="padl0 padr0" v-if="checkProperty( petition,'permDocs' ,'length')>0">
                              <div class="card-panels pad0">
                                <vs-card>
                                <div slot="header" >
                                  <h3>PERM Documents</h3> 
                                  
                                </div>
                                <div>
                                  <div>
                                     <template v-for="(item ,ind ) in  petition['permDocs']" >
                                  
                                      <div class="documents__list" v-if="checkProperty( item,'status') !=false" v-bind:key="ind">
                                        <div class="documents__title" @click="downloadfile(item)">
                                          <figure> 
                                            <img v-if="checkFileFormat(item['mimetype']) =='pdf'" src="@/assets/images/main/pdf.svg" /> 
                                            <img v-else-if="checkFileFormat(item['mimetype']) =='video_mime_types'" src="@/assets/images/main/film.png" />
                                            <img v-else-if="checkFileFormat(item['mimetype']) =='msDoc'" src="@/assets/images/main/doc.svg" />
                                            <img v-else-if="checkFileFormat(item['mimetype']) =='zip'" src="@/assets/images/main/zip-file-format.png" />
                                            <img v-else-if="checkFileFormat(item['mimetype']) =='msPpt'" src="@/assets/images/main/ppt.svg" />
                                            <img v-else-if="checkFileFormat(item['mimetype']) =='msXl'" src="@/assets/images/main/xls.svg" />
                                            <img v-else-if="checkFileFormat(item['mimetype']) =='image'" src="@/assets/images/main/image.svg" />
                                            <img v-else src="@/assets/images/main/icon-img.svg" />
                                          </figure>
                                          <span>{{item.name}}</span>
                                        </div>
                                        <div class="documents__actions">
                                          <button @click="downloadfile(item)" class="view-btn">View</button>
                                        </div>
                                      </div>
                                    </template>
                                  </div>
                                </div>
                                </vs-card>
                              </div>
                            </vs-col>
                           <!------Edit Section-->
                            <vs-col class="padl0 padr0" v-if="editJobDetails && !checkProperty(petition ,'permId')">
                              <div class="card-panels pad0 perm_job_details">
                                <vs-card>
                                <div slot="header" >
                                  <h3>Job Details</h3> 
                                  
                                </div>
                                  <div class="vx-col  w-full form_section pl-0 pr-0 padt20"  >
                                    <form data-vv-scope="permJobDetailsform" @submit.prevent="" @keydown.enter.prevent="">
                                      <div class="form-container alt-rows-bg" @keyup="formerrorsMsg=''">
                                          <div class="vx-row">
                                              
                                          

                                                  <immiInput :display="true" :wrapclass="'vx-col md:w-1/2'" :required="true" :fieldsArray="questionnaireDetails" cid="permjobTitle" formscope="permJobDetailsform" v-model="jobDetails['jobTitle']"  fieldName="jobTitle" label="Job Title" placeHolder="Job Title" :maxLength="25" />
                                                  <immiInput :onlyNumbers="true" :wrapclass="'vx-col md:w-1/2'" :display="true" cid="permhoursPerWeek" :formscope="'permJobDetailsform'"  v-model="jobDetails.hoursPerWeek" :required="true" fieldName="hoursPerWeek" label="Hours per Week" placeHolder="Hours per Week"  :maxLength="3" />
                                                  <immiInput :onlyNumbers="true" :wrapclass="'vx-col md:w-1/2'" :display="true" cid="permwageRate" :formscope="'permJobDetailsform'" v-model="jobDetails.wageRate" :required="true" fieldName="wageRate" label=" Wage Rate" placeHolder="Wage Rate" :maxLength="10" />
                                                  <selectField :listContainsId="false" :wrapclass="'vx-col md:w-1/2'" :display="true" :required="true"  :formscope="'permJobDetailsform'" cid="permofferpayFrequency"  :optionslist="payFrequencyList" v-model="jobDetails.payFrequency"  fieldName="offerpayFrequency" label="Pay Frequency" placeHolder="Pay Frequency"   />  
                                                  <selectField :showOptionItemStatus="true" :wrapclass="'md:w-1/2'" :required="true"  cid="socCode"  :formscope="'permJobDetailsform'" :optionslist="masterSocList" v-model="jobDetails.socDetails" @input="updatesocCode"   fieldName="socCod" label="SOC Code" placeHolder="SOC Code "   />  


                                                  <selectField :wrapclass="'md:w-1/2'" :required="true"  cid="Education"  :formscope="'permJobDetailsform'" :optionslist="educationTypes" v-model="jobDetails.minDegreeDetails" @input="jobDetails.minDegree=jobDetails.minDegreeDetails['id']"   fieldName="Education" label="Minimum Education" placeHolder="Minimum Education"   />  
                                                    <immiInput  :wrapclass="'md:w-1/2'" :display="true" :cid="'majorFieldsOfStudy'" :formscope="'permJobDetailsform'"  v-model="jobDetails.majorFieldsOfStudy" :required="true" fieldName="majorFieldsOfStudy" label="Major Field of Study" placeHolder="Major Field of Study"   />
                                                    <immiInput :onlyNumbers="true" :allowFloatingPoint="false" :wrapclass="'md:w-1/2 custom_form_group'" :display="true" cid="expInYears" :formscope="'permJobDetailsform'"  v-model="jobDetails.expInYears" :required="true" fieldName="expInYears" label="Experience in Months" placeHolder="Experience"  :maxLength="5" />
        
                                                <template >
                                                <div class="vx-col w-full mt-2">
                                                <div class="skilladdsec">
                                                <label>Skills Required</label>
                                                <ul v-if="checkProperty(jobDetails ,'skills' ,'length' )>0">
                                                    <li v-for="(skil , index ) in jobDetails['skills']" :key="index">
                                                        <span class="skill-label">{{skil}}</span>                                  
                                                        <span  @click="removePermSkill(index)" class="row_btn">
                                                            <img src="@/assets/images/main/delete-row-img.svg">
                                                        </span>
                                                    </li>
                                                </ul>
                                                <div class="add-input-sec" >
                                                    
                                                    <div  @keyup="addSkill=true;skillTextError=false" class="skill-text" :class="{'skill-text-error':skillTextError}">
                                                        <immiInput @keyEnter="addSkill=true;skillTextError=false;addPermNewSkill()" :wrapclass="'w-full'"  :display="true" cid="addSkill" :formscope="'jobOpptInfo'"  v-model="newSkill" :required="false" fieldName="altAcceptExpInYears" placeHolder=""  />
                                                        <!-- v-if="addSkill" -->
                                                        <span   @click="addPermNewSkill()" class="add-more">Add</span>
                                                    </div>
                                                </div>
                                                </div>
                                                </div>
                                                </template>
                                                      <div class="vx-col  w-full mb-10">
                                                      <div class="form_group">
                                                      <label class="form_label">Description<em >*</em></label>
                                                      <!-- <vs-textarea name="perm-jobDescription" v-model="jobDetails.description" v-validate="'required'"  class="w-full" :data-vv-as="'Description'" /> -->
                                                      <ckeditor name="perm-jobDescription" v-model="jobDetails.description" v-validate="'required'"  class="w-full" :data-vv-as="'Description'"  :editor="editor" :config="editorConfig"></ckeditor>

                                                      <p v-show="errors.has('permJobDetailsform.perm-jobDescription')" class="text-danger text-sm"><em>* </em>Description is required</p>
                                                      </div>
                                                      </div>

                                                    <br>
                                                  <immiswitchyesno :display="true" :wrapclass="'vx-col md:w-1/2'" :fieldsArray="questionnaireDetails" :cid="'fullTimePosition'" formscope="fullTimePosition" v-model="jobDetails.fullTimePosition" fieldName="fullTimePosition" label="Is this a full-time position? " placeHolder="" />
                                                  <immiswitchyesno :display="true"  :wrapclass="'vx-col md:w-1/2'" :fieldsArray="questionnaireDetails" :cid="'permanentPosition'" formscope="permanentPosition" v-model="jobDetails.permanentPosition" fieldName="permanentPosition" label="Is this a permanent position? " placeHolder="" />
                                                  <immiswitchyesno v-if="false" :display="true"  :wrapclass="'vx-col md:w-1/2'" :fieldsArray="questionnaireDetails" :cid="'newPosition'" formscope="newPosition" v-model="jobDetails.newPosition" fieldName="newPosition" label="Is this a new position? " placeHolder="" />
                                                

                                              

                                                  <div class="vx-col w-full">


                                                  <div >
                                                  <h3 class="small-header">Address</h3>
                                                  <template v-for="(address ,index) in petition.jobDetails['workAddresses']">
                                                  <addressField :key="index" :display="true" :fieldsArray="questionnaireDetails" :disableCountry="petition.beneficiaryInfo.currentlyInUS" formscope="permJobDetailsform" :showaptType="true" :addFormContainerCls="false" :validationRequired="true" :countries="countries" v-model="jobDetails['workAddresses'][index]" :cid="'beneficiaryInfoaddress'+index" />
                                                  </template>
                                                  </div>
                                                  </div>


                                              
                                          </div>
                                      </div>

                                        <div v-show="formerrorsMsg">
                                        <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
                                        icon="IP-information-button" active="true">{{ formerrorsMsg }}</vs-alert>
                                        </div>

                                      <div class="popup-footer relative">
                                        <span v-if="updatingJobDetails" class="loader" ><img src="@/assets/images/main/loader.gif"  /></span>
                                        <vs-button  color="dark"  @click="editJobDetails = false ;setJobDetailsData();" class="cancel" type="filled" >Cancel</vs-button>
                                      <vs-button color="success" class="save" type="filled"  @click="updateJobDetails()">Update</vs-button>
                                      </div>

                                    </form>
                                  </div>
                                </vs-card>
                              </div>
                            </vs-col>
                        </vs-row>
                        </div>

                        <!-----Details Section-->
                      <div class="vx-col w-full p-0  " v-if="!editJobDetails && !checkProperty(petition ,'permId')">
                              <div class="dependent-block_wrap">
                                  <div class="dependent-block w-full">
                                      <div class="dependent-title">
                                          <h3>
                                              Job Details
                                          </h3>
                                          <span  class="edit__btn" v-if="!checkUscisIsCompleted" @click="editJobDetails =true" >
                                             <img src="@/assets/images/main/icon-edit.svg" />Edit
                                          </span>
                                      </div>
                                      <div class="dependent_details job_info_details"> 
                                          <ul>
                                            <!-- checkProperty(child,'consularProcessing') == true || checkProperty(child,'consularProcessing') == false " -->
                                              <li v-if="checkProperty(petition,'jobDetails','jobTitle')"> Job Title <span>{{checkProperty(petition,'jobDetails','jobTitle')}}</span></li>
                                              <li v-if="checkProperty(petition,'jobDetails','fullTimePosition')== true || checkProperty(petition,'jobDetails','fullTimePosition')== false">Full Time Position <span>{{checkProperty(petition,'jobDetails','fullTimePosition') | booleanFormat}}</span></li>
                                              <li v-if="checkProperty(petition,'jobDetails','hoursPerWeek')">Work Hours per Week <span>{{checkProperty(petition,'jobDetails','hoursPerWeek')}}</span></li>
                                              <li v-if="checkProperty(petition,'jobDetails','wageRate')">Wage Rate <span>{{checkProperty(petition,'jobDetails','wageRate') | formatprice}}</span></li>
                                              
                                              <li v-if="checkProperty(petition,'jobDetails','socDetails') && checkProperty(petition['jobDetails'],'socDetails' ,'name')">SOC Code Details <span>{{checkProperty(petition['jobDetails'],'socDetails' ,'name')}}<template v-if="checkProperty(petition['jobDetails'],'socDetails' ,'designation')"></template> ({{ checkProperty(petition['jobDetails'],'socDetails' ,'designation') }})</span></li>

                                              <li v-if="checkProperty(petition,'jobDetails','payFrequency')">Pay Frequency <span>{{checkProperty(petition,'jobDetails','payFrequency')}}</span></li>
                                              
                                              <li v-if="checkProperty(petition,'jobDetails','minDegree')">Minimum Education <span>{{checkProperty(petition,'jobDetails','minDegree') | formatML(highestDegreeList)}}</span></li>
                                            <li v-if="checkProperty(petition,'jobDetails','majorFieldsOfStudy')">Major Field of Study <span>{{checkProperty(petition,'jobDetails','majorFieldsOfStudy')}}</span></li>
                                            <li v-if="checkProperty(petition ,'classification')"> Classification <span>{{checkProperty(petition ,'classification')}}</span></li>
                                            <li v-if="checkProperty(petition ,'categoryDetails','name')"> Category <span>{{checkProperty(petition ,'categoryDetails','name')}}</span></li>
                                            <li v-if="checkProperty(petition,'jobDetails','expInYears')">Experience in Months <span>{{checkProperty(petition,'jobDetails','expInYears')}}</span></li>
                                              <li v-if="checkProperty(petition,'jobDetails','permanentPosition')==true || checkProperty(petition,'jobDetails','permanentPosition')==false"> Permanent Position<span>{{checkProperty(petition,'jobDetails','permanentPosition')| booleanFormat}} </span></li>
                                              <!-- <li v-if="checkProperty(petition,'jobDetails','newPosition')== true || checkProperty(petition,'jobDetails','newPosition')== false"> New Position<span>{{checkProperty(petition,'jobDetails','newPosition')| booleanFormat}} </span></li> -->
                                          </ul>
                                          <ul>
                                             <li class="w-full" v-if="checkProperty(petition['jobDetails'] ,'skills' ,'length')>0">Skills
                                            <ul class="default_list_items skills_list" >
                                                <li v-for=" (skil ,ind) in petition['jobDetails']['skills']" :key="ind">
                                                    <span>{{skil}}</span>
                                                </li>
                                            </ul>                                    
                                          </li>
                                          </ul>
                                          <ul v-for="(item,inder) in petition['jobDetails']['workAddresses']" :key="inder">
                                              <li v-if="item" class="w-full">Work Address <span v-html="$options.filters.addressformat(item)"></span>
                                              </li>
                                          </ul>
                                                             
                                      </div>
                                      <div class="editor_view_wrap" v-if="checkProperty(petition,'jobDetails','description')">
                                          <h3 class="sub-title">Job Description</h3>
                                          <div class="editor_view" v-html="petition['jobDetails']['description']"></div>
                                      </div>
                                  </div>
                              </div>
                                  
                      </div>
                    </template>
                    </div>
                    </div>   
                      

                </vs-tab>
              </vs-tabs>                

            </div>
        </vs-col>
        </vs-row>
      </div>
    </div> 
  </div>                             








  
    </template>
<script>
import FileUpload from "vue-upload-component/src";
import draggable from "vuedraggable";
import VuePerfectScrollbar from "vue-perfect-scrollbar";

import selectField from "@/views/forms/fields/simpleselect.vue";
import immiswitchyesno from "@/views/forms/fields/switchyesno.vue";

import addressField from "@/views/forms/fields/address.vue";

import _ from "lodash";

import immiInput from "@/views/forms/fields/simpleinput.vue";
import Vue from 'vue';
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';

export default {
  provide() {
        return {
            parentValidator: this.$validator,
        };
    },
    components: {
        FileUpload,
        draggable,
        VuePerfectScrollbar,
        selectField,
        immiswitchyesno,
        addressField,
        immiInput
    },
    mounted(){
      this.$store.dispatch("getmasterdata", "education_types").then((response) => {
          this.highestDegreeList = response;
      });
               
      this.$store.dispatch("getcountries").then((response) => {
                this.countries = response;

            });
            
      this.getMasterSocList();
     setTimeout(() => {
       this.setJobDetailsData();
     }, 10);
     this.getEducationList();
  
    },
    data() {
    return {
      skillTextError:false,
      newSkill:'',
      addSkill:true,
      educationTypes:[],
      highestDegreeList:[],
      editor: ClassicEditor,
 editorConfig: {
     toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
 },

      payFrequencyList: ["Hour", "Week", "Month", "Year"],
      updatingJobDetails:false,
      editJobDetails:false,
      formerrorsMsg:'',
      countries: [],
      uploaddocType: "",
      masterSocList:[],
      jobDetails: {
            socCode:'',
            socDetails:null,
            

            jobTitle: '',
            minDegreeDetails:null,
          minDegree:null,
          skills:[],
          majorFieldsOfStudy:'',
          expInYears:null,

            workAddresses: [
            {
                    line1: null,
                    line2: null,
                    aptType: null,
                    locationId: null,
                    locationDetails: null,
                    stateId: null,
                    stateDetails: null,
                    countryId: null,
                    countryDetails: null,
                    zipcode: null
                }
            ],

            fullTimePosition: false,

            hoursPerWeek: '',

            wageRate: '',

            payFrequency: 'Month', // Year, Month, Bi-Weekly, Week, Hour

            description: '',

            permanentPosition: false,

            newPosition: false

        },
    }},
    props: {
      questionnaireDetails:[],
      value:null,
        petition: {
            type: Object,
            default: null,
        },
        currentRole: null,
    },
    methods:{

      updatedexpInYears(){
        if(this.checkProperty( this.jobDetails, 'expInYears' )){
          this.jobDetails.expInYears = parseInt(this.jobDetails.expInYears);
        }
        

      }, 
    addPermNewSkill(){
      
      
            this.skillTextError =false;
            if(this.newSkill && this.newSkill.trim() !=''){

                let skil = this.newSkill.trim();
                if(this.jobDetails['skills'].indexOf(skil) <=-1){
                    this.jobDetails['skills'].push(skil);
                }

               
                this.newSkill ='';
                this.addSkill =false;
            }else{
                this.skillTextError =true;
            }
        },
        removePermSkill(index ){
            
            this.jobDetails['skills'].splice(index ,1);
           // this.$emit('input', this.value);
        },
      getEducationList(){
            this.$store
                .dispatch("getmasterdata", "education_types")
                .then((response) => {
                    this.educationTypes = response;

                   // this.jobDetails =  this.value['jobDetails']; minDegree minDegreeDetails
                   if(this.checkProperty(this.value,'jobDetails','minDegree')){
                    this.jobDetails['minDegreeDetails'] = _.find( this.educationTypes,  { "id":parseInt(this.value['jobDetails']['minDegree'])});

                   }
                                     
                })
                },


      updateJobDetails(){
        let path="/petition/update-job-details";
        this.$validator.validateAll('permJobDetailsform').then((result) => {
          if(result){
            let postData ={
              "petitionId": "",
              "typeName": "",
              "subTypeName":"",
              "jobDetails":{}

            }
            postData['petitionId'] = this.checkProperty(this.petition ,'_id');
            postData['typeName'] = this.checkProperty(this.petition ,'typeDetails' ,'name');
            postData['subTypeName'] = this.checkProperty(this.petition ,'subTypeDetails' ,'name');
            postData['jobDetails'] = this.jobDetails;
            this.formerrorsMsg = '';
            this.updatingJobDetails =true;
          this.$store.dispatch("commonAction", {"data":postData ,"path":path}).then((response) => {
              this.showToster({message:response.message,isError:false });
              this.formerrorsMsg = '';
              this.updatingJobDetails =false;
              this.$emit("updatepetition" ,'PERM-INFO');
              this.editJobDetails = false 
            
          }).catch((error)=>{
               this.formerrorsMsg = error;
              this.updatingJobDetails =false;
          })
          }


        });

      },
      setJobDetailsData(){
        setTimeout(() => {
          if(_.has(this.value ,'jobDetails')){
             // this.jobDetails =  this.value['jobDetails']; minDegree minDegreeDetails
              _.forEach(this.jobDetails, (item ,key)=>{
                if(_.has(this.value['jobDetails'],key)){
                  this.jobDetails[key] =_.cloneDeep(this.value['jobDetails'][key]);

                }

              });

              let addressItem ={
                            line1: null,
                            line2: null,
                            aptType: null,
                            locationId: null,
                            locationDetails: null,
                            stateId: null,
                            stateDetails: null,
                            countryId: null,
                            countryDetails: null,
                            zipcode: null
                        };
              if(!this.checkProperty( this.jobDetails ,'workAddresses' )  || this.checkProperty( this.jobDetails ,'workAddresses' ,'length')<=0){
                this.jobDetails['workAddresses'] = [addressItem];
              }


              let submitToUscisCompleted =false;
              if(this.checkProperty( this.value ,'completedActivities' ,'length') >0 && this.value['completedActivities'].indexOf('SUBMIT_TO_USCIS') >-1 ){
                submitToUscisCompleted =true;
              }
              if( !this.checkUscisIsCompleted && !this.checkProperty(this.jobDetails ,'jobTitle') && !submitToUscisCompleted  ){
                this.editJobDetails =true;
              }
          }
        }, 0);

      },
      updatesocCode(item){ 

      if(_.has( item ,'id')){
      this['jobDetails']['socCode'] = item['id'];
      }
      },
      getMasterSocList(){

      let query = {};
      query["page"] = 1;
      query["perpage"] = 10000;
      query["matcher"] = { 
         "getInactiveListAlso": true
        };
      query["category"] = "soc_codes";


      this.$store
      .dispatch("getMasterData", query)
      .then((response) => {
        this.masterSocList = response.list;



      //alert(this.perpage);
      })
      .catch(() => {
      this.masterSocList = [];

      });

      },
      downloadfile(value) {
      if(_.has(value ,"url" ) && !(_.has(value ,"path" ) )){
        value =Object.assign(value ,{ "path":value['url']})
      }else  if(_.has(value ,"path" ) && !(_.has(value ,"url" )) ){
        value =Object.assign(value ,{ "url":value['path']})
      }
      
      this.$emit('download_or_view' ,value);
      // value.url = value.url.replace(this.$globalgonfig._S3URL,"");
      // value.url = value.url.replace(this.$globalgonfig._S3URLAWS,"");
      // let postdata = { keyName: value.url };
      // this.$store.dispatch("getSignedUrl", postdata).then((response) => {
      //   window.open(response.data.result.data, "_blank");
      // });
    },
        selectDoctype(type = "") {
            this.uploaddocType = type;
        },
        upload(model, uploaddocType) {
      this.is_enablesavebtn = false;
      
      let temp_count = 0;
      this.uploaddocType = uploaddocType;
      let formData = new FormData();
      if (model.length > 0) {
        this.$vs.loading();
        model.forEach((doc) => {
          formData.append("files", doc.file);
          formData.append("secureType", "public");
          this.$store.dispatch("uploadS3File", formData).then((response) => {
           temp_count++;
            let docmnt = {
              mimetype: model[0]["file"]["type"],
              name: model[0]["file"]["name"],
              status: true,
              uploadedOn: new Date(),
              url: response["data"]["result"][0],
              path: response["data"]["result"][0],
              tempDoc:true
            };

            this.petition["documents"][this.uploaddocType].push(docmnt);
            this.is_enablesavebtn = true;
            if (temp_count >= model.length) {
                 
                  this.$vs.loading.close();
              }
          });
        });
      }
    },
    },
    computed:{
      checkUscisIsCompleted(){
        let returnVal =false;
        if(_.has( this.petition ,'completedActivities') && this.petition.completedActivities.indexOf('SUBMIT_TO_USCIS') >= 0){
          returnVal = true;
        }
        return returnVal;
      }
    }
}
</script>