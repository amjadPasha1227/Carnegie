<template>
  <div class="settings_right">
    <div class="card_section"  >
      <div class="card_section_in">
      <template>
      <stripe-payment @reload="reload" v-if="isPlansLoaded && isExistedPlansLoaded" @cancelop="cancelop"  :userplan="userplan" :selectedPlan="selectedPlan" :stripe="$globalgonfig.STRIPKEY" />
      </template>
    </div>
    </div>

   <template v-if="userplan && ( callFromSerch || list.length>0 )"> 

    <div class="content-header">
      <div class="content-header-left">
        <div class="search">
          <vs-input icon-pack="feather" icon="icon-search" v-model="searchtxt" placeholder="Search by Invoice No"
            class="is-label-placeholder" />
        </div>
      </div>
      <div class="content-header-right">
        <!--filter dropdown-->
        <vs-dropdown  vs-custom-content vs-trigger-click>
          <vs-button
            color="primary"
            class="filter-btn"
            type="border"
            icon-pack="feather"
            icon="icon-chevron-down"
            icon-after
          >
            <img src="@/assets/images/main/icon-filter.svg" /> Filters
          </vs-button>
          <vs-dropdown-menu ref="filter_menu" class="filters-content settings_filters">

            <div class="filters-form-fileds">
              <div class="form-container">
                <div class="vx-row">

                  
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Select Status</label>
                 
                    <multiselect v-model="selected_statusids" :options="invoice_status" :multiple="true" :hideSelected="true"
                      :close-on-select="false" :clear-on-select="false" :select-label="''" :preserve-search="true"
                      placeholder="Select Status" label="name" track-by="name" :preselect-first="false">
                      <!-- <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">{{ values.length }}
                          options selected</span>
                      </template> -->
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} options selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template> 
                    </multiselect>
                  </div>

                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Created Date</label>
                    <date-range-picker
                       :maxDate="new Date()"
                      :autoApply="autoApply"
                      :ranges="false"
                      v-model="selected_createdDateRange"
                    ></date-range-picker>
                  </div>
                 </div>
                   
                   
     
              </div>
            </div>
            <div class="filters-status">
              <div class="left-buttons">

              </div>
              <div class="right-buttons">
                <vs-button color="success" class="save" type="filled" v-on:click="set_filter()">Apply</vs-button>
                <vs-button color="dark" class="cancel" type="filled" v-on:click="clear_filter($event)">Clear
                </vs-button>
              </div>
            </div>
          </vs-dropdown-menu>
        </vs-dropdown>
        <!-- end -->
        <!-- <vs-button type="border" class="light-blue-btn" @click="createNew(true)">Add Card<span>
          <img class="add-user-icon ml-2" src="@/assets/images/main/add-user.svg">
        </span>
        </vs-button> -->

        
      </div>
    </div>

   
    <NoDataFound ref="NoDataFoundRef"  v-if="list.length == 0 && !callFromSerch" content="" heading="No Invoice  Found" type='Invoice List' />
    <NoDataFound ref="NoDataFoundRef"  v-if="list.length == 0 && callFromSerch" content="" heading="No Results Found" type='Invoice List' />

    <div class="accordian-table" v-if="list.length > 0">
      <vs-table :data="list" :no-data-text="'No data found..!'">
        <vs-tr>
                            <vs-th class="text-left">
                                <span @click="sortMe('refId')" v-bind:class="{
                      sort_ascending: sortKeys['refId'] == 1,
                      sort_descending: sortKeys['refId'] != 1,
                    }">Invoice No. 
                                </span>
                            </vs-th>

                            

                        <vs-th class="text-left" v-if="userRole && [1,2,3].indexOf(userRole)>-1" >
                                   <!-- <span @click="sortMe('email')" v-bind:class="{
                            sort_ascending: sortKeys['email'] == 1,
                            sort_descending: sortKeys['email'] != 1,
                        }">Email
                                    </span>
                                    refId
                                    -->
                                    Email
                                </vs-th>

                            <vs-th class="text-left">Plan</vs-th>
                            <vs-th>
                                <span @click="sortMe('totalAmount')" v-bind:class="{
                      sort_ascending: sortKeys['totalAmount'] == 1,
                      sort_descending: sortKeys['totalAmount'] != 1,
                    }">Amount
                                </span>
                            </vs-th>
                            <vs-th>
                                <span @click="sortMe('createdOn')" v-bind:class="{
                      sort_ascending: sortKeys['createdOn'] == 1,
                      sort_descending: sortKeys['createdOn'] != 1,
                    }">Created On
                                </span>
                            </vs-th>
                            <vs-th>Status</vs-th>
                            <vs-th></vs-th>
                        </vs-tr>
         <template v-if="list.length > 0">
                            <template v-for="(payment, index) in list">
                                <vs-tr :key="index">
                                    <vs-td>{{payment.refId}}</vs-td>
                                    <vs-td class="text-left" v-if="userRole && [1,2,3].indexOf(userRole)>-1" >
                                        {{checkProperty(payment , 'subscriberDetails' ,'email') }}
                                    </vs-td>
                                    <vs-td>
                                        <span v-if="payment.planDetails.criteria && payment.planDetails.criteria.length > 0 && payment.planDetails.criteria[0].qty!=0">{{payment.planDetails.criteria[0].qty}} </span>
                                        <span v-if="payment.planDetails.criteria && payment.planDetails.criteria.length > 0 && payment.planDetails.criteria[0].label!=null">{{payment.planDetails.criteria[0].label}}</span>
                                    </vs-td>
                                    <vs-td>${{payment.totalAmount}}</vs-td>
                                    <vs-td>{{payment.createdOn | formatDate}}</vs-td>
                                    <vs-td>
                                        <div class="d-flex align-items-center">
                                            <span class="td_status " :class="{'pending':payment.statusId==1,'paid':payment.statusId==2}">{{ checkProperty(payment ,'statusDetails' , 'name') }}</span>

                                        </div>
                                    </vs-td>
                                    <vs-td>
                                        <div class="menu_profile">
                                            <v-icon>mdi-dots-horizontal</v-icon>
                                            <div class="menu_list">
                                                <ul>
                                                    <li @click="downloadInvoice(payment)"><a>Download</a></li>
                                                    <!-- <li><a href="#">View</a></li>-->
                                                </ul>
                                            </div>
                                        </div>
                                    </vs-td>
                                </vs-tr>
                            </template>
                        </template>
      </vs-table>
      <paginate  v-if="list.length>0"  v-model="page" :page-count="totalpages" :page-range="3" :margin-pages="2" :click-handler="pageNate"
        prev-class="vs-pagination--buttons btn-prev-pagination vs-pagination--button-prev"
        next-class="vs-pagination--buttons btn-next-pagination vs-pagination--button-next" :prev-text="'<i></i>'"
        :next-text="'<i></i>'" :container-class="'pagination vs-pagination--nav'" :page-class="'page-item'"></paginate>
    </div>
  </template>


    

  
  </div>
</template>

<script>
import DateRangePicker from "vue2-daterange-picker";
  import Datepicker from "vuejs-datepicker-inv";
  import Paginate from "vuejs-paginate";
  import NoDataFound from "@/views/common/noData.vue";
  
import "vue2-daterange-picker/dist/vue2-daterange-picker.css";

  import _ from "lodash";
  import { FormWizard, TabContent } from "vue-form-wizard";
  import "vue-form-wizard/dist/vue-form-wizard.min.css";
   import moment from 'moment'
  import PhoneMaskInput from "vue-phone-mask-input";
  import JQuery from 'jquery'
  import { TheMask } from 'vue-the-mask'
  
import FileUpload from "vue-upload-component/src";
import VuePhoneNumberInput from 'vue-phone-number-input';
import 'vue-phone-number-input/dist/vue-phone-number-input.css';
import { MoreVerticalIcon } from 'vue-feather-icons';
import stripePayment from "@/views/subscription/stripe.vue";
  export default {
    computed:{
     
    },
    components: {
      stripePayment,
      NoDataFound,
      DateRangePicker,
      VuePhoneNumberInput,
      Datepicker,
      Paginate,
      FileUpload,
      FormWizard,
      TabContent,
      PhoneMaskInput,
      TheMask,
      MoreVerticalIcon
    },

    data: () => ({
      invoice_status:[],
        selectedPlan:null,
        isPlansLoaded:false,
        isExistedPlansLoaded:false,
         cardDetails: null,
         activeCardInfo:null,
        userplan:null,
        updatecard:false,
       
         newform: {name:'' ,type:'' , description:'',"document":null , attachments:[],"today":moment().format("YYYY-MM-DD")},
        edit:false,
        addPopup:false,
      callFromSerch:false,
      formSubmited:false, 
      uploading:false,
     
    selected_createdDateRange: ["", ""],
    autoApply: "",
        value:[],
        all_formTypes:[{"name":"Form" ,"id":"Form"},{"name":"Letter" ,"id":"Letter"} ],
        
    
      formerrors: {
        msg: ""
      },
      date: null,
      
      list: [],
      searchtxt: "",
      
      all_statusids: [],
      selected_statusids: [],
      date_range: [],
      page: 1,
      perpage: 25,
      totalpages: 0,
      

     
      switch2:true,
      users_status:{},
      edit:false,
      sortKeys:{},
      sortKey:{},
      planslist:[],
      invoice_company_list:[],
      callFromSort:false,
      dateRange:[],
     loading:false
    }),
    watch: {
      searchtxt: function (value) {
        this.getList(true);
      }

    },
    methods: {
         getplans() {
            let payLoad = {
                page: 1,
                perpage: 2500,
                today: moment(new Date()).format("YYYY-MM-DD"),
            };
             this.isPlansLoaded =false;
     
            this.$store.dispatch("subscription/getplans", payLoad).then((res) => {
               this.isPlansLoaded =true;

                this.planslist = res.list;
                if(this.checkProperty(this.planslist ,'length') >0){
                    this.selectedPlan = this.planslist[0];
                   
                }
                

            }).catch((err)=>{
               this.isPlansLoaded =true;
            })

        },
        cancelop(action=false) {
            
            this.addPopup = false;
        },
        getCardDetails() {
            //cardDetails
            this.activeCardInfo =null
            this.updatecard =false;
            var user = this.$store.state.user;
            let self =this; 

            let tenantDetails = self.checkProperty(user , "tenantDetails")
             let subscriber = {
                    name: self.checkProperty(tenantDetails , "adminName"),
                    email: self.checkProperty(tenantDetails , "adminEmail"),
                    phone: self.checkProperty(user , "phone"),
                    phoneCode: self.checkProperty(user , "phoneCountryCode" ,"countryCallingCode")
                } 
            var payLoad = {
                subscriber: subscriber,
                page: 1,
                perpage: 100,
                appActivity: true
            };
            this.$store.dispatch("subscription/cardDetails", payLoad).then((cardResponse) => {
                self.cardDetails = cardResponse.list;

                if(self.checkProperty( self.cardDetails ,"length") >0){
                    let latestCard = self.cardDetails[0];
                     if(self.checkProperty( latestCard ,"source" ,"card")){
                        self.activeCardInfo = latestCard['source']['card'];
                        self.updatecard  =true;
                     }
                      
                 }
             
            })
        },

        createNew(action=false){
              this.newform=  {name:'' ,type:'' , description:'',"document":null , attachments:[],"today":moment().format("YYYY-MM-DD")},
             this.addPopup = action

        },
     
      
      
      
      
      set_filter: function () {
        
        this.$refs["filter_menu"].dropdownVisible = false;
        this.getList(true);
      },
      clear_filter: function () {
        this.searchtxt ='';
        this.callFromSerch =false;
        this.$refs["filter_menu"].dropdownVisible = false;
        this.selected_statusids = [];
     
        this.date = "";
        this.date_range = [];
         this.selected_createdDateRange["startDate"] = "";
         this.selected_createdDateRange["endDate"] = "";
        this.getList();
      },
      pageNate(pageNum) {
        this.page = pageNum;
        this.getList();
      },

       getMaterData(category ='invoice_company_list') {
            let payLoad = {
                appActivity: true,
                matcher: {
                    title: "",
                    cntryIds: [],
                    stateIds: [],
                },
                category: category ,//"invoice_company_list", // "plan_type", //invoice_company_list, city, state, country, plan_category, plan_frequency, plan_operator, payment_service, plan_status, subscribe_status, invoice_status, user_role, user_status, company_status
                page: 1,
                perpage: 2500,
            };
            this.$store.dispatch("subscription/getMaterData", payLoad).then((res) => {
                this[category] = res.list;
               
            });
        },
         getList() {
            var self = this;
                let user = this.$store.state.user;
             let userRole = this.$store.state.userRole;
             //adminEmail
             let tenantDetails = self.checkProperty(user , "tenantDetails")
             let subscriber = {
                    name: self.checkProperty(tenantDetails , "adminName"),
                    email: self.checkProperty(tenantDetails , "adminEmail"),
                    phone: self.checkProperty(tenantDetails , "phone"),
                    phoneCode: self.checkProperty(tenantDetails , "phoneCountryCode" ,"countryCallingCode")
                }

            let obj = {
                appActivity: true,
                "filters": {
                    "companyId": "", // Send When view as 'Admin'
                    "title": this.searchtxt,
                    "statusIds": [],
                    "dueDateRange": [],
                    "paidDateRange": [],
                    "createdOnRange": []
                },
                page: this.page,
                perpage: this.perpage,
                //sortKeys: this.sortKey,
                sorting: this.sortKey
            };

            

            if (
        this.selected_createdDateRange["startDate"] &&
        this.selected_createdDateRange["startDate"] != "" &&
        this.selected_createdDateRange["endDate"] != "" &&
        this.selected_createdDateRange["endDate"]
      ) {
       obj["filters"]["createdOnRange"]= [
          moment(this.selected_createdDateRange["startDate"]).format("YYYY-MM-DD"),
          moment(this.selected_createdDateRange["endDate"]).format("YYYY-MM-DD")
        ];
      }

          // if ([1, 2, 3].indexOf(userRole) != -1) {

          //           obj["filters"]["companyId"] = this.invoice_company_list[0]['_id'];

          //       } else {
          //           obj["subscriber"] = subscriber

          //       }
           obj["subscriber"] = subscriber

            if (this.callFromSort) {
                this.callFromSort = false;
            } else {
                this.loading = true;
                this.callFromSort = false;
                this.list = [];

            }
          obj['filters']['statusIds'] =   this.selected_statusids.map((item)=>item._id)
          self.updateLoading(true);
            this.$store
                .dispatch("subscription/getList", {
                    data: obj,
                    path: "/invoices/list"
                })
                .then((response) => {
                    // alert(JSON.stringify(response));
                    this.list = response.list;
                    this.totalpages = Math.ceil(response.totalCount / this.perpage);
                   // this.totalpages = Math.ceil(response.totalCount / this.perpage);

                 
                
                   setTimeout(() => {
                       self.updateLoading(false);

                            setTimeout(() => {
                            self.updateLoading(false);
                        } ,10)
                   } ,10)
                })
                .catch((err) => {
                    //alert(err);
                    this.list = [];
                    setTimeout(() => {
                       self.updateLoading(false);
                   } ,10)
                });
        },
        getCurrentPlan(){
            this.userplan= null;
             var user = this.getUserData
             let self = this;
             let tenantDetails = self.checkProperty(user , "tenantDetails")
             let subscriber = {
                    name: self.checkProperty(tenantDetails , "adminName"),
                    email: self.checkProperty(tenantDetails , "adminEmail"),
                    phone: self.checkProperty(tenantDetails , "phone"),
                    phoneCode: self.checkProperty(tenantDetails , "phoneCountryCode" ,"countryCallingCode")
                }
             
            var payLoad = {
                    selPlanIds: [],
                    plans: [],
                    source: null,
                    serviceTypeId: 1,
                    methodTypeId: 1,
                    newSource: true,
                    subscriber: subscriber,
                    today: moment(new Date()).format("YYYY-MM-DD"),
                    timezone: moment.tz.guess(),
                    browserTS: moment(new Date())
                };
                 var chargepayload = payLoad;
                 this.isExistedPlansLoaded =false;
                this.$store.dispatch("subscription/getSelectedPlan", payLoad).then((currentPlan) => {
                   this.isExistedPlansLoaded =true;
                    if (currentPlan && this.checkProperty(currentPlan , 'length') >0 ) {
                        this.userplan=currentPlan[0];
                        this.$store.commit("subscription/updateCurrentPlan" ,this.userplan)
                        

                    }
                }).catch((err) => {
                   this.isExistedPlansLoaded =true;

                })    
             
        },
        init(){
          this.isPlansLoaded =false;
          this.isExistedPlansLoaded =false;

          //this.$store.dispatch("updateSidebarWidth", "extended");
       this.getplans();
      this.getCurrentPlan();
      this.getCardDetails();
     
     this.getMaterData('invoice_status');
     this.getMaterData('invoice_company_list');
     
      this.selected_statusids = [];
       this.sortKeys = {
            'name':1,
            'typeName':1,
            'statusName':1,
            "createdOn":-1,
            "updatedOn":1
     
    },
    //invoice_status

    this.sortKey = {"path":"createdOn" ,"order":-1};
    this.getList();
     

        },
        reload(){
        
         // this.init();
          this.isPlansLoaded =false;
          this.isExistedPlansLoaded =false;
            this.getCurrentPlan();
            this.getCardDetails();
          setTimeout(() => {
             this.isPlansLoaded =true;
             this.isExistedPlansLoaded =true;
             this.$store.dispatch("common/activateSettingTab", 'profile');
             this.$emit('startTour')
          } ,10)
        }
     
    },
    mounted() {
      this.init();

      
    }
  };
</script>
