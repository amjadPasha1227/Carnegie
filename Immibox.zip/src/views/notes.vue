<template>
  <div>
    <div class="content-header">
      <div class="content-header-left">
        <div class="search">
          <vs-input icon-pack="feather" icon="icon-search" placeholder="Search by Title" class="is-label-placeholder"
            v-model.lazy="searchtxt" />
        </div>
        <div class="con-select selection_search casetype" v-if=" !callFromExternal && !loadedFromCaseDetails && [51].indexOf(getUserRoleId) < 0">
          <multiselect  v-model="categoryType" :options="notesMasterList" :multiple="false"  @input="changeCategory"
            :close-on-select="true" :clear-on-select="false" :preserve-search="true" placeholder="Category"
            label="name" track-by="name" :preselect-first="false">

            <template slot="selection" slot-scope="{ values, isOpen }">
              <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }} Category(s)
                Selected</span>
              <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
            </template>
          </multiselect>
        </div>
      </div>
      <div class="content-header-right">
        <!--filter dropdown-->

        <vs-dropdown vs-custom-content vs-trigger-click v-if="!callFromExternal">
          <vs-button color="primary" class="filter-btn" type="border" icon-pack="feather" icon="icon-chevron-down"
            icon-after>
            <img src="@/assets/images/main/icon-filter.svg" /> Filters
          </vs-button>
          <vs-dropdown-menu ref="filter_menu" class="filters-content">
            <div class="filters-form-fileds">
              <div class="form-container">
                <div class="vx-row">
                  <div class="vx-col md:w-1/3 w-full con-select filters-search">
                    <label class="typo__label">Title</label>
                    <vs-input icon-pack="feather" icon placeholder="Search" class="is-label-placeholder"
                      v-model="filter_searchtxt" />
                  </div>

                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Tagged To</label>
                    <multiselect v-model="filterTaggedToIds" :options="taggedUsersList" :multiple="true"
                      :hideSelected="true" :close-on-select="false" :clear-on-select="false" :preserve-search="true"
                      placeholder="Select Tagged To" label="name" track-by="name" :preselect-first="false">
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          Users Selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>

                  <div class="vx-col md:w-1/3 w-full con-select" v-if="!callFromExternal && !loadedFromCaseDetails && [1].indexOf(this.getUserRoleId) <=-1 
                  && checkProperty(categoryType,'id') !=1">
                    <label class="typo__label">Cases</label>
                    <multiselect v-model="selectedPetions" :options="petitionList" :multiple="true"
                      :hideSelected="true" :close-on-select="false" :clear-on-select="false" :preserve-search="true"
                      placeholder="Select Cases" label="name" track-by="name" :preselect-first="false">
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          Cases Selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>

                  

                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Status</label>
                    <multiselect v-model="selected_statusids" :options="all_statusids" :multiple="true"
                      :hideSelected="true" :close-on-select="false" :clear-on-select="false" :preserve-search="true"
                      placeholder="Select Status" label="name" track-by="name" :preselect-first="false">
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          Status Selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>

                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Access Level</label>
                    <multiselect v-model="filterAccessLevels" :options="accessLevelList" :multiple="true"
                      :hideSelected="true" :close-on-select="false" :clear-on-select="false" :preserve-search="true"
                      placeholder="Select Access Level" label="name" track-by="name" :preselect-first="false">
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          Access Level Selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>

                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Created Date</label>
                    <date-range-picker :maxDate="new Date()" :autoApply="autoApply" :ranges="false"
                      v-model="selected_createdDateRange"></date-range-picker>
                  </div>
                </div>
              </div>
            </div>
            <div class="filters-status">
              <div class="left-buttons"></div>
              <div class="right-buttons">
                <vs-button color="success" class="save" type="filled" v-on:click="set_filter()">Apply</vs-button>
                <vs-button color="dark" class="cancel" type="filled" v-on:click="clear_filter($event)">Clear</vs-button>
              </div>
            </div>
          </vs-dropdown-menu>
        </vs-dropdown>
        <!-- end -->
        <vs-button v-if="checkCreateButton" type="border" class="light-blue-btn" @click="
           
            AddNewNote = true;
            resetNewNote();
             $modal.show('newNoteModal');
          ">Create Note
          <span>
            <img class="add-user-icon ml-2" src="@/assets/images/main/add-user.svg" />
          </span>
        </vs-button>
      </div>
    </div>

    <NoDataFound ref="NoDataFoundRef" v-if="tickets.length <= 0" content="You haven't created/recevied any notes."
      :loading="isListLoading" heading="No Notes Found" type="support" />

    <div class="notes_section"  :class="{'grap-bg':loadedFromCaseDetails }"  v-if="tickets.length > 0">
      <div>
        <div class="notes_list_wrap">
          <template>
            <div class="notes_list" v-for="(ticket, tindex) in tickets" :key="tindex">
              <div class="notes_info">
                <h4 @click="gotTdetails(ticket)">{{ ticket.title }}</h4>
                <p>
                  <span class="cursor-pointer" @click="gotTdetails(ticket)" v-html="ticket.description">
                    <!-- {{ ticket.description }}  --></span>
                </p>
                <ul>
                  <li>
                    <label>Created By </label>
                    <p>
                      {{ checkProperty(ticket, "createdByName") }}
                      <template v-if="checkProperty(ticket, 'createdByRoleName')">({{
                        checkProperty(ticket, "createdByRoleName")
                        }})</template>
                    </p>
                  </li>
                  <li>

                    <label>

                      <img v-if="checkProperty(ticket ,'accessLevelId') ==1" src="@/assets/images/main/lock.svg" />
                      <img v-else src="@/assets/images/main/public.svg" />

                      {{
                      checkProperty(ticket, "accessLevelDetails", "name")
                      }}
                    </label>
                  </li>
                  <li v-if="
                      checkProperty(ticket, 'taggedToDetails', 'length') > 0 &&
                      checkProperty(ticket, 'accessLevelId') == 3
                    ">
                    <label>Tagged To </label>
                    <p v-if="
                        checkProperty(ticket, 'taggedToDetails', 'length') > 0
                      " v-on:click.stop.prevent="showTaggedDetails(true, ticket)">
                      {{
                      checkProperty(ticket, "taggedToDetails", "length")
                      }}
                      Member(s)<img src="@/assets/images/main/eye.png" width="15px" />
                    </p>
                  </li>
                  <li @click="goToCaseDetails(ticket)" class="cursor" v-if="checkProperty(ticket ,'petitionDetails', 'caseNo') && !loadedFromCaseDetails && !callFromExternal" >
                    <label>Case  </label>
                    <p>
                      {{ checkProperty(ticket['petitionDetails'], "caseNo") }}

                    </p>
    

                  </li>
                </ul>
              </div>
              <div class="notes_status_sec">

                <span class="notes_status cursor-pointer" :class="
                    getCalssName(checkProperty(ticket, 'statusDetails', 'name')) 
                  "><span @click="gotTdetails(ticket)" class="cursor-pointer"> {{ checkProperty(ticket,
                    "statusDetails", "name") }} </span></span>
                <label v-if="checkProperty(ticket, 'updatedOn')" @click="gotTdetails(ticket)"
                  class="cursor-pointer">Last Updated
                  <strong>
                    {{ ticket.updatedOn | formatDateTime }}
                  </strong>

                </label>
                <label v-else @click="gotTdetails(ticket)" class="cursor-pointer">
                  Created On
                  <strong>
                    {{ ticket.createdOn | formatDateTime }}
                  </strong>
                </label>


              </div>
            </div>
          </template>
        </div>
      </div>
        <div class="table_footer pt-4" v-if="totalCount> perpage && page">
        <div class="vx-col con-select pages_select" v-if="tickets.length > 0">
          <label class="typo__label">Per Page</label>
          <multiselect @input="changeperPage()" v-model="perpage" :options="perPeges" :multiple="false"
            :close-on-select="true" :clear-on-select="false" :preserve-search="true" placeholder="Per Page"
            :preselect-first="true">
          </multiselect>
          <span class="totla_list_count" v-if="totalCount"> Total <em>{{totalCount}}</em></span>
        </div>

        <paginate v-if="tickets.length > 0" v-model="page" :page-count="totalpages" :page-range="3" :margin-pages="2"
          :click-handler="pageNate" prev-class="vs-pagination--buttons btn-prev-pagination vs-pagination--button-prev"
          next-class="vs-pagination--buttons btn-next-pagination vs-pagination--button-next" :prev-text="'<i></i>'"
          :next-text="'<i></i>'" :container-class="'pagination vs-pagination--nav'" :page-class="'page-item'">
        </paginate>
      </div>
    </div>

    <vs-popup class="holamundo main-popup taggedlistmodal" :title="'Tagged To'" v-if="taggedModal"
      :active.sync="taggedModal">
      <div class="taggedlist">
        <VuePerfectScrollbar
            ref="mainSidebarPs"
            class="scroll-area--main-sidebar height_tagged"
            :settings="settings"
            @ps-scroll-y="psSectionScroll"
          >
        <ul>
          <template v-for="(member, index) in noteTaggedToDetails">
            <li :key="index">

              <figure>

                <img :src="checkProperty(member ,'profilePicture')" @error="setDefaultPhoto($event)" />
              </figure>
              <figcaption>
                {{ checkProperty(member, "name")
                }}<span>{{ checkProperty(member, "roleName") }}</span>
              </figcaption>
              <em
                v-if="!callFromExternal && ( checkProperty(selectedNote,'createdBy') == checkProperty(getUserData,'userId')) &&checkProperty(selectedNote,'statusDetails','id') !=4 && checkProperty(selectedNote,'statusDetails','id') !=5 && checkProperty(selectedNote,'statusDetails','id') != 2"
                class="remove" @click="deleteTaggedMember(member['_id'])"><img
                  src="@/assets/images/main/delete-row-img.svg" /></em>
            </li>
          </template>
        </ul>
        </VuePerfectScrollbar>
      </div>
    </vs-popup>
    <!----- updateStatusPopup :false,
    nweStatus:{

        "noteId": '',
		"statusId": '',
		"statusName": "",
		"comment": "" 

     }-->

    <modal name="newNoteModal" classes="v-modal-sec" :min-width="200" :min-height="200" :scrollable="true" :reset="true"
      width="600px" height="auto">
      <div class="v-modal" @click="taggedUserchText = ''">
        <div class="popup-header fromDetailsPage">
          <h2 class="popup-title">
            {{ editTicket ? "Edit Note" : "Create Note" }}
          </h2>
          <span @click="$modal.hide('newNoteModal')">
            <em class="material-icons">close</em>
          </span>
        </div>
        <form>
          <div class="form-container pb-0">
            <div class="vx-row">
              <div class="vx-col w-full">
                <div class="form_group">
                  <label class="form_label">Title<em>*</em></label>
                  <vs-input v-model="newNote.title" name="title" v-validate="'required'" class="w-full"
                    data-vv-as="Title" />
                  <span class="text-danger text-sm" v-show="errors.has('title')">{{ errors.first("title") }}</span>
                </div>
              </div>
              <div class="vx-col w-full">
                <div class="form_group">
                  <label class="form_label">Description<em>*</em></label>
                    <ckeditor class="w-full" v-model="newNote.description" v-validate="'required'"
                    data-vv-as="Description" name="description" :editor="editor" :config="editorConfig"></ckeditor>
                  <span class="text-danger text-sm" v-show="errors.has('description')">{{ errors.first("description")
                    }}</span>
                </div>
              </div>
            </div>
            
             <div class="vx-row" v-if="!callFromExternal && !loadedFromCaseDetails && [1].indexOf(this.getUserRoleId) <=-1">
              
                <div class="vx-col w-100"   >
                  <div class="form_group">
                    <label class="form_label">Category<em>*</em></label>
                      <div class="con-select w-full">
                    
                        <multiselect
                          name="category"
                          v-model="newNote.selectedcategory"
                          :options="notesMasterList"
                          :multiple="false"
                          :close-on-select="true"
                          :clear-on-select="false"
                          :preserve-search="true"
                          placeholder="Select Category"
                          label="name"
                          track-by="_id"
                          :preselect-first="false"
                          data-vv-as="Category"
                          v-validate="'required'"
                          @input="taggedUsersList=[];newNote.taggedTo=[];getMyPetitions(true); $validator.reset();gettaggedUsersList()"
                          
                        
                        > 
                          <template slot="selection" slot-scope="{ values, isOpen }">
                            <span
                            class="multiselect__selectcustom"
                            v-if="values.length && !isOpen"
                            >{{ values.length }} Category(s) Selected</span
                            >
                            <span
                            class="multiselect__selectcustom"
                            v-if="values.length && isOpen"
                            ></span>
                          </template>
                        </multiselect>
                    
                        <span   class="text-danger text-sm" v-show="errors.has('category')"  >{{ errors.first("category") }}</span
                    >
                      </div>
                  </div>
                </div>

                <div class="vx-col w-100" v-if="checkProperty(newNote ,'selectedcategory' ,'id') ==2 || checkProperty(newNote ,'selectedcategory' ,'id') ==3" >
                  <div class="form_group">
                    <label class="form_label">Case<em>*</em></label>
                      <div class="con-select w-full">
                    
                        <multiselect
                          name="Case"
                          v-model="newNote.selectedPetitionDetails"
                          :options="petitionList"
                          :multiple="false"
                          :close-on-select="true"
                          :clear-on-select="false"
                          :preserve-search="true"
                          placeholder="Select Case"
                          label="name"
                          track-by="id"
                          :preselect-first="false"
                          data-vv-as="Case"
                          v-validate="'required'"
                          @input="newNote.taggedTo=[];gettaggedUsersList()"
                        
                        > 
                          <template slot="selection" slot-scope="{ values, isOpen }">
                            <span
                            class="multiselect__selectcustom"
                            v-if="values.length && !isOpen"
                            >{{ values.length }} Category(s) Selected</span
                            >
                            <span
                            class="multiselect__selectcustom"
                            v-if="values.length && isOpen"
                            ></span>
                          </template>
                        </multiselect>
                    
                        <span   class="text-danger text-sm" v-show="errors.has('Case')"  >{{ errors.first("Case") }}</span
                    >
                      </div>
                  </div>
                </div>
            
             </div>
            

            <div class="vx-row">
              <div class="vx-col w-full">
                <div class="form_group">
                  <div class="access_section">
                    <label class="form_label">Access Level<em>*</em></label>

                    <ul class="custom-radio pt-2">
                      <template v-for="(lavel, index) in accessLevelList">
                        <li :key="index" @click="changedAccessLavel()">
                          <vs-radio v-model="newNote.accessLevelId" vs-name="accessLevels" :vs-value="lavel">{{
                            lavel.name }}</vs-radio>
                        </li>
                      </template>
                    </ul>
                    <input type="hidden" v-validate="'required'" name="accessLevelId" data-vv-as="Access Level"
                      v-model="newNote.accessLevelId" />
                    <span class="text-danger text-sm" v-show="errors.has('accessLevelId')">{{
                      errors.first("accessLevelId") }}</span>
                    <template v-if="checkProperty(newNote, 'accessLevelId', 'id') == 3 ">
                      <div class="form_group mt-4">
                        <div class="w-full con-select">
                          <label class="form_label mb-2">Tagged To<em>*</em></label>
                          <multiselect name="noteUserTo" v-model="newNote.taggedTo" :options="taggedUsersList"
                            :multiple="true" :hideSelected="true" :close-on-select="false" :clear-on-select="false"
                            :preserve-search="true" placeholder="Tagged To" label="name" track-by="name"
                            :preselect-first="false" v-validate="'required'">
                            <template slot="selection" slot-scope="{ values, isOpen }">
                              <span class="multiselect__selectcustom" v-if="values.length && !isOpen">Selected {{
                                values.length }} User(s)</span>
                              <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                            </template>
                          </multiselect>
                        </div>
                        <span class="text-danger text-sm" v-show="errors.has('noteUserTo')">
                          <em>*</em> Tagged To is required
                        </span>
                      </div>
                    </template>
                  </div>
                </div>
              </div>
              

              <div class="vx-col w-full" @click="value = []">
                <div class="form_group file_group">
                  <div class="vs-component marb10">
                    <label class="form_label">Documents</label>
                    <div class="relative">
                      <file-upload v-model="value" class="file-upload-input upload_file justify-center"
                        :accept="allDocEntity"
                        :name="'Documents'" :multiple="true" :hideSelected="true" @input="upload(value)">
                        <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                        Upload
                      </file-upload>
                      <span v-if="uploading" class="loader"><img src="@/assets/images/main/loader.gif" /></span>
                    </div>
                  </div>

                  <ul class="uploaded-list note_uploads">
                    <template v-for="(item, index) in newNote.documents">
                      <vs-chip @click="remove(item, newNote.documents, index)" :key="index" closable>
                        {{ item.name }}
                      </vs-chip>
                    </template>
                  </ul>
                </div>
              </div>
            </div>
            <!-- <span v-if="!isValid" class="text-danger text-sm"
              >Ticket Tagged users is required</span -->

            <div class="text-danger text-sm formerrors" v-show="formerrors.msg" @click="formerrors.msg = ''">
              <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius"
                icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
            </div>
          </div>
          <div class="popup-footer">
            <vs-button color="dark" @click="
                AddNewNote = false;
                editTicket = false;
                resetNewNote();
              " class="cancel" type="filled">Cancel</vs-button>

            <vs-button :disabled="creatingNewNote ||uploading" v-if="editTicket" color="success" class="save"
              @click="noteUpdate()" type="filled">Update</vs-button>

            <vs-button :disabled="creatingNewNote || uploading" v-else color="success" class="save"
              @click="newNoteCreate()" type="filled">Save</vs-button>
          </div>
        </form>
      </div>
    </modal>

    <vs-popup class="holamundo main-popup" title="Update Status" v-if="updateStatusPopup"
      :active.sync="updateStatusPopup">
      <form>
        <div class="form-container">
          <div class="vx-row">
            <div class="vx-col w-100">
              <div class="form_group">
                <label class="form_label">Status<em>*</em></label>
                <div class="con-select w-full">
                  <multiselect name="Status" v-model="nweStatus.statusId" :options="tempStatusids" :multiple="false"
                    :close-on-select="true" :clear-on-select="false" :preserve-search="true"
                    placeholder="Select Ticket Type" label="name" track-by="id" :preselect-first="false"
                    data-vv-as="Note Status" v-validate="'required'">
                    <template slot="selection" slot-scope="{ values, isOpen }">
                      <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                        Status(s) Selected</span>
                      <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                    </template>
                  </multiselect>

                  <span class="text-danger text-sm" v-show="errors.has('Status')">{{ errors.first("Status") }}</span>
                </div>
              </div>
            </div>
          </div>
          <div class="vx-row">
            <div class="vx-col w-full">
              <div class="form_group">
                <label class="form_label">Comment<em>*</em></label>
                <!-- <vs-textarea class="w-full" v-model="nweStatus.comment" v-validate="'required'" data-vv-as="Description"
                  name="description" /> -->
                  <ckeditor   :editor="editor" :config="editorConfig"></ckeditor>
                <span class="text-danger text-sm" v-show="errors.has('description')">{{ errors.first("description")
                  }}</span>
              </div>
            </div>
          </div>

          <div class="text-danger text-sm formerrors" v-show="formerrors.msg" @click="formerrors.msg = ''">
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
              icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
          </div>
        </div>
        <div class="popup-footer">
          <vs-button color="dark" @click="
              (updateStatusPopup = false), (AddNewNote = false);
              editTicket = false;
            " class="cancel" type="filled">Cancel</vs-button>

          <vs-button :disabled="creatingNewNote" color="success" class="save" @click="updateNoteStatus()" type="filled">
            Save</vs-button>
        </div>
      </form>
    </vs-popup>
  </div>
</template>

<script>
import DateRangePicker from "vue2-daterange-picker";
import Paginate from "vuejs-paginate";
import Datepicker from "vuejs-datepicker-inv";
import Multiselect from "vue-multiselect-inv";
import JQuery from "jquery";

import "vue2-daterange-picker/dist/vue2-daterange-picker.css";
import FileUpload from "vue-upload-component/src";
import moment from "moment";
import _ from "lodash";
import NoDataFound from "@/views/common/noData.vue";
import { MoreVerticalIcon } from "vue-feather-icons";
import Vue from 'vue';
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
 
import VuePerfectScrollbar from "vue-perfect-scrollbar";

 

export default {
  components: {
    Datepicker,
    DateRangePicker,
    Multiselect,
    Paginate,
    FileUpload,
    NoDataFound,
    MoreVerticalIcon,
    VuePerfectScrollbar
  },
  data: () => ({
    editor: ClassicEditor,
    editorConfig: {
        toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
    },
    settings: { 
      swipeEasing: true,
    },
    filteredList:[],
    petitionList:[],
    selectedPetions:[],
    taggedUserchText: "",
    selectedNote: null,
    noteTaggedToDetails: [],
    creatingNewNote: false,
    isListLoading: false,
    filterTaggedToIds: [],
    filterAccessLevels: [],
    accessLevelList: [],
    uploading: false,
    value: [],
    AddNewNote: false,
    editTicket: false,
    taggedModal: false,
    
    notesMasterList:[],
    categoryType:null,
    newNote: {
      categoryId:1,
      selectedcategory:{"id": 1, "name": "General"},
      petitionId:null,
      selectedPetitionDetails:null,
      accessLevelId: null,
      priorityId: null,
      title: "",
      description: "",
      documents: [],
      today: moment().format("YYYY-MM-DD"),
    },
    formerrors: {
      msg: "",
    },
    tickets: [],
    sortKeys: {},
    sortKey: {},
    searchtxt: "",
    page: 1,
    perpage: 25,
    totalpages: 0,
    totalCount:0,
    perPeges: [10, 25, 50, 75, 100],
    all_statusids: [],
    tempStatusids: [],
    selected_statusids: [],
    final_selected_statusids: [],
    searchtxt: "",
    filter_searchtxt: "",

    buttoncol: true,
    currentuserRole: null,
    selected_createdDateRange: ["", ""],
    autoApply: "",
    roleId: 0,
    all_user_roles: [],
    users: [],
    selected_user: null,
    assignmrntPopUp: false,
    selected_role: "",

    ticket_comments: [],
    ticket: null,
    selectedNoteId: "",
    selected_ticket_tindex: null,
    CommentPayload: {
      ticketId: "",
      statusId: "",
      description: "",
      documents: [],
      today: moment().format("YYYY-MM-DD"),
    },
    taggedUsersList: [],
    updateStatusPopup: false,
    nweStatus: {
      noteId: "",
      statusId: "",
      statusName: "",
      comment: "",
    },
    isValid: true,
    externalCaseCate:false,
    encodedString:''
  }),
  watch: {
    AddNewNote: function (value) {
      if (value) {
        this.$modal.show("newNoteModal");
      } else {
        this.$modal.hide("newNoteModal");
      }
    },
    searchtxt: function (value) {
      this.getNotes();
    },
  },
  methods: {
    changeCategory(){
      this.set_filter();
      this.getMyPetitions(false)
    },
    gotTdetails(note) {
     
     if(this.checkProperty(note ,'petitionDetails', 'caseNo') && this.loadedFromCaseDetails ){

     let filter ='';
      if (this.checkProperty(this.$router.currentRoute ,"query"  ,"filter") ){
        filter = this.$router.currentRoute['query']['filter'];
        
      }
      
      this.$router.push({ name: 'notes-details', params: { itemId: note._id } ,query: { 'filter':filter } }).catch(err => { })
     }
     if(( this.callFromExternal) || this.checkProperty(note,'categoryId') == 3 ){
      let filter ='';
      let reencodedString ='';
      if (this.checkProperty(this.$router.currentRoute ,"query"  ,"filter") ){
        filter = this.$router.currentRoute['query']['filter'];
          var actual = JSON.parse(atob(filter));
          actual = Object.assign(actual ,{ category:'external-case'});
          const string = JSON.stringify(actual) // convert Object to a String
          reencodedString = btoa(string) ;
          this.$router.push({ name: 'notes-details', params: { itemId: note._id } ,query: { 'filter':reencodedString } }).catch(err => { })
      }else{
        let obj={}
        obj = Object.assign(obj ,{ category:'external-case'});
        const strin = JSON.stringify(obj)
        let nofilterEncode = btoa(strin)
        this.$router.push({ name: 'notes-details', params: { itemId: note._id } ,query: { 'filter':nofilterEncode } }).catch(err => { })
      }
        
      }
     else{
      this.$router.push({ path: `/notes-details/${note["_id"]}` ,query: {'filter':this.encodedString} }).catch(err => {})
       //this.$router.push("/notes-details/" + note["_id"]);
     }
    
   },
    goToCaseDetails(note){
     // this.$router.push({ name: 'gc-employment-details', params: { itemId: response._id } }).catch(err => { })
     //this.$router.push({ name: 'petition-details', params: { itemId:Id } ,query: {'filter':this.encodedString} }).catch(err => {})
     if(this.checkProperty(note ,'petitionDetails' ,'_id') ){
      let setPetitionTab ="notes"
      
        if(this.checkProperty(note ,'petitionDetails' ,'subType') ==15){
          this.$router.push({ name: 'gc-employment-details', params: { 'tabname':'notes',itemId: note['petitionDetails']['_id'] }   }).catch(err => { })
        }
        if(this.checkProperty(note ,'petitionDetails' ,'subType') !=15){
         
          this.$router.push({ name: 'petition-details', params: {'tabname':'notes', itemId:note['petitionDetails']['_id'] }  }).catch(err => {})
        }

     }
    },
    setQueryString(obj){
      const string = JSON.stringify(obj) // convert Object to a String
      this.encodedString = btoa(string) // Base64 encode the String
      this.$route['query']['filter'] = this.encodedString;
    },
    getMyPetitions(callFormNote = false){
       this.newNote.selectedPetitionDetails=[];
      this.petitionList=[];
      
      let postData = {
      "matcher":{
            "searchString":"",
            "getMasterDataOnly": false
        }, 
        page: 1,
        perpage: 1000,
        
      };
      if(this.callFromExternal){
        postData['matcher']['getExternalCases'] = true
      }
      if(callFormNote && this.newNote.selectedcategory && this.checkProperty(this.newNote.selectedcategory,'id') == 3){
        postData['matcher']['getExternalCases'] = true
      }
      if(!callFormNote && this.categoryType && this.checkProperty(this.categoryType,'id') == 3){
        postData['matcher']['getExternalCases'] = true
      }
      this.$store
        .dispatch("getList", {
          data: postData,
          path: "/petition-common/get-list-for-notes",
        })
        .then((response) => {

          
          _.forEach(response ,(item) => {
              if(_.has(item,"caseNo")){
                    item['name'] =  item['caseNo'];
              }
              if(_.has(item,"_id")){
                    item['id'] =  item['_id'];
              }
              this.petitionList.push(item);
              //
            })
         
          
        });
    },
    getCalssName(statusName = "") {
      return "note-" + statusName.toLowerCase();
    },
   
    changedAccessLavel() {
      if (this.checkProperty(this.newNote, "accessLevelId", "id") != 3) {
        this.newNote.taggedTo = [];
      }
      this.$validator.reset();
    },
    removeUser(user) {
      this.newNote.taggedTo = _.filter(this.newNote.taggedTo, (item) => {
        return item["_id"] != user["_id"];
      });
      this.taggedUsersList = this.taggedUsersList;
    },
    selectUser(user) {
      // this.newNote.taggedTo
      if (!this.checkUserIsselected(user["_id"], this.newNote.taggedTo)) {
        this.newNote.taggedTo.push(user);
      }
    },

    checkUserIsselected(userId = null, object) {
      let isSelectedUser = _.find(object, { _id: userId });
      if (isSelectedUser) {
        return true;
      } else {
        return false;
      }
    },
    showTaggedDetails(action = false, note = null) {
      this.noteTaggedToDetails = [];
      this.selectedNote = note;

      if (this.checkProperty(this.selectedNote, "taggedToDetails") && action) {
        this.noteTaggedToDetails = this.checkProperty(
          this.selectedNote,
          "taggedToDetails"
        );
      }
      this.selectedNoteId = this.checkProperty(this.selectedNote, "_id");
      this.taggedModal = action;
    },
    deleteTaggedMember(id) {
      if (id) {
        let postData = { noteId: this.selectedNoteId ,"userId":id };
        this.$store
          .dispatch("commonAction", { data: postData, path: "notes/delete-tagged-users" })
          .then((response) => {
            this.showToster({ message: response.message, isError: false });
            this.noteTaggedToDetails = _.filter(
              this.noteTaggedToDetails,
              (item) => {
                return item["_id"] != id;
              }
            );
            this.getNotes();
            if (this.noteTaggedToDetails.length <= 0) {
              this.taggedModal = false;
            }
          })
          .catch((err) => {
            this.showToster({ message: err, isError: false });
          });
      }
    },
    // /notes/get-tagged-users
    gettaggedUsersList() {
      let self = this;
      let postData = {

       
        filters: {
          title: self.taggedUserchText,
        },
        page: 1,
        perpage: 1000,
        category: "priority",
      };
      this.taggedUsersList =[];
        let url ="/notes/get-tagged-users";
        if(this.checkProperty(this.petitionDetails ,'_id') && this.loadedFromCaseDetails ){
          postData = Object.assign(postData ,{petitionId:''} )
          postData['petitionId'] = this.petitionDetails['_id']

          url ="/petition/assigned-user-list"; 
          if([3].indexOf(this.checkProperty(this.petitionDetails,'typeDetails', 'id' )) >-1 &&  [15].indexOf(this.checkProperty(this.petitionDetails,'subTypeDetails', 'id' )) >-1){
            url = "/perm/assigned-user-list"; 
          }
       
      }
      else if(!this.loadedFromCaseDetails && this.checkProperty(this.newNote ,'selectedPetitionDetails' ,'_id'   )){

        postData = Object.assign(postData ,{petitionId:''} )
        postData['petitionId'] = this.newNote.selectedPetitionDetails['_id']

           url ="/petition/assigned-user-list"; 
          if([3].indexOf(this.checkProperty(this.newNote ,'selectedPetitionDetails','type' )) >-1 &&  [15].indexOf(this.checkProperty(this.newNote ,'selectedPetitionDetails','subType' )) >-1){
            url = "/perm/assigned-user-list"; 
          }
       
         
      }
      else if(this.callFromExternal && this.checkProperty(this.petitionDetails ,'_id') ){
        postData = {}
        postData['petitionId'] = this.petitionDetails['_id']
        url ="/notes/assigned-user-list";
      }
          
      this.$store
        .dispatch("getList", {
          data: postData,
          path: url,
        })
        .then((response) => {
          _.forEach(response.list,(item) => { 
            if(_.has(item,"roleName")){
                    item['name'] =  item['name']+" ("+ item['roleName']+")"
              }             
               if ( this.checkProperty(item ,"name") &&  !(this.checkProperty(item,'hide') ) &&!_.find(this.filteredList,{"_id":this.checkProperty(item,'_id') } ) ){


                  this.filteredList.push(item)
                  
                }     
            })    
      

          if(_.has(postData ,'petitionId')){
          
            //this.taggedUsersList = response['list'];
            this.taggedUsersList = this.filteredList;
            _.forEach(this.taggedUsersList ,(item) => {
              // if(_.has(item,"roleName")){
              //       item['name'] =  item['name']+" ("+ item['roleName']+")"
              // }
              //
            })
          }else{
            this.taggedUsersList = [];
            _.forEach(response ,(item) => {
              if(_.has(item,"roleName")){
                    item['name'] =  item['name']+" ("+ item['roleName']+")"
              }
              if(this.checkProperty(item , 'name')){
                this.taggedUsersList.push(item);
              }
             
            })
          }
          
          
        });
    },
    successUpload() {
      this.$vs.notify({
        color: "success",
        title: "Upload Success",
        text: "Lorem ipsum dolor sit amet, consectetur",
      });
    },

    upload(model, type = "") {
      var _current = this;
      // this.$vs.loading();

      let efiles = [];
      efiles = _.filter(model, (e) => {
        return e.url != null && e.url != "";
      });
      let nfiles = _.filter(model, (e) => {
        return e.url == null || e.url == undefined;
      });

      let mapper = nfiles.map(
        (item) =>
          (item = {
            name: item.name,
            file: item.file ? item.file : null,
            url: item.url ? item.url : "",
            path: item.path ? item.path : "",
            status:
              item.status === false || item.status === true
                ? item.status
                : true,
            mimetype: item.type ? item.type : item.mimetype,
          })
      );
      let tempFiles = [];
      if (mapper.length > 0) {
        this.uploading = true;
        let count = 0;
        mapper.forEach((doc, index) => {
          let formData = new FormData();
          formData.append("files", doc.file);
          formData.append("secureType", "private");
          formData.append("getDetails", true);
          count++;

          this.$store.dispatch("uploadS3File", formData).then((response) => {
            response.data.result.forEach((urlGenerated) => {
              //alert(JSON.stringify(urlGenerated))
              //  this.CommentPayload.documents.push(urlGenerated)
              if (
                _.has(urlGenerated, "name") &&
                tempFiles.indexOf(urlGenerated["name"]) <= -1
              ) {
                tempFiles.push(urlGenerated["name"]);
                this.newNote.documents.push(urlGenerated);
              }
              doc.url = urlGenerated;
              doc.path = urlGenerated;
              doc["mimetype"] = urlGenerated["mimetype"];
              doc["type"] = urlGenerated["mimetype"];
              delete doc.file;
              mapper[index] = doc;
            });
            if (index >= mapper.length - 1) {
              this.uploading = false;
              // _current.$vs.loading.close();
            }
          });
        });
        if (efiles.length > 0) efiles.push(...mapper);
        //this.CommentPayload["documents"] = efiles
      }
    },
    remove(item, data, filindex) {
      data.splice(filindex, 1);
    },
    petitionlink(tr) {
      let routedId = tr._id;
      const $ = JQuery;

      if (
        $(event.target).parents().hasClass("buttoncol") ||
        $(event.target).hasClass("buttoncol")
      ) {} else {
        this.$router.push({ path: `/ticket-details/${tr._id}` });
      }
    },
    pageNate(pageNum) {
      this.page = pageNum;
      this.getNotes();
    },

    set_filter: function () {
      this.final_selected_statusids = [];

      if (this.selected_statusids.length > 0) {
        this.final_selected_statusids = [];
        for (let ind = 0; ind < this.selected_statusids.length; ind++) {
          let current_index = this.selected_statusids[ind];
          this.final_selected_statusids.push(current_index["id"]);
        }
      }

      this.searchtxt = this.filter_searchtxt;

      this.getNotes();
      this.$refs["filter_menu"].dropdownVisible = false;
    },
    clear_filter: function () {
      this.searchtxt = "";
      this.selected_statusids = [];
      this.final_selected_statusids = [];

      this.date = "";
      this.date_range = [];
      this.selected_createdDateRange["startDate"] = "";
      this.selected_createdDateRange["endDate"] = "";
      this.filterTaggedToIds = [];
      this.filterAccessLevels = [];
      this.selectedPetions =[];
      this.categoryType = null;
      this.filter_searchtxt = "";
      this.$refs["filter_menu"].dropdownVisible = false;
      this.getNotes();
    },

    get_statusids() {
      this.$store.dispatch("getmasterdata", "notes_status").then((response) => {
        this.all_statusids = response;
        this.tempStatusids = response;
      });
    },
    getNotes() {
      let obj = {
        filters: {
          title: this.searchtxt,
          statusIds: this.final_selected_statusids,
          taggedToIds: [],
          accessLevelIds: [],
          createdByIds: [],
          createdDateRange: [],
          petitionIds:[],
          categoryIds:[],
        },
        page: this.page,
        perpage: this.perpage,
        sorting: this.sortKey,
      };
      if(this.checkProperty(this.categoryType,'id')){
        obj['filters']['categoryIds'] = [this.checkProperty(this.categoryType,'id')]
      }
      if(this.checkProperty(this.categoryType,'id') == 3 || obj['filters']['categoryIds'].indexOf(3)>-1){
        obj = Object.assign( obj ,{getExternalNotes:true} );
      }
      if (
        this.selected_createdDateRange["startDate"] &&
        this.selected_createdDateRange["startDate"] != "" &&
        this.selected_createdDateRange["endDate"] != "" &&
        this.selected_createdDateRange["endDate"]
      ) {
        obj["filters"]["createdDateRange"] = [
          moment(this.selected_createdDateRange["startDate"]).format("YYYY-MM-DD"),
          moment(this.selected_createdDateRange["endDate"]).format("YYYY-MM-DD")
        ];
      }

      obj["filters"]["taggedToIds"] = this.filterTaggedToIds.map((item) => {
        return item["_id"];
      });
      obj["filters"]["accessLevelIds"] = this.filterAccessLevels.map((item) => {
        return item["id"];
      });

      this.isListLoading = true;
 
      if(this.loadedFromCaseDetails &&  _.has(this.petitionDetails ,'_id')){
       
        obj['filters']['categoryIds'] =[2];
        obj['filters']['petitionIds'] =[this.petitionDetails['_id']];

      }
      else if( !this.loadedFromCaseDetails && this.checkProperty(this.selectedPetions ,'length')>0){
        obj['filters']['categoryIds'] =[2];
        obj['filters']['petitionIds'] = this.selectedPetions.map((item)=>item._id)
      }

      if(this.callFromExternal){
        obj = Object.assign( obj ,{getExternalNotes:true} );
        obj['filters']['categoryIds'] =[3];
        obj['filters']['statusIds'] =[1,2];
        obj['filters']['petitionIds'] =[this.petitionDetails['_id']];
      }
      let tempObj={
        categoryType:this.categoryType,
        filterTaggedToIds:this.filterTaggedToIds,
        filterAccessLevels:this.filterAccessLevels,
        filter_searchtxt:this.filter_searchtxt,
        selected_statusids:this.selected_statusids,
        searchtxt:this.searchtxt,
        selectedPetions:this.selectedPetions,
        page: this.page,
        perpage: this.perpage,
      };
      if (
        this.selected_createdDateRange["startDate"] &&
        this.selected_createdDateRange["startDate"] != "" &&
        this.selected_createdDateRange["endDate"] != "" &&
        this.selected_createdDateRange["endDate"]
      ) { 
        tempObj["startDate"] = moment(this.selected_createdDateRange["startDate"]).format("YYYY-MM-DD");
        tempObj["endDate"] = moment(this.selected_createdDateRange["endDate"]).format("YYYY-MM-DD");
      }
      this.setQueryString(tempObj);
      this.updateLoading(true);
      //this.$store .dispatch("supportTicketsList", obj) 
      this.$store
        .dispatch("getList", { data: obj, path: "/notes/list" })
        .then((response) => {
          this.isListLoading = false;
          this.updateLoading(false);
          let data = response.list;

          let temp_list = [];
          _.forEach(data, (obj) => {
            obj["is_expend"] = false;
            obj["all_comments"] = [];
            obj["newComment"] = {
              ticketId: "",
              statusId: "",
              description: "",
              documents: [],
              today: moment().format("YYYY-MM-DD"),
            };
            temp_list.push(obj);
          });
          this.tickets = temp_list;
            this.totalCount =response.totalCount
          this.totalpages = Math.ceil(response.totalCount / this.perpage);
          setTimeout(() => {
            this.updateLoading(false);
          }, 10);
        })
        .catch((err) => {
          this.tickets = [];
          this.isListLoading = false;

          //alert(err);

          setTimeout(() => {
            this.updateLoading(false);
          }, 10);
        });
    },
    filterQueryPreSelect(callFromMounted=false){
      if(this.checkProperty(this.$route ,'query' ,'filter')){
        try{
          let filter =this.$route['query']['filter']; this.checkProperty(this.$route ,'query' ,'filter')
          var actual = JSON.parse(atob(filter));
          let keys = Object.keys(actual);
          if(this.checkProperty(keys ,'length') >0 ){
            if(_.has(actual ,'page') && this.checkProperty(actual ,'page')){                                     
              this.page = this.checkProperty(actual ,'page');
            }
            if(_.has(actual ,'perpage') && this.checkProperty(actual ,'perpage')){                                     
              this.perpage = this.checkProperty(actual ,'perpage');
            }
            if(_.has(actual ,'categoryType') && this.checkProperty(actual ,'categoryType')){                                     
              this.categoryType = this.checkProperty(actual ,'categoryType');
            }
            if(_.has(actual ,'filterTaggedToIds') && this.checkProperty(actual ,'filterTaggedToIds') && this.checkProperty(actual ,'filterTaggedToIds', 'length')>0){                                     
              this.filterTaggedToIds = this.checkProperty(actual ,'filterTaggedToIds');
            }
            if(_.has(actual ,'filterAccessLevels') && this.checkProperty(actual ,'filterAccessLevels') && this.checkProperty(actual ,'filterAccessLevels', 'length')>0){                                     
              this.filterAccessLevels = this.checkProperty(actual ,'filterAccessLevels');
            }
            if(_.has(actual ,'startDate') && this.checkProperty(actual ,'startDate') ){                                     
              this.selected_createdDateRange["startDate"] = this.checkProperty(actual ,'startDate');
            }
            if(_.has(actual ,'endDate') && this.checkProperty(actual ,'endDate') ){                                     
              this.selected_createdDateRange["endDate"] = this.checkProperty(actual ,'endDate');
            }
            if(_.has(actual ,'filter_searchtxt') && this.checkProperty(actual ,'filter_searchtxt') ){                                     
              this.filter_searchtxt = this.checkProperty(actual ,'filter_searchtxt');
            }
            if(_.has(actual ,'searchtxt') && this.checkProperty(actual ,'searchtxt') ){                                     
              this.searchtxt = this.checkProperty(actual ,'searchtxt');
            }
            if(_.has(actual ,'selected_statusids') && this.checkProperty(actual ,'selected_statusids') && this.checkProperty(actual ,'selected_statusids', 'length')>0){                                     
              this.selected_statusids = this.checkProperty(actual ,'selected_statusids');
            }
            if(_.has(actual ,'selectedPetions') && this.checkProperty(actual ,'selectedPetions') && this.checkProperty(actual ,'selectedPetions', 'length')>0){                                     
              this.selectedPetions = this.checkProperty(actual ,'selectedPetions');
            }
            this.set_filter();
          }else{
            this.set_filter();
          }
        }catch(e){
          if(callFromMounted){
            this.set_filter();
          }
        }   
      }
      else{
        if(callFromMounted){
            this.set_filter();
        }
      } 
    },
    sortMe(sort_key = "") {
      if (sort_key != "") {
        this.sortKeys[sort_key] = this.sortKeys[sort_key] == 1 ? -1 : 1;
        localStorage.setItem("tickets_sort_key", sort_key);
        localStorage.setItem("tickets_sort_value", this.sortKey[sort_key]);

        this.sortKey = {
          path: sort_key,
          order: parseInt(this.sortKeys[sort_key]),
        };
        this.getNotes();
      }
    },
    changeperPage() {
      this.page = 1;
      localStorage.setItem("petitions_perpage", this.perpage);
      this.getNotes();
    },
    resetNewNote() {
      this.creatingNewNote = false;
      this.uploading = false;
      this.formerrors.msg = "";
      (this.editTicket = false), (this.AddBeneficiary = false);
      this.newNote = {

        categoryId:1,
      selectedcategory:{"id": 1, "name": "General"},
      petitionId:null,
      selectedPetitionDetails:null,
       
        ticketType: null,
        taggedTo: [],
        title: "",
        description: "",
        documents: [],
        today: moment().format("YYYY-MM-DD"),
        accessLevelId: null,
      };
      this.gettaggedUsersList();
    },
    newNoteCreate() {
      Object.assign(this.formerrors, {
        msg: "",
      });
      this.$validator.validateAll().then((result) => {
        if (this.checkProperty(this.newNote, "accessLevelId", "id") == 3) {
          if (this.newNote["taggedTo"].length <= 0) {
            this.isValid = false;
            result = false;
          }
        }

        if (result) {
          let postData = _.cloneDeep(this.newNote);
          postData = Object.assign(postData, {
            accessLevelId: this.newNote["accessLevelId"]["id"],
          });
          if (
            this.checkProperty(postData, "accessLevelId") == 3 &&
            postData["taggedTo"].length > 0
          ) {
            postData["taggedTo"] = postData["taggedTo"].map(
              (item) => item["_id"]
            );
          } else {
            postData["taggedTo"] = [];
          }


          if( this.checkProperty(postData ,'selectedcategory' ,'_id' ) ){
            postData["categoryId"] = postData['selectedcategory']['id'];
          }

     
        if(this.loadedFromCaseDetails && this.petitionDetails !=null && _.has(this.petitionDetails ,'_id')){
          postData["categoryId"] =2;
          postData = Object.assign( postData ,{ petitionId:'' } );
          postData['petitionId'] = this.petitionDetails['_id'];
        }else if( postData["categoryId"] ==2 && this.checkProperty(postData ,'selectedPetitionDetails' ,'_id' )){
          postData['petitionId'] = postData['selectedPetitionDetails']['_id'];
        }
        if(this.callFromExternal){
          postData["categoryId"] =3;
          postData = Object.assign( postData ,{ petitionId:'' ,isExternalCase:true} );
          postData['petitionId'] = this.petitionDetails['_id'];
        }
          this.creatingNewNote = true;
          this.$store
            .dispatch("commonAction", { data: postData, path: "notes/create" })
            .then((response) => {
              this.creatingNewNote = false;
              this.AddNewNote = false;
              this.editTicket = false;
              this.showToster({ message: response.message, isError: false });

              this.getNotes();
              if(postData['petitionId'] ){
                this.getMyPetitions();
              }
            })
            .catch((err) => {
              this.creatingNewNote = false;
              this.formerrors.msg = err;
            });
        }
      });
    },
    noteUpdate() {
      ///notes/update

      let postData = _.cloneDeep(this.newNote);
      postData = Object.assign(postData, {
        accessLevelId: this.newNote["accessLevelId"]["id"],
      });
      if (
        this.checkProperty(postData, "accessLevelId") == 3 &&
        postData["taggedTo"].length > 0
      ) {
        postData["taggedTo"] = postData["taggedTo"].map((item) => item["_id"]);
      }
      this.creatingNewNote = true;
      this.$store
        .dispatch("commonAction", { data: postData, path: "notes/update" })
        .then((response) => {
          this.creatingNewNote = false;
          this.AddNewNote = false;
          this.editTicket = false;
          this.showToster({ message: response.message, isError: false });
          this.getNotes();
        })
        .catch((err) => {
          this.creatingNewNote = false;
          //alert(JSON.stringify(err));
          this.formerrors.msg = err;
        });
    },

    reloadTicket(id, tindex) {
      this.selectedNoteId = id;
      this.$router.push("/note-details/" + this.selectedNoteId);
    },

    loadTicket(id) {
      this.uploading = false;
      let self = this;
      this.resetNewNote();
      this.selectedNoteId = id;
      this.loaded = false;
      //this.$store.dispatch("supportTickesDetails", { ticketId: this.selectedNoteId })
      let postData = { noteId: self.selectedNoteId };
      this.$store
        .dispatch("commonAction", { data: postData, path: "notes/details" })
        .then((response) => {
          this.ticket = response;
          this.editTicket = true;

          this.AddBeneficiary = false;

          // taggedTo

          this.newNote = {
            statusId: this.checkProperty(this.ticket, "statusId"),
            noteId: this.selectedNoteId,
            taggedTo: this.checkProperty(this.ticket, "taggedToDetails"),
            accessLevelId: this.checkProperty(
              this.ticket,
              "accessLevelDetails"
            ),
            title: this.ticket["title"],
            description: this.ticket["description"],
            documents: this.ticket["documents"] ? this.ticket["documents"] : [],
            today: moment().format("YYYY-MM-DD"),
          };
          this.AddNewNote = true;
        });
    },

    openUpdateStatusPopup(tr) {
      this.updateStatusPopup = true;
      this.nweStatus = {
        noteId: tr["_id"],
        statusId: "",
        statusName: "",
        comment: "",
      };
      this.tempStatusids = this.all_statusids;

      //remove create status from tempStatusids;
      this.tempStatusids = _.filter(this.all_statusids, (item) => {
        return item.id != 1;
      });

      let currentStatus = _.find(this.all_statusids, { id: tr["statusId"] });
      this.nweStatus["statusId"] = currentStatus;

      this.$validator.reset();
    },
    updateNoteStatus() {
      ///notes/update

      this.$validator.validateAll().then((result) => {
        if (result) {
          let postData = _.cloneDeep(this.nweStatus);
          postData["statusId"] = this.nweStatus["statusId"]["id"];
          postData["statusName"] = this.nweStatus["statusId"]["name"];

          this.creatingNewNote = true;
          this.$store
            .dispatch("commonAction", {
              data: postData,
              path: "notes/update-status",
            })
            .then((response) => {
              this.updateStatusPopup = false;
              this.creatingNewNote = false;
              this.AddNewNote = false;
              this.editTicket = false;
              this.showToster({ message: response.message, isError: false });
              this.getNotes();
            })
            .catch((err) => {
              this.creatingNewNote = false;
              //alert(JSON.stringify(err));
              this.formerrors.msg = err;
            });
        }
      });
    },
    // getGlobalConfigDetails(){
      
    //   this.noteCategoryList();
    // },
    noteCategoryList(){
      this.notesMasterList=[];
      this.$store.dispatch("getmasterdata", "notes_categories").then((response) => {
        let list = response;
          let postData ={}
          this.notesMasterList =[];
          this.$store.dispatch("commonAction", {data:postData,path:'global-config/details'})
          .then((response) =>{ 
            
            if(this.checkProperty(response ,"config") && this.checkProperty(response ,'config','isAllowExternalCases')){
              this.notesMasterList = list
            }
            else{
              this.notesMasterList = _.filter(list,(item)=>{
                return item['id'] != 3
              })
            }
          })
        
          
       
        //salert(this.externalCaseCate)
        
      });
    },
    
  },

  mounted() {
    if(this.$route.params && this.$route.params.openCreatePopup ){
        this.AddNewNote = true;
        this.resetNewNote();
        this.$modal.show('newNoteModal');
      }
    this.gettaggedUsersList();
  
    this.noteCategoryList();
    
   
    this.$store.dispatch("getmasterdata", "user_roles").then((response) => {
      this.all_user_roles = response;
    });

    if(!this.loadedFromCaseDetails){
    this.getMyPetitions();
  
  }

    this.accessLevelList = [
      {
        _id: "623ac50283c322166c6bdba4",
        id: 1,
        name: "Confidential",
        tenantId: null,
        __v: 0,
      },
      {
        _id: "623ac50283c322166c6bdba5",
        id: 2,
        name: "Public",
        tenantId: null,
        __v: 0,
      },
      {
        _id: "623ac50283c322166c6bdba6",
        id: 3,
        name: "Custom",
        tenantId: null,
        __v: 0,
      },
    ];
    this.$store
      .dispatch("getmasterdata", "notes_access_level")
      .then((response) => {
        this.accessLevelList = response;
      });

    this.get_statusids();
    this.username = this.$store.state.user.name;
    this.roleId = this.$store.state.user["roleId"][0];

    //"createdOn", //title, statusName, createdByName, updatedOn, accessLevelName
    (this.sortKeys = {
      createdOn: -1,
      title: 1,
      statusName: 1,
      createdByName: 1,
      updatedOn: 1,
      accessLevelName: 1,
    }),
      (this.sortKey = { path: "createdOn", order: -1 });
    if (
      localStorage.getItem("tickets_sort_key") &&
      localStorage.getItem("tickets_sort_value") &&
      localStorage.getItem("tickets_sort_value") >= -1
    ) {
      this.sortKeys[localStorage.getItem("tickets_sort_key")] = parseInt(
        localStorage.getItem("tickets_sort_value")
      );

      this.sortKey = {
        path: localStorage.getItem("tickets_sort_key"),
        order: parseInt(localStorage.getItem("tickets_sort_value")),
      };
    }

    this.currentuserRole = this.$store.state.user.loginRoleId;
   if(!this.callFromExternal && !this.loadedFromCaseDetails ){
    this.filterQueryPreSelect(true);
   }else{
    setTimeout(()=>{
      this.getNotes();
    },10);
   }
    
  },
  props:{
    callFromExternal:{
      type:Boolean,
      default:false
    },
    petitionDetails: {
      type: [Object ,Array],
      default: null,
    },
    loadedFromPreview:false,
    loadedFromCaseDetails:false
  },
  computed:{
    //petitionDetails loadedFromPreview , loadedFromCaseDetails

    checkCreateButton(){
      let returnValue =true;
      if(this.loadedFromPreview==true){
        returnValue =false;
      }

      return returnValue;


    }
    
  }
};
</script>
