<template>
    <div class="tabs-layout-header-items padr0">
       
        <div class="items-left">
            <!-- <ul class="items-list"
                v-if="checkProperty(petition, 'companyDetails', 'name') || checkProperty(petition, 'beneficiaryDetails', 'name')">
                <li v-if="[51].indexOf(getUserRoleId) <= -1" class="tabwidth">
                    Beneficiary
                    <span style="font-size:12px">{{ checkProperty(petition, 'beneficiaryInfo', 'name') }}</span>
                </li>
                <li v-if="getTenantTypeId != 2 && [51].indexOf(getUserRoleId) <= -1" class="tabwidth">
                    Petitioner
                    <span style="font-size:12px">{{ checkProperty(petition, 'companyDetails', 'name') }}</span>
                </li>
            </ul> -->
        </div>
        <div class="items-right capactions" v-if="checkCurrentUrl && !loadedFromPreview">
            <ul>
                <li v-if="checkProperty(petition, 'premiumProcessing')">
                    <div class="IB_tooltip premium_tooltip eee">
                        <div class="premium_tooltip_icon">
                            <span>P</span>
                            <!-- <img v-if="checkProperty( getPetitionDetails,'premiumProcessingDocuments' ,'length')>0" src="@/assets/images/main/doc.svg"/> -->
                        </div>
                        <div class="tooltip_cnt"
                            v-if="!checkProperty(petition, 'premiumProcessingDocuments', 'length') > 0">
                            <p>Premium Processing</p>
                        </div>
                        <div class="premium_documents"
                            v-if="checkProperty(petition, 'premiumProcessingDocuments', 'length') > 0">
                            <div class="premium_documents_cnt">
                                <h5>Premium Processing</h5>
                                <div class="premium_documents_list"
                                    @click="downloadfile(petition['premiumProcessingDocuments'][0])">
                                    <docType :item="petition['premiumProcessingDocuments'][0]" />
                                    <figcaption>{{ petition['premiumProcessingDocuments'][0]['name'] }}</figcaption>
                                </div>
                            </div>
                        </div>
                    </div>
                   
                </li>

                <template>
                    <li v-if="checkProperty(petition, 'statusDetails', 'name')">

                        <div class="dropdown-button-container">
                            <vs-button class="borderRadius20 status-btn"><span :class="{
                                ' lca_created ': checkProperty(petition, 'statusDetails', 'id') == 1,
                                ' lca_filed ': checkProperty(petition, 'statusDetails', 'id') == 2,
                                ' lca_certified ': checkProperty(petition, 'statusDetails', 'id') == 3,
                                ' lca_denied ': checkProperty(petition, 'statusDetails', 'id') == 4,
                                ' lca_request_for_withdrawal ': checkProperty(petition, 'statusDetails', 'id') == 5,
                                ' lca_withdrawn ': checkProperty(petition, 'statusDetails', 'id') == 6,
                                ' lca_expired': checkProperty(petition, 'statusDetails', 'id') == 7,
                                ' lca_rfe': checkProperty(petition, 'statusDetails', 'id') == 8,
                                'status_draft': checkProperty(petition, 'statusDetails', 'id') == 99,
                            }">{{ checkProperty(petition, 'statusDetails', 'name') }}</span></vs-button>
                        </div>
                    </li>
                </template>
                <!--  && checkProperty(petition, 'completedActivities') && checkProperty(petition, 'completedActivities', 'length') > 0 && petition.completedActivities.indexOf('UPDATE_USCIS_RESPONSE') < 0 -->
                <li
                    v-if="checkGenShareLink && [51].indexOf(getUserRoleId) <= -1 && false">
                    <div class="Generate_buttons">
                        <button class="copy_link"  @click="genarateLink()">
                            <img src="@/assets/images/main/link.svg" />
                            <small>Share Link </small>
                        </button>
                    </div>
                </li>

                <li class="menu_dropdown actions_dropdown actions_dropdown-hover mar0" v-if="checkActionItem">
                    <div class="d-flex">
                        <button class="actions_btn actions_btn_v2">Actions </button>
                        <div class="menu_list_wrap new_actions_menu menu_v2 nextstep-shadow">
                            <div class="menu_list">
                                <template v-for="(menuItem, index) in menuItems">
                                    <template v-if="checkActionRequired(menuItem)">
                                        <div class="menu_item drop_menu_items" :code="menuItem['code']">
                                            <a @click="openActionPopup(menuItem)">
                                                <template>{{ menuItem.actionLable }}</template> </a>
                                        </div>
                                    </template>
                                </template>
                            </div>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
        <!-- USCIS Fee Status -->
        <div style="position: absolute;">
            <updateLCA v-if="showLCAUpdatePopup" @updatepetition="updatepetition" :petitionDetails="null" :lcaDetails="petition"
            @hideMe="showLCAUpdatePopup = false" :isFromLCAList="true" />
        </div>

        <div v-if="createLCA" class="custom_modal_sec documents__modal custom_modal-v2" :class="{ modalopen: createLCA }">
            <div class="custom_modal_overlay"></div>
            <div class="custom_modal_cnt">
                <div class="modal_title">
                    <h2>Edit LCA </h2>
                    <span class="close" @click="createLCA = false; "><x-icon size="1.5x"></x-icon></span>
                </div>
                <RequestLCA v-bind:petitionDetails="null" v-bind:workFlowDetails="null" @updatepetition="updatepetition"
                    @editLca="false" :isFromLCAList="true" @lcaRequestCancel="createLCA = false;" />

            </div>
        </div>

        <ManageLCALink v-if="showLinkwithLCAPopup" @updatepetition="updatepetition" :petitionDetails="petitionDetails"
            :lcaDetails="petition" @hideMe="showLinkwithLCAPopup = false;assignlcaExecutive = false" :isFromLCAList="true" :popUpTitle="'Link with Case'"
            :ACTIVITYCODE="'LINK_LCA'" :lcaId="petition._id" />


            <assignActivity
      @updatepetition="updatepetition"
      :petitionDetails="petition"
      :ACTIVITYCODE="'ASSIGN_LCA_EXECUTIVE'"
      @hideMe="assignlcaExecutive = false"
      :rolesList="[14]"
      :popUpTitle="'Assign LCA Executive'"
      :lableTitle="'Assign LCA Executive'"
      v-if="assignlcaExecutive"
      :callFromLcaDetails="true"

    />
    <modal
      name="genaratLCAModal"
      classes="v-modal-sec"
      :min-width="200"
      :min-height="200"
      :scrollable="true"
      :reset="true"
      width="500px"
      height="auto"
    >
      <div class="v-modal">         
          <!---------Contanexdv--------->
          <div class="genarate_body">
            <span @click="$modal.hide('genaratLCAModal')" class="closemodal">
              <em class="material-icons">close</em>
            </span>
          
              <h3 class="lca_heading">LCA</h3>
             <h6>Copy LCA link.</h6>
            <div class="copysec" @click="copyLink('lca')">
              <p>{{anonymousLcaAccesLink}}</p>
              <img src="@/assets/images/main/copy.svg">
              <small>Copy</small>
            </div> 
            <div class="orshare"><span>OR</span></div>
            <h6>Share LCA link.</h6>   
               
             <div class="copysec">
               <vs-input placeholder="Enter comma separated emails " class="form-control" v-model="lcaLinkShareToemailText" @keyup="formatEmail('lca')" />
               <vs-button @click="shareLink('lca')" :disabled="sharing || lcaLinkShareToemailList.length<=0" class="primary-btn" type="filled">Share</vs-button>
             </div>
            
          </div>
        </div>
        </modal>

    </div>
</template>
  
<script>

import assignActivity from "@/views/actionpopups/assignActivity.vue";
import JQuery from "jquery";
import docType from "@/views/common/docType.vue"
import moment from "moment";
import immitextarea from "@/views/forms/fields/simpletextarea.vue";
import selectField from "@/views/forms/fields/simpleselect.vue";
import immiInput from "@/views/forms/fields/simpleinput.vue";
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import Vue from "vue";
import datepickerField from "@/views/forms/fields/datepicker.vue";
Vue.use(CKEditor);
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import FileUpload from "vue-upload-component/src";
import updateLCA from "@/views/actionpopups/updateLCA.vue";
import RequestLCA from "@/views/RequestLCA";
import { XIcon, MoreVerticalIcon } from 'vue-feather-icons'
import ManageLCALink from "@/views/actionpopups/manageLCALink.vue";

export default {
    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
    components: {
        assignActivity,
        datepickerField,
        docType,
        immitextarea,
        selectField,
        immiInput,
        FileUpload,
        VuePerfectScrollbar,
        updateLCA,
        XIcon,
        RequestLCA,
        ManageLCALink,
    },
    props: {
        petition: {
            type: [Object, Array],
            default: null,
        },
        caseDetails: {
            type: [Object, Array],
            default: null,
        },
        workFlow: {
            type: [Object, Array],
            default: null,
        },

        loadedFromPreview: false,
    },
    computed: {
        checkGenShareLink() {
            let returnVal = true
            let isSlg = true;
            if (this.checkProperty(this.petition, 'questionnaireTplType') == "general") {
                if (this.checkProperty(this.petition, 'intStatusDetails', 'id') == 1) {
                    returnVal = true
                } else {
                    returnVal = false
                }
            }
            return returnVal
        },
        checkActionItem() {
            let returnVal = true;

            if (!this.checkLCACreatePermisions || (this.checkProperty(this.petition, 'statusDetails', 'id') && ([4, 7].indexOf(this.checkProperty(this.petition, 'statusDetails', 'id')) >-1))) {
                returnVal = false
            }
            return returnVal
        },
        checkShareLinkBtn() {
            if ([50].indexOf(this.getUserRoleId) > -1) {
                if (this.petition.completedActivities.indexOf('SUBMIT_TO_LAW_FIRM') > -1) {
                    return false
                }
                else {
                    return true
                }
            } else {
                return false
            }
        },

    },
    data: () => ({
        anonymousLcaAccesLink:'',
        isSlg: true,
        capFormSubmited: false,
        capActionErrors: '',
        editor: ClassicEditor,
        editorConfig: {
            toolbar: ['bold', 'italic', '|', 'undo', 'redo', 'NumberedList', 'BulletedList',],
        },
        casetype: [
            { "name": 'H-1B', 'id': 'H-1B' }
        ],
        casesubtype: [
            { "name": 'Master Cap - Consular Processing', 'id': 'Master' },
            { "name": 'Regular Cap - Consular Processing', 'id': 'Regular' }
        ],
        //payReceipt:'',
        premiumProcessingFormErrors: '',
        premiumProcessing: false,
        premiumDocuments: [],
        premiumProcessingComment: '',
        documentTypes: ["Electronic", "Original"],
        documentType: null,
        selectedCaseType: null,
        selectedSubtype: null,
        BeneficiaryList: [],
        branchList: [],
        premiumProcessing: false,
        petitionersList: [],
        Petitionervalue: null,
        Beneficiaryvalue: null,
        branchvalue: null,
        uploading: false,
        trackingDocuments: [],
        receiptDocuments: [],
        uscisDocuments: [],
        uscisResponse: {
            comments: '',
            documets: '',
            status: null,
            fees: '',
        },
        trackingDocUpload: false,
        payment: '',
        registeredDate: null,
        submittedDate: null,
        paymentDate: null,
        receiptName: '',
        trackingNumber: '',
        formErrors: "",
        comments: '',
        selectedAction: '',
        genUSCISsatatus: [
            { "name": 'Selected', 'id': 'SELECTED' },
            { "name": 'Not Selected', 'id': 'NOT_SELECTED' },
        ],
        USCISstatus: [
            { "name": 'Selected', 'id': 'SELECTED' },
            { "name": 'Not Selected', 'id': 'NOT_SELECTED' },
            { "name": 'Denied', 'id': 'DENIED' },
            { "name": 'Invalidated-Failed Payment', 'id': 'INVALIDATED' }
        ],
        USCISfeesList: [{ "name": 'Pending', 'id': 'Pending' },
        { "name": 'Paid', 'id': 'Paid' },],
        //////////////////
        value: [],
        webBaseUrl: '',
        caseToken: '',
        linkShareToEmailList: [],
        linkShareToemailsText: '',
        lcaLinkShareToemailText:'',
        anonymousAccesLink: '',
        sharing: false,
        linkGenareating: false,
        copyingLink: false,
        menuItems: [
            {
                code: "EDIT_LCA",
                name: "Edit LCA",
                actionLable: "Edit LCA",
                forAdmins: true,
                roleIds: [3, 4],
            },

            {
                code: "UPDATE",
                name: "Update Status",
                actionLable: "Update Status",
                forAdmins: true,
                roleIds: [3, 4],
            },
            {
                code: "LINK_PETITION",
                name: "Link with Case",
                actionLable: "Link with Case",
                forAdmins: true,
                roleIds: [3, 4],
            },
            {
                code: "ASSIGN_LCA_EXECUTIVE",
                name: "Assign LCA Executive",
                actionLable: "Assign LCA Executive",
                popUpTitle:"Assign LCA Executive",
                forAdmins: true,
                roleIds: [],
                completedActivities:[]
            }

        ],
        internalStatusList: [{ _id: "637f7c565648c5150123duse", id: 2, name: "Hold" }],
        internalStatus: null,
        showLCAUpdatePopup: false,
        createLCA: false,
        petitionDetails: null,
        workflow: null,
        showLinkwithLCAPopup: false,
        assignlcaExecutive:false,
        lcaLinkShareToemailList:[],
    }),
    methods: {
    genarateLink(){
      this.webBaseUrl = window.location.origin;
      this.linkShareToEmailList =[];
      this.linkShareToemailsText ='';
      this.sharing =false;
      let petitionDetails = this.petition;
      if( (this.checkProperty( petitionDetails ,'token') =='' && (this.caseToken =='' || this.caseToken ==null || this.caseToken==undefined ))){
      let postData = {
        "lcaId":''
      };
      let path = "/lca/generate-link"
      postData['lcaId'] = petitionDetails['_id'];

      this.anonymousAccesLink ='';
      this.anonymousLcaAccesLink ='';
      this.linkGenareating = true;
        this.$store.dispatch("commonAction" ,{"data":postData , "path":path})
        .then((res)=>{
          this.linkGenareating = false;
          this.petition['token'] = res;
          //alert(this.petition['token'])
          this.caseToken = res;
          this.anonymousLcaAccesLink = this.webBaseUrl+"/fill-lca-inventory-details/"+petitionDetails['_id']+"?token="+res;
          this.$modal.show('genaratLCAModal');
        })
        .catch((err)=>{
            this.linkGenareating = false;
            this.showToster({message:err ,isError:true});
        })
      }else{
        this.anonymousLcaAccesLink = this.webBaseUrl+"/fill-lca-inventory-details/"+petitionDetails['_id']+"?token="+this.checkProperty(petitionDetails,'token');
       this.$modal.show('genaratLCAModal');
      

    }

    },
    async  copyLink(category =''){
     let self =this;
      this.copyingLink =true;
       let petitionDetails = this.petition;
      if((this.checkProperty( petitionDetails ,"token" ) || this.anonymousAccesLink !='') || (this.checkProperty( petitionDetails ,"lcaToken" ) || this.anonymousLcaAccesLink !='') ){
        try {

          if(category == 'lca'){
            await navigator.clipboard.writeText(this.anonymousLcaAccesLink);
          }
          this.showToster({  message: "Copied successfully ", isError: false, });
          this.showToolTip =true;
          this.copyingLink =false;
          setTimeout(() => {
            this.showToolTip =false;
            this.$modal.hide('genaratLCAModal');
          } ,10)       
        } catch ($e) {
           this.copyingLink =false
           //  filderPath = "";
           this.showToster({  message: "Can't Copied folder path! ", isError: true,   });
        }
      }
    
    },
    shareLink( category=''){
      //anonymousAccesLink
      //anonymousLcaAccesLink
      let self =this;
      let postData  = {
        "petitionId":self.petition['_id'],
        "caseNo":self.petition['caseNo'],
        "link":self.anonymousAccesLink,
        "email":self.linkShareToEmailList.join(),
        entityType:'case'

      }
      if(category == 'lca'){
        postData['link'] = self.anonymousLcaAccesLink;
        postData['email'] = self.lcaLinkShareToemailText;
        postData['entityType'] = 'lca';
      }
      this.sharing =true;
       this.$store.dispatch("commonAction", {"data":postData ,"path":"/petition/share-link"})
              .then(response => {
                this.sharing =false;

                  this.showToster({message:response.message,isError:false });
                  this.$modal.hide('genaratLCAModal');
                  this.linkShareToEmailList =[];
                  this.linkShareToemailsText ='';
                  this.lcaLinkShareToemailText ='';
                  this.lcaLinkShareToemailList = [];

              }).catch((err)=>{
                this.sharing =false;
                this.showToster({message:err,isError:true });
              });

    },
    formatEmail(category = ''){
      let emailList = null
      if(category == 'case'){
        emailList= this.linkShareToemailsText.split(',');
      }
      if(category == 'lca'){
        emailList= this.lcaLinkShareToemailText.split(',');
      }
      // this.linkShareToEmailList =[];
      // this.lcaLinkShareToemailList =[];
      let tempEmailList =[];
      if(this.checkProperty( emailList ,'length' )>0){
            const validateEmail = (email) => {
            return String(email)
            .toLowerCase()
            .match(
            /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
            );
            };
          if(category == 'case'){
            this.linkShareToEmailList = _.filter(emailList , (email)=>{
              if(validateEmail(email)){
                return true;
              }else{
                return false;
              }
            })
          }
          if(category == 'lca'){
            this.lcaLinkShareToemailList = _.filter(emailList , (email)=>{
              if(validateEmail(email)){
                return true;
              }else{
                return false;
              }
            })
        }    
      }

    },
        checkActionRequired(obj) {
            let item = obj;

            switch (item.code) {

                case "EDIT_LCA":
                    if ((this.checkProperty(this.petition, 'statusDetails', 'id') && [1,2,8].indexOf(this.petition['statusDetails']['id']) > -1 && this.checkLCACreatePermisions) ||
                    ([99].indexOf(this.checkProperty(this.petition, 'statusDetails', 'id'))> -1 && this.checkProperty(this.petition, 'createdBy') == this.checkProperty( this.getUserData ,'userId'))) {
                        if ([51].indexOf(this.getUserRoleId) > -1) {
                            return false
                        } else {
                            return true
                        }
                    }
                    return false;
                    break;
                case "UPDATE":
                    if ([51].indexOf(this.getUserRoleId) <= -1 && this.checkProperty(this.petition, 'statusDetails', 'id') &&[1,2,3,5,6,8].indexOf(this.petition['statusDetails']['id']) > -1 && this.checkLCACreatePermisions) return true

                    return false
                    break;
                case "LINK_PETITION":
                    if ([51].indexOf(this.getUserRoleId) <= -1 && this.checkProperty(this.petition, 'statusDetails', 'id')&&[1,2,3].indexOf(this.petition['statusDetails']['id']) > -1   && this.checkLCACreatePermisions) return true

                    return false
                    break;
                case "ASSIGN_LCA_EXECUTIVE":
                    if([11].indexOf(this.getUserRoleId)>-1 && !this.checkProperty(this.petition,'completedActivities')){
                        return true;
                    }else  if([11].indexOf(this.getUserRoleId)>-1 &&  (this.checkProperty(this.petition,'completedActivities' ) ) ){
                        if(this.petition['completedActivities'].indexOf('ASSIGN_LCA_EXECUTIVE')<=-1){
                            return true
                        }

                    }
                    return false;
                    break    
            }

        },
        openActionPopup(item) {
          
            this.comments = '';
            this.selectedAction = this.checkProperty(item, 'code');
            let routedId = this.checkProperty(this.petition, '_id');
            switch (item.code) {
                case "EDIT_LCA":
                    this.getCaseDetails()

                    break;
                case "UPDATE":
                    this.showLCAUpdatePopup = true;
                    break;
                case "LINK_PETITION":
                    this.showLinkwithLCAPopup = true
                    break
                case "ASSIGN_LCA_EXECUTIVE":
                    this.assignlcaExecutive = true;
                    break;
                default:


            }
        },
        submitForm() {
            this.$validator.validateAll('PREMIUM_PROCESS').then((result) => {
                let self = this;
                if (result) {
                    let postData = {
                        petitionId: self.checkProperty(self.petition, '_id'),
                        documents: self.premiumDocuments,
                        //today: moment().format("YYYY-MM-DD"),
                        comment: self.premiumProcessingComment,
                        premiumProcessing: !this.checkProperty(this.petition, 'premiumProcessing')

                    }
                    //this.updatingPremiumProcessing =true;            
                    this.$store
                        .dispatch("commonAction", { "data": postData, "path": "/cap-registrations/manage-premium-process" })
                        .then(response => {
                            this.$modal.hide('PREMIUM_PROCESS');
                            this.updatepetition()
                            this.showToster({ message: response.message, isError: false });
                            //this.$emit("updatepetition", "Case Details");                 
                        })
                        .catch((error) => {
                            this.premiumProcessingFormErrors = error;
                            this.updatingPremiumProcessing = false;
                        })
                }
            });
        },
        downloadfile(value) {
            this.$emit('download_or_view', value);
        },
        upload(fils, category = '') {
            this.disablePWDstatus = false;
            this.pwdDocFormatError = '';
            let model = _.cloneDeep(fils);
            this.value = [];
            var _current = this;
            let efiles = [];
            efiles = _.filter(model, (e) => {
                return e.url != null && e.url != "";
            });
            let nfiles = _.filter(model, (e) => {
                return e.url == null || e.url == undefined;
            });

            let mapper = nfiles.map(
                (item) =>
                (item = {
                    name: item.name,
                    file: item.file ? item.file : null,
                    url: item.url ? item.url : "",
                    path: item.path ? item.path : "",
                    status: true,
                    mimetype: item.type ? item.type : item.mimetype,
                })
            );
            let tempFiles = [];
            if (mapper.length > 0) {
                if (category == 'trackingDocuments') {
                    this.trackingDocUpload = true
                } else {
                    this.uploading = true;
                }


                let count = 0;
                mapper.forEach((doc, index) => {
                    let formData = new FormData();
                    formData.append("files", doc.file);
                    formData.append("secureType", "private");
                    formData.append("getDetails", true);
                    count++;
                    this.$store.dispatch("uploadS3File", formData).then((response) => {
                        response.data.result.forEach((urlGenerated) => {

                            let obj = {
                                uploadedBy: this.checkProperty(this.getUserData, 'userId'),
                                uploadedByName: this.checkProperty(this.getUserData, 'name'),
                                uploadedByRoleId: this.getUserRoleId,
                                uploadedByRoleName: this.checkProperty(this.getUserData, 'loginRoleName'),
                            }
                            let tempUrl = urlGenerated
                            tempUrl = Object.assign(tempUrl, { uploadedBy: this.checkProperty(this.getUserData, 'userId'), uploadedByName: this.checkProperty(this.getUserData, 'name'), uploadedByRoleId: this.getUserRoleId, uploadedByRoleName: this.checkProperty(this.getUserData, 'loginRoleName') });
                            //alert(JSON.stringify(tempUrl))
                            tempFiles.push(tempUrl["name"]);
                            // trackingDocuments          
                            if (category == 'trackingDocuments') {
                                this.trackingDocuments.push(tempUrl);
                            }
                            if (category == 'receiptDocuments') {
                                this.receiptDocuments.push(tempUrl);
                            }
                            if (category == 'uscisDocuments') {
                                this.uscisDocuments.push(tempUrl);
                            }
                            if (category == 'premiumDocuments') {
                                this.premiumDocuments.push(tempUrl);
                            }
                            doc.url = urlGenerated;
                            doc.path = urlGenerated;
                            doc["mimetype"] = urlGenerated["mimetype"];
                            doc["type"] = urlGenerated["mimetype"];
                            delete doc.file;
                            mapper[index] = doc;
                        });
                        if (index >= mapper.length - 1) {
                            this.uploading = false;
                            this.trackingDocUpload = false;
                            // _current.$vs.loading.close();
                        }
                    });
                });
                if (efiles.length > 0) efiles.push(...mapper);
                //this.CommentPayload["documents"] = efiles
            }
        },
        remove(item, data, filindex) {
            data.splice(filindex, 1);
            this.disablePWDstatus = false;


        },
        updatepetition() {
            this.createLCA = false
            this.assignlcaExecutive = false;
            this.showLinkwithLCAPopup = false;
            this.$emit("updatepetition", "Case Details");
        },
        getBranchList() {

            this.branchList = [];
            let item = {
                filters: {
                    "title": '',
                    "createdDateRange": [],
                    "statusList": [],
                    "activeList": [],
                    "countryIds": [],
                    "stateIds": [],
                    "locationIds": []
                },
                getMasterData: true,
                page: 1,
                perpage: 1000,
                sorting: { "path": "createdOn", "order": -1 },

            };
            this.$store
                .dispatch("getList", { "data": item, "path": "/branch/list" })
                .then(response => {
                    this.branchList = response.list;//branchvalue


                }).catch((error) => {
                    this.branchList = [];
                })
        },
        getPetitioners(callFromSerch = false, searchText = '') {

            let _self = this;
            let query = {
                "matcher": {
                    "searchString": searchText,
                    "statusIds": [],
                    "countryIds": [],
                    "stateIds": [],
                    "locationIds": [],
                    "createdDateRange": []
                },
                "sorting": { "path": "createdOn", "order": 1 },
                "page": 1,
                "perpage": 100,
                getMasterData: true
            }
            this.$store.dispatch("getList", { data: query, path: '/company/list' }).then(response => {

                _self.petitionersList = response.list;

            }).catch((err) => {

                
                this.petitionersList = [];

            })
        },
        getCaseDetails() {
            // if (this.checkProperty(this.petition, 'petitionDetails', '_id')) {
            //     this.$vs.loading()
            //     let petitionId = this.checkProperty(this.petition, 'petitionDetails', '_id')
            //     this.$store.dispatch("getpetition", petitionId).then((response) => {
            //         if (response.data) {
            //             this.petitionDetails = response.data.result
            //             if (this.checkProperty(this.petitionDetails, "workflowId")) {
            //                 let workFlowId = this.petitionDetails.workflowId;
            //                 if (workFlowId) {
            //                     let payLoad = {
            //                         path: "/workflow/details",
            //                         data: { workflowId: workFlowId },
            //                     };
            //                     this.$store
            //                         .dispatch("commonAction", payLoad)
            //                         .then((res) => {
            //                             this.$vs.loading.close();
            //                             this.workflow = res;
            //                             this.$store.dispatch("setPetitionData", { petitionDetails: this.petitionDetails, lcaDetails: this.petition, workFlowDetails: this.workflow, });
            //                             setTimeout(() => {
            //                                 this.createLCA = true;
            //                             }, 100);
            //                         })
            //                         .catch((error) => {
            //                             this.$vs.loading.close();
            //                         });
            //                 } else {
            //                     this.$vs.loading.close();
            //                 }
            //             }

            //         } else {
            //             this.$vs.loading.close();
            //         }
            //     });
            // } else {
            this.$store.dispatch("setPetitionData", { petitionDetails: null, lcaDetails: this.petition, workFlowDetails: null, });
            setTimeout(() => {
                this.createLCA = true;
            }, 100);
            // }
        },
    },
    mounted() {
        this.getPetitioners();
        this.getBranchList();
        if (this.checkProperty(this.petition, 'questionnaireTplType') == "general") {
            this.isSlg = false
        }
        this.caseToken = this.checkProperty(this.petition, 'token');
        setTimeout(() => {
            this.caseToken = this.checkProperty(this.petition, 'token');
           

        }, 10)
        setTimeout(() => {
            if (this.checkProperty(this.petition, 'petitionerId')) {
                if (this.petitionersList && this.checkProperty(this.petitionersList, 'length') > 0) {
                    let obj = _.find(this.petitionersList, { "_id": this.checkProperty(this.petition, 'petitionerId') })
                    this.Petitionervalue = obj
                }
            }
            if (this.branchList && this.checkProperty(this.branchList, 'length') > 0) {
                let obj = _.find(this.petitionersList, { "_id": this.checkProperty(this.petition, 'branchId') })
                this.branchvalue = obj
            }
        }, 100)
        if (this.checkProperty(this.petition, 'beneficiaryDetails')) {
            this.Beneficiaryvalue = this.checkProperty(this.petition, 'beneficiaryDetails')
        }



    },
    watch: {
        createLCA: function (value) {

            const $ = JQuery;
            if (value) {
                $('body').addClass('vm--block-scroll');
            } else {
                $('body').removeClass('vm--block-scroll');
            }

        },
    }
}
</script>