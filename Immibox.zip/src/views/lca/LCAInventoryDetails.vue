<template>
    <div class="main-tabs-content"
        :class="{ 'tabs_mob petetion__details_page petetion__details_full_width': !loadedFromPreview, 'anonymouslogin': !checkCurrentUrl }">
        <!-- header area-->
        <div class="tabs-layout-header" v-if="!loadedFromPreview">

            <div class="case-no-panel">
                <div class="casenumber_sec">
                    <div class="case_number">
                        <div class="d-flex align-items-center">
                            Case No
                        </div>
                        <span>{{ checkProperty(petition, "caseNo") }}
                        </span>
                        <i class="material-icons"
                            v-if="!loadedFromPreview && checkCurrentUrl && checkProperty(petitions, 'length') > 0">arrow_drop_down</i>
                    </div>
                    <div class="case_number_list"
                        v-if="!loadedFromPreview && checkCurrentUrl && checkProperty(petitions, 'length') > 0">
                        <VuePerfectScrollbar class="scroll-area">
                            <ul v-if="petitions">
                                <li @click="petetionChange(petition._id)" v-for="(petition, index) in petitions"
                                    :key="index">{{
                                        petition.caseNo }}
                                </li>
                            </ul>
                        </VuePerfectScrollbar>
                    </div>
                </div>

            </div>
            <LCAProcessFlow ref="process_flow" v-bind:petition="petition" @updatepetition="reloadPetition"
                @download_or_view="download_or_view" :loadedFromPreview="loadedFromPreview" />

        </div>

        <div class="main-tabs-content tabs_mob petetion__details_page  petetion__details_full_width">
            <div class="
                                               tabs-content
                                               detail_page_sec
                                               petetion__details
                                               case-details-box-width
                                              petetion__details_full_width">
                <section class="petition__details_section cap_page"
                    :class="{ 'cap_page_full': checkCurrentUrl && !loadedFromPreview && [50, 51].indexOf(getUserRoleId) > -1 }">
                    <div class="pd_left">
                        <ul>
                            <!-- <li v-if="
                                ((checkProperty(petition, 'questionnaireTplType') == 'slg' && (checkProperty(petition, 'questionnaireFilled')) && petition.completedActivities && petition.completedActivities.indexOf('VERIFY') > -1) ||
                                    (checkProperty(petition, 'questionnaireTplType') == 'general' && (checkProperty(petition, 'questionnaireFilled')) && petition.completedActivities && petition.completedActivities.indexOf('REGISTERED') > -1))
                                && getUserRoleId != 51 && !loadedFromPreview"
                                :class="{ current_child: getPetitionTab == 'Petition Updates', }"
                                @click="setActivetab('Petition Updates', true)">
                                <a>Case Updates </a>
                            </li> -->
                            <li :class="{
                                current_child: getPetitionTab == 'Case Details' || (getPetitionTab == 'Petition Updates' && getUserRoleId == 50),
                            }" @click="setActivetab('Case Details', true)">
                                <a>LCA Info </a>
                            </li>
                        </ul>
                    </div>
                    <div class="pd_right petition__details_cnt">
                        <div class="pd_right_cnt">
                            <template>
                                <div
                                    v-if="getPetitionTab == 'Petition Updates' && getUserRoleId != 51 && !loadedFromPreview">
                                    <capCaseUpdates :petition="petition" :checkCurrentUrl="checkCurrentUrl"
                                        @download_or_view="download_or_view" />
                                </div>
                                <!-- {{ getPetitionTab }} -->
                                <div v-if="getPetitionTab == 'Case Details'">
                                    <LCADetails v-bind:workFlowDetails=null :showStatusButton="true"
                                        v-bind:currentRole="getUserRoleId" v-bind:lcaDetails="petition"
                                        v-bind:petition="null" :showLcaActivity="false" @download_or_view="download_or_view"
                                        @updatepetition="reloadPetition" :isFromLCAList="true" :showStatus="false" />

                                </div>

                            </template>

                            <div>

                            </div>
                        </div>

                    </div>
                </section>
                <div vs-type="flex" class="padr0 padl0 mob-right activies_list_wrap status_wrap cap_activies_list_wrap"
                    v-if="!loadedFromPreview && checkCurrentUrl && [51].indexOf(getUserRoleId) <= -1">
                    <!-- Newly Added -->
                    <ul v-if="checkCurrentUrl && !loadedFromPreview">
                        <li class="ptstatusBar " v-if="[51].indexOf(getUserRoleId) < 0">
                            <div class="status_activities" style="justify-content:center">
                                <label class="active">Activities </label>
                            </div>
                        </li>
                    </ul>
                    <div class="history-sidebar petition_history activies_list cap_details_activies_list">
                        <div class="vs-sidebar">
                            <div class="petition_updated" v-if="petitionhistory.length == 0">
                                Last Updated -
                                {{ checkProperty(petition, "updatedOn") | formatDateTime }}
                            </div>
                            <div class="petition_updated" v-if="petitionhistory.length > 0">
                                Last Updated - {{ petitionhistory[0].createdOn | formatDateTime }}
                            </div>

                            <div class="vs-sidebar--items">
                                <VuePerfectScrollbar class="scroll-area">
                                    <div class="timeline-sidebar 2">
                                        <ul>
                                            <li v-for="(history, index) in petitionhistory" :key="index">
                                                <div class="timeline-icon">
                                                    <i class="icon IP-tick-sign"></i>
                                                </div>
                                                <div class="timeline-info">
                                                    <button class="btn active-green ml-0">
                                                        {{ history.createdByRoleName }}
                                                    </button>
                                                    <ul>
                                                        <li>
                                                            <h3><span>
                                                                    {{ history.title }}
                                                                </span>
                                                                <div v-if="
                                                                    history.comment && history.comment != ''
                                                                " class="title_des">
                                                                    <small></small>
                                                                    <div class="dec-content">
                                                                        <p> {{ returnCommentText(history.comment) | commentSubString }}</p>
                                                                        <span v-if="checkCommentLength(history['comment'])" class="view_more" @click="showHistoryComment(history)"> View More</span>
                                                                    </div>
                                                                </div>
                                                            </h3>

                                                            <span>{{ history.description }}</span>
                                                            <span>{{
                                                                history.createdOn | formatDateTime
                                                            }}</span>

                                                            <div class="attorney_details"
                                                                v-if="checkProperty(history.withdrawReasonDetails, 'name')">
                                                                <p>
                                                                    Reason for Withdrawal
                                                                    <span> {{ history.withdrawReasonDetails.name }}</span>
                                                                </p>
                                                            </div>
                                                            <div class="attorney_details"
                                                                v-if="checkProperty(history.attroneyDetails, 'name')">
                                                                <p>
                                                                    Attorney
                                                                    <span> {{ history.attroneyDetails.name }}</span>
                                                                </p>
                                                            </div>

                                                            <p calss="cursor-pointer"
                                                                style="margin-top: 5px;cursor: pointer; "
                                                                v-if="checkProperty(history, 'action') == 'STATUS_UPDATE' && checkProperty(history, 'documents', 'length') > 0"
                                                                @click="downloads3file(history['documents'][0])">
                                                                <docmentType
                                                                    :title="checkProperty(history['documents'][0], 'name')"
                                                                    :item="history['documents'][0]" />
                                                                <!----<figcaption>{{checkProperty(history['documents'][0] ,'name')}}</figcaption>-->


                                                            </p>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                </VuePerfectScrollbar>
                            </div>
                        </div>
                    </div>



                </div>
            </div>
        </div>
        <!--- Share Modal  --->

        <vs-popup class="document_modal document_modal-v2"
        :class="{ expand: expandModal }"
         :title="checkProperty(selectedFile, 'name')" :active.sync="docPrivew">
         <div class="document_actions" @click="expandModal = !expandModal">
      <figure v-if="!expandModal" class="maximize-img"><img src="@/assets/images/maximize.png"  width="18" height="18"/></figure>
      <figure v-else class="minimize-img"><img src="@/assets/images/minimize.png"  width="20" height="20"/></figure>
    </div>
            <h2> <img :class="{
                pdf_view_download: docType == 'pdf',
                office_view_download: docType == 'office',
                image_view_download: docType == 'image',
            }" class="download-button" @click="downloads3file(selectedFile)" src="@/assets/images/download.svg" /></h2>

            <div class="pdf_loader">
                <figure v-if="formSubmited" class="loader loader2"><img src="@/assets/images/main/loader.gif" /></figure>

                <!-- <span :class="{'pdf_view_close':docType == 'pdf', 'office_view_close':docType == 'office'  , 'image_view_close 33':docType =='image'}" class="close close2" @click="docPrivew= false"></span> -->
                <template v-if="docType == 'office'">
                    <div style="height:90vh">

                        <div id="placeholder" style="height:100%"></div>
                    </div>
                </template>
                <template v-else-if="docType == 'image'">
                    <img :src="docValue" />
                </template>
                <template v-else-if="docType == 'pdf'">
                    <div class="pdf" style="height:90vh">

                        <iframe v-if="docValue != ''" border="0" style="border:0px;" :src="docValue" height="100%"
                            width="100%">

                        </iframe>
                    </div>
                </template>
            </div>
        </vs-popup>

        <modal
      name="historyComment"
      classes="v-modal-sec"
      :min-width="200"
      :min-height="200"
      :scrollable="true"
      :reset="true"
      width="800px"
      height="auto"
    >
      <div class="v-modal">
        <div class="popup-header fromDetailsPage">
          <h2 class="popup-title">Comment</h2>
          <span @click="$modal.hide('historyComment');selectedHistory=null">
            <em class="material-icons">close</em> 
          </span>
        </div>

        <div class="form-container">
                <div class="vx-row mb-2">
                    <div class="vx-col w-full comment_modal">
                        <p style="line-height: 20px" v-html="checkProperty(selectedHistory ,'comment')">
                         
                        </p>
                    </div>
                </div>
            </div>
            <div class="popup-footer">
                <vs-button color="dark" class="cancel" type="filled" @click="$modal.hide('historyComment');selectedHistory=null">Cancel</vs-button>
                
            </div>

       
        </div>
    </modal> 


    </div>
</template>
 
<script>
import Vue from 'vue';
Vue.use(CKEditor);
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import docmentType from "@/views/common/docType.vue"
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import capCaseUpdates from "@/views/cap/capCaseUpdates.vue";
import LCAProcessFlow from "@/views/lca/LCAProcessFlow.vue";
import educationInfo from "@/views/petition/subtabs/educationsVersion2.vue";
import personalInfo from "@/views/cap/capPersonalDetails.vue";
import immiInput from "@/views/forms/fields/simpleinput.vue";
import immitextarea from "@/views/forms/fields/simpletextarea.vue";
import selectField from "@/views/forms/fields/simpleselect.vue";
import FileUpload from "vue-upload-component/src";
import axios from '@/axios.js';
import LCADetails from "@/views/LCADetails";
export default {
    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
    data: () => ({
        selectedHistory:null,
        expandModal: false,
        editor: ClassicEditor,
        editorConfig: {
            toolbar: ['bold', 'italic', '|', 'undo', 'redo', 'NumberedList', 'BulletedList',],
        },
        petitionhistory: [],
        formSubmited: false,
        selectedFile: '',
        docValue: "",
        docPrivew: false,
        docType: false,
        petitions: [],
        setTab: false,
        lcaStatusList: [],
        getPetitionTab: null,
        petitionId: null,
        petition: null,
        ///////////////////////////
        activeTab: 'caseUpdate',
        routeId: '',
        routeQuery: '',
        linkShareToemailsText: "",
        petitionDetails: null,
        workFlowDetails: null,


    }),
    components: {
        docmentType,
        VuePerfectScrollbar,
        capCaseUpdates,
        LCAProcessFlow,
        //ProcessFlow,
        personalInfo,
        educationInfo,
        immiInput,
        FileUpload,
        selectField,
        immitextarea,
        LCADetails,
    },
    methods: {
        showHistoryComment(item=null){
      
      this.selectedHistory = item;
      if(this.checkProperty(this.selectedHistory ,'comment')){
        this.$modal.show('historyComment');
      }else{
        this.$modal.hide('historyComment');
      }

    },
        loadPetetion(tab = "") {

            this.$store.dispatch("fetchLcaDetails", this.petitionId)
                .then((response) => {
                    this.$vs.loading.close();
                    this.petition = response.data.result;
                    this.getPetitionTab = "Case Details"


                    this.getcaseHistory();
                    if (this.checkProperty(this.petition, "userId")) {
                        let postdata = {
                            matcher: { rfeCases: '', getMasterDataOnly: true, beneficiaryIds: '', },
                            "page": 1,
                            "perpage": 100
                        }
                        postdata['matcher']['userId'] = this.petition['userId'];
                        if (_.has(this.petition, "rfeCase")) {
                            postdata['matcher']['isRfeCase'] = false
                        }

                        this.$store.dispatch("fetchlcalist", postdata).then(response => {
                            this.petitions = response.data.result.list;
                        }).catch(() => {

                        })
                    }
                })
                .catch((error) => {
                    this.$vs.loading.close();
                    this.showToster({ message: error, isError: true });
                });

        },
        setActivetab(stab = "Case Details", callFromClick = false) {
            if (!stab) {
                stab = "Case Details";
            }
            this.getPetitionTab = stab

        },
        reloadPetition(tab = "Case Details") {
            //reloading Petition Updates

            if (this.getPetitionTab == 'Petition Updates') {
                this.getPetitionTab = 'Case Details';
            }


            if (tab != "") {

                this.$store.dispatch("setPetitionTab", tab)
                    .then(() => {

                        this.init(tab);
                    })
                    .catch((err) => {

                        this.init();
                    });
            } else {
                this.$store.dispatch("setPetitionTab", "Case Details");
                this.init();
            }
        },
        getcaseHistory() {
            if (this.petitionId) {
                let postdata = {
                    lcaId: this.petitionId,
                    page: 1,
                    perpage: 500
                };
                this.$store.dispatch("fetchLCAactivities", postdata).then(response => {
                    this.petitionhistory = response['data']['result']['list'];
                });
            }
        },
        init(tab = '') {
            this.loadPetetion(tab);
            this.$store.dispatch("getmasterdata", "lca_inventory_status").then((response) => {
                this.lcaStatusList = response;
            });
        },
        petetionChange(id) {
            this.setActivetab("Case Details", true);
            this.petition = null;
            this.petitionId = id;
            this.$store.dispatch("setPetitionData", { petitionDetails: this.petition, })
                .then(() => {
                    setTimeout(() => {
                        this.init();
                    }, 10);
                })
                .catch(() => {
                    setTimeout(() => {
                        this.init();
                    }, 1);
                });
            this.updateUrl();
        },
        updateUrl() {
            this.$route['params']['itemId'] = _.cloneDeep(this.petitionId);
        },
        goToQuestionaireLink(item) {
            this.$router.push({ name: 'Cap questionnaire', params: { itemId: item } })
        },
        showShareLink() {
            this.$modal.show('capgenaratModal')
        },
        efilingmodal() {
            this.$modal.show('efileModal')
        },
        Trackinginfomodal() {
            this.$modal.show('Trackingmodal')
        },
        paymentInfomodal() {
            this.$modal.show('paymentmodal')
        },
        UpdateUSICmodal() {
            this.$modal.show('usicResponsemodal')
        },
        CreateCaseModal() {
            this.$modal.show('Createcasemodal')
        },
        download_or_view(docItem) {


            let value = _.cloneDeep(docItem);
            this.expandModal= false;
            if (this.checkProperty(this.getPetitionDetails, 'caseNo') && this.checkProperty(value, 'name')) {
                let docName = _.cloneDeep(value['name']);
                value['name'] = this.checkProperty(this.getPetitionDetails, 'caseNo') + "_" + docName;
            }


            var _self = this;
            this.formSubmited = false;
            if (_.has(value, "path")) {
                value["url"] = value["path"];
                value["document"] = value["path"];
            }

            if (_.has(value, "url")) {
                value["path"] = value["url"];
                value["document"] = value["url"];
            }

            if (_.has(value, "document")) {
                value["path"] = value["document"];
                value["url"] = value["document"];
            }
            value = Object.assign(value, { 'petitionId': this.petition['_id'] })
            value = Object.assign(value, { 'subTypeDetails': this.petition['subTypeDetails'] })


            this.selectedFile = value;
            this.docValue = "";
            this.docPrivew = false;
            this.docType = false;
            this.docType = this.findmsDoctype(value);

            if ((this.docType == "office" || this.docType == "image" || this.docType == "pdf")) {
                //if ( (this.docType == "office" || this.docType == "image" || this.docType == "pdf") && value.download == false ) {
                value.url = value.url.replace(this.$globalgonfig._S3URL, "");
                value.url = value.url.replace(this.$globalgonfig._S3URLAWS, "");
                let postdata = {
                    keyName: value.url,
                    "petitionId": value['petitionId'],

                    // entityType:value['petitionId']
                    // "fileName":value.name?value.name:''
                };
                if (this.checkProperty(value, 'subTypeDetails', 'id') == 15) {
                    postdata['entityType'] = 'perm'
                } else {
                    postdata['entityType'] = 'case'
                }


                this.$store.dispatch("getSignedUrl", postdata).then((response) => {
                    this.docValue = response.data.result.data;

                    if (this.docType == "office") {
                        document.getElementById("placeholder").innerHTML = "  <div  id='placeholder2' style='height:100%'></div>";
                        let _editing = true;

                        if ([50, 51].indexOf(this.getUserRoleId) > -1) {
                            _editing = false;
                        }

                        if (value.viewmode) {
                            _editing = false;
                        }
                        var _ob = {}
                        if (value.editedDocument) {
                            _ob = {

                                petitionId: this.petition._id,
                                name: value.name,
                                _id: value._id,
                                "extn": "docx",
                                "formLetterType": "Letter",
                                parentId: value.parentId
                            }

                        } else {

                            _ob = {

                                name: value.name,
                                petitionId: this.petition._id,
                                _id: value._id,
                                "extn": "docx",
                                "formLetterType": "Letter",
                                parentId: value._id

                            }

                        }


                        window.docEditor = new DocsAPI.DocEditor("placeholder2",
                            {

                                "document": {
                                    "c": "forcesave",
                                    "fileType": "docx",
                                    "key": value._id,
                                    "userdata": JSON.stringify(_ob),
                                    "title": value.name,
                                    "url": response.data.result.data,
                                    permissions: {
                                        edit: _editing,
                                        download: true,
                                        reader: false,
                                        review: false,
                                        comment: false
                                    }
                                },

                                "documentType": "word",
                                "height": "100%",
                                "width": "100%",

                                "editorConfig": {
                                    "userdata": JSON.stringify(_ob),
                                    "callbackUrl": "https://immibox.com/api/perm/post-edited-document?payload=" + JSON.stringify(_ob) + "&token=" + _self.$store.state.token + "&name=" + value.name.replace('.docx', ''),
                                    "customization": {
                                        "logo": {
                                            "image": "https://immibox.com/app/favicon.png",
                                            "imageDark": "https://immibox.com/app/favicon.png",
                                            "url": "https://immibox.com"
                                        },
                                        "anonymous": {
                                            "request": false,
                                            "label": "Guest"
                                        },
                                        "chat": false,
                                        "comments": false,
                                        "compactHeader": false,
                                        "compactToolbar": true,
                                        "compatibleFeatures": false,
                                        "feedback": {
                                            "visible": false
                                        },
                                        "forcesave": true,
                                        "help": false,
                                        "hideNotes": true,
                                        "hideRightMenu": true,
                                        "hideRulers": true,
                                        layout: {
                                            toolbar: {
                                                "collaboration": false,
                                            },
                                        },
                                        "macros": false,
                                        "macrosMode": "warn",
                                        "mentionShare": false,
                                        "plugins": false,
                                        "spellcheck": false,
                                        "toolbarHideFileName": true,
                                        "toolbarNoTabs": true,
                                        "uiTheme": "theme-light",
                                        "unit": "cm",
                                        "zoom": 100
                                    },
                                }, events: {
                                    onReady: function () {

                                    },
                                    onDocumentStateChange: function (event) {
                                        var url = event.data;
                                        

                                        if (!event.data) {

                                            if (value.editedDocument) {

                                            }

                                        }
                                    }

                                }
                            });
                        //this.docValue = encodeURIComponent(response.data.result.data);
                    }

                    if (this.docType == "pdf") {

                        // this.downloadFile(this.docValue, value.mimetype, value.name)

                        // return
                        var _vid = value._id;
                        if (value.parentId) {
                            _vid = value.parentId;
                        }
                        var viewmode = 1; // Enable edit
                        viewmode = 0; //Disabled Edit
                        if (value.viewmode) {
                            viewmode = 0;
                        }
                        let pdfViewUrl ='https://immibox.com/viewer/pdfjs-dist/web/viewerv2.html';            
                        if(_.has(this.$globalgonfig, 'PDF_VIEW_URL')){
                            pdfViewUrl = this.$globalgonfig['PDF_VIEW_URL']; //PDF_EDIT_URL
                        }
                        if(viewmode==1){
                            if(_.has(this.$globalgonfig, 'PDF_EDIT_URL')){
                                pdfViewUrl = this.$globalgonfig['PDF_EDIT_URL']; //PDF_EDIT_URL
                           }
                        }
                        this.docValue = pdfViewUrl+"?view=" + viewmode + "+&file=" + encodeURIComponent(response.data.result.data);
                    }
                    this.docPrivew = true;
                });
            } else {



                this.downloads3file(value);
            }

        },

        downloadFile(url, mimetype, fireName) {
            axios({
                url: url,
                method: 'GET',
                responseType: 'blob',
            }).then((res) => {
                var FILE = window.URL.createObjectURL(new Blob([res.data], { type: mimetype }));

                var docUrl = document.createElement('x');
                docUrl.href = FILE;
                docUrl.setAttribute('download', fireName);
                document.body.appendChild(docUrl);
                docUrl.click();
            });
        },


    },
    mounted() {
        if (this.$route.params && this.$route.params.itemId) {
            this.petitionId = this.$route.params.itemId;
            this.init();
        }
        //this.loadPetetion();
    },
    props: {
        loadedFromPreview: false,
        previewData: null,
    },
    computed: {
        checkCommentLength(){
      return (comment='')=>{
        let textcomment = comment;
        let self = this;
        let returnVal = false;
        if(textcomment){
          var plainText = textcomment.replace(/<[^>]*>/g, '');
          let plainext = plainText.replace(/&nbsp;|&nbsp/g, ' ');
          if(plainext){
            var htmlString = plainext.trim();
            if(htmlString && self.checkProperty(htmlString, 'length') > 100 ){
              returnVal = true
            }
          }
        }
        return returnVal
      }
    },
    returnCommentText(){
      return (comment='')=>{
        let returnVal = '';
        if(comment){
          var plainText = comment.replace(/<[^>]*>/g, ' ');
          let plainext = plainText.replace(/&nbsp;|&nbsp/g, ' ');
          if(plainext){
            returnVal = plainext.trim();
            
          }
        }
        return returnVal
      }
    },
        checkCaseStatus() {
            if (this.checkProperty(this.petition, 'intStatusDetails', 'id') == 1) {
                return this.checkProperty(this.petition, 'intStatusDetails', 'id')
            }
            else {
                return 4
            }
        },
        checkCaseCreatedLogin() {
            let returnVal = true
            let createdBy = null;
            if (this.petition && this.checkProperty(this.petition, 'createdBy')) {
                createdBy = this.checkProperty(this.petition, 'createdBy')
                if (this.checkProperty(this.getUserData, 'userId') && (createdBy == this.checkProperty(this.getUserData, 'userId'))) {
                    returnVal = true
                } else {
                    returnVal = false
                }
            }
            return returnVal
        }
    }
}
</script>