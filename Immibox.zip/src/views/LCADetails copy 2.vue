<template>



<div class="lca-view-details">
    <div class="lca-view-details-top bg-white">
        <div class="lca-top-content mr-6" v-if="lcaDetails.number">
            <p>
                DOL Reference Number
                <span>{{lcaDetails.number}}</span>
            </p>
        </div>

        <div class="form-container flex items-center">
            <template v-for="(docs, docs_index) in lcaDetails.status_documents">
                <div class="lca-top-content" :key="docs_index" v-if="docs_index<=1">

                    <span class="flex items-center" v-for="(item, index) in docs" :key="index">

                        <img class="mr-2" src="@/assets/images/main/icon-pdf.svg" />
                        <a @click="fetchSignedUrl(item)" style="cursor:pointer">
                            <span v-if="docs_index == 1">
                                Certified LCA Document
                            </span>
                            <span v-if="docs_index == 0">
                                DOL Document
                            </span>
                        </a>&nbsp;&nbsp;

                        <span class="doc_header ">
                            <vx-tooltip color="primary" v-bind:text="docs[0]['comment']">
                                <img style="margin-top:3px;" src="@/assets/images/main/info-icon.svg" /></vx-tooltip>
                        </span>

                    </span>

                </div>
            </template>

        </div>
    </div>

    <div class="lca-view-details-bottom">


      <div class="lca-bottom-content" v-if="lcaDetails.clientName!=null">
        <div class="main-list-wrap">
          <div class="vx-row m-0 main-list-panel">
            <div class="vx-col md:w-1/2 w-full p-0">
              <div class="main-list">
                <p>
                  Client Name
                   <span v-if="lcaDetails.clientName">{{lcaDetails.clientName | empty}}</span>

                  <span v-if="lcaDetails.clientName == '' && petition.clientInfo && petition.clientInfo.name" >{{petition.clientInfo.name | empty}}</span>
                </p>
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full p-0">
              <div class="main-list">
                <p>
                  Job Title
                  <span>{{lcaDetails.jobTitle | empty}}</span>
                </p>
              </div>
            </div>
          </div>
          <div class="vx-row m-0 main-list-panel">
            <div class="vx-col md:w-1/2 w-full p-0">
              <div class="main-list">
                <p>
                  SOC Code
                  <span >{{lcaDetails.desiredSOCCode | empty}}</span>
                </p>
              </div>
            </div>
          </div>
          <div class="vx-row m-0 main-list-panel">
            <div class="vx-col md:w-1/2 w-full p-0">
              <ul class="main-list">
                <li>
                  <p>Masters Degree</p>
                  <span >{{lcaDetails.mastersDegree.schoolName | empty}}</span>
                </li>
              </ul>
            </div>
            <div class="vx-col md:w-1/2 w-full p-0">
              <div class="main-list">
                <p>
                  Major
                  <span >{{lcaDetails.mastersDegree.major | empty}}</span>
                </p>
              </div>
            </div>
          </div>
          <div class="vx-row m-0 main-list-panel">
          

            <!-- <div class="vx-col md:w-1/2 w-full p-0">
              
            <div class="main-list" >
              <p >
               Current Position
                <span> {{lcaDetails.position | empty }} </span>
              </p>

            </div>
            </div> -->
            

            <div class="vx-col md:w-1/2 w-full p-0">
              
            <div class="main-list" >
              <p  >
                Salary Offered
                <span>{{lcaDetails.salary?'$':''}} {{lcaDetails.salary | empty }} {{lcaDetails.wageLevelDetails?lcaDetails.wageLevelDetails.name:" "}}</span>
              </p>

            </div>
            </div>

           <div class="vx-col md:w-1/2 w-full p-0">
              <div class="main-list">
                <p >
                  Primary Work Location 
                  <b v-if="lcaDetails.workAddress.workLocation">(Home Work Location)</b>
                  <span v-html="$options.filters.addressformat(lcaDetails.workAddress)"></span>
                </p>
              </div>
            </div>

          </div>
          <div class="vx-row m-0 main-list-panel">
            
            <div class="vx-col md:w-1/2 w-full p-0" v-if="lcaDetails.secondaryWorkAddress && lcaDetails.secondaryWorkAddress.line1!=null">
              <div class="main-list">
                  <p >
                  Second Work Location
                  <b v-if="lcaDetails.secondaryWorkAddress.workLocation">(Home Work Location)</b>
                   <span v-html="$options.filters.addressformat(lcaDetails.secondaryWorkAddress)"></span>
                </p>
              </div>
            </div>


              <div class="vx-col w-full p-0">
              <ul class="main-list">
                <li>
                  <p>Job Duties</p>
                  <span>{{lcaDetails.jobDuties | empty}}</span>
                </li>
              </ul>
            </div>





          </div>
        </div>
      </div>


        </div> </div>
</template>
<script>
export default {
  props: {
    lcaDetails: {
      type: Object,
      default: null
    },
    petition:{
      type: Object,
      default: null
    }
  }
};
</script>