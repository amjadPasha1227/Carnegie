
<template>
<ul>


          <template v-if="documentList.length>0"   >
            <template v-for="(certified ,index) in documentList">
              

               <li  class="flex items-center" :key="index" v-if="checkProperty(certified,'status')"  v-tooltip.top-center="certified.name" > 
           
                <figure>
                
               
                  <img v-if="checkFileFormat(certified['mimetype']) =='pdf'" src="@/assets/images/main/pdf.svg" /> 
                  <img v-else-if="checkFileFormat(certified['mimetype']) =='video_mime_types'" src="@/assets/images/main/film.png" />
                  <img v-else-if="checkFileFormat(certified['mimetype']) =='msDoc'" src="@/assets/images/main/doc.svg" />
                  <img v-else-if="checkFileFormat(certified['mimetype']) =='zip'" src="@/assets/images/main/zip-file-format.png" />
                 <img v-else-if="checkFileFormat(certified['mimetype']) =='msPpt'" src="@/assets/images/main/ppt.svg" />
                 <img v-else-if="checkFileFormat(certified['mimetype']) =='msXl'" src="@/assets/images/main/xls.svg" />
                 <img v-else-if="checkFileFormat(certified['mimetype']) =='image'" src="@/assets/images/main/image.svg" />
                 <img v-else src="@/assets/images/main/icon-img.svg" /> 
                  <span @click="fetchSignedUrl(certified)" class="download_icon"></span>  
                </figure> 
                                
              </li>


            </template>  
          </template>
        </ul>
</template>

<script>
import * as _ from "lodash";
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import Vue from 'vue'
import VTooltip from 'v-tooltip'
import lcaDocuments from '@/views/lcaDocuments'

Vue.use(VTooltip)

export default {
   components: { 
    VuePerfectScrollbar,
    lcaDocuments
   },
  props: {
    documentList:{
      type: Array,
      default: []
    }
   
  },
  data: () => ({

  }),
  mounted() {
      
   
    

  },
  methods: {
      fetchSignedUrl(item){
          this.$emit('fetchSignedUrl',item);
      },
      
  }
};
</script>