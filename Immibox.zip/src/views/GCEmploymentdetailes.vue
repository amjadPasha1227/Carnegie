<template>
  <div class="main-tabs-content tabs_mob petetion__details_page "  :class="{'petetion__details_full_width':!loadedFromPreview,'anonymouslogin':!checkCurrentUrl}" >
    <div class="tabs-layout-header" v-if="!loadedFromPreview">
      <div class="case-no-panel" > 
        <!-- <vs-dropdown>
          <a class="flex items-center">
            <div class="drop-down-content">
              Case No
              <span>{{ checkProperty(petition, "caseNo") }}</span>
            </div>
            <i class="material-icons" v-if="petition">arrow_drop_down</i>
          </a>
          
          <vs-dropdown-menu class="caseno-dropdown" v-if="petitions && checkCurrentUrl">
            <vs-dropdown-item
              @click="petetionChange(petition._id)"
              v-for="(petition, index) in petitions"
              :key="index"
              >{{ petition.caseNo }}</vs-dropdown-item
            >
          </vs-dropdown-menu>
          
        </vs-dropdown> -->
         
        <div class="casenumber_sec">
          <div class="case_number">
            <div class="d-flex align-items-center">
            Case No
            <em class="edit_caseno" v-if=" !loadedFromPreview && [3,4,5].indexOf(getUserRoleId)>-1 && checkProperty(petition ,'_id') ==checkProperty(getPetitionDetails ,'_id') && getPetitionDetails && getPetitionDetails.completedActivities &&  getPetitionDetails.completedActivities.indexOf('ASSIGN_CUSTOM_CASE_NO')>-1 && checkProperty(getPetitionDetails ,'status' )!=false" v-on:click.stop.prevent="editCaseNumber" > 
                <img src="@/assets/images/main/edit_icon.svg" />
                <small>Edit Case No</small>
            </em>
            </div>
            <span>{{ checkProperty(petition, "caseNo") }}


            </span>
            <i class="material-icons" v-if="!loadedFromPreview && checkCurrentUrl&& checkProperty(petitions ,'length')>0">arrow_drop_down</i>
            
          </div>
          <div class="case_number_list"  v-if="!loadedFromPreview && checkCurrentUrl&& checkProperty(petitions ,'length')>0" >
            <VuePerfectScrollbar class="scroll-area">
            <ul v-if="petitions"> 
                <li
              @click="petetionChange(petition._id)"
              v-for="(petition, index) in petitions"
              :key="index"
              >{{ petition.caseNo }}
              
              <!-- <span v-if="petition._id ==petitionId && getPetitionDetails && getPetitionDetails.completedActivities &&  getPetitionDetails.completedActivities.indexOf('ASSIGN_CUSTOM_CASE_NO')>-1" v-on:click.stop.prevent="editCaseNumber" > 
                  
                  <img src="@/assets/images/main/edit_icon.svg" />
 
              </span> -->
              </li>
            </ul>
            </VuePerfectScrollbar>
          </div>
        </div>

      </div>
      
      <ProcessFlow
        @reloadCaseHistory="reloadActivities"
        :caseUsers="caseUsers"
        ref="process_flow"
        :loadedFromPreview="loadedFromPreview"
        v-bind:lettersAndForms="formsAndLettersList"
        v-bind:workFlowDetails="workFlowDetails"
        v-bind:petition="petition"
        :isLcaRequiredForPetition="isLcaRequiredForPetition"
        v-bind:lcaDetails="lcaDetails"
        :configDetails="configDetails"
        @passparent="setActivetab"
        @updatepetition="reloadPetition"
        v-bind:currentRole="currentRole"
        @loadstatus="setActivetabstatus"
        :enable_submit_to_offshore_manager="enable_submit_to_offshore_manager"
        @showfilingFeesPopup="showfilingFeesPopup"
         @download_or_view="download_or_view"
         @openFilingFee="openFilingFee()"
         @opengenFormsAndLatters="opengenFormsAndLatters"
      />
      <div></div>
    </div>
    <!-- content section start here  {{petition.questionnaireFilled}}   -->

    <div
      class="
        tabs-content
        detail_page_sec
        petetion__details
        case-details-box-width
      "
      :class="{'petetion__details_full_width':!loadedFromPreview}"
    >
      <vs-row
        vs-w="12"
        class="bg_white"
        
      >
        <vs-col
          vs-type="flex"
          style="padding: 0px; width: calc(100% - 300px)"
          class="mob-left "  :class="{'w-full':!checkCurrentUrl || [51].indexOf(getUserRoleId)>-1}"
        >
          <section class="petition__details_section" >
            <div class="pd_left">
              <ul>
                <li
                  v-if="
                  (
                    (
                   ( checkProperty(petition, 'questionnaireFilled') || true ) &&
                  getPetitionDetails && getPetitionDetails.completedActivities &&  (getPetitionDetails.completedActivities.indexOf('CREATE_JOB_DESC')>-1 || checkCompletedActivity('EFILE_PWD') || getPetitionDetails.completedActivities.indexOf('PWD_CERTIFID')>-1) ) || (checkProperty(petition ,'hasJobDetails')) 
                  )
                  && getUserRoleId !=51 && !loadedFromPreview
                  "
                  :class="{
                    current_child: getPetitionTab == 'Petition Updates',
                  }"
                  @click="setActivetab('Petition Updates')"
                >
                  <a>Case Updates </a>
                </li>
                <li
                  :class="{
                    current_child: getPetitionTab == 'Case Details' || (getPetitionTab == 'Petition Updates' && getUserRoleId==51   ),
                  }"
                  @click="setActivetab('Case Details', true)"
                >
                  <a>Beneficiary Info </a>
                </li> 
                <li v-if="checkCompletedActivity('CREATE_JOB_DESC') || checkCompletedActivity('PWD_CERTIFID') ||  checkCompletedActivity('EFILE_PWD') || checkProperty(petition ,'hasJobDetails') ==true"
                  :class="{
                    current_child: getPetitionTab == 'Job Details',
                  }"
                  @click="setActivetab('Job Details', true)"
                >
                  <a>PWD Info</a>
                </li>
                <li v-if="checkCompletedActivity('COLLECT_ADV_EVIDENCE')"
                  :class="{
                    current_child: getPetitionTab == 'Advertise Info',
                  }"
                  @click="setActivetab('Advertise Info', true)"
                >
                  <a>Advertise Info </a>
                </li>
              
               <li v-if="checkCompletedActivity('PREPARE_PERM_APPLICATION')"
                  :class="{
                    current_child: getPetitionTab == 'Perm Draft',
                  }"
                  @click="setActivetab('Perm Draft', true)"
                >
                  <a>PERM Info </a>
                </li>
                              
                <li
                  v-if=" ( checkProperty(petition, 'questionnaireFilled') || loadedFromPreview ) "
                      :class="{ current_child: getPetitionTab == 'Documents' }"
                      @click="setActivetab('Documents', true)"
                    >
                      <a>Documents </a>
                </li>
                <li
                  v-if="
                   ( checkProperty(petition, 'questionnaireFilled') || loadedFromPreview ) &&
                   ([5, 8].indexOf(checkProperty(petition ,'subTypeDetails' ,'id')) <=-1) &&
                    checkProperty(petition, 'dependentsInfo', 'spouse') &&
                    (checkProperty( petition['dependentsInfo'], 'spouse', 'name' ) || checkProperty( petition['dependentsInfo'], 'spouse', 'firstName' ) )
                  "
                  :class="{
                    current_child: getPetitionTab == 'Dependents Info',
                  }"
                  @click="setActivetab('Dependents Info', true)"
                >
                  <a>Dependents Info </a>
                </li>
                
                <li
                  v-if="
                   ( checkProperty(petition, 'questionnaireFilled') || loadedFromPreview ) &&
                  ([5, 8].indexOf(checkProperty(petition ,'subTypeDetails' ,'id')) <=-1) &&
                    checkProperty(petition, 'dependentsInfo', 'childrens') &&
                    petition.dependentsInfo.childrens.length > 0 &&
                    petition.dependentsInfo.childrens[0].hasChildren &&
                    (checkProperty(petition.dependentsInfo.childrens[0], 'name') ||
                      checkProperty(petition.dependentsInfo.childrens[0], 'firstName'))"
                  :class="{ current_child: getPetitionTab == 'Children Info' }"
                  @click="setActivetab('Children Info', true)"
                >
                  <a>Children Info</a>
                </li>
          
                 <template v-if="checkCurrentUrl" >

             
                <li
                  v-if="currentRole != 51 && !loadedFromPreview && isLcaRequiredForPetition && false"
                  :class="{ current_child: getPetitionTab == 'LCA' }"
                  @click="setActivetab('LCA', true)"
                >
                  <a>LCA </a>
                </li>
                   <li
                  v-if=" ( checkProperty(petition, 'questionnaireFilled') ) && checkProperty(petition, 'clinetshowed')"
                  :class="{ current_child: getPetitionTab == 'Client Info' }"
                  @click="setActivetab('Client Info', true)"
                >
                  <a>Client Info</a>
                </li>

                <li
                  v-if="
                   (
                     checkProperty(petition, 'questionnaireFilled') || checkProperty(petition, 'invoiceId') ) && !loadedFromPreview  &&
                   // getPetitionDetails.completedActivities.indexOf('FILING_FEE')>-1&&
                 //   petition &&
                 //   checkProperty(petition, 'filingFeeDetails' ) &&
                 //   petition['filingFeeDetails'] != null &&
                    currentRole != 51 && 
                    //currentRole != 50 &&
                    
                   // feeInvoicesPermessions &&
                   ( checkProperty(petition, 'tenantDetails', 'typeId') != 2 || (checkProperty(petition, 'tenantDetails', 'typeId') == 2 &&checkProperty(petition, 'typeDetails', 'id') == 3))
                   && ( checkProperty(petition, 'completedActivities', 'length')>0 && petition.completedActivities.indexOf('SUBMIT_TO_LAW_FIRM') >-1)
                    
                  "
                  :class="{ current_child: getPetitionTab == 'Fees/Invoices' }"
                  @click="setActivetab('Fees/Invoices', true)"
                >
               
                  <a>Fees/Invoices </a>
                </li>

                <li
                  v-if=" (
                  (( checkProperty(petition, 'questionnaireFilled') ) && !loadedFromPreview && checkFormsAndLattersPermissions)

                 && petition.completedActivities.indexOf('DOL_AUDIT')>-1
                  )
                  "
                  :class="{
                    current_child: getPetitionTab == 'Forms and Letters',
                  }"
                  @click="setActivetab('Forms and Letters', true)"
                >
                  <a>Audit Response</a>
                </li>
                <li
                  :class="{
                    current_child: getPetitionTab == 'Scanned Documents',
                  }"
                  @click="setActivetab('Scanned Documents', true)"
                  

                  v-if="(( checkProperty(petition, 'questionnaireFilled') ) && [51].indexOf(currentRole) < 0 && checkrequestSigninActivityCompleted) && false "
                >
                  <a>Scanned/Signed Documents</a>
                </li>
                <li
                  :class="{ current_child: getPetitionTab == 'Company Docs' }"
                  @click="setActivetab('Company Docs', true)"
                  v-if="
                   ( checkProperty(petition, 'questionnaireFilled') ) && !loadedFromPreview &&
                    [3, 4, 5, 6, 7, 8, 9, 10, 11, 12].indexOf(currentRole) >
                      -1 && getTenantTypeId != 2
                  "
                >
                  <a>Company Docs</a>
                </li>
                <li
                  v-if=" ( checkProperty(petition, 'questionnaireFilled') ) && !loadedFromPreview"
                  :class="{
                    current_child: getPetitionTab == 'Recent Documents',
                  }"
                  @click="setActivetab('Recent Documents', true)"
                >
                  <a>Recent Downloads</a>
                </li>
                <li
                    v-if="!loadedFromPreview"
                  :class="{ current_child: getPetitionTab == 'Communication' }"
                  @click="setActivetab('Communication', true)"
                >
                  <a>Messages</a>
                </li>

                <li
                    v-if="!loadedFromPreview"
                  :class="{ current_child: getPetitionTab == 'notes' }"
                  @click="setActivetab('notes', true)"
                >
                  <a>Notes</a>
                </li>


              </template>

              </ul>
            </div>

            <div class="pd_right petition__details_cnt">
              <div class="pd_right_cnt">
                <div  class="no-activities q_not_submitted" v-if="false&&caseNotAvailable">

                  <div class="q_not_submitted_cnt">
                    <figure>
                      <img src="@/assets/images/main/no-activity-img.png" />
                      <h3></h3>
                    </figure>
                  </div>
                </div>

                <div
                  class="pad20"
                  v-if="
                    
                    getPetitionTab == 'Petition Updates'   && getUserRoleId !=51 && !loadedFromPreview
                  "
                >
                  <PetitionUpdates
                   ref="PetitionUpdatesRef"
                    v-bind:petition="petition"
                    @download_or_view="download_or_view"
                    :currentCaseDetails="caseCurrentDetails"
                    @reloadPetitionMe="setActivetab"
                    v-bind:workFlowDetails="workFlowDetails"
                    @updatepetition="reloadPetition"
                  />
                </div>
                <template v-if="  getPetitionTab == 'Case Details' || (getPetitionTab == 'Petition Updates' && getUserRoleId==51)">
                      <div 
                        v-if="(loadedFromPreview && petition.beneficiaryInfo!=null && petition.beneficiaryInfo.firstName!=null) ||
                        ( checkProperty(petition, 'questionnaireFilled') ) 
                         // checkProperty(petition, 'beneficiaryInfo') &&
                         // getPetitionTab == 'Case Details'
                        "
                      >
                        <BeneficiaryDetails
                          v-bind:petition="petition"
                          :visastatuses="visastatuses"
                          :questionnaireDetails="questionnaireDetails"
                        />
                      </div>
                      <div v-else class="no-activities q_not_submitted">

                        <div class="q_not_submitted_cnt">
                          <figure>
                            <img src="@/assets/images/main/no-activity-img.png" />
                          </figure>
                          <h3 :removeAction="updatePetiotionActionBtn(false)">
                            <!-- <template v-if="[3,4 ,5,50,51].indexOf(getUserRoleId)>-1" > <router-link  :to="{ name: 'perm-questionnaire', params: { 'id':petition._id }}"> Fill Questionnaire.</router-link></template> -->
                            <template v-if="checkCaseStatus == 1">
                                 <template v-if="[3,4 ,6,8 ,5,50,51].indexOf(getUserRoleId)>-1" > <a  href="#" @click="goToQuestionaireLink(petition._id)"> Fill Questionnaire.</a></template>
                                 <template v-else >Questionnaire Not Submitted Yet</template>
                            </template>
                            <template v-else>
                              Questionnaire Not Submitted Yet
                            </template>
                          </h3>
                        </div>
                      
                      </div>
                </template>
                <div
                  v-if="
                    
                    getPetitionTab == 'Job Details'
                  "
                >
                
                  <permJobDetails
                    v-bind:petition="petition"
                    @download_or_view="download_or_view"
                    v-bind:workFlowDetails="workFlowDetails"
                    @openActionMenu="openActionMenu"
                  />
                </div>
                <div
                  v-if="
                    
                    getPetitionTab == 'Perm Draft'
                  "
                >
                  <permDraftDetails
                    v-bind:petition="petition"
                    :visastatuses="visastatuses"
                    @download_or_view="download_or_view"

                      :currentCaseDetails="caseCurrentDetails"
                      @reloadPetitionMe="setActivetab"
                    v-bind:workFlowDetails="workFlowDetails"
                    @updatepetition="reloadPetition"
                  />
                </div>
                <div
                  v-if="
                    
                    getPetitionTab == 'Advertise Info'
                  "
                >
                  <permAdvertiseInfo
                    v-bind:petition="petition"
                    @download_or_view="download_or_view"
                    @openAdv="openActionMenu"
                  />
                </div>
                <div
                  v-if="
                    checkProperty(petition, 'dependentsInfo', 'spouse') &&
                    (checkProperty( petition['dependentsInfo'], 'spouse', 'name' ) || checkProperty( petition['dependentsInfo'], 'spouse', 'firstName' ) ) &&
                    getPetitionTab == 'Dependents Info'
                  "
                >
                  <SpouseDetails
                   :loadedFromPreview="loadedFromPreview"
                    v-bind:petition="petition"
                    @download_or_view="download_or_view"
                    :questionnaireDetails="questionnaireDetails"
                    :callFromPerm="true"
                  />
                </div>
                <div
                  class="pad20"
                  v-if="
                    checkProperty(petition, 'dependentsInfo', 'childrens') &&
                    petition.dependentsInfo.childrens.length > 0 &&
                    petition.dependentsInfo.childrens[0].hasChildren &&
                    (checkProperty(petition.dependentsInfo.childrens[0], 'name') ||
                      checkProperty(petition.dependentsInfo.childrens[0], 'firstName')) &&
                    getPetitionTab == 'Children Info'
                  "
                >
                  <ChildDetails
                  :loadedFromPreview="loadedFromPreview"
                    v-bind:petition="petition"
                    :visastatuses="visastatuses"
                    @download_or_view="download_or_view"
                    :questionnaireDetails="questionnaireDetails"
                    :callFromPerm="true"
                  />
                </div>

                <div
                  v-if="
                    checkProperty(petition, 'clinetshowed') &&
                    getPetitionTab == 'Client Info'
                  "
                >
                  <ClientDetails v-bind:petition="petition" />
                </div>

                <div v-if="getPetitionTab == 'Fees/Invoices'">
                  <Fees
                    @download_or_view="download_or_view"
                     @updatepetition="reloadPetition"
                    @showfilingFeesPopup="showfilingFeesPopup"
                    v-bind:currentRole="currentRole"
                    v-bind:petition="petition"
                    :workFlowDetails="workFlowDetails"
                  />
                </div>
                <!----LCA---->
                <div v-if="getPetitionTab == 'LCA'">
              
                  <RequestLCA
                    v-if="
                      ((!checkProperty(petition, 'lcaId') ||
                        petition.lcaId == null) || (isEditLca  && petition.lcaId)) &&
                      (checkPetitionLcaSubmit || checkPetitionLcaRequired)
                    "
                    v-bind:petition="petition"
                    @updatepetition="reloadPetition"
                    @editLca="editLca"

                  />
                 
                  <LCADetails
                    :showStatusButton="true"
                    v-if="lcaDetails != null && !isEditLca"
                    v-bind:currentRole="currentRole"
                    v-bind:lcaDetails="lcaDetails"
                    v-bind:petition="petition"
                    :showLcaActivity="false"
                    @download_or_view="download_or_view"
                    @updatepetition="reloadPetition"
                    @editLca="editLca"
                  />
                </div>

                <div
                  v-if="
                    checkProperty(petition, 'documents') &&
                    getPetitionTab == 'Documents'
                  "
                >
                  <Documents
                    @updatepetition="reloadDocuments"
                    :openTabes="true"
                    @download_or_view="download_or_view"
                    :documentsUploadbtn="true"
                    :loadedFromPreview="loadedFromPreview"
                    :currentRole="currentRole"
                    :allbtn="true"
                    v-bind:petition="petition"
                    v-bind:workFlowDetails="workFlowDetails"
                    :editableDocs="true"
                    v-if="reRenderDocuments"
                    :fieldsArray="questionnaireDetails"
                  />
                </div>
                <div  v-if="getPetitionTab == 'Recent Documents' ">
                  <recentDocuments
                  @download_or_view="download_or_view"
                   v-bind:petition="petition"
                 />
                </div>

                <!----Forms and Letters---->
                <div v-if="getPetitionTab == 'Forms and Letters'">
                  <FormsandLetters
                    :configDetails="configDetails"
                    :currentUser="currentUserId"
                    v-bind:currentRole="currentRole"
                    @download_or_view="download_or_view"
                    @updatepetition="reloadPetition"
                    @showfilingFeesPopup="showfilingFeesPopup"
                    v-bind:petition="petition"
                    @enableAction="enableAction"
                    ref="FormsAndLetters"
                  />
                </div>

                <div
                  v-if="
                    [ 51].indexOf(currentRole) < 0 &&
                    getPetitionTab == 'Scanned Documents'
                  "
                >
                  <ScannedCopies
                    :currentUser="currentUserId"
                    v-bind:currentRole="currentRole"
                    @download_or_view="download_or_view"
                    @updatepetition="reloadPetition"
                    @showfilingFeesPopup="showfilingFeesPopup"
                    v-bind:petition="petition"
                  />
                </div>

                <!----Company Docs--->
                <div
                  v-if="
                    [3, 4, 5, 6, 7, 8, 9, 10, 11, 12].indexOf(currentRole) >
                      -1 && getPetitionTab == 'Company Docs'
                  "
                >
                  <CompanyDocsTemplates
                    :companyId="
                      checkProperty(petition, 'companyDetails', '_id')
                    "
                    :uploadCompanyDocs="(checkProperty(getPetitionDetails ,'status' )!=false)"
                    :currentUser="currentUserId"
                    v-bind:currentRole="currentRole"
                    @download_or_view="download_or_view"
                    @updatepetition="reloadPetition"
                    @showfilingFeesPopup="showfilingFeesPopup"
                    v-bind:petition="petition"
                    @enableAction="enableAction"
                  />
                </div>
                <div v-if="getPetitionTab == 'Communication'">
                  <Communication 
                  v-bind:workFlowDetails="workFlowDetails"
                    v-bind:petition="petition"
                    v-bind:userId="currentUserId"
                  />
                </div>
                <div v-if="getPetitionTab==='notes'">
                  <notes 
                 
                  @download_or_view="download_or_view"
                  @updatepetition="reloadPetition"
                  v-bind:petitionDetails="petition"
                  :loadedFromPreview="loadedFromPreview"
                  :loadedFromCaseDetails="true"
                  
                  />
                
                </div>
              </div>
              
            </div>
            
          </section>

          <div
            v-if="
              isEveryThingLoaded &&
              petition &&
              checkProperty(petition, 'questionnaireFilled') == 'false---'
            "
            class="no-activities q_not_submitted"
          >
          <div class="q_not_submitted_cnt">
            <figure>
              <img src="@/assets/images/main/no-activity-img.png" />
            </figure>
            <h3 :removeAction="updatePetiotionActionBtn(false)">
              <!-- <template v-if="[3,4 ,5,50,51].indexOf(getUserRoleId)>-1" >  <router-link  :to="{ name: 'perm-questionnaire', params: { 'id':petition._id }}"> Fill Questionnaire. </router-link></template> -->
              <template v-if="checkCaseStatus == 1">
                <template v-if="[3,4 ,5 ,6,8,50,51].indexOf(getUserRoleId)>-1" >  <a  href="#" @click="goToQuestionaireLink(petition._id)"> Fill Questionnaire.</a></template>
                <template v-else >Questionnaire Not Submitted Yet</template>
              </template>
              <template v-else>
                Questionnaire Not Submitted Yet
              </template>  
           
             <!-- Questionnaire Not Submitted Yet -->
            </h3>
          </div>
      </div>
        </vs-col>

        <vs-col
          vs-type="flex"
          class="padr0 padl0 mob-right activies_list_wrap status_wrap"
          style="width: 300px; flex-direction: column;"
          v-if="!loadedFromPreview && checkCurrentUrl && [51].indexOf(getUserRoleId)<=-1"
        >
        <!-- Newly Added -->
          <ul v-if="checkCurrentUrl && !loadedFromPreview">
            <li class="ptstatusBar "  v-if="[51].indexOf(getUserRoleId)<0">
              <div class="status_activities" :class="{'status_activities_full':[50,51].indexOf(getUserRoleId)>-1}">
                <label :class="{ 'active':getCaseStatusTab =='showCaseStatus' || ([50,51].indexOf(getUserRoleId)>-1 && getCaseStatusTab !='showCaseStatus')}" @click="reloadCaseHistory('showCaseStatus'); $store.commit('toggleCaseStatusTab','showCaseStatus')"  >Status</label>
                <label v-if="[50,51 ].indexOf(getUserRoleId)<=-1" :class="{ 'active':getCaseStatusTab !='showCaseStatus'}"  @click="reloadCaseHistory('showActivities');$store.commit('toggleCaseStatusTab','showActivities')" >Activities </label>
              </div>
            </li>
          </ul>
          <div class="status_list gc_status" v-if="(getCaseStatusTab=='showCaseStatus' ) || ([50,51].indexOf(getUserRoleId)>-1 && getCaseStatusTab !='showCaseStatus')">
            
            <VuePerfectScrollbar class="scroll-area" >
              <caseStatusList v-if="workFlowDetails" :workFlowDetails="workFlowDetails"  :petition="petition" v-bind:workFlowDetails="workFlowDetails" :currentCaseDetails="caseCurrentDetails" :scannedDocumentsList="scannedDocumentsList" />
            </VuePerfectScrollbar>
            <div class="deadline" v-if=" ( checkProperty(petition ,'deadlineDate') && [1, 2,51].indexOf(getUserRoleId) < 0)" > Deadline {{petition.deadlineDate | formatDate}}</div>  
            <!-- <div class="deadline" v-if=" ( checkProperty(petition ,'permFileDeadlineDate') && [1, 2,51].indexOf(getUserRoleId) < 0)" >PERM File Deadline is {{petition.permFileDeadlineDate | formatDate}}</div>   -->
          </div>
          <div v-else class="history-sidebar petition_history activies_list ">
            <div class="vs-sidebar">
              <div class="petition_updated" v-if="petitionhistory.length == 0">
                Last Updated -
                {{ checkProperty(petition, "updatedOn") | formatDateTime }}
              </div>
              <div class="petition_updated" v-if="petitionhistory.length > 0">
                Last Updated - {{ petitionhistory[0].createdOn | formatDateTime }}
              </div>

              <div class="vs-sidebar--items">
                <VuePerfectScrollbar class="scroll-area">
                  <div class="timeline-sidebar 2">
                    <ul>
                      <li
                        v-for="(history, index) in petitionhistory"
                        :key="index"
                      >
                        <div class="timeline-icon">
                          <i class="icon IP-tick-sign"></i>
                        </div>
                        <div class="timeline-info">
                          <button class="btn active-green ml-0">
                            {{ history.createdByRoleName }}
                          </button>
                          <ul>
                            <li>
                              <h3><span>
                                {{ history.title }}
                              </span>
                                <div
                                  v-if="
                                    history.comment && history.comment != ''
                                  "
                                  class="title_des"
                                >
                                  <small></small>
                                  <div class="dec-content">
                                    <!-- <p v-html="history.comment"></p> -->
                                    <p> {{ returnCommentText(history.comment) | commentSubString }}</p>
                                    <span v-if="checkCommentLength(history['comment'])"  class="view_more" @click="showHistoryComment(history)"> View More</span>
                                  </div>
                                </div>
                              </h3>

                              <span>{{ history.description }}</span>
                             <span>{{
                                history.createdOn | formatDateTime
                              }}</span>
                                 <!----(checkProperty(history ,'action' ) =='MANAGE_PREMIUM_PROCESS' || checkProperty(history, 'action') == 'PERM_DOC_DELETE')  && 
                                  <figcaption>{{checkProperty(history['documents'][0] ,'name')}}</figcaption>-->
                               <!-- <p calss="cursor-pointer" style="margin-top: 5px;cursor: pointer; "   
                               v-if=" checkProperty(history ,'documents' ,'length')>0 "
                                @click="download_or_view(history['documents'][0])">
                                 <docmentType :title="checkProperty(history['documents'][0] ,'name')"  :item="history['documents'][0]" />
                                
                            
                             
                              </p> -->
                              <!-- {{ typeof(history['documents']) }}  v-if="isArrayy({'dataVar':history['documents']})"-->
                                <p class="m-0" v-if="checkProperty(history, 'documents') && checkProperty(history, 'documents', 'length') > 0" >
                                  <ul class="activities_doc_list">
                                    <template v-for="(doc,indoc) in history['documents']" >
                                      <template v-if="checkProperty(doc, 'path')">
                                        <li class="cursor-pointer" @click="download_or_view(doc)" >
                                          <docmentType :title="checkProperty(doc, 'name')" :item="doc" />
                                        </li>
                                      </template>
                                    </template>
                                  </ul>
                                </p>
                            </li>
                          </ul>
                        </div>
                      </li>
                    </ul>
                  </div>
                </VuePerfectScrollbar>
              </div>
            </div>
          </div>
          


        </vs-col>
      </vs-row>
      <!-- <div
        v-if="
          isEveryThingLoaded &&
          petition &&
          checkProperty(petition, 'questionnaireFilled') == false
        "
        class="no-activities q_not_submitted"
      >
        <figure>
          <img src="@/assets/images/main/no-activity-img.png" />
        </figure>
        <h3 :removeAction="updatePetiotionActionBtn(false)">
          Questionnaire Not Submitted Yet
        </h3>
      </div> -->
     <!-----
      <div class="nocontent-layer" v-if="caseNotAvailable"></div>
    -->
    </div>

    <vs-popup
      class="holamundo success-popups"
      title="Your registration is complete."
      :active.sync="SuccessQuestionnaire"
    >
      <figure>
        <img
          src="@/assets/images/main/icon-note.svg"
          alt="login"
          class="mx-auto"
        />
      </figure>
      <h2 class="title">
        USCIS receipt has been
        <br />sent to the Petitioner
      </h2>
    </vs-popup>

    <vs-popup
      class="document_modal document_modal-v2"
      :class="{ expand: expandModal }"
      :title="checkProperty(selectedFile, 'name')"
      :active.sync="docPrivew"
    >
    <div class="document_actions" @click="expandModal = !expandModal">
      <figure v-if="!expandModal" class="maximize-img"><img src="@/assets/images/maximize.png"  width="18" height="18"/></figure>
      <figure v-else class="minimize-img"><img src="@/assets/images/minimize.png"  width="20" height="20"/></figure>
    </div>
      <h2> <img 
          :class="{
            pdf_view_download: docType == 'pdf',
            office_view_download: docType == 'office',
            image_view_download: docType == 'image',
          }"
          class="download-button"
          @click="downloads3file(selectedFile)"
          src="@/assets/images/download.svg"
        /></h2>
       
      <div class="pdf_loader" >
     <figure v-if="formSubmited" class="loader loader2"><img src="@/assets/images/main/loader.gif" /></figure>
       
        <!-- <span :class="{'pdf_view_close':docType == 'pdf', 'office_view_close':docType == 'office'  , 'image_view_close 33':docType =='image'}" class="close close2" @click="docPrivew= false"></span> -->
        <template v-if="docType == 'office'">
                       <div   style="height:90vh">

             <div  id="placeholder" style="height:100%"></div>
</div>

        </template>
        <template v-else-if="docType == 'image'">
          <img :src="docValue" />
        </template>
        <template v-else-if="docType == 'pdf'">
          <div class="pdf" style="height:90vh">
            
           <iframe v-if="docValue!=''" border="0" style="border:0px;" :src="docValue" height="100%" width="100%">

           </iframe>
          </div>
        </template>
      </div>
    </vs-popup>

    <modal
      name="FilingFeesModal"
      classes="v-modal-sec"
      :min-width="200"
      :min-height="200"
      :scrollable="true"
      :reset="true"
      width="800px"
      height="auto"
    >
      <div class="v-modal">
        <div class="popup-header fromDetailsPage">
          <h2 class="popup-title">Filing Fees</h2>
          <span @click="$modal.hide('FilingFeesModal')">
            <em class="material-icons">close</em>
          </span>
        </div>
        <form data-vv-scope="filingFeesform"  @submit.prevent>
          <div @click="filingFeeformerrors = ''" class="form-container filingFeesformcontainer editfeeform">
            <div class="filing_fields w-100">
              <template v-if="checkProperty(petition,'filingFeeCategoryType')=='pre_defined'">
                
                <div class="form-container">
                <div class="vx-row">
                  <div class="pre_defined_sec" >
                     <vs-table :data="filingFeeData">
                     
                      <template v-if="filingFeeData.length > 0" slot="thead">
                        <vs-th>Fee Type</vs-th>
                        <vs-th>Amount($)</vs-th>
                        <vs-th>Exclude from Invoice</vs-th>
                      </template>
                      <template slot-scope="{ data }">
                        <vs-tr>
                          <vs-td colspan="3"> 
                          <h3>USCIS Fees</h3>
                          </vs-td>
                        </vs-tr>
                        <vs-tr :data="filingFee" :key="index" v-for="(filingFee ,index) in filingFeeData" class="vs-table--tr" v-if="filingFee.descriptionType=='USCIS'">
                          <vs-td>{{ filingFee.description  }}</vs-td>
                          <vs-td>
                           
                            <div class="comments_sec mb-0">
                                  <vs-input
                                  data-vv-as="Amount"
                                  v-validate="'required'"
                                  v-model="filingFee.amount"
                                  :name="'amountUSCIS'+index"
                                  v-mask="'#####'"
                                  class="amount_input"
                                />
                                <span
                                  class="text-danger text-sm"
                                  v-show="errors.has('filingFeesform.amountUSCIS'+index)"
                                  >{{ errors.first("filingFeesform.amountUSCIS"+index) }}
                                </span>
                            </div>
                          </vs-td>
                          <vs-td>
                            <div class="form_group">
                                <div class="con-select w-full select-large">
                                  <vs-checkbox v-model="filingFee.invoice" :name="'amountUSCISinvoice'+index"
                                  ></vs-checkbox>
                                </div>
                            </div>
                          </vs-td>
                        </vs-tr>
                        <vs-tr>
                          <vs-td colspan="3"> 
                            <h3>Attorney Fee</h3>
                          </vs-td>
                        </vs-tr>                        
                        <vs-tr :data="filingFee" :key="index" v-for="(filingFee ,index) in filingFeeData" class="vs-table--tr" v-if="filingFee.descriptionType=='Internal'">
                          <vs-td>{{ filingFee.description  }}</vs-td>
                          <vs-td>
                            <div class="comments_sec mb-0">
                                  <vs-input
                                  data-vv-as="Amount"
                                  v-validate="checkProperty(getUserData, 'tenantDetails', 'slug') == 'slg'?'':'required'"
                                  v-model="filingFee.amount"
                                  :name="'amountAttorney'+index"
                                  v-mask="'#####'"
                                  class="amount_input"
                                />
                                <span
                                  class="text-danger text-sm"
                                  v-show="errors.has('filingFeesform.amountAttorney' + index)"
                                  >{{ errors.first("filingFeesform.amountAttorney" + index) }}
                                </span>
                            </div>
                          </vs-td>
                          <vs-td>
                            <div class="form_group">
                                <div class="con-select w-full select-large">
                                  <vs-checkbox v-model="filingFee.invoice" :name="'invoiceAttorney' + index"
                                  ></vs-checkbox>
                                </div>
                            </div>
                          </vs-td>
                        </vs-tr>
                      </template>
                     </vs-table>
                  
              
                    </div>
                <div class="vx-col w-full" @click="value = [];uploading=false;DocErr=false">
                <div class="form_group file_group">
                  <div class="vs-component marb10">
                    <label class="form_label">Cheques<em>*</em></label>
                    <div class="relative">
                      <file-upload v-model="value" class="file-upload-input upload_file justify-center"
                        :accept="allDocEntity"
                        :name="'Documents'" :multiple="true" :hideSelected="true" @input="upload(value)"
                      >
                        <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                        Upload
                      </file-upload>
                      <span v-if="uploading" class="loader"><img src="@/assets/images/main/loader.gif" /></span>
                      
                      <!-- <input type="hidden" :name="'Documents'" v-validate="'required'"  data-vv-as="Documents"  v-model="filingFeeDocs"> -->
                      <span class="text-danger text-sm" v-if="DocErr">*Documents are required</span>
                    </div>
                  </div>
                  <ul class="uploaded-list note_uploads">
                    <template v-for="(item, index) in filingFeeDocs">
                      <vs-chip @click="remove(item, filingFeeDocs, index)" :key="index" closable>
                        {{ item.name }}
                      </vs-chip>
                     
                    </template>
                  </ul>
                </div>
              </div>
                </div>
              </div>
              </template>
              <template v-else>
                <div class="filing_fees_v2">
                  <template vs-w="12" v-for="(filingFee, index) in filingFeeData">
                    <div class="amount_sec" :key="index">
                      <vs-row>
                        <vs-col vs-xs="12">
                          <div class="form_group">
                            <label class="form_label">Description<em>*</em></label>
                              <!-- <vs-textarea
                                data-vv-as="Description"
                                v-validate="'required'"
                                v-model="filingFee.description"
                                :name="'filingdescription' + index"
                                class="w-full"
                              /> -->
                              <ckeditor data-vv-as="Description"
                                v-validate="'required'"
                                v-model="filingFee.description"
                                :name="'filingdescription' + index"
                                class="w-full"  :editor="editor" :config="editorConfig"></ckeditor>


                              <span
                                class="text-danger text-sm"
                                v-show="
                                  errors.has(
                                    'filingFeesform.filingdescription' + index
                                  )
                                "
                                >{{
                                  errors.first(
                                    "filingFeesform.filingdescription" + index
                                  )
                                }}</span
                              >
                          </div>
                        </vs-col>
                        <vs-col vs-xs="12">
                          <vx-input-group>
                            <div class="form_group">
                              <label class="form_label">Amount($)<em>*</em></label>
                              <div class="comments_sec mb-0">
                                <vs-input
                                data-vv-as="Amount"
                                v-validate="'required'"
                                v-model="filingFee.amount"
                                :name="'amount' + index"
                                v-mask="'##############'"
                                class="amount_input"
                              />
                              <span
                                class="text-danger text-sm"
                                v-show="errors.has('filingFeesform.amount' + index)"
                                >{{
                                  errors.first("filingFeesform.amount" + index)
                                }}</span
                              >
                              <div class="delete" v-if="filingFeeData.length > 1" @click="removefilingfee(index)">
                                <a >
                                  <img
                                    src="@/assets/images/main/delete-row-img.svg"
                                  />
                                </a>
                              </div>
                              </div>
                              
                            </div>
                            <!-- <vs-checkbox
                                v-model="filingFee.invoice"
                                :name="'invoice'+index"
                                >Exclude from invoice</vs-checkbox> -->
                          </vx-input-group>
                        </vs-col>
                      </vs-row>
                      <vs-row class="border-0">
                        <vs-checkbox
                          v-model="filingFee.invoice"
                          :name="'invoice' + index"
                          class="mt-2">Exclude from invoice</vs-checkbox
                        >
                      </vs-row>
                    </div>
                  </template>
                </div>
              <vs-row class="more_btn_wrap">
                <vs-col
                  class="float-none pl-0 pt-3 pb-5 more_btn"
                  vs-type="flex"
                  vs-align="center"
                >
                  <a @click="addfilingfee" class="add-more ml-0" type="filled">
                    <span>+</span> More
                  </a>
                </vs-col>
              </vs-row>
              <vs-row>
                    <vs-col vs-lg="12" vs-sm="12" vs-xs="12">
                      <div class="filing_comments p-0">
                        <div class="form_group">
                          <label class="form_label">Note<em>*</em></label>
                          <!-- <vs-textarea
                            data-vv-as="Note"
                            v-validate="'required'"
                            v-model="filingFeeComment"
                            :name="'filingFeeComment'"
                            class="w-full"
                          /> -->
                          <ckeditor  data-vv-as="Note"
                            v-validate="'required'"
                            v-model="filingFeeComment"
                            :name="'filingFeeComment'"
                            class="w-full" :editor="editor" :config="editorConfig"></ckeditor>

                          <span
                            v-if="validatefilingFeeDescrition"
                            class="text-danger text-sm"
                            v-show="errors.has('filingFeesform.filingFeeComment')"
                            >{{ errors.first("filingFeesform.filingFeeComment") }}</span
                          >
                        </div>
                      </div>
                      <!--
                      <vs-checkbox
                          v-model="emailInvoice"
                          :name="'invoice'+index"
                        >Email Invoice</vs-checkbox>
                        -->
                    </vs-col>
              </vs-row>
              </template>
            </div>
          </div>
          <div
            class="text-danger text-sm formerrors"
            v-show="filingFeeformerrors"
          >
            <vs-alert
              color="warning"
              class="warning-alert reg-warning-alert no-border-radius"
              icon-pack="IntakePortal"
              icon="IP-information-button"
              active="true"
              >{{ filingFeeformerrors }}</vs-alert
            >
          </div>
          <div class="popup-footer relative">
            <span class="loader" v-if="submitingFilingFee"
              ><img src="@/assets/images/main/loader.gif"
            /></span>
            <vs-button
              color="dark"
              @click="$modal.hide('FilingFeesModal')"
              class="cancel"
              type="filled"
              >Cancel</vs-button
            >
            <!-----checkProperty(petition ,'filingFeeDetails') && checkProperty(petition,'filingFeeDetails','amount') > 0-->
            <vs-button
              color="success"
               v-if="editFilngFee "
              :disabled="submitingFilingFee"
              @click="createOrupdateInvoice"
              class="save"
              type="filled"
              >
              Update</vs-button
            >
            <vs-button
              color="success"
              v-else
              :disabled="submitingFilingFee"
              @click="submitFilingFees"
              class="save"
              type="filled"
              >Submit</vs-button
            >
          </div>
        </form>
      </div>
    </modal>

    <vs-popup style="z-index:99999999;"  class="holamundo main-popup"  title="Save Document" :active.sync="saveEditedFile">
      <div class="form-container" @click="errorMessage=''" >
        
        <div class="vx-row">
          <div class="vx-col w-full">
          <p>Changes made will be saved as new version.</p>
          
         
            
          </div>
          
        </div>

         <div v-show="errorMessage">
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
              icon="IP-information-button" active="true">{{ errorMessage}}</vs-alert>
          </div>
       
      </div>
      <div class="popup-footer relative">
        <vs-button color="dark" class="cancel" type="filled" @click="saveEditedFile=false">Cancel </vs-button>
        <template >   
           <figure v-if="formSubmited" class="loader loader2"><img src="@/assets/images/main/loader.gif" /></figure>
            <vs-button color="success"  v-if="!checkProperty(getDelectedForEditDocument ,'editedDocument')" :disabled="formSubmited"  class="save" type="filled" @click="uploadSavedFileToS3()">Ok</vs-button>
            <vs-button color="success" v-else  :disabled="formSubmited"  class="save" type="filled" @click="updateExistingDocument()">Yes</vs-button>
            
        </template>
        
      </div>
  </vs-popup>
  <modal
      name="historyComment"
      classes="v-modal-sec"
      :min-width="200"
      :min-height="200"
      :scrollable="true"
      :reset="true"
      width="800px"
      height="auto"
    >
      <div class="v-modal">
        <div class="popup-header fromDetailsPage">
          <h2 class="popup-title">Comment</h2>
          <span @click="$modal.hide('historyComment');selectedHistory=null">
            <em class="material-icons">close</em> 
          </span>
        </div>

        <div class="form-container">
                <div class="vx-row mb-2">
                    <div class="vx-col w-full comment_modal">
                        <p style="line-height: 20px" v-html="checkProperty(selectedHistory ,'comment')">
                         
                        </p>
                    </div>
                </div>
            </div>
            <div class="popup-footer">
                <vs-button color="dark" class="cancel" type="filled" @click="$modal.hide('historyComment');selectedHistory=null">Cancel</vs-button>
                
            </div>

       
        </div>
    </modal> 
  </div>
</template>

<script>

import VuePerfectScrollbar from "vue-perfect-scrollbar";
import FormsandLetters from "./petition/FormsLetters";
import CompanyDocsTemplates from "./petition/CompanyDocsTemplates";
import ScannedCopies from "./ScannedCopies";
import ProcessFlow from "./petition/ProcessFlow";
import RequestLCA from "./RequestLCA";
import LCADetails from "./LCADetails";
import PetitionUpdates from "./petition/perm/permCaseUpdates.vue";
import recentDocuments from "@/views/recentDocuments.vue"
import ClientDetails from "./petition/ClientDetails";
// import ChildDetails from "./petition/ChildDetails";
// import SpouseDetails from "./petition/SpouseDetails";
import ChildDetails from "./petition/ChildDetails";
import SpouseDetails from "./petition/spouseDetailsPage.vue";
import Documents from "./petition/Documents";
//import BeneficiaryDetails from "./petition/BeneficiaryDetails";
import BeneficiaryDetails from "./petition/perm/permBeneficiaryDetails.vue";
import permJobDetails from "./petition/perm/permJobDetails.vue";
import permDraftDetails from "./petition/perm/permDraftDetails.vue";
import permAdvertiseInfo from "./petition/perm/permAdvertiseInfo.vue";
import Communication from "./petition/Communication";
import Fees from "./petition/Fees";
import _ from "lodash";
import moment from "moment";
import JQuery from "jquery";
import FileUpload from "vue-upload-component/src";
import VueDocPreview from "vue-doc-preview";
import docmentType from "@/views/common/docType.vue"
import caseStatusList from "./petition/permCaseStatusList.vue";
import pdfReader from "../views/common/pdfReader.vue";
import notes from "@/views/notes.vue"
import axios from 'axios'
import { NullStream } from "pdfjs-dist/build/pdf.worker";
import Vue from 'vue';
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
export default {
  components: {
    recentDocuments,
    FileUpload,
    notes,
    permDraftDetails,
    permAdvertiseInfo,
    docmentType,
    pdfReader,
    caseStatusList,
    VueDocPreview,
    VuePerfectScrollbar,
    FormsandLetters,
    ScannedCopies,
    Documents,
    ProcessFlow,
    RequestLCA,
    LCADetails,
    ClientDetails,
    SpouseDetails,
    ChildDetails,
    BeneficiaryDetails,
    Communication,
    PetitionUpdates,
    Fees,
    CompanyDocsTemplates,
    permJobDetails,
  },
  name: "app",
  data: () => ({
    selectedHistory:null,
    expandModal: false,
    questionnaireDetails:[],
    removedInvoiceItems:[],
    newlyAddInvoiceItems:[],
    editor: ClassicEditor,
   
    uploading:false,
    value:[],
    editorConfig: {
        toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
    },
    caseNotAvailable:false,
    getPetitionTab:null,
    reRenderDocuments:true,
    setTab :false,
     editedFile:null,
      saveEditedFile:false,
      errorMessage:'',
      formSubmited:false,
      DocErr:false,
    isEditLca: false,
    currentRouteName:'',
    caseUsers: [],
    formsAndLettersList: [],
    feeInvoicesPermessions: false,
    isLcaRequiredForPetition: true,
    isEveryThingLoaded: false,
    showProcessFlow: false,
    docPrivew: false,
    docValue: "",
    docType: "",
    selectedFile: null,

    loaded: false,
    currentRole: null,
    currentUserId: null,
    SuccessQuestionnaire: false,
    petition:{
        beneficiaryInfo: {

          name: '',
          firstName: '',
          middleName: '',
          lastName: '',
          email: '',
          gender:'',
          homePhoneNumber: null,
          homePhoneCountryCode: {
              countryCode: '',
              countryCallingCode: ''
          },
            cellPhoneNumber: null,
            cellPhoneCountryCode: {
                countryCode: '',
                countryCallingCode: ''
            },
            workPhoneNumber:null,
            workPhoneCountryCode:{countryCode: '', countryCallingCode: ''},
            fax:null,
            faxCountryCode:{countryCode: '', countryCallingCode: ''},

            dateOfBirth: null,
            countryOfBirth: null,
            countryOfBirthDetails: null,
            provinceOfBirth: null,
            provinceOfBirthDetails: null,
            locationOfBirth: null,
            countryOfCitizenship: null,
            countryOfCitizenshipDetails: null,
            mailingAddressIsSameAsAddress:false,
            mailingAddress: {
                line1: null,
                line2: null,
                aptType: null,
                locationId: null,
                locationDetails: null,
                stateId: null,
                stateDetails: null,
                countryId: null,
                countryDetails: null,
                zipcode: null
            },
            address: {
                line1: null,
                line2: null,
                aptType: null,
                locationId: null,
                locationDetails: null,
                stateId: null,
                stateDetails: null,
                countryId: null,
                countryDetails: null,
                zipcode: null
            },
            currentAddress: {
                line1: null,
                line2: null,
                aptType: null,
                locationId: null,
                locationDetails: null,
                stateId: null,
                stateDetails: null,
                countryId: null,
                countryDetails: null,
                zipcode: null
            },
            haveYouEverTravelledToUS:null,
            priorPeriodOfStayInUS: [{
                _id: 0,
                
                visaStatus: null,
                visaStatusDetails: null,
                noOfDays: null,
                enteredDate: null,
                departedDate: null,
                dateerror: false
            }],

            curNonImmigrantVisaStatus: null,
            curNonImmigrantVisaStatusDetails: null,
            curVisaExpiryNumber: null,
            I94: '',
          I94ExpiryDate: null,
            firstEntryDateOrApprovalInUsWithH1B:null,
            dateFifthYearOfHExpire:null,


            alienNumber: '',
            SSN: '',
            educations: [
            /* 
            {
                _id: 0,
                name: null,
                address: {
                    line1: null,
                    line2: null,
                    aptType: null,
                    locationId: null,
                    locationDetails: null,
                    stateId: null,
                    stateDetails: null,
                    countryId: null,
                    countryDetails: null,
                    zipcode: null
                },
                highestDegree: null,
                highestDegreeDetails: null,
                majorFieldOfStudy: null,
                attendedFrom: null,
                attendedTo: null,
                graduatedYear: null,
                degreereceived: null,
                isAccredited: null,
                isForProfit: null
              }
              */
            ],
            vacationalOrTrainingInst: [
            /* 
            {
                _id: 0,
                name: null,
                address: {
                    line1: null,
                    line2: null,
                    aptType: null,
                    locationId: null,
                    locationDetails: null,
                    stateId: null,
                    stateDetails: null,
                    countryId: null,
                    countryDetails: null,
                    zipcode: null
                },
                highestDegree: null,
                highestDegreeDetails: null,
                majorFieldOfStudy: null,
                attendedFrom: null,
                attendedTo: null,
                graduatedYear: null,
                degreereceived: null,
                isAccredited: null,
                isForProfit: null
              }
              */
            ],

            prevEmploymentInfo: [{
                _id: 0,
                employerName: '',
                address: {
                    line1: null,
                    line2: null,
                    aptType: null,
                    locationId: null,
                    locationDetails: null,
                    stateId: null,
                    stateDetails: null,
                    countryId: null,
                    countryDetails: null,
                    zipcode: null
                },
                businessType: null,
                jobTitle: null,
                jobDuties: null,
                startDate: null,
                endDate: null,
                currentEmployer: false,
                workPhoneNumber: "",
                workPhoneCountryCode: {
                  countryCode:null,
                  countryCallingCode: ''
                },
              fax: '',
              faxCountryCode: {
                  countryCode:null,
                  countryCallingCode: ''
              },
              hoursWorkedPerWeek: '',
              supervisor:{
                  name:'',
                  phoneNumber:'',
                  phoneCountryCode:{
                      countryCode:'',
                      countryCallingCode:''
                  },


              }

            }],


            /*OLD */
            
            currentlyInUS: null,
            haveOwnershipInterest: null,
            ownershipInterestDesc: '',
            consulateInfo: {
                locationId: null,
                locationDetails: null,
                stateId: null,
                stateDetails: null,
                countryId: null,
                countryDetails: null
            },
            
            lastArrivalNumber: null,
            placeOfLastEntryInUS: '',
            
            nonImmPetitionsInfo: [{
                _id: 0,
                visaStatus: null,
                visaStatusDetails: null,
                receiptNo: '',
                petitionerName: ''
            }],
            anyImmPetitionFiled: null,
            immPetitionInfo: {
                anyOtherAlienFiled: null,
                filedNumber: null,
                employerName: '',
                rirOrRegularProcessing: null,
                filedStateId: null,
                filedStateDetails: null,
                applCurStatus: '',
                seekingFilednullforETA750: null,
                anyI140Filed: null,
                i140Info: {
                    fieldNumber: null,
                    employerName: '',
                    priorityNumber: null,
                    eb2orEb3: '',
                    currentStatus: ''
                }
            },
            
            addressOutsideUS: {
                line1: null,
                line2: null,
                aptType: null,
                locationId: null,
                locationDetails: null,
                stateId: null,
                stateDetails: null,
                countryId: null,
                countryDetails: null,
                zipcode: null
            },

          
            hasOtherNames: false,
            otherNames: [{
                _id: 0,
                name: '',
                firstName: '',
                middleName: '',
                lastName: '',
            }],
            gender: '',
          
            
            maritalStatus: null,
            
            
            I94: null,
            I94ExpiryDate: null,

            iAmFromUS: null,
            
            consulateNotifyAddress: null,
            
            hasI140ImmPetitionFiled: null,
            I140ImmPetitionFiledDetails: null,
            passportNumber: null,
            passportIssuedNumber: null,
            passportExpiryNumber: null,
            
            sevisNumber: null,
            eadNumber: null,
            
            noOfDaysStayInUS: null,
            confirmDaysStayInUS: false,
            hasApprovedI140: false,
            hasPermPendingForMorethan365Days: false
        },
                
        documents: {
            
            slgResume: [],
            slgEduCredentials:[],
            slgEvalOfEduCredentials:[],
            slgTransScripts:[],
            slgExpLetters:[],
            slgPassportAndVisa:[],
            slgCurPrevH1BH4ApprovalsByINS:[], 
            slgAdvancedDegrees:[]




            
        },
      jobDetails: {
          jobId: '',
          noOfPositions: null,
          minDegree: null,
          expInYears: '',
          salary: '',
          jobType: '', //Full Time Regular
          jobShift: '', //First Shift (Day)
          hoursPerWeek: null,
          description: '',
          applicationInfo: {
              applyByMail: '',
              jobStartsOn: null,
              jobEndOn: null
          }
      },
      refilingInstructions: {
          useFilingDateFromPrevSubtn: 'No', // Yes/No // Are you seeking to utilize the filing date from a previously submitted Yes No Application for Alien Employment Certification (ETA 750)? 
          prevFilingDate: null, // enter the previous filing date
          prevSWAOrLocalCaseNo: '', // Indicate the previous SWA or local office case number OR if not available, specify state where case was originally filed
          caseFiledStateId: null, // Indicate the previous SWA or local office case number OR if not available, specify state where case was originally filed
          caseFiledStateDetails: {} // Indicate the previous SWA or local office case number OR if not available, specify state where case was originally filed
          
      },
      wageInfo: {
          trackingNumber: '',
          socCode: null,
          wageRate: '',
          payFrequency: '', // Year, Month, Bi-Weekly, Week, Hour
          wageSource: '', // OES, CBA, Employer Conducted Survey, DBA, SCA, Other
          wageSourceOtherDesc: '',
          determinationDate: null,
          expirationDate: null
      },
      wageOfferInfo: {
          minWage: '',
          maxWage: '',
          payFrequency: '', // Year, Month, Bi-Weekly, Week, Hour
      },
      jobOpportunityInfo: {
      
          workAddresses: [
          {
        "companyName": "",
        "workLocation": true,
        line1: "",
        line2: "",
        zipcode: "",
        countryId: "231",
        stateId: "",
        locationId: "",
        "countryDetails": { "_id": "626a8f03a972fa4d60681140", "id": 231, "name": "United States", "phoneCode": 1, "order": 1, "currencySymbol": "$", "currencyCode": "USD", "zipcodeLength": 5, "sortName": "united states" },
        stateDetails: null,
        locationDetails: null,
        aptType:''
      }
          ],
          jobTitle: '',
          minDegree: null,
          majorFieldsOfStudy: null,
          isTrainigRequired: 'No', // Yes/No // Is training required for the job opportunity?
          noOfTraningMonths: null, //  If Yes, number of months of training required
          fieldOfTraining: '', // Indicate the field of training:
          isExpRequired: 'No', // Yes/No // Is experience in the job offered required for the job?
          noOfExpMonths: null, //  If Yes, number of months experience required
          isAltFieldOfStudyAccept: 'No', // Yes/No // Is there an alternate field of study that is acceptable?
          altMajorFieldOfStudy: '', //  If Yes, specify the major field of study
          isAltCombOfEduAndExpAccept: 'No', // Yes/No // Is there an alternate combination of education and experience that is acceptable
          altLevelOfEdu: null, // If Yes, specify the alternate level of education required
          altAcceptExpInYears: null, // If applicable, indicate the number of years experience acceptable
          foreignEduEqAccept: 'No', // Yes/No // Is a foreign educational equivalent acceptable?
          isExpInAltOccuAccept: 'No', // Yes/No // Is experience in an alternate occupation acceptable?
          noOfExpMonthsInAltOccu: null, // If Yes, number of months experience in alternate occupation required
          jobTitleOfAcceptAltOccu: '', // Identify the job title of the acceptable alternate occupation
          jobDuties: '', // Job duties – If submitting by mail, add attachment if necessary. Job duties description must begin in this space
          jobOppoReqForNormalOccu: 'No', // Yes/No // Are the job opportunity’s requirements normal for the occupation?
          isForiegnLangRequired: 'No', // Yes/No // Is knowledge of a foreign language required to perform the job duties?
          skills: [], // Specific skills or other requirements – If submitting by mail, add attachment if necessary. Skills description must begin in this space. 
          isApplInvolJobOppoInclCombOfOccu: 'No', // Yes/No // Does this application involve a job opportunity that includes a combination of occupations?
          positionOfferToAlien: 'No', // Yes/No // Is the position identified in this application being offered to the alien identified in Section J?
          alienReqToLiveEmplrPrimisis: 'No', // Yes/No //  Does the job require the alien to live on the employer’s premises?
          applLiveInHouseDomWorker: 'No', // Yes/No // Is the application for a live-in household domestic service worker?
          emplrProviedAlienCopyOfContract: 'NA' // Yes/No/NA // If Yes, have the employer and the alien executed the required employment contract and has the employer provided a copy of the contract to the alien?
          
      },
      recruitmentInfo: {
        // a. Occupation Type – All must complete this section. 
        applForProfOcc: "Yes", // Yes/No // Is this application for a professional occupation, other than a college or university teacher? Professional occupations are those for which a bachelor’s degree (or equivalent) is normally required.
        applForColOrUniTeacher: "No", // Yes/No // Is this application for a college or university teacher?
        selCandiadateByCompRecru: '', // Yes/No // Did you select the candidate using a competitive recruitment and selection process?
        useBasicRecruProcForProfOccu: '', // Yes/No // Did you use the basic recruitment process for professional occupations?
        
        // b. Special Recruitment and Documentation Procedures for College and University Teachers
        dateAlienSelected: null,//Date, //  Date alien selected
        nameOfNationalProfJourAdvPlaced: '',//String, //  Name and date of national professional journal in which advertisement was placed
        dateOfNationalProfJourAdvPlaced: null, //Date, //  Name and date of national professional journal in which advertisement was placed
        addiRecruInfo: '',//String, // Specify additional recruitment information in this space. Add an attachment if necessary 
       
        // c. Professional/Non-Professional Information
        swaStartDate: null,//Date, // Start date for the SWA job order
        swaEndDate:null,// Date, // End date for the SWA job order
        hasSundayEditionOfNewsPaper: 'Yes',//String, // Yes/No // Is there a Sunday edition of the newspaper in the area of intended employment?
        endDateOfSundayNewsPaper:null,
        startDateOfSundayNewsPaper:null,
        nameOfNewsPaperFirstAdvPlaced: '',//String, // Name of newspaper (of general circulation) in which the first advertisement was placed
        dateOfFirstAdvtIdentified: null,//Date, // Date of first advertisement identified
        nameOfNewsPaperOrJourSecondAdvPlaced:'',// String, //  Name of newspaper or professional journal (if applicable) in which second advertisement was placed: 
        isNewsPaperOrJournal: '',//, // Newspaper/Journal 
        dateOfSecondAdvIdentified:null,// Date, // Date of second newspaper advertisement or date of publication of journal identified 
        
        // d. Professional Recruitment Information
        dateOfAdvAtJobFair:null,// Date, // . Dates advertised at job fair
        dateOfNonCampusRecru: null,//Date, // Dates of on-campus recruiting
        startDateOfEmplrWebsitePosted:null,// Date, // Dates posted on employer web site
        endDateOfEmplrWebsitePosted: null,//Date, // Dates posted on employer web site
        startDateOfAdvWithTradeOrProfOrg: null,//Date, // Dates advertised with trade or professional organization
        endDateOfAdvWithTradeOrProfOrg: null,//Date, // Dates advertised with trade or professional organization
        startDateOfListedInJobSite: null,//Date, // Dates listed with job search web site
        endDateOfListedInJobSite: null,//Date, // Dates listed with job search web site
        startDateOfListedInPrivateEmpFirm:null,// Date, // Dates listed with private employment firm
        endDateOfListedInPrivateEmpFirm: null,//Date, // Dates listed with private employment firm
        startDateOfAdvEmpRefProgram: null,//Date, // Dates advertised with employee referral program
        endDateOfAdvEmpRefProgram:null,// Date, // Dates advertised with employee referral program
        startDateOfAdvCampusPlacOfc: null,//Date, //  Dates advertised with campus placement office
        endDateOfAdvCampusPlacOfc: null,//Date, //  Dates advertised with campus placement office
        startDateOfAdvLocalNewsPaper: null,//Date, // Dates advertised with local or ethnic newspaper
        endDateOfAdvLocalNewsPaper: null,//Date, // Dates advertised with local or ethnic newspaper
        startDateOfAdvInTVOrRadio: null,//Date, // Dates advertised with radio or TV ads
        endDateOfAdvInTVOrRadio:null,// Date, // Dates advertised with radio or TV ads
        
        // e. General Information
        hasEmplrRecPayForSubAppl: 'No',//String, // Yes/No // Has the employer received payment of any kind for the submission of this application?
        amountRecivedPurposeAndDateForSubAppl:'', //String, // Describe details of the payment including the amount, date and purpose of the payment
        purposeOfAmountForSubAppl: '',//String, // Describe details of the payment including the amount, date and purpose of the payment
        dateOfAmountForSubAppl: null,//Date, // Describe details of the payment including the amount, date and purpose of the payment 
        hasBargainRepreForWorkerInOccu:'No',// String, // Yes/No/NA // Has the bargaining representative for workers in the occupation in which the alien will be employed been provided with notice of this filing at least 30 days but not more than 180 days before the date the application is filed? 
        noBargainRepreHasNotice: 'No',//String, // Yes/No/NA // If there is no bargaining representative, has a notice of this filing been posted for 10 business days in a conspicuous location at the place of employment, ending at least 30 days before but not more than 180 days before the date the application is filed?
        hasEmplrHadLayoffInArea: 'No',//String, // Yes/No // Has the employer had a layoff in the area of intended employment in the occupation involved in this application or in a related occupation within the six months immediately preceding the filing of this application? 
        wereLaidOffUSWorker: 'No',//String, // Yes/No/NA // If Yes, were the laid off U.S. workers notified and considered for the job opportunity for which certification is sought? 
   
      },
      permEfileInfo: {
        supportOfAScheduleASheepherder: 'No',
        isEmployerInvolved: 'No',
        classOfAdmission: '',
        skillLevel:'',
      },
      alienInfo: {
        isTrainigRequired: 'No',//String, // Yes/No // Is training required for the job opportunity?
        isExpRequired: 'No',//String, // Yes/No // Is experience in the job offered required for the job?
        isAltCombOfEduAndExpAccept:'No',// String, // Yes/No // Is there an alternate combination of education and experience that is acceptable
        isExpInAltOccuAccept:'No',// String, // Yes/No // Is experience in an alternate occupation acceptable?
        hasGainAnyExpWithEmplr: 'No',//String, // Yes/No // Did the alien gain any of the qualifying experience with the employer in a position substantially comparable to the job opportunity requested?
        didEmplrPayForEdu: 'No',//String, // Yes/No // Did the employer pay for any of the alien’s education or training necessary to satisfy any of the employer’s job requirements for this position?
        isWorkingWithPetngEmplr:'No',// String, // Yes/No // Is the alien currently employed by the petitioning employer?
      },
      
      refilingInstructions: {
          useFilingDateFromPrevSubtn: 'No',//String, // Yes/No // Are you seeking to utilize the filing date from a previously submitted Yes No Application for Alien Employment Certification (ETA 750)? 
          prevFilingDate: null ,//Date, // enter the previous filing date
          prevSWAOrLocalCaseNo: '',//String, // Indicate the previous SWA or local office case number OR if not available, specify state where case was originally filed
          caseFiledStateId: null,//Number, // Indicate the previous SWA or local office case number OR if not available, specify state where case was originally filed
          caseFiledStateDetails: null, //Object // Indicate the previous SWA or local office case number OR if not available, specify state where case was originally filed
      },
    },
    petitions: [],
    petitionhistory: [],
    supervisorlist: [],
    active_tab: 0,
    tabs: [
      {
        index: 0,
      },
      {
        index: 1,
      },
      {
        index: 2,
      },
      {
        index: 3,
      },
      {
        index: 4,
      },
      {
        index: 5,
      },
      {
        index: 6,
      },
    ],

    visa_status: {},
    visastatuses: [],
    spouse_currentStatusDetails: {},
    country_names: {},
    lcaDetails: null,
    workFlowId: null,
    workFlowDetails: null,
    //Filing Fee Veriables
    editFilngFee: false,
    filingFeeDocs:[],
    filingFeeData: [
      {
        amount: null,
        invoice: false,
        description: "",
      },
    ],
    filingFeesPopup: false,
    filingFeeformerrors: "",
    submitingFilingFee: false,
    filingFeeComment: "",
    emailInvoice: false,
    validatefilingFeeDescrition: true,
    //Filing Fee Veriables End
    configDetails:null,
    caseCurrentDetails:[],
    caseStatusList:[],
    foundDcurrentUsers:true,
    crruntUserList:[],
    scannedDocumentsList:[],
    educationTypes:[],
    masterSocList:[],
    invoicecategoryList:[],
  }),
  watch: {
    active_tab(val) {
      var self = this;
      
      setTimeout(function () {
        JQuery(".vs-tabs--li:contains(Communication)").addClass("comm");
      }, 5);
    },
     $route:function(){
       if (this.$route.params && this.$route.params.itemId) {
     this.petitionId  = this.$route.params.itemId;
      //if(this.petitionId  !=petitionId){

         this.init();
      //}
     
    }
   }
  },
  methods: {
    showHistoryComment(item=null){
      
      this.selectedHistory = item;
      if(this.checkProperty(this.selectedHistory ,'comment')){
        this.$modal.show('historyComment');
      }else{
        this.$modal.hide('historyComment');
      }

    },
    getQuestioinnairyDetails(){
      this.questionnaireDetails=null;
      this.$store.dispatch("commonAction", {
          data: {
              questionnaireId: this.petition.questionnaireTplId
          },
          path: "/questionnaire/details",
      })
      .then((res) => {
        this.questionnaireDetails = res.fields;
        
      })
    },
    upload(model, type = "") {
      
      var _current = this;
     
      let efiles = [];
      efiles = _.filter(model, (e) => {
        return e.url != null && e.url != "";
      });
      let nfiles = _.filter(model, (e) => {
        return e.url == null || e.url == undefined;
      });

      let mapper = nfiles.map(
        (item) =>
          (item = {
            name: item.name,
            file: item.file ? item.file : null,
            url: item.url ? item.url : "",
            path: item.path ? item.path : "",
            status:
              item.status === false || item.status === true
                ? item.status
                : true,
            mimetype: item.type ? item.type : item.mimetype,
          })
      );
     
      let tempFiles = [];
      if (mapper.length > 0) {
        this.uploading = true;
        let count = 0;
        mapper.forEach((doc, index) => {
          let formData = new FormData();
          formData.append("files", doc.file);
          formData.append("secureType", "private");
          formData.append("getDetails", true);
          count++;

          this.$store.dispatch("uploadS3File", formData).then((response) => {
            response.data.result.forEach((urlGenerated) => {
              Object.assign(urlGenerated, {uploadedOn: moment().format("YYYY-MM-DD"), uploadedBy: _current.checkProperty(_current.getUserData, 'userId'), uploadedByName: _current.checkProperty(_current.getUserData, 'name'), uploadedByRoleId: _current.getUserRoleId, uploadedByRoleName: _current.checkProperty(_current.getUserData, 'loginRoleName') });
             
              if (
                _.has(urlGenerated, "name") &&
                tempFiles.indexOf(urlGenerated["name"]) <= -1
              ) {
                tempFiles.push(urlGenerated["name"]);
                this.filingFeeDocs.push(urlGenerated);        
              }
              if(this.filingFeeDocs.length>0){
                this.DocErr=false;
              }
              doc.url = urlGenerated;
              doc.path = urlGenerated;
              doc["mimetype"] = urlGenerated["mimetype"];
              doc["type"] = urlGenerated["mimetype"];
              delete doc.file;
              mapper[index] = doc;
            });
            if (index >= mapper.length - 1) {
              this.uploading = false;
             
            }
          });
        });
        
        if (efiles.length > 0) efiles.push(...mapper);
       
      }
    },
    remove(item, data, filindex) {
      data.splice(filindex, 1);
      if(this.item.length<=0){
        this.DocErr=true;
      
      }
      
    },
    getListcat(){
     
     let Payload={
       petitionId:this.$route.params.itemId
     }
     return new Promise((res ,rej)=>{
   
      this.$store.dispatch("getList",{data:Payload ,path:'/invoices/get-filing-fee-categories'} )
       .then((response) => {
          this.invoicecategoryList = response;
          
          res();      
              
        }).catch((err)=>{
        res();
      });
    })
  },
  async showfilingFeesPopup(editFilngFee = false) {
    this.removedInvoiceItems =[];
    this.newlyAddInvoiceItems =[];
    await this.getListcat()
      this.editFilngFee = editFilngFee;
      this.DocErr=false;
      this.filingFeeData = [
        {
          amount: null,
          invoice: false,
          description: "",
        },
      ];
      if (
         this.editFilngFee && 
         this.checkProperty(this.petition ,'filingFeeDetails' ,'feeDetails') 
        //&& this.petition.filingFeeDetails.amount > 0
      ) {
        this.filingFeeData = [];
       // this.filingFeeDocs =[];
       if(this.checkProperty(this.petition ,'filingFeeCategoryType') =="pre_defined" && this.invoicecategoryList.length>0){
         let filingFeeData = _.cloneDeep(this.petition.filingFeeDetails.feeDetails);
         //descriptionId
         let finalItems =[];
         _.forEach(filingFeeData ,(dbInvoice)=>{
            let isExistsInML = _.find(this.invoicecategoryList ,{ "id": dbInvoice['descriptionId']});
            if(isExistsInML){
              finalItems.push(dbInvoice);
            }else{
              this.removedInvoiceItems.push(dbInvoice);

            }

         })
         _.forEach(this.invoicecategoryList ,(invCat)=>{
            let isExistsInML = _.find(filingFeeData ,{ "descriptionId": invCat['id']});
            let isAlreadyExists  = _.find(finalItems ,{ "descriptionId": invCat['id']});

            if(!isExistsInML && !isAlreadyExists){

            let item = {  amount: null, description: "",  invoice: false,"descriptionId":''  };

            item['description'] = this.checkProperty(invCat ,"name");
            item['amount'] = this.checkProperty(invCat ,"amount");
            item['descriptionId'] = this.checkProperty(invCat ,"id");
            item['descriptionType'] = this.checkProperty(invCat,"type");
            item['newly_add'] = true;
            finalItems.push(item);
            this.newlyAddInvoiceItems.push(item);
            }

         })
         this.filingFeeData =finalItems;

        }else{
          this.filingFeeData = _.cloneDeep(this.petition.filingFeeDetails.feeDetails);
        }

        if(this.checkProperty(this.petition ,'filingFeeDocs', 'cheques')){
         
         this.filingFeeDocs = this.petition.filingFeeDocs['cheques'];
        }
      }
      else{
        if(this.checkProperty(this.petition ,'filingFeeCategoryType') =="pre_defined" && this.invoicecategoryList.length>0){
          this.filingFeeData = [];
          this.filingFeeDocs =[];
          this.DocErr=false;
          _.forEach(this.invoicecategoryList ,(invCat)=>{
            let item = {  amount: null, description: "",  invoice: false,"descriptionId":''  };
            item['description'] = this.checkProperty(invCat ,"name");
            item['amount'] = this.checkProperty(invCat ,"amount");
            item['descriptionId'] = this.checkProperty(invCat ,"id");
            item['descriptionType'] = this.checkProperty(invCat,"type")
            
            this.filingFeeData.push(item);

          });
        }
      }

      this.filingFeesPopup = true;
      this.filingFeeformerrors = "";
      this.submitingFilingFee = false;
      this.filingFeeComment = this.checkProperty(
        this.petition,
        "filingFeeDetails",
        "comment"
      );
      if(!editFilngFee){
        this.filingFeeComment ='Thank you for the business. Please process this at the earliest possible.'
      }
      this.emailInvoice = true;
      this.$modal.show("FilingFeesModal");
      setTimeout(()=>{
        this.$validator.reset();
      } ,10);

      // this.$refs.ProcessFlow.showfilingFeesPopup(editFilngFee);
    },
    opengenFormsAndLatters(){
      let _self= this;
      
    
      if(this.getPetitionTab == 'Forms and Letters'){
       
        try{
          this.$route['params']['openGeneratePopup'] ='';
          this.$route['query']['openGenForms'] ='';
          this.$refs["FormsAndLetters"].openGenerateFormsLattersPopup();
        }catch(err){
          this.$route['params']['openGeneratePopup'] ='';
          this.$route['query']['openGenForms'] ='';
          

        }
        
      }else{
        this.getPetitionTab ='Forms and Letters'
        setTimeout(()=>{

          try{
            _self.$route['params']['openGeneratePopup'] ='';
            _self.$route['query']['openGenForms'] ='';
            _self.$refs["FormsAndLetters"].openGenerateFormsLattersPopup();
        }catch(err){
          _self.$route['params']['openGeneratePopup'] ='';
          _self.$route['query']['openGenForms'] ='';
          

        }

        } ,100);
      }
    },
    checkPaidAmount(){
      setTimeout(()=>{
        try{
        this.$refs['feeModule'].init();

      }catch(e){
         //alert(e);
      }

      },500);
      
    },
    openFilingFee(){

      if( this.checkProperty(this.petition ,'invoiceId' )){
    
         this.showfilingFeesPopup(true);
      }else{
        
      this.filingFeeData =[
            {
              amount: null,
              invoice: false,
              description: "",
            }
       ];
        this.showfilingFeesPopup(false);
      }
    },
    updateUrl(){
      
      this.$route['params']['itemId']= _.cloneDeep(this.petitionId);
      
      
    },
   
    openActionMenu(code){
     
      if(code){
        try {
          switch (code){
            case 'COLLECT_ADV_EVIDENCE':
              this.$refs['process_flow'].$refs['actionsMenu'].$refs["actionsPopup"].openPermAdvrtisementModal();
              break;
            case 'COLLECT_ADV_EVIDENCE_EDIT':
              this.$refs['process_flow'].$refs['actionsMenu'].$refs["actionsPopup"].openPermAdvrtisementModal()
              break
            case 'INITIATE_REMINDER':
              this.$refs['process_flow'].$refs['actionsMenu'].$refs["actionsPopup"].openInitiatePaymentPopup('INITIATE_REMINDER');
              break;
            case 'APPROVE_JOB_DESC':
              this.$refs['process_flow'].$refs['actionsMenu'].$refs["actionsPopup"].openPermJobDescActionsModal('APPROVE_JOB_DESC');
              break;
            case 'FINALIZE_JOB_DESC':
              this.$refs['process_flow'].$refs['actionsMenu'].$refs["actionsPopup"].openPermJobDescActionsModal('FINALIZE_JOB_DESC');
              break;
            case 'JOB_DESC_SUGGESSION':
              this.$refs['process_flow'].$refs['actionsMenu'].$refs["actionsPopup"].openPermJobDescActionsModal('JOB_DESC_SUGGESSION');
              break;
            case 'JOB_DESC_SUGGESSION':
              this.$refs['process_flow'].$refs['actionsMenu'].$refs["actionsPopup"].openPermJobDescActionsModal('JOB_DESC_SUGGESSION');
              break;
            case 'JOB_DESC_EDIT':
              this.$refs['process_flow'].$refs['actionsMenu'].$refs["actionsPopup"].openJobDescription('JOB_DESC_SUGGESSION');
              break;
            case 'JOB_DESC_APPROVE_OR_SUGGESSION':
              this.$refs['process_flow'].$refs['actionsMenu'].$refs["actionsPopup"].openPermJobDescActionsModal('JOB_DESC_APPROVE_OR_SUGGESSION');
              break;
  

                
            

          }

         
      }catch(e) {
        
      
      }
    }
      
     
    },
    reloadCaseHistory(data){
       this.$emit("reloadCaseHistory" ,data);
    },

    goToQuestionaireLink(item){
      this.$router.push({ name: 'perm-questionnaire', params: { itemId:item } })
    },
    getEducationList(){
        this.$store
            .dispatch("getmasterdata", "education_types")
            .then((response) => {
                this.educationTypes = response;
                /*
                petitionDetails['jobDetails'].minDegreeDetails =this.petitionDetails['jobDetails']['minDegree']
                petitionDetails.jobOpportunityInfo.altLevelOfEduDetails ===== petitionDetails.jobOpportunityInfo.altLevelOfEdu
                petitionDetails['jobOpportunityInfo'].minDegreeDetails === this.petitionDetails['jobOpportunityInfo']['minDegree']
                */
              
                

                if(this.checkProperty(this.petition ,'jobDetails' ,'minDegree' )){
                  this.petition['jobDetails'].minDegreeDetails = _.find(this.educationTypes ,{'id':this.petition['jobDetails']['minDegree']});
                }

                if(this.checkProperty(this.petition ,'jobOpportunityInfo' ,'minDegree' )){
                  this.petition.jobOpportunityInfo.minDegreeDetails = _.find(this.educationTypes ,{'id':this.petition['jobOpportunityInfo']['minDegree']});
                }

                if(this.checkProperty(this.petition ,'jobOpportunityInfo' ,'altLevelOfEdu' )){
                  this.petition.jobOpportunityInfo.altLevelOfEduDetails = _.find(this.educationTypes ,{'id':this.petition['jobOpportunityInfo']['altLevelOfEdu']});
                }

            });

    },
    getMasterSocList(){

        let query = {};
        query["page"] = 1;
        query["perpage"] = 10000;
        query["matcher"] = {  "getInactiveListAlso": true};
        query["category"] = "soc_codes";


        this.$store
        .dispatch("getMasterData", query)
        .then((response) => {
            this.masterSocList = response.list;
            if(this.checkProperty(this.petition ,'wageInfo' ,'socCode' )){
                this.petition['wageInfo']['socCodeDetails'] = _.find(this.masterSocList, {"id": this.petition['wageInfo']['socCode']});
            }


        //alert(this.perpage);
        })
        .catch(() => {
        this.masterSocList = [];

        });

    },

    resetPetitionObject(){
      this.petition ={
        beneficiaryInfo: {

          name: '',
          firstName: '',
          middleName: '',
          lastName: '',
          email: '',
          gender:'',
          homePhoneNumber: null,
          homePhoneCountryCode: {
              countryCode: '',
              countryCallingCode: ''
          },
            cellPhoneNumber: null,
            cellPhoneCountryCode: {
                countryCode: '',
                countryCallingCode: ''
            },
            workPhoneNumber:null,
            workPhoneCountryCode:{countryCode: '', countryCallingCode: ''},
            fax:null,
            faxCountryCode:{countryCode: '', countryCallingCode: ''},

            dateOfBirth: null,
            countryOfBirth: null,
            countryOfBirthDetails: null,
            provinceOfBirth: null,
            provinceOfBirthDetails: null,
            locationOfBirth: null,
            countryOfCitizenship: null,
            countryOfCitizenshipDetails: null,
            mailingAddressIsSameAsAddress:false,
            mailingAddress: {
                line1: null,
                line2: null,
                aptType: null,
                locationId: null,
                locationDetails: null,
                stateId: null,
                stateDetails: null,
                countryId: null,
                countryDetails: null,
                zipcode: null
            },
            address: {
                line1: null,
                line2: null,
                aptType: null,
                locationId: null,
                locationDetails: null,
                stateId: null,
                stateDetails: null,
                countryId: null,
                countryDetails: null,
                zipcode: null
            },
            currentAddress: {
                line1: null,
                line2: null,
                aptType: null,
                locationId: null,
                locationDetails: null,
                stateId: null,
                stateDetails: null,
                countryId: null,
                countryDetails: null,
                zipcode: null
            },
            haveYouEverTravelledToUS:null,
            priorPeriodOfStayInUS: [{
                _id: 0,
                
                visaStatus: null,
                visaStatusDetails: null,
                noOfDays: null,
                enteredDate: null,
                departedDate: null,
                dateerror: false
            }],

            curNonImmigrantVisaStatus: null,
            curNonImmigrantVisaStatusDetails: null,
            curVisaExpiryNumber: null,
            I94: '',
          I94ExpiryDate: null,
            firstEntryDateOrApprovalInUsWithH1B:null,
            dateFifthYearOfHExpire:null,


            alienNumber: '',
            SSN: '',
            educations: [
            /* 
            {
                _id: 0,
                name: null,
                address: {
                    line1: null,
                    line2: null,
                    aptType: null,
                    locationId: null,
                    locationDetails: null,
                    stateId: null,
                    stateDetails: null,
                    countryId: null,
                    countryDetails: null,
                    zipcode: null
                },
                highestDegree: null,
                highestDegreeDetails: null,
                majorFieldOfStudy: null,
                attendedFrom: null,
                attendedTo: null,
                graduatedYear: null,
                degreereceived: null,
                isAccredited: null,
                isForProfit: null
              }
              */
            ],
            vacationalOrTrainingInst: [
            /* 
            {
                _id: 0,
                name: null,
                address: {
                    line1: null,
                    line2: null,
                    aptType: null,
                    locationId: null,
                    locationDetails: null,
                    stateId: null,
                    stateDetails: null,
                    countryId: null,
                    countryDetails: null,
                    zipcode: null
                },
                highestDegree: null,
                highestDegreeDetails: null,
                majorFieldOfStudy: null,
                attendedFrom: null,
                attendedTo: null,
                graduatedYear: null,
                degreereceived: null,
                isAccredited: null,
                isForProfit: null
              }
              */
            ],

            prevEmploymentInfo: [{
                _id: 0,
                employerName: '',
                address: {
                    line1: null,
                    line2: null,
                    aptType: null,
                    locationId: null,
                    locationDetails: null,
                    stateId: null,
                    stateDetails: null,
                    countryId: null,
                    countryDetails: null,
                    zipcode: null
                },
                businessType: null,
                jobTitle: null,
                jobDuties: null,
                startDate: null,
                endDate: null,
                currentEmployer: false,
                workPhoneNumber: "",
                workPhoneCountryCode: {
                  countryCode:null,
                  countryCallingCode: ''
                },
              fax: '',
              faxCountryCode: {
                  countryCode:null,
                  countryCallingCode: ''
              },
              hoursWorkedPerWeek: '',
              supervisor:{
                  name:'',
                  phoneNumber:'',
                  phoneCountryCode:{
                      countryCode:'',
                      countryCallingCode:''
                  },


              }

            }],


            /*OLD */
            
            currentlyInUS: null,
            haveOwnershipInterest: null,
            ownershipInterestDesc: '',
            consulateInfo: {
                locationId: null,
                locationDetails: null,
                stateId: null,
                stateDetails: null,
                countryId: null,
                countryDetails: null
            },
            
            lastArrivalNumber: null,
            placeOfLastEntryInUS: '',
            
            nonImmPetitionsInfo: [{
                _id: 0,
                visaStatus: null,
                visaStatusDetails: null,
                receiptNo: '',
                petitionerName: ''
            }],
            anyImmPetitionFiled: null,
            immPetitionInfo: {
                anyOtherAlienFiled: null,
                filedNumber: null,
                employerName: '',
                rirOrRegularProcessing: null,
                filedStateId: null,
                filedStateDetails: null,
                applCurStatus: '',
                seekingFilednullforETA750: null,
                anyI140Filed: null,
                i140Info: {
                    fieldNumber: null,
                    employerName: '',
                    priorityNumber: null,
                    eb2orEb3: '',
                    currentStatus: ''
                }
            },
            
            addressOutsideUS: {
                line1: null,
                line2: null,
                aptType: null,
                locationId: null,
                locationDetails: null,
                stateId: null,
                stateDetails: null,
                countryId: null,
                countryDetails: null,
                zipcode: null
            },

          
            hasOtherNames: false,
            otherNames: [{
                _id: 0,
                name: '',
                firstName: '',
                middleName: '',
                lastName: '',
            }],
            gender: '',
          
            
            maritalStatus: null,
            
            
            I94: null,
            I94ExpiryDate: null,

            iAmFromUS: null,
            
            consulateNotifyAddress: null,
            
            hasI140ImmPetitionFiled: null,
            I140ImmPetitionFiledDetails: null,
            passportNumber: null,
            passportIssuedNumber: null,
            passportExpiryNumber: null,
            
            sevisNumber: null,
            eadNumber: null,
            
            noOfDaysStayInUS: null,
            confirmDaysStayInUS: false,
            hasApprovedI140: false,
            hasPermPendingForMorethan365Days: false
        },
                
        documents: {
            
            slgResume: [],
            slgEduCredentials:[],
            slgEvalOfEduCredentials:[],
            slgTransScripts:[],
            slgExpLetters:[],
            slgPassportAndVisa:[],
            slgCurPrevH1BH4ApprovalsByINS:[], 
            slgAdvancedDegrees:[]




            
        },
      jobDetails: {
          jobId: '',
          noOfPositions: null,
          minDegree: null,
          expInYears: '',
          salary: '',
          jobType: '', //Full Time Regular
          jobShift: '', //First Shift (Day)
          hoursPerWeek: null,
          description: '',
          applicationInfo: {
              applyByMail: '',
              jobStartsOn: null,
              jobEndOn: null
          },
          minDegreeDetails:null, 
          
      },
      refilingInstructions: {
          useFilingDateFromPrevSubtn: 'No', // Yes/No // Are you seeking to utilize the filing date from a previously submitted Yes No Application for Alien Employment Certification (ETA 750)? 
          prevFilingDate: null, // enter the previous filing date
          prevSWAOrLocalCaseNo: '', // Indicate the previous SWA or local office case number OR if not available, specify state where case was originally filed
          caseFiledStateId: null, // Indicate the previous SWA or local office case number OR if not available, specify state where case was originally filed
          caseFiledStateDetails: {} // Indicate the previous SWA or local office case number OR if not available, specify state where case was originally filed
          
      },
      wageInfo: {
          trackingNumber: '',
          socCode: null,
          wageRate: '',
          payFrequency: '', // Year, Month, Bi-Weekly, Week, Hour
          wageSource: '', // OES, CBA, Employer Conducted Survey, DBA, SCA, Other
          wageSourceOtherDesc: '',
          determinationDate: null,
          expirationDate: null
      },
      wageOfferInfo: {
          minWage: '',
          maxWage: '',
          payFrequency: '', // Year, Month, Bi-Weekly, Week, Hour
      },
      permEfileInfo: {
        supportOfAScheduleASheepherder: 'No',
        isEmployerInvolved: 'No',
        classOfAdmission: '',
        skillLevel:''
      },
      jobOpportunityInfo: {
      
          workAddresses: [
          {
        "companyName": "",
        "workLocation": true,
        line1: "",
        line2: "",
        zipcode: "",
        countryId: "231",
        stateId: "",
        locationId: "",
        "countryDetails": { "_id": "626a8f03a972fa4d60681140", "id": 231, "name": "United States", "phoneCode": 1, "order": 1, "currencySymbol": "$", "currencyCode": "USD", "zipcodeLength": 5, "sortName": "united states" },
        stateDetails: null,
        locationDetails: null,
        aptType:''
      }
          ],
          jobTitle: '',
          minDegree: null,
          minDegreeDetails:null, 
          altLevelOfEduDetails:null,
          majorFieldsOfStudy: null,
          isTrainigRequired: 'No', // Yes/No // Is training required for the job opportunity?
          noOfTraningMonths: null, //  If Yes, number of months of training required
          fieldOfTraining: '', // Indicate the field of training:
          isExpRequired: 'No', // Yes/No // Is experience in the job offered required for the job?
          noOfExpMonths: null, //  If Yes, number of months experience required
          isAltFieldOfStudyAccept: 'No', // Yes/No // Is there an alternate field of study that is acceptable?
          altMajorFieldOfStudy: '', //  If Yes, specify the major field of study
          isAltCombOfEduAndExpAccept: 'No', // Yes/No // Is there an alternate combination of education and experience that is acceptable
          altLevelOfEdu: null, // If Yes, specify the alternate level of education required
          altAcceptExpInYears: null, // If applicable, indicate the number of years experience acceptable
          foreignEduEqAccept: 'No', // Yes/No // Is a foreign educational equivalent acceptable?
          isExpInAltOccuAccept: 'No', // Yes/No // Is experience in an alternate occupation acceptable?
          noOfExpMonthsInAltOccu: null, // If Yes, number of months experience in alternate occupation required
          jobTitleOfAcceptAltOccu: '', // Identify the job title of the acceptable alternate occupation
          jobDuties: '', // Job duties – If submitting by mail, add attachment if necessary. Job duties description must begin in this space
          jobOppoReqForNormalOccu: 'No', // Yes/No // Are the job opportunity’s requirements normal for the occupation?
          isForiegnLangRequired: 'No', // Yes/No // Is knowledge of a foreign language required to perform the job duties?
          skills: [], // Specific skills or other requirements – If submitting by mail, add attachment if necessary. Skills description must begin in this space. 
          isApplInvolJobOppoInclCombOfOccu: 'No', // Yes/No // Does this application involve a job opportunity that includes a combination of occupations?
          positionOfferToAlien: 'No', // Yes/No // Is the position identified in this application being offered to the alien identified in Section J?
          alienReqToLiveEmplrPrimisis: 'No', // Yes/No //  Does the job require the alien to live on the employer’s premises?
          applLiveInHouseDomWorker: 'No', // Yes/No // Is the application for a live-in household domestic service worker?
          emplrProviedAlienCopyOfContract: 'NA' // Yes/No/NA // If Yes, have the employer and the alien executed the required employment contract and has the employer provided a copy of the contract to the alien?
          
      },
      recruitmentInfo: {
        documents: {
          sunday: [],
          jobFair: [],
          campusRecruitment: [],
          empWebsite: [],
          profOrgOrTrade: [],
          jobSearchWebsite: [],
          pvtEmpmtFirm: [],
          empRefProgram: [],
          campusPlacement: [],
          localNewsPaper: [],
          tvAds: [],
          busNecLetterByEplr:[],
          recruReportSummary:[],
          intrOfcMemomandum:[]
        },
        //Signed and dated Inter Office Memorandum
        endDateOfPostedIntrOfcMemorandum:null,
        startDateOfPostedIntrOfcMemorandum:null,
        // a. Occupation Type – All must complete this section. 
        applForProfOcc: "Yes", // Yes/No // Is this application for a professional occupation, other than a college or university teacher? Professional occupations are those for which a bachelor’s degree (or equivalent) is normally required.
        applForColOrUniTeacher: "No", // Yes/No // Is this application for a college or university teacher?
        selCandiadateByCompRecru: '', // Yes/No // Did you select the candidate using a competitive recruitment and selection process?
        useBasicRecruProcForProfOccu: '', // Yes/No // Did you use the basic recruitment process for professional occupations?
        
        // b. Special Recruitment and Documentation Procedures for College and University Teachers
        dateAlienSelected: null,//Date, //  Date alien selected
        nameOfNationalProfJourAdvPlaced: '',//String, //  Name and date of national professional journal in which advertisement was placed
        dateOfNationalProfJourAdvPlaced: null, //Date, //  Name and date of national professional journal in which advertisement was placed
        addiRecruInfo: '',//String, // Specify additional recruitment information in this space. Add an attachment if necessary 
       
        // c. Professional/Non-Professional Information
        swaStartDate: null,//Date, // Start date for the SWA job order
        swaEndDate:null,// Date, // End date for the SWA job order
        hasSundayEditionOfNewsPaper: 'Yes',//String, // Yes/No // Is there a Sunday edition of the newspaper in the area of intended employment?
        nameOfNewsPaperFirstAdvPlaced: '',//String, // Name of newspaper (of general circulation) in which the first advertisement was placed
        dateOfFirstAdvtIdentified: null,//Date, // Date of first advertisement identified
        nameOfNewsPaperOrJourSecondAdvPlaced:'',// String, //  Name of newspaper or professional journal (if applicable) in which second advertisement was placed: 
        isNewsPaperOrJournal: '',//, // Newspaper/Journal 
        dateOfSecondAdvIdentified:null,// Date, // Date of second newspaper advertisement or date of publication of journal identified 
        
        // d. Professional Recruitment Information
        dateOfAdvAtJobFair:null,// Date, // . Dates advertised at job fair
        dateOfNonCampusRecru: null,//Date, // Dates of on-campus recruiting
        startDateOfEmplrWebsitePosted:null,// Date, // Dates posted on employer web site
        endDateOfEmplrWebsitePosted: null,//Date, // Dates posted on employer web site
        startDateOfAdvWithTradeOrProfOrg: null,//Date, // Dates advertised with trade or professional organization
        endDateOfAdvWithTradeOrProfOrg: null,//Date, // Dates advertised with trade or professional organization
        startDateOfListedInJobSite: null,//Date, // Dates listed with job search web site
        endDateOfListedInJobSite: null,//Date, // Dates listed with job search web site
        startDateOfListedInPrivateEmpFirm:null,// Date, // Dates listed with private employment firm
        endDateOfListedInPrivateEmpFirm: null,//Date, // Dates listed with private employment firm
        startDateOfAdvEmpRefProgram: null,//Date, // Dates advertised with employee referral program
        endDateOfAdvEmpRefProgram:null,// Date, // Dates advertised with employee referral program
        startDateOfAdvCampusPlacOfc: null,//Date, //  Dates advertised with campus placement office
        endDateOfAdvCampusPlacOfc: null,//Date, //  Dates advertised with campus placement office
        startDateOfAdvLocalNewsPaper: null,//Date, // Dates advertised with local or ethnic newspaper
        endDateOfAdvLocalNewsPaper: null,//Date, // Dates advertised with local or ethnic newspaper
        startDateOfAdvInTVOrRadio: null,//Date, // Dates advertised with radio or TV ads
        endDateOfAdvInTVOrRadio:null,// Date, // Dates advertised with radio or TV ads
        
        // e. General Information
        hasEmplrRecPayForSubAppl: 'No',//String, // Yes/No // Has the employer received payment of any kind for the submission of this application?
        amountRecivedPurposeAndDateForSubAppl:'', //String, // Describe details of the payment including the amount, date and purpose of the payment
        purposeOfAmountForSubAppl: '',//String, // Describe details of the payment including the amount, date and purpose of the payment
        dateOfAmountForSubAppl: null,//Date, // Describe details of the payment including the amount, date and purpose of the payment 
        hasBargainRepreForWorkerInOccu:'No',// String, // Yes/No/NA // Has the bargaining representative for workers in the occupation in which the alien will be employed been provided with notice of this filing at least 30 days but not more than 180 days before the date the application is filed? 
        noBargainRepreHasNotice: 'No',//String, // Yes/No/NA // If there is no bargaining representative, has a notice of this filing been posted for 10 business days in a conspicuous location at the place of employment, ending at least 30 days before but not more than 180 days before the date the application is filed?
        hasEmplrHadLayoffInArea: 'No',//String, // Yes/No // Has the employer had a layoff in the area of intended employment in the occupation involved in this application or in a related occupation within the six months immediately preceding the filing of this application? 
        wereLaidOffUSWorker: 'No',//String, // Yes/No/NA // If Yes, were the laid off U.S. workers notified and considered for the job opportunity for which certification is sought? 
   
      },

      alienInfo: {
        isTrainigRequired: 'Yes',//String, // Yes/No // Is training required for the job opportunity?
        isExpRequired: 'No',//String, // Yes/No // Is experience in the job offered required for the job?
        isAltCombOfEduAndExpAccept:'No',// String, // Yes/No // Is there an alternate combination of education and experience that is acceptable
        isExpInAltOccuAccept:'No',// String, // Yes/No // Is experience in an alternate occupation acceptable?
        hasGainAnyExpWithEmplr: 'No',//String, // Yes/No // Did the alien gain any of the qualifying experience with the employer in a position substantially comparable to the job opportunity requested?
        didEmplrPayForEdu: 'No',//String, // Yes/No // Did the employer pay for any of the alien’s education or training necessary to satisfy any of the employer’s job requirements for this position?
        isWorkingWithPetngEmplr:'No',// String, // Yes/No // Is the alien currently employed by the petitioning employer?
      },
      refilingInstructions: {
          useFilingDateFromPrevSubtn: 'No',//String, // Yes/No // Are you seeking to utilize the filing date from a previously submitted Yes No Application for Alien Employment Certification (ETA 750)? 
          prevFilingDate: null ,//Date, // enter the previous filing date
          prevSWAOrLocalCaseNo: '',//String, // Indicate the previous SWA or local office case number OR if not available, specify state where case was originally filed
          caseFiledStateId: null,//Number, // Indicate the previous SWA or local office case number OR if not available, specify state where case was originally filed
          caseFiledStateDetails: null, //Object // Indicate the previous SWA or local office case number OR if not available, specify state where case was originally filed
      },
    }
    },
    
    reloadDocuments(tab='Documents'){
     this.$store.dispatch("setPetitionTab", 'Documents')
      this.loadPetetion(tab);
     // this.$store.dispatch("setPetitionTab", 'Case Details')
    },
    uploadSavedFileToS3(){
      
      //this.editedFile  =Object.assign( this.editedFile , {'extn': this.checkProperty(this.getDelectedForEditDocument ,'extn')})
     //  this.editedFile  =Object.assign( this.editedFile , {'mimetype': this.checkProperty(this.getDelectedForEditDocument ,'mimetype')})
                 
      let formData = new FormData();
        formData.append("files", this.editedFile);
        formData.append("secureType", "private");
          formData.append("getDetails", true);
        this.formSubmited =true;
            
        this.$store.dispatch("uploadS3File", formData).then(response => {
          response.data.result.forEach(urlGenerated => {
           
            let postData = { 
              petitionId: this.petitionId,  formLetterType: this.getDelectedForEditDocument['type'], documents:[],
              entityId:null
               };
               if(this.checkProperty(this.getDelectedForEditDocument ,'entityId')){
                 postData['entityId'] = this.getDelectedForEditDocument['entityId'] 
               }
            if(!this.checkProperty(this.getDelectedForEditDocument ,'editedDocument')){
              postData = Object.assign(postData, {editedDocument:true ,"parentId":this.getDelectedForEditDocument['_id']})
            }

            if(this.checkProperty(this.getDelectedForEditDocument ,'depLabel')){
                 postData = Object.assign(postData, { "depLabel":""})
                 postData['depLabel'] = this.getDelectedForEditDocument['depLabel'] 
            }
               if(this.checkProperty(this.getDelectedForEditDocument ,'depType')){
                 postData = Object.assign(postData, { "depType":""})
                 postData['depType'] = this.getDelectedForEditDocument['depType'] 
             }

           
            postData.documents.push(urlGenerated);
            
            let action ="uploadFormsAndLetters";
                action ="uploadPermFormsAndLetters"

            this.$store .dispatch(action, postData).then(response => {
                         this.showToster({message:response.message ,isError:false });

                          this.saveEditedFile=false;
                          this.errorMessage='';
                          this.formSubmited =false;
                          this.docPrivew =false;
                          //this.$refs['FormsAndLetters'].getFormsAndLetters();

                    }).catch(error =>{
                      this.errorMessage =error
                     this.formSubmited =false
          
                    })

          })
        }).catch(error =>{
          this.errorMessage =error
          this.formSubmited =false
          
        })

    },
    updateExistingDocument(){

       let formData = new FormData();
        formData.append("files", this.editedFile);
        formData.append("secureType", "private");
          formData.append("getDetails", true);
        this.formSubmited =true;
            
        this.$store.dispatch("uploadS3File", formData).then(response => {
          response.data.result.forEach(urlGenerated => {
           
            let postData = { petitionId: this.petitionId,  formLetterType: this.getDelectedForEditDocument['type'], documents:null ,document:null ,"formAndLetterId":null };
             postData['formAndLetterId'] = this.getDelectedForEditDocument['_id'];
            postData.documents =urlGenerated
             postData.document =urlGenerated
            let path= "/perm/update-forms-and-letters";
                path ="/filled-forms-and-letters/update";
            this.$store.dispatch("commonAction", {"data":postData ,"path":path}).then(response => {
                         this.showToster({message:response.message ,isError:false });

                          this.saveEditedFile=false;
                          this.errorMessage='';
                          this.formSubmited =false;
                           this.docPrivew =false;
                         // this.$refs['FormsAndLetters'].getFormsAndLetters();

                    }).catch(error =>{
                      this.errorMessage =error
                     this.formSubmited =false
          
                    })

          })
        }).catch(error =>{
          this.errorMessage =error
          this.formSubmited =false
          
        })
      

    },
    editLca(action=false){
      this.isEditLca = action;
     
    },

    
    getscannedDocumentsList() {
      this.scannedDocumentsList = [];
      return false;
      if(this.petitionId && ( [3].indexOf(this.checkProperty(this.petition ,'typeDetails' ,'id'))<=-1 )){
    
      let finalList = [];
      let postData = { petitionId: this.petitionId, page: 1, perpage: 10000 };
      this.$store
        .dispatch("getList", {
          data: postData,
          path: "/perm/scanned-copies-list",
        })
        .then((response) => {
          //  this.formsAndLettersList = response.list;

          let lst = [];

          _.forEach(response.list, (mainItem) => {
            mainItem = Object.assign(mainItem, {
              reverse_document_versions: [],
              mainParentId: "",
              showMe: true,
              selectedForSigning: false,
            });
            if (mainItem.parentId) {
              mainItem["mainParentId"] = mainItem["parentId"];
            } else {
              mainItem["mainParentId"] = mainItem["_id"];
            }

            lst.push(mainItem);
          });

          let subList = [];

          //reverse_document_versions
          _.forEach(lst, (mainItem) => {
            _.forEach(lst, (subItem) => {
              if (
                mainItem.parentId &&
                (mainItem.parentId == subItem["parentId"] ||
                  mainItem.parentId == subItem["_id"]) &&
                mainItem["_id"] != subItem["_id"]
              ) {
                subItem["showMe"] = false;
                if (subList.indexOf(subItem["_id"] <= -1)) {
                  mainItem["reverse_document_versions"].push(subItem);
                  subList.push(subItem["_id"]);
                }

                // mainItem['showMe'] =true;
              }
            });

            if (mainItem.showMe) {
              finalList.push(mainItem);
            }
          });

          this.scannedDocumentsList = finalList;
        
        });
      
   
   
      }
   },

     getCaseCurrentDetails(){
      if(this.petitionId){
       let self = this;
            let postData ={
              "petitionId":self.petitionId,
            }
            this.caseCurrentDetails =[]
             this.$store.dispatch("commonAction", {data:postData,path:'perm/get-current-at-details'})
           .then((response) =>{ 
              
               if(this.checkProperty(response ,"agingLogs"  )){
                  this.caseCurrentDetails = response['agingLogs'];
                    
                     
                        
                  
               }
              
               
            
            })

          }
    },

    editCaseNumber(){
      try {

        this.$refs['process_flow'].$refs['actionsMenu'].$refs["actionsPopup"].assignCaseNumber(true)
      }catch(e) {
        
      }
    },
     getGlobalConfigDetails(){
            let postData ={}
            this.configDetails =null
             this.$store.dispatch("commonAction", {data:postData,path:'global-config/details'})
           .then((response) =>{ 
              
               if(this.checkProperty(response ,"config"  )){
                  this.configDetails = response['config'];
               }
              
               
            
            })


        },
    getCaseUsers() {
      let self = this;
      this.caseUsers = [];
      let postData = {
        petitionId: self.petitionId,
        page: 1,
        perpage: 2500,
      };
      this.$store
        .dispatch("getList", {
          data: postData,
          path: "/perm/assigned-user-list",
        })
        .then((response) => {
          if (self.checkProperty(response, "list")) {
            let list = response["list"];
            _.forEach(list, (user) => {
              user["tempName"] = user["name"];
              if (_.has(user, "roleName")) {
                user["tempName"] =
                  user["tempName"] + " (" + user["roleName"] + ")";
              }
            });
            self.caseUsers = list;
          }
        });
    },

    reloadProcessFlow() {
      this.showProcessFlow = true;
    },
    getFormsAndLetters() {
      if(this.petitionId){

      
      this.formsAndLettersList = [];
      let finalList = [];
      let postData = { petitionId: '', page: 1, perpage: 10000 };
      postData['petitionId'] = this.petitionId;
      this.$store
        .dispatch("getList", {
          data: postData,
          //path: "/perm/filled-forms-and-letters-list",
          path: "/filled-forms-and-letters/list",
          
        })
        .then((response) => {
          //  this.formsAndLettersList = response.list;

          let lst = [];

          _.forEach(response.list, (mainItem) => {
            mainItem = Object.assign(mainItem, {
              reverse_document_versions: [],
              mainParentId: "",
              showMe: true,
              selectedForSigning: false,
            });
            if (mainItem.parentId) {
              mainItem["mainParentId"] = mainItem["parentId"];
            } else {
              mainItem["mainParentId"] = mainItem["_id"];
            }

            lst.push(mainItem);
          });

          let subList = [];

          //reverse_document_versions
          _.forEach(lst, (mainItem) => {
            _.forEach(lst, (subItem) => {
              if (
                mainItem.parentId &&
                (mainItem.parentId == subItem["parentId"] ||
                  mainItem.parentId == subItem["_id"]) &&
                mainItem["_id"] != subItem["_id"]
              ) {
                subItem["showMe"] = false;
                if (subList.indexOf(subItem["_id"] <= -1)) {
                  mainItem["reverse_document_versions"].push(subItem);
                  subList.push(subItem["_id"]);
                }

                // mainItem['showMe'] =true;
              }
            });

            if (mainItem.showMe) {
              finalList.push(mainItem);
            }
          });

          this.formsAndLettersList = finalList;
          this.reloadProcessFlow();
        });
   
      }
      },
    submitFilingFees() {
      this.validatefilingFeeDescrition = true;
      this.filingFeeformerrors = "";
      this.DocErr=false;
       if(this.checkProperty(this.petition,'filingFeeCategoryType')=='pre_defined' && this.checkProperty(this.filingFeeDocs,'length')<=0){
        this.DocErr=true;
       }
      this.$validator.validateAll("filingFeesform").then((result) => {

       

        let includeInvoicesList = _.filter(this.filingFeeData ,{"invoice":false});
       
          if(includeInvoicesList && includeInvoicesList.length<=0){
            this.filingFeeformerrors = "Include at least one item into invoice";
            return false;
          }

        if (result && this.DocErr==false) {
          this.DocErr=false;
          var totala = 0;
          this.filingFeeData.forEach((i) => {
            totala = totala + parseInt(i.amount);
          });
          
          var postData = {
            subTypeName: this.checkProperty(
              this.getPetitionDetails,
              "subTypeDetails",
              "name"
            ),
            typeName: this.checkProperty(
              this.getPetitionDetails,
              "typeDetails",
              "name"
            ),
            petitionId: this.checkProperty(this.getPetitionDetails, "_id"),
            filingFeeData: this.filingFeeData,
            today: moment().format("YYYY-MM-DD"),
            comment:this.filingFeeComment,
            filingFeeDocs:{ "cheques":[]}, //this.filingFeeDocs,
            /*
            companyName: this.petition.petitionerDetails.name,
            beneficiaryName: this.petition.beneficiaryDetails.name,
            beneficiaryCustomId: this.petition.beneficiaryDetails.customId,
            petitionType: this.petition.typeDetails.name,
            companyId: this.petition.petitionerDetails._id,
             petitionId: this.petition._id,
           
            amount: totala,
            customer: {
              Id: this.petition.companyDetails.qbCustomerId,
              displayName: this.petition.companyDetails.name,
              email: this.petition.companyDetails.authorizedSignatory.email,
            },
            invoiceTerms: {
              days: 30,
            },
             comment:this.filingFeeComment,
            emailInvoice:this.emailInvoice
            */
            "entityType": "perm",
          };
          if(this.filingFeeDocs.length>0){
            postData['filingFeeDocs']['cheques'] = this.filingFeeDocs;
            // filingFeeDocs:{ "cheques":[]} //this.filingFeeDocs,
          }
          this.submitingFilingFee = true;
          this.$store
            .dispatch("commonAction", {
              data: postData,
              path: "/perm/save-filing-fees",
            })
            .then((response) => {
              this.createOrupdateInvoice("save-filing-fees");
            })
            .catch((error) => {
              this.submitingFilingFee = false;
              this.filingFeeformerrors = error;
            });
        }
      });
    },
    createOrupdateInvoice(callFrom = "") {
      let self = this;
      this.validatefilingFeeDescrition = true;
      this.filingFeeformerrors = "";
      this.DocErr=false;
       if(this.checkProperty(this.petition,'filingFeeCategoryType')=='pre_defined' && this.checkProperty(this.filingFeeDocs,'length')<=0){
        this.DocErr=true;
       }
      this.$validator.validateAll("filingFeesform").then((result) => {
        let includeInvoicesList = _.filter(this.filingFeeData ,{"invoice":false});
          if(includeInvoicesList && includeInvoicesList.length<=0){
            this.filingFeeformerrors = "Include atleast one itme into invoice";
            return false;
          }
        if (result && this.DocErr==false) {
          var totala = 0;
          this.filingFeeData.forEach((i) => {
            totala = totala + parseInt(i.amount);
          });
          let filingFeeData = _.cloneDeep(this.filingFeeData);
          if (callFrom == "save-filing-fees") {
            //filingFeeData  = _.filter(filingFeeData , {'invoice':false});
          }

          var postdata = {
            companyName: self.checkProperty(  self.petition, "petitionerDetails", "name" ),
            beneficiaryName: self.petition.beneficiaryDetails.name,
            beneficiaryCustomId: self.petition.beneficiaryDetails.customId,
            petitionType: self.petition.typeDetails.name,
            filingFeeDocs:{"cheques":[]},
            companyId: self.checkProperty(
              self.petition,
              "petitionerDetails",
              "_id"
            ),
            petitionId: self.petition._id,
            feeDetails: filingFeeData,
            amount: totala?totala:0,
            today: moment().format("YYYY-MM-DD"),
            customer: {
              Id: self.checkProperty(
                self.petition,
                "companyDetails",
                "qbCustomerId"
              ),
              displayName: "", //this.petition.companyDetails.name,
              email: "", //this.petition.companyDetails.authorizedSignatory.email,
              "entityType": "perm"
            },
            invoiceTerms: {
              days: 30,
            },
            comment: this.filingFeeComment,
            emailInvoice: self.checkPaymentIntigration, //this.emailInvoice
            "entityType": "perm"
          };
          if(this.filingFeeDocs.length>0){
            postdata['filingFeeDocs']['cheques'] = this.filingFeeDocs;
           
          }
          if (this.checkProperty(self.petition, "companyDetails")) {
            postdata["customer"]["Id"] = this.checkProperty(
              self.petition,
              "companyDetails",
              "qbCustomerId"
            );
            postdata["customer"]["displayName"] = this.checkProperty(
              self.petition,
              "authorizedSignatory",
              "name"
            );
            postdata["customer"]["email"] = this.checkProperty(
              self.petition,
              "authorizedSignatory",
              "email"
            );
          }


          let totalPaidAmount =0
            
            if(this.checkProperty(this.petition,'filingFeeDetails','partlyPaidLogs') && this.checkProperty(this.petition['filingFeeDetails'],'partlyPaidLogs','length')>0 ){
            let filingfeeList = _.cloneDeep(this.checkProperty(this.petition,'filingFeeDetails','partlyPaidLogs'))
              filingfeeList.forEach(item => { totalPaidAmount += parseInt(item.amount);  });
            }

          this.submitingFilingFee = true;
          if (
            this.checkProperty(self.petition, "invoiceId") &&
            this.petition.invoiceId != null
          ) {
            
            postdata.invoiceId = this.petition.invoiceId;
            postdata.statusId = 2;
            postdata.statusName = "Sent";
            
            let dueAmount = totala-totalPaidAmount
            if(dueAmount <=0){
              postdata.statusId = 6;
              postdata.statusName = "Fully Paid";
            }


            if(self.checkProperty(self.petition ,'filingFeeCategoryType') =="pre_defined" && self.invoicecategoryList.length>0){
               let dbFilingFeeData = _.cloneDeep(self.petition.filingFeeDetails.feeDetails);
               //this.removedInvoiceItems =[];
               //this.newlyAddInvoiceItems =[];
               if(self.removedInvoiceItems.length>0 || self.newlyAddInvoiceItems.length>0 ){

               let dbAmount =0
                dbFilingFeeData.forEach((i) => {
                  dbAmount = totala + parseInt(i.amount);
                 });


                    let totalPaidAmount =0
                    if(self.checkProperty(self.petition,'filingFeeDetails','partlyPaidLogs') && self.checkProperty(self.petition['filingFeeDetails'],'partlyPaidLogs','length')>0 ){
                    let filingfeeList = _.cloneDeep(self.checkProperty(self.petition,'filingFeeDetails','partlyPaidLogs'))
                      filingfeeList.forEach(item => { totalPaidAmount += parseInt(item.amount);  });
                    }

                    if(totala >totalPaidAmount && totalPaidAmount>0){
                      postdata.statusId = 5;
                      postdata.statusName = "Partially Paid";

                    }else if(totala==totalPaidAmount){
                      postdata.statusId = 6;
                      postdata.statusName = "Fully Paid";

                    }else if(totalPaidAmount<totala && totalPaidAmount>0){
                      postdata.statusId = 5;
                      postdata.statusName = "Partially Paid";

                    }
                  }
            }
            this.$store
              .dispatch("updateFilingFees", postdata)
              .then((response) => {
                this.filingFeesPopup = false;
                this.$modal.hide("FilingFeesModal");
                this.editFilngFee = false;
                this.submitingFilingFee = false;
                this.showToster({ message: response.message, isError: false });
                //this.setActivetab('Case Details', true)
                    this.$route['params']['tabname']= 'Fees/Invoices';
                    this.reloadPetition('Fees/Invoices');
                
                
              })
              .catch((error) => {
                if (callFrom == "save-filing-fees") {
                  this.filingFeesPopup = false;
                  this.$modal.hide("FilingFeesModal");
                  this.editFilngFee = false;
                  this.submitingFilingFee = false;
                  this.showToster({ message: error, isError: true });
                  //this.setActivetab('Case Details', true)
                  this.$route['params']['tabname']= 'Fees/Invoices';
                  this.reloadPetition('Fees/Invoices');
                  
                   
                } else {
                  this.filingFeeformerrors = error;
                }
              });
          } else {
            this.$store
              .dispatch("submitFilingFees", postdata)
              .then((response) => {
                this.filingFeesPopup = false;
                this.$modal.hide("FilingFeesModal");
                this.submitingFilingFee = false;
                this.showToster({ message: response.message, isError: false });
                //this.setActivetab('Case Details', true)
                this.$route['params']['tabname']= 'Fees/Invoices';
                this.reloadPetition('Fees/Invoices');
               
              })
              .catch((error) => {
                if (callFrom == "save-filing-fees") {
                  this.filingFeesPopup = false;
                  this.$modal.hide("FilingFeesModal");
                  this.submitingFilingFee = false;
                  this.showToster({ message: error, isError: true });
                  //this.setActivetab('Case Details', true)
                  this.$route['params']['tabname']= 'Fees/Invoices';
                  this.reloadPetition('Fees/Invoices');
                  

                } else {
                  this.filingFeeformerrors = error;
                }
              });
          }
        }
      });
    },

    addfilingfee: function () {
      let isValied = true;
      this.validatefilingFeeDescrition = false;
      this.$validator.validateAll("filingFeesform").then((result) => {
        if (this.filingFeeData.length > 0) {
          _.forEach(this.filingFeeData, (item, index) => {
            if (
              this.errors.has("filingFeesform.amount" + index) ||
              this.errors.has("filingFeesform.filingdescription" + index)
            ) {
              isValied = false;
            }
          });
        }

        if (isValied) {
          this.filingFeeData.push({
            amount: null,
            description: "",
          });

          this.$validator.reset("filingFeesform.filingFeeComment");
        }
      });
    },
    removefilingfee: function (index) {
      this.filingFeeData.splice(index, 1);
      //Vue.delete(this.filingFeeData, index);
    },

    

    checkFeeInvoicesPermessions() {
      this.feeInvoicesPermessions = false;
      let wf = _.cloneDeep(this.getWorkFlowDetails);

      if (wf && _.has(wf, "config")) {
        let filingFeeRequired = _.find(wf["config"], { code: "FILING_FEE" });

        if (
          (filingFeeRequired &&
            _.has(filingFeeRequired, "editors") &&
            _.has(filingFeeRequired, "actionRequired") &&
            filingFeeRequired["editors"].length > 0 &&
            filingFeeRequired.actionRequired == "Yes" &&
            _.has(this.petition, "completedActivities") &&
            this.petition["completedActivities"].indexOf("CASE_APPROVED") >
              -1) ||
          (_.has(this.petition, "nextWorkflowActivity") &&
            this.petition["nextWorkflowActivity"] == "FILING_FEE")
        ) {
          this.feeInvoicesPermessions = true;
        } else {
          this.feeInvoicesPermessions = false;
        }
      } else {
        this.feeInvoicesPermessions = false;
      }
      // alert(this.feeInvoicesPermessions);
    },

    isLcaRequired() {
      this.isLcaRequiredForPetition = false;
      let wf = _.cloneDeep(this.getWorkFlowDetails);

      if (wf && _.has(wf, "config")) {
        let lcaRequired = _.find(wf["config"], { code: "LCA_REQUEST" });

        if (
          lcaRequired &&
          _.has(lcaRequired, "editors") &&
          _.has(lcaRequired, "actionRequired") &&
          lcaRequired["editors"].length > 0 &&
          lcaRequired.actionRequired == "Yes"
        ) {
          if (this.petition.lcaId) {
            this.isLcaRequiredForPetition = true;
          } else if (
            this.petition.lcaId == null &&
            (_.find(lcaRequired["editors"], { roleId: this.getUserRoleId }) ||
              this.checkAdminLoginroles)
          ) {
            this.isLcaRequiredForPetition = true;
          }
        } else {
          this.isLcaRequiredForPetition = false;
        }
      } else {
        this.isLcaRequiredForPetition = false;
      }

      this.isEveryThingLoaded = true;

      let tab = this.getPetitionTab;

      this.setActivetab(tab);
    },

    getWorkflowDetails(tab = "") {
      if (tab == "") {
        tab = this.getPetitionTab;
      }

      //alert(this.workFlowId)
      this.workFlowDetails = null;
      this.$store.dispatch("setPetitionData", {
        petitionDetails: this.petition,
        lcaDetails: this.lcaDetails,
        workFlowDetails: this.workFlowDetails,
      });

      if (this.workFlowId) {
        let payLoad = {
          path: "/workflow/details",
          data: { workflowId: this.workFlowId },
        };
        this.$store
          .dispatch("commonAction", payLoad)
          .then((res) => {
            this.workFlowDetails = res;
            this.$store.dispatch("setPetitionData", {
              petitionDetails: this.petition,
              lcaDetails: this.lcaDetails,
              workFlowDetails: this.workFlowDetails,
            });
            if (this.checkProperty(this.petition, "questionnaireFilled")) {
              this.showProcessFlow = true;
            }

            setTimeout(() => {
              this.isLcaRequired();
              this.checkFeeInvoicesPermessions();
             
            }, 100);
           // this.getFormsAndLetters();

            
            if(tab !='Fees/Invoices'){
              setTimeout(() => {  this.setActivetab(tab); }, 100);
             }
             if(tab=='Fees/Invoices' && this.checkProperty(this.petition ,'filingFeeDetails','feeDetail')  ){
             
                  this.$store.dispatch("setPetitionTab", "Case Details").then(()=>{
                  setTimeout(()=>{

                  this.$store.dispatch("setPetitionTab", "Fees/Invoices");

                  });

                  })
             }
            this.reloadProcessFlow();
              setTimeout(()=>{
               
                if(this.getPetitionTab == 'Petition Updates'){
                 
                  this.$refs['PetitionUpdatesRef'].init();
                }
             },100);
          })
          .catch((error) => {
            this.reloadProcessFlow();
            this.workFlowDetails = null;
            this.$store.dispatch("setPetitionData", {
              petitionDetails: this.petition,
              lcaDetails: this.lcaDetails,
              workFlowDetails: this.workFlowDetails,
            });
            setTimeout(() => {
              this.setActivetab(tab);
            }, 100);
          });
      }
    },
    enable_submit_to_offshore_manager(data) {},

    download_or_view(docItem) {
      
      
       let value = _.cloneDeep(docItem);
       this.expandModal= false;
      if( this.checkProperty(this.getPetitionDetails ,'caseNo') && this.checkProperty(value ,'name')){
        let docName = _.cloneDeep(value['name']);
        value['name'] = this.checkProperty(this.getPetitionDetails ,'caseNo')+"_"+docName;
      }
       
      
      var _self = this;
      this.formSubmited =false;
      if (_.has(value, "path")) {
        value["url"] = value["path"];
        value["document"] = value["path"];
      }

      if (_.has(value, "url")) {
        value["path"] = value["url"];
        value["document"] = value["url"];
      }

      if (_.has(value, "document")) {
        value["path"] = value["document"];
        value["url"] = value["document"];
      }
      value = Object.assign(value ,{ 'petitionId':this.petition['_id']})
      value = Object.assign(value ,{ 'subTypeDetails':this.petition['subTypeDetails']})


      this.selectedFile = value;
      this.docValue = "";
      this.docPrivew = false;
      this.docType = false;
      this.docType = this.findmsDoctype(value);
      
      if ( (this.docType == "office" || this.docType == "image" || this.docType == "pdf")  ) {
      //if ( (this.docType == "office" || this.docType == "image" || this.docType == "pdf") && value.download == false ) {
        value.url = value.url.replace(this.$globalgonfig._S3URL, "");
        value.url = value.url.replace(this.$globalgonfig._S3URLAWS, "");
        let postdata = {
          keyName: value.url,
          "petitionId":value['petitionId'],
          
          // entityType:value['petitionId']
         // "fileName":value.name?value.name:''
        };
        if(this.checkProperty(value,'subTypeDetails','id') == 15){
          postdata['entityType'] = 'perm'
        }else{
          postdata['entityType'] = 'case'
        }
        
       
        this.$store.dispatch("getSignedUrl", postdata).then((response) => {
          this.docValue = response.data.result.data;

          if (this.docType == "office") {
            document.getElementById("placeholder").innerHTML= "  <div  id='placeholder2' style='height:100%'></div>";
              let _editing= true;
            
              if([50,51].indexOf(this.getUserRoleId)>-1){
                    _editing= false;
              }

              if(value.viewmode){
                _editing= false;
              }
              var _ob  = {}
              if(value.editedDocument){
                     _ob ={
                
                petitionId:this.petition._id,
                 name:value.name,
                _id:value._id,
                  "extn": "docx",
                "formLetterType": "Letter",
                  parentId:value.parentId
              }

              }else{

                     _ob ={
                       
                    name:value.name,
                         petitionId:this.petition._id,
                _id:value._id,
               "extn": "docx",
                "formLetterType": "Letter",
                  parentId:value._id

              }

              }
          
              
              window.docEditor = new DocsAPI.DocEditor("placeholder2",
            {
                
                "document": {
                   "c": "forcesave",
                    "fileType": "docx",
                    "key": value._id,
                     "userdata": JSON.stringify(_ob),
                    "title": value.name,
                    "url": response.data.result.data,
                     permissions: {
                    edit: _editing,
                    download: true,
                    reader:false,
                    review: false,
                    comment: false
                   }
                },
              
                "documentType": "word",
                "height": "100%",
                "width": "100%",
               
               "editorConfig": {
                   "userdata": JSON.stringify(_ob),
               "callbackUrl": "https://immibox.com/api/perm/post-edited-document?payload="+JSON.stringify(_ob)+"&token="+_self.$store.state.token+"&name="+value.name.replace('.docx',''),
        "customization": {
              "logo": {
                "image": "https://immibox.com/app/favicon.png",
                "imageDark": "https://immibox.com/app/favicon.png",
                "url": "https://immibox.com"
            },
          "anonymous": {
                "request": false,
                "label": "Guest"
            },
            "chat": false,
            "comments": false,
            "compactHeader": false,
            "compactToolbar": true,
            "compatibleFeatures": false,
            "feedback": {
                "visible": false
            },
            "forcesave": true,
            "help": false,
            "hideNotes": true,
            "hideRightMenu": true,
            "hideRulers": true,
              layout: { 
                  toolbar: {
                     "collaboration": false,
                  },
              },
            "macros": false,
            "macrosMode": "warn",
            "mentionShare": false,
            "plugins": false,
            "spellcheck": false,
            "toolbarHideFileName": true,
            "toolbarNoTabs": true,
            "uiTheme": "theme-light",
            "unit": "cm",
            "zoom": 100
        },
},          events: {
         onReady: function () {
       
            },
            onDocumentStateChange: function (event) {
              var url = event.data;
              

              if(!event.data){

                if(value.editedDocument){

                 }

              }
            }

}
            });
            //this.docValue = encodeURIComponent(response.data.result.data);
          }

            if (this.docType == "pdf") {
              var _vid= value._id;
              if(value.parentId){
                 _vid= value.parentId;
              }
              var  viewmode = 0; //1== edit , 0== Disble Edit
              let pdfViewUrl ='https://immibox.com/viewer/pdfjs-dist/web/viewerv2.html';            
              if(_.has(this.$globalgonfig, 'PDF_VIEW_URL')){
                pdfViewUrl = this.$globalgonfig['PDF_VIEW_URL']; //PDF_EDIT_URL
              }
              if(_.has( value ,'viewmode')){
                if(value.viewmode){
                 viewmode= 0;
              }else{
                viewmode= 1;
                if(_.has(this.$globalgonfig, 'PDF_EDIT_URL')){
                  pdfViewUrl = this.$globalgonfig['PDF_EDIT_URL']; //PDF_EDIT_URL
                }
              }

              }
              
            this.docValue = pdfViewUrl+"?view="+viewmode+"+&file="+encodeURIComponent(response.data.result.data);
          }
          this.docPrivew = true;
        });
      } else {
       
       

        this.downloads3file(value);
      }
     
    },

    enableAction() {
      this.loadPetetion();
    },
    reloadPetition(tab = "Case Details") {
      //reloading Petition Updates
      
      if(this.getPetitionTab=='Petition Updates' || tab == 'Fees/Invoices' || this.getPetitionTab=='Fees/Invoices'){
        this.getPetitionTab ='Case Details';
      }
      
      
      if (tab != "") {
        
        this.$store.dispatch("setPetitionTab", tab)
          .then(() => {
           
            this.init(tab);
          })
          .catch((err) => {
           
            this.init();
          });
      } else {
        this.$store.dispatch("setPetitionTab", "Case Details");
        this.init();
      }
    },
    setActivetab(stab = "Case Details", callFromClick = false) {
      //Communication Company Docs Case Details Dependents Info  , Children Info , Fees/Invoices
     // this.updatePetiotionActionBtn(false)
      if (!stab) {
        stab = "Case Details";
      }
      this.getPetitionTab = stab
   
    },
    setActivetabstatus() { 
      var self = this;
      setTimeout(function () {
        self.active_tab = JQuery(".vs-tabs--li:contains(Tracking)").index();
      }, 100);
    },

    setchromeStore(){
      var data ={'loginToken':'','caseId':'' ,'dolEfilePwdRefId':'' ,'dolEfilePermRefId':'' ,"lcaId":''};
      var loginToken = localStorage.getItem('loginToken');
      data['loginToken'] = loginToken;
      data['petitionId'] = this.petitionId;
      data['caseId'] = this.petitionId;
      if(this.checkProperty( this.petition,'lcaId')){
        data['lcaId'] = this.checkProperty(this.petition,'lcaId');
      }
     

      if(this.petition && this.petition['dolEfilePwdRefId']){
        data = Object.assign(data ,{'dolEfilePwdRefId':this.petition['dolEfilePwdRefId']});
      }
      if(this.petition && this.petition['dolEfilePermRefId']){
        data = Object.assign(data ,{'dolEfilePermRefId':this.petition['dolEfilePermRefId']})
      }
     // alert(chrome);
      
      localStorage.setItem("storeData", JSON.stringify(data))
    //  chrome.storage.local.set({'storeData': data}, () => { });




    },


    loadPetetion(tab = "") {
      this.updatePetiotionActionBtn(false);
     
  this.getscannedDocumentsList();
  
      // this.workFlowDetails =null;
      //this.petition =null;
      //  this.lcaDetails = null;
      // this.petition.filingFeeDetails = null;
      this.active_tab = 0;
      if (this.petition == null) {
        this.loaded = false;
        this.loaded = true;
        this.$vs.loading();
      }
     this.getGlobalConfigDetails();
     this.getCaseCurrentDetails();
     let path= "/perm/details";
     let postData = {"petitionId":''};
     postData['petitionId'] = this.petitionId;
     this.caseNotAvailable =false;
      this.$store.dispatch("commonAction", {"data":postData ,"path":path})
      .then(response => {
         if(!response){
          this.caseNotAvailable =true;
          this.showToster({message:"Case Details are not found",isError:true });
          setTimeout(() => { this.$router.push("/cases/");   }, 10);
          return true;
         }
            
        this.updatePetiotionActionBtn(false);
     


        this.getCaseUsers();
        this.$vs.loading.close();
        this.loaded = false;
        this.loaded = true;
        if (response) {
          this.reRenderDocuments =false;
          this.resetPetitionObject();
          var data = _.merge(this.petition ,response);
          this.getQuestioinnairyDetails();
          if( _.has( data ,'jobOpportunityInfo') && this.checkProperty(data['jobOpportunityInfo'] ,'workAddresses','length' ) <=0){
            let addItem = {
                  "companyName": "",
                  "workLocation": true,
                  line1: "",
                  line2: "",
                  zipcode: "",
                  countryId: "231",
                  stateId: "",
                  locationId: "",
                  "countryDetails": { "_id": "626a8f03a972fa4d60681140", "id": 231, "name": "United States", "phoneCode": 1, "order": 1, "currencySymbol": "$", "currencyCode": "USD", "zipcodeLength": 5, "sortName": "united states" },
                  stateDetails: null,
                  locationDetails: null,
                  aptType:''
                };
                data['jobOpportunityInfo']['workAddresses'].push(_.deepClone(addItem));
                data = data;

          }
          this.petition = data;

            if(this.checkProperty(this.petition ,'jobDetails' ,'minDegree' )){
              this.petition['jobDetails'].minDegreeDetails = _.find(this.educationTypes ,{'id':this.petition['jobDetails']['minDegree']});
            }

            if(this.checkProperty(this.petition ,'jobOpportunityInfo' ,'minDegree' )){
              this.petition.jobOpportunityInfo.minDegreeDetails = _.find(this.educationTypes ,{'id':this.petition['jobOpportunityInfo']['minDegree']});
            }

            if(this.checkProperty(this.petition ,'noOfPositions'  )){
              this.petition['jobDetails']['noOfPositions']= this.petition['noOfPositions']
            }
          

            if(this.checkProperty(this.petition ,'jobOpportunityInfo' ,'altLevelOfEdu' )){
              this.petition.jobOpportunityInfo.altLevelOfEduDetails = _.find(this.educationTypes ,{'id':this.petition['jobOpportunityInfo']['altLevelOfEdu']});
            }

            if(this.checkProperty(this.petition ,'wageInfo' ,'socCode' )){
                this.petition['wageInfo']['socCodeDetails'] = _.find(this.masterSocList, {"id": this.petition['wageInfo']['socCode']});
            }


     
     if (["set_Communication" ,'set_LCA' ,'set_notes' ].indexOf(this.getPetitionTab) > -1) {
      let tmp = this.getPetitionTab.split("set_");
    
      if (this.checkProperty(tmp, "length") >= 2) {
        this.setTab =true;
        this.getPetitionTab = tmp[1];
      } 
    } 
   

    
    if (this.$route.params && this.$route.params.tabname ) {
     
      this.getPetitionTab = _.cloneDeep(this.$route.params.tabname);
      this.$route.params.tabname =''
      this.$store.dispatch("setPetitionTab", this.getPetitionTab );
      this.setTab =true;
    }else if( this.petition &&  (this.petition.completedActivities.indexOf('CREATE_JOB_DESC')>-1 || this.petition.completedActivities.indexOf('EFILE_PWD')>-1 || this.petition.completedActivities.indexOf('PWD_CERTIFID')>-1 || this.checkProperty(this.petition ,'hasJobDetails'))  ){
      this.getPetitionTab = "Petition Updates"

      this.setTab =true;
    }
   
    if(!this.setTab && tab ==''){

this.getPetitionTab = "Case Details"
}
    this.getcaseHistory();

          this.$store.dispatch("setPetitionData", {
            petitionDetails: this.petition,
            lcaDetails: this.lcaDetails,
            workFlowDetails: this.workFlowDetails,
          });
        }
        setTimeout(() =>{
           this.reRenderDocuments =true;
           this.setchromeStore();
      },0)
        if (this.currentRole == 51 && !this.loadedFromPreview && !this.petition.questionnaireFilled) {
          let routeId = this.petitionId;

          this.$router.push("/perm-questionnaire/" + routeId);
        }
        if (
          this.checkProperty(this.petition, "beneficiaryInfo", "dateOfBirth")
        ) {
          let routeId = this.$route.params.itemId;
          
          //this.$router.push({ name: 'questionnaire', params: { routeId } })
        }

        if (this.checkProperty(this.petition, "workflowId")) {
          this.workFlowId = this.petition.workflowId;
          this.getWorkflowDetails();
        }
        //this.petition.filingFeeDetails = null;
        if (_.has(this.petition, "invoiceId")) {
          this.$store
            .dispatch("filingFeeDetails", {
              invoiceId: this.petition.invoiceId,
            })
            .then((response) => {
              this.loaded = true;
              this.petition.filingFeeDetails = response;
              this.petition = _.cloneDeep(this.petition);

              if(tab == 'Fees/Invoices'){
                this.$store.dispatch("setPetitionTab", "Fees/Invoices");
              }
              this.checkPaidAmount();
            })
            .catch((response) => {
              this.loaded = true;
              
            });
        }

        if (this.checkProperty(this.petition, "lcaId")) {
          this.$store
            .dispatch("fetchLcaDetails", this.petition.lcaId)
            .then((response) => {
              this.lcaDetails = response.data.result;
              //alert(JSON.stringify( this.lcaDetails));
              // this.lcaDetails["status_documents"] = [];
               this.lcaDetails = Object.assign(this.lcaDetails, { "status_documents":[]})

              let stsid = this.lcaDetails["statusId"];
              let status_documents = {};
              let statusLogs = this.lcaDetails["statusLogs"];
              _.forEach(statusLogs, (object) => {
                let comment = object["comment"];
                let statusId = object["statusId"];
                _.forEach(
                  this.lcaDetails["documents"].lca,
                  (document, indx) => {
                    this.lcaDetails["documents"].lca[indx]["is_new"] = false;

                    let doc = _.cloneDeep(document);
                    doc["comment"] = comment;

                    if (
                      doc["statusId"] &&
                      doc["statusId"] == statusId &&
                      doc["comment"] &&
                      doc["comment"] != ""
                    ) {
                      if (_.has(status_documents, statusId)) {
                        status_documents[statusId].push(doc);
                      } else {
                        status_documents[statusId] = [];
                        status_documents[statusId].push(doc);
                      }
                      document["is_status_document"] = true;
                    } else {
                      if (!document["is_status_document"])
                        document["is_status_document"] = false;
                    }
                  }
                );
              });

              _.forEach(status_documents, (docs) => {
                if (docs.length > 0) {
                  this.lcaDetails["status_documents"].push(docs);
                }
              });
              this.$store.dispatch("setPetitionData", {
                petitionDetails: this.petition,
                lcaDetails: this.lcaDetails,
                workFlowDetails: this.workFlowDetails,
              });
              setTimeout(() => {
                //this.setActivetab(tab);
              }, 100);
            });
        } else {
          setTimeout(() => {
            //this.setActivetab(tab);
          }, 100);
        }
        this.$store.dispatch("setPetitionData", {
          petitionDetails: this.petition,
          lcaDetails: this.lcaDetails,
          workFlowDetails: this.workFlowDetails,
        });
          

        if (this.checkProperty(this.petition, "userId")) {
          
       
          
        

         let postdata = {
              matcher:{  rfeCases:'', getMasterDataOnly:true,  beneficiaryIds:'',  },
            "page": 1,
            "perpage": 100
        }
      
         postdata['matcher']['userId'] = this.petition['userId'];

         if(_.has(this.petition ,"rfeCase" )){
          postdata['matcher']['isRfeCase'] = this.petition['rfeCase']
          }
         this.$store.dispatch("getList", {
        data: postdata,
        path: '/perm/list',
      }).then((response) => {
       
              this.petitions = response['list'];
            });
        }
      }).catch((err)=>{
        this.caseNotAvailable =true;
      });
      this.getcaseHistory();
    },
    reloadActivities(data){
      //'showCaseStatus' showActivities
      if(data=="showActivities"){
        this.getcaseHistory();
      }
      if(data=="showCaseStatus"){
        this.getCaseCurrentDetails();
      }
      
      
    },
    getcaseHistory(){
      if(this.petitionId){
     let postData ={"petitionId":'' ,"page": 1,
        "perpage": 500};
            postData['petitionId'] =  this.petitionId ;
         
        this.$store
        .dispatch("getList", {
          data: postData,
          path:'/perm/activity-list',
        }).then((response) => {
        
          this.petitionhistory = response['list'];
        });

      }
     

    },
    init(tab='') {
      // this.$store.commit("TOGGLE_IS_SIDEBAR_ACTIVE", false);
      // this.$store.dispatch('updateSidebarWidth', 'reduced');
      //  this.$store.commit('UPDATE_SIDEBAR_ITEMS_MIN', true)

      this.updatePetiotionActionBtn(false);
   
      this.currentRole = this.$store.state.user.loginRoleId;
      this.currentUserId = this.$store.state.user._id;
      this.loadPetetion(tab);
      

      this.$store.dispatch("getmasterdata", "visa_status").then((response) => {
        this.visastatuses = response;
      });
      this.$store.dispatch("getusersByrole", 8).then((response) => {
        this.paralegallist = response.list;
      });
      this.$store.dispatch("getusersByrole", 7).then((response) => {
        this.supervisorlist = response.list;
      });
    },
    petetionChange(id) {

      if([50,51].indexOf(this.getUserRoleId)>-1 ){
          this.$store.commit('toggleCaseStatusTab','showActivities')
      }else{
          this.$store.commit('toggleCaseStatusTab','showCaseStatus')
           
        }
     
      this.getPetitionTab ='Case Details';
      this.setActivetab('Case Details', true);
      /*
        if(this.petitions.length>1){
            this.petitionId = id;
            //this.$router.push("/petition-details/"+id);
                setTimeout( ()=>{this.init()},100);

        }else{
                this.petitionId = id;
                setTimeout( ()=>{this.init()},100);

        }
        */

      this.workFlowDetails = null;
      this.petition = null;
      this.lcaDetails = null;
      this.petitionId = id;

    // this.$store.commit('toggleCaseStatusTab','showCaseStatus')

     
     
    // this.$store.dispatch("setPetitionTab", "Case Details");
      this.$store
        .dispatch("setPetitionData", {
          petitionDetails: this.petition,
          lcaDetails: this.lcaDetails,
          workFlowDetails: this.workFlowDetails,
        })
        .then(() => {
          setTimeout(() => {
            this.init();
          }, 10);
        })
        .catch(() => {
          setTimeout(() => {
            this.init();
          }, 1);
        });
        this.updateUrl();
    },
    
  },
  beforeDestroy() {
    //  JQuery('#btnSidebarToggler').click()
    //window.removeEventListener("message");
  },
  mounted() {  
    this.getListcat();
    if([50,51].indexOf(this.getUserRoleId)>-1 ){
    this.$store.commit('toggleCaseStatusTab','showActivities')
    }else{
    this.$store.commit('toggleCaseStatusTab','showCaseStatus')
      
    }


    this.getEducationList();
    this.getMasterSocList();
  // this.$store.commit('toggleCaseStatusTab','showCaseStatus')

    let _self =this;
    this.setTab =false;
         window.addEventListener('message', event => {
         
           
                if(event.data.blobUrl && _self.checkProperty(_self.getDelectedForEditDocument ,'name')){
                  
                    _self.rrorMessage='';
                    _self.formSubmited =false;
                    
                   this.editedFile = new File([event.data.blobUrl], _self.checkProperty(_self.getDelectedForEditDocument ,'name'), {
                  type:'application/pdf' // event.data.blobUrl.type,
                  });
                  
                  if(this.checkProperty(this.getDelectedForEditDocument ,'editedDocument')){
                     this.updateExistingDocument()
                  }else{

                      _self.saveEditedFile=true;

                  }
                 

                  

                
                    
                    
                 
             }
        });
    



  
    if (this.$route.params && this.$route.params.itemId) {
      this.petitionId = this.$route.params.itemId;
        if(this.loadedFromPreview && this.previewData){
          this.setActivetab('Case Details', true);
        this.petition = _.cloneDeep(this.previewData);
        if(this.loadedFromPreview && this.fieldsArrayDetails && this.checkProperty(this.fieldsArrayDetails,'length')>0){
        this.questionnaireDetails = _.cloneDeep(this.fieldsArrayDetails)
      }
      }else{
        this.init();
      }
    }
  },
  computed: {
    checkCommentLength(){
      return (comment='')=>{
        let textcomment = comment;
        let self = this;
        let returnVal = false;
        if(textcomment){
          var plainText = textcomment.replace(/<[^>]*>/g, ' ');
          if(plainText){
            var htmlString = plainText.trim();
            if(htmlString && self.checkProperty(htmlString, 'length') > 100 ){
              returnVal = true
            }
          }
        }
        return returnVal
      }
    },
    returnCommentText(){
      return (comment='')=>{
        let returnVal = '';
        if(comment){
          var plainText = comment.replace(/<[^>]*>/g, ' ');
          let plainext = plainText.replace(/&nbsp;|&nbsp/g, ' ');
          if(plainext){
            returnVal = plainext.trim();
            
          }
        }
        return returnVal
      }
    },
    checkCaseStatus(){
      if(this.checkProperty(this.petition ,'intStatusDetails', 'id') == 1){
        return this.checkProperty(this.petition ,'intStatusDetails', 'id')
      }
      else{
        return 4
      }
    },
    checkCompletedActivity(){
      return (activityCode)=>{
      if(this.checkProperty(this.petition ,'completedActivities' ,'length')>0){
        if(this.petition['completedActivities'].indexOf(activityCode)>-1){
          return true
        }
        else{
          return false
        }
      }else{
        return false
      }
    }
    },
    		 getDelectedForEditDocument(){
    if(this.checkProperty( this.$store.state ,'selectedForEditDocument') ){

      return this.$store.state['selectedForEditDocument'];
    }else{
      return null
    }

    

  },
    
    checkFormsAndLattersPermissions(){
     
      let returValue =true;
      if([51].indexOf(this.getUserRoleId)>-1){
        returValue =false;
      }else{
        if([50].indexOf(this.getUserRoleId)>-1 && this.checkProperty( this.getPetitionDetails ,'completedActivities' ,'length')>0 ){

           if(this.getPetitionDetails['completedActivities'].indexOf('REQUEST_PETITIONER_SIGN')<=-1 ){
             returValue =false;

           }

        }

      }
      return returValue;


    },
   
    activateLcaTab() {
      if (
        this.checkPetitionLcaRequired &&
        !this.checkProperty(this.getPetitionDetails, "lcaId")
      ) {
        return true;
      } else {
        return false;
      }
    }
  },
  props:{
    fieldsArrayDetails:{
      type:Array,
      default:null
    },
    loadedFromPreview:false,
    previewData:null,
  }
};
</script>
