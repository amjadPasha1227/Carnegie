<template>
  <div>
    <div class="dashboard__section">
      <div
        class="dashboard_cnt"
        :class="{ fulldashboard: [1, 2, 50, 51].indexOf(getUserRoleId) > -1 }"
      >
        <div class="dashboard_left">
          <div class="grid_actions">
            <div>
              <div class="self_info">
                <label
                  >{{ generateGreetings }}
                  <b>
                    <template v-if="checkProperty(user, 'userName') != ''">
                      {{ user.userName }}
                    </template>
                    <template v-else>
                      {{ user.name }}
                    </template>
                  </b></label
                >
                <p v-if="pendingActionsCount > 0">
                  You have
                  <a @click="changedTab('todo')"
                    >{{ pendingActionsCount }} pending task(s)</a
                  >
                </p>
                <p v-if="pendingActionsCount == 0 && !isLodaing" >
                <a @click="changedTab('todo')">
                  You don't have pending task(s)
                  </a>
                </p>
              </div>
              <ul>
                <!--  // all, todo activity changedTab -->
                <li
                  @click="changedTab('all')"
                  :class="{ active: tabName == 'all' }"
                >
                  <a>ALL ACTIVITIES</a>
                </li>
                <li
                  @click="changedTab('todo')"
                  :class="{ active: tabName == 'todo' }"
                >
                  <a>MY TASKS ({{ pendingActionsCount }})</a>
                </li>
                <li
                  @click="changedTab('activity')"
                  :class="{ active: tabName == 'activity' }"
                >
                  <a>UPDATES</a>
                </li>
              </ul>
            </div>

            <DatePickerCustom
              @ondateSelection="reloadWall"
              v-model="selected_createdDateRange"
            />
          </div>
          <div class="dashboard_left_cnt" @scroll="scroll">
            <!-- <div class="grid_title">
                    <span>TODAY </span>
                </div>  -->
            <div class="dashboard_skelton" v-if="isLodaing">
              <div class="skelton_cards" v-for="index in 9" :key="index">
                <div class="skline line1"></div>
                <div class="skline line2"></div>
                <div class="skline line3"></div>
                <div class="user_skelton">
                  <div class="skline picture"></div>
                  <div>
                    <div class="skline line2"></div>
                    <div class="skline line3"></div>
                  </div>
                </div>
              </div>
            </div>
            <div v-else-if="!isLodaing && list.length > 0">
              <div class="db_grid" id="infinite-list">
                <template v-if="!isLodaing && list.length">
                  <template v-for="(item, ind) in list">
                    <div
                      class="grid_element"
                      :class="{
                        todoItem: item.type == 'todo',
                        activityItem: item.type != 'todo',
                        ['box' + (ind + 2)]: true,
                        ['box__' + (ind + 2)]: true,
                      }"
                      :key="'item' + ind"
                    >
                      <toDoGridItem
                      :lableData="lableData"
                        :templateClass="templateClass"
                        :all_statusids="all_statusids"
                        :key="ind"
                        :item="item"
                        :itemIndex="ind"
                        :itemTemplate="itemTemplate"
                        @reloadWals="wallList"
                        :userRolelist="userRolelist"
                      />
                    </div>
                  </template>
                </template>
              </div>
            </div>
            <div v-else-if="!isLodaing && list.length <= 0">
              <NoDataFound
                ref="NoDataFoundRef"
                :loading="false"
                :heading="'No ' + tabDataName + ' Found'"
                type="User Roles"
              />
            </div>
          </div>
        </div>
      </div>
      <div class="dashboard_right" v-if="[1, 2, 50, 51].indexOf(getUserRoleId) < 0">
        <casesChart  :wallsLoaded='wallsLoaded'/>
        <usersChart :wallsLoaded='wallsLoaded'/>
        <lcaChart  :wallsLoaded='wallsLoaded' />
        <invoiceChart :wallsLoaded='wallsLoaded' />
        <!---
            <div class="graph_block">
                <div class="graph_title">
                    <h4>USERS</h4>
                </div>
                <div class="graph_cnt">

                        <div>
                        <canvas id="planet-chart"></canvas>
                        </div>

                </div>
            </div>
            <div class="graph_block">
                <div class="graph_title">
                    <h4>LCA</h4>
                </div>
                <div class="graph_cnt">

                </div>
            </div>
             <div class="graph_block">
                <div class="graph_title">
                    <h4>INVOICE</h4>
                </div>
                <div class="graph_cnt">

                </div>
            </div>
            -->
      </div>
    </div>
  </div>
</template>
 
 
<script>
import VueApexCharts from "vue-apexcharts";
import Vue from "vue";
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import { MoreVerticalIcon } from "vue-feather-icons";
import DateRangePicker from "vue2-daterange-picker";
import Avatar from "vue-avatar";
import WallMessage from "../views/wall/message.vue";

import toDoGridItem from "./wall/templateOneItem";
import activityItem from "./wall/activityItem.vue";
import { _ } from "core-js";
import NoDataFound from "@/views/common/noData.vue";
import "vue2-daterange-picker/dist/vue2-daterange-picker.css";
Vue.use(VueApexCharts);
import Paginate from "vuejs-paginate";

import JQuery from "jquery";
Vue.component("apexchart", VueApexCharts);
import casesChart from "../views/wall/casesChart.vue";
import usersChart from "../views/wall/usersChart.vue";
import lcaChart from "../views/wall/lcaChart.vue";
import invoiceChart from "../views/wall/invoiceChart.vue";
import moment from "moment";

import VueSlimScroll from "vue-slimscroll";
import DatePickerCustom from "@/views/common/_date_picker_custom.vue";

Vue.use(VueSlimScroll);
var _isotope;
export default {
  components: {
    DatePickerCustom,
    Paginate,
    WallMessage,
    Avatar,
    VuePerfectScrollbar,
    MoreVerticalIcon,
    DateRangePicker,
    toDoGridItem,
    activityItem,
    NoDataFound,

    casesChart,
    usersChart,
    lcaChart,
    invoiceChart,
  },
  data: function () {
    return {
      lableData:[],
      userRolelist:[],
      wallsLoaded:false,
      pendingActionsCount: 0,
      tabDataName: "Activities ",
      isOpenDateFilter: false,
      subItem: false,
      selected_createdDateRange: [],
      autoApply: "",
      list: [],
      itemCount: 0,
      scorlOptions: {
        height: "100%",
        size: 0,
      },
      all_statusids: [],
      templateClass: "box",
      windowHight: 0,
      callFromSerch: false,
      itemTemplate: [],
      isLodaing: true,
      tabName: "all",
      perPage: 25,
      page: 1,

      gap: 0,
      frame: [
        [1, 1, 2, 2],
        [3, 3, 2, 2],
        [4, 4, 4, 5],
      ],
      rectSize: 0,
      useFrameFill: true,
      dateRange: {
        // startDate: '2019-12-26',
        // endDate: '2019-12-28',
      },
      username: "",
      activities: [],
      options: {},
      series: [50, 102, 155, 141, 117],
      dashboard_data: {},
      lca_requests: [],
      new_petitioners: [],
      new_petitions: [],
      petitionersCount: {},
      beneficiaryStats: {},

      petitionsCount: {},
      rfe_petitions: [],

      //recent activity data
      recent_activitys: [],
      my_tasks: [],
      roleId: 0,
      wallFilterData: {
        filters: {
          types: ["todo"], // all, todo activity
          createdDateRange: [],
        },
        page: 1,
        perpage: 25,
        sorting: {
          path: "createdOn",
          order: -1,
        },
      },
      jaquery: null,
      filterText: "Today",
    };
  },

  mounted() {
    this.getUserRoles();

     this.$store.dispatch("getList" ,{data:{"category": "WORKFLOW"},path:"/messages/list"})
       .then(response => {
         //alert(JSON.stringify(response))
         this.lableData = response.messages.WORKFLOW;
         
         
       })
    this.wallsLoaded = false;
    this.filterText = "";
    this.jaquery = JQuery;
    //     // Detect when scrolled to bottom.
    // const listElm = document.querySelector('#infinite-list');
    // listElm.addEventListener('scroll', e => {
    //   if(listElm.scrollTop + listElm.clientHeight >= listElm.scrollHeight) {
    //       //alert();
    //    // this.wallList();
    //   }
    // });

    this.getCompanyStatusList();
    this.username = this.$store.state.user.name;
    //  this.roleId = this.$store.state.user['roleId'][0];

    this.petitionsCount = {
      petitionCount: 0,
      rfeCount: 0,
      totalCount: 0,
    };
    this.petitionersCount = {
      approvedCount: 0,
      pendingCount: 0,
      totalCount: 0,
    };
    this.beneficiaryStats = {
      total: 0,
      active: 0,
      inactive: 0,
    };

    //this.get_dashboardData();
    // this.get_recentActivitys();
    // this.get_mytasks();
    // this.getactivities();
    this.wallFilterData = {
      filters: {
        types: [this.tabName], // all, todo activity
        createdDateRange: [],
      },
      page: this.page,
      perpage: this.perPage,
      sorting: {
        path: "createdOn",
        order: -1,
      },
    };
    this.wallList();
    // this.myresizeEventHandler();

   
  },

  created() {
    window.addEventListener("resize", this.myresizeEventHandler);
  },
  destroyed() {
    window.removeEventListener("resize", this.myresizeEventHandler);
  },
  methods: {
    getUserRoles(){
      let query = {};
        query['page'] = 1;
        query['perpage'] = 100;
        query['matcher'] = {};
        query['category'] = 'user_roles';
        
       

        this.$store
          .dispatch("getMasterData", query)
          .then(response => {
            this.userRolelist = response.list;
        
            
          }).catch(()=>{
            
          })
    },
    getStats() {
      //  this.statusCount =0;
      let payLoad = {
        categoryList: ["pending-actions-count"], //["case-stats-by-status", "pending-actions-count", "lca-stats-by-status", "invoice-stats-by-status", "petitioner-stats-by-status", "pending-cases-stats", "case-aging-stats"],
        matcher: {
          statusIds: [],
          typeIds: [],
          subTypeIds: [],
          createdDateRange: [],
        },
      };

      payLoad["matcher"]["createdDateRange"] =
        this.wallFilterData["filters"]["createdDateRange"];

      this.$store
        .dispatch("getStats", payLoad)
        .then((result) => {
          if (_.has(result, "pendingActionsCount")) {
            this.pendingActionsCount = result["pendingActionsCount"];
          }
        })
        .catch((err) => {
          this.pendingActionsCount = 0;
        });
    },

    togleDateFIlter() {
      this.isOpenDateFilter = !this.isOpenDateFilter;
      // if(this.isOpenDateFilter){
      //     document.addEventListener("click", ()=>{
      //         this.isOpenDateFilter =false;

      //     });
      // }
    },

    reloadWall(seleteddates) {
      if (seleteddates && seleteddates.startDate != null) {
        this.wallFilterData["filters"]["createdDateRange"] = [];
        this.wallFilterData["filters"]["createdDateRange"] = [
          seleteddates.startDate,
          seleteddates.endDate,
        ];
      } else {
        this.wallFilterData["filters"]["createdDateRange"] = [];
      }
      this.wallList();
    },
    generateDate(type = "") {
      let startDate = moment().startOf("day").format("YYYY-MM-DD");
      let endDate = moment().endOf("day").format("YYYY-MM-DD");
      this.filterText = "Today";
      this.isOpenDateFilter = true;
      if (type == "Today") {
        this.filterText = "Today";
        startDate = moment().startOf("day").format("YYYY-MM-DD");
        endDate = moment().endOf("day").format("YYYY-MM-DD");
      } else if (type == "This Week") {
        this.filterText = "This Week";
        startDate = moment().startOf("week").format("YYYY-MM-DD");
        endDate = moment().endOf("week").format("YYYY-MM-DD");
      } else if (type == "This Month") {
        this.filterText = "This Month";
        startDate = moment().startOf("month").format("YYYY-MM-DD");
        endDate = moment().endOf("month").format("YYYY-MM-DD");
      } else if (type == "Custom_date") {
        startDate = this.selected_createdDateRange["startDate"];
        endDate = this.selected_createdDateRange["endDate"];
        startDate = moment(startDate).format("YYYY-MM-DD");
        endDate = moment(endDate).format("YYYY-MM-DD");

        this.filterText = startDate + " - " + endDate;
      }

      this.isOpenDateFilter = false;
      this.wallFilterData["filters"]["createdDateRange"] = [];
      this.wallFilterData["filters"]["createdDateRange"] = [startDate, endDate];
      this.wallList();
    },
    scroll(e) {
      const { target } = e;
      if (
        Math.ceil(target.scrollTop) >=
        target.scrollHeight - target.offsetHeight
      ) {
        //this code will run when the user scrolls to the bottom of this div so
        //you could do an api call here to implement lazy loading
        //this.countTotalPages

        if (this.page < this.countTotalPages) {
          this.page = this.page + 1;
          this.wallList();
        }
      }
    },

    getCompanyStatusList() {
      this.all_statusids = [];
      let postdata = {
        page: 1,
        perpage: 1000,
        category: "company_status",
      };
      this.$store
        .dispatch("getMasterData", postdata)
        .then((res) => {
          this.all_statusids = res["list"];
          this.all_statusids = _.filter(this.all_statusids, (item) => {
            return [1, 2, 3, 4].indexOf(item["id"]) > -1;
          });
        })
        .catch(() => {});
    },

    myresizeEventHandler() {
      this.windowHight = window.screen.height; // window.innerHeight;
    },

    pageNate(pageNum) {
      this.page = pageNum;

      this.wallFilterData = {
        filters: {
          types: [this.tabName], // all, todo activity
          createdDateRange: [],
        },
        page: this.page,
        perpage: this.perPage,
        sorting: {
          path: "createdOn",
          order: -1,
        },
      };
      this.wallList();
    },
    getRandomTemplate() {
      let tmp = [
        [
          "grid_1x",
          "grid_1x",
          "grid_3x",
          "grid_3x",
          "grid_3x",
          "grid_2x",
          "grid_1x",
          "grid_1x",
          "grid_1x",
          "grid_2x",
          "grid_1x",
          "grid_2x",
          "grid_2x",
          "grid_1x",
          "grid_1x",
          "grid_2x",
          "grid_3x",
          "grid_3x",
          "grid_3x",
          "grid_1x",
          "grid_2x",
          "grid_1x",
          "grid_2x",
          "grid_2x",
          "grid_1x",
          "grid_1x",
          "grid_2x",
        ],

        [
          "grid_2x",
          "grid_2x",

          "grid_2x",
          "grid_1x",
          "grid_1x",
          "grid_3x",
          "grid_3x",
          "grid_3x",
          "grid_2x",
          "grid_2x",
          "grid_1x",
          "grid_2x",
          "grid_1x",
          "grid_3x",
          "grid_3x",
          "grid_3x",
          "grid_1x",
          "grid_1x",
          "grid_2x",
          "grid_2x",
          "grid_2x",
          "grid_1x",
          "grid_2x",
          "grid_1x",
          "grid_3x",
          "grid_3x",
          "grid_3x",
        ],

        [
          "grid_1x",
          "grid_1x",
          "grid_1x",
          "grid_2x",
          "grid_1x",
          "grid_3x",
          "grid_3x",
          "grid_3x",
          "grid_2x",
          "grid_2x",
          "grid_2x",
          "grid_1x",
          "grid_1x",
          "grid_1x",
          "grid_2x",
          "grid_1x",
          "grid_3x",
          "grid_3x",
          "grid_3x",
          "grid_2x",
          "grid_2x",
          "grid_1x",
          "grid_1x",
          "grid_2x",
          "grid_3x",
          "grid_3x",
          "grid_3x",
        ],

        [
          "grid_2x",
          "grid_1x",
          "grid_1x",
          "grid_1x",
          "grid_1x",
          "grid_2x",
          "grid_2x",
          "grid_3x",
          "grid_3x",
          "grid_3x",
          "grid_2x",
          "grid_2x",
          "grid_2x",
          "grid_1x",
          "grid_1x",
          "grid_3x",
          "grid_3x",
          "grid_3x",
          "grid_1x",
          "grid_2x",
          "grid_1x",
          "grid_3x",
          "grid_3x",
          "grid_3x",
          "grid_1x",
          "grid_1x",
          "grid_2x",
          "grid_2x",
          "grid_2x",
          "grid_3x",
          "grid_3x",
          "grid_3x",
        ],
      ];
      let random = _.random(tmp.length - 1);

      return tmp[random];
    },
    updateLoading(value) {
      setTimeout(() => {
        try {
          if (this.$refs["NoDataFoundRef"]) {
            this.$refs["NoDataFoundRef"].updateLoading(value);
          }
        } catch (err) {}
      }, 100);
      return;
    },
    geAlltWallList({ callFromSerch = false, postData = {} }) {
      this.list = [];
      this.updateLoading(true);
      let clsList = ["box", "box_", "box__", "box_", "box__", "box"];
      let random = _.random(clsList.length - 1);
      //  random = Math.floor(Math.random() * clsList.length);
      this.templateClass = clsList[random];

      this.itemTemplate = this.getRandomTemplate();
      this.isLodaing = true;
      //this.$vs.loading();
      var _self = this;
      this.getStats();

      this.updateLoading(true);
      this.$store
        .dispatch("common/getWallList", postData)
        .then((response) => {
          this.isLodaing = false;
          

          this.list = [];
          this.list = response;
          setTimeout(() => {
            jQuery(".db_grid").isotope({
              layoutMode: "packery",
              itemSelector: ".grid_element",
              masonry: {
                horizontalOrder: true,
              },
            });
            if (jQuery(".db_grid").height() <= 50) {
              jQuery(".db_grid").height("auto");
              var _h = jQuery(".db_grid").innerHeight();
              jQuery(".db_grid").height(_h);
            }

            _self.updateLoading(false);
            // this.$vs.loading.close();
          }, 500);
        this.wallsLoaded =true;
          //alert(this.perpage);
        })
        .catch(() => {
          this.wallsLoaded =true;
          // this.$vs.loading.close();
          this.updateLoading(false);
          jQuery(".db_grid").isotope({
            layoutMode: "packery",
            itemSelector: ".grid_element",
          });
          this.isLodaing = false;
        });
    },
    changedTab(tabName = "all") {
      var _prevtab = this.tabName;

      this.page = 1;
      this.tabName = tabName;
      this.wallFilterData = {
        filters: {
          types: [this.tabName], // all, todo activity
          createdDateRange: [],
        },
        page: this.page,
        perpage: this.perPage,
        sorting: {
          path: "createdOn",
          order: -1,
        },
      };
      //this.tabDataName  = 'Activities ';
      // if('todo'==this.tabName || 'activity'==this.tabName){
      //       this.tabDataName  = 'Tasks ';
      // }

      this.tabDataName = "Activities ";
      if ("todo" == this.tabName || "activity" == this.tabName) {
        //   if('todo'==this.tabName){
        //        jQuery('.db_grid').isotope({ filter: '.todo' })

        //   }
        //    if('todo'==this.tabName){
        //         jQuery('.db_grid').isotope({ filter: '.activity' })

        //   }

        this.tabDataName = "Tasks ";
      }
      if ("todo" == this.tabName) {
        jQuery(".db_grid").isotope({ filter: ".todoItem" });
      } else if ("activity" == this.tabName) {
        jQuery(".db_grid").isotope({ filter: ".activityItem" });
      } else {
        jQuery(".db_grid").isotope({ filter: "*" });
      }

      if (jQuery(".todoItem").length == 0 && _prevtab != "todo") {
        jQuery(".db_grid").fadeOut().fadeIn();
      }

      //      this.wallList();
    },
    wallList() {
      // this.$store.commit('UPDATE_SIDEBAR_ITEMS_MIN', true)
      //this.$store.commit("TOGGLE_IS_SIDEBAR_ACTIVE", false);
      // this.$store.commit("TOGGLE_IS_SIDEBAR_ACTIVE", false);
      this.geAlltWallList({ postData: this.wallFilterData });
    },
    get_dashboardData: function () {
      this.$store.dispatch("get_dashboard_data", {}).then((response) => {
        this.dashboard_data = response;
        this.lca_requests = this.dashboard_data["lca_requests"]
          ? this.dashboard_data["lca_requests"]
          : [];

        this.petitionsCount = this.dashboard_data["petitionsCount"]
          ? this.dashboard_data["petitionsCount"]
          : {
              petitionCount: 0,
              rfeCount: 0,
              totalCount: 0,
            };
        this.petitionersCount = this.dashboard_data["petitionersCount"]
          ? this.dashboard_data["petitionersCount"]
          : {
              approvedCount: 0,
              pendingCount: 0,
              totalCount: 0,
            };
        this.beneficiaryStats = this.dashboard_data["beneficiaryStats"]
          ? this.dashboard_data["beneficiaryStats"]
          : {
              total: 0,
              active: 0,
              inactive: 0,
            };

        this.new_petitioners = this.dashboard_data["new_petitioners"]
          ? this.dashboard_data["new_petitioners"]
          : [];
        this.new_petitions = this.dashboard_data["new_petitions"]
          ? this.dashboard_data["new_petitions"]
          : [];
        this.rfe_petitions = this.dashboard_data["rfe_petitions"]
          ? this.dashboard_data["rfe_petitions"]
          : [];
      });
    },
    get_recentActivitys: function () {
      this.$store.dispatch("get_recent_activitys", {}).then((response) => {
        this.recent_activitys = response.list;
      });
    },
    getactivities: function () {
      this.$store.dispatch("getactivities").then((response) => {
        this.activities = response;
      });
    },
    get_mytasks: function () {
      this.$store.dispatch("get_my_tasks", {}).then((response) => {
        this.my_tasks = response.list.map((element) => {
          //"navigationKey":
          element["data"]["navigation_link"] = "#";
          if (element["data"]["navigationKey"] == "USER_DETAILS")
            if (element["data"]["navigationKey"] == "COMPANY_DETAILS")
              // element["data"]['navigation_link'] ="#/company/details/"+element["data"]['companyId'];

              element["data"]["navigation_link"] =
                "/company/details/" + element["data"]["companyId"];

          if (element["data"]["navigationKey"] == "PETITION_DETAILS")
            element["data"]["navigation_link"] =
              "/petition-details/" + element["data"]["petitionId"];

          if (element["data"]["navigationKey"] == "LCA_DETAILS")
            element["data"]["navigation_link"] =
              "/lca-details/" + element["data"]["lcaId"];

          if (element["data"]["description"].includes("questionnaire "))
            element["data"]["navigation_link"] =
              "/questionnaire/" + element["data"]["petitionId"];

          return element;
        });
        //this.my_tasks = a//response.list;
      });
    },
    refresh() {
      // alert("REFERESH");
      this.get_recentActivitys();
    },
  },
  computed: {
    generateGreetings() {
      var currentHour = moment().format("HH");

      if (currentHour >= 3 && currentHour < 12) {
        return "Good Morning";
      } else if (currentHour >= 12 && currentHour < 15) {
        return "Good Afternoon";
      } else if (currentHour >= 15 && currentHour < 20) {
        return "Good Evening";
      } else if (currentHour >= 20 && currentHour < 3) {
        return "Good Night";
      } else {
        return "Hello";
      }
    },
    countTotalPages() {
      return (this.totalpages = Math.ceil(
        this.getWallList.totalCount / this.perPage
      ));
    },
    user() {
      return this.$store.state.user;
    },
    getToDoWallListCount() {
      let returnVal = 0;
      let todoList = _.filter(this.getWallList.list, { type: "todo" });
      if (todoList) {
        returnVal = todoList.length;
      }
      return returnVal;
    },
  },
};
</script>
