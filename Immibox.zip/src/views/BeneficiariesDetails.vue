<template>
<div class="main-tabs-content tabs_mob petetion__details_page">
    <!-- <div class="tabs-layout-header" >
        <div class="case-no-panel">
             <vs-dropdown>
                <a class="flex items-center">
                    <div class="drop-down-content" >
                        Case No
                        <span >{{checkProperty(petition ,'caseNo')}}</span>
                    </div>
                    <i class="material-icons" v-if="petition">arrow_drop_down</i>
                </a>
                <vs-dropdown-menu class="caseno-dropdown" v-if="petitions">
                    <vs-dropdown-item @click="petetionChange(petition._id)" v-for="(petition, index) in petitions" :key="index">{{ petition.caseNo }}</vs-dropdown-item>
                </vs-dropdown-menu>
            </vs-dropdown>  
        </div>

        
        <div></div>
    </div> -->
    <!-- content section start here  {{petition.questionnaireFilled}}   -->

    <div class="tabs-content detail_page_sec petetion__details">
  
        <vs-row vs-w="12" class="bg_white"  >
            <vs-col vs-type="flex" style="padding:0px; width:100%" class="mob-left">
                <section class="petition__details_section">
                    
                    <div class="pd_left">
                        <ul style="top:60px">
                       
                        <li :class="{'current_child':activeTab=='Case Details'}" @click="setActivetab('Case Details' ,true)"><a>Profile Details</a></li>
                        <li v-if="checkProperty(petition ,'dependentsInfo','spouse' ) 
                                    && (  petition.dependentsInfo.spouse.firstName!=null)
                                    && petition.dependentsInfo.spouse.firstName!=''"
                             :class="{'current_child':activeTab=='Dependents Info'}" @click="setActivetab('Dependents Info' ,true)"        
                                    >
                                    <a>Dependents Info</a>
                        </li>
                            <li v-if="checkProperty(petition ,'dependentsInfo' ,'childrens') && 
                                            petition.dependentsInfo.childrens.length > 0 && 
                                            petition.dependentsInfo.childrens[0].h4Required && checkProperty(petition.dependentsInfo.childrens[0] ,'firstName')"
                                 :class="{'current_child':activeTab=='Children Info'}" @click="setActivetab('Children Info' ,true)"               
                                            >
                                <a>Children Info</a>
                            </li>
                            <li v-if="((checkProperty(petition,'fatherInfo') && checkProperty(petition,'fatherInfo','firstName')) || (checkProperty(petition,'motherInfo') && checkProperty(petition,'motherInfo','firstName')) )"
                                 :class="{'current_child':activeTab=='Parents Info'}" @click="setActivetab('Parents Info' ,true)"               
                                            >
                                <a>Parents Info</a>
                            </li>
                            <li v-if="checkProperty(petition ,'documents' ) "
                                 :class="{'current_child':activeTab=='Documents'}" @click="setActivetab('Documents' ,true)"               
                                            >
                                <a>Documents</a>
                            </li>

                             <li 
                                 :class="{'current_child':activeTab=='petitions'}" @click="setActivetab('petitions' ,true)"               
                                            >
                                <a>Cases</a>
                            </li>

                            
                        </ul>
                    </div>
                   
                    <div class="pd_right" v-if="[3,4].indexOf(checkProperty(beneficiarDetails,'statusId'))<=-1 " >
                        <div class="benefeciery_edit">
                          <ul>
                            <li class="edit_btn_list" @click="benEditProfile()">
                              <span class="items_edit">
                                  <img src="@/assets/images/main/icon-edit.svg" />Edit
                              </span>
                            </li>
                          </ul>
                        </div>
                        <div class="pd_right_cnt">
                          
                            <div v-if="checkProperty(petition,'beneficiaryInfo') && activeTab=='Case Details'" >
                          
                                 <beneficiaryDetails v-bind:petition="petition" :visastatuses="visastatuses" />
                            </div>

                            <div v-else-if="activeTab=='Case Details'" >
                            <div class="main-list-wrap petition_details_wrap pad20">

                                <div class="vx-row m-0 main-list-panel">
                                <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(userDetails ,'details' ,'firstName') || checkProperty(userDetails ,'beneficiaryInfo' ,'firstName') ">
                                    <div class="main-list">
                                    <p>
                                        First Name
                                        <span v-if="userDetails.details">{{checkProperty(userDetails ,'details' ,'firstName')}}</span>
                                        <span v-if="userDetails.beneficiaryInfo">{{checkProperty(userDetails ,'beneficiaryInfo' ,'firstName')}}</span>

                                    </p>
                                    </div>
                                </div>

                                <div  class="vx-col md:w-1/3 w-full p-0"
                                   v-if="checkProperty(userDetails ,'details' ,'middleName') || checkProperty(userDetails ,'beneficiaryInfo' ,'middleName')"
                                >
                                    <div class="main-list">
                                    <p>
                                        Middle Name
                                        <span style="text-transform: capitalize;"  v-if="userDetails.details">{{checkProperty(userDetails ,'details' ,'middleName')}}</span>
                                        <span style="text-transform: capitalize;" v-if="userDetails.beneficiaryInfo">{{checkProperty(userDetails ,'beneficiaryInfo' ,'middleName')}}</span>

                                    </p>
                                    </div>
                                </div>

                                <div  class="vx-col md:w-1/3 w-full p-0"
                                   v-if="checkProperty(userDetails ,'details' ,'lastName') || checkProperty(userDetails ,'beneficiaryInfo' ,'lastName')"
                                >
                                    <div class="main-list">
                                    <p>
                                        Last Name
                                        <span v-if="userDetails.details" style="text-transform: capitalize;" >{{checkProperty(userDetails ,'details' ,'lastName')}}</span>
                                        <span style="text-transform: capitalize;" v-if="userDetails.beneficiaryInfo">{{checkProperty(userDetails ,'beneficiaryInfo' ,'lastName')}}</span>

                                    </p>
                                    </div>
                                </div>
                                <div  class="vx-col md:w-1/3 w-full p-0"
                                     v-if="checkProperty(userDetails ,'details' ,'email') || checkProperty(userDetails ,'beneficiaryInfo' ,'email')"
                                >
                                    <div class="main-list">
                                    <p>
                                        Email
                                        <span v-if="userDetails.details">{{checkProperty(userDetails ,'details' ,'email')}}</span>
                                        <span v-if="userDetails.beneficiaryInfo">{{checkProperty(userDetails ,'beneficiaryInfo' ,'email')}}</span>

                                    </p>
                                    </div>
                                </div>

                                 <div  class="vx-col md:w-1/3 w-full p-0"
                                     v-if="checkProperty(userDetails ,'details' ,'phone') || checkProperty(userDetails ,'beneficiaryInfo' ,'cellPhoneNumber')"
                                >
                                    <div class="main-list">
                                    <p>
                                        Phone Number
                                        <span v-if="userDetails.details">{{checkProperty(userDetails ,'phoneCountryCode' ,'countryCallingCode')}} {{checkProperty(userDetails ,'details' ,'phone')}}</span>
                                        <span v-if="userDetails.beneficiaryInfo">{{checkProperty(userDetails['beneficiaryInfo'] ,'cellPhoneCountryCode' ,'countryCallingCode')}} {{checkProperty(userDetails,'beneficiaryInfo' ,'cellPhoneNumber')}}</span>

                                    </p>
                                    </div>
                                </div>
                                </div>

                            </div>
                                                             
                            </div>
            
                            <div v-if="checkProperty(petition ,'dependentsInfo','spouse') 
                            && (checkProperty(petition['dependentsInfo'] ,'spouse','firstName'))
                                   
                             && activeTab=='Dependents Info' "> 
                                <SpouseDetails v-bind:petition="petition"  @download_or_view="download_or_view" />
                            </div>

                            <div class="pad20"
                            v-if="checkProperty(petition ,'dependentsInfo' ,'childrens') && (
                                            petition.dependentsInfo.childrens.length > 0 && 
                                            petition.dependentsInfo.childrens[0].h4Required && checkProperty(petition.dependentsInfo.childrens[0] ,'firstName')
                                           &&  activeTab=='Children Info')
                                            "
                            >
                          
                                 <ChildDetails v-bind:petition="petition" @download_or_view="download_or_view" :visastatuses="visastatuses"  />
                            </div>
                            <div v-if="checkProperty(petition,'beneficiaryInfo') && activeTab=='Parents Info'" >
                                <parentsInfoDetails
                                    v-bind:petition="petition"
                                    :visastatuses="visastatuses"
                                />
                            </div>
                                                     

                           <div v-if="checkProperty(petition, 'documents') &&  activeTab=='Documents'"  class="pad20">
                           <Documents @updatepetition="reloadPetition" :openTabes="false" @download_or_view="download_or_view" :documentsUploadbtn="true" :callBenDetails="true" :currentRole="currentRole" :allbtn="true" v-bind:petition="petition" />
                           </div>
                           <div v-if="  activeTab=='petitions' && (checkProperty(petition ,'beneficiaryInfo') || checkProperty(userDetails ,'_id')) "  class="pad20">
                            
                                <petitions v-if="checkProperty(petition ,'beneficiaryInfo')" :callFromBen="true" :beneficiaryId="petitionId" :beneficiaryInfo="checkProperty(petition ,'beneficiaryInfo')" :petitionerDetails="checkProperty(petition,'petitionerDetails')" />
                                <petitions v-else :beneficiaryId="petitionId" :callFromBen="true" :beneficiaryInfo="userDetails" :petitionerDetails="checkProperty(userDetails,'petitionerDetails')"/>
                            
                           </div>
                        
                        </div>
                    </div>
                </section>
            </vs-col>

            

            
        </vs-row>

        
        
        
    

    </div>

    <vs-popup class="document_modal document_modal-v2"
    :class="{ expand: expandModal }" 
     :title="checkProperty(selectedFile,'name')" 
     :active.sync="docPrivew">
      <div class="document_actions" @click="expandModal = !expandModal">
      <figure v-if="!expandModal" class="maximize-img"><img src="@/assets/images/maximize.png"  width="18" height="18"/></figure>
      <figure v-else class="minimize-img"><img src="@/assets/images/minimize.png"  width="20" height="20"/></figure>
    </div>
        <h2><img :class="{'pdf_view_download':docType == 'pdf', 'office_view_download':docType == 'office'  , 'image_view_download':docType =='image'}" class="download-button" @click="downloads3file(selectedFile)" src="@/assets/images/download.svg" /></h2>
        <div class="pdf_loader">
            
            <!-- <span :class="{'pdf_view_close':docType == 'pdf', 'office_view_close':docType == 'office'  , 'image_view_close 33':docType =='image'}" class="close close2" @click="docPrivew= false"></span> -->
            <template v-if="docType=='office'">
                <!-- <VueDocPreview :value="docValue" type="office" /> -->
                <div style="height: 90vh">
                    <div id="placeholder" style="height: 100%"></div>
                </div>
            </template>
            <template v-else-if="docType == 'image'">
                <img :src="docValue">
            </template>
            <template v-else-if="docType == 'pdf'">
                <div class="pdf" style="height: 90vh">
                  <iframe
              v-if="docValue != '' && docPrivew"
              border="0"
              style="border: 0px"
              :src="docValue"
              height="100%"
              width="100%"
            >PDF</iframe>
                    <!-- <object :data="docValue" type="application/pdf" width="1000" height="600" v-if="docPrivew">
                        alt : <a :href="docValue">PDF</a>
                    </object> -->
                </div>
            </template>
        </div>
    </vs-popup>

    

</div>
</template>

<script>
import parentsInfoDetails  from "@/views/petition/subtabs/parentsInfoDetails.vue"; 
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import FormsandLetters from "./petition/FormsLetters";
import CompanyDocsTemplates from  "./petition/CompanyDocsTemplates";
import ScannedCopies from "./ScannedCopies";
import ProcessFlow from "./petition/ProcessFlow";
import RequestLCA from "./RequestLCA";
import LCADetails from "./LCADetails";
import PetitionUpdates from "./petition/PetitionUpdates";

import ClientDetails from "./petition/ClientDetails";
import ChildDetails from "./petition/ChildDetails";
import SpouseDetails from "@/views/beneficiaryProfile/benSpouseDetailsPage.vue";
import Documents from "./petition/Documents";
import beneficiaryDetails from "@/views/beneficiaryProfile/benDetails.vue";
import Communication from "./petition/Communication";
import Fees from "./petition/Fees";
//import petitions from "@/views/Petitions.vue";
import petitions from "@/views/Petitions-new-list.vue";
  import _ from "lodash";
import moment from "moment";
import JQuery from "jquery";
import VueDocPreview from 'vue-doc-preview'


export default {
    components: {
        parentsInfoDetails,
        VueDocPreview,
        VuePerfectScrollbar,
        FormsandLetters,
        ScannedCopies,
        Documents,
        ProcessFlow,
        RequestLCA,
        LCADetails,
        ClientDetails,
        SpouseDetails,
        ChildDetails,
        beneficiaryDetails,
        Communication,
        PetitionUpdates,
        Fees,
        CompanyDocsTemplates,
        petitions
    },
    name: "app",
    data: () => ({
      expandModal: false,
      beneficiarDetails:null,
        activeTab:'Case Details',
       formsAndLettersList:[],
        feeInvoicesPermessions:false,
        isLcaRequiredForPetition:true,
        isEveryThingLoaded:false,
        showProcessFlow:false,
        docPrivew: false,
        docValue: '',
        docType: "",
        selectedFile: null,

        loaded: false,
        currentRole: null,
        currentUserId: null,
        SuccessQuestionnaire: false,
        petition: [],
        petitions: [],
        petitionhistory: [],
        supervisorlist: [],
        
        tabs: [{
                index: 0
            },
            {
                index: 1
            },
            {
                index: 2
            },
            {
                index: 3
            },
            {
                index: 4
            },
            {
                index: 5
            },
            {
                index: 6
            }
        ],

        visa_status: {},
        visastatuses: [],
        spouse_currentStatusDetails: {},
        country_names: {},
        lcaDetails: null,
        workFlowId:null,
        workFlowDetails:null,
       //Filing Fee Veriables
        editFilngFee:false,
		filingFeeData:[
            {
            amount: null,
            invoice: false,
            description: "",
            },
            ],
	    filingFeesPopup:false,
		filingFeeformerrors:'',
		submitingFilingFee:false,
		filingFeeComment:'',
		emailInvoice:false,
        validatefilingFeeDescrition:true,
         //Filing Fee Veriables End
         userDetails:null

    }),
    watch: {
       $route:function(){
        if (this.$route.params && this.$route.params.itemId) {
            this.petitionId = this.$route.params.itemId;
            this.init();
        }
       }
    },
    methods: {
      benEditProfile(){
            let benId = this.$route.params.itemId;
            this.$router.push('/beneficiary-edit/'+benId)
        },
        download_or_view(docItem) {
      let value = _.cloneDeep(docItem);
      this.expandModal= false;
      

      if (
        this.checkProperty(this.getPetitionDetails, "caseNo") &&
        this.checkProperty(value, "name")
      ) {
        let docName = _.cloneDeep(value["name"]);
        
        try{
          if(!docName.includes(this.checkProperty(this.getPetitionDetails, "caseNo"))){
            value["name"] = docName;
          }
        }catch(err){

        }

        
      }

      var _self = this;
      this.formSubmited = false;
      if (_.has(value, "path")) {
        value["url"] = value["path"];
        value["document"] = value["path"];
      }

      if (_.has(value, "url")) {
        value["path"] = value["url"];
        value["document"] = value["url"];
      }

      if (_.has(value, "document")) {
        value["path"] = value["document"];
        value["url"] = value["document"];
      }

      this.selectedFile = value;
      this.docValue = "";
      this.docPrivew = false;
      this.docType = false;
      this.docType = this.findmsDoctype(value);

      //if ( (this.docType == "office" || this.docType == "image" || this.docType == "pdf") && value.download == false ) {
      if (this.docType == "office" || this.docType == "image" || this.docType == "pdf") {
        value.url = value.url.replace(this.$globalgonfig._S3URL, "");
        value.url = value.url.replace(this.$globalgonfig._S3URLAWS, "");
        let postdata = {
          keyName: value.url,
          petitionId: value["petitionId"],
        };
        this.$store.dispatch("getSignedUrl", postdata).then((response) => {
          this.docValue = response.data.result.data;

          if (this.docType == "office") {
            document.getElementById("placeholder").innerHTML =
              "  <div  id='placeholder2' style='height:100%'></div>";
            let _editing = false;

            if ([50, 51].indexOf(this.getUserRoleId) > -1) {
              _editing = false;
            }
           
           
            let docViewUrl ='https://immibox.com/api/petition/post-edited-document';
            if(_.has(this.$globalgonfig, 'DOC_VIEW_URL')){
              docViewUrl = this.$globalgonfig['DOC_VIEW_URL'];
            }
               
            if ( _.has(value ,'viewmode') && value.viewmode==false ) {
              _editing = true;
            }
            var _ob = {};
            if (value.editedDocument) {
              _ob = {
                petitionId: this.petition._id,
                name: value.name,
                _id: value._id,
                extn: "docx",
                formLetterType: "Letter",
                parentId: value.parentId,
              };
            } else {
              _ob = {
                name: value.name,
                petitionId: this.petition._id,
                _id: value._id,
                extn: "docx",
                formLetterType: "Letter",
                parentId: value._id,
              };
            }
            var nid = value._id +  Math.round(+new Date()/1000)
            window.docEditor = new DocsAPI.DocEditor("placeholder2", {
              document: {
                c: "forcesave",
                fileType: "docx",
                key: nid,
                userdata: JSON.stringify(_ob),
                title: value.name,
                url: response.data.result.data,
                permissions: {
                  edit: _editing,
                  download: true,
                  reader: false,
                  review: false,
                  comment: false,
                },
              },

              documentType: "word",
              height: "100%",
              width: "100%",

              editorConfig: {
                userdata: JSON.stringify(_ob),
                callbackUrl:
                  docViewUrl+"?payload=" +
                  JSON.stringify(_ob) +
                  "&token=" +
                  _self.$store.state.token +
                  "&name=" +
                  value.name.replace(".docx", ""),
                customization: {
                  logo: {
                    image: "https://immibox.com/app/favicon.png",
                    imageDark: "https://immibox.com/app/favicon.png",
                    url: "https://immibox.com",
                  },
                  anonymous: {
                    request: false,
                    label: "Guest",
                  },
                  chat: false,
                  comments: false,
                  compactHeader: false,
                  compactToolbar: true,
                  compatibleFeatures: false,
                  feedback: {
                    visible: false,
                  },
                  forcesave: true,
                  help: false,
                  hideNotes: true,
                  hideRightMenu: true,
                  hideRulers: true,
                  layout: {
                    toolbar: {
                      collaboration: false,
                    },
                  },
                  macros: false,
                  macrosMode: "warn",
                  mentionShare: false,
                  plugins: false,
                  spellcheck: false,
                  toolbarHideFileName: true,
                  toolbarNoTabs: true,
                  uiTheme: "theme-light",
                  unit: "cm",
                  zoom: 100,
                },
              },
              events: {
                onReady: function () {},
                onDocumentStateChange: function (event) {
                  var url = event.data;
                  if (!event.data) {
                    if (value.editedDocument) {
                    }
                  }
                },
              },
            });
            //this.docValue = encodeURIComponent(response.data.result.data);
          }

          if (this.docType == "pdf") {
            var _vid = value._id;
            if (value.parentId) {
              _vid = value.parentId;
            }
            var  viewmode = 0; //viewmode= 1 Enable edit AND viewmode= 0; //Disabled Edit
            let pdfViewUrl ='https://immibox.com/viewer/pdfjs-dist/web/viewerv2.html';
            
            if(_.has(this.$globalgonfig, 'PDF_VIEW_URL')){
              pdfViewUrl = this.$globalgonfig['PDF_VIEW_URL'];
            }

            if(_.has(value ,'viewmode')){
              if (value.viewmode) {
                viewmode = 0;
              }else{
                viewmode = 1;
                viewmode=viewmode+"&depLabel="+value.depLabel+"&depType="+value.depType+"&docUserType="+value.docUserType+"&generated="+value.generated+"&formAndLetterId="+value._id+"&save=v2&docname="+value.name+"&posturl="+this.$globalgonfig._APIURL+"/&petitionId="+this.$route.params.itemId+"&entityId="+value.entityId+"&token="+this.$store.state.token
                if(_.has(this.$globalgonfig, 'PDF_EDIT_URL')){
                  pdfViewUrl = this.$globalgonfig['PDF_EDIT_URL'];
                 }
              }

            }

           
            
           
            if(this.getPetitionTab != 'Forms and Letters'){
              viewmode= 0; //Disabled Edit
              if(_.has(this.$globalgonfig, 'PDF_VIEW_URL')){
                pdfViewUrl = this.$globalgonfig['PDF_VIEW_URL'];
              }
            }
            this.docValue =
              pdfViewUrl+"?view=" +
              viewmode +
              "+&file=" +
              encodeURIComponent(response.data.result.data);
          }
          this.docPrivew = true;
        });
      } else {
        this.downloads3file(value);
      }
    },   
   
  
    // download_or_view(value) {
        
    //     if (_.has(value, "path")) {
    //         value['url'] = value['path'];
    //         value['document'] = value['path'];
    //     }

    //     if (_.has(value, "url")) {
    //         value['path'] = value['url'];
    //         value['document'] = value['url'];
    //     }

    //     if (_.has(value, "document")) {
    //         value['path'] = value['document'];
    //         value['url'] = value['document'];
    //     }
        

    //     this.selectedFile = value;
    //     this.docValue = '';
    //     this.docPrivew = false;
    //     this.docType = false;
    //     this.docType = this.findmsDoctype(value['name'], value.mimetype);

    //     if (this.docType == "office" || this.docType == "image") {

    //         value.url = value.url.replace(this.$globalgonfig._S3URL, "");
    //         value.url = value.url.replace(this.$globalgonfig._S3URLAWS, "");
    //         let postdata = {
    //             keyName: value.url
    //         };
    //         this.$store.dispatch("getSignedUrl", postdata).then((response) => {
    //             this.docValue = response.data.result.data;

    //             if (this.docType == "office") {
    //                 this.docValue = encodeURIComponent(response.data.result.data);
    //             }
    //             this.docPrivew = true;
    //         });

    //     } else {

    //         this.downloads3file(value);
    //     }

    // },

    
    reloadPetition(tab='Case Details') {
        
        
        if(tab !=''){
            
            this.$store.dispatch("setPetitionTab" , tab)
            .then(()=>{
                
                this.init();
                
            })
            .catch(()=>{
                this.init();
                
            })
        }else{
            this.$store.dispatch("setPetitionTab" , 'Case Details')
            this.init();
            

        }
        
        
            
        
    },
    setActivetab(stab='Case Details' ,callFromClick=false) {
        //Communication Company Docs Case Details Dependents Info  , Children Info , Fees/Invoices
       
        if(!stab){
             stab='Case Details'
        }
        this.activeTab= stab
          
        
    },
   
    
    loadPetetion(tab='') {
      
        if(tab==''){
            tab = this.activeTab;

        }
        
       // this.workFlowDetails =null;
      //this.petition =null;
      //  this.lcaDetails = null;
        // this.petition.filingFeeDetails = null; ,"getDocuments":true
     
        if(this.petition ==null){
             this.loaded = false;
             this.loaded = true;
            this.$vs.loading();

        }
       let postData ={"userId":"" }

            postData['userId'] = this.petitionId;
            let pth="petition/get-recent-by-beneficiary";
            pth ="petition-common/get-recent-by-beneficiary";
            pth = '/beneficiary-profile/get-profile-details'
         this.$store.dispatch("commonAction", {"data":postData ,"path":pth}).then(response => {
            if(response){
                this.$vs.loading.close();
                this.loaded = false;
                this.loaded = true;
                this.petition = response;
                if(!this.checkProperty(this.petition,'beneficiaryInfo','name')){
                    this.petition['beneficiaryInfo']['name'] = this.concateName
                }
                this.userDetails = response['userDetails'];
            }else{
                pth ="petition-common/get-recent-by-beneficiary";
                this.$store.dispatch("commonAction", {"data":postData ,"path":pth}).then(response => {
                    if(response && response['caseDetails']){
                        this.petition = response['caseDetails'];
                    }
                    else{
                        if(response && response['userDetails']){
                            this.userDetails = response['userDetails']; 
                        }
                        
                    }
                   
                }).catch((err)=>{
                    
                })

            }

            let payLoad ={"userId":"", } 
            payLoad['userId'] = this.petitionId;
            let path ="users/details"
            this.$store.dispatch("commonAction", {"data":payLoad ,"path":path}).then(response => {
            this.beneficiarDetails = response 
            });
        });
       
    },
    init(){
      this.currentRole = this.$store.state.user.loginRoleId;
      this.currentUserId = this.$store.state.user._id;
      this.loadPetetion();
    },
    
    },
    beforeDestroy() {
        //  JQuery('#btnSidebarToggler').click()
    },
    mounted() {
        this.$store.dispatch("getmasterdata", "visa_status").then((response) => {
                this.visastatuses = response;
            });
         //this.$store.dispatch("setPetitionTab" , 'Case Details');
      
        if (this.$route.params && this.$route.params.itemId) {
            this.petitionId = this.$route.params.itemId;
            this.init();

        }
   
    },
    computed:{
        concateName(){
            let returnVal = ''
            if(this.checkProperty(this.petition['beneficiaryInfo'],'firstName')){
                returnVal = this.checkProperty(this.petition['beneficiaryInfo'],'firstName')
            }
            if(this.checkProperty(this.petition['beneficiaryInfo'],'middleName')){
                    returnVal = returnVal +' '+ this.checkProperty(this.petition['beneficiaryInfo'],'middleName')
            }
            if(this.checkProperty(this.petition['beneficiaryInfo'],'lastName')){
                returnVal =  returnVal +' '+this.checkProperty(this.petition['beneficiaryInfo'],'lastName')
            }
            return returnVal
        },
        
    }
};
</script>
