<template>
  <div class="text-center section calendarwidget">
    <FullCalendar
      ref="calendar"
       @eventRender="eventRender"
      :options="calendarOptions"
    />
  </div>
</template>

<script>
import "@fullcalendar/core/vdom"; // solves problem with Vite
import FullCalendar from "@fullcalendar/vue";
import dayGridPlugin from "@fullcalendar/daygrid";
import interactionPlugin from "@fullcalendar/interaction";
import timeGridPlugin from "@fullcalendar/timegrid";
import { _ } from "core-js";
import moment from "moment";

export default {
  components: {
    FullCalendar, // make the <FullCalendar> tag available
  },
  mounted() {},
  data() {
    const vm = this;
    return {
      allCaseList: [],
      initialView: "dayGridMonth",
      calendarOptions: {
       
          
           eventClick: function(info) {
               
            if(_.get( info,'event.extendedProps.type') =="task"){
               let path =  {'path':"/tasks-list" ,"query":{}};
               path["query"]['id'] =info.event.id
               vm.$router.push(path);

            } 
             if(_.get( info,'event.extendedProps.type') =="perm"){
              vm.$router.push({ path: `/gc-employment-details/${info.event.id}` }).catch(err => {})


            }
            if(_.get( info,'event.extendedProps.type') =="case"){

               vm.$router.push({ path: `/petition-details/${info.event.id}` }).catch(err => {})

            }

       
            return false;
       },
        events: function (start, end, callback, callbacks) {
          let self = vm;

          let postData = {
            matcher: {
              //	"rfeCases": true,
              searchString: "",
              petitionerIds: [],
              beneficiaryIds: [],
              statusIds: [],
              typeIds: [],
              subTypeIds: [],
              genders: [],
              maritalStatusIds: [],
              countryIds: [],
              stateIds: [],
              locationIds: [],
              createdDateRange: [],
              getMasterDataOnly: false, // Send true when needs master data only
              lcaStatusIds: [],
              invoiceStatusIds: [],
              deadlineDateRange: [start.startStr, start.endStr],
            },
            page: 1,
            perpage: 20,
            sorting: {
              path: "createdOn", //deadlineDays, updatedOn, createdByName, typeName, subTypeName, caseNo, statusName, clientName, beneficiaryName
              order: 1,
            },
            today: moment().format("YYYY-MM-DD"),
          };
          vm.allCaseList = [];
         var formstedevents = [];
          vm.$store
            .dispatch("petitioner/getpetitions", postData)
            .then((response) => {
              vm.allCaseList = _.cloneDeep(response.list);
              let postData={
                filters:{
                  title:'',
                  priorityIds: [],
			            statusIds: [],
			            assignedToIds: [],
			            watchingByIds: [], 
			            createdByIds: [],
			            createdOnRange: [],
                  dueDateRange: [start.startStr, start.endStr],
                  "addToCalendarList": [true],
                },
                sorting:{
                    path: "dueDate",
                    order:-1
                },
                page: 1,
                perpage: 20,
                today: moment().format("YYYY-MM-DD"),
            }
             vm.$store.dispatch("getList", { data: postData, path: "/tasks/list" })
            .then((res)=>{

                res.list.forEach( (elem) =>{
                  let title =elem.title;
                  if(vm.checkProperty(elem ,'customId')){
                    title = elem['customId']+": "+elem.title
                  }
                  vm.allCaseList.push(elem);
                formstedevents.push({
                  start: elem["dueDate"],
                  end: elem["dueDate"],
                  id:elem._id,
                  title: title,
                  type:"task",
                  toolTipHtml:title
                });
              });
               response.list.forEach(function (elem) {
               let caseItem= {
                  start: elem["deadlineDate"],
                  end: elem["deadlineDate"],
                  id:elem._id,
                  title: elem.caseNo,
                  type:"case",
                  toolTipHtml:elem.caseNo
                }
                
                if(vm.checkProperty(elem ,'typeDetails' ,'name' ) && vm.checkProperty(elem ,'subTypeDetails' ,'name' ) ){
                 caseItem['toolTipHtml'] = caseItem['toolTipHtml']+"<br>"+elem['typeDetails']['name']+"/"+elem['subTypeDetails']['name']
                }
                 if(vm.checkProperty(elem ,'beneficiaryDetails' ,'name' )  ){
                 caseItem['toolTipHtml'] = caseItem['toolTipHtml']+"<br>"+elem['beneficiaryDetails']['name']
                }
                 if(vm.checkProperty(elem ,'petitionerDetails' ,'name' )  ){
                  if(vm.checkProperty(elem ,'beneficiaryDetails' ,'name' )  ){

                    caseItem['toolTipHtml'] = caseItem['toolTipHtml']+" / "+elem['petitionerDetails']['name']
                  }else{

                    caseItem['toolTipHtml'] = caseItem['toolTipHtml']+"<br>"+elem['petitionerDetails']['name']

                  }

                 
                }
                 if(vm.checkProperty(elem ,'statusDetails' ,'name' )  ){

                    let clas='sr';
                    if( vm.checkProperty(elem ,'statusDetails','id') == 1){
                      clas= 'status_created'
                    }
                    if( vm.checkProperty(elem ,'statusDetails','id') == 2){
                      clas= 'status_submited'
                    }
                    if( vm.checkProperty(elem ,'statusDetails','id') == 3){
                      clas= 'status_inProcess'
                    }
                    if( vm.checkProperty(elem ,'statusDetails','id') == 4){
                      clas= 'status_waiting'
                    }
                    if( vm.checkProperty(elem ,'statusDetails','id') == 5){
                      clas= 'status_ready_for_filing'
                    }
                    if( vm.checkProperty(elem ,'statusDetails','id') == 6){
                      clas= 'status_sent_for_signatures'
                    }
                    if( vm.checkProperty(elem ,'statusDetails','id') == 7){
                      clas= 'staus_filed_with_USCIS'
                    }
                     if( vm.checkProperty(elem ,'statusDetails','id') == 8){
                      clas= 'Status_received_by_USCIS'
                    }
                    if( vm.checkProperty(elem ,'statusDetails','id') == 9){
                    clas= 'status_approved'
                  }
                  if( vm.checkProperty(elem ,'statusDetails','id') == 10){
                    clas= 'status_denied'
                  }
                  if( vm.checkProperty(elem ,'statusDetails','id') == 11){
                    clas= 'RFE_Received'
                  }
                  if( vm.checkProperty(elem ,'statusDetails','id') == 12){
                    clas= 'response_to_RFE_Filed'
                  }
                   if( vm.checkProperty(elem ,'statusDetails','id') == 13){
                    clas= 'response_to_RFE_Received'
                  }
                  if( vm.checkProperty(elem ,'statusDetails','id') == 14){
                    clas= 'status_withdrawn'
                  }
                  if( vm.checkProperty(elem ,'statusDetails','id') == 15){
                    
                  }
                clas ='noclr'
                  
                   

                 caseItem['toolTipHtml'] = caseItem['toolTipHtml']+"<br><span style='color:#E50019' calss='"+clas+"'>"+elem['statusDetails']['name']+"</span>"
                }
                
                formstedevents.push(caseItem);
              });
              end(formstedevents);

            }).catch((err)=>{

               response.list.forEach(function (elem) {
                formstedevents.push({
                  start: elem["deadlineDate"],
                  end: elem["deadlineDate"],
                  id:elem._id,
                  title: elem.caseNo,
                  type:"case"
                });
              });
              end(formstedevents);

            })

              



       

              //alert(this.totalpages);
            })
            .catch((err) => {
              vm.allCaseList = [];
            });

            
            vm.$store.dispatch("getList", { data: postData, path: "/perm/list" })
      .then(response => {

            response.list.forEach(function (elem) {


              let caseItem= {
                  start: elem["deadlineDate"],
                  end: elem["deadlineDate"],
                  id:elem._id,
                  title: elem.caseNo,
                  type:"perm",
                  toolTipHtml:elem.caseNo
                }
                
                if(vm.checkProperty(elem ,'typeDetails' ,'name' ) && vm.checkProperty(elem ,'subTypeDetails' ,'name' ) ){
                 caseItem['toolTipHtml'] = caseItem['toolTipHtml']+"<br>"+elem['typeDetails']['name']+"/"+elem['subTypeDetails']['name']
                }
                 if(vm.checkProperty(elem ,'beneficiaryDetails' ,'name' )  ){
                 caseItem['toolTipHtml'] = caseItem['toolTipHtml']+"<br>"+elem['beneficiaryDetails']['name']
                }
                 if(vm.checkProperty(elem ,'petitionerDetails' ,'name' )  ){
                  if(vm.checkProperty(elem ,'beneficiaryDetails' ,'name' )  ){

                    caseItem['toolTipHtml'] = caseItem['toolTipHtml']+" / "+elem['petitionerDetails']['name']
                  }else{

                    caseItem['toolTipHtml'] = caseItem['toolTipHtml']+"<br>"+elem['petitionerDetails']['name']

                  }

                 
                }
                 if(vm.checkProperty(elem ,'statusDetails' ,'name' )  ){

                    let clas='sr';
                    if( vm.checkProperty(elem ,'statusDetails','id') == 1){
                      clas= 'status_created'
                    }
                    if( vm.checkProperty(elem ,'statusDetails','id') == 2){
                      clas= 'status_submited'
                    }
                    if( vm.checkProperty(elem ,'statusDetails','id') == 3){
                      clas= 'status_inProcess'
                    }
                    if( vm.checkProperty(elem ,'statusDetails','id') == 4){
                      clas= 'status_waiting'
                    }
                    if( vm.checkProperty(elem ,'statusDetails','id') == 5){
                      clas= 'status_ready_for_filing'
                    }
                    if( vm.checkProperty(elem ,'statusDetails','id') == 6){
                      clas= 'status_sent_for_signatures'
                    }
                    if( vm.checkProperty(elem ,'statusDetails','id') == 7){
                      clas= 'staus_filed_with_USCIS'
                    }
                     if( vm.checkProperty(elem ,'statusDetails','id') == 8){
                      clas= 'Status_received_by_USCIS'
                    }
                    if( vm.checkProperty(elem ,'statusDetails','id') == 9){
                    clas= 'status_approved'
                  }
                  if( vm.checkProperty(elem ,'statusDetails','id') == 10){
                    clas= 'status_denied'
                  }
                  if( vm.checkProperty(elem ,'statusDetails','id') == 11){
                    clas= 'RFE_Received'
                  }
                  if( vm.checkProperty(elem ,'statusDetails','id') == 12){
                    clas= 'response_to_RFE_Filed'
                  }
                   if( vm.checkProperty(elem ,'statusDetails','id') == 13){
                    clas= 'response_to_RFE_Received'
                  }
                  if( vm.checkProperty(elem ,'statusDetails','id') == 14){
                    clas= 'status_withdrawn'
                  }
                  if( vm.checkProperty(elem ,'statusDetails','id') == 15){
                    
                  }
                clas ='noclr'
                  
                   

                 caseItem['toolTipHtml'] = caseItem['toolTipHtml']+"<br><span style='color:#E50019' calss='"+clas+"'>"+elem['statusDetails']['name']+"</span>"
                }
                
                formstedevents.push(caseItem);

               

              })
      })
            


        },
   
        headerToolbar: {
          left: "today prev,next",
          center: "title",
          right: "dayGridMonth,timeGridWeek,timeGridDay",
        },
        plugins: [dayGridPlugin, timeGridPlugin, interactionPlugin],
         eventMouseEnter: function(eventObj, $el) {

            var elemenet = document.getElementById("tooltipcal");

           // elemenet.style.left =   eventObj.jsEvent.screenX +'px' ;
           // elemenet.style.top =   eventObj.jsEvent.screenY   +'px' ;  
             elemenet.style.left =   eventObj.jsEvent.screenX +'px' ;
            // alert(window.screenY)
            elemenet.style.top =   (eventObj.jsEvent.screenY + eventObj.el.clientHeight) +'px' ;
 
            elemenet.innerHTML = eventObj.event.title;
            if(eventObj.event['_def']['extendedProps']['toolTipHtml']){
              
              elemenet.innerHTML =eventObj.event['_def']['extendedProps']['toolTipHtml'];
            }

            elemenet.style.display = "block"

           },
           eventMouseLeave : function(eventObj, $el) {

            var elemenet = document.getElementById("tooltipcal");

            // elemenet.style.left =   eventObj.jsEvent.clientX +'px' ;
           // elemenet.style.top =   eventObj.jsEvent.clientY   +'px' ;      

            // elemenet.innerHTML = eventObj.event.title;

            elemenet.style.display = "none"

           }
      },
    };
  },
  methods: {
 eventRender(info){


 },
    filterCasesList(type = "DeadLine") {
      /*
      caseListTypes: ['Latest', 'DeadLine'],
        caseListType:'Latest',
      */
      if (this.caseListType == "Latest") {
        this.deadlineDateRange = [];
        this.getMissingDeadlines = false;
      } else {
        let today = moment();
        let tomorrow = moment().add(1, "days");
        let yesterday = moment().add(-1, "days");
        this.deadlineDateRange = [today, tomorrow];
        this.getMissingDeadlines = true;
      }
      this.isListloading = true;
      this.getpetitions();
    },

    getpetitions() {
      let self = this;

      let postData = {
        matcher: {
          //	"rfeCases": true,
          searchString: "",
          petitionerIds: [],
          beneficiaryIds: [],
          statusIds: [],
          typeIds: [],
          subTypeIds: [],
          genders: [],
          maritalStatusIds: [],
          countryIds: [],
          stateIds: [],
          locationIds: [],
          createdDateRange: [],
          getMasterDataOnly: false, // Send true when needs master data only
          lcaStatusIds: [],
          invoiceStatusIds: [],
          deadlineDateRange: self.deadlineDateRange,
        },
        page: 1,
        perpage: 20,
        sorting: {
          path: "createdOn", //deadlineDays, updatedOn, createdByName, typeName, subTypeName, caseNo, statusName, clientName, beneficiaryName
          order: 1,
        },
        today: moment().format("YYYY-MM-DD"),
      };
      this.allCaseList = [];

      this.$store
        .dispatch("petitioner/getpetitions", postData)
        .then((response) => {
          this.allCaseList = _.cloneDeep(response.list);

          //alert(this.totalpages);
        })
        .catch((err) => {
          this.allCaseList = [];
        });
    },
  },
};
</script>

<style lang="scss">
.calendarwidget {
  padding: 20px;
}
.fc-event-time {
  display: none;
}
.fc-event-title{

    cursor: pointer;
}
.fc-v-event{
  background-color: #0e1d48;
}
.fc-daygrid-event-dot, .fc-timegrid-event-dot{

border-color: #fff !important;
}
.fc-event-title{
color: #fff !important;
font-family: "DM Sans", sans-serif !important; font-weight:700 !important; font-size:12px; text-overflow: ellipsis;
}
.fc-daygrid-event, .fc-day-past .fc-timegrid-event{
  background-color: #0e1d48 !important;

}
.fc-day-past .fc-daygrid-event, .fc-day-past .fc-timegrid-event{
  background-color: #E50019 !important;

}


.fc-theme-standard td{    font-family: "DM Sans", sans-serif; font-weight:500;
  &.fc-day-past {
    .fc-timegrid-col-frame .fc-timegrid-col-events .fc-timegrid-event-harness {
      .fc-timegrid-event {background:#E50019; border:0px;     padding: 0 6px !important; box-shadow:none !important;}
    }
  }
  &.fc-day-today {background-color:#FAFBFD !important;
    .fc-timegrid-col-frame .fc-timegrid-col-events .fc-timegrid-event-harness {
      .fc-timegrid-event {background:#0e1d48; border:0px;     padding: 0 6px !important; box-shadow:none !important;}
    }
  }
}
.fc-theme-standard td, .fc-theme-standard th {border: 1px solid #E8ECEF !important;}
.fc-theme-standard th {    height: 32px; vertical-align: middle;
  .fc-scrollgrid-sync-inner .fc-col-header-cell-cushion  {font-family: "DM Sans", sans-serif; font-weight:700; color:#0e1d48; font-size:14px;}
}
.fc .fc-timegrid-axis-cushion, .fc .fc-timegrid-axis-cushion, .fc .fc-timegrid-slot-label-cushion {    text-transform: capitalize; font-family: "DM Sans", sans-serif; font-weight:700; color:#0e1d48; font-size:14px;}
.fc .fc-daygrid-day-number {font-family: "DM Sans", sans-serif; font-weight:500; color:#0e1d48; font-size:14px;}
.fc-theme-standard .fc-scrollgrid {border: 1px solid #E8ECEF !important;} 
</style>
