<template >
  

    <div class="tab-inner-content">
        <div class="tabs-content-panel tab-pad-wrap">
          <div class="card-panels">
            
            <vs-row vs-justify="center" >
    
    
            <vs-col class="p-0" type="flex" vs-justify="center" vs-align="center" vs-w="12">
                <div class="forms_letters">
                  <vs-tabs>
                    <vs-tab label="Documents"  >
                        <div class="main-list-wrap pad0">
                        <div  class="tab-inner-content">
                          <div class="doc_header pt-0 d" >
                            <h3 class="small-header mart25"  >
                              <template >
                                   Documents
                              </template>
                            </h3>
                          </div>
                                                    
                                                  
                        <template   >
                            <div >
                            <vs-row  >
                                <vs-col class="padl0 padr0" v-if="checkProperty( petition,'i140Docs' ,'length')>0">
                                  <div class="card-panels pad0">
                                    <vs-card>
                                    <div slot="header" >
                                      <h3>PERM Documents</h3> 
                                      
                                    </div>
                                    <div>
                                      <div>
                                         <template v-for="(item ,ind ) in  petition['i140Docs']" >
                                      
                                          <div class="documents__list" v-if="checkProperty( item,'status') !=false" v-bind:key="ind">
                                            <div class="documents__title" @click="downloadfile(item)">
                                              <figure> 
                                                <img v-if="checkFileFormat(item['mimetype']) =='pdf'" src="@/assets/images/main/pdf.svg" /> 
                                                <img v-else-if="checkFileFormat(item['mimetype']) =='video_mime_types'" src="@/assets/images/main/film.png" />
                                                <img v-else-if="checkFileFormat(item['mimetype']) =='msDoc'" src="@/assets/images/main/doc.svg" />
                                                <img v-else-if="checkFileFormat(item['mimetype']) =='zip'" src="@/assets/images/main/zip-file-format.png" />
                                                <img v-else-if="checkFileFormat(item['mimetype']) =='msPpt'" src="@/assets/images/main/ppt.svg" />
                                                <img v-else-if="checkFileFormat(item['mimetype']) =='msXl'" src="@/assets/images/main/xls.svg" />
                                                <img v-else-if="checkFileFormat(item['mimetype']) =='image'" src="@/assets/images/main/image.svg" />
                                                <img v-else src="@/assets/images/main/icon-img.svg" />
                                              </figure>
                                              <span>{{item.name}}</span>
                                            </div>
                                            <div class="documents__actions">
                                              <button @click="downloadfile(item)" class="view-btn">View</button>
                                            </div>
                                          </div>
                                        </template>
                                      </div>
                                    </div>
                                    </vs-card>
                                  </div>
                                </vs-col>
                               <!------Edit Section-->

                            </vs-row>
                            </div>
    
                            <!-----Details Section-->

                        </template>
                        </div>
                        </div>   
                          
    
                    </vs-tab>
                  </vs-tabs>                
    
                </div>
            </vs-col>
            </vs-row>
          </div>
        </div> 
      </div>                             
    
    
    
    
    
    
    
    
      
        </template>
    <script>
    import FileUpload from "vue-upload-component/src";
    import draggable from "vuedraggable";
    import VuePerfectScrollbar from "vue-perfect-scrollbar";
    
    import selectField from "@/views/forms/fields/simpleselect.vue";
    import immiswitchyesno from "@/views/forms/fields/switchyesno.vue";
    
    import addressField from "@/views/forms/fields/address.vue";
    
    import _ from "lodash";
    
    import immiInput from "@/views/forms/fields/simpleinput.vue";
    import Vue from 'vue';
    Vue.use( CKEditor );
    import CKEditor from '@ckeditor/ckeditor5-vue2';
    import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
    
    export default {
      provide() {
            return {
                parentValidator: this.$validator,
            };
        },
        components: {
            FileUpload,
            draggable,
            VuePerfectScrollbar,
            selectField,
            immiswitchyesno,
            addressField,
            immiInput
        },
        mounted(){
         
    
      
        },
        data() {
        return {

        }},
        props: {
          questionnaireDetails:[],
          value:null,
            petition: {
                type: Object,
                default: null,
            },
            currentRole: null,
        },
        methods:{

            downloadfile(value) {
            if(_.has(value ,"url" ) && !(_.has(value ,"path" ) )){
                value =Object.assign(value ,{ "path":value['url']})
            }else  if(_.has(value ,"path" ) && !(_.has(value ,"url" )) ){
                value =Object.assign(value ,{ "url":value['path']})
            }
            
            this.$emit('download_or_view' ,value);

            },
            selectDoctype(type = "") {
                this.uploaddocType = type;
            },
            upload(model, uploaddocType) {
          this.is_enablesavebtn = false;
          
          let temp_count = 0;
          this.uploaddocType = uploaddocType;
          let formData = new FormData();
          if (model.length > 0) {
            this.$vs.loading();
            model.forEach((doc) => {
              formData.append("files", doc.file);
              formData.append("secureType", "public");
              this.$store.dispatch("uploadS3File", formData).then((response) => {
               temp_count++;
                let docmnt = {
                  mimetype: model[0]["file"]["type"],
                  name: model[0]["file"]["name"],
                  status: true,
                  uploadedOn: new Date(),
                  url: response["data"]["result"][0],
                  path: response["data"]["result"][0],
                  tempDoc:true
                };
    
                this.petition["documents"][this.uploaddocType].push(docmnt);
                this.is_enablesavebtn = true;
                if (temp_count >= model.length) {
                     
                      this.$vs.loading.close();
                  }
              });
            });
          }
        },
        },
        computed:{

        }
    }
    </script>