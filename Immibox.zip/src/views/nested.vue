<template>
  <div>

    <div calss="">
      <draggable v-if="checkProperty(tasks, 'length') > 0" class="dragArea" tag="div" :list="tasks"
        :group="{ name: groupName }" @start="showRestore(true)">
        <template v-for="(el, index) in tasks">
          <template v-if="checkProperty(el, 'isTrashDocument') == isTrashDocument && checkItem(el) ">
            <div :key="index" class="dragArea_list">

              <!-- <p v-if="el.category" style="color: rgb(255, 0, 25);">{{ el.category }}</p> -->
              <p v-if="el.name"> {{ el.name }}</p>

              <ul class="drag_actions">
                <li>
                  <span class="doc_delete download"  v-if="checkProperty(el ,'path')">
                    <img src="@/assets/images/main/down-arrow2.svg" @click="downloadView(el)"/>
                    <em>Download</em>
                  </span>
                </li>
                <li>
                  <span class="doc_delete" v-if="isTrashDocument">
                    <img src="@/assets/images/main/delete-row-img.svg" @click="moveToTrash(el,false )" />
                    <em>Remove from the Trash</em>
                  </span>
                </li>
                <li>
                  <span class="doc_delete" v-if="!isTrashDocument">
                    <img src="@/assets/images/main/delete-row-img.svg" @click="moveToTrash(el,true )" />
                    <em>Move to Trash</em>
                  </span>
                </li>
              </ul>
              <nested-draggable class="nestedDrag" :tasks="el.tasks" />
            </div>
          </template>
        </template>
      </draggable>
    </div>
  </div>
</template>
<script>

import VuePerfectScrollbar from "vue-perfect-scrollbar";
import draggable from "vuedraggable";

import * as _ from "lodash";
export default {
  mounted() {
    setTimeout(() => {
      // this.init();
    }, 10000);

  },
  data() {
    return {
      allTasks: [],
      finalSaveItems: [],

    }
  },
  methods: {
    downloadView(value){
            this.downloads3file(value)
           // this.$emit('download_or_view' ,value);
         },
    downLoadAction() {
      this.finalSaveItems = [];

    },
    moveToTrash(selectedItem, action = false) {
      if (!_.has(selectedItem, "isTrashDocument")) {
        Object(selectedItem, { "isTrashDocument": action });
        selectedItem['isTrashDocument'] = action
      }
      selectedItem['isTrashDocument'] = action

      //isTrashDocument
      if (_.has(selectedItem, 'tasks') && selectedItem['tasks'] && this.checkProperty(selectedItem, 'tasks', 'length') > 0) {
      _.forEach(selectedItem['tasks'], (mTItem) => {
        mTItem['isTrashDocument'] = action
        if (_.has(mTItem, 'tasks') && mTItem['tasks'] && this.checkProperty(mTItem, 'tasks', 'length') > 0) {
          _.forEach(mTItem['tasks'], (sItem) => {
            sItem['isTrashDocument'] = action

            if (_.has(sItem, 'tasks') && sItem['tasks'] && this.checkProperty(sItem, 'tasks', 'length') > 0) {
              _.forEach(sItem['tasks'], (item) => {
                item['isTrashDocument'] = action
                if (_.has(item, 'tasks') && item['tasks'] && this.checkProperty(item, 'tasks', 'length') > 0) {
                  _.forEach(item['tasks'], (docItem) => {
                    docItem['isTrashDocument'] = action
                    if (_.has(docItem, 'tasks') && docItem['tasks'] && this.checkProperty(docItem, 'tasks', 'length') > 0) {
                      _.forEach(docItem['tasks'], (lItem) => {
                        lItem['isTrashDocument'] = action
                        if (_.has(lItem, 'tasks') && lItem['tasks'] && this.checkProperty(lItem, 'tasks', 'length') > 0) {
                          _.forEach(lItem['tasks'], (DItem) => {
                            DItem['isTrashDocument'] = action
                          })
                        }

                      })
                    }

                  })
                }

              })
            }


          })
        }




      })
    }
    },
    remMveFromTrash(item) {
      if (!_.has(item, "isTrashDocument")) {
        Object(item, { "isTrashDocument": false });
        item['isTrashDocument'] = false
      }
      item['isTrashDocument'] = false;
      _.forEach(item['tasks'], (taskItem) => {
        Object(taskItem, { "isTrashDocument": false });
        taskItem['isTrashDocument'] = false;
      });
      //isTrashDocument
    },
    showRestore(action = false){
      this.$store.commit('isDraggeded' ,action);
    }

  },
  props: {
    
    groupName: {
      type: String,
      default: 'g1'
    },
    isTrashDocument: {


      type: Boolean,
      default: false
    },
    petitionDetails: {
      type: Object,
      default: null,
    },
    tasks: {
      required: true,
      type: Array
    }
  },
  components: {
    VuePerfectScrollbar,
    draggable
  },
  computed:{
    checkItem(){
      return (item)=>{
        if(this.checkProperty( item ,"path")){
          return true
        }else if(this.checkProperty( item ,"tasks"  ,'length') >0){
          let activeItems = _.filter(item['tasks'] ,{"isTrashDocument":false})
          if(activeItems.length>0){
            return true
          }else{
            return false;
          }

        }else{
          return false;
        }

      }
    },
    
  },
  name: "nested-draggable"
};
</script>
<style scoped>
.dragArea {
  /* min-height: 15px;
  outline: 1px dashed; */
  margin-top: 2px;
  margin-bottom: 2px;
}

/* .nestedDrag{
    padding-left: 20px;
} */
</style>