
<template>
 <div class="main-list-wrap">
   <div class="petition_updates_wrap">
     <div class="petition_details_list pad">
       <div   v-for="tracking in this.petition.courierTrackingDetails" :key="tracking"  >
                                             <div class="petition_details" v-if="tracking.category == 'UPDATE_TRACKING_NUMBER'" >

          <h6>Tracking Details<span>
              
           <b>Tracking Number</b> - <a :href="tracking.trackingUrl">  {{tracking.trackingId}} </a>  &nbsp; &nbsp; &nbsp;  <b>Updated on</b> -  {{tracking.created | formatDate }}

             </span></h6>
             <p> </p>
          <ul>
            <li>
              <figure><img src="@/assets/images/main/file_icon.svg"></figure>
              <figcaption>Tracking Document</figcaption>
            </li>
          </ul>
   </div>

       </div>
        
     </div>
     
   </div>
   
 </div>
</template>


<script>
import FileUpload from "vue-upload-component/src";
import * as _ from "lodash";
export default {
   props: {
      petition: {
         type: Object,
         default: null
      }
   },
   components: {
      FileUpload
   },
   methods: {
      fetchSignedUrl(value) {
         value.url = value.url.replace(this.$globalgonfig._S3URL,"");
         let postdata = {
         keyName: value.url
         };
         this.$store
         .dispatch("getSignedUrl", postdata)
         .then(response => {
            window.open(response.data.result.data, '_blank');
         });
      },
      uploadUSCISReceipt(docs) {
         let formData = new FormData();   
         docs = docs.map(item => item = {
            name: item.name,
            file: item.file,
            url: "",
            mimetype: item.type
         })
         if(docs.length > 0){
            docs.forEach(doc=> {
               formData.append('files', doc.file);
               formData.append('secureType', 'private');
               this.$store.dispatch('uploadS3File', formData).then(response=> {
                  response.data.result.forEach(urlGenerated=> {
                     doc.url = urlGenerated;
                  })
                  delete doc.file;
               });
            })
            this.documents = docs;
         }
      },
      submitUSCISReceipt() {
         let postdata = {
            action: 'UPDATE_USCIS_RECEIPT_NUMBER',
            petitionId: this.petition._id,
            documents: this.documents,
            receiptName: this.receiptName,
            receiptNumber: this.receiptNumber
         }
         this.$store.dispatch("updateTrackingDetails", postdata).then(response => {
            this.$router.go(this.$route.name);
            this.filesUpload = false;
         });
      },
      checkTrackingStatus() {
         window.location.href(petition.courierTrackingDetails, '_blank')
      },
      submitTrackingInfo() {
         let postdata= {
            trackingId: this.trackingId,
            trackingUrl: this.trackingUrl,
            action: 'UPDATE_TRACKING_NUMBER',
            petitionId: this.petition._id
         }
         this.$store.dispatch("updateTrackingDetails", postdata).then(response => {
            this.$router.go(this.$route.name);
         });
      },
   },
   data: ()=> ({
      trackingId: null,
      trackingUrl:  null,
      documents: [],
      receiptNumber: null,
      receiptName: null,
      filesUpload: null,
      types: [],
      typeSelected: '',
      trackingData: [],
      receiptDetailsDisplay: [],
      receiptDocuments: [],
      
   }),
   mounted() {
      this.trackingData = [];
      this.receiptDetailsDisplay = [];
      this.receiptDocuments = [];
      this.petition.courierTrackingDetails.forEach(item=>{
         if(item.trackingId) {
            this.trackingData.push({
               trackingId: item.trackingId,
               trackingUrl: item.trackingUrl
            });
         }
         if(item.receiptNumber && item.receiptNumber && item.documents.length > 0) {
            this.receiptDetailsDisplay.push({
               receiptNumber: item.receiptNumber,
               receiptName: item.receiptName,
               documents: item.documents
            })
         }
      })
      
      // this.receiptNumber = (this.petition.courierTrackingDetails[1].receiptNumber) ? this.petition.courierTrackingDetails[1].receiptNumber : null;
      // this.documents = (this.petition.courierTrackingDetails[1].documents) ? this.petition.courierTrackingDetails[1].documents : null;
   }
}
</script>


<style scoped>
.petition_details{
    position: relative;
}
.petition_updates_wrap .petition_details_list .petition_details ul{
    position: absolute;
    right:0px;
    top:10px;
}
.petition_updates_wrap .petition_details_list .petition_details h6{
    border: 0px !important;
}
</style>