<template>
  <div>
    <div class="content-header">
      <div class="content-header-left">
        <div class="search">
          <vs-input icon-pack="feather" icon="icon-search" v-model="searchtxt" placeholder="Search"
            class="is-label-placeholder" />
        </div>
      </div>
      <div class="content-header-right">
         <!--
        <vs-dropdown  vs-custom-content vs-trigger-click>
          <vs-button
            color="primary"
            class="filter-btn"
            type="border"
            icon-pack="feather"
            icon="icon-chevron-down"
            icon-after
          >
            <img src="@/assets/images/main/icon-filter.svg" /> Filters
          </vs-button>
          <vs-dropdown-menu ref="filter_menu" class="filters-content">

            <div class="filters-form-fileds">
              <div class="form-container">
                <div class="vx-row">

                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Select Type</label>
                    
                    <multiselect v-model="selected_typeids" :options="all_formTypes" :multiple="true" :hideSelected="true"
                      :close-on-select="false" :clear-on-select="false" :select-label="''" :preserve-search="true"
                      placeholder="Select types" label="name" track-by="name" :preselect-first="false">
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">{{ values.length }}
                          options selected</span>
                      </template>
                    </multiselect>
                  </div>
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Select Status</label>
                    
                    <multiselect v-model="selected_statusids" :options="all_statusids" :multiple="true" :hideSelected="true"
                      :close-on-select="false" :clear-on-select="false" :select-label="''" :preserve-search="true"
                      placeholder="Select Status" label="name" track-by="name" :preselect-first="false">
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">{{ values.length }}
                          options selected</span>
                      </template>
                    </multiselect>
                  </div>

                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Created Date</label>
                    <date-range-picker
                      :autoApply="autoApply"
                      :ranges="false"
                      v-model="selected_createdDateRange"
                    ></date-range-picker>
                  </div>
                 </div>
                   
                   
     
              </div>
            </div>
            <div class="filters-status">
              <div class="left-buttons">

              </div>
              <div class="right-buttons">
                <vs-button color="success" class="save" type="filled" v-on:click="set_filter()">Apply</vs-button>
                <vs-button color="dark" class="cancel" type="filled" v-on:click="clear_filter($event)">Clear
                </vs-button>
              </div>
            </div>
          </vs-dropdown-menu>
        </vs-dropdown>
        -->
        
        <vs-button type="border" class="light-blue-btn" @click="createNew(true)">Add New <span>
          <img class="add-user-icon ml-2" src="@/assets/images/main/add-user.svg">
        </span>
        </vs-button>
        
        
      </div>
    </div>
    <div class="accordian-table">
      <vs-table :data="list" :no-data-text="'No data found..!'">
        <template slot="thead">
          <vs-th>
          <a @click="sortMe('name')"  v-bind:class="{'sort_ascending':sortKeys['name']==1, 'sort_descending':sortKeys['name']!=1}" >
             Name
              </a>
          </vs-th>
          <vs-th>Config status</vs-th>
          <vs-th class="actions">Actions</vs-th>

        </template>

        <template slot-scope="{data}">
          <vs-tr  :data="tr" :key="indextr" v-for="(tr, indextr) in data">
            <vs-td :data="tr.username">
            <!--
              <img class="user-image" src="@/assets/images/main/avatar2.svg" />
              -->
              
              {{tr.name }}
            </vs-td>

            <vs-td >
              <span class="statusspan " :class="{'status_pending':(!checkProperty(tr ,'workflowConfigDetails' ) ||  tr['workflowConfigDetails'].length<=0 ),'status_active':(checkProperty(tr ,'workflowConfigDetails' ) && tr['workflowConfigDetails'].length>0  )}" >
              {{checkProperty(tr ,"workflowConfigDetails" ) && tr['workflowConfigDetails'].length>0 ?'Completed':'Pending' }}
              </span>
            </vs-td>
           
            <vs-td >
              
             
              <vs-dropdown class="msg_dropdown_icon" :vs-trigger-click="true">
                  <a class="a-icon" href.prevent><more-vertical-icon size="1.5x" class="custom-class"></more-vertical-icon></a>
                 <vs-dropdown-menu class="loginx msg_dropdown">
                    <vs-dropdown-item>
                      <router-link style="cursor:pionter;padding:3px 10px" :to="'/petition-subtype-list/'+tr.id">Case Subtypes</router-link>
                    </vs-dropdown-item>

                    <vs-dropdown-item>
                        <span style="cursor:pionter;padding:3px 10px"  @click="editMe(tr)" >Edit</span>
                    </vs-dropdown-item>
                     <vs-dropdown-item v-if="checkProperty(tr ,'workflowConfigDetails' ) && tr['workflowConfigDetails'].length<=0">
                      <a style="cursor:pionter;padding:3px 10px"  href.prevent v-if="[1 ,2,3 ].indexOf(getUserRoleId)>-1" @click="openPetitionConfiguration(tr)"  >Config Workflow
                        
                      </a>
                    </vs-dropdown-item>
                    <vs-dropdown-item v-if="checkProperty(tr ,'workflowConfigDetails' ) && tr['workflowConfigDetails'].length>0">
                      <a style="cursor:pionter;padding:3px 10px"  href.prevent v-if="[1 ,2,3 ].indexOf(getUserRoleId)>-1" @click="editWorkflowConfig(tr)"  >Edit Workflow
                        
                      </a>
                    </vs-dropdown-item> 
                    
                    
                   </vs-dropdown-menu>
                  
                </vs-dropdown>
              
            </vs-td>


          </vs-tr>
        </template>
      </vs-table>
      <paginate  v-if="list.length>0"  v-model="page" :page-count="totalpages" :page-range="3" :margin-pages="2" :click-handler="pageNate"
        prev-class="vs-pagination--buttons btn-prev-pagination vs-pagination--button-prev"
        next-class="vs-pagination--buttons btn-next-pagination vs-pagination--button-next" :prev-text="'<i></i>'"
        :next-text="'<i></i>'" :container-class="'pagination vs-pagination--nav'" :page-class="'page-item'"></paginate>
    </div>


    
    
     <modal 
     
    name="create-modal"
    classes="demo-modal-class"
    :min-width="200"
    :min-height="200"
    :scrollable="true"
    :reset="true"
    width="60%"
    height="auto"
    
  >
    <div class="size-modal-content">
    <h2>{{edit?'Edit Case Type ':'New Case Type'}}</h2>
    <form>
        <div class="form-container">
          <div class="vx-row">
            <div class="vx-col w-full">
              <vs-input v-model="newform.name" placeholder="Name" name="name" v-validate="'required'" class="w-full"
                label="Name"   data-vv-as="name"    />
              <span class="text-danger text-sm"
                v-show="errors.has('name')">{{ errors.first("name") }}</span>
            </div>
             
                
            
          </div>


          <div class="text-danger text-sm formerrors" v-show="formerrors.msg" @click="formerrors.msg=''">
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
              icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
          </div>
        </div>
        <div class="popup-footer">
          <vs-button color="dark" @click="edit=false;createNew(false)" class="cancel" type="filled">Cancel</vs-button>
          <vs-button color="success"  :disabled="validateForm" class="save" v-if="edit" @click="updateformandLetter()" type="filled">Update</vs-button>
          <vs-button color="success" :disabled="validateForm" class="save" v-else @click="createformandLetter()" type="filled">Save</vs-button>
        </div>
      </form>
   

    </div>
     </modal>

    

   
    <vs-popup class="holamundo main-popup" :title="editworkFlowConfigaration?'Update Case Configuration ':'Case Configuration'" v-if="configPopup"   :active.sync="configPopup" >
      <div class="form-container">
        
        <div class="vx-row">
          <div class="vx-col w-full">
         
         
           <multiselect name="Case Configuration"   v-model="selectedWorkFlow" 
                :multiple="false"
                :show-labels="false"
                :ref="'Petition Workflow  '"
                track-by="_id" 
                label="name"
                data-vv-as="Workflow"
                placeholder="Select Workflow"
                :options="tempworkFlowList"
                :searchable="true"
                :allow-empty="false">
            </multiselect>
           
          </div>
          
        </div>
       
      </div>
      <div class="popup-footer">
        <vs-button color="dark" class="cancel" type="filled" @click="configPopup=false;">Cancel</vs-button>
        <vs-button color="success" class="save" :disabled="selectedWorkFlow ==null" type="filled" @click="workFlowconfigAction()">
          {{editworkFlowConfigaration?'Update':'Save'}}
        </vs-button>
      </div>
    </vs-popup>

    <vs-popup class="holamundo main-popup" :title="'Petitiontype Workflow Configuration Details'" v-if="detailsPopup"   :active.sync="detailsPopup" >
      <div class="form-container">
        
        <div class="vx-row">
          <div class="vx-col w-full" v-for=" ( item ,index) in petitionWorkFlowConfigDetails" :key="index">
          {{item.name}}
           
           
          </div>
          
        </div>
       
      </div>
      <div class="popup-footer">
        <vs-button color="dark" class="cancel" type="filled" @click="detailsPopup=false;">Cancel</vs-button>
        <!--
            <vs-button color="success" class="save" :disabled="selectedWorkFlow ==null" type="filled" @click="workFlowconfigAction()">Save</vs-button>
        -->
      </div>
    </vs-popup>

  </div>
</template>

<script>
import DateRangePicker from "vue2-daterange-picker";
  import Datepicker from "vuejs-datepicker-inv";
  import Paginate from "vuejs-paginate";
  
import "vue2-daterange-picker/dist/vue2-daterange-picker.css";

  import _ from "lodash";
  import { FormWizard, TabContent } from "vue-form-wizard";
  import "vue-form-wizard/dist/vue-form-wizard.min.css";
   import moment from 'moment'
  import PhoneMaskInput from "vue-phone-mask-input";
  import JQuery from 'jquery'
  import { TheMask } from 'vue-the-mask'
  
import FileUpload from "vue-upload-component/src";
import VuePhoneNumberInput from 'vue-phone-number-input';
import 'vue-phone-number-input/dist/vue-phone-number-input.css';
import { MoreVerticalIcon } from 'vue-feather-icons';
  export default {
    computed:{
      validateForm(){
        if(
          (this.newform.name && this.newform.name.trim() !='' ) 
         
        
        ){

          return false;
        }else{
          return true;
        }

      },
      
    },
    components: {
      DateRangePicker,
      VuePhoneNumberInput,
      Datepicker,
      Paginate,
      FileUpload,
      FormWizard,
      TabContent,
      PhoneMaskInput,
      TheMask,
      MoreVerticalIcon
    },

    data: () => ({ 
      detailsPopup:false,
      selectedWorkFlow:null,
      configPopup:false,
      workFlowList:[], 
      tempworkFlowList:[],
      petitionWorkFlowConfigDetails:[], 
      
    selected_createdDateRange: ["", ""],
    autoApply: "",
        value:[],
        all_formTypes:[{"name":"Form" ,"id":"Form"},{"name":"Letter" ,"id":"Letter"} ],
        
      selectedItem:null,
      selectedStatus:2,
      actionText:"Do you want to Delete?",
      formerrors: {
        msg: ""
      },
      date: null,
      approveConformpopUp: false,
     
     newform: {name:'' ,type:'' ,"document":null , attachments:[],"today":moment().format("YYYY-MM-DD")},
      list: [],
      addPopup: false,
      NewPetition: false,
      
     
      searchtxt: "",
      query: [],
      country_code: 231,
      all_statusids: [],
      selected_statusids: [],
      final_selected_statusids: [],
      filter_roleIds: [],
      final_filter_roleIds: [1,2,3,4,5,8,9,10,11,12],

      
      seleted_states: [],
      final_selected_states: [],
      locations: [],
      // locationIds
      final_selected_typesids:[],
      selected_typeids:[],
      
      
      date: "",
      date_range: [],
      page: 1,
      perpage: 25,
      totalpages: 0,
      

     
      switch2:true,
      users_status:{},
      edit:false,
      sortKeys:{},
      sortKey:{},
      details:null,
      editworkFlowConfigaration:false,
    }),
    watch: {
      searchtxt: function (value) {
        this.getList();
      }

    },
    methods: {

      processPetitionTypes(showDetailpopUp=false){
       this.detailsPopup =showDetailpopUp;
        //petitionWorkFlowConfigDetails
       // selectedWorkFlow:null,
       // configPopup:false,
       // workFlowList:[], 
       // tempworkFlowList:[],
       let postData = {
          "filters":{
            
            "statusList": [true ],
            "createdByList": [],
            "createdDateRange": [],
            "petitionTypeList": [this.selectedItem['id']],
          },
		
      "page": 1, // Optional when 'getAll' send as 'true'
      "perpage": 250000, // Optional when 'getAll' send as 'true'
      "getAll": true // Send as 'true' to get all list
	     }
       this.$store.dispatch("getList" ,{ data:postData, path:"/workflow/config-list"})
       .then((res)=>{
             
             this.petitionWorkFlowConfigDetails =res.list;
             //this.tempworkFlowList = this.workFlowList;
             if(this.petitionWorkFlowConfigDetails.length>0 && this.workFlowList.length>0) {
              

                this.tempworkFlowList =[];
                _.forEach(this.workFlowList ,(item)=>{
                  let findindex =  _.findIndex(this.petitionWorkFlowConfigDetails  ,{ "workflowId":item['_id']});
                  // alert(findindex + " === "+item.name)
                    if(findindex<=-1){
                        this.tempworkFlowList.push(item);
                    }

                })



             }else{
               this.tempworkFlowList = this.workFlowList;
             }
             
            })
           .catch((err)=>{});

      },
      openPetitionConfiguration(item){
       this.selectedItem = item;
       this.tempworkFlowList = this.workFlowList;
       this.selectedWorkFlow =null;
       this.workFlowConfigDetails =[];
       this.configPopup =true;
       this.processPetitionTypes();
       this.editworkFlowConfigaration =false;
      },
      editWorkflowConfig(item){
        this.selectedItem = item;
        this.tempworkFlowList = this.workFlowList;
        this.selectedWorkFlow =null ;
        this.workFlowConfigDetails =[];
        
        this.processPetitionTypes();
        if(this.checkProperty(this.selectedItem ,'workflowConfigDetails') && this.selectedItem['workflowConfigDetails'].length>0 ){
          let workflowConfigDetails = this.selectedItem['workflowConfigDetails'][0];
          if(this.checkProperty(workflowConfigDetails ,'workflowId') &&  this.checkProperty(workflowConfigDetails ,'workflowName' )){
            this.selectedWorkFlow = { "_id": workflowConfigDetails['workflowId'], "name": workflowConfigDetails['workflowName'], "showMe": true };
          }
        }
         this.editworkFlowConfigaration =true;
        this.configPopup =true;

      },

      workFlowconfigAction(){
         if(this.selectedWorkFlow !=null){
           let postData  = {"workflowId":this.selectedWorkFlow['_id'] , "petitionTypeId": this.selectedItem['id']  };
           let actionPath ="/workflow/config-save";
           if(this.editworkFlowConfigaration){
             actionPath ="/workflow/config-update";
             
             if(this.checkProperty(this.selectedItem ,'workflowConfigDetails') && this.selectedItem['workflowConfigDetails'].length>0 ){
              let workflowConfigDetails = this.selectedItem['workflowConfigDetails'][0];
              if(this.checkProperty(workflowConfigDetails ,'_id') ){
                postData = Object.assign(postData,{"workflowConfigId":workflowConfigDetails['_id']})
              }
        }
           }
           this.$store.dispatch("commonAction" ,{ data:postData, path:actionPath})
           .then((res)=>{
             this.configPopup =false;
             this.editworkFlowConfigaration =false;
             this.showToster({message:res.message ,isError:false});
             this.selectedWorkFlow =null;
             this.workFlowConfigDetails =[];
             this.getList();
             
            })
           .catch((err)=>{
            
              this.showToster({message:err ,isError:true});
               //alert(err)
           });

         }
      },

      getworkFlowList(){
         let postData = {
            matcher:{
                "searchString":'',
              // "petitionType":

            },   
            page:1,
            perpage: 100000000,
            category: "petition_types",
            getMasterData:true,
            getAll:true,
          
        };
          this.$store.dispatch("commonAction" ,{ data:postData, path:"/workflow/list"})
          .then(response => {
            let tempList =[];
            let lst = response.list;
            _.forEach(lst ,(item)=>{
              
              item = Object.assign(item ,{"showMe":true});
              tempList.push(item);
            });
            this.workFlowList = tempList;
           
          });
      },

      formandLetterDetails(){
        let query = {"formAndLetterId":this.selectedItem['_id']};
        this.$store
          .dispatch("formandLetterDetails", query)
          .then(response => {
             //alert(JSON.stringify(response));
             //this.details
          });

      },
      changedDocType(){
         this.newform.attachments =[];
         this.newform.document = null;
         if(this.edit  ){
            this.newform.attachments =[this.selectedItem.document];
            this.newform.document = this.selectedItem.document;
         }

      },
       sortMe(sort_key=''){

      
      if(sort_key !=''){
          this.sortKeys[sort_key] = this.sortKeys[sort_key]==1?-1:1
          // this.sortKey[sort_key] = this.sortKeys[sort_key]
          this.sortKey = {"path":sort_key ,"order":this.sortKeys[sort_key]};

          localStorage.setItem('petitiin_sort_key', sort_key);
          localStorage.setItem('formandLetter_sort_value', this.sortKey[sort_key]);
          this.getList();
      }
          
      

      },
      editMe(item){
        this.edit =true;
        this.selectedItem = item;
        this.newform = {name:this.selectedItem.name }
         this.addPopup=true;

        this.$modal.show('create-modal');
       
      },
     
     createNew(action =true){
       this.addPopup=action;
       if(action){
         this.$modal.show('create-modal');
       }else{
          this.$modal.hide('create-modal');
       }
       this.edit =false;
       this.newform = {name:''}
      
     },
      
      deleteConform(item ){
        this.selectedItem = item;
        this.approveConformpopUp =true;
        this.edit= false;

      },
  
      getList() {
       

        let matcher = {
          title: this.searchtxt,
          statusIds: this.final_selected_statusids,
          typeIds:this.final_selected_typesids,
          createdDateRange:[]
          
        };
        if (
        this.selected_createdDateRange["startDate"] &&
        this.selected_createdDateRange["startDate"] != "" &&
        this.selected_createdDateRange["endDate"] != "" &&
        this.selected_createdDateRange["endDate"]
      ) {
        matcher["createdDateRange"] = [
          this.selected_createdDateRange["startDate"],
          this.selected_createdDateRange["endDate"]
        ];
      }

       
         let item ={
          matcher:{
              "searchString":this.searchtxt,
              getWorkFlowConfig:true
             // "petitionType":

          },   
          page:this.page,
          perpage: this.perpage,
          category: "petition_types",
          
        };

        this.$store
          .dispatch("getMasterData",item )
          .then(response => {
            this.list = response.list;
            this.totalpages = Math.ceil(response.totalCount / this.perpage);
            //alert(this.perpage);
          });
      },
      updateformandLetter(){
        this.$validator.validateAll().then(result => {
          if (result) {
            let postData ={"name":this.newform.name ,category: "petition_types"}
         
         postData = Object.assign(postData ,{"mDataId":this.selectedItem['id']})
        this.$store.dispatch("updateMasetrRole", postData)
          .then(response => {
            this.showToster({message:response.message,isError:false});
            this.getList();
            this.addPopup =false;
            this.edit =false;


          }).catch((error)=>{
                  Object.assign(this.formerrors, {
                    msg:error
                  });
            //this.showToster({message:"Somthin went wrong..!",isError:true});
          
        });
         }
        });

      },
      createformandLetter() {

        
        this.$validator.validateAll().then(result => {
          if (result) {
            let postData ={"name":this.newform.name , category: "petition_types"}
            this.$store
              .dispatch("createMasterNewRole", postData)
              .then(response => {
                 this.showToster({message:response.message,isError:false });
                 this.getList();
                 this.addPopup =false;
                
              })
              .catch((error)=>{
                Object.assign(this.formerrors, {
                    msg:error
                  });
              })
          }
        });
      },
      upload(files ,type="") {
        let model = _.cloneDeep(files);
        this.value = [];
        let fileType = "Form";
        if(_.has(this.newform['type'] ,"name")){
        
        if(this.newform['type']['name'] =="Form" ){
             fileType = "Form";
        }else if(this.newform['type']['name'] =="Letter" ){
           fileType = "Letter";
        }

      }
      this.newform['document'] =null;
       this.newform['attachments'] = [];

            var _current = this;
            this.$vs.loading();
            let formData = new FormData();
           
            let tempFiles =[]
            if (model.length > 0) {
                
                model.forEach((doc, index) => {
                   
                    if((fileType == "Form" && doc.type=='application/pdf' ) || (fileType == "Letter" && doc.type=='application/msword' ) ){

                    
                    formData.append("files", doc.file);
                    formData.append("secureType", "private");
                    formData.append("getDetails", true);
                                        
                    this.$store.dispatch("uploadLocal", formData).then((response) => {
                        response.data.result.forEach((urlGenerated) => {
                            doc.url = urlGenerated;
                            delete doc.file;
                             let temp_file = urlGenerated;
                             
                           
                          tempFiles.push(temp_file);
                          let fl = { "name":temp_file['name'] ,"url":temp_file['path'] , "mimetype":temp_file['mimetype']} ;
                          this.newform.document =  urlGenerated ;
                          this.newform.attachments.push(fl);
                        
                         
                         if (tempFiles.length >= model.length) {
                              _current.$vs.loading.close();
                          }   
                       
                       });
                    
                    });

                  }else{
                     _current.$vs.loading.close();
                  }
               });
                
               
            }     
              //  model.splice(0, mapper.length, ...mapper);
            
    },
     remove(item, data ,filindex) {
            data.splice(filindex, 1);
            this.newform.document =null;
    
    },  
      
      get_statusids() {
        
        const item ={
          page:1,
          perpage: 10000,
          category: "form_letter_status",
          
        };

        this.$store.dispatch("getMasterData", item).then(response => {
          this.all_statusids = response.list;
         // alert(JSON.stringify(response.list))
        });
      },
      
      set_filter: function () {
        this.$refs["filter_menu"].dropdownVisible = false;
        this.final_selected_statusids = [];
        if (this.selected_statusids.length > 0) {
          this.final_selected_statusids = [];
          for (let ind = 0; ind < this.selected_statusids.length; ind++) {
            let current_index = this.selected_statusids[ind];
            this.final_selected_statusids.push(current_index["id"]);
          }
        }

        this.final_selected_typesids = [];
        if (this.selected_typeids.length > 0) {
          this.final_selected_typesids = [];
          for (let ind = 0; ind < this.selected_typeids.length; ind++) {
            let current_index = this.selected_typeids[ind];
            this.final_selected_typesids.push(current_index["id"]);
          }
        }

        
// alert(this.final_selected_typesids)
       

       

        this.getList();
      },
      clear_filter: function () {
         this.searchtxt ='';
        this.$refs["filter_menu"].dropdownVisible = false;
        this.selected_statusids = [];
        this.final_selected_statusids = [];
        this.final_selected_typesids = [];
        this.selected_typeids = [];
      
        this.date = "";
        this.date_range = [];
         this.selected_createdDateRange["startDate"] = "";
         this.selected_createdDateRange["endDate"] = "";
        this.getList();
      },
      pageNate(pageNum) {
        this.page = pageNum;
        this.getList();
      },
      
      deleteformandLetter( ){
        let post_data = {"formAndLetterId":this.selectedItem['_id'] }
        this.$store.dispatch("deleteformandLetter", post_data)
          .then(response => {
           this.approveConformpopUp = false;
            this.showToster({message:response.message,isError:false});
            this.getList();
            this.edit =false;


          }).catch((er)=>{
            this.showToster({message:er,isError:true});
          
        });
      },

    },
    mounted() {
      this.getworkFlowList();
      this.selected_statusids = [];
      this.final_selected_statusids = [];
      this.seleted_states = [];
      this.final_selected_states = [];
 this.sortKeys = {
      'name':1,
      'type':1,
      "createdOn":-1,
      "updatedOn":1
     
    },

    this.sortKey = {"path":"createdOn" ,"order":-1};

    if(localStorage.getItem('petitiin_sort_key') && localStorage.getItem('petitiin_sort_value')  && localStorage.getItem('petitiin_sort_value') >=-1 ){
       this.sortKey = {};

      this.sortKey[localStorage.getItem('petitiin_sort_key')] = parseInt(localStorage.getItem('petitiin_sort_value'));
      this.sortKeys[localStorage.getItem('petitiin_sort_key')] = this.sortKey[localStorage.getItem('petitiin_sort_key')];

      //alert();
    }
    if(localStorage.getItem('formandLetter_perpage')){
        this.perpage = parseInt(localStorage.getItem('formandLetter_perpage'));
    }
     
      this.get_statusids();
      this.getList();
     

    }
  };
</script>
