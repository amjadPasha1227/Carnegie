<template>
  <div>
    <div class="content-header">
      <div class="content-header-left">
        <div class="search">
          <vs-input
            icon-pack="feather"
            icon="icon-search"
            placeholder="Search"
            class="is-label-placeholder"
            v-model.lazy="searchtxt"
          />
        </div>
      </div>
      <div class="content-header-right">
        <!--filter dropdown-->
         <vs-dropdown vs-custom-content vs-trigger-click>
          <vs-button
            color="primary"
            class="actions-btn"
            type="border"
            icon-pack="feather"
            icon="icon-chevron-down"
            icon-after
          >Actions
          </vs-button>
          <vs-dropdown-menu ref="filter_menu" class="actions-content">
            <ul>
              <!-- <li><a href="#" @click="ChangePetition=true">Change Attorney</a></li>  
              <li><a href="#"  @click="ChangePetition=true">Change Paralegal</a></li>
              <li><a href="#" @click="ChangePetition=true">Change Supervisor</a></li> -->

              <li><a href="#" @click="change_action('Change Attorney' ,'REPLACE_ATTORNEY')">Change Attorney</a></li>  
              <li><a href="#"  @click="change_action('Change Paralegal' ,'REPLACE_PARALEGAL')">Change Paralegal</a></li>
              <li><a href="#" @click="change_action('Change Supervisor' ,'REPLACE_SUPERVISOR')">Change Supervisor</a></li>

              
            </ul>
          </vs-dropdown-menu>
        </vs-dropdown>
        <vs-dropdown vs-custom-content vs-trigger-click>
          <vs-button
            color="primary"
            class="filter-btn"
            type="border"
            icon-pack="feather"
            icon="icon-chevron-down"
            icon-after
          >
            <img src="@/assets/images/main/icon-filter.svg" /> Filters
          </vs-button>
          <vs-dropdown-menu ref="filter_menu" class="filters-content">
            <div class="filters-form-fileds">
              <div class="form-container">
                <div class="vx-row">
                  <div class="vx-col md:w-1/3 w-full con-select filters-search">
                    <label class="typo__label">Search</label>
                    <vs-input
                      icon-pack="feather"
                      icon
                      placeholder="Search"
                      class="is-label-placeholder"
                      v-model="filter_searchtxt"
                    />
                  </div>

                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Status</label>
                    <multiselect
                      v-model="selected_statusids"
                      :options="all_statusids"
                      :multiple="true" :hideSelected="true"
                      :close-on-select="false"
                      :clear-on-select="false"
                      :preserve-search="true"
                      placeholder="Select Status"
                      label="name"
                      track-by="name"
                      :preselect-first="false"
                    >
                      <!-- <template slot="selection" slot-scope="{ values, search, isOpen }">
                        <span
                          class="multiselect__single"
                          v-if="values.length &amp;&amp; !isOpen"
                        >{{ values.length }} options selected</span>
                      </template> -->
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} options selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template>
                    </multiselect>
                  </div>
                  <!---all_subtypes---->
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Case Type</label>
                    <multiselect
                      @input="changedsubtypes()"
                      v-model="selected_subtypes"
                      :options="all_subtypes"
                      :multiple="true" :hideSelected="true"
                      :close-on-select="false"
                      :clear-on-select="false"
                      :preserve-search="true"
                      placeholder="Select Case Type"
                      label="name"
                      track-by="name"
                      :preselect-first="false"
                    >
                      <!-- <template slot="selection" slot-scope="{ values, search, isOpen }">
                        <span
                          class="multiselect__single"
                          v-if="values.length &amp;&amp; !isOpen"
                        >{{ values.length }} options selected</span>
                      </template> -->
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} options selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template> 
                    </multiselect>
                  </div>
                  <!---users--->
                  <div v-if="roleId != 6 && roleId != 7" class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Users</label>
                    <multiselect
                      @input="changedusers()"
                      v-model="selected_users"
                      :options="users"
                      :multiple="true" :hideSelected="true"
                      :close-on-select="false"
                      :clear-on-select="false"
                      :preserve-search="true"
                      placeholder="Select Users"
                      label="name"
                      track-by="name"
                      :preselect-first="false"
                      @search-change="user_search"
                    >
                      <!-- <template slot="selection" slot-scope="{ values, search, isOpen }">
                        <span
                          class="multiselect__single"
                          v-if="values.length &amp;&amp; !isOpen"
                        >{{ values.length }} options selected</span>
                      </template> -->
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} options selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template> 
                    </multiselect>
                  </div>

                  <!-------------Select Petitioners this.all_peritioners ----------->
                  <!-- <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Select Petitioners</label>
                    <multiselect @input="changedperitioners()"  v-model="selected_peritioners" :options="all_peritioners"   :multiple="true" :hideSelected="true"
                                 :close-on-select="false" :clear-on-select="false" :preserve-search="true"
                                 placeholder="Select Seritioners" label="name" track-by="name" :preselect-first="false"
                                 @search-change="peritioners_search_fun"
                    >
                      <template slot="selection" slot-scope="{ values, search, isOpen }"><span
                        class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">{{ values.length }}
                          options selected</span></template>
                    </multiselect>

                  </div>-->
                  <!-------Select Beneficiars-------->
                  <!-- <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Select Beneficiars</label>
                    <multiselect ref="country_selectbox" @input="changedCountry()"  v-model="selected_country_obj" :options="countries"  :multiple="false" :close-on-select="true" :clear-on-select="false" :preserve-search="true" placeholder="Select Country" label="name" track-by="name" :preselect-first="false">
                      <template slot="selection" slot-scope="{ values, search, isOpen }"><span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">{{ values.length }} options selected</span></template>
                    </multiselect>

                  </div>-->
                  <!-------genders--------->
                  <!--<div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Select Gender</label>
                    <multiselect ref="country_selectbox" @input="changedCountry()"  v-model="selected_country_obj" :options="countries"  :multiple="false" :close-on-select="true" :clear-on-select="false" :preserve-search="true" placeholder="Select Country" label="name" track-by="name" :preselect-first="false">
                      <template slot="selection" slot-scope="{ values, search, isOpen }"><span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">{{ values.length }} options selected</span></template>
                    </multiselect>

                  </div>-->
                  <!------------maritalStatusIds---------->
                  <!-- <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Select MaritalStatus</label>
                    <multiselect ref="country_selectbox" @input="changedCountry()"  v-model="selected_country_obj" :options="countries"  :multiple="false" :close-on-select="true" :clear-on-select="false" :preserve-search="true" placeholder="Select Country" label="name" track-by="name" :preselect-first="false">
                      <template slot="selection" slot-scope="{ values, search, isOpen }"><span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">{{ values.length }} options selected</span></template>
                    </multiselect>

                  </div>-->

                  <!----------Select Country------->
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Country</label>
                    <multiselect
                      ref="country_selectbox"
                      @input="changedCountry()"
                      v-model="selected_country_obj"
                      :options="countries"
                      :multiple="false"
                      :close-on-select="true"
                      :clear-on-select="false"
                      :preserve-search="true"
                      placeholder="Select Country"
                      label="name"
                      track-by="name"
                      :preselect-first="false"
                    >
                      <!-- <template slot="selection" slot-scope="{ values, search, isOpen }">
                        <span
                          class="multiselect__single"
                          v-if="values.length &amp;&amp; !isOpen"
                        >{{ values.length }} options selected</span>
                      </template> -->
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} options selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template> 
                    </multiselect>
                  </div>

                  <!--------Select States----->
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">States</label>
                    <multiselect
                      v-bind:disabled="country_code <= 0"
                      @input="changedState()"
                      v-model="seleted_states"
                      :options="all_states"
                      :multiple="false"
                      :close-on-select="true"
                      :clear-on-select="false"
                      :preserve-search="true"
                      placeholder="Select States"
                      label="name"
                      track-by="name"
                      :preselect-first="false"
                    >
                      <!-- <template slot="selection" slot-scope="{ values, search, isOpen }">
                        <span
                          class="multiselect__single"
                          v-if="values.length &amp;&amp; !isOpen"
                        >{{ values.length }} options selected</span>
                      </template> -->
                    <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} options selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template> 
                      </multiselect>
                  </div>
                  <!---- seleted_locations --->
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Locations</label>
                    <multiselect
                      v-bind:disabled="final_selected_states.length <= 0"
                      v-model="seleted_locations"
                      :options="all_locations"
                      :multiple="true" :hideSelected="true"
                      :close-on-select="false"
                      :clear-on-select="false"
                      :preserve-search="true"
                      placeholder="Select Locations"
                      label="name"
                      track-by="name"
                      :preselect-first="false"
                    >
                      <!-- <template slot="selection" slot-scope="{ values, search, isOpen }">
                        <span
                          class="multiselect__single"
                          v-if="values.length &amp;&amp; !isOpen"
                        >{{ values.length }} options selected</span>
                      </template> -->
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} options selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template> 
                    </multiselect>
                  </div>
                  <!--Created Date--->
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Created Date</label>
                    <date-range-picker
                      :autoApply="autoApply"
                      :ranges="false"
                      v-model="selected_createdDateRange"
                    ></date-range-picker>
                  </div>
                </div>
              </div>
            </div>
            <div class="filters-status">
              <div class="left-buttons"></div>
              <div class="right-buttons">
                <vs-button
                  color="success"
                  class="save"
                  type="filled"
                  v-on:click="set_filter()"
                >Apply</vs-button>
                <vs-button
                  color="dark"
                  class="cancel"
                  type="filled"
                  v-on:click="clear_filter($event)"
                >Clear</vs-button>
              </div>
            </div>
          </vs-dropdown-menu>
        </vs-dropdown>
        <!-- end -->
      </div>
    </div>
    <vs-popup class="Change_petition_wrap" v-bind:title="actionPopupText" :active.sync="ChangePetition">
      <div class="Change_petition">

        <div class="vx-col w-full marb10">
                <div class="con-select w-full select-large">
                  <label for class="vs-select--label">{{selectBoxText}}<em>*</em></label>
                  <multiselect
                    v-bind:name="selectBoxText"
                    v-validate="'required'"
                    v-model="assignedTouserId"
                    :show-labels="false"
                    label="name"
                    v-bind:data-vv-as="selectBoxText"
                    v-bind:placeholder="selectBoxText"
                    :options="selectedROle_allusers"
                    :searchable="true"
                    :allow-empty="false"
                  ></multiselect>
                </div>

                <span
                  class="text-danger text-sm"
                  v-show="assignedTouserIdError"
                > Select {{selectBoxText}}</span>
              </div>
         
        <div class="note">
          <!-- <vs-textarea v-model="actionComent"   label="Comments…" class="w-full" /> -->
          <ckeditor v-model="actionComent"   label="Comments…" class="w-full"  :editor="editor" :config="editorConfig"></ckeditor>

          <span class="text-danger text-sm"  v-show="commentError!=''">{{ commentError }}</span>
        </div>
      </div> 
      <div class="actions_footer">
        <button @click="ChangePetition=false" class="btn cancel">Cancel</button>
        <button class="btn" @click="submitAction()">  Submit</button>
      </div>
    </vs-popup>
    <div class="accordian-table custom-table">
      <div>
        <!-- <vs-table :data="petitioners" @selected="petitionlink"> -->
        <vs-table :data="petitioners" >  
         

<template slot="thead">
            <vs-th >
              <vs-checkbox v-model="selectAll" @click="selct_all()" class="padl6"></vs-checkbox>
              <a @click="sortMe('caseNo')" v-bind:class="{'sort_ascending':sortKeys['caseNo']==1, 'sort_descending':sortKeys['caseNo']!=1}">Case No</a></vs-th>
            <vs-th ><a  @click="sortMe('beneficiaryDetails.name')"  v-bind:class="{'sort_ascending':sortKeys['beneficiaryDetails.name']==1, 'sort_descending':sortKeys['beneficiaryDetails.name']!=1}" >Beneficiary</a> </vs-th>
            <vs-th> <a @click="sortMe('typeDetails.name')" v-bind:class="{'sort_ascending':sortKeys['typeDetails.name']==1, 'sort_descending':sortKeys['typeDetails.name']!=1}"  >Case Type</a></vs-th>
            <vs-th ><a @click="sortMe('petitionerDetails.name')"  v-bind:class="{'sort_ascending':sortKeys['petitionerDetails.name']==1, 'sort_descending':sortKeys['petitionerDetails.name']!=1}"  >Client</a></vs-th>
            <vs-th> <a @click="sortMe('updatedOn')"  v-bind:class="{'sort_ascending':sortKeys['updatedOn']==1, 'sort_descending':sortKeys['updatedOn']!=1}" > Last Updated</a></vs-th>
            <vs-th ><a @click="sortMe('communicationDetailslength')"  v-bind:class="{'sort_ascending':sortKeys['communicationDetailslength']==1, 'sort_descending':sortKeys['communicationDetailslength']!=1}" > Messages</a></vs-th> 
            <vs-th > Status</vs-th> 
             </template>

          <template slot-scope="{ data }">
            <vs-tr
              :data="petition"
              :key="petition.index"
              v-for="petition in data"
              class="vs-table--tr"
            >
          
              <vs-td>
                <vs-checkbox v-model="petition.is_checked" @click="selectMe(petition._id ,petition.is_checked ,petition)" ></vs-checkbox>
                <img class="user-image" src="@/assets/images/main/avatar2.svg" />
                {{ petition.caseNo }}
              </vs-td>

              <vs-td>
                {{ petition.beneficiaryDetails.name }}
                <router-link
                  :to="{
                    name: 'petition-details',
                    params: { itemId: petition._id }
                  }"
                >
                </router-link>
                </vs-td>

              <vs-td>
                {{ petition.typeDetails.name }} /
                {{ petition.subTypeDetails.name }}
                <router-link
                  :to="{
                    name: 'petition-details',
                    params: { itemId: petition._id }
                  }"
                >
                </router-link>
              </vs-td>
              <vs-td>
                {{ petition.petitionerDetails.name }}
                <router-link
                  :to="{
                    name: 'petition-details',
                    params: { itemId: petition._id }
                  }"
                >
                </router-link>
                </vs-td>
              <vs-td>
                {{ petition.updatedOn | formatDateTime }}
                <router-link
                  :to="{
                    name: 'petition-details',
                    params: { itemId: petition._id }
                  }"
                >
                </router-link>
                </vs-td>
              <vs-td class="buttoncol">
               

            

                <router-link
                  v-if="
                    currentuserRole == 7 &&
                      !petition.questionnaireFilled &&
                      petition.questionnaireSent
                  "
                  :to="{
                    name:
                      petition.currentActivity == 'QUESTIONNIRE_REJECTED'
                        ? 'questionnaire'
                        : 'fillquestionnaire',
                    params: { itemId: petition._id }
                  }"
                >
                  <button class="btn btn-brown">
                    <span
                      v-if="petition.currentActivity == 'QUESTIONNIRE_REJECTED'"
                    >Update Questionnaire</span>
                    <span v-else>Fill Questionnaire</span>
                  </button>
                </router-link>

                <button
                  class="btn btn-brown"
                  v-if="currentuserRole == 6 && !petition.questionnaireSent"
                  @click="
                    SendQuestionnaire = true;
                    setuser(petition);
                  "
                >Send Questionnaire</button>

                   <vs-dropdown
                  v-if="
                    petition.questionnaireFilled &&
                      currentuserRole == 6 &&
                      petition.statusId == 1
                  "
                  vs-custom-content
                  vs-trigger-click
                  class="msg_dropdown_icon"
                >
                  <a class="a-icon" href.prevent>
                    <img src="@/assets/images/main/message_icon.svg" />
                  </a>

                  <vs-dropdown-menu class="loginx msg_dropdown">
                    <p>Please Review Questionnaire</p>
                  </vs-dropdown-menu>
                </vs-dropdown>

                <vs-dropdown
                  v-if="
                    petition.questionnaireInstructions &&
                      currentuserRole == 7 &&
                      !petition.questionnaireFilled
                  "
                  vs-custom-content
                  vs-trigger-click
                  class="msg_dropdown_icon"
                >
                  <a class="a-icon" href.prevent>
                    <img src="@/assets/images/main/message_icon.svg" />
                  </a>

                  <vs-dropdown-menu class="loginx msg_dropdown">
                    <span
                      v-if="petition.currentActivity == 'QUESTIONNIRE_REJECTED'"
                    >{{ petition.statusChangeComment }}</span>
                    <span v-else>{{ petition.questionnaireInstructions }}</span>
                  </vs-dropdown-menu>
                </vs-dropdown>


                
              
              </vs-td>
              <vs-td>
                <span class="statusspan status_active"
                  v-if="
                    currentuserRole == 7 &&
                      petition.questionnaireFilled &&
                      petition.questionnaireSent
                  "
                  v-bind:class="{
                    status_active: petition.statusDetails.id == 1,
                    status_approved: petition.statusDetails.id == 2,
                    status_rejected: petition.statusDetails.id == 3
                  }"
                >{{ petition.statusDetails.name }}</span>

                <span class="statusspan status_active"
                  v-if="currentuserRole != 7 && petition.questionnaireSent"
                  v-bind:class="{
                    status_active: petition.statusDetails.id == 1,
                    status_approved: petition.statusDetails.id == 2,
                    status_rejected: petition.statusDetails.id == 3
                  }"
                >{{ petition.statusDetails.name }}</span>


              </vs-td>
            </vs-tr>
          </template>
        </vs-table>

        <div class="table_footer">
                    

<div class="vx-col  con-select" v-if="petitioners.length > 0">
                    <label class="typo__label">Per Page</label>
                    <multiselect
                      @input="changeperPage()"
                      v-model="perpage"
                      :options="perPeges"
                      :multiple="false"
                      :close-on-select="true"
                      :clear-on-select="false"
                      :preserve-search="true"
                      placeholder="Per Page"
                     
                      :preselect-first="true"
                    >
                      
                    </multiselect>
                  </div>
        <paginate
          v-if="petitioners.length > 0"
          v-model="page"
          :page-count="totalpages"
          :page-range="3"
          :margin-pages="2"
          :click-handler="pageNate"
          prev-class="vs-pagination--buttons btn-prev-pagination vs-pagination--button-prev"
          next-class="vs-pagination--buttons btn-next-pagination vs-pagination--button-next"
          :prev-text="'<i></i>'"
          :next-text="'<i></i>'"
          :container-class="'pagination vs-pagination--nav'"
          :page-class="'page-item'"
        ></paginate>

      </div>

        <vs-popup
        v-if="SendQuestionnaire"
          class="holamundo main-popup"
          title="Questionnaire"
          :active.sync="SendQuestionnaire"
        >
          <div class="media-header">
            <img src="@/assets/images/main/avatar2.svg" />
            <div class="media-content">
              <h3>{{ selecteduser.userName }}</h3>
              <p>{{ selecteduser.email }}</p>
            </div>
          </div>
          <div class="form-container">
            <div class="vx-row">
              <div class="vx-col w-full">
                <vs-input
                  class="w-full"
                  v-model="selecteduser.typeName"
                  disabled="true"
                  icon-pack="IntakePortal"
                  icon-after
                  icon="IP-disabled"
                  label="Case Type"
                />
              </div>
              <div class="vx-col w-full">
                <!-- <vs-textarea
                  class="w-full"
                  v-model="selecteduser.instructions"
                  label="Instructions"
                /> -->
                <ckeditor  class="w-full"
                  v-model="selecteduser.instructions"
                  label="Instructions" :editor="editor" :config="editorConfig"></ckeditor>
              </div>
            </div>
          </div>
          <div class="popup-footer">
            <vs-button
              color="dark"
              @click="SendQuestionnaire = false"
              class="cancel"
              type="filled"
            >Cancel</vs-button>
            <vs-button
              color="success"
              @click="SendQuestionnaireUser"
              class="save"
              type="filled"
            >Send</vs-button>
          </div>
        </vs-popup>
        <vs-popup
          class="holamundo success-popups"
          title="Your registration is complete."
          :active.sync="SuccessQuestionnaire"
        >
          <figure>
            <img src="@/assets/images/main/icon-note.svg" alt="login" class="mx-auto" />
          </figure>
          <h2 class="title">Questionnaire has been sent to {{ selecteduser.userName }}</h2>
          <p>
            You will be notified once the beneficiary completes the
            questionnaire.
          </p>
        </vs-popup>
      </div>
    </div>
  </div>
</template>

<script>
import DateRangePicker from "vue2-daterange-picker";
import Paginate from "vuejs-paginate";
import Datepicker from "vuejs-datepicker-inv";
import Multiselect from "vue-multiselect-inv";
import JQuery from "jquery";
import Vue from 'vue';
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import "vue2-daterange-picker/dist/vue2-daterange-picker.css";
export default {
  components: {
    Datepicker,
    DateRangePicker,
    Multiselect,
    Paginate
  },
  data: () => ({
    editor: ClassicEditor,
 editorConfig: {
     toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
 },
    buttoncol: true,
    ChangePetition: false,
    formerrors: {
      msg: ""
    },
    searchtxt: "",
    query: [],
    selected: [],
    petitioners: [],
    currentuserRole: null,
    selecteduser: {
      petitionId: null,
      userName: null,
      email: null,
      typeName: null,
      subTypeName: null,
      instructions: null
    },
    SendQuestionnaire: false,
    SuccessQuestionnaire: false,
    selected_createdDateRange: ["", ""],
    autoApply: "",
    countries: [],
    country_code: 0,
    selected_country_obj: "",
    selected_statusids: [],
    final_selected_statusids: [],
    all_states: [],
    seleted_states: [],
    final_selected_states: [],
    singel_final_selected_state: "",
    all_locations: [],
    seleted_locations: [],
    final_selected_locations: [],
    all_statusids: [],
    selected_statusids: [],
    final_selected_statusids: [],
    page: 1,
    perpage: 25,
    totalpages: 0,

    filter_searchtxt: "",
    all_subtypes: [],
    selected_subtypes: [],
    final_selected_subtypes: [],

    final_filter_roleIds: [3, 4, 5, 9, 10],
    rolebased_filter: {
      3: { name: "supervisorIds", values: [] },
      4: { name: "paralegalIds", values: [] },
      5: { name: "attorneyIds", values: [] },
      9: { name: "offshoreUserIds", values: [] },
      10: { name: "evidenceSupervisorIds", values: [] }
    },
    users: [],
    selected_users: [],
    final_selected_users: [],
    user_search_value: "",
    roleId: 0,

    all_peritioners: [],
    peritioners_search_value: "",
    selected_peritioners: [],
    final_selected_peritioners: [],
    actionPopupText:"",
    actionComent:'',
    selectAll:false,
    seletedItems:[],
    searchQuery:'',
    actionChangeType:'',
    assignedTouserId:'',
    selectedUserTypeId:'',
    selectedROle_allusers:[],
    selectBoxText:'',
    commentError:'',
    assignedTouserIdError:false,

     sortKeys:{},
    sortKey:{},
    perPeges:[  10,25,50,75,100],
    

  }),
  watch: {
    searchtxt: function(value) {
      this.getpetitions();
      
    },
    
  },
  methods: {


    
    increaseIndex(val){
     // alert(val);
    },

    selectMe(id ,is_checked =false ,petition){
      petition['is_checked'] =is_checked;

     //alert(petition['is_checked']);

      //if value present in selectedItems then Remove selecteItem from selectd list else
      if(_.includes(this.seletedItems, id)){
       
        _.remove(this.seletedItems, (item)=>{
          if(id==item){
            return true;
          }else{
            return false;
          }

        });

       

      }else{
        this.seletedItems.push(id);
      
      }


    },

    selct_all(){
      
      this.selectAll != this.selectAll;

      if(this.selectAll ==false){
        //petitioners
                _.forEach(this.petitioners , (val ,index)=>{
                  this.seletedItems.push(val._id);
                  this.petitioners[index]['is_checked'] =true;

                }); 


              }else{

                _.forEach(this.petitioners , (val ,index)=>{
                          
                  this.petitioners[index]['is_checked'] =false;

                }); 
                this.seletedItems = [];

              }     

            },
            
      change_action(type='' ,action="REPLACE_ATTORNEY"){
        this.commentError ="";
        this.assignedTouserIdError =false;
        this.actionChangeType ='';
        this.actionComent =''
      

          if(type !='' && action !='' && this.seletedItems.length >0 ){
            
            
            if(action=="REPLACE_ATTORNEY"){
              this.selectedUserTypeId = 5
              this.selectBoxText ="Attorney";

            }

            if(action=="REPLACE_PARALEGAL"){
              this.selectBoxText ="Paralegal";
            this.selectedUserTypeId =4
           }

           if(action=="REPLACE_SUPERVISOR"){
             this.selectBoxText ="Supervisor";
             this.selectedUserTypeId = 3
          }


            let matcher = {
          roleIds: [this.selectedUserTypeId],
          searchString: ''
          };
          let query = {};
          query["page"] = 1;
          query["perpage"] = 1000000;
          query["matcher"] = matcher;

          this.$store.dispatch("getusers", query).then(response => {
          this.selectedROle_allusers = response.list;
          });

            this.actionPopupText = type;
            this.ChangePetition = true;
            this.actionChangeType = action;

          }else{
            let msg = "Somting Went Wrong";
            if(this.seletedItems.length <=0){
              msg = "Please Select atleast One Petition";
            }

            this.$vs.notify({
                    title: "Error",
                    
                position: "top-right",
                color: "danger",
                    text: msg
                  });

          }

      },

            submitAction(){

              this.commentError ='';
              this.assignedTouserIdError =false;
                  let Payload= {
                  "action":this.actionChangeType ,//"REPLACE_ATTORNEY", // REPLACE_PARALEGAL, REPLACE_SUPERVISOR
                  "petitionIds":this.seletedItems,
                  "replaceId":this.assignedTouserId['_id'],//"5de4a68f3f265070080ad945", // Replace user ID
                  "replaceRoleId":this.selectedUserTypeId,
                  "petitionCategory":"standard", // "rfe" for RFE petition
                  "comment":this.actionComent
                  }

                  if(this.actionChangeType !='' && this.seletedItems.length >0 && this.actionComent !='' ){

                  this.$store
                  .dispatch("petitioner/entity_bulk_replace", Payload)
                  .then(response => {
                      if (response.error) {
                         Object.assign(this.formerrors, {
                         msg: response.error.message
                      });
                      } else {
                        this.$vs.notify({
                        title: "Success",
                        
                position: "top-right",
                color: "primary",
                        text: response.message
                        });

                      this.ChangePetition = false;
                      this.actionChangeType ="";
                      this.seletedItems =[];
                      this.actionComent ='';
                    

                      }

                  // this.petitioners = response.list;
                  });


                  }else{

            
            if(this.actionComent ==''){
              this.commentError ="Enter Coment";
            }

            if(!this.assignedTouserId){
               this.assignedTouserIdError =true;
            }


                  this.$vs.notify({
                  title: "Error",
                  
                position: "top-right",
                color: "danger",
                  text: "Somthing went wrong"
                  });


                  }

        
    
    },

    petitionlink(tr) {
      let routedId = tr._id;
      const $ = JQuery;

      if (
        $(event.target)
          .parents()
          .hasClass("buttoncol") ||
        $(event.target).hasClass("buttoncol")
      ) {
      } else {
        this.$router.push({ path: `/petition-details/${tr._id}` }).catch(err => {})
      }
    },
    pageNate(pageNum) {
      this.page = pageNum;
      this.getpetitions();
    },
    SendQuestionnaireUser() {
      this.$store
        .dispatch("petitioner/sendquestionnaire", this.selecteduser)
        .then(response => {
          if (response.error) {
            Object.assign(this.formerrors, {
              msg: response.error.message
            });
          } else {
            this.$vs.notify({
              title: "Success",
              
                position: "top-right",
                color: "primary",
              text: response.message
            });
            this.SendQuestionnaire = false;
            this.SuccessQuestionnaire = true;
            var timer = this.$router;
            setTimeout(function() {
              timer.go("/cases");
            }, 1000);
          }

          // this.petitioners = response.list;
        });
    },
    setuser(petition) {
      this.selecteduser.petitionId = petition._id;
      this.selecteduser.userName = petition.beneficiaryDetails.name;
      this.selecteduser.email = petition.beneficiaryDetails.email;
      this.selecteduser.typeName =
        petition.typeDetails.name + "/" + petition.subTypeDetails.name;
      this.selecteduser.subTypeName = petition.subTypeDetails.name;
    },
    selectCreatedDateRange(option) {
      option.startDate = moment(option.startDate).format("YYYY-MM-DD");
      option.endDate = moment(option.endDate).format("YYYY-MM-DD");
      this.selected_createdDateRange = [option.startDate, option.endDate];
    },
    set_filter: function() {
      this.final_selected_statusids = [];

      if (this.selected_statusids.length > 0) {
        this.final_selected_statusids = [];
        for (let ind = 0; ind < this.selected_statusids.length; ind++) {
          let current_index = this.selected_statusids[ind];
          this.final_selected_statusids.push(current_index["id"]);
        }
      }

      /*//states
        this.final_selected_states= [];
        if( this.seleted_states.length >0 ){
          this.final_selected_states = [];
          for(let ind =0;ind < this.seleted_states.length ; ind++ ){
            let current_index =  this.seleted_states[ind];
            this.final_selected_states.push(current_index["id"]);
          }
        }*/

      //alert(this.singel_final_selected_state);

      this.final_selected_locations = [];
      if (this.seleted_locations.length > 0) {
        for (let ind = 0; ind < this.seleted_locations.length; ind++) {
          let current_index = this.seleted_locations[ind];
          this.final_selected_locations.push(current_index["id"]);
        }
      }

      this.searchtxt = this.filter_searchtxt;

      this.getpetitions();
      this.$refs["filter_menu"].dropdownVisible = false;
    },
    clear_filter: function() {
      this.searchtxt = "";
      this.selected_statusids = [];

      this.selected_country_obj = "";
      this.seleted_states = [];
      this.final_selected_states = [];
      this.singel_final_selected_state = "";

      this.seleted_locations = [];
      this.final_selected_locations = [];
      this.final_selected_statusids = [];

      this.date = "";
      this.date_range = [];
      this.selected_createdDateRange["startDate"] = "";
      this.selected_createdDateRange["endDate"] = "";

      this.filter_searchtxt = "";
      this.selected_subtypes = [];
      this.final_selected_subtypes = [];

      (this.rolebased_filter = {
        3: { name: "supervisorIds", values: [] },
        4: { name: "paralegalIds", values: [] },
        5: { name: "attorneyIds", values: [] },
        9: { name: "offshoreUserIds", values: [] },
        10: { name: "evidenceSupervisorIds", values: [] }
      }),
        (this.final_selected_peritioners = []);
      this.selected_peritioners = [];
      //this.getPetitioners();
      this.$refs["filter_menu"].dropdownVisible = false;
      this.getpetitions();
    },
    get_all_states() {
      this.$store.dispatch("getstates", this.country_code).then(response => {
        this.all_states = response;
      });
    },
    getAllLocations() {
      Object.assign(this.query, {
        countryId: this.country_code,
        stateId: this.singel_final_selected_state //this.final_selected_states//3922
      });

      this.$store.dispatch("getlocations", this.query).then(response => {
        this.all_locations = response;
      });
    },
    get_statusids() {
      Object.assign(this.query, {
        category: "company_statuses"
      });

      this.$store
        .dispatch("get_petition_statusids", this.query)
        .then(response => {
          this.all_statusids = response;
        });
    },
    getpetitions() {
      let obj = {
        matcher: {
          searchString: this.searchtxt,
          statusIds: this.final_selected_statusids,
          //"countryIds": [this.country_code],
          stateIds: [], //this.final_selected_statusids,
          locationIds: this.final_selected_locations
          //"createdDateRange":this.selected_createdDateRange
        },
        page: this.page,
        perpage: this.perpage,
        sortKeys:this.sortKey
      };

      //
      if (this.singel_final_selected_state > 0) {
        obj["matcher"]["stateIds"] = [this.singel_final_selected_state];
      }

      if (
        this.selected_createdDateRange["startDate"] &&
        this.selected_createdDateRange["startDate"] != "" &&
        this.selected_createdDateRange["endDate"] != "" &&
        this.selected_createdDateRange["endDate"]
      ) {
        obj["matcher"]["createdDateRange"] = [
          this.selected_createdDateRange["startDate"],
          this.selected_createdDateRange["endDate"]
        ];
      }

      obj["matcher"]["countryIds"] = [];
      if (
        this.selected_country_obj["id"] &&
        this.selected_country_obj["id"] > 0
      ) {
        obj["matcher"]["countryIds"] = [this.selected_country_obj["id"]];
      }

      //final_selected_subtypes
      obj["matcher"]["subTypeIds"] = this.final_selected_subtypes;

      //rolebased_filter

      Object.keys(this.rolebased_filter).forEach(key => {
        let filtered_item = this.rolebased_filter[key]; // value of the current key
        obj["matcher"][filtered_item["name"]] = filtered_item["values"];
      });

      this.$store.dispatch("petitioner/getpetitions", obj).then(response => {
        this.petitioners = response.list;
        this.totalpages = Math.ceil(response.totalCount / this.perpage);
        // alert(this.totalpages);
      });
    },

    changedCountry() {
      this.country_code = this.selected_country_obj["id"];
      this.get_all_states();
    },

    changedState() {
      this.singel_final_selected_state = "";
      this.final_selected_locations = [];
      this.singel_final_selected_state = this.seleted_states["id"];
      this.final_selected_states.push(this.seleted_states["id"]);
      this.getAllLocations();
    },
    multiple_changedState() {
      // alert();
      if (this.seleted_states.length > 0) {
        this.final_selected_states = [];
        for (let ind = 0; ind < this.seleted_states.length; ind++) {
          let current_index = this.seleted_states[ind];
          this.final_selected_states.push(current_index["id"]);
        }
        this.getAllLocations();
      } else {
        this.final_selected_states = [];
        this.final_selected_locations = [];
      }
    },

    getvisa_subtypes() {
      this.$store.dispatch("getvisasubtypes").then(response => {
        this.all_subtypes = response;
      });
    },
    changedsubtypes() {
      this.final_selected_subtypes = [];
      if (this.selected_subtypes.length > 0) {
        for (let ind = 0; ind < this.selected_subtypes.length; ind++) {
          let current_index = this.selected_subtypes[ind];
          this.final_selected_subtypes.push(current_index["id"]);
        }
      }
    },
    getusers() {
      let matcher = {
        roleIds: this.final_filter_roleIds,
        searchString: this.user_search_value,
        page: 1
      };
      let query = {};
      query["page"] = 1;
      query["perpage"] = 100;
      query["matcher"] = matcher;

      this.$store.dispatch("getusers", query).then(response => {
        this.users = response.list;
      });
    },
    get_peritioners() {
      let matcher = {
        roleIds: [6],
        searchString: this.peritioners_search_value
      };
      let query = {};
      query["page"] = 1;
      query["perpage"] = 100;
      query["matcher"] = matcher;

      this.$store.dispatch("getusers", query).then(response => {
        this.all_peritioners = response.list;
      });
    },
    changedusers() {
      //rolebased_filter
      this.rolebased_filter = {
        3: { name: "supervisorIds", values: [] },
        4: { name: "paralegalIds", values: [] },
        5: { name: "attorneyIds", values: [] },
        9: { name: "offshoreUserIds", values: [] },
        10: { name: "evidenceSupervisorIds", values: [] }
      };
      if (this.selected_users.length > 0) {
        for (let i = 0; i < this.selected_users.length; i++) {
          let selected_user_item = this.selected_users[i];
          let roleId = selected_user_item["roleId"][0];
          this.rolebased_filter[roleId]["values"].push(
            selected_user_item["_id"]
          );
        }
      }
    },
    user_search(searchValue) {
      this.user_search_value = searchValue;
      this.getusers();
    },

    //
    changedperitioners() {
      this.final_selected_peritioners = [];
      if (this.selected_peritioners.length > 0) {
        for (let i = 0; i < this.selected_peritioners.length; i++) {
          this.final_selected_peritioners.push(
            this.selected_peritioners[i]["_id"]
          );
        }
      }
      this.get_peritioners_beneficiaries();
    },
    peritioners_search_fun(searchValue) {
      this.peritioners_search_value = searchValue;
      this.get_peritioners();
    },
    get_peritioners_beneficiaries() {},

     sortMe(sort_key=''){

      //   this.sortKeys = {
      //   'caseNo':1,
      //   'beneficiaryDetails.name':1,
      //   "typeDetails.name":1,
      //   "petitionerDetails.name":1,
      //   "updatedOn":1,
      //   "communicationDetailslength":1

      // }

      if(sort_key !=''){
          this.sortKeys[sort_key] = this.sortKeys[sort_key]==1?-1:1
          this.sortKey ={};
          this.sortKey[sort_key] = this.sortKeys[sort_key]

          localStorage.setItem('petitions_sort_key', sort_key);
          localStorage.setItem('petitions_sort_value', this.sortKey[sort_key]);

          this.getpetitions();
      }
          
      

    },
    changeperPage(){
      localStorage.setItem('petitions_perpage', this.perpage);
      this.page = 1;
      this.getpetitions();
     
      
    }
  },

  mounted() {
    this.username = this.$store.state.user.name;
    this.roleId = this.$store.state.user["roleId"][0];

    this.sortKeys = {
      'caseNo':1,
      'beneficiaryDetails.name':1,
      "typeDetails.name":1,
      "petitionerDetails.name":1,
      "updatedOn":1,
      "communicationDetailslength":1

    },

    this.sortKey['updatedOn'] =1;
    if(localStorage.getItem('petitions_sort_key') && localStorage.getItem('petitions_sort_value')  && localStorage.getItem('petitions_sort_value') >=-1 ){
       this.sortKey = {};

      this.sortKey[localStorage.getItem('petitions_sort_key')] = parseInt(localStorage.getItem('petitions_sort_value'));
      this.sortKeys[localStorage.getItem('petitions_sort_key')] = this.sortKey[localStorage.getItem('petitions_sort_key')];

      //alert();

    }

    
if(localStorage.getItem('petitions_perpage')){
        this.perpage = parseInt(localStorage.getItem('petitions_perpage'));
    }

    this.getvisa_subtypes();
    this.getusers();
    this.get_peritioners();
    this.currentuserRole = this.$store.state.user.loginRoleId;
    this.getpetitions();
    this.$store.dispatch("getcountries").then(response => {
      this.countries = response;
    });

    this.selected_statusids = [];
    this.final_selected_statusids = [];
    this.seleted_states = [];
    this.final_selected_states = [];

    this.seleted_locations = [];
    this.final_selected_locations = [];
    this.get_statusids();
  }
};
</script>
