<template>
    <!-- <NoDataFound ref="NoDataFoundRef"  :content="'No Results Found'" heading="No Results Found"  /> -->
      <div class="nodataTemplate">
   <div class="wrapTpl"  > 
      <img src="@/assets/images/main/nodata_global.svg"   />
      <h3 >No Data Found</h3>
      <p></p>      
  </div>
  </div>
</template>

<script>
import NoDataFound from "@/views/common/noData.vue";

export default {
    components: {
  
    NoDataFound
    }
}
</script>