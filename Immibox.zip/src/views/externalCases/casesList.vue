<template>
  <div>
    <div class="content-header case-search-header">
        <div class="content-header-left">
            <div class="search">
                <vs-input icon-pack="feather" icon="icon-search"
                    placeholder="Search by Case No/Beneficiary"
                    class="is-label-placeholder" v-model.lazy="searchtxt" />
            </div>
        </div>
        <div class="content-header-right">
           <!--Sorting dropdown-->
           <div class="sorting_sec">
            <div class="sort_icon">
              <img src="@/assets/images/icons/sort.png" />
              <span v-if="addCls" class="loader"><img src="@/assets/images/main/loader.gif"></span>
            </div>
            <div class="soring_cnt" :class="{'hide': addCls}">
              <ul>
                <li @click="changeSorting(item)" :class="{'active': checkProperty(sortKey,'path' ) ==checkProperty(item,'path' ) , 'sort_ascending': checkProperty(sortKey,'path' ) ==checkProperty(item,'path' ) && item['order']==1 , 'sort_descending': checkProperty(sortKey,'path' ) ==checkProperty(item,'path' ) && item['order'] !=1 }" v-for="( item ,index) in sortingList">
                  <em></em>{{ item['displayName'] }}
                </li>
              </ul>
            </div>
          </div>
            <vs-dropdown vs-custom-content vs-trigger-click>
                <vs-button color="primary" class="filter-btn" type="border" icon-pack="feather" icon="icon-chevron-down"
                  icon-after>
                  <img src="@/assets/images/main/icon-filter.svg" /> Filters
                </vs-button>
                <vs-dropdown-menu ref="filter_menu" class="filters-content">
                  <div class="filters-form-fileds">
                    <div class="form-container">
                      <div class="vx-row">
                        <div class="vx-col md:w-1/3 w-full con-select filters-search">
                          <label class="typo__label">Title</label>
                          <vs-input icon-pack="feather" icon placeholder="Search by Case No/Beneficiary"
                            class="is-label-placeholder" v-model="filter_searchtxt" />
                        </div>
                        <div class="vx-col md:w-1/3 w-full con-select">
                          <label class="typo__label">Case Type</label>
                     
                          <multiselect @input="changedVisaType" v-model="selectedVisaType" :options="visaTypes"
                            :multiple="false" :close-on-select="true" :clear-on-select="false" :preserve-search="true"
                            placeholder="Select Case Type" label="name" track-by="name" :preselect-first="false">
                            <template slot="selection" slot-scope="{ values, isOpen }">
                              <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }} Case
                                Type(s) Selected</span>
                              <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                            </template>
                          </multiselect>
                        </div>
                        <div class="vx-col md:w-1/3 w-full con-select">
                          <label class="typo__label">Case Subtype</label>
                          <multiselect @input="changedsubtypes()" v-model="selected_subtypes"
                          :disabled="selectedVisaType==null"
                            :options="all_subtypes" :multiple="true" :hideSelected="true" :close-on-select="false"
                            :clear-on-select="false" :preserve-search="true" placeholder="Select Case Subtype" label="name"
                            track-by="name" :preselect-first="false">
                            <template slot="selection" slot-scope="{ values, isOpen }">
                              <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }} Case
                                Subtype(s) Selected</span>
                              <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                            </template>
                          </multiselect>
                        </div>
                        <div class="vx-col md:w-1/3 w-full con-select">
                          <label class="typo__label">Status</label>
                          <multiselect  v-model="selected_statusids"
                            :options="case_statusids" :multiple="true" :hideSelected="true" :close-on-select="false"
                            :clear-on-select="false" :preserve-search="true" placeholder="Select Status" label="name"
                            track-by="id" :preselect-first="false">
                            <template slot="selection" slot-scope="{ values, isOpen }">
                              <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                                Status Selected</span>
                              <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                            </template>
                          </multiselect>
                        </div> 
                        <div class="vx-col md:w-1/3 w-full con-select"
                          v-if="[3,4,5,6,7,8,9,10,11,12,13,14].indexOf(getUserRoleId)>-1 && beneficiaryId ==null && getTenantTypeId !=2">
                          <label class="typo__label">Petitioner</label>
                          <multiselect @input="changedperitioners()" v-model="selected_peritioners" :options="all_peritioners"
                            :multiple="true" :hideSelected="true" :close-on-select="false" :clear-on-select="false"
                            :preserve-search="true" placeholder="Select Petitioner" label="name" track-by="name"
                            :preselect-first="false" @search-change="peritioners_search_fun">
                            <template slot="selection" slot-scope="{ values, isOpen }">
                              <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                                Petitioner(s) Selected</span>
                              <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                            </template>
                          </multiselect>
                        </div>
                        <div class="vx-col md:w-1/3 w-full con-select">
                          <label class="typo__label">Law Office</label>
                          <multiselect  v-model="selectedLawOffice" :options="lawOfficeList"
                            :multiple="true" :hideSelected="true" :close-on-select="false" :clear-on-select="false"
                            :preserve-search="true" placeholder="Select Law Office" label="name" track-by="id"
                            :preselect-first="false" >
                            <template slot="selection" slot-scope="{ values, isOpen }">
                              <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                                Law Office(s) Selected</span>
                              <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                            </template>
                          </multiselect>
                        </div>
                        <div class="vx-col md:w-1/3 w-full con-select">
                          <label class="typo__label">Created Date</label>
                          <date-range-picker  :maxDate="new Date()" :autoApply="autoApply"
                            :ranges="false" :opens="'left'" v-model="selected_createdDateRange"></date-range-picker>
                        </div>   
                      </div>
                    </div>
                  </div>
                  <div class="filters-status">
                    <div class="left-buttons"></div>
                    <div class="right-buttons">
                      <vs-button color="success" class="save" type="filled" v-on:click="set_filter()">Apply</vs-button>
                      <vs-button color="dark" class="cancel" type="filled" v-on:click="clear_filter($event)">Clear</vs-button>
                    </div>
                  </div>
                </vs-dropdown-menu>
            </vs-dropdown>
            <vs-button color="primary" type="border" class="light-blue-btn"
                  @click="selectedBeneficiary =null ; selectedPetitioner=null;addNewCase(true);uploading=false;"
                  v-if="!isRfe && checkCaseCreatePermisions">

                  New Case <span>
              <img class="add-user-icon ml-2" src="@/assets/images/main/add-user.svg">
              </span>
            </vs-button>
        </div>
    </div> 
    <div class="accordian-table custom-table no-wrap relative">
        <NoDataFound ref="NoDataFoundRef" :loading="isListLoading" v-if="petitioners.length == 0" content=""
              :heading="callFromSerch?'No Results Found':'No Cases Found'" type='petitions' />
          <div v-if="petitioners.length >  0">
                  
                  <vs-table :data="petitioners">
                  <!--
                  //"path": clientName "createdOn", updatedOn, createdByName, typeName, subTypeName, caseNo, statusName
                  --->
                  <template v-if="petitioners.length > 0" slot="thead">
                      <vs-th class="mw-280">

                      <a @click="sortMe('caseNo')"
                          v-bind:class="{'sort_ascending':sortKeys['caseNo']==1, 'sort_descending':sortKeys['caseNo']!=1}">Case
                          No </a>            
                      </vs-th> 
                      
                      <vs-th> <a @click="sortMe('typeName')"
                          v-bind:class="{'sort_ascending':sortKeys['typeName']==1, 'sort_descending':sortKeys['typeName']!=1}">Case
                          Type</a></vs-th>
                          <vs-th v-if="[51].indexOf(getUserRoleId)<=-1">


                          <a @click="sortMe('beneficiaryName')"
                              v-bind:class="{'sort_ascending':sortKeys['beneficiaryName']==1, 'sort_descending':sortKeys['beneficiaryName']!=1}">Beneficiary</a>

                          </vs-th>
                        
                      <vs-th v-if="[50].indexOf(getUserRoleId) <= -1 && beneficiaryId ==null && getTenantTypeId !=2"><a
                          @click="sortMe('petitionerName')"
                          v-bind:class="{'sort_ascending':sortKeys['petitionerName']==1, 'sort_descending':sortKeys['petitionerName']!=1}">Petitioner</a>
                      </vs-th>
                      <vs-th> <a @click="sortMe('lawOfficeName')"
                          v-bind:class="{'sort_ascending':sortKeys['lawOfficeName']==1, 'sort_descending':sortKeys['lawOfficeName']!=1}">Law Office
                          </a></vs-th>
                      <!-- <vs-th>


                      <a @click="sortMe('clientName')"
                          v-bind:class="{'sort_ascending':sortKeys['clientName']==1, 'sort_descending':sortKeys['clientName']!=1}">Client</a>
                      </vs-th> -->

                      <vs-th> <a @click="sortMe('updatedOn')"
                          v-bind:class="{'sort_ascending':sortKeys['updatedOn']==1, 'sort_descending':sortKeys['updatedOn']!=1}">
                          Last Updated</a></vs-th>

                      <vs-th>
                      <a @click="sortMe('statusName')"
                          v-bind:class="{'sort_ascending':sortKeys['statusName']==1, 'sort_descending':sortKeys['statusName']!=1}">
                          Status
                      </a>
                      </vs-th>
                  </template>

                  <template slot-scope="{ data }">
                      <vs-tr :data="petition" :key="petition.index" v-for="petition in data" class="vs-table--tr">
                      <vs-td>
                          <template>
                              <template v-if="checkProperty(petition,'subTypeDetails','id')">
                              <router-link :to="{
                                  name: 'external-case-details',
                                  params: { itemId: petition._id },
                                  query: {'filter':encodedString}
                              }">{{ petition.caseNo }}</router-link>
                              </template>
                          </template>
                         
                      </vs-td>
                      

                      <vs-td class="td_label">
                          <div class="cursor-pointer" @click="petitionlink(petition)">
                          {{ checkProperty(petition ,'typeDetails','name') }} <br />
                          <small> {{ checkProperty(petition ,'subTypeDetails','name') }} </small>
                          </div>
                      </vs-td>
                      <vs-td v-if="[51].indexOf(getUserRoleId)<=-1">
                          <span class="cursor-pointer" v-if="[51].indexOf(getUserRoleId)<=-1" @click="petitionlink(petition)">{{
                          checkProperty(petition ,'beneficiaryInfo' ,'name' ) }} </span>
                      </vs-td>
                      
                      <vs-td v-if="[50].indexOf(getUserRoleId) <= -1 && beneficiaryId ==null &&  getTenantTypeId !=2"
                          >
                          <span class="cursor-pointer" @click="petitionlink(petition)">{{
                          checkProperty(petition,'companyDetails','name') }}</span>
                      </vs-td>
                      <vs-td
                          >
                          <span class="cursor-pointer" @click="petitionlink(petition)">{{
                          checkProperty(petition,'lawOfficeInfo','name') }}</span>
                      </vs-td>
                      <!-- <vs-td class="content_ellipsis"><span class="cursor-pointer" @click="petitionlink(petition)" class="content_ellipsis" 
                          v-if="checkProperty(petition ,'clientInfo' ,'name')"> {{petition.clientInfo.name}} </span></vs-td> -->
                      <vs-td>
                          <span class="cursor-pointer" @click="petitionlink(petition)">
                          {{ petition.updatedOn | formatDate }}
                          
                          </span>
                      </vs-td>

                      
                      <vs-td >



                          <span class="statusspan cursor-pointer" @click="petitionlink(petition)" v-bind:class="{
                          'status_created': checkProperty(petition ,'statusDetails','id') == 1,
                          'status_submited': checkProperty(petition ,'statusDetails','id') == 2,
                          'status_inProcess': checkProperty(petition ,'statusDetails','id') == 3,
                          'status_waiting': checkProperty(petition ,'statusDetails','id') == 4,
                          'status_ready_for_filing':[5, 8].indexOf(checkProperty(petition, 'statusId')) > -1,
                          'status_sent_for_signatures': [6, 9].indexOf(checkProperty(petition, 'statusId')) > -1,
                          'staus_filed_with_USCIS':[7, 18].indexOf(checkProperty(petition, 'statusId')) > -1,
                          'received_signed_forms': checkProperty(petition ,'statusDetails','id') == 10,
                          'RFE_Received': [11, 24].indexOf(checkProperty(petition, 'statusId')) > -1,
                          'status_submited-USCIS': checkProperty(petition ,'statusDetails','id') == 12,
                          'response_to_RFE_Received': checkProperty(petition ,'statusDetails','id') == 13,
                          'status_jobdescription': checkProperty(petition ,'statusDetails','id') == 14,
                          'status_pwd_filed': checkProperty(petition ,'statusDetails','id') == 15,
                          'status_pwd_response': checkProperty(petition ,'statusDetails','id') == 16,
                          'staus_advertisements': checkProperty(petition ,'statusDetails','id') == 17,
                          'Status_received_by_USCIS': checkProperty(petition ,'statusDetails','id') == 19,
                          'Perm_drft_approved': checkProperty(petition ,'statusDetails','id') == 20,
                          'Perm_submited_dol': checkProperty(petition ,'statusDetails','id') == 21,
                          'status_approved': checkProperty(petition ,'statusId') == 22,
                          'status_denied': checkProperty(petition ,'statusDetails','id') == 23,
                          'notice_supervisory_audit': checkProperty(petition ,'statusDetails','id') == 27,
                          'status_supervisory_audit': checkProperty(petition ,'statusDetails','id') == 28,
                          'status_withdrawn': checkProperty(petition ,'statusDetails','id') == 31
                          }">{{checkProperty(petition,'statusDetails','name') }}</span>
                      </vs-td>



                      </vs-tr>
                  </template>
                  </vs-table>
                  <div class="table_footer">


                  <div class="vx-col  con-select pages_select" v-if="petitioners.length > 0">
                      <label class="typo__label">Per Page</label>
                      <multiselect @input="changeperPage()" v-model="perpage" :options="perPeges" :multiple="false"
                      :close-on-select="true" :clear-on-select="false" :preserve-search="true" placeholder="Per Page"
                      :preselect-first="true">

                      </multiselect>
                      <span class="totla_list_count" v-if="totalCount"> Total <em>{{totalCount}}</em></span>
                  </div>

                  <paginate v-if="petitioners.length > 0" v-model="page" :page-count="totalpages" :page-range="3"
                      :margin-pages="2" :click-handler="pageNate"
                      prev-class="vs-pagination--buttons btn-prev-pagination vs-pagination--button-prev"
                      next-class="vs-pagination--buttons btn-next-pagination vs-pagination--button-next" :prev-text="'<i></i>'"
                      :next-text="'<i></i>'" :container-class="'pagination vs-pagination--nav'" :page-class="'page-item'">
                  </paginate>
                  </div>
          </div>
    </div>
    <modal
      name="newCaseCreationModal"
      classes="v-modal-sec"
      :min-width="200"
      :min-height="200"
      :scrollable="true"
      :reset="true"
      width="750px"
      height="auto"
      >
      <div class="v-modal">
      <div class="popup-header fromDetailsPage"> 
      <h2 class="popup-title">
        New Case

      </h2>
      <span @click="$modal.hide('newCaseCreationModal');usciscUpdateStatusError='';NewPetition=false">
        <em class="material-icons">close</em>
      </span>
      </div>
      <form @submit.prevent data-vv-scope="newpetitionform" >
      <div class="form-container errorScroll">
         <div class="vx-row">
              <template>
            <div class="vx-col " :class="{'w-full':getTenantTypeId ==2 ,'w-1/2':!( getTenantTypeId ==2)}">
              <div class="form_group">
                <div class="con-select w-full select-large">
                  <label for="" class="form_label">Case Type<em>*</em></label>
               
                  <multiselect name="visatype" data-vv-as="Case Type" v-validate="'required'" v-model="visatype"
                    :show-labels="false" track-by="id" label="name" placeholder="Select Case Type"
                    :options="activeVisatypes" :searchable="true" :allow-empty="false" @input="getvisasubtypes">
                  </multiselect>
                </div>
                <span class="text-danger text-sm" v-show="errors.has('newpetitionform.visatype')">{{
                  errors.first("newpetitionform.visatype") }}</span>
              </div>
            </div>

            <div class="vx-col " :class="{'w-full':getTenantTypeId ==2 ,'w-1/2':getTenantTypeId !=2}">
              <div class="form_group">
                <div class="con-select w-full select-large">
                  <label for="" class="form_label">Case Subtype<em>*</em></label>
                  <multiselect name="visasubtype" data-vv-as="Case Subtype" v-validate="'required'"
                    v-model="visasubtype" :show-labels="false" track-by="id" label="name"
                    placeholder="Select Case Subtype" :options="visasubtypes" :searchable="true" :allow-empty="false"
                    >
                  </multiselect>
                </div>
                <span class="text-danger text-sm" v-show="errors.has('newpetitionform.visasubtype')">{{
                  errors.first("newpetitionform.visasubtype") }}</span>
              </div>
            </div>
            <div class="vx-col w-1/2 " >
            <immiInput :wrapclass="'w-1/2'" :fieldsArray="[]" :display="false" :tplkey="''"  cid="lawOfficeName" formscope="newpetitionform" 
            v-model="lawOfficeName" :required="false" :tplsection="''"  :fieldName="'lawOfficeName'"  label="Law Office Name" placeHolder="Law Office Name" />
          </div>
            <div class="vx-col w-1/2 " >
              <div class="form_group">
                <div class="con-select w-full select-large">
                  <label for="" class="form_label">Status<em>*</em></label>
               
                  <multiselect name="Status" data-vv-as="Status" v-validate="'required'" v-model="caseStatusDetails"
                    :show-labels="false" track-by="id" label="name" placeholder="Status"
                    :options="casesStatusList" :searchable="true" :allow-empty="false" >
                  </multiselect>
                </div>
                <span class="text-danger text-sm" v-show="errors.has('newpetitionform.Status')">{{
                  errors.first("newpetitionform.Status") }}</span>
              </div>
            </div>
          
              </template>
           <template >
            <template v-if="([3,4,5,6,7,8,50].indexOf(getUserRoleId)>-1 && getTenantTypeId !=2 )">
              <div class="vx-col w-1/2" v-if="([3,4,5,6,7,8].indexOf(getUserRoleId)>-1 )">
                <div class="form_group">
                  <div class="con-select w-full select-large">
                    <label class="form_label">Select Petitioner<em>*</em></label>                   
                    <multiselect v-model="selectedPetitioner" :options="petitionersList" :multiple="false"
                      :hideSelected="false" :close-on-select="true" :clear-on-select="false" :preserve-search="true"
                      :select-label="'Search Petitioner'" placeholder="Select Petitioner" label="name" track-by="name"
                      :preselect-first="false" data-vv-as="Petitioner" v-validate="'required'"
                      tag-placeholder="Invite Petitioner" :taggable="false" @tag="addNewPet" :searchable="true"
                      @search-change="searchPet" @input="petitionerUpdated" name="Petitioner" 
                      >
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          options selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>
                  <span class="text-danger text-sm" v-show="errors.has('newpetitionform.Petitioner')">{{
                    errors.first("newpetitionform.Petitioner") }}</span>
                </div>
                <p v-if="checkPetInvitePermisions" class="createnew marb15">Not found?<span @click="addNewPet()">Invite
                    Customer</span> </p>
              </div>
              <div class="vx-col w-1/2" :class="{'w-full':[50 ].indexOf(getUserRoleId)>-1 }"
                v-if="([3,4,5,6,7,8,50 ].indexOf(getUserRoleId)>-1  )">
                <div class="form_group">
                  <div class="con-select w-full select-large">
                    <label class="form_label">Select Beneficiary<em>*</em></label>
                    <multiselect v-model="selectedBeneficiary" :options="beneficiaryMasterDataList" :multiple="false"
                      :hideSelected="false" :close-on-select="true" :clear-on-select="false" :preserve-search="true"
                      :select-label="'Search Beneficiary'" placeholder="Select Beneficiary" label="name"
                      track-by="name" :preselect-first="false" data-vv-as="Beneficiary" v-validate="'required'"
                      :searchable="true" @search-change="getbeneficiaryMasterDataList" name="beneficiary"
                      @input="upDateBenef" tag-placeholder="Add New Beneficiary" :taggable="false"
                      @tag="addNewBenFromTag"
                      :disabled="(!checkProperty(selectedPetitioner ,'_id') && [50 ].indexOf(getUserRoleId)<=-1 )">
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          options selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>
                  <span class="text-danger text-sm" v-show="errors.has('newpetitionform.beneficiary')">{{
                    errors.first("newpetitionform.beneficiary") }}</span>
                </div>
                <p v-if="selectedPetitioner && checkBeneficaryInvitePermisions" class="createnew"
                  >Not found? <span @click="AddBeneficiary =true;selectedBeneficiary=null">Invite Beneficiary</span>
                </p>
              </div>
            </template>
            <template v-else-if=" getTenantTypeId ==2">
              <div class="vx-col " :class="{'w-full':getTenantTypeId ==2 ,'w-1/2':getTenantTypeId !=2}">
                <div class="form_group">
                  <div class="con-select w-full select-large">
                    <label class="form_label">Select Beneficiary<em>*</em></label>
                    <multiselect v-model="selectedBeneficiary" :options="beneficiaryMasterDataList" :multiple="false"
                      :hideSelected="false" :close-on-select="true" :clear-on-select="false" :preserve-search="true"
                      :select-label="'Search Beneficiary'" placeholder="Select Beneficiary" label="name"
                      track-by="name" :preselect-first="false" data-vv-as="Beneficiary" v-validate="'required'"
                      :searchable="true" @search-change="getbeneficiaryMasterDataList" name="beneficiary"
                      @input="upDateBenef" tag-placeholder="Add New Beneficiary" :taggable="false"
                      @tag="addNewBenFromTag">
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          options selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>
                  <span class="text-danger text-sm" v-show="errors.has('newpetitionform.beneficiary')">{{
                    errors.first("newpetitionform.beneficiary") }}</span>
                </div>
                <p class="createnew">Not found?<span @click="AddBeneficiary =true;selectedBeneficiary=null">Invite
                    Beneficiary</span> </p>
              </div>
            </template>  
          </template>
        </div>
        <div class="text-danger text-sm formerrors custom_margin" v-show="formerrors.msg">
          <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
            icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
        </div>
      </div>
      <div class="popup-footer relative">
        <span class="loader" v-if="newPetitionFormSubmited" ><img src="@/assets/images/main/loader.gif" /></span>
        <vs-button color="dark" @click="addNewCase(false);NewPetition=false ;formerrors.msg='';" class="cancel" type="filled">Cancel
        </vs-button>
        <vs-button color="success" :disabled=" newPetitionFormSubmited || !enableSubmitBtn" @click="fileNewCase"
          class="save" type="filled">Submit</vs-button>
      </div>
    </form>
      </div>
    </modal>
    <vs-popup class="holamundo main-popup" title="Invite Customer" :active.sync="invitepetitioner">
        <addBenewPet @closenewPetPopup="closenewPetPopup" v-if="invitepetitioner" />
    </vs-popup>
    <vs-popup class="holamundo main-popup" :class="{'openedNewpetpopup':invitepetitioner}" :title="'Add Beneficiary'"
          :active.sync="AddBeneficiary">
      <addBeneficiary ref="add_ben" @closeAddBenPopUp="closeAddBenPopUp" @fileNewCase="fileNewCase" v-if="AddBeneficiary"
         :petitioner="selectedPetitioner" @openAddpetPopUp="openAddpetPopUp" />
    </vs-popup> 
  </div>
</template>
<script>
import datepickerField from "@/views/forms/fields/datepicker.vue";
import selectField from "@/views/forms/fields/simpleselect.vue";
import _ from "lodash";
import immiswitchyesno from "@/views/forms/fields/switchyesno.vue"
import DateRangePicker from "vue2-daterange-picker";
import Paginate from "vuejs-paginate";
import Datepicker from "vuejs-datepicker-inv";
import Multiselect from "vue-multiselect-inv";
import JQuery from "jquery";
import NoDataFound from "@/views/common/noData.vue";
import FileUpload from "vue-upload-component/src";
import "vue2-daterange-picker/dist/vue2-daterange-picker.css";
import addBeneficiary  from "@/views/common/addBeneficiary.vue" 
import addBenewPet  from "@/views/common/invitePet.vue" 
import moment from 'moment'
import { stringify } from "querystring";
import Vue from 'vue';
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import immiInput from "@/views/forms/fields/simpleinput.vue";
export default{
  provide() {
      return {
          parentValidator: this.$validator,
      };
  },
  components: {
    immiInput,
      datepickerField,
      selectField,
      immiswitchyesno,
      FileUpload,
      addBeneficiary,
      addBenewPet,
      Datepicker,
      DateRangePicker,
      Multiselect,
      Paginate,
      NoDataFound
  },
  props: {
    beneficiaryId:null,
    beneficiaryInfo:null,
    petitionerDetails:null,
    isRfe:{
      type: Boolean, default:false
    }
  },
  data: () => ({
    addCls:false, 
    sortingList:[
      //  {path:'caseNo',order:-1 ,"displayName":"Case Number"},
   //    {path:'createdByName',order:-1 ,"displayName":"Created By Name"},
   //    {path:'typeName',order:-1 ,"displayName":"Case Type"},
    //   {path:'subTypeName',order:-1,"displayName":"Case Sub Type"},
    //   {path:'statusName',order:-1,"displayName":"Case Status"},
       {path:'createdOn',order:-1,"displayName":"Created Date"},
       {path:'updatedOn',order:-1,"displayName":"Updated Date"},
  //     {path:'clientName',order:-1,"displayName":"Client Name"},
    //   {path:'beneficiaryName',order:-1,"displayName":"Beneficiary Name"},
        
   ],
    casesStatusList:[],
    caseStatusDetails:null,
    lawOfficeName:'',
    getPendingWithLCA:false,
    debounce:null,
    global_selected_petitioners:[],
    gobalType:[],
    getActiveCases:false,
    getClosedCases:false,
    dashboardBranchIds:[],
    editor: ClassicEditor,
    editorConfig: {
        toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
    },
    loading:false,
    enableSubmitBtn:true,
    uploading:false,
    newPetitionFormSubmited:false,
    formerrors: {
      msg: ""
    },
    selectedBranch:null,
    NewPetition:false,
    petitionersList:[],
    invitepetitioner:false,
    AddBeneficiary:false,
    selectedPetitioner:null,
    saveBenbtn:false,
    selectedUser:'',
    selectedUsername:'',
    beneficiaryMasterDataList:[],
    visatypes:[],
    activeVisatypes:[],
    visatype:null,
    visasubtypes:[],
    visasubtype:null,
    selectedBeneficiary:null,
    branchList:[],
    selectedBranches:[],
    isListloading:false,
    callFromSerch:false,
    sortKeys:{},
    sortKey:{},
    buttoncol: true,
    ChangePetition: false,
    formerrors: {
      msg: ""
    },
    searchtxt: "",
    query: [],
    selected: [],
    petitioners: [],
    currentuserRole: null,

    selected_createdDateRange: ["", ""],
    selected_deadLineDateRange: ["", ""],
    autoApply: "",
    countries: [],
    country_code: 0,
    selected_country_obj: "",
    all_states: [],
    seleted_states: [],
    final_selected_states: [],
    singel_final_selected_state: "",
    all_locations: [],
    seleted_locations: [],
    final_selected_locations: [],
    case_statusids:[],
    selected_statusids: [],
    final_selected_statusids: [],
    page: 1,
    perpage: 25,
    totalpages: 0,
    totalCount:0,
    filter_searchtxt: "",
    visaTypes:[],
    selectedVisaType:null,
    all_subtypes: [],
    selected_subtypes: [],
    final_selected_subtypes: [],
    all_peritioners: [],
    peritioners_search_value: "",
    selected_peritioners: [],
    selectedLawOffice:[],
    lawOfficeList:[],
    final_selected_peritioners: [],

  isListLoading:false,
    sortKeys:{},
    sortKey:{},
    perPeges: [10,25,50,75,100], // [  {name:10 ,perPage:10} , {name:25 ,perPage:25} ,{name:50 ,perPage:50},{name:100 ,perPage:100}],
    encodedString:'',
    classificationResultList:[],
  }),
  watch: {
  searchtxt: function(value) {
    this.searchMe(); 
  },
   '$route.query.filter':function (val) {
    this.selected_statusids =[];
    this.final_selected_statusids =[];
    this.final_selected_subtypes = []
    this.selected_subtypes = []
    this.selectedVisaType =null;
      if(this.checkProperty(this.$route ,'query' ,'filter')){
              try{
                let filter =this.$route['query']['filter']; this.checkProperty(this.$route ,'query' ,'filter')
                var actual = JSON.parse(atob(filter));
                let keys = Object.keys(actual);
                if(this.checkProperty(keys ,'length') >0){
                  
                 
                  if(actual && (Object.keys(actual)).length>0 ){               
                  _.forEach(actual ,(item ,key) => {
                      if(key=='matcher' ){
                        
                        if((Object.keys(item)).length>0 ){

                          if(_.has(item ,'typeIds') && this.checkProperty(item , 'typeIds' ,'length')>0 ){
                             
                            this.selectedVisaType = _.find(this.visaTypes ,{"id":item['typeIds'][0]})
                           this.getvisa_subtypes();
                         
                          }  
                          if(_.has(item ,'subTypeIds') && this.checkProperty(item ,'subTypeIds' ,'length')>0){
                                
                                
                                this.final_selected_subtypes = item['subTypeIds'];
                               
                                if(this.all_subtypes.length>0){

                                
                                this.selected_subtypes = _.filter(this.all_subtypes ,(status)=>{
                                    return item['subTypeIds'].indexOf(status['id'])>-1;
                                    

                              })
                            }
                          }
                             
                          if(_.has(item ,'statusIds') && this.checkProperty(item ,'statusIds' ,'length')>0){
                            let statusIds = item['statusIds']
                            let selectedStatus = _.find(this.case_statusids ,{"id":parseInt(statusIds[0])}); 
                            this.final_selected_statusids =statusIds;
                          if(selectedStatus){
                          this.selected_statusids =[selectedStatus];
                          
                          } 

                          }
                       
                              
                        }
                      
                      }
                  })
                }                    
                }

              }catch(e){
              }          
            } 
            else{
              this.gobalType = {"_id":"632953d43ecbeaeefe93efefr","id":'ALL',"name":"All","isCaseTypeSelected":true}
              this.selectedVisaType = this.gobalType
            }      
        this.getpetitions(true);
    }
},
  methods: {
    changeSorting(item){
      if(_.has(this.$route,'name')){
            item['order'] = item['order']==1?-1:1;
          this.addCls = true;   
          localStorage.setItem(this.$route['name'] ,JSON.stringify(item));
          this.sortKey = item;
          this.sortKeys[item['path']] = item['order'];
          _.forEach(this.sortKeys, (sortVal, sortKey)=>{
            if(sortKey == item['path'] ){ 
              this.sortKeys[sortKey] = this.sortKey['order'];
            }else{
            //  this.sortKeys[sortKey]= this.sortKey['order']==1?-1:1
            }

            
          });
          this.getpetitions();

          }

    },
    getLawOfficeList(){
        let payLoad={
          matcher:{
            statusIds:[],
            createdDateRange:[]
          },
          page:1,
          perpage:1000
        };
        let path ="/external-cases/office-list";
            this.$store.dispatch("getList", { data: payLoad, path: path})
            .then((response) => {
              let list = response.list;
              this.lawOfficeList = _.filter(list,(item)=>{
                return item['name']
              })
            })
            .catch((err)=>{

            })
      },
    getvisaforNewCase(){
    let item ={
        matcher:{ 
          getActiveList:true,
        },   
        page:this.page,
        perpage: this.perpage,
        category: "petition_types",
    };
    this.visatype =null;
    this.$store.dispatch("getMasterData",item ).then(response => {
      if([51].indexOf(this.getUserRoleId)>-1){
      this.activeVisatypes = _.filter(response.list ,(item)=>{
     return item.id !=3
    })
    }else{
      this.activeVisatypes = response.list
    }
    if(this.checkProperty(this.activeVisatypes ,'length')>0){
      this.visatype = this.activeVisatypes[0];
      if(this.checkProperty(this.$route ,'query' ,'filter')){
          try{
            let filter =this.$route['query']['filter']; this.checkProperty(this.$route ,'query' ,'filter')
            var actual = JSON.parse(atob(filter));
            let keys = Object.keys(actual);
            if(this.checkProperty(keys ,'length') >0){
              if(actual && (Object.keys(actual)).length>0 ){
              _.forEach(actual ,(item ,key) => {
                  if(key=='matcher' ){
                    if((Object.keys(item)).length>0 ){
                      if(_.has(item ,'typeIds') && this.checkProperty(item , 'typeIds' ,'length')>0 ){
                        let visatype = _.find(this.activeVisatypes ,{"id":item['typeIds'][0]})
                        if(visatype){
                          this.visatype = visatype;
                         this.getvisasubtypes();
                        }
                      }
                    }
                  
                  }
              })
            }
              
              
            }

          }catch(e){
          }
            
      }

      
        this.getvisasubtypes(this.visatype)
  }
  });
},
        searchMe(){
            let self =this;
            clearTimeout(this.debounce)
              this.debounce = setTimeout(() => {
                self.getpetitions(true ,false);
              }, 900)
        },
        closeAddBenPopUp(selectedBeneficiary=null){
            this.AddBeneficiary =false;
            this.selectedBeneficiary =selectedBeneficiary;
            if(this.checkProperty(this.selectedBeneficiary ,'name') && this.checkProperty(this.selectedBeneficiary ,'_id') ){
              this.selectedUser =this.checkProperty(this.selectedBeneficiary ,'_id');
              this.selectedUsername = this.checkProperty(this.selectedBeneficiary ,'name');
            }
            this.getbeneficiaryMasterDataList();
            this.checkBenPermStatus();
        },
        openAddpetPopUp(){
            this.selectedPetitioner =null;
            this.invitepetitioner =true;
        },
        closenewPetPopup(selectedPetitioner=null){
            this.getPetitioners();
            this.selectedPetitioner =selectedPetitioner;
            this.invitePetitionPopupshow(false);
            this.openNewbenFormPopup(true);
        },
        searchPet(searchText=''){
          let _self =this;
          this.selectedBeneficiary =null;
          this.selectedPetitioner =null;
          this.selectedUser ='';
          this.selectedUsername = '';
          let self =this;
          clearTimeout(self.debounce)
          self.debounce = setTimeout(() => {
              self.getPetitioners(self ,searchText);
            }, 900)   
        },
        fileNewCase(){
            Object.assign(this.formerrors, {
                    msg: ''
            })
            this.$validator.validateAll('newpetitionform').then(result => {
                if (result) {
                 
                    let self =this;
           
                  var postdata={
                   
                      userId: this.selectedUser,
                      today: moment().format('YYYY-MM-DD'),
                      typeId: this.visatype.id,
                      subTypeId:this.visasubtype.id,
                      petitionerId: null,
                      statusId:null,
                      lawOfficeInfo: {
                        name:'',
                      }

                  }
                  if(this.lawOfficeName){
                    postdata['lawOfficeInfo']['name'] = this.lawOfficeName
                  }
                  if(this.checkProperty(this.caseStatusDetails,'id')){
                    postdata['statusId'] = this.checkProperty(this.caseStatusDetails,'id');
                  }
                  if(this.getTenantTypeId !=2){
                    if([50].indexOf(this.getUserRoleId) > -1){
                        postdata['petitionerId'] = this.$store.state.user._id

                    }else{
                        postdata['petitionerId'] = this.checkProperty(this.selectedPetitioner ,"userId")
                    }
                  }
                  if(this.checkProperty(this.beneficiaryInfo ,"name") && this.beneficiaryId){
                    postdata['userId'] = this.beneficiaryId;
                    postdata['userName'] =this.beneficiaryInfo['name']
                  }
                  if(!this.newPetitionFormSubmited){
                    this.newPetitionFormSubmited =true;
                    let path = '/external-cases/create'
                    this.$store.dispatch("commonAction", { "data": postdata, "path": path })
                    .then(response => {
                              if (response.error) {
                            Object.assign(this.formerrors, {
                              msg: response.error.message
                            });
                            this.newPetitionFormSubmited =false;
                          } 
                          else {
                            
                            this.NewPetition =false; 
                              this.newPetitionFormSubmited =false;
                              this.getpetitions();

                              this.visatype = {
                              id: 1,
                              name: "H-1B"
                              }
                              this.getvisasubtypes(this.visatype);
                              this.showToster({message:response.message ,isError:false});
                              this.addNewCase(false);
                              setTimeout(()=>{

                              if (this.checkProperty(response,'_id')) {
                                let itemId = this.checkProperty(response,'_id')
                              //this.$router.push({ name: 'external-case-details', params: { itemId: response._id } }).catch(err => { })
                              this.$router.push({ path: `/external-case-details/${itemId}` ,query: {'filter':this.encodedString} })
                              }
                          } ,10)

                                  
                                  
                          }

                    })
                    .catch((error)=>{
                      let errorr = error.result.error
                      this.newPetitionFormSubmited =false;  
                    });

                  }
                }else{
                      const $ = JQuery;
                          if($('.errorScroll .text-danger:visible')){
                            var _t = $('.errorScroll .text-danger:visible').first().parent().offset().top;
                            if(_t < 0) _t = -(_t)
                              $('.scrollable:visible').scrollTop(_t-50);
                            }
                }
            });
        },
        petitionerUpdated(){
          this.selectedBeneficiary = null;
          this.selectedUser ='';
          this.selectedUsername = '';
          this.getbeneficiaryMasterDataList();
        },
        addNewPet(newPet='' ,id){
          this.newPetOpenFromben =false;
          this.openNewbenForm =false;
          this.addNewPete =true;
          this.invitePetitionPopupshow(true)
        },
        invitePetitionPopupshow(action =true){
            this.invitepetitioner=action;
            if(!action){
              this.selectedBeneficiary =null;
            }  
        },
        getPetitioners(callFromSerch=false,searchText='' ) {
            let _self =this;
            if(this.callFromSerch){
            }
            let query ={
              "matcher":{
                "searchString": searchText,
                "statusIds": [],
                "countryIds": [],
                "stateIds": [],
                "locationIds": [],
                "createdDateRange": []
              },
            "sorting": { 	"path": "createdOn", 	"order": -1 	},
            "page": 1,
            "perpage": 100,
            getMasterData:true
            }
            this.$store
              .dispatch("getList",{data:query ,path:'/company/list'} )
                  .then(response => {
                      _self.petitionersList = response.list;
                      let filteredData =  _.filter(_self.petitionersList ,(item)=>{
                          if( item&& ( _.has(item ,'name') || _.has(item ,'email')  )){
                                  if((_.has(item ,'name')&& item['name'].includes(searchText)) || (_.has(item ,'email') && item['email'].includes(searchText)) ){
                                    return true;
                                  }else{
                                      return false;
                                  }
                          }else{
                            return false;
                          }
                  })
              }).catch((err)=>{
               
                this.petitionersList =[];
              
              })
        },
        changeperPage(){       
              this.page = 1;
              localStorage.setItem('petitions_perpage', this.perpage);
              this.getpetitions(); 
        },
        petitionlink(tr) {
          let routedId = tr._id;
          let itemType = tr
          if(itemType){
            this.$router.push({ path: `/external-case-details/${routedId}` ,query: {'filter':this.encodedString} }).catch(err => {})
          }
        },
        setQueryString(obj){
          const string = JSON.stringify(obj) // convert Object to a String
          this.encodedString = btoa(string) // Base64 encode the String
          this.$route['query']['filter'] = this.encodedString;
        },
        get_all_states() {
          this.$store.dispatch("getstates", this.country_code).then(response => {
            this.all_states = response;
          });
        },
        getAllLocations() {
          Object.assign(this.query, {
            countryId: this.country_code,
            stateId: this.singel_final_selected_state //this.final_selected_states//3922
          });
          this.$store.dispatch("getlocations", this.query).then(response => {
            this.all_locations = response;
          });
        },
        getpetitions(callFromSerch=false , applyUrlFilter=false) {
            this.selectedAllForArchive =false;
          this.selectedForArchiveList =[]; 
          this.callFromSerch = callFromSerch;
          let self =this; 
              if(this.callFromSerch){
                  this.petitioners  =[];
              }

         let obj= {
              matcher: {
                title: self.searchtxt,
                statusIds: [],
                petitionerIds:self.final_selected_peritioners,
                typeIds:[],
                subTypeIds:[],
                createdDateRange: [],
                lawOfficeNames:[]
              },
              page: self.page,
              perpage: self.perpage,
              sorting:self.sortKey
}
          if(this.selectedVisaType && _.has(this.selectedVisaType , 'id' )){
            if(this.checkProperty(this.selectedVisaType, 'id')!='ALL'){
              obj["matcher"]["typeIds"] = [this.selectedVisaType['id']];
              obj["matcher"]["subTypeIds"] = this.final_selected_subtypes;  
            }
            
          }
          if (
          this.selected_createdDateRange["startDate"] &&
          this.selected_createdDateRange["startDate"] != "" &&
          this.selected_createdDateRange["endDate"] != "" &&
          this.selected_createdDateRange["endDate"]
        ) {
          obj["matcher"]["createdDateRange"] = [
            this.selected_createdDateRange["startDate"],
            this.selected_createdDateRange["endDate"]
          ];
        }
          if(this.final_selected_statusids ){
           obj["matcher"]["statusIds"] =this.final_selected_statusids;
        }
        if(this.selectedLawOffice && this.checkProperty(this.selectedLawOffice,'length')>0){
         _.forEach(this.selectedLawOffice,(item)=>{
          if(item['name']){
            obj["matcher"]["lawOfficeNames"].push(item['name'])
          }
          })
        }
            this.isListloading = true;
            this.updateLoading(true);
            // let tmpObj =_.cloneDeep(obj['matcher']);
            // tmpObj = Object.assign(tmpObj ,{ page: self.page, perpage: self.perpage,sorting:self.sortKey});
            let tempObj={
              selectedLawOffice:this.selectedLawOffice,
              selected_statusids:this.selected_statusids,
              searchtxt:this.searchtxt,
              selected_peritioners:this.selected_peritioners,
              selectedVisaType:this.selectedVisaType,
              selected_subtypes:this.selected_subtypes,
              filter_searchtxt:this.filter_searchtxt,
              page: this.page,
              perpage: this.perpage,
              sortKey: this.sortKey,
            };
            if (
              this.selected_createdDateRange["startDate"] &&
              this.selected_createdDateRange["startDate"] != "" &&
              this.selected_createdDateRange["endDate"] != "" &&
              this.selected_createdDateRange["endDate"]
            ) { 
              tempObj["startDate"] = moment(this.selected_createdDateRange["startDate"]).format("YYYY-MM-DD");
              tempObj["endDate"] = moment(this.selected_createdDateRange["endDate"]).format("YYYY-MM-DD");
            }
            this.setQueryString(tempObj)
            this.$store.dispatch("commonAction", { "data": obj,"path":"/external-cases/list"}).then(response => {  
              this.addCls = false;   
                this.isListloading = false;
            this.updateLoading(false);
            this.getClosedCases = false;
            this.getActiveCases = false;
            this.dashboardBranchIds = [];
            let tempList =[];
            let list = response.list
            _.forEach( list,(item) => {
                item =Object.assign(item,{ 'selectedForArchive':false});
              if(this.selectedForArchiveList.indexOf(item['_id'])>-1){
                  item =Object.assign(item,{ 'selectedForArchive':true});
              }
              tempList.push(item)
              
            });

              this.petitioners = list;

                this.updateLoading(false);
                this.totalCount = this.checkProperty(response, 'totalCount')
            this.totalpages = Math.ceil(response.totalCount / this.perpage);
            setTimeout(() =>{
                    this.updateLoading(false);
                    this.caseStatus(this.selectedVisaType)
                  })

            }) .catch((err) => {
              this.addCls = false;   
              this.isListLoading =false;
                this.updateLoading(false);
                this.petitioners = [];
                setTimeout(() =>{
                    this.updateLoading(false);
                  })
                  
              });
        },
        set_filter: function() {
          this.global_selected_petitioners = this.selected_peritioners
          this.gobalType = this.selectedVisaType
          this.final_selected_statusids = [];
          if(this.selected_statusids) {
            this.final_selected_statusids = [];
            for (let ind = 0; ind < this.selected_statusids.length; ind++) {
              let current_index = this.selected_statusids[ind];
              this.final_selected_statusids.push(current_index["id"]);
            }
          }
          this.final_selected_locations = [];
          if (this.seleted_locations.length > 0) {
            for (let ind = 0; ind < this.seleted_locations.length; ind++) {
              let current_index = this.seleted_locations[ind];
              this.final_selected_locations.push(current_index["id"]);
            }
          }

          this.searchtxt = this.filter_searchtxt;

          this.getpetitions(false ,false);
          this.page=1;
          this.$refs["filter_menu"].dropdownVisible = false;
        },
        clear_filter: function() {
          this.selectedVisaType =[]
          this.global_selected_petitioners = [];

          this.selected_deadLineDateRange =  ["", ""];
          this.selectedpremiumProcessing = [];
          this.peritioners_search_value ='';
          this.searchtxt = "";
          this.selected_statusids = [];

          this.selected_country_obj = "";
          this.seleted_states = [];
          this.final_selected_states = [];
          this.singel_final_selected_state = "";
          this.selectedLawOffice = [];
          this.seleted_locations = [];
          this.final_selected_locations = [];
          this.final_selected_statusids = [];

          this.date = "";
          this.date_range = [];
          this.selected_createdDateRange["startDate"] = "";
          this.selected_createdDateRange["endDate"] = "";


          
          this.selectedVisaType =null;
          this.filter_searchtxt = "";
          this.selected_subtypes = [];
          this.final_selected_subtypes = [];

          (this.rolebased_filter = {
            3: { name: "supervisorIds", values: [] },
            4: { name: "paralegalIds", values: [] },
            5: { name: "attorneyIds", values: [] },
            9: { name: "offshoreUserIds", values: [] },
            10: { name: "evidenceSupervisorIds", values: [] }
          }),
            (this.final_selected_peritioners = []);
          this.selected_peritioners = [];
          //this.getPetitioners();
          this.$refs["filter_menu"].dropdownVisible = false;
          this.selected_users =[];
          this.selectedBranches =[];
          this.page=1;
          this.getpetitions(false ,false);
          //this.$router.push({ query: {} })
        },
        caseStatus(obj){ 
          let selectedItem = null
          if(obj){
            selectedItem = obj
          }
          
          let postData = {
            "matcher": { 
              "searchString":"",
              "tenantId": "",
              "branchId": "",
              "getWorkFlowConfig": false,
              "getCasenoCodeConfig": false,
              "tenantCustomId": "",
              "petitionTypes": [],
              "getInactiveListAlso": false,
              "caseType": ""
              },
              "category": "case_status",
              "page": 1,
              "perpage": 25,
              "sorting": {    
                "path": "name",
                "order": 1
              }
          }
          if(selectedItem && this.checkProperty(selectedItem, 'id')==1){
            postData['matcher']['caseType'] = "h1b"
          }
          if(selectedItem && this.checkProperty(selectedItem, 'id')==2){
            postData['matcher']['caseType'] = "h4"  
          }
          if(selectedItem && this.checkProperty(selectedItem, 'id')==3){
            postData['matcher']['caseType'] = "gc"  
          }
          if( selectedItem ==null){
            postData['matcher']['caseType'] = ""
          
          }
          if( this.selected_subtypes && this.checkProperty(this.selected_subtypes,'length')==1){
            _.forEach(this.selected_subtypes,(item)=>{
              if(item['id'] == 15){
                postData['matcher']['caseType'] = "perm"
              }
              if(item['id'] == 16){
                postData['matcher']['caseType'] = "i-140"
              }
              if(item['id'] == 17){
                postData['matcher']['caseType'] = "i-485"
              }
            })
          }
          
        
          if(this.checkProperty(this.tenantDetails ,"customId")){
            postData['matcher']['tenantCustomId']= this.tenantDetails['customId'];
          }  //"get_case_statusids"  //getMasterData
            this.$store.dispatch("getMasterData",postData).then(response => {
              
              this.case_statusids = response.list;
                if (this.checkProperty(this.$router.currentRoute ,"query"  ,"status") ){        
                      let status = this.checkProperty(this.$router.currentRoute ,"query"  ,"status");
                      let selectedStatus = _.find(this.case_statusids ,{"id":parseInt(status)});        
                          if(selectedStatus){
                            this.selected_statusids =[selectedStatus];
                            this.final_selected_statusids =[parseInt(status)];
                          }          
                  }  
            })
        },
        pageNate(pageNum) {
          this.page = pageNum;
          this.getpetitions();
        },
        addNewBenFromTag(){

        },
        filterQueryPreSelect(callFromMounted=false){
            if(this.checkProperty(this.$route ,'query' ,'filter')){
              try{
                let filter =this.$route['query']['filter']; this.checkProperty(this.$route ,'query' ,'filter')
                var actual = JSON.parse(atob(filter));
                let keys = Object.keys(actual);
                if(this.checkProperty(keys ,'length') >0 ){
                  if(_.has(actual ,'page') && this.checkProperty(actual ,'page')){                                     
                    this.page = this.checkProperty(actual ,'page');
                  }
                  if(_.has(actual ,'perpage') && this.checkProperty(actual ,'perpage')){                                     
                    this.perpage = this.checkProperty(actual ,'perpage');
                  }
                  if(_.has(actual ,'sortKey') && this.checkProperty(actual ,'sortKey')){                                     
                    this.sortKey = this.checkProperty(actual ,'sortKey');
                  }
                  if(_.has(actual ,'selectedVisaType') && this.checkProperty(actual ,'selectedVisaType')){                                     
                    //this.selectedVisaType = this.checkProperty(actual ,'selectedVisaType');
                    this.changedVisaType(this.checkProperty(actual ,'selectedVisaType'), true);
                  }
                  if(_.has(actual ,'selected_subtypes') && this.checkProperty(actual ,'selected_subtypes')  && this.checkProperty(actual ,'selected_subtypes', 'length')>0){                                     
                    this.selected_subtypes = this.checkProperty(actual ,'selected_subtypes');
                    this.changedsubtypes();
                  }
                  if(_.has(actual ,'selectedLawOffice') && this.checkProperty(actual ,'selectedLawOffice')){                                     
                    this.selectedLawOffice = this.checkProperty(actual ,'selectedLawOffice');
                  }
                  if(_.has(actual ,'selected_statusids') && this.checkProperty(actual ,'selected_statusids') && this.checkProperty(actual ,'selected_statusids', 'length')>0){                                     
                    this.selected_statusids = this.checkProperty(actual ,'selected_statusids');
                  }
                  if(_.has(actual ,'selected_peritioners') && this.checkProperty(actual ,'selected_peritioners') && this.checkProperty(actual ,'selected_peritioners', 'length')>0){                                     
                    this.selected_peritioners = this.checkProperty(actual ,'selected_peritioners');
                    this.changedperitioners();
                  }
                  if(_.has(actual ,'startDate') && this.checkProperty(actual ,'startDate') ){                                     
                    this.selected_createdDateRange["startDate"] = this.checkProperty(actual ,'startDate');
                  }
                  if(_.has(actual ,'endDate') && this.checkProperty(actual ,'endDate') ){                                     
                    this.selected_createdDateRange["endDate"] = this.checkProperty(actual ,'endDate');
                  }
                  if(_.has(actual ,'searchtxt') && this.checkProperty(actual ,'searchtxt') ){                                     
                    this.searchtxt = this.checkProperty(actual ,'searchtxt');
                  }
                  if(_.has(actual ,'filter_searchtxt') && this.checkProperty(actual ,'filter_searchtxt') ){                                     
                    this.filter_searchtxt = this.checkProperty(actual ,'filter_searchtxt');
                  }
                  this.set_filter(); 
                }else{
                  this.set_filter();
                }
              }catch(e){
                if(callFromMounted){
                  this.set_filter();
                }
              }   
            }
            else{
              if(callFromMounted){
                  this.set_filter();
              }
            } 
        },
        getbeneficiaryMasterDataList(text=''){
          let postData = {
              "matcher": {
                "title": text,
                "statusList": [],
                "branchIds": [],
                "companyIds": [], // Required only for Tenant Admin and Branch Manager to list Beneficiaries
                "createdByIds": [],
                "createdDateRange": [],
                "roleIds": [51],
                "statusIds": [],
                "petitionTypeIds": [],
                "petitionSubTypeIds": [],
                "petitionCreatedDateRange": [],
                "petitionStatusIds": [],
                "getPetitionStats": true
              },
            "sorting": {
              "path": "createdOn", // invitedByName, updatedOn, name, email, phone, statusName, roleName
              "order": 1
            },
            "page": 1,
            "perpage": 1000000,
            "getMasterData": true,
            "getBeneficiaryList": true, // Required only for Tenant Admin and Branch Manager to list Beneficiaries
            "branchId": "", // Required when 'getMasterData' is true and roleIds are [4, 5, 6, 7, 8, 9, 10, 11]
            "companyId": "" // Required when 'getMasterData' is true and roleIds are [50, 51]
      }; 
      this.enableAddNewBenTag =false;
        if(this.checkProperty(this.selectedPetitioner ,"_id")){
          postData['companyId'] = this.selectedPetitioner['_id']
        }
        if([50,51].indexOf(this.getUserRoleId)>-1){
        postData['companyId'] = this.checkProperty(this.getUserData ,"companyDetails" ,"_id")
      }
          this.$store
            .dispatch("petitioner/getbeneficiaries", postData)
            .then(response => {
              this.beneficiaryMasterDataList = response.list;
              let filteredData =[];
          _.forEach(this.beneficiaryMasterDataList ,(item)=>{
                    if( item && ( _.has(item ,'name') || _.has(item ,'email')  )){
                            if((_.has(item ,'name') && item['name'].includes(text)) || (_.has(item ,'email') && item['email'].includes(text)) ){
                              filteredData.push(item)
                            }else{
                                return false;
                            }
                    }else{
                      return false;
                    } 
            })
            if(filteredData.length<=0){
              this.enableAddNewBenTag =true;
            }
              })
        },
        peritioners_search_fun(searchValue) {
              this.peritioners_search_value = searchValue;
              this.get_peritioners();
        },
        get_peritioners() {
            let item ={
                page:1,
                perpage: 10000,
                category: "petitioner_list_for_tenant_users",
                matcher:{
                  "searchString":this.peritioners_search_value, 
                },
                "sorting": {
                  "path": "name",
                  "order": 1
                  }                
            };
            if([51].indexOf(this.getUserRoleId)>-1){
              item['category'] = "petitioner_list_for_beneficaries"
            }
            this.$store.dispatch("getMasterData", item).then(response => {
              this.all_peritioners =response.list;
                  if(this.checkProperty(this.$route ,'query' ,'filter')){
                    try{
                      let filter =this.$route['query']['filter']; this.checkProperty(this.$route ,'query' ,'filter')
                      var actual = JSON.parse(atob(filter));
                      let keys = Object.keys(actual);
                      if(this.checkProperty(keys ,'length') >0){
                          if(actual && (Object.keys(actual)).length>0 ){
                        _.forEach(actual ,(item ,key) => {
                            if(key=='matcher' ){
                                if((Object.keys(item)).length>0 ){
                                  if(_.has(item ,'petitionerIds')){  
                                    this.selected_peritioners = _.filter(this.all_peritioners ,(status)=>{
                                        return item['petitionerIds'].indexOf(status['_id'])>-1;
                                    })
                                  }
                                }
                            }
                      })
                  }              
              }
              }catch(e){
              }   
            }

        
      
            });
        },
        changedperitionersSearch() {
                  this.selected_peritioners = this.global_selected_petitioners
                  this.final_selected_peritioners = [];
                  if (this.selected_peritioners.length > 0) {
                    for (let i = 0; i < this.selected_peritioners.length; i++) {
                      this.final_selected_peritioners.push(
                        this.selected_peritioners[i]["_id"]
                      );
                    }
                  }
                  this.get_peritioners_beneficiaries();
                  this.set_filter();
        },
        changedperitioners() {
                  this.final_selected_peritioners = [];
                  if (this.selected_peritioners.length > 0) {
                    for (let i = 0; i < this.selected_peritioners.length; i++) {
                      this.final_selected_peritioners.push(
                        this.selected_peritioners[i]["_id"]
                      );
                    }
                  }
                  this.get_peritioners_beneficiaries();
        },
        changedsubtypes() {
                  this.selected_statusids =null;
                  this.final_selected_subtypes = [];
                  if (this.selected_subtypes.length > 0) {
                    for (let ind = 0; ind < this.selected_subtypes.length; ind++) {
                      let current_index = this.selected_subtypes[ind];
                      this.final_selected_subtypes.push(current_index["id"]);
                      if([15,16,17].indexOf(current_index['id'])>-1){
                        this.caseStatus(this.selected_subtypes);
                      }
                    }
                  }
                  
                  
        },
        get_peritioners_beneficiaries() {},
        changedVisaType(item, callFromUrl = false){
            // this.$router.push({ query: {} });
              this.selectedVisaType = item;
              if(!callFromUrl){
                this.final_selected_subtypes = [];
                this.selected_subtypes =[];
                this.selected_statusids =[];
              }
              this.all_subtypes = [];
          
              if(_.has(this.selectedVisaType , "id")){
                this.getvisa_subtypes();
              }
              this.caseStatus(this.selectedVisaType);
             // this.setQueryString()
        },
        upDateBenef(){

        if(this.checkProperty(this.selectedBeneficiary ,'name') && this.checkProperty(this.selectedBeneficiary ,'_id') ){
        this.selectedUser =this.checkProperty(this.selectedBeneficiary ,'_id');
        this.selectedUsername = this.checkProperty(this.selectedBeneficiary ,'name');
        }
        
        },
        getvisasubtypes(){
              this.visasubtype = null;
            let item ={
              matcher:{
              
                "petitionType":parseInt(this.visatype['id']),
                getActiveList:true,

              },   
              page:this.page,
              perpage: this.perpage,
              category: "petition_sub_types",
            
              
            };

            this.$store.dispatch("getMasterData",item ).then(response => {
              if(response['list']){
                this.visasubtypes = response['list']
              
              }
              });
            this.$validator.reset();
          this.caseStatusList(this.visatype['id'])
        },
        caseStatusList(data){ 
          let item = data
      let postData = {

        "matcher": { 
          "searchString":"",
          "tenantId": "",
          "branchId": "",
          "getWorkFlowConfig": false,
          "getCasenoCodeConfig": false,
          "tenantCustomId": "",
          "petitionTypes": [],
          "getInactiveListAlso": false,
          "caseType": "h1b"
        },
          "category": "case_status",
          "page": 1,
          "perpage": 25,
          "sorting": {    
            "path": "name",
            "order": 1
        }
      }
      if(item ==1){
       
        postData['matcher']['caseType'] = "h1b"
      }
      if(item ==2){
        postData['matcher']['caseType'] = "h4"  
      }
      if( item ==3){
        postData['matcher']['caseType'] = "gc"  
      }
      if(item == '' || item == null ){
        postData['matcher']['caseType'] = ""  
      }
        this.$store.dispatch("getMasterData",postData).then(response => {
          this.casesStatusList =response.list;
          this.caseStatusDetails = {id: 1,name: "Case Created",sortName: "case created",_id: "63da629612005d2008b4963b"}
           
        })
    }, 
        addNewCase(action=true){
          
          this.NewPetition =action;
          let self =this;
          this.caseStatusDetails = null;
          this.lawOfficeName = '';
          this.getvisaforNewCase();
          if(this.checkProperty(this.petitionerDetails ,'_id')){
            this.selectedPetitioner = this.petitionerDetails;
            this.selectedPetitioner =  Object.assign(this.selectedPetitioner ,{"userId":self.petitionerDetails['_id']})
          }
          if([50].indexOf(this.getUserRoleId) >-1){
          
            let userId =  this.checkProperty((this.getUserData ,'companyDetails' ,"_id"))
            let name =  this.checkProperty((this.getUserData ,'companyDetails',"name"))
            this.selectedPetitioner ={}
            this.selectedPetitioner  =  Object.assign(this.selectedPetitioner ,{"_id":userId})
            this.selectedPetitioner =  Object.assign(this.selectedPetitioner ,{"name":name})
            this.selectedBeneficiary =null;
              //this.getbeneficiaryMasterDataList();
            
          }
        
          if( this.NewPetition){
          this.$modal.show('newCaseCreationModal');

          }else{
          this.$modal.hide('newCaseCreationModal');
            //hide 
          }
          
          this.$validator.reset();

        },
        sortMe(sort_key=''){


    if(sort_key !=''){
        this.page = 1;
        this.sortKeys[sort_key] = this.sortKeys[sort_key]==1?-1:1
        this.sortKey ={};
        this.sortKey= {"path":sort_key,"order": this.sortKeys[sort_key] }

        localStorage.setItem('petitions_sort_key', sort_key);
        localStorage.setItem('petitions_sort_value', this.sortKey[sort_key]);
        this.getpetitions();
    }
        },
        getCategoryForCase(){
          let item ={
              matcher:{
              
              },   
              page:this.page,
              perpage: 10000,
              category: "case_category",  
          };
          this.$store.dispatch("getMasterData",item ).then(response => {   
            this.categoryList = response.list;   
          
          });
        },
        getvisatypes(){
          this.$store.dispatch("getvisatypes").then(response => {
            this.visaTypes = [];
            _.forEach(response ,(item)=>{
                        this.visaTypes.push(item)
              });
                this.activeVisatypes = response
            
          });
          
        },
        getvisa_subtypes() {
            
            if(this.selectedVisaType && _.has(this.selectedVisaType ,"id")){
              
            
            let item = {
              matcher: {
                getAllSubTypes:false,
                searchString: '',
                petitionType: parseInt(this.selectedVisaType['id']),
                getWorkFlowConfig: false,
              },
              page: 1,
              perpage: 1000,
              category: "petition_sub_types",
              "sorting": {
                  "path": "name",
                  "order": 1
                  }
            };

            if(this.selectedVisaType['id'] =='ALL'){
              item['matcher']['petitionType'] =null;
              item['matcher']['getAllSubTypes'] =true;
            }

            this.$store.dispatch("getMasterData", item).then((response) => {
              this.all_subtypes = response.list;
              //this.filterQueryPreSelect();
            
            });
            }
        },
        getVisaTypes(){
              let item ={
                    matcher:{
                        "searchString":'',
                        getWorkFlowConfig:true
                      // "petitionType":

                    },   
                    page:this.page,
                    perpage: this.perpage,
                    category: "petition_types",
                  "sorting": {
                      "path": "name",
                      "order": 1
                      }
                    
                  };

                  this.$store
                    .dispatch("getMasterData",item )
                    .then(response => {
                      this.visaTypes = [];

                      _.forEach(response.list ,(item)=>{
                        this.visaTypes.push(item)
                      });
                      //this.filterQueryPreSelect();
                    });
        },
        init(){
          let postData ={}
          this.configurationDetails =null
          this.$store.dispatch("commonAction", {data:postData,path:'global-config/details'})
          .then((response) =>{ 
            if(this.checkProperty(response ,"config") && !this.checkProperty(response ,'config','isAllowExternalCases')){ 
              this.showToster({ message: "You do not have access permissions.", isError: true });
              setTimeout(()=>{
                this.$router.push('/dashboard')
              },5)
            }
          })
        }
  },
  mounted() { 
    if(this.$route.params && this.$route.params.openCreatePopup ){
        this.selectedBeneficiary =null 
        this. selectedPetitioner=null 
        var _s = this;
        setTimeout(function(){
          _s.addNewCase(true)
        },600)
    }
    this.init()
    //this.getpetitions();
    this.caseStatus();  
    this.getvisatypes();
    this.getvisa_subtypes();
    this.get_peritioners();
    this.getLawOfficeList();
    this.username = this.$store.state.user.name;
    this.sortKeys = {
      'statusName':1,
      'lawOfficeName':1 , 
      'createdOn':1,
      'updatedOn':1,
      'beneficiaryName':1,
      'petitionerName':1,
      'caseNo':1,
      'createdByName':1,
      'typeName':1
    };
    this.getbeneficiaryMasterDataList();
    this.getVisaTypes();  
    this.currentuserRole = this.$store.state.user.loginRoleId;
    this.$store.dispatch("getcountries").then(response => {
      this.countries = response;
    });
    this.selected_statusids = [];
    this.final_selected_statusids = [];
    this.seleted_states = [];
    this.final_selected_states = [];
    this.seleted_locations = [];
    this.final_selected_locations = [];   
    this.filterQueryPreSelect(true);
    if(this.checkProperty(this.beneficiaryInfo ,"name")){
        this.selectedUser = this.beneficiaryId;
        this.selectedUsername =this.beneficiaryInfo['name']
    }
  },
  computed:{
    checkEnableSelectAll(){
      let returnVal =false;
      let activeItems = _.filter(this.petitioners ,(item)=>{
        return this.checkProperty( item ,'status') !=false
    });
    if(activeItems && this.checkProperty(activeItems ,'length')>0){
      returnVal =true;
    }
      return returnVal;
    }
  }
}
</script>