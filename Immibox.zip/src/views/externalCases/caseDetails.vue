<template>
    <div class="main-tabs-content"
       :class="{ 'petetion__details_full_width': !loadedFromPreview, 'anonymouslogin': !checkCurrentUrl }">
       <div class="tabs-layout-header cpr_heading" v-if="!loadedFromPreview">
 
          <div class="case-no-panel">
             <div class="casenumber_sec">
                <div class="case_number">
                   <div class="d-flex align-items-center">
                      Case No
                   </div>
                   <span>{{ checkProperty(petition, "caseNo") }}
                   </span>
                    <i class="material-icons"
                      v-if="!loadedFromPreview && checkCurrentUrl && checkProperty(petitions, 'length') > 0">arrow_drop_down</i>
                </div>
                 <div class="case_number_list"
                   v-if="!loadedFromPreview && checkCurrentUrl && checkProperty(petitions, 'length') > 0">
                   <VuePerfectScrollbar class="scroll-area">
                      <ul v-if="petitions">
                         <li @click="petetionChange(petition._id)" v-for="(petition, index) in petitions" :key="index">{{
                            petition.caseNo }}
                         </li>
                      </ul>
                   </VuePerfectScrollbar>
                </div>
             </div>
          </div>
          <externalCaseProcess ref="process_flow" v-bind:petition="petition" @updatepetition="reloadPetition"
          @assignLawOffice="assignLawOffice" @assignTo="assignTo" @updateStatus="updateStatus"
            @download_or_view="download_or_view" :loadedFromPreview="loadedFromPreview" />
       </div>
 
       <div class="main-tabs-content tabs_mob petetion__details_page  petetion__details_full_width">
          <div class="
               tabs-content
               detail_page_sec
               petetion__details
               case-details-box-width
              petetion__details_full_width">
             <section class="petition__details_section cap_page"
                :class="{ 'cap_page_full': checkCurrentUrl && !loadedFromPreview && [50, 51].indexOf(getUserRoleId) > -1 }">
                <div class="pd_left">
                   <ul>
                      <li :class="{
                         current_child: getPetitionTab == 'Case Details',
                      }" @click="setActivetab('Case Details', true)">
                         <a>Documents </a>
                      </li>
                      <li :class="{
                         current_child: getPetitionTab == 'notes',
                      }" @click="setActivetab('notes', true)">
                         <a>Notes </a>
                      </li>
                     
                   </ul>
                </div>
              
                <div class="pd_right petition__details_cnt">
                   <div class="pd_right_cnt">
                      <template>

                         <div v-if="getPetitionTab == 'Case Details'">
                            <template>
                               <div class="pad20">
                                    <externalCaseDocs  ref="externalCaseDocsref" :visastatuses="visastatuses" @download_or_view="download_or_view" @updatepetition="reloadPetition"
                                    :petition="petition" @getcaseHistory="getcaseHistory"></externalCaseDocs>
                                </div>
                            </template>
                         </div>
                         <div v-if="getPetitionTab === 'notes'">
                           <notes
                           @download_or_view="download_or_view"
                           @updatepetition="reloadPetition"
                           v-bind:petitionDetails="petition"
                           :loadedFromPreview="loadedFromPreview"
                           :callFromExternal="true"
                           />
                        </div>
                      </template>
 
                      <div>
 
                      </div>
                   </div>
 
                </div>
             </section>
             <div vs-type="flex" class="padr0 padl0 mob-right activies_list_wrap status_wrap cap_activies_list_wrap"
                v-if="!loadedFromPreview && checkCurrentUrl && [50, 51].indexOf(getUserRoleId) <= -1">
                <ul v-if="checkCurrentUrl && !loadedFromPreview">
                   <li class="ptstatusBar " v-if="[50, 51].indexOf(getUserRoleId) < 0">
                      <div class="status_activities" style="justify-content:center">
                         <label class="active">Activities </label>
                      </div>
                   </li>
                </ul>
                <div class="history-sidebar petition_history activies_list cap_details_activies_list">
                   <div class="vs-sidebar">
                      <div class="petition_updated" v-if="petitionhistory.length == 0">
                         Last Updated -
                         {{ checkProperty(petition, "updatedOn") | formatDateTime }}
                      </div>
                      <div class="petition_updated" v-if="petitionhistory.length > 0">
                         Last Updated - {{ petitionhistory[0].createdOn | formatDateTime }}
                      </div>
 
                      <div class="vs-sidebar--items">
                         <VuePerfectScrollbar class="scroll-area">
                            <div class="timeline-sidebar 2">
                               <ul>
                                  <li v-for="(history, index) in petitionhistory" :key="index">
                                     <div class="timeline-icon">
                                        <i class="icon IP-tick-sign"></i>
                                     </div>
                                     <div class="timeline-info">
                                        <button class="btn active-green ml-0">
                                           {{ history.createdByRoleName }}
                                        </button>
                                        <ul>
                                           <li>
                                              <h3><span>
                                                    {{ history.title }}
                                                 </span>
                                                 <div v-if="
                                                    history.comment && history.comment != ''
                                                 " class="title_des">
                                                    <small></small>
                                                    <div class="dec-content">
                                                       <p v-html="history.comment"></p>
                                                    </div>
                                                 </div>
                                              </h3>
 
                                              <span>{{ history.description }}</span>
                                              <span>{{
                                                 history.createdOn | formatDateTime
                                              }}</span>
 
                                              <p class="m-0"
                                                 v-if="checkProperty(history, 'documents', 'length') > 0"
                                                 >
                                                 
                                                    <ul class="activities_doc_list">
                                                    <template v-for="(doc,indoc) in history['documents']" >
                                                      <li class="cursor-pointer" @click="download_or_view(doc)" >
                                                       <docmentType :title="checkProperty(doc, 'name')" :item="doc" />
                                                      </li>
                                                    
                                                   </template>
                                                   </ul>
                                              </p>
                                           </li>
                                        </ul>
                                     </div>
                                  </li>
                               </ul>
                            </div>
                         </VuePerfectScrollbar>
                      </div>
                   </div>
                </div>
 
 
 
             </div>
          </div>
       </div>
       <vs-popup class="document_modal document_modal-v2"
       :class="{ expand: expandModal }"
        :title="checkProperty(selectedFile, 'name')" :active.sync="docPrivew">
        <div class="document_actions" @click="expandModal = !expandModal">
      <figure v-if="!expandModal" class="maximize-img"><img src="@/assets/images/maximize.png"  width="18" height="18"/></figure>
      <figure v-else class="minimize-img"><img src="@/assets/images/minimize.png"  width="20" height="20"/></figure>
    </div>
          <h2> <img :class="{
             pdf_view_download: docType == 'pdf',
             office_view_download: docType == 'office',
             image_view_download: docType == 'image',
          }" class="download-button" @click="downloads3file(selectedFile)" src="@/assets/images/download.svg" /></h2>
 
          <div class="pdf_loader">
             <figure v-if="formSubmited" class="loader loader2"><img src="@/assets/images/main/loader.gif" /></figure>
 
             <!-- <span :class="{'pdf_view_close':docType == 'pdf', 'office_view_close':docType == 'office'  , 'image_view_close 33':docType =='image'}" class="close close2" @click="docPrivew= false"></span> -->
             <template v-if="docType == 'office'">
                <div style="height:90vh">
 
                   <div id="placeholder" style="height:100%"></div>
                </div>
             </template>
             <template v-else-if="docType == 'image'">
                <img :src="docValue" />
             </template>
             <template v-else-if="docType == 'pdf'">
                <div class="pdf" style="height:90vh">
 
                   <iframe v-if="docValue != ''" border="0" style="border:0px;" :src="docValue" height="100%" width="100%">
 
                   </iframe>
                </div>
             </template>
          </div>
       </vs-popup> 
       <assignLawOffice
            @updatepetition="reloadPetition"
            :petitionDetails="petition"
            @hideMe="assignLawOfficeModal = false"
            v-if="assignLawOfficeModal"
        />
        <assignToPopup
            @updatepetition="reloadPetition"
            :petitionDetails="petition"
            @hideMe="assignToModal = false"
            v-if="assignToModal"
        />
        <updateStatus
            @updatepetition="reloadPetition"
            :petitionDetails="petition"
            @hideMe="updateStatusModal = false"
            v-if="updateStatusModal"
        />
 
    </div>
 </template>
 
 <script>
 import Vue from 'vue';
 Vue.use(CKEditor);
 import CKEditor from '@ckeditor/ckeditor5-vue2';
 import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
 import docmentType from "@/views/common/docType.vue"
 import VuePerfectScrollbar from "vue-perfect-scrollbar";
 import capCaseUpdates from "@/views/cap/capCaseUpdates.vue";
 import externalCaseProcess from "@/views/externalCases/externalCaseProcess.vue";

 import externalCaseDocs from "@/views/externalCases/externalCaseDocs.vue";
 import assignLawOffice from "@/views/externalCases/assignLawOffice.vue"; 
 import assignToPopup from "@/views/externalCases/assignToPopup.vue";
 import updateStatus from "@/views/externalCases/updateStatusPopup.vue";
 import notes from "@/views/notes.vue";
 import educationInfo from "@/views/petition/subtabs/educationsVersion2.vue";
 import personalInfo from "@/views/cap/capPersonalDetails.vue";
 import immiInput from "@/views/forms/fields/simpleinput.vue";
 import immitextarea from "@/views/forms/fields/simpletextarea.vue";
 import selectField from "@/views/forms/fields/simpleselect.vue";
 import FileUpload from "vue-upload-component/src";
 import axios from '@/axios.js';
 export default {
    provide() {
       return {
          parentValidator: this.$validator,
       };
    },
    data: () => ({
      expandModal: false,
        petitionDetails:null,

       editor: ClassicEditor,
       editorConfig: {
          toolbar: ['bold', 'italic', '|', 'undo', 'redo', 'NumberedList', 'BulletedList',],
       },
       petitionhistory: [],
       formSubmited: false,
       selectedFile: '',
       docValue: "",
       docPrivew: false,
       docType: false,
       petitions: [],
       currentRole: null,
       setTab: false,
       visastatuses: [],
       getPetitionTab: null,
       petitionId: null,
       petition: null,
       ///////////////////////////
       activeTab: 'caseUpdate',
       routeId: '',
       routeQuery: '',
       linkShareToemailsText: "",
       users: [
          {
             "id": "B-1",
             "name": "24 September 2013",
             "email": "12 June 2013",
          },
          {
             "id": "H-1B",
             "name": "08 March 2017",
             "email": "18 January 2014",
          }
       ],
       USCISstatus: [
          { "name": 'Selected', 'id': 'Selected' },
          { "name": 'Not Selected', 'id': 'Not Selected' },
          { "name": 'Denied', 'id': 'Denied' },
          { "name": 'Invalidated-Failed Payment', 'id': 'Invalidated-Failed Payment' }
       ],
       casetype: [
          { "name": 'H-1B', 'id': 'H-1B' }
       ],
       casesubtype: [
          { "name": 'Master Cap - Consular Processing', 'id': 'Master' },
          { "name": 'Regular Cap - Consular Processing', 'id': 'Regular' }
       ],
       branchList: [
          { "name": 'Head Office', 'id': 'Head Office' }
       ],
       PetitionerList: [
          { "name": 'Berkshare LLP', 'id': 'Berkshare LLP' }
       ],
       BeneficiaryList: [
          { "name": 'Wasim Pathan', 'id': 'Wasim Pathan' }
       ],
 
 
       SubmitParalegal: false,
       SuccessQuestionnaire: false,
       branchvalue: { "name": 'Head Office', 'id': 'Head Office' },
       Petitionervalue: { "name": 'Berkshare LLP', 'id': 'Berkshare LLP' },
       Beneficiaryvalue: { "name": 'Wasim Pathan', 'id': 'Wasim Pathan' },
       assignLawOfficeModal:false,
       assignToModal:false,
       updateStatusModal:false,
 
    }),
    components: {
      notes,
       docmentType,
       VuePerfectScrollbar,
       capCaseUpdates,
       externalCaseProcess,
       assignLawOffice,
       assignToPopup,
       updateStatus,
       externalCaseDocs,
       //ProcessFlow,
       personalInfo,
       educationInfo,
       immiInput,
       FileUpload,
       selectField,
       immitextarea
    },
    methods: {
       loadPetetion(tab = "") {
          let paylaod = {
            externalId: ''
          }
          if (this.petition == null) {
            this.$vs.loading();
         }
          let path = '/external-cases/details'
          paylaod['externalId'] = this.petitionId
          
          this.$store.dispatch("commonAction", { "data": paylaod, "path": path })
             .then((response) => {
               this.$vs.loading.close();
               this.petition = null;
                this.petition = response;                
              //  this.$store.dispatch("setPetitionData", { petitionDetails: this.petition,  lcaDetails: null, workFlowDetails: null,});
                
              
                this.petitions =[];
                if (this.checkProperty(this.petition, "userId")) {
                   let postdata = {
                      matcher: { rfeCases: true, getMasterDataOnly: true, beneficiaryIds: [], },
                      "page": 1,
                      "perpage": 100
                   }
                   postdata['matcher']['beneficiaryIds'].push(this.petition['userId']);
                  
                   
                   this.$store.dispatch("getList", { data: postdata, path: '/external-cases/list', }).then((response) => {
                      this.petitions = response['list'];
                   });
                }
                this.setActivetab('Case Details', true);
                this.getcaseHistory();
                this.$refs['externalCaseDocsref'].processDocuments();
             }).catch((err) => {
               this.$vs.loading.close();
             })
       },
       setActivetab(stab = "Case Details", callFromClick = false) {
          if (!stab) {
             stab = "Case Details";
          }
          if(stab){
            this.getPetitionTab = null;
            this.getPetitionTab = stab
          }
         
 
       },
       reloadPetition(tab = "Case Details") {
          if (tab != "") {
          
             this.$store.dispatch("setPetitionTab", tab)
                .then(() => {
 
                   this.init(tab);
                })
                .catch((err) => {
 
                   this.init();
                });
          } else {
             this.$store.dispatch("setPetitionTab", "Case Details");
             this.init();
          }
       },
       getcaseHistory() {
          if (this.petitionId) {
          
             let postData = {
                "externalId": '', "page": 1,
                "perpage": 500
             };
             postData['externalId'] = this.petitionId;
 
             this.$store
                .dispatch("getList", {
                   data: postData,
                   path: '/external-cases/activity-list',
                }).then((response) => {
 
                   this.petitionhistory = response['list'];
                });
 
          }
 
 
       },
       init(tab = '') {
          //this.updatePetiotionActionBtn(false);
          this.currentRole = this.$store.state.user.loginRoleId;
          this.currentUserId = this.$store.state.user._id;
          this.loadPetetion(tab);
          this.$store.dispatch("getmasterdata", "visa_status").then((response) => {
             this.visastatuses = response;
          });
       },
       petetionChange(id) {
          this.setActivetab("Case Details", true);
          this.petition = null;
          this.petitionId = id;

          setTimeout(() => {
                   this.init();
                }, 5);
                setTimeout(() => {
                   this.init();
                }, 5);
          
          this.updateUrl();
       },
       updateUrl() {
            this.$route["params"]["itemId"] = _.cloneDeep(this.petitionId);
      },
       download_or_view(docItem) {
 
 
          let value = _.cloneDeep(docItem);
          this.expandModal= false;
         //  if (this.checkProperty(this.getPetitionDetails, 'caseNo') && this.checkProperty(value, 'name')) {
         //     let docName = _.cloneDeep(value['name']);
         //     value['name'] = this.checkProperty(this.getPetitionDetails, 'caseNo') + "_" + docName;
         //  }
          let docName = _.cloneDeep(value['name']);
             value['name'] = docName;
 
 
          var _self = this;
          this.formSubmited = false;
          if (_.has(value, "path")) {
             value["url"] = value["path"];
             value["document"] = value["path"];
          }
 
          if (_.has(value, "url")) {
             value["path"] = value["url"];
             value["document"] = value["url"];
          }
 
          if (_.has(value, "document")) {
             value["path"] = value["document"];
             value["url"] = value["document"];
          }
          value = Object.assign(value, { 'petitionId': this.petition['_id'] })
          value = Object.assign(value, { 'subTypeDetails': this.petition['subTypeDetails'] })
 
 
          this.selectedFile = value;
          this.docValue = "";
          this.docPrivew = false;
          this.docType = false;
          this.docType = this.findmsDoctype(value);
 
          if ((this.docType == "office" || this.docType == "image" || this.docType == "pdf")) {
             //if ( (this.docType == "office" || this.docType == "image" || this.docType == "pdf") && value.download == false ) {
             value.url = value.url.replace(this.$globalgonfig._S3URL, "");
             value.url = value.url.replace(this.$globalgonfig._S3URLAWS, "");
             let postdata = {
                keyName: value.url,
                "petitionId": value['petitionId'],
 
                // entityType:value['petitionId']
                // "fileName":value.name?value.name:''
             };
             if (this.checkProperty(value, 'subTypeDetails', 'id') == 15) {
                postdata['entityType'] = 'perm'
             } else {
                postdata['entityType'] = 'case'
             }
 
 
             this.$store.dispatch("getSignedUrl", postdata).then((response) => {
                this.docValue = response.data.result.data;
 
                if (this.docType == "office") {
                   document.getElementById("placeholder").innerHTML = "  <div  id='placeholder2' style='height:100%'></div>";
                   let _editing = true;
 
                   if ([50, 51].indexOf(this.getUserRoleId) > -1) {
                      _editing = false;
                   }
 
                   if (value.viewmode) {
                      _editing = false;
                   }
                   var _ob = {}
                   if (value.editedDocument) {
                      _ob = {
 
                         petitionId: this.petition._id,
                         name: value.name,
                         _id: value._id,
                         "extn": "docx",
                         "formLetterType": "Letter",
                         parentId: value.parentId
                      }
 
                   } else {
 
                      _ob = {
 
                         name: value.name,
                         petitionId: this.petition._id,
                         _id: value._id,
                         "extn": "docx",
                         "formLetterType": "Letter",
                         parentId: value._id
 
                      }
 
                   }
 
 
                   window.docEditor = new DocsAPI.DocEditor("placeholder2",
                      {
 
                         "document": {
                            "c": "forcesave",
                            "fileType": "docx",
                            "key": value._id,
                            "userdata": JSON.stringify(_ob),
                            "title": value.name,
                            "url": response.data.result.data,
                            permissions: {
                               edit: _editing,
                               download: true,
                               reader: false,
                               review: false,
                               comment: false
                            }
                         },
 
                         "documentType": "word",
                         "height": "100%",
                         "width": "100%",
 
                         "editorConfig": {
                            "userdata": JSON.stringify(_ob),
                            "callbackUrl": "https://immibox.com/api/perm/post-edited-document?payload=" + JSON.stringify(_ob) + "&token=" + _self.$store.state.token + "&name=" + value.name.replace('.docx', ''),
                            "customization": {
                               "logo": {
                                  "image": "https://immibox.com/app/favicon.png",
                                  "imageDark": "https://immibox.com/app/favicon.png",
                                  "url": "https://immibox.com"
                               },
                               "anonymous": {
                                  "request": false,
                                  "label": "Guest"
                               },
                               "chat": false,
                               "comments": false,
                               "compactHeader": false,
                               "compactToolbar": true,
                               "compatibleFeatures": false,
                               "feedback": {
                                  "visible": false
                               },
                               "forcesave": true,
                               "help": false,
                               "hideNotes": true,
                               "hideRightMenu": true,
                               "hideRulers": true,
                               layout: {
                                  toolbar: {
                                     "collaboration": false,
                                  },
                               },
                               "macros": false,
                               "macrosMode": "warn",
                               "mentionShare": false,
                               "plugins": false,
                               "spellcheck": false,
                               "toolbarHideFileName": true,
                               "toolbarNoTabs": true,
                               "uiTheme": "theme-light",
                               "unit": "cm",
                               "zoom": 100
                            },
                         }, events: {
                            onReady: function () {
 
                            },
                            onDocumentStateChange: function (event) {
                               var url = event.data;
                               if (!event.data) {
 
                                  if (value.editedDocument) {
 
                                  }
 
                               }
                            }
 
                         }
                      });
                   //this.docValue = encodeURIComponent(response.data.result.data);
                }
 
                if (this.docType == "pdf") {
 
                   // this.downloadFile(this.docValue, value.mimetype, value.name)
 
                   // return
                   var _vid = value._id;
                   if (value.parentId) {
                      _vid = value.parentId;
                   }
                   var viewmode = 1; // Enable edit
                   viewmode = 0; //Disabled Edit
                   if (value.viewmode) {
                      viewmode = 0;
                   }

                   let pdfViewUrl ='https://immibox.com/viewer/pdfjs-dist/web/viewerv2.html';            
                  if(_.has(this.$globalgonfig, 'PDF_VIEW_URL')){
                     pdfViewUrl = this.$globalgonfig['PDF_VIEW_URL']; //PDF_EDIT_URL
                  }
                  if(viewmode==1){
                     if(_.has(this.$globalgonfig, 'PDF_EDIT_URL')){
                      pdfViewUrl = this.$globalgonfig['PDF_EDIT_URL'];
                     }
                  }


                   this.docValue = pdfViewUrl+"?view=" + viewmode + "+&file=" + encodeURIComponent(response.data.result.data);
                }
                 this.docPrivew = true;
             });
          } else {
 
 
 
             this.downloads3file(value);
          }
 
       },
 
       downloadFile(url, mimetype, fireName) {
          axios({
             url: url,
             method: 'GET',
             responseType: 'blob',
          }).then((res) => {
             var FILE = window.URL.createObjectURL(new Blob([res.data], { type: mimetype }));
 
             var docUrl = document.createElement('x');
             docUrl.href = FILE;
             docUrl.setAttribute('download', fireName);
             document.body.appendChild(docUrl);
             docUrl.click();
          });
       },
       assignLawOffice(action = false) {
            this.assignLawOfficeModal = action;
        },
        assignTo(action = false) {
            this.assignToModal = action;
        },
        updateStatus(action = false){
            this.updateStatusModal = action;
        },
        checkAccess(){
          let postData ={}
          this.configurationDetails =null
          this.$store.dispatch("commonAction", {data:postData,path:'global-config/details'})
          .then((response) =>{ 
            if(this.checkProperty(response ,"config") && !this.checkProperty(response ,'config','isAllowExternalCases')){ 
              this.showToster({ message: "You do not have access permissions.", isError: true });
              setTimeout(()=>{
                this.$router.push('/dashboard')
              },5)
            }
          })
        }
       

 
    },
    mounted() {
      this.checkAccess();
       if (this.$route.params && this.$route.params.itemId) {
          this.petitionId = this.$route.params.itemId;
          if (this.loadedFromPreview && this.previewData) {
             this.setActivetab('Case Details', true);
             this.petition = _.cloneDeep(this.previewData);
          } else {
             this.init();
          }
       }
       //this.loadPetetion();
    },
    props: {
       loadedFromPreview: false,
       previewData: null,
    },
    computed: {
       checkCaseStatus() {
          if (this.checkProperty(this.petition, 'intStatusDetails', 'id') == 1) {
             return this.checkProperty(this.petition, 'intStatusDetails', 'id')
          }
          else {
             return 4
          }
       },
       checkCaseCreatedLogin() {
          let returnVal = true
          let createdBy = null;
          if (this.petition && this.checkProperty(this.petition, 'createdBy')) {
             createdBy = this.checkProperty(this.petition, 'createdBy')
             if (this.checkProperty(this.getUserData, 'userId') && (createdBy == this.checkProperty(this.getUserData, 'userId'))) {
                returnVal = true
             } else {
                returnVal = false
             }
          }
          return returnVal
       }
    }
 }
 </script>