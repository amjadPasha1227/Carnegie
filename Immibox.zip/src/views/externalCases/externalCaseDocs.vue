<template>
    <div>
        <template >
                <div class="main-list-wrap" >
                      <div class="tab-inner-content pad0 pt-0 pb-2">

                        <div :class="{'pad20':!checkCurrentUrl}" >
                          <div class="doc_header pt-0" >
                            <h3 class="small-header mart25"  >
                            
                            </h3>
                            
                            <div class="d-flex">  
                               <button  @click="openEditDocs(true)" class="edit-doc"> <img src="@/assets/images/main/icon-edit.svg" />Upload Documents</button>        
                              <button v-if="checkProperty(petition,'documents') && checkProperty(petition,'documents','length')>0"  @click="downloadallfile();prepopulateSavedDocs();showRestore()" class="download_all">Download Documents </button>
                            </div>
                            
                          </div>
                          <!-- v-if="todalDocumentsCount>0" -->
                            <template v-if="petition" >
                          <div :key="docs" v-for="(type,docs) in  processedCaseDocs" >
                            <!-- v-if="docs !='beneficiaryDocs' && type && (type.length > 0 || ((currentRole ==50 || currentRole == 51) && petition.documentsUploadEnabled )) && checkDocumentsExists(type) "  -->
                            <vs-row >
                            
                              <vs-col class="padl0 padr0">
                                <div class="card-panels pad0">
                                  <vs-card>
                                    <div slot="header" >
                                      <h3>{{docs}}</h3> 
                                    </div>
                                    <div>
                                      <div>
                                        <template v-for="(item ,ind ) in  type">
                                    
                                          <div class="documents__list"   v-bind:key="ind">
                                            <div class="documents__title"  @click="downloadfile(item)">
                                              <figure> 
                                                <img v-if="checkFileFormat(item['mimetype']) =='pdf'" src="@/assets/images/main/pdf.svg" /> 
                                                <img v-else-if="checkFileFormat(item['mimetype']) =='video_mime_types'" src="@/assets/images/main/film.png" />
                                                <img v-else-if="checkFileFormat(item['mimetype']) =='msDoc'" src="@/assets/images/main/doc.svg" />
                                                <img v-else-if="checkFileFormat(item['mimetype']) =='zip'" src="@/assets/images/main/zip-file-format.png" />
                                                <img v-else-if="checkFileFormat(item['mimetype']) =='msPpt'" src="@/assets/images/main/ppt.svg" />
                                                <img v-else-if="checkFileFormat(item['mimetype']) =='msXl'" src="@/assets/images/main/xls.svg" />
                                                <img v-else-if="checkFileFormat(item['mimetype']) =='image'" src="@/assets/images/main/image.svg" />
                                                <img v-else src="@/assets/images/main/icon-img.svg" />
                                              </figure>
                                              <span>
                                               
                                                <em class="fl_scanned_docs" :title="item.name">{{item.name}}</em>
                                                <small class="uploaded_doc_small" v-if="!loadedFromPreview"> 
                                                  <p><span v-if="getformated(item)"> {{ getformated(item) }}</span><span v-if="checkProperty(item,'uploadedByName')"> - Uploaded By {{ item['uploadedByName']}} <em v-if="checkProperty(item,'uploadedByRoleName')">({{ item['uploadedByRoleName'] }})</em></span></p>
                                                </small>
                                              
                                              </span>
                                            </div>
                                            <div class="documents__actions">
                                              <button @click="removethis(ind ,type)" v-if="checkProperty( item, 'tempDoc')==true" class="view-btn">Remove</button>
                                              <button v-else @click="downloadfile(item,false,true)" class="view-btn">View</button>
                                            </div>
                                          </div>
                                        </template>
                                      </div>
                                    </div>
                                  </vs-card>
                                </div>
                              </vs-col>
                            </vs-row>
                          </div>
                            </template>
                            <!-- v-if="(todalDocumentsCount<=0  )" -->
                          <NoDataFound :loading="false" ref="NoDataFound" v-if="checkProperty(petition,'documents','length')<=0"  :update_loading="updateNodataLoading()"   content=""  heading="No Documents Found." type='documents'   />
                        </div>
                      </div>
                </div>
        </template>
    
    
       <vs-popup class="Change_petition_wrap " :class="{'no_close':disable_uploadBtn}" :title="'Upload Documents'" :active.sync="fileuploadPopup">
        <form data-vv-scope="documentUploadForm" @submit.prevent @keydown.enter.prevent>
            <div class="Change_petition" @click="formerrors.msg=''">
                <div class="vx-col w-full marb10">
                    <immiInput :display="true" :tplkey="''" :fieldsArray="[]"  :wrapclass="'w-1/2'" cid="docCategory" :formscope="'documentUploadForm'" v-model="docCategory" :tplsection="''"  :fieldName="'docCategory'"  :required="true"  label="Document Type"  placeHolder="Document Type" />
                        <div class="vx-row pt-5 ">
                            
                            <div class="vx-col w-full">
                                <label class="form_label">Documents<em>*</em></label>
                                <vx-input-group class="form-input-group select-upload-group">
                                    <div class="uploadsec_wrap">
                                        <div class="w-full">
    
                                            <div  @click="uploadMainDocuments=[]">
                                                <file-upload v-model="uploadMainDocuments"
                                                :accept="acceptedFiles" 
                                                 class="file-upload-input mb-0" style="height:50px; padding:0px;" :name="'pdocuments'" :multiple="true" :hideSelected="true" v-validate="'required'" label="Forms and Letters" data-vv-as="Forms and Letters"  @input="uploadToS3MainDocuments( uploadMainDocuments)">
                                                    <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                                                    Upload
                                                </file-upload>
                                                <span class="file-type mb-0">(File Type: PDF, DOC, JPEG, PNG. Max file size: 1MB)</span>
                                                <span class="text-danger text-sm" v-show="errors.has('pdocuments')">{{ errors.first('documents') }}</span>
                                            </div>
    
                                            <VuePerfectScrollbar class="scrollbardoc">
                                                <div class="uploded-files_wrap" v-if="uploadFinalMainDocuments && uploadFinalMainDocuments.length >0 ">
                                                    <div class="w-full" v-for="(fil, fileindex) in uploadFinalMainDocuments" :key="fileindex">
                                                       
                                                        <div class="uploded-files">
                                                            <vx-input-group class="form-input-group">
                                                                <vs-input v-on:keyup="filameChenged(fileindex)"  v-validate="'required'" class="w-full" :name="'fName'+fileindex" v-model="fil['name']" data-vv-as="File Name" />
                                                                <span class="text-danger text-sm" v-show="errors.has('fName'+fileindex)">{{ errors.first('fName'+fileindex) }}</span>
    
                                                                <div class="delete"  @click="remove(fil, uploadFinalMainDocuments ,fileindex)">
                                                                    <img src="@/assets/images/main/cross.svg" />
                                                                </div>
                                                            </vx-input-group>
                                                        </div>
                                                    </div>
                                                </div>
                                            </VuePerfectScrollbar>
                                        </div>
                                    </div>
                                </vx-input-group>
                            </div>
                        </div>
                    
                </div>
            </div>
            <!-----v-if="fuploder"-->
             <div class="text-danger text-sm formerrors" v-show="formerrors.msg" @click="formerrors.msg=''">
                <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
                  icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
              </div>
            <div  class="popup-footer relative" >
                <button @click="fileuploadPopup=false; fuploder=false" class="btn cancel">Cancel</button>
                <button class="btn save" v-bind:disble="disable_uploadBtn || uploadFinalMainDocuments.length<=0" @click="uploadBenDocuments()">
                    <figure v-if="fuploder" class="loader loader2"><img src="@/assets/images/main/loader.gif" /></figure>
                    Upload
                </button>
            </div>
          </form>
        </vs-popup>
    
        <div  class="custom_modal_sec documents__modal custom_modal-v2" :class="{ modalopen: downloadDocList }" >
            <div class="custom_modal_overlay"   ></div>
                <div class="custom_modal_cnt">
                    <div class="modal_title">      
                        <h2> Download Documents </h2>                
                         <span class="close" @click="$emit('closeMe');downloadDocList = false"><x-icon size="1.5x"></x-icon></span>
                    </div>
                    <div class="all_docs_header">
                    <ul>
                        <li :class="{'active':!isTrashDocument}" @click="toggleDownloadTab(false)">  Saved Documents </li>
                        <li :class="{'active':isTrashDocument}" @click="toggleDownloadTab(true)">Deleted Documents </li>
                    </ul>
                    <button  type="filled" class="restore_btn mb-1" v-if="(checkProperty(savedDocDetails,'length')>0 || $store.state.isDragged) && showDragged  && !isTrashDocument " @click="prepopulateSavedDocs(true);showRestore()">Restore</button>
                    </div>
                    <div class="all_docs_dragArea">
                   
                   <div class="all_doc_cnt" >
                       <template v-if="!isTrashDocument">
                           <template v-if="checkProperty(processedTaskDocs ,'length')>0">
                               <nested  @download_or_view="download_or_view" :isTrashDocument="isTrashDocument" :groupName="'g1'" :tasks="processedTaskDocs" :petitionDetails="petition"  v-if="!loadedFromPreview && downloadDocList" @downloadfile="download_or_view" v-bind:petition="petition" v-bind:loadedFromPreview="loadedFromPreview" />
                           </template>
                           <template v-if="checkSavedDocs">
                               <NoDataFound :loading="false" ref="NoDataFoundRef"  content=""  heading="No Documents Found." type='documents' />
                           </template>
                       </template>
                       <template v-if="isTrashDocument">
                           <template v-if="checkProperty(processedTaskDocs ,'length')>0">
                               <trashedDocuments @download_or_view="download_or_view" :groupName="'g2'" :isTrashDocument="isTrashDocument"  v-model="processedTaskDocs"  :petitionDetails="petition"  v-if="!loadedFromPreview && downloadDocList" @downloadfile="download_or_view" v-bind:petition="petition" v-bind:loadedFromPreview="loadedFromPreview" />
                           </template>
                       </template>
                   </div>
                   <div class="popup-footer relative all_doc_popup_footer">
                    <!-- @click=" openUploadPopup('otherMerge',null,true) -->
                       <!-- <button v-if="!isTrashDocument" :disabled="filesDownloading"  class="edit-doc upload_doc" @click="openEditDocs(true)" >Upload <img src="@/assets/images/main/upload.svg" /></button>  -->
                       <div class="d-flex">

                           
        
                       
                           
                       <button class="cancel" @click="$emit('closeMe');downloadDocList = false" type="filled" color="dark">Cancel</button>
                       
                       
                       <vs-button   @click="downloadAllDocuments()" v-if="checkProperty(processedTaskDocs ,'length')>0 && !isTrashDocument && !checkSavedDocs" 
                       :disabled="filesDownloading"                        
                           color="success"
                           class="marl15 save"
                           type="filled"
                          
                       >Download All</vs-button>
                       </div>
                       <span v-if="filesDownloading" class="loader"><img src="@/assets/images/main/loader.gif"></span>
                   </div>
               </div> 
                </div>       
         </div>
        </div>

    </div>
    </template>
    
    <style >
    .dragHead {
      background: #eceff3;
      border-radius: 4px 4px 0 0;
      padding: 6px 10px;
      color: #1d202c;
      font-size: 14px;
      font-family: "robotomedium";
      line-height: normal;
    }
    
    .subdragHead {
      padding: 6px 10px;
      color: #1d202c;
      font-size: 14px;
      font-family: "robotomedium";
      line-height: normal;
    }
    .dragNested {
      padding: 10px 20px;
    }
    .scrollbardoc {
      height: 400px;
    }
    </style>
    <script>
    import trashedDocuments from "@/views/trashedDocuments.vue";
    import nested from "@/views/nested.vue";
    import immiInput from "@/views/forms/fields/simpleinput.vue";
    import moment, { relativeTimeThreshold } from "moment";
    import casedocumentslist from "@/views/common/casedocuments.vue";
    import * as _ from "lodash";
    import draggable from "vuedraggable";
    import VuePerfectScrollbar from "vue-perfect-scrollbar";
    import NoDataFound from "@/views/common/noData.vue";
      import { XIcon } from 'vue-feather-icons'
    import FileUpload from "vue-upload-component/src";
    import caseQuestionnaireDocs from "@/views/forms/caseQuestionnaireDocs.vue";
    import downLoadCaseDocuments from "@/views/petition/downLoadCaseDocuments.vue";
    import Vue from 'vue';
    Vue.use( CKEditor );
    import CKEditor from '@ckeditor/ckeditor5-vue2';
    import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
    import JQuery from "jquery";
    import { formatDate } from "tough-cookie";
    export default {
       provide() {
            return {
                parentValidator: this.$validator,
            };
        },
      components: {
        trashedDocuments,
        nested,
        immiInput,
        downLoadCaseDocuments,
        caseQuestionnaireDocs,
        draggable,
        FileUpload,
        VuePerfectScrollbar,
        NoDataFound,
        casedocumentslist,
        XIcon
      },
      data() {
        return {
          savedDocDetails:[],
          isTrashDocument:false,
          processedTaskDocs:[],
          processedTaskDocsTemp:[],
          processedCaseDocs:null,
            docCategory:'',
          acceptDocs:[],
          documensUpdating:false,
          offerDocuments:{
            slgOfferLetter:[],
            slgSignedOfferLetter:[],
          },
          benOfferDocslist:[
          {
              required: false,
              fieldName: 'slgSignedOfferLetter',
              key: "slgSignedOfferLetter",
              label: "Signed Offer Letter"
            },
          ],
          offerDocslist:[
            {
              required: false,
              fieldName: 'slgOfferLetter',
              key: "slgOfferLetter",
              label: "Unsigned Offer Letter"
            },
            {
              required: false,
              fieldName: 'slgSignedOfferLetter',
              key: "slgSignedOfferLetter",
              label: "Signed Offer Letter"
            },
          ],
          allChildrens:[],
          testVariable:[],
          childsObject:[],
          benChildsObject:[],
          showConetent1:false,
          showConetent2:false,
          showConetent3:false,
          editor: ClassicEditor,
          editorConfig: {
              toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
          },
          savedDocumentsList:[],
          isDocumentsAreSaved:false,
          documentActiveTab:'savedDocuments',
          editDocuments:false,
           documents: {
            birthCertificate:[],
            passportVisaI94: [],
            passport: [],
            resume: [],
            education: [],
            expLetters: [],
            INSNotices: [],
    
            formI20: [],
            I797NoticeofApprovalforI140:[],
            socialSecurityCardAndProfLicense: [],
            I140ApprovalNotice: [],
            payStubs: [],
            offerLetter: [],
    
            clientLetter: [],
            vendorLetter: [],
            ead: [],
            msa: [],
            po: [],
            h1bRegSelectionNotice: [],
            employmentAgreement: [],
            primeVendor: [],
            formI94: [],
            priorFormI797: [],
            other: [],
          },
          documentTypes:{
            "beneficiary":{},
            "spouse":{},
            "child":{}
          },
          itemSlength:0,
           downloadDocList: false,
           acceptedFiles:"image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document",
          filesDownloading:false,
          lockUnlockformerrors:'',
          color: "#000",
          downloadDocumentPop: false,
          documentsUpload: true,
          lockDocumentsPopup: false,
          lockDocumentsPopupTitle: "",
          uploaddocType: "",
          profilePicture: [],
          petitiondocuments: {},
          
          petitiondocumentsl: [],
          petitiondocumentr: [],
          childernDocuments:[],
          is_enablesavebtn: false,
    
          errorMessage:'',
          fileuploadPopup:false,
          documentUploaded:[],
          activeTabName:'Documents',
          disable_uploadBtn:false,
          fuploder:false,
           formerrors: {
            msg: ""
          },
          selectedDocsForApprove:[],
          selectAll:false,
          uploadMainDocuments:[],
          uploadFinalMainDocuments:[],
    
          todalDocumentsCount:0,
          spouseDocumentCount:0,
          totalChildDocumentCount:0,
          spouseActiveDocs:[],
          questionnaireDetails:null,
          tempUpdateDocList:{
            "benficiaryCategoryOrders":[], //[{ category:'resumes' ,order:1}]
            "spouseCategoryOrders":[], //[{ category:'resumes' ,order:1}]
            "childCategoryOrders":[], //[{ category:'resumes' ,order:1 ,"childrenId":'' }]
             "documentsOrder":[ ] //[{'path':'http://s3.amozon.com' ,order:2}]
          },
          benficiaryTrashItems:[],
          trashedItems:[],
          processingDocuments:true,
          finalProcessDocs:null,  
          showDragged:true,
    
          
    
        };
      },
      watch: {
        documentsUpload: function (value) {},
        '$store.state.isDragged'(val) {
            if(val){
                this.showDragged = val;
            }
            
        }
      },
      props: {
        loadedFromPreview:{type: Boolean , default: false},
        editableDocs:{type: Boolean , default: false},
        openTabes:false,
        allbtn: false,
        documentsUploadbtn: false,
        currentRole: null,
        petition: {
          type: Object,
          default: null,
        },
        workFlowDetails: {
          type: Object,
          default: null,
        },
        fieldsArray:[]
      },
      mounted() {
        this.showDragged = true;
        let self =this;
        
        setTimeout(()=>{
          if (_.has(this.petition, "questionnaireTplId")) {
    
         
          this.questionnaireTplId = this.getPetitionDetails["questionnaireTplId"];
          this.getquestionnaireDetails();
        }
        });
          this.initDocuments();
        this.processDocuments();
        this.getSavedDocuments();
        
          setTimeout(()=>{
                this.updateLoading(false,'NoDataFound')
                setTimeout(()=>{
                this.updateLoading(false,'NoDataFound')
               
               
                this.updateLoading(false,'NoDataFound')
         
            },20);
            },10);
        
      },
      methods: {
        showRestore(action = false){
            this.$store.commit('isDraggeded' ,action);
        },
        toggleDownloadTab(val){
          let _self = this;
          _self.isTrashDocument = val;
          setTimeout(()=>{
            this.updateLoading(false,'NoDataFoundRef')
            setTimeout(()=>{
            this.updateLoading(false,'NoDataFoundRef')
           // "NoDataFoundRef"
          } ,10);
           // "NoDataFoundRef"
          } ,10);
        },
        prepopulateSavedDocs(callFromRestore=false){
            if(callFromRestore){
                this.processedTaskDocs = _.cloneDeep(this.processedTaskDocsTemp)
                this.showDragged = false;
            }else{
                if(this.savedDocDetails && this.checkProperty(this.savedDocDetails,'length')>0){
                    this.processedTaskDocs = _.cloneDeep(this.savedDocDetails)
                }else{
                    this.processedTaskDocs = _.cloneDeep(this.processedTaskDocsTemp)
                }
            }
        },
        processTasksDocumet(item,mainCateg,isArray){
          let _self = this;
            let mainCategory = mainCateg;
            let passedItem = item;
            let categoryDocuments = [];
          if(passedItem && this.checkProperty(passedItem,'length')>0 && isArray ){
                    _.forEach(passedItem,(dbDocItem)=>{
                    let catDocuments =Object.entries(dbDocItem);
                    //console.log('catDocuments',catDocuments)
                    _.forEach(dbDocItem,(item,cat)=>{
                      // console.log('category',item)
                      let obj = {}
                      let reqCat = cat;
                      if(item && this.checkProperty(item,'length')>0){
                        let filterD =[];
                        _.forEach(item,(dcCIt)=>{
                          if(!_.has(dcCIt,'status') || (_.has(dcCIt,'status') && this.checkProperty(dcCIt,'status'))){
                            if(!_.has(dcCIt,'isTrashDocument')){
                              Object.assign(dcCIt,{"isTrashDocument":false})
                            }
                            filterD.push(dcCIt)
                          }
                        })
                        if(filterD){
                          Object.assign(obj,{'name':reqCat,'tasks':filterD,"isTrashDocument":false})
                        }
                      }
                      if(obj && this.checkProperty(obj,'tasks') && this.checkProperty(obj,'tasks','length')>0){
                        
                        categoryDocuments.push(obj)
                       }
                    })
                    })
                    if(categoryDocuments){
                      this.processedTaskDocs = categoryDocuments;
                      this.processedTaskDocsTemp = categoryDocuments;
                    }
            }
        },
        processDocuments(){
          if(this.checkProperty(this.petition,'documents') && this.checkProperty(this.petition,'documents','length')>0){
            let petitionDocs = _.cloneDeep(this.checkProperty(this.petition,'documents'))
            let docList = {};
            _.forEach(petitionDocs,(docItem)=>{
              if(!_.has(docList,docItem['documentType'] && this.checkProperty(docItem,'documentType'))){
                docList[docItem['documentType']] = [];
                docList[docItem['documentType']].push(docItem)
              }else{
                if(this.checkProperty(docItem,'documentType')){
                  docList[docItem['documentType']].push(docItem)
                }
              }
            })
            if(docList){
              this.processedCaseDocs = _.cloneDeep(docList);
              this.splitDocuments();
            }
          }
        },
        splitDocuments(){
                let catDocuments =Object.entries(this.processedCaseDocs);
                let documentsArray = [];
                let orgCategory = ''
                _.forEach(catDocuments,(item)=>{
                    let obj = {}
                    if(item){
                        let category =_.cloneDeep(item[0]);
                        let tempSection= category
                        orgCategory = category
                        if(item[1].length>0){
                            let documents =_.cloneDeep(item[1]);
                            let filteredDocs =[]
                            _.forEach(documents,(docs)=>{
                                if(!_.has(docs,'status') || (_.has(docs,'status') && this.checkProperty(docs,'status'))){
                                    filteredDocs.push(docs)
                                }
                            })
                            if(filteredDocs){
                                obj[tempSection] = filteredDocs
                            }
                        }
                        else{
                            obj[tempSection] = []
                        }
                    }
                    documentsArray.push(obj)
                })
                if(documentsArray){
                    this.processTasksDocumet(documentsArray,orgCategory,true)
                }
        },
        initDocuments(){
          this.acceptDocs =[];
         _.filter(this.petition.documents['beneficiaryDocs'] ,(item)=>{
              item['accepted'] =false
              this.acceptDocs.push(item)
            
         })
        },
        openUploadPopup(){
            this.$modal.hide('fileuploadComPopup')
            this.fuploder=false
            this.formerrors.msg = '';
            this.selectedChildItem = childItem
            this.uploadMainDocuments = [];
            this.selectedDocCategory = categy
            this.$modal.show('fileuploadComPopup')
        },
        downloadAllDocuments(){
            if(this.processedTaskDocs && this.checkProperty(this.processedTaskDocs,'length')>0){
                let downloadedPath = [];
                _.forEach(this.processedTaskDocs,(mTItem)=>{
                    if(_.has(mTItem,'isTrashDocument') && mTItem['isTrashDocument'] == false){
                        if(_.has(mTItem,'path') && mTItem['path']){
                            downloadedPath.push(mTItem['path'])
                        }else{
                            if(_.has(mTItem,'tasks') && mTItem['tasks'] && this.checkProperty(mTItem,'tasks','length')>0 ){
                                _.forEach(mTItem['tasks'],(sItem)=>{
                                    if(_.has(sItem,'isTrashDocument') && sItem['isTrashDocument'] == false){
                                        if(_.has(sItem,'path') && sItem['path']){
                                            downloadedPath.push(sItem['path'])
                                        }else{
                                            if(_.has(sItem,'tasks') && sItem['tasks'] && this.checkProperty(sItem,'tasks','length')>0 ){
                                                _.forEach(sItem['tasks'],(item)=>{
                                                    if(_.has(item,'isTrashDocument') && item['isTrashDocument'] == false){
                                                        if(_.has(item,'path') && item['path']){
                                                            downloadedPath.push(item['path'])
                                                        }else{
                                                            if(_.has(item,'tasks') && item['tasks'] && this.checkProperty(item,'tasks','length')>0 ){
                                                                _.forEach(item['tasks'],(docItem)=>{
                                                                    if(_.has(docItem,'isTrashDocument') && docItem['isTrashDocument'] == false){
                                                                        if(_.has(docItem,'path') && docItem['path']){
                                                                            downloadedPath.push(docItem['path'])
                                                                        }else{
                                                                            if(_.has(docItem,'tasks') && docItem['tasks'] && this.checkProperty(docItem,'tasks','length')>0 ){
                                                                                _.forEach(docItem['tasks'],(lItem)=>{
                                                                                    if(_.has(lItem,'isTrashDocument') && lItem['isTrashDocument'] == false){
                                                                                        if(_.has(lItem,'path') && lItem['path']){
                                                                                            downloadedPath.push(lItem['path'])
                                                                                        }else{
                                                                                            if(_.has(lItem,'tasks') && lItem['tasks'] && this.checkProperty(lItem,'tasks','length')>0 ){
                                                                                                _.forEach(lItem['tasks'],(DItem)=>{
                                                                                                    if(_.has(DItem,'isTrashDocument') && DItem['isTrashDocument'] == false){
                                                                                                        if(_.has(DItem,'path') && DItem['path']){
                                                                                                            downloadedPath.push(DItem['path'])
                                                                                                        }
                                                                                                    }
                                                                                                })
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                })
                                                                            }
                                                                        }
                                                                    }
                                                                })
                                                            }
                                                        }
                                                    }
                                                })
                                            }
                                        }
                                    }
                                })
                            }
                        }
                        
                    }

                })
                if(downloadedPath && this.checkProperty(downloadedPath,'length')>0){
                    this.finalProcessDocs = downloadedPath;
                    let postdata = {
                      externalId: this.petition._id,
                        documents: this.finalProcessDocs,
                    };
                    let _APIURL = this.$globalgonfig._APIURL
                    if(postdata['documents'].length>0){

                        this.filesDownloading =true; 
                        let path = '/external-cases/generate-pdf'
                        this.$store.dispatch("commonAction" ,{data:postdata,'path':path}).then((response) => {
                            this.savedDocumentsAction(true);
                            this.filesDownloading =false;
                            if(_.has(response ,'path' )){
                              window.open(_APIURL+"/common/viewfile?path=" +response.path,"_blank");
                            }
                            
                        })
                        .catch((error)=>{
                            this.filesDownloading =false;
                            this.showToster({ message:error , isError: true})
                        });
                    }
                }
                else{
                    this.filesDownloading =false;
                    this.showToster({ message:'Select Atleast one document' , isError: true})
                }
            }
        },
        savedDocumentsAction(){
            let postData = { "petitionId":'', 'docListPaths':[] ,"entityType": "external_case"  ,"category": "merge_all_docs"};
            if(this.checkProperty(this.petition ,'_id')  ){
                postData['petitionId'] =this.petition._id;
            }
            if(this.finalProcessDocs){
                postData['docListPaths'] = _.cloneDeep(this.finalProcessDocs)
            }
            if(this.processedTaskDocs){
                postData['rawData'] = _.cloneDeep(this.processedTaskDocs)
            }
            let path ="/petition-common/save-docs-selected-config";
            this.$store.dispatch("commonAction" ,{data:postData,'path':path})
            .then((rx) =>{
                this.getSavedDocuments();
            }).catch((err)=>{

            })
        },
        getSavedDocuments(){

            let postData ={
                'petitionId':'',
                'entityType':'external_case',
                "category": "merge_all_docs"
            };
            postData['petitionId'] =this.petition._id;
            // this.isDocumentsAreSaved =false;
            let path ="/petition/get-docs-selected-config";
            path ="/petition-common/get-docs-selected-config";
            this.$store.dispatch("commonAction" ,{data:postData,'path':path}).then((rx) =>{
            if(rx){

            if(this.checkProperty( rx,'rawData')){
            // this.isDocumentsAreSaved =true;
            this.savedDocDetails =_.cloneDeep(rx['rawData']);
            }else{
                this.savedDocDetails=[];
                // this.isDocumentsAreSaved =false;
            }
            }else{
            this.savedDocDetails=[];
            // this.isDocumentsAreSaved =false;

            }
            }).catch((e)=>{

            this.savedDocDetails=[];
            // this.isDocumentsAreSaved =false;
            });
        },

        getformated(item) {
    
           if(item.uploadedOn){
                return (
                "Uploaded On  " +
                moment(item.uploadedOn).format("MMM DD, YYYY hh:mm:ss a")
              );
            }
            else {
            if( item.createdOn){
                  return (
                  "Uploaded On  " +
                  moment(item.createdOn).format("MMM DD, YYYY hh:mm:ss a")
              );
    
            }
          }
            },

    
        splitFiles(){
    
          this.processingDocuments =true;
          this.petitiondocuments ={};
          let self =this;
          let total = Object.entries(this.petition.documents).length;
          let half = Math.round(total/2);
           this.todalDocumentsCount = 0;
           this.spouseDocumentCount = 0;
           this.totalChildDocumentCount =0;
           this.petitiondocumentr ={};
           let tempDocs =  _.cloneDeep(this.petition.documents );
           if(_.has(tempDocs,'slgOfferLetter')){
            delete tempDocs["slgOfferLetter"]
           }
           if(_.has(tempDocs,'slgSignedOfferLetter')){
            delete tempDocs["slgSignedOfferLetter"]
           }
           
         let caseDocuments =_.cloneDeep(tempDocs );
              _.forEach(
              Object.entries(caseDocuments ),
              (item ,index)=> {
                
                  if( this.checkProperty(item  ,'length')>1){
                  if( this.checkProperty(item[1] ,'length')>0){
                    let documentCategory =item[0];
    
                      let activeRecords = [];
                      _.forEach(item[1] ,(doc)=>{
                         Object.assign(doc ,{'isTrashDocument':false})  
                         if(this.getUserRoleId == 51){
                          if(this.checkProperty(doc,'uploadedByRoleId') && this.checkProperty(doc,'uploadedByRoleId') == 51 ){
                            Object.assign(doc ,{'showMe':true}) 
                          }else{
                            Object.assign(doc ,{'showMe':false}) 
                          }
                         } else{
                          Object.assign(doc ,{'showMe':true})  
                         }
                        doc['isTrashDocument'] =false;
                        if(this.isDocumentsAreSaved  ){
                            let isSavedDoc = _.find(this.savedDocumentsList ,{'path':doc['path']});
                            
                          if(!isSavedDoc){
                             
                              doc['isTrashDocument'] =true;
                              
                                                     
    
                          }
    
                        }
                        if(doc.status && ( this.checkProperty( doc ,'path') !='' || this.checkProperty( doc ,'url') !=''  )){
                          // if(this.checkProperty( doc ,'isTrashDocument')){
                          //   alert(doc['isTrashDocument'])
                          // }
                         
                          if(this.getUserRoleId == 51 ){
                            if(this.checkProperty(doc,'uploadedByRoleId') == 51 && doc.showMe==true){
                              //alert(doc.showMe)
                              activeRecords.push(doc)
                            }
                          }
                            else{
                            activeRecords.push( _.cloneDeep(doc));
                           
                          }
                         
                        
                        }
    
                      })
                      if(activeRecords.length>0){
                        this.petitiondocuments[documentCategory] =[];
                        this.petitiondocuments[documentCategory] =_.cloneDeep(activeRecords);
                        this.todalDocumentsCount = this.todalDocumentsCount +(activeRecords.length);
                       
                      
                      }
                     
                     
                    
              }
              }
                    
              });
              if(this.petition.documents && this.checkProperty(this.petition.documents,'slgSignedOfferLetter') && this.checkProperty(this.petition.documents,'slgSignedOfferLetter','length')>0){
                this.petitiondocuments['slgSignedOfferLetter'] = this.checkProperty(this.petition.documents,'slgSignedOfferLetter')
              }
          
    
    
        if(this.checkProperty( this.petition,'dependentsInfo' ,'spouse')){
    
          if(this.checkProperty( this.petition['dependentsInfo'] ,'spouse','documents')){
             
             _.forEach(
              Object.entries(this.petition['dependentsInfo']['spouse']['documents']),
              (item ,index)=> {
                
                  if( this.checkProperty(item  ,'length')>1){
                  if( this.checkProperty(item[1] ,'length')>0){
                    let documentCategory =item[0];
    
                      let activeRecords = [];
                      _.forEach(item[1] ,(doc)=>{
                        if(this.getUserRoleId == 51){
                          if(this.checkProperty(doc,'uploadedByRoleId') && this.checkProperty(doc,'uploadedByRoleId') == 51 ){
                            Object.assign(doc ,{'showMe':true}) 
                          }else{
                            Object.assign(doc ,{'showMe':false}) 
                          }
                         } else{
                          Object.assign(doc ,{'showMe':true})  
                         }
                        
                        doc['isTrashDocument'] =false;
                        if(this.isDocumentsAreSaved  ){
                            let isSavedDoc = _.find(this.savedDocumentsList ,{'path':doc['path']});
                          if(!isSavedDoc){
                              doc['isTrashDocument'] =true;
    
                          }
    
                        }
                        if(doc.status && ( this.checkProperty( doc ,'path') !='' || this.checkProperty( doc ,'url') !=''  )){
                          if(this.getUserRoleId == 51 ){
                            if(this.checkProperty(doc,'uploadedByRoleId') == 51 && doc.showMe==true){
                              activeRecords.push(doc)
                            }
                          }
                            else{
                            activeRecords.push( _.cloneDeep(doc));
                           }
                          
                        }
                      })
                      
                      if(activeRecords.length>0){
                        this.petitiondocumentr[documentCategory] =[];
                        this.petitiondocumentr[documentCategory] =activeRecords;
                       this.spouseDocumentCount = this.spouseDocumentCount +(activeRecords.length);
                      
                      }
                     
    
                    }
              }
                    
              });
              
           
          
          }
    
        }
       
    
    
      //childrens
      this.childernDocuments =[];
      if(this.checkProperty( this.petition,'dependentsInfo' ,'childrens')){
          if(this.checkProperty( this.petition['dependentsInfo'] ,'childrens' ,'length')>0){
    
            _.forEach(this.petition['dependentsInfo']['childrens'] ,(childernDocs)=>{
               
    
    
    
              if( this.checkProperty( childernDocs ,"documents") ){
              
                let childDocs = _.filter(
                  Object.entries(childernDocs['documents']),
                  (item)=> {
                    if(item[1] && item[1].length > 0){
    
                      let activeRecords = [];
                      _.forEach(item[1] ,(doc)=>{
                        
                        doc['isTrashDocument'] =false;
                          if(this.isDocumentsAreSaved  ){
                              let isSavedDoc = _.find(this.savedDocumentsList ,{'path':doc['path']});
                            if(!isSavedDoc){
                                doc['isTrashDocument'] =true;
    
                            }
    
                          }
                        if(doc.status){
                            doc['childrenId'] =this.checkProperty(childernDocs ,'_id');
                            activeRecords.push(doc)
                            
                        }
    
                    })
                  
                    
                      if(activeRecords.length>0 && this.allChildrens.length>0){
    
                        self.totalChildDocumentCount = self.totalChildDocumentCount+(activeRecords.length )
                        return true;
                      }else{
                      return false;
                      }
    
                      }else{
                        return false;
                      }
                  }
                );
                
               self.childernDocuments.push(_.cloneDeep(childDocs))
              
                
                
            }
    
            })
    
          }
    
      }
    
      this.petitiondocuments  =_.cloneDeep(this.petitiondocuments);
      this.petitiondocumentr = _.cloneDeep(this.petitiondocumentr);
      this.childernDocuments = _.cloneDeep(this.childernDocuments);
     this.processingDocuments =false;
    
         
        },
         reloadCaseDetails(){
            this.openEditDocs(false);
            this.$store.dispatch("setPetitionTab", 'Documents')
            this.$emit("updatepetition" ,'Documents');
         },
         openEditDocs(action){
            this.formerrors.msg=''
            this.uploadMainDocuments = [];
            this.uploadFinalMainDocuments =[];
            this.docCategory = '';
            this.fileuploadPopup = action;
            this.$validator.reset();
            
         },
        
         checkDocumentsExists(docs){
        //  alert(JSON.stringify(docs))
           if( this.checkProperty( docs ,'length'>0)){
    
              let activeDocs = _.filter(docs,{"status":true});
             // alert(JSON.stringify(activeDocs))
             if(activeDocs){
               return true
             }else{
               return false
             }
    
           }else{
             return true;
           }
         },
        
    
     remove(item, type) {
                type.splice(type.indexOf(item), 1);
                return false;
            },
          filameChenged(fileindex) {
                this.disable_uploadBtn = false;
    
                
                    if (this.uploadFinalMainDocuments.length > 0) {
                        _.forEach(this.uploadFinalMainDocuments, (fl, value) => {
                            //let fname = fl.name;
                            let fname = fl.name;
                            fname = fname.trim();
                            
    
                            if (!fname) {
                                this.disable_uploadBtn = true;
                            }
                        });
                    }
             
    
            },
             //uploadMainDocuments
            uploadToS3MainDocuments( docs){
                 docs = docs.map(
                    item =>
                    (item = {
                        name: item.name,
                        file: item.file,
                        path:'',
                        mimetype: item.type,
                        uploadedBy:item.uploadedBy?item.uploadedBy:this.checkProperty(this.getUserData,'userId')!=''?this.checkProperty(this.getUserData,'userId'):null,
                        uploadedByName:item.uploadedByName?item.uploadedByName:this.checkProperty(this.getUserData,'name')!=''?this.checkProperty(this.getUserData,'name'):'',
                        uploadedByRoleId:item.uploadedByRoleId?item.uploadedByRoleId:this.getUserRoleId?this.getUserRoleId:null,
                        uploadedByRoleName:item.uploadedByRoleName?item.uploadedByRoleName:this.checkProperty(this.getUserData,'loginRoleName'),
                   
                    })
                );
    
    
                if (docs.length > 0) {
                    let filIndex = 0;
                    this.fuploder = true;
                    this.disable_uploadBtn = true;
                    docs.forEach(doc => {
                        let formData = new FormData();
                        formData.append("files", doc.file);
                        formData.append("secureType", "private");
                        formData.append("getDetails", true);
                        
                           
                        this.$store.dispatch("uploadS3File", formData).then(response => {
                            filIndex++;
                            if (filIndex >= this.uploadMainDocuments.length) {
                                this.fuploder = false;
                                this.disable_uploadBtn = false;
                            }
                            response.data.result.forEach(urlGenerated => {
                                delete doc.file
                                doc.path = urlGenerated['path'];
                                doc['size'] =urlGenerated['size'];
                               this.uploadFinalMainDocuments.push(doc);
                            });
                        });
                    
                        
                    });
                }
    
            },
    
        updateNodataLoading(){
          setTimeout(()=>{
            this.updateLoading(false);
          } ,100)
          return true;
    
        },


    
        uploadBenDocuments() {
               
                 
                 Object.assign( this.formerrors ,{ msg:''})
                if (this.disable_uploadBtn) {
                    return false;
                }
               // this.fileuploadPopup = false; /petition/upload-beneficiary-docs,
                let postData = {
                  externalId: '',
                  documents:[],
                  
                };
                this.$validator.validateAll("documentUploadForm").then((result) => {  
                if(this.uploadFinalMainDocuments && this.uploadFinalMainDocuments.length>0 && result){
    
    
                   if(this.uploadFinalMainDocuments.length>0){
    
                    this.uploadFinalMainDocuments.forEach((doc)=>{
                      let document = doc
                      document = Object.assign(document ,{ name:doc.name})
                      document = Object.assign(document ,{ 'documentType':this.docCategory,'uploadedOn':moment()})
                      postData['documents'].push(document);
                    })
                  if(this.checkProperty(this.petition,'_id')){
                    postData['externalId'] = this.checkProperty(this.petition,'_id')
                  }
                  this.fuploder = true;
                  this.disable_uploadBtn = true;
                  let path ="/external-cases/upload-documents"
                  this.$store.dispatch('commonAction', {"data":postData ,path}).then(response => {
                        this.showToster({message:response.message ,isError:false })
                        this.fileuploadPopup = false;
                        this.fuploder = false;
                        this.disable_uploadBtn = false;
                        this.fileuploadPopup = false;
                       this.$emit("getcaseHistory");
                       let list = _.cloneDeep(this.petition['documents'])
                       this.petition['documents'] = [];
                       _.forEach(postData['documents'] ,(fl)=>{
                            this.petition['documents'].push(fl);
                       })
                       _.forEach(list ,(f2)=>{
                            this.petition['documents'].push(f2);
                       })
                       
                       
                      
                        this.processDocuments();
    
                  
                  })
                  .catch((error) => {
                      Object.assign(this.formerrors ,{'msg':error})
                      this.fuploder = false;
                      this.disable_uploadBtn = false;
                  });
            
             }
              }else{
                if(this.uploadFinalMainDocuments && this.uploadFinalMainDocuments.length==0){
                  Object.assign( this.formerrors ,{ msg:'Upload atleast one document'})
                }
              }
            })
        
             
           
        },
    
        selectedDocuments(docs) {
               
                docs = docs.map(
                    item =>
                    (item = {
                        name: item.name,
                        file: item.file,
                        extn: "",
                        path:'',
                        mimetype: item.type,
                        accepted:false,
                    })
                );
                this.documentUploaded = [];
                this.documentUploaded = docs;
                this.fuploder = false;
                this.disable_uploadBtn = false;
                if (docs.length > 0) {
                    let filIndex = 0;
                    this.fuploder = true;
                    this.disable_uploadBtn = true;
                    this.documentUploaded.forEach(doc => {
                        let formData = new FormData();
                        formData.append("files", doc.file);
                        formData.append("secureType", "private");
                         formData.append("getDetails", true);
                        
                           
                        this.$store.dispatch("uploadS3File", formData).then(response => {
                             filIndex++;
                             if (filIndex >= this.documentUploaded.length) {
                                    this.fuploder = false;
                                    this.disable_uploadBtn = false;
                                }
                          
    
                            response.data.result.forEach(urlGenerated => {
                                
                                 doc.path = urlGenerated.path;
                                 doc.extn = urlGenerated.extn;
                                 delete doc.file
                            });
    
                            
                          
                        });
                   
                        
                    });
                }
                this.fileuploadPopup = true
            },
         remove_uploadedfile( fileindex) {
                
                this.documentUploaded.splice(fileindex, 1);
    
                if(this.documentUploaded.length ==0){
                  this.fileuploadPopup =false;
    
                }
            },
         fileNameChenged( fileindex) {
                this.disable_uploadBtn = false;
    
                
                    if (this.documentUploaded.length > 0) {
                        _.forEach(this.documentUploaded, (fl, index) => {
                          if(index ==fileindex){
                            //let fname = fl.name;
                            let fname = fl.name;
                            fname = fname.trim();
    
                            if (!fname) {
                                this.disable_uploadBtn = true;
                            }
                        }
    
                        });
                    }
               
    
            },

        checkDocLen(documents){
         
          
            let return_value =false
            _.each(documents ,(val ,indx)=>{
             
              if(val.length>0 && indx !="beneficiaryDocs"){
                
             
                return_value = true;
    
                
              }
            });
            
            return return_value;
          
    
        },
        selectDoctype(type = "") {
          this.uploaddocType = type;
        },
    
        upload(model, uploaddocType) {
          this.is_enablesavebtn = false;
          
          let temp_count = 0;
          this.uploaddocType = uploaddocType;
          let formData = new FormData();
          if (model.length > 0) {
            this.$vs.loading();
            model.forEach((doc) => {
              formData.append("files", doc.file);
              formData.append("secureType", "public");
              this.$store.dispatch("uploadS3File", formData).then((response) => {
               temp_count++;
                let docmnt = {
                  mimetype: model[0]["file"]["type"],
                  name: model[0]["file"]["name"],
                  status: true,
                  uploadedOn: new Date(),
                  url: response["data"]["result"][0],
                  path: response["data"]["result"][0],
                  tempDoc:true,
                  uploadedBy:this.checkProperty(this.getUserData,'userId'),
                  uploadedByName:this.checkProperty(this.getUserData,'name'),
                  uploadedByRoleId:this.getUserRoleId,
                  uploadedByRoleName:this.checkProperty(this.getUserData,'loginRoleName'),
                };
    
                this.petition["documents"][this.uploaddocType].push(docmnt);
                this.is_enablesavebtn = true;
                if (temp_count >= model.length) {
                     
                      this.$vs.loading.close();
                  }
              });
            });
          }
        },
    
        saveUploadedsFiles() {
          var postpetition = {
            petitionId: this.$route.params.itemId,
            userName: this.$store.state.user.name,
            action: "UPLOAD_DOCUMENTS",
            documents: this.petition["documents"],
            typeName: this.petition["subTypeDetails"]["name"],
            subTypeName: this.petition["typeDetails"]["name"],
          };
    
    
    
          this.$store
            .dispatch("petitioner/petitionupdate", postpetition)
    
            .then((response) => {
              if (response.error) {
                Object.assign(this.formerrors, {
                  msg: response.error.message,
                });
              } else {
                this.is_enablesavebtn = false;
                this.$emit("updatepetition" ,'Documents');
                this.$vs.notify({
                  text: response.message,
                  position: "top-right",
                  color: "primary",
                  
                });
              }
            });
        },
        removethis(index,parent) {
          parent.splice(index, 1);
          this.trashDocument()
          return false;
          
        },
        removethisalt(index,parent) {
          this.petitiondocumentr.splice(index, 1);
          return false;  
        },
        removethissub(item,parent) {
       parent.splice(item.indexOf(parent), 1);
          return false;
        },
        checker(value) {
          this.documentlockformcomments = "";
          this.lockUnlockformerrors = '';
          this.lockDocumentsPopup = true;
          this.lockDocumentsPopupTitle = "Lock Documents";
          if (!value) this.lockDocumentsPopupTitle = "Unlock Documents";
          this.documentsUpload = value;
    
           this.$validator.reset();
        },
        submitdocumentslock() {
         this.lockUnlockformerrors ='';
          this.$validator.validateAll("documentlockform").then((result) => {
            if (result) {
              var postdata = {
                petitionId: this.petition._id,
                typeName: this.petition.typeDetails.name,
                subTypeName: this.petition.subTypeDetails.name,
                comment: this.documentlockformcomments,
                action: this.documentsUpload
                  ? "DISABLE_DOCUMENT_UPLOAD"
                  : "ENABLE_DOCUMENT_UPLOAD",
              };
    
              this.$store
                .dispatch("managedocumentupload", postdata)
                .then((response) => {
                  this.lockDocumentsPopup = false;
                  this.documentlockformcomments = "";
                  this.petition.documentsUploadEnabled = this.documentsUpload;
                  this.showMessages(response.message);
                  window.location.reload();
                  //this.$emit("updatepetition");
                  
                })
                .catch((error)=>{
                  this.lockUnlockformerrors = error;
                  this.showToster({ message: error, isError: true });
    
                })
            }
          });
        },
        successUpload() {
          this.$vs.notify({
            color: "success",        
            position: "top-right",
            color: "primary",
            text: "Documents Sucessfully Uploded",
          });
        },
        showMessages(message) {
          this.$vs.notify({
            title: "Success",
            position: "top-right",
            color: "success",
            iconPack: "feather",
            icon: "icon-check",
            text: message,
          });
        },
        downloadallfile() {
            this.filesDownloading =false;
            //this.petitiondocuments =[];
             //this.petitiondocumentr =[];
           //  this.petitiondocuments = _.cloneDeep(this.petition.documents);
             this.downloadDocList = true;
            //this.splitFiles();
          
            this.downloadDocumentPop = true;
            // setTimeout(()=>{
            //   this.changedDocumentsTab('savedDocuments');
            // });
         
        },
        downloadcombine() {
         let _APIURL = this.$globalgonfig._APIURL
          var self = this;
          var docs = [];
    
    
        let combailDocuments = (documents)=>{
            _.forEach(documents ,(doc)=> {
    
              if(this.checkProperty(doc ,'length') >1){
                if(this.checkProperty(doc[1] ,'length') >0){
               
                doc[1].forEach(i=> {
                      if(i.path!=null && i.path !='' && !this.checkProperty(i ,'isTrashDocument')   ){ 
                        docs.push(i.path);
                      }else if(i.url!=null && i.url !='' && !this.checkProperty(i ,'isTrashDocument')  ){ 
                        docs.push(i.url);
                      }
                })
              }
              }
            })
        }
        combailDocuments(this.petitiondocuments );
        combailDocuments(this.petitiondocumentr );
           
             
            this.childernDocuments.forEach((child)=>{
    
               child.forEach(doc=> {
               doc[1].forEach(i=> {
                    if(i.path !='' && i.path!=null && !this.checkProperty(i ,'isTrashDocument') ){ 
                      docs.push(i.path);
                    }else if(i.url !='' && i.url!=null && !this.checkProperty(i ,'isTrashDocument') ){ 
                      docs.push(i.url);
                    }
               })
            })
    
    
            })
           
    
                  let postdata = {
            petitionId: this.petition._id,
            documents: docs,
          };
         
          
          if(postdata['documents'].length>0){
              this.filesDownloading =true;
            this.$store
            .dispatch("downloaddocsbyorder", postdata)
            .then((response) => {
               this.filesDownloading =false;
           
              self.downloadDocumentPop = true;
             // alert( _APIURL+"/common/viewfile?path="+response.data.result.path);
              window.open(
                _APIURL+"/common/viewfile?path=" +
                  response.data.result.path,
                "_blank"
              );
            }).catch((error)=>{
              this.filesDownloading =false;
              this.showToster({ message:error , isError: true})
             
            });
        
          } 
        },
        download_or_view(value){
            this.$emit('download_or_view' ,value);
        },
        downloadfile(value, download = false, viewmode = true) {
          value.download = download;
         // value.viewmode = viewmode;
          if(_.has(value ,"url" ) && !(_.has(value ,"path" ) )){
            value =Object.assign(value ,{ "path":value['url']})
          }else  if(_.has(value ,"path" ) && !(_.has(value ,"url" )) ){
            value =Object.assign(value ,{ "url":value['path']})
          }
          //alert(value.viewmode)
          this.$emit('download_or_view' ,value);
        },
      },
      computed:{
        checkSavedDocs(){
            let returnVal = true;
            let _self = this
            if(_self.processedTaskDocs && _self.checkProperty(_self.processedTaskDocs,'length')>0 ){
                _.forEach(_self.processedTaskDocs,(mItem)=>{
                    if( !_self.checkProperty(mItem, 'isTrashDocument') ){
                        returnVal = false;
                        return returnVal
                    }else if( _self.checkProperty(mItem, 'tasks') && _self.checkProperty(mItem, 'tasks' ,'length') >0){
                        _.forEach(mItem['tasks'],(sItem)=>{
                            if(! _self.checkProperty(sItem, 'isTrashDocument')  ){
                                returnVal = false;
                                return returnVal
                            }else if(_self.checkProperty(sItem, 'tasks') && _self.checkProperty(sItem, 'tasks' ,'length') >0){
                                _.forEach(sItem['tasks'],(item)=>{
                                    if(! _self.checkProperty(item, 'isTrashDocument')  ){
                                        returnVal = false;
                                        return returnVal
                                    
                                    }else if(_self.checkProperty(item, 'tasks') && _self.checkProperty(item, 'tasks' ,'length') >0){
                                        _.forEach(item['tasks'],(dItem)=>{
                                            if(! _self.checkProperty(dItem, 'isTrashDocument')  ){
                                                returnVal = false;
                                                return returnVal
                                                
                                            }else if(_self.checkProperty(dItem, 'tasks') && _self.checkProperty(dItem, 'tasks' ,'length') >0){
                                                _.forEach(dItem['tasks'],(dbItem)=>{
                                                    if(! _self.checkProperty(dbItem, 'isTrashDocument')  ){
                                                        returnVal = false;
                                                        return returnVal
                                                    }else if(_self.checkProperty(dbItem, 'tasks') && _self.checkProperty(dbItem, 'tasks' ,'length') >0){
                                                        _.forEach(dbItem['tasks'],(yItem)=>{
                                                            if(! _self.checkProperty(yItem, 'isTrashDocument')  ){
                                                                returnVal = false;
                                                                return returnVal
                                                            }
                                                        })
                                                    }
                                                })
                                            }
                                        })
                                    }
                                })
                            }
                        })
                    }
                })
            }else{
                returnVal = true
            }
            if(returnVal){
                setTimeout(()=>{
                    this.updateLoading(false)
                },10);
            }
            return returnVal
        },
       checkDocumentPath(){
        return (data)=>{
    
        }
       },
        checkNoNotifyUserIds(){
          let returnValue =true;
          if(_.has(this.petition, 'noNotifyUserIds')  ){
            if(this.petition['noNotifyUserIds'].length>0){
              if(this.petition['noNotifyUserIds'].indexOf(this.getUserData['userId']) >-1){
                returnValue = false;
              }
    
            }
    
          }
          return returnValue;
        },
        //5--front office user
        checkApproveDocuments(){
          let returnVal = false;
          
          let docSupList = _.find(this.workFlowDetails.config, {
            code: "SUPERVISOR_LIST",
          });
          if (docSupList && docSupList.editors) {
            this.finalList = _.map(docSupList.editors, "roleId");
          }
          if(this.finalList && this.finalList.indexOf( this.getUserRoleId)>-1 || [5].indexOf(this.getUserRoleId)>-1) {
            returnVal = true;
          }
          
          return returnVal;
        },
    
        
        getbenficiarySavedDocuments(){
         
          let returnSavedDocuments =[];
          _.forEach(Object.entries(this.petitiondocuments) , (category ,index)=>{
           
            if(this.checkProperty(category ,'length')>1){
              if(this.checkProperty(category[1] ,'length') >0){
                let trashedItems = _.filter(category[1] ,{'isTrashDocument':false});
               
                if(trashedItems && this.checkProperty(trashedItems ,'length')>0){
                 
                  returnSavedDocuments.push(category);
                }
    
              }
              //isTrashDocument
           
    
            }
    
          });
          return returnSavedDocuments
         
         
        },
        getbenficiaryTrashedDocuments(){
         
          let returnSavedDocuments =[];
          _.forEach(Object.entries(this.petitiondocuments) , (category ,index)=>{
           
            if(this.checkProperty(category ,'length')>1){
              if(this.checkProperty(category[1] ,'length') >0){
                let trashedItems = _.filter(category[1] ,{'isTrashDocument':true});
               
                if(trashedItems && this.checkProperty(trashedItems ,'length')>0){
                 
                  returnSavedDocuments.push(category);
                }
    
              }
              //isTrashDocument
           
    
            }
    
          });
         
          return returnSavedDocuments
         
         
        },
    
        
        getspouseSavedDocuments(){
          //this.petitiondocumentr
           let returnSavedDocuments =[];
          _.forEach(Object.entries(this.petitiondocumentr) , (category ,index)=>{
           
            if(this.checkProperty(category ,'length')>1){
              if(this.checkProperty(category[1] ,'length') >0){
                let trashedItems = _.filter(category[1] ,{'isTrashDocument':false});
               
                if( this.checkProperty(trashedItems ,'length')>0){
                 
                  returnSavedDocuments.push(category);
                }
    
              }
              //isTrashDocument
           
    
            }
    
          });
          return returnSavedDocuments
         
    
        },
        getspouseTrashedDocuments(){
          //this.petitiondocumentr
           let returnSavedDocuments =[];
          _.forEach(Object.entries(this.petitiondocumentr) , (category ,index)=>{
           
            if(this.checkProperty(category ,'length')>1){
              if(this.checkProperty(category[1] ,'length') >0){
                let trashedItems = _.filter(category[1] ,{'isTrashDocument':true});
               
                if(trashedItems && this.checkProperty(trashedItems ,'length')>0){
                 
                  returnSavedDocuments.push(category);
                }
    
              }
              //isTrashDocument
           
    
            }
    
          });
          return returnSavedDocuments
         
    
        },
        
        //childernDocuments
        getChildSavedDocuments(){
    
          
          //this.petitiondocumentr
            let finalArray =[];
           _.forEach(this.childernDocuments ,(child ,index)=>{
             
             let returnSavedDocuments =[];
          _.forEach(Object.entries(child) , (category ,index)=>{
           
            if(this.checkProperty(category ,'length')>1){
              if(this.checkProperty(category[1] ,'length') >0){
                let trashedItems = _.filter(category[1][1] ,{'isTrashDocument':false});
               
                if( this.checkProperty(trashedItems ,'length')>0){
                 
                  returnSavedDocuments.push(category[1]);
               }
    
              }
              //isTrashDocument
           
    
            }
    
          });
         
    
          if(this.checkProperty(returnSavedDocuments ,'length')>0){
            finalArray.push(returnSavedDocuments)
          }
    
    
        })
          return finalArray
         
    
        },
        getChildTrasheddDocuments(){
    
          
    
          
          //this.petitiondocumentr
            let finalArray =[];
           _.forEach(this.childernDocuments ,(child ,index)=>{
             
             let returnSavedDocuments =[];
          _.forEach(Object.entries(child) , (category ,index)=>{
           
            if(this.checkProperty(category ,'length')>1){
              if(this.checkProperty(category[1] ,'length') >0){
                let trashedItems = _.filter(category[1][1] ,{'isTrashDocument':true});
               
                if( this.checkProperty(trashedItems ,'length')>0){
                 
                  returnSavedDocuments.push(category[1]);
               }
    
              }
              //isTrashDocument
           
    
            }
    
          });
         
    
          if(this.checkProperty(returnSavedDocuments ,'length')>0){
            finalArray.push(returnSavedDocuments)
          }
    
    
        })
          return finalArray
    
        },
        
        isSelectedForApprove(){
         let selectedItems= _.filter(this.acceptDocs,{"accepted":true})
         if(selectedItems && selectedItems.length>0){
           return true;
         }else{
           return false;
    
         }
        }
       
      }
    };
    </script>
    