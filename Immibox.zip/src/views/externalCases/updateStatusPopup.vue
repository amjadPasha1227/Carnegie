
<template>
    <vs-popup
      class="holamundo main-popup"
      :title="'Update Status'"
      :active.sync="showPopup"
    >
      <form data-vv-scope="newCaseNumberForm" @submit.prevent @keydown.enter.prevent>
        <div class="popup-accounts-content edit_password">
          <div class="form-container padb20" @click="formerrors.msg=''">
            <!-- <immiInput :display="true" :tplkey="''" :fieldsArray="[]"  wrapclass=" " cid="lawOfficeName" formscope="newCaseNumberForm" v-model="lawOfficeName" :tplsection="''"  :fieldName="'lawOfficeName'"  :required="true"  label="Name" vvas="Name" placeHolder="Name" /> -->
            <selectField :fieldsArray="[]" :display="true" :wrapclass="'w-1/2'" :tplkey="''" :cid="'caseStatus'"  :required="true" :optionslist="statusList" v-model="caseStatus" formscope="newCaseNumberForm" :fieldName="'caseStatus'" label="Select Status" placeHolder="Select Status" :tplsection="''" />

            <div class="vx-col w-full">
                <div class="form_group">
                  <label class="form_label">Comments</label>
                  <ckeditor data-vv-as="Comments" v-model="caseComments"
                    name="comments" class="w-full" :editor="editor" :config="editorConfig"></ckeditor>

                </div>
              </div>
            <div class="text-danger text-sm formerrors mt-6" v-show="formerrors.msg">
              <vs-alert
                color="warning"
                class="warning-alert reg-warning-alert no-border-radius"
                icon-pack="IntakePortal"
                icon="IP-information-button"
                active="true"
              >
                {{ formerrors.msg }}
              </vs-alert>
            </div>
          </div>
          <div class="popup-footer relative">
            <!-- <div class="password-count">
            <i class="icon IP-lock"></i> Password must contain 6 to 15 characters
          </div> -->
            <div class="d-flex">
              <vs-button
                color="dark"
                @click="hideMe()"
                class="cancel"
                type="filled"
                >Cancel</vs-button
              >
  
              <vs-button
                class="save"
                type="filled"
                @click="submitForm"
                :disabled="settingCaseNumber"
              >
                <figure v-if="settingCaseNumber" class="loader">
                  <img src="@/assets/images/main/loader.gif" />
                </figure>
                Update
              </vs-button>
            </div>
          </div>
        </div>
      </form>
    </vs-popup>
  </template>
  <script>
    import Vue from "vue";
Vue.use(CKEditor);
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
  import selectField from "@/views/forms/fields/simpleselect.vue";
    import immiInput from "@/views/forms/fields/simpleinput.vue";
  export default {
    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
    methods: {
      submitForm() {
        this.$validator.validateAll("newCaseNumberForm").then((result) => {
          if (result) {
            let self = this;
            let postData = {
              externalId: this.checkProperty(this.petitionDetails,'_id'),
              statusId: this.checkProperty(this.caseStatus,'id'),
              statusName:this.checkProperty(this.caseStatus,'name'),
              comments:this.caseComments
            };
            let path ="/external-cases/update-status";
            this.$store
              .dispatch("commonAction", {
                data: postData,
                path: path,
              })
              .then((response) => {
                this.showToster({ message: response.message, isError: false });
                this.$validator.reset("newCaseNumberForm");
                this.settingCaseNumber = false;
                this.$emit("updatepetition", "Case Details");
                 this.hideMe()
              })
              .catch((err) => {
                this.settingCaseNumber = false;
                this.formerrors.msg = err
                //this.showToster({ message: err, isError: true });
              });
          }
        });
      },
      hideMe() {
        this.$emit("hideMe");
      },
      caseStatusList(obj){ 
      let postData = {

        "matcher": { 
          "searchString":"",
          "tenantId": "",
          "branchId": "",
          "getWorkFlowConfig": false,
          "getCasenoCodeConfig": false,
          "tenantCustomId": "",
          "petitionTypes": [],
          "getInactiveListAlso": false,
          "caseType": "h1b"
        },
          "category": "case_status",
          "page": 1,
          "perpage": 25,
          "sorting": {    
            "path": "name",
            "order": 1
        }
      }
      if(this.checkProperty(this.petitionDetails,'typeDetails') && this.checkProperty(this.petitionDetails,'typeDetails','id')==1){
       
        postData['matcher']['caseType'] = "h1b"
      }
      if(this.checkProperty(this.petitionDetails,'typeDetails') && this.checkProperty(this.petitionDetails,'typeDetails','id')==2){
        postData['matcher']['caseType'] = "h4"  
      }
      if(this.checkProperty(this.petitionDetails,'typeDetails') && this.checkProperty(this.petitionDetails,'typeDetails','id')==3){
        postData['matcher']['caseType'] = "gc"  
      }
        this.$store.dispatch("getMasterData",postData).then(response => {
          //this.statusList =response.list;
           let list = response.list;
           this.statusList = _.filter(list, (item)=>{
            return item['id']>= this.checkProperty(this.petitionDetails,'statusId')
           })
        })
    }, 
    },
    watch: {
      showPopup(val) {
        if (!val) this.$emit("hideMe");
      },
    },
    mounted() {
      this.showPopup = true;
      if(this.checkProperty(this.petitionDetails,'statusDetails')){
        this.caseStatus = this.checkProperty(this.petitionDetails,'statusDetails');
      }
      this.caseStatusList();
      this.formerrors.msg = '';
    },
    data: () => ({
      caseComments:'',
      editor: ClassicEditor,
    editorConfig: {
      toolbar: ['bold', 'italic', '|', 'undo', 'redo', 'NumberedList', 'BulletedList',],
    },
        caseStatus:null,
        statusList:[],
      showPopup: false,
      settingCaseNumber: false,
      formerrors: {
        msg: "",
      },
      lawOfficeName:'',
    }),
    props: {
      caseNumber: {
        type: String,
        default: null,
      },
      isCaseNumberEdit: {
        type: Boolean,
        default: false,
      },
      petitionDetails: {
        type: Object,
        default: null,
      },
    },
    components:{
        immiInput,
        selectField
    }
  };
  </script>