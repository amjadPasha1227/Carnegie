
<template>
    <vs-popup
      class="holamundo main-popup"
      :title="'Add Law Office'"
      :active.sync="showPopup"
    >
      <form data-vv-scope="newCaseNumberForm" @submit.prevent @keydown.enter.prevent>
        <div class="popup-accounts-content edit_password">
          <div class="form-container padb20">
           
            <!-- <immiInput :display="true" :tplkey="''" :fieldsArray="[]"  wrapclass=" " cid="lawOfficeName" formscope="newCaseNumberForm" v-model="lawOfficeName" :tplsection="''"  :fieldName="'lawOfficeName'"  :required="true"  label="Name" vvas="Name" placeHolder="Name" /> -->
            <!-- <selectField :fieldsArray="[]" :display="true" :wrapclass="'w-1/2'" :tplkey="''" :cid="'lawOfficeInfo'"  :required="true" :optionslist="lawOfficeList" v-model="lawOfficeInfo" formscope="newCaseNumberForm" :fieldName="'lawOfficeInfo'" label="Name" placeHolder="Name" :tplsection="''" /> -->
            <div class="vx-col md: w-full" >
          <div class="form_group city-form">
            <div class="con-select select-large addselect">
              <label  class="form_label"
                >Name<em>*</em></label
              >
              <multiselect
                :name="'Namecid'"
                v-model="lawOfficeDetails"
                :disabled="false"
                :show-labels="false"
                track-by="id"
                label="name"
                data-vv-as="Name"
                tag-placeholder="Add"
                :taggable=true
                @tag="addOffice"
                placeholder="Name"
                :options="lawOfficeList"
                :searchable="true"
                :showNoOptions="false"
                :allow-empty="false"
                :no-options="false"
                v-validate="{
                  required: true,
                }"
              >
              <template slot="noResult" > <!-- Customized empty list display --> </template>
              </multiselect>
            </div>
            <span class="text-danger text-sm" v-show="errors.has('newCaseNumberForm.Namecid')">{{
                  errors.first("newCaseNumberForm.Namecid") }}</span>
          </div>
        </div>








            <div class="vx-col w-full">
                <div class="form_group">
                  <label class="form_label">Comments</label>
                  <ckeditor data-vv-as="Comments" v-model="lawOfficeComments"
                    name="comments" class="w-full" :editor="editor" :config="editorConfig"></ckeditor>

                </div>
              </div>
  
            <div class="text-danger text-sm formerrors mt-6" v-show="formerrors.msg">
              <vs-alert
                color="warning"
                class="warning-alert reg-warning-alert no-border-radius"
                icon-pack="IntakePortal"
                icon="IP-information-button"
                active="true"
              >
                {{ formerrors.msg }}
              </vs-alert>
            </div>
          </div>
          <div class="popup-footer relative">
            <div class="d-flex">
              <vs-button color="dark" @click="hideMe()" class="cancel" type="filled">Cancel</vs-button>
  
              <vs-button class="save" type="filled" @click="submitForm" :disabled="settingCaseNumber" >
                <figure v-if="settingCaseNumber" class="loader"> <img src="@/assets/images/main/loader.gif" /> </figure> Assign
              </vs-button>
            </div>
          </div>
        </div>
      </form>
    </vs-popup>
  </template>
  <script>
  import Vue from "vue";
Vue.use(CKEditor);
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import selectField from "@/views/forms/fields/simpleselect.vue";
  import immiInput from "@/views/forms/fields/simpleinput.vue";
  export default {
    provide() {
            return {
                parentValidator: this.$validator,
            };
        },
    methods: {
      submitForm() {
        this.$validator.validateAll("newCaseNumberForm").then((result) => {
          if (result) {
            let self = this;
            let postData = {
              externalId:this.checkProperty(this.petitionDetails,'_id'),
              lawOfficeInfo:{
                name:''
              },
              comments:self.lawOfficeComments,
            };
            if(this.checkProperty(this.lawOfficeDetails,'name')){
              postData['lawOfficeInfo']['name'] =  this.checkProperty(this.lawOfficeDetails,'name')
            }
            this.settingCaseNumber = true;
            let path ="/external-cases/law-office-info";
            this.$store
              .dispatch("commonAction", {
                data: postData,
                path: path,
              })
              .then((response) => {
                this.showToster({ message: response.message, isError: false });
                this.$validator.reset("newCaseNumberForm");
                this.settingCaseNumber = false;
                this.$emit("updatepetition", "Case Details");
                 this.hideMe()
              })
              .catch((err) => {
                this.settingCaseNumber = false;
                this.showToster({ message: err, isError: true });
              });
          }
        });
      },
      getLawOfficeList(){
        let payLoad={
          matcher:{
            statusIds:[],
            createdDateRange:[]
          },
          page:1,
          perpage:1000
        };
        let path ="/external-cases/office-list";
            this.$store.dispatch("getList", { data: payLoad, path: path})
            .then((response) => {
              let list = response.list;
              this.lawOfficeList = _.filter(list,(item)=>{
                return item['name']
              })
            })
            .catch((err)=>{

            })
      },
      hideMe() {
        this.$emit("hideMe");
      },
      addOffice(newTag=''){
      if(!newTag){
       return false;
      }
      let item = newTag
      let obj = {
        'id':'875454545454545',
        'name':item,
      }
      this.lawOfficeDetails = obj
      // this.loading = true;
      // this.$store
      //   .dispatch("addLocations", {
      //     name: newTag,
      //     stateId: 512,
      //   })
      //   .then((response) => {
      //     var tag = response;
      //     this.locations.push(response);
      //     this.value.location = response;
      //     this.loading = false;
         
      //   })
      //   .catch((error) => {
      //     this.loading = false;
         
          
      //   });
    },
    },
    watch: {
      showPopup(val) {
        if (!val) this.$emit("hideMe");
      },
    },
    mounted() {
      this.showPopup = true;
      
      this.getLawOfficeList();
    },
    data: () => ({
      lawOfficeList:[],
      lawOfficeDetails:null,
        editor: ClassicEditor,
    editorConfig: {
      toolbar: ['bold', 'italic', '|', 'undo', 'redo', 'NumberedList', 'BulletedList',],
    },
        lawOfficeComments:'',
      showPopup: false,
      settingCaseNumber: false,
      formerrors: {
        msg: "",
      },
      lawOfficeName:'',
    }),
    props: {
      caseNumber: {
        type: String,
        default: null,
      },
      isCaseNumberEdit: {
        type: Boolean,
        default: false,
      },
      petitionDetails: {
        type: Object,
        default: null,
      },
    },
    components:{
        immiInput,
        selectField
    }
  };
  </script>