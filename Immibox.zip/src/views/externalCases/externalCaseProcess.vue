<template>
    <div class="tabs-layout-header-items padr0">
      <div class="items-left">
        <ul class="items-list"
          v-if="checkProperty(petition, 'companyDetails', 'name') || checkProperty(petition, 'beneficiaryInfo', 'name') || checkProperty(petition, 'typeDetails','name')">
          <li>
         
         <span>{{checkProperty(petition,"typeDetails","name")}} <br/>
           <small>{{checkProperty(petition ,"subTypeDetails","name")}}</small>
            </span>
       </li>
          <li v-if=" [51].indexOf(getUserRoleId) <= -1 && checkProperty(petition,'beneficiaryInfo','name')" class="tabwidth">
            Beneficiary
            <span style="font-size:12px">{{ checkProperty(petition,'beneficiaryInfo','name') }}</span>
          </li>
          <li v-if="getTenantTypeId != 2 && [51].indexOf(getUserRoleId) <= -1 && checkProperty(petition,'companyDetails','name')" class="tabwidth">
            Petitioner
            <span style="font-size:12px">{{ checkProperty(petition,'companyDetails','name') }}</span>
          </li>
        </ul>
          <ul class="peoples_list" >
          <template v-if="checkProperty(petition ,'assignRoleLogs') && checkProperty(petition ,'assignRoleLogs','length')>0">
            <li >
            <figure class="moreinfo"><img src="@/assets/images/main/avatar3.svg"/> </figure>
            <div class="peoples-dropdown morepeople">
              <div class="morepeople_cnt">
              <VuePerfectScrollbar 
              ref="mainSidebarPs"
              class="scroll-area--nofications-dropdown p-0"
                :settings="peoplelist"
              >
              <ul>
              <template v-for="( assignedUser ,asindx) in petition['assignRoleLogs']">
                
                  <li :key='asindx' >
                  <figure>
                     <img class="user-image" :src="getUserPrfoilePic(assignedUser.userId)" />
                     </figure>
                     <div>
                     <h5>{{checkProperty(assignedUser ,"name")}}</h5>
                     
                     <h6 v-if="assignedUser.roleName">{{checkProperty(assignedUser ,"roleName")}}</h6>
                     </div>
                        
                      
                  </li>
                
              </template>
                  
              </ul>
              </VuePerfectScrollbar>
              </div>
            </div>
            </li>
          </template>
        </ul>
        
      </div>
      <div class="items-right capactions" v-if="checkCurrentUrl && !loadedFromPreview">
        <ul>
          <li class="law-office-lbl" v-if="checkProperty(petition ,'lawOfficeInfo') && checkProperty(petition ,'lawOfficeInfo','name')" >
          
          Law Office
          <span>{{ checkProperty(petition ,'lawOfficeInfo','name')}}</span>
        </li> 
          <template >
          <li v-if="checkProperty(petition, 'statusDetails', 'name')">
            <div class="dropdown-button-container">
              <vs-button class="borderRadius20 status-btn"><span 
              
                v-bind:class="{[getCaseColors(checkProperty(petition ,'statusDetails','id'))]:true }"
              >{{checkProperty(petition,'statusDetails','name') }}</span>
                      </vs-button>
            </div>
          </li>
        </template>
          
        <!-- v-if="checkActionItem && checkToShowActiononGen" -->
          <li class="menu_dropdown actions_dropdown actions_dropdown-hover mar0" v-if="[50,51].indexOf(getUserRoleId) <= -1">
            <div class="d-flex">
              <button class="actions_btn actions_btn_v2">Actions </button>
              <div class="menu_list_wrap new_actions_menu menu_v2 nextstep-shadow">
                <div class="menu_list">
                  <template v-for="(menuItem, index) in menuItems">
                    <template v-if="checkActionRequired(menuItem)">
                      <div class="menu_item drop_menu_items" :code="menuItem['code']">
                          <a @click="openActionPopup(menuItem)">
                            <template> {{ menuItem.actionLable }} </template></a>   
                      </div>
                    </template>
                  </template>
                </div>
              </div>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </template>
  
  <script>
  import docType from "@/views/common/docType.vue"
  import moment from "moment";
  import immitextarea from "@/views/forms/fields/simpletextarea.vue";
  import selectField from "@/views/forms/fields/simpleselect.vue";
  import immiInput from "@/views/forms/fields/simpleinput.vue";
  import VuePerfectScrollbar from "vue-perfect-scrollbar";
  import Vue from "vue";
  import datepickerField from "@/views/forms/fields/datepicker.vue";
  import commonImage from "@/assets/images/main/avatar3.svg"
  Vue.use(CKEditor);
  import CKEditor from '@ckeditor/ckeditor5-vue2';
  import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
  import FileUpload from "vue-upload-component/src";
  export default {
    provide() {
      return {
        parentValidator: this.$validator,
      };
    },
    components: {
      datepickerField,
      docType,
      immitextarea,
      selectField,
      immiInput,
      FileUpload,
      VuePerfectScrollbar,
    },
    props: {
      petition: {
        type: [Object, Array],
        default: null,
      },
      loadedFromPreview: false,
    },
    computed: {
      checkGenShareLink(){
        let returnVal = true
        let isSlg = true;
        if(this.checkProperty(this.petition, 'questionnaireTplType') == "general"){
          if(this.checkProperty(this.petition,'intStatusDetails','id')==1){
            returnVal = true
          }else{
          returnVal = false
          }
        }
        return returnVal
      },
      checkActionItem() {
        let returnVal = true;
        let isSlg = true;
        if(this.checkProperty(this.petition, 'questionnaireTplType') == "general"){
          isSlg = false
        }
        if (this.checkProperty(this.petition, 'completedActivities') && this.checkProperty(this.petition, 'completedActivities', 'length') > 0) {
          if ([50, 51].indexOf(this.getUserRoleId) > -1) {
            if(isSlg == false){
              if(this.getUserRoleId == 51){
                if (this.petition.completedActivities.indexOf('CREATE') > -1 && this.petition.completedActivities.indexOf('SUBMIT_TO_LAW_FIRM') > -1) {
                  returnVal = false;
                }
                else {
                  returnVal = true;
                }
              }else{
                if (this.petition.completedActivities.indexOf('CREATE') > -1 && this.petition.completedActivities.indexOf('REGISTERED') > -1) {
                  returnVal = false;
                }
                else {
                  returnVal = true;
                }
              }
            }else{
              if (this.petition.completedActivities.indexOf('CREATE') > -1 && this.petition.completedActivities.indexOf('SUBMIT_TO_LAW_FIRM') > -1) {
                  returnVal = false;
                }
                else {
                  returnVal = true;
                }
            }
          }
  
          else {
            if ((this.petition.completedActivities.indexOf('CASE_CREATED') > -1 || this.petition.completedActivities.indexOf('NOT_SELECTED') > -1 || this.petition.completedActivities.indexOf('DENIED') > -1 ||
              this.petition.completedActivities.indexOf('INVALIDATED') > -1)) {
              returnVal = false;
            }
            else {
              returnVal = true;
            }
          }
  
        }
        return returnVal
      },
      checkShareLinkBtn(){
        if([50].indexOf(this.getUserRoleId)>-1){
          if(this.petition.completedActivities.indexOf('SUBMIT_TO_LAW_FIRM') > -1){
            return false
          }
          else{
            return true
          }
        }else{
          return false
        }
      },
      checkToShowActiononGen(){
        let returnVal = true;
        let isSlg = true;
        if(this.checkProperty(this.petition, 'questionnaireTplType') == "general"){
          isSlg = false
        }
        if(this.checkProperty(this.petition,'intStatusDetails','id')==2 && isSlg == false){
            if([50].indexOf(this.getUserRoleId)>-1){
              returnVal = true
            }
            else{
              returnVal = false
            }
        }
        return returnVal
      }
    },
    data: () => ({
      peoplelist: { 
        wheelSpeed: 0.6,
      },
      isSlg:true,
      capFormSubmited:false,
      capActionErrors:'',
      editor: ClassicEditor,
      editorConfig: {
        toolbar: ['bold', 'italic', '|', 'undo', 'redo', 'NumberedList', 'BulletedList',],
      },
   
      //payReceipt:'',
      premiumProcessingFormErrors: '',
      premiumProcessing: false,
      premiumDocuments: [],
      premiumProcessingComment: '',
      documentTypes: ["Electronic", "Original"],
      documentType: null,
      selectedCaseType: null,
      selectedSubtype: null,
      BeneficiaryList: [],
      branchList: [],
      premiumProcessing: false,
      petitionersList: [],
      Petitionervalue: null,
      Beneficiaryvalue: null,
      branchvalue: null,
      uploading: false,
      trackingDocuments: [],
      receiptDocuments: [],
      uscisDocuments: [],
      uscisResponse: {
        comments: '',
        documets: '',
        status: null,
        fees:'',
      },
      trackingDocUpload: false,
      payment: '',
      registeredDate: null,
      submittedDate: null,
      paymentDate: null,
      receiptName: '',
      trackingNumber: '',
      formErrors: "",
      comments: '',
      selectedAction: '',
      value: [],
      webBaseUrl: '',
      caseToken: '',
      linkShareToEmailList: [],
      linkShareToemailsText: '',
      anonymousAccesLink: '',
      sharing: false,
      linkGenareating: false,
      copyingLink: false,
      menuItems: [
      {
          code: "ASSIGN_LAW_OFFICE",
          name: "Add Law Office",
          actionLable: "Add Law Office",
          forAdmins: true,
          roleIds: [3, 4],
          completedActivities: ["SUBMIT_BY_BENEFICIARY", "SUBMIT_TO_LAW_FIRM"]
        },
        {
          code: "ASSIGN_TO",
          name: "Assign User",
          actionLable: "Assign User",
          forAdmins: true,
          roleIds: [3, 4],
          completedActivities: ["CREATE", "SUBMIT_BY_BENEFICIARY"]
        },
        {
          code: "UPDATE_STATUS",
          name: "Update Status",
          actionLable: "Update Status",
          forAdmins: true,
          roleIds: [3, 4],
          completedActivities: ["CREATE", "SUBMIT_TO_LAW_FIRM"]
        },
        
      ],
      internalStatusList:[{_id: "637f7c565648c5150123duse", id: 2, name: "Hold"}],
      internalStatus:null,
    }),
    methods: {
      getUserPrfoilePic(userId){
              let myDocements = _.find(this.petition.assignLogUserDetails ,{'_id':userId});

           if(myDocements && myDocements.profilePicture!=''){

             return myDocements.profilePicture
           }else{

             return commonImage;
           }

         },
      checkActionRequired(obj) {
        let item = obj;
        var $self = this;
        let caseCreatedPermision = true
        let createdBy = null;
        let isSlg = true;
        let paymentConfirmed = false;
        let paymentStatus = '';
        if (this.checkProperty(this.petition, 'completedActivities') || true) {
          switch (item.code) {
  
            case "ASSIGN_LAW_OFFICE":
              if(this.checkProperty(this.petition,'lawOfficeInfo', 'name'))return false;
              return true;
              break;
            case "ASSIGN_TO":
              
              return true
              break;
              case "UPDATE_STATUS":
              if([22,23,24,31].indexOf(this.checkProperty(this.petition,'statusDetails', 'id'))>-1)return false;
              return true
              break;

          }
        }
      },
      manageApprovalProcess(code = '') {
        let formscope = code
        let payload = {};
        this.$validator.validateAll(formscope).then((result) => {
          if (result) {
            payload['today'] = moment().format('YYYY-MM-DD')
              payload['petitionId'] = this.checkProperty(this.petition, '_id')
            if (code == 'SUBMIT_CASE') {
              payload['comment'] = this.comments;
              payload['action'] = 'SUBMIT_TO_LAW_FIRM'
            }
            if(code == 'VERIFY'){
              payload['comments'] = this.comments;
              payload['action'] = 'VERIFY'
            }
            if(code == 'REGISTERED'){
              payload['registeredDate'] = this.registeredDate;
              payload['comments'] = this.comments;
              payload['action'] = 'REGISTERED'
            }
            if (code == 'RECEIPT_OF_PAYMENT_MADE') {
              payload['paymentDate'] = this.paymentDate;
              payload['payAmount'] = this.payment;
              payload['payReceipt'] = this.receiptDocuments;
              payload['documents'] = this.trackingDocuments;
              payload['trackingNumber'] = this.trackingNumber;
              payload['comments'] = this.comments;
              payload['action'] = 'RECEIPT_OF_PAYMENT_MADE'
            }
            if(code == 'GEN_PTNR_PAYMENT_INFO'){
              payload['action'] = 'CONFIRM_PETITIONER_PAYMENT_INFO'
            }
            if (code == 'TRACKING_INFO_UPDATE') {
              payload['comment'] = this.comments;
              payload['trackingNumber'] = this.trackingNumber;
              payload['receiptName'] = this.receiptName;
              payload['documents'] = this.trackingDocuments;
              payload['action'] = 'TRACKING_INFO_UPDATE'
            }
            if(code == 'GEN_SUBMIT_TO_USCIS'){
                payload['trackingNumber'] = this.trackingNumber;
                payload['registeredDate'] = this.registeredDate;
                payload['documents'] = this.trackingDocuments;
                payload['action'] = 'REGISTERED';
                //payload['uscisFeeStatus'] = this.checkProperty(this.uscisResponse, 'fees', 'id')
            }
            if(code == 'GEN_FINAL_SUBMIT_TO_USCIS'){
              payload['action'] = this.checkProperty(this.uscisResponse, 'status', 'id')
              payload['description'] = this.uscisResponse.comments;
              if(this.checkProperty(this.petition,'registeredInfo','documents') && this.checkProperty(this.petition['registeredInfo'],'documents','length') == 0){
                 payload['documents'] = this.trackingDocuments;
              }
              if(this.checkProperty(this.petition,'registeredInfo','trackingNumber') == ''){
                payload['trackingNumber'] = this.trackingNumber;
              }
            }
            if (code == 'SUBMIT_TO_USCIS') {
              payload['description'] = this.uscisResponse.comments;
              payload['documents'] = this.uscisDocuments;
              payload['action'] = this.checkProperty(this.uscisResponse, 'status', 'id')
              payload['documentType'] = this.documentType;
            }
            this.capFormSubmited = true;
            this.capActionErrors = '';
            let path = '/cap-registrations/manage-approval-process'
            this.$store.dispatch("commonAction", { "data": payload, "path": path }).then((response) => {
              this.$modal.hide(formscope);
              this.capFormSubmited = false;
              this.updatepetition()
              //alert(JSON.stringify(response))
            }).catch((error) => {
              this.capActionErrors = error;
              this.capFormSubmited = false;
  
            })
  
          }
  
        });
      },
      openActionPopup(item) {
      
        switch (item.code) {
          case "ASSIGN_LAW_OFFICE":
            this.$emit("assignLawOffice", true);
        break;
          case "ASSIGN_TO":
          this.$emit("assignTo", true);
            break;
          case "UPDATE_STATUS":
          this.$emit("updateStatus", true);
            break;
        }
      },
      updateInternalStatus(code = ''){
        let formscope = code
        let payload = {};
        this.$validator.validateAll(formscope).then((result) => {
          if (result) {
            payload['today'] = moment().format('YYYY-MM-DD');
            payload['petitionIds'] = [this.checkProperty(this.petition, '_id')];
            payload['comments'] = this.comments;
            if(this.checkProperty(this.petition,'intStatusDetails','id')==1){
              payload['intStatusId'] = 2
            }
            else{
              payload['intStatusId'] = 1
            }
            //payload['intStatusId'] = this.checkProperty(this.internalStatus, 'id');
            this.capFormSubmited = true;
            this.capActionErrors = '';
            let path = '/cap-registrations/update-internal-status'
            this.$store.dispatch("commonAction", { "data": payload, "path": path }).then((response) => {
              this.$modal.hide(formscope);
              this.capFormSubmited = false;
              this.updatepetition()
            }).catch((error) => {
              this.capActionErrors = error;
              this.capFormSubmited = false;
            })
          }
        })
      },
      changeinternalList(){
        if(this.checkProperty(this.petition,'intStatusDetails','id')==1){
          this.internalStatusList = [{_id: "637f7c565648c5150123duse", id: 2, name: "Hold"}]
        }
        else{
          this.internalStatusList = [{_id: "637f7c565648c5150123deab", id: 1, name: "Active"}]
        }
      },
      addUscisOption(){
        this.uscisResponse.fees = this.USCISfeesList[0]
          let temArry = [];
          let obj = { "name": 'Registered', 'id': 'REGISTERED' }
          let fdObj = _.find(temArry,{'id':'REGISTERED'})
          if(!fdObj){
            temArry.push(obj)
          }
          this.genUSCISsatatus=[
      { "name": 'Selected', 'id': 'SELECTED' },
        { "name": 'Not Selected', 'id': 'NOT_SELECTED' },
      ],
          _.forEach(this.genUSCISsatatus,(item)=>{
            let filedObj = _.find(temArry,{'id':item['item']})
            if(!filedObj){
              temArry.push(item)
            }
          });
          this.genUSCISsatatus = temArry
          this.uscisResponse.status = this.genUSCISsatatus[0]
  
      },
      removeUscisOption(){
        let tempArr = _.filter(this.genUSCISsatatus,(item)=>{
          return item['id'] != 'REGISTERED'
        });
        if(tempArr){
          this.genUSCISsatatus = tempArr;
        }
      },
      goToQuestionnaire() {
        let routedId = this.checkProperty(this.petition, '_id')
        this.$router.push("/cap-registration-questionnaire/" + routedId)
      },
      clearFeefields(){
        this.paymentDate = null;
        this.uscisResponse.status = this.genUSCISsatatus[0];
      },
      clearUSCISfields(){
        this.trackingDocuments = [];
        this.uscisResponse.fees = '';
        this.trackingNumber = '';
        this.registeredDate ='';
      },
      submitForm() {
        this.$validator.validateAll('PREMIUM_PROCESS').then((result) => {
          let self = this;
          if (result) {
            let postData = {
              petitionId: self.checkProperty(self.petition, '_id'),
              documents: self.premiumDocuments,
              //today: moment().format("YYYY-MM-DD"),
              comment: self.premiumProcessingComment,
              premiumProcessing: !this.checkProperty(this.petition, 'premiumProcessing')
  
            }
            //this.updatingPremiumProcessing =true;            
            this.$store
              .dispatch("commonAction", { "data": postData, "path": "/cap-registrations/manage-premium-process" })
              .then(response => {
                this.$modal.hide('PREMIUM_PROCESS');
                this.updatepetition()
                this.showToster({ message: response.message, isError: false });
                //this.$emit("updatepetition", "Case Details");                 
              })
              .catch((error) => {
                this.premiumProcessingFormErrors = error;
                this.updatingPremiumProcessing = false;
              })
          }
        });
      },
      clearAllFields() {
        //this.payReceipt = '';
        this.internalStatus = null;
        this.capActionErrors = '';
        this.capFormSubmited = false;
        this.premiumProcessingFormErrors = '',
        //this.premiumProcessing = false,
        this.premiumDocuments = [],
        this.premiumProcessingComment = '',
        this.documentType = this.documentTypes[0]
        this.payment = '';
        this.registeredDate = null,
        this.submittedDate = null,
        this.paymentDate = null,
        this.receiptName = '';
        this.trackingNumber = '';
        this.comments = '';
        this.uscisResponse = {
          comments: '',
          documets: '',
          status: null,
          fees:'',
        }
        this.trackingDocuments = [];
        this.receiptDocuments = [];
        this.uscisDocuments = [];
      },
      downloadfile(value) {
        this.$emit('download_or_view', value);
      },
      createCaseRedirect() {
        let data = {};
        if (this.checkProperty(this.petition, 'beneficiaryDetails')) {
          data['beneficiaryDetails'] = this.checkProperty(this.petition, 'beneficiaryDetails')
        }
        if (this.checkProperty(this.petition, 'beneficiaryInfo') && this.checkProperty(this.petition, 'beneficiaryInfo', 'name') && this.checkProperty(this.petition, 'beneficiaryInfo', '_id')) {
  
          data['beneficiaryDetails'] = { "name": '', '_id': '' };
          data['beneficiaryDetails']['name'] = this.checkProperty(this.petition, 'beneficiaryInfo', 'name');
          data['beneficiaryDetails']['_id'] = this.checkProperty(this.petition, 'beneficiaryInfo', '_d');
  
        }
        if (this.checkProperty(this.petition, 'branchDetails')) {
          data['branchDetails'] = this.checkProperty(this.petition, 'branchDetails')
        }
        if (this.checkProperty(this.petition, 'companyDetails')) {
          data['companyDetails'] = this.checkProperty(this.petition, 'companyDetails')
        }
        if (this.checkProperty(this.petition, '_id')) {
          data['capRegId'] = this.checkProperty(this.petition, '_id')
        }
        data['reqConsdnOfAdvDegreeExptn'] = this.checkProperty(this.petition, 'beneficiaryInfo', 'reqConsdnOfAdvDegreeExptn')
  
        this.$store.commit('updateCapCaseDetails', data)
        this.$router.push({ name: 'petitions', params: { 'capCaseCreate': true } })
      },
      genarateLink() {
        this.webBaseUrl = window.location.origin;
        this.linkShareToEmailList = [];
        this.linkShareToemailsText = '';
        this.sharing = false;
        let petitionDetails = this.petition;
        if ((this.checkProperty(petitionDetails, 'token') == '' && (this.caseToken == '' || this.caseToken == null || this.caseToken == undefined))) {
          let postData = {
            "petitionId": ''
          };
          let path = "/cap-registrations/generate-link"
          postData['petitionId'] = petitionDetails['_id'];
          this.anonymousAccesLink = '';
          this.linkGenareating = true;
  
          this.$store.dispatch("commonAction", { "data": postData, "path": path })
            .then((res) => {
              this.linkGenareating = false;
              this.petition['token'] = this.checkProperty(res, 'token');
              this.caseToken = this.checkProperty(res, 'token');
              if (this.checkProperty(petitionDetails, 'questionnaireFilled')) {
                this.anonymousAccesLink = this.webBaseUrl + "/filled-cap-registration-details/" + petitionDetails['_id'] + "?token=" + this.checkProperty(res, 'token');
              } else {
                this.anonymousAccesLink = this.webBaseUrl + "/fill-cap-registration/" + petitionDetails['_id'] + "?token=" + this.checkProperty(res, 'token');
              }
  
              this.$modal.show('capgenaratModal');
            })
            .catch((err) => {
              this.linkGenareating = false;
              this.showToster({ message: err, isError: true });
            })
        } else {
          if (this.checkProperty(petitionDetails, 'questionnaireFilled')) {
            this.anonymousAccesLink = this.webBaseUrl + "/filled-cap-registration-details/" + petitionDetails['_id'] + "?token=" + this.checkProperty(petitionDetails, 'token');
          }
          this.$modal.show('capgenaratModal');
        }
  
      },
      showShareLink() {
        this.$modal.show('capgenaratModal')
      },
      upload(fils, category = '') {
        this.disablePWDstatus = false;
        this.pwdDocFormatError = '';
        let model = _.cloneDeep(fils);
        this.value = [];
        var _current = this;
        let efiles = [];
        efiles = _.filter(model, (e) => {
          return e.url != null && e.url != "";
        });
        let nfiles = _.filter(model, (e) => {
          return e.url == null || e.url == undefined;
        });
  
        let mapper = nfiles.map(
          (item) =>
          (item = {
            name: item.name,
            file: item.file ? item.file : null,
            url: item.url ? item.url : "",
            path: item.path ? item.path : "",
            status: true,
            mimetype: item.type ? item.type : item.mimetype,
          })
        );
        let tempFiles = [];
        if (mapper.length > 0) {
          if (category == 'trackingDocuments') {
            this.trackingDocUpload = true
          } else {
            this.uploading = true;
          }
  
  
          let count = 0;
          mapper.forEach((doc, index) => {
            let formData = new FormData();
            formData.append("files", doc.file);
            formData.append("secureType", "private");
            formData.append("getDetails", true);
            count++;
            this.$store.dispatch("uploadS3File", formData).then((response) => {
              response.data.result.forEach((urlGenerated) => {
  
                let obj = {
                  uploadedBy: this.checkProperty(this.getUserData, 'userId'),
                  uploadedByName: this.checkProperty(this.getUserData, 'name'),
                  uploadedByRoleId: this.getUserRoleId,
                  uploadedByRoleName: this.checkProperty(this.getUserData, 'loginRoleName'),
                }
                let tempUrl = urlGenerated
                tempUrl = Object.assign(tempUrl, { uploadedBy: this.checkProperty(this.getUserData, 'userId'), uploadedByName: this.checkProperty(this.getUserData, 'name'), uploadedByRoleId: this.getUserRoleId, uploadedByRoleName: this.checkProperty(this.getUserData, 'loginRoleName') });
                //alert(JSON.stringify(tempUrl))
                tempFiles.push(tempUrl["name"]);
                // trackingDocuments          
                if (category == 'trackingDocuments') {
                  this.trackingDocuments.push(tempUrl);
                }
                if (category == 'receiptDocuments') {
                  this.receiptDocuments.push(tempUrl);
                }
                if (category == 'uscisDocuments') {
                  this.uscisDocuments.push(tempUrl);
                }
                if (category == 'premiumDocuments') {
                  this.premiumDocuments.push(tempUrl);
                }
                doc.url = urlGenerated;
                doc.path = urlGenerated;
                doc["mimetype"] = urlGenerated["mimetype"];
                doc["type"] = urlGenerated["mimetype"];
                delete doc.file;
                mapper[index] = doc;
              });
              if (index >= mapper.length - 1) {
                this.uploading = false;
                this.trackingDocUpload = false;
                // _current.$vs.loading.close();
              }
            });
          });
          if (efiles.length > 0) efiles.push(...mapper);
          //this.CommentPayload["documents"] = efiles
        }
      },
      remove(item, data, filindex) {
        data.splice(filindex, 1);
        this.disablePWDstatus = false;
  
  
      },
      updatepetition() {
        this.$emit("updatepetition", "Case Details");
      },
      shareLink() {
        let self = this;
        let postData = {
          "petitionId": self.petition['_id'],
          "caseNo": self.petition['caseNo'],
          "link": self.anonymousAccesLink,
          "email": self.linkShareToemailsText,
          entityType: 'case'
        }
        this.sharing = true;
        this.$store.dispatch("commonAction", { "data": postData, "path": "/cap-registrations/share-link" })
          .then(response => {
            this.sharing = false;
  
            this.showToster({ message: response.message, isError: false });
            this.$modal.hide('genaratModal');
            this.linkShareToEmailList = [];
            this.linkShareToemailsText = '';
          }).catch((err) => {
            this.sharing = false;
            this.showToster({ message: err, isError: true });
          });
      },
      async copyLink() {
        let self = this;
        this.copyingLink = true;
        let petitionDetails = this.petition;
        if ((this.checkProperty(petitionDetails, "token") || this.anonymousAccesLink != '') || (this.checkProperty(petitionDetails, "lcaToken") || this.anonymousLcaAccesLink != '')) {
          try {
            await navigator.clipboard.writeText(this.anonymousAccesLink);
            this.showToster({ message: "Copied successfully ", isError: false, });
            this.showToolTip = true;
            this.copyingLink = false;
            setTimeout(() => {
              this.showToolTip = false;
              this.$modal.hide('genaratModal');
            }, 10)
          } catch ($e) {
            this.copyingLink = false
            //  filderPath = "";
            this.showToster({ message: "Can't Copied folder path! ", isError: true, });
          }
        }
  
      },
      getBranchList() {
  
        this.branchList = [];
        let item = {
          filters: {
            "title": '',
            "createdDateRange": [],
            "statusList": [],
            "activeList": [],
            "countryIds": [],
            "stateIds": [],
            "locationIds": []
          },
          getMasterData: true,
          page: 1,
          perpage: 1000,
          sorting: { "path": "createdOn", "order": -1 },
  
        };
        this.$store
          .dispatch("getList", { "data": item, "path": "/branch/list" })
          .then(response => {
            this.branchList = response.list;//branchvalue
  
  
          }).catch((error) => {
            this.branchList = [];
          })
      },
      getPetitioners(callFromSerch = false, searchText = '') {
  
        let _self = this;
        let query = {
          "matcher": {
            "searchString": searchText,
            "statusIds": [],
            "countryIds": [],
            "stateIds": [],
            "locationIds": [],
            "createdDateRange": []
          },
          "sorting": { "path": "createdOn", "order": 1 },
          "page": 1,
          "perpage": 100,
          getMasterData: true
        }
        this.$store.dispatch("getList", { data: query, path: '/company/list' }).then(response => {
  
          _self.petitionersList = response.list;
  
        }).catch((err) => {
          this.petitionersList = [];
  
        })
      },
      int() {
        //this.premiumProcessing = !this.petition.premiumProcessing;
      }
  
    },
    mounted() {
      this.int();
      this.getPetitioners();
      this.getBranchList();
      if(this.checkProperty(this.petition, 'questionnaireTplType') == "general"){
          this.isSlg = false
        }
      this.caseToken = this.checkProperty(this.petition, 'token');
      setTimeout(() => {
        this.caseToken = this.checkProperty(this.petition, 'token');
  
      }, 10)
      setTimeout(() => {
        if (this.checkProperty(this.petition, 'petitionerId')) {
          if (this.petitionersList && this.checkProperty(this.petitionersList, 'length') > 0) {
            let obj = _.find(this.petitionersList, { "_id": this.checkProperty(this.petition, 'petitionerId') })
            this.Petitionervalue = obj
          }
        }
        if (this.branchList && this.checkProperty(this.branchList, 'length') > 0) {
          let obj = _.find(this.petitionersList, { "_id": this.checkProperty(this.petition, 'branchId') })
          this.branchvalue = obj
        }
      }, 100)
      if (this.checkProperty(this.petition, 'beneficiaryDetails')) {
        this.Beneficiaryvalue = this.checkProperty(this.petition, 'beneficiaryDetails')
      }
      
    },
  }
  </script>