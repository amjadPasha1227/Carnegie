<template>
    <div class="all_documents_sec">
      
        <div class="tabs_list_section">
            <ul class="documents_list_tabs">
                <li :class="{'active':setActiveTab == 'All' }" @click="setActiveTab = 'All'" > All</li>
                <li  :class="{'active': setActiveTab == 'Case Docs'  }" @click="setActiveTab = 'Case Docs'" > Petition Docs</li>
                <li v-if="( ([2,10].indexOf(petition['type'])>-1 &&  checkProperty(petition,'petitionerId')) || [2,10].indexOf(petition['type'])<=-1 )" :class="{'active': setActiveTab == 'Company Docs' }" @click="setActiveTab = 'Company Docs'" > Company Docs</li>
                <!-- <li :class="{'active': setActiveTab == 'Petitioner Docs'  }" @click="setActiveTab = 'Petitioner Docs'"> Petitioner Docs</li>  -->
                <li v-if="[9].indexOf(checkProperty(petition,'typeDetails', 'id')) <=-1" :class="{'active': setActiveTab == 'Forms & Letters'  }" @click="setActiveTab = 'Forms & Letters'"> Forms & Letters</li>  
                <li v-if="[9].indexOf(checkProperty(petition,'typeDetails', 'id')) <=-1 && isLcaRequired" :class="{'active': setActiveTab == 'LcaDocs'  }" @click="setActiveTab='LcaDocs'"> LCA Docs</li>
                <li  :class="{'active': setActiveTab == 'Checks'  }" @click="setActiveTab='Checks'"> Cheques</li>  
                <li v-if="[9].indexOf(checkProperty(petition,'typeDetails', 'id')) <=-1" :class="{'active': setActiveTab == 'Downloads'  }" @click="setActiveTab = 'Downloads'"> Downloads</li>  

                <li  v-if="[9].indexOf(checkProperty(petition,'typeDetails', 'id')) <=-1 ||
                ([9].indexOf(checkProperty(petition,'typeDetails', 'id')) >-1 && checkWorkActivityisRequires('REQUEST_PETITIONER_SIGN') && checkActivityCompleted('REQUEST_PETITIONER_SIGN')) "
                 :class="{'active': setActiveTab == 'Scanned Docs'  }" @click="setActiveTab = 'Scanned Docs'"> Scanned Docs</li>  
                <!-- <li :class="{'active': setActiveTab == 'Filed Copies' }" @click="setActiveTab = 'Filed Copies'"> Filed Copies</li> -->
                <li v-if="checkProperty( this.petition ,'subTypeDetails' ,'id') !=15" :class="{'active': setActiveTab == 'USCIS Notices' }" @click="setActiveTab = 'USCIS Notices'" >USCIS Docs</li>
                <li v-if="[9].indexOf(checkProperty(petition,'typeDetails', 'id')) <=-1" :class="{'active': setActiveTab == 'Affidavits'  }" @click="setActiveTab = 'Affidavits'"> Affidavits</li>  
                <template v-if="(canRenderField('slgOfferLetter', fieldsArray, false, 'documents', 'slgOfferLetter') ||
                canRenderField('slgSignedOfferLetter', fieldsArray, false, 'documents', 'slgSignedOfferLetter')) && fieldsArray && false">
                    <li :class="{'active': setActiveTab == 'offerLetters'  }" @click="setActiveTab = 'offerLetters'"> Offer Letters</li>  
                </template>
                <li v-if="[9].indexOf(checkProperty(petition,'typeDetails', 'id')) <=-1" :class="{'active': setActiveTab == 'Other Docs'  }" @click="setActiveTab = 'Other Docs'"> Other Docs</li>  
                <li v-if="([9].indexOf(checkProperty(petition,'typeDetails', 'id')) >-1 ) || ([1].indexOf(this.checkProperty(this.petition ,'type')) >-1 && this.checkProperty(this.workFlowDetails ,'manageRfeCase') =='with_in_case') " :class="{'active': setActiveTab == 'Response Docs'  }" @click="setActiveTab = 'Response Docs'">RFE Response Docs</li>  
            </ul>
            <button  class="download_all" @click="openDownloadPopup();prepopulateSavedDocs();showRestore()">
                Download All
            </button>
        </div>
        
        <div class="tab-inner-content">
            <div class="tabs-content-panel">
                <div class="card-panels">
                    <vs-row vs-justify="center">
                        <vs-col class="p-0" type="flex" vs-justify="center" vs-align="center" vs-w="12">
                            <div class="forms_letters dd forms_letters-v2"> 
                                <vs-card class="no-card documents_list_wrapper">
                                    <div class="documents_list" v-if="setActiveTab == 'Case Docs' || setActiveTab == 'All' ">
                                        <div class="doc_list_header" v-if="setActiveTab == 'Case Docs' || setActiveTab == 'All' ">
                                            <span v-if="[9].indexOf(checkProperty(petition,'typeDetails', 'id')) >-1">Petition Docs</span>
                                            <span v-else>Beneficiary Docs</span>
                                            <span class="download-all" @click="openUploadPopup('caseDocs')">
                                                Upload
                                                <img src="@/assets/images/main/upload.svg" />
                                            </span>
                                        </div>
                                        <div class="documents_list_inner">
                                                <template v-for="(item,inde,) in processedCaseDocs " >
                                                    <template v-if="checkValue({'dataVal':item})"> 
                                                        <allDocumentsComponent :ref="'caseDocs'" @openDownloadPopup="openDownloadPopup" v-if="setActiveTab == 'Case Docs' || setActiveTab == 'All' "  @download_or_view="download_or_view" @updatepetition="updatepetition" :callFromCaseDocs="true"  :documentsList="item" :docsLabel="returnDocLabel({'dataVal':item})"  :petition="petition" :docCategory="'caseDocs'"    :docUserType="'Case Docs'" />
                                                    </template>
                                                </template>
                                            <NoDataFound :loading="false" ref="NoDataFoundRef"  v-if="checkSectionValue({'dataVal':processedCaseDocs})" content=""  heading="No Documents Found." type='documents' />
                                        </div>
                                    </div>
                                    <div class="documents_list" v-if="(setActiveTab == 'Case Docs' || setActiveTab == 'All') && checkProperty(petition,'dependentsInfo','spouse') &&  (checkProperty(petition['dependentsInfo']['spouse'], 'h4Required')==true || [2,10].indexOf(checkProperty(petition,'typeDetails', 'id'))>-1) ">
                                        <div class="doc_list_header" v-if="setActiveTab == 'Case Docs' || setActiveTab == 'All' ">
                                            <span>Spouse Docs</span>
                                            <span class="download-all" @click="openUploadPopup('spouse')">
                                                Upload
                                                <img src="@/assets/images/main/upload.svg" />
                                            </span>
                                        </div>
                                        <div class="documents_list_inner">
                                            <template v-for="(item,inde) in processedSpouseDocs " >
                                                <template v-if="checkValue({'dataVal':item})"> 
                                                    <allDocumentsComponent @openDownloadPopup="openDownloadPopup" v-if="setActiveTab == 'Case Docs' || setActiveTab == 'All' "  @download_or_view="download_or_view" @updatepetition="updatepetition" :callFromCaseDocs="true"  :documentsList="item" :docsLabel="returnDocLabel({'dataVal':item})"  :petition="petition" :docCategory="'spouse'"    :docUserType="'spouse'" />
                                                </template>
                                            </template>
                                            <NoDataFound :loading="false" ref="NoDataFoundRef"  v-if="checkSectionValue({'dataVal':processedSpouseDocs})" content=""  heading="No Documents Found." type='documents' />
                                        </div>
                                    </div>
                                    <div class="documents_list" v-if="(setActiveTab == 'Case Docs' || setActiveTab == 'All') && [9].indexOf(checkProperty(petition,'typeDetails', 'id')) <=-1 ">
                                        <!-- <div class="doc_list_header" v-if="setActiveTab == 'Case Docs' || setActiveTab == 'All' ">
                                            <span>Children Documents</span>
                                            <span class="download-all">
                                                Upload
                                                <img src="@/assets/images/main/upload.svg" />
                                            </span>
                                        </div> -->
                                        
                                            <template v-if="(setActiveTab == 'Case Docs' || setActiveTab == 'All') && checkProperty(petition,'dependentsInfo') && checkProperty(petition,'dependentsInfo','childrens') &&  checkProperty(petition['dependentsInfo'],'childrens','length')>0">
                                                <template v-for="(item,inde) in petition['dependentsInfo']['childrens'] ">
                                                  <template v-if=" checkProperty(item ,'name')">  
                                                    <div class="doc_list_header" v-if="setActiveTab == 'Case Docs' || setActiveTab == 'All' ">
                                                        <span>Child {{ item['name'] }} Docs  </span>
                                                        <span class="download-all" @click="openUploadPopup('childrens',item)">
                                                            Upload
                                                            <img src="@/assets/images/main/upload.svg" />
                                                        </span>
                                                    </div>
                                                    <div class="documents_list_inner">
                                                        <template v-if="processChildDocs(item , false)" v-for="(childItem,inder) in processChildDocs(item,true) ">
                                                            <template v-if="checkValue({'dataVal':childItem})"> 
                                                                
                                                                <allDocumentsComponent @openDownloadPopup="openDownloadPopup" v-if="setActiveTab == 'Case Docs' || setActiveTab == 'All' "  @download_or_view="download_or_view" @updatepetition="updatepetition" :callFromCaseDocs="true" :documentsList="childItem" :docsLabel="returnDocLabel({'dataVal':childItem})"  :petition="petition" :docCategory="'caseDocs'"    :docUserType="'Case Docs'" />
                                                            </template>
                                                            <!-- <NoDataFound :loading="false" ref="NoDataFoundRef"  v-if="checkSectionValue({'dataVal':item})" content=""  heading="No Documents Found." type='documents' /> -->
                                                        </template>
                                                    </div>
                                                </template>
                                               </template>
                                            </template>
                                            
                                        
                                    </div>
                                    <div class="documents_list" v-if="( ([2,10].indexOf(petition['type'])>-1 &&  checkProperty(petition,'petitionerId')) || [2,10].indexOf(petition['type'])<=-1 ) && (setActiveTab == 'Company Docs' || setActiveTab == 'All') && checkProperty(configurationDetails,'acceptCompayDocsForPtnr') ">
                                        <div class="doc_list_header" v-if="setActiveTab == 'Company Docs' || setActiveTab == 'All' ">
                                            <span>Petitioner Documents</span>
                                            <span class="download-all" @click="openUploadPopup('companyPtnr')">
                                                Upload
                                                <img src="@/assets/images/main/upload.svg" />
                                            </span>
                                        </div>
                                        <div class="documents_list_inner">
                                            <template v-for="(item,inde,) in processedCompanyPtnrDocs " >
                                                <template v-if="checkValue({'dataVal':item})"> 
                                                    <allDocumentsComponent :ref="'Company'" @openDownloadPopup="openDownloadPopup" v-if="( ([2,10].indexOf(petition['type'])>-1 &&  checkProperty(petition,'petitionerId')) || [2,10].indexOf(petition['type'])<=-1 ) && setActiveTab == 'Company Docs' || setActiveTab == 'All' "  @download_or_view="download_or_view" @updatepetition="updatepetition" :callFromCaseDocs="true"  :documentsList="item" :docsLabel="returnDocLabel({'dataVal':item})"  :petition="petition" :docCategory="'companyPtnr'"    :docUserType="'companyPtnr'" />
                                                </template>
                                            </template>
                                            <NoDataFound :loading="false" ref="NoDataFoundRef"  v-if="checkSectionValue({'dataVal':processedCompanyPtnrDocs})" content=""  heading="No Documents Found." type='documents' />
                                        </div>
                                    </div>
                                    <allDocumentsComponent @openUploadPopup="openUploadPopup"  @openDownloadPopup="openDownloadPopup" v-if="( ([2,10].indexOf(petition['type'])>-1 &&  checkProperty(petition,'petitionerId')) || [2,10].indexOf(petition['type'])<=-1 ) && (setActiveTab == 'Company Docs' || setActiveTab == 'All' )"  @download_or_view="download_or_view" @updatepetition="updatepetition"  :documentsList="companyDocs" :docsLabel="'Company Docs'"  :petition="petition"  :docCategory="'company'"    :docUserType="'company'" />
                                    <template v-if="(setActiveTab == 'Forms & Letters' || setActiveTab == 'All') && [9].indexOf(checkProperty(petition,'typeDetails', 'id')) <=-1 ">
                                        <template v-if="filteredLetters && filteredLetters.length>0">
                                            <template v-for="( catDocs ,catInx) in checkFormsandLetters({'dataVal':filteredLetters})">
                                                <template>
                                                    <allDocumentsComponent :uploadFormsAndLetters="true"  :depType="catDocs['depType']"  :docUserType="catDocs['docUserType']" :depLabel="catDocs['depLabel']" @openUploadPopup="openUploadFormsLettersPopup" @openDownloadPopup="openDownloadPopup" v-if="setActiveTab == 'Forms & Letters' || setActiveTab == 'All' "  @download_or_view="download_or_view" @updatepetition="updatepetition"  :documentsList="catDocs['documents']" :docsLabel="catDocs['label']"  :petition="petition" :docCategory="'letters'"  />
                                                </template>
                                            </template> 
                                        </template> 
                                        <template v-else>
                                            <template v-for="( caDocs ,catInx) in tempFilteredForm">
                                            <allDocumentsComponent :uploadFormsAndLetters="true"  :depType="caDocs['depType']"  :docUserType="caDocs['docUserType']" :depLabel="caDocs['depLabel']" @openUploadPopup="openUploadFormsLettersPopup" @openDownloadPopup="openDownloadPopup" v-if="setActiveTab == 'Forms & Letters' || setActiveTab == 'All' "  @download_or_view="download_or_view" @updatepetition="updatepetition"  :documentsList="caDocs['documents']" :docsLabel="caDocs['label']"  :petition="petition" :docCategory="'letters'"  />
                                            </template>
                                        </template>
                                    </template>
                                    <div class="documents_list" v-if="((setActiveTab == 'Scanned Docs' || setActiveTab == 'All') && 
                                    ([9].indexOf(this.checkProperty(this.petition,'typeDetails', 'id')) <=-1 ||
                                    ([9].indexOf(this.checkProperty(this.petition,'typeDetails', 'id')) >-1 && this.checkWorkActivityisRequires('REQUEST_PETITIONER_SIGN')
                                    && this.checkActivityCompleted('REQUEST_PETITIONER_SIGN')))
                                    )
                                     ">
                                        <div class="doc_list_header" v-if="(setActiveTab == 'Scanned Docs' || setActiveTab == 'All') ">
                                            <span>Scanned Docs</span>
                                            <span class="download-all" @click="openUploadPopup('scanned')" v-if="false">
                                                Upload
                                                <img src="@/assets/images/main/upload.svg" />
                                            </span>
                                        </div>
                                        <div class="documents_list_inner">
                                            <allDocumentsComponent @openUploadPopup="openUploadPopup" @openDownloadPopup="openDownloadPopup"  v-if="( ([2,10].indexOf(petition['type'])>-1 &&  checkProperty(petition,'petitionerId')) || [2,10].indexOf(petition['type'])<=-1 ) &&  ((setActiveTab == 'Scanned Docs' || setActiveTab == 'All') && [51].indexOf(getUserRoleId)<=-1 )"  @download_or_view="download_or_view" @updatepetition="updatepetition"  :documentsList="petitionerDocs" :docsLabel="'Petitioner Scanned Docs'"  :petition="petition" :docCategory="'scanPtnr'"    :docUserType="'scanPtnr'" />
                                            <template v-if="[2,10].indexOf(petition['type'])>-1 || (checkProperty(petition,'beneficiaryInfo','maritalStatus' ) !=1 &&   (checkProperty(petition['dependentsInfo']['spouse'], 'h4Required')==true || checkIsChildh4Required) )">
                                                <allDocumentsComponent @openUploadPopup="openUploadPopup" @openDownloadPopup="openDownloadPopup" v-if="(setActiveTab == 'Scanned Docs' || setActiveTab == 'All') && [50].indexOf(getUserRoleId)<=-1  "  @download_or_view="download_or_view" @updatepetition="updatepetition"  :documentsList="beneficairyDocs" :docsLabel="'Beneficiary Scanned Docs'"  :petition="petition" :docCategory="'scanBnf'"    :docUserType="'scanBnf'" />
                                            </template>
                                                <allDocumentsComponent @openUploadPopup="openUploadPopup" @openDownloadPopup="openDownloadPopup"  v-if="(setActiveTab == 'Scanned Docs' || setActiveTab == 'All') && [51,50].indexOf(getUserRoleId)<=-1 "  @download_or_view="download_or_view" @updatepetition="updatepetition"  :documentsList="lawOfficeDocs" :docsLabel="'Law Firm Scanned Docs'"  :petition="petition" :docCategory="'scanLawFirm'"    :docUserType="'scanLawFirm'" />
                                            
                                        </div>
                                    </div>
                                    <template v-if="processedUscisDocs && processedUscisDocs.length>0">
                                        <div class="documents_list" v-if="(setActiveTab == 'USCIS Notices' || setActiveTab == 'All') ">
                                            <div class="doc_list_header" v-if="(setActiveTab == 'USCIS Notices' || setActiveTab == 'All') ">
                                                <span>USCIS Receipt Documents</span>
                                                <span class="download-all" @click="openUploadPopup('uscisNotices')" v-if="false" >
                                                    Upload
                                                    <img src="@/assets/images/main/upload.svg" />
                                                </span>
                                            </div>
                                            <div class="documents_list_inner">
                                                <template v-for="(item,indr) in processedUscisDocs ">
                                                    <allDocumentsComponent :USCISDownLoads="true" @openUploadPopup="openUploadPopup" @openDownloadPopup="openDownloadPopup"  v-if="(setActiveTab == 'USCIS Notices' || setActiveTab == 'All') && [51].indexOf(getUserRoleId)<=-1 "  @download_or_view="download_or_view" @updatepetition="updatepetition"  :documentsList="item['documents']" :docsLabel="item['label']"  :petition="petition" :docCategory="item['userType']"    :docUserType="item['userType']" />    
                                                </template>                                        
                                            </div>
                                        </div>
                                        <allDocumentsComponent @openUploadPopup="openUploadPopup" @openDownloadPopup="openDownloadPopup" v-if="setActiveTab == 'USCIS Notices' || setActiveTab == 'All' "  @download_or_view="download_or_view" @updatepetition="updatepetition"  :documentsList="USCISDocs" :docsLabel="'USCIS Response Documents'"  :petition="petition"  :docCategory="'uscisNotices'"    :docUserType="'uscisNotices'" />
                                    </template>
                                    <template v-else>
                                        <allDocumentsComponent @openUploadPopup="openUploadPopup" @openDownloadPopup="openDownloadPopup" v-if="setActiveTab == 'USCIS Notices' || setActiveTab == 'All' "  @download_or_view="download_or_view" @updatepetition="updatepetition"  :documentsList="USCISDocs" :docsLabel="'USCIS Response Documents'"  :petition="petition"  :docCategory="'uscisNotices'"    :docUserType="'uscisNotices'" />
                                    </template>
                                    <allDocumentsComponent @openUploadPopup="openUploadPopup" @openDownloadPopup="openDownloadPopup" v-if="(setActiveTab == 'LcaDocs' || setActiveTab == 'All') && [9].indexOf(checkProperty(petition,'typeDetails', 'id')) <=-1 && isLcaRequired "  @download_or_view="download_or_view" @updatepetition="updatepetition"  :documentsList="processedLcaDocs" :docsLabel="'LCA Documents'"  :petition="petition"  :docCategory="'lca'"    :docUserType="'lca'" />
                                    <allDocumentsComponent @openUploadPopup="openUploadPopup" @openDownloadPopup="openDownloadPopup" v-if="setActiveTab == 'Checks' || setActiveTab == 'All'"  @download_or_view="download_or_view" @updatepetition="updatepetition"  :documentsList="processedChequeDocs" :docsLabel="'Cheques'"  :petition="petition"  :docCategory="'checks'"    :docUserType="'checks'" />
                                    <allDocumentsComponent @openUploadPopup="openUploadPopup" @openDownloadPopup="openDownloadPopup" v-if="(setActiveTab == 'Other Docs' || setActiveTab == 'All') && [9].indexOf(checkProperty(petition,'typeDetails', 'id')) <=-1 "  @download_or_view="download_or_view" @updatepetition="updatepetition"  :documentsList="otherMergeDocs" :docsLabel="'Other Docs'"  :petition="petition"  :docCategory="'otherMerge'"    :docUserType="'otherMerge'" />
                                    <allDocumentsComponent @openUploadPopup="openUploadPopup" @openDownloadPopup="openDownloadPopup" v-if="(setActiveTab == 'Affidavits' || setActiveTab == 'All') && [9].indexOf(checkProperty(petition,'typeDetails', 'id')) <=-1 "  @download_or_view="download_or_view" @updatepetition="updatepetition"  :documentsList="processedAffidavitDocs" :docsLabel="'Affidavits'"  :petition="petition"  :docCategory="'affidavits'"    :docUserType="'affidavits'" />
                                    <allDocumentsComponent @openUploadPopup="openUploadPopup" @openDownloadPopup="openDownloadPopup" v-if="(setActiveTab == 'Response Docs' || setActiveTab == 'All') && ([9].indexOf(checkProperty(petition,'typeDetails', 'id')) >-1 || ([1].indexOf(checkProperty(petition ,'type')) >-1 && checkProperty(workFlowDetails ,'manageRfeCase') =='with_in_case') )"  @download_or_view="download_or_view" @updatepetition="updatepetition"  :documentsList="rfeResDocs" :docsLabel="'RFE Response Docs'"  :petition="petition"  :docCategory="'rfeResDocs'"    :docUserType="'rfeResDocs'" />
                                    <div class="documents_list" v-if="(setActiveTab == 'Downloads' || setActiveTab == 'All') && [9].indexOf(checkProperty(petition,'typeDetails', 'id')) <=-1 ">
                                        <div class="doc_list_header" v-if="setActiveTab == 'Downloads' || setActiveTab == 'All' ">
                                            <span>Recent Downloads</span>
                                            <span class="download-all" v-if="false">
                                                Upload
                                                <img src="@/assets/images/main/upload.svg" />
                                            </span>
                                        </div>
                                        <div class="documents_list_inner">
                                            <allDocumentsComponent :recentDownLoads="true" @openDownloadPopup="openDownloadPopup" v-if="setActiveTab == 'Downloads' || setActiveTab == 'All' "  @download_or_view="download_or_view" @updatepetition="updatepetition"  :documentsList="recentBenDocsList" :docsLabel="'Petition Docs'"  :petition="petition" :docCategory="'Downloads'"    :docUserType="'Downloads'" />
                                            <allDocumentsComponent :recentDownLoads="true" @openDownloadPopup="openDownloadPopup" v-if="setActiveTab == 'Downloads' || setActiveTab == 'All' "  @download_or_view="download_or_view" @updatepetition="updatepetition"  :documentsList="recentDocsFormsList" :docsLabel="'Forms and Letters'"  :petition="petition" :docCategory="'Downloads'"    :docUserType="'Downloads'" />
                                            <allDocumentsComponent :recentDownLoads="true" @openDownloadPopup="openDownloadPopup" v-if="setActiveTab == 'Downloads' || setActiveTab == 'All' "  @download_or_view="download_or_view" @updatepetition="updatepetition"  :documentsList="recentScannedDocsList" :docsLabel="'Scanned Docs'"  :petition="petition" :docCategory="'Downloads'"    :docUserType="'Downloads'" />
                                        </div>
                                    </div>
                                </vs-card>
                            </div> 
                        </vs-col>
                    </vs-row>
                </div>
            </div>
        </div>
        <div  class="custom_modal_sec documents__modal custom_modal-v2" :class="{ modalopen: downloadDocList }" >
            <div class="custom_modal_overlay" ></div>
            <div class="custom_modal_cnt">
                <div class="modal_title">      
                    <h2> Download Documents </h2>                
                    <span class="close" @click="$emit('closeMe');downloadDocList = false"><x-icon size="1.5x"></x-icon></span>
                </div>
                <div class="all_docs_header">
                    <ul>
                        <li :class="{'active':!isTrashDocument}" @click="toggleDownloadTab(false)">  Saved Documents </li>
                        <li :class="{'active':isTrashDocument}" @click="toggleDownloadTab(true)">Trashed Documents </li>
                    </ul>
                    <button  type="filled" class="restore_btn mb-1" v-if="(checkProperty(savedDocDetails,'length')>0 || $store.state.isDragged) && showDragged  && !isTrashDocument " @click="prepopulateSavedDocs(true);showRestore()">Reset</button>
                </div>       
                <!-- && showDragged isTrashDocument <nested :tasks="processedTaskDocs" @closeMe="downloadDocList=false" :petitionDetails="petition" :categoryDocsList="mergedAllDocuments" v-if="!loadedFromPreview && downloadDocList" @downloadfile="download_or_view" v-bind:petition="petition" v-bind:loadedFromPreview="loadedFromPreview" /> -->
                <!-- downloadAllCaseDocuments -->
                 <div class="all_docs_dragArea">
                    <div class="doc_info" v-if="(checkProperty(savedDocDetails,'length')>0 ) && showDragged  && !isTrashDocument" >

                        
                        <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal" icon="IP-information-button" active="true">

                           <template>It seems, new documents were added after the last download. Use Reset option to configure again.</template>
                        </vs-alert>
                       
                    </div>
                   
                    <div class="all_doc_cnt " :class="{'doc_cnt_info':(checkProperty(savedDocDetails,'length')>0 ) && showDragged  && !isTrashDocument}" >
                       
                        <template v-if="!isTrashDocument">
                            <template v-if="checkProperty(processedTaskDocs ,'length')>0">
                                <nested  @download_or_view="download_or_view" :isTrashDocument="isTrashDocument" :groupName="'g1'" :tasks="processedTaskDocs" :petitionDetails="petition" :categoryDocsList="mergedAllDocuments" v-if="!loadedFromPreview && downloadDocList" @downloadfile="download_or_view" v-bind:petition="petition" v-bind:loadedFromPreview="loadedFromPreview" />
                            </template>
                            <template v-if="checkSavedDocs">
                                <NoDataFound :loading="false" ref="NoDataFoundRef"  content=""  heading="No Documents Found." type='documents' />
                            </template>
                        </template>
                        <template v-if="isTrashDocument">
                            <template v-if="checkProperty(processedTaskDocs ,'length')>0">
                                <trashedDocuments @download_or_view="download_or_view" :groupName="'g2'" :isTrashDocument="isTrashDocument"  v-model="processedTaskDocs"  :petitionDetails="petition" :categoryDocsList="mergedAllDocuments" v-if="!loadedFromPreview && downloadDocList" @downloadfile="download_or_view" v-bind:petition="petition" v-bind:loadedFromPreview="loadedFromPreview" />
                            </template>
                        </template>
                    </div>
                    <div class="popup-footer relative all_doc_popup_footer">
                        <button v-if="!isTrashDocument" :disabled="filesDownloading"  class="edit-doc upload_doc"  @click=" openUploadPopup('otherMerge',null,true)">Upload <img src="@/assets/images/main/upload.svg" /></button> 
                        <div class="d-flex">

                            
         
                        
                            
                        <button class="cancel" @click="$emit('closeMe');downloadDocList = false" type="filled" color="dark">Cancel</button>
                        <!---openUploadPopup(otherMerge,null)   -->
                        
                        <vs-button   @click="downloadAllDocuments()" v-if="checkProperty(processedTaskDocs ,'length')>0 && !isTrashDocument && !checkSavedDocs" 
                        :disabled="filesDownloading"                        
                            color="success"
                            class="marl15 save"
                            type="filled"
                           
                        >Download All</vs-button>
                        </div>
                        <span v-if="filesDownloading" class="loader"><img src="@/assets/images/main/loader.gif"></span>
                    </div>
                </div>                  
            </div>
        </div>
        <modal
            :name="'fileuploadComPopup'"
            classes="v-modal-sec"
            :min-width="200"
            :min-height="200"
            :scrollable="true"
            :reset="true"
            width="600px"
            height="auto"
            >
            <div class="v-modal">
                <div class="popup-header fromDetailsPage">
                <h2 class="popup-title">Upload Documents</h2>
                <span @click="$modal.hide('fileuploadComPopup')">
                    <em class="material-icons">close</em>
                </span>
                </div>
                <form  @submit.prevent >
                    <div class="form-container">
                        <div class="vx-row">
                            <div class="vx-col w-full">
                                <div class="vx-row form-container pad0"   v-if="uploadFormsAndLetters">
                                    <div class="custom-radio_wrap wf_radio">
                                    <label class="form_label pb-1 pl-4">Document Type<em >*</em></label>
                                    
                                    <ul class="custom-radio mb-1" >
                                    
                                        <li> 
                                        <vs-radio  name="documentType"  vs-value="Form" v-model="formLetterType" class="w-full" >Forms</vs-radio>
                                        </li>
                                        <li>
                                            <vs-radio  name="documentType"   vs-value="Letter"  v-model="formLetterType" class="w-full" >Letters</vs-radio>
                                        </li>
                                    </ul>
                                    </div>
                                    <span  class="text-danger text-sm"  v-show="false">Document Type is required</span>
                                </div>
                                <div class="vx-row form-container pad0 mt-3"  v-if="uploadFormsAndLetters && formLetterType=='Letter'">
                                    <div class="custom-radio_wrap wf_radio" @click="showentityIdError=''">
                                    <label class="form_label pb-1 pl-4">Letter Type<em >*</em></label>
                                    <!----entityIds:[{"id":"'cover_letter'" ,"name":"Cover Letter"},{"id":'support_letter' ,"name":'Support Letter'}],
                        -->
                                    <ul class="custom-radio mb-3">
                                        
                                        <li> 
                                        <vs-radio   name="entity_id" id="defaultEntityId"  vs-value="cover_letter" v-model="entityId" class="w-full" >Cover Letter</vs-radio>
                                        </li>
                                        <li>
                                            <vs-radio  name="entity_id" vs-value="support_letter"  v-model="entityId" class="w-full" >Support Letter</vs-radio>
                                        </li>
                                    </ul>
                                    <span  class="text-danger text-sm ml-3"  v-show="showentityIdError"  >Letter Type is required</span>
                                    </div>
                                </div>

                                <div class="uploadsec_wrap ff">
                                    <div class="w-full">
                                        <div  @click="uploadMainDocuments=[]">
                                            <file-upload v-model="uploadMainDocuments"
                                            :accept="acceptedFiles" 
                                            class="file-upload-input mb-0" style="height:50px; padding:0px;" :name="'documents'+selectedDocCategory" :multiple="true" :hideSelected="true" v-validate="'required'" label="Scanned Documents" data-vv-as="Scanned Documents"  @input="uploadToS3MainDocuments(0,uploadMainDocuments)">
                                                <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                                                Upload
                                            </file-upload>
                                            <span class="file-type mb-0">(File Type: PDF, DOC. Max file size: 1MB)</span>
                                            <!-- <span class="text-danger text-sm" v-show="errors.has('pdocuments')">{{ errors.first('documents'+index) }}</span> -->
                                        </div>
                                        <VuePerfectScrollbar class="scrollbardoc">
                                            <div class="uploded-files_wrap mt-3" >
                                                <div class="w-full" v-for="(fil, fileindex) in uploadOriginalDocument" :key="fileindex">
                                                
                                                    <div class="uploded-files">
                                                        <vx-input-group class="form-input-group">
                                                            <vs-input v-on:keyup="filameChenged(fileindex)"  v-validate="'required'" class="w-full" :name="'fName'+fileindex" v-model="fil['name']" data-vv-as="File Name" />
                                                            <span class="text-danger text-sm" v-show="errors.has('fName'+fileindex)">{{ errors.first('fName'+fileindex) }}</span>

                                                            <div class="delete" style="z-index:999" @click="remove(fil, uploadOriginalDocument ,fileindex)">
                                                                <img src="@/assets/images/main/cross.svg" />
                                                            </div>
                                                        </vx-input-group>
                                                    </div>
                                                </div>
                                            </div>
                                        </VuePerfectScrollbar>
                                    </div>
                                </div>
                                <div class="text-danger text-sm formerrors mt-2" v-show="formerrors.msg" @click="formerrors.msg=''">
                                    <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius mb-0" icon-pack="IntakePortal"
                                    icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
                                </div>
                            </div>
                        </div>
                    </div>
                   
                    <div class="popup-footer relative">
                        <button @click="$modal.hide('fileuploadComPopup'+selectedDocCategory); fuploder=false;$modal.hide('fileuploadComPopup')" class="btn cancel">Cancel</button>
                        <button class="btn save"  @click="updateFormsAndDocuments()">
                            <figure v-if="fuploder" class="loader"><img src="@/assets/images/main/loader.gif" /></figure> Submit
                        </button>
                    </div>
                </form>
                </div>
        </modal>
    </div>
</template>
<script>
import { XIcon } from "vue-feather-icons";
import NoDataFound from "@/views/common/noData.vue";
import scannedView from "@/views/petition/scannedCopiesView.vue"
import allDocumentsComponent from "@/views/allDocumentsComponent.vue";
import downloadAllCaseDocuments from "@/views/downloadAllCaseDocuments.vue";
import nested from "@/views/nested.vue";

import trashedDocuments from "@/views/trashedDocuments.vue";
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import FileUpload from "vue-upload-component/src";
import _ from "lodash";
import JQuery from "jquery";
export default {
    data: () => ({
        rfeResDocs:null,
        showDragged:true,
        showentityIdError:false,
        entityId:'cover_letter',
        acceptedFiles:'*',
        formsAndLettersData:null,
        uploadFormsAndLetters:false,
        formLetterType:"Form",
        downloadDocList:false,
        setActiveTab:'All',
        companyDocs:null,
        USCISDocs:null,
        formsAndLettersList : [],
        allFormsAndLettersList : [],
        showConformTocangeLca:false,
        filteredLetters:null,
        tempFilteredForm:[],
        filteredForms:null,
        scannedDocsList:[],
        petitionerDocs:null,
        beneficairyDocs:null,
        lawOfficeDocs:null,
        processedCaseDocs:[],
        processedCompanyPtnrDocs:[],
        processedAffidavitDocs:[],
        processedSpouseDocs:[],
        recentDocsFormsList:null,
        recentBenDocsList:null,
        recentScannedDocsList:null,
        processedChequeDocs:null,
        processedLcaDocs:null,
        selectedDocCategory:'',
        uploadMainDocuments:[],
        uploadOriginalDocument:[],
        disable_uploadBtn: false,
        fuploder: false,
        formerrors:{
            msg:''
        },
        selectedChildItem:null,
        otherMergeDocs:null,
        mergedAllDocuments:[],
        processedTaskDocs:[],
        processedTaskDocsTemp:[],
        savedDocDetails:null,
        processedUscisDocs:[],
        configurationDetails:null,
        finalProcessDocs:null,
        filesDownloading:false,
        isTrashDocument:false,
        callFromDocs:false,

    }),
    components:{
        trashedDocuments,
        XIcon,
        NoDataFound,
        allDocumentsComponent,
        scannedView,
        downloadAllCaseDocuments,
        nested,
        FileUpload,
        VuePerfectScrollbar
    },
    props: {
        workFlowDetails:null,
        petition: {
            type: Object,
            default: null
        },
        loadedFromPreview:{
            type:Boolean,
            default:false
        },
        lcaDetails:{
            type: Object,
            default: null
        },
        fieldsArray:{
            type:Array,
            default:[]
        }
    },
    methods:{
       
        showRestore(action = false){
            this.$store.commit('isDraggeded' ,action);
        },
        toggleDownloadTab(val=false){
            let _self =this;
            let processedTaskDocs = _.cloneDeep(this.processedTaskDocs);
            this.processedTaskDocs =[];
            setTimeout(()=>{
                _self.processedTaskDocs =_.cloneDeep(processedTaskDocs);
                setTimeout(()=>{
                    _self.isTrashDocument = val;
                });
            } ,100);
           
        },
        prepopulateSavedDocs(callFromRestore=false){
            if(callFromRestore){
                this.processedTaskDocs = _.cloneDeep(this.processedTaskDocsTemp)
                this.showDragged = false;
            }else{
                if(this.savedDocDetails && this.checkProperty(this.savedDocDetails,'length')>0){
                    this.processedTaskDocs = _.cloneDeep(this.savedDocDetails)
                }else{
                    this.processedTaskDocs = _.cloneDeep(this.processedTaskDocsTemp)
                }
            }
        },
        downloadAllDocuments(){
            if(this.processedTaskDocs && this.checkProperty(this.processedTaskDocs,'length')>0){
                let downloadedPath = [];
                _.forEach(this.processedTaskDocs,(mTItem)=>{
                    if(_.has(mTItem,'isTrashDocument') && mTItem['isTrashDocument'] == false){
                        if(_.has(mTItem,'path') && mTItem['path']){
                            downloadedPath.push(mTItem['path'])
                        }else{
                            if(_.has(mTItem,'tasks') && mTItem['tasks'] && this.checkProperty(mTItem,'tasks','length')>0 ){
                                _.forEach(mTItem['tasks'],(sItem)=>{
                                    if(_.has(sItem,'isTrashDocument') && sItem['isTrashDocument'] == false){
                                        if(_.has(sItem,'path') && sItem['path']){
                                            downloadedPath.push(sItem['path'])
                                        }else{
                                            if(_.has(sItem,'tasks') && sItem['tasks'] && this.checkProperty(sItem,'tasks','length')>0 ){
                                                _.forEach(sItem['tasks'],(item)=>{
                                                    if(_.has(item,'isTrashDocument') && item['isTrashDocument'] == false){
                                                        if(_.has(item,'path') && item['path']){
                                                            downloadedPath.push(item['path'])
                                                        }else{
                                                            if(_.has(item,'tasks') && item['tasks'] && this.checkProperty(item,'tasks','length')>0 ){
                                                                _.forEach(item['tasks'],(docItem)=>{
                                                                    if(_.has(docItem,'isTrashDocument') && docItem['isTrashDocument'] == false){
                                                                        if(_.has(docItem,'path') && docItem['path']){
                                                                            downloadedPath.push(docItem['path'])
                                                                        }else{
                                                                            if(_.has(docItem,'tasks') && docItem['tasks'] && this.checkProperty(docItem,'tasks','length')>0 ){
                                                                                _.forEach(docItem['tasks'],(lItem)=>{
                                                                                    if(_.has(lItem,'isTrashDocument') && lItem['isTrashDocument'] == false){
                                                                                        if(_.has(lItem,'path') && lItem['path']){
                                                                                            downloadedPath.push(lItem['path'])
                                                                                        }else{
                                                                                            if(_.has(lItem,'tasks') && lItem['tasks'] && this.checkProperty(lItem,'tasks','length')>0 ){
                                                                                                _.forEach(lItem['tasks'],(DItem)=>{
                                                                                                    if(_.has(DItem,'isTrashDocument') && DItem['isTrashDocument'] == false){
                                                                                                        if(_.has(DItem,'path') && DItem['path']){
                                                                                                            downloadedPath.push(DItem['path'])
                                                                                                        }
                                                                                                    }
                                                                                                })
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                })
                                                                            }
                                                                        }
                                                                    }
                                                                })
                                                            }
                                                        }
                                                    }
                                                })
                                            }
                                        }
                                    }
                                })
                            }
                        }
                        
                    }

                })
                if(downloadedPath && this.checkProperty(downloadedPath,'length')>0){
                    this.finalProcessDocs = downloadedPath;
                    let postdata = {
                        petitionId: this.petition._id,
                        documents: this.finalProcessDocs,
                    };
                    let _APIURL = this.$globalgonfig._APIURL
                    if(postdata['documents'].length>0){

                        this.filesDownloading =true;
                        let actionPath ="downloaddocsbyorder";
                        if(this.checkProperty(this.petition, 'type')==3  && this.checkProperty(this.petition, 'subType')==15){
                            actionPath ="downloaddocsbyorderPerm";
                        }  

                        this.$store.dispatch(actionPath, postdata).then((response) => {
                            this.savedDocumentsAction(true);
                            this.filesDownloading =false;
                            window.open(_APIURL+"/common/viewfile?path=" +response.data.result.path,"_blank");
                        })
                        .catch((error)=>{
                            this.filesDownloading =false;
                            this.showToster({ message:error , isError: true})
                        });
                    }
                }
                else{
                    this.filesDownloading =false;
                    this.showToster({ message:'Select Atleast one document' , isError: true})
                }
            }
        },
        savedDocumentsAction(){
            let postData = { "petitionId":'', 'docListPaths':[] ,"entityType": "case"  ,"category": "merge_all_docs"};
            if(this.checkProperty(this.petition ,'_id')  ){
                postData['petitionId'] =this.petition._id;
                if(this.checkProperty(this.petition, 'type')==3 &&  [15].indexOf(this.checkProperty(this.petition,'subTypeDetails', 'id' )) >-1 ){
                    postData['entityType'] ='perm'
                }
            }
            if(this.finalProcessDocs){
                postData['docListPaths'] = _.cloneDeep(this.finalProcessDocs)
            }
            if(this.processedTaskDocs){
                postData['rawData'] = _.cloneDeep(this.processedTaskDocs)
            }
            let path ="/petition-common/save-docs-selected-config";
            this.$store.dispatch("commonAction" ,{data:postData,'path':path})
            .then((rx) =>{
                this.getSavedDocuments();
            }).catch((err)=>{

            })
        },
        getSavedDocuments(){

            let postData ={
                'petitionId':'',
                'entityType':'case',
                "category": "merge_all_docs"
            };
            postData['petitionId'] =this.petition._id;
            // this.isDocumentsAreSaved =false;
            let path ="/petition/get-docs-selected-config";
            path ="/petition-common/get-docs-selected-config";
            if(this.checkProperty(this.petition, 'type')==3 &&  [15].indexOf(this.checkProperty(this.petition,'subTypeDetails', 'id' )) >-1 ){
                postData['entityType'] ='perm'
            }
            this.$store.dispatch("commonAction" ,{data:postData,'path':path}).then((rx) =>{
            if(rx){

            if(this.checkProperty( rx,'rawData')){
            // this.isDocumentsAreSaved =true;
            this.savedDocDetails =_.cloneDeep(rx['rawData']);
            }else{
                this.savedDocDetails=[];
                // this.isDocumentsAreSaved =false;
            }
            }else{
            this.savedDocDetails=[];
            // this.isDocumentsAreSaved =false;

            }
            }).catch((e)=>{

            this.savedDocDetails=[];
            // this.isDocumentsAreSaved =false;
            });
        },
        getGlobalConfigDetails(){
            let postData ={}
            this.configurationDetails =null
            this.$store.dispatch("commonAction", {data:postData,path:'global-config/details'})
            .then((response) =>{ 
                if(this.checkProperty(response ,"config"  )){
                this.configurationDetails = response['config'];
                }
            })
        },
        reloadCase(){
            this.$route['params']['tabname']= 'Case Details';
            this.$route['params']['allDocumentsActiveTab']= this.setActiveTab;
            this.$emit("updatepetition" ,'Case Details');   
            setTimeout(()=>{                           
                           
                           this.$route['params']['tabname']= 'All Documents';
                           this.$route['params']['allDocumentsActiveTab']= this.setActiveTab;
                           this.$emit("updatepetition" ,'All Documents');                              
                       } ,100);
        },
        processUsicsDocuments(){
            if(this.checkProperty(this.petition,'courierTrackingDetails') && this.checkProperty(this.petition ,'courierTrackingDetails' ,'length') > 1){
                let courierTrackingDetails = this.checkProperty(this.petition,'courierTrackingDetails');
                _.forEach(courierTrackingDetails,(item)=>{
                    if(_.has(item,'documents') && this.checkProperty(item,'documents') && this.checkProperty(item,'documents','length')>0 && _.has(item,'userName') && _.has(item,'userType')  && this.checkProperty(item,'userName') && this.checkProperty(item,'userType') ){
                        let docCategory = this.checkProperty(item,'userType');
                        let catName  = 'Beneficiary'
                        if(docCategory == 'spouse'){
                            catName  = 'Spouse'
                        }
                        if(docCategory == 'children'){
                            catName  = 'Children'
                        }
                         
                        let docLabel = item['userName']+' '+' USCIS Receipt Documents'+' ('+catName+')'
                        let filteredDocs =[];
                        let processedUscisDocs = [];
                        let obj = {};
                        _.forEach(item['documents'],(docs)=>{
                            if(!_.has(docs,'status') || (_.has(docs,'status') && this.checkProperty(docs,'status'))){
                                Object.assign(docs,{'uploadedBy':item['createdBy']?item['createdBy']:null,
                                'uploadedByName':item['createdByName']?item['createdByName']:'',
                                'uploadedByRoleId':item['createdByRoleId']?item['createdByRoleId']:null,
                                'uploadedByRoleName':item['createdByRoleName']?item['createdByRoleName']:''

                            });
                                filteredDocs.push(docs)
                            }
                        })
                        if(filteredDocs){
                            Object.assign(obj,{'label':docLabel});
                            obj['userType'] = docCategory;
                            obj['documents'] = {};
                            obj['documents'][docCategory] = filteredDocs
                        }
                        if(obj && this.checkProperty(obj,'documents',docCategory) && this.checkProperty(obj['documents'],docCategory,'length')>0){
                            this.processedUscisDocs.push(obj)
                        }
                    }
                })
            }
        },
        openUploadPopup(categy,childItem,callFromDocs = false){
            this.callFromDocs = callFromDocs;
            this.showentityIdError =false;
            this.entityId = 'cover_letter';
            this.$modal.hide('fileuploadComPopup')
           // alert(this.selectedDocCategory);
            this.fuploder=false
            this.formerrors.msg = '';
            this.selectedChildItem = childItem
            this.uploadMainDocuments = [];
            this.uploadOriginalDocument = [];
            this.selectedDocCategory = categy
            this.uploadFormsAndLetters =false;
            this.formsAndLettersData =null;
            this.formLetterType ="Form" ; // "Letter"
            setTimeout(()=>{
                this.acceptedFiles = "*";
            },100);
           // alert(this.selectedDocCategory);
            this.$modal.show('fileuploadComPopup')
        },
        updateFormsAndDocuments() {

            this.showentityIdError =false;
                
            Object.assign( this.formerrors ,{ msg:''})
            if (this.disable_uploadBtn) {
                return false;
            }
            let postData = {
                petitionId: this.checkProperty(this.petition, '_id'),
                docType:this.selectedDocCategory,
                documents:[],
            };
            

            if(this.uploadFormsAndLetters){
                if(this.formLetterType =='Letter'  ){
                    if(!this.entityId){
                        this.showentityIdError =true;
                        return false;
                    }else{
                        postData =Object.assign(postData, { 'entityId': this.entityId });
                    }
                   
                
                }
                
                //postData['docType'] = _.cloneDeep(this.formLetterType);
                //postData['docType'] = postData['docType']+'s'
                if(this.formLetterType =="Form"){
                    postData['docType'] ='forms';
                }else {
                    postData['docType'] ='letters';
                }
            }
           if(this.uploadOriginalDocument.length>0){

                this.uploadOriginalDocument.forEach((doc)=>{
                    let document = doc.document
                    document = Object.assign(document ,{ name:doc.name ,"type":'' });
                    if(this.formLetterType =='Letter'  ){
                        document = Object.assign(document ,{ "entityId":'' }); 
                        document['entityId'] = this.entityId;
                    }
                    if(this.uploadFormsAndLetters){
                       
                        document['type'] = _.cloneDeep(this.formLetterType)
                        document = _.merge(document , this.formsAndLettersData)
                    }
                    if(!document.depLabel){
                        document['depLabel'] = 'beneficiary';
                    }
                  
                    if(this.selectedChildItem && this.selectedDocCategory == 'childrens' ){
                        document = Object.assign(document ,{ 'childId':this.checkProperty(this.selectedChildItem,'_id')});
                    }
                    document['uploadedBy'] =this.checkProperty(this.getUserData,'userId')!=''?this.checkProperty(this.getUserData,'userId'):null,
                    document['uploadedByName'] =this.checkProperty(this.getUserData,'name')!=''?this.checkProperty(this.getUserData,'name'):'',
                    document['uploadedByRoleId'] = this.getUserRoleId?this.getUserRoleId:null,
                    document['uploadedByRoleName'] =this.checkProperty(this.getUserData,'loginRoleName'),
                    postData['documents'].push(document);
                })
               // alert(JSON.stringify(postData));

            this.fuploder = true;
            this.disable_uploadBtn = true;
            let count = 0;
            this.$store.dispatch("commonAction", { "data": postData,"path":"/petition/upload-case-docs"}).then(response => {  //fileuploadComPopup
                         this.fileuploadComPopup = false;
                         this.$modal.hide('fileuploadComPopup')
                         this.showToster({message:response.message ,isError:false })
                         this.fuploder = false;
                         this.disable_uploadBtn = false;
                         this.fileuploadComPopup = false;
                         this.$modal.hide('fileuploadComPopup')
                         if(!this.callFromDocs){
                            this.reloadCase();
                        }
                        if(this.selectedDocCategory =='otherMerge' && this.callFromDocs ){
                            let tempDocs = null;
                            this.addOtherMergeDocs(postData['documents'])
                            
                        }
                    })
                    .catch((error) => {
                        Object.assign(this.formerrors ,{'msg':error})
                        this.fuploder = false;
                        this.disable_uploadBtn = false;
                    });
       
            }else{
                    Object.assign( this.formerrors ,{ msg:'Upload atleast one document'})

            }
        },
        addOtherMergeDocs(data){
            let docData = data;
            if(docData && this.checkProperty(docData,'length')>0){
                _.forEach(docData,(item)=>{
                    if(!_.has(item,'isTrashDocument')){
                        Object.assign(item,{"isTrashDocument":false})
                    }
                })
            }
            let noDocFound = 0;
            if(this.processedTaskDocs && this.checkProperty(this.processedTaskDocs,'length')>0){
                _.forEach(this.processedTaskDocs,(mItem)=>{
                    if(docData){
                        if(_.has(mItem,'tasks')&& _.has(mItem,'name') && mItem['name'] == 'Other Docs'&& mItem['tasks'] && this.checkProperty(mItem,'tasks','length')>=0 ){
                            _.forEach(docData,(item)=>{
                                mItem['tasks'].push(item)
                            })
                            mItem['isTrashDocument'] = false;
                            noDocFound = noDocFound+1
                        }else{
                            if(mItem['tasks'] && this.checkProperty(mItem,'tasks','length')>0){
                                _.forEach(mItem['tasks'],(sItem)=>{
                                if((_.has(sItem,'name') && sItem['name'] == 'Other Docs' && _.has(sItem,'tasks') && sItem['tasks'] ) ){
                                    _.forEach(docData,(item)=>{
                                        sItem['tasks'].push(item)
                                    })
                                    sItem['isTrashDocument'] = false;
                                    noDocFound = noDocFound+1
                                }else{
                                    if(sItem['tasks'] && this.checkProperty(sItem['tasks'],'length')>0){
                                        _.forEach(sItem['tasks'],(dItem)=>{
                                            if((_.has(dItem,'name') && dItem['name'] == 'Other Docs' && _.has(dItem,'tasks') && dItem['tasks'] ) ){
                                                _.forEach(docData,(item)=>{
                                                    dItem['tasks'].push(item)
                                                })
                                                dItem['isTrashDocument'] = false;
                                                noDocFound = noDocFound+1
                                            }else{
                                                if(dItem['tasks'] && this.checkProperty(dItem['tasks'],'length')>0){
                                                    _.forEach(dItem['tasks'],(cItem)=>{
                                                        if((_.has(cItem,'name') && cItem['name'] == 'Other Docs' && _.has(cItem,'tasks') && cItem['tasks'] ) ){
                                                            _.forEach(docData,(item)=>{
                                                                cItem['tasks'].push(item)
                                                            })
                                                            cItem['isTrashDocument'] = false;
                                                            noDocFound = noDocFound+1
                                                        }else{
                                                            if(cItem['tasks'] && this.checkProperty(cItem['tasks'],'length')>0){
                                                                _.forEach(cItem['tasks'],(dbItem)=>{
                                                                    if((_.has(dbItem,'name') && dbItem['name'] == 'Other Docs' && _.has(dbItem,'tasks') && dbItem['tasks'] ) ){
                                                                        _.forEach(docData,(item)=>{
                                                                            dbItem['tasks'].push(item)
                                                                        })
                                                                        dbItem['isTrashDocument'] = false;
                                                                        noDocFound = noDocFound+1
                                                                    }
                                                                })
                                                            }
                                                        }
                                                    })
                                                }
                                            }
                                        })
                                    }
                                }
                                })
                            }
                        }
                    }
                })
            }
            if(noDocFound ==0){
                let obj={ name:'Other Docs', tasks:[],isTrashDocument:false }
                obj['tasks'] = docData
                this.processedTaskDocs.push(obj)
            }
        },
        openUploadFormsLettersPopup(data){
            this.showentityIdError =false;
            this.entityId = 'cover_letter';
            ////forms //letters

            this.formsAndLettersData =data;
           
            this.uploadFormsAndLetters =true;
            this.formLetterType ="Form" ; // "Letter"
            setTimeout(()=>{
                this.acceptedFiles = "application/pdf";
                
            },100);
            setTimeout(()=>{
                const $ = JQuery;
                this.entityId = 'cover_letter';
                $("#defaultEntityId").trigger('click');
            } ,100);
            this.$modal.show('fileuploadComPopup')
        },
        processFormsAndLetters(){
      this.filteredLetters =[];
      if(this.checkProperty(this.petition,'caseDocs') && this.checkProperty(this.petition,'caseDocs','forms') && this.checkProperty(this.petition['caseDocs'],'forms','length')>0){
          _.forEach(this.petition['caseDocs']['forms'] ,(document)=>{
            document = Object.assign(document, {
                        reverse_document_versions: [],
                        mainParentId: "",
                        showMe: true,
                        selectedForDownload: false,
                        "viewmode":true,
                        });
            this.formsAndLettersList.push(document);

          } );
     }
     if(this.checkProperty(this.petition,'caseDocs') && this.checkProperty(this.petition,'caseDocs','letters') && this.checkProperty(this.petition['caseDocs'],'letters','length')>0){
          _.forEach(this.petition['caseDocs']['letters'] ,(document)=>{
            document = Object.assign(document, {
                        reverse_document_versions: [],
                        mainParentId: "",
                        showMe: true,
                        selectedForDownload: false,
                        "viewmode":true,
                        });
                        
            this.formsAndLettersList.push(document);

          } );
     }
    //this.savedDocumentsList
        if(this.formsAndLettersList && this.checkProperty(this.formsAndLettersList,'length')>0){
           
            let letters = [];

           
            
           
            if(this.formsAndLettersList && this.formsAndLettersList.length>0){
             
              let groupedItems = _.groupBy(this.formsAndLettersList ,'depLabel');
             
              if(groupedItems && Object.keys(groupedItems).length>0){
                _.forEach(groupedItems,(grouPitems ,key)=>{
                 
                  if(grouPitems.length>0){
                  if(key =='beneficiary'){
                    let tempitem=  {'depType':'beneficiary' ,'docUserType':'Beneficiary' ,"depLabel":'', "label":"Beneficiary Forms and Letters", "documents": { "beneficiary":[]}};
                    tempitem['documents']['benDocs'] = grouPitems;
                   let obj ={}
                   if(grouPitems){

                    //v-if="forms['type']=='Letter' && forms['entityId'] =='support_letter'"
                    //alert(grouPitems)
                   
                    let coverLetters =[];
                    let tempBenForms =[];
                    _.forEach(grouPitems ,(documentObj)=>{
                        if(documentObj['type']=='Letter' && documentObj['entityId'] !='support_letter'){
                            coverLetters.push(documentObj);
                        }else{
                            tempBenForms.push(documentObj);
                        }

                    });
                   
                    if(tempBenForms && tempBenForms.length>0){
                     
                        let temBen = {'benForms':tempBenForms}
                        this.processTasksDocumet(temBen,'Beneficiary Forms and Letters',false)
                    }

                    if(coverLetters && coverLetters.length>0){
                        
                        let coverLDocuments = {'cover-letters':coverLetters}
                        this.processTasksDocumet(coverLDocuments,'Cover Letter',false)
                    }

                    //    console.log(JSON.stringify(grouPitems))
                        // obj['benForms'] = grouPitems
                        // let tempBen = {'benForms':grouPitems}
                        // this.processTasksDocumet(tempBen,'Beneficiary Forms and Letters',false);
                   }
                    this.filteredLetters.push(tempitem);
                  }else {
                    //depType :child ,docUserType:Dependent
                    let spouseDocs = _.filter( grouPitems ,{ 'depType':'spouse' ,'docUserType':'Dependent'});
                    if(spouseDocs && spouseDocs.length>0){
                        let tempitem=  { 'depType':'spouse' ,'docUserType':'Dependent' , "depLabel":'',"label":"Spouse Forms and Letters", "documents": { "spouse":[]}};
                         tempitem['documents']['spouse'] = grouPitems;
                         tempitem['depLabel'] = this.checkProperty(grouPitems[0] , 'depLabel')
                         let obj ={}
                        if(grouPitems){
                            obj['spouseForms'] = grouPitems
                            let tempspouse = {'spouseForms':grouPitems}
                            this.processTasksDocumet(tempspouse,'Spouse Forms and Letters',false)
                        }
                        this.filteredLetters.push(tempitem);
                    }
                    else{
                      let childDocs = _.filter( grouPitems ,{ 'depType':'child' ,'docUserType':'Dependent'});
                      if(childDocs &&childDocs.length>0){
                       let childLabel = "Child Forms and Letters";
                        let tempitem=  { 'depType':'child' ,'docUserType':'Dependent' , "depLabel":"" ,"label":childLabel, "documents": { "child":[]}};
                         tempitem['documents']['child'] = grouPitems;
                         tempitem['depLabel'] = this.checkProperty(grouPitems[0] , 'depLabel')
                         let obj ={}
                         if(grouPitems){
                            obj['childForms'] = grouPitems
                            let tempChild = {'childForms':grouPitems}
                            this.processTasksDocumet(tempChild,childLabel,false)
                        }
                        
                         this.filteredLetters.push(tempitem);
                      }


                    }


                    

                  }
                }


                });
              
              }
            }
            

        }
       
    },

    processTempFormsandLetters(){
        let tempFilteredForm = [{'depType':'beneficiary' ,'docUserType':'Beneficiary' ,"depLabel":'', "label":"Beneficiary Forms and Letters", "documents": { "beneficiary":[]}}]
        if(this.checkProperty(this.petition,'dependentsInfo','spouse') && this.checkProperty(this.petition['dependentsInfo'],'spouse','h4Required') ){
            let spouseItem = { 'depType':'spouse' ,'docUserType':'Dependent' , "depLabel":'',"label":"Spouse Forms and Letters", "documents": { "spouse":[]}}
            tempFilteredForm.push(spouseItem)
        }
        if(this.checkProperty(this.petition,'dependentsInfo','childrens') && this.checkProperty(this.petition['dependentsInfo'],'childrens','length')>0 ){
           _.forEach(this.petition['dependentsInfo']['childrens'],(item,inde)=>{
            if(_.has(item,'h4Required') && item['h4Required'] ){
                let id = parseInt(inde)+1
                let childLabel = item['name']+' Forms and Letters'
                let tempitem=  { 'depType':'child' ,'docUserType':'Dependent' , "depLabel":"child_"+id ,"label":childLabel, "documents": { "child":[]}};
                tempFilteredForm.push(tempitem)
            }
           })
        }
        this.tempFilteredForm = tempFilteredForm
    },
        mergeAllDocumet(item,mainCateg){
            let passedItem = item;
            if(passedItem){
                    let catDocuments =Object.entries(passedItem);
                    let documentsArray = [];
                    _.forEach(catDocuments,(item)=>{
                        let obj = {}
                        if(item){
                            let category =_.cloneDeep(item[0]);
                            if(item[1].length>0){
                                let documents =_.cloneDeep(item[1]);
                                let filteredDocs =[]
                                _.forEach(documents,(docs)=>{
                                    if(!_.has(docs,'status') || (_.has(docs,'status') && this.checkProperty(docs,'status'))){
                                        Object.assign(docs,{'category':mainCateg,'saved':false})
                                        filteredDocs.push(docs)
                                    }
                                })
                                if(filteredDocs){
                                    Object.assign(obj,{'category':category,'documents':filteredDocs,'mainCategory':mainCateg,'categoryOrder':false,'saved':false})
                                }
                            }
                        }
                        if(obj && this.checkProperty(obj,'documents') && this.checkProperty(obj,'documents','length')>0){
                            this.mergedAllDocuments.push(obj)
                        }
                    })
                }
            
        },
        processTasksDocumet(item,mainCateg,isArray,loadedAffidavits=false){
            let itemOrder =100
            if(mainCateg=="checks"){
                itemOrder=1
            }else if(mainCateg=="Cover Letter"){
                itemOrder=2
            }else if(loadedAffidavits){
                itemOrder=3
            }          
            let _self = this;
            let mainCategory = mainCateg;
            if(_self.formatdoctype(mainCateg)){                                
                mainCategory  = _self.formatdoctype(mainCateg);
            }
            let passedItem = item;
            let categoryDocuments = [];
          
            if(passedItem && this.checkProperty(passedItem,'length')>0 && isArray ){
                    _.forEach(passedItem,(dbDocItem)=>{
                    let catDocuments =Object.entries(dbDocItem);
                    _.forEach(catDocuments,(item)=>{
                        let obj = {}
                        if(item){
                            let category =_.cloneDeep(item[0]);
                            category =category.trim();
                            if(_self.formatdoctype(category)){
                                
                                category  = _self.formatdoctype(category);
                            }
                            if(item[1].length>0){
                                let documents =_.cloneDeep(item[1]);
                                let filteredDocs =[]
                                _.forEach(documents,(docs)=>{
                                    if((!_.has(docs,'status') || (_.has(docs,'status') && this.checkProperty(docs,'status'))) && this.checkProperty(docs,'path')){
                                       if(!_.has(docs,'isTrashDocument')){
                                        Object.assign(docs,{"isTrashDocument":false})
                                       }
                                        filteredDocs.push(docs)
                                    }
                                })
                                if(filteredDocs){
                                    Object.assign(obj,{'name':category,'tasks':filteredDocs,"isTrashDocument":false})
                                }
                            }
                        }
                        if(obj && this.checkProperty(obj,'tasks') && this.checkProperty(obj,'tasks','length')>0){
                        
                         categoryDocuments.push(obj)
                        }
                    })
                    })
                if(categoryDocuments){
                    let fiteredItem = {};
                    Object.assign(fiteredItem,{'name':mainCategory,'tasks':categoryDocuments,"isTrashDocument":false,"itemOrder":itemOrder})

                    this.processedTaskDocs.push(fiteredItem)
                    this.processedTaskDocsTemp.push(fiteredItem)
                }
            }
            if(passedItem && !isArray){
                let catDocuments =Object.entries(passedItem);
                    _.forEach(catDocuments,(item)=>{
                        let obj = {}
                        if(item){
                            let category =_.cloneDeep(item[0]);
                            if(item[1].length>0){
                                let documents =_.cloneDeep(item[1]);
                                let filteredDocs =[]
                                _.forEach(documents,(docs)=>{
                                    if(!_.has(docs,'status') || (_.has(docs,'status') && this.checkProperty(docs,'status'))){
                                        if(!_.has(docs,'isTrashDocument')){
                                            Object.assign(docs,{"isTrashDocument":false})
                                        }
                                        filteredDocs.push(docs)
                                    }
                                })
                                if(filteredDocs){
                                    Object.assign(obj,{'name':mainCategory,'tasks':filteredDocs,"isTrashDocument":false})
                                }
                            }
                        }
                        if(obj && this.checkProperty(obj,'tasks') && this.checkProperty(obj,'tasks','length')>0){
                            Object.assign(obj,{"itemOrder":itemOrder})
                            this.processedTaskDocs.push(obj)
                            this.processedTaskDocsTemp.push(obj)
                            
                        }
                    })
            }
          this.processedTaskDocs =  _.orderBy(this.processedTaskDocs, ["itemOrder"] ,['asc'] );
          this.processedTaskDocsTemp =  _.orderBy(this.processedTaskDocsTemp, ["itemOrder"] ,['asc'] );
            // this.processedTaskDocsTemp =_.cloneDeep(this.processedTaskDocs);
        },
        formatdoctype(value) {
	  if (value) {
		var doctypes = [ 
            {
				'key':'rfeResDoc',
				'name':'RFE Response Docs'
			},
            {
				'key':'scanLawFirm',
				'name':'Law Firm Scanned Docs'
			},
            {
				'key':'scanPtnr',
				'name':'Petitioner Scanned Docs'
			},
            {
				'key':'otherMerge',
				'name':'Other Docs'
			},
            {
				'key':'companyPtnr',
				'name':'Petitioner Documents'
			},
            {
				'key':'company',
				'name':'Company Docs'
			},
            {
				'key':'checks',
				'name':'Cheques'
			},
            {
				'key':'uscisNotices',
				'name':'USCIS Response Documents'
			},
           {
				'key':'lca',
				'name':'LCA Documents'
			},

            {
				'key':'spouse',
				'name':'Spouse Documents'
			},
            {
				'key':'caseDocs',
				'name':'Case Documents'
			},

			{
				'key':'bnfSpouseLatestI797',
				'name':'Latest I-797, Notice of Approval of the spouse (if spouse is on H-1B or L-1 status)'
			},
			{
				'key':'bnfSpousePassport',
				'name':'Spouse’s Passport- First page with photo, Visa page and last page with address'
			},
			{
				'key':'bnfSpouseRecentPayStubs',
				'name':'Three recent pay stubs (if spouse is on H-1B or L-1 status)'
			},
			{
				'key':'bnfSpouseFormAllI20',
				'name':'Spouse’s all Form I-20s (if spouse is on F-1 status)'
			},
			{
				'key':'passportVisaI94',
				'name':'Passport- First page with photo, Visa page and last page with address'
			},
			{
				'key':'passport',
				'name':'Passport- First page with photo and last page with address'
			},{
				'key':'visa',
				'name':'Visa'
			},
			{
				'key':'formI94',
				'name':'Form I-94'
			},
			{
				'key':'formI797',
				'name':'Form I-797'
			},{
				'key':'marriageCertificate',
				'name':'Marriage Certificate'
			},{
				'key':'birthCertificate',
				'name':'Birth Certificate'
			},{
				'key':'resume',
				'name':'Resume'
			},{
				'key':'education',
				'name':'Master’s/ Bachelor’s degree certificate, transcripts, 12th and 10th certificates'
			},{
				'key':'expLetters',
				'name':'Experience Letters'
			},{
				'key':'INSNotices',
				'name':'I-797, Notice of Approval granting the current nonimmigrant status (if applicable)'
			},
			{
				'key':'formI20',
				'name':'All Form I-20s (if on F-1 or F2 status)'
			},{
				'key':'socialSecurityCardAndProfLicense',
				'name':'Social Security Card'
			},{
				'key':'I140ApprovalNotice',
				'name':'I–140 Approval Notice'
			},

			{
				'key':'I797NoticeofApprovalforI140',
				'name':'I-797, Notice of Approval for I-140 if available'
			},
			
			{
				'key':'payStubs',
				'name':'Three recent pay stubs'
			},
			//offerLetter
			{
				'key':'offerLetter',
				'name':'Employment Offer Letter'
			},
			{
				'key':'employmentAgreement',
				'name':'Employment Agreement Letter'
			},
			
			
			//clientLetter
			{
				'key':'clientLetter',
				'name':'Client Letter'
			}
			,
			//vendorLetter
			{
				'key':'vendorLetter',
				'name':'Vendor Letter'
			}
			//msa
			,
			//vendorLetter
			{
				'key':'msa',
				'name':'MSA/Service Agreement and PO/SOW'
			}
			,
			//po
			{
				'key':'po',
				'name':'PO'
			}

			,
			{
				'key':'other',
				'name':'Others'
			}
			,
			{
				'key':'approvalNotice',
				'name':'Approval Notice'
			},
			{
				'key':'beneficiaryDocs',
				'name':'Beneficiary Documents'
			},

			{
				'key':'h1bRegSelectionNotice',
				'name':'H-1B Registration Selection Notice'
			},
			{
				'key':'ead',
				'name':'EADs (if on OPT or STEM OPT Extension)'
			},
			{
				'key':'primeVendor',
				'name':'Prime Vendor Letter'
			},
			// {
			// 	'key':'formI94',
			// 	'name':'I-94'
			// }
			,
			//slgApprovalNoticeOfPrevH4
			{
				'key':'slgApprovalNoticeOfPrevH4',
				'name':'SLG Spouse Current and Previous H4 Approval Copies'
			},

			{
				'key':'priorFormI797',
				'name':'All prior I-797, Notice of Approvals granting H-1B status'
			},
			{
				'key':'noticeOfApprovalOfH1Status',
				'name':'Notice of approval of H1 Status'
			},
			{
				'key':'approvalNoticeOfPrevH4',
				'name':'Previous H4 approval notices'
			},
			{
				'key': 'slgEvalOfEduCredentials',
				//'name': 'Evaluation of Education certification'
				// "name":"Education/Education+Experience Evaluation" and 
				"name":"Education Evaluation"
			},
			{
				'key' : 'slgEvalOfEduExpCredentials',
				'name':'Education+Experience Evaluation'
			},
			{
				'key' : 'slgEduCredentials',
				'name':'Education certification'
			},
			{
				'key' : 'slgTransScripts',
				'name':'Transcripts/Marks memo’s'
			},

			{
				'key': "slgAdvancedDegrees",
				'name': "Adavanced Degree Certificate"
			},
			{
				'key': "slgCurPrevH1BH4ApprovalsByINS",
				'name': "Previous H1B & H4 Approvals by INS"
			},
			{
				"key":"slgResume",
				"name":"Current Resume- Please mention the accurate names of the employer and periods of employment. Do not state the client names"
			  },
			  {
				 "key":"slgCollegeDegreesCert",
				"name":"All College Degrees"
			  },
			  {
				 "key":"slgTransScripts",
				"name":"Transcripts/Marks memo’s."
			  },
			  {
				 "key":"slgExpLetters",
				"name":"Letters of Experience.Each experience letter on company letterhead must document your professional experience and must include the (1) job title (2) duration of employment (beginning date and ending date), (3) full time (i.e., 40 hours) or part time position, and (4) the job duties.  If you had more than one position within the company, please list each position along with the job description."
			  },
			  
			  {
				 "key":"slgPassportAndVisa",
				 "name":"Copy of New and Old Passport"
			  },
			  {
				 "key":"slgI94",
				 "name":"I-94"
			  },
			  
			  {
				 "key":"slgPrevNonimmApprovalNotices",
				 "name":"Copy of all Previous Nonimmigrant Approval Notices (e.g., H-1B, H-4, L-1A, L-1B, L-2 etc.,)"
			  },
			  {
				 "key":"slgI140OrPermNoties",
				 "name":"Copy of any I-140 approval notices or PERM filing Notices (if applicable)"
			  },
			  {
				 "key":"slgPrevLaborApplications",
				 "name":"Copy of the previously filed Labor Application, if applicable."
			  },
			  
			  {
				 "key":"slgAckOfPrevLaborApplications",
				 "name":"Copy of the Acknowledgement letter for the previously filed Labor application, if applicable. "
			  },
			  {
				 "key":"slgPaystubs",
				 "name":"Copies of Most recent paystubs (last 2 to 3 months)."
			  },
			  
			  {
				 "key":"slgI20",
				 "name":"Copies of all I-20’s."
			  },
			  {
				 "key":"slgEad",
				 "name":"Copies of EAD cards."
				 
			  },

			  {
				"key":"w2",
				"name":"Copy of all w2"
				
			 },
			//  {
			// 	"key":"slgEvalOfEduCredentials",
			// 	"name":"Evaluation of Education certification"
				
			//  },
			 {
				"key":"slgPrevImmApprovalNotices",
				"name":"Copy of all Previous Immigrant Approval Notices (e.g., H-1B, H-4, L-1A, L-1B, L-2 etc.,)"
				
			 },

			

			//approvalNotice
			//perm Advertisement Documents
			{
				key: 'sunday',
				name: 'Copy of Advertisement',
			  },
			  {
				key: 'jobFair',
				name: 'Copy of Advertisement',
			  },
			  {
				key: 'campusRecruitment',
				name: 'Copy of Advertisement',
			  },
			  {
				key: 'empWebsite',
				name: 'Copy of Advertisement',
			  },
			  {
				key: 'profOrgOrTrade',
				name: 'Copy of Advertisement',
			  },
			  {
				key: 'jobSearchWebsite',
				name: 'Copy of Advertisement',
			  },
			  {
				key: 'pvtEmpmtFirm',
				name: 'Copy of Advertisement',
			  },
			  {
				key: 'empRefProgram',
				name: 'Copy of Advertisement',
			  },
			  {
				key: 'campusPlacement',
				name: 'Copy of Advertisement',
			  },
			  {
				key: 'localNewsPaper',
				name: 'Copy of Advertisement',
			  },
			  {
				key: 'tvAds',
				name: 'Copy of Advertisement',
			  },
			  {
				key: 'recruReportSummary',
				name: 'Recruitment Report and Summary describing the recruitment efforts and results',
			  },
			  {
				key: 'busNecLetterByEplr',
				name: 'Business Necessity Letter Provided by Employer',
			  },
			  {
				key: 'intrOfcMemomandum',
				name: 'Signed copies',
			  },
			  {
				key: 'payReceipt',
				name: 'Receipt',
			  },
			  {
				key: 'documents', 
				name: 'Acknowledgement',
			  },
			  {
				key: 'usicsDocuments',
				name: 'Documents',
			  },
			  /// Education form documents
			  {
				key:'educationPassport',
				name:'Passport'
			  },
			  {
				key:'graduationCertificate',
				name:'Certificate of Graduation'
			  },
			  {
				key:'transcripts',
				name:'Transcripts/Marks Memo'
			  }, {
				'key':'eduTranscripts',
				'name':'U.S. Master’s Degree Certificate and Transcripts'
			},
			//485 fields copy of the EAD CARD(S), front and  back  
			{
				key: "appliedAOSInUSDocs",
				name: "copy of applied AOS in the united states or an immigrant visa at the US Embassy"
			},
			{
				key: "eadCard",
				name: "Copy of the EAD CARD(S), front and  back"
			},
			{
				key: "slgSignedOfferLetter",
				name: "Signed Offer Letter"
			},
			{
				key: "slgOfferLetter",
				name: "Unsigned Offer Letter"
			},
			{
				key: "marriageCertDocs",
				name: "Copy of Marriage Certificates."
			},
			{
				key: "haveYouArrestedBeforeDocs",
				name: "Copy of the Documents."
			},
			{
				key: "marriageCertificate",
				name:"Marriage Certificate"
				//name: "Copy of the marriage certificate, with certified translation if required."
			},
			{
				key: "underlyingLaborApplications",
				name: "Copy of the underlying Labor Certification (PERM) if applicable."
			},
			{
				key: "mostRecentTaxTranscrips",
				name: "A copy of Most Recent Year’s Tax Transcripts – can be obtained from."
			},
			{
				key: "w2",
				name: "Copy of all w2."
			},
			{
				key: "photographs",
				name: "Photographs."
			},
			{
				key: "medicalExamins",
				name: "Medical Examins."
			},
			{
				key: "dependentForI134",
				name: "Dependent For I-134."
			},
			{
				key: "dependentTaxReturns",
				name: "Dependent Tax Returns."
			},
			{
				key: "bankStatements",
				name: "Bank Statements."
			}, 
			{
				key: "evidenceOfContinuVisaStatus",
				name: "Evidence of Continue Visa Status."
			}, 
			{
				key: "evidenceOfFilePetitionBefore30Apr2001",
				name: "Evidence of File Petition Before 30-Apr-2001."
			}, 
			{
				key: "proofOfIncomeOrAsset",
				name: "Proof of Income or Asset."
			}, 
			{ 
				key: "proofOfMedicalInsurence",
				name: "Proof of Medical Insurance."
			}, 
			{
				key: "recentCreditReport",
				name: "Recent Credit Report."
			}, 
			{
				key: "permResidence",
				name: "Permanent Residence." 
			}, 
			{
				key: "empAuth",
				name: "Employment Auth."
			},
			{
				key: "capSelectNotice",
				name: "CAP Selection Notice"
			},
			{

				key: "formI797H4ApprovalNotice",
				name: "Form I-797 H4 approval notice if applicable",
					  
			  },
	  
			{
	  
			key: "h4Ead",
			name: "H4 EAD if applicable",
				  
			},
					
			
	  
			{
	  
			key: "marriageCertificate",
			name: "Marriage Certificate",
			
	  
			},
	  
			{
	  
			key: "formI797H1BApprovalNoticePrinNonCtzn",
			name: "Form I-797 H-1B approval notice of Principal Non-citizen",
			
	  
			},
	  
			{
	  
			key: "passportOfPrinNonCtzn",
			name: "Passport of Principal Non-citizen- First page with photo, Visa page and last page with address",
			
	  
			},
	  
			{
	  
			key: "last3MonthsPayslipsOfPrinNonCtzn",
			name: "Last 3 months pay statements of Principal Non-citizen",
				  
			},

			{
				key: "slgApprovalNoticeOfPrevH4 ",
				name: "SLG Current and Previous H4 Approval Copies."
			},
			{
				key: "spouse_docs_slgApprovalNoticeOfPrevH4 ",
				name: "Current and Previous H4 Approval Copies."
			},
			
			
			{
				key: "child_docs_slgApprovalNoticeOfPrevH4 ",
				name: "Current and Previous H4 Approval Copies."
			},
			{

				
				key: "Petitioner",
			   name: "Petitioner",
			},
			{

			key: "cheques",
			name: "Cheques",
					
			},
			{
				//companyDocs
				key: "companyDocs",
			   name: "Company Documents",

			},
			
			{

			key: "Forms",
			name: "Forms",
					
			},
			{

				key: "Letters",
				name: "Letters",
						
				},
			{

			key: "beneficiary_forms_and_letters",
			name: "Beneficiary Forms and Letters",
					
			},
			{

				key: "spouse_forms_and_letters",
				name: "Spouse Forms and Letters",
						
			},
			
			{

				key: "child_1",
				name: "Child 1 Forms and Letters",
						
			},
			{

				key: "child_2",
				name: "Child 2 Forms and Letters",
						
			},
			{

				key: "child_3",
				name: "Child 3 Forms and Letters",
						
			},
			{

				key: "child_4",
				name: "Child 4 Forms and Letters",
						
			},
			{

				key: "child_5",
				name: "Child 5 Forms and Letters",
						
			},
			{

				key: "child_6",
				name: "Child 6 Forms and Letters",
						
			},
			{

				key: "child_7",
				name: "Child 7 Forms and Letters",
						
			},
			{

				key: "child_8",
				name: "Child 8 Forms and Letters",
						
			},
			{

				key: "Petitioner",
				name: "Petitioner",
						
			},
			{

				key: "Beneficiary",
				name: "Beneficiary",
						
			},
			{

				key: "Law Firm",
				name: "Law Firm",
						
			},
			{

				key: "Company",
				name: "Company",
						
			},
			
			{

				key: "USCIS",
				name: "USCIS",
						
			},
			{

				key: "USCISDocs",
				name: "USCIS",
						
			},
			{

				key: "USCIS Docs",
				name: "USCISDocs",
						
			},
			{

				key: "recent_forms_and_letters",
				name: "Recent Forms and Letters",
						
			},
			{

				key: "recent_beneficiary_docs",
				name: "Beneficiary Recent",
						
			},
			{

				key: "recent_scanned_copies",
				name: "Recent Scanned Copies",
						
			},
			//////Petitioner Documents
			{
				key: "articleOfIncorp",
				name: "Articles of Incorporation",	
			},
			{
				key: "stateRegCert",
				name: "State Registration Certificate",	
			},
			{
				key: "fein",
				name: "Document identifying the EIN number (Form SS-4 issued by IRS)",	
			},
			{
				key: "goodStandCert",
				name: "Good standing certificate",	
			},
			{
				key: "markMetOrWebsitePrints",
				name: "Marketing materials/website printouts",	
			},
			{
				key: "orgCharts",
				name: "Organizational chart",	
			},
			{
				key: "latestTaxReturn",
				name: "Last two years Federal income tax returns",	
			},
			{
				key: "latestWageReports",
				name: "Copy of Last four quaterly wage reports",	
			},
			{
				key: "letterHeads",
				name: "Copy of Petitioner letterhead in word format",	
			},
			  //recent_forms_and_letters
           // recent_beneficiary_docs
            //recent_scanned_copies
			 
			
			
			
			
			
				//beneficiary_forms_and_letters
				
				//spouse_forms_and_letters

		]
		var find = _.find(doctypes, { 'key': value});
		return find?find.name:"";
	}
},
       
       
        openDownloadPopup(category=''){
            
            this.downloadDocList = true;
        },
        download_or_view(value){
            this.$emit('download_or_view' ,value);
        },
        filameChenged(fileindex) {
            this.disable_uploadBtn = false;
            if (this.uploadOriginalDocument.length > 0) {
                _.forEach(this.uploadOriginalDocument, (fl, value) => {
                    //let fname = fl.name;
                    let fname = fl.document.name;
                    fname = fname.trim();
                    

                    if (!fname) {
                        this.disable_uploadBtn = true;
                    }
                });
            }
        },
        remove(item, type) {
            type.splice(type.indexOf(item), 1);
            return false;
        },
        getOtherMergeDocs(){
            if(this.checkProperty(this.petition,'caseDocs') && this.checkProperty(this.petition,'caseDocs','otherMerge') && this.checkProperty(this.petition['caseDocs'],'otherMerge','length')>0){
                let list = this.checkProperty(this.petition,'caseDocs','otherMerge')
                let obj = {}
                if(list && this.checkProperty(list,'length')>0){
                    Object.assign(obj,{'otherMerge':list})
                }
                if(obj['otherMerge']){
                    this.otherMergeDocs = obj
                }
                this.processTasksDocumet(this.otherMergeDocs,'otherMerge',false)
                this.mergeAllDocumet(this.otherMergeDocs,'otherMerge')
            }
        },
        getResponseDocs(){
            
            if(
                this.checkProperty(this.petition,'caseDocs') &&
                ( this.checkProperty(this.petition, 'typeDetails', 'id') == 9 || ([1].indexOf(this.checkProperty(this.petition ,'type')) >-1 && this.checkProperty(this.workFlowDetails ,'manageRfeCase') =='with_in_case') )
             && this.checkProperty(this.petition,'caseDocs','rfeResDocs') && this.checkProperty(this.petition['caseDocs'],'rfeResDocs','length')>0)
             {
               
                let list = this.checkProperty(this.petition,'caseDocs','rfeResDocs')
                let obj = {}
                if(list && this.checkProperty(list,'length')>0){
                    Object.assign(obj,{'rfeResDocs':list})
                }
                if(obj['rfeResDocs']){
                    this.rfeResDocs = obj
                }
                this.processTasksDocumet(this.rfeResDocs,'rfeResDoc',false)
            }
        },
        getCompanyDocs(){
            this.companyDocs = null;
            let postData ={companyId:this.checkProperty(this.petition, 'companyDetails', '_id') ,'page':1 ,'perpage':100000};
            this.$store.dispatch("getList" ,{data:postData,path:"/company/documents-list"})
            .then(response => {
                let list = response.list
                let obj = {}
                if(this.checkProperty(this.petition,'caseDocs') && this.checkProperty(this.petition,'caseDocs','company') && this.checkProperty(this.petition['caseDocs'],'company','length')>0){
                    _.forEach(this.petition['caseDocs']['company'],(item)=>{
                        Object.assign(item ,{ "isTrashDocument":false});
                        list.push(item)
                    })
                }
                if(list && this.checkProperty(list,'length')>0){
                    Object.assign(obj,{'companyDocs':list })
                }
                if(obj['companyDocs']){
                    this.companyDocs = obj
                    this.processTasksDocumet(this.companyDocs,'companyDocs',false)
                }
                this.mergeAllDocumet(this.companyDocs,'companyDocs')
            })
            .catch((err)=>{
            })
        },
        getPetitionerDocs(){
            this.petitionerDocs = null;
            let postData ={petitionId: this.checkProperty(this.petition, '_id') ,'page':1 ,'perpage':100000, matcher:{"docUserTypeList":["Petitioner"]}};
            this.$store.dispatch("getList" ,{data:postData,path:"/petition/scanned-copies-list"})
            .then(response => {
                let list = response.list
                let obj = {}
                if(list && this.checkProperty(list,'length')>0){
                    Object.assign(obj,{'petitionerDocs':list})
                }
                if(obj['petitionerDocs']){
                    this.petitionerDocs = obj
                }
            })
            .catch((err)=>{
            })
        },
        processUSCISDocs(){
            let USCISDocs = [];
            if(this.checkProperty(this.petition,'caseDocs') && this.checkProperty(this.petition,'caseDocs','uscisNotices') && this.checkProperty(this.petition['caseDocs'],'uscisNotices','length')>0){
                _.forEach(this.petition['caseDocs']['uscisNotices'],(item)=>{
                    USCISDocs.push(item)
                })
            }
            if(this.checkProperty(this.petition,'rfeNotice') && this.checkProperty(this.petition,'rfeNotice','documents') && this.checkProperty(this.petition['rfeNotice'],'documents','length')>0){
                _.forEach(this.petition['rfeNotice']['documents'],(item)=>{
                    USCISDocs.push(item)
                })
            }
            let obj = {'uscisNotices':USCISDocs}
            this.USCISDocs = obj
            this.processTasksDocumet(this.USCISDocs,'uscisNotices',false)
            this.mergeAllDocumet(this.USCISDocs,'uscisNotices')
        },
        updatepetition() {
            setTimeout(()=>{
                this.$emit("updatepetition" ,'All Documents');
            } ,100);
        },
        getFormsAndLetters(callFromMenu =false,code='') {
            this.showConformTocangeLca =false;
            this.formsAndLettersList = [];
            this.allFormsAndLettersList = [];
            let finalList = [];

            let postData = {
            petitionId: this.petition._id,
            matcher: { typeIds: ["Form" ,'Letter'] },
            page: 1,
            perpage: 100000,
            };
            this.updateLoading(true);
            this.$store
            .dispatch("getList", {
                data: postData,
                path: "/filled-forms-and-letters/list",
            })
            .then((response) => {
                this.allFormsAndLettersList = response.list;
                let lst = [];
                    _.forEach(response.list, (mainItem) => {
                        mainItem = Object.assign(mainItem, {
                        reverse_document_versions: [],
                        mainParentId: "",
                        showMe: true,
                        selectedForDownload: false,
                        "viewmode":true,
                        });
                        if (mainItem.parentId) {
                        mainItem["mainParentId"] = mainItem["parentId"];
                        } else {
                        mainItem["mainParentId"] = mainItem["_id"];
                        }

                        lst.push(mainItem);
                    });
                    let subList = [];

                    //reverse_document_versions
                    _.forEach(lst, (mainItem) => {
                        if (this.checkProperty(mainItem, "depType") != "child") {
                        _.forEach(lst, (subItem) => {
                            if (
                            mainItem.parentId &&
                            (mainItem.parentId == subItem["parentId"] ||
                                mainItem.parentId == subItem["_id"]) &&
                            mainItem["_id"] != subItem["_id"]
                            ) {
                            subItem["showMe"] = false;
                            if (subList.indexOf(subItem["_id"]) <= -1) {
                                mainItem["reverse_document_versions"].push(subItem);
                                this.previousExisted = true;
                                subList.push(subItem["_id"]);
                            }
                            }
                        });

                        if (mainItem.showMe) {
                            finalList.push(_.cloneDeep(mainItem));
                        }
                        } else {
                        _.forEach(lst, (subItem) => {
                            if (
                            this.checkProperty(mainItem, "depType") ==
                                this.checkProperty(subItem, "depType") &&
                            this.checkProperty(mainItem, "depLabel") ==
                                this.checkProperty(subItem, "depLabel") &&
                            mainItem.parentId &&
                            (mainItem.parentId == subItem["parentId"] ||
                                mainItem.parentId == subItem["_id"]) &&
                            mainItem["_id"] != subItem["_id"]
                            ) {
                            subItem["showMe"] = false;
                            if (subList.indexOf(subItem["_id"]) <= -1) {
                                mainItem["reverse_document_versions"].push(subItem);
                                this.previousExisted = true;
                                subList.push(subItem["_id"]);
                            }

                            // mainItem['showMe'] =true;
                            }
                        });
                            if (mainItem.showMe) {
                                finalList.push(_.cloneDeep(mainItem));
                            }
                        }
                    });
                    this.formsAndLettersList = _.cloneDeep(finalList); // JSON.parse(JSON.stringify(finalList));
                    // this.formsAndLetters =this.formsAndLettersList;  
                    this.processFormsAndLetters();
                })
                .catch((err) => {

                    this.formsAndLettersList = [];
                });
        },
       
        getScannedDocuments(){
            this.updateLoading(true);
            this.scannedDocsList =[];
            let finalList =[];
            let postData ={petitionId:'','page':1 ,'perpage':100000};
            postData['petitionId']= this.petition._id; 
            this.$store.dispatch("getList" ,{data:postData,path:"/petition/scanned-copies-list"}).then(response => {
                this.updateLoading(false);
                let lst = [];
                _.forEach(response.list ,(mainItem)=>{
                    mainItem = Object.assign(mainItem,{"reverse_document_versions":[] ,"mainParentId":'',showMe:true ,selectedForDownload:false});
                    if(mainItem.parentId){
                        mainItem['mainParentId'] = mainItem['parentId']
                    }else{
                            mainItem['mainParentId'] = mainItem['_id']
                    }
                        lst.push(mainItem);
                });
                let subList=[];
            //reverse_document_versions
                _.forEach(lst ,(mainItem)=>{
                    _.forEach(lst ,(subItem)=>{
                        if( mainItem.parentId && (mainItem.parentId == subItem['parentId'] ||  mainItem.parentId == subItem['_id']   ) &&  mainItem['_id'] != subItem['_id']){                            
                            subItem['showMe'] =false;
                            if(subList.indexOf(subItem['_id']<=-1)){
                                mainItem['reverse_document_versions'].push(subItem);
                                subList.push(subItem['_id']);
                            }
                        }
                    })            
                    if(mainItem.showMe){
                        finalList.push(mainItem);
                    }
                })
                this.totalpages = Math.ceil(response.totalCount / this.perpage);
                this.scannedDocsList =  finalList;
                this.processScannedDocs();
                this.updateLoading(false);
                }).catch((err)=>{
                    this.scannedDocsList  =[];
                    this.updateLoading(false);
                })
        },
        processScannedDocs(){
            let petitionerDocs = [];
            let beneficairyDocs = [];
            let lawOfficeDocs = [];
            if(this.checkProperty(this.petition,'caseDocs') && this.checkProperty(this.petition,'caseDocs','scanBnf') && this.checkProperty(this.petition['caseDocs'],'scanBnf','length')>0){
                _.forEach(this.petition['caseDocs']['scanBnf'],(item)=>{
                    beneficairyDocs.push(item)
                })
            }
            if(this.checkProperty(this.petition,'caseDocs') && this.checkProperty(this.petition,'caseDocs','scanPtnr') && this.checkProperty(this.petition['caseDocs'],'scanPtnr','length')>0){
                _.forEach(this.petition['caseDocs']['scanPtnr'],(item)=>{
                    petitionerDocs.push(item)
                })
            }
            if(this.checkProperty(this.petition,'caseDocs') && this.checkProperty(this.petition,'caseDocs','scanLawFirm') && this.checkProperty(this.petition['caseDocs'],'scanLawFirm','length')>0){
                _.forEach(this.petition['caseDocs']['scanLawFirm'],(item)=>{
                    lawOfficeDocs.push(item)
                })
            }
            if(this.scannedDocsList && this.checkProperty(this.scannedDocsList,'length')>0){
                // petitionerDocs = _.filter(this.scannedDocsList,(item)=>{
                //     return item['docUserType'] == 'Petitioner'
                // })
                // beneficairyDocs = _.filter(this.scannedDocsList,(item)=>{
                //     return item['docUserType'] == 'Beneficiary'
                // })
                _.forEach(this.scannedDocsList,(item)=>{
                    if(item['docUserType'] == 'Petitioner'){
                        petitionerDocs.push(item)
                    }
                })
                _.forEach(this.scannedDocsList,(item)=>{
                    if(item['docUserType'] == 'Beneficiary'){
                        beneficairyDocs.push(item)
                    }
                })
                _.forEach(this.scannedDocsList,(item)=>{
                    if(item['docUserType'] == 'Internal'){
                        lawOfficeDocs.push(item)
                    }
                })
                // lawOfficeDocs = _.filter(this.scannedDocsList,(item)=>{
                //     return item['docUserType'] == 'Internal'
                // })
            }
            if(petitionerDocs && this.checkProperty(petitionerDocs,'length')>0){
                let obj={}
                Object.assign(obj,{'petitionerDocs':petitionerDocs});
                this.petitionerDocs= obj
                this.processTasksDocumet(this.petitionerDocs,'scanPtnr',false)
                this.mergeAllDocumet(this.petitionerDocs,'scanned')
            }
            if(beneficairyDocs && this.checkProperty(beneficairyDocs,'length')>0){
                let obj={}
                Object.assign(obj,{'beneficairyDocs':beneficairyDocs});
                this.beneficairyDocs = obj
                this.processTasksDocumet(this.beneficairyDocs,'scanBnf',false)
                this.mergeAllDocumet(this.beneficairyDocs,'scanned')
            }
            if(lawOfficeDocs && this.checkProperty(lawOfficeDocs,'length')>0){
                let obj={}
                Object.assign(obj,{'lawOfficeDocs':lawOfficeDocs});
                this.lawOfficeDocs = obj
                this.processTasksDocumet(this.lawOfficeDocs,'scanLawFirm',false)
                this.mergeAllDocumet(this.lawOfficeDocs,'scanned')
            }

            
        },
        processCaseDocs(){  
            if(this.checkProperty(this.petition,'documents')){
                let catDocuments =Object.entries(this.checkProperty(this.petition,'documents'));
                let documentsArray = [];
                _.forEach(catDocuments,(item)=>{
                    let obj = {}
                    if(item){
                        let category =_.cloneDeep(item[0]);
                        let tempSection= category
                        if(item[1].length>0 && tempSection !='slgOfferLetter' && tempSection!='slgSignedOfferLetter'  ){
                             
                            
                            let documents =_.cloneDeep(item[1]);
                            let filteredDocs =[]
                            _.forEach(documents,(docs)=>{
                                if(!_.has(docs,'status') || (_.has(docs,'status') && this.checkProperty(docs,'status'))){
                                    filteredDocs.push(docs)
                                }
                            })
                            
                            if(filteredDocs){
                                obj[tempSection] = filteredDocs
                            }
                        }
                        else{
                            obj[tempSection] = []
                        }
                    }
                    this.mergeAllDocumet(obj,'caseDocs')
                    documentsArray.push(obj)
                })
                if(documentsArray){
                    this.processedCaseDocs  =_.cloneDeep(documentsArray);
                    this.processTasksDocumet(this.processedCaseDocs,'caseDocs',true)
                }
                
            }
            //this.checkProperty(this.petition,'dependentsInfo','spouse') &&  checkProperty(this.petition['dependentsInfo']['spouse'], 'h4Required')==true
            if( this.checkProperty(this.petition['dependentsInfo'],'spouse','documents') && ( [2,10].indexOf(this.checkProperty(this.petition,'typeDetails', 'id'))>-1 || (this.checkProperty( this.petition,'beneficiaryInfo','maritalStatus') !=1 && this.checkProperty(this.petition['dependentsInfo']['spouse'], 'h4Required')==true ) ) ){
                let catDocuments =Object.entries(this.checkProperty(this.petition['dependentsInfo'],'spouse','documents'));
                let documentsArray = [];
                _.forEach(catDocuments,(item)=>{
                    let obj = {}
                    if(item){
                        let category =_.cloneDeep(item[0]);
                        let tempSection= category
                        if(item[1].length>0){
                             
                            
                            let documents =_.cloneDeep(item[1]);
                            let filteredDocs =[]
                            _.forEach(documents,(docs)=>{
                                if(!_.has(docs,'status') || (_.has(docs,'status') && this.checkProperty(docs,'status'))){
                                    filteredDocs.push(docs)
                                }
                            })
                            
                            if(filteredDocs){
                                obj[tempSection] = filteredDocs
                            }
                        }
                        else{
                            obj[tempSection] = []
                        }
                    }
                    this.mergeAllDocumet(obj,'spouse')
                    documentsArray.push(obj)
                })
                if(documentsArray){
                    this.processedSpouseDocs  =_.cloneDeep(documentsArray);
                    this.processTasksDocumet(this.processedSpouseDocs,'spouse',true)
                }
            }
           
            if(this.checkProperty(this.petition,'dependentsInfo') && this.checkProperty(this.petition,'dependentsInfo','childrens') && this.checkProperty(this.petition['dependentsInfo'],'childrens','length')>0
            ){
                _.forEach(this.petition['dependentsInfo']['childrens'],(item)=>{
                    let child = item;
                    if(this.checkProperty(child,'documents') && this.checkProperty(item, 'h4Required')==true){
                        let catDocuments =Object.entries(this.checkProperty(child,'documents'));
                        let documentsArray = [];
                        _.forEach(catDocuments,(item)=>{
                            let obj = {}
                            if(item){
                                let category =_.cloneDeep(item[0]);
                                let tempSection= category
                                if(item[1].length>0){
                                    let documents =_.cloneDeep(item[1]);
                                    let filteredDocs =[]
                                    _.forEach(documents,(docs)=>{
                                        if(!_.has(docs,'status') || (_.has(docs,'status') && this.checkProperty(docs,'status'))){
                                            filteredDocs.push(docs)
                                        }
                                    })
                                    if(filteredDocs){
                                        obj[tempSection] = filteredDocs
                                    }
                                }
                                else{
                                    obj[tempSection] = []
                                }
                            }
                            documentsArray.push(obj)
                        })
                        if(documentsArray){
                            let typeDoc = 'Child '+this.checkProperty(child,'name')+' Docs'
                            this.processTasksDocumet(documentsArray,typeDoc,true)
                            // if(child && this.checkProperty(child,'name')){
                            //     
                            //      this.processTasksDocumet(documentsArray,typeDoc,true)
                            // }
                        
                        }
                    }
                })
            }
            if(this.checkProperty(this.petition,'companyDetails') && this.checkProperty(this.petition,'companyDetails','documents') ){
                let tempDocs = this.checkProperty(this.petition,'companyDetails','documents');
                if(this.checkProperty(this.petition,'caseDocs','companyPtnr')){
                    Object.assign(tempDocs,{'other':this.checkProperty(this.petition,'caseDocs','companyPtnr')})
                }
                let catDocuments =Object.entries(tempDocs);
                let documentsArray = [];
                _.forEach(catDocuments,(item)=>{
                    let obj = {}
                    if(item){
                        let category =_.cloneDeep(item[0]);
                        if(category != 'letterHeads' ){
                            let tempSection= category
                            if(item[1].length>0){
                                let documents =_.cloneDeep(item[1]);
                                let filteredDocs =[]
                                _.forEach(documents,(docs)=>{
                                    if(!_.has(docs,'status') || (_.has(docs,'status') && this.checkProperty(docs,'status'))){
                                        filteredDocs.push(docs)
                                    }
                                })
                                if(filteredDocs){
                                    obj[tempSection] = filteredDocs
                                }
                            }
                            else{
                                obj[tempSection] = []
                            }
                        }
                    }
                    this.mergeAllDocumet(obj,'caseDocs')
                    documentsArray.push(obj)
                })
                if(documentsArray){
                    this.processedCompanyPtnrDocs  =_.cloneDeep(documentsArray);
                    this.processTasksDocumet(this.processedCompanyPtnrDocs,'companyPtnr',true)
                }
            }
        },
        processChildDocs(childItem,callFrom = false ){
            let returnDocs= [];
            let callFromTest = callFrom
            let child = childItem
            if(this.checkProperty(child,'documents')){
                let catDocuments =Object.entries(this.checkProperty(child,'documents'));
                let documentsArray = [];
                _.forEach(catDocuments,(item)=>{
                    let obj = {}
                    if(item){
                        let category =_.cloneDeep(item[0]);
                        let tempSection= category
                        if(item[1].length>0){
                             
                            
                            let documents =_.cloneDeep(item[1]);
                            let filteredDocs =[]
                            _.forEach(documents,(docs)=>{
                                if(!_.has(docs,'status') || (_.has(docs,'status') && this.checkProperty(docs,'status'))){
                                    filteredDocs.push(docs)
                                }
                            })
                            
                            if(filteredDocs){
                                obj[tempSection] = filteredDocs
                            }
                        }
                        else{
                            obj[tempSection] = []
                        }
                    }
                    // if(callFromTest){
                    //     this.mergeAllDocumet(obj,'children')
                    // }
                    documentsArray.push(obj)
                })
                if(documentsArray){
                    returnDocs  =_.cloneDeep(documentsArray);
                    // if(child && this.checkProperty(child,'name')){
                    //     let typeDoc = 'child '+this.checkProperty(child,'name')+' Docs'
                    //      this.processTasksDocumet(documentsArray,typeDoc,true)
                    // }
                   
                }
                return returnDocs
            }
        },
        getDocumentsList(){
        let payLoad={
            petitionId: this.checkProperty(this.petition,'_id') ,
		    categories: ['forms_and_letters','beneficiary_docs','scanned_copies'],
            entityType:'case',
            typeName: this.checkProperty(this.petition,'typeDetails','name'),
            subTypeName:this.checkProperty(this.petition,'subTypeDetails','name'),
        }
        if(this.checkProperty(this.petition,'subTypeDetails','id')==15){
            payLoad['entityType'] ='perm'
        }
        let path = '/petition-common/get-recent-downloads'
        this.$store.dispatch("commonAction" ,{data:payLoad,'path':path}).then((response) =>{
            let list = response 
            let recentDocsFormsList = _.filter(list, (item) => {
                return item.category == 'forms_and_letters'
            });
            if(recentDocsFormsList){
                let obj = {}
                if(recentDocsFormsList && this.checkProperty(recentDocsFormsList,'length')>0){
                    Object.assign(obj,{'recentDocsFormsList':recentDocsFormsList})
                }
                if(obj['recentDocsFormsList']){
                    this.recentDocsFormsList = obj
                }
               // this.processTasksDocumet(this.recentDocsFormsList,'Downloads',false)
                this.mergeAllDocumet(this.recentDocsFormsList,'Downloads')
            }
            let recentBenDocsList = _.filter(list, (item) => {
                return item.category == 'beneficiary_docs'
            });
            if(recentBenDocsList){
                let obj = {}
                if(recentBenDocsList && this.checkProperty(recentBenDocsList,'length')>0){
                    Object.assign(obj,{'recentBenDocsList':recentBenDocsList})
                }
                if(obj['recentBenDocsList']){
                    this.recentBenDocsList = obj
                }
                //this.processTasksDocumet(this.recentBenDocsList,'otherMerge',false)
                this.mergeAllDocumet(this.recentBenDocsList,'otherMerge')
            }
            let recentScannedDocsList = _.filter(list, (item) => {
                return item.category == 'scanned_copies'
            });
            if(recentScannedDocsList){
                let obj = {}
                if(recentScannedDocsList && this.checkProperty(recentScannedDocsList,'length')>0){
                    Object.assign(obj,{'recentScannedDocsList':recentScannedDocsList})
                }
                if(obj['recentScannedDocsList']){
                    this.recentScannedDocsList = obj
                }
                //this.processTasksDocumet(this.recentScannedDocsList,'otherMerge',false)
                this.mergeAllDocumet(this.recentScannedDocsList,'otherMerge')
            }
          })
          .catch((err) =>{  

          })

        },
        processChequesDocs(){
            let checkDocs = [];
            if(this.checkProperty(this.petition,'caseDocs') && this.checkProperty(this.petition,'caseDocs','checks') && this.checkProperty(this.petition['caseDocs'],'checks','length')>0){
                _.forEach(this.petition['caseDocs']['checks'],(item)=>{
                    checkDocs.push(item)
                })
            }
            if(this.checkProperty(this.petition,'filingFeeDocs') && this.checkProperty(this.petition ,'filingFeeDocs', 'cheques') && this.checkProperty(this.petition['filingFeeDocs'],'cheques','length')>0){
                _.forEach(this.petition['filingFeeDocs']['cheques'],(item)=>{
                    checkDocs.push(item)
                })
            }
            let obj = {'cheques':checkDocs}
            this.processedChequeDocs = obj
            this.processTasksDocumet(this.processedChequeDocs,'checks',false)
            this.mergeAllDocumet(this.processedChequeDocs,'checks')
        },
        processLcaDocs(){
            let LCADocs = [];
            if(this.checkProperty(this.petition,'caseDocs') && this.checkProperty(this.petition,'caseDocs','lca') && this.checkProperty(this.petition['caseDocs'],'lca','length')>0){
                _.forEach(this.petition['caseDocs']['lca'],(item)=>{
                   
                    //Object.assign(item ,{ "isTrashDocument":false})
                    LCADocs.push(item)
                })
            }
            if(this.checkProperty(this.lcaDetails,'documents') && this.checkProperty(this.lcaDetails ,'documents', 'certified') && this.checkProperty(this.lcaDetails['documents'],'certified','length')>0){
                _.forEach(this.lcaDetails['documents']['certified'],(item)=>{
                    //Object.assign(item ,{ "isTrashDocument":false})
                    LCADocs.push(item)
                })
            }else{
                if(this.checkProperty(this.lcaDetails,'documents') && this.checkProperty(this.lcaDetails ,'documents', 'filed') && this.checkProperty(this.lcaDetails['documents'],'filed','length')>0){
                    _.forEach(this.lcaDetails['documents']['filed'],(item)=>{
                        //Object.assign(item ,{ "isTrashDocument":false});
                        LCADocs.push(item)
                    })
                }
            }
            let obj = {'lca':LCADocs}
            this.processedLcaDocs = obj
            this.processTasksDocumet(this.processedLcaDocs,'lca',false)
            this.mergeAllDocumet(this.processedLcaDocs,'lca')
        },
        prcoessAffidavtiDocs(){
            if(this.checkProperty(this.petition,'caseDocs') && this.checkProperty(this.petition,'caseDocs','affidavits') && this.checkProperty(this.petition['caseDocs'],'affidavits','length')>0){
                let catDocuments =this.checkProperty(this.petition,'caseDocs','affidavits');
                let documentsArray = [];
                if(this.checkProperty(catDocuments,'length')>0){
                    let tempobj = {};
                    tempobj['affidavits'] = catDocuments;
                    this.processedAffidavitDocs  = tempobj
                    _.forEach(catDocuments,(docItem)=>{
                        let tempobj={}
                        let label = docItem['name'];
                        let newName = label.replace(/\.pdf$/, '');
                        let arr = label.split('.');

                        if(_.has(docItem ,'path') && this.checkProperty(arr,'length' )>0 ){
                           if(this.checkProperty(arr,'length' )>1){
                            arr.pop();
                            
                           }
                           newName = arr.join('.');
                          

                        }


                        
                        tempobj[label] = [docItem]
                        this.processTasksDocumet(tempobj,newName,false ,true)
                    })
                    // this.processedAffidavitDocs  =_.cloneDeep(documentsArray);
                    // this.processTasksDocumet(documentsArray,'affidavits',true)
                }
            }else{
                    let objtemp = {'affidavits':[]};
                    this.processedAffidavitDocs  = objtemp;
                }
        },
       
        uploadToS3MainDocuments(index,docs){
            let self = this
             docs = docs.map(
                item =>
                (item = {
                    name: item.name,
                    file: item.file,
                    document: "",
                    path:'',
                    size:item.size ? item.size : null,
                    mimetype: item.type,
                    extn:item.extn?item.extn:'',
                    documentType:item.documentType?item.documentType:null,
                })
            );

           let docsList =[];
           if(this.uploadFormsAndLetters){
            docs.forEach(doc => { 

                if (
            (this.formLetterType == "Form" &&
              (doc.mimetype == "application/pdf" || doc.type == "application/pdf")) ||
            (this.formLetterType == "Letter" &&
              (doc.mimetype == "application/msword" ||
                doc.type == "application/msword" ||
                doc.mimetype ==
                  "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||
                doc.type ==
                  "application/vnd.openxmlformats-officedocument.wordprocessingml.document"))
          ) {
            docsList.push(doc);
          }

              })

           }else{
            docsList =docs
           }
           
            if (docsList.length > 0) {
                let filIndex = 0;
                docsList.forEach(doc => {    
                  this.fuploder = true;
                this.disable_uploadBtn = true;
                    let formData = new FormData();
                    formData.append("files", doc.file);
                    formData.append("secureType", "private");
                     formData.append("getDetails", true);
                    // alert(1)
                    this.$store.dispatch("uploadS3File", formData).then(response => {
                         filIndex++;
                         if (filIndex >= self.uploadMainDocuments.length) {
                            self.fuploder = false;
                            self.disable_uploadBtn = false;
                        }
                        response.data.result.forEach(urlGenerated => {
                    
                            doc.document = urlGenerated;
                            doc.path = urlGenerated;
                            //this.uploadMainDocuments.push(doc);
                            self.uploadOriginalDocument.push(doc);
                            
                            self.uploadOriginalDocument = _.cloneDeep(self.uploadOriginalDocument)
                            //alert(JSON.stringify(self.uploadOriginalDocument));
                        });
                       
                    });
                
                    
                });
            }

        },
        childDocsForDownloadAll(){
            if(this.checkProperty(this.petition,'dependentsInfo') && this.checkProperty(this.petition,'dependentsInfo','childrens') && this.checkProperty(this.petition['dependentsInfo']['childrens'],'length')>0){
                _.forEach(this.petition['dependentsInfo']['childrens'],(itemd)=>{
                    if(this.checkProperty(itemd,'documents')){
                        let catDocuments =Object.entries(this.checkProperty(itemd,'documents'));
                        let documentsArray = [];
                        _.forEach(catDocuments,(item)=>{
                            let obj = {}
                            if(item){
                                let category =_.cloneDeep(item[0]);
                                let tempSection= category
                                if(item[1].length>0){
                                    
                                    
                                    let documents =_.cloneDeep(item[1]);
                                    let filteredDocs =[]
                                    _.forEach(documents,(docs)=>{
                                        if(!_.has(docs,'status') || (_.has(docs,'status') && this.checkProperty(docs,'status'))){
                                            filteredDocs.push(docs)
                                        }
                                    })
                                    
                                    if(filteredDocs){
                                        obj[tempSection] = filteredDocs
                                    }
                                }
                                else{
                                    obj[tempSection] = []
                                }
                            }
                            this.mergeAllDocumet(obj,'children')
                        })
             
                    }
                })
            }
        }
    },
    mounted(){
        this.processTempFormsandLetters();
        this.showDragged = true;
        this.getGlobalConfigDetails()
        this.processCaseDocs();
        this.processUsicsDocuments()
        this.getCompanyDocs();
        this.getPetitionerDocs();
        this.processUSCISDocs();
        this.getFormsAndLetters();
        this.getScannedDocuments();
        this.getDocumentsList();
        this.processChequesDocs();
        this.processLcaDocs();
        this.getOtherMergeDocs();
        this.prcoessAffidavtiDocs();
        this.childDocsForDownloadAll();
        this.getSavedDocuments();
        this.getResponseDocs();
        if(this.checkProperty(this.$route ,'params', 'allDocumentsActiveTab')){
            setTimeout(()=>{
                this.setActiveTab =this.$route['params']['allDocumentsActiveTab'];
                this.$route['params']['allDocumentsActiveTab']= '';
            },10);

        }
        
    },
    computed:{
        isLcaRequired(){
            let returnVal = false;
            let wf = _.cloneDeep(this.workFlowDetails);
            if (wf && _.has(wf, "config")) {
                let lcaRequired = _.find(wf["config"], { code: "LCA_REQUEST",'actionRequired':'Yes' });
                if(lcaRequired){
                    returnVal = true;
                }
            }
            return returnVal
        },
        checkActivityCompleted(){
            let returVal =false;
            return (activityCode='')=>{

                if(this.petition && _.has(this.petition ,"completedActivities") ){
                if(this.petition['completedActivities'].indexOf(activityCode)>-1){
                    returVal =true;
                }
                }
            return returVal;
            }
        },
        checkWorkActivityisRequires(){
            return (code='')=>{
            if( _.has(this.workFlowDetails ,"config") && this.checkProperty(this.workFlowDetails ,'config', 'length') ){
                let config = this.workFlowDetails['config'];
                let ilteredItem = _.find(config, {"code":code,"actionRequired":'Yes'});
                if(ilteredItem){
                return true;
                }
                return false;
            }else{
                return false;
            }
            }
        },
        checkFormsandLetters(){
            return (data)=>{
                let returnVal = data['dataVal'];
                let docs = data['dataVal'];
                let benFinds = _.find(docs,{'depType':'beneficiary'});
                let spouseFinds = _.find(docs,{'depType':'spouse'});
                // let childFinds = _.filter(docs,(item)=>{
                //     return item['depType'] == 'child'
                // })
                
                
                if(!benFinds){
                    let tempBen = {'depType':'beneficiary' ,'docUserType':'Beneficiary' ,"depLabel":'beneficiary', "label":"Beneficiary Forms and Letters", "documents": { "beneficiary":[]}}
                    returnVal.push(tempBen)
                }
                if(!spouseFinds && this.checkProperty(this.petition,'dependentsInfo','spouse') && this.checkProperty(this.petition['dependentsInfo'],'spouse','h4Required') ){
                    let tempspouse ={ 'depType':'spouse' ,'docUserType':'Dependent' , "depLabel":'spouse',"label":"Spouse Forms and Letters", "documents": { "spouse":[]}}
                    returnVal.push(tempspouse)
                }
                // if(this.checkProperty(this.petition,'dependentsInfo','childrens') && this.checkProperty(this.petition['dependentsInfo'],'childrens','length')>0 ){
                //     _.forEach(this.petition['dependentsInfo']['childrens'],(item,inde)=>{
                //         if(_.has(item,'h4Required') && item['h4Required'] ){
                //             childCount++
                //         }
                //     })
                // }
                // if((childFinds && this.checkProperty(childFinds,'length')<=0) || this.checkProperty(childFinds,'length')< childCount){
                //     _.forEach(this.petition['dependentsInfo']['childrens'],(item,inde)=>{
                //         if(_.has(item,'h4Required') && item['h4Required'] ){
                //             let id = parseInt(inde)+1
                //             let childLabel = item['name']+' Forms and Letters'
                //             let tempitem=  { 'depType':'child' ,'docUserType':'Dependent' , "depLabel":"child_"+id ,"label":childLabel, "documents": { "child":[]}};
                //             returnVal.push(tempitem)
                //         }
                //     })
                // }
                return returnVal
            }
        },
        checkSavedDocs(){
            let returnVal = true;
            let _self = this
            if(_self.processedTaskDocs && _self.checkProperty(_self.processedTaskDocs,'length')>0 ){
                _.forEach(_self.processedTaskDocs,(mItem)=>{
                    if( !_self.checkProperty(mItem, 'isTrashDocument') ){
                        returnVal = false;
                        return returnVal
                    }else if( _self.checkProperty(mItem, 'tasks') && _self.checkProperty(mItem, 'tasks' ,'length') >0){
                        _.forEach(mItem['tasks'],(sItem)=>{
                            if(! _self.checkProperty(sItem, 'isTrashDocument')  ){
                                returnVal = false;
                                return returnVal
                            }else if(_self.checkProperty(sItem, 'tasks') && _self.checkProperty(sItem, 'tasks' ,'length') >0){
                                _.forEach(sItem['tasks'],(item)=>{
                                    if(! _self.checkProperty(item, 'isTrashDocument')  ){
                                        returnVal = false;
                                        return returnVal
                                    
                                    }else if(_self.checkProperty(item, 'tasks') && _self.checkProperty(item, 'tasks' ,'length') >0){
                                        _.forEach(item['tasks'],(dItem)=>{
                                            if(! _self.checkProperty(dItem, 'isTrashDocument')  ){
                                                returnVal = false;
                                                return returnVal
                                                
                                            }else if(_self.checkProperty(dItem, 'tasks') && _self.checkProperty(dItem, 'tasks' ,'length') >0){
                                                _.forEach(dItem['tasks'],(dbItem)=>{
                                                    if(! _self.checkProperty(dbItem, 'isTrashDocument')  ){
                                                        returnVal = false;
                                                        return returnVal
                                                    }else if(_self.checkProperty(dbItem, 'tasks') && _self.checkProperty(dbItem, 'tasks' ,'length') >0){
                                                        _.forEach(dbItem['tasks'],(yItem)=>{
                                                            if(! _self.checkProperty(yItem, 'isTrashDocument')  ){
                                                                returnVal = false;
                                                                return returnVal
                                                            }
                                                        })
                                                    }
                                                })
                                            }
                                        })
                                    }
                                })
                            }
                        })
                    }
                })
            }else{
                returnVal = true
            }
            if(returnVal){
                setTimeout(()=>{
                    this.updateLoading(false)
                },10);
            }
            return returnVal
        },
        checkIsChildh4Required(){
            let returVal = false;
            if(this.checkProperty( this.petition['dependentsInfo'] ,'childrens')){
               _.forEach(this.petition['dependentsInfo']['childrens'],( item)=>{
                   if(item.h4Required==true){
                       returVal =true;
                   }
                })
            }
            return returVal;
        },
        checkValue(){
            return (data)=>{
              let returnVal = false
                if(data && _.has(data,'dataVal') ){
                    let catDocuments =Object.entries(data['dataVal']);
                    if(catDocuments){
                        _.forEach(catDocuments,(item)=>{
                            if(item){
                                let category  =_.cloneDeep(item[0]);
                                if(this.checkProperty(data['dataVal'],category) && this.checkProperty(data['dataVal'],category,'length')>0 ){
                                    returnVal =  true;
                                }else{
                                    returnVal =  false;
                                }
                            }
                        })
                    }

                }else{
                    returnVal =  false;
                }
                return returnVal
                
            }
        },
        returnDocLabel(){
            return (data)=>{
              let returnVal = ''
                if(data && _.has(data,'dataVal') ){
                    let catDocuments =Object.entries(data['dataVal']);
                    if(catDocuments){
                        _.forEach(catDocuments,(item)=>{
                            if(item){
                                let category  =_.cloneDeep(item[0]);
                                returnVal = category
                            }
                        })
                    }

                }else{
                    returnVal =  '';
                }
                return returnVal
                
            }
        },
        checkSectionValue(){
            return (data)=>{
              let returnVal = false
              let count = 0
              let valueCount = 0
                if(data && _.has(data,'dataVal') && this.checkProperty(data,'dataVal') ){
                    _.forEach(data['dataVal'],(docObj)=>{
                        if(docObj){
                            let catDocuments =Object.entries(docObj);
                            if(catDocuments){
                                _.forEach(catDocuments,(item)=>{
                                    if(item){
                                        let category  =_.cloneDeep(item[0]);
                                        
                                        if(this.checkProperty(docObj,category) && this.checkProperty(docObj,category,'length')>0  ){
                                            valueCount++
                                        }
                                    }else{
                                        count++
                                    }
                                })
                            }
                        }
                    })

                }else{
                    count++
                }
                
                if(valueCount>0){
                    returnVal = false
                }else{
                    returnVal = true
                }
                if(returnVal){
                    setTimeout(()=>{
                        this.updateLoading(false);
                        this.updateLoading(false,'NoDataFoundRef')
                    },10);
            
                }
                
                return returnVal
                
            }
        }
    },
    watch:{
        downloadDocList:function(value){
            if(!value){
                this.reloadCase();
            }
        },
        
        formLetterType:function(value){
            this.uploadOriginalDocument =[];
            // :accept="acceptedFiles"
            if (value == "Form") {
        
                this.acceptedFiles = "application/pdf";
            } else if (value == "Letter") {
                this.acceptedFiles = "application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document";
            } 

        },
        '$store.state.isDragged'(val) {
            if(val){
                this.showDragged = val;
            }
            
        }
    }
}
</script>