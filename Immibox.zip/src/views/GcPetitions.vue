<template>
<div>
    <div class="content-header">
        <div class="content-header-left">
            <div class="search">
                <vs-input icon-pack="feather" icon="icon-search" placeholder="Search" class="is-label-placeholder" v-model.lazy="searchtxt" />
            </div>
        </div>
        <div class="content-header-right">

            <vs-button color="secondary" class="nabtn delete-button" type="border" v-if="(roleId == 1 || roleId == 2) && deletePetitionIds.length > 0" @click="deleteApplication = true">Delete Application</vs-button>

            <vs-button color="primary" class="nabtn" type="border" v-if="roleId == 1 || roleId == 2" @click="newApplication = true">New Application</vs-button>

            <vs-dropdown vs-custom-content vs-trigger-click>
                <vs-button color="primary" class="filter-btn" type="border" icon-pack="feather" icon="icon-chevron-down" icon-after>
                    <img src="@/assets/images/main/icon-filter.svg" /> Filters
                </vs-button>
                <vs-dropdown-menu ref="filter_menu" class="filters-content">
                    <div class="filters-form-fileds">
                        <div class="form-container">
                            <div class="vx-row">
                                <div class="vx-col md:w-1/3 w-full con-select filters-search">
                                    <label class="typo__label">Search</label>
                                    <vs-input icon-pack="feather" icon class="is-label-placeholder" v-model="filter_searchtxt" />
                                </div>

                                <div class="vx-col md:w-1/3 w-full con-select">
                                    <label class="typo__label">Status</label>
                                    <multiselect v-model="selected_statusids" :options="all_statusids" :multiple="true" :hideSelected="true" :close-on-select="false" :clear-on-select="false" :preserve-search="true" placeholder="Select Status" label="name" track-by="name" :preselect-first="false">
                                        <!-- <template slot="selection" slot-scope="{ values, search, isOpen }">
                                            <span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">{{ values.length }} options selected</span>
                                        </template> -->
                                        <template slot="selection" slot-scope="{ values, isOpen }">
                                            <span
                                            class="multiselect__selectcustom"
                                            v-if="values.length && !isOpen"
                                            >{{ values.length }} options selected</span
                                            >
                                            <span
                                            class="multiselect__selectcustom"
                                            v-if="values.length && isOpen"
                                            ></span>
                                        </template> 
                                    </multiselect>
                                </div>
                                <!---all_subtypes---->
                                <div class="vx-col md:w-1/3 w-full con-select">
                                    <label class="typo__label">Case Type</label>
                                    <multiselect @input="changedsubtypes()" v-model="selected_subtypes" :options="all_subtypes" :multiple="true" :hideSelected="true" :close-on-select="false" :clear-on-select="false" :preserve-search="true" placeholder="Select Case Type" label="name" track-by="name" :preselect-first="false">
                                        <!-- <template slot="selection" slot-scope="{ values, search, isOpen }">
                                            <span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">{{ values.length }} options selected</span>
                                        </template> -->
                                        <template slot="selection" slot-scope="{ values, isOpen }">
                                            <span
                                            class="multiselect__selectcustom"
                                            v-if="values.length && !isOpen"
                                            >{{ values.length }} options selected</span
                                            >
                                            <span
                                            class="multiselect__selectcustom"
                                            v-if="values.length && isOpen"
                                            ></span>
                                        </template> 
                                    </multiselect>
                                </div>
                                <!---users--->
                                <div v-if="roleId != 6 && roleId != 7" class="vx-col md:w-1/3 w-full con-select">
                                    <label class="typo__label">Select Users</label>
                                    <multiselect @input="changedusers()" v-model="selected_users" :options="users" :multiple="true" :hideSelected="true" :close-on-select="false" :clear-on-select="false" :preserve-search="true" placeholder="Select Users" label="name" track-by="name" :preselect-first="false" @search-change="user_search">
                                        <!-- <template slot="selection" slot-scope="{ values, search, isOpen }">
                                            <span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">{{ values.length }} options selected</span>
                                        </template> -->
                                        <template slot="selection" slot-scope="{ values, isOpen }">
                                        <span
                                        class="multiselect__selectcustom"
                                        v-if="values.length && !isOpen"
                                        >{{ values.length }} options selected</span
                                        >
                                        <span
                                        class="multiselect__selectcustom"
                                        v-if="values.length && isOpen"
                                        ></span>
                                    </template> 
                                    </multiselect>
                                </div>

                                <div class="vx-col md:w-1/3 w-full con-select">
                                    <label class="typo__label">Country</label>
                                    <multiselect ref="country_selectbox" @input="changedCountry()" v-model="selected_country_obj" :options="countries" :multiple="false" :close-on-select="true" :clear-on-select="false" :preserve-search="true" placeholder="Select Country" label="name" track-by="name" :preselect-first="false">
                                        <!-- <template slot="selection" slot-scope="{ values, search, isOpen }">
                                            <span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">{{ values.length }} options selected</span>
                                        </template> -->
                                        <template slot="selection" slot-scope="{ values, isOpen }">
                                            <span
                                            class="multiselect__selectcustom"
                                            v-if="values.length && !isOpen"
                                            >{{ values.length }} options selected</span
                                            >
                                            <span
                                            class="multiselect__selectcustom"
                                            v-if="values.length && isOpen"
                                            ></span>
                                        </template> 
                                    </multiselect>
                                </div>

                                <!--------Select States----->
                                <div class="vx-col md:w-1/3 w-full con-select">
                                    <label class="typo__label">States</label>
                                    <multiselect v-bind:disabled="country_code <= 0" @input="changedState()" v-model="seleted_states" :options="all_states" :multiple="false" :close-on-select="true" :clear-on-select="false" :preserve-search="true" placeholder="Select States" label="name" track-by="name" :preselect-first="false">
                                        <template slot="selection" slot-scope="{ values, search, isOpen }">
                                            <span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">{{ values.length }} options selected</span>
                                        </template>
                                    </multiselect>
                                </div>
                                <!---- seleted_locations --->
                                <div class="vx-col md:w-1/3 w-full con-select">
                                    <label class="typo__label">Locations</label>
                                    <multiselect v-bind:disabled="final_selected_states.length <= 0" v-model="seleted_locations" :options="all_locations" :multiple="true" :hideSelected="true" :close-on-select="false" :clear-on-select="false" :preserve-search="true" placeholder="Select Locations" label="name" track-by="name" :preselect-first="false">
                                        <!-- <template slot="selection" slot-scope="{ values, search, isOpen }">
                                            <span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">{{ values.length }} options selected</span>
                                        </template> -->
                                        <template slot="selection" slot-scope="{ values, isOpen }">
                                            <span
                                            class="multiselect__selectcustom"
                                            v-if="values.length && !isOpen"
                                            >{{ values.length }} options selected</span
                                            >
                                            <span
                                            class="multiselect__selectcustom"
                                            v-if="values.length && isOpen"
                                            ></span>
                                        </template> 
                                    </multiselect>
                                </div>
                                <!--Created Date--->
                                <div class="vx-col md:w-1/3 w-full con-select">
                                    <label class="typo__label">Created Date</label>
                                    <date-range-picker :autoApply="autoApply" :ranges="false" v-model="selected_createdDateRange"></date-range-picker>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="filters-status">
                        <div class="left-buttons"></div>
                        <div class="right-buttons">
                            <vs-button color="success" class="save" type="filled" v-on:click="set_filter()">Apply</vs-button>
                            <vs-button color="dark" class="cancel" type="filled" v-on:click="clear_filter($event)">Clear</vs-button>
                        </div>
                    </div>
                </vs-dropdown-menu>
            </vs-dropdown>
            <!-- end -->
        </div>
    </div>
    <vs-popup class="Change_petition_wrap" title="Change Paralegal" :active.sync="ChangePetition">
        <div class="Change_petition">
            <div class="search">
                <vs-input :placeholder="Search" label="Search Paralegal" ref="input" :class="inputClassses" class="z-50" icon-pack="feather" icon="icon-search" icon-no-border v-model="searchQuery" @keyup.esc="escPressed" @keyup.up="increaseIndex(false)" @keyup.down="increaseIndex" @keyup.enter="suggestionSelected" @focus="updateInputFocus" @blur="updateInputFocus(false)"></vs-input>
            </div>
            <div class="note">
                <!-- <vs-textarea v-model="textarea" label="Comments…" class="w-full" /> -->
                <ckeditor v-model="textarea" label="Comments…" class="w-full"  :editor="editor" :config="editorConfig"></ckeditor>

            </div>
        </div>
        <div class="actions_footer">
            <button class="btn cancel">Cancel</button>
            <button class="btn">Submit</button>
        </div>
    </vs-popup>

    <vs-popup v-if="deleteApplication" class="holamundo main-popup" title="Delete Application(s)" :active.sync="deleteApplication">
        <div class="form-container">
            <div class="vx-row">
                <div class="vx-col w-full">

                    <h3 style="padding:20px 0px;"> Are you sure want delete the Application(s) </h3>
                </div>
                <div class="popup-footer">
                    <vs-button color="dark" @click="deleteApplication = false;" class="cancel" type="filled">Cancel</vs-button>
                    <vs-button color="success" @click="deleteApplications()" class="save" type="filled">Submit</vs-button>
                </div>
            </div>
        </div>
    </vs-popup>

    <vs-popup v-if="newApplication" class="holamundo main-popup" title="New Application" :active.sync="newApplication">
        <form>
            <div class="form-container">
                <div class="vx-row">
                    <div class="vx-col w-full">
                        <vs-input v-model="gc.name" name="name" data-vv-as="Name" v-validate="'required'" class="w-full" label="Name" />
                        <span class="text-danger text-sm" v-show="errors.has('name')">{{
                errors.first("name")
              }}</span>
                    </div>
                    <div class="vx-col w-full">
                        <vs-input class="w-full" name="email" v-model="gc.email" data-vv-as="Email" v-validate="'required|email'" label="Email" />
                        <span class="text-danger text-sm" v-show="errors.has('email')">{{
                errors.first("email")
              }}</span>
                    </div>
                </div>
                <div class="text-danger text-sm formerrors" v-show="formerrors.msg">
                    <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
                </div>
            </div>

            <div class="popup-footer">
                <vs-button color="dark" @click="newApplication = false;gc = {};" class="cancel" type="filled">Cancel</vs-button>
                <vs-button color="success" @click="saveapplication" class="save" type="filled">Save</vs-button>
            </div>
        </form>
    </vs-popup>

    <div class="accordian-table custom-table no-wrap">
        <div v-if="loaded">
            <vs-table noDataText="No data available" :data="listItems" @selected="petitionlink">
                <template v-if="listItems.length > 0" slot="thead">
                    <vs-th>
                        <vs-checkbox v-if="roleId == 1 || roleId == 2" v-model="selectAll" @change="selectAllApplications()" class="padl6"></vs-checkbox>

                        <a @click="sortMe('caseNo')" v-bind:class="{
                  sort_ascending: sortKeys['caseNo'] == 1,
                  sort_descending: sortKeys['caseNo'] != 1,
                }">Case No</a>
                    </vs-th>
                    <vs-th><a @click="sortMe('beneficiaryDetails.name')" v-bind:class="{
                  sort_ascending: sortKeys['beneficiaryDetails.name'] == 1,
                  sort_descending: sortKeys['beneficiaryDetails.name'] != 1,
                }">Beneficiary</a>
                    </vs-th>
                    <vs-th>
                        <a @click="sortMe('updatedOn')" v-bind:class="{
                  sort_ascending: sortKeys['updatedOn'] == 1,
                  sort_descending: sortKeys['updatedOn'] != 1,
                }">
                           Created On</a></vs-th>
                    <vs-th><a @click="sortMe('communicationDetailslength')" v-bind:class="{
                  sort_ascending: sortKeys['communicationDetailslength'] == 1,
                  sort_descending: sortKeys['communicationDetailslength'] != 1,
                }">
                            Messages</a></vs-th>
                    <vs-th v-if="currentuserRole == 7 && listItems[0].enableEditOption"> Action</vs-th>

                    <vs-th> 
                        <a @click="sortMe('statusDetails.name')"  v-bind:class="{'sort_ascending':sortKeys['statusDetails.name']==1, 'sort_descending':sortKeys['statusDetails.name']!=1}" >
                         Status
                        </a>
                    </vs-th>
                </template>
                <template slot-scope="{ data }">
                    <vs-tr :data="petition" :key="petition.index" v-for="petition in data" class="vs-table--tr">
                        <vs-td>

                            <vs-checkbox v-if="roleId == 1 || roleId == 2" v-model="petition.is_checked"
                             @click="stopEvent($event)"
                             @change="selectApplication($event,petition._id,petition.is_checked)"></vs-checkbox>

                            <router-link :to="{
                    name: 'gcapplication',
                    params: { itemId: petition._id },
                  }">{{ petition.caseNo }}</router-link>
                        </vs-td>

                        <vs-td>{{ petition.beneficiaryDetails.name }}</vs-td>
                        <vs-td>{{ petition.createdOn | formatDate }}</vs-td>
                        <vs-td class="buttoncol">
                            <a v-if="petition.communicationDetails.length > 0" class="a-icon messageCount" href.prevent>
                                <label class="unread">{{
                    petition.communicationDetails.length
                  }}</label>
                                <img src="@/assets/images/main/message_icon2.svg" />
                            </a>

                        </vs-td>

                        <vs-td  @click="stopEvent($event)" v-if="currentuserRole == 7 && petition.enableEditOption">

                            <router-link :to="{name: 'fillgcquestionnaire', params: { itemId: petition._id },
                  }">
                                <button class="btn btn-brown">
                                    <span v-if="petition.statusId > 1">Update Application</span>
                                    <span v-else>Fill Application</span>
                                </button>
                            </router-link>

                        </vs-td>

                        <vs-td>
                            <span class="statusspan status_active" v-bind:class="{
                    status_active: petition.statusDetails.id == 1,
                    status_approved: petition.statusDetails.id == 2,
                    status_rejected: petition.statusDetails.id == 3,
                  }">{{ petition.statusDetails.name }}</span>

                        </vs-td>

                    </vs-tr>
                </template>
            </vs-table>

            <div class="table_footer" v-if="totalrecords > 10">
                <div class="vx-col con-select pages_select">
                    <label class="typo__label">Per Page</label>
                    <multiselect @input="changeperPage()" v-model="perpage" :options="perPeges" :multiple="false" :close-on-select="true" :clear-on-select="false" :preserve-search="true" placeholder="Per Page" :preselect-first="true">
                    </multiselect>
                </div>

                <paginate v-model="page" :page-count="totalpages" :page-range="3" :margin-pages="2" :click-handler="pageNate" prev-class="vs-pagination--buttons btn-prev-pagination vs-pagination--button-prev" next-class="vs-pagination--buttons btn-next-pagination vs-pagination--button-next" :prev-text="'<i></i>'" :next-text="'<i></i>'" :container-class="'pagination vs-pagination--nav'" :page-class="'page-item'"></paginate>
            </div>

        </div>
    </div>
</div>
</template>

<script>
import DateRangePicker from "vue2-daterange-picker";
import Paginate from "vuejs-paginate";
import Datepicker from "vuejs-datepicker-inv";
import Multiselect from "vue-multiselect-inv";
import JQuery from "jquery";
import moment from "moment";
import _ from "lodash";
import "vue2-daterange-picker/dist/vue2-daterange-picker.css";
import Vue from 'vue';
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
export default {
    components: {
        Datepicker,
        DateRangePicker,
        Multiselect,
        Paginate,
    },
    data: () => ({
        editor: ClassicEditor,
        editorConfig: {
           toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
        },
        deleteApplication: false,
        loaded: false,
        sortKeys: {},
        sortKey: {},
        newApplication: false,
        gc: {},
        buttoncol: true,
        ChangePetition: false,
        formerrors: {
            msg: "",
        },
        searchtxt: "",
        query: [],
        selected: [],
        listItems: [],
        currentuserRole: null,
        selecteduser: {
            petitionId: null,
            userName: null,
            email: null,
            typeName: null,
            subTypeName: null,
            instructions: null,
        },
        SendQuestionnaire: false,
        SuccessQuestionnaire: false,
        selected_createdDateRange: ["", ""],
        autoApply: "",
        countries: [],
        country_code: 0,
        selected_country_obj: "",
        selected_statusids: [],
        final_selected_statusids: [],
        all_states: [],
        seleted_states: [],
        final_selected_states: [],
        singel_final_selected_state: "",
        all_locations: [],
        seleted_locations: [],
        final_selected_locations: [],
        all_statusids: [],
        selected_statusids: [],
        final_selected_statusids: [],
        page: 1,
        perpage: 25,
        totalpages: 0,
        totalrecords: 0,
        filter_searchtxt: "",
        all_subtypes: [],
        selected_subtypes: [],
        final_selected_subtypes: [],

        final_filter_roleIds: [3, 4, 5, 9, 10],
        rolebased_filter: {
            3: {
                name: "supervisorIds",
                values: []
            },
            4: {
                name: "paralegalIds",
                values: []
            },
            5: {
                name: "attorneyIds",
                values: []
            },
            9: {
                name: "offshoreUserIds",
                values: []
            },
            10: {
                name: "evidenceSupervisorIds",
                values: []
            },
        },
        users: [],
        selected_users: [],
        final_selected_users: [],
        user_search_value: "",
        roleId: 0,

        all_peritioners: [],
        peritioners_search_value: "",
        selected_peritioners: [],
        final_selected_peritioners: [],
        deletePetitionIds: [],
        sortKeys: {},
        sortKey: {},
        selectAll: false,
        perPeges: [10, 25, 50, 75, 100], // [  {name:10 ,perPage:10} , {name:25 ,perPage:25} ,{name:50 ,perPage:50},{name:100 ,perPage:100}],
    }),
    watch: {
        searchtxt: function (value) {
            this.getpetitions();
        },
    },
    methods: {
        deleteApplications() {
            this.deleteApplication = false;
            this.$vs.loading();
            var postdata = {
                petitionIds: this.deletePetitionIds
            };
            this.$store
                .dispatch("petitioner/deleteapplication", postdata)
                .then((response) => {
                    this.deletePetitionIds = [];
                    this.getpetitions();
                    this.$vs.notify({
                        title: "Success",
                        
                position: "top-right",
                color: "primary",
                        text: response.message,
                    });
                    this.$vs.loading.close();

                })

        },
        selectAllApplications() {
            this.deletePetitionIds = [];
            var $this = this;
            if (this.selectAll) {

                _.forEach(this.listItems, function (obj, index) {
                    $this.listItems[index]['is_checked'] = true;
                })
                                this.deletePetitionIds = _.map(this.listItems, '_id');


            } else {
                _.forEach(this.listItems, function (obj, index) {
                    $this.listItems[index]['is_checked'] = false;
                })
            }
        },
        stopEvent(e){
             e.stopPropagation();
        },
        selectApplication(e, petitionId, checked) {
           if(!this.selectAll){
                this.deletePetitionIds = [];
           }
            if (checked && !this.selectAll) {
                 this.deletePetitionIds = [];
                this.deletePetitionIds.push(petitionId);

            }
           
        },
        saveapplication() {
            this.gc.today = moment().format("YYYY-MM-DD");
            this.$store
                .dispatch("petitioner/createapplication", this.gc)
                .then((response) => {

                    if (response.error) {
                        Object.assign(this.formerrors, {
                            msg: response.error.message,
                        });
                    } else {
                        this.newApplication = false;
                        this.gc = {};
                        this.$vs.notify({
                            title: "Success",
                            
                position: "top-right",
                color: "primary",
                            text: response.message,
                        });

                        this.getpetitions();

                    }

                });
        },
        petitionlink(tr) {
            let routedId = tr._id;
            const $ = JQuery;

            if (
                $(event.target).parents().hasClass("buttoncol") ||
                $(event.target).hasClass("buttoncol")
            ) {} else {
                this.$router.push({
                    path: `/gcapplication/${tr._id}`
                });
            }
        },
        pageNate(pageNum) {
            this.page = pageNum;
            this.getpetitions();
        },
        SendQuestionnaireUser() {
            this.$store
                .dispatch("petitioner/sendquestionnaire", this.selecteduser)
                .then((response) => {
                    if (response.error) {
                        Object.assign(this.formerrors, {
                            msg: response.error.message,
                        });
                    } else {
                        this.$vs.notify({
                            title: "Success",                            
                            position: "top-right",
                            color: "primary",
                            text: response.message,
                        });
                        this.SendQuestionnaire = false;
                        this.SuccessQuestionnaire = true;
                        var timer = this.$router;
                        setTimeout(function () {
                            timer.go("/cases");
                        }, 1000);
                    }

                    // this.listItems = response.list;
                });
        },
        setuser(petition) {
            this.selecteduser.petitionId = petition._id;
            this.selecteduser.userName = petition.beneficiaryDetails.name;
            this.selecteduser.email = petition.beneficiaryDetails.email;
            this.selecteduser.typeName =
                petition.typeDetails.name + "/" + petition.subTypeDetails.name;
            this.selecteduser.subTypeName = petition.subTypeDetails.name;
        },
        selectCreatedDateRange(option) {
            option.startDate = moment(option.startDate).format("YYYY-MM-DD");
            option.endDate = moment(option.endDate).format("YYYY-MM-DD");
            this.selected_createdDateRange = [option.startDate, option.endDate];
            
        },
        set_filter: function () {
            this.final_selected_statusids = [];

            if (this.selected_statusids.length > 0) {
                this.final_selected_statusids = [];
                for (let ind = 0; ind < this.selected_statusids.length; ind++) {
                    let current_index = this.selected_statusids[ind];
                    this.final_selected_statusids.push(current_index["id"]);
                }
            }

            /*//states
              this.final_selected_states= [];
              if( this.seleted_states.length >0 ){
                this.final_selected_states = [];
                for(let ind =0;ind < this.seleted_states.length ; ind++ ){
                  let current_index =  this.seleted_states[ind];
                  this.final_selected_states.push(current_index["id"]);
                }
              }*/

            //alert(this.singel_final_selected_state);

            this.final_selected_locations = [];
            if (this.seleted_locations.length > 0) {
                for (let ind = 0; ind < this.seleted_locations.length; ind++) {
                    let current_index = this.seleted_locations[ind];
                    this.final_selected_locations.push(current_index["id"]);
                }
            }

            this.searchtxt = this.filter_searchtxt;

            this.getpetitions();
            this.$refs["filter_menu"].dropdownVisible = false;
        },
        clear_filter: function () {
            this.searchtxt = "";
            this.selected_statusids = [];

            this.selected_country_obj = "";
            this.seleted_states = [];
            this.final_selected_states = [];
            this.singel_final_selected_state = "";

            this.seleted_locations = [];
            this.final_selected_locations = [];
            this.final_selected_statusids = [];

            this.date = "";
            this.date_range = [];
            this.selected_createdDateRange["startDate"] = "";
            this.selected_createdDateRange["endDate"] = "";

            this.filter_searchtxt = "";
            this.selected_subtypes = [];
            this.final_selected_subtypes = [];

            (this.rolebased_filter = {
                3: {
                    name: "supervisorIds",
                    values: []
                },
                4: {
                    name: "paralegalIds",
                    values: []
                },
                5: {
                    name: "attorneyIds",
                    values: []
                },
                9: {
                    name: "offshoreUserIds",
                    values: []
                },
                10: {
                    name: "evidenceSupervisorIds",
                    values: []
                },
            }),
            (this.final_selected_peritioners = []);
            this.selected_peritioners = [];
            //this.getlistItems();
            this.$refs["filter_menu"].dropdownVisible = false;
            this.getpetitions();
        },
        get_all_states() {
            this.$store.dispatch("getstates", this.country_code).then((response) => {
                this.all_states = response;
            });
        },
        getAllLocations() {
            Object.assign(this.query, {
                countryId: this.country_code,
                stateId: this.singel_final_selected_state, //this.final_selected_states//3922
            });

            this.$store.dispatch("getlocations", this.query).then((response) => {
                this.all_locations = response;
            });
        },
        get_statusids() {
            Object.assign(this.query, {
                category: "company_statuses",
            });

            this.$store
                .dispatch("get_petition_statusids", this.query)
                .then((response) => {
                    
                    this.all_statusids = response;
                });
        },
        getpetitions() {
            this.$vs.loading();
            let obj = {
                matcher: {
                    searchString: this.searchtxt,
                    statusIds: this.final_selected_statusids,
                    stateIds: [],
                    locationIds: this.final_selected_locations,
                },
                page: this.page,
                perpage: this.perpage,
                sortKeys: this.sortKey,
            };
            this.totalrecords = 0;
            if (this.singel_final_selected_state > 0) {
                obj["matcher"]["stateIds"] = [this.singel_final_selected_state];
            }

            if (
                this.selected_createdDateRange["startDate"] &&
                this.selected_createdDateRange["startDate"] != "" &&
                this.selected_createdDateRange["endDate"] != "" &&
                this.selected_createdDateRange["endDate"]
            ) {
                obj["matcher"]["createdDateRange"] = [
                    this.selected_createdDateRange["startDate"],
                    this.selected_createdDateRange["endDate"],
                ];
            }

            obj["matcher"]["countryIds"] = [];
            if (
                this.selected_country_obj["id"] &&
                this.selected_country_obj["id"] > 0
            ) {
                obj["matcher"]["countryIds"] = [this.selected_country_obj["id"]];
            }

            obj["matcher"]["subTypeIds"] = this.final_selected_subtypes;

            Object.keys(this.rolebased_filter).forEach((key) => {
                let filtered_item = this.rolebased_filter[key];
                obj["matcher"][filtered_item["name"]] = filtered_item["values"];
            });

            this.$store
                .dispatch("petitioner/getgcpetitions", obj)
                .then((response) => {
                    this.listItems = response.list;
                    this.totalpages = Math.ceil(response.totalCount / this.perpage);
                    this.totalrecords = response.totalCount;
                    this.loaded = true;
                    _.forEach(this.listItems, function (obj) {
                        _.set(obj, 'is_checked', false);
                    })
                    this.$vs.loading.close();
                });
        },

        changedCountry() {
            this.country_code = this.selected_country_obj["id"];
            this.get_all_states();

           
        },

        changedState() {
            this.singel_final_selected_state = "";
            this.final_selected_locations = [];
            this.singel_final_selected_state = this.seleted_states["id"];
            this.final_selected_states.push(this.seleted_states["id"]);
            this.getAllLocations();
        },
        multiple_changedState() {
            // alert();
            if (this.seleted_states.length > 0) {
                this.final_selected_states = [];
                for (let ind = 0; ind < this.seleted_states.length; ind++) {
                    let current_index = this.seleted_states[ind];
                    this.final_selected_states.push(current_index["id"]);
                }
                this.getAllLocations();
            } else {
                this.final_selected_states = [];
                this.final_selected_locations = [];
            }
        },

        getvisa_subtypes() {
            this.$store.dispatch("getvisasubtypes").then((response) => {
                
                this.all_subtypes = response;
            });
        },
        changedsubtypes() {
            this.final_selected_subtypes = [];
            if (this.selected_subtypes.length > 0) {
                for (let ind = 0; ind < this.selected_subtypes.length; ind++) {
                    let current_index = this.selected_subtypes[ind];
                    this.final_selected_subtypes.push(current_index["id"]);
                }
                
            }
        },
        getusers() {
            let matcher = {
                roleIds: this.final_filter_roleIds,
                searchString: this.user_search_value,
                page: 1,
            };
            let query = {};
            query["page"] = 1;
            query["perpage"] = 100;
            query["matcher"] = matcher;

            this.$store.dispatch("getusers", query).then((response) => {
                this.users = response.list;
            });
        },
        get_peritioners() {
            let matcher = {
                roleIds: [6],
                searchString: this.peritioners_search_value,
            };
            let query = {};
            query["page"] = 1;
            query["perpage"] = 100;
            query["matcher"] = matcher;

            this.$store.dispatch("getusers", query).then((response) => {
                this.all_peritioners = response.list;
            });
        },
        changedusers() {
            //rolebased_filter
            this.rolebased_filter = {
                3: {
                    name: "supervisorIds",
                    values: []
                },
                4: {
                    name: "paralegalIds",
                    values: []
                },
                5: {
                    name: "attorneyIds",
                    values: []
                },
                9: {
                    name: "offshoreUserIds",
                    values: []
                },
                10: {
                    name: "evidenceSupervisorIds",
                    values: []
                },
            };
            if (this.selected_users.length > 0) {
                for (let i = 0; i < this.selected_users.length; i++) {
                    let selected_user_item = this.selected_users[i];
                    let roleId = selected_user_item["roleId"][0];
                    this.rolebased_filter[roleId]["values"].push(
                        selected_user_item["_id"]
                    );
                }
            }
            
        },
        user_search(searchValue) {
            this.user_search_value = searchValue;
            this.getusers();
        },

        //
        changedperitioners() {
            this.final_selected_peritioners = [];
            if (this.selected_peritioners.length > 0) {
                for (let i = 0; i < this.selected_peritioners.length; i++) {
                    this.final_selected_peritioners.push(
                        this.selected_peritioners[i]["_id"]
                    );
                }
            }
            
            this.get_peritioners_beneficiaries();
        },
        peritioners_search_fun(searchValue) {
            this.peritioners_search_value = searchValue;
            this.get_peritioners();
        },
        get_peritioners_beneficiaries() {},
        sortMe(sort_key = "") {
            if (sort_key != "") {
                this.sortKeys[sort_key] = this.sortKeys[sort_key] == 1 ? -1 : 1;
                this.sortKey = {};
                this.sortKey[sort_key] = this.sortKeys[sort_key];

                localStorage.setItem("petitions_sort_key", sort_key);
                localStorage.setItem("petitions_sort_value", this.sortKey[sort_key]);
                this.getpetitions();
            }
        },
        changeperPage() {
            this.page = 1;
            localStorage.setItem("petitions_perpage", this.perpage);
            this.getpetitions();
        },
    },

    mounted() {
        this.username = this.$store.state.user.name;
        this.roleId = this.$store.state.user.loginRoleId;

        (this.sortKeys = {
            caseNo: 1,
            "beneficiaryDetails.name": 1,
            "typeDetails.name": 1,
            "petitionerDetails.name": 1,
            updatedOn: 1,
            communicationDetailslength: 1,
        }),
        (this.sortKey["updatedOn"] = 1);

        if (
            localStorage.getItem("petitions_sort_key") &&
            localStorage.getItem("petitions_sort_value") &&
            localStorage.getItem("petitions_sort_value") >= -1
        ) {
            this.sortKey = {};

            this.sortKey[localStorage.getItem("petitions_sort_key")] = parseInt(
                localStorage.getItem("petitions_sort_value")
            );
            this.sortKeys[localStorage.getItem("petitions_sort_key")] = this.sortKey[
                localStorage.getItem("petitions_sort_key")
            ];

            //alert();
            
        }
        if (localStorage.getItem("petitions_perpage")) {
            this.perpage = parseInt(localStorage.getItem("petitions_perpage"));
        }

        this.getvisa_subtypes();
        this.getusers();
        this.get_peritioners();
        this.currentuserRole = this.$store.state.user.loginRoleId;
        this.getpetitions();
        this.$store.dispatch("getcountries").then((response) => {
            
            this.countries = response;
        });

        this.selected_statusids = [];
        this.final_selected_statusids = [];
        this.seleted_states = [];
        this.final_selected_states = [];

        this.seleted_locations = [];
        this.final_selected_locations = [];
        this.get_statusids();
    },
};
</script>
