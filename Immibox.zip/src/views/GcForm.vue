<template>
  <div class="main-list-wrap pad0">
    <div class="gcform_section">
      <form>
        <div class="form-container">
          <div class="vx-row">
            <div class="vx-col w-full">
              <vx-input-group class="form-input-group">
                <vs-input
                  name="firstname"
                  class="w-full"
                  data-vv-as="First Name"
                  label="First Name"
                />
                <vs-input
                  class="w-full"
                  name="middleName"
                  data-vv-as="Middle Name"
                  label="Middle Name"
                />
                <vs-input
                  class="w-full"
                  name="lastName"
                  data-vv-as="Last Name"
                  label="Last Name"
                />
              </vx-input-group>
              <!-- <div class="input-group-error">
                        <p class="w-1/3">
                          <span class="text-danger text-sm"
                            v-show="errors.has('beneficiaryInfoform.firstname')">{{ errors.first("beneficiaryInfoform.firstname") }}</span>
                        </p>
                        <p class="w-1/3">
                        
                        </p>
                        <p class="w-1/3">
                          <span class="text-danger text-sm"
                            v-show="errors.has('beneficiaryInfoform.lastName')">{{ errors.first("beneficiaryInfoform.lastName") }}</span>
                        </p>
                        </div> -->
            </div>
            <div class="vx-col w-full md:w-1/2">
              <div class="form_group">
                <label class="form_label">job title</label>
                <vs-input class="w-full" data-vv-as="DOL Reference Number" />
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <label class="form_label">Street Address<em>*</em></label>
                <vs-input
                  class="w-full"
                  name="line1"
                  data-vv-as="Street Address"
                />
                <!-- <span
                          class="text-danger text-sm"
                          v-show="errors.has('line1')"
                        >{{ errors.first("line1") }}</span> -->
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <label class="form_label">Apt, Suite</label>
                <vs-input name="line2" data-vv-as="Apt, Suite" class="w-full" />
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <label class="form_label">Country</label>
                <div class="con-select">
                  <multiselect v-model="value" :options="options"></multiselect>
                </div>
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <label class="form_label">State</label>
                <div class="con-select">
                  <multiselect v-model="value" :options="options"></multiselect>
                </div>
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <label class="form_label">City</label>
                <div class="con-select">
                  <multiselect v-model="value" :options="options"></multiselect>
                </div>
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <label class="form_label">Zip Code</label>
                <div class="con-select">
                  <multiselect v-model="value" :options="options"></multiselect>
                </div>
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <label class="form_label"> Province (if applicable)</label>
                <vs-input name="line2" data-vv-as="Apt, Suite" class="w-full" />
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group ph_number">
                <div class="vs-component">
                  <label class="form_label">Telephone number</label>
                  <VuePhoneNumberInput v-model="value" />
                </div>
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <label class="form_label">Extension</label>
                <vs-input name="line2" data-vv-as="Apt, Suite" class="w-full" />
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <div class="vs-component">
                  <label class="form_label">Fax Number</label>
                  <VuePhoneNumberInput v-model="value" />
                </div>
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <label class="form_label">E-Mail</label>
                <vs-input name="line2" data-vv-as="Apt, Suite" class="w-full" />
              </div>
            </div>
          </div>
          <span class="form_devider"></span>
          <h3 class="small-header">Employer Information</h3>
          <div class="vx-row">
            <div class="vx-col w-full md:w-1/2">
              <div class="form_group">
                <label class="form_label">Legal business name</label>
                <vs-input class="w-full" data-vv-as="DOL Reference Number" />
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <label class="form_label"
                  >Trade name/Doing Business As (DBA), if applicable §</label
                >
                <vs-input
                  class="w-full"
                  name="line1"
                  data-vv-as="Street Address"
                />
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <label class="form_label">Street Address<em>*</em></label>
                <vs-input
                  class="w-full"
                  name="line1"
                  data-vv-as="Street Address"
                />
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <label class="form_label">Apt, Suite</label>
                <vs-input name="line2" data-vv-as="Apt, Suite" class="w-full" />
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <label class="form_label">Country</label>
                <div class="con-select">
                  <multiselect v-model="value" :options="options"></multiselect>
                </div>
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <label class="form_label">State</label>
                <div class="con-select">
                  <multiselect v-model="value" :options="options"></multiselect>
                </div>
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <label class="form_label">City</label>
                <div class="con-select">
                  <multiselect v-model="value" :options="options"></multiselect>
                </div>
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <label class="form_label">Zip Code</label>
                <div class="con-select">
                  <multiselect v-model="value" :options="options"></multiselect>
                </div>
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <label class="form_label"> Province (if applicable)</label>
                <vs-input name="line2" data-vv-as="Apt, Suite" class="w-full" />
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group ph_number">
                <div class="vs-component">
                  <label class="form_label">Telephone number</label>
                  <VuePhoneNumberInput v-model="value" />
                </div>
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <label class="form_label">Extension</label>
                <vs-input name="line2" data-vv-as="Apt, Suite" class="w-full" />
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <label class="form_label"
                  >Federal Employer Identification Number (FEIN from IRS)</label
                >
                <vs-input name="line2" data-vv-as="Apt, Suite" class="w-full" />
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <label class="form_label"
                  >NAICS code (must be at least 4-digits)</label
                >
                <vs-input name="line2" data-vv-as="Apt, Suite" class="w-full" />
              </div>
            </div>
          </div>
          <span class="form_devider"></span>
          <h3 class="small-header">Wage Processing Information</h3>
          <div class="vx-row">
            <div class="vx-col w-full">
              <div class="form_group">
                <div class="listitems">
                  <h6>Is the employer covered by ACWIA?</h6>
                  <ul class="custom-radio">
                    <li>
                      <vs-checkbox v-model="checkBox1">Yes</vs-checkbox>                      
                    </li>
                     <li>
                      <vs-checkbox v-model="checkBox1">No</vs-checkbox>                      
                    </li>
                  </ul>
                </div>
                <div class="listitems">
                  <h6>Is the employer covered by ACWIA?</h6>
                  <ul class="custom-radio">
                    <li>
                      <vs-checkbox v-model="checkBox1">Yes</vs-checkbox>                      
                    </li>
                     <li>
                      <vs-checkbox v-model="checkBox1">No</vs-checkbox>                      
                    </li>
                  </ul>
                </div> 
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <label class="form_label"
                  >Trade name/Doing Business As (DBA), if applicable §</label
                >
                <vs-input
                  class="w-full"
                  name="line1"
                  data-vv-as="Street Address"
                />
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <label class="form_label">Street Address<em>*</em></label>
                <vs-input
                  class="w-full"
                  name="line1"
                  data-vv-as="Street Address"
                />
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <label class="form_label">Apt, Suite</label>
                <vs-input name="line2" data-vv-as="Apt, Suite" class="w-full" />
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <label class="form_label">Country</label>
                <div class="con-select">
                  <multiselect v-model="value" :options="options"></multiselect>
                </div>
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <label class="form_label">State</label>
                <div class="con-select">
                  <multiselect v-model="value" :options="options"></multiselect>
                </div>
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <label class="form_label">City</label>
                <div class="con-select">
                  <multiselect v-model="value" :options="options"></multiselect>
                </div>
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <label class="form_label">Zip Code</label>
                <div class="con-select">
                  <multiselect v-model="value" :options="options"></multiselect>
                </div>
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <label class="form_label"> Province (if applicable)</label>
                <vs-input name="line2" data-vv-as="Apt, Suite" class="w-full" />
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group ph_number">
                <div class="vs-component">
                  <label class="form_label">Telephone number</label>
                  <VuePhoneNumberInput v-model="value" />
                </div>
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <label class="form_label">Extension</label>
                <vs-input name="line2" data-vv-as="Apt, Suite" class="w-full" />
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <label class="form_label"
                  >Federal Employer Identification Number (FEIN from IRS)</label
                >
                <vs-input name="line2" data-vv-as="Apt, Suite" class="w-full" />
              </div>
            </div>
            <div class="vx-col md:w-1/2 w-full">
              <div class="form_group">
                <label class="form_label"
                  >NAICS code (must be at least 4-digits)</label
                >
                <vs-input name="line2" data-vv-as="Apt, Suite" class="w-full" />
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  </div>
</template>
<script>
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import moment from "moment";
import JQuery from "jquery";
import FileUpload from "vue-upload-component/src";
import "vue-form-wizard/dist/vue-form-wizard.min.css";
import * as _ from "lodash";
import Datepicker from "vuejs-datepicker-inv";
import { CheckIcon } from "vue-feather-icons";
import { XIcon } from "vue-feather-icons";
//import addressFields from "@/views/common/addressForm.vue";
//import addressFields from "@/views/forms/fields/address.vue";
import VuePhoneNumberInput from "vue-phone-number-input";
import "vue-phone-number-input/dist/vue-phone-number-input.css";

export default {
  components: {
    // addressFields,
    VuePerfectScrollbar,
    VuePhoneNumberInput,
    FileUpload,
    Datepicker,
    CheckIcon,
    XIcon,
  },

  data: () => ({
    Employee: false,
    value: null,
    options: ["list", "of", "options"],
  }),
};
</script>