<template>
    <div>
        <div class="content-header">
            <div class="content-header-left">
                <div class="search">
                    <vs-input icon-pack="feather" icon="icon-search" placeholder="Search" class="is-label-placeholder"
                        v-model.lazy="searchtxt" />
                </div>
            </div>

            <div class="content-header-right">


                <vs-button type="border" class="light-blue-btn" @click="invitepetitioner=true">Invite Petitioner <span>
                        <img class="add-user-icon ml-2" src="@/assets/images/main/add-user.svg">
                    </span>
                </vs-button>

                <vs-button style="display:none" color="primary" class="filter-btn" @click="fetchAccessToken()"
                    type="border" icon-pack="feather" icon="icon-chevron-down" icon-after>
                    Integrate with Quickbooks
                </vs-button>
                <!--filter dropdown-->
                <vs-dropdown vs-custom-content vs-trigger-click>
                    <vs-button color="primary" class="filter-btn" type="border" icon-pack="feather"
                        icon="icon-chevron-down" icon-after>
                        <img src="@/assets/images/main/icon-filter.svg"> Filters
                    </vs-button>
                    <vs-dropdown-menu ref="filter_menu" class="filters-content">

                        <div class="filters-form-fileds">
                            <div class="form-container">
                                <div class="vx-row">
                                    <div class="vx-col md:w-1/3 w-full con-select">
                                        <label class="typo__label">Status</label>
                                        <multiselect v-model="selected_statusids" :options="all_statusids"
                                            :multiple="true" :hideSelected="true" :close-on-select="true"
                                            :clear-on-select="false" :preserve-search="true" placeholder="Select Status"
                                            label="name" track-by="name" :preselect-first="false">
                                            <!-- <template slot="selection" slot-scope="{ values, search, isOpen }"><span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">{{ values.length }} options selected</span></template> -->
                                            <template slot="selection" slot-scope="{ values, isOpen }">
                                                <span class="multiselect__selectcustom"
                                                    v-if="values.length && !isOpen">{{ values.length }} Status
                                                    Selected</span>
                                                <span class="multiselect__selectcustom"
                                                    v-if="values.length && isOpen"></span>
                                            </template>
                                        </multiselect>

                                    </div>

                                    <div class="vx-col md:w-1/3 w-full con-select">
                                        <label class="typo__label">Country</label>
                                        <multiselect @input="changedCountry()" v-model="selected_country_obj"
                                            :options="all_countries" :multiple="false" :close-on-select="true"
                                            :clear-on-select="false" :preserve-search="true"
                                            placeholder="Select Country" label="name" track-by="name"
                                            :preselect-first="false">
                                            <template slot="selection" slot-scope="{ values, search, isOpen }"><span
                                                    class="multiselect__single"
                                                    v-if="values.length &amp;&amp; !isOpen">{{ values.length }} options
                                                    selected</span></template>
                                        </multiselect>
                                    </div>

                                    <div class="vx-col md:w-1/3 w-full con-select">
                                        <label class="typo__label">States</label>
                                        <multiselect v-bind:disabled="filtered_country<=0" @input="changedState()"
                                            v-model="seleted_states" :options="all_states" :multiple="false"
                                            :close-on-select="true" :clear-on-select="false" :preserve-search="true"
                                            placeholder="Select States" label="name" track-by="name"
                                            :preselect-first="false">
                                            <template slot="selection" slot-scope="{ values, search, isOpen }"><span
                                                    class="multiselect__single"
                                                    v-if="values.length &amp;&amp; !isOpen">{{ values.length }} options
                                                    selected</span></template>
                                        </multiselect>

                                    </div>
                                    <!---- seleted_locations --->
                                    <div class="vx-col md:w-1/3 w-full con-select">
                                        <!--<vs-input class="w-full" label="Email" />-->
                                        <label class="typo__label">Locations</label>
                                        <multiselect v-bind:disabled="final_selected_states.length<=0"
                                            v-model="seleted_locations" :options="all_locations" :multiple="true"
                                            :hideSelected="true" :close-on-select="false" :clear-on-select="false"
                                            :preserve-search="true" placeholder="Select Locations" label="name"
                                            track-by="name" :preselect-first="false">
                                            <!-- <template slot="selection" slot-scope="{ values, search, isOpen }"><span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">{{ values.length }} options selected</span></template> -->
                                            <template slot="selection" slot-scope="{ values, isOpen }">
                                                <span class="multiselect__selectcustom"
                                                    v-if="values.length && !isOpen">{{ values.length }} Status
                                                    Selected</span>
                                                <span class="multiselect__selectcustom"
                                                    v-if="values.length && isOpen"></span>
                                            </template>
                                        </multiselect>

                                    </div>

                                    <!-- <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="date-picker-label">Posted Date</label>
                    <div class="main-placeholder right">
                      <i class="placeholder-icon IP-calendar-1"></i>
                      <datepicker  :typeable="true" placeholder="Select Date" v-model="date"></datepicker>
                    </div>
                  </div> -->
                                    <div class="vx-col md:w-1/3 w-full con-select">
                                        <label class="typo__label">Created Date</label>
                                        <date-range-picker :maxDate="new Date()" :autoApply="autoApply" :ranges="false"
                                            v-model="selected_createdDateRange"></date-range-picker>
                                    </div>
                                    <!-- <div class="vx-col md:w-1/3 w-full">
                        <vs-select v-model="city" class="w-full select-large" label="Posted By">
                          <vs-select-item :key="index" :value="item.value" :text="item.text"
                            v-for="(item,index) in cityOptions" class="w-full" />
                        </vs-select>
                  </div>-->

                                    <!-- <div class="vx-col md:w-1/3 w-full">
                        <vs-select v-model="city" class="w-full select-large" label="Submitted By">
                          <vs-select-item :key="index" :value="item.value" :text="item.text"
                            v-for="(item,index) in cityOptions" class="w-full" />
                        </vs-select>
                      </div>
                      <div class="vx-col md:w-1/3 w-full">
                        <vs-input class="w-full" label="Posted Date" />
                      </div>
                      <div class="vx-col md:w-1/3 w-full">
                        <vs-input class="w-full" label="Submitted Date" />
                      </div>
                      <div class="vx-col md:w-1/3 w-full">
                        <div class="custom-label">Pay Rate/HR($)</div>
                        <vs-slider step=10 v-model="value11"/>
                      </div>
                      <div class="vx-col md:w-1/3 w-full">
                        <div class="custom-label">Pay Rate/HR($)</div>
                        <vs-slider ticks step=25 v-model="value22"/>
                      </div>
                      <div class="vx-col md:w-1/3 w-full">
                        <vs-input class="w-full" label="Interview Status" />
                  </div>-->
                                </div>
                            </div>
                        </div>
                        <div class="filters-status">
                            <div class="left-buttons">
                                <!-- <vs-button color="success" class="clearall" type="filled">Clear All <i class="material-icons">
                      refresh
                      </i>
                </vs-button>-->
                            </div>
                            <div class="right-buttons">
                                <vs-button color="success" class="save" type="filled" v-on:click="set_filter()">Apply
                                </vs-button>
                                <vs-button color="dark" class="cancel" type="filled" v-on:click="clear_filter($event)">
                                    Clear</vs-button>
                            </div>
                        </div>
                    </vs-dropdown-menu>
                </vs-dropdown>
                <!-- end -->
            </div>
        </div>

        <NoDataFound v-if="petitioners.length == 0" content="" heading="No Petitioners Found" type='petitions' />

        <div class="accordian-table custom-table" v-if="petitioners.length > 0">
            <div>
                <vs-table :data="petitioners" @selected="petitionlink">
                    <template slot="thead">

                        <vs-th><a @click="sortMe('name')"
                                v-bind:class="{'sort_ascending':sortKeys['name']==1, 'sort_descending':sortKeys['name']!=1}">Company
                                Name</a></vs-th>
                        <vs-th><a @click="sortMe('authorizedSignatory.name')"
                                v-bind:class="{'sort_ascending':sortKeys['authorizedSignatory.name']==1, 'sort_descending':sortKeys['authorizedSignatory.name']!=1}">Representative
                                Name</a></vs-th>
                        <vs-th>Representative Phone</vs-th>
                        <vs-th><a @click="sortMe('createdOn')"
                                v-bind:class="{'sort_ascending':sortKeys['createdOn']==1, 'sort_descending':sortKeys['createdOn']!=1}">Registered
                                Date</a></vs-th>
                        <!-- <vs-th><a @click="sortMe('statusDetails.id')" v-bind:class="{'sort_ascending':sortKeys['statusDetails.id']==1, 'sort_descending':sortKeys['statusDetails.id']!=1}">Status</a></vs-th> -->
                        <vs-th>
                            <a @click="sortMe('statusDetails.name')"
                                v-bind:class="{'sort_ascending':sortKeys['statusDetails.name']==1, 'sort_descending':sortKeys['statusDetails.name']!=1}">
                                Status
                            </a>
                        </vs-th>
                    </template>
                    <template slot-scope="{ data }">
                        <vs-tr :data="tr" :key="indextr" v-for="(tr, indextr) in data" class="vs-table--tr">
                            <vs-td>
                                <img class="user-image" src="@/assets/images/main/avatar2.svg" />
                                <router-link :to="{ name: 'petitionerdetails', params: { itemId: data[indextr]._id }}">
                                    {{ data[indextr].name }}</router-link>

                            </vs-td>

                            <vs-td>
                                <div class="cursor-pointer">
                                    {{ data[indextr].authorizedSignatory.name }}
                                </div>
                            </vs-td>

                            <vs-td>
                                <div class="cursor-pointer">{{ data[indextr].phone }}</div>
                            </vs-td>
                            <vs-td>
                                <div class="cursor-pointer">{{ data[indextr].createdOn | formatDateTime }}</div>
                            </vs-td>
                            <vs-td>
                                <div class="cursor-pointer">
                                    <span v-bind:class="{
                    status_registered: data[indextr].statusDetails.id == 1,
                    status_approved: data[indextr].statusDetails.id == 2,
                    status_rejected: data[indextr].statusDetails.id == 3
                  }">{{ data[indextr].statusDetails.name }}</span>
                                </div>    </vs-td>
                        </vs-tr>

                    </template>    

                </vs-table>
                <div class="table_footer">

                    <div class="vx-col  con-select" v-if="petitioners.length > 0">
                        <label class="typo__label">Per Page{{invitepetitioner}}</label>
                        <multiselect @input="changeperPage()" v-model="perpage" :options="perPeges" :multiple="false"
                            :close-on-select="true" :clear-on-select="false" :preserve-search="true"
                            placeholder="Per Page" :preselect-first="true">

                        </multiselect>
                    </div>
                    <paginate v-if="petitioners.length>0" v-model="page" :page-count="totalpages" :page-range="3"
                        :margin-pages="2" :click-handler="pageNate"
                        prev-class="vs-pagination--buttons btn-prev-pagination vs-pagination--button-prev"
                        next-class="vs-pagination--buttons btn-next-pagination vs-pagination--button-next"
                        :prev-text="'<i></i>'" :next-text="'<i></i>'" :container-class="'pagination vs-pagination--nav'"
                        :page-class="'page-item'">
                    </paginate>
                </div>

            </div>
        </div>

        <vs-popup class="holamundo main-popup" title="Invite Petitioner"
            v-if="invitepetitioner && userData && (userData.roleId.indexOf(1) >-1 ||userData.roleId.indexOf(2) >-1 )"
            :active.sync="invitepetitioner">
            <div>
                <invitePetitioner @close_invitePopup="invitepetitioner=false"> </invitePetitioner>
            </div>
        </vs-popup>



    </div>


</template>

<script>
import DateRangePicker from "vue2-daterange-picker";
import Datepicker from "vuejs-datepicker-inv";
import Multiselect from 'vue-multiselect'
import Paginate from 'vuejs-paginate'
import "vue2-daterange-picker/dist/vue2-daterange-picker.css";
import JQuery from "jquery";
import invitePetitioner from "./invitePetitioner.vue"
import NoDataFound from "@/views/common/noData.vue";

export default {
    components: {
        invitePetitioner,
        Datepicker,
        DateRangePicker,
        Multiselect,
        Paginate,
        NoDataFound
    },
    data: () => ({
        userData:null,
        searchtxt: "",
        query: [],
        petitioners: [],
        all_countries: [],
        selected_country_obj: '',
        filtered_country: '',
        country_code: 231,

        all_statusids: [],
        selected_statusids: [],
        final_selected_statusids: [],
        selected_createdDateRange: {},
        all_states: [],
        seleted_states: [],
        final_selected_states: [],
        singel_final_selected_state: '',
        // locationIds
        all_locations: [],
        seleted_locations: [],
        final_selected_locations: [],

        date: '',
        date_range: [],
        page: 1,
        perpage: 50,
        totalpages: 0,
        autoApply: "",

        sortKeys: {},
        sortKey: {},
        perPeges: [10, 25, 50, 75, 100],

    }),
    watch: {
        searchtxt: function (value) {
            this.getPetitioners();
        }
    },
    methods: {
        petitionlink(tr) {
            let routedId = tr._id;
            const $ = JQuery;
            if (
                $(event.target)
                .parents()
                .hasClass("buttoncol") ||
                $(event.target).hasClass("buttoncol")
            ) {} else {
                this.$router.push({
                    path: `/petitioner-details/${tr._id}`
                });
            }
        },
        fetchAccessToken() {
            let authUri = "https://appcenter.intuit.com/connect/oauth2?client_id=ABdNZGhAAEie2BKr32PTAyecMj6rxjkK0qj6wZNxEv2f2sXDCP&response_type=code&scope=com.intuit.quickbooks.accounting%20com.intuit.quickbooks.payment%20openid%20email%20profile&redirect_uri=http://localhost:8080/callback&state=sampleTest"
            window.open(authUri, "_blank", "toolbar=yes,scrollbars=yes,resizable=yes")
        },
        getPetitioners() {

            let lq = {
                search: this.searchtxt,
                statusIds: this.final_selected_statusids,
                stateIds: [], //this.final_selected_states,
                locationIds: this.final_selected_locations,
                registeredDateRange: this.date_range,
                page: this.page,
                perpage: this.perpage,
                sortKeys: this.sortKey
            }
            if (this.singel_final_selected_state > 0) {
                lq['stateIds'] = [this.singel_final_selected_state];
            }
            if ((this.selected_createdDateRange['startDate'] && this.selected_createdDateRange['startDate'] != '') && (this.selected_createdDateRange['endDate'] != '' && this.selected_createdDateRange['endDate'])) {
                lq['registeredDateRange'] = [this.selected_createdDateRange['startDate'], this.selected_createdDateRange['endDate']]
            }
            lq['countryIds'] = [];
            if (this.filtered_country) {
                lq['countryIds'] = [this.filtered_country];
            }
            Object.assign(this.query, lq);

            this.query['sortKeys'] = this.sortKey;
            this.$store
                .dispatch("petitioner/getpetitioners", this.query)
                .then(response => {
                    this.petitioners = response.list;
                    this.totalpages = Math.ceil(response.totalCount / this.perpage);

                });
        },

        get_statusids() {
            Object.assign(this.query, {
                category: "company_statuses"
            });

            this.$store
                .dispatch("get_statusids", this.query)
                .then(response => {
                    this.all_statusids = response;
                });
        },

        //get all_states
        get_all_states() {
            this.$store
                .dispatch("getstates", this.filtered_country)
                .then(response => {
                    this.all_states = response;
                });
        },
        getAllLocations() {
            Object.assign(this.query, {
                countryId: this.filtered_country,
                stateId: this.singel_final_selected_state //this.final_selected_states//3922
            });

            this.$store
                .dispatch("getlocations", this.query)
                .then(response => {
                    this.all_locations = response;
                });
        },
        selectCreatedDateRange(option) {
            option.startDate = moment(option.startDate).format("YYYY-MM-DD");
            option.endDate = moment(option.endDate).format("YYYY-MM-DD");
            this.selected_createdDateRange = [option.startDate, option.endDate];
        },

        changedState() {
            this.singel_final_selected_state = '';
            this.final_selected_locations = [];
            this.singel_final_selected_state = this.seleted_states["id"];
            this.final_selected_states.push(this.seleted_states["id"]);
            this.getAllLocations();
        },
        multiple_changedState: function () {
            if (this.seleted_states.length > 0) {
                this.final_selected_states = [];
                for (let ind = 0; ind < this.seleted_states.length; ind++) {
                    let current_index = this.seleted_states[ind];
                    this.final_selected_states.push(current_index["id"]);
                }
                this.getAllLocations();
            } else {
                this.final_selected_states = [];
                this.final_selected_locations = [];
            }

        },
        set_filter: function () {
            this.final_selected_statusids = [];

            if (this.selected_statusids.length > 0) {
                this.final_selected_statusids = [];
                for (let ind = 0; ind < this.selected_statusids.length; ind++) {
                    let current_index = this.selected_statusids[ind];
                    this.final_selected_statusids.push(current_index["id"]);
                }
            }

            //states
            this.final_selected_states = [];
            if (this.seleted_states.length > 0) {
                this.final_selected_states = [];
                for (let ind = 0; ind < this.seleted_states.length; ind++) {
                    let current_index = this.seleted_states[ind];
                    this.final_selected_states.push(current_index["id"]);
                }
            }

            this.final_selected_locations = [];
            if (this.seleted_locations.length > 0) {

                for (let ind = 0; ind < this.seleted_locations.length; ind++) {
                    let current_index = this.seleted_locations[ind];
                    this.final_selected_locations.push(current_index["id"]);
                }
            }
            this.$refs["filter_menu"].dropdownVisible = false;

            this.getPetitioners();

        },
        clear_filter: function () {
            this.searchtxt = '';
            this.selected_statusids = [];
            this.final_selected_statusids = [];
            this.selected_country_obj = '';

            this.seleted_states = [];
            this.final_selected_states = [];
            this.singel_final_selected_state = '';

            this.seleted_locations = [];
            this.final_selected_locations = []

            this.date = '';
            this.date_range = [];
            this.selected_createdDateRange['startDate'] = '';
            this.selected_createdDateRange['endDate'] = '';
            this.getPetitioners();
            this.$refs["filter_menu"].dropdownVisible = false;
            this.filtered_country = '';

            this.selected_createdDateRange = [];
            this.getPetitioners();
        },
        pageNate(pageNum) {
            this.page = pageNum;
            this.getPetitioners();
        },
        changedCountry() {
            this.filtered_country = this.selected_country_obj['id'];
            this.get_all_states();
        },
        sortMe(sort_key = '') {

            //   this.sortKeys = {
            //   'caseNo':1,
            //   'beneficiaryDetails.name':1,
            //   "typeDetails.name":1,
            //   "petitionerDetails.name":1,
            //   "updatedOn":1,
            //   "communicationDetailslength":1

            // }

            if (sort_key != '') {
                this.sortKeys[sort_key] = this.sortKeys[sort_key] == 1 ? -1 : 1
                this.sortKey = {};
                this.sortKey[sort_key] = this.sortKeys[sort_key]
                localStorage.setItem('clients_sort_key', sort_key);
                localStorage.setItem('clients_sort_value', this.sortKey[sort_key]);

                this.getPetitioners();
            }

        },
        changeperPage() {

            localStorage.setItem('petitioners_perpage', this.perpage);
            this.page = 1;
            this.getPetitioners();

        }

    },
    mounted() {
         this.userData = this.$store.state.user;
         //alert(JSON.stringify(this.userData.roleId))
        this.$store.dispatch("getcountries").then(response => {
            this.all_countries = response;
        });

        this.sortKeys['name'] = 1;
        this.sortKeys['authorizedSignatory.name'] = 1;
        this.sortKeys['createdOn'] = 1;
        this.sortKeys['statusDetails.id'] = 1;

        this.sortKey['createdOn'] = 1;
        if (localStorage.getItem('clients_sort_key') && localStorage.getItem('clients_sort_value') && localStorage.getItem('clients_sort_value') >= -1) {
            this.sortKey = {};

            this.sortKey[localStorage.getItem('clients_sort_key')] = parseInt(localStorage.getItem('clients_sort_value'));
            this.sortKeys[localStorage.getItem('clients_sort_key')] = this.sortKey[localStorage.getItem('clients_sort_key')];

            //alert();

        }

        if (localStorage.getItem('petitioners_perpage')) {

            this.perpage = parseInt(localStorage.getItem('petitioners_perpage'));
        }

        this.selected_statusids = [];
        this.final_selected_statusids = [];
        this.seleted_states = [];
        this.final_selected_states = [];

        this.seleted_locations = [];
        this.final_selected_locations = [];

        this.get_statusids();

        //this.getAllLocations();
        this.getPetitioners();

    }
};
</script>
