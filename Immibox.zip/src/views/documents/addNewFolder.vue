<template>
  <form>
    <div class="form-container" @click="formErrors=''">
      <div class="vx-row">
        <div class="vx-col w-full">
          <div class="form_group">
            <label class="form_label">Folder Name<em>*</em></label>
            <vs-input
              v-model="newFolder.name"
              name="foldername"
              v-validate="'required'"
              class="w-full"
              data-vv-as="Folder Name"
            />
            <span
              class="text-danger text-sm"
              v-show="errors.has('foldername')"
              >{{ errors.first("foldername") }}</span
            >
          </div>
        </div>
        <!--
        <div class="vx-col w-1/2">
          <div class="form_group">
            <label class="form_label">Display Name<em>*</em></label>
            <vs-input
              v-model="newFolder.displayName"
              name="displayName"
              v-validate="'required'"
              class="w-full"
              data-vv-as="Display Name"
            />
            <span
              class="text-danger text-sm"
              v-show="errors.has('displayName')"
              >{{ errors.first("displayName") }}</span
            >
          </div>
        </div>
        
        <div class="vx-col w-1/2">
          <div class="form_group">
            <label class="form_label"><em></em></label>
            
             <vs-checkbox   v-model="newFolder.myDrive" class="">Add to My Drive</vs-checkbox>
          </div>
        </div>
        -->
        
      </div>

      <div v-show="formErrors">
        <vs-alert
          color="warning"
          class="warning-alert reg-warning-alert no-border-radius"
          icon-pack="IntakePortal"
          icon="IP-information-button"
          active="true"
          >{{ formErrors }}</vs-alert
        >
      </div>
    </div>
    <div class="popup-footer">
      <vs-button color="dark" @click="closePopup()" class="cancel" type="filled"
        >Cancel</vs-button
      >
      <vs-button
        color="success"
        :disabled="creating"
        @click="saveFolder()"
        class="save"
        type="filled"
        >Submit</vs-button
      >
    </div>
    
  </form>
</template>

<script>
import { defineComponent } from "@vue/composition-api";
import moment from "moment";
import _ from "lodash";
export default defineComponent({
    props:{
        selectedItem:'',
        myDrive:false,
        baseFolderName:'',
    },
  mounted() {
      this.newFolder['myDrive'] = this.myDrive;
  },
  methods: {
    closePopup() {
      this.$emit("closePopup");
    },
    saveFolder() {
       let self =this;
        this.$validator.validateAll().then(result => {
          
        if (result) {
          let postData = _.cloneDeep(this.newFolder);
          postData['displayName'] = postData['name'];
          if(_.has(this.selectedItem ,"_id")){
              postData['parentId'] =this.selectedItem['_id'];
          }
           

           if(!postData['myDrive']){

               postData['companyId'] = "";

           }else{
                //  postData['tenantId'] =self.checkProperty(self.getUserData ,"tenantDetails" , "_id")
                ///  if([3].indexOf(self.getUserRoleId) <=-1){
               //     postData['branchId'] =self.checkProperty(self.getUserData ,"branchId");
               //   }
                  
                  postData['companyId'] =self.checkProperty(self.getUserData ,"companyId");
           }
          
           if(this.baseFolderName =='Common'){
            postData['commonFolder'] =true;
           }
          this.creating =true;
          this.$store
            .dispatch("commonAction", {
              data: postData,
              path: "documents/folder-create",
            })
            .then((response) => {
              this.showToster({ message: response.message, isError: false });
              this.closePopup();
              this.creating =false;
            })
            .catch((err) => {
                  this.creating =false;
                  this.formErrors = err
             // this.showToster({ message: err, isError: false });
            });
        }
      });
    },
  },
  data() {
    return {
      creating:false,  
      formErrors: "",
      newFolder: {
        name: "",
        displayName: "",
        parentId: "", // Required when create inside a folder
        companyId: "", // Optional // Not required on send "myDrive" as true
        myDrive: false, // Required for saving in "My Drive"
      },
    };
  },
});
</script>
>

