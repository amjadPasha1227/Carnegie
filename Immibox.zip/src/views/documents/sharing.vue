<template>
  <form> 
  
    <div class="form-container pb-8" @click="formErrors=''">
  
      <div class="vx-row">
        <div class="vx-col w-full" v-if="checkProperty(existedUsers , 'length')>0">
            <div class="form_group">         
              <label class="form_label">Shared with</label>
              <div class="taggedlist sharedlist">
            <ul class="pl-0 pr-0">
            <template  v-for="(user ,index) in existedUsers" >
              <li :key="index">
                 <figure><img :src="
                      checkProperty(user, 'SharedToProfilePicture')
                    "
                    @error="setDefaultPhoto($event)" /></figure>
                  <figcaption>
                    {{user['tempName']}} <span>{{user['roleName']}}</span>
                  </figcaption> 
              </li>
              </template>
              
            </ul>
          </div>
            </div>
        </div>
        <div class="vx-col w-full">
          <div class="form_group multiselection">
         
            <label class="form_label">Share To<em>*</em></label>
            <div class="con-select w-full">
              <multiselect 
                      v-model="newFolder.accessTo"
                      :options="taggedUsersList"
                      :multiple="true"
                      :hideSelected="true"
                      :close-on-select="false"
                      :clear-on-select="false"
                      :preserve-search="true"
                      placeholder="Select users"
                      label="name"
                      track-by="name"
                      :preselect-first="false"
                      name="accessTo"
                       :searchable="true"
                      @search-change="getUsersList"
                       v-validate="'required'"
                       data-vv-as="User"
                    >
                      <template
                        slot="selection"
                        slot-scope="{ values, isOpen }"
                      >
                        <span
                          class="multiselect__selectcustom"
                          v-if="values.length && !isOpen"
                          >{{ values.length }} Users Selected</span
                        >
                        <span
                          class="multiselect__selectcustom"
                          v-if="values.length && isOpen"
                        ></span>
                      </template>
              </multiselect>
            <span class="text-danger text-sm"  v-show="errors.has('accessTo')"  >{{ errors.first("accessTo") }}</span>
            </div>
          </div>
        </div>
        
        
      </div>

      <div v-show="formErrors">
        <vs-alert
          color="warning"
          class="warning-alert reg-warning-alert no-border-radius"
          icon-pack="IntakePortal"
          icon="IP-information-button"
          active="true"
          >{{ formErrors }}</vs-alert
        >
      </div>
    </div>

   
    <div class="popup-footer">
      <vs-button color="dark" @click="closePopup()" class="cancel" type="filled"
        >Cancel </vs-button
      >
      <vs-button
        color="success"
        :disabled="creating"
        @click="shareFolder()"
        class="save"
        type="filled"
        >Share</vs-button
      >
    </div>
   
  </form>
</template>

<script>
import { defineComponent } from "@vue/composition-api";
import moment from "moment";
import _ from "lodash";
export default defineComponent({
    props:{
        selectedItem:'',
        myDrive:false,
        baseFolderName:''
    },
  mounted() {
      if(this.checkProperty(  this.selectedItem,"myDrive")){
          this.newFolder['myDrive'] = this.selectedItem['myDrive'];
          
                
      }
       if(this.checkProperty(  this.selectedItem,"_id")){
            this.newFolder['folderId'] = this.selectedItem['_id'];
            this.getFolderDetails();
       }

  },
  methods: {
    getFolderDetails(){
      this.existedUsers =[];
      ///documents/folder-details
      let self =this;
      this.folderDetails = null;
      let postData ={
        "folderId":''
      }
     postData['folderId'] = this.selectedItem['_id'];

      let path ="documents/folder-details";
     
     if(this.checkProperty(  this.selectedItem,"type") =="document"){
         path ="documents/details";
         postData['documentId'] = this.selectedItem['_id'];
     }
      this.$store
            .dispatch("commonAction", {
              data: postData,
              path:path,
            })
            .then((response) => {
              this.folderDetails = response;
              if(_.has( this.folderDetails , 'accessDetails')){
                _.forEach(this.folderDetails['accessDetails'] , (item)=>{

                  let tempObj ={"_id":"" ,"name":'' ,"roleName":'' ,'tempName':'' , "sharedToProfilePicture":''};
                  tempObj['sharedToProfilePicture'] =self.checkProperty(item ,"sharedToProfilePicture")
                  if(self.checkProperty(item ,"sharedTo") && self.checkProperty(item ,"sharedToName")){
                      tempObj['_id'] =self.checkProperty(item ,"sharedTo") ;
                      tempObj['roleName'] =self.checkProperty(item ,"sharedToRoleName") ;
                      tempObj['tempName'] = item['sharedToName'];

                      if( tempObj['roleName']){
                          tempObj['name'] = tempObj['name'] +"("+self.checkProperty(item ,"sharedToName")+")" ;

                      }
                    self.existedUsers.push(tempObj);

                  }
                 
                  

                })

              }

                    this.getUsersList()
              
            })
            .catch((err) => {
                    this.getUsersList()
                  
            });
    },
    closePopup() {
      this.$emit("closePopup");
    },
    shareFolder() {
       let self =this;
        this.$validator.validateAll().then(result => {
          
        if (result) {
          let postData = _.cloneDeep(this.newFolder);
          
          


          postData['accessTo'] = this.newFolder['accessTo'].map((item) => {
            return item["_id"];
          });
          this.creating =true;
          let path ="documents/folder-share";
          if(this.checkProperty(this.selectedItem ,"type") =="document"){
            path ="documents/share";
            postData = Object.assign(postData ,{ "documentId":self.selectedItem['_id']})

          }else{
              postData = Object.assign(postData ,{ "folderId":self.selectedItem['_id']})
            
          }
          ///documents/share
          this.$store
            .dispatch("commonAction", {
              data: postData,
              path: path,
            })
            .then((response) => {
              this.showToster({ message: response.message, isError: false });
              this.closePopup();
              this.creating =false;
            })
            .catch((err) => {
                  this.creating =false;
                  this.formErrors = err
             // this.showToster({ message: err, isError: false });
            });
        }
      });
    },
     getUsersList(searchtxt='') {
          this.taggedUsersList = [];
          let self =this;
        let matcher = {
         
          title: searchtxt,
         
        };

       
        let query = {};
        query['page'] = 1;
        query['perpage'] = 5000;
        query['getMasterData'] = true;
        query['filters'] = matcher;
        query['sorting'] = { "path":"createdOn" , "order":-1};
        this.$store
          .dispatch("getList",{data:query ,path:'documents/get-share-users-list'} )
          .then(response => {
           //  alert(JSON.stringify(response));
            let taggedUsersList = response;
            _.forEach( taggedUsersList , (item)=>{
                if(_.has(item,'roleName')){
                    item['name'] = item['name']+" ("+item['roleName']+")";

                }
                let isExists =_.find(self.existedUsers,{"_id":item['_id']} )
                  if(!isExists){
                        self.taggedUsersList.push(item)

                  }

            })
           
           // this.totalpages = Math.ceil(response.totalCount / this.perpage);
            
            //alert(this.perpage);
          }).catch((err)=>{
            this.taggedUsersList = [];
            
          })
      },
  },
  data() {
    return {
      existedUsers:[],
      folderDetails:null,
      taggedUsersList:[],
      creating:false,  
      formErrors: "",
      newFolder: {
        accessTo: [],
        folderId: "", // Required when create inside a folder
        myDrive: false, // Required for saving in "My Drive"
      },
    };
  },
});
</script>
>

