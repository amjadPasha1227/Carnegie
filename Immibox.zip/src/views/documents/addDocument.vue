<template>
  <div>
    <div class="Change_petition"  @click="formErrors=''">
      <div class="vx-col w-full">
        <div>
          <div class="vx-row" @click="documents = []">
            <div class="vx-col w-full">
              <vx-input-group class="form-input-group select-upload-group">
                <div class="uploadsec_wrap">
                  <div class="w-full">
                    <file-upload
                      v-model="documents"
                      class="file-upload-input mb-0"
                      style="height: 50px"
                      :name="'version_documents'"
                      :multiple="true"
                      v-validate="'required'"
                      label="Scanned Documents"
                      data-vv-as="Scanned Documents"
                      :accept="allDocEntity"
                      @input="doUpload(documents)"
                    >
                      <img
                        class="file-icon"
                        src="@/assets/images/main/file-upload.svg"
                      />

                      Upload 
                    </file-upload>

                    <span class="file-type mb-0"
                      >(File Type: PDF, DOC, JPEG, PNG. Max file size:
                      1MB)</span
                    >

                    <div
                      class="uploded-files_wrap mt-3"
                      v-if="checkProperty(documentUploaded, 'length') > 0"
                    >
                      <div
                        class="w-full"
                        v-for="(fil, fileindex) in documentUploaded"
                        :key="fileindex"
                      >
                        <div class="uploded-files">
                          <div class="w-50">
                            <label class="form_label"></label>
                            <vx-input-group class="form-input-group">
                              <vs-input
                                v-on:keyup="fileNameChenged(fileindex)"
                                required
                                class="w-full"
                                :name="'fName'"
                                v-model="documentUploaded[fileindex]['name']"
                                data-vv-as="File Name"
                              />
                              <span
                                class="text-danger text-sm"
                                v-show="!documentUploaded[fileindex]['name']"
                                >Please Enter file name</span
                              >
                              <span
                                class="text-danger text-sm"
                                v-show="errors.has('fName' + fileindex)"
                                >{{ errors.first("fName" + fileindex) }}</span
                              >
                            </vx-input-group>
                            <vs-checkbox
                              @change="confidentialChanged(fil)"
                              v-model="fil.confidential"
                              class="pt-5"
                              >Confidential</vs-checkbox
                            >
                          </div>
                          <div class="slection_wrap">
                            <div class="vx-col w-full" >
                              <div class="form_group" v-if="!fil.confidential">
                                <label class="form_label"
                                  >Share To<em></em></label
                                >
                                <multiselect
                                  v-model="fil.accessTo"
                                  :options="taggedUsersList"
                                  :multiple="true"
                                  :hideSelected="true"
                                  :close-on-select="false"
                                  :clear-on-select="false"
                                  :preserve-search="true"
                                  placeholder="Select users"
                                  label="name"
                                  track-by="name"
                                  :preselect-first="false"
                                  name="accessTo"
                                  :searchable="true"
                                  @search-change="getUsersList"
                                >
                                  <template
                                    slot="selection"
                                    slot-scope="{ values, isOpen }"
                                  >
                                    <span
                                      class="multiselect__selectcustom"
                                      v-if="values.length && !isOpen"
                                      >{{ values.length }} Users Selected</span
                                    >
                                    <span
                                      class="multiselect__selectcustom"
                                      v-if="values.length && isOpen"
                                    ></span>
                                  </template>
                                </multiselect>
                                <span
                                  class="text-danger text-sm"
                                  v-show="errors.has('accessTo')"
                                  >{{ errors.first("accessTo") }}</span
                                >
                              </div>
                            </div>
                            <div
                              class="delete" 
                              @click="remove(fileindex)"
                            >
                              <img src="@/assets/images/main/delete-row-img.svg" />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </vx-input-group>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div
      class="text-danger text-sm formerrors"
      v-show="formErrors"
      @click="formErrors = ''"
    >
      <vs-alert
        color="warning"
        class="warning-alert reg-warning-alert no-border-radius"
        icon-pack="IntakePortal"
        icon="IP-information-button"
        active="true"
        >{{ formErrors }}</vs-alert
      >
    </div>
    <div class="popup-footer relative">
      <button
        @click="
          fileuploadPopup = false;
          formErrors = '';
          $emit('closePopup')
        "
        class="btn cancel"
      >
        Cancel
      </button>
      <button
        class="btn save"
        v-bind:disble="
          disable_uploadBtn 
        "
        @click="saveDocuments()"
      >
        <figure v-if="fuploder" class="loader loader2">
          <img src="@/assets/images/main/loader.gif" />
        </figure>
        Upload
      </button>
    </div>
  </div>
</template>

<script>
import { defineComponent } from "@vue/composition-api";
import moment from "moment";
import FileUpload from "vue-upload-component/src";
import _ from "lodash";
export default defineComponent({
  props: {
    selectedItem: "",
    myDrive: false,
    baseFolderName:''
  },
  mounted() {
    this.fuploder = false;

    if (this.myDrive) {
      this.newFolder.myDrive = this.myDrive;
    }

    this.getUsersList();
  },
  methods: {
    confidentialChanged(item) {
      if (item.confidential) {
        item.accessTo = [];
      }
    },
    getUsersList(text = "") {},
    doUpload(documents) {
      let self = this;

      documents = documents.map(
        (item) =>{
          item = {
            name: item.name,
            file: item.file,
            path: "",
            extn: "",
            mimetype: "",
            size:item.size?item.size:0,

            mimetype: item.type,
          }
          if(self.baseFolderName =='Common'){
            item['commonFolder'] =true;
          }
          return item;

        }
      );
      let documentsCount = self.checkProperty(documents, "length");
      self.disable_uploadBtn = false;
      self.fuploder = false;
      if (documents.length > 0) {
        self.fuploder = true;
        self.disable_uploadBtn = true;
        let findx = 0;
        documents.forEach((doc) => {
          let formData = new FormData();
          formData.append("files", doc.file);
          formData.append("secureType", "private");
          formData.append("getDetails", true);

          self.$store.dispatch("uploadS3File", formData).then((response) => {
            response.data.result.forEach((urlGenerated) => {
              doc.path = urlGenerated["path"];
              if(_.has(urlGenerated ,'size' )){
                doc['size'] = urlGenerated['size'];
              }
              doc.mimetype = urlGenerated["mimetype"];
              doc.extn = urlGenerated["extn"];
              self.reversionFile = doc;
              self.disable_uploadBtn = false;
              delete doc["file"];
              doc["accessTo"] = [];
              doc["confidential"] = false;
              doc["myDrive"] = false;
              doc["tenantId"] = "";
              doc["branchId"] = "";
              doc["companyId"] = "";
              doc["parentId"] = "";

              // "tenantId":"5f296e3a04ca862fd8915bf9",// Requied while sending "myDrive" as false
              // "branchId":"5f296e3a04ca862fd8915bf9",// Requied while sending "myDrive" as false
              //	"companyId":"5f296e3a04ca862fd8915bf9",// Requied while sending "myDrive" as false

              if (_.has(self.selectedItem, "_id")) {
                doc["parentId"] = self.selectedItem["_id"];
              }
              if (self.myDrive) {
                doc["myDrive"] = self.myDrive;
              } else {
                if ([1, 2].indexOf(self.getUserRoleId) <= -1) {
                  doc["tenantId"] = self.checkProperty(
                    self.getUserData,
                    "tenantDetails",
                    "_id"
                  );
                  doc["branchId"] = self.checkProperty(
                    self.getUserData,
                    "branchId"
                  );
                  doc["companyId"] = self.checkProperty(
                    self.getUserData,
                    "companyId"
                  );
                }
              }
              self.documentUploaded.push(doc);
            });
            findx++;
          if (findx >= documentsCount) {
            
           self.fuploder = false;
          }
          });
          
        });
      }
    },
    fileNameChenged(fileindex) {
      let fname = this.documentUploaded[fileindex]["name"];
      fname = fname.trim();
      this.disable_uploadBtn = false;
      if (!fname) {
        this.disable_uploadBtn = true;
      }
    },
    remove(index = -1) {
      if (index > -1) {
        this.documentUploaded.splice(index, 1);
      }
    },
    closePopup() {
      this.$emit("closePopup");
    },
    saveDocuments() {
      //"tenantId":"5f296e3a04ca862fd8915bf9",// Requied while sending "myDrive" as false
      //	"branchId":"5f296e3a04ca862fd8915bf9",// Requied while sending "myDrive" as false
      //		"companyId":"5f296e3a04ca862fd8915bf9",// Requied while sending "myDrive" as false
      this.formErrors ='';
      if(this.documentUploaded.length<=0){
        
         this.formErrors = "Upload atleast one document.";
         return false
      }

      let postData = { documents: [] };

      postData["documents"] = _.cloneDeep(this.documentUploaded);
      if(this.baseFolderName =='Common'){
        postData['commonFolder'] =true;
      }

      this.creating = true;
      this.$store
        .dispatch("commonAction", {
          data: postData,
          path: "documents/save",
        })
        .then((response) => {
          this.showToster({ message: response.message, isError: false });
          this.closePopup();
          this.creating = false;
        })
        .catch((err) => {
          this.creating = false;
          this.formErrors = err;
          // this.showToster({ message: err, isError: false });
        });
    },
    getUsersList(searchtxt = "") {
      let matcher = {
        title: searchtxt,
      };

      let query = {};
      query["page"] = 1;
      query["perpage"] = 5000;
      query["getMasterData"] = true;
      query["filters"] = matcher;
      query["sorting"] = { path: "createdOn", order: -1 };
      this.$store
        .dispatch("getList", {
          data: query,
          path: "documents/get-share-users-list",
        })
        .then((response) => {
          //  alert(JSON.stringify(response));
          this.taggedUsersList = response;
          _.forEach(this.taggedUsersList, (item) => {
            if (_.has(item, "roleName")) {
              item["name"] = item["name"] + " (" + item["roleName"] + ")";
            }
          });

          // this.totalpages = Math.ceil(response.totalCount / this.perpage);

          //alert(this.perpage);
        })
        .catch((err) => {
          this.taggedUsersList = [];
        });
    },
  },
  data() {
    return {
      taggedUsersList: [],
      rfuploder: false,
      fileuploadPopup: false,
      fuploder: false,
      disable_uploadBtn: false,
      documentUploaded: [],
      documents: [],
      creating: false,
      formErrors: "",
      newFolder: {
        name: "",
        displayName: "",
        parentId: "", // Required when create inside a folder
        companyId: "", // Optional // Not required on send "myDrive" as true
        myDrive: false, // Required for saving in "My Drive"
      },
    };
  },
  components: {
    FileUpload,
  },
});
</script>
>

