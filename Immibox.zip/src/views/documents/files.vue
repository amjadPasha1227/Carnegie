<template>
    <div class="files_wrapper">
      <!-- <div class="files_heading">
        <div class="btn_group">
          <button class="btn-list" title="List"><img src="@/assets/images/icons/files/list.png"/></button>
          <button class="btn-grid" title="Grid"><img src="@/assets/images/icons/files/grid.png"/></button>
        </div>
      </div> -->
      <div class="files_list">
        <ul>
          <li>
            <div class="file_icon">
              <img src="@/assets/images/icons/folder.svg"/>
            </div>
            <div class="file_name">
              New Documents
            </div>
          </li>
          <li>
            <div class="file_icon">
              <img src="@/assets/images/icons/folder.svg"/>
            </div>
            <div class="file_name">
              API
            </div>
          </li>
          <li>
            <div class="file_icon">
              <img src="@/assets/images/icons/folder.svg"/>
            </div>
            <div class="file_name">
              Invoices
            </div>
          </li>
        </ul>
      </div>
      <div class="files_list list_view">
        <ul>
          <li>
            <div class="file_icon">
              <img src="@/assets/images/main/pdf.svg"/>
            </div>
            <div class="file_name">
              Form I-94.pdf
            </div>
          </li>
          <li>
            <div class="file_icon">
              <img src="@/assets/images/main/doc.svg"/>
            </div>
            <div class="file_name">
              9e0dbed0c4ad11ec9dfb01ae0f7d3252.docx
            </div>
          </li>
        </ul>
      </div>
    </div>
  </template>
  
  <script>
  import * as _ from "lodash";
  import Vue from "vue";
  export default {
    
  };
  </script>
  