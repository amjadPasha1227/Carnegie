<template>
    <div class="upload_sec">
      
    </div>
    </template>
    
     
  <script>
  import FileUpload from "vue-upload-component/src";
  import { InfoIcon } from 'vue-feather-icons'
  import mime from 'mimetype';
  import * as _ from "lodash";
  import axios from 'axios'
  var Dropbox = require('dropbox').Dropbox;
  export default {
       
        
        data() {
          return {
                        
            configDetails:null,
            //drop Box veriables
          
           dropBoxAccessToken: '',
           dropBoxAuthUrl:'',
           dropBoxAuthorizationCode:'',
           dropBoxClientId:'ftl7hhws3nvp2xp',
           clientSecret:'kwfakdnzt3913mb',
           dropBoxRedirectUrl:'https://localhost:8080/dropbox-config',
           configType:'',
           oneDriveRedirectUri:'https://localhost:8080/ms',
  
  
          
            
          };
        },
        components: { 
          FileUpload,
            InfoIcon
        },
        methods: {
            pageRediredt(isError=false){
                let path ="/"
                let params ={};
                let query ={};
                
            let dropBoxRedirectUrlData = localStorage.getItem('dropBoxRedirectUrlData');
            dropBoxRedirectUrlData = JSON.parse(dropBoxRedirectUrlData)
            if(_.has(dropBoxRedirectUrlData ,'path')){
                path = dropBoxRedirectUrlData['path'];
            }

               
                this.$router.push({"path":path ,"params":params,"query":query})
            },
            getglobalConfigData(){
                this.$vs.loading();
           
          let postData ={}
          let path = '/global-config/get-ext-file-upload-config'
          this.$store.dispatch("commonAction", {data:postData,path:path})
          .then((response) =>{ 
            this.configDetails = response
            if(this.checkProperty(response ,'dropbox' ) && this.configType =="dropbox"){
                this.dropBoxClientId = this.checkProperty(response ,'dropbox' ,'clientId'  );
                this.clientSecret = this.checkProperty(response ,'dropbox' ,'clientSecret'  );
              
                this.generateDropBoxAccessKey();
               
            } else if(this.checkProperty(response ,'oneDrive' ) && this.configType =="oneDrive"){
                this.dropBoxClientId = this.checkProperty(response ,'oneDrive' ,'clientId'  );
                this.clientSecret = this.checkProperty(response ,'oneDrive' ,'clientSecret'  );
              
                this.generateOneDriveAccessToken();
               
            }    
          }).catch((eer)=>{
            this.$vs.loading.close();
            this.pageRediredt(true);
           
          })
           },

          
  generateOneDriveAccessToken(){

   
    let postData ={
      //"client_id":'',
    //  "client_secret":"",
      "code":"",
      "redirectUri":'',
      "configType":'oneDrive'

    }
    //postData['client_id'] =this.dropBoxClientId
    postData['configType'] ="oneDrive";
    postData['code'] =this.dropBoxAuthorizationCode;
    postData['redirectUri'] = this.oneDriveRedirectUri;
   ///oauth/get-access-token,
   let url ="/oauth/get-access-token";
       
      this.$store.dispatch("commonAction" ,{data:postData,path:url})
        .then(response => {
         
                  //redirect to dropBoxRedirectUrl
                this.showToster({message:response.message,isError:false });
                                  
                this.$vs.loading.close();
                this.pageRediredt();

            
        }).catch((err)=>{
            this.$vs.loading.close();
            this.showToster({message:err,isError:treu });
            this.pageRediredt(true);
          
        })


  },
        generateDropBoxAccessKey(){
          // Dropbox SDK setup
         
        var code = this.dropBoxAuthorizationCode //'AUTHORIZATION_CODE';
        var clientId = this.dropBoxClientId;
        var clientSecret = this.clientSecret;
        var redirectUri = this.dropBoxRedirectUrl;
       // this.dbx = new Dropbox({ clientId: clientId  ,clientSecret:clientSecret});
              
  
        var xhr = new XMLHttpRequest();
  xhr.open('POST', 'https://api.dropboxapi.com/oauth2/token', true);
  xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
  
  xhr.onreadystatechange =  ()=> {
    if (xhr.readyState === 4 && xhr.status === 200) {
      var response = JSON.parse(xhr.responseText);
      var accessToken = response.access_token;
      //this.$store.commit('updateDropBoxConfig' ,response);

  
     // this.dropBoxAccessToken =accessToken;
     // var refreshToken = response.refresh_token;
        let url ="/users/save-ext-file-upload-config";
        let postData = {
            "configType":'dropbox',
            'config':response
        };
      this.$store.dispatch("commonAction" ,{data:postData,path:url})
        .then(response => {
         
                  //redirect to dropBoxRedirectUrl
                this.showToster({message:response.message,isError:false });
                                  
                this.$vs.loading.close();
                this.pageRediredt();

            
        }).catch((err)=>{
            this.$vs.loading.close();
            this.showToster({message:err,isError:false });
            this.pageRediredt(true);
          
        })

   
    }else{
        this.pageRediredt(true);

    }
  };
  
  var requestBody = 'code=' + encodeURIComponent(code) +
                    '&grant_type=authorization_code' +
                    '&client_id=' + encodeURIComponent(clientId) +
                    '&client_secret=' + encodeURIComponent(clientSecret) +
                    '&redirect_uri=' + encodeURIComponent(redirectUri);
  
  xhr.send(requestBody);
          
          
        },
       
      
          
     
        },
       // inject: ["parentValidator"],
        props: {
        },
        created() {
          //  this.$validator = this.parentValidator;
        },
        mounted() {
            
        
        this.dropBoxRedirectUrl = this.$globalgonfig.dropBoxRedirectUrl;
        this.oneDriveRedirectUri =this.$globalgonfig.oneDriveRedirectUri;
           console.log(this.$route); 
          //alert(this.$route['name']);
         
          if( this.checkProperty(this.$route, 'name') && this.checkProperty(this.$route, 'query','code' )){
            this.configType =this.$route['name'];
            this.dropBoxAuthorizationCode= this.$route.query.code;
            this.getglobalConfigData();
          }else{
            this.pageRediredt(true);
          }
         
     
        },
        computed: {
         
        },
       
  }
  </script>
    
    