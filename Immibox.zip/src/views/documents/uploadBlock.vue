<template>
  <div class="w-full" v-if="lodedFromPopup|| (fieldName !=null && canRenderField(tplkey,fieldsArray, display,tplsection,fieldName))">
    <div class="upload_blocks" v-if="!lodedFromPopup">
     
      <div @click="togleModal(true)" class="upload_block"> 
        <label class="form_label" ><span v-html="getLabel" style="display:inline"></span>      <div class="IB_tooltip" v-if="tooltip!=null">
                    <span>
                      <info-icon size="1.5x" class="custom-class"></info-icon>
                    </span>
                    <div class="tooltip_cnt">
                      <p>
                        {{tooltip}}
                      </p>
                    </div>
                  </div></label>
        <div class="upload_cnt">
          <img class="file-icon" src="@/assets/images/main/file-upload.svg" />Upload
        </div>
      </div>
      <ul class="uploaded-list">
        <template v-for="(item, index) in getlist">
          <template v-if="checkProperty(item,'uploadedByRoleId') &&  getUserRoleId == 51 && !showToBeneficiary  ">
              <template v-if="checkProperty(item,'uploadedByRoleId') == 51">
                  <vs-chip v-if="item.status" @click="item.status=false;remove(index)"  :key="index" closable>
                      <img src="@/assets/images/main/down-arrow2.svg" @click="downloads3file(item)" />
                      {{ item.name }}
                  </vs-chip>
              </template>
          </template>
          <template v-else>
              <vs-chip v-if="item.status" @click="item.status=false;remove(index)"  :key="index" closable>
                  <img src="@/assets/images/main/down-arrow2.svg" @click="downloads3file(item)" />
                  {{ item.name }}
              </vs-chip>
          </template>
        </template>
      </ul>
    </div>
         <template v-if="popUpName && !lodedFromPopup">
          <modal
            :name="popUpName"
            classes="v-modal-sec upload_drive_mdl"
            :min-width="200"
            :min-height="200"
            :scrollable="true"
            :reset="true"
            width="600px"
            height="auto"
           
            >
            <div class="v-modal">
                <div class="popup-header fromDetailsPage">
                <h2 class="popup-title">
                  <template v-if="getLabel"> <p v-html="getLabel" ></p>
                  </template>
                  <template v-else>
                  Upload Documents
                  </template>
                </h2>

                <span @click="togleModal(false)">
                    <em class="material-icons">close</em>
                </span>
                </div>
                <div class="upload_sec">
            
                <div class="category_list">
                  <ul>
                    <li  :class="{'active':activeTab=='localDrive'}"  @click="changeTab('localDrive')"><span></span>Local Drive</li>
                    <li :class="{'active':activeTab=='gDrive'}"  @click="changeTab('gDrive')"><span></span>Google Drive</li>
                    <li :class="{'active':activeTab=='dropBox'}" @click="changeTab('dropBox')"><span></span>Dropbox</li>
                    <li :class="{'active':activeTab=='oneDrive'}" @click="changeTab('oneDrive')"><span></span>One Drive</li>
                  </ul>
                </div>
                
                <div class="category_cnt">
                  <VuePerfectScrollbar ref="mainSidebarPs" class="scroll-area--nofications-dropdown p-0" :settings="settings">
                  <div v-if="activeTab=='localDrive'" id="local_drive">
                    <div class="files_sec">
                      <div class="file_upload"  v-if="true || (fieldName !=null && canRenderField(tplkey,fieldsArray, display,tplsection,fieldName))">
                          <div class="form_group" @click="showFileTypeError = ''">
                            <label class="form_label" ><span v-html="getLabel" style="display:inline"></span>      <div class="IB_tooltip" v-if="tooltip!=null">
                                        <span>
                                          <info-icon size="1.5x" class="custom-class"></info-icon>
                                        </span>
                                        <div class="tooltip_cnt">
                                          <p>
                                            {{tooltip}}
                                          </p>
                                        </div>
                                      </div></label>
                            <file-upload  :ref="fieldName+cid"  v-validate="checkFieldIsRequired({'key':tplkey,'section':tplsection, 'fieldsArray':fieldsArray, 'required':required })? 'required': datatype " :hideSelected="true" v-model="fvalue" class="file-upload-input file-upload-input-cs" :name="fieldName+cid"  :data-vv-as="vvas?vvas:placeHolder" :multiple="multiple" :accept="docAcceptType" @input="upload(fvalue)">
                                <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                                
                                Upload
                                <span class="loader" v-if="filesUploading" ><img src="@/assets/images/main/loader.gif"></span>
                            </file-upload>

                          <p v-show="errors.has((formscope!=''?formscope+'.':'')+fieldName+cid)" class="text-danger text-sm-doc">{{ errors.first((formscope!=''?formscope+'.':'')+fieldName+cid) }}</p>
                          <p v-show="showFileTypeError" class="text-danger text-sm-doc">{{ showFileTypeError }}</p>
                          
                      </div>
                      </div>
                    </div>
                  </div>
                  <div v-if="activeTab=='gDrive'" class="show" id="google_drive">
                <div class="files_sec">
                  <ul class="bredcumbs" v-if="!gDriveFilesLoading && gDriveFilesAndFolders.length>0">
                    <template v-for="(bc ,indx) in gDriveBredCrumbs">
                      <li  :path="bc['path']" @click="getGoodleDriveFilesAndFolders(bc['path'])" v-if="indx==0">
                        <p>{{ bc['name'] }}  </p>
                      </li>
                      <li  :path="bc['path']" @click="getGoodleDriveFilesAndFolders(bc['path'])" v-else-if="bc['path'] !='/'">
                        <p>{{ bc['name'] }}  </p>
                      </li>
                    </template>
                  </ul>
                 
                  <div class="files_wrapper" v-if="!gDriveFilesLoading"> 
                    <div class="files_list">
                      <ul>
                        <template v-for="(entry ,index) in gDriveFilesAndFolders" >
                        <li  v-if="entry['.tag'] !='file'" :key="index" >
                          <div class="file_icon">
                            <img src="@/assets/images/icons/folder.svg"/>
                          </div>
                          <div class="file_details" @click="getGoodleDriveFilesAndFolders(entry.path_lower)">
                            <span class="folder_name">{{ entry.name }}</span>          
                          </div>
                        </li>
                      </template>
                        
                      </ul>
                    </div>
                    <div class="files_list list_view">
                      <ul>
                        <template v-for="(entry ,index) in gDriveFilesAndFolders" >
                        <li  v-if="entry['.tag']=='file'" :key="index" >
                          <div class="file_icon">
                            <docType :item="entry" />
                          </div>
                          <div class="file_details">
                            <span class="folder_name">{{ entry.name }}</span>
                          </div>
                          <vs-checkbox    :name="'dropBoxItem'+index"  v-model="entry['selectedForUpload']" ></vs-checkbox>
                        </li>
                      </template>
                        
                      </ul>
                    </div>
                  </div>
                  <template v-if="gDriveFilesLoading">
                    <NoDataFound  ref="NoDataFoundRef"  :loading="false"  heading="No Data"  type="support"  />
                  </template>
                  {{ gDriveFilesAndFolders }}
                  <div class="crete_sec" >
                    <button class="primary-btn action_btn"  @click="driveIconClicked();" ><span>Connect to Google Drive</span></button>
                  </div>
                </div>
              </div>
                  <div v-if="activeTab=='dropBox'" id="dropbox">
                    <div class="files_sec">
                      <ul class="bredcumbs">
                        <template v-for="(bc ,indx) in dropBoxBredCrumbs">
                          <li  :path="bc['path']" @click="getDropBoxFiles(bc['path'])" v-if="indx==0">
                            <p>{{ bc['name'] }}  </p>
                          </li>
                          <li  :path="bc['path']" @click="getDropBoxFiles(bc['path'])" v-else-if="bc['path'] !='/'">
                            <p>{{ bc['name'] }}  </p>
                          </li>
                        </template>
                        <!-----
                        <li class="active">
                          <p>Drop Box1 </p></li>
                        <li><p>Drop Box 2</p></li>
                        <li><span>/</span><p>Dropbox 3</p></li>
                        --->
                        </ul>
                      <div class="files_wrapper" v-if="!dropBoxFilesLoading"> 
                        <div class="files_list">
                          <ul>
                            <template v-for="(entry ,index) in dropBoxentries" >
                            <li  v-if="entry['.tag'] !='file'" :key="index" >
                              <div class="file_icon">
                                <img src="@/assets/images/icons/folder.svg"/>
                              </div>
                              <div class="file_details" @click="getDropBoxFiles(entry.path_lower)">
                                <span class="folder_name">{{ entry.name }}</span>          
                              </div>
                            </li>
                          </template>
                            
                          </ul>
                        </div>
                        <div class="files_list list_view">
                          <ul>
                            <template v-for="(entry ,index) in dropBoxentries" >
                            <li  v-if="entry['.tag']=='file'" :key="index" >
                              <div class="file_icon">
                                <docType :item="entry" />
                              </div>
                              <div class="file_details">
                                <span class="folder_name">{{ entry.name }}</span>
                              </div>
                              <vs-checkbox  @input="selectDropBoxFileForUpload(entry ,index)"  :name="'dropBoxItem'+index"  v-model="entry['selectedForUpload']" ></vs-checkbox>
                            </li>
                          </template>
                            
                          </ul>
                        </div>
                      </div>
                      <template v-if="dropBoxFilesLoading">
                        <NoDataFound  ref="NoDataFoundRef"  :loading="false"  heading="No Data"  type="support"  />
                      </template>
                      <div class="crete_sec" v-if="!dropBoxFilesLoading"  >
                        <vs-button  color=""  class="primary-btn action_btn" v-if="!dropBoxAccessToken"  :disabled="filesUploading"  type="filled" > <a :href="dropBoxAuthUrl" >Connect to Drop Box</a>  </vs-button>
                      </div>
                    </div>
                    
                      
                  </div> 

                  <!----oneDrive-->
                
                  <div v-if="activeTab=='oneDrive'" id="oneDrive">
                    <div class="files_sec">
                      <ul class="bredcumbs">
                        <template v-for="(bc ,indx) in oneDriveBredCrumbs">
                          <li  :path="bc['path']" @click="getDropBoxFiles(bc['path'])" v-if="indx==0">
                            <p>{{ bc['name'] }}  </p>
                          </li>
                          <li  :path="bc['path']" @click="getDropBoxFiles(bc['path'])" v-else-if="bc['path'] !='/'">
                            <p>{{ bc['name'] }}  </p>
                          </li>
                        </template>
                        
                        </ul>
                      <div class="files_wrapper" v-if="!oneDriveFilesLoading"> 
                        <div class="files_list">
                          <ul>
                            <template v-for="(entry ,index) in oneDriveEntries" >
                            <li  v-if="entry['.tag'] !='file'" :key="index" >
                              <div class="file_icon">
                                <img src="@/assets/images/icons/folder.svg"/>
                              </div>
                              <div class="file_details" @click="getDropBoxFiles(entry.path_lower)">
                                <span class="folder_name">{{ entry.name }}</span>            
                              </div>
                            </li>
                          </template>
                            
                          </ul>
                        </div>
                        <div class="files_list list_view">
                          <ul>
                            <template v-for="(entry ,index) in oneDriveEntries" >
                            <li  v-if="entry['.tag']=='file'" :key="index" >
                              <div class="file_icon">
                                <docType :item="entry" />
                              </div>
                              <div class="file_details">
                                <span class="folder_name">{{ entry.name }}</span>
                              </div>
                              <vs-checkbox  @input="selectDropBoxFileForUpload(entry ,index)"  :name="'dropBoxItem'+index"  v-model="entry['selectedForUpload']" ></vs-checkbox>
                            </li>
                          </template>
                            
                          </ul>
                        </div>
                      </div>
                      <template v-if="oneDriveFilesLoading">
                        <img src="@/assets/images/main/loader.gif"/>
                      </template>
                      <div class="crete_sec" v-if="!oneDriveFilesLoading"  >
                        <vs-button  color=""  class="primary-btn action_btn" v-if="!oneDriveAccessToken"  :disabled="filesUploading"  type="filled" > <a :href="oneDriveAuthUrl" >Connect to One Drive</a>  </vs-button>
                      </div>
                    </div>
                    
                      
                  </div>
                  </VuePerfectScrollbar>
                </div>
                
                <ul class="uploaded-list">
                    
                    <template v-for="(item, index) in fvalue">
                        <template v-if="checkProperty(item,'path') && checkProperty(item,'uploadedByRoleId') &&  getUserRoleId == 51 && !showToBeneficiary  ">
                            <template v-if="checkProperty(item,'uploadedByRoleId') == 51">
                                <vs-chip v-if="item.status" @click="item.status=false;remove(index ,checkProperty( item,'resourceId'))"  :key="index" closable>
                                    <img src="@/assets/images/main/down-arrow2.svg" @click="downloads3file(item)" />
                                    {{ item.name }}
                                </vs-chip>
                            </template>
                        </template>
                        <template v-else>
                            <vs-chip v-if="item.status" @click="item.status=false;remove(index,checkProperty( item,'resourceId'))"  :key="index" closable>
                                <img src="@/assets/images/main/down-arrow2.svg" @click="downloads3file(item)" />
                                {{ item.name }} 
                            </vs-chip>
                        </template>
                        
                    </template>
                </ul>

                <div class="popup-footer relative">
                  <span class="loader" v-if="filesUploading"  ><img src="@/assets/images/main/loader.gif"/></span>
                  
                <vs-button  color="dark"  class="cancel" :disabled="filesUploading" @click="updateData()" type="filled"  >Cancel</vs-button>
                <vs-button  color="success"  class="save" :disabled="filesUploading" @click="updateData()" type="filled" > Submit  </vs-button>
              </div>
              </div>
            </div>
          </modal> 
        </template>
        <template v-else>


          <div class="upload_sec">
            
            <div class="category_list">
              <ul>
                <li  :class="{'active':activeTab=='localDrive'}"  @click="changeTab('localDrive')"><span></span>Local Drive</li>
                <li :class="{'active':activeTab=='gDrive'}"  @click="changeTab('gDrive')"><span></span>Google Drive</li>
                <li :class="{'active':activeTab=='dropBox'}" @click="changeTab('dropBox')"><span></span>Dropbox</li>
                <li :class="{'active':activeTab=='oneDrive'}" @click="changeTab('oneDrive')"><span></span>One Drive</li>
              </ul>
            </div>
            
            <div class="category_cnt">
              <VuePerfectScrollbar ref="mainSidebarPs" class="scroll-area--nofications-dropdown p-0" :settings="settings">
              <div v-if="activeTab=='localDrive'" id="local_drive">
                <div class="files_sec">
                  <div class="file_upload"  v-if="true || (fieldName !=null && canRenderField(tplkey,fieldsArray, display,tplsection,fieldName))">
                      <div class="form_group" @click="showFileTypeError = ''">
                        <label class="form_label" ><span v-html="getLabel" style="display:inline"></span>      <div class="IB_tooltip" v-if="tooltip!=null">
                                    <span>
                                      <info-icon size="1.5x" class="custom-class"></info-icon>
                                    </span>
                                    <div class="tooltip_cnt">
                                      <p>
                                        {{tooltip}}
                                      </p>
                                    </div>
                                  </div></label>
                        <file-upload  :ref="fieldName+cid"  v-validate="checkFieldIsRequired({'key':tplkey,'section':tplsection, 'fieldsArray':fieldsArray, 'required':required })? 'required': datatype " :hideSelected="true" v-model="fvalue" class="file-upload-input file-upload-input-cs" :name="fieldName+cid"  :data-vv-as="vvas?vvas:placeHolder" :multiple="multiple" :accept="docAcceptType" @input="upload(fvalue)">
                            <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                            
                            Upload
                            <span class="loader" v-if="filesUploading" ><img src="@/assets/images/main/loader.gif"></span>
                        </file-upload>

                      <p v-show="errors.has((formscope!=''?formscope+'.':'')+fieldName+cid)" class="text-danger text-sm-doc">{{ errors.first((formscope!=''?formscope+'.':'')+fieldName+cid) }}</p>
                      <p v-show="showFileTypeError" class="text-danger text-sm-doc">{{ showFileTypeError }}</p>
                      
                  </div>
                  </div>
                </div>
              </div>
              <div v-if="activeTab=='gDrive'" class="show" id="google_drive">
                <div class="files_sec">
                  <ul class="bredcumbs" v-if="!gDriveFilesLoading && gDriveFilesAndFolders.length>0">
                    <template v-for="(bc ,indx) in gDriveBredCrumbs">
                      <li  :path="bc['path']" @click="getGoodleDriveFilesAndFolders(bc['path'])" v-if="indx==0">
                        <p>{{ bc['name'] }}  </p>
                      </li>
                      <li  :path="bc['path']" @click="getGoodleDriveFilesAndFolders(bc['path'])" v-else-if="bc['path'] !='/'">
                        <p>{{ bc['name'] }}  </p>
                      </li>
                    </template>
                  </ul>
                 
                  <div class="files_wrapper" v-if="!gDriveFilesLoading"> 
                    <div class="files_list">
                      <ul>
                        <template v-for="(entry ,index) in gDriveFilesAndFolders" >
                        <li  v-if="entry['.tag'] !='file'" :key="index" >
                          <div class="file_icon">
                            <img src="@/assets/images/icons/folder.svg"/>
                          </div>
                          <div class="file_details" @click="getGoodleDriveFilesAndFolders(entry.path_lower)">
                            <span class="folder_name">{{ entry.name }}</span>          
                          </div>
                        </li>
                      </template>
                        
                      </ul>
                    </div>
                    <div class="files_list list_view">
                      <ul>
                        <template v-for="(entry ,index) in gDriveFilesAndFolders" >
                        <li  v-if="entry['.tag']=='file'" :key="index" >
                          <div class="file_icon">
                            <docType :item="entry" />
                          </div>
                          <div class="file_details">
                            <span class="folder_name">{{ entry.name }}</span>
                          </div>
                          <vs-checkbox    :name="'dropBoxItem'+index"  v-model="entry['selectedForUpload']" ></vs-checkbox>
                        </li>
                      </template>
                        
                      </ul>
                    </div>
                  </div>
                  <template v-if="gDriveFilesLoading">
                    <NoDataFound  ref="NoDataFoundRef"  :loading="false"  heading="No Data"  type="support"  />
                  </template>
                  {{ gDriveFilesAndFolders }}
                  <div class="crete_sec" >
                    <button class="primary-btn action_btn"  @click="driveIconClicked();" ><span>Connect to Google Drive</span></button>
                  </div>
                </div>
              </div>
              <div v-if="activeTab=='dropBox'" id="dropbox">
                <div class="files_sec">
                  <ul class="bredcumbs">
                    <template v-for="(bc ,indx) in dropBoxBredCrumbs">
                      <li  :path="bc['path']" @click="getDropBoxFiles(bc['path'])" v-if="indx==0">
                        <p>{{ bc['name'] }}  </p>
                      </li>
                      <li  :path="bc['path']" @click="getDropBoxFiles(bc['path'])" v-else-if="bc['path'] !='/'">
                        <p>{{ bc['name'] }}  </p>
                      </li>
                    </template>
                    <!-----
                    <li class="active">
                      <p>Drop Box1 </p></li>
                    <li><p>Drop Box 2</p></li>
                    <li><span>/</span><p>Dropbox 3</p></li>
                    --->
                    </ul>
                  <div class="files_wrapper" v-if="!dropBoxFilesLoading"> 
                    <div class="files_list">
                      <ul>
                        <template v-for="(entry ,index) in dropBoxentries" >
                        <li  v-if="entry['.tag'] !='file'" :key="index" >
                          <div class="file_icon">
                            <img src="@/assets/images/icons/folder.svg"/>
                          </div>
                          <div class="file_details" @click="getDropBoxFiles(entry.path_lower)">
                            <span class="folder_name">{{ entry.name }}</span>          
                          </div>
                        </li>
                      </template>
                        
                      </ul>
                    </div>
                    <div class="files_list list_view">
                      <ul>
                        <template v-for="(entry ,index) in dropBoxentries" >
                        <li  v-if="entry['.tag']=='file'" :key="index" >
                          <div class="file_icon">
                            <docType :item="entry" />
                          </div>
                          <div class="file_details">
                            <span class="folder_name">{{ entry.name }}</span>
                          </div>
                          <vs-checkbox  @input="selectDropBoxFileForUpload(entry ,index)"  :name="'dropBoxItem'+index"  v-model="entry['selectedForUpload']" ></vs-checkbox>
                        </li>
                      </template>
                        
                      </ul>
                    </div>
                  </div>
                  <template v-if="dropBoxFilesLoading">
                    <NoDataFound  ref="NoDataFoundRef"  :loading="false"  heading="No Data"  type="support"  />
                  </template>
                  <div class="crete_sec" v-if="!dropBoxFilesLoading"  >
                    <vs-button  color=""  class="primary-btn action_btn" v-if="!dropBoxAccessToken"  :disabled="filesUploading"  type="filled" > <a :href="dropBoxAuthUrl" >Connect to Drop Box</a>  </vs-button>
                  </div>
                </div>
                
                  
              </div> 

              <!----oneDrive-->
             
              <div v-if="activeTab=='oneDrive'" id="oneDrive">
                <div class="files_sec">
                  <ul class="bredcumbs">
                    <template v-for="(bc ,indx) in oneDriveBredCrumbs">
                      <li  :path="bc['path']" @click="getDropBoxFiles(bc['path'])" v-if="indx==0">
                        <p>{{ bc['name'] }}  </p>
                      </li>
                      <li  :path="bc['path']" @click="getDropBoxFiles(bc['path'])" v-else-if="bc['path'] !='/'">
                        <p>{{ bc['name'] }}  </p>
                      </li>
                    </template>
                    
                    </ul>
                  <div class="files_wrapper" v-if="!oneDriveFilesLoading"> 
                    <div class="files_list">
                      <ul>
                        <template v-for="(entry ,index) in oneDriveEntries" >
                        <li  v-if="entry['.tag'] !='file'" :key="index" >
                          <div class="file_icon">
                            <img src="@/assets/images/icons/folder.svg"/>
                          </div>
                          <div class="file_details" @click="getDropBoxFiles(entry.path_lower)">
                            <span class="folder_name">{{ entry.name }}</span>            
                          </div>
                        </li>
                      </template>
                        
                      </ul>
                    </div>
                    <div class="files_list list_view">
                      <ul>
                        <template v-for="(entry ,index) in oneDriveEntries" >
                        <li  v-if="entry['.tag']=='file'" :key="index" >
                          <div class="file_icon">
                            <docType :item="entry" />
                          </div>
                          <div class="file_details">
                            <span class="folder_name">{{ entry.name }}</span>
                          </div>
                          <vs-checkbox  @input="selectDropBoxFileForUpload(entry ,index)"  :name="'dropBoxItem'+index"  v-model="entry['selectedForUpload']" ></vs-checkbox>
                        </li>
                      </template>
                        
                      </ul>
                    </div>
                  </div>
                  <template v-if="oneDriveFilesLoading">
                    <NoDataFound  ref="NoDataFoundRef"  :loading="false"  heading="No Data"  type="support"  />
                  </template>
                  <div class="crete_sec" v-if="!oneDriveFilesLoading"  >
                    <vs-button  color=""  class="primary-btn action_btn" v-if="!oneDriveAccessToken"  :disabled="filesUploading"  type="filled" > <a :href="oneDriveAuthUrl" >Connect to One Drive</a>  </vs-button>
                  </div>
                </div>
                
                  
              </div>
            </VuePerfectScrollbar>
            </div>
            
            <ul class="uploaded-list">
                
                <template v-for="(item, index) in fvalue">
                    <template v-if="checkProperty(item,'path') && checkProperty(item,'uploadedByRoleId') &&  getUserRoleId == 51 && !showToBeneficiary  ">
                        <template v-if="checkProperty(item,'uploadedByRoleId') == 51">
                            <vs-chip v-if="item.status" @click="item.status=false;remove(index ,checkProperty( item,'resourceId'))"  :key="index" closable>
                                <img src="@/assets/images/main/down-arrow2.svg" @click="downloads3file(item)" />
                                {{ item.name }}
                            </vs-chip>
                        </template>
                    </template>
                    <template v-else>
                        <vs-chip v-if="item.status" @click="item.status=false;remove(index,checkProperty( item,'resourceId'))"  :key="index" closable>
                            <img src="@/assets/images/main/down-arrow2.svg" @click="downloads3file(item)" />
                            {{ item.name }} 
                        </vs-chip>
                    </template>
                    
                </template>
            </ul>

            <div class="popup-footer relative">
              <span class="loader" v-if="filesUploading"  ><img src="@/assets/images/main/loader.gif"/></span>
              
            <vs-button  color="dark"  class="cancel" :disabled="filesUploading" @click="updateData()" type="filled"  >Cancel</vs-button>
            <vs-button  color="success"  class="save" :disabled="filesUploading" @click="updateData()" type="filled" > Submit  </vs-button>
          </div>
          </div>
        </template>
    
  </div>
  </template>
  
   
<script>
import FileUpload from "vue-upload-component/src";
import { InfoIcon } from 'vue-feather-icons'
import mime from 'mimetype';
import * as _ from "lodash";
import moment from "moment";
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import NoDataFound from "@/views/common/noData.vue";
import docType from "@/views/common/docType.vue";
var Dropbox = require('dropbox').Dropbox;
import { gapi } from "gapi-script";
export default {
     
      
      data() {
        return {
          settings: {

           wheelSpeed: 0.6,
       },
          popUpName:'',
          showPopUp:false,
          option1:false,
          activeTab:'localDrive', //gDrive ,dropBox
          filesUploading:false,
          configDetails:null,

          //local upload files
          showFileTypeError:'',
          fvalue: [],
          filesUploading:false,
          docAcceptType: "image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document",


          //drop Box veriables
         dropBoxBredCrumbs:[],
         selectedSourceFiles:[],
         finalUploadedFiles:[],
         dropBoxentries: [],
         dropBoxAccessToken: '',
         dropBoxAuthUrl:'',
         dropBoxAuthorizationCode:'',
         dropBoxClientId:'ftl7hhws3nvp2xp',
         clientSecret:'kwfakdnzt3913mb',
         dropBoxRedirectUrl:'https://localhost:8080/dropbox-config',
         dropBoxFilesLoading:false,


         //Google Drive 
         gDriveFilesAndFolders: [],
        attachments: [],
        pickerApiLoaded: false,
        developerKey: "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",
        clientId: "34479281417-9h58pod2rqm2iuketsgschef1ugs7ga7.apps.googleusercontent.com",
        scope: "https://www.googleapis.com/auth/drive.readonly",
        gDriveOauthToken: null,
        gDriveFilesLoading:false,
        gDriveBredCrumbs:[],


        /*oneDrive */
        oneDriveBredCrumbs:[],
        oneDriveFilesLoading:false,
        oneDriveEntries:[],
        oneDriveAccessToken:'',
        oneDriveAuthUrl:'',
        oneDriveClientId:'',
        oneDriveClientSecret:'',
        oneDriveRedirectUri:'https://localhost:8080/ms',
          
        };
      },
      components: { 
        docType,
        FileUpload,
          InfoIcon,
          VuePerfectScrollbar,
          NoDataFound
      },
      methods: {
        getAccessTockenConfigData(){
          this.dropBoxAccessToken ='';
          this.oneDriveAccessToken ='';
          this.gDriveOauthToken ="";
          let url ="/users/get-ext-file-upload-config"
          let postData ={};
          this.$store.dispatch("commonAction" ,{data:postData,path:url})
        .then(response => {
         
          if(this.checkProperty( response,'dropbox' ,'access_token')){
            this.dropBoxAccessToken = this.checkProperty( response,'dropbox' ,'access_token');
          }
          if(this.checkProperty( response,'oneDrive' ,'access_token')){
            this.oneDriveAccessToken =String(this.checkProperty( response,'oneDrive' ,'access_token'));
            this.getOpenDriveFilesAndFolders();
          }
          if(this.checkProperty( response,'googleDrive' ,'access_token')){
            //
            this.gDriveOauthToken = response.googleDrive.access_token;
          }

        }).catch(()=>{
          
        });

        },
        init(){

          this.showPopUp =false;
        this.generateAuthrizationCode();
        this.getglobalConfigData();
      
        this.dropBoxRedirectUrl = this.$globalgonfig.dropBoxRedirectUrl;
       
        if(this.checkProperty(this.$route, 'query','code' )){
          this.dropBoxAuthorizationCode= this.$route.query.code;
        }
       
       if(this.value){
           this.fvalue = _.cloneDeep(this.value);

       }
       if(this.fileAcceptType){
           if( this.fileAcceptType == 'MSWORD'){
               this.docAcceptType = 'application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document'
           }
       }



       let gDrive = document.createElement("script");
       gDrive.setAttribute("type", "text/javascript");
       gDrive.setAttribute("src", "https://apis.google.com/js/api.js");
        document.head.appendChild(gDrive);
       
     
        

        },
       togleModal(show=false){
        let self =this;
          if(show){
            this.init();
            this.showPopUp =true;
            this.activeTab ='localDrive';
           
            this.$modal.show(self.popUpName);
          }else{
           
           // alert()
           if(this.lodedFromPopup){
                
                this.$emit('closeUploadPopUp')
              }else{
                this.updateData();
              
            
            setTimeout(()=>{
              this.showPopUp =false;
              this.$modal.hide(self.popUpName);
            } ,5);
          }
           
          }

       },
        getglobalConfigData(){
          let postData ={}
          let path = '/global-config/get-ext-file-upload-config'
          this.$store.dispatch("commonAction", {data:postData,path:path})
          .then((response) =>{ 
           
          
            this.configDetails = response;
            if(this.checkProperty(response ,'dropbox' )){
                this.dropBoxClientId = this.checkProperty(response ,'dropbox' ,'clientId'  );
                this.clientSecret = this.checkProperty(response ,'dropbox' ,'clientSecret'  );
               this.generateAuthrizationCode();
               this.getAccessTockenConfigData();
               
            }
            if(this.checkProperty(this.configDetails ,'oneDrive', 'clientId' )){
              
                this.oneDriveClientId = this.checkProperty(response ,'oneDrive' ,'clientId'  );
                this.oneDriveClientSecret = this.checkProperty(response ,'oneDrive' ,'clientSecret'  );
                this.generateOneDriveAuthUrl();
               this.getAccessTockenConfigData();
               
            }
            if(this.checkProperty(this.configDetails ,'googleDrive', 'clientId' )){
              
              this.clientId = this.checkProperty(response ,'googleDrive' ,'clientId'  );
              this.developerKey = this.checkProperty(response ,'googleDrive' ,'developerKey'  );
              this.scope = this.checkProperty(response ,'googleDrive' ,'scope'  );
              
             
          } 
                
          }).catch((eer)=>{
            
           
          })
        },

      

        changeTab(tab='localDrive'){
          this.activeTab = tab;
          if(this.activeTab=='dropBox'){
            //this.selectedSourceFiles = [];
            this.dropBoxBredCrumbs =[];
            if(this.dropBoxAccessToken){

             
              var ACCESS_TOKEN = this.dropBoxAccessToken;
               this.dbx = new Dropbox({
              accessToken: ACCESS_TOKEN//'sl.BfYWd7iOuXDL0Dna3lMNskjuLBq3t5oPZE3LSv57OkeaRkeAIelZ7KOvwD_OvripemPkDTfqgHBArn0MGCLOxwVXI-u8nUJ9tUpBROJHXp_p0o385kD22CYH2im2XFmXvkHNFuSawDl6'
              });
            this.getDropBoxFiles();

            }
            
          }
          if(this.activeTab=='gDrive'){
            //this.driveIconClicked();
          }
          if(this.activeTab=='oneDrive' &&  this.oneDriveAccessToken !=''){
            this.getOpenDriveFilesAndFolders();
          }
        },

        remove(index ,resourceId='') {
            this.fvalue[index].status = false;
           
            if(this.deleteDocPermenantly){
                this.fvalue.splice(index, 1); 
                
            }
            else{
                this.fvalue.splice(index, 1); 
               
                
            }
           
            this.selectedSourceFiles = _.filter(this.selectedSourceFiles ,(fl)=>{
              return fl['id'] !=resourceId
            }) ;
                   
        },
        updateData() {
            this.fvalue =_.filter(this.fvalue, function (item) { return item.status == true &&  item.path})
            this.$emit('input', this.fvalue)
            setTimeout(()=>{
             
                this.togleModal(false);
              
              
            },1);
        },
        extractDocument(fileUrl=''){
            let self = this;
            let data = {
                category:'cap_notice',
                "lcaDocument": ''
            };
            this.filesUploading =false;
            data['lcaDocument'] = fileUrl;
            if(fileUrl){
                let path = "/petition/extract-lca-data-from-pdf"
                this.$store.dispatch('commonCaseAction', { "data": data, 'path': path })
                .then((response) => {
                    let res = response 
                    if(_.has(res,'beneficiaryCnfmNumber') && this.checkProperty(res,'beneficiaryCnfmNumber')){
                        if(this.checkProperty(this.petition,'beneficiaryInfo')){
                            this.petition['beneficiaryInfo']['beneficiaryCnfmNumber'] = this.checkProperty(res,'beneficiaryCnfmNumber')
                        }
                    }
                    if(_.has(res,'capType') && this.checkProperty(res,'capType')){
                        if(this.checkProperty(this.petition,'beneficiaryInfo')){
                            this.petition['beneficiaryInfo']['capType'] = this.checkProperty(res,'capType')
                        }
                    }
                    if(_.has(res,'serviceCenterName') && this.checkProperty(res,'serviceCenterName')){
                        if(this.checkProperty(this.petition,'beneficiaryInfo')){
                            this.petition['beneficiaryInfo']['serviceCenterName'] = this.checkProperty(res,'serviceCenterName')
                        }
                    }
                })
                .catch((err)=>{})
            }
        },

        //local Drive 
        upload(model) {
          let self =this;
            let mapper = model.map(
                (item) =>{
               if(item.name && item.resourceId){
                 let mimetype = mime.lookup(item.name);
                 if(mimetype){
                  item.mimetype =mimetype;
                 }

               }
                  
               let  tempitem = {
                    resourceId:item.resourceId?item.resourceId:'',
                    name: item.name,
                    size:item.size ? item.size : null,
                    file: item.file ? item.file : null,
                    path: item.path ? item.path : "",
                    isNew: item.isNew ? item.isNew : false,
                    status: item.status === false || item.status === true ? item.status : true,
                    mimetype: item.type ? item.type : item.mimetype,
                    uploadedBy:item.uploadedBy?item.uploadedBy:self.checkProperty(self.getUserData,'userId')!=''?self.checkProperty(self.getUserData,'userId'):null,
                    uploadedByName:item.uploadedByName?item.uploadedByName:self.checkProperty(self.getUserData,'name')!=''?self.checkProperty(self.getUserData,'name'):'',
                    uploadedByRoleId:item.uploadedByRoleId?item.uploadedByRoleId:self.getUserRoleId?self.getUserRoleId:null,
                    uploadedByRoleName:item.uploadedByRoleName?item.uploadedByRoleName:self.checkProperty(self.getUserData,'loginRoleName'),
                    
                }

               
               
                return tempitem;
            }
            );
            if (mapper.length > 0 && this.sendS3Responce) {
               
                let count =0;
                this.showFileTypeError =""
                mapper.forEach((doc, index) => {
                    if (doc.file) {
                     
                      self.filesUploading =true;
                        if(self.fileAcceptType !=''){
                            if(self.fileAcceptType && self.fileAcceptType =="MSWORD"){
                                if(doc.mimetype == 'application/pdf' || doc.mimetype == 'image/*' ){
                                  self.showFileTypeError ="Upload only word format document";
                                    mapper.splice(index ,1)
                                    self.filesUploading =false;
                                    return false;
                                }
                        
                            }
                        }
                        self.filesUploading =true;
                        let formData = new FormData();
                        formData.append("files", doc.file);
                        formData.append("secureType", "private");
                        formData.append("getDetails", true);
                        self.$store.dispatch("uploadS3File", formData).then((response) => {
                            response.data.result.forEach((urlGenerated) => {
                            
                                doc.isNew = true;
                                doc.url = uurlGenerated["url"];
                                doc.path = urlGenerated["path"];
                                if(_.has(urlGenerated ,'size' )){
                                     doc['size'] = urlGenerated['size'];
                                }
                                doc['file'] =null
                                delete doc.file;
                                delete doc.url;
                                mapper[index] = doc;
                                
                                if(self.callExtract && self.fieldName == 'capSelectNotice'){
                                 // self.extractDocument(urlGenerated)
                                }
                                if(!self.multiple){
                                  self.fvalue =[];
                                }
                                let isExists = _.filter( self.fvalue ,{"path":doc.path});
                               
                               // if(isExists.length<=0 ){
                                  self.fvalue[index] =doc
                               // }
                                
                            });
                           
                            count =count+1;
                            if(mapper.length >=count ){
                              self.filesUploading =false;                             

                            }
                           
                        });
                    }else{
                      count =count+1;
                    }
                });
                model.splice(0, mapper.length, ...mapper);
            }else if(mapper.length > 0 && !this.sendS3Responce){

              this.filesUploading =true;
                let count =0;
                this.showFileTypeError =""
                mapper.forEach((doc, index) => {
                    if (doc.file) {
                        if(self.fileAcceptType !=''){
                            if(self.fileAcceptType && self.fileAcceptType =="MSWORD"){
                                if(doc.mimetype == 'application/pdf' || doc.mimetype == 'image/*' ){
                                  self.showFileTypeError ="Upload only word format document";
                                    mapper.splice(index ,1)
                                    self.filesUploading =false;
                                    return false;
                                }
                        
                            }
                        }
                        self.filesUploading =true;
                        if(!self.multiple){
                            self.fvalue =[];
                          }
                       // self.fvalue.push(doc);
                         count =count+1;
                            if(mapper.length >=count ){
                              self.filesUploading =false;                             

                            }
                        
                    }else{
                      count =count+1;
                    }
                });
                model.splice(0, mapper.length, ...mapper);

            }
            
            self.fvalue =_.cloneDeep(self.fvalue)
            

        },
       

        //Drop Box Methods 
       
        updateDropBoxRedirectUrl(){
          let rdata = { "path":"" ,"query":{} ,"params":{}}
          rdata['name'] = this.$route['name'];
          rdata['path'] = this.$route['path'];
          rdata['params'] = this.$route['params'];
          rdata['query'] = this.$route['query'];
          this.$store.commit('updateDropBoxRedirectUrl',rdata);

        },

        generateAuthrizationCode(redirect=false){

        //   const DROPBOX_APP_KEY = this.dropBoxClientId;
        // this.dbx = new Dropbox({ clientId: DROPBOX_APP_KEY });
        // this.dropBoxAuthUrl = this.dbx.getAuthenticationUrl('http://localhost:8080/app/doc-upload');

        var clientId = this.dropBoxClientId;
var redirectUri = this.dropBoxRedirectUrl;
var scopes = [];
this.dropBoxAuthUrl = 'https://www.dropbox.com/oauth2/authorize' +
  '?response_type=code' +
  '&client_id=' + encodeURIComponent(clientId) +
  '&redirect_uri=' + encodeURIComponent(redirectUri) +
  '&scope=' + encodeURIComponent(scopes.join(' '));
  this.updateDropBoxRedirectUrl();
  if(redirect){
    //updateDropBoxRedirectUrl
    //update dropBoxRedirectUrlData
    
  
   // window.open(this.dropBoxAuthUrl ,"_blank")
   //window.location = this.dropBoxAuthUrl;

  }

        },
      generateAccessKey(){
        // Dropbox SDK setup
       
      var code = this.dropBoxAuthorizationCode //'AUTHORIZATION_CODE';
      var clientId = this.dropBoxClientId;
      var clientSecret = this.clientSecret;
      var redirectUri = this.dropBoxRedirectUrl;
     // this.dbx = new Dropbox({ clientId: clientId  ,clientSecret:clientSecret});
            

      var xhr = new XMLHttpRequest();
xhr.open('POST', 'https://api.dropboxapi.com/oauth2/token', true);
xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xhr.onreadystatechange =  ()=> {
  if (xhr.readyState === 4 && xhr.status === 200) {
    var response = JSON.parse(xhr.responseText);
    var accessToken = response.access_token;
    this.dropBoxAccessToken =accessToken;
    var refreshToken = response.refresh_token;
   // alert(accessToken)
    // Store the access token and refresh token securely for future use
  }
};

var requestBody = 'code=' + encodeURIComponent(code) +
                  '&grant_type=authorization_code' +
                  '&client_id=' + encodeURIComponent(clientId) +
                  '&client_secret=' + encodeURIComponent(clientSecret) +
                  '&redirect_uri=' + encodeURIComponent(redirectUri);

xhr.send(requestBody);
        
        
      },
      selectDropBoxFileForUpload(item ,index){
        //dropBoxentries
        let self = this;
        item['fileObject'] =null;
        let isExists = _.find(this.selectedSourceFiles ,{"id":item['id']})
        setTimeout(()=>{
        if(item['selectedForUpload']){
            if(!isExists){
             if(!this.multiple){
              this.selectedSourceFiles =[];
              _.map(self.dropBoxentries ,(dpFile ,ind)=>{
                   if(dpFile['.tag'] =='file' && ind!=index){
                    dpFile['selectedForUpload'] =false;
                   }
              })
             }
              this.selectedSourceFiles.push(_.cloneDeep(item));
              this.downloadFromDropBoxFile(item);
            }
          
        }else{
          self.selectedSourceFiles = _.filter(self.selectedSourceFiles ,(fl)=>{
              return fl['id'] !=item['id']
          }) ;

          this.fvalue  = _.filter(this.fvalue ,(fl)=>{
            if(fl.resourceId){
               return  fl.resourceId !=item['id'];
            }else{
              return true;
            }

          })

        }
        },10);
        
      },
      generateBredCrumbs(path=''){
        let self =this;
        this.dropBoxBredCrumbs =[];
        let PathData = {"path":'/' ,"name":'/' };
        this.dropBoxBredCrumbs.push(PathData);
        if(path){
          let lst = path.split("/");
          _.forEach(lst ,( item ,index)=>{
            if(index>0){
              let tempPath = {"path":'/' ,"name":item };
              let priviousItem =  lst[index-1]
              let cP = priviousItem+"/"+item;
              
              
              if (!cP.startsWith("/")) {
                cP = "/"+cP
              }
              cP =cP.replaceAll("//", '/');
              let name = item+'/';
              name = name.replaceAll("//", '/');
              tempPath = {"path":cP ,"name":name };
              this.dropBoxBredCrumbs.push(tempPath);

            }
          })
        }
      },
      getDropBoxFiles(path=''){
        
        let self =this;
        let tmpPath=path
        if (path=='/'){
          tmpPath ='';
        }
         this.dropBoxFilesLoading =true; 
          this.dbx.filesListFolder({ path: tmpPath })
        .then(response => {
          self.dropBoxFilesLoading =false; 
          self.dropBoxBredCrumbs =[];
          self.generateBredCrumbs(path);
          let list =response['result']['entries'];
          let tempList = [];
        
          _.forEach(list ,(item)=>{
            item =  Object.assign( item ,{ "selectedForUpload":false ,"uploadingToS3":false,"downLoadingFromSource":false,fileObject:null ,"resourceType":'dropBox' ,"s3Data":null})
            if(item['id']){
              let alreadySelected = _.find(self.selectedSourceFiles ,{"id":item['id'] });
              if(alreadySelected){
                item['selectedForUpload'] =true;
              }
            }

            if(item['.tag']=='file'){
              let mimetype = mime.lookup(item.name);
                 if(mimetype){
                  item['mimetype'] = mimetype;
                 }

            }
            
            tempList.push(item);
          });
          self.dropBoxentries = tempList;
          self.dropBoxFilesLoading =false; 
        })
        .catch(error => {
          self.dropBoxFilesLoading =false; 
          self.dropBoxAccessToken ='';
        //  self.showToster({"message":error ,isError:true})
          
        });

      },
      downloadFromDropBoxFile(item) {
        let _self =this;
        _self.dbx.filesDownload({ path: item['path_lower']})
          .then((response)=>{
          
            
            let  result = response['result'];
            let fileData = result.fileBlob;
            let contentType = response.headers.get('Content-Type');
            let mimetype = mime.lookup(item.name);
            if(mimetype){
              contentType = mimetype;
            }
           
            // const file = new File([fileData], 'file.wmv', { type: fileData.type });
            item['file'] = new File([fileData], item['name'], { type: contentType });
           // alert(item.name);
            item['downLoadingFromSource'] = false;
            let fileItem = {
                     resourceId: item['id'],
                      name: item.name,
                      file: item.file ? item.file : null,
                      path: item.path ? item.path : "",
                      isNew: true,
                      status: item.status === false || item.status === true ? item.status : true,
                      mimetype: contentType,
                      uploadedBy:item.uploadedBy?item.uploadedBy:_self.checkProperty(_self.getUserData,'userId')!=''?_self.checkProperty(_self.getUserData,'userId'):null,
                      uploadedByName:item.uploadedByName?item.uploadedByName:_self.checkProperty(_self.getUserData,'name')!=''?_self.checkProperty(_self.getUserData,'name'):'',
                      uploadedByRoleId:item.uploadedByRoleId?item.uploadedByRoleId:_self.getUserRoleId?_self.getUserRoleId:null,
                      uploadedByRoleName:item.uploadedByRoleName?item.uploadedByRoleName:_self.checkProperty(_self.getUserData,'loginRoleName'),
                      
            };
            _self.fvalue.push(fileItem);
            this.upload( _self.fvalue);
        })
      },
      downloadFromDropBoxFileUploadTos3(){
        let _self = this;
        let downLoadedCount =-1;
        _.forEach(_self.selectedSourceFiles, (sitem, index)=>{
          let item = sitem;
          item['fileObject'] =null;
          item['downLoadingFromSource'] = true;
          item['uploadingToS3'] = false;
          item['resourceId'] = item['id'];
          
          
          
          _self.dbx.filesDownload({ path: item['path_lower']})
          .then((response)=>{
            
            let  result = response['result'];
            let fileData = result.fileBlob;
            let contentType = response.headers.get('Content-Type');
          // const file = new File([fileData], 'file.wmv', { type: fileData.type });
          item['file'] = new File([fileData], item['name'], { type: contentType });
          item['downLoadingFromSource'] = false;
          let fileItem = {
                    resourceId: item['id'],
                    name: item.name,
                    file: item.file ? item.file : null,
                    path: item.path ? item.path : "",
                    isNew: true,
                    status: item.status === false || item.status === true ? item.status : true,
                    mimetype: contentType,
                    uploadedBy:item.uploadedBy?item.uploadedBy:t_selfhis.checkProperty(_self.getUserData,'userId')!=''?_self.checkProperty(_self.getUserData,'userId'):null,
                    uploadedByName:item.uploadedByName?item.uploadedByName:_self.checkProperty(_self.getUserData,'name')!=''?_self.checkProperty(_self.getUserData,'name'):'',
                    uploadedByRoleId:item.uploadedByRoleId?item.uploadedByRoleId:_self.getUserRoleId?_self.getUserRoleId:null,
                    uploadedByRoleName:item.uploadedByRoleName?item.uploadedByRoleName:_self.checkProperty(_self.getUserData,'loginRoleName'),
                    
          };
          _self.fvalue.push(fileItem);
          downLoadedCount = downLoadedCount+1;
          if(downLoadedCount>=_self.selectedSourceFiles.length){
            _self.upload(_self.fvalue)
          }
          _self.selectedSourceFiles.splice(index ,1 );
          
          

          }).catch((err)=>{
            downLoadedCount = downLoadedCount+1
            _self.selectedSourceFiles.splice(index ,1 );

          });
            
          

        })

        //bulk files uploadTo s3;
      

      },

      //One Drive Methods
      generateOneDriveAuthUrl(){
        
       this.oneDriveAuthUrl = "https://login.microsoftonline.com/common/oauth2/v2.0/authorize?client_id="+this.oneDriveClientId+"&response_type=code&redirect_uri="+this.oneDriveRedirectUri+"&response_mode=query&scope=Files.ReadWrite%20offline_access"

      },
      getOpenDriveFilesAndFolders(){
        const accessToken = this.dropBoxAccessToken.trim();
        let self =this;
          // Make the API request to retrieve files and folders
          fetch('https://graph.microsoft.com/v1.0/me/drive/root/children', {
            headers: {
              "Authorization":"Bearer "+accessToken,
            },
          })
            .then(response => response.json())
            .then(data => {
             
              // Process the response data
              if(_.get(data,'error.code','')  ){
                this.oneDriveAccessToken =''; 
                //self.showToster({"message":data.error.message ,isError:true})
              }else{
                this.oneDriveEntries = data
              }
             
              console.log(data);
              // Handle the files and folders as needed
            })
            .catch(error => {
             
              // Handle any errors that occur during the API request;
              this.oneDriveAccessToken ='';
              console.error(error);
            });

      },


      //Google Drive methods
      // function called on click of drive icon
      getGoodleDriveFilesAndFolders(path=''){
       // alert()
        this.createPicker();   
      },
    async driveIconClicked() {
      if(this.gDriveOauthToken){
        this.getGoodleDriveFilesAndFolders();
       // return false
      }
    let self =this;
    const clientId = self.clientId;
    let  useEffect =(() => { 
       
        
       function start() { 
        gapi.client.init({ clientId: clientId, scope: self.scope, }); 
        gapi.load("picker", () => {
          self.pickerApiLoaded = true;
          self.createPicker();
      });
      } 
       gapi.load("client:auth2", () => {
        gapi.auth2.authorize(
          {
            client_id: this.clientId,
            scope: this.scope,
            immediate: false
          },
          this.handleAuthResult
        );
      });
      start()

       });
       useEffect()
     
      
    },
    saveGoogleDriveAccessToken(response){
      let url ="/users/save-ext-file-upload-config";
        let postData = {
            "configType":'googleDrive',
            'config':response
        };
      this.$store.dispatch("commonAction" ,{data:postData,path:url})
        .then(res => {
                           
               this.gDriveOauthToken = response.access_token;
               this.createPicker();   

            
        }).catch((err)=>{
           
          
        })
    },

    handleAuthResult(authResult) {
      if (authResult && !authResult.error) {
       
        this.saveGoogleDriveAccessToken(authResult);
        //this.createPicker()
       
       
      }
    },

    // Create and render a Picker object for picking user Photos.
    createPicker() {
      if (this.pickerApiLoaded && this.gDriveOauthToken) {
      try{

      
        var picker = new google.picker.PickerBuilder()
          .enableFeature(google.picker.Feature.MULTISELECT_ENABLED)
          .addView(google.picker.ViewId.DOCS)
          .setOAuthToken(this.gDriveOauthToken)
          .setDeveloperKey(this.developerKey)
          .setCallback(this.pickerCallback)
          .build();
        picker.setVisible(true);
        //alert('createPicker')
       // alert(picker)
    }catch(err){
     // alert(JSON.stringify(err))
      console.log(err)
    }
      }
    },
    async pickerCallback(data) {
    //  alert('pickerCallback')
      var url = "nothing";
      var name = "nothing";
      console.log(JSON.stringify(data));
      if (data[google.picker.Response.ACTION] === google.picker.Action.PICKED) {
        var doc = data[google.picker.Response.DOCUMENTS][0];
        url = doc[google.picker.Document.URL];
        name = doc.name;
        let docs = data.docs;
        var param = { fileId: doc.id, oAuthToken: this.gDriveOauthToken, name: name };
        let attachments = [];
        for (let i = 0; i < docs.length; i++) {
          let attachment = {};
          attachment._id = docs[i].id;
          attachment.title = docs[i].name;
          attachment.name = docs[i].name + "." + docs[i].mimeType.split("/")[1];
          attachment.type = "gDrive";
          attachment.description = "Shared with GDrive";
          attachment.extension =
            "." +
            docs[i].mimeType.substring(docs[i].mimeType.lastIndexOf(".") + 1);
          attachment.iconURL = docs[i].iconUrl;
          attachment.size = docs[i].sizeBytes;
          attachment.user = JSON.parse(localStorage.getItem("user"));
          attachment.thumb = null;
          attachment.thumb_list = null;
          attachments.push(attachment);
        }
        this.gDriveFilesAndFolders = [...attachments];
      }
      this.gDriveOauthToken = null;
      this.pickerApiLoaded = false;
    }
      },
      inject: ["parentValidator"],
      props: {
        lodedFromPopup:{
              type:Boolean,
              default:false  // if false this component emit file s3 data , if false then it will emit file object data
          },
        popUpIndex:{
          default:''
        },
        sendS3Responce:{
              type:Boolean,
              default:true  // if true this component emit file s3 data , if false then it will emit file object data
          },
          showToBeneficiary:{
              type:Boolean,
              default:false
          },
          fileAcceptType: {
              type: String,
              default: ''
          },
          tplsection:{
              type: String,
              default: null,
          },
          tplkey:{
              type: String,
              default: null,
          },
          deleteDocPermenantly:{
              type:Boolean,
              default:false
          },
          tooltip:{
              type: String,
              default: null,
          },
          display: {
              type: Boolean,
              default: false,
          },
          fieldsArray:Array,
          multiple: {
              type: Boolean,
              default: true
          },
          vvas: {
              type: String,
              default: ""
          },
          wrapclass: {
              type: String,
              default: "md:w-1/2"
          },
          datatype: {
              type: String,
              default: ""
          },
          cid: {
              type: String,
              default: '',
          },
          formscope: {
              type: String,
              default: null
          },
          value: null,
          label: {
              type: String,
              default: null,
          },
          fieldName: {
              type: String,
              default: null,
          },
          placeHolder: {
              type: String,
              default: null,
          },
          required: {
              type: Boolean,
              default: false,
          },
          callExtract:{
              type: Boolean,
              default: false,
          },
          petition: null,
      },
      created() {
        this.popUpName ="customFileUploadPopUp_"+Math.floor((Math.random() * 10000000) + 1);
          this.$validator = this.parentValidator;
      },
      mounted() {
        this.generateOneDriveAuthUrl()
        //this.popUpName ="customFileUploadPopUp_"+moment().unix();
        this.showPopUp =false;
        this.activeTab ='localDrive';
        if(this.lodedFromPopup){
          this.init();
        }
      
        
       
        
   
      },
      computed: {
        
        getLabel(){
            let label = _.cloneDeep(this.label);
            if(this.checkFieldIsRequired({'key':this.tplkey,'section':this.tplsection, 'fieldsArray':this.fieldsArray, 'required':this.required })){
                label = label+"<em>*</em>";
            }
           
            return label;

        },
        getlist() {
            
            return  _.filter(this.fvalue, function (item) {

                return item.status == true && item['path']
            })

        }
      },
     
}
</script>
  
  