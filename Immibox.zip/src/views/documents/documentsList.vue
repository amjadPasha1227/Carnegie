<template>
  <div>
    <div class="content-header"  v-if="baseFolderName != ''">
  
      <div class="content-header-left">
        
        <div class="search">
          <vs-input
          v-if="baseFolderName != ''"
            icon-pack="feather"
            icon="icon-search"
           
            v-model.lazy="searchtxt"
            placeholder="Search by Name"
            class="is-label-placeholder"
          />
        </div>
      </div>
      <div class="content-header-right">
        <!--filter dropdown-->
        <vs-dropdown
          vs-custom-content
          vs-trigger-click
          v-if="baseFolderName != '' && false"
        >
          <vs-button
            color="primary"
            class="filter-btn"
            type="border"
            icon-pack="feather"
            icon="icon-chevron-down"
            icon-after
          >
            <img src="@/assets/images/main/icon-filter.svg" /> Filters
          </vs-button>
          <vs-dropdown-menu ref="filter_menu" class="filters-content">
            <div class="filters-form-fileds">
              <div class="form-container">
                <div class="vx-row">
                  <div
                    class="vx-col md:w-1/3 w-full con-select"
                    v-if="this.baseFolderName == 'Trash'"
                  >
                    <label class="typo__label">Select Status</label>

                    <multiselect
                      v-model="selectedStatusIds"
                      :options="statusIdsList"
                      :multiple="true"
                      :hideSelected="true"
                      :close-on-select="false"
                      :clear-on-select="false"
                      :select-label="''"
                      :preserve-search="true"
                      placeholder="Select Status"
                      label="name"
                      track-by="name"
                      :preselect-first="false"
                    >
                      <template
                        slot="selection"
                        slot-scope="{ values, isOpen }"
                      >
                        <span
                          class="multiselect__selectcustom"
                          v-if="values.length && !isOpen"
                          >{{ values.length }} Status selected</span
                        >
                        <span
                          class="multiselect__selectcustom"
                          v-if="values.length && isOpen"
                        ></span>
                      </template>
                    </multiselect>
                  </div>
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Created Date</label>
                    <date-range-picker
                      :maxDate="new Date()"
                      :autoApply="autoApply"
                      :ranges="false"
                      v-model="selected_createdDateRange"
                    ></date-range-picker>
                  </div>
                </div>
              </div>
            </div>
            <div class="filters-status">
              <div class="left-buttons"></div>
              <div class="right-buttons">
                <vs-button
                  color="success"
                  class="save"
                  type="filled"
                  vs-trigger-click
                  v-on:click="set_filter()"
                  >Apply</vs-button
                >
                <vs-button
                  color="dark"
                  class="cancel"
                  type="filled"
                  vs-trigger-click
                  v-on:click="clear_filter($event)"
                  >Clear
                </vs-button>
              </div>
            </div>
          </vs-dropdown-menu>
        </vs-dropdown>
        <!-- end -->

        <template
          v-if="
            baseFolderName != '' &&
            baseFolderName != 'My Favourites' &&
            baseFolderName != 'Shared With Me' &&
            baseFolderName != 'Trash'&&
            baseFolderName !='Cases'
          "
        >
          <!-- <div class="addnew_actions">
            <vs-button class="light-blue-btn">Add </vs-button>
            <div class="actions__list">
              <ul>
              <li @click="openNewfolder()">
                  Add Folder<img src="@/assets/images/icons/files/folder.svg"/>
                </li>
                <li @click="openAddDocPopup()">
                  Add Document<img src="@/assets/images/icons/files/doc.svg"/>
                </li>
                
              </ul>
            </div>            
          </div> -->


          <vs-button
            type="border"
            class="light-blue-btn"
            @click="openAddDocPopup()"
            >Upload Files
            <span>
              <img src="@/assets/images/icons/files/doc.svg"/>
            </span>
          </vs-button>
          <vs-button
            type="border"
            class="light-blue-btn"
            @click="openNewfolder()"
            >
            Create Folder
            <span>
              <img src="@/assets/images/icons/files/folder.svg"/>
            </span>
          </vs-button>
        </template>
        <!-- <button class="btn btn-brown" @click="FillingFreeDetails=true">Filling</button> -->
      </div>
    </div>

    <ul class="bredcumbs" v-if="breadcrumbs.length>1">
      <template v-for="(breadcrumb, index) in breadcrumbs">
        <li
          :key="index"
        
          class="brecumb-item"
        >
            <template v-if="breadcrumb['name']=='/'"><p @click="changedBreadcrumb(breadcrumb)">Documents</p></template>
            <template v-else>
            <span v-if="breadcrumb['name'] !='/'">/</span>
              <p  @click="changedBreadcrumb(breadcrumb)">
              <template v-if="checkProperty(breadcrumb ,'displayName')">{{breadcrumb['displayName']}}</template>
              <template v-else>{{checkProperty(breadcrumb ,'name')}}</template>
              
              </p>
            </template>
        </li>
      </template>
    </ul>

    <div class="files_wrapper" v-if="checkFileType('baseFolder') || checkFileType('folder')">
      
      <div class="files_list">
        <ul>
          <template  v-for="(tr, indextr) in documentsList" >
          <li :data="tr"
              :key="indextr"
              @click="gotoSubFolder(tr)"   v-if="tr['type'] != 'document'" >
            <div class="file_icon">
              <img src="@/assets/images/icons/files/folder.svg"/>
            </div>
            <div class="file_details"> 
              <span class="folder_name">{{ tr["displayName"] }}</span>
            
           
 
              <span class="updated_on" v-if="checkProperty(tr, 'updatedOn')">Updated on: <b>{{ tr["updatedOn"] | formatDate }}</b></span>
              <span class="updated_on" v-else-if="checkProperty(tr, 'createdOn')">Created on: <b>{{ tr["createdOn"] | formatDate }}</b></span>
              <div class="folders_files">
               <span class="folders"><b>{{ checkProperty(tr, 'folderCount') }}</b> Folder(s)</span>|<span class="files"><b>{{ checkProperty(tr, 'fileCount') }}</b> File(s)</span>
              </div>
            </div>
          </li>
          </template>
        </ul>
      </div>
    </div>
    <div class="accordian-table" v-if="documentsList.length > 0 && checkFileType('document')">
      <vs-table :data="documentsList" :no-data-text="'No data found..!'">
        <template slot="thead" v-if="documentsList.length > 0">
          <vs-th class="pt-10">
            
            Files
          
        
          </vs-th>
           
          <vs-th class="pt-10">Size </vs-th>
          
          <vs-th v-if="baseFolderName" class="pt-10">
            <template v-if="baseFolderName =='Shared With Me'">
              Shared By
            </template>
            <template v-else>Uploaded By</template>
            
          </vs-th>
          <vs-th v-if="baseFolderName" class="pt-10">
            
           
            <template v-if="baseFolderName =='Shared With Me'">
              Shared On
            </template>
            <template v-else> Last Updated</template>
            
          </vs-th>

          <vs-th class="actions pt-10">Actions</vs-th>
        </template>

        <template>
          <template v-for="(tr, indextr) in documentsList">
            
            <vs-tr
            v-if="tr['type'] == 'document'"
              :data="tr"
              :key="indextr"
              
            >
              <vs-td :data="tr.name">
                <span  class="cursor" >
                  <figure class="files_img">
                    <template v-if="tr['type'] == 'document'">
                      <img v-on:click.stop.prevent="download_or_view(tr)"  v-if="checkFileFormat(tr['mimetype']) =='pdf'" src="@/assets/images/main/pdf.svg" /> 
                      <img v-on:click.stop.prevent="download_or_view(tr)"  v-else-if="checkFileFormat(tr['mimetype']) =='video_mime_types'" src="@/assets/images/main/film.png" />
                      <img v-on:click.stop.prevent="download_or_view(tr)" v-else-if="checkFileFormat(tr['mimetype']) =='msDoc'" src="@/assets/images/main/doc.svg" />
                      <img v-on:click.stop.prevent="download_or_view(tr)" v-else-if="checkFileFormat(tr['mimetype']) =='zip'" src="@/assets/images/main/zip-file-format.png" />
                      <img v-on:click.stop.prevent="download_or_view(tr)" v-else-if="checkFileFormat(tr['mimetype']) =='msPpt'" src="@/assets/images/main/ppt.svg" />
                      <img v-on:click.stop.prevent="download_or_view(tr)" v-else-if="checkFileFormat(tr['mimetype']) =='msXl'" src="@/assets/images/main/xls.svg" /> 
                      <img v-on:click.stop.prevent="download_or_view(tr)" v-else-if="checkFileFormat(tr['mimetype']) =='image'" src="@/assets/images/main/image.svg" />
                      <img v-on:click.stop.prevent="download_or_view(tr)" v-else src="@/assets/images/icons/files/doc.svg" />
                    
                    </template>
                     
                    <img v-else src="@/assets/images/icons/files/folder.svg" />
                  </figure>
                  <div class="d-flex align-center pl-3">
                   <span v-on:click.stop.prevent="download_or_view(tr)"  v-if="tr['type'] == 'document'" > {{ tr["name"] }}</span>
                   <span v-else > {{ tr["displayName"] }}</span>
                    <ul
                      class="documents_icons"
                      v-if="tr['type'] != 'baseFolder'"
                    >
                      <li style="cursor:default" v-if="checkProperty(tr, 'confidential')">
                        <img src="@/assets/images/main/padlock.svg" />
                      </li>
                      <li v-if="checkProperty(tr, 'type') == 'document'" >

                        
                        <template v-if="baseFolderName =='Trash'">
                          <img style="cursor:default"  v-if="checkProperty(tr, 'favourite')"   src="@/assets/images/main/star-active.svg" favourite="true"/>
                        </template>
                        <template v-else>
                          <img  v-if="checkProperty(tr, 'favourite')" v-on:click.stop.prevent="removefavlist(tr)"  src="@/assets/images/main/star-active.svg" favourite="true"/>
                        </template>
                        <img  v-if="!checkProperty(tr, 'favourite') && baseFolderName !='Trash'" v-on:click.stop.prevent="addTofavlist(tr)" src="@/assets/images/main/star.svg" favourite="false"/>
                      </li>
                      <li v-if="checkProperty(tr, 'sharedCount') > 0" class="tooltip_sec cursor" v-on:click.stop.prevent="openSharingDetails(tr)">
                        <figure class="icons_hover">
                          <img class="default" src="@/assets/images/main/user2.svg" />
                          <img class="hover" src="@/assets/images/main/user2_active.svg" />
                        </figure>
                        <div class="tooltip_cnt">
                          <p >Shared with<strong>{{checkProperty(tr, 'sharedCount')}}</strong>Member(s)</p>
                          
                        </div>
                      </li>
                    </ul>
                  </div>
                </span>
                <!-- <a href="">{{tr.name}}</a> -->
              </vs-td>
              <vs-td>
                {{ tr['size'] | convert_bytes }}
              </vs-td>
              <vs-td class="td_label">
               
                <template v-if="baseFolderName !='Shared With Me'">
                    <template  v-if="checkProperty( tr ,'createdByName')" >
                      {{ tr['createdByName'] }}                      
                        <small v-if="checkProperty( tr ,'createdByRoleName')">{{ tr['createdByRoleName']  }}</small>
                    </template>
                    <template  v-else-if="checkProperty( tr ,'uploadedByName')" >
                      {{ tr['uploadedByName'] }}                      
                        <small v-if="checkProperty( tr ,'uploadedByRoleName')">{{ tr['uploadedByRoleName']  }}</small>
                    </template>
                  </template>
                  <template  v-else-if="checkProperty( tr ,'sharedByName')" >
                    {{ tr['sharedByName'] }}                      
                      <small v-if="checkProperty( tr ,'sharedByRoleName')">{{ tr['sharedByRoleName']  }}</small>
                  </template>
                  
              </vs-td>
                <!-- <vs-td >
               
               <figure class="dp_img"><img src="@/assets/images/main/profile-image.png" class="user-image"/></figure>
               <div>
                Madhu Sanisetty <br/> 
                <span class="user_role">
                Paralegal
              </span>
                </div>
            
            </vs-td> -->
              <vs-td v-if="baseFolderName">
               
                <template v-if="checkProperty(tr, 'updatedOn')">{{
                  tr["updatedOn"] | formatDate
                }}</template>
                <template v-else>{{ tr["createdOn"] | formatDateTime }}</template>
              </vs-td>

              <vs-td>
                <vs-dropdown class="msg_dropdown_icon" :vs-trigger-click="true">
                  <template v-if="tr['type'] != 'baseFolder'">
                    <a class="a-icon" href.prevent
                      ><more-vertical-icon
                        size="1.5x"
                        class="custom-class"
                      ></more-vertical-icon
                    ></a>
                    <vs-dropdown-menu class="loginx msg_dropdown">
                      <vs-dropdown-item
                        v-if="checkProperty(tr, 'type') == 'document' && baseFolderName !='Trash'"
                      >
                         <p v-if="checkProperty(tr, 'favourite')"
                            style="cursor: pionter"
                            v-on:click.stop.prevent="removefavlist(tr)"
                          >
                            Remove from Favourites
                          </p>
                         <p v-if="!checkProperty(tr, 'favourite') && baseFolderName !='Trash'"
                            style="cursor: pionter"
                            v-on:click.stop.prevent="addTofavlist(tr)"
                          >
                            Add to Favourites
                          </p> 
                      </vs-dropdown-item>
                      <vs-dropdown-item
                        v-if="
                        baseFolderName !='Trash' &&
                          [1].indexOf(tr['statusId']) > -1 &&
                         
                          !checkProperty(tr, 'confidential')
                          && baseFolderName != 'Cases'
                        "
                      >
                         <p
                            style="cursor: pionter"
                            v-on:click.stop.prevent="shareMe(tr)"
                          >
                            Share
                          </p> 
                      </vs-dropdown-item>
                      <vs-dropdown-item
                        v-if="checkProperty(tr, 'sharedCount') > 0"
                      >
                        <p
                            style="cursor: pionter"
                            v-on:click.stop.prevent="openSharingDetails(tr)"
                          >
                            Sharing Details
                          </p>
                      </vs-dropdown-item>

                      <vs-dropdown-item v-if=" baseFolderName !='Trash'">
                         <p
                            style="cursor: pionter"
                            v-on:click.stop.prevent="copyMe(tr)"
                          >
                            Copy to clipboard
                          </p>
                      </vs-dropdown-item>

                      <vs-dropdown-item
                        v-if="
                          [1].indexOf(tr['statusId']) > -1 &&
                          checkProperty(tr, 'createdBy') ==
                            checkProperty(getUserData, 'userId')
                            && baseFolderName != 'Cases'
                        "
                      >
                        <p
                            style="cursor: pionter"
                            v-on:click.stop.prevent="openPopUpdateFolder(tr)"
                          >
                            Edit
                          </p> 
                      </vs-dropdown-item>

                      <vs-dropdown-item
                        v-if="checkProperty(tr, 'type') == 'document'"
                      >
                         <p
                            style="cursor: pionter"
                            v-on:click.stop.prevent="download_or_view(tr)"
                          >
                            View
                          </p>
                      </vs-dropdown-item>
                      <vs-dropdown-item
                        v-if="checkProperty(tr, 'type') == 'document'"
                      ><p
                            style="cursor: pionter"
                            v-on:click.stop.prevent="downloads3file(tr)"
                          >
                            Download
                          </p>
                      </vs-dropdown-item>

                      <template
                        v-if="
                          checkProperty(tr, 'createdBy') ==
                          checkProperty(getUserData, 'userId')
                        "
                      >
                        <vs-dropdown-item
                          v-if="[1].indexOf(tr['statusId']) > -1  && baseFolderName != 'Cases' && baseFolderName !='My Favourites' "
                        >
                          <a
                            ><p
                              style="cursor: pionter"
                              v-on:click.stop.prevent="deleteMe(tr, 2)"
                            >
                              Trash
                            </p></a
                          >
                        </vs-dropdown-item>

                        <vs-dropdown-item
                          v-if="[2].indexOf(tr['statusId']) > -1 && baseFolderName !='My Favourites'  "
                        >
                          <a
                            ><p
                              style="cursor: pionter"
                              v-on:click.stop.prevent="deleteMe(tr, 3)"
                            >
                              Delete 
                            </p></a
                          >
                        </vs-dropdown-item>
                        <vs-dropdown-item
                          v-if="baseFolderName =='Trash'"
                        >
                          <a
                            ><p
                              style="cursor: pionter"
                              v-on:click.stop.prevent="deleteMe(tr, 1)"
                            >
                              Restore 
                            </p></a
                          >
                        </vs-dropdown-item>
                      </template>
                    </vs-dropdown-menu>
                  </template>
                  <template v-else>
                    <a  class="a-icon" href.prevent><more-vertical-icon size="1.5x" class="custom-class disbleMenu"  ></more-vertical-icon
                    ></a>
                  </template>
                </vs-dropdown>
              </vs-td>
            </vs-tr>
          </template>
        </template>
      </vs-table>
     
      
    </div>
    <NoDataFound
      ref="NoDataFoundRef"
      :loading="!contentLoaded"
      v-if="documentsList.length == 0"
      content=""
      :heading="
        callFromSerch
          ? 'No Results Found'
          : 'No Documents Found'
      "
      type="documents"
    /> 
    <div class="table_footer doc_pagination">
      <template v-if="totalpages>0">
        <div class="vx-col con-select pages_select" v-if="documentsList.length > 0 && totalpages>page">
          <label class="typo__label">Per Page</label>
          <multiselect @input="pageNate(page)" v-model="perpage" :options="perPeges" :multiple="false"
            :close-on-select="true" :clear-on-select="false" :preserve-search="true" placeholder="Per Page"
            :preselect-first="true">
          </multiselect>
        </div>
        <paginate
          
          v-model="page"
          :page-count="totalpages"
          :page-range="3"
          :margin-pages="2"
          :click-handler="pageNate"
          prev-class="vs-pagination--buttons btn-prev-pagination vs-pagination--button-prev"
          next-class="vs-pagination--buttons btn-next-pagination vs-pagination--button-next"
          :prev-text="'<i></i>'"
          :next-text="'<i></i>'"
          :container-class="'pagination vs-pagination--nav'"
          :page-class="'page-item'"
        ></paginate>
      </template>
    </div>
    <vs-popup
      class="holamundo main-popup"
      title="Create Folder"
      v-if="addNew"
      :active.sync="addNew"
    >
      <addNewFolder
        v-if="addNew"
        :baseFolderName="baseFolderName"
        @closePopup="closePopup"
        :selectedItem="selectedItem"
        :myDrive="myDrive"
      />
    </vs-popup>

    <vs-popup
      class="holamundo main-popup"
      title="Sharing"
      v-if="openShareMePopup"
      :active.sync="openShareMePopup"
    >
      <sharing
        :baseFolderName="baseFolderName"
        v-if="openShareMePopup"
        @closePopup="closeSharing"
        :selectedItem="selectedforSharing"
        :myDrive="myDrive"
      />
    </vs-popup>

    <vs-popup
      class="holamundo main-popup"
      title="Update"
      v-if="openUpdateFolder"
      :active.sync="openUpdateFolder"
    >
      <updateFolder
      :baseFolderName="baseFolderName"
        v-if="openUpdateFolder"
        @closePopup="closeUpdateFolder"
        :selectedItem="selectedFroUpdate"
        :myDrive="myDrive"
      />
    </vs-popup>

    <modal
      name="sahringDetailsPopup"
      classes="v-modal-sec"
      :min-width="200"
      :min-height="200"
      :scrollable="true"
      :reset="true"
      width="600px"
      height="auto"
    >
      <div class="v-modal">
        <div class="popup-header fromDetailsPage">
          <h2 class="popup-title">Sharing Details</h2>
          <span @click="closeSharingDetails()">
            <em class="material-icons">close</em>
          </span>
        </div>
        <sharingDetails
          v-if="openPopupSharingDetails"
          @closePopup="closeSharingDetails"
          :selectedItem="selectedforSharing"
          :baseFolderName="baseFolderName"
        />
      </div>
    </modal>

    <modal
      name="addDocumentPopup"
      classes="v-modal-sec"
      :min-width="200"
      :min-height="200"
      :scrollable="true"
      :reset="true"
      width="600px"
      height="auto"
    >
      <div class="v-modal">
        <div class="popup-header fromDetailsPage">
          <h2 class="popup-title">Upload Files</h2>
          <span @click="closeAddDocPopup()">
            <em class="material-icons">close</em>
          </span>
        </div>
        <div class="add_doc_wrap">
        <addDocument
          :baseFolderName="baseFolderName"
          v-if="openAddDoc"
          @closePopup="closeAddDocPopup"
          :selectedItem="selectedItem"
          :myDrive="myDrive"
        />
        </div>
      </div>
    </modal>

    <vs-popup class="document_modal document_modal-v2" 
    :class="{ expand: expandModal }"
    :title="checkProperty(selectedFile,'name')"  :active.sync="docPrivew">
    <div class="document_actions" @click="expandModal = !expandModal">
      <figure v-if="!expandModal" class="maximize-img"><img src="@/assets/images/maximize.png"  width="18" height="18"/></figure>
      <figure v-else class="minimize-img"><img src="@/assets/images/minimize.png"  width="20" height="20"/></figure>
    </div>
      <h2></h2>
      <div class="">
        <img
          :class="{
            pdf_view_download: docType == 'pdf',
            office_view_download: docType == 'office',
            image_view_download: docType == 'image',
          }"
          class="download-button"
          @click="downloads3file(selectedFile)"
          src="@/assets/images/download.svg"
        />
        <!-- <span :class="{'pdf_view_close':docType == 'pdf', 'office_view_close':docType == 'office'  , 'image_view_close 33':docType =='image'}" class="close close2" @click="docPrivew= false"></span> -->
        <template v-if="docType == 'office'">
          <VueDocPreview :value="docValue" type="office" />
        </template>
        <template v-else-if="docType == 'image'">
          <img :src="docValue" />
        </template>
        <template v-else-if="docType == 'pdf'">
          <div class="pdf" style="height: 90vh">
            <!-- <object
              :data="docValue"
              type="application/pdf"
              width="1000"
              height="600"
              v-if="docPrivew"
            >
              alt : <a :href="docValue">PDF</a>
            </object> -->
            <iframe
              v-if="docValue != '' && docPrivew"
              border="0"
              style="border: 0px"
              :src="docValue"
              height="100%"
              width="100%"
            >PDF</iframe>
          </div>
        </template>
      </div>
    </vs-popup>
  </div>
</template>

<script>

import sharingDetails from "@/views/documents/sharingDetails.vue";

import updateFolder from "@/views/documents/updateFolder.vue";
import addDocument from "@/views/documents/addDocument.vue";
import addNewFolder from "@/views/documents/addNewFolder.vue";

import sharing from "@/views/documents/sharing.vue";
import * as _ from "lodash";
import DateRangePicker from "vue2-daterange-picker";
import Datepicker from "vuejs-datepicker-inv";
import Paginate from "vuejs-paginate";
import "vue2-daterange-picker/dist/vue2-daterange-picker.css";

import { FormWizard, TabContent } from "vue-form-wizard";
import "vue-form-wizard/dist/vue-form-wizard.min.css";
import moment from "moment";
import PhoneMaskInput from "vue-phone-mask-input";
//import JQuery from 'jquery'
import { TheMask } from "vue-the-mask";
import { MoreVerticalIcon } from "vue-feather-icons";
import VuePhoneNumberInput from "vue-phone-number-input";
import "vue-phone-number-input/dist/vue-phone-number-input.css";
import NoDataFound from "@/views/common/noData.vue";
import Vue from "vue";
import VueCryptojs from "vue-cryptojs";
import VueDocPreview from 'vue-doc-preview'
Vue.use(VueCryptojs);
export default {
  components: {
    VueDocPreview,
    sharingDetails,
    updateFolder,
    addDocument,
    addNewFolder,
    sharing,
    NoDataFound,
    Datepicker,
    Paginate,
    DateRangePicker,
    FormWizard,
    TabContent,
    PhoneMaskInput,
    TheMask,
    VuePhoneNumberInput,
    MoreVerticalIcon,
  },
  computed: {
    getCount(){
    return (item ,category='')=>{
        //baseFolderCount
        /*
          {"name": "My Drive", "type": "baseFolder", "displayName": "My Drive", "_id": 0 },
          { "name": "Cases","type": "baseFolder", "displayName": "Cases",  "_id": 1},
          { "name": "Shared With Me","type": "baseFolder", "displayName": "Shared With Me", "_id": 2},
          { "name": "My Favourites", "type": "baseFolder", "displayName": "My Favourites", "_id": 3},
          { "name": "Trash","type": "baseFolder", "displayName": "Trash","_id": 4},
          {"name": "Common","type": "baseFolder", "displayName": "Common", "_id": 5}

        */
       let returnValue =0
          if(item['_id'] ==0){
            
            if(category=='folders'){
              returnValue =_.get(this.baseFolderCount ,"myDrive.folders" ,0);
            }else if(category=='files'){
              returnValue =_.get(this.baseFolderCount ,"myDrive.files" ,0);
            }

          }else if(item['_id'] ==1){
            if(category=='folders'){
              returnValue =_.get(this.baseFolderCount ,"cases.folders" ,0);
          }else if(category=='files'){
            returnValue =_.get(this.baseFolderCount ,"cases.files" ,0);

          }

          }else if(item['_id'] ==2){
            if(category=='folders'){
              returnValue =_.get(this.baseFolderCount ,"sharedWithMe.folders" ,0);
          }else if(category=='files'){
            returnValue =_.get(this.baseFolderCount ,"sharedWithMe.files" ,0);

          }

          }else if(item['_id'] ==3){
            if(category=='folders'){
              returnValue =_.get(this.baseFolderCount ,"myFavourites.folders" ,0);
          }else if(category=='files'){
            returnValue =_.get(this.baseFolderCount ,"myFavourites.files" ,0);

          }

          }else if(item['_id'] ==4){
            if(category=='folders'){
              returnValue =_.get(this.baseFolderCount ,"trash.folders" ,0);
          }else if(category=='files'){
            returnValue =_.get(this.baseFolderCount ,"trash.files" ,0);

          }

          }else if(item['_id'] ==5){
            if(category=='folders'){
              returnValue =_.get(this.baseFolderCount ,"common.folders" ,8);
          }else if(category=='files'){
            returnValue =_.get(this.baseFolderCount ,"common.files" ,10);

          }

          }
       return returnValue;
      }
    },
    checkFileType(){
      //documentsList tr['type'] != 'document'
      return (category='document')=>{
        let list = _.filter(this.documentsList, { "type":category });
        return list && list.length >0;
      }
    },
    showPagenation() {
      let returnValue = false;
      if (["My Favourites"].indexOf(this.baseFolderName) > -1) {
        returnValue = true;
      }

      return returnValue;
    },
    //(this.getUserRoleId ==3 && this.selectedBranch && _.has(this.selectedBranch , "_id"))
  },
  data: () => ({
    expandModal: false,
    baseFolderCount:{},
    selectedFile:null,
    docPrivew: false,
    docValue: "",
    docType: "",
    screateKey: "fdshdfd1234567@#$%^&",
    selectedFroUpdate: null,
    breadcrumbs: [],
    baseFolderName: "",
    openAddDoc: false,
    openPopupSharingDetails: false,
    openUpdateFolder: false,
    callFromSerch: false,
    selectedItem: null,
    contentLoaded: false,
    sortKeys: {},
    sortKey: {},
    selected_createdDateRange: ["", ""],
    documentsList: [],
    addNew: false,
    totalRecords:0,
    date_range: [],
    page: 1,
    perPeges: [10, 25, 50, 75, 100 ,150,200],
    perpage: 25,
    totalpages: 0,
    autoApply: false,
    searchtxt: "",
    selectedItem: null,
    openShareMePopup: false,
    folderDetails: null,
    defaultFolders: [],
    myDrive: false,
    selectedforSharing: null,
    statusIdsList: [],
    selectedStatusIds: [],
    filderPath: "",
    debounce:null,
  }),
  watch: {
    addNew: function (value) {
      if (!value && this.checkProperty(this.selectedItem, "type") != "folder") {
        // this.selectedItem =null;
      }
    },
    openShareMePopup: function (value) {
      if (!value) {
        this.selectedforSharing = null;
        this.$modal.hide("sahringDetailsPopup");
      }
    },
    openPopupSharingDetails: function (value) {
      if (!value) {
        this.selectedforSharing = null;
      }
    },
    openUpdateFolder: function (value) {
      if (!value) {
        this.selectedFroUpdate = null;
      }
    },
    searchtxt: function (value) {
      //this.getdocumentsList(true);
      this.searchMe();
    },
  },
  methods: {
    searchMe(){
    let self =this;
    clearTimeout(this.debounce)
      this.debounce = setTimeout(() => {
        self.getdocumentsList(true);
      }, 900)

     //self.getGlobalSearch(true);

    
      },
    getBaseFoldersCount(){
      let url ="/documents/get-root-folder-stats";
       let postData ={};
      this.$store.dispatch("commonAction" ,{data:postData,path:url})
        .then(response => {
        //  ,'folderCount":0, "fileCount":0
         this.baseFolderCount =response;
         if(this.documentsList.length>0){
          _.map(this.documentsList ,(item)=>{

            if(item['_id'] ==0){
              item['folderCount'] =_.get(this.baseFolderCount ,"myDrive.folders" ,0);
              item['fileCount'] =_.get(this.baseFolderCount ,"myDrive.files" ,0);
             
          
             
            

          }else if(item['_id'] ==1){
            item['folderCount'] =_.get(this.baseFolderCount ,"cases.folders" ,0);
            item['fileCount'] =_.get(this.baseFolderCount ,"cases.files" ,0);
            

          }else if(item['_id'] ==2){
            
          item['folderCount'] =_.get(this.baseFolderCount ,"sharedWithMe.folders" ,0);
          item['fileCount'] =_.get(this.baseFolderCount ,"sharedWithMe.files" ,0);

          }else if(item['_id'] ==3){
            item['folderCount'] =_.get(this.baseFolderCount ,"myFavourites.folders" ,0);
            item['fileCount'] =_.get(this.baseFolderCount ,"myFavourites.files" ,0);
           

          }else if(item['_id'] ==4){

            item['folderCount'] =_.get(this.baseFolderCount ,"trash.folders" ,0);
            item['fileCount'] =_.get(this.baseFolderCount ,"trash.files" ,0);
            

          }else if(item['_id'] ==5){
            
            item['folderCount'] =_.get(this.baseFolderCount ,"common.folders" ,0);
            item['fileCount'] =_.get(this.baseFolderCount ,"common.files" ,0);

          }

          })
          this.documentsList =_.cloneDeep(this.documentsList);

         }

            
        }).catch((err)=>{
            
          
        })
    },
    changedBreadcrumb(breadcrumb) {
       this.$router.replace({'query': null});
      if (this.checkProperty(breadcrumb, "_id") == -1) {
        this.init();
      } else {

        let findIndex = _.findIndex(this.breadcrumbs, {
          _id: breadcrumb["_id"],
        });

        let tempBreadcrumbs = [];
        if (findIndex > -1) {
          _.forEach(this.breadcrumbs, (item, index) => {
            if (index <= findIndex) {
              tempBreadcrumbs.push(item);
            }
          });
        }
        this.breadcrumbs = tempBreadcrumbs;
        this.gotoSubFolder(breadcrumb, true);
       
      }
    },

    gotoSubFolder(tr, callFromBredCumbs = false) {
     this.$router.replace({'query': null});
      this.page = 1;
      this.perpage = 25;
      this.totalpages =0;
      this.searchtxt = "";
      this.selected_createdDateRange["startDate"] = "";
      this.selected_createdDateRange["endDate"] = "";
      this.selectedStatusIds = [];
      this.selectedStatusIds = [];

      if (this.checkProperty(tr, "type") == "baseFolder") {
        this.myDrive = false;
        if (this.checkProperty(tr, "_id") == 0) {
         
          this.myDrive = true;
        }
        this.baseFolderName = tr["name"];
        this.selectedItem = null;

        if (this.baseFolderName == "Common") {
          
            this.selectedItem = null;
            let commonFolder ={
              "type":"folder",
              "_id":'',
              "displayName":'Common',
              "name":'Common',

            };
           
            // if([3,4,5,6,7,8,9,10,11,12,13,14].indexOf(this.getUserRoleId)>-1 && this.checkProperty(this.getUserData, 'branchDetails',"docFolderId")){
            //   //branch Users
            
            //   commonFolder['_id'] = this.checkProperty(this.getUserData, 'branchDetails',"docFolderId");

            // }else if([50].indexOf(this.getUserRoleId)>-1 && this.checkProperty(this.getUserData, 'companyDetails',"docFolderId")){
            //    commonFolder['_id'] = this.checkProperty(this.getUserData, 'companyDetails',"docFolderId");
            // }else if([51].indexOf(this.getUserRoleId)>-1 && this.checkProperty(this.getUserData,"docFolderId")){
            //    commonFolder['_id'] = this.checkProperty(this.getUserData, "docFolderId");
            // }else if([3].indexOf(this.getUserRoleId)>-1 && this.checkProperty(this.getUserData, 'tenantDetails',"docFolderId")){
            //    commonFolder['_id'] = this.checkProperty(this.getUserData,"tenantDetails", "docFolderId");
            // }
            if([3,4,5,6,7,8,9,10,11,12,13,14 ,50,51].indexOf(this.getUserRoleId)>-1 && this.checkProperty(this.getUserData, 'tenantDetails',"docFolderId")){
               commonFolder['_id'] = this.checkProperty(this.getUserData,"tenantDetails", "docFolderId");
            }

            if(this.checkProperty(commonFolder ,"_id") !=''){
              this.selectedItem = commonFolder;
            }
            

        } 
        if (this.baseFolderName == "Cases") {
          this.selectedItem = null;
            let commonFolder ={
              "type":"folder",
              "_id":'',
              "displayName":'Cases',
              "name":'Cases',

            };

          if([50].indexOf(this.getUserRoleId)>-1 && this.checkProperty(this.getUserData, 'companyDetails',"docFolderId")){
               commonFolder['_id'] = this.checkProperty(this.getUserData, 'companyDetails',"docFolderId");
            }else if([51].indexOf(this.getUserRoleId)>-1 && this.checkProperty(this.getUserData,"docFolderId")){
               commonFolder['_id'] = this.checkProperty(this.getUserData, "docFolderId");
            }else if([3,4,5,6,7,8,9,10,11,12,13,14].indexOf(this.getUserRoleId)>-1 && this.checkProperty(this.getUserData,"tenantDetails", "docFolderId")){
              //branch Users
            
              commonFolder['_id'] = this.checkProperty(this.getUserData, "tenantDetails","docFolderId");

            }
            if(this.checkProperty(commonFolder ,"_id") !=''){
              this.selectedItem = commonFolder;
            }

        }
        this.getdocumentsList(false,tr);
      } else {

        if (this.baseFolderName == "Cases") {
          this.myDrive = false;
        }
 
        if (this.checkProperty(tr, "type") == "folder") {
          this.selectedItem = tr;
            
         
          
          
          this.getdocumentsList();
        }
      }
      let findItem = _.find(this.breadcrumbs, { '_id': tr["_id"] });

    
      if (
        !callFromBredCumbs && this.checkProperty(tr, "type") != "document" &&  !findItem
      ) {
        this.breadcrumbs.push(tr);
      }

     
     

    

    this.genareteUrl(tr ,false)
     
    },
      genareteUrl(item ,copyToClip=true) {
      
       this.$router.push({ query: null })
       let self = this;
              
      this.filderPath = "";
      let text = "?myDrive=" + this.myDrive + "&baseFolderName=" + this.baseFolderName;

       let Obj = {};
       Obj['myDrive'] = self.myDrive;
      Obj['baseFolderName'] = self.baseFolderName;
      if(self.checkProperty(self.selectedItem ,"_id") && self.checkProperty(self.selectedItem ,"displayName") && self.checkProperty(self.selectedItem ,"type") ){

      
      Obj['selectedItemId'] = self.checkProperty(self.selectedItem ,"_id");
      Obj['selectedItemName'] = self.checkProperty(self.selectedItem ,"displayName");
      Obj['selectedItemType'] = self.checkProperty(self.selectedItem ,"type");
     } 

      
     
  //  alert(JSON.stringify(item))
      if (self.checkProperty(self.breadcrumbs, "length") > 0) {
        
          _.forEach(self.breadcrumbs, (breadcrum, index) => {
           

            let displayName = self.checkProperty(breadcrum, "name");
            if(self.checkProperty(breadcrum, "displayName")){
            displayName = self.checkProperty(breadcrum, "displayName")
            }
            let  id =self.checkProperty(breadcrum, "_id")
            let  type =self.checkProperty(breadcrum, "type")


              let tmp =  "&bredCumbId_"+index+"="+id+"&bredCumbName_"+index+"="+displayName+"&bredCumbType_"+index+"="+type;
              text = text + tmp;
             

              Obj['bredCumbId_'+index] =id;
              Obj['bredCumbName_'+index] =displayName;
              Obj['bredCumbType_'+index] =type;
            
             
             
          });
         
          Obj['page'] =self.page;
          Obj['perpage'] =self.perpage;
          Obj['totalpages'] =self.totalpages;


      }

      self.$router.push({ query: Obj })
     
      

      

      // this.$router.push("/documents"+text);
    },
   async copyMe(item ,copyToClip=true){
      
       this.filderPath = window.location.href;
     let self =this;
       if(copyToClip){
            try {
              await navigator.clipboard.writeText(self.filderPath);
              
                  this.showToster({  message: "Folder path Copied successfully ", isError: false, });
                this.filderPath = "";

            
            
            } catch ($e) {
              
              this.filderPath = "";
              this.showToster({  message: "Con't Copied folder path! ", isError: true,   });
            
            }
    }
    },
    download_or_view(value) {
      this.expandModal= false;
      if (_.has(value, "path")) {
        value["url"] = value["path"];
        value["document"] = value["path"];
      }

      if (_.has(value, "url")) {
        value["path"] = value["url"];
        value["document"] = value["url"];
      }

      if (_.has(value, "document")) {
        value["path"] = value["document"];
        value["url"] = value["document"];
      }

      this.selectedFile = value;
      this.docValue = "";
      this.docPrivew = false;
      this.docType = false;
      this.docType = this.findmsDoctype(value);

      if (this.docType == "office" || this.docType == "image" || this.docType == "pdf") {
        value.url = value.url.replace(this.$globalgonfig._S3URL, "");
        value.url = value.url.replace(this.$globalgonfig._S3URLAWS, "");
        let postdata = {
          keyName: value.url,
        };
        this.$store.dispatch("getSignedUrl", postdata).then((response) => {
          this.docValue = response.data.result.data;

          if (this.docType == "office") {
            this.docValue = encodeURIComponent(response.data.result.data);
          }
          if (this.docType == "pdf") {
            var _vid = value._id;
            if (value.parentId) {
              _vid = value.parentId;
            }
            var  viewmode = 0; //viewmode= 1 Enable edit AND viewmode= 0; //Disabled Edit
            let pdfViewUrl ='https://immibox.com/viewer/pdfjs-dist/web/viewerv2.html';
            if(viewmode == 0){
              if(_.has(this.$globalgonfig, 'PDF_VIEW_URL')){
                  pdfViewUrl = this.$globalgonfig['PDF_VIEW_URL'];
              }

            }else if(viewmode == 1){
              if(_.has(this.$globalgonfig, 'PDF_EDIT_URL')){
                  pdfViewUrl = this.$globalgonfig['PDF_EDIT_URL'];
              }

            }
           
            
           
            this.docValue =
              pdfViewUrl+"?view=" +
              viewmode +
              "+&file=" +
              encodeURIComponent(response.data.result.data);
          }
          this.docPrivew = true;
        });
      } else {
        this.downloads3file(value);
      }
    },

   
    deleteMe(item, statusId = 1) {
      let postData = {
        documentId: item["_id"],
        statusId: statusId,
      };
      let path = "/documents/manage-status";
      if (item["type"] != "document") {
        path = "documents/manage-folder-status";
        postData = {
          folderId: item["_id"],
          statusId: statusId,
        };
      }

      this.$store
        .dispatch("commonAction", {
          data: postData,
          path: path,
        })
        .then((response) => {
          this.showToster({ message: response.message, isError: false });
          this.closePopup();
          this.getdocumentsList();
        })
        .catch((err) => {
          this.showToster({ message: err, isError: false });
        });
    },
    removefavlist(item) {
      let query = {
        type: "",
        documentId: "",
        folderId: "",
      };

      query["type"] = item["type"];
      query["documentId"] = item["_id"];
      query["folderId"] = item["_id"];

      this.$store
        .dispatch("commonAction", {
          data: query,
          path: "/documents/manage-favorite",
        })
        .then((response) => {
          this.showToster({ message: response.message, isError: false });
          this.getdocumentsList();
        })
        .catch((err) => {
          this.showToster({ message: err, isError: true });
        });
    },
    addTofavlist(item) {
      ///documents/manage-favorite
      let query = {
        type: "",
        documentId: "",
        folderId: "",
      };

      query["type"] = item["type"];
      query["documentId"] = item["_id"];
      query["folderId"] = item["_id"];

      this.$store
        .dispatch("commonAction", {
          data: query,
          path: "/documents/manage-favorite",
        })
        .then((response) => {
          this.showToster({ message: response.message, isError: false });
          this.getdocumentsList();
        })
        .catch((err) => {
          this.showToster({ message: err, isError: true });
        });
    },
    
    closeAddDocPopup() {
      this.openAddDoc = false;
      
      this.$modal.hide("addDocumentPopup");
      this.getdocumentsList();
    },
    openAddDocPopup() {
      this.openAddDoc = true;
      this.$modal.show("addDocumentPopup");
    },
    
    openSharingDetails(item) {
      this.openPopupSharingDetails = true;
      this.selectedforSharing = item;
      this.$modal.show("sahringDetailsPopup");
    },
    closeSharingDetails() {
      this.openPopupSharingDetails = false;
      if (this.checkProperty(this.selectedItem, "type") != "folder") {
        this.selectedItem = null;
      }
      this.$modal.hide("sahringDetailsPopup");
      this.getdocumentsList();
    },

    closeUpdateFolder() {
      this.openUpdateFolder = false;
      if (this.checkProperty(this.selectedItem, "type") != "folder") {
        this.selectedItem = null;
      }
      this.getdocumentsList();
    },
    openPopUpdateFolder(item) {
      this.openUpdateFolder = true;
      this.selectedFroUpdate = item;
    },
    getFolderDetails() {
      ///documents/folder-details
      this.folderDetails = null;
      let postData = {
        folderId: "",
      };
      postData["folderId"] = this.selectedItem["_id"];
      this.$store
        .dispatch("commonAction", {
          data: postData,
          path: "documents/folder-details",
        })
        .then((response) => {
          this.folderDetails = response;
        })
        .catch((err) => {});
    },

    closeSharing() {
      this.selectedforSharing = null;

      this.openShareMePopup = false;
      this.getdocumentsList();
    },
    shareMe(item) {
      this.selectedforSharing = item;
      this.openShareMePopup = true;
    },
    openNewfolder() {
      this.addNew = true;
    },
    closePopup(data) {
      this.addNew = false;
      this.getdocumentsList();
    },
    sortMe(sort_key = "") {
      if (sort_key != "") {
        this.sortKeys[sort_key] = this.sortKeys[sort_key] == 1 ? -1 : 1;
        this.sortKey = {};
        this.sortKey = { path: sort_key, order: this.sortKeys[sort_key] };

        this.getdocumentsList();
      }
    },

    getdocumentsList(callFromSerch = false,tr=null) {
      // if(this.baseFolderName =="My Favourites"){
      //   this.getFavList();
      //  return
      // }
      let item = tr;
      this.callFromSerch = callFromSerch;
      this.contentLoaded = false;
      this.updateLoading(true);
      
        this.documentsList = [];
  
//alert(JSON.stringify(this.selectedItem))
      let matcher = {
        title: this.searchtxt,
        tenantId: "",
        branchId: "", // Requied while sending "myDrive" as false
        companyId: "", // Requied while sending "myDrive" as false
        bnfId: "", // Requied while sending "myDrive" as false
        parentId: "",
        statusIds: [], // 1. Active 2. Trash 3. Delete,
        myDrive: false, // "true" for get My drive folders
       
      };
    //   if (_.has(this.$route.query, "baseFolderName")) {
    //   this.baseFolderName = this.$route.query["baseFolderName"];
    // }|| (_.has(this.$route.query, "baseFolderName") && this.checkProperty(this.$route.query,'baseFolderName') == 'Cases' )
    // if((_.has(this.$route.query, "baseFolderName") && this.checkProperty(this.$route.query,'baseFolderName') == 'Cases' )){
    //   alert(1)
    // }
      if((item && this.checkProperty(item,'name') == 'Cases') || (_.has(this.$route.query, "baseFolderName") && this.checkProperty(this.$route.query,'baseFolderName') == 'Cases' )  ){
        if(this.getUserRoleId == 3 && this.checkProperty(this.getUserData,'docFolderId')){
          matcher['parentId'] =this.checkProperty(this.getUserData,'docFolderId')
        }
        if(this.getUserRoleId == 50){
          matcher['parentId'] = ''
        }
        if(this.getUserRoleId == 51){
          matcher['parentId'] = ''
        }
      }
      if (this.checkProperty(this.selectedStatusIds, "length") > 0) {
        matcher["statusIds"] = this.selectedStatusIds.map((item) => item["id"]);
      }
      matcher["myDrive"] = this.myDrive;

      if (this.checkProperty(this.selectedItem, "type") == "folder") {
        matcher["parentId"] = this.selectedItem["_id"];
      }

      if (
        this.selected_createdDateRange["startDate"] &&
        this.selected_createdDateRange["startDate"] != "" &&
        this.selected_createdDateRange["endDate"] != "" &&
        this.selected_createdDateRange["endDate"]
      ) {
        matcher["createdDateRange"] = [
          this.selected_createdDateRange["startDate"],
          this.selected_createdDateRange["endDate"],
        ];
      }

      let query = {};
      query["page"] = this.page;
      query["perpage"] = this.perpage;
      query["filters"] = matcher;
      query["sorting"] = this.sortKey;
      //alert( JSON.stringify(query['sorting']))
      let path = "/documents/folders-and-files";
      if (this.baseFolderName == "Shared With Me") {
        path = "/documents/shared-folders-and-files";
      } else if (this.baseFolderName == "My Favourites") {
        path = "/documents/favorite-folders-and-files";
      } else if (this.baseFolderName == "Trash") {
        matcher["statusIds"] = [2];
      } else if (this.baseFolderName == "Cases") {
        this.myDrive = false;
        
        query["filters"]["myDrive"] = false;
        matcher["statusIds"] = [];
      } else if (this.baseFolderName == "Common") {
        //alert("sfsfdsf") //getCommonFolder
        query['filters']['getCommonFolder'] =true;
        if (!this.checkProperty(query, "filters", "parentId")) {
         
          //get parent id from  login details
        }
        
      }
      
      if(this.checkProperty( this.getUserData,'tenantId') ){

        query['filters']['tenantId'] = this.getUserData['tenantId'];
      }

      this.$store
        .dispatch("getList", { data: query, path: path })
        .then((response) => {
          //this.getBaseFoldersCount();
          this.updateLoading(false);
          let tempList = [];
          if (this.checkProperty(response, "list", "length") > 0) {
            let foldersList = response.list;

            _.forEach(foldersList, (item) => {
              if(!_.has(item ,'displayName' )){
                item = Object.assign(item, { 'displayName': item["name"]  });
              }
              item = Object.assign(item, { type: "folder"  });
              if(item['entityType']=='Folder'){
                item['type'] = 'folder';
                tempList.push(item);
              }
              if(item['entityType']=='Document'){
                item['type'] = 'document';
                tempList.push(item);
              }
              
             
              
            });
          }
          if (this.checkProperty(response, "documentList", "length") > 0 ) {
            let foldersList = response.documentList;
            _.forEach(foldersList, (item) => {
              item = Object.assign(item, { type: "document" });
              if( !_.has( item ,'favourite')){
                item = Object.assign(item, { 'favourite': false });
              }
              tempList.push(item);
            });
          }
         if( _.has(response ,'totalCount')){
          this.totalpages = Math.ceil(response.totalCount / this.perpage);
         }
          this.documentsList = tempList;
          this.contentLoaded = true;

         
          setTimeout(() => {
            this.updateLoading(false);
          }, 5);
          this.updateLoading(false);
          //alert(this.perpage);
          
        })
        .catch((err) => {
          this.documentsList = [];
          setTimeout(() => {
            this.updateLoading(false);
          }, 5);
        });
    },

    set_filter: function () {
      this.$refs["filter_menu"].dropdownVisible = false;

      this.getdocumentsList(true);
    },
    clear_filter: function () {
      this.page = 1;
      this.perpage = 25;
      this.searchtxt = "";
      this.$refs["filter_menu"].dropdownVisible = false;

      this.selected_createdDateRange["startDate"] = "";
      this.selected_createdDateRange["endDate"] = "";
      this.selectedStatusIds = [];

      this.getdocumentsList();
    },
    pageNate(pageNum) {
      this.page = pageNum;
     // this.genareteUrl(this.selectedItem,false);
      this.getdocumentsList();
    },
    init() {
      this.selectedforSharing = null;
      this.baseFolderName = "";
      this.selectedItem = null;
      this.sortKey = { path: "createdOn", order: -1 };
      this.sortKeys = {
        createdOn: -1,
        invitedByName: 1,
        updatedOn: 1,
        name: 1,
        email: 1,
        phone: 1,
        statusName: 1,
        roleName: 1,
      };
       this.breadcrumbs = [{ name: "/", type: "", displayName: "Documents", _id: -1 }];
      this.documentsList = [
        {
          name: "My Drive",
          type: "baseFolder",
          displayName: "My Drive",
          _id: 0,
        },
        { name: "Cases", type: "baseFolder", displayName: "Cases", _id: 1 },
        { name: "Common", type: "baseFolder", displayName: "Common", _id: 5 },
        { name: "Shared With Me", type: "baseFolder", displayName: "Shared With Me", _id: 2 },
        {
          name: "My Favourites",
          type: "baseFolder",
          displayName: "My Favourites",
          _id: 3,
        },
        { name: "Trash", type: "baseFolder", displayName: "Trash", _id: 4 },
      ];

      if ([1, 2].indexOf(this.getUserRoleId) > -1) {
        this.documentsList = _.filter(this.documentsList, (item) => {
          return item["name"] != "Cases" && item["type"] == "baseFolder";
        });
      }
    },

    getFavList() {
      let path = "documents/favorite-list";

      let query = {
        page: 1,
        perpage: 25,
        filters: {
          title: "",
        },
        sorting: {
          path: "createdOn", // name, createdByName
          order: -1,
        },
      };
      query["filters"]["title"] = this.searchtxt;
      query["page"] = this.page;
      query["page"] = this.perpage;
      query["sorting"] = this.sortKey;

      this.$store
        .dispatch("getList", { data: query, path: path })
        .then((response) => {
          this.updateLoading(false);
          let tempList = [];
          // if(this.checkProperty(response ,'folderList' ,'length')>0){

          //    let foldersList  = response.folderList;

          //    _.forEach(foldersList , (item)=>{

          //      item = Object.assign(item,{ "type":"folder"})
          //      tempList.push(item)

          //    })

          // }
          if (this.checkProperty(response, "list", "length") > 0) {
            let foldersList = response.list;
            _.forEach(foldersList, (item) => {
              item = Object.assign(item, { type: "document" });
              tempList.push(item);
            });
          }

          this.documentsList = tempList;
          this.contentLoaded = true;

          this.totalpages = Math.ceil(response.totalCount / this.perpage);
          setTimeout(() => {
            this.updateLoading(false);
          }, 10);
          this.updateLoading(false);
          //alert(this.perpage);
        })
        .catch((err) => {
          this.documentsList = [];
          setTimeout(() => {
            this.updateLoading(false);
          }, 10);
        });
    },
  },

  mounted() {
    if([50,51].indexOf(this.getUserRoleId) >-1){
      this.showToster({  message:"You do not have permissions to access this page.", isError: true });
      this.$router.push("/dashboard");

    }
    if(this.checkProperty(this.$route, "query" ,'page') >0){
        this.page = parseInt(this.checkProperty(this.$route, "query" ,'page'));
    }
    if(this.checkProperty(this.$route, "query" ,'perpage')>0){
        this.perpage = parseInt(this.checkProperty(this.$route, "query" ,'perpage'));
    }
    if(this.checkProperty(this.$route, "query" ,'perpage') >0){
        this.totalpages = parseInt(this.checkProperty(this.$route, "query" ,'totalpages'));
    }
   
     //this.init();
    let self = this;
    this.screateKey = "fdshdfd1234567@#$%^&";
    this.statusIdsList = [
      { name: "Active", id: 1 },
      { name: "Trash", id: 2 },
      { name: "Delete", id: 3 },
    ];
    this.selectedStatusIds = [];
    this.baseFolderName = "";
     this.breadcrumbs = [{ name: "/", type: "", displayName: "Documents", _id: -1 }];
    this.documentsList = [
      { name: "My Drive", type: "baseFolder", displayName: "My Drive", _id: 0 ,"folderCount":0, "fileCount":0 },
      { name: "Cases", type: "baseFolder", displayName: "Cases", _id: 1,"folderCount":0, "fileCount":0 },
      { name: "Common", type: "baseFolder", displayName: "Common", _id: 5 ,"folderCount":0, "fileCount":0},
      { name: "Shared With Me", type: "baseFolder", displayName: "Shared With Me", _id: 2,"folderCount":0, "fileCount":0 },
      {  name: "My Favourites",   type: "baseFolder",   displayName: "My Favourites",   _id: 3,"folderCount":0, "fileCount":0  },
      { name: "Trash", type: "baseFolder", displayName: "Trash", _id: 4,"folderCount":0, "fileCount":0 },
    ];

    if ([1, 2].indexOf(this.getUserRoleId) > -1) {
      this.documentsList = _.filter(this.documentsList, (item) => {
        return item["name"] != "Cases" && item["type"] == "baseFolder";
      });
    }

    if (_.has(this.$route.query, "myDrive")) {
      if(this.$route.query["myDrive"] =='false' || this.$route.query["myDrive"] ==false){
        this.myDrive =false;
      }else if(this.$route.query["myDrive"] =='true' || this.$route.query["myDrive"] ==true){
        this.myDrive =true;
      }
      
    }

    if (_.has(this.$route.query, "baseFolderName")) {
      this.baseFolderName = this.$route.query["baseFolderName"];
    }
    if (
      _.has(this.$route.query, "selectedItemId") &&
      _.has(this.$route.query, "selectedItemName") &&
      _.has(this.$route.query, "selectedItemType")
    ) {
      this.selectedItem = {
        _id: self.$route.query["selectedItemId"],
        name: self.$route.query["selectedItemName"],
        type: self.$route.query["selectedItemType"],
      };
      //alert(JSON.stringify(this.selectedItem))
    }
    if (this.checkProperty(this.$route, "query")) {
        this.breadcrumbs = [{ name: "/", type: "", displayName: "Documents", _id: -1 }];
       this.documentsList = [
      { name: "My Drive", type: "baseFolder", displayName: "My Drive", _id: 0,"folderCount":0, "fileCount":0 },
      { name: "Cases", type: "baseFolder", displayName: "Cases", _id: 1,"folderCount":0, "fileCount":0 },
      { name: "Common", type: "baseFolder", displayName: "Common", _id: 5,"folderCount":0, "fileCount":0 },
      { name: "Shared With Me", type: "baseFolder", displayName: "Shared With Me", _id: 2 ,"folderCount":0, "fileCount":0},
      {  name: "My Favourites",   type: "baseFolder",   displayName: "My Favourites",   _id: 3,"folderCount":0, "fileCount":0  },
      { name: "Trash", type: "baseFolder", displayName: "Trash", _id: 4 ,"folderCount":0, "fileCount":0},
    ];

     // if (this.checkProperty(this.$route, "query")) {
        for (let i = 0; i < 100; i++) {
          if (i > 0) {
            if (
             _.has(this.$route.query, "bredCumbName_"+i) &&
             _.has(this.$route.query, "bredCumbType_"+i) &&
              _.has(this.$route.query, "bredCumbId_"+i)
            ) {
              let berdCumb = {
                _id: "",
                name: "",
                type: "",
              };
              berdCumb["_id"] = this.$route.query["bredCumbId_"+i] ;
              berdCumb["type"] = this.$route.query["bredCumbType_"+i];
              berdCumb["name"] =  this.$route.query["bredCumbName_"+i];
              berdCumb["displayName"] =this.$route.query["bredCumbName_"+i];
              let findObj = _.find(this.breadcrumbs ,{"_id":berdCumb['_id']})
             
              if(!findObj){
                 this.breadcrumbs.push(berdCumb);

              }
             
            }
          }
        }
        if(this.breadcrumbs.length>1){
        let lastIndex = ((this.breadcrumbs.length)-1);
        let lastItem = this.breadcrumbs[lastIndex];
        let obj ={};
        obj['bredCumbId_'+lastIndex] = "folder";
        // if(lastItem && this.checkProperty( lastItem,obj)){
        //     this.selectedItem['_id'] = lastItem['bredCumbId_'+lastIndex];
        //     this.selectedItem['type'] = lastItem['bredCumbType_'+lastIndex];
        //     this.selectedItem['displayName'] = lastItem['bredCumbName_'+lastIndex];
        // }
         
       //  alert(JSON.stringify(this.selectedItem))
         this.getdocumentsList();
       // this.gotoSubFolder(this.selectedItem)

        }else{
           this.documentsList = [
      { name: "My Drive", type: "baseFolder", displayName: "My Drive", _id: 0,"folderCount":0, "fileCount":0 },
      { name: "Cases", type: "baseFolder", displayName: "Cases", _id: 1,"folderCount":0, "fileCount":0 },
      { name: "Common", type: "baseFolder", displayName: "Common", _id: 5,"folderCount":0, "fileCount":0 },
      { name: "Shared With Me", type: "baseFolder", displayName: "Shared With Me", _id: 2,"folderCount":0, "fileCount":0 },
      {  name: "My Favourites",   type: "baseFolder",   displayName: "My Favourites",   _id: 3,"folderCount":0, "fileCount":0  },
      { name: "Trash", type: "baseFolder", displayName: "Trash", _id: 4,"folderCount":0, "fileCount":0 },
    ];
           this.init();

        }
    //  }
      //this.getdocumentsList();
    } else {
      this.init();
    }

    //

    //this.getdocumentsList();
    this.getBaseFoldersCount()
  },
};
</script>
