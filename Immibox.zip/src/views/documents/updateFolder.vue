<template>
  <form>
    <div class="form-container" @click="formErrors = ''">
      <div class="vx-row">
        <div class="vx-col w-full">
          <div
            class="form_group"
            v-if="checkProperty(selectedItem, 'type') == 'document'"
          >
            <label class="form_label">Name<em>*</em></label>
            <vs-input
              v-model="newFolder.name"
              name="foldername"
              v-validate="'required'"
              class="w-full"
              data-vv-as=" Name"
            />
            <span
              class="text-danger text-sm"
              v-show="errors.has('foldername')"
              >{{ errors.first("foldername") }}</span
            >
          </div>
          <div class="form_group" v-else>
            <label class="form_label">Name<em>*</em></label>
            <vs-input
              v-model="newFolder.displayName"
              name="foldername"
              v-validate="'required'"
              class="w-full"
              data-vv-as="Name"
            />
            <span
              class="text-danger text-sm"
              v-show="errors.has('foldername')"
              >{{ errors.first("foldername") }}</span
            >
          </div>
        </div>
      </div>

      <div v-show="formErrors">
        <vs-alert
          color="warning"
          class="warning-alert reg-warning-alert no-border-radius"
          icon-pack="IntakePortal"
          icon="IP-information-button"
          active="true"
          >{{ formErrors }}</vs-alert
        >
      </div>
    </div>

    <div class="popup-footer">
      <vs-button color="dark" @click="closePopup()" class="cancel" type="filled"
        >Cancel
      </vs-button>
      <vs-button
        color="success"
        :disabled="creating"
        @click="updateFolder()"
        class="save"
        type="filled"
        >Update</vs-button
      >
    </div>
  </form>
</template>

<script>
import { defineComponent } from "@vue/composition-api";
import moment from "moment";
import _ from "lodash";
export default defineComponent({
  props: {
    selectedItem: null,
    myDrive: false,
    baseFolderName:''
  },
  mounted() {
    let self = this;
    if (this.checkProperty(this.selectedItem, "displayName")) {
      this.newFolder["displayName"] = this.selectedItem["displayName"];
    }
    if (this.checkProperty(this.selectedItem, "name")) {
      this.newFolder["name"] = this.selectedItem["name"];
    }
    if (
      this.checkProperty(this.selectedItem, "_id") &&
      this.checkProperty(this.selectedItem, "type") != "document"
    ) {
      this.newFolder["folderId"] = this.selectedItem["_id"];
      // this.getFolderDetails();
    } else {
      this.newFolder = Object.assign(this.newFolder, {
        documentId: self.selectedItem["_id"],
        confidential: false,
      });
      this.newFolder["confidential"] = self.selectedItem["confidential"];
    }
    //  this.getUsersList()
  },
  methods: {
    getFolderDetails() {
      ///documents/folder-details
      this.folderDetails = null;
      let postData = {
        folderId: "",
      };
      postData["folderId"] = this.selectedItem["_id"];
      this.$store
        .dispatch("commonAction", {
          data: postData,
          path: "documents/folder-details",
        })
        .then((response) => {
          this.folderDetails = response;
          if (_.has(this.folderDetails, "accessDetails")) {
            _.forEach(this.folderDetails["accessDetails"], (item) => {
              this.newFolder["accessTo"].push(item["sharedToDetails"]);
            });
          }
        })
        .catch((err) => {});
    },
    closePopup() {
      this.$emit("closePopup");
    },
    updateFolder() {
      let self = this;
      this.$validator.validateAll().then((result) => {
        if (result) {
          let postData = _.cloneDeep(this.newFolder);
          let path = "documents/folder-update";
          if (this.checkProperty(this.selectedItem, "type") != "document") {
            postData["folderId"] = this.selectedItem["_id"];
            // this.getFolderDetails();
          } else {
            path = "documents/update";
            postData["documentId"] = this.selectedItem["_id"];
          }

          this.creating = true;
          this.$store
            .dispatch("commonAction", {
              data: postData,
              path: path,
            })
            .then((response) => {
              this.showToster({ message: response.message, isError: false });
              this.closePopup();
              this.creating = false;
            })
            .catch((err) => {
              this.creating = false;
              this.formErrors = err;
              // this.showToster({ message: err, isError: false });
            });
        }
      });
    },
    getUsersList() {
      let matcher = {
        roleIds: [],
        title: this.searchtxt,
        searchString: this.searchtxt,
        statusIds: [],
        stateIds: [],
        locationIds: [],
        createdDateRange: [],
        page: 1,
        perpage: 500000,
      };

      let query = {};
      query["page"] = 1;
      query["perpage"] = 5000;
      query["getMasterData"] = true;
      query["matcher"] = matcher;
      query["sorting"] = { path: "createdOn", order: -1 };
      //alert( JSON.stringify(query['sorting']))

      this.$store
        .dispatch("getList", { data: query, path: "/users/list" })
        .then((response) => {
          this.taggedUsersList = response.list;
          _.forEach(this.taggedUsersList, (item) => {
            if (_.has(item, "roleName")) {
              item["name"] = item["name"] + " (" + item["roleName"] + ")";
            }
          });

          // this.totalpages = Math.ceil(response.totalCount / this.perpage);

          //alert(this.perpage);
        })
        .catch((err) => {
          this.taggedUsersList = [];
        });
    },
  },
  data() {
    return {
      folderDetails: null,
      taggedUsersList: [],
      creating: false,
      formErrors: "",
      newFolder: {
        name: "",
        displayName: "",
        folderId: "", // Required when create inside a folder
        //  myDrive: false, // Required for saving in "My Drive"
      },
    };
  },
});
</script>
>

