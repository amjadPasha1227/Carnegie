<template>
  <form>
    <div class="form-container pb-0" @click="formErrors = ''">
      <div class="vx-row">
        <div class="vx-col w-full">
          <div class="shared_info">
            <p v-if="getSharedByDetails">Shared By<strong>{{ getSharedByDetails }}</strong>&nbsp;On <strong v-if="getSharedDate">{{ getSharedDate | formatDate }}</strong></p>
            <!-- <p v-if="getSharedDate">
              Shared On: <strong>{{ getSharedDate | formatDate }}</strong>
            </p> -->
          </div>          
          <div class="taggedlist">
            <ul class="pl-0 pr-0">
              <li v-for="(member, index) in newFolder['accessTo']" :key="index">
            
                <figure>
                  <img
                    :src="
                      checkProperty(member, 'SharedToProfilePicture')
                    "
                    @error="setDefaultPhoto($event)"
                  />
                </figure>

                <figcaption>
                  {{ checkProperty(member, "sharedToName")
                  }}<span>{{ checkProperty(member, "sharedToRoleName") }}</span>
                </figcaption>

                <template
                  v-if=" baseFolderName !='Trash'
                    && checkProperty(member, 'sharedBy') &&
                    checkProperty(member, 'sharedBy') ==
                      checkProperty(getUserData, 'userId')
                  "
                >
                  <em class="remove" @click="removeSharing(member)"
                    ><img src="@/assets/images/main/delete-row-img.svg"
                  /></em>
                </template>
              </li>
            </ul>
          </div>
        </div>
      </div>

      <div v-show="formErrors">
        <vs-alert
          color="warning"
          class="warning-alert reg-warning-alert no-border-radius"
          icon-pack="IntakePortal"
          icon="IP-information-button"
          active="true"
          >{{ formErrors }}</vs-alert
        >
      </div>
    </div>

    <div class="popup-footer">
      <vs-button color="dark" @click="closePopup()" class="cancel" type="filled"
        >Cancel
      </vs-button>
    </div>
  </form>
</template>

<script>
import { defineComponent } from "@vue/composition-api";
import moment from "moment";
import _ from "lodash";
export default defineComponent({
  computed: {
    getSharedDate() {
      if (this.checkProperty(this.newFolder, "accessTo", "length") > 0) {
        let member = this.newFolder["accessTo"][0];
        return this.checkProperty(member, "sharedOn");
      } else {
        return false;
      }
    },
    getSharedByDetails() {
      // {{ checkProperty(member , 'sharedByName') }} {{ checkProperty(member , 'sharedByRoleName') }}

      if (this.checkProperty(this.newFolder, "accessTo", "length") > 0) {
        let member = this.newFolder["accessTo"][0];
        if (
          this.checkProperty(member, "sharedBy") ==
          this.checkProperty(this.getUserData, "userId")
        ) {
          return " Me";
        } else {
          return (
            this.checkProperty(member, "sharedByName") +
            " (" +
            this.checkProperty(member, "sharedByRoleName") +
            ")"
          );
        }
      } else {
        return false;
      }
    },
  },
  props: {
    selectedItem: "",
    myDrive: false,
    baseFolderName:""
  },
  mounted() {
    if (this.checkProperty(this.selectedItem, "myDrive")) {
      this.newFolder["myDrive"] = this.selectedItem["myDrive"];
    }
    if (this.checkProperty(this.selectedItem, "_id")) {
      this.newFolder["folderId"] = this.selectedItem["_id"];
      this.getFolderDetails();
    }
    //this.getUsersList()
  },
  methods: {
    removeSharing(item) {
      let self = this;
      let postData = {
        folderId: "",
        sharingId: "",
      };
      postData["sharingId"] = item["_id"];
      postData["folderId"] = this.selectedItem["_id"];

      let path = "documents/remove-folder-sharing";
      if (this.checkProperty(this.selectedItem, "type") == "document") {
        path = "/documents/remove-sharing";
        postData = Object.assign(postData, {
          documentId: self.selectedItem["_id"],
        });
      } else {
        postData = Object.assign(postData, {
          folderId: self.selectedItem["_id"],
        });
      }
      this.$store
        .dispatch("commonAction", {
          data: postData,
          path: path,
        })
        .then((response) => {
          this.showToster({ message: response.message, isError: false });
          this.getFolderDetails(true);
          this.creating = false;
        })
        .catch((error) => {
          this.creating = false;
          this.formErrors = error;
        });
    },

    getFolderDetails(callFromRemove = false) {
      let self = this;
      ///documents/folder-details
      this.folderDetails = null;
      let postData = {
        folderId: "",
      };
      postData["folderId"] = this.selectedItem["_id"];
      this.newFolder["accessTo"] = [];
      ///documents/details

      let path = "documents/folder-details";
      if (this.checkProperty(this.selectedItem, "type") == "document") {
        path = "/documents/details";
        postData = Object.assign(postData, {
          documentId: self.selectedItem["_id"],
        });
      } else {
        postData = Object.assign(postData, {
          folderId: self.selectedItem["_id"],
        });
      }
      this.$store
        .dispatch("commonAction", {
          data: postData,
          path: path,
        })
        .then((response) => {
          this.folderDetails = response;
          if (_.has(this.folderDetails, "accessDetails")) {
            _.forEach(this.folderDetails["accessDetails"], (item) => {
              this.newFolder["accessTo"].push(item);
            });

            if (
              callFromRemove &&
              this.folderDetails["accessDetails"].length <= 0
            ) {
              this.closePopup();
            }
          } else {
            //callFromRemove
            if (callFromRemove) {
              this.closePopup();
            }
          }
        })
        .catch((err) => {});
    },
    closePopup() {
      this.$emit("closePopup");
    },

    getUsersList(searchtxt = "") {
      let matcher = {
        title: searchtxt,
      };

      let query = {};
      query["page"] = 1;
      query["perpage"] = 5000;
      query["getMasterData"] = true;
      query["filters"] = matcher;
      query["sorting"] = { path: "createdOn", order: -1 };
      this.$store
        .dispatch("getList", {
          data: query,
          path: "/documents/get-share-users-list",
        })
        .then((response) => {
          this.taggedUsersList = response.list;
          _.forEach(this.taggedUsersList, (item) => {
            if (_.has(item, "roleName")) {
              item["name"] = item["name"] + " (" + item["roleName"] + ")";
            }
          });

          // this.totalpages = Math.ceil(response.totalCount / this.perpage);

          //alert(this.perpage);
        })
        .catch((err) => {
          this.taggedUsersList = [];
        });
    },
  },
  data() {
    return {
      sharingDetails: [],
      folderDetails: null,
      taggedUsersList: [],
      creating: false,
      formErrors: "",
      newFolder: {
        accessTo: [],
        folderId: "", // Required when create inside a folder
        myDrive: false, // Required for saving in "My Drive"
      },
    };
  },
});
</script>
>

