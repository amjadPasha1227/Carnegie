<template>
<div>
     <div class="dashboard__section">
        <div class="dashboard_cnt">  
            <div class="dashboard_left">
                <div class="grid_actions">
                    <ul>
                        <li class="active"><a>ALL ACTIVITIES</a></li>
                        <li><a>MY TASKS (10)</a></li>
                        <li><a>TASKS</a></li>
                    </ul>
                </div>
                <div class="grid_title">
                    <span>TODAY</span>
                </div>      
                <div class="grid">
                    <div class="grid-item grid_2x">
                        <div class="wishes_box">
                            <h6>Good Morning Ravindrababu<img src="@/assets/images/main/smile.png"></h6> 
                            <h4>You have 5 pending task(s).</h4>
                            <span class="note"><img src="@/assets/images/main/note_icon.png"></span>
                        </div>
                    </div>
                    <div class="grid-item grid_1x">
                        <div class="grid-item_cnt bg-1">
                            <div class="d-flex justify-between">
                                <p>Lorem Ipsum is simply mmy Lorem Ipsum is Lorem Ipsum is.</p>
                                <em>2 min.</em>
                            </div>   
                            <div class="d-flex justify-between align-center">
                                <div class="avatar">
                                    <figure><img src="@/assets/images/main/avatar.png"></figure>
                                    <div>
                                        <figcaption>Thomas V</figcaption>
                                        <p>Attorney</p>
                                    </div>
                                </div> 
                                <span class="note"><img src="@/assets/images/main/note_icon.png"></span> 
                            </div>               
                        </div>
                    </div>
                    <div class="grid-item grid_1x">
                        <div class="grid-item_cnt bg-2">
                            <div class="d-flex justify-between">
                                <p>Lorem Ipsum is simply mmy Lorem Ipsum is Lorem Ipsum is.</p>
                                <em>2 min.</em>
                            </div>   
                            <div class="d-flex justify-between align-center">
                                <div class="avatar">
                                    <figure><img src="@/assets/images/main/avatar.png"></figure>
                                    <div>
                                        <figcaption>Thomas V</figcaption>
                                        <p>Attorney</p>
                                    </div>
                                </div> 
                                <span class="note"><img src="@/assets/images/main/note_icon.png"></span> 
                            </div>               
                        </div>
                    </div>
                    <div class="grid-item grid_1x">
                        <div class="grid-item_cnt bg-2">
                            <div class="d-flex justify-between">
                                <p>Lorem Ipsum is simply mmy Lorem Ipsum is Lorem Ipsum is.</p>
                                <em>2 min.</em>
                            </div>   
                            <div class="d-flex justify-between align-center">
                                <div class="avatar">
                                    <figure><img src="@/assets/images/main/avatar.png"></figure>
                                    <div>
                                        <figcaption>Thomas V</figcaption>
                                        <p>Attorney</p>
                                    </div>
                                </div> 
                                <span class="note"><img src="@/assets/images/main/note_icon.png"></span> 
                            </div>               
                        </div>
                    </div>
                     
                    <div class="grid-item grid_1x">
                        <div class="grid-item_cnt bg-4">
                            <div class="d-flex justify-end">                            
                                <em>2 min.</em>
                            </div>  
                            <p>Lorem Ipsum is simply mmy Lorem Ipsum is Lorem Ipsum is.</p>
                            <p>Lorem Ipsum is simply mmy Lorem Ipsum is Lorem Ipsum is.</p> 
                            <div class="d-flex justify-between align-center">
                                <div class="avatar">
                                    <figure><img src="@/assets/images/main/avatar.png"></figure>
                                    <div>
                                        <figcaption>Thomas V</figcaption>
                                        <p>Attorney</p>
                                    </div>
                                </div> 
                                <span class="note"><img src="@/assets/images/main/note_icon.png"></span> 
                            </div>               
                        </div>
                    </div>
                    <div class="grid-item grid_1x">
                        <div class="grid-item_cnt bg-5">
                            <div class="d-flex justify-between">   
                                <figure><img src="@/assets/images/main/route_map.png"></figure>                         
                                <em>2 min.</em>
                            </div>  
                            <label>Your petition docket sent to USCIS. To Track the FedEx use ITTY456566.</label>
                            <div class="d-flex justify-between align-center">
                                <div class="avatar">
                                    <figure><img src="@/assets/images/main/avatar.png"></figure>
                                    <div>
                                        <figcaption>Thomas V</figcaption>
                                        <p>Attorney</p>
                                    </div>
                                </div> 
                                <span class="note"><img src="@/assets/images/main/note_icon.png"></span> 
                            </div>               
                        </div>
                    </div>
                    <div class="grid-item grid_2x">
                        <div class="grid-item_cnt bg-2">   
                            <div class="d-flex justify-between">                            
                                <div class="avatar">
                                    <figure><img src="@/assets/images/main/avatar.png"></figure>
                                    <div>
                                        <figcaption>Thomas V</figcaption>
                                        <p>Attorney</p>
                                    </div>
                                </div>  
                                <em>2 min.</em>
                            </div> 
                            <div class="d-flex align-center pt-6">
                                <figure class="globe_icon"><img src="@/assets/images/main/globe_icon.png"></figure>
                                <div class="pl-2">
                                    <figure class="company_logo">
                                        <img src="@/assets/images/main/sevanes_logo.png">
                                        <span><img src="@/assets/images/main/varified.png"></span>    
                                    </figure>
                                    <div class="d-flex justify-between align-end">
                                        <p class="mb-0">Lorem ipsum, or lipsum as it is some times known, Lorem ipsum, or lipsum Lorem ipsum</p>
                                        <span class="note"><img src="@/assets/images/main/note_icon.png"></span>
                                    </div>
                                    
                                </div>
                            </div>
                                    
                        </div>
                    </div>
                     <div class="grid-item grid_2x">
                        <div class="grid-item_cnt bg-3 bg_img-1">   
                            <div class="d-flex justify-between">  
                                <em>2 min.</em>                          
                                <div class="avatar">
                                    <figure><img src="@/assets/images/main/avatar.png"></figure>
                                    <div>
                                        <figcaption>Thomas V</figcaption>
                                        <p>Attorney</p>
                                    </div>
                                </div>
                            </div> 
                            <h6>Congratulations!</h6> 
                            <h4>Lorem Ipsum is simply dummy text of the printing</h4>
                            <ul>
                                <li><a href="#" class="primary__btn"><img src="@/assets/images/main/download_icon.svg">Case Approval</a></li>
                                 <li><a href="#" class="primary__btn"><img src="@/assets/images/main/download_icon.svg">Case Approval</a></li>
                            </ul>
                            <ul>
                                <li><button class="secondary__btn">REJECT</button></li>
                                <li><button class="secondary__btn">APPROVE</button></li>
                                <li><button class="secondary__btn">Hold</button></li>
                            </ul>  
                        </div>
                    </div>
                    <div class="grid-item grid_1x">
                        <div class="grid-item_cnt bg-1"> 
                            <div class="d-flex justify-between mb-3">
                                <div class="avatar">                                 
                                    <div>
                                        <figcaption>Thomas V</figcaption>
                                        <p>Attorney</p>
                                    </div>
                                </div> 
                                <em>2 min.</em>
                            </div>  
                            <p>Lorem Ipsum is simply dummy Lorem Ipsum is simply dummy Lorem Ipsum is simply</p>             
                        </div>
                    </div>
                    <div class="grid-item grid_1x">
                        <div class="grid-item_cnt bg-1">
                            <div class="d-flex justify-between">
                                <p>Lorem Ipsum is simply mmy Lorem Ipsum is Lorem Ipsum is.</p>
                                <em>2 min.</em>
                            </div>   
                            <div class="d-flex justify-between align-center">
                                <div class="avatar">
                                    <figure><img src="@/assets/images/main/avatar.png"></figure>
                                    <div>
                                        <figcaption>Thomas V</figcaption>
                                        <p>Attorney</p>
                                    </div>
                                </div> 
                                <span class="note"><img src="@/assets/images/main/note_icon.png"></span> 
                            </div>               
                        </div>
                    </div>
                    <div class="grid-item grid_1x">
                        <div class="grid-item_cnt bg-2">
                            <div class="d-flex justify-between">
                                <p>Lorem Ipsum is simply mmy Lorem Ipsum is Lorem Ipsum is.</p>
                                <em>2 min.</em>
                            </div>   
                            <div class="d-flex justify-between align-center">
                                <div class="avatar">
                                    <figure><img src="@/assets/images/main/avatar.png"></figure>
                                    <div>
                                        <figcaption>Thomas V</figcaption>
                                        <p>Attorney</p>
                                    </div>
                                </div> 
                                <span class="note"><img src="@/assets/images/main/note_icon.png"></span> 
                            </div>               
                        </div>
                    </div>
                    <div class="grid-item grid_1x">
                        <div class="grid-item_cnt bg-2">
                            <div class="d-flex justify-between">
                                <p>Lorem Ipsum is simply mmy Lorem Ipsum is Lorem Ipsum is.</p>
                                <em>2 min.</em>
                            </div>   
                            <div class="d-flex justify-between align-center">
                                <div class="avatar">
                                    <figure><img src="@/assets/images/main/avatar.png"></figure>
                                    <div>
                                        <figcaption>Thomas V</figcaption>
                                        <p>Attorney</p>
                                    </div>
                                </div> 
                                <span class="note"><img src="@/assets/images/main/note_icon.png"></span> 
                            </div>               
                        </div>
                    </div>
                    


        
                </div>
            </div>
        </div>
    </div>
</div>
</template>
 
<script>
import VueApexCharts from 'vue-apexcharts'
import Vue from 'vue'
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import { MoreVerticalIcon } from 'vue-feather-icons'
import DateRangePicker from "vue2-daterange-picker";
import Avatar from 'vue-avatar'
import WallMessage from '../views/wall/message.vue'
import { MasonryGrid, JustifiedGrid, FrameGrid, PackingGrid } from "@egjs/vue-grid";
import toDoGridItem from './wall/toDoGridItem.vue'
import activityItem from './wall/activityItem.vue'


import 'vue2-daterange-picker/dist/vue2-daterange-picker.css'
Vue.use(VueApexCharts)

Vue.component('apexchart', VueApexCharts)

export default {
    components: {
        MasonryGrid,
        WallMessage,
        Avatar,
        VuePerfectScrollbar,
        MoreVerticalIcon,
        DateRangePicker,
        toDoGridItem,
        activityItem
    },
    data: function () {
         



        return {
              items: [
        { title: 'Ravi Kumar',groupKey:1,role:"Front Office User", petitioner:true, action:true,cssclass:'color4d', description: 'Innvectra Info Solutions registered as Petitioner.' },
        { title: 'Thomas V Allen',action:false, document:true,role:"Attorney",groupKey:2,cssclass:'color1d', description: 'Congratulations! H1B Petition (CASE 1234523456) Amendment is approved BY USCIS.' },
        { title: 'Joseph P', groupKey:3,role:"Supervisor",action:false,cssclass:'color3d', description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum is simply dummy text of the printing and typesetting industry.' },
        { title: 'John Doe',groupKey:4, role:"Paralegal",action:false,cssclass:'color4d', description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.' },
        { title: 'Katrina Kivokova', role:"Documentation Manager",action:false,groupKey:1,cssclass:'color2d', description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.' },
        { title: 'Wilimos Dip', role:"Paralegal",casetracking:true,action:false,groupKey:2,cssclass:'color3d', description: 'Your petition docket sent to USCIS. To Track the FedEx use ITTY456566.' },
        { title: 'James Machnoche', role:"Paralegal",action:false,groupKey:3,cssclass:'color1d', description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.' },
        { title: 'Bill David', role:"Front Office User",action:false,groupKey:4,cssclass:'color4d', description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.' },
        { title: 'Igor Vadliman', role:"Paralegal",action:false,groupKey:1,cssclass:'color3d', description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.' },
        { title: 'Satish Reddy',role:"Front Office User",action:false, groupKey:2,cssclass:'color2d', description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.' },
        { title: 'Syam Kumar', role:"Front Office User",action:false,groupKey:3,cssclass:'color1d', description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.' },
        { title: 'Prem Kumar',role:"Branch Manager",action:false, groupKey:4,cssclass:'color4d', description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.' },
    
      { title: 'Ravi Kumar',groupKey:1,role:"Front Office User", petitioner:true, action:true,cssclass:'color4d', description: 'Innvectra Info Solutions registered as Petitioner.' },
         { title: 'Katrina Kivokova', role:"Documentation Manager",action:false,groupKey:1,cssclass:'color2d', description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.' },
        { title: 'Wilimos Dip', role:"LCA Manager",action:true,groupKey:2,cssclass:'color3d', description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.' },
        { title: 'Igor Vadliman', role:"Paralegal",action:false,groupKey:1,cssclass:'color3d', description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.' },
        { title: 'Satish Reddy',role:"Front Office User",action:false, groupKey:2,cssclass:'color2d', description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.' },
    
        { title: 'Thomas V Allen',action:false, document:true,role:"Attorney",groupKey:2,cssclass:'color1d', description: 'Congratulations! H1B Petition (CASE 1234523456) Amendment is approved BY USCIS.' },
        { title: 'Joseph P', groupKey:3,role:"Supervisor",action:false,cssclass:'color3d', description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum is simply dummy text of the printing and typesetting industry.' },
        { title: 'John Doe',groupKey:4, role:"Paralegal",action:false,cssclass:'color4d', description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.' },
           { title: 'Syam Kumar', role:"Front Office User",action:false,groupKey:3,cssclass:'color1d', description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.' },
        { title: 'Prem Kumar',role:"Branch Manager",action:false, groupKey:4,cssclass:'color4d', description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.' },
        { title: 'James Machnoche', role:"Paralegal",action:false,groupKey:3,cssclass:'color1d', description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.' },
        { title: 'Bill David', role:"Front Office User",action:false,groupKey:4,cssclass:'color4d', description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.' },
    
    
    ],
          gap:0,
    frame: [[1,1,2,2],[3,3,2,2],[4,4,4,5]],
    rectSize: 0,
    useFrameFill: true,
             dateRange: {
               // startDate: '2019-12-26',
               // endDate: '2019-12-28',
                },
            username: '',
            activities: [],
            options: {},
            series: [50, 102, 155, 141, 117],
            dashboard_data: {},
            lca_requests: [],
            new_petitioners: [],
            new_petitions: [],
            petitionersCount: {},
            beneficiaryStats: {},

            petitionsCount: {},
            rfe_petitions: [],

            //recent activity data
            recent_activitys: [],
            my_tasks: [],
            roleId: 0,
            wallFilterData: {
          "filters":{
            "types": ['todo'], // all, todo activity
            "createdDateRange": []
          },
          "page": 1,
          "perpage": 25,
          "sorting": {
            "path": "createdOn",
            "order": -1
          }
        }

        }
    },
   
    mounted() {

        jQuery('.grid').isotope({
          layoutMode: 'packery',
          itemSelector: '.grid-item'
        });


        this.username = this.$store.state.user.name;
        this.roleId = this.$store.state.user['roleId'][0];
       
        this.petitionsCount = {
            petitionCount: 0,
            rfeCount: 0,
            totalCount: 0
        };
        this.petitionersCount = {
            approvedCount: 0,
            pendingCount: 0,
            totalCount: 0
        };
        this.beneficiaryStats = {
            "total": 0,
            "active": 0,
            "inactive": 0
        };

        this.get_dashboardData();
        this.get_recentActivitys();
        this.get_mytasks();
        this.getactivities();
         this.wallFilterData = {
          "filters":{
            "types": [], // all, todo activity
            "createdDateRange": []
          },
          "page": 1,
          "perpage": 25,
          "sorting": {
            "path": "createdOn",
            "order": -1
          }
        }
    this.wallList();

    },
    methods: {
        wallList(){
            this.geAlltWallList({ postData:this.wallFilterData });
        },
        get_dashboardData: function () {
            this.$store.dispatch("get_dashboard_data", {}).then(response => {
                this.dashboard_data = response;
                this.lca_requests = this.dashboard_data['lca_requests'] ? this.dashboard_data['lca_requests'] : [];

                this.petitionsCount = this.dashboard_data['petitionsCount'] ? this.dashboard_data['petitionsCount'] : {
                    petitionCount: 0,
                    rfeCount: 0,
                    totalCount: 0
                };
                this.petitionersCount = this.dashboard_data['petitionersCount'] ? this.dashboard_data['petitionersCount'] : {
                    approvedCount: 0,
                    pendingCount: 0,
                    totalCount: 0
                };
                this.beneficiaryStats = this.dashboard_data['beneficiaryStats'] ? this.dashboard_data['beneficiaryStats'] : {
                    "total": 0,
                    "active": 0,
                    "inactive": 0
                };

                this.new_petitioners = this.dashboard_data['new_petitioners'] ? this.dashboard_data['new_petitioners'] : [];
                this.new_petitions = this.dashboard_data['new_petitions'] ? this.dashboard_data['new_petitions'] : [];
                this.rfe_petitions = this.dashboard_data['rfe_petitions'] ? this.dashboard_data['rfe_petitions'] : [];
            });
        },
        get_recentActivitys: function () {
            this.$store.dispatch("get_recent_activitys", {}).then(response => {
                this.recent_activitys = response.list;
                
            });
        },
        getactivities: function () {
            this.$store.dispatch("getactivities").then(response => {
                this.activities = response;
            });
        },
        get_mytasks: function () {
            this.$store.dispatch("get_my_tasks", {}).then(response => {

                this.my_tasks = response.list.map((element) => {
                    //"navigationKey":

                    

                    element["data"]['navigation_link'] = "#";
                    if (element["data"]["navigationKey"] == "USER_DETAILS")
                        // element["data"]['navigation_link'] ="#/company/details/"+element["data"]['companyId'];

                        if (element["data"]["navigationKey"] == "COMPANY_DETAILS")
                            element["data"]['navigation_link'] = "/company/details/" + element["data"]['companyId'];

                    if (element["data"]["navigationKey"] == "PETITION_DETAILS")
                        element["data"]['navigation_link'] = "/petition-details/" + element["data"]['petitionId'];

                    if (element["data"]["navigationKey"] == "LCA_DETAILS")
                        element["data"]['navigation_link'] = "/lca-details/" + element["data"]['lcaId'];

                    if (element["data"]["description"].includes("questionnaire ")) element["data"]['navigation_link'] = "/questionnaire/" + element["data"]['petitionId'];

                    return element;

                });
                
                //this.my_tasks = a//response.list;

            });
        },
        refresh() {
           // alert("REFERESH");
            this.get_recentActivitys();
        },
    }
};
</script>
