<template>
    <div class="pad20">
        <div class="vx-row m-0 main-list-panel">
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'beneficiaryInfo' ,'name') || checkProperty(petition,'beneficiaryInfo' ,'firstName') || 
            checkProperty(petition,'beneficiaryInfo' ,'middleName') || checkProperty(petition,'beneficiaryInfo' ,'lastName') ">
                <div class="main-list">
                    <p>
                        Full Name
                        <span>{{formatFullname(petition.beneficiaryInfo)}}</span>
                    </p>
                </div>
            </div>
    
            <template v-if="checkProperty(petition,'beneficiaryInfo' ,'email')">
                <div class="vx-col md:w-1/3 w-full p-0" v-if="checkIsTempAccount(checkProperty(petition,'beneficiaryInfo' ,'email'))">
                    <div class="main-list">
                        <p>
                            Email
                            <span>{{checkProperty(petition,'beneficiaryInfo' ,'email')}}</span>
                        </p>
                    </div>
                </div>
            </template>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'beneficiaryInfo','gender')">
                <div class="main-list">
                    <p>
                        Gender
                        <span style="text-transform: capitalize;">{{petition.beneficiaryInfo.gender}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'beneficiaryInfo','dateOfBirth')">
                <div class="main-list">
                    <p>
                        Date of Birth
                        <span>{{petition.beneficiaryInfo.dateOfBirth | formatDate}}</span>
                    </p>
                </div>
            </div>
    
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition['beneficiaryInfo'],'countryOfBirthDetails' ,'name')">
                <div class="main-list">
                    <p>
                        Country of Birth
                        <span>{{checkProperty(petition['beneficiaryInfo'],'countryOfBirthDetails' ,'name')}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition['beneficiaryInfo'],'provinceOfBirthDetails' ,'name')">
                <div class="main-list">
                    <p>
                        Province of Birth
                        <span>{{checkProperty(petition['beneficiaryInfo'],'provinceOfBirthDetails' ,'name')}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition['beneficiaryInfo'],'locationOfBirth' )">
                <div class="main-list">
                    <p>
                        Location of Birth
                        <span>{{checkProperty(petition['beneficiaryInfo'],'locationOfBirth')}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition['beneficiaryInfo'],'countryOfCitizenshipDetails' ,'name')">
                <div class="main-list">
                    <p>
                        Country of Citizenship
                        <span>{{checkProperty(petition['beneficiaryInfo'],'countryOfCitizenshipDetails' ,'name')}}</span>
                    </p>
                </div>
            </div>
            <template>
        <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'beneficiaryInfo','dateOfMarriage')">
            <div class="main-list">
                <p>
                    Date of Marriage
                    <span>{{petition.beneficiaryInfo.dateOfMarriage | formatDate}}</span>
                </p>
            </div>
        </div>
        <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'beneficiaryInfo','noOfChildrens')">
            <div class="main-list">
                <p>
                    No of Childrens
                    <span>{{petition.beneficiaryInfo.noOfChildrens }}</span>
                </p>
            </div>
        </div>
        <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition['beneficiaryInfo'],'countryOfMarriageDetails' ,'name')">
            <div class="main-list">
                <p>
                    Country of Marriage
                    <span>{{checkProperty(petition['beneficiaryInfo'],'countryOfMarriageDetails' ,'name')}}</span>
                </p>
            </div>
        </div>
        <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition['beneficiaryInfo'],'provinceOfMarriageDetails' ,'name')">
            <div class="main-list">
                <p>
                    Province of Marriage
                    <span>{{checkProperty(petition['beneficiaryInfo'],'provinceOfMarriageDetails' ,'name')}}</span>
                </p>
            </div>
        </div>
        <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition['beneficiaryInfo'],'locationOfMarriage')">
            <div class="main-list">
                <p>
                    Location of Marriage
                    <span>{{checkProperty(petition['beneficiaryInfo'],'locationOfMarriage')}}</span>
                </p>
            </div>
        </div>
        
        <div class="vx-col  md:w-1/3 w-full p-0" v-if="checkProperty(petition['beneficiaryInfo'],'doYouHaveMarriageCert') == true || checkProperty(petition['beneficiaryInfo'],'doYouHaveMarriageCert') == false" >
            <div class="main-list">
                <p>
                    Do you have a Marriage Certificate
                    <span>{{checkProperty(petition['beneficiaryInfo'],'doYouHaveMarriageCert') | booleanFormat}}</span>
                </p>
            </div>
        </div> 
        <template v-if="checkProperty(petition['beneficiaryInfo'],'marriageCertDocs') && checkProperty(petition['beneficiaryInfo'],'marriageCertDocs','length')>0 && checkProperty(petition['beneficiaryInfo']  ,'doYouHaveMarriageCert')">
            <vs-col class="padl0 padr0" v-if="checkProperty(petition['beneficiaryInfo'],'marriageCertDocs','length')>0" >
                <documentsView @download_or_view="download_or_view" :type="'marriageCertDocs'"  :documentsList="petition['beneficiaryInfo']['marriageCertDocs']" :petitionDetails="petition" />
            </vs-col>
        </template>
    </template>
    
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'beneficiaryInfo' ,'I94')">
                <div class="main-list">
                    <p>
                        I-94 Number
                        <span>{{ checkProperty(petition,'beneficiaryInfo' ,'I94')}}</span>
                    </p>
                </div>
            </div>
            
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'beneficiaryInfo' ,'I94ExpiryDate') || checkProperty(petition,'beneficiaryInfo' ,'isI94DSExpiryDate') ">
                <div class="main-list">
                    <p>
                        I-94 Expiry Date
                        <span v-if="checkProperty(petition,'beneficiaryInfo' ,'isI94DSExpiryDate')">D/S</span>
                        <span v-else>{{petition.beneficiaryInfo.I94ExpiryDate | formatDate}}</span>
                    </p>
                </div>
            </div>
    
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'beneficiaryInfo' ,'maritalStatusDetails') || checkProperty(petition,'beneficiaryInfo' ,'maritalStatus') ">
                <div class="main-list">
                    <p>
                        Marital Status
                        <span>{{ checkProperty(petition['beneficiaryInfo'] , "maritalStatus" ) | formatML(marital_statuses)}}</span>
                    </p>
                </div>
            </div>
            <template>
        <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'beneficiaryInfo' ,'hairColor') && checkProperty(petition['beneficiaryInfo'] ,'hairColor','id')">
            <div class="main-list">
                <p>
                    Hair color
                    <span>{{ checkProperty(petition['beneficiaryInfo'] ,'hairColor','name')  }}</span>
                </p>
            </div>
        </div>
        <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'beneficiaryInfo' ,'race') && checkProperty(petition['beneficiaryInfo'] ,'race','id')">
            <div class="main-list">
                <p>
                    Race
                    <span>{{ checkProperty(petition['beneficiaryInfo'] ,'race','name')  }}</span>
                </p>
            </div>
        </div> 
        <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'beneficiaryInfo' ,'eyeColor') && checkProperty(petition['beneficiaryInfo'] ,'eyeColor','id')">
            <div class="main-list">
                <p>
                    Eye Color
                    <span>{{ checkProperty(petition['beneficiaryInfo'] ,'eyeColor','name')  }}</span>
                </p>
            </div>
        </div>
        <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'beneficiaryInfo' ,'weight') ">
            <div class="main-list">
                <p>
                    Weight
                    <span>{{ checkProperty(petition['beneficiaryInfo'] ,'weight')  }}</span>
                </p>
            </div>
        </div>
        <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'beneficiaryInfo' ,'height') && (checkProperty(petition['beneficiaryInfo'] ,'height','feet')||
        checkProperty(petition['beneficiaryInfo'] ,'height','inches')) ">
            <div class="main-list">
                <p>
                    Height
                    <!-- <span>{{ checkProperty(petition['beneficiaryInfo'] ,'height')  }}</span> -->
                    <span>{{ convertHeight(checkProperty(petition['beneficiaryInfo'] ,'height')) }}</span>
                </p>
            </div>
        </div>
        <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'beneficiaryInfo' ,'curNonImmigrantVisaNumber')">
            <div class="main-list">
                <p>
                    Current nonimmigrant visa number
                    <span>{{ checkProperty(petition,'beneficiaryInfo' ,'curNonImmigrantVisaNumber')}}</span>
                </p>
            </div>
        </div>
    </template>
    
        </div>
        <template v-if="checkProperty(petition,'beneficiaryInfo' ,'hasOtherNames') && checkProperty(petition['beneficiaryInfo'] ,'otherNames' ,'length') >0">
            <div class="vx-row m-0 main-list-panel">
                <h5 class="names_title">Used other names previously</h5>
                <template v-for="(item , ind)  in petition['beneficiaryInfo']['otherNames']">
    
                    <div :key="ind" class="vx-col md:w-1/3 w-full p-0">
                        <div class="main-list">
                            <p>First Name<span v-if="item.firstName">{{item.firstName}}</span> 
                                <span v-else>N/A</span>
                            </p>
                        </div>
                    </div>
                    <div :key="ind" class="vx-col md:w-1/3 w-full p-0">
                        <div class="main-list">
                            <p> Middle Name <span v-if="item.middleName"  >{{item.middleName}}</span>
                                <span v-else>N/A</span>
                            </p>
                        </div>
                    </div>
    
                    <div :key="ind" class="vx-col md:w-1/3 w-full p-0">
                        <div class="main-list">
                            <p> Last Name <span v-if="item.lastName">{{item.lastName}}</span> 
                                <span v-else>N/A</span>
                            </p>
                        </div>
                    </div>
    
                </template>
    
            </div>
    
        </template>
        <div class="vx-row m-0 main-list-panel" v-if="
                           checkProperty(petition,'beneficiaryInfo' ,'passportNumber')
                          || checkProperty(petition,'beneficiaryInfo' ,'passportExpiryDate')
                          || checkProperty(petition,'beneficiaryInfo' ,'passportIssuedDate')
                          || checkProperty(petition,'beneficiaryInfo' ,'curNonImmigrantVisaStatus')
                          || checkProperty(petition,'beneficiaryInfo' ,'curVisaExpiryDate')
                          || checkProperty(petition,'beneficiaryInfo' ,'sevisNumber')
                          || checkProperty(petition,'beneficiaryInfo' ,'eadNumber')
                           ">
    
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'beneficiaryInfo' ,'passportNumber')">
                <div class="main-list">
                    <p>
                        Passport Number
                        <span>{{ checkProperty(petition,'beneficiaryInfo' ,'passportNumber')  }}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'beneficiaryInfo' ,'passportIssuedDate')">
                <div class="main-list">
                    <p>
                        Passport Issued Date
                        <span>{{ checkProperty(petition,'beneficiaryInfo' ,'passportIssuedDate') | formatDate }}</span>
                    </p>
                </div>
            </div>
    
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'beneficiaryInfo' ,'passportExpiryDate')">
                <div class="main-list">
                    <p>
                        Date of Passport Expiry
                        <span>{{ checkProperty(petition,'beneficiaryInfo' ,'passportExpiryDate') | formatDate }}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition['beneficiaryInfo'] ,'passportIssuedCountryDetails','name')">
                <div class="main-list">
                    <p>
                        Country of Passport Issued
                        <span>{{ checkProperty(petition['beneficiaryInfo'] ,'passportIssuedCountryDetails','name') }}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'beneficiaryInfo' ,'I94StatusName')">
                <div class="main-list">
                    <p>
                     I-94 Status Name 
                        <span>{{ checkProperty(petition,'beneficiaryInfo' ,'I94StatusName') }}</span>
                    </p>
                </div>
            </div>
    
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'beneficiaryInfo' ,'curNonImmigrantVisaStatus')">
                <div class="main-list">
                    <p>
                        Current Nonimmigrant Status
                        <span>{{ checkProperty(petition,'beneficiaryInfo' ,'curNonImmigrantVisaStatus')  | formatML(visastatuses)}}</span>
                    </p>
                </div>
            </div>
    
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'beneficiaryInfo' ,'curVisaExpiryDate') || checkProperty(petition,'beneficiaryInfo' ,'isDSExpiryDate')">
                <div class="main-list">
                    <p>
                        Current Status Expiry Date
                        <span v-if="checkProperty(petition,'beneficiaryInfo' ,'isDSExpiryDate')">D/S</span>
                        <span v-else>{{ checkProperty(petition,'beneficiaryInfo' ,'curVisaExpiryDate') | formatDate}}</span>
                    </p>
                </div>
            </div>
    
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'beneficiaryInfo' ,'sevisNumber')">
                <div class="main-list">
                    <p>
                        SEVIS Number
                        <span>{{ checkProperty(petition,'beneficiaryInfo' ,'sevisNumber') }}</span>
                    </p>
                </div>
            </div>
    
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'beneficiaryInfo' ,'eadNumber')">
                <div class="main-list">
                    <p>
                        EAD Number
                        <span>{{ checkProperty(petition,'beneficiaryInfo' ,'eadNumber') }}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'beneficiaryInfo','firstEntryDateOrApprovalInUsWithH1B')">
                <div class="main-list">
                    <p>
                        First Entry Date or Approval in US With H1B
                        <span>{{petition.beneficiaryInfo.firstEntryDateOrApprovalInUsWithH1B | formatDate}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'beneficiaryInfo','dateFifthYearOfHExpire')">
                <div class="main-list">
                    <p>
                        Date Fifth Year of H1B Status Expires
                        <span>{{petition.beneficiaryInfo.dateFifthYearOfHExpire | formatDate}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'beneficiaryInfo' ,'beneficiaryCnfmNumber')">
                <div class="main-list">
                    <p>
                        Confirmation Number
                        <span>{{ checkProperty(petition,'beneficiaryInfo' ,'beneficiaryCnfmNumber') }}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'beneficiaryInfo' ,'capType')">
                <div class="main-list">
                    <p>
                       Cap Type
                        <span>{{ checkProperty(petition,'beneficiaryInfo' ,'capType') }}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'beneficiaryInfo' ,'serviceCenterName')">
                <div class="main-list">
                    <p>
                        Service Center Name
                        <span>{{ checkProperty(petition,'beneficiaryInfo' ,'serviceCenterName') }}</span>
                    </p>
                </div>
            </div>
    
        </div>
        <div class="vx-row m-0 main-list-panel" v-if="checkProperty(petition ,'beneficiaryInfo', 'cellPhoneNumber') || checkProperty(petition ,'beneficiaryInfo', 'homePhoneNumber') 
        || checkProperty(petition ,'beneficiaryInfo', 'fax') || checkProperty(petition ,'beneficiaryInfo', 'workPhoneNumber')  " >
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition ,'beneficiaryInfo', 'cellPhoneNumber')">
                <div class="main-list">
                    <p>
                        Phone Number
                        <span>
                            <template v-if="checkProperty(petition['beneficiaryInfo'] ,'cellPhoneCountryCode' ,'countryCallingCode')">{{checkProperty(petition['beneficiaryInfo'] ,'cellPhoneCountryCode' ,'countryCallingCode')+"&nbsp;"}}</template>
                            {{petition.beneficiaryInfo.cellPhoneNumber | formatPhone}}
    
                        </span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition ,'beneficiaryInfo', 'homePhoneNumber')">
                <div class="main-list">
                    <p>
    
                        Home Phone Number
                        <span>
                            <template v-if="checkProperty(petition['beneficiaryInfo'] ,'homePhoneCountryCode' ,'countryCallingCode')">{{checkProperty(petition['beneficiaryInfo'] ,'homePhoneCountryCode' ,'countryCallingCode')+"&nbsp;"}}</template>
                            {{petition.beneficiaryInfo.homePhoneNumber | formatPhone}}
                        </span>
                    </p>
                </div>
            </div>
            
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition ,'beneficiaryInfo', 'fax')">
                <div class="main-list">
                    <p>
                        Fax Number
                        <span>
                            <template v-if="checkProperty(petition['beneficiaryInfo'] ,'faxCountryCode' ,'countryCallingCode')">{{checkProperty(petition['beneficiaryInfo'] ,'faxCountryCode' ,'countryCallingCode')+"&nbsp;"}}</template>
                            {{petition.beneficiaryInfo.fax | formatPhone}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition ,'beneficiaryInfo', 'workPhoneNumber')">
                <div class="main-list">
                    <p>
                        Work Phone Number
                        <span>
                            <template v-if="checkProperty(petition['beneficiaryInfo'] ,'workPhoneCountryCode' ,'countryCallingCode')">{{checkProperty(petition['beneficiaryInfo'] ,'workPhoneCountryCode' ,'countryCallingCode')+"&nbsp;"}}</template>
                            {{petition.beneficiaryInfo.workPhoneNumber | formatPhone}}</span>
                    </p>
                </div>
            </div>
    
        </div>
        <div class="vx-row m-0 main-list-panel" v-if="checkProperty(petition['beneficiaryInfo']  ,'education' ,'highestDegreeDetails')
                          || checkProperty(petition['beneficiaryInfo']  ,'education' ,'majorFieldOfStudy')
                          || checkProperty(petition['beneficiaryInfo']  ,'education' ,'majorFieldOfStudy')
                          || checkProperty(petition['beneficiaryInfo']  ,'beneficiaryInfo' ,'SSN')
                          //|| ( checkProperty(petition ,'beneficiaryInfo' ,'iAmFromUS') || !checkProperty(petition  ,'beneficiaryInfo' ,'iAmFromUS') )
                          || ( (checkProperty(petition ,'beneficiaryInfo' ,'hasI140ImmPetitionFiled')) ||  !(checkProperty(petition ,'beneficiaryInfo' ,'hasI140ImmPetitionFiled')) )
    
                        ">
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition['beneficiaryInfo']  ,'education' ,'highestDegreeDetails') ">
                <div class="main-list">
                    <p>
                        Highest Degree
                        <span>
                            {{
                                   checkProperty(petition['beneficiaryInfo']['education']  ,'highestDegreeDetails' ,'name')
                                  }}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition['beneficiaryInfo']  ,'education' ,'majorFieldOfStudy')">
                <div class="main-list">
                    <p>
                        Major Field of Study
                        <span>{{
                                   checkProperty(petition['beneficiaryInfo']  ,'education' ,'majorFieldOfStudy')
    
                                  }}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="petition.beneficiaryInfo.SSN">
                <div class="main-list">
                    <p>
                        Social Security Number
                        <span>{{petition.beneficiaryInfo.SSN}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'beneficiaryInfo','alienNumber')">
                <div class="main-list">
                    <p>
                        Alien Number
                        <span>{{checkProperty(petition,'beneficiaryInfo','alienNumber')}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition['beneficiaryInfo'], 'currentlyInUS') == false || checkProperty(petition['beneficiaryInfo'], 'currentlyInUS') == true">
                <div class="main-list">
                    <p>
                        Currently in USA 
                        <span>{{checkProperty(petition['beneficiaryInfo'], 'currentlyInUS') | booleanFormat }}</span>
                    </p>
                </div>
            </div>
            
            <div class="vx-col  md:w-1/3 w-full p-0" v-if="checkProperty(petition ,'beneficiaryInfo' ,'anyImmPetitionFiled') == true || checkProperty(petition ,'beneficiaryInfo' ,'anyImmPetitionFiled') == false ">
                <div class="main-list">
                    <p>
                        Has any immigrant Visa petition (PERM, I-140, I-485) ever been filed on your behalf?
                        <span>{{checkProperty(petition['beneficiaryInfo']  ,'anyImmPetitionFiled') | booleanFormat}}</span>
                    </p>
                </div>
            </div>
    
            <div class="vx-col md:w-1/3  w-full p-0" v-if="checkProperty(petition ,'beneficiaryInfo' ,'hasI140ImmPetitionFiled') == true || checkProperty(petition ,'beneficiaryInfo' ,'hasI140ImmPetitionFiled') == false" >
                <div class="main-list">
                    <p>
                        Has I-140 immigrant petition been filed on your behalf?
                        <span v-if="checkProperty(petition ,'beneficiaryInfo' ,'hasI140ImmPetitionFiled')"> Yes</span>
                        <span v-else> No</span>
                    </p>
                </div>
            </div>
           
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'beneficiaryInfo','applyI485AdjOrConsuProcess') == false || checkProperty(petition,'beneficiaryInfo','applyI485AdjOrConsuProcess') == true ">
                    <div class="main-list">
                        <p>
                            Would you like to apply for adjustment of status (I-485) or consular processing?
                            <span>{{petition.beneficiaryInfo.applyI485AdjOrConsuProcess | booleanFormat}}</span>
                        </p>
                    </div>
                </div>
                <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'beneficiaryInfo','adjustmentOfI485Status') == false || checkProperty(petition,'beneficiaryInfo','adjustmentOfI485Status') == true ">
                    <div class="main-list">
                        <p>
                            Adjustment of Status (I-485) 
                            <span>{{petition.beneficiaryInfo.adjustmentOfI485Status | booleanFormat}}</span>
                        </p>
                    </div>
                </div>
                <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'beneficiaryInfo','consularProcessing') == false || checkProperty(petition,'beneficiaryInfo','consularProcessing') == true ">
                    <div class="main-list">
                        <p>
                            Consular Processing 
                            <span>{{petition.beneficiaryInfo.consularProcessing | booleanFormat}}</span>
                        </p>
                    </div>
                </div>
                <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'beneficiaryInfo','areYouUnderRemoveOfIndOrUscis') == false || checkProperty(petition,'beneficiaryInfo','areYouUnderRemoveOfIndOrUscis') == true ">
                    <div class="main-list">
                        <p>
                            Are you currently under removal proceedings by the INS/USCIS
                            <span>{{petition.beneficiaryInfo.areYouUnderRemoveOfIndOrUscis | booleanFormat}}</span>
                        </p>
                    </div>
                </div>
            <div class="vx-col md:w-1/3  w-full p-0" v-if="checkProperty(petition ,'beneficiaryInfo' ,'haveYouEverTravelledToUS') == true || checkProperty(petition ,'beneficiaryInfo' ,'haveYouEverTravelledToUS') == false" >
                <div class="main-list">
                    <p>
                        Have you ever travelled to the United States?
                        <span>{{checkProperty(petition ,'beneficiaryInfo' ,'haveYouEverTravelledToUS') | booleanFormat}}</span>
                        <!-- <span v-if="checkProperty(petition ,'beneficiaryInfo' ,'haveYouEverTravelledToUS') == 'true'"> Yes</span>
                        <span v-else> No</span> -->
                    </p>
                </div>
            </div>

   
        <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition['beneficiaryInfo'],'stateDetailsOfLastEntryInUS') && checkProperty(petition['beneficiaryInfo'],'stateDetailsOfLastEntryInUS','name')  ">
            <div class="main-list">
                <p>
                    State of recent entry into the USA
                    <span>{{checkProperty(petition['beneficiaryInfo'],'stateDetailsOfLastEntryInUS','name')}}</span>
                </p>
            </div>
        </div>
        <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition['beneficiaryInfo'],'placeOfLastEntryInUS')">
            <div class="main-list">
                <p>
                    Place of recent entry into the USA
                    <span>{{checkProperty(petition['beneficiaryInfo'],'placeOfLastEntryInUS')}}</span>
                </p>
            </div>
        </div>
        <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition['beneficiaryInfo'],'lastArrivalDate')">
          <div class="main-list">
            <p>
              Date of most recent entry into the USA
              <span>{{petition.beneficiaryInfo.lastArrivalDate | formatDate}}</span>
            </p>
          </div>
      </div> 
      <template>
        
        <div class="vx-col  md:w-1/3 w-full p-0" v-if="checkProperty(petition['beneficiaryInfo']  ,'hasPermResidencyInOtherCountry') == true || checkProperty(petition['beneficiaryInfo']  ,'hasPermResidencyInOtherCountry') == false" >
            <div class="main-list">
                <p>
                    Do you hold Permanent residence in any other country
                    <span>{{checkProperty(petition['beneficiaryInfo']  ,'hasPermResidencyInOtherCountry') | booleanFormat}}</span>
                </p>
            </div>
        </div>
        <div class="vx-col  md:w-1/3 w-full p-0" v-if="checkProperty(petition ,'beneficiaryInfo' ,'hasPermResidencyInOtherCountry') && checkProperty(petition ,'beneficiaryInfo' ,'permResidencyCountryDetails')  && checkProperty(petition['beneficiaryInfo'] ,'permResidencyCountryDetails','name') " >
            <div class="main-list">
                <p>
                    Permanent Residency Country
                    <span>{{checkProperty(petition['beneficiaryInfo'] ,'permResidencyCountryDetails','name')}}</span>
                </p>
            </div>
        </div>
        <div class="vx-col  md:w-1/3 w-full p-0" v-if="checkProperty(petition['beneficiaryInfo']  ,'have2AffidavitsAttestingToMarriage') == true || checkProperty(petition['beneficiaryInfo']  ,'have2AffidavitsAttestingToMarriage') == false" >
            <div class="main-list">
                <p>
                    Do you have Two (2) Affidavits attesting to the Marriage
                    <span>{{checkProperty(petition['beneficiaryInfo']  ,'have2AffidavitsAttestingToMarriage') | booleanFormat}}</span>
                </p>
            </div>
        </div>
        
        <div class="vx-col  md:w-1/3 w-full p-0" v-if="checkProperty(petition['beneficiaryInfo']  ,'have2AffidavitsOfBirthFamily') == true || checkProperty(petition['beneficiaryInfo']  ,'have2AffidavitsOfBirthFamily') == false" >
            <div class="main-list">
                <p>
                    Do you have Two (2) Affidavits of Birth from family members
                    <span>{{checkProperty(petition['beneficiaryInfo']  ,'have2AffidavitsOfBirthFamily') | booleanFormat}}</span>
                </p>
            </div>
        </div>
       
        <div class="vx-col  md:w-1/3 w-full p-0" v-if="checkProperty(petition['beneficiaryInfo']  ,'haveYouArrestedBefore') == true || checkProperty(petition['beneficiaryInfo']  ,'haveYouArrestedBefore') == false" >
            <div class="main-list">
                <p>
                    Have you ever been arrested,cited, charged or detained for any reason by an law enforcement official
                    <span>{{checkProperty(petition['beneficiaryInfo']  ,'haveYouArrestedBefore') | booleanFormat}}</span>
                </p>
            </div>
        </div>
        <template v-if="checkProperty(petition['beneficiaryInfo'],'haveYouArrestedBeforeDocs') && checkProperty(petition['beneficiaryInfo'],'haveYouArrestedBeforeDocs','length')>0 && checkProperty(petition['beneficiaryInfo']  ,'haveYouArrestedBefore')">
            <vs-col class="padl0 padr0" v-if="checkProperty(petition['beneficiaryInfo'],'haveYouArrestedBeforeDocs','length')>0" >
                <documentsView @download_or_view="download_or_view" :type="'haveYouArrestedBeforeDocs'"  :documentsList="petition['beneficiaryInfo']['haveYouArrestedBeforeDocs']" :petitionDetails="petition" />
            </vs-col>
        </template>

      </template>
      <template>
            <div class="vx-col  md:w-1/3 w-full p-0" v-if="checkProperty(petition['beneficiaryInfo']  ,'everAppliedAOSInUS') == true || checkProperty(petition['beneficiaryInfo']  ,'everAppliedAOSInUS') == false" >
                <div class="main-list">
                    <p>
                        Have you ever applied AOS in the united states or an immigrant visa at the US Embassy/Consulate to obatain permanent resident status before
                        <span>{{checkProperty(petition['beneficiaryInfo']  ,'everAppliedAOSInUS') | booleanFormat}}</span>
                    </p>
                </div>
            </div>
            <template v-if="checkProperty(petition['beneficiaryInfo'],'appliedAOSInUSDocs') && checkProperty(petition['beneficiaryInfo'],'appliedAOSInUSDocs','length')>0 && checkProperty(petition['beneficiaryInfo']  ,'everAppliedAOSInUS')">
                <vs-col class="padl0 padr0" v-if="checkProperty(petition['beneficiaryInfo'],'appliedAOSInUSDocs','length')>0" >
                    <documentsView @download_or_view="download_or_view" :type="'appliedAOSInUSDocs'"  :documentsList="petition.beneficiaryInfo['appliedAOSInUSDocs']" :petitionDetails="petition" />
                </vs-col>
            </template>
            <div class="vx-col  md:w-1/3 w-full p-0" v-if="checkProperty(petition['beneficiaryInfo']  ,'birthCertHaveNamePobDob') == true || checkProperty(petition['beneficiaryInfo']  ,'birthCertHaveNamePobDob') == false" >
                <div class="main-list">
                    <p>
                        The birth certificate have your name, place of birth, date of birth, parents’ names mentioned, and the birth was registered around the time you were born
                        <span>{{checkProperty(petition['beneficiaryInfo']  ,'birthCertHaveNamePobDob') | booleanFormat}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col  md:w-1/3 w-full p-0" v-if="checkProperty(petition['beneficiaryInfo']  ,'inspectedByAnyImmOfficer') == true || checkProperty(petition['beneficiaryInfo']  ,'inspectedByAnyImmOfficer') == false" >
                <div class="main-list">
                    <p>
                        Were you inspected by an immigration officer
                        <span>{{checkProperty(petition['beneficiaryInfo']  ,'inspectedByAnyImmOfficer') | booleanFormat}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col  md:w-1/3 w-full p-0" v-if="checkProperty(petition['beneficiaryInfo']  ,'issuedAnyEADFromUSCIS') == true || checkProperty(petition['beneficiaryInfo']  ,'issuedAnyEADFromUSCIS') == false" >
                <div class="main-list">
                    <p>
                        Have you ever been issued an Employement Authorization Document(EAD) from the USCIS
                        <span>{{checkProperty(petition['beneficiaryInfo']  ,'issuedAnyEADFromUSCIS') | booleanFormat}}</span>
                    </p>
                </div>
            </div>
            <template v-if="checkProperty(petition['documents'],'eadCard') && checkProperty(petition['documents'],'eadCard','length')>0 && checkProperty(petition['beneficiaryInfo']  ,'issuedAnyEADFromUSCIS')">
                <vs-col class="padl0 padr0" v-if="checkProperty(petition['documents'],'eadCard','length')>0" >
                    <documentsView @download_or_view="download_or_view" :type="'eadCard'"  :documentsList="petition.documents['eadCard']" :petitionDetails="petition" />
                </vs-col>
            </template>
            <div class="vx-col  md:w-1/3 w-full p-0" v-if="checkProperty(petition['beneficiaryInfo']  ,'nameDiffFromBirthCert') == true || checkProperty(petition['beneficiaryInfo']  ,'nameDiffFromBirthCert') == false" >
                <div class="main-list">
                    <p>
                        Your name is different from that stated on your birth certificate, have you had it legally changes
                        <span>{{checkProperty(petition['beneficiaryInfo']  ,'nameDiffFromBirthCert') | booleanFormat}}</span>
                    </p>
                </div>
            </div>
        </template>
        </div>
        
      
        <div class="vx-row m-0 main-list-panel" v-if="checkProperty(petition ,'beneficiaryInfo', 'associations') && checkProperty(petition['beneficiaryInfo'], 'associations','length')>0 && checkProperty(petition['beneficiaryInfo']['associations'][0],'name') " >
        <h5 class="names_title">Associations/Groups</h5>
        <template  v-for="(item , ind)  in petition['beneficiaryInfo']['associations']">
            <div :key="ind" class="vx-row m-0 main-list-panel" v-if="checkProperty(petition ,'beneficiaryInfo', 'associations')">
                <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty( item,'name')">
                    <div class="main-list">
                        <p>
                            Name of the associations and groups
                            <span>{{checkProperty( item,'name')}}</span>
                        </p>
                    </div>
                </div>
                <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty( item,'natureofAssociations')">
                    <div class="main-list">
                        <p>
                            Nature of associations and groups
                            <span>{{checkProperty( item,'natureofAssociations')}}</span>
                        </p>
                    </div>
                </div>
                <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty( item,'startDate')">
                    <div class="main-list">
                        <p>
                            Start Date
                            <span>{{checkProperty( item,'startDate') | formatDate}}</span>
                        </p>
                    </div>
                </div>
                <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty( item,'endDate')">
                    <div class="main-list">
                        <p>
                            End Date
                            <span>{{checkProperty( item,'endDate') | formatDate}}</span>
                        </p>
                    </div>
                </div>
                <div class="vx-col md:w-1/3 w-full p-0" v-if=" checkProperty(item ,'address' )  && 
                        (
                            checkProperty(item ,'address' ,'line1' )

                           || checkProperty(item['address'] ,'locationDetails' ,'name' )
                            || checkProperty(item['address'] ,'stateDetails' ,'name' )
                             || checkProperty(item['address'] ,'countryDetails' ,'name' )

                        )
                         ">
                    <div class="main-list">
                <p>

                    Address
                    <span v-html="$options.filters.addressformat(item.address)"></span>

                </p>
            </div>
                </div>
            </div>
        </template>
        </div>
        <div class="vx-row m-0 main-list-panel" v-if=" checkProperty(petition ,'beneficiaryInfo' ,'address' )  && 
                            (
                                checkProperty(petition['beneficiaryInfo'] ,'address' ,'line1' )
    
                               || checkProperty(petition['beneficiaryInfo']['address'] ,'locationDetails' ,'name' )
                                || checkProperty(petition['beneficiaryInfo']['address'] ,'stateDetails' ,'name' )
                                 || checkProperty(petition['beneficiaryInfo']['address'] ,'countryDetails' ,'name' )
    
                            )
                             ">
    
            <div class="vx-col w-full p-0" >
                <div class="main-list">
                    <p>
    
                        Current Address
                        <span v-html="$options.filters.addressformat(petition.beneficiaryInfo.address)"></span>
    
                    </p>
                </div>
            </div>
        </div>
        <div class="vx-row m-0 main-list-panel" v-if=" checkProperty(petition ,'beneficiaryInfo' ,'currentAddress' )  && 
                    (
                        checkProperty(petition['beneficiaryInfo'] ,'currentAddress' ,'line1' )
    
                       || checkProperty(petition['beneficiaryInfo']['currentAddress'] ,'locationDetails' ,'name' )
                        || checkProperty(petition['beneficiaryInfo']['currentAddress'] ,'stateDetails' ,'name' )
                         || checkProperty(petition['beneficiaryInfo']['currentAddress'] ,'countryDetails' ,'name' )
    
                    )
                     ">
    
    <div class="vx-col w-full p-0" v-if=" checkProperty(petition ,'beneficiaryInfo' ,'currentAddress' )  && 
                    (
                        checkProperty(petition['beneficiaryInfo'] ,'currentAddress' ,'line1' )
    
                       || checkProperty(petition['beneficiaryInfo']['currentAddress'] ,'locationDetails' ,'name' )
                        || checkProperty(petition['beneficiaryInfo']['currentAddress'] ,'stateDetails' ,'name' )
                         || checkProperty(petition['beneficiaryInfo']['currentAddress'] ,'countryDetails' ,'name' )
    
                    )
                     ">
        <div class="main-list">
            <p>
    
               Mailing Address
                <span v-html="$options.filters.addressformat(petition.beneficiaryInfo.currentAddress)"></span>
    
            </p>
        </div>
    </div>
        </div>
        <div class="vx-row m-0 main-list-panel" v-if=" checkProperty(petition ,'beneficiaryInfo' ,'addressOutsideUS' )  && 
                    (
                        checkProperty(petition['beneficiaryInfo'] ,'addressOutsideUS' ,'line1' )
    
                       || checkProperty(petition['beneficiaryInfo']['addressOutsideUS'] ,'locationDetails' ,'name' )
                        || checkProperty(petition['beneficiaryInfo']['addressOutsideUS'] ,'stateDetails' ,'name' )
                         || checkProperty(petition['beneficiaryInfo']['addressOutsideUS'] ,'countryDetails' ,'name' )
    
                    )
                     ">
    
        <div class="vx-col w-full p-0" v-if=" checkProperty(petition ,'beneficiaryInfo' ,'addressOutsideUS' )  && 
                    (
                        checkProperty(petition['beneficiaryInfo'] ,'addressOutsideUS' ,'line1' )
    
                       || checkProperty(petition['beneficiaryInfo']['addressOutsideUS'] ,'locationDetails' ,'name' )
                        || checkProperty(petition['beneficiaryInfo']['addressOutsideUS'] ,'stateDetails' ,'name' )
                         || checkProperty(petition['beneficiaryInfo']['addressOutsideUS'] ,'countryDetails' ,'name' )
    
                    )
                     ">
        <div class="main-list">
            <p>
    
                Address Outside the U.S
                <span v-html="$options.filters.addressformat(petition.beneficiaryInfo.addressOutsideUS)"></span>
    
            </p>
        </div>
    </div>
        </div>
        <template v-if=" canRenderField('addressOfLastNYears',questionnaireDetails, false, 'beneficiaryInfo' ) &&
         checkProperty(petition ,'beneficiaryInfo' ,'addressOfLastNYears') &&  checkProperty(petition['beneficiaryInfo'] ,'addressOfLastNYears','length')>0 ">
        <div class="vx-row m-0 main-list-panel address_pad" v-if=" checkProperty(petition ,'beneficiaryInfo' ,'addressOfLastNYears' )  && 
                    (
                        checkProperty(petition['beneficiaryInfo']['addressOfLastNYears'][0] ,'line1' )

                    || checkProperty(petition['beneficiaryInfo']['addressOfLastNYears'][0] ,'locationDetails' ,'name' )
                        || checkProperty(petition['beneficiaryInfo']['addressOfLastNYears'][0] ,'stateDetails' ,'name' )
                        || checkProperty(petition['beneficiaryInfo']['addressOfLastNYears'][0] ,'countryDetails' ,'name' )

                    )
                    ">

        <div class="vx-col w-full p-0">
        <div class="main-list  p-0">
            <p>
                Residence starting with most current for the Past Five Years in the U.S and Abroad
                <template v-if="checkProperty(petition ,'beneficiaryInfo', 'addressOfLastNYears')">
                <div :key="ind" class="vx-row m-0 main-list-panel address_pad" >
                  <template v-for="(item , ind)  in petition['beneficiaryInfo']['addressOfLastNYears']">
                        <div class="vx-col  w-full mt-3 map-pointer">
                            <span v-html="$options.filters.addressformat(item)"></span>
                        </div>
                        <div class="main-list md:w-1/3 p-0 mt-1" v-if="canRenderField('startDate',questionnaireDetails, false, 'beneficiaryInfo.addressOfLastNYears' ) && item.startDate">
                           <p> Start Date<span>{{item.startDate | formatDate}}</span></p>
                        </div>
                        <div class="main-list md:w-1/3 p-0 mt-1" v-if="canRenderField('endDate',questionnaireDetails, false, 'beneficiaryInfo.addressOfLastNYears' ) && item.endDate">
                            <p>End Date<span>{{item.endDate | formatDate}}</span></p>
                        </div>
                      </template>
                   </div>
            </template>
            </p>
        </div>
       </div>
       </div>
        </template>
        <template v-if="canRenderField('addressOutsideUSMoreThanYear',questionnaireDetails, false, 'beneficiaryInfo' ) &&
        checkProperty(petition ,'beneficiaryInfo' ,'addressOutsideUSMoreThanYear' ) && checkProperty(petition['beneficiaryInfo'] ,'addressOutsideUSMoreThanYear','length' )>0 ">
        <div class="vx-row m-0 main-list-panel" v-if=" checkProperty(petition ,'beneficiaryInfo' ,'addressOutsideUSMoreThanYear' )  && 
                    (
                        checkProperty(petition['beneficiaryInfo']['addressOutsideUSMoreThanYear'][0] ,'line1' )

                    || checkProperty(petition['beneficiaryInfo']['addressOutsideUSMoreThanYear'][0] ,'locationDetails' ,'name' )
                        || checkProperty(petition['beneficiaryInfo']['addressOutsideUSMoreThanYear'][0] ,'stateDetails' ,'name' )
                        || checkProperty(petition['beneficiaryInfo']['addressOutsideUSMoreThanYear'][0] ,'countryDetails' ,'name' )

                    )
                    ">

        <div class="vx-col w-full p-0">
        <div class="main-list  p-0">
            <p>
            Last Address outside Of the United States for more than one year
            <template v-if="checkProperty(petition,'beneficiaryInfo','addressOutsideUSMoreThanYear')">
                    <div :key="ind" class="vx-row m-0 main-list-panel " >
                    <template v-for="(item , ind)  in petition['beneficiaryInfo']['addressOutsideUSMoreThanYear']">
                            <div class="vx-col  w-full p-0 mt-3">
                                <span v-html="$options.filters.addressformat(item)"></span>
                            </div>
                            <div class="main-list md:w-1/3 p-0 mt-1" v-if="canRenderField('startDate',questionnaireDetails, false, 'beneficiaryInfo.addressOutsideUSMoreThanYear' ) && item.startDate">
                            <p> Start Date<span>{{item.startDate | formatDate}}</span></p>
                            </div>
                            <div class="main-list md:w-1/3 p-0 mt-1" v-if="canRenderField('endDate',questionnaireDetails, false, 'beneficiaryInfo.addressOutsideUSMoreThanYear' ) && item.endDate">
                                <p>End Date<span>{{item.endDate | formatDate}}</span></p>
                            </div>
                        </template>
                    </div>
                </template>
            </p>
        </div>
        </div>
        
            
        </div>
        </template>
        <div class="vx-row m-0 main-list-panel" v-if="checkProperty(petition, 'beneficiaryInfo' ,'I140ImmPetitionFiledDetails' ) && checkProperty(petition, 'beneficiaryInfo' ,'hasI140ImmPetitionFiled' ) ">
            <div class="vx-col w-full p-0">
                <div class="main-list">
                    <p>
                        Has an I-140 immigrant petition been filed on your behalf? Details
                        <span>{{petition.beneficiaryInfo.I140ImmPetitionFiledDetails}}</span>
                    </p>
                </div>
            </div>
        </div>
        <div class="vx-row m-0 main-list-panel" v-if="false && petition.beneficiaryInfo.priorPeriodOfStayInUS && petition.beneficiaryInfo.priorPeriodOfStayInUS.length > 0  && checkProperty(petition['beneficiaryInfo']['priorPeriodOfStayInUS'][0],'visaStatus')!=null">
            <div class="vx-col w-full p-0">
                <div class="tabs-content-table mt-2 priorPeriodtable">
                    <p>
                        All prior periods of stay in the U.S. over the last seven years</p>
                    <template>
                       
                        <vs-table :data="petition.beneficiaryInfo.priorPeriodOfStayInUS"> 
    
                            <template>
                                <template slot="thead">
                                    <vs-th>Case Status</vs-th>
                                    <vs-th>Date Entered</vs-th>
                                    <vs-th>Date Departed</vs-th>
                                    <vs-th v-if="checkNoofDays">No. of Days</vs-th>
                                </template>
                                <template>
                                    <vs-tr :key="sin" v-for="(stay ,sin) in petition.beneficiaryInfo.priorPeriodOfStayInUS">
                                        <vs-td> {{ stay.visaStatus  | formatML(visastatuses)}}</vs-td>
                                        <vs-td>{{stay.enteredDate | formatDate}}</vs-td>
                                        <vs-td>{{stay.departedDate | formatDate}}</vs-td>
                                         <!-- {{ visastatuses | visastatus(stay.visaStatus) }}-->
                                        
                                        <vs-td v-if="checkNoofDays">{{stay.noOfDays}}</vs-td>
                                    </vs-tr>
                                </template>
                            </template>
                        </vs-table>
    
                        <template v-if="petition.beneficiaryInfo.noOfDaysStayInUS > 1095 && petition.beneficiaryInfo.confirmDaysStayInUS">
    
                            Total No. of days in the US in H/L status - {{noOfDaysStayInUS}}
                        </template>
                        <template v-if="noOfDaysStayInUS > 2185">
    
                            <label class="form_label pb-5 pt-5">Note: Please note that you are allowed a maximum period of 6 years on your H-1B. To receive H-1B approval past 6 years you need to either have an approved I-140 or PERM application pending for more than 364 days. Please confirm if you have the following:</label>
    
                            Approved I-140 (from any employer that has not been revoked within 180 days of its approval) {{hasApprovedI140?'Yes':'No'}}
                            PERM application pending for more than 365 days {{hasPermPendingForMorethan365Days?'Yes':'No'}}
    
                        </template>
    
                    </template>
                </div>
            </div>
        </div>

        <div class="vx-row m-0 main-list-panel" >
           <div class="vx-col md:w-1/3  w-full p-0" v-if="checkProperty(petition, 'beneficiaryInfo' ,'haveYouEverEmployed' ) ">
                <div class="main-list">
                    <p>
                        Have you ever been employed Outside US?
                        <span>{{petition.beneficiaryInfo.haveYouEverEmployed | booleanFormat}}</span>
                    </p>
                </div>
            </div> 
            <!-- <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition, 'beneficiaryInfo' ,'hasMasterDegreeInUS' ) ">
                <div class="main-list">
                    <p>
                        Do you have Masters degree in United States?
                        <span>{{petition.beneficiaryInfo.hasMasterDegreeInUS | booleanFormat}}</span>
                    </p>
                </div>
            </div> -->
            <div class="vx-col md:w-1/3 w-full p-0"  v-if="checkProperty(petition, 'beneficiaryInfo' ,'hasAnyDependetsinUStoFileH4' ) ">
                <div class="main-list">
                    <p>
                        Do you have any dependents currently in USA for whom you wish to file H4 Visa?
                        <span>{{petition.beneficiaryInfo.hasAnyDependetsinUStoFileH4 | booleanFormat}}</span>
                    </p>
                </div>
            </div>
        </div> 
        

      
        <div class="vx-row m-0 main-list-panel" v-if="checkProperty(petition , 'beneficiaryInfo', 'maritalStatus') !== 1 && [5, 8].indexOf(checkProperty(petition ,'subTypeDetails','id')) < 0 && checkProperty(petition['dependentsInfo'] ,'spouse')
        && (checkProperty(petition['dependentsInfo'] ,'spouse' ,'h4Required') == true || checkProperty(petition['dependentsInfo'] ,'spouse' ,'h4Required') == false)">
            <div class="vx-col md:w-1/3 w-full p-0">
                <div class="main-list">
    
                    <p>
                        H4 required for spouse?
                        <span v-if="checkProperty(petition['dependentsInfo'] ,'spouse' ,'h4Required')">Yes</span>
                        <span v-else>No</span>
                    </p>
                </div>
            </div>
        </div>

    </div>
    </template>
    
    <script>
    import documentsView from "@/views/common/documentsView.vue";
    import _ from "lodash";
    export default {
        data: ()=>({
        visastatuses:[],
        marital_statuses:[],
      }),
        props: {
            petition: {
                type: Object,
                default: null
            },
            tplSection:{
                type:String,
                default:''
            },
            questionnaireDetails:{
                type: Array,
                default: null
            }
            // visastatuses: {
            //     type: Array,
            //     default: null
            // }
        },
        computed: {
            checkNoofDays(){
                let returnVal = true
                //petition.beneficiaryInfo.priorPeriodOfStayInUS
                if(this.checkProperty(this.petition['beneficiaryInfo'] ,'priorPeriodOfStayInUS') && this.checkProperty(this.petition['beneficiaryInfo'] ,'priorPeriodOfStayInUS', 'length')>0 ){
                   let noOfDaysList =  _.filter(this.petition.beneficiaryInfo.priorPeriodOfStayInUS, (item)=>{
                        if(item && item['noOfDays']){
                           return item
                        }
                    })
                    if(noOfDaysList && this.checkProperty(noOfDaysList,'length')>0){
                        returnVal = true
                    }else{
                        returnVal = false
                    }
                }
                return returnVal
            },
            showRouteName(){
                if(this.$route.name == 'questionnaire'){
                    return false
                }
                else{
                    return true
                }
            }
        },
        methods:{
            convertHeight(val){
                
                if(val){
                    let returnVal = null;
                    let feet = ''
                    let inches = ''
                    if( _.has(val,'feet')){
                        feet = val['feet']
                    }
                    if(_.has(val,'inches')){
                        inches = val['inches']
                    }
                    if(feet){
                        returnVal = feet+"'"+inches+"''"
                    }
                    return returnVal
                }
            },
            download_or_view(value) {
            this.$emit('download_or_view' ,value);
         },
            formatFullname(item){
                    let returnVal = ''
                    if(this.checkProperty(item,'name')){
                        return returnVal = this.checkProperty(item,'name')
                    }
                    else{
                        if(this.checkProperty(item,'firstName')){
                            returnVal = this.checkProperty(item,'firstName')
                        }
                        if(this.checkProperty(item,'middleName')){
                             returnVal = returnVal +' '+ this.checkProperty(item,'middleName')
                        }
                        if(this.checkProperty(item,'lastName')){
                            returnVal =  returnVal +' '+this.checkProperty(item,'lastName')
                        }
                        return returnVal
                    }
                },
            getVisastatues(){
          this.$store.dispatch("getmasterdata", "visa_status").then((response) => {
            this.visastatuses = response;
          });
        },
        },
        mounted(){
            this.$store.dispatch("getmasterdata", "marital_status").then((response) => {
                this.marital_statuses = response;
            });
            this.getVisastatues()
        },
        components:{
            documentsView,
        },
    };
    </script>
    