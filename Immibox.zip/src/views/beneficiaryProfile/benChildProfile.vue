<template>
    <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12">
        <div class="form-container pt-5">
            <div class="vx-row">
                <!-- @input="setOutsideAddress" -->
                <immiswitchyesno :required="checkFieldIsRequired({'key':'currentlyInUS','section':tplsection, 'fieldsArray':fieldsArray, 'required':true,'notRequired':true })" :display="false" :tplkey="'currentlyInUS'" :tplsection="tplsection" wrapclass=" " :fieldsArray="fieldsArray" :cid="'chi_currentlyInUS'"  :formscope="formscope" v-model="value.currentlyInUS" fieldName="chi_currentlyInUS" label="Are you currently in USA?" placeHolder="Are you currently in USA" />
    
                    <template >
                        <div class="vx-col w-full" v-if="canRenderField('adjustmentOfI485Status', fieldsArray ,false,tplsection) || canRenderField('consularProcessing', fieldsArray ,false,tplsection) ">
                    <label class="switch-label">Would you like to apply for adjustment of status (I-485) or consular processing? </label>
                       </div>
                        <div class="vs-col " v-if="canRenderField('adjustmentOfI485Status', fieldsArray ,false,tplsection)" >
    
                        <div class="form_group custom-form-label custom-cx-box">
    
                        <vs-checkbox
                        v-model="value.adjustmentOfI485Status"
                        data-vv-as="childadjustmentOfI485Status"
                        name="childadjustmentOfI485Status"
                        @change="changedAdjustmentOfI485Status"
                        >Adjustment of Status (I-485)
    
                        <p>When your Priority Date is current, and you have a valid status in the U.S. by then, you may file I-485 to get your Green Card</p>
    
                        </vs-checkbox>
    
                        </div>
    
                        </div>
                        <div class="vs-col " v-if="canRenderField('consularProcessing', fieldsArray ,false,tplsection)" >
                        <div class="form_group custom-form-label custom-cx-box">
                            <vs-checkbox v-model="value.consularProcessing"  data-vv-as="childconsularProcessing"  name="childconsularProcessing"  @change="changedConsularProcessing"
                            >Consular Processing
    
                        <p>When your Priority Date is current, and you would like to go to a U.S. consulate 
                        abroad to apply for an immigrant visa to get your Green Card</p>
                        </vs-checkbox>
                        </div>
                        <!-- <input  v-if="!value.consularProcessing &&  !value.adjustmentOfI485Status" type="hidden" :name="'childconsularProcessing'" v-validate="'required'"   v-model="consularProcessingValidator">
                        <span v-if="formscope" class="text-danger text-sm" v-show="errors.has(formscope+'.childconsularProcessing')">* Adjustment of Status (I-485)/Consular Processing is required</span>
                        <span v-else class="text-danger text-sm" v-show="errors.has('childconsularProcessing')">* Adjustment of Status (I-485)/Consular Processing is required</span> -->
                        
                        </div>
                     </template>
    
                <immiyesorno :cid="'h4EADRequired'" :formscope="formscope" :required="checkFieldIsRequired({'key':'h4EADRequired','section':tplsection, 'fieldsArray':fieldsArray, 'required':true,'notRequired':true })" :display="false" :tplkey="'h4EADRequired'" :tplsection="tplsection" :wrapclass="'h4_ead_label mb-0'" :fieldsArray="fieldsArray" v-model="value.h4EADRequired" fieldName="child_h4_ead_required" label="H4 EAD required for Child?"></immiyesorno>
                <immiswitchyesno :required="checkFieldIsRequired({'key':'applyingWithYou','section':tplsection, 'fieldsArray':fieldsArray, 'required':true,'notRequired':true })" wrapclass=" " :display="false" :tplkey="'applyingWithYou'"  :fieldsArray="fieldsArray" :cid="'applyingWithYou'" :formscope="formscope" v-model="value.applyingWithYou" :tplsection="tplsection"  :fieldName="'applyingWithYou'"   label="Applying with you?" placeHolder="" />
                <div class="divider full-divider mb-10"></div>
    
                <div class="vx-col w-full">
                    <vx-input-group class="form-input-group FML">
                        <immiInput  :display="false" :tplkey="'firstName'" :tplsection="tplsection" :fieldsArray="fieldsArray" cid="benf" :formscope="formscope" v-model="value.firstName" :required="true" fieldName="child_first_name" label="First Name" placeHolder="First Name" />
                        <immiInput :notRequired="notRequired" :display="false" :tplkey="'middleName'" :tplsection="tplsection" :fieldsArray="fieldsArray" cid="benm" :formscope="formscope" v-model="value.middleName" :required="true" fieldName="child_middle_name" label="Middle Name" placeHolder="Middle Name" />
                        <immiInput :notRequired="notRequired" :display="false" :tplkey="'lastName'" :allowUpperCase="petition.tenantDetails && checkProperty(petition,'tenantDetails','slug') &&  checkProperty(petition,'tenantDetails','slug') == 'slg'" :tplsection="tplsection" :fieldsArray="fieldsArray" cid="benl" :formscope="formscope" v-model="value.lastName" :required="true" fieldName="child_last_name" label="Last Name" placeHolder="Last Name" />
                    </vx-input-group>
                </div>
    
                <div class="vx-col w-full mb-5 yesno-v2" v-if="canRenderField('hasOtherNames', fieldsArray ,false,tplsection)">
                    <div class="d-block align-center">
                        <a class="switch-label nowrap_whtspc">
                            Have you used any other names previously?
                        </a><em v-if="checkFieldIsRequired({'key':'hasOtherNames','section':tplsection, 'fieldsArray':fieldsArray, 'required':true ,'notRequired':true})">*</em>
                        <!-- <vs-switch v-model="value.hasOtherNames" @input="resetOtherNames(value.hasOtherNames)">
                            <span slot="on">Yes</span>
                            <span slot="off">No</span>
                        </vs-switch> -->
                        <ul class="custom-radio custom-radio_v2">
                            <li>
                                <vs-radio ref="yes" v-model="value.hasOtherNames" vs-name="hasOtherNames" :vs-value="true"  @input="resetOtherNames(value.hasOtherNames)">Yes</vs-radio>
                            </li>
                            <li>
                                <vs-radio ref="no" v-model="value.hasOtherNames" vs-name="hasOtherNames" :vs-value="false"  @input="resetOtherNames(value.hasOtherNames)" >No</vs-radio>
                            </li> 
                        </ul>
                        <div class="form_group" v-if="checkFieldIsRequired({'key':'hasOtherNames','section':tplsection, 'fieldsArray':fieldsArray, 'required':true,'notRequired':true })">
                            <input type="hidden" :name="'otherNames_chidldInfo'" v-validate="'required'"  data-vv-as="Field"  v-model="value.hasOtherNames">
                            <span v-show="errors.has( formscope+'.otherNames_chidldInfo')" class="text-danger text-sm mart-4">*Field is required</span>
                        </div>
                        
                    </div>
                    <span class="inline_note pt-4">(NOTE: Please enter the name if you have a different name in the educational document other than passport.)</span>
                </div>
    
                <template v-if="value && value.hasOtherNames && canRenderField('hasOtherNames', fieldsArray ,false,tplsection)">
                    <div class="vx-col w-full" v-for="(item, ind) in value['otherNames']" :key="ind">
                        <vx-input-group class="form-input-group delete-rows-cst FML">
                            <immiInput :notRequired="notRequired" :display="false" :tplkey="'firstName'" :tplsection="tplsection" :formscope="formscope" :cid="'benf'+ind" v-model="item.firstName" :required="false" fieldName="child_last_name" label="First Name" placeHolder="First Name" />
                            <immiInput :notRequired="notRequired" :display="false" :tplkey="'middleName'" :tplsection="tplsection" :formscope="formscope" :cid="'benm'+ind" v-model="item.middleName" :required="false" fieldName="child_middle_name" label="Middle Name" placeHolder="Middle Name" />
                            <immiInput :notRequired="notRequired" :display="false" :allowUpperCase="petition.tenantDetails && checkProperty(petition,'tenantDetails','slug') &&  checkProperty(petition,'tenantDetails','slug') == 'slg'" :tplkey="'lastName'" :tplsection="tplsection" :formscope="formscope" :cid="'benl'+ind" v-model="item.lastName" :required="false" fieldName="child_last_name" label="Last Name" placeHolder="Last Name" />
                            <div class="delete delete_spousechild" v-if="ind > 0" @click="removeOtherName(ind)">
                                <a>
                                    <img src="@/assets/images/main/delete-row-img.svg" />
                                </a>
                            </div>
                        </vx-input-group>
                        <a class="add-more add-more-names mb-10" v-if="value['otherNames'].length - 1 ==ind" @click="addOtherNames()"><span>+</span>Add</a>
                    </div>
                </template>
    
                <immiInput :notRequired="notRequired" datatype="email"  :display="false" :tplkey="'email'" :tplsection="tplsection" :fieldsArray="fieldsArray" :cid="'chi_email'+ind" :formscope="formscope" v-model="value.email" :required="true" :fieldName="'chi_email'+ind" label="Email" placeHolder="Email" />
               
                <immiPhone  
                :notRequired="notRequired"
                :display="false"
                 :tplsection="tplsection"
                 :tplkey="'phoneNumber'"
                 :fieldsArray="fieldsArray"
                  @updatephoneCountryCode="updatephoneCountryCode"
                  :countrycode="value.phoneCountryCode.countryCode" 
                  :cid="'child_PhoneNumber'+ind" 
                  :formscope="formscope" 
                  v-model="value.phoneNumber" 
                  
                    :required="false" label="Phone Number"
                     placeHolder="Phone Number" 
                     />
                                                
    
                <selectField :notRequired="notRequired" :display="false" :tplkey="'relationship'" :tplsection="tplsection" :listContainsId="false" :fieldsArray="fieldsArray" :required="true" :optionslist="petition.relationships" v-model="value.relationship" :formscope="formscope" fieldName="chi_relationship" label="Your Relationship with the dependent" placeHolder="Relationship" />
    
                <datepickerField :notRequired="notRequired" :display="false" :tplkey="'dateOfBirth'" :tplsection="tplsection" :fieldsArray="fieldsArray" :dateEnableTo="featureDates" :validationRequired="true" v-model="value.dateOfBirth" :formscope="formscope" fieldName="child_dob" label="Date of Birth" />
                <selectField :notRequired="notRequired" :display="false" :tplkey="'countryOfBirth'" :tplsection="tplsection" :fieldsArray="fieldsArray" @input="changeBfProvince" :required="true" :optionslist="countriesWithoutUS" v-model="value.countryOfBirthDetails" :formscope="formscope" fieldName="child_cob" label="Country of Birth" placeHolder="Country of Birth" />
    
                <selectField :notRequired="notRequired" :display="false" :tplkey="'provinceOfBirth'" :tplsection="tplsection" :fieldsArray="fieldsArray" @input="value.provinceOfBirth = value.provinceOfBirthDetails.id" :required="true" v-if="bfeprovinceStates.length > 0" :optionslist="bfeprovinceStates" v-model="value.provinceOfBirthDetails" :formscope="formscope" fieldName="chi_provinceOfBirth" label="Province of Birth" placeHolder="Province of Birth" />
                <immiInput :notRequired="notRequired" :display="false" :tplkey="'locationOfBirth'" :tplsection="tplsection" :fieldsArray="fieldsArray" cid="benflocationOfBirth" :formscope="formscope" v-model="value.locationOfBirth" :required="true" fieldName="chi_locationOfBirth" label="Location of Birth" placeHolder="Location of Birth" />
                <selectField :notRequired="notRequired" :display="false" :tplkey="'countryOfCitizenship'" :tplsection="tplsection" :fieldsArray="fieldsArray" @input="value.countryOfCitizenship = value.countryOfCitizenshipDetails.id" :required="true" :optionslist="countries" v-model="value.countryOfCitizenshipDetails" :formscope="formscope" fieldName="child_country_of_citizenship" label="Country of Citizenship" placeHolder="Country of Citizenship" />
    
                
                <div class="vx-col w-full" v-if="canRenderField('passportNumber', fieldsArray ,false,tplsection) || canRenderField('passportIssuedDate', fieldsArray ,false,tplsection) || canRenderField('passportExpiryDate', fieldsArray ,false,tplsection)  ">
                    <h3 class="small-header">Passport</h3>
                </div>
                <immiInput :notRequired="notRequired" :allowUpperCase="true" :display="false" :tplkey="'passportNumber'" :tplsection="tplsection" :fieldsArray="fieldsArray" datatype="alpha_num|max:15" cid="benfpassportNumber" :formscope="formscope" v-model="value.passportNumber" :required="true" fieldName="child_passport_number" label="Passport Number" placeHolder="Passport Number" />
                <datepickerField :notRequired="notRequired" :display="false" :tplkey="'passportIssuedDate'" :tplsection="tplsection" :fieldsArray="fieldsArray" :validationRequired="true" v-model="value.passportIssuedDate" :formscope="formscope" fieldName="chi_passportIssuedDate" :dateEnableTo="featureDates" label="Passport Issued Date" />
                <datepickerField :notRequired="notRequired" :display="false" :tplkey="'passportExpiryDate'" :tplsection="tplsection" :fieldsArray="fieldsArray"  :dateEnableFrom="featureDates" :validationRequired="true" v-model="value.passportExpiryDate" :formscope="formscope" fieldName="child_passport_expiry_date" label="Passport Expiry Date" />
                <selectField :notRequired="notRequired"  :display="false" :tplkey="'passportIssuedCountry'" :fieldsArray="fieldsArray" @input="value.passportIssuedCountry = value.passportIssuedCountryDetails.id" :required="true" :optionslist="countries" v-model="value.passportIssuedCountryDetails"  :tplsection="tplsection"  :fieldName="'passportIssuedCountry'" cid="passportIssuedCountry" :formscope="formscope"  label="Country of Passport Issued" placeHolder="Country of Passport Issued" />
                
    
                <template v-if="value.h4EADRequired">
                <selectField :notRequired="notRequired" :display="false" :fieldsArray="fieldsArray"  @input="value.stateOfLastEntryInUS =value.stateDetailsOfLastEntryInUS.id" :required="true" :optionslist="usastates" v-model="value.stateDetailsOfLastEntryInUS" :tplsection="tplsection"  :tplkey="'stateOfLastEntryInUS'" :fieldName="'stateOfLastEntryInUS'"  :formscope="formscope"  label="State of recent entry into the USA" placeHolder="State of recent entry into the USA" />
                <immiInput :notRequired="notRequired" :display="false" :fieldsArray="fieldsArray"  cid="placeOfLastEntryInUS" :formscope="formscope" v-model="value.placeOfLastEntryInUS" :tplsection="tplsection" :tplkey="'placeOfLastEntryInUS'" :fieldName="'placeOfLastEntryInUS'"  :required="true"  label="Place of recent entry into the USA" placeHolder="Place of recent entry into the USA" />
                <datepickerField :notRequired="notRequired" :display="false" :tplkey="'lastArrivalDate'" :tplsection="tplsection" :fieldsArray="fieldsArray" :dateEnableTo="featureDates" :validationRequired="true" v-model="value.lastArrivalDate" :formscope="formscope" fieldName="child_date_of_last_arrival" label="Date of most recent entry into the USA" />
            </template>
            <template v-if="(canRenderField('currentlyInUS',fieldsArray, false, tplsection ) && checkProperty(value,'currentlyInUS') || !canRenderField('currentlyInUS',fieldsArray, false, tplsection ) )">
                <div class="vx-col w-full">
                    <h3 class="small-header">Status in USA</h3>
                </div>
                <selectField :notRequired="notRequired" :display="false" :tplkey="'currentStatus'" :tplsection="tplsection" :fieldsArray="fieldsArray" @input="value.currentStatus = value.currentStatusDetails.id;checkDSExpireFields()" :validationRequired="value.statusExpiryDate != null"  :required="value.currentlyInUS || value.statusExpiryDate != null" :optionslist="petition.visaStatusList" v-model="value.currentStatusDetails" :formscope="formscope" fieldName="child_current_status" label="Current Status" vvas="Current Status" placeholder="Current Status" />
                <div class="vx-col w-full md:w-1/2 relative" v-if="canRenderField('isDSExpiryDate',fieldsArray, false, tplsection )&& checkProperty(value,'currentStatusDetails')&& checkProperty(value,'currentStatusDetails','id') ||canRenderField('statusExpiryDate',fieldsArray, false, tplsection )  ">
                    <div class="vs-col ds_check ds_check_v2"  v-if="canRenderField('isDSExpiryDate',fieldsArray, false, tplsection )&& checkProperty(value,'currentStatusDetails')&& checkProperty(value,'currentStatusDetails','id')  " >
                        <div class="form_group custom-form-label custom-cx-box">
                            <vs-checkbox v-model="value.isDSExpiryDate" :tplsection="'beneficiaryInfo'" :fieldName="'isDSExpiryDate'"  data-vv-as="isDSExpiryDate"  name="isDSExpiryDate"  @input="clearCurrentStatusField"
                            >Check here if D/S
                            </vs-checkbox>
                        </div>
                    </div>
                    <datepickerField :notRequired="notRequired" :wrapclass="'md:w-full'" :isDisabled="(canRenderField('isDSExpiryDate',fieldsArray, false, tplsection ) && value.isDSExpiryDate) || !value.currentStatus " 
                      :display="false" :tplkey="'statusExpiryDate'" :tplsection="tplsection" :fieldsArray="fieldsArray" :dateEnableFrom="featureDates" :validationRequired="value.currentStatusDetails != null" v-model="value.statusExpiryDate" :formscope="formscope" fieldName="child_status_expiry_date" label="Current Status Expiry Date" />
                </div>
                <immiInput :notRequired="notRequired" :allowUpperCase="true" :display="false" :tplkey="'I94'" :tplsection="tplsection" :fieldsArray="fieldsArray" cid="benI94" datatype="max:15" :formscope="formscope" v-model="value.I94" @input="I94ValueCheck(value.I94)" :required="value.currentlyInUS" fieldName="child_i94" label="I-94 Number" placeHolder="I-94 Number" />
                <div class="vx-col w-full md:w-1/2 relative" v-if="canRenderField('isI94DSExpiryDate',fieldsArray, false, tplsection )&& checkProperty(value,'I94') ||canRenderField('statusExpiryDate',fieldsArray, false, tplsection )  ">
                    <div class="vs-col ds_check ds_check_v2"  v-if="canRenderField('isI94DSExpiryDate',fieldsArray, false, tplsection )&& checkProperty(value,'I94') " >
                        <div class="form_group custom-form-label custom-cx-box">
                            <vs-checkbox v-model="value.isI94DSExpiryDate" :tplsection="'beneficiaryInfo'" :fieldName="'isI94DSExpiryDate'"  data-vv-as="isI94DSExpiryDate"  name="isI94DSExpiryDate"  @input="clearI94Field"
                            >Check here if D/S
                            </vs-checkbox>
                        </div>
                    </div>
                    <datepickerField :notRequired="notRequired" :wrapclass="'md:w-full'" :display="false" :isDisabled="(canRenderField('isI94DSExpiryDate',fieldsArray, false, tplsection ) && value.isI94DSExpiryDate) || ( value.I94=='' && disablefield)"   :tplkey="'I94ExpiryDate'" :tplsection="tplsection" :fieldsArray="fieldsArray" :validationRequired="value.I94!=null && value.I94!=''" v-model="value.I94ExpiryDate" :formscope="formscope" :dateEnableFrom="featureDates" fieldName="child_i94_expiry_date" label="I-94 Expiry Date" />
                </div>
                <immiInput :notRequired="notRequired" :allowUpperCase="true" :display="false" :mRequired="[1,2].indexOf(checkProperty(value,'currentStatusDetails','id'))>-1?true:false" :tplkey="'sevisNumber'" :fieldsArray="fieldsArray" datatype="alpha_num|max:15" cid="benfsevisNumber" :formscope="formscope" v-model="value.sevisNumber" :tplsection="tplsection"  :fieldName="'sevisNumber'"    label="SEVIS  Number" placeHolder="SEVIS  Number" />
                <immiInput :notRequired="notRequired" :allowUpperCase="true" :display="false" :tplkey="'eadNumber'"  :fieldsArray="fieldsArray" datatype="alpha_num|min:9|max:20" cid="benfeadNumber" :formscope="formscope" v-model="value.eadNumber" :maxCharacters="20" :tplsection="tplsection"  :fieldName="'eadNumber'"   label="EAD  Number" placeHolder="EAD  Number" />
            </template>
    
    
    
    
    
    
                
                
                
               
                <div class="vx-col w-full" >
                    <template v-if="(canRenderField('currentlyInUS',fieldsArray, false, tplsection ) && checkProperty(value,'currentlyInUS')) || !canRenderField('currentlyInUS',fieldsArray, false, tplsection ) ">
                        <div v-if="canRenderField('physicalAddress', fieldsArray ,false,tplsection)">
                        <h3 class="small-header">Current Address</h3>
        
                        
                            <addressField :prefiilAddress="prefillCountryInQuestionnaire == false||([10,8].indexOf(checkProperty(petition,'subTypeDetails','id'))>-1 && checkProperty(petition,'typeDetails','id')==1 )?false:true" 
                            :fieldsArray="fieldsArray" :disableCountry="value.currentlyInUS" :formscope="formscope" :showaptType="true" :addFormContainerCls="false" :validationRequired="checkFieldIsRequired({'key':'physicalAddress','section':tplsection, 'fieldsArray':fieldsArray, 'required':true,'notRequired':true })" :countries="countries" v-model="value.physicalAddress" :cid="'chi_Infoaddress'" />
    
                        </div>
                    </template>
    
                    <div v-if="canRenderField('addressOutsideUS', fieldsArray ,false,tplsection)">
                        <h3 class="small-header">Address Outside the U.S</h3>
                        <addressField :prefiilAddress="prefillCountryInQuestionnaire" :fieldsArray="fieldsArray" :validationRequired="checkFieldIsRequired({'key':'addressOutsideUS','section':tplsection, 'fieldsArray':fieldsArray, 'required':true,'notRequired':true })" :hideusa="true" :disableCountry="false" :formscope="formscope" :showaptType="true" :addFormContainerCls="false" :countries="countries" v-model="value.addressOutsideUS" fieldName="chi_addressOutsideUS" :cid="'chi_addressOutsideUS'" />
    
                    </div>
                </div>
    
                <immiMask :notRequired="notRequired" :display="false" :tplkey="'SSN'" :tplsection="tplsection" :fieldsArray="fieldsArray" :patren="['### - ## - ####']" datatype="min:9|max:9" :wrapclass="canRenderField('chi_alienNumber',fieldsArray)?'md:w-1/2':' '" cid="child_ssn" :formscope="formscope" v-model="value.SSN" :required="false" fieldName="child_ssn" label="Social Security number (if applicable)" vvas="Social Security number" placeHolder="123 - 45 - 6789" />
                <immiInput :notRequired="notRequired" :display="false" :tplkey="'alienNumber'" :tplsection="tplsection" :fieldsArray="fieldsArray" datatype="alpha_num|max:9" cid="chi_alienNumber" :formscope="formscope" v-model="value.alienNumber" fieldName="chi_alienNumber" label="Alien Number (if applicable)" placeHolder="Alien Number" />
                <immiyesorno :cid="'haveYouEverTravelledToUS'" :formscope="formscope" :required="checkFieldIsRequired({'key':'haveYouEverTravelledToUS','section':tplsection, 'fieldsArray':fieldsArray, 'required':true,'notRequired':true })" :wrapclass="'swicth-label_v2 yesno-v2 formgroup-mb0 yesnomar'" :display="false" :tplkey="'haveYouEverTravelledToUS'" :fieldsArray="fieldsArray"   v-model="value.haveYouEverTravelledToUS" :tplsection="tplsection"  :fieldName="'haveYouEverTravelledToUS'"   label="Have you ever travelled to the United States?"></immiyesorno>
                <template v-if="(canRenderField('haveYouEverTravelledToUS',fieldsArray,false ,tplsection)  && value.haveYouEverTravelledToUS && canRenderField('priorPeriodOfStayInUS', fieldsArray ,false,tplsection )) || (!canRenderField('haveYouEverTravelledToUS',fieldsArray,false ,tplsection) && canRenderField('priorPeriodOfStayInUS', fieldsArray ,false,tplsection )) ">
                    <immipriorstay :notRequired="notRequired"  :tplsection="getTplSection" :noday="false" :fieldsArray="fieldsArray" :formscope="formscope" v-if="petition && petition.visaStatusList && petition.visaStatusList.length > 0 && canRenderField('priorPeriodOfStayInUS', fieldsArray ,false,tplsection )" fieldName="chi_priorPeriodOfStayInUS" :petition="petition" v-model="value.priorPeriodOfStayInUS"></immipriorstay>
                </template>
            </div>
        </div>
    </vs-col>
    </template>
    
    <script>
    import genderField from '@/views/forms/fields/gender.vue'
    import immiInput from "@/views/forms/fields/simpleinput.vue";
    import {
        Trash2Icon
    } from "vue-feather-icons";
    import addressField from "@/views/forms/fields/address.vue";
    import datepickerField from "@/views/forms/fields/datepicker.vue";
    import selectField from "@/views/forms/fields/simpleselect.vue";
    import immiPhone from "@/views/forms/fields/phonenumber.vue";
    import immiMask from "@/views/forms/fields/maskinput.vue";
    import immiyesorno from "@/views/forms/fields/yesorno.vue";
    import immiuploader from "@/views/forms/fields/fileupload.vue";
    import immipriorstay from "@/views/forms/fields/priorstay.vue";
    import immitextarea from "@/views/forms/fields/simpletextarea.vue";
    import immieducations from "@/views/forms/fields/educations.vue";
    import immiswitchyesno from "@/views/forms/fields/switchyesno.vue";
    
    import casedocumentslist from "@/views/common/casedocuments.vue";
    import immiemployment from "@/views/forms/fields/employment.vue";
    import moment from "moment";
    import petitionsinformation from "@/views/forms/fields/petitionsinformation.vue";
    export default {
        inject: ["parentValidator"],
        props: {
            countriesWithoutUS:{
                type: Array,
                default: [],
            },
            notRequired:{
                type: Boolean,
                default: false,
            },
            prefillCountryInQuestionnaire:{
                type: Boolean,
                default: true,
            },
            tplsection:{
                type: String,
                default: null,
            },
            petition: Object,
            countries: Array,
            display: {
                type: Boolean,
                default: false,
            },
            fieldsArray: Array,
            vvas: {
                type: String,
                default: ""
            },
            wrapclass: {
                type: String,
                default: "md:w-1/2"
            },
            datatype: {
                type: String,
                default: ""
            },
            cid: {
                type: String,
                default: null,
            },
            formscope: {
                type: String,
                default: null
            },
            value: null,
            label: {
                type: String,
                default: null,
            },
            fieldName: {
                type: String,
                default: null,
            },
            placeHolder: {
                type: String,
                default: null,
            },
            required: {
                type: Boolean,
                default: false,
            }
        },
        created() {
            this.$validator = this.parentValidator;
        },
    
        components: {
            genderField,
            immiInput,
            addressField,
            Trash2Icon,
            datepickerField,
            selectField,
            immiPhone,
            immiMask,
            immiyesorno,
            immiuploader,
            immipriorstay,
            immitextarea,
            immieducations,
            immiswitchyesno,
            casedocumentslist,
            immiemployment,
            petitionsinformation
        },
        data() {
            return {
                disablefield:false,
                usastates:[],
                consularProcessingValidator:'',
                featureDates: null,
                startEligibleDate: new Date().setFullYear(new Date().getFullYear() - 18),
                bfeprovinceStates: []
            };
        },
        mounted() {
            if (this.value.countryOfBirthDetails && this.value.countryOfBirth != null) {
    
                this.loadStatesByCountry('bfeprovinceStates', this.value.countryOfBirth)
    
            }
            this.featureDates = new Date();
    
            this.$store.dispatch("getstates", 231).then((response) => {
                    this.usastates = response;
            })
            if(this.value.I94=='' && this.checkProperty(this.value,'isI94DSExpiryDate') ==false){
                    this.value.I94ExpiryDate = null;
                    this.disablefield = true;
                  }
            let currentStatus = this.value.currentStatus;
            if (currentStatus != null) {
                this.value.currentStatusDetails = _.find(this.petition.visaStatusList, function (item) {
    
                    return item.id == currentStatus
                })
            }
            setTimeout(()=>{
                    if(this.value['adjustmentOfI485Status'] || this.value['consularProcessing']){
                    this.consularProcessingValidator ='consularProcessingValidator';
                    }
                   
                });
        },
        methods: {
            I94ValueCheck(val){
                   if(val.length<=0 && this.checkProperty(this.value,'isI94DSExpiryDate') ==false){
                    this.value.I94ExpiryDate = null;
                    this.disablefield = true;
                  }
                },
            clearCurrentStatusField(val){
                if(val){
                    this.value.statusExpiryDate = null;
                }
            },
            clearI94Field(val){
                if(val){
                    this.value.I94ExpiryDate = null;
                }
            },
            checkDSExpireFields(){
                if(this.checkProperty(this.value,'currentStatusDetails') && !this.checkProperty(this.value,'currentStatusDetails','id')  ){
                    this.value.isDSExpiryDate = false;
                }
            },
            updatecellPhoneCountryCode(data){
                    this.value.cellPhoneCountryCode =data;
                },
                updatephoneCountryCode(data){
                this.value.phoneCountryCode = data;
            },
            changedAdjustmentOfI485Status(val){
               
               if(this.value['adjustmentOfI485Status']){
                   this.value.consularProcessing = false;
               }
    
               this.consularProcessingValidator ='';
                if(this.value['adjustmentOfI485Status'] || this.value['consularProcessing']){
                    this.consularProcessingValidator ='adjustmentOfI485Status';
                }
               //this.value.consularProcessing = true;
              // this.value['adjustmentOfI485Status'] =false
    
           },
           changedConsularProcessing(val){
            
               //this.value.consularProcessing = true;
              // this.value['adjustmentOfI485Status'] =false
              if(this.value['consularProcessing']){
                   this.value.adjustmentOfI485Status = false;
               }
    
               this.consularProcessingValidator ='';
                if(this.value['adjustmentOfI485Status'] || this.value['consularProcessing']){
                    this.consularProcessingValidator ='adjustmentOfI485Status';
                }
    
           },
           
            loadStatesByCountry(model, countryId) {
    
                this.$store.dispatch("getstates", countryId).then((response) => {
                    switch (model) {
                        case "bfeprovinceStates":
                            this.bfeprovinceStates = response;
                            break;
                    }
    
                });
    
            },
            changeBfProvince(value) {
                this.value.countryOfBirth = this.value.countryOfBirthDetails.id;
                this.bfeprovinceStates = [];
                this.value.provinceOfBirth = null;
                this.value.provinceOfBirthDetails = null;
                this.loadStatesByCountry('bfeprovinceStates', value.id)
            },
            setOutsideAddress() {
    
                if (this.value.currentlyInUS) {
                    this.value.addressOutsideUS = {
                        line1: null,
                        line2: null,
                        aptType: null,
                        locationId: null,
                        locationDetails: null,
                        stateId: null,
                        stateDetails: null,
                        countryId: null,
                        countryDetails: null,
                        zipcode: null
                    };
                } else {
    
                    this.value.addressOutsideUS = null;
                }
    
            },
            addOtherNames() {
                let item = {
                    firstName: "",
                    middleName: "",
                    lastName: ""
                };
                this.value["otherNames"].push(item);
            },
            removeOtherName(index) {
                this.value["otherNames"].splice(index, 1);
            },
            resetOtherNames($event) {
                this.value["otherNames"] = [];
                this.addOtherNames();
    
            },
            updateData() {
                this.$emit('input', this.value)
            },
            
        },
        computed:{
            getTplSection(){
            if(this.tplsection=='dependentsInfo.childrens'){
            return "dependentsInfo.childrens.priorPeriodOfStayInUS"
            }else{
                return this.tplsection;
            }
            }
        }
    };
    </script>
    