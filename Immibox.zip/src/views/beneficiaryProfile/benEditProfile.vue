<template>
     
    <div class="block-layout questionnaire" id="scrollableques" :class="{'padt20':!checkCurrentUrl}">
        <div class="vx-col w-full wizard-container form_section  questionnairesection pad0 case-form-v2">
            <div class="questionnaire_page" id="questionnaire_page" v-if="petition">
                <div class="questionnaire_sec">

                    <div class="questionnaire_titles" v-if="petition">
                        <div class="questionnaire_titles_info">

                        
                            <h2 >
                                Profile for Beneficiary
                            </h2>
                            
                            <p>
                                Please take a few moments to complete this short registration form
                                
                            </p>
                            
                            <ul>
                                <template v-for="(item,index) in tabslist">
                                    <li :key="index" :class="{'active':currentTab==item.key || (index<=checkActiveTab && currentTab!=item.key)} " @click="setActiveTab(item.key,true)">
                                        <span>{{index+1}}</span><a>{{item.name}}</a>
                                    </li>
    
                                </template>
    
                            </ul>
                        </div>
                        <figure><img src="@/assets/images/main/content-bottom-image.svg" /></figure>
                    </div>
                    <div class="questionnaire_form">
                      
    
                        <div v-if="currentTab=='casedetails'" id="case_details_dt">
                            <form data-vv-scope="casedetailsform" @submit.prevent="" @keydown.enter.prevent="">
                                <vs-col class="w-full p-0">
                                    <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal" icon="IP-information-button" active="true">
                                        NOTE: This questionnaire should be filled out completely and
                                        accurately. Kindly read the instructions carefully.
                                    </vs-alert>
    
                                </vs-col>
    
                                <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12">
                                    <div class="form-container pt-10 form-container-questionnaire">
                                        <div class="vx-row">
                                            <div class="vx-col w-full" v-if="canRenderField('adjustmentOfI485Status',questionnaireDetails,false ,'beneficiaryInfo') || canRenderField('consularProcessing',questionnaireDetails,false ,'beneficiaryInfo') ">
                                                <label class="switch-label">Would you like to apply for adjustment of status (I-485) or consular processing? </label>
                                            </div>
                                                  <div class="vs-col " v-if="canRenderField('adjustmentOfI485Status',questionnaireDetails,false ,'beneficiaryInfo')" >
    
                                                    <div class="form_group custom-form-label custom-cx-box">
                                             
                                                    <vs-checkbox :tplsection="'beneficiaryInfo'" :fieldName="'adjustmentOfI485Status'"  
                                                    v-model="petition.beneficiaryInfo.adjustmentOfI485Status"
                                                    data-vv-as="adjustmentOfI485Status"
                                                    name="adjustmentOfI485Status"
                                                    @change="changedAdjustmentOfI485Status"
                                                >Adjustment of Status (I-485)
                                            
                                                <p>When your Priority Date is current, and you have a valid status in the U.S. by then, you may file I-485 to get your Green&nbsp;Card</p>
                                            </vs-checkbox>
    
                                                  </div>
    
                                               </div>
                                               <div class="vs-col " v-if="canRenderField('consularProcessing',questionnaireDetails,false ,'beneficiaryInfo')" >
                                                    <div class="form_group custom-form-label custom-cx-box">
                                                       <vs-checkbox v-model="petition.beneficiaryInfo.consularProcessing" :tplsection="'beneficiaryInfo'" :fieldName="'consularProcessing'"  data-vv-as="consularProcessing"  name="consularProcessing"  @change="changedConsularProcessing"
                                                        >Consular Processing
                                                    
                                                        <p>When your Priority Date is current, and you would like to go to a U.S. consulate 
                                                            abroad to apply for an immigrant visa to get your Green Card</p>
                                                        </vs-checkbox>
                                                    
                                                        <!-- <input type="hidden" v-if="!petition.beneficiaryInfo.consularProcessing && !petition.beneficiaryInfo.adjustmentOfI485Status " :name="'benconsularProcessing'" v-validate="'required'" :tplsection="'beneficiaryInfo'" :fieldName="'consularProcessingValidator'"  v-model="consularProcessingValidator">
                                                        <span v-if="!petition.beneficiaryInfo.consularProcessing || !petition.beneficiaryInfo.adjustmentOfI485Status "  class="text-danger text-sm" v-show="errors.has('casedetailsform.benconsularProcessing')">* Adjustment of Status (I-485)/Consular Processing is required</span> -->
                                                
                                                    </div>
                                                
                                               </div>
                                               
    
                                              <immiswitchyesno :notRequired="true" wrapclass=" mt-10" :required="checkFieldIsRequired({'key':'areYouUnderRemoveOfIndOrUscis','section':'beneficiaryInfo', 'fieldsArray':questionnaireDetails, 'required':true,'notRequired':true })"  :display="false" :fieldsArray="questionnaireDetails" :cid="'areYouUnderRemoveOfIndOrUscis'"  formscope="casedetailsform" v-model="petition.beneficiaryInfo.areYouUnderRemoveOfIndOrUscis"  :fieldName="'areYouUnderRemoveOfIndOrUscis'" :tplkey="'areYouUnderRemoveOfIndOrUscis'" :tplsection="'beneficiaryInfo'"  label="Are you currently under removal proceedings by the INS/USCIS?" placeHolder="" />
    


                                            <immiswitchyesno :notRequired="true" @input="chnageMailingAddress()" wrapclass=" " :required="checkFieldIsRequired({'key':'currentlyInUS','section':'beneficiaryInfo', 'fieldsArray':questionnaireDetails, 'required':true,'notRequired':true })" :display="false" :fieldsArray="questionnaireDetails" :cid="'cidben_currentlyInUS'"  :formscope="'casedetailsform'" v-model="petition.beneficiaryInfo.currentlyInUS"  :fieldName="'currentlyInUS'" :tplkey="'currentlyInUS'" :tplsection="'beneficiaryInfo'" label="Are you currently in USA?" placeHolder="" />
                                          <!-- <div class="divider full-divider mb-10"></div> -->
                                            <genderField :required="false" :display="true" formScope="casedetailsform" :fieldsArray="questionnaireDetails" :gender="petition.beneficiaryInfo.gender" v-model="petition.beneficiaryInfo.gender" :tplsection="'beneficiaryInfo'" :tplkey="'gender'" :fieldName="'gender'" />
                                            <div class="divider full-divider mb-10"></div>

                                            <div class="vx-col w-full">
                                                <vx-input-group class="form-input-group FML">
                                                    <immiInput  :display="false" :fieldsArray="questionnaireDetails" cid="benf" formscope="casedetailsform" v-model="petition.beneficiaryInfo.firstName" :tplsection="'beneficiaryInfo'" :tplkey="'firstName'"  :required="true" :fieldName="'firstName'" label="First Name" placeHolder="First Name" />
                                                    <immiInput :notRequired="true" :display="false" :fieldsArray="questionnaireDetails" cid="benm" formscope="casedetailsform" v-model="petition.beneficiaryInfo.middleName" :tplsection="'beneficiaryInfo'"  :tplkey="'middleName'" :required="false" :fieldName="'middleName'" label="Middle Name" placeHolder="Middle Name" />
                                                    <immiInput :notRequired="true" :display="false" :allowUpperCase="petition.tenantDetails && checkProperty(petition,'tenantDetails','slug') &&  checkProperty(petition,'tenantDetails','slug') == 'slg'" :fieldsArray="questionnaireDetails" cid="benl" formscope="casedetailsform" v-model="petition.beneficiaryInfo.lastName" :tplsection="'beneficiaryInfo'" :tplkey="'lastName'"  :required="true" :fieldName="'lastName'" label="Last Name" placeHolder="Last Name" />
                                                </vx-input-group>
                                            </div>

                                            <div class="vx-col w-full mb-5 yesno-v2" v-if="canRenderField('otherNames',questionnaireDetails, false, 'beneficiaryInfo' )">
                                                <div class="d-block align-center">
                                                    <a class="switch-label">
                                                        Have you ever used any other names previously?
                                                    </a><em v-if="checkFieldIsRequired({'key':'otherNames','section':'beneficiaryInfo', 'fieldsArray':questionnaireDetails, 'required':true,'notRequired':true })" >*</em>
                                                    <!-- <vs-switch v-model="petition.beneficiaryInfo.hasOtherNames" :tplsection="'beneficiaryInfo'"  @input="resetOtherNames(petition.beneficiaryInfo.hasOtherNames)">
                                                        <span slot="on">Yes</span>
                                                        <span slot="off">No</span>
                                                    </vs-switch> -->
                                                    <ul class="custom-radio custom-radio_v2">
                                                        <li>
                                                            <vs-radio ref="yes" v-model="petition.beneficiaryInfo.hasOtherNames" vs-name="beneficiaryInfo.hasOtherNames" :vs-value="true"  @input="resetOtherNames(petition.beneficiaryInfo.hasOtherNames)">Yes</vs-radio>
                                                        </li>
                                                        <li>
                                                            <vs-radio ref="no" v-model="petition.beneficiaryInfo.hasOtherNames" vs-name="beneficiaryInfo.hasOtherNames" :vs-value="false"  @input="resetOtherNames(petition.beneficiaryInfo.hasOtherNames)" >No</vs-radio>
                                                        </li> 
                                                    </ul>
                                                    <div class="form_group" v-if="checkFieldIsRequired({'key':'otherNames','section':'beneficiaryInfo', 'fieldsArray':questionnaireDetails, 'required':true, notRequired:true })">
                                                        <input type="hidden" :name="'otherNames_beneficiaryInfo'" v-validate="'required'"  data-vv-as="Field"  v-model="petition.beneficiaryInfo.hasOtherNames">
                                                        <span v-show="errors.has( 'casedetailsform.otherNames_beneficiaryInfo')" class="text-danger text-sm" style="">*Field is required</span>
                                                    </div>
                                                </div>
                                                <span class="inline_note pt-4">(NOTE: Please enter the name if you have a different name in the educational document other than passport.)</span>
                                            </div>
                                            <template v-if="petition.beneficiaryInfo && petition.beneficiaryInfo.hasOtherNames && canRenderField('otherNames',questionnaireDetails, false, 'beneficiaryInfo' )">
                                               <div class="vx-col w-full" v-for="(item, ind) in petition.beneficiaryInfo['otherNames']" :key="ind">
                                                    <vx-input-group class="form-input-group delete-rows-cst FML">
                                                        <immiInput :notRequired="true" formscope="casedetailsform" :cid="'benf'+ind" v-model="item.firstName" :display="false" :tplkey="''" :tplsection="'beneficiaryInfo.otherNames'"   :required="false" :fieldName="'firstName'" label="First Name" placeHolder="First Name" />
                                                        <immiInput :notRequired="true" formscope="casedetailsform" :cid="'benm'+ind" v-model="item.middleName" :display="false" :tplkey="''" :tplsection="'beneficiaryInfo.otherNames'"   :required="false" :fieldName="'middleName'" label="Middle Name" placeHolder="Middle Name" />
                                                        <immiInput :notRequired="true" formscope="casedetailsform" :allowUpperCase="petition.tenantDetails && checkProperty(petition,'tenantDetails','slug') &&  checkProperty(petition,'tenantDetails','slug') == 'slg'" :cid="'benl'+ind" v-model="item.lastName" :display="false" :tplkey="''" :tplsection="'beneficiaryInfo.otherNames'"  :required="false" :fieldName="'lastName'" label="Last Name" placeHolder="Last Name" />
                                                        <div class="delete" v-if="ind > 0" @click="removeOtherName(ind)">
                                                            <a>
                                                                <img src="@/assets/images/main/delete-row-img.svg">
                                                            </a>
                                                        </div>
                                                    </vx-input-group>
                                                    <a class="add-more add-more-names ml-0 mt-0" v-if="petition.beneficiaryInfo['otherNames'].length - 1 ==ind" @click="addOtherNames()"><span>+</span>Add</a>
                                                </div>
                                            </template>
                                            
                                            <immiInput :notRequired="true" :wrapclass="''" :fieldsArray="questionnaireDetails" :display="false" :tplkey="'email'" datatype="email" cid="benfemail" formscope="casedetailsform" v-model="petition.beneficiaryInfo.email" :required="true" :tplsection="'beneficiaryInfo'"  :fieldName="'email'"  label="Email" placeHolder="Email" />
                                            <immiPhone :notRequired="true" :fieldsArray="questionnaireDetails" :display="false" :tplkey="'cellPhoneNumber'" @updatephoneCountryCode="updatecellPhoneCountryCode" :countrycode="petition.beneficiaryInfo.cellPhoneCountryCode.countryCode" cid="bencellPhoneNumber" formscope="casedetailsform" v-model="petition.beneficiaryInfo.cellPhoneNumber" :tplsection="'beneficiaryInfo'"  :fieldName="'cellPhoneNumber'" :required="false" label="Phone Number" placeHolder="Phone Number" />
                                            <immiPhone :notRequired="true" :fieldsArray="questionnaireDetails" :display="false" :tplkey="'homePhoneNumber'" @updatephoneCountryCode="updatehomePhoneCountryCode" :countrycode="petition.beneficiaryInfo.homePhoneCountryCode.countryCode" cid="benhomePhoneNumber" formscope="casedetailsform" v-model="petition.beneficiaryInfo.homePhoneNumber" :tplsection="'beneficiaryInfo'"  :fieldName="'homePhoneNumber'" label="Home Phone Number" placeHolder="Home Phone Number" />
                                            <immiPhone :notRequired="true" :fieldsArray="questionnaireDetails" :display="false" :tplkey="'workPhoneNumber'" @updatephoneCountryCode="updateWorkPhoneCountryCode" :countrycode="petition.beneficiaryInfo.workPhoneCountryCode.countryCode" cid="workPhoneNumber" formscope="casedetailsform" v-model="petition.beneficiaryInfo.workPhoneNumber" :tplsection="'beneficiaryInfo'"  :fieldName="'workPhoneNumber'" label="Work Phone Number" placeHolder="Home Phone Number" />
                                            <immiPhone :notRequired="true" :fieldsArray="questionnaireDetails" :display="false" :tplkey="'fax'" @updatephoneCountryCode="updateFaxCode" :countrycode="petition.beneficiaryInfo.faxCountryCode.countryCode" cid="fax" formscope="casedetailsform" v-model="petition.beneficiaryInfo.fax" :tplsection="'beneficiaryInfo'"  :fieldName="'fax'" label="Fax" placeHolder="Fax" />

                                            <datepickerField :notRequired="true" :fieldsArray="questionnaireDetails" :display="false" :tplkey="'dateOfBirth'" :dateEnableTo="startEligibleDate" :validationRequired="true" v-model="petition.beneficiaryInfo.dateOfBirth" formscope="casedetailsform" :fieldName="'dateOfBirth'" label="Date of Birth" :tplsection="'beneficiaryInfo'" />
                                            <selectField :notRequired="true" :fieldsArray="questionnaireDetails" :display="false" :tplkey="'countryOfBirth'" @input="changeBfProvince" :required="true" :optionslist="countriesWithoutUS" v-model="petition.beneficiaryInfo.countryOfBirthDetails" formscope="casedetailsform" :fieldName="'countryOfBirth'" label="Country of Birth" placeHolder="Country of Birth" :tplsection="'beneficiaryInfo'" />
                                            <selectField :notRequired="true" :fieldsArray="questionnaireDetails" :display="false" :tplkey="'provinceOfBirth'" @input="petition.beneficiaryInfo.provinceOfBirth = petition.beneficiaryInfo.provinceOfBirthDetails.id" :required="true" :optionslist="bfeprovinceStates" v-model="petition.beneficiaryInfo.provinceOfBirthDetails" formscope="casedetailsform" :tplsection="'beneficiaryInfo'"  :fieldName="'provinceOfBirth'" label="Province of Birth" placeHolder="Province of Birth" />
                                            <immiInput :notRequired="true" :fieldsArray="questionnaireDetails" :display="false" :tplkey="'locationOfBirth'" cid="benflocationOfBirth" formscope="casedetailsform" v-model="petition.beneficiaryInfo.locationOfBirth" :required="true"  :fieldName="'locationOfBirth'" label="Location of Birth" placeHolder="Location of Birth" :tplsection="'beneficiaryInfo'" />
                                            <selectField :notRequired="true" :fieldsArray="questionnaireDetails" :display="false" :tplkey="'countryOfCitizenship'" @input="petition.beneficiaryInfo.countryOfCitizenship = petition.beneficiaryInfo.countryOfCitizenshipDetails.id" :required="true" :optionslist="countries" v-model="petition.beneficiaryInfo.countryOfCitizenshipDetails" formscope="casedetailsform" :tplsection="'beneficiaryInfo'" :fieldName="'countryOfCitizenship'" label="Country of Citizenship" placeHolder="Country of Citizenship" />
                                            <selectField :notRequired="true" :display="false" :tplkey="'highestDegree'" :fieldsArray="questionnaireDetails" @input="petition.beneficiaryInfo.education.highestDegree = petition.beneficiaryInfo.education.highestDegreeDetails.id"  :tplsection="'beneficiaryInfo.education'"  :fieldName="'highestDegree'"  :required="true" :optionslist="education_types" v-model="petition.beneficiaryInfo.education.highestDegreeDetails" formscope="casedetailsform"  label="Highest Degree" />
                                                <immiInput :notRequired="true" :display="false" :tplkey="'majorFieldOfStudy'" :fieldsArray="questionnaireDetails" cid="benmajorFieldOfStudy" formscope="casedetailsform" v-model="petition.beneficiaryInfo.education.majorFieldOfStudy"  :tplsection="'beneficiaryInfo.education'"  :fieldName="'majorFieldOfStudy'"  :required="true" label="Major Field of Study" placeHolder="Major Field of Study" /> 
                                            <selectField :notRequired="true" :fieldsArray="questionnaireDetails" :display="false" :tplkey="'maritalStatus'" @input="petition.beneficiaryInfo.maritalStatus = petition.beneficiaryInfo.maritalStatusDetails.id" :required="true" v-if="marital_statuses.length > 0" :optionslist="marital_statuses" v-model="petition.beneficiaryInfo.maritalStatusDetails" formscope="casedetailsform" :tplsection="'beneficiaryInfo'" :fieldName="'maritalStatus'" label="Marital Status" placeHolder="Marital Status" />
                                                 <!----485 Start ;updateTablist()    &&-->
                                                 
                                            <template v-if="checkProperty(petition ,'beneficiaryInfo','maritalStatus') && checkProperty(petition ,'beneficiaryInfo','maritalStatus')!=1 "  >   
                                                <immiInput :notRequired="true"  :onlyNumbers="true" :allowFloatingPoint="false" :maxLength="2" :tplkey="'noOfChildrens'"  :display="true" :fieldsArray="questionnaireDetails"  cid="noOfChildrens" formscope="casedetailsform" v-model="petition.beneficiaryInfo.noOfChildrens" :required="false"  :tplsection="'beneficiaryInfo'"  :fieldName="'noOfChildrens'"  label="No of Childrens" placeHolder="No of Childrens" />
                                                <datepickerField :notRequired="true"  :display="false" :fieldsArray="questionnaireDetails" :tplkey="'dateOfMarriage'"  :validationRequired="false" v-model="petition.beneficiaryInfo.dateOfMarriage" formscope="casedetailsform" :dateEnableTo="new Date()"  :tplsection="'beneficiaryInfo'"  :fieldName="'dateOfMarriage'"  label="Date of Marriage" />
                                                <selectField :notRequired="true"   :display="false" :fieldsArray="questionnaireDetails" :tplkey="'countryOfMarriage'"   @input="changeCountryMarriage" :required="false" :optionslist="countries" v-model="petition.beneficiaryInfo.countryOfMarriageDetails" formscope="casedetailsform"  :tplsection="'beneficiaryInfo'"  :fieldName="'countryOfMarriage'"  label="Country of Marriage" placeHolder="Country of Marriage" />
                                                <selectField :notRequired="true"  :display="false" :fieldsArray="questionnaireDetails" :tplkey="'provinceOfMarriage'"  @input="petition.beneficiaryInfo.provinceOfMarriage = petition.beneficiaryInfo.provinceOfMarriageDetails.id" :required="false" :optionslist="statesOfMarriage" v-model="petition.beneficiaryInfo.provinceOfMarriageDetails" formscope="casedetailsform"  :tplsection="'beneficiaryInfo'"  :fieldName="'provinceOfMarriage'"  label="Province of Marriage" placeHolder="Province of Marriage" />
                                                <immiInput  :notRequired="true"  :display="false" :fieldsArray="questionnaireDetails" :tplkey="'locationOfMarriage'"  cid="locationOfMarriage" formscope="casedetailsform" v-model="petition.beneficiaryInfo.locationOfMarriage" :required="false"  :tplsection="'beneficiaryInfo'"  :fieldName="'locationOfMarriage'"  label="Location of Marriage" placeHolder="Location of Marriage" />
                                                <immiyesorno :notRequired="true" formscope="casedetailsform" :cid="'doYouHaveMarriageCert'" :required="checkFieldIsRequired({'key':'doYouHaveMarriageCert','section':'beneficiaryInfo', 'fieldsArray':questionnaireDetails, 'required':true,'notRequired':true })"   :display="false" :fieldsArray="questionnaireDetails" :tplkey="'doYouHaveMarriageCert'"  v-model="petition.beneficiaryInfo.doYouHaveMarriageCert"  :tplsection="'beneficiaryInfo'"  :fieldName="'doYouHaveMarriageCert'"  label="Do you have a Marriage Certificate?"></immiyesorno>
                                                <immiyesorno :notRequired="true" formscope="casedetailsform" :cid="'have2AffidavitsAttestingToMarriage'" :required="checkFieldIsRequired({'key':'have2AffidavitsAttestingToMarriage','section':'beneficiaryInfo', 'fieldsArray':questionnaireDetails, 'required':true,'notRequired':true })" v-if="!petition.beneficiaryInfo.doYouHaveMarriageCert" :tplkey="'have2AffidavitsAttestingToMarriage'" :display="false" :fieldsArray="questionnaireDetails" v-model="petition.beneficiaryInfo.have2AffidavitsAttestingToMarriage"  :tplsection="'beneficiaryInfo'"  :fieldName="'have2AffidavitsAttestingToMarriage'"  label="Do you have Two (2) Affidavits attesting to the Marriage?"></immiyesorno>
                                                
                                                <template v-if="petition.beneficiaryInfo.doYouHaveMarriageCert">
                                                    <div class="vx-col w-full quest_485_v2">
                                                        <casedocumentslist :showTitle="false" :tplsection="'beneficiaryInfo'" :docslist="marriageCertDocsList" formscope="casedetailsform" :fieldsArray="questionnaireDetails" v-model="petition.beneficiaryInfo" :fieldName="'marriageCertDocs'"></casedocumentslist>
                                                    </div>
                                                </template> 
                                            </template>  
                                                <!-- <selectField :display="true" :fieldsArray="questionnaireDetails"  :required="true" :optionslist="countries" v-model="petition.beneficiaryInfo.nationality" :tplsection="'beneficiaryInfo'"  :fieldName="'nationality'"  formscope="casedetailsform"  label="Nationality" placeHolder="Nationality" /> -->
                                                <immiyesorno :notRequired="true"  :required="checkFieldIsRequired({'key':'nameDiffFromBirthCert','section':'beneficiaryInfo', 'fieldsArray':questionnaireDetails, 'required':true,'notRequired':true })"  wrapclass=" "    :display="false" :fieldsArray="questionnaireDetails" formscope="casedetailsform" cid="nameDiffFromBirthCert" :tplkey="'nameDiffFromBirthCert'"   v-model="petition.beneficiaryInfo.nameDiffFromBirthCert" :tplsection="'beneficiaryInfo'"  :fieldName="'nameDiffFromBirthCert'"   label="If your name is different from that stated on your birth certificate, have you had it legally changes?"></immiyesorno>
                                                <immiyesorno :notRequired="true" :required="checkFieldIsRequired({'key':'birthCertHaveNamePobDob','section':'beneficiaryInfo', 'fieldsArray':questionnaireDetails, 'required':true,'notRequired':true })" wrapclass="yesno-v2_wrap" :tplkey="'birthCertHaveNamePobDob'"   :display="false" :fieldsArray="questionnaireDetails" formscope="casedetailsform" cid="birthCertHaveNamePobDob"  v-model="petition.beneficiaryInfo.birthCertHaveNamePobDob" :tplsection="'beneficiaryInfo'"  :fieldName="'birthCertHaveNamePobDob'"  label="Does the birth certificate have your name, place of birth, date of birth, parent's names mentioned, and the birth was registered around the time you were born?"></immiyesorno>
                                                <immiyesorno :notRequired="true" :required="checkFieldIsRequired({'key':'have2AffidavitsOfBirthFamily','section':'beneficiaryInfo', 'fieldsArray':questionnaireDetails, 'required':true,'notRequired':true })" wrapclass=" " :tplkey="'have2AffidavitsOfBirthFamily'"   :display="false" :fieldsArray="questionnaireDetails" formscope="casedetailsform" cid="have2AffidavitsOfBirthFamily"  v-model="petition.beneficiaryInfo.have2AffidavitsOfBirthFamily"  :tplsection="'beneficiaryInfo'"  :fieldName="'have2AffidavitsOfBirthFamily'" label="Do you have Two (2) Affidavits of Birth from family members?"></immiyesorno>                                                                                                                                                   
                                                
                                                                                 
                                                <immiInput :notRequired="true" :allowFloatingPoint="false" :maxLength="3" :onlyNumbers="true" :display="false" :fieldsArray="questionnaireDetails" :tplkey="'weight'"  cid="weight" formscope="casedetailsform" v-model="petition.beneficiaryInfo.weight" :tplsection="'beneficiaryInfo'"  :fieldName="'weight'"  :required="false"  label="Weight (LBS)" placeHolder="Weight" />
                                                
                                                <selectField :notRequired="true" :display="false" :fieldsArray="questionnaireDetails"  :required="true"  :tplkey="'race'"  cid="race" :optionslist="races_list" v-model="petition.beneficiaryInfo.race" :tplsection="'beneficiaryInfo'"  :fieldName="'race'"  formscope="casedetailsform"  label="Race" placeHolder="Race" />
                                                <selectField :notRequired="true" :display="false" :fieldsArray="questionnaireDetails"  :required="true"  :tplkey="'hairColor'" cid="hairColor" :optionslist="hair_colorsList" v-model="petition.beneficiaryInfo.hairColor" :tplsection="'beneficiaryInfo'"  :fieldName="'hairColor'"  formscope="casedetailsform"  label="Hair Color" placeHolder="Hair Color" />
                                                <div class="vx-col  w-full md:w-1/2" v-if="canRenderField('inches',questionnaireDetails, false, 'beneficiaryInfo.height' ) || canRenderField('feet',questionnaireDetails, false, 'beneficiaryInfo.height' )">
                                                    <div class="form_group">
                                                        <label class="form_label">Height</label>
                                                        <div class="height_field">
                                                            <selectField :notRequired="true"  :display="false" :fieldsArray="questionnaireDetails"  :required="true"  :tplkey="'feet'" cid="feet" :optionslist="feetList" v-model="petition.beneficiaryInfo.height.feet"  :tplsection="'beneficiaryInfo.height'"  :fieldName="'feet'" :listContainsId="false" formscope="casedetailsform"  label="" placeHolder="Feet" />
                                                            <selectField :notRequired="true" :display="false" :fieldsArray="questionnaireDetails"  :required="true"  :tplkey="'inches'" cid="inches" :optionslist="inchesList" v-model="petition.beneficiaryInfo.height.inches" :tplsection="'beneficiaryInfo.height'"  :fieldName="'inches'" :listContainsId="false"  formscope="casedetailsform"  label="" placeHolder="Inches" />
                                                        </div>
                                                    </div>
                                                </div>
                                                <selectField :notRequired="true" :display="false" :fieldsArray="questionnaireDetails"  :required="true" :optionslist="eye_colorList" v-model="petition.beneficiaryInfo.eyeColor" :tplsection="'beneficiaryInfo'"  :fieldName="'eyeColor'" :tplkey="'eyeColor'"  formscope="casedetailsform"  label="Eye Color" placeHolder="Eye Color" />
                                                
                                                <template v-if="false">
                                                    <selectField :notRequired="true" :tplkey="'stateOfLastEntryInUS'" :display="false" :fieldsArray="questionnaireDetails" @input="petition.beneficiaryInfo.stateOfLastEntryInUS = petition.beneficiaryInfo.stateDetailsOfLastEntryInUS.id" :required="true" :optionslist="usastates" v-model="petition.beneficiaryInfo.stateDetailsOfLastEntryInUS" :tplsection="'beneficiaryInfo'"  :fieldName="'stateOfLastEntryInUS'"  formscope="casedetailsform"  label="State of recent entry into the USA" placeHolder="State of recent entry into the USA" />                         
                                                    <immiInput :notRequired="true" :tplkey="'placeOfLastEntryInUS'" :display="false" :fieldsArray="questionnaireDetails"  cid="placeOfLastEntryInUS" formscope="casedetailsform" v-model="petition.beneficiaryInfo.placeOfLastEntryInUS" :tplsection="'beneficiaryInfo'"  :fieldName="'placeOfLastEntryInUS'"  :required="true"  label="Place of recent entry into the USA" placeHolder="Place of recent entry into the USA" />
                                                    <datepickerField :notRequired="true"  :display="false" :fieldsArray="questionnaireDetails" :tplkey="'lastArrivalDate'"  :validationRequired="true" v-model="petition.beneficiaryInfo.lastArrivalDate" formscope="casedetailsform" :dateEnableTo="featureDates"  :tplsection="'beneficiaryInfo'" :cid="'lastArrivalDate'"  :fieldName="'lastArrivalDate'"  label="Date of most recent entry into the USA" />
                                                </template>

                                                <immiyesorno :notRequired="true" wrapclass=" " :required="checkFieldIsRequired({'key':'inspectedByAnyImmOfficer','section':'beneficiaryInfo', 'fieldsArray':questionnaireDetails, 'required':true,'notRequired':true })" :tplkey="'inspectedByAnyImmOfficer'"  :display="false" :fieldsArray="questionnaireDetails" formscope="casedetailsform" cid="inspectedByAnyImmOfficer"  v-model="petition.beneficiaryInfo.inspectedByAnyImmOfficer" :tplsection="'beneficiaryInfo'"  :fieldName="'inspectedByAnyImmOfficer'"  label="Were you inspected by an immigration officer?"></immiyesorno>
                                                <immiyesorno :notRequired="true" wrapclass="" :required="checkFieldIsRequired({'key':'issuedAnyEADFromUSCIS','section':'beneficiaryInfo', 'fieldsArray':questionnaireDetails, 'required':true,'notRequired':true })" :tplkey="'issuedAnyEADFromUSCIS'"  :display="false" :fieldsArray="questionnaireDetails" formscope="casedetailsform" cid="issuedAnyEADFromUSCIS"  v-model="petition.beneficiaryInfo.issuedAnyEADFromUSCIS" :tplsection="'beneficiaryInfo'"  :fieldName="'issuedAnyEADFromUSCIS'"  label=" Have you ever been issued an Employement Authorization Document (EAD) from the USCIS?"></immiyesorno>
                                                <template v-if="petition.beneficiaryInfo.issuedAnyEADFromUSCIS">
                                                    <div class="vx-col w-full quest_485_v2">
                                                        <casedocumentslist :wrapclass="'mart0'" :showTitle="false" :tplsection="'documents'" :docslist="eadCardList" formscope="casedetailsform" :fieldsArray="questionnaireDetails" v-model="petition.documents" :fieldName="'eadCard'"></casedocumentslist>
                                                    </div>
                                                </template>
                                                <immiyesorno :notRequired="true"  wrapclass=" " :required="checkFieldIsRequired({'key':'hasPermResidencyInOtherCountry','section':'beneficiaryInfo', 'fieldsArray':questionnaireDetails, 'required':true,'notRequired':true })" :tplkey="'hasPermResidencyInOtherCountry'" :display="false" :fieldsArray="questionnaireDetails" formscope="casedetailsform" cid="hasPermResidencyInOtherCountry"  v-model="petition.beneficiaryInfo.hasPermResidencyInOtherCountry" :tplsection="'beneficiaryInfo'"  :fieldName="'hasPermResidencyInOtherCountry'"  label="Do you hold Permanent residence in any other country?"></immiyesorno>             
                                                <selectField :notRequired="true" :tplkey="'permResidencyCountryDetails'" v-if="petition.beneficiaryInfo.hasPermResidencyInOtherCountry" :display="false" :fieldsArray="questionnaireDetails" @input="petition.beneficiaryInfo.permResidencyCountryId = petition.beneficiaryInfo.permResidencyCountryDetails.id" :required="true" :optionslist="countries" v-model="petition.beneficiaryInfo.permResidencyCountryDetails" :tplsection="'beneficiaryInfo'"  :fieldName="'permResidencyCountryDetails'"  formscope="casedetailsform"  label="Permanent Residency Country" placeHolder="Permanent Residency Country" />                                              
                                                <immiyesorno :notRequired="true" wrapclass=" " :required="checkFieldIsRequired({'key':'haveYouArrestedBefore','section':'beneficiaryInfo', 'fieldsArray':questionnaireDetails, 'required':true,'notRequired':true })" :tplkey="'haveYouArrestedBefore'"  :display="false" :fieldsArray="questionnaireDetails" formscope="casedetailsform" cid="haveYouArrestedBefore"  v-model="petition.beneficiaryInfo.haveYouArrestedBefore" :tplsection="'beneficiaryInfo'"  :fieldName="'haveYouArrestedBefore'"  label=" Have you ever been arrested, cited, charged or detained for any reason by an law enforcement official?"></immiyesorno>
                                                <template v-if="petition.beneficiaryInfo.haveYouArrestedBefore">
                                                    <div class="vx-col w-full quest_485_v2"> 
                                                        <casedocumentslist :wrapclass="'mart0'" :showTitle="false" :tplsection="'beneficiaryInfo'" :docslist="haveYouArrestedBeforeDocsList" formscope="casedetailsform" :fieldsArray="questionnaireDetails" v-model="petition.beneficiaryInfo" :fieldName="'haveYouArrestedBeforeDocs'"></casedocumentslist>
                                                    </div>
                                                </template>
                                                <immiyesorno :notRequired="true" :required="checkFieldIsRequired({'key':'everAppliedAOSInUS','section':'beneficiaryInfo', 'fieldsArray':questionnaireDetails, 'required':true ,'notRequired':true})" :tplkey="'everAppliedAOSInUS'"   wrapclass="yesno-v2_wrap" :display="false" :fieldsArray="questionnaireDetails" formscope="casedetailsform" cid="everAppliedAOSInUS"  v-model="petition.beneficiaryInfo.everAppliedAOSInUS" :tplsection="'beneficiaryInfo'"  :fieldName="'everAppliedAOSInUS'"  label="Have you ever applied AOS in the united states or an immigrant visa at the US Embassy/Consulate to obtain permanent resident status before?"></immiyesorno>
                                                <template v-if="petition.beneficiaryInfo.everAppliedAOSInUS">
                                                    <div class="vx-col w-full quest_485_v2">
                                                        <casedocumentslist :wrapclass="'mart0'" :showTitle="false" :tplsection="'beneficiaryInfo'" :docslist="appliedAOSInUSDocsList" formscope="casedetailsform" :fieldsArray="questionnaireDetails" v-model="petition.beneficiaryInfo" :fieldName="'appliedAOSInUSDocs'"></casedocumentslist> 
                                                    </div>
                                                </template>
                                                <template>
                                                    <div class="vx-col w-full">
                                                        <div class="form_group w-full">
                                                            <label class="form_label"><h3 class="small-header">Passport</h3>
                                                            <div class="IB_tooltip H1-140">
                                                                <span ><info-icon size="1.5x" class="custom-class"></info-icon ></span>
                                                                    <div class="tooltip_cnt">
                                                                        <p>Make sure you input the most recent passport information. Also, note that the passport must have more than 6 months validity.</p>
                                                                    </div>
                                                            </div>
                                                        </label>
                                                        </div>
                                                    </div>
                                                </template>
                                            
                                            
                                            <immiInput :notRequired="true" :allowUpperCase="true" :display="false" :tplkey="'passportNumber'" :fieldsArray="questionnaireDetails" datatype="alpha_num|max:15" cid="benfpassportNumber" formscope="casedetailsform" v-model="petition.beneficiaryInfo.passportNumber" :tplsection="'beneficiaryInfo'"  :fieldName="'passportNumber'"  :required="true"  label="Passport Number" placeHolder="Passport Number" />
                                            <datepickerField :notRequired="true" :display="false" :tplkey="'passportIssuedDate'" :fieldsArray="questionnaireDetails" :validationRequired="true" v-model="petition.beneficiaryInfo.passportIssuedDate" :tplsection="'beneficiaryInfo'"  :fieldName="'passportIssuedDate'"  formscope="casedetailsform"  :dateEnableTo="new Date()" label="Passport Issued Date" />
                                            <datepickerField :notRequired="true" :display="false" :tplkey="'passportExpiryDate'" :fieldsArray="questionnaireDetails" :dateEnableFrom="featureDates" :validationRequired="true" v-model="petition.beneficiaryInfo.passportExpiryDate" :tplsection="'beneficiaryInfo'"  :fieldName="'passportExpiryDate'"  formscope="casedetailsform"  label="Passport Expiry Date" />
                                            <selectField :notRequired="true"   :display="false" :tplkey="'passportIssuedCountry'" :fieldsArray="questionnaireDetails" @input="petition.beneficiaryInfo.passportIssuedCountry = petition.beneficiaryInfo.passportIssuedCountryDetails.id" :required="true" :optionslist="countries" v-model="petition.beneficiaryInfo.passportIssuedCountryDetails"  :tplsection="'beneficiaryInfo'"  :fieldName="'passportIssuedCountry'" cid="passportIssuedCountry" formscope="casedetailsform"  label="Country of Passport Issued" placeHolder="Country of Passport Issued" />
                                            <immiInput :notRequired="true" :onlyNumbers="true" :tplkey="'curNonImmigrantVisaNumber'" :allowFloatingPoint="false" :maxLength="8" :display="false" :fieldsArray="questionnaireDetails"  :cid="'curNonImmigrantVisaNumber'" formscope="casedetailsform" v-model="petition.beneficiaryInfo.curNonImmigrantVisaNumber" :tplsection="'beneficiaryInfo'"  :fieldName="'curNonImmigrantVisaNumber'"  :required="false"  label="Current Non-Immigrant Visa Number" placeHolder="Current Non-Immigrant Visa Number" />

                                            <template v-if="(canRenderField('currentlyInUS',questionnaireDetails, false, 'beneficiaryInfo' ) && checkProperty(petition,'beneficiaryInfo','currentlyInUS')) || !canRenderField('currentlyInUS',questionnaireDetails, false, 'beneficiaryInfo' ) ">
                                                <div class="vx-col w-full" v-if="canRenderField('curNonImmigrantVisaStatus',questionnaireDetails, false, 'beneficiaryInfo' )||
                                                canRenderField('curVisaExpiryDate',questionnaireDetails, false, 'beneficiaryInfo' ) || canRenderField('I94',questionnaireDetails, false, 'beneficiaryInfo' )||
                                                canRenderField('I94ExpiryDate',questionnaireDetails, false, 'beneficiaryInfo' )||canRenderField('sevisNumber',questionnaireDetails, false, 'beneficiaryInfo' )||
                                                canRenderField('eadNumber',questionnaireDetails, false, 'beneficiaryInfo' )">
                                                    <div class="form_group w-full"> 
                                                        <label class="form_label"><h3 class="small-header">Status in USA</h3>
                                                    
                                                    </label>
                                                    </div>
                                                </div>
                                                <selectField :notRequired="true" :display="false" :tplkey="'curNonImmigrantVisaStatus'" :fieldsArray="questionnaireDetails" @input="petition.beneficiaryInfo.curNonImmigrantVisaStatus = petition.beneficiaryInfo.curNonImmigrantVisaStatusDetails.id ;mamageVisaStatusDocuments();checkDSExpireFields()" :required="petition.beneficiaryInfo.currentlyInUS" :optionslist="visastatuses" v-model="petition.beneficiaryInfo.curNonImmigrantVisaStatusDetails" :tplsection="'beneficiaryInfo'"  :fieldName="'curNonImmigrantVisaStatus'"  formscope="casedetailsform"  label="Current Non-Immigrant Status" vvas="Nonimmigrant Status" placeholder="Nonimmigrant Status" />
                                                <div class="vx-col w-full md:w-1/2 relative" v-if="(canRenderField('isDSExpiryDate',questionnaireDetails, false, 'beneficiaryInfo' )&& checkProperty(petition['beneficiaryInfo'],'curNonImmigrantVisaStatusDetails')&& checkProperty(petition['beneficiaryInfo'],'curNonImmigrantVisaStatusDetails','id')  ) || canRenderField('curVisaExpiryDate',questionnaireDetails, false, 'beneficiaryInfo' ) ">
                                                    <div class="vs-col w-1/2 ds_check" v-if="canRenderField('isDSExpiryDate',questionnaireDetails, false, 'beneficiaryInfo' )&& checkProperty(petition['beneficiaryInfo'],'curNonImmigrantVisaStatusDetails')&& checkProperty(petition['beneficiaryInfo'],'curNonImmigrantVisaStatusDetails','id')  "  >
                                                        <div class="form_group custom-form-label custom-cx-box">
                                                        <vs-checkbox v-model="petition.beneficiaryInfo.isDSExpiryDate" :tplsection="'beneficiaryInfo'" :fieldName="'consularProcessing'"  data-vv-as="consularProcessing"  name="isDSExpiryDate" @input="clearCurrentStatusField"
                                                            >Check here if D/S
                                                            </vs-checkbox>
                                                        </div>
                                                    </div>
                                                    <!-- :isDisabled="(canRenderField('isDSExpiryDate',questionnaireDetails, false, 'beneficiaryInfo' ) && petition.beneficiaryInfo.isDSExpiryDate) || !petition.beneficiaryInfo.curNonImmigrantVisaStatus"  -->
                                                    <datepickerField :notRequired="true" :wrapclass="'md:w-full'"  :isDisabled="checkCurrentStatus"
                                                    :display="false"  :tplkey="'curVisaExpiryDate'" :fieldsArray="questionnaireDetails" :dateEnableFrom="featureDates" :validationRequired="true" v-model="petition.beneficiaryInfo.curVisaExpiryDate" :tplsection="'beneficiaryInfo'"  :fieldName="'curVisaExpiryDate'"  formscope="casedetailsform"  label="Current Status Expiry Date" />
                                                </div>
                                                <immiInput :notRequired="true" :allowUpperCase="true" :display="false" :tplkey="'I94'" :fieldsArray="questionnaireDetails" cid="benI94" datatype="max:15" formscope="casedetailsform" v-model="petition.beneficiaryInfo.I94"  :tplsection="'beneficiaryInfo'" @input="I94ValueCheck(petition.beneficiaryInfo.I94)" :fieldName="'I94'"  :required="true"  label="I-94 Number" placeHolder="I-94 Number" />                                                
                                                <div class="vx-col w-full md:w-1/2 relative" v-if="(canRenderField('isI94DSExpiryDate',questionnaireDetails, false, 'beneficiaryInfo' ) && checkProperty(petition,'beneficiaryInfo') && checkProperty(petition['beneficiaryInfo'],'I94')  ) || canRenderField('I94ExpiryDate',questionnaireDetails, false, 'beneficiaryInfo' ) ">
                                                    <div class="vs-col w-1/2 ds_check" v-if="canRenderField('isI94DSExpiryDate',questionnaireDetails, false, 'beneficiaryInfo' )&& checkProperty(petition,'beneficiaryInfo') && checkProperty(petition['beneficiaryInfo'],'I94')  "  >
                                                        <div class="form_group custom-form-label custom-cx-box">
                                                        <vs-checkbox v-model="petition.beneficiaryInfo.isI94DSExpiryDate" :tplsection="'beneficiaryInfo'" :fieldName="'isI94DSExpiryDate'"  data-vv-as="consularProcessing"  name="isI94DSExpiryDate" @input="clearI94Field"
                                                            >Check here if D/S
                                                            </vs-checkbox>
                                                        </div>
                                                    </div>
                                                    <!-- || (petition.beneficiaryInfo.I94=='' && disablefield)  -->
                                                    <!-- :isDisabled="(petition.beneficiaryInfo.isI94DSExpiryDate != '' || petition.beneficiaryInfo.isI94DSExpiryDate != null)  && petition.beneficiaryInfo.I94" -->
                                                    <datepickerField :wrapclass="'md:w-full'" :isDisabled="checkI94" :display="false" :notRequired="true"  :tplkey="'I94ExpiryDate'" :fieldsArray="questionnaireDetails" :validationRequired="petition.beneficiaryInfo.I94!=null && petition.beneficiaryInfo.I94!=''" v-model="petition.beneficiaryInfo.I94ExpiryDate"  :tplsection="'beneficiaryInfo'"  :fieldName="'I94ExpiryDate'"  formscope="casedetailsform" :dateEnableFrom="featureDates"  label="I-94 Expiry Date" />
                                                </div>
                                                <immiInput :notRequired="true" :allowUpperCase="true" :display="false"  :tplkey="'sevisNumber'" :fieldsArray="questionnaireDetails" datatype="alpha_num|max:15" cid="benfsevisNumber" formscope="casedetailsform" v-model="petition.beneficiaryInfo.sevisNumber" :tplsection="'beneficiaryInfo'"  :fieldName="'sevisNumber'"    label="SEVIS  Number" placeHolder="SEVIS  Number" />
                                                <immiInput :notRequired="true" :allowUpperCase="true" :display="false" :tplkey="'eadNumber'"  :fieldsArray="questionnaireDetails" datatype="alpha_num|min:9|max:20" cid="benfeadNumber" formscope="casedetailsform" v-model="petition.beneficiaryInfo.eadNumber" :maxCharacters="20" :tplsection="'beneficiaryInfo'"  :fieldName="'eadNumber'"   label="EAD  Number" placeHolder="EAD  Number" />
                                            </template>
                                            <datepickerField :notRequired="true"  :display="false"  :fieldsArray="questionnaireDetails" :validationRequired="true" v-model="petition.beneficiaryInfo.firstEntryDateOrApprovalInUsWithH1B" :tplsection="'beneficiaryInfo'"  :tplkey="'firstEntryDateOrApprovalInUsWithH1B'"  :fieldName="'firstEntryDateOrApprovalInUsWithH1B'"  formscope="casedetailsform" :dateEnableTo="featureDates"  label="First Entry Date or Approval in US With H1B" />                                        
                                        <datepickerField  :notRequired="true" :display="false"  :fieldsArray="questionnaireDetails" :validationRequired="true" v-model="petition.beneficiaryInfo.dateFifthYearOfHExpire" :tplsection="'beneficiaryInfo'"  :tplkey="'dateFifthYearOfHExpire'"  :fieldName="'dateFifthYearOfHExpire'"  formscope="casedetailsform" :dateEnableFrom="null"   label="Date Fifth Year of H1B Status Expires"  />                                        
                                            <div class="vx-col w-full">

                                                <template v-if=" checkProperty(countries,'length')>0 && (canRenderField('currentlyInUS',questionnaireDetails, false, 'beneficiaryInfo' ) && checkProperty(petition,'beneficiaryInfo','currentlyInUS') || !canRenderField('currentlyInUS',questionnaireDetails, false, 'beneficiaryInfo' ) )">
                                                    <div v-if="canRenderField('address',questionnaireDetails, false, 'beneficiaryInfo' )">
                                                        <h3 class="small-header">Current Address</h3>
                                                        <addressField  
                                                        :prefiilAddress="prefillCountryInQuestionnaire == false||([10,8].indexOf(checkProperty(petition,'subTypeDetails','id'))>-1 && checkProperty(petition,'typeDetails','id')==1 )?false:true" 
                                                        :fieldsArray="questionnaireDetails" :disableCountry="petition.beneficiaryInfo.currentlyInUS" formscope="casedetailsform" :showaptType="true" :addFormContainerCls="false" :validationRequired="false" :countries="countries" v-model="petition.beneficiaryInfo.address" :tplsection="'beneficiaryInfo'"  :fieldName="'address'"  :cid="'beneficiaryInfoaddress'" />
        
                                                    </div>
                                                </template>
                                                <div v-if="checkProperty(countries,'length')>0 && (canRenderField('mailingAddressIsSameAsAddress',questionnaireDetails, false, 'beneficiaryInfo' ) && canRenderField('currentAddress',questionnaireDetails, false, 'beneficiaryInfo' ) )" >
    
                                                                                                    
                                                    <div class="vx-col w-full d-flex">
                                                        <h3 class="small-header">Mailing Address</h3>
                                                        <template v-if="(canRenderField('currentlyInUS',questionnaireDetails, false, 'beneficiaryInfo' ) && checkProperty(petition,'beneficiaryInfo','currentlyInUS')  )">
                                                            <vs-checkbox @change="setSameaddress()"  v-model="petition.beneficiaryInfo.mailingAddressIsSameAsAddress" :tplsection="'beneficiaryInfo'"  :fieldName="'mailingAddressIsSameAsAddress'" 
                                                            style="margin-left: 15px; margin-bottom:12px;">Same as Current Address </vs-checkbox
                                                            >
                                                        </template>
                                                    </div>
                                                    <!-- petition.beneficiaryInfo.mailingAddressIsSameAsAddress!=true && -->
                                                    <template v-if=" countries.length>0">
                                                        
                                                      
                                                    <addressField :notRequired="true" :ref="'mailingAddresscomponent'"  :display="true" :fieldsArray="questionnaireDetails" :disableCountry="petition.beneficiaryInfo.currentlyInUS && checkProperty(petition,'beneficiaryInfo','currentAddress') && checkProperty(petition['beneficiaryInfo'],'currentAddress','countryDetails')
                                                     && checkProperty(petition['beneficiaryInfo'],'currentAddress','countryId') && petition.beneficiaryInfo.mailingAddressIsSameAsAddress"
                                                     formscope="casedetailsform" :showaptType="true" :addFormContainerCls="false" :validationRequired="checkFieldIsRequired({'key':'currentAddress','section':'beneficiaryInfo', 'fieldsArray':questionnaireDetails, 'required':true,'notRequired':true })" :countries="countries" v-model="petition.beneficiaryInfo.currentAddress" :tplsection="'beneficiaryInfo'"  :fieldName="'currentAddress'"  :cid="'beneficiarymailInfoaddress'" />
                                                    </template>
                                                </div>
                                                <div v-if=" checkProperty(countries,'length')>0 && canRenderField('addressOutsideUS',questionnaireDetails, false, 'beneficiaryInfo' )">
                                                    <h3 class="small-header">Address Outside the U.S</h3>
                                                    <addressField  :hideusa="true" :validationRequired="false" :fieldsArray="questionnaireDetails" :disableCountry="false" formscope="casedetailsform" :showaptType="true" :addFormContainerCls="false" :countries="countries" v-model="petition.beneficiaryInfo.addressOutsideUS" :tplsection="'beneficiaryInfo'"  :fieldName="'addressOutsideUS'"  :cid="'addressOutsideUS'" />
    
                                                </div>
                                            </div>
                                            <template v-if=" canRenderField('addressOfLastNYears',questionnaireDetails, false, 'beneficiaryInfo') || canRenderField('addressOutsideUSMoreThanYear',questionnaireDetails, false, 'beneficiaryInfo') ">
                                                <div class="vx-col w-full" v-if="canRenderField('addressOfLastNYears',questionnaireDetails, false, 'beneficiaryInfo' ) &&  checkProperty(petition.beneficiaryInfo,'addressOfLastNYears') && checkProperty(petition.beneficiaryInfo,'addressOfLastNYears' ,'length')>0">                                      
                                                    <template v-if=" checkProperty(countries,'length')>0 && canRenderField('addressOfLastNYears',questionnaireDetails, false, 'beneficiaryInfo' ) &&  checkProperty(petition.beneficiaryInfo,'addressOfLastNYears') && checkProperty(petition.beneficiaryInfo,'addressOfLastNYears' ,'length')>0">
                                                        <h3 class="small-header" style="margin-bottom:0 !important;padding-bottom:0 !important">Your Residence starting with most current for the Past Five Years in the U.S and Abroad </h3>
                                                        <div class="I-485-wrapper">
                                                            <div class="vx-row delete-row I-485-bg" v-for="(lyearItem, index) in petition.beneficiaryInfo['addressOfLastNYears']" :key="index">
                                                            <addressField :fieldsArray="questionnaireDetails" :disableCountry="false" formscope="casedetailsform" :showaptType="true" :addFormContainerCls="false" :validationRequired="false" :countries="countries" v-model="petition.beneficiaryInfo['addressOfLastNYears'][index]" :tplsection="'beneficiaryInfo'"  :fieldName="'addressOfLastNYears'+index"  :cid="'addressOfLastNYears'+index" />
                                                            <div class="w-full">
                                                                <div class="vx-row">
                                                                    <datepickerField :notRequired="true"  @input="clearStartandEnddate($event,'addressOfLastNYears',index,'start')" :display="false" :fieldsArray="questionnaireDetails" :tplkey="'startDate'"  :validationRequired="false" v-model="lyearItem.startDate" formscope="casedetailsform" :dateEnableTo="featureDates"  :tplsection="'beneficiaryInfo.addressOfLastNYears'"  :fieldName="'residenceStartDate'+index" :cid="'residenceStartDate'+index"  label="Start Date" />
                                                                    <datepickerField :notRequired="true" @input="clearStartandEnddate($event,'addressOfLastNYears',index,'end')"   :display="false" :fieldsArray="questionnaireDetails" :tplkey="'endDate'" :isDisabled="!lyearItem.startDate"  :validationRequired="false" v-model="lyearItem.endDate" :dateEnableFrom="lyearItem.startDate" formscope="casedetailsform" :dateEnableTo="featureDates"  :tplsection="'beneficiaryInfo.addressOfLastNYears'" :cid="'residenceEndDate'+index"  :fieldName="'residenceEndDate'+index"  label="End Date" />
                                                                </div>
                                                            </div>
                                                                <div class="delete" v-if="petition.beneficiaryInfo['addressOfLastNYears'].length > 1">
                                                                    <a @click="removeNyears(index)">
                                                                    <img src="@/assets/images/main/delete-row-img-white.svg" />
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </template>
                                                     <div class="m-auto" vs-type="flex" vs-align="center" vs-lg="2" vs-sm="2">
                                                         <a @click="addNyears()" class="add-more ml-0 mt-4" style="display:inline-block" type="filled">
                                                       <span>+</span> More</a>
                                                    </div>
                                           </div>
                                           <div class="vx-col w-full" v-if=" checkProperty(countries,'length')>0 && canRenderField('addressOutsideUSMoreThanYear',questionnaireDetails, false, 'beneficiaryInfo' ) && checkProperty(petition.beneficiaryInfo,'addressOutsideUSMoreThanYear') && checkProperty(petition.beneficiaryInfo,'addressOutsideUSMoreThanYear' ,'length')>0">
                                                <template v-if="canRenderField('addressOutsideUSMoreThanYear',questionnaireDetails, false, 'beneficiaryInfo' )  &&  checkProperty(petition.beneficiaryInfo,'addressOutsideUSMoreThanYear') && checkProperty(petition.beneficiaryInfo,'addressOutsideUSMoreThanYear','length')>0">
                                                    <h3 class="small-header" style="margin-top: 40px !important;
                                                            padding-bottom: 0 !important;"> Last Address outside Of the United States for more than one year</h3>
                                                    <div class="vx-row delete-row" v-for="(lastYearItem, ind) in petition.beneficiaryInfo['addressOutsideUSMoreThanYear']" :key="ind">
                                                        <addressField :hideusa="true" :wrapclass="'px-4'" :fieldsArray="questionnaireDetails"  formscope="casedetailsform" :showaptType="true" :addFormContainerCls="false" :validationRequired="checkFieldIsRequired({'key':'addressOutsideUSMoreThanYear','section':'beneficiaryInfo', 'fieldsArray':questionnaireDetails, 'required':true,'notRequired':true })" :countries="countries" v-model="petition.beneficiaryInfo['addressOutsideUSMoreThanYear'][ind]" :tplsection="'beneficiaryInfo'"  :fieldName="'addressOutsideUSMoreThanYear'+ind"  :cid="'addressOutsideUSMoreThanYear'+ind" />
                                                        <datepickerField   @input="clearStartandEnddate($event,'addressOutsideUSMoreThanYear',ind,'start')" :display="false" :fieldsArray="questionnaireDetails" :tplkey="'startDate'"  :validationRequired="false" v-model="lastYearItem.startDate" formscope="casedetailsform" :dateEnableTo="featureDates"  :tplsection="'beneficiaryInfo.addressOutsideUSMoreThanYear'"  :fieldName="'outSideStartDate'+ind" :cid="'outSideStartDate'+ind"  label="Start Date" />
                                                        <datepickerField @input="clearStartandEnddate($event,'addressOutsideUSMoreThanYear',ind,'end')" :display="false" :fieldsArray="questionnaireDetails" :tplkey="'endDate'" :isDisabled="!lastYearItem.startDate"  :validationRequired="false" v-model="lastYearItem.endDate" :dateEnableFrom="lastYearItem.startDate"  formscope="casedetailsform" :dateEnableTo="featureDates"  :tplsection="'beneficiaryInfo.addressOutsideUSMoreThanYear'"  :fieldName="'outSideEndDate'+ind" :cid="'outSideStartDate'+ind" label="End Date" /> 
                                                        <div class="delete" v-if="petition.beneficiaryInfo['addressOutsideUSMoreThanYear'].length > 1">
                                                                <a @click="removeLastYearItem(ind)">
                                                                <img src="@/assets/images/main/delete-row-img-white.svg" />
                                                                </a>
                                                            </div>
                                                    </div> 
                                                </template>
                                            </div> 
                                            </template>
                                            <template v-if="canRenderField('associations',questionnaireDetails, false, 'beneficiaryInfo.associations' )">
                                                <div class="vx-col w-full" >
                                                    <div class="form_group w-full"> 
                                                        <label class="form_label">
                                                            <!-- ASSOCIATIONS/GROUPS -->
                                                            <h3 class="small-header">Associations/Groups</h3>
                                                            <div class="IB_tooltip H1-140">
                                                                <span ><info-icon size="1.5x" class="custom-class"></info-icon ></span>
                                                                    <div class="tooltip_cnt">
                                                                        <p>All associations and groups of which you are or have been a member, including political organizations, if you do not belong to any organizations, please write "None".</p>
                                                                    </div>
                                                            </div>
                                                        </label>
                                                    </div>
                                                </div> 
                                                <immiInput :notRequired="true" :display="false" :tplkey="'name'" :fieldsArray="questionnaireDetails"  cid="benfname" formscope="casedetailsform" v-model="petition.beneficiaryInfo['associations'][0].name" :tplsection="'beneficiaryInfo.associations'"  :fieldName="'name'"  :required="true"  label="Name of the associations and groups" placeHolder="Name of the associations and groups" />
                                                <immiInput :notRequired="true" :display="false" :tplkey="'natureofAssociations'" :fieldsArray="questionnaireDetails"  cid="benfnatureofAssociations" formscope="casedetailsform" v-model="petition.beneficiaryInfo['associations'][0].natureofAssociations" :tplsection="'beneficiaryInfo.associations'"  :fieldName="'natureofAssociations'"  :required="true"  label="Nature of associations and groups" placeHolder="Nature of associations and groups" /> 
                                                <datepickerField :notRequired="true" :display="false" @input="clearDependentField(petition.beneficiaryInfo['associations'])" :tplkey="'startDate'" :fieldsArray="questionnaireDetails" :validationRequired="true" v-model="petition.beneficiaryInfo['associations'][0].startDate" :tplsection="'beneficiaryInfo.associations'"  :fieldName="'assosicationsStartDate'"  formscope="casedetailsform"  :dateEnableTo="featureDates" label="Start Date" />
                                                <datepickerField :notRequired="true" :display="false" :tplkey="'endDate'" :isDisabled="!petition.beneficiaryInfo['associations'][0].startDate"  :fieldsArray="questionnaireDetails" :dateEnableFrom="petition.beneficiaryInfo['associations'][0].startDate" :validationRequired="true" v-model="petition.beneficiaryInfo['associations'][0].endDate" :tplsection="'beneficiaryInfo.associations'"  :fieldName="'assosicationsEndDate'"  formscope="casedetailsform"  label="End Date" /> 
                                                <div class="vx-col w-full" v-if="checkProperty(countries,'length')>0 && canRenderField('address',questionnaireDetails, false, 'beneficiaryInfo.associations' )">
                                                    <h3 class="small-header"> Address</h3>
                                                    <addressField :validationRequired="checkFieldIsRequired({'key':'address','section':'beneficiaryInfo.associations', 'fieldsArray':questionnaireDetails, 'required':true,'notRequired':true })"  :fieldsArray="questionnaireDetails" :showLane1="false" :showLane2="false" :disableCountry="false" :showZip="false" formscope="casedetailsform" :showaptType="false" :addFormContainerCls="false" :countries="countries" v-model="petition.beneficiaryInfo['associations'][0].address" :tplsection="'beneficiaryInfo.associations'"  :fieldName="'address'"  :cid="'address'" />
                                                </div>   
                                            </template>

    
                                            <immiMask :notRequired="true" :display="false" :tplkey="'SSN'" :fieldsArray="questionnaireDetails" :patren="['### - ## - ####']" datatype="min:9|max:9" :wrapclass="canRenderField('ben_alienNumber',questionnaireDetails)?'md:w-1/2':' '" cid="benfSSN" formscope="casedetailsform" v-model="petition.beneficiaryInfo.SSN" :tplsection="'beneficiaryInfo'"  :fieldName="'SSN'"  :required="false"  label="Social Security number (if applicable)" vvas="Social Security number" placeHolder="123 - 45 - 6789" />
                                            <immiInput :notRequired="true" :display="false" :tplkey="'alienNumber'" :fieldsArray="questionnaireDetails" datatype="alpha_num|max:9" cid="benfalienNumber_alienNumber" formscope="casedetailsform" v-model="petition.beneficiaryInfo.alienNumber" :tplsection="'beneficiaryInfo'"  :fieldName="'alienNumber'"   label="Your Alien Number (if applicable)" placeHolder="Alien Number " />
    
                                            
    
                                            <immiyesorno :notRequired="true" formscope="casedetailsform" :cid="'hasI140ImmPetitionFiled'" :required="checkFieldIsRequired({'key':'hasI140ImmPetitionFiled','section':'beneficiaryInfo', 'fieldsArray':questionnaireDetails, 'required':true,'notRequired':true })" :display="false" :tplkey="'hasI140ImmPetitionFiled'"  :fieldsArray="questionnaireDetails" v-model="petition.beneficiaryInfo.hasI140ImmPetitionFiled" :tplsection="'beneficiaryInfo'"  :fieldName="'hasI140ImmPetitionFiled'" :wrapclass="'yesno-v2'"   label="Has I-140 immigrant petition been filed on your behalf?"></immiyesorno>
                                            <immiuploader :display="false" :tplkey="'I140ApprovalNotice'" :fieldsArray="questionnaireDetails" v-if="petition.beneficiaryInfo.hasI140ImmPetitionFiled" formscope="casedetailsform" :required="false" v-model="petition.documents.I140ApprovalNotice" :wrapclass="'mb-5'" :tplsection="'documents'"  :fieldName="'I140ApprovalNotice'"  label="I-140 Approval Notice, if any" vvas="I-140 Approval Notice"></immiuploader>
    
    
                                          
                                           

                                            <immiyesorno :notRequired="true" formscope="casedetailsform" :cid="'anyImmPetitionFiled'" :required="checkFieldIsRequired({'key':'anyImmPetitionFiled','section':'beneficiaryInfo', 'fieldsArray':questionnaireDetails, 'required':true,'notRequired':true })" :display="false" :tplkey="'anyImmPetitionFiled'"  :fieldsArray="questionnaireDetails" v-model="petition.beneficiaryInfo.anyImmPetitionFiled" :tplsection="'beneficiaryInfo'"  :fieldName="'anyImmPetitionFiled'" :wrapclass="'yesno-v2'"   label="Has any immigrant Visa petition (PERM, I-140, I-485) ever been filed on your behalf?"></immiyesorno>
                                            <template v-if="petition.beneficiaryInfo && petition.beneficiaryInfo.anyImmPetitionFiled">
                                                <petitionImmigranInfo :notRequired="true" :fieldsArray="questionnaireDetails" formscope="casedetailsform"    :petition="petition" v-model="petition.beneficiaryInfo.h1bImmPetitionsInfo" :tplsection="'beneficiaryInfo.h1bImmPetitionsInfo'"  :fieldName="'h1bImmPetitionsInfo'" ></petitionImmigranInfo>
                                            </template>
                                            <!-- <immiswitchyesno wrapclass=" " @input="clearImmiputFields" :display="false" :fieldsArray="questionnaireDetails" :cid="'ben_anyImmPetitionFiled'" formscope="casedetailsform" v-model="petition.beneficiaryInfo.anyImmPetitionFiled"  :tplsection="'beneficiaryInfo'" :tplkey="'anyImmPetitionFiled'" :fieldName="'anyImmPetitionFiled'" label="Has any Immigrant Visa Petition ever been filed on your behalf? " placeHolder="" /> -->
         
                                            <immiyesorno :notRequired="true" :cid="'haveYouEverTravelledToUS'" formscope="casedetailsform" :required="checkFieldIsRequired({'key':'haveYouEverTravelledToUS','section':'beneficiaryInfo', 'fieldsArray':questionnaireDetails, 'required':true,'notRequired':true })" :wrapclass="'swicth-label_v2 yesno-v2'" :display="false" :tplkey="'haveYouEverTravelledToUS'" :fieldsArray="questionnaireDetails"   v-model="petition.beneficiaryInfo.haveYouEverTravelledToUS" :tplsection="'beneficiaryInfo'"  :fieldName="'haveYouEverTravelledToUS'"   label="Have you ever travelled to the United States?"></immiyesorno>
                                           
                                            <template v-if="petition.beneficiaryInfo && petition.beneficiaryInfo.haveYouEverTravelledToUS">
                                            <span class="vx-col  w-full mart10"></span>
                                            <template v-if="canRenderField('stateOfLastEntryInUS',questionnaireDetails,false ,'beneficiaryInfo')  ">

                                            <selectField :notRequired="true" :display="false" :fieldsArray="questionnaireDetails"  @input="petition.beneficiaryInfo.stateOfLastEntryInUS = petition.beneficiaryInfo.stateDetailsOfLastEntryInUS.id"  :optionslist="usastates" v-model="petition.beneficiaryInfo.stateDetailsOfLastEntryInUS" :tplsection="'beneficiaryInfo'"  :tplkey="'stateOfLastEntryInUS'" :fieldName="'stateOfLastEntryInUS'"  :formscope="'casedetailsform'"  label="State of recent entry into the USA" placeHolder="State of recent entry into the USA" />
                                            </template>
                                            <template v-if="canRenderField('placeOfLastEntryInUS',questionnaireDetails,false ,'beneficiaryInfo')  ">
                                                <immiInput :notRequired="true" :display="false" :fieldsArray="questionnaireDetails"  cid="placeOfLastEntryInUS" :formscope="'casedetailsform'" v-model="petition.beneficiaryInfo.placeOfLastEntryInUS" :tplsection="'beneficiaryInfo'" :tplkey="'placeOfLastEntryInUS'" :fieldName="'placeOfLastEntryInUS'"    label="Place of recent entry into the USA" placeHolder="Place of recent entry into the USA" />
                                            </template>
                                            <template v-if="canRenderField('lastArrivalDate',questionnaireDetails,false ,'beneficiaryInfo')  ">
                                                <datepickerField :notRequired="true"  :display="false" :fieldsArray="questionnaireDetails" :tplkey="'lastArrivalDate'"   v-model="petition.beneficiaryInfo.lastArrivalDate" :formscope="'casedetailsform'" :dateEnableTo="featureDates"  :tplsection="'beneficiaryInfo'"  :fieldName="'lastArrivalDate'"  label="Date of most recent entry into the USA" />
                                            </template>
                                            </template>
                                           
                                            <template v-if=" petition.beneficiaryInfo && petition.beneficiaryInfo.haveYouEverTravelledToUS ">
                                             <immipriorstay :notRequired="true" :fieldsArray="questionnaireDetails" formscope="casedetailsform" v-if="canRenderField('priorPeriodOfStayInUS', questionnaireDetails ,false,'beneficiaryInfo' ) && petition && petition.visaStatusList && petition.visaStatusList.length > 0"  :petition="petition" v-model="petition.beneficiaryInfo.priorPeriodOfStayInUS" :tplsection="'beneficiaryInfo'"  :fieldName="'priorPeriodOfStayInUS'" ></immipriorstay>
                                            </template>                                         
                                                 <!------------------------------------------------------------------------>
                                            <template v-if="canRenderField('anyOtherAlienFiled', questionnaireDetails ,false,'beneficiaryInfo.immPetitionInfo' )  && petition.beneficiaryInfo.anyImmPetitionFiled">
                                                <div class="vx-col w-full" >
    
                                                <h3 class="small-header">Immigrant Petition Information</h3>
                                            </div>
                                                <immiswitchyesno :notRequired="true" v-if="canRenderField('anyOtherAlienFiled', questionnaireDetails ,false,'beneficiaryInfo.immPetitionInfo' )" :required="checkFieldIsRequired({'key':'anyOtherAlienFiled','section':'beneficiaryInfo.immPetitionInfo', 'fieldsArray':questionnaireDetails, 'required':true,'notRequired':true })" :display="false" wrapclass=" " :fieldsArray="questionnaireDetails" :cid="'ben_anyImmPetitionFiled'" formscope="casedetailsform" v-model="petition.beneficiaryInfo.immPetitionInfo.anyOtherAlienFiled" :tplsection="'beneficiaryInfo.immPetitionInfo'"  :fieldName="'anyOtherAlienFiled'"   label="Has any other Alien Employment Certification, a.k.a Labor Certification been filed on your behalf? " placeHolder="" />
                                               
                                                <template v-if="petition.beneficiaryInfo.immPetitionInfo.anyOtherAlienFiled"> 
                                                    <datepickerField :notRequired="true" :validationRequired="true" v-if="canRenderField('filedDate', questionnaireDetails ,false,'beneficiaryInfo.immPetitionInfo' )" wrapclass="md:w-1/2"  :display="false" :tplkey="'filedDate'" :fieldsArray="questionnaireDetails" v-model="petition.beneficiaryInfo.immPetitionInfo.filedDate"  :tplsection="'beneficiaryInfo.immPetitionInfo'"  :fieldName="'filedDate'"  formscope="casedetailsform"  :dateEnableTo="featureDates" label="Date Filed" />
                                                <immiInput :notRequired="true" v-if="canRenderField('employerName', questionnaireDetails ,false,'beneficiaryInfo.immPetitionInfo' )" wrapclass="md:w-1/2"  :display="false" :tplkey="'employerName'" :fieldsArray="questionnaireDetails"  cid="benfalienNumber" formscope="casedetailsform" v-model="petition.beneficiaryInfo.immPetitionInfo.employerName" :tplsection="'beneficiaryInfo.immPetitionInfo'"  :fieldName="'employerName'"   label="Name of the Employer" placeHolder="Name of the Employer" />
                                                <immiswitchyesno :notRequired="true" v-if="canRenderField('rirOrRegularProcessing', questionnaireDetails ,false,'beneficiaryInfo.immPetitionInfo' )" :required="checkFieldIsRequired({'key':'rirOrRegularProcessing','section':'beneficiaryInfo.immPetitionInfo', 'fieldsArray':questionnaireDetails, 'required':true ,'notRequired':true})" :display="false" :tplkey="'rirOrRegularProcessing'" wrapclass=" " :fieldsArray="questionnaireDetails" :cid="'ben_rirOrRegularProcessing'" formscope="casedetailsform" v-model="petition.beneficiaryInfo.immPetitionInfo.rirOrRegularProcessing" :tplsection="'beneficiaryInfo.immPetitionInfo'"  :fieldName="'rirOrRegularProcessing'"   label="RIR or Regular Processing" placeHolder="" />
    
                                                <selectField :notRequired="true" v-if="canRenderField('filedStateId', questionnaireDetails ,false,'beneficiaryInfo.immPetitionInfo' )" :display="false" :tplkey="'filedStateId'"  :fieldsArray="questionnaireDetails" @input="petition.beneficiaryInfo.immPetitionInfo.filedStateId = petition.beneficiaryInfo.immPetitionInfo.filedStateDetails.id"  :optionslist="usastates" v-model="petition.beneficiaryInfo.immPetitionInfo.filedStateDetails" :tplsection="'beneficiaryInfo.immPetitionInfo'"  :fieldName="'filedStateId'"  formscope="casedetailsform"  label="State where it was filed" placeHolder="State where it was filed" />
                                                <immiInput :notRequired="true" v-if="canRenderField('applCurStatus', questionnaireDetails ,false,'beneficiaryInfo.immPetitionInfo' )" wrapclass="md:w-1/2"  :display="false" :tplkey="'applCurStatus'" :fieldsArray="questionnaireDetails"  cid="applCurStatus" formscope="casedetailsform" v-model="petition.beneficiaryInfo.immPetitionInfo.applCurStatus" :tplsection="'beneficiaryInfo.immPetitionInfo'"  :fieldName="'applCurStatus'"   label="Current Status of the Application" placeHolder="Current Status of the Application"/>
    
                                                
                                                
                                                </template>
    
    
    
                                                <immiswitchyesno :notRequired="true" :required="checkFieldIsRequired({'key':'seekingFiledDateforETA750','section':'beneficiaryInfo.immPetitionInfo', 'fieldsArray':questionnaireDetails, 'required':true ,'notRequired':true})" v-if="canRenderField('seekingFiledDateforETA750', questionnaireDetails ,false,'beneficiaryInfo.immPetitionInfo' )" :display="false" :tplkey="'seekingFiledDateforETA750'" wrapclass=" " :fieldsArray="questionnaireDetails" :cid="'ben_seekingFiledDateforETA750'" formscope="casedetailsform" v-model="petition.beneficiaryInfo.immPetitionInfo.seekingFiledDateforETA750" :tplsection="'beneficiaryInfo.immPetitionInfo'"  :fieldName="'seekingFiledDateforETA750'" :wrapclass="'yesno-v1'"    label="Are you seeking to utilize the filing date from a previously submitted Application for Alien Employment Certification (ETA 750)?" placeHolder="" />
                                                <immiswitchyesno :notRequired="true" :required="checkFieldIsRequired({'key':'anyI140Filed','section':'beneficiaryInfo.immPetitionInfo', 'fieldsArray':questionnaireDetails, 'required':true,'notRequired':true })"  v-if="canRenderField('anyI140Filed', questionnaireDetails ,false,'beneficiaryInfo.immPetitionInfo' )" :display="false" :tplkey="'anyI140Filed'" wrapclass=" " :fieldsArray="questionnaireDetails" :cid="'ben_anyI140Filed'" formscope="casedetailsform" v-model="petition.beneficiaryInfo.immPetitionInfo.anyI140Filed" :tplsection="'beneficiaryInfo.immPetitionInfo'"  :fieldName="'anyI140Filed'"   label="Has any I-140 Petition been filed on your behalf? " placeHolder="" />
    
                                                <template v-if="petition.beneficiaryInfo.immPetitionInfo.anyI140Filed"> 
    
                                                <datepickerField :notRequired="true" :validationRequired="true" v-if="canRenderField('fieldDate', questionnaireDetails ,false,'beneficiaryInfo.immPetitionInfo.i140Info' )" wrapclass="md:w-1/2"  :display="false" :tplkey="'fieldDate'" :fieldsArray="questionnaireDetails"  v-model="petition.beneficiaryInfo.immPetitionInfo.i140Info.fieldDate" :tplsection="'beneficiaryInfo.immPetitionInfo.i140Info'"  :fieldName="'fieldDate'"  formscope="casedetailsform"  :dateEnableTo="featureDates" label="Date Filed" />
                                                <immiInput :notRequired="true" v-if="canRenderField('employerName', questionnaireDetails ,false,'beneficiaryInfo.immPetitionInfo.i140Info' )" wrapclass="md:w-1/2"  :display="false" :tplkey="'employerName'" :fieldsArray="questionnaireDetails"  cid="benfalienNumber" formscope="casedetailsform" v-model="petition.beneficiaryInfo.immPetitionInfo.i140Info.employerName"  :tplsection="'beneficiaryInfo.immPetitionInfo.i140Info'"  :fieldName="'employerName'"  label="Name of the Employer" placeHolder="Name of the Employer" />
                                                <datepickerField :notRequired="true" :validationRequired="true"  v-if="canRenderField('priorityDate', questionnaireDetails ,false,'beneficiaryInfo.immPetitionInfo.i140Info' )" wrapclass="md:w-1/2"  :display="false" :tplkey="'priorityDate'" :fieldsArray="questionnaireDetails"  v-model="petition.beneficiaryInfo.immPetitionInfo.i140Info.priorityDate" :tplsection="'beneficiaryInfo.immPetitionInfo.i140Info'"  :fieldName="'priorityDate'"  formscope="casedetailsform"  :dateEnableTo="featureDates" label="Priority Date" />
                                                <immiInput v-if="canRenderField('currentStatus', questionnaireDetails ,false,'beneficiaryInfo.immPetitionInfo.i140Info' )" wrapclass="md:w-1/2"  :display="false" :tplkey="'currentStatus'" :fieldsArray="questionnaireDetails"  cid="applCurStatus" formscope="casedetailsform" v-model="petition.beneficiaryInfo.immPetitionInfo.i140Info.currentStatus" :tplsection="'beneficiaryInfo.immPetitionInfo.i140Info'"  :fieldName="'currentStatus'"   label="Current Status of the I-140" placeHolder="Current Status of the I-140"/>
    
                                                <immiInput v-if="canRenderField('eb2orEb3', questionnaireDetails ,false,'beneficiaryInfo.immPetitionInfo.i140Info' )" wrapclass="md:w-1/2"  :display="false" :tplkey="'eb2orEb3'" :fieldsArray="questionnaireDetails"  cid="applCurStatus" formscope="casedetailsform" v-model="petition.beneficiaryInfo.immPetitionInfo.i140Info.eb2orEb3" :tplsection="'beneficiaryInfo.immPetitionInfo.i140Info'"  :fieldName="'eb2orEb3'"   label="EB2/EB3" placeHolder="EB2/EB3"/>
                                            </template>
                                            </template>
                                            <!-------------------------------------->
                                            <template v-if="gettotalDays > 1095 && canRenderField('confirmDaysStayInUS', questionnaireDetails ,false,'beneficiaryInfo' )">
                                                <div class="vx-col  w-full rspace-bottom">
                                                    <div class="form_group pt-10" v-if="canRenderField('confirmDaysStayInUS', questionnaireDetails ,false,'beneficiaryInfo' )">
                                                        <label class="form_label">It appears that you have spent {{gettotalDays}} of days in the US in H/L status. Please confirm if this is correct.?
                                                        </label>
                                                        <label class="form_label" for="confirmDaysStayInUS">
                                                            <input name="confirmDaysStayInUS" v-validate="'required'" type="checkbox" v-model="petition.beneficiaryInfo.confirmDaysStayInUS" :tplsection="'beneficiaryInfo'"  :fieldName="'confirmDaysStayInUS'" >
    
                                                            Yes</label>
                                                        <p v-show="errors.has('casedetailsform.confirmDaysStayInUS')" class="text-danger text-sm">Please confirm if this is correct.</p>
    
                                                    </div>
    
                                                    <div class="form_group mb-10" v-if="canRenderField('hasApprovedI140', questionnaireDetails ,false,'beneficiaryInfo' ) || canRenderField('hasPermPendingForMorethan365Days', questionnaireDetails ,false,'beneficiaryInfo' )">
                                                        <template v-if="gettotalDays > 2185">
    
                                                            <label class="form_label pb-5 pt-5">Note: Please note that you are allowed a maximum period of 6 years on your H-1B. To receive H-1B approval past 6 years you need to either have an approved I-140 or PERM application pending for more than 364 days. Please confirm if you have the following:</label>
    
                                                            <immiswitchyesno :notRequired="true" :required="checkFieldIsRequired({'key':'hasApprovedI140','section':'beneficiaryInfo', 'fieldsArray':questionnaireDetails, 'required':true ,'notRequired':true})" :display="false" :tplkey="'hasApprovedI140'"  wrapclass=" " :fieldsArray="questionnaireDetails" :cid="'hasApprovedI140'" formscope="casedetailsform" v-model="petition.beneficiaryInfo.hasApprovedI140" :tplsection="'beneficiaryInfo'"  :fieldName="'hasApprovedI140'"   label="Approved I-140 (from any employer that has not been revoked within 180 days of its approval)" placeHolder="" />
    
                                                            <immiswitchyesno :notRequired="true" :required="checkFieldIsRequired({'key':'hasPermPendingForMorethan365Days','section':'beneficiaryInfo', 'fieldsArray':questionnaireDetails, 'required':true,'notRequired':true })" :display="false" :tplkey="'hasPermPendingForMorethan365Days'"  wrapclass=" " :fieldsArray="questionnaireDetails" :cid="'hasPermPendingForMorethan365Days'" formscope="casedetailsform" v-model="petition.beneficiaryInfo.hasPermPendingForMorethan365Days" :tplsection="'beneficiaryInfo'"  :fieldName="'hasPermPendingForMorethan365Days'"   label="PERM application pending for more than 365 days" placeHolder="" />
    
                                                        </template>
    
                                                    </div>
    
                                                </div>
    
                                            </template>
                                            <immiyesorno :notRequired="true" :required="checkFieldIsRequired({'key':'previouslyMarried','section':'beneficiaryInfo', 'fieldsArray':questionnaireDetails, 'required':true,'notRequired':true })" v-if="checkProperty(petition ,'beneficiaryInfo','maritalStatus') && checkProperty(petition ,'beneficiaryInfo','maritalStatus') !=1" wrapclass=" "  :display="false" :fieldsArray="questionnaireDetails" formscope="casedetailsform" cid="previouslyMarried"  v-model="petition.beneficiaryInfo.previouslyMarried" :tplkey="'previouslyMarried'" :tplsection="'beneficiaryInfo'"  :fieldName="'previouslyMarried'"   label="Were you married previously?"></immiyesorno>
                                            <template v-if="petition.beneficiaryInfo.previouslyMarried  && checkProperty(petition ,'beneficiaryInfo','maritalStatus') !=1 && canRenderField('previousSpouse',questionnaireDetails, false, 'beneficiaryInfo.previousSpouse' )">
                                                <previousSpouseForm :notRequired="true"  :tplsection="'beneficiaryInfo.previousSpouse'" cid="ben_previousSpouse" formscope="casedetailsform" :countries="countries" :petition="petition" :fieldName="'previousSpouse'" :fieldsArray="questionnaireDetails" v-model="petition.beneficiaryInfo.previousSpouse"    />
                                            </template> 
    
                                        </div>
                                    </div>
                                </vs-col>
                            </form>
                        </div>            
    <!-------------------------------------------------------------------------------->
                        <div v-if="currentTab=='education' && canRenderField('educations', questionnaireDetails ,false,'beneficiaryInfo.educations')" id="education_details">
                            <form data-vv-scope="educationform" @submit.prevent="" @keydown.enter.prevent="">
                                <vs-col class="w-full p-0">
                                    <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal" icon="IP-information-button" active="true">
                                        After your 12th grade – Starting from the most recent degree first
    
                                    </vs-alert>
    
                                </vs-col>
    
                                <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12">
                                    <div class="form-container pt-10 form-container-questionnaire">
                                        <div class="vx-row">
                                            <!-- @input="updateEducationDegree" -->
                                            <immiyesorno  :notRequired="true" @input="disableCountryUsa();removeCOuntryUSA()" :cid="'hasMasterDegreeInUS'" formscope="educationform" :required="checkFieldIsRequired({'key':'hasMasterDegreeInUS','section':'beneficiaryInfo', 'fieldsArray':questionnaireDetails, 'required':true,'notRequired':true })" :display="false"  :tplkey="'hasMasterDegreeInUS'" :fieldsArray="questionnaireDetails"   v-model="petition.beneficiaryInfo.hasMasterDegreeInUS" :tplsection="'beneficiaryInfo'"  :fieldName="'hasMasterDegreeInUS'"   label="Do you have Masters degree in United States?"></immiyesorno>
                                            <immieducations  :notRequired="true"  ref="beneficairy_education" :prefillCountryInQuestionnaire="prefillCountryInQuestionnaire" :tplsection="'beneficiaryInfo.educations'" :petition="petition" :countries="countries" :fieldsArray="questionnaireDetails"  cid="ben_educations" formscope="educationform" v-model="petition.beneficiaryInfo.educations" :fieldName="'educations'"  />
    
                                        </div>
    
                                    </div>
                                </vs-col>
                            </form>
                        </div>
                                    
                        <div v-if="currentTab=='employment'" id="employment_details">
                            <form data-vv-scope="employmentform" @submit.prevent="" @keydown.enter.prevent="">
                                <template >
                                    <vs-col class="w-full p-0">
                                        <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal" icon="IP-information-button" active="true">
                                            Provide your current and previous employment details, starting from the most recent first.
                                        </vs-alert>
        
                                    </vs-col>
                                        
                                    <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12">
                                        <div class="form-container form-container-questionnaire form-container-employment">
                                            <div class="vx-row">
                                                <!-- <h3 class="small-header emp_det_header">Employment Details</h3> -->
                                                <div class="empyes_no">
                                                    <immiyesorno  :notRequired="true" :wrapclass="'yesnomar'" :cid="'anyOtherPersonEmployedInUS'" formscope="employmentform" :required="checkFieldIsRequired({'key':'anyOtherPersonEmployedInUS','section':'beneficiaryInfo', 'fieldsArray':questionnaireDetails, 'required':true, notRequired:true })" :display="false" :tplkey="'anyOtherPersonEmployedInUS'" :fieldsArray="questionnaireDetails"   v-model="petition.beneficiaryInfo.anyOtherPersonEmployedInUS" :tplsection="'beneficiaryInfo'"  :fieldName="'anyOtherPersonEmployedInUS'"   label="Have you ever been employed?"></immiyesorno>
                                                </div>
                                                <template v-if="(petition.beneficiaryInfo && petition.beneficiaryInfo.anyOtherPersonEmployedInUS )  ">
                                                    <immiemployment  :forPermQiestionnaire="true"  :notRequired="true" :prefillCountryInQuestionnaire="prefillCountryInQuestionnaire" :petition="petition" :countries="countries" :fieldsArray="questionnaireDetails"  cid="ben_prevEmploymentInfo" formscope="employmentform" v-model="petition.beneficiaryInfo.prevEmploymentInfo" :tplsection="'beneficiaryInfo.prevEmploymentInfo'"  :fieldName="'prevEmploymentInfo'"  />
                                                </template>
                                            </div>
        
                                        </div>
                                    </vs-col>
                                </template>
                                <template >
                                    <vs-col class="w-full p-0 mart30">
                                        <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal" icon="IP-information-button" active="true">
                                            Last Employer outside of the United States for more than one year.
                                        </vs-alert>
        
                                    </vs-col>
                                    <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12">
                                        <div class="form-container form-container-questionnaire form-container-employment">
                                            <div class="vx-row">
                                                <div class="empyes_no">
                                                    <immiyesorno  :notRequired="true" :wrapclass="'yesnomar'" :cid="'haveYouEverEmployed'" formscope="employmentform" :required="checkFieldIsRequired({'key':'haveYouEverEmployed','section':'beneficiaryInfo', 'fieldsArray':questionnaireDetails, 'required':true, notRequired:true })" :display="false" :tplkey="'haveYouEverEmployed'" :fieldsArray="questionnaireDetails"   v-model="petition.beneficiaryInfo.haveYouEverEmployed" :tplsection="'beneficiaryInfo'"  :fieldName="'haveYouEverEmployed'"   label="Have you ever been employed Outside US?"></immiyesorno>
                                                </div>
                                                <template v-if="petition.beneficiaryInfo.haveYouEverEmployed">
                                                    <immiemployment  :forPermQiestionnaire="true"  :notRequired="true" :prefillCountryInQuestionnaire="prefillCountryInQuestionnaire" :petition="petition" :countries="countries" :fieldsArray="questionnaireDetails"  cid="ben_prevEmploymentOutsideUS" formscope="employmentform" v-model="petition.beneficiaryInfo.prevEmploymentOutsideUS" :tplsection="'beneficiaryInfo.prevEmploymentOutsideUS'"  :fieldName="'prevEmploymentOutsideUS'"  />
                                                </template>
                                            </div>
                                        </div>
                                    </vs-col>  
                                </template>
                            </form>
    
                        </div>
                        <div v-if="currentTab=='parent' && (canRenderField('motherInfo', questionnaireDetails ,false,'motherInfo') || canRenderField('fatherInfo', questionnaireDetails ,false,'fatherInfo'))" id="parent_details">
                            <form data-vv-scope="parentform" @submit.prevent="" @keydown.enter.prevent="">
                                <template v-if=" canRenderField('fatherInfo', questionnaireDetails ,false,'fatherInfo')">
                                    <vs-col class="w-full p-0">
                                        <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal" icon="IP-information-button" active="true">
                                            Provide your father details, starting from the most recent first.
                                        </vs-alert>
                                    </vs-col>
                                    <vs-col class="m-auto float-none p-0" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12">
                                        <div class="form-container form-container-questionnaire form_container_485">
                                            <div class="vx-row">
                                                <div class="vx-col w-full">
                                                    <parentForm :countriesWithoutUS="countriesWithoutUS"  :notRequired="true"  :petition="petition" :countries="countries" :fieldsArray="questionnaireDetails" cid="ben_fatherInfo"  formscope="parentform"  v-model="petition.fatherInfo" :tplsection="'fatherInfo'"  :fieldName="'fatherInfo'"   />
                                                </div>
                                            </div>
                                        </div>
                                    </vs-col>
                                </template>
                                <template v-if=" canRenderField('motherInfo', questionnaireDetails ,false,'motherInfo')">
                                    <vs-col class="w-full p-0 mart20" >
                                        <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal" icon="IP-information-button" active="true">
                                            Provide your mother details, starting from the most recent first.
                                        </vs-alert>
                                    </vs-col>
                                    <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12" >
                                        <div class="form-container form-container-questionnaire form_container_485">
                                            <div class="vx-row">
                                                <div class="vx-col w-full">
                                                    <parentForm :countriesWithoutUS="countriesWithoutUS" :notRequired="true"  :countries="countries" :fieldsArray="questionnaireDetails" :petition="petition" v-model="petition.motherInfo" :parentType="'Mother Information'" cid="ben_motherInfo"  :tplsection="'motherInfo'"  :fieldName="'motherInfo'"  formscope="parentform"  />
                                                </div>    
                                            </div>
                                        </div>
                                    </vs-col>
                                </template>
                                </form>
                        </div> 
    
                        <div v-if="currentTab=='dependentsinfo' " id="dependentsinfo_details">
                            <form data-vv-scope="dependentsinfoform" @submit.prevent="" @keydown.enter.prevent="">
                                <!-- hasAnyDependetsinUStoFileH4 -->
                                <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12">
                                    <div class="form-container pt-10 form-container-questionnaire">
                                        <div class="vx-row">
                                            <immiyesorno  :notRequired="true" :cid="'hasAnyDependetsinUStoFileH4'"  formscope="dependentsinfoform" :required="checkFieldIsRequired({'key':'hasAnyDependetsinUStoFileH4','section':'beneficiaryInfo', 'fieldsArray':questionnaireDetails, 'required':true,'notRequired':true })" :display="false" :tplkey="'hasAnyDependetsinUStoFileH4'" :fieldsArray="questionnaireDetails" v-model="petition.beneficiaryInfo.hasAnyDependetsinUStoFileH4"  :tplsection="'beneficiaryInfo'"  :fieldName="'hasAnyDependetsinUStoFileH4'"  label="Do you have any dependents currently in USA for whom you wish to file H4 Visa?"></immiyesorno>
                                            <template v-if="(petition.beneficiaryInfo && petition.beneficiaryInfo.hasAnyDependetsinUStoFileH4 && canRenderField('hasAnyDependetsinUStoFileH4', questionnaireDetails ,false,'beneficiaryInfo' )) || !canRenderField('hasAnyDependetsinUStoFileH4',questionnaireDetails,false ,'beneficiaryInfo')  ">
                                                
                                                <immiyesorno  :notRequired="true" :cid="'h4Required'" formscope="dependentsinfoform" :required="checkFieldIsRequired({'key':'h4Required','section':'dependentsInfo.spouse', 'fieldsArray':questionnaireDetails, 'required':true,'notRequired':true })" :wrapclass="'h4_ead_label'" @input="spouseH4();checkMarriageCerti()" :display="false" :tplkey="'h4Required'" :fieldsArray="questionnaireDetails" v-model="petition.dependentsInfo.spouse.h4Required"  :tplsection="'dependentsInfo.spouse'"  :fieldName="'h4Required'"  label="H4 required for spouse?"></immiyesorno>

                                                <div class="vx-col w-full">
                                                    <div class="dependent-block_wrap" v-if="checkProperty(petition ,'dependentsInfo' ,'spouse' ) && petition.dependentsInfo && petition.dependentsInfo.spouse && petition.dependentsInfo.spouse.firstName!='' && petition.dependentsInfo.spouse.firstName!=null && checkProperty(petition.dependentsInfo ,'spouse' ,'h4Required')">
                                                        <div class="dependent-block">
                                                            <div class="dependent-title">
                                                                <h3>
                                                                    <!-- {{petition.dependentsInfo.spouse | formatFullname}} -->
                                                                    {{ formatFullname(petition.dependentsInfo.spouse) }}
                                                                </h3>
                                                                <ul>
                                                                    <li @click="editSpouse(petition.dependentsInfo.spouse)">
                                                                        <a><img src="@/assets/images/main/edit_icon.svg" />
                                                                        </a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                            <div class="dependent_details">
                                                                <ul>
                                                                    <li v-if="petition.dependentsInfo.spouse.dateOfBirth"> Date of Birth <span>{{petition.dependentsInfo.spouse.dateOfBirth | formatDate}}</span></li>
                                                                    <li v-if="petition.dependentsInfo.spouse.physicalAddress && petition.dependentsInfo.spouse.physicalAddress.countryDetails && petition.dependentsInfo.spouse.physicalAddress.countryDetails.name"> Country <span>{{petition.dependentsInfo.spouse.physicalAddress.countryDetails.name}}</span></li>
            
                                                                </ul>
            
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <immiyesorno :cid="'h4Required_h4Required'" formscope="dependentsinfoform" :required="checkFieldIsRequired({'key':'h4Required','section':'dependentsInfo.childrens', 'fieldsArray':questionnaireDetails, 'required':true,'notRequired':true })" @input="childH4()" :wrapclass="'h4_ead_label'" :display="false" :tplkey="'h4Required'" :fieldsArray="questionnaireDetails" v-model="petition.h4RequiredForChild" :tplsection="'dependentsInfo.childrens'"  :fieldName="'h4Required'"    label="H4 required for children?"></immiyesorno>
        
                                                <template v-if="petition.dependentsInfo.childrens && petition.dependentsInfo.childrens.length > 0 && petition.dependentsInfo.childrens[0].firstName!='' && petition.dependentsInfo.childrens[0].firstName!=null">
                                                    <div class="vx-col w-full">
        
                                                        <div class="dependent-block_wrap">
        
                                                            <template v-for="(children, index) in petition.dependentsInfo.childrens">
                                                                <div class="dependent-block" v-if="children.saved" :key="index">
                                                                    <div class="dependent-title" :key="index">
                                                                        <h3>
                                                                            {{ formatFullname(children) }}
                                                                            <!-- {{ children.name }} -->
                                                                            <!-- {{children | formatFullname}}  physicalAddress -->
                                                                        </h3>
                                                                        <ul>
                                                                            <li @click="editChildren(children,index)">
                                                                                <a><img src="@/assets/images/main/edit_icon.svg" />
                                                                                </a>
                                                                            </li>
                                                                        </ul>
                                                                    </div>
        
                                                                    <div class="dependent_details">
                                                                        <ul>
                                                                            <li v-if="children.dateOfBirth"> Date of Birth <span>{{children.dateOfBirth | formatDate}}</span></li>
                                                                            <li v-if="
                                                                            children.physicalAddress.countryDetails && children.physicalAddress.countryDetails.name
                                                                            
                                                                            "> Country <span>{{children.physicalAddress.countryDetails.name}}</span></li>
        
                                                                        </ul>
        
                                                                    </div>
                                                                </div>
        
                                                            </template>
        
                                                        </div>
        
                                                    </div>
        
                                                </template>
        
                                                <div style="margin-left:1rem;" vs-type="flex" vs-align="left" vs-lg="2" vs-sm="2" v-if="petition.h4RequiredForChild">
                                                    <a @click="addchildren" class="add-more ml-0" style="display:inline-block" type="filled">
                                                        <span>+</span> Add Child
                                                    </a>
                                                </div>
                                            </template>
    
                                        </div>
    
                                    </div>
                                </vs-col>
                            </form>
                        </div>
    
                        <div v-if="currentTab=='documents'" id="documents_details">
                            <form data-vv-scope="documentsform" @submit.prevent="" @keydown.enter.prevent="">
                                <vs-col class="w-full p-0">
                                    <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal" icon="IP-information-button" active="true">
                                        NOTE: This questionnaire should be filled out completely and
                                        accurately. Kindly read the instructions carefully.
                                       
                                    </vs-alert>
    
                                </vs-col>
    
                                <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12">
                                    <div class="form-container pt-10 form-container-questionnaire">
                                        <casedocumentslist @emitUploadingAction="emitUploadingAction" :docMainCategory="'bendocslist'" :docslist="bendocslist" :petition="petition" formscope="documentsform" :fieldsArray="questionnaireDetails" v-model="petition.documents" :tplsection="'documents'"  :fieldName="''" ></casedocumentslist>
    
                                    </div>
    
                                </vs-col>
    
                            </form>
    
                        </div>
    
                        <!-------------485 Tabs-------------->
                    </div>
                </div>
                <div class="questionnaire_footer">
                    <div class="d-flex">
                        <vs-button v-if="getIndexOfActivetab!=1" @click="goBack()" class="questionnaire_btn" type="filled">Back</vs-button>
                    </div>
                    <div class="d-flex">
                        <vs-button @click="saveCase(false);" :disabled="documentUploading" class="questionnaire_btn" type="filled">Save</vs-button>
                        <vs-button color="success" @click="submitCase();" :disabled="documentUploading" class="save questionnaire_btn" type="filled">{{actiontype}}</vs-button>
    
                    </div>
                </div>
            </div>
    
        </div>
    
        <div class="custom_modal_sec preview_questionarie" :class="{ modalopen: questionnairePreview }">
            <div class="custom_modal_overlay" ></div>
    
            <div class="custom_modal_cnt">
                <div class="modal_title">
                    <h2>Questionnaire Review</h2>
                    <span @click="questionnairePreview = false">
                        <x-icon size="1.5x" class="close"></x-icon>
                    </span>
                </div>
                <div class="modal_cnt preview_content new_questionnaire_review">
                    <VuePerfectScrollbar ref="mainSidebarPs1" :settings="settings">
                        <PetitionDetails v-if="questionnairePreview" :loadedFromPreview="true" :fieldsArrayDetails="questionnaireDetails" :previewData="questionnairePreviewData" />
                    </VuePerfectScrollbar>
                </div>
                <div class="questionnaire_footer">
                    <div class="d-flex">
                        <vs-button @click="questionnairePreview = false" class="cancel questionnaire_btn" type="filled">Cancel
                        </vs-button>
                        <vs-button @click="saveCase(true,false);" class="save questionnaire_btn" type="filled">Submit 
                        </vs-button>
                    </div>
                </div>
            </div>
        </div>
    
        <vs-popup class="holamundo success-popups" title="Your registration is complete." :active.sync="SuccessQuestionnaire">
            <figure>
                <img src="@/assets/images/main/icon-note.svg" alt="login" class="mx-auto" />
            </figure>
            <h2 class="title">Questionnaire submitted successfully!</h2>
            <template v-if="checkProperty($route ,'name') !='fill-questionnaire' && checkProperty($route ,'name') !='fill-perm-questionnaire' ">
            <p v-if="getUserData && checkProperty(getUserData['tenantDetails']['typeDetails'],'id') == 2">
                It will be reviewed by the Admin and appropriate actions will be
                taken soon. 
            </p>
            <p v-if="getUserData && (checkProperty(getUserData['tenantDetails']['typeDetails'],'id') == 1)">
                It will be reviewed by the petitioner and appropriate actions will be
                taken soon. 
            </p>
        </template>
        </vs-popup>
        <vs-popup class="holamundo main-popup qcomment" title="Comment" :active.sync="commentPopUp">
            <form data-vv-scope="commentForm" @submit.prevent="" @keydown.enter.prevent="">
                <div class="form-container" @click="formerrors.msg = ''">
                    <div class="vx-row">
                        <div class="vx-col w-full">
                            <div class="form_group">
                                <label class="form_label">Comments </label>
                                <!-- <vs-textarea data-vv-as="Comments" v-validate="'required'" v-model="comments" name="comments" class="w-full" /> -->
                                <ckeditor data-vv-as="Comments" v-validate="'required'" v-model="comments" name="comments" class="w-full"   :editor="editor" :config="editorConfig"></ckeditor>
                                <span class="text-danger text-sm" v-show="errors.has('commentForm.comments')">{{ errors.first("commentForm.comments") }}</span>
                            </div>
                        </div>
                    </div>
                    <div class="text-danger text-sm formerrors" v-show="formerrors.msg">
                        <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
                    </div>
                </div>
                <div class="popup-footer relative">
                    <span class="loader" v-if="submiTing"><img src="@/assets/images/main/loader.gif" /></span>
    
                    <vs-button :disabled="comments == '' || comments.trim() == '' || submiTing" color="success" @click="formSubmitted(false)" class="save" type="filled">Submit</vs-button>
                </div>
            </form>
        </vs-popup>
    
        <div class="custom_modal_sec spouse_doc documents__modal" v-if="spouseModalForm" :class="{ modalopen: spouseModalForm }">
            <div class="custom_modal_overlay"></div>
            <div class="custom_modal_cnt">
                <div class="modal_title">
                    <h2>Spouse Information</h2>
                    <span class="close" v-if="!documentUploading" @click="toggleSpouseForm(false)">
                        <em class="material-icons">close</em>
                    </span>
                </div>
                <div class="modal_cnt">
                    <VuePerfectScrollbar ref="mainSidebarPs" :settings="settings">
                        <form data-vv-scope="dependentsInfoformmodal" @submit.prevent="" @keydown.enter.prevent="" >
                            <personalinfo :countriesWithoutUS="countriesWithoutUS" :notRequired="true"  :tplsection="'dependentsInfo.spouse'" :eye_colorList="eye_colorList" :marital_statuses="marital_statuses"  :races_list="races_list"  :hair_colorsList="hair_colorsList" :feetList="feetList" :inchesList="inchesList"  :visastatuses="visastatuses" :countries="countries" formscope="dependentsInfoformmodal" :petition="petition" :fieldsArray="questionnaireDetails" v-model="spouse"></personalinfo>
                            <template  v-if="(canRenderField('prevEmploymentInfo', questionnaireDetails ,false,'dependentsInfo.spouse.prevEmploymentInfo') || canRenderField('anyOtherPersonEmployedInUS', questionnaireDetails ,false,'dependentsInfo.spouse'))">
                               
                                <vs-col class="w-full p-0 mart20">
                                    <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal" icon="IP-information-button" active="true" v-if="spouse && spouse.h4EADRequired">
                                        Provide your current and previous employment details, starting from the most recent first.
                                    </vs-alert>
                                </vs-col>
                                <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12">
                                    <div class="form-container form-container-questionnaire form-container-employment form_container_485_v2 cstm_mdl_485_spouce_emp">
                                        <div class="vx-row">
                                            <immiyesorno :notRequired="true"  v-if="spouse && spouse.h4EADRequired" :cid="'anyOtherPersonEmployedInUS'" formscope="dependentsInfoformmodal" :required="checkFieldIsRequired({'key':'anyOtherPersonEmployedInUS','section':'dependentsInfo.spouse', 'fieldsArray':questionnaireDetails, 'required':true,'notRequired':true })"  :display="false" :tplkey="'anyOtherPersonEmployedInUS'" :tplsection="'dependentsInfo.spouse'"   :wrapclass="'mt-6 mb-0 yesnomar formgroup-mb0'" :fieldsArray="questionnaireDetails" v-model="spouse.anyOtherPersonEmployedInUS" fieldName="anyOtherPersonEmployedInUS" label="Have you ever been employed?"></immiyesorno>    
                                            <template v-if="spouse.anyOtherPersonEmployedInUS && spouse.h4EADRequired">
                                                <immiemployment :notRequired="true"  :prefillCountryInQuestionnaire="prefillCountryInQuestionnaire" :petition="petition" :callFromSpouse="true" :countries="countries" :fieldsArray="questionnaireDetails"  cid="dep_prevEmploymentInfo" formscope="dependentsInfoformmodal" v-model="spouse.prevEmploymentInfo" :tplsection="'dependentsInfo.spouse.prevEmploymentInfo'"  :fieldName="'prevEmploymentInfo'"  />  
                                            </template>
        
                                        </div>
                                    </div>
                                </vs-col>
                             </template>
                             <template v-if="(canRenderField('prevEmploymentOutsideUS', questionnaireDetails ,false,'dependentsInfo.spouse.prevEmploymentOutsideUS') || canRenderField('haveYouEverEmployed', questionnaireDetails ,false,'dependentsInfo.spouse')) ">
                                <vs-col class="w-full p-0">
                                    <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal" icon="IP-information-button" active="true" v-if="spouse && spouse.h4EADRequired">
                                        Last Employer outside of the United States for more than one year.
                                    </vs-alert>
                                </vs-col>
                                <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12">
                                    <div class="form-container form-container-questionnaire form-container-employment form_container_485_v2 cstm_mdl_485_spouce_emp">
                                        <div class="vx-row">
                                            <immiyesorno v-if="spouse && spouse.h4EADRequired" :cid="'haveYouEverEmployed'" formscope="dependentsInfoformmodal" :required="checkFieldIsRequired({'key':'haveYouEverEmployed','section':'dependentsInfo.spouse', 'fieldsArray':questionnaireDetails, 'required':true,'notRequired':true })" :display="false" :tplkey="'haveYouEverEmployed'" :fieldsArray="questionnaireDetails"   v-model="spouse.haveYouEverEmployed" :tplsection="'dependentsInfo.spouse'" :wrapclass="'mt-6 mb-0 yesnomar formgroup-mb0'" :fieldName="'haveYouEverEmployed'"   label="Have you ever been employed Outside US?"></immiyesorno>
                                            <template v-if="spouse && spouse.haveYouEverEmployed && spouse.h4EADRequired">
                                                <immiemployment :notRequired="true" :petition="petition" :countries="countries" :fieldsArray="questionnaireDetails"  cid="dep_prevEmploymentOutsideUS" formscope="dependentsInfoformmodal"  v-model="spouse.prevEmploymentOutsideUS" :tplsection="'dependentsInfo.spouse.prevEmploymentOutsideUS'"  :fieldName="'prevEmploymentOutsideUS'"  />   
                                            </template>
                                        </div>
                                    </div>
                                </vs-col>
                            </template>
                            
                           
                            <template v-if="canRenderField('fatherInfo', questionnaireDetails ,false,'dependentsInfo.spouse.fatherInfo')">
                               
                                <vs-col class="w-full p-0">
                                    <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal" icon="IP-information-button" active="true" >
                                        Provide your father details, starting from the most recent first.
                                    </vs-alert>
                                </vs-col>
                                <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12">
                                    <div class="form-container form-container-questionnaire form-container-employment form_container_485 pad_485_set">
                                        <div class="vx-row">
                                            <div class="vx-col w-full p-0">
                                                <parentForm :countriesWithoutUS="countriesWithoutUS" :notRequired="true"  v-model="spouse.fatherInfo"  cid="dep_fatherInfo" :tplsection="'dependentsInfo.spouse.fatherInfo'"  :fieldName="'dep_fatherInfo'"  formscope="dependentsInfoformmodal" :countries="countries" :fieldsArray="questionnaireDetails" :petition="petition" />
                                            </div>
                                        </div>
                                    </div>
                                </vs-col>
                            </template>
                            <template v-if="canRenderField('motherInfo', questionnaireDetails ,false,'dependentsInfo.spouse.motherInfo')">
                                <vs-col class="w-full p-0 mart30">
                                    <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal" icon="IP-information-button" active="true">
                                        Provide your mother details, starting from the most recent first.
                                    </vs-alert>
                                </vs-col>
                                <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12">
                                    <div class="form-container form-container-questionnaire form-container-employment form_container_485 pad_485_set">
                                        <div class="vx-row">
                                            <div class="vx-col w-full p-0">
                                                <parentForm :countriesWithoutUS="countriesWithoutUS" :notRequired="true"  v-model="spouse.motherInfo" :parentType="'Mother Information'"  cid="dep_motherInfo" :tplsection="'dependentsInfo.spouse.motherInfo'"  :fieldName="'motherInfo'"  formscope="dependentsInfoformmodal" :countries="countries" :fieldsArray="questionnaireDetails" :petition="petition" />
                                            </div>
                                        </div>
                                    </div>
                                </vs-col>
                            </template>
                            <template v-if="checkProperty(spouse, 'associations') && checkProperty(spouse, 'associations', 'length')>0 && canRenderField('associations', questionnaireDetails ,false,'dependentsInfo.spouse.associations') ">
                                <vs-col class="w-full p-0 mart10">
                                    <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal" icon="IP-information-button" active="true">
                                        All associations and groups of which you are or have been a member, including political organizations, if you do not belong to any organizations, please write "None"
                                    </vs-alert>
                                </vs-col>
                                <vs-col class="m-auto float-none pt-6" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12">
                                    <div class="form-container form-container-questionnaire form-container-employment">
                                        <h3 class="small-header">Associations/Groups</h3>
                                            <div class="vx-row">
                                                
                                                <immiInput :notRequired="true" :display="false" :tplkey="'name'" :fieldsArray="questionnaireDetails"  cid="deffname" formscope="dependentsInfoformmodal" v-model="spouse['associations'][0].name" :tplsection="'dependentsInfo.spouse.associations'"  :fieldName="'name'"  :required="true"  label="Name of the associations and groups" placeHolder="Name of the associations and groups" />
                                                
                                                <immiInput :notRequired="true"  :display="false" :tplkey="'natureofAssociations'" :fieldsArray="questionnaireDetails"  cid="defbenfnatureofAssociations" formscope="dependentsInfoformmodal" v-model="spouse['associations'][0].natureofAssociations" :tplsection="'dependentsInfo.spouse.associations'"  :fieldName="'natureofAssociations'"  :required="true"  label="Nature of associations and groups" placeHolder="Nature of associations and groups" />
                                                <datepickerField :notRequired="true" :display="false" :tplkey="'startDate'" :fieldsArray="questionnaireDetails" :validationRequired="true" v-model="spouse['associations'][0].startDate" @input="clearEndDate(spouse['associations'])" :tplsection="'dependentsInfo.spouse.associations'"  :fieldName="'startDate_associations'"  formscope="dependentsInfoformmodal"  :dateEnableTo="featureDates" label="Start Date" />
                                                <datepickerField :notRequired="true" :display="false" :tplkey="'endDate'" :isDisabled="!spouse['associations'][0].startDate" :fieldsArray="questionnaireDetails"  :dateEnableFrom="spouse['associations'][0].startDate" :validationRequired="true" v-model="spouse['associations'][0].endDate" :tplsection="'dependentsInfo.spouse.associations'"  :fieldName="'endDate_associations'"  formscope="dependentsInfoformmodal"  label="End Date" /> 
                                                <div class="vx-col w-full">
                                                    <div >
                                                        <h3 class="small-header"> Address</h3>
                                                        <addressField :validationRequired="false"  :fieldsArray="questionnaireDetails" :showLane1="false" :showLane2="false" :disableCountry="false" :showZip="false" formscope="dependentsInfoformmodal" :showaptType="false" :addFormContainerCls="false" :countries="countries" v-model="spouse['associations'][0].address" :tplsection="'dependentsInfo.spouse.associations'"  :fieldName="'address'"  :cid="'daddress'" />

                                                    </div>
                                                </div>
                                            </div>
                                        
                                    </div>
                                </vs-col>
                            </template>
                            <template v-if="canRenderField('previousSpouse', questionnaireDetails ,false,'dependentsInfo.spouse.previousSpouse')">
                                <vs-col>
                                    <previousSpouseForm :countriesWithoutUS="countriesWithoutUS" :notRequired="true" :display="false" :countries="countries"  :cid="'previousSpouse'+'cid'" :formscope="'dependentsInfoformmodal'" v-model="spouse.previousSpouse"  :tplsection="'dependentsInfo.spouse.previousSpouse'" :fieldsArray="questionnaireDetails" :tplkey="'previousSpouse'" :validationRequired="true" :fieldName="'previousSpouse'"  />
                                </vs-col>
                            </template>

                            <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12" >
                                <div class="form-container mart10 padt20 child_case_docs_v2">
                                    <casedocumentslist :notRequired="true"  @emitUploadingAction="emitUploadingAction" :docMainCategory="'spousedoclist'" :tplsection="'dependentsInfo.spouse.documents'" :docslist="spousedoclist" formscope="dependentsInfoformmodal" :fieldsArray="questionnaireDetails" v-model="spouse.documents"></casedocumentslist>
                                </div>
                            </vs-col>
                        </form>
                    </VuePerfectScrollbar>
                </div>
                <!-- :disabled="submiTing"  -->
                <div class="popup-footer relative">
                    <vs-button color="dark" :disabled="documentUploading" @click="toggleSpouseForm(false)" class="cancel" type="filled">Cancel</vs-button> 
                    <vs-button color="success" :disabled="documentUploading" @click="submitSpouse()" class="save" type="filled">Save
                    </vs-button>
                </div>
                <div></div>
            </div>
        </div>
    
        <div class="custom_modal_sec child_doc documents__modal" v-if="childModalForm" :class="{ modalopen: childModalForm }">
            <div class="custom_modal_overlay"></div>
            <div class="custom_modal_cnt">
                <div class="modal_title">
                    <h2>Child Information</h2>
                    <span class="close" @click="toggleChildForm(false)">
                        <em class="material-icons">close</em>
                    </span>
                </div>
                <div class="modal_cnt">
                    <VuePerfectScrollbar ref="mainSidebarPschild" :settings="settings">
                        <form data-vv-scope="childInfoformmodal" @submit.prevent="" @keydown.enter.prevent="">
                            <childpersonalinfo :countriesWithoutUS="countriesWithoutUS" :notRequired="true" :tplsection="'dependentsInfo.childrens'" :countries="countries" formscope="childInfoformmodal" :petition="petition" :fieldsArray="questionnaireDetails" v-model="petition.dependentsInfo.childrens[selectedchild]"></childpersonalinfo>
                            
                            <vs-col class="float-none employment_yesno mt-0" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12" v-if="canRenderField('prevEmploymentInfo', questionnaireDetails ,false,'dependentsInfo.childrens.prevEmploymentInfo') && petition.dependentsInfo.childrens && petition.dependentsInfo.childrens[selectedchild]  && petition.dependentsInfo.childrens[selectedchild].h4EADRequired">
                                <div class="form-container">
                                    <div class="vx-row">
                                        <immiyesorno :notRequired="true" :cid="'anyOtherPersonEmployedInUS'" formscope="childInfoformmodal" :required="checkFieldIsRequired({'key':'anyOtherPersonEmployedInUS','section':'dependentsInfo.childrens', 'fieldsArray':questionnaireDetails, 'required':true,'notRequired':true })"  :display="false" :tplkey="'anyOtherPersonEmployedInUS'" :tplsection="'dependentsInfo.childrens'"  :wrapclass="'yesnomar'" :fieldsArray="questionnaireDetails" v-model="petition.dependentsInfo.childrens[selectedchild].anyOtherPersonEmployedInUS" fieldName="anyOtherPersonEmployedInUS" label="Have you ever been employed?"></immiyesorno>
                                    </div>
                                </div>
                            </vs-col>
                            <template v-if="petition.dependentsInfo.childrens && petition.dependentsInfo.childrens[selectedchild] && petition.dependentsInfo.childrens[selectedchild].anyOtherPersonEmployedInUS && petition.dependentsInfo.childrens[selectedchild].h4EADRequired && canRenderField('prevEmploymentInfo', questionnaireDetails ,false,'dependentsInfo.childrens.prevEmploymentInfo')"  >
                                
                                <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12">
                                    <div class="form-container form-container-questionnaire form-container-employment spouse_immi_employment questionnairesection">
                                        <div class="vx-row">
                                        <immiemployment :notRequired="true" :prefillCountryInQuestionnaire="prefillCountryInQuestionnaire" :petition="petition" :callFromSpouse="true" :countries="countries" :fieldsArray="questionnaireDetails"  cid="dep_prevEmploymentInfo" formscope="childInfoformmodal" v-model="petition.dependentsInfo.childrens[selectedchild].prevEmploymentInfo" :tplsection="'dependentsInfo.childrens.prevEmploymentInfo'"  :fieldName="'prevEmploymentInfo'"  />
                                        </div>
                                    </div>
                                </vs-col> 
                            </template>
                            <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12" >
                                <div class="form-container padt20 child_case_docs_v2">
                                    <casedocumentslist :notRequired="true"  @emitUploadingAction="emitUploadingAction" :docMainCategory="'childdoclist'" :tplsection="'dependentsInfo.childrens.documents'" :docslist="childdoclist" formscope="childInfoformmodal" :fieldsArray="questionnaireDetails" v-model="petition.dependentsInfo.childrens[selectedchild].documents"></casedocumentslist>
                            </div>
                            </vs-col>
                        </form>
                    </VuePerfectScrollbar>
                </div>
                <!-- :disabled="submiTing"  -->
                <div class="popup-footer relative">  
                    <vs-button color="dark" :disabled="documentUploading" @click="toggleChildForm(false)" class="cancel" type="filled">Cancel</vs-button>
                    <vs-button color="success" :disabled="documentUploading" @click="submitChild()" class="save" type="filled">Save
                    </vs-button>
                </div>
                <div></div>
            </div>
        </div>
    
        <vs-popup class="holamundo main-popup cls-btn" title="Case Details" :active.sync="showPrefillPopup">
            <div class="form-container">
                <div class="vx-row">
                    <div class="vx-col w-full">
                        <p style="line-height: 20px">
                            Do you want to pre-fill the basic information from the previous
                            case details?
                        </p>
                    </div>
                </div>
            </div>
            <div class="popup-footer">
                <vs-button color="dark" class="cancel" type="filled" @click="setBasicData();removeFields();showPrefillPopup = false">Cancel</vs-button>
                <vs-button color="success" class="save" type="filled" @click="
                prefilltheDetails();prefillAction = true;
                showPrefillPopup = false;
              ">Yes</vs-button>
            </div>
        </vs-popup>
    
    </div>
    </template>
    
    <script>
     import { InfoIcon } from "vue-feather-icons";
    import { EyeIcon } from "vue-feather-icons";
     import genderField from '@/views/forms/fields/gender.vue'
    import immiInput from "@/views/forms/fields/simpleinput.vue";
    
    import {
        Trash2Icon
    } from "vue-feather-icons";
    
    import addressField from "@/views/forms/fields/address.vue";
    import datepickerField from "@/views/forms/fields/datepicker.vue";
    import selectField from "@/views/forms/fields/simpleselect.vue";
    import monthAndYear from "@/views/forms/fields/monthAndYear.vue";
    import immiPhone from "@/views/forms/fields/phonenumber.vue";
    import immiMask from "@/views/forms/fields/maskinput.vue";
    import immiyesorno from "@/views/forms/fields/yesorno.vue";
    import immiuploader from "@/views/forms/fields/fileupload.vue";
    import immipriorstay from "@/views/forms/fields/priorstay.vue";
    import immitextarea from "@/views/forms/fields/simpletextarea.vue";
    import immieducations from "@/views/forms/fields/educations.vue";
    import immiswitchyesno from "@/views/forms/fields/switchyesno.vue";
    import Datepicker from "vuejs-datepicker-inv";
    import casedocumentslist from "@/views/common/casedocuments.vue";
    import immiemployment from "@/views/forms/fields/employment.vue";
    import moment from "moment";
    import petitionsinformation from "@/views/forms/fields/petitionsinformation.vue";
    import petitionImmigranInfo from "@/views/forms/fields/petitionImmigranInfo.vue";
    import personalinfo from "@/views/beneficiaryProfile/benSpouseProfile.vue";
    import childpersonalinfo from "@/views/beneficiaryProfile/benChildProfile.vue";
    import { XIcon } from 'vue-feather-icons'
    import JQuery from 'jquery';
    import FileUpload from "vue-upload-component/src";
    import _ from "lodash";
    import PetitionDetails from "@/views/PetitionDetails.vue";
    import VuePerfectScrollbar from "vue-perfect-scrollbar";
    
    import immitextfield from "@/views/forms/fields/simpleTextField.vue";
    
    //485 Components
    import Vue from 'vue';
    Vue.use( CKEditor );
    import CKEditor from '@ckeditor/ckeditor5-vue2';
    import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
    import previousSpouseForm from "@/views/petition/gc/previousSpouseForm.vue";
    import immigrationForm from "@/views/petition/gc/immigrationForm.vue";
    import financialForm from "@/views/petition/gc/financialForm.vue";
    import assestsForm from "@/views/petition/gc/assestsForm.vue";
    import liabilitiesForm  from "@/views/petition/gc/liabilitiesForm.vue";
    import publicBenefitsForm  from "@/views/petition/gc/publicBenefitsForm.vue";
    
    import parentForm from "@/views/petition/gc/parentForm.vue";
    
    
    export default {
        props: {
    
        },
        provide() {
            return {
                parentValidator: this.$validator,
            };
        },
        data() {
            return {
                documentUploading:false,
                disablefield:false, 
                editor: ClassicEditor,
                editorConfig: {
                    toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
                },
                consularProcessingValidator:'',
                eye_colorList:[],
                feetList:[1,2,3,4,5,6,7,8,9,10,11,12],
                inchesList:[0,1,2,3,4,5,6,7,8,9,10,11],
                hair_colorsList:[],
                races_list:[],
                uploading:false,
                value:[],
                payFrequencyList:[ "Hour","Week","Month","Year" ],
                settings: { 
                    swipeEasing: true,
                },
                commentPopUp:false,
                petition: {
                    tenantId: null,
                    petitionerId: null,
                    companyId: null,
                    branchId: null,
                    workflowId: null,
                    customId: '',
                    caseNo: '',
                    caseNoOld: '',
                    caseNoRef: '',
                    caseNoSNo: 0,
                    allowCustomCaseNo: false,
                    caseNumber: null,
                    type: null,
                    subType: null,
                    masterSocList:[], 
                   // We need to ask above job details in case we don't have the beneficiary PERM info in our system
                    jobDetails: {
                        socCode:'',
                        socDetails:null,
                        
    
                        jobTitle: '',
    
                        workAddresses: [
                        {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            }
                        ],
    
                        fullTimePosition: false,
    
                        hoursPerWeek: '',
    
                        wageRate: '',
    
                        payFrequency: 'Month', // Year, Month, Bi-Weekly, Week, Hour
    
                        description: '',
    
                        permanentPosition: false,
    
                        newPosition: false
    
                    },
                    beneficiaryInfo: {
                        hasMasterDegreeInUS:null,
                        isDSExpiryDate:false,
                        isI94DSExpiryDate:false,
                        anyOtherPersonEmployedInUS:null,
                        haveYouEverEmployed:null,
                        hasAnyDependetsinUStoFileH4 : null,
                        maritalStatusDetails:null,
                        haveYouEverTravelledToUS:null,
                        currentlyInUS: null,
                        beneficiaryCnfmNumber:null,
                        capType:'',
                        serviceCenterName:'',

                        alienNumber: '',
                        lastArrivalNumber: null,
                        placeOfLastEntryInUS: '',
                        educations: [{
                            _id: 0,
                            name: null,
                            graduatedDate:null,
                            address: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                            highestDegree: null,
                            highestDegreeDetails: null,
                            majorFieldOfStudy: null,
                            attendedFrom: null,
                            attendedTo: null,
                            graduatedYear: null,
                            degreereceived: null,
                            isAccredited: null,
                            isForProfit: null
                        }],
                        h1bImmPetitionsInfo: [{
                            _id: 0,
                            typeId: null,
                            typeDetails: null,
                            receiptNo: '',
                            petitionerName: '',
                            validFrom:null,
                            validTo:null
                        }],
                        didThisPtnrFliedImmPetitionEarlier:null,
                        secOrSubSequentExtnWithPtnr:false,
                        firstExtnWithPtnr:false,
                        anyImmPetitionFiled: null,
                        immPetitionInfo: {
                            anyOtherAlienFiled: null,
                            filedNumber: null,
                            employerName: '',
                            rirOrRegularProcessing: null,
                            filedStateId: null,
                            filedStateDetails: null,
                            applCurStatus: '',
                            seekingFilednullforETA750: null,
                            anyI140Filed: null,
                            i140Info: {
                                fieldNumber: null,
                                employerName: '',
                                priorityNumber: null,
                                eb2orEb3: '',
                                currentStatus: ''
                            }
                        },
                        prevEmploymentInfo: [{
                            _id: 0,
                            employerName: '',
                            address: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                            businessType: null,
                            jobTitle: null,
                            jobDuties: null,
                            startDate: null,
                            endDate: null,
                            currentEmployer: null,
                            salary:null,
                            payFrequency:null,
                        }],
                        prevEmploymentOutsideUS:[{
                            _id: 0,
                            employerName: '',
                            address: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                            businessType: null,
                            jobTitle: null,
                            jobDuties: null,
                            startDate: null,
                            endDate: null,
                            currentEmployer: false  
                        }],
                        addressOutsideUS: {
                            line1: null,
                            line2: null,
                            aptType: null,
                            locationId: null,
                            locationDetails: null,
                            stateId: null,
                            stateDetails: null,
                            countryId: null,
                            countryDetails: null,
                            zipcode: null
                        },
    
                        name: '',
                        firstName: '',
                        middleName: '',
                        lastName: '',
                        hasOtherNames: null,
                        otherNames: [{
                            _id: 0, 
                            name: '',
                            firstName: '',
                            middleName: '',
                            lastName: '',
                        }],
                        gender: '',
                        email: '',
                        education: {
                            highestDegree: null,
                            highestDegreeDetails: null,
                            majorFieldOfStudy: ''
                        },
                        maritalStatus: null,
                        // GC 485 fields start
                        noOfChildrens: '',
                        dateOfMarriage: '',
                        countryOfMarriage: '',
                        countryOfMarriageDetails: null,
                        provinceOfMarriage: '',
                        provinceOfMarriageDetails: null,
                        locationOfMarriage: '',
                        doYouHaveMarriageCert: false ,
                        marriageCertDocs: [],
                        have2AffidavitsAttestingToMarriage: false,
                        nameDiffFromBirthCert:null,
                        have2AffidavitsOfBirthFamily:null,
                        birthCertHaveNamePobDob:false,
                        previouslyMarried:false,
                        previousSpouse:{
                            hasOtherNames:false,
                            otherNames: [{
                                _id: 0,
                                name: '',
                                firstName: '',
                                middleName: '',
                                lastName: '',
                            }],
                            maidenName:'',
                            marriageEndedDueTo:null,
                            marriageEndedOtherInfo:'',
                            firstName: '',
                            middleName: '',
                            lastName: '',
                            dateOfBirth: null,
                            dateOfMarriage:null,
                            dateOfMarriageEnd:null,
                              //Place of Marriage
                            countryOfMarriage: '',
                            countryOfMarriageDetails: null,
                            provinceOfMarriage: '',
                            provinceOfMarriageDetails: null,
                            locationOfMarriage: '',
    
                            //Place of Termination
                            countryOfMarriageTermination: '',
                            countryOfMarriageTerminationDetails: null,
                            provinceOfMarriageTermination: '',
                            provinceOfMarriageTerminationDetails: null,
                            locationOfMarriageTermination: '',
                            obtainPermResidenceThroughSpouse:false  
                          
                        },
                        publicBenefits:[],
                        // GC 485 fields close
                        dateOfBirth: null,
                        countryOfBirth: null,
                        countryOfBirthDetails: null,
                        provinceOfBirth: null,
                        provinceOfBirthDetails: null,
                        locationOfBirth: null,
                        countryOfCitizenship: null,
                        countryOfCitizenshipDetails: null,
                        I94: null,
                        I94ExpiryDate: null,
                        I94StatusName:'',
                        //GC 485 fields start
                        height: {
                        feet: '',
                        inches: ''
                        },
                        weight: null,
                        race: null,
                        eyeColor: null,
                        hairColor: null,
                        firstArrivalDate: null,
                        lastArrivalDate: null,
                        reasonOfLastArrival: '',
                        stateOfLastEntryInUS: '',
                        stateDetailsOfLastEntryInUS: null,
                        placeOfLastEntryInUS: '',
                        caseIssuedDate: null,
                        caseExpiryDate: null,
                        placeOfCaseIssued: '',
                        // GC 485 fields end
                        homePhoneNumber: null,
                        homePhoneCountryCode: {
                            countryCode: '',
                            countryCallingCode: ''
                        },
                        workPhoneNumber: null,
                        workPhoneCountryCode: {
                            countryCode: '',
                            countryCallingCode: ''
                        },
                        fax: null,
                        faxCountryCode: {
                            countryCode: '',
                            countryCallingCode: ''
                        },
                        cellPhoneNumber: null,
                        cellPhoneCountryCode: {
                            countryCode: '',
                            countryCallingCode: ''
                        },
                        // GC 485 fields start
                        allIssuedpassportData: [{
                            countryId: '',
                            countryDetails: null,
                            number: '',
                            issuedDate: null,
                            expiryDate: null 
                        }],
                        curVisaExpiryDate:null,
                        dateFromWhichResideInUs:null,
                        inspectedByAnyImmOfficer:false,
                        issuedAnyEADFromUSCIS:false,
                        curNonImmigrantVisaNumber:null,
                        hasPermResidencyInOtherCountry:false,
                        permResidencyCountryId:'',
                        haveYouArrestedBefore:null,
                        everAppliedAOSInUS:null,
                        permResidencyCountryDetails:null,
                        addressOfLastNYears:[{
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null,
                                startDate: null,
                                endDate: null,
                        }], 
                        addressOutsideUSMoreThanYear:[{
                        
                            line1: null,
                            line2: null,
                            aptType: null,
                            locationId: null,
                            locationDetails: null,
                            stateId: null,
                            stateDetails: null,
                            countryId: null,
                            countryDetails: null,
                            zipcode: null,
                            startDate: null,
                            endDate: null,
                        }],
                        associations:[ {
                            name:'', 
                            address:{
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                            },
                            startDate: null,
                            endDate:null,
                            natureofAssociations:'',
                        }],
                        // GC 485 fields end
                        //GC 485 fields start
                        assets: [{ 
                            typeId: '', 
                            typeDetails: null, 
                            nameOfHolder: '', 
                            amount: '' 
                        }],
                        financials: { 
                            deppositsInUSBanks: '', 
                            valueOfRealEstate:'', 
                            caseSurrenderOfLifeInsurance: '', 
                            reasonalValOfPersonalProp: '', 
                            marketValOfStoks: '', 
                            sumOfLifeInsurence: '', 
                            healthInsurancePremium: '', 
                            HealthInsuranceRenewalDate: null, 
                            creditScore: '', 
                            amtOfMortgageOnProperty: '', 
                        }, 
                        liabilitiesDebts: [{ 
                            typeId: '',                    
                            typeDetails: null, 
                            amount: '' 
                        }], 
                        //GC 485 fields ends
                        iAmFromUS: null,
                        mailingAddressIsSameAsAddress:false,
                          mailingAddress: {
                              line1: null,
                              line2: null,
                              aptType: null,
                              locationId: null,
                              locationDetails: null,
                              stateId: null,
                              stateDetails: null,
                              countryId: null,
                              countryDetails: null,
                              zipcode: null
                          },
                          currentAddress:{
                            line1: null,
                            line2: null,
                            aptType: null,
                            locationId: null,
                            locationDetails: null,
                            stateId: null,
                            stateDetails: null,
                            countryId: null,
                            countryDetails: null,
                            zipcode: null
                        },
                        address: {
                            line1: null,
                            line2: null,
                            aptType: null,
                            locationId: null,
                            locationDetails: null,
                            stateId: null,
                            stateDetails: null,
                            countryId: null,
                            countryDetails: null,
                            zipcode: null
                        },
                        SSN: '',
                        hasI140ImmPetitionFiled: null,
                        I140ImmPetitionFiledDetails: null,
                        passportNumber: null,
                        passportIssuedNumber: null,
                        passportExpiryNumber: null,
                        curNonImmigrantVisaStatus: null,
                        curNonImmigrantVisaStatusDetails: null,
                        curVisaExpiryNumber: null,
                        sevisNumber: null,
                        firstEntryDateOrApprovalInUsWithH1B:null,
                        dateFifthYearOfHExpire:null,
                        eadNumber: null,

                        priorPeriodOfStayInUS: [{
                            _id: 0,
                            enteredNumber: null,
                            departedNumber: null,
                            visaStatus: null,
                            visaStatusDetails: null,
                            noOfDays: null,
                            dateerror: false
                        }],
                        noOfDaysStayInUS: null,
                        confirmDaysStayInUS: false,
                        hasApprovedI140: null,
                        hasPermPendingForMorethan365Days: null,
    
                         //i140
                         passportIssuedCountry:null,
                         passportIssuedCountryDetails:null,
                        applyI485AdjOrConsuProcess: true, // Would you like to apply for adjustment of status (I-485) or consular processing? { type: Boolean, default: false },
                        adjustmentOfI485Status: false, //Adjustment of Status (I-485) //{ type: Boolean, default: false },
                        consularProcessing:false,// Consular Processing { type: Boolean, default: false },
                        areYouUnderRemoveOfIndOrUscis: null, // Are you currently under removal proceedings by the INS/USCIS? { type: Boolean, default: false },
    
                    },
                    //GC 485 fields starts
                    fatherInfo: { 
                                name: '', 
                                firstName: '', 
                                middleName: '', 
                                lastName: '', 
                                hasOtherNames: false, 
                                otherNames: [{ 
                                    _id: 0, 
                                    name: '', 
                                    firstName: '', 
                                    middleName: '', 
                                    lastName: '', 
                                }], 
                                dateOfBirth: null, 
                                countryOfBirth: '', 
                                countryOfBirthDetails: null, 
                                provinceOfBirth: '', 
                                provinceOfBirthDetails: null, 
                                locationOfBirth: '', 
                                currentAddress: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                                isUSCitizen: false, 
                                dateFromUSCitizen: null, //["", ""],
                                nameAtBirth:{
                                    firstName: '', 
                                    middleName: '', 
                                    lastName: '',
                                },
                                deceasedCity: '',
                                deceasedCityDetails:null,
                                deceasedDate: null,
                    },
                    motherInfo: { 
                        name: '',                    
                        firstName: '', 
                        middleName: '', 
                        lastName: '', 
                        hasOtherNames: false , 
                        otherNames: [{ 
                            _id: 0, 
                            name: '', 
                            firstName: '', 
                            middleName: '', 
                            lastName: '', 
                        }], 
                        dateOfBirth: null, 
                        countryOfBirth: '', 
                        countryOfBirthDetails: null, 
                        provinceOfBirth: '', 
                        provinceOfBirthDetails: null, 
                        locationOfBirth: '', 
                        currentAddress: {
                        line1: null,
                        line2: null,
                        aptType: null,
                        locationId: null,
                        locationDetails: null,
                        stateId: null,
                        stateDetails: null,
                        countryId: null,
                        countryDetails: null,
                        zipcode: null
                        },
                        isUSCitizen: false, 
                        dateFromUSCitizen:null,// ["", ""],
                        nameAtBirth:{
                            firstName: '', 
                            middleName: '', 
                            lastName: '',
                        },
                        deceasedCity: '',
                        deceasedCityDetails:null,
                        deceasedDate: null,
                    },  
                     //GC 485 fields ends
                    dependentsInfo: {
                        spouse: {
                            adjustmentStatusToPermResidenceI485:null,
                            sevisNumber: null,
                            eadNumber: null,
                            haveYouEverTravelledToUS:null,
                            isDSExpiryDate:false,
                            isI94DSExpiryDate:false,
                            relationship: '',
                            saved: false,
                            currentlyInUS: null,
                            hasOtherNames: null, 
                            otherNames: [{
                                _id: 0,
                                name: '',
                                firstName: '',
                                middleName: '',
                                lastName: '',
                            }],
                            passportIssuedNumber: null,
                            alienNumber: '',
                            anyOtherPersonEmployedInUS:null,
                            prevEmploymentInfo: [{
                                _id: 0,
                                employerName: '',
                                address: {
                                    line1: null,
                                    line2: null,
                                    aptType: null,
                                    locationId: null,
                                    locationDetails: null,
                                    stateId: null,
                                    stateDetails: null,
                                    countryId: null,
                                    countryDetails: null,
                                    zipcode: null
                                },
                                businessType: null,
                                jobTitle: null,
                                jobDuties: null,
                                startDate: null,
                                endDate: null,
                                payFrequency:null,
                                salary: null,
                                currentEmployer: null
                            }],
                            addressOutsideUS: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                            priorPeriodOfStayInUS: [{
                                _id: 0,
                                enteredNumber: null,
                                departedNumber: null,
                                dateerror: false,
                                noOfDays: null,
                                visaStatus: null
                            }],
                            dateFromWhichResideInUs:null,
                            caseIssuedDate: null,
                            caseExpiryDate: null,
                            placeOfCaseIssued: '',
                            mailingAddressIsSameAsAddress:false,
                            stateOfLastEntryInUS: '',
                            stateDetailsOfLastEntryInUS: null,
                            placeOfLastEntryInUS: '',
                            firstArrivalDate: null,
                            lastArrivalDate: null,
                            allIssuedpassportData: [{
                                countryId: '',
                                countryDetails: null,
                                number: '',
                                issuedDate: null,
                                expiryDate: null 
                            }],
                            currentAddress: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                            height: {
                            feet: '',
                            inches: ''
                            },
                            weight: null,
                            race: null,
                            eyeColor:null,
                            hairColor: null,
                            educations: [{
                            _id: 0,
                            name: null,
                            address: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                            highestDegree: null,
                            highestDegreeDetails: null,
                            majorFieldOfStudy: null,
                            attendedFrom: null,
                            attendedTo: null,
                            graduatedYear: null,
                            degreereceived: null,
                            isAccredited: null,
                            isForProfit: null
                            }],
                            prevEmploymentInfo: [{
                            _id: 0,
                            employerName: '',
                            address: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                            businessType: null,
                            jobTitle: null,
                            jobDuties: null,
                            startDate: null,
                            endDate: null,
                            currentEmployer: null
                            }],
                            prevEmploymentOutsideUS:[{
                                _id: 0,
                                employerName: '',
                                address: {
                                    line1: null,
                                    line2: null,
                                    aptType: null,
                                    locationId: null,
                                    locationDetails: null,
                                    stateId: null,
                                    stateDetails: null,
                                    countryId: null,
                                    countryDetails: null,
                                    zipcode: null
                                },
                                businessType: null,
                                jobTitle: null,
                                jobDuties: null,
                                startDate: null,
                                endDate: null,
                                currentEmployer: false  
                            }],
                            previousSpouse:{
                            hasOtherNames:null,
                            otherNames: [{
                                _id: 0,
                                name: '',
                                firstName: '',
                                middleName: '',
                                lastName: '',
                            }],
                            maidenName:'',
                            marriageEndedDueTo:null,
                            marriageEndedOtherInfo:'',
                            firstName: '',
                            middleName: '',
                            lastName: '',
                            dateOfBirth: null,
                            dateOfMarriage:null,
                            dateOfMarriageEnd:null,
    
                              //Place of Marriage
                            countryOfMarriage: '',
                            countryOfMarriageDetails: null,
                            provinceOfMarriage: '',
                            provinceOfMarriageDetails: null,
                            locationOfMarriage: '',
    
                            //Place of Termination
                            countryOfMarriageTermination: '',
                            countryOfMarriageTerminationDetails: null,
                            provinceOfMarriageTermination: '',
                            provinceOfMarriageTerminationDetails: null,
                            locationOfMarriageTermination: '',
                            obtainPermResidenceThroughSpouse:null  
                          
                            },
                            addressOfLastNYears:[{
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null,
                                startDate: null,
                                endDate: null,
                            }], 
                            addressOutsideUSMoreThanYear:[{
                            
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null,
                                startDate: null,
                                endDate: null,
                            }],
                            dateOfLastEntryInUS:null,
                            dateOfMarriage: null, 
                            dateOfMarriageEnd: null, 
                            countryOfMarriage: '', 
                            countryOfMarriageDetails: null, 
                            provinceOfMarriage: '', 
                            provinceOfMarriageDetails: null, 
                            locationOfMarriage: '',
                            currentSpouseName: '',
                            maritalStatus : null, 
                            maritalStatusDetails: null,
                            curNonImmigrantVisaStatus: '', 
                            associations:[ {
                                name:'', 
                                address:{
                                    locationId: null,
                                    locationDetails: null,
                                    stateId: null,
                                    stateDetails: null,
                                    countryId: null,
                                    countryDetails: null,
                                },
                                startDate: null,
                                endDate:null,
                                natureofAssociations:'',
                            }],
                            everAppliedAOSInUS: null, 
                            appliedAOSInUSDocs:[],
                            haveYouArrestedBefore:null,
                            haveYouArrestedBeforeDocs:[], 
                            doesBirthRegistered:null, 
                            curNonImmigrantVisaNumber:'',
                            inspectedByAnyImmOfficer: null, 
                            issuedAnyEADFromUSCIS: null, 
                            hasPermResidencyInOtherCountry: null, 
                            permResidencyCountryId: '', 
                            passportIssuedDate: null,
                            permResidencyCountryDetails: null,
                            

                            h4Required: null,
                            h4EADRequired: null,
                            name: '',
                            firstName: '',
                            middleName: '',
                            lastName: '',
                            email: '',
                            phoneNumber: '',
                            phoneCountryCode: {
                                countryCode: '',
                                countryCallingCode: ''
                            },
                            dateOfBirth: null,
                            countryOfBirth: null,
                            countryOfBirthDetails: null,
                            provinceOfBirth: null,
                            provinceOfBirthDetails: null,
                            locationOfBirth: '',
                            locationOfBirthDetails: null,
                            countryOfCitizenship: null,
                            countryOfCitizenshipDetails: null,
                            passportNumber: '',
                            passportExpiryNumber: null,
                            passportIssuedCountry:null,
                            passportIssuedCountryDetails:null,
                            I94: '',
                            I94ExpiryNumber: null,
                            currentStatus: null,
                            currentStatusDetails: null,
                            statusExpiryNumber: null,
                            SSN: '',
                            lastArrivalNumber: null,
                            placeOfLastEntryInUS: '',
                            applyingWithYou:null,
                            nameDiffFromBirthCert:null,
                            physicalAddress: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                            fatherInfo: { 
                                name: '', 
                                firstName: '', 
                                middleName: '', 
                                lastName: '', 
                                hasOtherNames: null, 
                                otherNames: [{ 
                                    _id: 0, 
                                    name: '', 
                                    firstName: '', 
                                    middleName: '', 
                                    lastName: '', 
                                }], 
                                dateOfBirth: null, 
                                countryOfBirth: '', 
                                countryOfBirthDetails: null, 
                                provinceOfBirth: '', 
                                provinceOfBirthDetails: null, 
                                locationOfBirth: '', 
                                currentAddress: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                                isUSCitizen: null, 
                                dateFromUSCitizen: null, //["", ""],
                                nameAtBirth:{
                                    firstName: '', 
                                    middleName: '', 
                                    lastName: '',
                                },
                                deceasedCity: '',
                                deceasedCityDetails:null,
                                deceasedDate: null,
                            },
                            motherInfo: { 
                                name: '',                    
                                firstName: '', 
                                middleName: '', 
                                lastName: '', 
                                hasOtherNames: null , 
                                otherNames: [{ 
                                    _id: 0, 
                                    name: '', 
                                    firstName: '', 
                                    middleName: '', 
                                    lastName: '', 
                                }], 
                                dateOfBirth: null, 
                                countryOfBirth: '', 
                                countryOfBirthDetails: null, 
                                provinceOfBirth: '', 
                                provinceOfBirthDetails: null, 
                                locationOfBirth: '', 
                                currentAddress: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                                },
                                isUSCitizen: null, 
                                dateFromUSCitizen:null,// ["", ""],
                                nameAtBirth:{
                                    firstName: '', 
                                    middleName: '', 
                                    lastName: '',
                                },
                                deceasedCity: '',
                                deceasedCityDetails:null,
                                deceasedDate: null,
                            }, 
                            documents: {
                                eadCard:[],
                                passport: [],
                                visa: [],
                                formI94: [],
                                formI797: [],
                                formI20: [],
                                payStubs: [],
                                marriageCertificate: [],
                                noticeOfApprovalOfH1Status: [],
                                approvalNoticeOfPrevH4: [],
                                other: [],
                                //
                                // slgApprovalNoticeOfPrevH4: [],
                                approvedI140: [],
                                h1Bapprovals: [],
                                 usVisa: [],
                                  mostRecentI94: [],  
                                  travelHistory: [],  
                                  mostRecentPayStubs: [],
                              
                            },
                            //i140
                            adjustmentOfI485Status: false, //Adjustment of Status (I-485) //{ type: Boolean, default: false },
                            consularProcessing:false,// Consular Processing { type: Boolean, default: false },
                        
    
                        },
                        childrens: [{
                            sevisNumber: null,
                            eadNumber: null,
                            haveYouEverTravelledToUS:null,
                            isDSExpiryDate:false,
                            isI94DSExpiryDate:false,
                            email: '',
                            phoneNumber: '',
                            phoneCountryCode: {
                            countryCode: '',
                            countryCallingCode: ''
                            },
                            saved: false,
                            relationship: '',
                            currentlyInUS: null,
                            hasOtherNames: null,
                            otherNames: [{
                                _id: 0,
                                name: '',
                                firstName: '',
                                middleName: '',
                                lastName: '',
                            }],
                            alienNumber: '',
                            lastArrivalNumber: null,
                            placeOfLastEntryInUS: '',
                            physicalAddress: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: {
                                    id: null,
                                    name: null,
                                    stateId: null,
                                    countryId: null
                                },
                                stateId: null,
                                stateDetails: {
                                    id: null,
                                    name: null,
                                    countryId: null
                                },
                                countryId: null,
                                countryDetails: {
                                    id: null,
                                    name: null,
                                    shortName: null,
                                    phoneCode: null,
                                    countryId: null,
                                    currencySymbol: null,
                                    currencyCode: null,
                                    zipcodeLength: null
                                },
                                zipcode: null
                            },
                            addressOutsideUS: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: {
                                    id: null,
                                    name: null,
                                    stateId: null,
                                    countryId: null
                                },
                                stateId: null,
                                stateDetails: {
                                    id: null,
                                    name: null,
                                    countryId: null
                                },
                                countryId: null,
                                countryDetails: {
                                    id: null,
                                    name: null,
                                    shortName: null,
                                    phoneCode: null,
                                    countryId: null,
                                    currencySymbol: null,
                                    currencyCode: null,
                                    zipcodeLength: null
                                },
                                zipcode: null
                            },
                            passportIssuedNumber: null,
                            priorPeriodOfStayInUS: [{
                                _id: 0,
                                enteredNumber: null,
                                dateerror: false,
                                noOfDays: null,
                                departedNumber: null,
                                visaStatus: null
                            }],
                            prevEmploymentInfo: [{
                                _id: 0,
                                employerName: '',
                                address: {
                                    line1: null,
                                    line2: null,
                                    aptType: null,
                                    locationId: null,
                                    locationDetails: null,
                                    stateId: null,
                                    stateDetails: null,
                                    countryId: null,
                                    countryDetails: null,
                                    zipcode: null
                                },
                                businessType: null,
                                jobTitle: null,
                                jobDuties: null,
                                startDate: null,
                                endDate: null,
                                salary: null,
                                payFrequency:null,
                                currentEmployer: null,
                            }],
                            anyOtherPersonEmployedInUS:null,
                            haveYouEverEmployed:null,
                            lastArrivalDate:null,
                            stateOfLastEntryInUS: '',
                            stateDetailsOfLastEntryInUS: null,
                            placeOfLastEntryInUS: '',
                            h4Required: null,
                            name: '',
                            firstName: '',
                            middleName: '',
                            lastName: '',
                            dateOfBirth: null,
                            countryOfBirth: null,
                            countryOfBirthDetails: null,
                            provinceOfBirth: null,
                            provinceOfBirthDetails: null,
                            locationOfBirth: '',
                            locationOfBirthDetails: null,
                            countryOfCitizenship: null,
                            countryOfCitizenshipDetails: null,
                            passportIssuedCountry:null,
                            passportIssuedCountryDetails:null,
                            passportNumber: '',
                            passportExpiryNumber: null,
                            I94: '',
                            I94ExpiryNumber: null,
                            currentStatus: null,
                            statusExpiryNumber: null,
                            documents: {
                                passport: [],
                                visa: [],
                                formI94: [],
                                birthCertificate: [],
                                approvalNotice: [],
                                approvalNoticeOfPrevH4: [],
                                other: []
                            },
    
                             //i140
                             adjustmentOfI485Status: null, //Adjustment of Status (I-485) //{ type: Boolean, default: false },
                            consularProcessing:null,// Consular Processing { type: Boolean, default: false },
                        
                        }]
                    },
                    documents: {
                      //
                      usVisa: [],
                      mostRecentI94:[],
                      ssnCard:[],
                      priorH4Approvals:[],
                      proofOfCurrentStatus:[],
            copyOfExistingVisa:[],
            approvalCopyOfi140:[],

                        //
                        birthCertificate:[],
                        eadCard:[],
                        marriageCertificate:[],
                        underlyingLaborApplications:[],
                        mostRecentTaxTranscrips:[],
                        empAuth:[],
                        permResidence:[],
                        recentCreditReport:[],
                        proofOfMedicalInsurence:[],
                        proofOfIncomeOrAsset:[],
                        evidenceOfFilePetitionBefore30Apr2001:[],
                        evidenceOfContinuVisaStatus:[],
                        bankStatements:[],
                        dependentTaxReturns:[],
                        dependentForI134:[],
                        medicalExamins:[],
                        photographs:[],
                        w2: [],

                        // added fields
                        resume: [],
                        education: [],
                        expLetters: [],
                        INSNotices: [],
                        I140ApprovalNotice: [],
                        passport: [],
                        passportVisaI94: [],
                        formI20: [],
                        socialSecurityCardAndProfLicense: [],
                        other: [],
                        payStubs: [],
                        offerLetter: [],
                        clientLetter: [],
                        vendorLetter: [],
                        msa: [],
                        po: [],
                        beneficiaryDocs: [],
                        h1bRegSelectionNotice: [],
                        employmentAgreement: [],
                        primeVendor: [],
                        formI94: [],
                        priorFormI797: [],
                        I797NoticeofApprovalforI140: [],
                        ead: [],
                        slgResume: [],
                        slgCollegeDegreesCert: [],
                        slgTransScripts: [],
                        slgExpLetters: [],
                        slgPassportAndVisa: [],
                        slgI94: [],
                        slgPrevNonimmApprovalNotices: [],
                        slgI140OrPermNoties: [],
                        slgPrevLaborApplications: [],
                        slgAckOfPrevLaborApplications: [],
                        slgPaystubs: [],
                        slgI20: [],
                        slgEad: [],
                        capSelectNotice:[],
                        bnfSpouseLatestI797:[],
                        bnfSpousePassport:[],
                        bnfSpouseRecentPayStubs:[],
                        bnfSpouseFormAllI20:[],
                        slgEvalOfEduCredentials:[],
                        slgEvalOfEduExpCredentials:[],
    
                        // case i140
                        // w2:[],
                        // slgEvalOfEduCredentials:[],
                        // slgPrevImmApprovalNotices:[],
                    },
                    lcaRequested: false,
                    questionnaireFilled: false,
                    questionnaireFilled_temp: false,
                    lcaId: null,
                    statusId: 1,
                    status: 1,
                    questionnaireSent: true,
                    questionnaireInstructions: '',
                    assignOrSubmitRoleComment: '',
                    curWorkflowActivity: 'CREATE_PETITION',
                    nextWorkflowActivity: ['SUBMIT_BY_BENEFICIARY'],
                        //  relationships:[
                        //     {
                        //     "id":"Son",
                        //  "name":"Son"
                        //  },{
                        //     "id":"Daughter",
                        //  "name":"Daughter"
                        //  }
                        //  ]
                         relationships:['Son','Daughter']
    
                },

                marriageCertDocsList:[{
                    required: false,
                        key: 'docs_marriageCertDocs',
                        fieldName: 'marriageCertDocs',
                        label: 'Marriage Certificates'
                }],
                eadCardList:[{
                        required: false,
                        key: 'docs_eadCard',
                        fieldName: 'eadCard',
                        label: 'Please provide a copy of the EAD CARD(S), front and  back'
                }],
                haveYouArrestedBeforeDocsList:[{
                    required: false,
                        key: 'docs_haveYouArrestedBeforeDocs',
                        fieldName: 'haveYouArrestedBeforeDocs',
                        label: 'Please provide documents, if any'
                }],  
                appliedAOSInUSDocsList:[{
                        required: false,
                        key: 'docs_appliedAOSInUSDocs',
                        fieldName: 'appliedAOSInUSDocs',
                        label: 'Documents'
                }], 
                currentTab: 'casedetails',
                countries: [],
                countriesWithoutUS:[],
                bfeprovinceStates: [],
                statesOfMarriage:[],
                usastates: [],
                visastatuses: [],
                marital_statuses: [],
                education_types: [],
                questionnaireDetails: [],
                showPrefillPopup: false,
                latestPetition: null,
                featureDates: null,
                tabslist: [ { "key": "casedetails", "name": "Personal Info" }, 
                { "key": "education", "name": "Educational Info" }, 
                { "key": "employment", "name": "Employment Info" }, 
                { "key": "parent", "name": "Parents Info" }, 
                { "key": "dependentsinfo", "name": "Dependents Info" }, 
                { "key": "documents", "name": "Documents" } ],
                questionnairePreview: false,
                questionnairePreviewData:null,
                SuccessQuestionnaire: false,
                h4RequiredForChild: null,
                spouseModalForm: false,
                childModalForm: false,
                submiTing: false,
                comments: "",
                formerrors: {
                    msg: ""
                },
                executionCompleted:true,
                startEligibleDate: new Date().setFullYear(new Date().getFullYear() - 18),
                childdoclist: [{
                        required: false,
                        key: 'child_docs_passport',
                        fieldName: 'passport',
                        label: 'Passport- First page with photo, Visa page and last page with address'
                    }, {
                        required: false,
                        key: 'child_docs_visa',
                        fieldName: 'visa',
                        label: 'Visa'
                    },
                    {
                        required: false,
                        key: 'child_docs_form_i94',
                        fieldName: 'formI94',
                        label: 'I94'
                    },
                    {
                        required: false,
                        key: 'child_docs_approval_notice',
                        fieldName: 'approvalNotice',
                        label: 'Approval Notice'
                    },
                    {
                        required: false,
                        fieldName: 'slgApprovalNoticeOfPrevH4',
                        "key": "child_docs_slgApprovalNoticeOfPrevH4",
                       "label": "Current and Previous H4 Approval Copies"
                    },
                    {
                        required: false,
                        key: 'child_docs_other',
                        fieldName: 'other',
                        label: 'Others'
                    }
                ],
                selectedchild: 0,
                spousedoclist: [
                    {
                        required: false,
                        key: 'spouse_docs_passport',
                        fieldName: 'passport',
                        label: 'Passport- First page with photo, Visa page and last page with address'
                    },
                    
                    // {
                    //     required: false,
                    //     fieldName: 'eadCard',
                    //     key: "spouse_docs_eadCard",
                    //    label: "Please provide a copy of the EAD CARD(S), front and  back"
                    // },
                    {
                        required: false,
                        fieldName: 'slgApprovalNoticeOfPrevH4',
                        key: "spouse_docs_slgApprovalNoticeOfPrevH4",
                       label: "Current and Previous H4 Approval Copies"
                    },
                    {
                        required: false,
                        key: 'spouse_docs_visa',
                        fieldName: 'visa',
                        label: 'Visa'
                    }, {
                        required: false,
                        key: 'spouse_docs_formi94',
                        fieldName: 'formI94',
                        label: 'I94'
                    }, {
                        required: false,
                        key: 'spouse_docs_form_i797',
                        fieldName: 'formI797',
                        label: 'Form I-797'
                    }, {
                        required: false,
                        key: 'spouse_docs_form_i20',
                        fieldName: 'formI20',
                        label: 'Spouse’s all Form I-20s (if spouse is on F-1 status)'
                    }, {
                        required: false,
                        key: 'spouse_docs_pay_stubs',
                        fieldName: 'payStubs',
                        label: 'Three Recent Pay Stubs'
                    }, {
                        required: false,
                        key: 'spouse_docs_mrg_certificate',
                        fieldName: 'marriageCertificate',
                        label: 'Marriage Certificate (if spouse is on H-1B, L-1, or F-1 status) '
                    }, 
                    {
                        required: false,
                        key: 'other', //'spouse_docs_other',
                        fieldName: 'other',
                        label: 'Others'
                    },
                    
                    //
                    {
                        required: false,
                        key: 'passport',
                        fieldName: 'passport',
                        label: 'Passport'
                    },
                    {
                        required: false,
                        key: 'approvedI140',
                        fieldName: 'approvedI140',
                        label: 'Approved I-140 or Pending Perm for more than 365 days'
                    }, 
                    {
                        required: false,
                        key: 'h1Bapprovals',
                        fieldName: 'h1Bapprovals',
                        label: 'All H-1B approvals, all the way to CAP '
                    },
                  
                    
                    {
                        required: false,
                        key: 'usVisa',
                        fieldName: 'usVisa',
                        label: 'US Visa'
                    },
                    {
                        required: false,
                        key: 'mostRecentI94',
                        fieldName: 'mostRecentI94',
                        label: 'Most recent I-94'
                    },
                    {
                        required: false,
                        key: 'travelHistory',
                        fieldName: 'travelHistory',
                        label: 'Travel History'
                    },
                    {
                        required: false,
                        key: 'mostRecentPayStubs',
                        fieldName: 'mostRecentPayStubs',
                        label: '3 most recent pay stubs '
                    },
                     
    
                ],
                bendocslist: [
                {
          required: false,
          fileUploading:false,
          key:'proofOfCurrentStatus',
          fieldName:"proofOfCurrentStatus",
          label:'Proof Of Current Status'
        },
        {
          required: false,
          fileUploading:false,
          key:'copyOfExistingVisa',
          fieldName:"copyOfExistingVisa",
          label:'Copy Of Existing visa'
        },
        {
          required: false,
          fileUploading:false,
          key:'approvalCopyOfi140',
          label:'Approval Copy Of I-140',
          fieldName:"approvalCopyOfi140",
        },
                {

                    
                    //
            required: false,
            fileUploading:false,
            key: 'priorH4Approvals',
            fieldName: 'priorH4Approvals',
            label: 'All prior H4 approvals, if any'
          },
          {
            required: false,
            fileUploading:false,
            key: 'passport',
            fieldName: 'passport',
            label: 'Passport- First page with photo and last page with address'
          },
          {
            required: false,
            fileUploading:false,
            key: 'usVisa',
            fieldName: 'usVisa',
            label: 'US Visa'
          },
          {
            required: false,
            fileUploading:false,
            key: 'mostRecentI94',
            fieldName: 'mostRecentI94',
            label: 'Most recent I-94'
          },
          {
            required: false,
            fileUploading:false,
            key: 'ssnCard',
            fieldName: 'ssnCard',
            label: 'SSN Card, if any'
          },{
            required: false,
            fileUploading:false,
            key: 'eadCard',
            fieldName: 'eadCard',
            label: 'Prior EAD Cards, if any '
          },
          {
              required: false,
              key: 'other',
              fieldName: 'other',
              label: 'Others'
          },
          {
                required: false,
                key: 'marriageCertificate',
                fieldName: 'marriageCertificate',
                label: 'Marriage Certificate'
            },

          // 
                    {
                        required: false,
                        fileUploading:false,
                        key: 'docs_underlyingLaborApplications',
                        fieldName: 'underlyingLaborApplications',
                        label: 'Copy of the underlying Labor Certification (PERM) if applicable.'
                    },  
                    {
                        required: false,
                        fileUploading:false,
                        key: 'docs_mostRecentTaxTranscrips',
                        fieldName: 'mostRecentTaxTranscrips',
                        label: 'A copy of Most Recent Year’s Tax Transcripts – can be obtained from.'
                    },  
                    {
                        required: false,
                        fileUploading:false,
                        key: 'docs_passport_visa_i94',
                        fieldName: 'passportVisaI94',
                        label: 'Passport- First page with photo, Visa page and last page with address'
                    },
                    {
                        key: 'docs_passport',
                        fileUploading:false,
                        fieldName: 'passport',
                        required: false,
                        label: 'Passport- First page with photo and last page with address'
                    },
                   
                    {
                        key: 'docs_visa',
                        fileUploading:false,
                        fieldName: 'visa',
                        required: false,
                        label: 'Visa'
                    },
                    {
                        key: 'docs_formI94',
                        fileUploading:false,
                        fieldName: 'formI94',
                        required: false,
                        label: 'I94'
                    },
                    {
                        key: 'docs_formI797',
                        fileUploading:false,
                        fieldName: 'formI797',
                        required: false,
                        label: 'Form I-797'
                    },
                    {
                        required: false,
                        key: "slgEvalOfEduCredentials",
                        fileUploading:false,
                        fieldName: 'slgEvalOfEduCredentials',
                        label: "Education Evaluation",
                        display:true,
                    },
                    {
                        required: false,
                        key: "slgEvalOfEduExpCredentials",
                        fileUploading:false,
                        fieldName: 'slgEvalOfEduExpCredentials',
                        label: "Education+Experience Evaluation",
                        display:true,
                    },
                    // {  
                    //     key: 'marriageCertificate',
                    //     fieldName: 'marriageCertificate',
                    //     required: false,
                    //     label: 'Marriage Certificate (if spouse is on H-1B, L-1, or F-1)'
                    // },
                    {
                        key: 'docs_birthCertificate',
                        fileUploading:false,
                        fieldName: 'birthCertificate',
                        required: false,
                        label: 'Birth Certificate'
                    },
                    {
                        key: 'docs_resume',
                        fileUploading:false,
                        fieldName: 'resume',
                        required: false,
                        label: 'Resume'
                    },
                    {
                        key: 'docs_education',
                        fileUploading:false,
                        fieldName: 'education',
                        required: false,
                        label: 'Master’s/ Bachelor’s degree certificate, transcripts, 12th and 10th certificates'
                    },
                    {
                        key: 'docs_expLetters',
                        fileUploading:false,
                        fieldName: 'expLetters',
                        required: false,
                        label: 'Experience Letters'
                    },
                    {
                        key: 'docs_INSNotices',
                        fileUploading:false,
                        fieldName: 'INSNotices',
                        required: false,
                        label: 'I-797, Notice of Approval granting the current nonimmigrant status (if applicable)'
                    },
                    {
                        key: 'docs_formI20',
                        fileUploading:false,
                        fieldName: 'formI20',
                        required: false,
                        label: 'All Form I-20s if applicable'
                    },
                    {
                        required: false,
                        fileUploading:false,
                        fieldName: 'socialSecurityCardAndProfLicense',
                        key: 'docs_socialSecurityCardAndProfLicense',
                        label: 'Social Security Card'
                    },
                    {
                        required: false,
                        fileUploading:false,
                        fieldName: 'I797NoticeofApprovalforI140',
                        key: 'docs_I797NoticeofApprovalforI140',
                        label: 'I-797, Notice of Approval for I-140 if available'
                    },
                    {
                        required: false,
                        fileUploading:false,
                        key: 'docs_paystubs',
                        fieldName: 'payStubs',
                        label: 'Three Recent Pay Stubs'
                    },
                    {
                        required: false,
                        fileUploading:false,
                        key: 'docs_offer_letters',
                        fieldName: 'offerLetter',
                        label: 'Employment Offer Letter'
                    },
                    {
                        required: false,
                        fileUploading:false,
                        key: 'docs_employment_agreement',
                        fieldName: 'employmentAgreement',
                        label: 'Employment Agreement'
                    },
                    {
                        required: false,
                        fileUploading:false,
                        key: 'docs_client_letters',
                        fieldName: 'clientLetter',
                        label: 'Client Letter'
                    },
                    {
                        required: false,
                        fileUploading:false,
                        key: 'docs_vendor_letters',
                        fieldName: 'vendorLetter',
                        label: 'Vendor Letter if applicable'
                    },
                    {
                        required: false,
                        fileUploading:false,
                        key: 'docs_msa',
                        fieldName: 'msa',
                        label: 'MSA/Service Agreement and PO/SOW'
                    },
                    {
                        required: false,
                        fileUploading:false,
                        key: 'docs_po',
                        fieldName: 'po',
                        label: 'PO'
                    },
                    {
                        required: false,
                        fileUploading:false,
                        key: 'docs_approvalNotice',
                        fieldName: 'approvalNotice',
                        label: 'Approval Notice'
                    },
                    {
                        required: false,
                        fileUploading:false,
                        key: 'docs_beneficiaryDocs',
                        fieldName: 'beneficiaryDocs',
                        label: 'Beneficiary Documents'
                    },
                    {
                        required: false,
                        fileUploading:false,
                        key: 'docs_h1bRegSelectionNotice',
                        fieldName: 'h1bRegSelectionNotice',
                        label: 'H-1B Registration Selection Notice'
                    },
                    {
                        required: false,
                        fileUploading:false,
                        key: 'docs_ead',
                        fieldName: 'ead',
                        label: 'EADs (if on OPT or STEM OPT Extension)'
                    },
                    {
                        required: false,
                        fileUploading:false,
                        key: 'docs_prime_vendor',
                        fieldName: 'primeVendor',
                        label: 'Prime Vendor Letter if applicable'
                    },
                    // {
                    //     required: false,
                    //     key: 'docs_formI94',
                    //     fieldName: 'formI94',
                    //     label: 'I-94'
                    // },
                    {
                        required: false,
                        fileUploading:false,
                        key: 'docs_prior_form_i797',
                        fieldName: 'priorFormI797',
                        label: 'All prior I-797, Notice of Approvals granting H-1B status'
                    },
                    {
                        required: false,
                        fileUploading:false,
                        key: 'docs_noticeOfApprovalOfH1Status',
                        fieldName: 'noticeOfApprovalOfH1Status',
                        label: 'Spouse’s all Form I-20s (if spouse is on F-1 status)'
                    },
                    {
                        required: false,
                        fileUploading:false,
                        key: 'docs_other',
                        fieldName: 'other',
                        label: 'Other Documents, if any'
                    },
                    {
                        required: false,
                        fileUploading:false,
                        key: "slgResume",
                        fieldName: 'slgResume',
                        label: "Current Resume- Please mention the accurate names of the employer and periods of employment. Do not state the client names"
                    },
                    {
                        required: false,
                        fileUploading:false,
                        key: "slgCollegeDegreesCert",
                        fieldName: 'slgCollegeDegreesCert',
                        label: "All College Degrees"
                    },
                    {
                        required: false,
                        fileUploading:false,
                        key: "slgTransScripts",
                        fieldName: 'slgTransScripts',
                        label: "Transcripts/Marks memo’s"
                    },
                    {
                        required: false,
                        fileUploading:false,
                        key: "slgExpLetters",
                        fieldName: 'slgExpLetters',
                        label: "Letters of Experience.Each experience letter on company letterhead must document your professional experience and must include the (1) job title (2) duration of employment (beginning date and ending date), (3) full time (i.e., 40 hours) or part time position, and (4) the job duties.  If you had more than one position within the company, please list each position along with the job description"
                    },
                    {
                        required: false,
                        fileUploading:false,
                        key: "slgPassportAndVisa",
                        fieldName: 'slgPassportAndVisa',
                        label: "Copy of New and Old Passport"
                    },
                    {
                        required: false,
                        fileUploading:false,
                        key: "slgI94",
                        fieldName: 'slgI94',
                        label: "I-94"
                    },
                    {
                        required: false,
                        fileUploading:false,
                        fieldName: 'slgPrevNonimmApprovalNotices',
                        key: "slgPrevNonimmApprovalNotices",
                        label: "Copy of all Previous Nonimmigrant Approval Notices (e.g., H-1B, H-4, L-1A, L-1B, L-2 etc.,)"
                    },
                    {
                        required: false,
                        fileUploading:false,
                        key: "slgI140OrPermNoties",
                        fieldName: 'slgI140OrPermNoties',
                        label: "Copy of any I-140 approval notices or PERM filing Notices (if applicable)"
                    },
                    {
                        required: false,
                        fileUploading:false,
                        key: "slgPrevLaborApplications",
                        fieldName: 'slgPrevLaborApplications',
                        label: "Copy of the previously filed Labor Application, if applicable"
                    },
                    {
                        required: false,
                        fileUploading:false,
                        key: "slgAckOfPrevLaborApplications",
                        fieldName: 'slgAckOfPrevLaborApplications',
                        label: "Copy of the Acknowledgement letter for the previously filed Labor application, if applicable"
                    },
                    {
                        required: false,
                        fileUploading:false,
                        key: "slgPaystubs",
                        fieldName: 'slgPaystubs',
                        label: "Copies of Most recent paystubs (last 2 to 3 months)"
                    },
                    {
                        required: false,
                        fileUploading:false,
                        key: "slgI20",
                        fieldName: 'slgI20',
                        label: "Copies of all I-20’s"
                    },
                    {
                        required: false,
                        fileUploading:false,
                        key: "slgEad",
                        fieldName: 'slgEad',
                        label: "Copies of EAD cards"
                    },
                    //Added fields
                    {
                        required: false,
                        fileUploading:false,
                        key: "w2",
                        fieldName: 'w2',
                        label: "Copy of all w2"
                    },
                    {
                        required: false,
                        fileUploading:false,
                        key: "photographs",
                        fieldName: 'photographs',
                        label: "Photographs"
                    },
                    {
                        required: false,
                        fileUploading:false,
                        key: "medicalExamins",
                        fieldName: 'medicalExamins',
                        label: "Medical Examins"
                    },
                    {
                        required: false,
                        fileUploading:false,
                        key: "dependentForI134",
                        fieldName: 'dependentForI134',
                        label: "Dependent For I-134"
                    },
                    {
                        required: false,
                        fileUploading:false,
                        key: "dependentTaxReturns",
                        fieldName: 'dependentTaxReturns',
                        label: "Dependent Tax Returns"
                    },
                    {
                        required: false,
                        fileUploading:false,
                        key: "bankStatements",
                        fieldName: 'bankStatements',
                        label: "Bank Statements"
                    }, 
                    {
                        required: false,
                        fileUploading:false,
                        key: "evidenceOfContinuVisaStatus",
                        fieldName: 'evidenceOfContinuVisaStatus',
                        label: "Evidence of Continue Visa Status"
                    }, 
                    {
                        required: false,
                        fileUploading:false,
                        key: "evidenceOfFilePetitionBefore30Apr2001",
                        fieldName: 'evidenceOfFilePetitionBefore30Apr2001',
                        label: "Evidence of File Petition Before 30-Apr-2001"
                    }, 
                    {
                        required: false,
                        fileUploading:false,
                        key: "proofOfIncomeOrAsset",
                        fieldName: 'proofOfIncomeOrAsset',
                        label: "Proof of Income or Asset"
                    }, 
                    { 
                        required: false,
                        fileUploading:false,
                        key: "proofOfMedicalInsurence",
                        fieldName: 'proofOfMedicalInsurence',
                        label: "Proof of Medical Insurence"
                    }, 
                    {
                        required: false,
                        fileUploading:false,
                        key: "recentCreditReport",
                        fieldName: 'recentCreditReport',
                        label: "Recent Credit Report"
                    }, 
                    {
                        required: false,
                        fileUploading:false,
                        key: "permResidence",
                        fieldName: 'permResidence',
                        label: "Permenant Residence"
                    }, 
                    {
                        required: false,
                        fileUploading:false,
                        key: "empAuth",
                        fieldName: 'empAuth',
                        label: "Employment Auth"
                    },
                    {
                        required: false,
                        fileUploading:false,
                        key: "capSelectNotice",
                        fieldName: 'capSelectNotice',
                        label: "CAP Selection Notice",
                        callExtract:true,
                    },
                    // new Documents 04/04/2023
                    /*
                    {
                        required: false,
                        key: "formI797H4ApprovalNotice",
                        fieldName: 'formI797H4ApprovalNotice',
                        label: "Form I-797 H4 approval notice if applicable."
                    },
                    {
                        required: false,
                        key: "h4Ead",
                        fieldName: 'h4Ead',
                        label: "H4 EAD if applicable"
                    },
                    {
                        required: false,
                        key: "marriageCertificate",
                        fieldName: 'marriageCertificate',
                        label: "Marriage Certificate"
                    },
                    {
                        required: false,
                        key: "formI797H1BApprovalNoticePrinNonCtzn",
                        fieldName: 'formI797H1BApprovalNoticePrinNonCtzn',
                        label: "Form I-797 H-1B approval notice of Principal Non-citizen"
                    },
                    {
                        required: false,
                        key: "passportOfPrinNonCtzn",
                        fieldName: 'passportOfPrinNonCtzn',
                        label: "Passport of Principal Non-citizen- First page with photo, Visa page and last page with address"
                    },
                    {
                        required: false,
                        key: "last3MonthsPayslipsOfPrinNonCtzn",
                        fieldName: 'last3MonthsPayslipsOfPrinNonCtzn',
                        label: "Last 3 months pay statements of Principal Non-citizen"
                    },
                    */
                    {
                        key: 'bnfSpouseLatestI797',
                        fileUploading:false,
                        fieldName: 'bnfSpouseLatestI797',
                        required: false,
                        label: 'Latest I-797, Notice of Approval of the spouse (if spouse is on H-1B or L-1 status)'
                    },
                    {
                        key: 'bnfSpousePassport',
                        fileUploading:false,
                        fieldName: 'bnfSpousePassport',
                        required: false,
                        label: 'Spouse’s Passport- First page with photo, Visa page and last page with address'
                    },
                    {
                        key: 'bnfSpouseRecentPayStubs',
                        fileUploading:false,
                        fieldName: 'bnfSpouseRecentPayStubs',
                        required: false,
                        label: 'Three recent pay stubs (if spouse is on H-1B or L-1 status)'
                    },
                    {
                        key: 'bnfSpouseFormAllI20',
                        fileUploading:false,
                        fieldName: 'bnfSpouseFormAllI20',
                        required: false,
                        label: 'Spouse’s all Form I-20s (if spouse is on F-1 status)'
                    },
                ],
                //ignoreItems:['maritalStatusDetails'],
                prefillAction:false,
                spouse: {
                            sevisNumber: null,
                            eadNumber: null,
                            haveYouEverTravelledToUS:null,
                            isDSExpiryDate:false,
                            isI94DSExpiryDate:false,
                            relationship: '',
                            saved: false,
                            currentlyInUS: null,
                            hasOtherNames: null, 
                            otherNames: [{
                                _id: 0,
                                name: '',
                                firstName: '',
                                middleName: '',
                                lastName: '',
                            }],
                            passportIssuedNumber: null,
                            alienNumber: '',
                            prevEmploymentInfo: [{
                                _id: 0,
                                employerName: '',
                                address: {
                                    line1: null,
                                    line2: null,
                                    aptType: null,
                                    locationId: null,
                                    locationDetails: null,
                                    stateId: null,
                                    stateDetails: null,
                                    countryId: null,
                                    countryDetails: null,
                                    zipcode: null
                                },
                                businessType: null,
                                jobTitle: null,
                                jobDuties: null,
                                startDate: null,
                                endDate: null,
                                payFrequency:null,
                                salary: null,
                                currentEmployer: null
                            }],
                            addressOutsideUS: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                            priorPeriodOfStayInUS: [{
                                _id: 0,
                                enteredNumber: null,
                                departedNumber: null,
                                dateerror: false,
                                noOfDays: null,
                                visaStatus: null
                            }],
                            dateFromWhichResideInUs:null,
                            caseIssuedDate: null,
                            caseExpiryDate: null,
                            placeOfCaseIssued: '',
                            mailingAddressIsSameAsAddress:false,
                            stateOfLastEntryInUS: '',
                            stateDetailsOfLastEntryInUS: null,
                            placeOfLastEntryInUS: '',
                            firstArrivalDate: null,
                            lastArrivalDate: null,
                            allIssuedpassportData: [{
                                countryId: '',
                                countryDetails: null,
                                number: '',
                                issuedDate: null,
                                expiryDate: null 
                            }],
                            currentAddress: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                            height: {
                            feet: '',
                            inches: ''
                            },
                            weight: null,
                            race: null,
                            eyeColor:null,
                            hairColor: null,
                            educations: [{
                            _id: 0,
                            name: null,
                            address: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                            highestDegree: null,
                            highestDegreeDetails: null,
                            majorFieldOfStudy: null,
                            attendedFrom: null,
                            attendedTo: null,
                            graduatedYear: null,
                            degreereceived: null,
                            isAccredited: null,
                            isForProfit: null
                            }],
                            prevEmploymentInfo: [{
                            _id: 0,
                            employerName: '',
                            address: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                            businessType: null,
                            jobTitle: null,
                            jobDuties: null,
                            startDate: null,
                            endDate: null,
                            currentEmployer: false
                            }],
                            prevEmploymentOutsideUS:[{
                                _id: 0,
                                employerName: '',
                                address: {
                                    line1: null,
                                    line2: null,
                                    aptType: null,
                                    locationId: null,
                                    locationDetails: null,
                                    stateId: null,
                                    stateDetails: null,
                                    countryId: null,
                                    countryDetails: null,
                                    zipcode: null
                                },
                                businessType: null,
                                jobTitle: null,
                                jobDuties: null,
                                startDate: null,
                                endDate: null,
                                currentEmployer: false  
                            }],
                            previousSpouse:{
                            hasOtherNames:false,
                            otherNames: [{
                                _id: 0,
                                name: '',
                                firstName: '',
                                middleName: '',
                                lastName: '',
                            }],
                            maidenName:'',
                            marriageEndedDueTo:null,
                            marriageEndedOtherInfo:'',
                            firstName: '',
                            middleName: '',
                            lastName: '',
                            dateOfBirth: null,
                            dateOfMarriage:null,
                            dateOfMarriageEnd:null,
    
                              //Place of Marriage
                            countryOfMarriage: '',
                            countryOfMarriageDetails: null,
                            provinceOfMarriage: '',
                            provinceOfMarriageDetails: null,
                            locationOfMarriage: '',
    
                            //Place of Termination
                            countryOfMarriageTermination: '',
                            countryOfMarriageTerminationDetails: null,
                            provinceOfMarriageTermination: '',
                            provinceOfMarriageTerminationDetails: null,
                            locationOfMarriageTermination: '',
                            obtainPermResidenceThroughSpouse:false  
                          
                            },
                            addressOfLastNYears:[{
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null,
                                startDate: null,
                                endDate: null,
                            }], 
                            addressOutsideUSMoreThanYear:[{
                            
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null,
                                startDate: null,
                                endDate: null,
                            }],
                            dateOfLastEntryInUS:null,
                            dateOfMarriage: null, 
                            dateOfMarriageEnd: null, 
                            countryOfMarriage: '', 
                            countryOfMarriageDetails: null, 
                            provinceOfMarriage: '', 
                            provinceOfMarriageDetails: null, 
                            locationOfMarriage: '',
                            currentSpouseName: '',
                            maritalStatus : null, 
                            maritalStatusDetails: null,
                            curNonImmigrantVisaStatus: '', 
                            associations:[ {
                                name:'', 
                                address:{
                                    locationId: null,
                                    locationDetails: null,
                                    stateId: null,
                                    stateDetails: null,
                                    countryId: null,
                                    countryDetails: null,
                                },
                                startDate: null,
                                endDate:null,
                                natureofAssociations:'',
                            }],
                            everAppliedAOSInUS: false, 
                            appliedAOSInUSDocs:[],
                            haveYouArrestedBefore:false,
                            haveYouArrestedBeforeDocs:[], 
                            doesBirthRegistered:false, 
                            curNonImmigrantVisaNumber:'',
                            inspectedByAnyImmOfficer: false, 
                            issuedAnyEADFromUSCIS: false, 
                            hasPermResidencyInOtherCountry: false, 
                            permResidencyCountryId: '', 
                            passportIssuedDate: null,
                            permResidencyCountryDetails: null,
                            

                            h4Required: null,
                            h4EADRequired: null,
                            name: '',
                            firstName: '',
                            middleName: '',
                            lastName: '',
                            email: '',
                            phoneNumber: '',
                            phoneCountryCode: {
                                countryCode: '',
                                countryCallingCode: ''
                            },
                            dateOfBirth: null,
                            countryOfBirth: null,
                            countryOfBirthDetails: null,
                            provinceOfBirth: null,
                            provinceOfBirthDetails: null,
                            locationOfBirth: '',
                            locationOfBirthDetails: null,
                            countryOfCitizenship: null,
                            countryOfCitizenshipDetails: null,
                            passportNumber: '',
                            passportExpiryNumber: null,
                            passportIssuedCountry:null,
                            passportIssuedCountryDetails:null,
                            I94: '',
                            I94ExpiryNumber: null,
                            currentStatus: null,
                            currentStatusDetails: null,
                            statusExpiryNumber: null,
                            SSN: '',
                            lastArrivalNumber: null,
                            placeOfLastEntryInUS: '',
                            applyingWithYou:null,
                            nameDiffFromBirthCert:false,
                            physicalAddress: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                            fatherInfo: { 
                                name: '', 
                                firstName: '', 
                                middleName: '', 
                                lastName: '', 
                                hasOtherNames: false, 
                                otherNames: [{ 
                                    _id: 0, 
                                    name: '', 
                                    firstName: '', 
                                    middleName: '', 
                                    lastName: '', 
                                }], 
                                dateOfBirth: null, 
                                countryOfBirth: '', 
                                countryOfBirthDetails: null, 
                                provinceOfBirth: '', 
                                provinceOfBirthDetails: null, 
                                locationOfBirth: '', 
                                currentAddress: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                                isUSCitizen: false, 
                                dateFromUSCitizen: null, //["", ""],
                                nameAtBirth:{
                                    firstName: '', 
                                    middleName: '', 
                                    lastName: '',
                                },
                                deceasedCity: '',
                                deceasedCityDetails:null,
                                deceasedDate: null,
                            },
                            motherInfo: { 
                                name: '',                    
                                firstName: '', 
                                middleName: '', 
                                lastName: '', 
                                hasOtherNames: false , 
                                otherNames: [{ 
                                    _id: 0, 
                                    name: '', 
                                    firstName: '', 
                                    middleName: '', 
                                    lastName: '', 
                                }], 
                                dateOfBirth: null, 
                                countryOfBirth: '', 
                                countryOfBirthDetails: null, 
                                provinceOfBirth: '', 
                                provinceOfBirthDetails: null, 
                                locationOfBirth: '', 
                                currentAddress: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                                },
                                isUSCitizen: false, 
                                dateFromUSCitizen:null,// ["", ""],
                                nameAtBirth:{
                                    firstName: '', 
                                    middleName: '', 
                                    lastName: '',
                                },
                                deceasedCity: '',
                                deceasedCityDetails:null,
                                deceasedDate: null,
                            }, 
                            documents: {
                                passport: [],
                                visa: [],
                                formI94: [],
                                formI797: [],
                                formI20: [],
                                payStubs: [],
                                marriageCertificate: [],
                                noticeOfApprovalOfH1Status: [],
                                approvalNoticeOfPrevH4: [],
                                other: []
                            },
                            //i140
                            adjustmentOfI485Status: false, //Adjustment of Status (I-485) //{ type: Boolean, default: false },
                            consularProcessing:false,// Consular Processing { type: Boolean, default: false },
                        
    
                        },
                ignorePrefillItems:[ 
                
                    {
                        key:'isUSCitizen',
                        section:'dependentsInfo.spouse.fatherInfo',
                    },
                    {
                        key:'applyI485AdjOrConsuProcess',
                        section:'beneficiaryInfo',
                    },
                    {
                        key:'consularProcessing',
                        section:'beneficiaryInfo',
                    },
                    {
                        key:'adjustmentOfI485Status',
                        section:'beneficiaryInfo',
                    },
                    {
                        key:'isUSCitizen',
                        section:'dependentsInfo.spouse.motherInfo',
                    },
                    {
                        key:'isUSCitizen',
                        section:'fatherInfo',
                    },
                    {
                        key:'isUSCitizen',
                        section:'motherInfo',
                    }, 
                    {
                        key:'hasOtherNames',
                        section:'dependentsInfo.spouse.fatherInfo',
                    },
                    {
                        key:'hasOtherNames',
                        section:'dependentsInfo.spouse.motherInfo',
                    },
                    {
                        key:'hasOtherNames',
                        section:'fatherInfo',
                    },
                    {
                        key:'hasOtherNames',
                        section:'motherInfo',
                    },                               
                    {
                        key:'obtainPermResidenceThroughSpouse',
                        section:'beneficiaryInfo.previousSpouse',
                    },
                    {
                        key:'haveYouEverEmployed',
                        section:'beneficiaryInfo',
                    },
                    {
                        key:'obtainPermResidenceThroughSpouse',
                        section:'dependentsInfo.spouse.previousSpouse',
                    },
                    {
                        key:'areYouUnderRemoveOfIndOrUscis',
                        section:'beneficiaryInfo',
                    },
                    {
                        key:'currentlyInUS',
                        section:'beneficiaryInfo',
                        preSelect:true,
                    },
					{
                        key:'anyImmPetitionFiled',
                        section:'beneficiaryInfo',
                    },
					{
                        key:'anyOtherAlienFiled',
                        section:'beneficiaryInfo.immPetitionInfo',
                    },
					{
                        key:'rirOrRegularProcessing',
                        section:'beneficiaryInfo.immPetitionInfo',
                    }, 
					{
                        key:'seekingFiledDateforETA750',
                        section:'beneficiaryInfo.immPetitionInfo', 
                    }, 
					{
                        key:'anyI140Filed',
                        section:'beneficiaryInfo.immPetitionInfo',
                    }, 
					{
                        key:'hasApprovedI140',
                        section:'beneficiaryInfo',
                    },
					{
                        key:'hasPermPendingForMorethan365Days',
                        section:'beneficiaryInfo',
                    },
					{
                        key:'currentlyInUS',
                        section:'dependentsInfo.spouse',
                        preSelect:true,
                    },
                    {
                        key:'nameDiffFromBirthCert',
                        section:'beneficiaryInfo',
                    },
                    {
                        key:'have2AffidavitsOfBirthFamily',
                        section:'beneficiaryInfo',
                    },
                    {
                        key:'birthCertHaveNamePobDob',
                        section:'beneficiaryInfo',
                    },
                    {
                        key:'previouslyMarried',
                        section:'beneficiaryInfo',
                    },
                    {
                        key:'hasI140ImmPetitionFiled',
                        section:'beneficiaryInfo',
                    },
                    {
                        key:'haveYouEverTravelledToUS',
                        section:'dependentsInfo.spouse',
                        preSelect:true,
                    },
                    {
                        key:'haveYouEverTravelledToUS',
                        section:'beneficiaryInfo',
                        preSelect:true,
                    },
                   
                    {
                        key:'hasMasterDegreeInUS',
                        section:'beneficiaryInfo',
                    },
                    {
                        key:'anyOtherPersonEmployedInUS',
                        section:'beneficiaryInfo',
                    },
                    {
                        key:'hasAnyDependetsinUStoFileH4',
                        section:'beneficiaryInfo',
                    },
                    {
                        key:'h4Required',
                        section:'dependentsInfo.spouse',
                    },
                    {
                        key:'h4EADRequired',
                        section:'dependentsInfo.spouse',
                    },
                    {
                        key:'anyOtherPersonEmployedInUS',
                        section:'dependentsInfo.spouse',
                    },
                    {
                        key:'anyOtherPersonEmployedInUS',
                        section:'spouse',
                    },
                    {
                        key:'haveYouEverEmployed',
                        section:'spouse',
                    },
                    {
                        key:'hasOtherNames',
                        section:'beneficiaryInfo',
                    },
					{
                        key:'hasOtherNames',
                        section:'dependentsInfo.spouse',
                    },
                    {
                        key:'nameDiffFromBirthCert',
                        section:'beneficiaryInfo',
                    },
                    {
                        key:'birthCertHaveNamePobDob',
                        section:'beneficiaryInfo',
                    },
                    {
                        key:'have2AffidavitsOfBirthFamily',
                        section:'beneficiaryInfo',
                    },
                    {
                        key:'previouslyMarried',
                        section:'beneficiaryInfo',
                    },
                    {
                        key:'inspectedByAnyImmOfficer',
                        section:'beneficiaryInfo',
                    },
                    {
                        key:'issuedAnyEADFromUSCIS',
                        section:'beneficiaryInfo',
                    },
                    {
                        key:'hasPermResidencyInOtherCountry',
                        section:'beneficiaryInfo',
                    },
                    {
                        key:'haveYouArrestedBefore',
                        section:'beneficiaryInfo',
                    },
                    {
                        key:'everAppliedAOSInUS',
                        section:'beneficiaryInfo',
                    },

                    {
                        key:'doYouHaveMarriageCert',
                        section:'beneficiaryInfo',
                    },
                    {
                        key:'have2AffidavitsAttestingToMarriage',
                        section:'beneficiaryInfo',
                    },
                ],
                educationErrorMsg:"Seems you have not submitted bachelor's information. Please fill to continue",
                configDetails:null,
                prefillCountryInQuestionnaire:true,
                
            };
        },
        computed: {
            checkI94(){
                let returnVal = false;
                if(!this.petition.beneficiaryInfo.I94 || this.petition.beneficiaryInfo.isI94DSExpiryDate){
                    returnVal = true
                }
                return returnVal
            },
            checkCurrentStatus(){
                let returnVal = false;
                if(!this.petition.beneficiaryInfo.curNonImmigrantVisaStatus || this.petition.beneficiaryInfo.isDSExpiryDate){
                    returnVal = true
                }
                return returnVal
            },
            getTplSectionPrevious(){
                if(this.tplsection=='dependentsInfo.spouse'){
                return "dependentsInfo.spouse.previousSpouse"
                }else{
                    return this.tplsection;
                }
            },
            checkActiveTab(){
              return  _.findIndex(this.tabslist ,{"key":this.currentTab});
            },  
            getCaseName(){
                //petition.typeDetails.name
                let s =this.checkProperty(this.petition ,'typeDetails','name');
               if(s){
                s='Questionnaire for '+s;
                if( this.checkProperty(this.petition ,'subTypeDetails','name') ){
                    s=s+" <small>"+this.petition.subTypeDetails.name+"</small"
                }
                return s.replace(/(\d)/g, '<span class="number">$1</span>');
            }else{
                return '';
            }
    
            },
            gettotalDays() {
                var totaldays = 0;
                if(this.petition.beneficiaryInfo.priorPeriodOfStayInUS && this.checkProperty(this.petition['beneficiaryInfo'],'priorPeriodOfStayInUS','length')>0){
                    this.petition.beneficiaryInfo.priorPeriodOfStayInUS.forEach(function (item, index) {
                        if (item.noOfDays > 0) {
                            totaldays = totaldays + item.noOfDays;
        
                        }
                    })
                }
                return totaldays;
            },
            getIndexOfActivetab() {
                var $self = this;
                return _.findIndex(this.tabslist, (e) => {
                    return e.key == $self.currentTab;
                }) + 1;
            },
            actiontype() {
                if (this.getIndexOfActivetab == this.tabslist.length) {
                    if (this.petition.questionnaireFilled) {
                        return "Update";
                    }
                    if (!this.petition.questionnaireFilled) {
                        return "Submit";
                    }
                    return "Submit";
                }
                return "Next";
            }
    
        },
        methods: {
            emitUploadingAction(data){
                if(_.has(data,'docMainCategory')){
                    _.map(this[data['docMainCategory']],(item)=>{
                        if(item['fieldName'] == data['fieldName']){
                            item = Object.assign( item ,{ "fileUploading": false})
                            item['fileUploading'] = data['action'] 
                        }
                    })
                }
                this.checkSubmitBtn(data)
            },
            checkSubmitBtn(data){
                this.documentUploading = false;
                if(_.has(data,'docMainCategory')){
                    _.forEach(this[data['docMainCategory']],(item)=>{
                        if(_.has(item,'fileUploading') && item['fileUploading']){
                            this.documentUploading = true;
                            return false;
                        }
                    })
                }
            },
            chnageMailingAddress(){
                if(this.checkProperty(this.petition,'beneficiaryInfo','currentlyInUS') && this.canRenderField('mailingAddressIsSameAsAddress',this.questionnaireDetails, false, 'beneficiaryInfo' ) 
                && this.canRenderField('currentAddress',this.questionnaireDetails, false, 'beneficiaryInfo' ) && this.canRenderField('address',this.questionnaireDetails, false, 'beneficiaryInfo' )
                && this.petition.beneficiaryInfo.mailingAddressIsSameAsAddress){
                    this.setSameaddress()
                }
            },
            addNyears(){
                let obj ={
                        line1: null,
                        line2: null,
                        aptType: null,
                        locationId: null,
                        locationDetails: null,
                        stateId: null,
                        stateDetails: null,
                        countryId: null,
                        countryDetails: {
                            _id: "61408c9ed01ea1248cdcf6b7",
                            id: 231,
                            name: "United States",
                            phoneCode: 1,
                            order: 1,
                            currencySymbol: "$",
                            currencyCode: "USD",
                            zipcodeLength: 5,
                            sortName: "united states",
                        },
                        zipcode: null,
                        startDate: null,
                        endDate: null,
                }
                this.petition.beneficiaryInfo['addressOfLastNYears'].push(obj);
                this.petition.beneficiaryInfo['addressOfLastNYears'] = _.cloneDeep( this.petition.beneficiaryInfo['addressOfLastNYears']);
            },
            removeNyears: function (index) {
                Vue.delete(this.petition.beneficiaryInfo.addressOfLastNYears, index);
            },
            addLastYearItem(){
                let obj ={
                        line1: null,
                        line2: null,
                        aptType: null,
                        locationId: null,
                        locationDetails: null,
                        stateId: null,
                        stateDetails: null,
                        countryId: null,
                        countryDetails: {
                            _id: "61408c9ed01ea1248cdcf6b7",
                            id: 231,
                            name: "United States",
                            phoneCode: 1,
                            order: 1,
                            currencySymbol: "$",
                            currencyCode: "USD",
                            zipcodeLength: 5,
                            sortName: "united states",
                        },
                        zipcode: null,
                        startDate: null,
                        endDate: null,
                }
                    this.petition.beneficiaryInfo['addressOutsideUSMoreThanYear'].push(obj);
                   this.petition.beneficiaryInfo['addressOutsideUSMoreThanYear'] = _.cloneDeep( this.petition.beneficiaryInfo['addressOutsideUSMoreThanYear']); 
            },
            removeLastYearItem: function (ind) {
                Vue.delete(this.petition.beneficiaryInfo.addressOutsideUSMoreThanYear, ind);
            },
            clearStartandEnddate(val,key,inder,position){
                if( this.petition.beneficiaryInfo[key] && this.checkProperty(this.petition.beneficiaryInfo[key],'length')>0){
                    let startDate = moment(this.petition.beneficiaryInfo[key][inder]['startDate']);
                    let endDate = moment(this.petition.beneficiaryInfo[key][inder]['endDate']);
                    if(!val && position == 'start'){
                        this.petition.beneficiaryInfo[key][inder]['endDate'] = null
                    }
                    if(val && position == 'start' && ( startDate.isAfter(endDate , 'day'))){
                        this.petition.beneficiaryInfo[key][inder]['endDate'] = null
                    }
                    if(position == 'end' && ( endDate.isBefore(startDate, 'day'))){
                        this.petition.beneficiaryInfo[key][inder]['startDate'] = null
                    }
                }
            },
            clearDependentField(obj){   
               if(obj['startDate']==null){
                   obj.endDate = null;
               }
               if(obj.startDate > obj.endDate){
                   obj.endDate = null;
               }
            },
            clearEndDate(obj){
               if(obj['startDate']==null){
                   obj.endDate = null;
               }
               if(obj.startDate > obj.endDate){
                   obj.endDate = null;
               }
            },
            disableCountryUsa(){
                if(this.checkProperty(this.petition,'highestDegreeList') && this.checkProperty(this.petition,'highestDegreeList','length')>0 && this.checkProperty(this.petition,'beneficiaryInfo','educations') && this.checkProperty(this.petition['beneficiaryInfo'],'educations','length')>0
                && this.petition.beneficiaryInfo.hasMasterDegreeInUS ){
                    _.forEach(this.petition.beneficiaryInfo.educations,(item)=>{
                        if(_.has(item,'highestDegree') && this.checkProperty(item,'highestDegree') == 6 && 
                        _.has(item,'address') && _.has(item['address'],'countryId')){
                            item['address']['countryId'] = 231
                            item['address']['countryDetails'] = { "_id": "626a8f03a972fa4d60681140", "id": 231, "name": "United States", "phoneCode": 1, "order": 1, "currencySymbol": "$", "currencyCode": "USD", "zipcodeLength": 5, "sortName": "united states" }
                        }
                    })
                }
            },
            removeCOuntryUSA(){
                if(!this.petition.beneficiaryInfo.hasMasterDegreeInUS && this.canRenderField('hasMasterDegreeInUS', this.questionnaireDetails ,false,'beneficiaryInfo')){
                    this.$refs['beneficairy_education'].removeCountryUs();     
                }
            },
            checkPreviousSpouse(){
                if((this.petition.beneficiaryInfo.previouslyMarried == null || this.petition.beneficiaryInfo.previouslyMarried == false)  && this.checkProperty(this.petition ,'beneficiaryInfo','maritalStatus') ==1){
                    this.petition.beneficiaryInfo.previousSpouse = {
                        hasOtherNames:false,
                        otherNames: [{
                            _id: 0,
                            name: '',
                            firstName: '',
                            middleName: '',
                            lastName: '',
                        }],
                        maidenName:'',
                        marriageEndedDueTo:null,
                        marriageEndedOtherInfo:'',
                        firstName: '',
                        middleName: '',
                        lastName: '',
                        dateOfBirth: null,
                        dateOfMarriage:null,
                        dateOfMarriageEnd:null,
                        countryOfMarriage: '',
                        countryOfMarriageDetails: null,
                        provinceOfMarriage: '',
                        provinceOfMarriageDetails: null,
                        locationOfMarriage: '',
                        countryOfMarriageTermination: '',
                        countryOfMarriageTerminationDetails: null,
                        provinceOfMarriageTermination: '',
                        provinceOfMarriageTerminationDetails: null,
                        locationOfMarriageTermination: '',
                        obtainPermResidenceThroughSpouse:false     
                    }
                }
            },
            I94ValueCheck(val){
                if(!val){
                    this.petition.beneficiaryInfo.I94ExpiryDate = null;
                }
            //    if(val.length<=0 && this.petition.beneficiaryInfo.isI94DSExpiryDate==false){
            //     this.petition.beneficiaryInfo.I94ExpiryDate = null;
            //     this.disablefield = true;
            //   }
            },
            getGlobalConfigDetails(){
                let postData ={}
                let path = 'global-config/details'
                this.$store.dispatch("commonAction", {data:postData,path:path})
                .then((response) =>{   
                this.defaultCountryCode = this.countrycode;            
                    if(this.checkProperty(response ,"config" )){
                        this.configDetails = this.checkProperty(response ,"config" );
                        if(_.has(this.configDetails ,"prefillCountryInQuestionnaire" )){
                            this.prefillCountryInQuestionnaire =this.configDetails['prefillCountryInQuestionnaire']
                        }
                    
                    }
                })
            },
            removeH4Docs(){
                if(this.checkProperty( this.petition,'beneficiaryInfo','curNonImmigrantVisaStatus') && this.checkProperty( this.petition,'beneficiaryInfo','curNonImmigrantVisaStatus')!=7 ){
                    let docsList = ['formI797H4ApprovalNotice','h4Ead','marriageCertificate','formI797H1BApprovalNoticePrinNonCtzn','passportOfPrinNonCtzn','last3MonthsPayslipsOfPrinNonCtzn']
                    _.forEach(docsList,(item)=>{
                        if(_.has(this.petition['documents'],item)){
                            this.petition['documents'][item] = []
                        }
                    })
                }
            },
            removeFields(){
                
                _.forEach(this.ignorePrefillItems,(item)=>{
                    let section = item['section'];
                    let key  = item['key'];
                    if(section == 'spouse'){
                        _.update(this.spouse,key, () => null);
                    }else{
                        _.update(this.petition,section+'.'+key, () => null);
                    }    
                })
                if(this.checkProperty(this.petition,'beneficiaryInfo','prevEmploymentInfo') && this.checkProperty(this.petition['beneficiaryInfo'],'prevEmploymentInfo','length')>0){
                    _.forEach(this.petition['beneficiaryInfo']['prevEmploymentInfo'],(item)=>{
                        if(_.has(item,'currentEmployer')){
                            item['currentEmployer'] = null;
                        }
                    })
                }
                
            },
            checkCurrentlyInUsa(){
                if(this.canRenderField('currentlyInUS',this.questionnaireDetails, false, 'beneficiaryInfo' ) && !this.checkProperty(this.petition,'beneficiaryInfo','currentlyInUS')){
                    this.petition.beneficiaryInfo.curNonImmigrantVisaStatusDetails = null
                    this.petition.beneficiaryInfo.curNonImmigrantVisaStatus  = null
                    this.petition.beneficiaryInfo.isDSExpiryDate = null
                    this.petition.beneficiaryInfo.curVisaExpiryDate = null
                    this.petition.beneficiaryInfo.I94 = null
                    this.petition.beneficiaryInfo.isI94DSExpiryDate = null
                    this.petition.beneficiaryInfo.I94ExpiryDate = null
                    this.petition.beneficiaryInfo.sevisNumber = null
                    this.petition.beneficiaryInfo.eadNumber = null
                    this.petition.beneficiaryInfo.address ={
                        line1: null,
                        line2: null,
                        aptType: null,
                        locationId: null,
                        locationDetails: null,
                        stateId: null,
                        stateDetails: null,
                        countryId: null,
                        countryDetails: null,
                        zipcode: null
                    }
                }
            },
            checkDependentsInfo(){
                if(this.petition.beneficiaryInfo && _.has(this.petition['beneficiaryInfo'],'hasAnyDependetsinUStoFileH4') && !this.checkProperty(this.petition,'beneficiaryInfo','hasAnyDependetsinUStoFileH4') && this.canRenderField('hasAnyDependetsinUStoFileH4',this.questionnaireDetails,false ,'beneficiaryInfo')){
                    this.petition['dependentsInfo'] = {
                        spouse: {
                            adjustmentStatusToPermResidenceI485:null,
                            sevisNumber: null,
                            eadNumber: null,
                            haveYouEverTravelledToUS:null,
                            isDSExpiryDate:false,
                            isI94DSExpiryDate:false,
                            relationship: '',
                            saved: false,
                            currentlyInUS: null,
                            hasOtherNames: null, 
                            otherNames: [{
                                _id: 0,
                                name: '',
                                firstName: '',
                                middleName: '',
                                lastName: '',
                            }],
                            passportIssuedNumber: null,
                            alienNumber: '',
                            prevEmploymentInfo: [{
                                _id: 0,
                                employerName: '',
                                address: {
                                    line1: null,
                                    line2: null,
                                    aptType: null,
                                    locationId: null,
                                    locationDetails: null,
                                    stateId: null,
                                    stateDetails: null,
                                    countryId: null,
                                    countryDetails: null,
                                    zipcode: null
                                },
                                businessType: null,
                                jobTitle: null,
                                jobDuties: null,
                                startDate: null,
                                endDate: null,
                                payFrequency:null,
                                salary: null,
                                currentEmployer: null
                            }],
                            addressOutsideUS: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                            priorPeriodOfStayInUS: [{
                                _id: 0,
                                enteredNumber: null,
                                departedNumber: null,
                                dateerror: false,
                                noOfDays: null,
                                visaStatus: null
                            }],
                            dateFromWhichResideInUs:null,
                            caseIssuedDate: null,
                            caseExpiryDate: null,
                            placeOfCaseIssued: '',
                            mailingAddressIsSameAsAddress:false,
                            stateOfLastEntryInUS: '',
                            stateDetailsOfLastEntryInUS: null,
                            placeOfLastEntryInUS: '',
                            firstArrivalDate: null,
                            lastArrivalDate: null,
                            allIssuedpassportData: [{
                                countryId: '',
                                countryDetails: null,
                                number: '',
                                issuedDate: null,
                                expiryDate: null 
                            }],
                            currentAddress: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                            height: {
                            feet: '',
                            inches: ''
                            },
                            weight: null,
                            race: null,
                            eyeColor:null,
                            hairColor: null,
                            educations: [{
                            _id: 0,
                            name: null,
                            address: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                            highestDegree: null,
                            highestDegreeDetails: null,
                            majorFieldOfStudy: null,
                            attendedFrom: null,
                            attendedTo: null,
                            graduatedYear: null,
                            degreereceived: null,
                            isAccredited: null,
                            isForProfit: null
                            }],
                            prevEmploymentInfo: [{
                            _id: 0,
                            employerName: '',
                            address: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                            businessType: null,
                            jobTitle: null,
                            jobDuties: null,
                            startDate: null,
                            endDate: null,
                            currentEmployer: false
                            }],
                            prevEmploymentOutsideUS:[{
                                _id: 0,
                                employerName: '',
                                address: {
                                    line1: null,
                                    line2: null,
                                    aptType: null,
                                    locationId: null,
                                    locationDetails: null,
                                    stateId: null,
                                    stateDetails: null,
                                    countryId: null,
                                    countryDetails: null,
                                    zipcode: null
                                },
                                businessType: null,
                                jobTitle: null,
                                jobDuties: null,
                                startDate: null,
                                endDate: null,
                                currentEmployer: false  
                            }],
                            previousSpouse:{
                            hasOtherNames:false,
                            otherNames: [{
                                _id: 0,
                                name: '',
                                firstName: '',
                                middleName: '',
                                lastName: '',
                            }],
                            maidenName:'',
                            marriageEndedDueTo:null,
                            marriageEndedOtherInfo:'',
                            firstName: '',
                            middleName: '',
                            lastName: '',
                            dateOfBirth: null,
                            dateOfMarriage:null,
                            dateOfMarriageEnd:null,
    
                              //Place of Marriage
                            countryOfMarriage: '',
                            countryOfMarriageDetails: null,
                            provinceOfMarriage: '',
                            provinceOfMarriageDetails: null,
                            locationOfMarriage: '',
    
                            //Place of Termination
                            countryOfMarriageTermination: '',
                            countryOfMarriageTerminationDetails: null,
                            provinceOfMarriageTermination: '',
                            provinceOfMarriageTerminationDetails: null,
                            locationOfMarriageTermination: '',
                            obtainPermResidenceThroughSpouse:false  
                          
                            },
                            addressOfLastNYears:[{
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null,
                                startDate: null,
                                endDate: null,
                            }], 
                            addressOutsideUSMoreThanYear:[{
                            
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null,
                                startDate: null,
                                endDate: null,
                            }],
                            dateOfLastEntryInUS:null,
                            dateOfMarriage: null, 
                            dateOfMarriageEnd: null, 
                            countryOfMarriage: '', 
                            countryOfMarriageDetails: null, 
                            provinceOfMarriage: '', 
                            provinceOfMarriageDetails: null, 
                            locationOfMarriage: '',
                            currentSpouseName: '',
                            maritalStatus : '', 
                            maritalStatusDetails: null,
                            curNonImmigrantVisaStatus: '', 
                            associations:[ {
                                name:'', 
                                address:{
                                    locationId: null,
                                    locationDetails: null,
                                    stateId: null,
                                    stateDetails: null,
                                    countryId: null,
                                    countryDetails: null,
                                },
                                startDate: null,
                                endDate:null,
                                natureofAssociations:'',
                            }],
                            everAppliedAOSInUS: false, 
                            appliedAOSInUSDocs:[],
                            haveYouArrestedBefore:false,
                            haveYouArrestedBeforeDocs:[], 
                            doesBirthRegistered:false, 
                            curNonImmigrantVisaNumber:'',
                            inspectedByAnyImmOfficer: false, 
                            issuedAnyEADFromUSCIS: false, 
                            hasPermResidencyInOtherCountry: false, 
                            permResidencyCountryId: '', 
                            passportIssuedDate: null,
                            permResidencyCountryDetails: null,
                            

                            h4Required: null,
                            h4EADRequired: null,
                            name: '',
                            firstName: '',
                            middleName: '',
                            lastName: '',
                            email: '',
                            phoneNumber: '',
                            phoneCountryCode: {
                                countryCode: '',
                                countryCallingCode: ''
                            },
                            dateOfBirth: null,
                            countryOfBirth: null,
                            countryOfBirthDetails: null,
                            provinceOfBirth: null,
                            provinceOfBirthDetails: null,
                            locationOfBirth: '',
                            locationOfBirthDetails: null,
                            countryOfCitizenship: null,
                            countryOfCitizenshipDetails: null,
                            passportNumber: '',
                            passportExpiryNumber: null,
                            passportIssuedCountry:null,
                            passportIssuedCountryDetails:null,
                            I94: '',
                            I94ExpiryNumber: null,
                            currentStatus: null,
                            currentStatusDetails: null,
                            statusExpiryNumber: null,
                            SSN: '',
                            lastArrivalNumber: null,
                            placeOfLastEntryInUS: '',
                            applyingWithYou:null,
                            nameDiffFromBirthCert:null,
                            physicalAddress: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                            fatherInfo: { 
                                name: '', 
                                firstName: '', 
                                middleName: '', 
                                lastName: '', 
                                hasOtherNames: false, 
                                otherNames: [{ 
                                    _id: 0, 
                                    name: '', 
                                    firstName: '', 
                                    middleName: '', 
                                    lastName: '', 
                                }], 
                                dateOfBirth: null, 
                                countryOfBirth: '', 
                                countryOfBirthDetails: null, 
                                provinceOfBirth: '', 
                                provinceOfBirthDetails: null, 
                                locationOfBirth: '', 
                                currentAddress: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                                isUSCitizen: false, 
                                dateFromUSCitizen: null, //["", ""],
                                nameAtBirth:{
                                    firstName: '', 
                                    middleName: '', 
                                    lastName: '',
                                },
                                deceasedCity: '',
                                deceasedCityDetails:null,
                                deceasedDate: null,
                            },
                            motherInfo: { 
                                name: '',                    
                                firstName: '', 
                                middleName: '', 
                                lastName: '', 
                                hasOtherNames: false , 
                                otherNames: [{ 
                                    _id: 0, 
                                    name: '', 
                                    firstName: '', 
                                    middleName: '', 
                                    lastName: '', 
                                }], 
                                dateOfBirth: null, 
                                countryOfBirth: '', 
                                countryOfBirthDetails: null, 
                                provinceOfBirth: '', 
                                provinceOfBirthDetails: null, 
                                locationOfBirth: '', 
                                currentAddress: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                                },
                                isUSCitizen: false, 
                                dateFromUSCitizen:null,// ["", ""],
                                nameAtBirth:{
                                    firstName: '', 
                                    middleName: '', 
                                    lastName: '',
                                },
                                deceasedCity: '',
                                deceasedCityDetails:null,
                                deceasedDate: null,
                            }, 
                            documents: {
                                passport: [],
                                visa: [],
                                formI94: [],
                                formI797: [],
                                formI20: [],
                                payStubs: [],
                                marriageCertificate: [],
                                noticeOfApprovalOfH1Status: [],
                                approvalNoticeOfPrevH4: [],
                                other: []
                            },
                            //i140
                            adjustmentOfI485Status: false, //Adjustment of Status (I-485) //{ type: Boolean, default: false },
                            consularProcessing:false,// Consular Processing { type: Boolean, default: false },
                        
    
                        },
                        childrens: [{
                            sevisNumber: null,
                            eadNumber: null,
                            isDSExpiryDate:false,
                            isI94DSExpiryDate:false,
                            email: '',
                            phoneNumber: '',
                            phoneCountryCode: {
                            countryCode: '',
                            countryCallingCode: ''
                            },
                            saved: false,
                            relationship: '',
                            currentlyInUS: null,
                            hasOtherNames: null, 
                            otherNames: [{
                                _id: 0,
                                name: '',
                                firstName: '',
                                middleName: '',
                                lastName: '',
                            }],
                            alienNumber: '',
                            lastArrivalNumber: null,
                            placeOfLastEntryInUS: '',
                            physicalAddress: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: {
                                    id: null,
                                    name: null,
                                    stateId: null,
                                    countryId: null
                                },
                                stateId: null,
                                stateDetails: {
                                    id: null,
                                    name: null,
                                    countryId: null
                                },
                                countryId: null,
                                countryDetails: {
                                    id: null,
                                    name: null,
                                    shortName: null,
                                    phoneCode: null,
                                    countryId: null,
                                    currencySymbol: null,
                                    currencyCode: null,
                                    zipcodeLength: null
                                },
                                zipcode: null
                            },
                            addressOutsideUS: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: {
                                    id: null,
                                    name: null,
                                    stateId: null,
                                    countryId: null
                                },
                                stateId: null,
                                stateDetails: {
                                    id: null,
                                    name: null,
                                    countryId: null
                                },
                                countryId: null,
                                countryDetails: {
                                    id: null,
                                    name: null,
                                    shortName: null,
                                    phoneCode: null,
                                    countryId: null,
                                    currencySymbol: null,
                                    currencyCode: null,
                                    zipcodeLength: null
                                },
                                zipcode: null
                            },
                            passportIssuedNumber: null,
                            priorPeriodOfStayInUS: [{
                                _id: 0,
                                enteredNumber: null,
                                dateerror: false,
                                noOfDays: null,
                                departedNumber: null,
                                visaStatus: null
                            }],
                            prevEmploymentInfo: [{
                                _id: 0,
                                employerName: '',
                                address: {
                                    line1: null,
                                    line2: null,
                                    aptType: null,
                                    locationId: null,
                                    locationDetails: null,
                                    stateId: null,
                                    stateDetails: null,
                                    countryId: null,
                                    countryDetails: null,
                                    zipcode: null
                                },
                                businessType: null,
                                jobTitle: null,
                                jobDuties: null,
                                startDate: null,
                                endDate: null,
                                salary: null,
                                payFrequency:null,
                                currentEmployer: null
                            }],
                            anyOtherPersonEmployedInUS:null,
                            haveYouEverEmployed:null,
                            lastArrivalDate:null,
                            stateOfLastEntryInUS: '',
                            stateDetailsOfLastEntryInUS: null,
                            placeOfLastEntryInUS: '',
                            h4Required: null,
                            name: '',
                            firstName: '',
                            middleName: '',
                            lastName: '',
                            dateOfBirth: null,
                            countryOfBirth: null,
                            countryOfBirthDetails: null,
                            provinceOfBirth: null,
                            provinceOfBirthDetails: null,
                            locationOfBirth: '',
                            locationOfBirthDetails: null,
                            countryOfCitizenship: null,
                            countryOfCitizenshipDetails: null,
                            passportIssuedCountry:null,
                            passportIssuedCountryDetails:null,
                            passportNumber: '',
                            passportExpiryNumber: null,
                            I94: '',
                            I94ExpiryNumber: null,
                            currentStatus: null,
                            statusExpiryNumber: null,
                            documents: {
                                passport: [],
                                visa: [],
                                formI94: [],
                                birthCertificate: [],
                                approvalNotice: [],
                                approvalNoticeOfPrevH4: [],
                                other: []
                            },
    
                             //i140
                             adjustmentOfI485Status: false, //Adjustment of Status (I-485) //{ type: Boolean, default: false },
                            consularProcessing:false,// Consular Processing { type: Boolean, default: false },
                        
                        }]
                    };
                    this.spouse = {
                            sevisNumber: null,
                            eadNumber: null,
                            isI94DSExpiryDate:false,
                            isDSExpiryDate:false,
                            anyOtherPersonEmployedInUS:null,
                            haveYouEverEmployed:null,
                            relationship: '',
                            saved: false,
                            currentlyInUS: null,
                            hasOtherNames: null, 
                            otherNames: [{
                                _id: 0,
                                name: '',
                                firstName: '',
                                middleName: '',
                                lastName: '',
                            }],
                            passportIssuedNumber: null,
                            alienNumber: '',
                            addressOutsideUS: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                            stateDetailsOfLastEntryInUS:null,
                            stateOfLastEntryInUS:null,
                            lastArrivalDate:null,
                            prevEmploymentInfo: [{
                                _id: 0,
                                employerName: '',
                                address: {
                                    line1: null,
                                    line2: null,
                                    aptType: null,
                                    locationId: null,
                                    locationDetails: null,
                                    stateId: null,
                                    stateDetails: null,
                                    countryId: null,
                                    countryDetails: null,
                                    zipcode: null
                                },
                                businessType: null,
                                jobTitle: null,
                                jobDuties: null,
                                startDate: null,
                                endDate: null,
                                salary: null,
                                payFrequency:null,
                                currentEmployer: null
                            }],
                            priorPeriodOfStayInUS: [{
                                _id: 0,
                                enteredNumber: null,
                                departedNumber: null,
                                dateerror: false,
                                noOfDays: null,
                                visaStatus: null
                            }],
    
                            h4Required: null,
                            h4EADRequired: null,
                            name: '',
                            firstName: '',
                            middleName: '',
                            lastName: '',
                            email: '',
                            cellPhoneNumber:'',
                    cellPhoneCountryCode: {
                        countryCode: '',
                        countryCallingCode: ''
                    },
                            phoneNumber: '',
                            phoneCountryCode: {
                                countryCode: '',
                                countryCallingCode: ''
                            },
                            dateOfBirth: null,
                            countryOfBirth: null,
                            countryOfBirthDetails: null,
                            provinceOfBirth: null,
                            provinceOfBirthDetails: null,
                            locationOfBirth: '',
                            locationOfBirthDetails: null,
                            countryOfCitizenship: null,
                            countryOfCitizenshipDetails: null,
                            passportNumber: '',
                            passportExpiryNumber: null,
                            passportIssuedCountry:null,
                            passportIssuedCountryDetails:null,
                            I94: '',
                            I94ExpiryNumber: null,
                            currentStatus: null,
                            currentStatusDetails: null,
                            statusExpiryNumber: null,
                            SSN: '',
                            lastArrivalNumber: null,
                            placeOfLastEntryInUS: '',
                            physicalAddress: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                            documents: {
                                passport: [],
                                visa: [],
                                formI94: [],
                                formI797: [],
                                formI20: [],
                                payStubs: [],
                                marriageCertificate: [],
                                noticeOfApprovalOfH1Status: [],
                                approvalNoticeOfPrevH4: [],
                                other: []
                            },
                            //i140
                            adjustmentOfI485Status: false, //Adjustment of Status (I-485) //{ type: Boolean, default: false },
                            consularProcessing:false,// Consular Processing { type: Boolean, default: false },
                        
    
                        }
                }
            },
            updateEducationDegree(val){
                if(val){
                    if(this.checkProperty(this.petition,'highestDegreeList') && this.checkProperty(this.petition,'highestDegreeList','length')>0 && this.checkProperty(this.petition,'beneficiaryInfo','educations') && this.checkProperty(this.petition['beneficiaryInfo'],'educations','length')>0 ){
                        this.petition.beneficiaryInfo.educations[0]['highestDegreeDetails'] = { "id": 6, "name": "Masters" };
                        this.petition.beneficiaryInfo.educations[0]['highestDegree'] = 6
                        // this.petition.beneficiaryInfo.educations[0]['attendedFrom'] = null
                        // this.petition.beneficiaryInfo.educations[0]['attendedTo'] = null 
                        // this.petition.beneficiaryInfo.educations[0]['graduatedYear'] = null
                        this.petition.beneficiaryInfo.educations[0]['address']['countryId'] = 231
                        this.petition.beneficiaryInfo.educations[0]['address']['countryDetails'] =  { "_id": "626a8f03a972fa4d60681140", "id": 231, "name": "United States", "phoneCode": 1, "order": 1, "currencySymbol": "$", "currencyCode": "USD", "zipcodeLength": 5, "sortName": "united states" }
                    }
                }
            },
            updateBenEducation(){
                if( this.checkProperty(this.petition,'beneficiaryInfo') && this.checkProperty(this.petition,'beneficiaryInfo','educations') && this.checkProperty(this.petition['beneficiaryInfo'],'educations','length')>0 &&
                  this.canRenderField('hasMasterDegreeInUS', this.questionnaireDetails ,false,'beneficiaryInfo')){
                    let mastDExists = _.find(this.petition['beneficiaryInfo']['educations'], { 'highestDegree': 6 });
                    if(mastDExists){
                        _.forEach(this.petition['beneficiaryInfo']['educations'],(item)=>{
                            if(_.has(item,'highestDegree') && this.checkProperty(item,'highestDegree') == 6){
                                if( _.has(this.petition['beneficiaryInfo'],'hasMasterDegreeInUS') && this.checkProperty(this.petition,'beneficiaryInfo','hasMasterDegreeInUS')){
                                    item['attendedFrom'] = null
                                    item['attendedTo'] = null
                                    item['graduatedYear'] = null 
                                    
                                }else{
                                    item['graduatedDate'] = null
                                }
                            }
                            else{
                                item['graduatedDate'] = null
                            }
                            
                        })
                    }
                    
                }
            },
            checkDSExpireFields(){
                if(this.checkProperty(this.petition,'beneficiaryInfo','curNonImmigrantVisaStatusDetails') && !this.checkProperty(this.petition['beneficiaryInfo'],'curNonImmigrantVisaStatusDetails','id') ){
                    this.petition.beneficiaryInfo.isDSExpiryDate = false;
                }
            },
            checkImmpetition(){
            },
            checkH1bImmPetitionsInfo(){
                if(this.canRenderField('anyImmPetitionFiled',this.questionnaireDetails,false ,'beneficiaryInfo') && _.has(this.petition['beneficiaryInfo'],'anyImmPetitionFiled') && !this.checkProperty(this.petition['beneficiaryInfo'],'anyImmPetitionFiled')  ){
                    this.petition['beneficiaryInfo']['h1bImmPetitionsInfo'] = [{
                        _id: 0,
                        typeId: null,
                        typeDetails: null,
                        receiptNo: '',
                        petitionerName: '',
                        validFrom:null,
                        validTo:null
                    }]
                }
            },
            checkDatesOfStayInUSA(){
                if(this.canRenderField('haveYouEverTravelledToUS',this.questionnaireDetails,false ,'beneficiaryInfo') && _.has(this.petition['beneficiaryInfo'],'haveYouEverTravelledToUS') && !this.checkProperty(this.petition['beneficiaryInfo'],'haveYouEverTravelledToUS')  ){
                    this.petition['beneficiaryInfo']['priorPeriodOfStayInUS'] = [{
                        _id: 0,
                        enteredNumber: null,
                        departedNumber: null,
                        visaStatus: null,
                        visaStatusDetails: null,
                        noOfDays: null,
                        dateerror: false
                    }]
                }
            },
            checkPrevEmployment(){
                if(this.canRenderField('anyOtherPersonEmployedInUS',this.questionnaireDetails,false ,'beneficiaryInfo') && _.has(this.petition['beneficiaryInfo'],'anyOtherPersonEmployedInUS') && !this.checkProperty(this.petition['beneficiaryInfo'],'anyOtherPersonEmployedInUS')  ){
                    this.petition['beneficiaryInfo']['prevEmploymentInfo'] = [{
                        _id: 0,
                        employerName: '',
                        address: {
                            line1: null,
                            line2: null,
                            aptType: null,
                            locationId: null,
                            locationDetails: null,
                            stateId: null,
                            stateDetails: null,
                            countryId: null,
                            countryDetails: null,
                            zipcode: null
                        },
                        businessType: null,
                        jobTitle: null,
                        jobDuties: null,
                        startDate: null,
                        endDate: null,
                        currentEmployer: false,
                        salary:null,
                        payFrequency:null,
                    }]
                }
            },
            mamageVisaStatusDocuments(){
               let tempDocs  =_.cloneDeep( this.bendocslist );
               this.bendocslist =[];
            let tpDocs = [
                {
                    required: false,
                    key: "formI797H4ApprovalNotice",
                    fieldName: 'formI797H4ApprovalNotice',
                    label: "Form I-797 H4 approval notice if applicable"
                },
                {
                    required: false,
                    key: "h4Ead",
                    fieldName: 'h4Ead',
                    label: "H4 EAD if applicable"
                },
                {
                    required: false,
                    key: "marriageCertificate",
                    fieldName: 'marriageCertificate',
                    label: "Marriage Certificate (if spouse is on H-1B, L-1, or F-1 status) "
                },
                {
                    required: false,
                    key: "formI797H1BApprovalNoticePrinNonCtzn",
                    fieldName: 'formI797H1BApprovalNoticePrinNonCtzn',
                    label: "Form I-797 H-1B approval notice of Principal Non-citizen"
                },
                {
                    required: false,
                    key: "passportOfPrinNonCtzn",
                    fieldName: 'passportOfPrinNonCtzn',
                    label: "Passport of Principal Non-citizen- First page with photo, Visa page and last page with address"
                },
                {
                    required: false,
                    key: "last3MonthsPayslipsOfPrinNonCtzn",
                    fieldName: 'last3MonthsPayslipsOfPrinNonCtzn',
                    label: "Last 3 months pay statements of Principal Non-citizen"
                },
            ];
         //5 ---H1b , H4---7
                if( this.checkProperty( this.petition,'beneficiaryInfo','curNonImmigrantVisaStatus') ==7){
                    _.forEach(tpDocs , (doc)=>{
                        let isExist = _.find(tempDocs ,{"key":doc['key']});
                        if(!isExist){
                            tempDocs.push(doc);
                        }

                    });
                }else{

                    // let isExist = _.find(tempDocs ,{"key":'marriageCertificate'});
                    // if(!isExist){

                    //     tempDocs.push( { required: false,  key: "marriageCertificate", fieldName: 'marriageCertificate', label: "Marriage Certificate (if spouse is on H-1B, L-1, or F-1 status) " });

                    // }
                   
                let its =['formI797H4ApprovalNotice','h4Ead','formI797H1BApprovalNoticePrinNonCtzn','passportOfPrinNonCtzn','last3MonthsPayslipsOfPrinNonCtzn'];
                    tempDocs = _.filter(tempDocs ,(item)=>its.indexOf(item['key'])<=-1);

                    //documents
                    _.forEach(this.petition.documents ,(documents ,category)=>{
                        if(its.indexOf(category)>-1){
                            this.petition.documents[category] = [];

                        }

                    });
                    

                } 

                this.bendocslist =[];
                this.bendocslist =tempDocs;
            },

            clearImmiputFields(){
                if(!this.checkProperty(this.petition,'beneficiaryInfo','anyImmPetitionFiled')){
                   
                    this.petition.beneficiaryInfo.immPetitionInfo = {
                        anyOtherAlienFiled: null,
                        filedNumber: null,
                        employerName: '',
                        rirOrRegularProcessing: null,
                        filedStateId: null,
                        filedStateDetails: null,
                        applCurStatus: '',
                        seekingFilednullforETA750: null,
                        anyI140Filed: null,
                        i140Info: {
                            fieldNumber: null,
                            employerName: '',
                            priorityNumber: null,
                            eb2orEb3: '',
                            currentStatus: ''
                        }
                    }
                }
            },

            callQuestionairePrefill(){
                this.updateBenEducation();
                this.checkCurrentlyInUsa();
                this.checkH1bImmPetitionsInfo();
                this.checkDatesOfStayInUSA();
                this.checkPrevEmployment();
                this.checkDependentsInfo();
            },
            formatFullname(item){
                let returnVal = ''
                if(this.checkProperty(item,'name')){
                    return returnVal = this.checkProperty(item,'name')
                }
                else{
                    if(this.checkProperty(item,'firstName')){
                        returnVal = this.checkProperty(item,'firstName')
                    }
                    if(this.checkProperty(item,'middleName')){
                         returnVal = returnVal +' '+ this.checkProperty(item,'middleName')
                    }
                    if(this.checkProperty(item,'lastName')){
                        returnVal =  returnVal +' '+this.checkProperty(item,'lastName')
                    }
                    return returnVal
                }
            },
            upload(fils,) {
           
           let  model =_.cloneDeep(fils);
           this.value =[];
           var _current = this;
           // this.$vs.loading();
     
           let efiles = [];
           efiles = _.filter(model, (e) => {
             return e.url != null && e.url != "";
           });
           let nfiles = _.filter(model, (e) => {
             return e.url == null || e.url == undefined;
           });
     
           let mapper = nfiles.map(
             (item) =>
               (item = {
                 name: item.name,
                 file: item.file ? item.file : null,
                 url: item.url ? item.url : "",
                 path: item.path ? item.path : "",
                 status: true,
                 mimetype: item.type ? item.type : item.mimetype,
               })  
           );
           let tempFiles = [];
           if (mapper.length > 0) {
             this.uploading = true;
             let count = 0;
             mapper.forEach((doc, index) => {
               let formData = new FormData();
               formData.append("files", doc.file);
               formData.append("secureType", "private");
               formData.append("getDetails", true);
               count++;
     
               this.$store.dispatch("uploadS3File", formData).then((response) => {
                 response.data.result.forEach((urlGenerated) => {
                   //alert(JSON.stringify(urlGenerated))
                   //  this.CommentPayload.documents.push(urlGenerated)
                  // if (  _.has(urlGenerated, "name") &&  tempFiles.indexOf(urlGenerated["name"]) <= -1 ) {
                    let tempUrl = urlGenerated
                    tempUrl = Object.assign(tempUrl, { uploadedBy: this.checkProperty(this.getUserData, 'userId'), uploadedByName: this.checkProperty(this.getUserData, 'name'), uploadedByRoleId: this.getUserRoleId, uploadedByRoleName: this.checkProperty(this.getUserData, 'loginRoleName') });
                     tempFiles.push(urlGenerated["name"]);
                     this.petition['beneficiaryInfo']['marriageCertDocs'].push(tempUrl);
                //   }
                   doc.url = urlGenerated;
                   doc.path = urlGenerated;
                   doc["mimetype"] = urlGenerated["mimetype"];
                   doc["type"] = urlGenerated["mimetype"];
                   delete doc.file;
                   mapper[index] = doc;
                 });
                 if (index >= mapper.length - 1) {
                   this.uploading = false;
                   // _current.$vs.loading.close();
                 }
               });
             });
             if (efiles.length > 0) efiles.push(...mapper);
             //this.CommentPayload["documents"] = efiles
           }
            },
            remove(item, data, filindex) {
                data.splice(filindex, 1);
            },
        
            changedAdjustmentOfI485Status(val){
              
            if(this.petition.beneficiaryInfo.adjustmentOfI485Status){
                this.petition.beneficiaryInfo.consularProcessing = false;
                
            }
               this.consularProcessingValidator ='';
               this.petition.beneficiaryInfo.applyI485AdjOrConsuProcess =false;
    
               if(this.petition.beneficiaryInfo.adjustmentOfI485Status || this.petition.beneficiaryInfo.consularProcessing){
                   this.consularProcessingValidator ='adjustmentOfI485Status';
                   this.petition.beneficiaryInfo.applyI485AdjOrConsuProcess =true;
               }
           
            },
          
            changedConsularProcessing(val){
           
              
              if(this.petition.beneficiaryInfo.consularProcessing){
                this.petition.beneficiaryInfo.adjustmentOfI485Status = false
              }
    
               this.consularProcessingValidator ='';
              
               if(this.petition.beneficiaryInfo.adjustmentOfI485Status || this.petition.beneficiaryInfo.consularProcessing){
                   this.consularProcessingValidator ='consularProcessingValidator';
                   this.petition.beneficiaryInfo.applyI485AdjOrConsuProcess =true;
               }
    
            },
           
            
            updatesocCode(item){ 
    
            if(_.has( item ,'id')){
                this.petition['jobDetails']['socCode'] = item['id'];
            }
            },
            getMasterSocList(){
    
                let query = {};
                query["page"] = 1;
                query["perpage"] = 10000;
                query["matcher"] = { 
                    // "getInactiveListAlso": true
                    };
                query["category"] = "soc_codes";
    
    
                this.$store
                .dispatch("getMasterData", query)
                .then((response) => {
                    this.masterSocList = response.list;
                
    
    
                //alert(this.perpage);
                })
                .catch(() => {
                this.masterSocList = [];
    
                });
    
            },
            setSameaddress(callFromChecckBox =true){
                
                    if( this.checkProperty(this.petition,'beneficiaryInfo','currentlyInUS') && this.canRenderField('mailingAddressIsSameAsAddress',this.questionnaireDetails, false, 'beneficiaryInfo' ) 
                && this.canRenderField('currentlyInUS',this.questionnaireDetails, false, 'beneficiaryInfo' ) && this.petition.beneficiaryInfo.mailingAddressIsSameAsAddress){
                        this.petition.beneficiaryInfo['currentAddress'] = _.cloneDeep(this.petition.beneficiaryInfo['address']);
                    }else{
    

                        if(callFromChecckBox){
                        this.petition.beneficiaryInfo['currentAddress'] =  {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                        }
                        this.$refs['mailingAddresscomponent'].clearStatesList();
                    }
    
                    }
    
               
                
    
            },
            updatecellPhoneCountryCode(data){
                this.petition.beneficiaryInfo.cellPhoneCountryCode =data;
               
            },
            updatehomePhoneCountryCode(data){
                this.petition.beneficiaryInfo.homePhoneCountryCode =data;
               
            },
            updateWorkPhoneCountryCode(data){
                this.petition.beneficiaryInfo.workPhoneCountryCode =data;
            },
            updateFaxCode(data){
                this.petition.beneficiaryInfo.faxCountryCode =data; 
            },
            clearCurrentStatusField(val){
                if(val){
                    this.petition.beneficiaryInfo.curVisaExpiryDate = null;
                }
            },
            clearI94Field(val){
                if(val){
                    this.petition.beneficiaryInfo.I94ExpiryDate = null;
                }
            },
            
            sethaveYouEverTravelledToUS(val){
                this.petition.beneficiaryInfo.haveYouEverTravelledToUS = val;
            },
            toggleSpouseForm() {
                if (this.spouse.saved) {
    
                } else {
                    this.spouse.h4Required = false
                    this.petition.dependentsInfo.spouse.h4Required = false;
                }
    
                // if (this.petition.dependentsInfo && this.petition.dependentsInfo.spouse.saved) {
    
                // } else {
                //     this.petition.dependentsInfo.spouse = {
                //         h4Required: false
                //     }
                // }
    
                this.spouseModalForm = false;
    
            },
            toggleChildForm() {
                var savedone = false;
                this.petition.dependentsInfo.childrens.forEach((element, index) => {
    
                    if (element.saved) {
                        savedone = true;
                    }
    
                });
                if (!savedone) {
                    this.petition.h4RequiredForChild = false;
                    this.petition.dependentsInfo.childrens[0] = {
                        h4Required: null
                    }
                }
    
                this.childModalForm = false;
            },
            editChildren(item, index) {
                this.childModalForm = true;
                this.selectedchild = index;
    
                         if(item){
                        var childocs = item.documents;
                        if(childocs && childocs.passport == null)  item.documents.passport =[];
                        if(childocs && childocs.visa == null)  item.documents.visa =[];
                        if(childocs && childocs.formI94 == null)  item.documents.formI94 =[];
                        if(childocs && childocs.birthCertificate == null)  item.documents.birthCertificate =[];
                        if(childocs && childocs.approvalNotice == null)  item.documents.approvalNotice =[];
                        if(childocs && childocs.approvalNoticeOfPrevH4 == null)  item.documents.approvalNoticeOfPrevH4 =[];
                        if(childocs && childocs.other == null)  item.documents.other =[];
                  }      
    
               
                this.$validator.reset();
            },
            submitChild() {
                this.$validator.validateAll("childInfoformmodal").then((result) => {
                    if (result) {
                        this.petition.dependentsInfo.childrens[this.selectedchild].saved = true;
                        this.petition.dependentsInfo.childrens[this.selectedchild].h4Required = true;
                        if(this.petition && this.petition.dependentsInfo && this.petition.dependentsInfo.childrens && this.petition.dependentsInfo.childrens[this.selectedchild] && this.canRenderField( 'anyOtherPersonEmployedInUS', this.questionnaireDetails ,false, 'dependentsInfo.childrens') &&    _.has(this.petition.dependentsInfo.childrens[this.selectedchild],'anyOtherPersonEmployedInUS') && !this.checkProperty(this.petition.dependentsInfo.childrens[this.selectedchild],'anyOtherPersonEmployedInUS')){
                            this.petition.dependentsInfo.childrens[this.selectedchild]['prevEmploymentInfo'] = [{
                                _id: 0,
                                employerName: '',
                                    address: {
                                    line1: null,
                                    line2: null,
                                    aptType: null,
                                    locationId: null,
                                    locationDetails: null,
                                    stateId: null,
                                    stateDetails: null,
                                    countryId: null,
                                    countryDetails: null,
                                    zipcode: null
                                },
                                businessType: null,
                                jobTitle: null,
                                jobDuties: null,
                                startDate: null,
                                endDate: null,
                                salary: null,
                                currentEmployer: null
                            }]
                        }
                        if(this.petition && this.petition.dependentsInfo && this.petition.dependentsInfo.childrens && this.petition.dependentsInfo.childrens[this.selectedchild] && !this.petition.dependentsInfo.childrens[this.selectedchild]['h4EADRequired'] ){
                            this.petition.dependentsInfo.childrens[this.selectedchild]['stateOfLastEntryInUS'] = null;
                            this.petition.dependentsInfo.childrens[this.selectedchild]['placeOfLastEntryInUS'] = null;
                            this.petition.dependentsInfo.childrens[this.selectedchild]['lastArrivalDate'] = null; 
                            this.petition.dependentsInfo.childrens[this.selectedchild]['stateDetailsOfLastEntryInUS'] = null;
                            this.petition.dependentsInfo.childrens[this.selectedchild]['anyOtherPersonEmployedInUS'] = false;
                            this.petition.dependentsInfo.childrens[this.selectedchild]['prevEmploymentInfo'] = [{
                                _id: 0,
                                employerName: '',
                                    address: {
                                    line1: null,
                                    line2: null,
                                    aptType: null,
                                    locationId: null,
                                    locationDetails: null,
                                    stateId: null,
                                    stateDetails: null,
                                    countryId: null,
                                    countryDetails: null,
                                    zipcode: null
                                },
                                businessType: null,
                                jobTitle: null,
                                jobDuties: null,
                                startDate: null,
                                endDate: null,
                                salary: null,
                                currentEmployer: null
                            }]
                        }
                        if(this.petition && this.petition.dependentsInfo && this.petition.dependentsInfo.childrens && this.petition.dependentsInfo.childrens[this.selectedchild] &&this.canRenderField('haveYouEverTravelledToUS',this.questionnaireDetails,false ,'dependentsInfo.childrens') && _.has(this.petition.dependentsInfo.childrens[this.selectedchild],'haveYouEverTravelledToUS') && !this.checkProperty(this.petition.dependentsInfo.childrens[this.selectedchild],'haveYouEverTravelledToUS')  ){
                            this.petition.dependentsInfo.childrens[this.selectedchild]['priorPeriodOfStayInUS'] = [{
                                _id: 0,
                                enteredNumber: null,
                                departedNumber: null,
                                visaStatus: null,
                                visaStatusDetails: null,
                                noOfDays: null,
                                dateerror: false
                            }]
                        }
                        if(this.canRenderField('currentlyInUS',this.questionnaireDetails, false, 'dependentsInfo.childrens' ) && _.has(this.petition.dependentsInfo.childrens[this.selectedchild],'currentlyInUS') && !this.checkProperty(this.petition.dependentsInfo.childrens[this.selectedchild],'currentlyInUS')){
                            this.petition.dependentsInfo.childrens[this.selectedchild]['currentStatusDetails'] = null
                            this.petition.dependentsInfo.childrens[this.selectedchild]['currentStatus']  = null
                            this.petition.dependentsInfo.childrens[this.selectedchild]['isDSExpiryDate'] = null
                            this.petition.dependentsInfo.childrens[this.selectedchild]['statusExpiryDate'] = null
                            this.petition.dependentsInfo.childrens[this.selectedchild]['I94'] = null
                            this.petition.dependentsInfo.childrens[this.selectedchild]['isI94DSExpiryDate'] = null
                            this.petition.dependentsInfo.childrens[this.selectedchild]['I94ExpiryDate'] = null
                            this.petition.dependentsInfo.childrens[this.selectedchild]['physicalAddress'] = {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            }
                        }
                        var childres = []
                        this.petition.dependentsInfo.childrens.forEach((element, index) => {
    
                            if (element.saved && element.firstName != '' && element.firstName != null) {
                                childres.push(element)
                            }
    
                        });
                        this.petition.dependentsInfo.childrens = childres;
                        this.saveCase(false, true)
                    } else{
                        const $ = JQuery;
                        if($('.text-danger:visible')){
                             $('.modal_cnt').scrollTop($('.text-danger:visible').first().parent().offset().top-30);
                        }
                    }
                  

                })
    
            },
            addchildren() {
                this.petition.h4RequiredForChild = true;
                this.childH4(true)
            },
            childH4(addmore = false) {
    
                var _child = this.getChildObject();
                
                if(this.petition.beneficiaryInfo && this.petition.beneficiaryInfo.hasAnyDependetsinUStoFileH4 && this.canRenderField('hasAnyDependetsinUStoFileH4', this.questionnaireDetails ,false,'beneficiaryInfo' )){
                    _child.currentlyInUS = true;
                    _child.haveYouEverTravelledToUS = true;
                    
                }
            
    
                if (addmore) {
    
                    var savedone = false;
                    this.petition.dependentsInfo.childrens.forEach((element, index) => {
    
                        if (element.saved) {
                            savedone = true;
                        }
    
                    });
    
                    if (savedone) {
                        /* If already saved children exists then push new object*/
                        var _childrens = this.petition.dependentsInfo.childrens;
                        _childrens.push(_child);
                        this.petition.dependentsInfo.childrens = _childrens;
                        this.petition.dependentsInfo.childrens[this.petition.dependentsInfo.childrens.length - 1].h4Required = false;
                        
                        this.selectedchild = this.petition.dependentsInfo.childrens.length - 1;
    
    
                        this.childModalForm = true;
                    } else {
                        var _childrens = [];
                        _childrens.push(_child)
                        this.petition.dependentsInfo.childrens = _childrens;
                        this.childModalForm = true;
                    }
    
                } else {
                    if (this.petition.h4RequiredForChild) {
                        this.addchildren()
                    } else {
                        this.childModalForm = false;
                        var _childrens = [];
                        _childrens.push(_child)
                        this.petition.dependentsInfo.childrens = _childrens;
                        this.petition.dependentsInfo.childrens[0].h4Required = false;
    
                    }
    
                }
    
                if (!this.petition.h4RequiredForChild) {
                    this.petition.dependentsInfo.childrens = []
                    this.petition.dependentsInfo.childrens.push(_child)
                }
    
    
            },
            spouseH4(){
                if(_.has(this.petition,'dependentsInfo') && this.checkProperty(this.petition,'dependentsInfo','spouse')){
                    let spouseDt = _.merge(this.spouse, this.petition.dependentsInfo.spouse);
                    this.spouse = spouseDt;
                }
                //this.spouse = _.cloneDeep(this.petition.dependentsInfo.spouse);
                        if(!_.has(this.spouse,'phoneCountryCode') || !this.checkProperty(this.spouse,'phoneCountryCode')){
                            this.spouse['phoneCountryCode'] = {
                                countryCode: '',
                                countryCallingCode: ''
                            }
                        }
                        if(!_.has(this.spouse,'prevEmploymentInfo') || !this.checkProperty(this.spouse,'prevEmploymentInfo')){
                            this.spouse['prevEmploymentInfo'] = [{
                                _id: 0,
                                employerName: '',
                                address: {
                                    line1: null,
                                    line2: null,
                                    aptType: null,
                                    locationId: null,
                                    locationDetails: null,
                                    stateId: null,
                                    stateDetails: null,
                                    countryId: null,
                                    countryDetails: null,
                                    zipcode: null
                                },
                                businessType: null,
                                jobTitle: null,
                                jobDuties: null,
                                startDate: null,
                                endDate: null,
                                salary: null,
                                currentEmployer: true
                            }]
                        }
                        if(!_.has(this.spouse,'fatherInfo') || !this.checkProperty(this.spouse,'fatherInfo')){
                            this.spouse['fatherInfo']= { 
                                name: '', 
                                firstName: '', 
                                middleName: '', 
                                lastName: '', 
                                hasOtherNames: null, 
                                otherNames: [{ 
                                    _id: 0, 
                                    name: '', 
                                    firstName: '', 
                                    middleName: '', 
                                    lastName: '', 
                                }], 
                                dateOfBirth: null, 
                                countryOfBirth: '', 
                                countryOfBirthDetails: null, 
                                provinceOfBirth: '', 
                                provinceOfBirthDetails: null, 
                                locationOfBirth: '', 
                                currentAddress: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                                isUSCitizen: null, 
                                dateFromUSCitizen: null, //["", ""],
                                nameAtBirth:{
                                    firstName: '', 
                                    middleName: '', 
                                    lastName: '',
                                },
                                deceasedCity: '',
                                deceasedCityDetails:null,
                                deceasedDate: null,
                            }
                        }
                        if(!_.has(this.spouse,'motherInfo') || !this.checkProperty(this.spouse,'motherInfo')){
                            this.spouse['motherInfo']= { 
                                name: '', 
                                firstName: '', 
                                middleName: '', 
                                lastName: '', 
                                hasOtherNames: null, 
                                otherNames: [{ 
                                    _id: 0, 
                                    name: '', 
                                    firstName: '', 
                                    middleName: '', 
                                    lastName: '', 
                                }], 
                                dateOfBirth: null, 
                                countryOfBirth: '', 
                                countryOfBirthDetails: null, 
                                provinceOfBirth: '', 
                                provinceOfBirthDetails: null, 
                                locationOfBirth: '', 
                                currentAddress: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                                isUSCitizen: null, 
                                dateFromUSCitizen: null, //["", ""],
                                nameAtBirth:{
                                    firstName: '', 
                                    middleName: '', 
                                    lastName: '',
                                },
                                deceasedCity: '',
                                deceasedCityDetails:null,
                                deceasedDate: null,
                            }
                        }
                        if((_.has(this.spouse,'height') && !this.checkProperty(this.spouse,'height')) || !_.has(this.spouse,'height')  ){
                            this.spouse['height']= {
                                feet: '',
                                inches: ''
                            }
                        }
                        if( (_.has(this.spouse,'associations') && !this.checkProperty(this.spouse,'associations')) || !_.has(this.spouse,'associations') ){
                           
                            this.spouse['associations']= [{
                                name:'', 
                                address:{
                                    locationId: null,
                                    locationDetails: null,
                                    stateId: null,
                                    stateDetails: null,
                                    countryId: null,
                                    countryDetails: null,
                                },
                                startDate: null,
                                endDate:null,
                                natureofAssociations:'',
                            }]
                        }

                        if(!_.has(this.spouse,'prevEmploymentOutsideUS') || !this.checkProperty(this.spouse,'prevEmploymentOutsideUS')){
                            this.spouse['prevEmploymentOutsideUS'] = [{
                                _id: 0,
                                employerName: '',
                                address: {
                                    line1: null,
                                    line2: null,
                                    aptType: null,
                                    locationId: null,
                                    locationDetails: null,
                                    stateId: null,
                                    stateDetails: null,
                                    countryId: null,
                                    countryDetails: null,
                                    zipcode: null
                                },
                                businessType: null,
                                jobTitle: null,
                                jobDuties: null,
                                startDate: null,
                                endDate: null,
                                currentEmployer: null  
                            }]
                        }
                        if(!_.has(this.spouse,'previousSpouse') || !this.checkProperty(this.spouse,'previousSpouse')){
                            this.spouse['previousSpouse'] = {
                            hasOtherNames:null,
                            otherNames: [{
                                _id: 0,
                                name: '',
                                firstName: '',
                                middleName: '',
                                lastName: '',
                            }],
                            maidenName:'',
                            marriageEndedDueTo:null,
                            marriageEndedOtherInfo:'',
                            firstName: '',
                            middleName: '',
                            lastName: '',
                            dateOfBirth: null,
                            dateOfMarriage:null,
                            dateOfMarriageEnd:null,
    
                              //Place of Marriage
                            countryOfMarriage: '',
                            countryOfMarriageDetails: null,
                            provinceOfMarriage: '',
                            provinceOfMarriageDetails: null,
                            locationOfMarriage: '',
    
                            //Place of Termination
                            countryOfMarriageTermination: '',
                            countryOfMarriageTerminationDetails: null,
                            provinceOfMarriageTermination: '',
                            provinceOfMarriageTerminationDetails: null,
                            locationOfMarriageTermination: '',
                            obtainPermResidenceThroughSpouse:null  
                          
                            }
                        }
                        if(!_.has(this.spouse,'addressOfLastNYears') || !this.checkProperty(this.spouse,'addressOfLastNYears')){
                            this.spouse['addressOfLastNYears'] = [{
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null,
                                startDate: null,
                                endDate: null,
                        }]
                        }
                        if(!_.has(this.spouse,'addressOutsideUSMoreThanYear') || !this.checkProperty(this.spouse,'addressOutsideUSMoreThanYear')){
                            this.spouse['addressOutsideUSMoreThanYear'] = [{
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null,
                                startDate: null,
                                endDate: null,
                        }]
                        }
                        this.spouseModalForm = true;
            },
            spouseH4444() {
                let _spouse= {
                            sevisNumber: null,
                            eadNumber: null,
                            haveYouEverTravelledToUS:null,
                            isDSExpiryDate:false,
                            isI94DSExpiryDate:false,
                            relationship: '',
                            saved: false,
                            currentlyInUS: null,
                            hasOtherNames: null, 
                            otherNames: [{
                                _id: 0,
                                name: '',
                                firstName: '',
                                middleName: '',
                                lastName: '',
                            }],
                            passportIssuedNumber: null,
                            alienNumber: '',
                            prevEmploymentInfo: [{
                                _id: 0,
                                employerName: '',
                                address: {
                                    line1: null,
                                    line2: null,
                                    aptType: null,
                                    locationId: null,
                                    locationDetails: null,
                                    stateId: null,
                                    stateDetails: null,
                                    countryId: null,
                                    countryDetails: null,
                                    zipcode: null
                                },
                                businessType: null,
                                jobTitle: null,
                                jobDuties: null,
                                startDate: null,
                                endDate: null,
                                payFrequency:null,
                                salary: null,
                                currentEmployer: null
                            }],
                            addressOutsideUS: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                            priorPeriodOfStayInUS: [{
                                _id: 0,
                                enteredNumber: null,
                                departedNumber: null,
                                dateerror: false,
                                noOfDays: null,
                                visaStatus: null
                            }],
                            dateFromWhichResideInUs:null,
                            caseIssuedDate: null,
                            caseExpiryDate: null,
                            placeOfCaseIssued: '',
                            mailingAddressIsSameAsAddress:false,
                            stateOfLastEntryInUS: '',
                            stateDetailsOfLastEntryInUS: null,
                            placeOfLastEntryInUS: '',
                            firstArrivalDate: null,
                            lastArrivalDate: null,
                            allIssuedpassportData: [{
                                countryId: '',
                                countryDetails: null,
                                number: '',
                                issuedDate: null,
                                expiryDate: null 
                            }],
                            currentAddress: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                            height: {
                            feet: '',
                            inches: ''
                            },
                            weight: '',
                            race: null,
                            eyeColor:null,
                            hairColor: null,
                            educations: [{
                            _id: 0,
                            name: null,
                            address: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                            highestDegree: null,
                            highestDegreeDetails: null,
                            majorFieldOfStudy: null,
                            attendedFrom: null,
                            attendedTo: null,
                            graduatedYear: null,
                            degreereceived: null,
                            isAccredited: null,
                            isForProfit: null
                            }],
                            prevEmploymentInfo: [{
                            _id: 0,
                            employerName: '',
                            address: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                            businessType: null,
                            jobTitle: null,
                            jobDuties: null,
                            startDate: null,
                            endDate: null,
                            currentEmployer: null
                            }],
                            prevEmploymentOutsideUS:[{
                                _id: 0,
                                employerName: '',
                                address: {
                                    line1: null,
                                    line2: null,
                                    aptType: null,
                                    locationId: null,
                                    locationDetails: null,
                                    stateId: null,
                                    stateDetails: null,
                                    countryId: null,
                                    countryDetails: null,
                                    zipcode: null
                                },
                                businessType: null,
                                jobTitle: null,
                                jobDuties: null,
                                startDate: null,
                                endDate: null,
                                currentEmployer: null  
                            }],
                            previousSpouse:{
                            hasOtherNames:null,
                            otherNames: [{
                                _id: 0,
                                name: '',
                                firstName: '',
                                middleName: '',
                                lastName: '',
                            }],
                            maidenName:'',
                            marriageEndedDueTo:null,
                            marriageEndedOtherInfo:'',
                            firstName: '',
                            middleName: '',
                            lastName: '',
                            dateOfBirth: null,
                            dateOfMarriage:null,
                            dateOfMarriageEnd:null,
    
                              //Place of Marriage
                            countryOfMarriage: '',
                            countryOfMarriageDetails: null,
                            provinceOfMarriage: '',
                            provinceOfMarriageDetails: null,
                            locationOfMarriage: '',
    
                            //Place of Termination
                            countryOfMarriageTermination: '',
                            countryOfMarriageTerminationDetails: null,
                            provinceOfMarriageTermination: '',
                            provinceOfMarriageTerminationDetails: null,
                            locationOfMarriageTermination: '',
                            obtainPermResidenceThroughSpouse:null  
                          
                            },
                            addressOfLastNYears:[{
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null,
                                startDate: null,
                                endDate: null,
                            }], 
                            addressOutsideUSMoreThanYear:[{
                            
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null,
                                startDate: null,
                                endDate: null,
                            }],
                            dateOfLastEntryInUS:null,
                            dateOfMarriage: null, 
                            dateOfMarriageEnd: null, 
                            countryOfMarriage: '', 
                            countryOfMarriageDetails: null, 
                            provinceOfMarriage: '', 
                            provinceOfMarriageDetails: null, 
                            locationOfMarriage: '',
                            currentSpouseName: '',
                            maritalStatus : '', 
                            maritalStatusDetails: null,
                            curNonImmigrantVisaStatus: '', 
                            associations:[ {
                                name:'', 
                                address:{
                                    locationId: null,
                                    locationDetails: null,
                                    stateId: null,
                                    stateDetails: null,
                                    countryId: null,
                                    countryDetails: null,
                                },
                                startDate: null,
                                endDate:null,
                                natureofAssociations:'',
                            }],
                            everAppliedAOSInUS: null, 
                            appliedAOSInUSDocs:[],
                            haveYouArrestedBefore:null,
                            haveYouArrestedBeforeDocs:[], 
                            doesBirthRegistered:null, 
                            curNonImmigrantVisaNumber:'',
                            inspectedByAnyImmOfficer: null, 
                            issuedAnyEADFromUSCIS: null, 
                            hasPermResidencyInOtherCountry: null, 
                            permResidencyCountryId: '', 
                            passportIssuedDate: null,
                            permResidencyCountryDetails: null,
                            

                            h4Required: null,
                            h4EADRequired: null,
                            name: '',
                            firstName: '',
                            middleName: '',
                            lastName: '',
                            email: '',
                            phoneNumber: '',
                            phoneCountryCode: {
                                countryCode: '',
                                countryCallingCode: ''
                            },
                            dateOfBirth: null,
                            countryOfBirth: null,
                            countryOfBirthDetails: null,
                            provinceOfBirth: null,
                            provinceOfBirthDetails: null,
                            locationOfBirth: '',
                            locationOfBirthDetails: null,
                            countryOfCitizenship: null,
                            countryOfCitizenshipDetails: null,
                            passportNumber: '',
                            passportExpiryNumber: null,
                            passportIssuedCountry:null,
                            passportIssuedCountryDetails:null,
                            I94: '',
                            I94ExpiryNumber: null,
                            currentStatus: null,
                            currentStatusDetails: null,
                            statusExpiryNumber: null,
                            SSN: '',
                            lastArrivalNumber: null,
                            placeOfLastEntryInUS: '',
                            applyingWithYou:null,
                            nameDiffFromBirthCert:null,
                            physicalAddress: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                            fatherInfo: { 
                                name: '', 
                                firstName: '', 
                                middleName: '', 
                                lastName: '', 
                                hasOtherNames: null, 
                                otherNames: [{ 
                                    _id: 0, 
                                    name: '', 
                                    firstName: '', 
                                    middleName: '', 
                                    lastName: '', 
                                }], 
                                dateOfBirth: null, 
                                countryOfBirth: '', 
                                countryOfBirthDetails: null, 
                                provinceOfBirth: '', 
                                provinceOfBirthDetails: null, 
                                locationOfBirth: '', 
                                currentAddress: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                                isUSCitizen: null, 
                                dateFromUSCitizen: null, //["", ""],
                                nameAtBirth:{
                                    firstName: '', 
                                    middleName: '', 
                                    lastName: '',
                                },
                                deceasedCity: '',
                                deceasedCityDetails:null,
                                deceasedDate: null,
                            },
                            motherInfo: { 
                                name: '',                    
                                firstName: '', 
                                middleName: '', 
                                lastName: '', 
                                hasOtherNames: null , 
                                otherNames: [{ 
                                    _id: 0, 
                                    name: '', 
                                    firstName: '', 
                                    middleName: '', 
                                    lastName: '', 
                                }], 
                                dateOfBirth: null, 
                                countryOfBirth: '', 
                                countryOfBirthDetails: null, 
                                provinceOfBirth: '', 
                                provinceOfBirthDetails: null, 
                                locationOfBirth: '', 
                                currentAddress: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                                },
                                isUSCitizen: null, 
                                dateFromUSCitizen:null,// ["", ""],
                                nameAtBirth:{
                                    firstName: '', 
                                    middleName: '', 
                                    lastName: '',
                                },
                                deceasedCity: '',
                                deceasedCityDetails:null,
                                deceasedDate: null,
                            }, 
                            documents: {
                                passport: [],
                                visa: [],
                                formI94: [],
                                formI797: [],
                                formI20: [],
                                payStubs: [],
                                marriageCertificate: [],
                                noticeOfApprovalOfH1Status: [],
                                approvalNoticeOfPrevH4: [],
                                other: []
                            },
                            //i140
                            adjustmentOfI485Status: false, //Adjustment of Status (I-485) //{ type: Boolean, default: false },
                            consularProcessing:false,// Consular Processing { type: Boolean, default: false },
                        
    
                        };
                if(this.petition.beneficiaryInfo && this.petition.beneficiaryInfo.hasAnyDependetsinUStoFileH4 && this.canRenderField('hasAnyDependetsinUStoFileH4', this.questionnaireDetails ,false,'beneficiaryInfo' )){
                    _spouse.currentlyInUS = true;
                    _spouse.haveYouEverTravelledToUS = true;
                }
                let addBenificiaryAdd = false;
                _.forEach(_spouse['physicalAddress'],(item)=>{
                    if(item != null ){
                        addBenificiaryAdd = true;
                       return false;
                    }
                })
                if(!addBenificiaryAdd){
                    _spouse['physicalAddress'] = _.cloneDeep(this.petition.beneficiaryInfo.address)
                }
                if (this.petition.dependentsInfo.spouse.h4Required) { 
                
                    if(this.latestPetition && _.has(this.latestPetition,'dependentsInfo') && this.checkProperty(this.latestPetition,'dependentsInfo') && this.checkProperty(this.latestPetition,'dependentsInfo','spouse')
                         && this.checkProperty(this.latestPetition['dependentsInfo'],'spouse','firstName') && this.prefillAction){
                            // var data = _.merge(this.spouse, this.latestPetition.dependentsInfo.spouse);
                            // this.spouse = data
                            
                        this.spouse = _.cloneDeep(this.latestPetition.dependentsInfo.spouse);
                       
                        if(!_.has(this.spouse,'prevEmploymentInfo') || !this.checkProperty(this.spouse,'prevEmploymentInfo')){
                            this.spouse['prevEmploymentInfo'] = [{
                                _id: 0,
                                employerName: '',
                                address: {
                                    line1: null,
                                    line2: null,
                                    aptType: null,
                                    locationId: null,
                                    locationDetails: null,
                                    stateId: null,
                                    stateDetails: null,
                                    countryId: null,
                                    countryDetails: null,
                                    zipcode: null
                                },
                                businessType: null,
                                jobTitle: null,
                                jobDuties: null,
                                startDate: null,
                                endDate: null,
                                salary: null,
                                currentEmployer: true
                            }]
                        }
                        if(!_.has(this.spouse,'fatherInfo') || !this.checkProperty(this.spouse,'fatherInfo')){
                            this.spouse['fatherInfo']= { 
                                name: '', 
                                firstName: '', 
                                middleName: '', 
                                lastName: '', 
                                hasOtherNames: null, 
                                otherNames: [{ 
                                    _id: 0, 
                                    name: '', 
                                    firstName: '', 
                                    middleName: '', 
                                    lastName: '', 
                                }], 
                                dateOfBirth: null, 
                                countryOfBirth: '', 
                                countryOfBirthDetails: null, 
                                provinceOfBirth: '', 
                                provinceOfBirthDetails: null, 
                                locationOfBirth: '', 
                                currentAddress: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                                isUSCitizen: null, 
                                dateFromUSCitizen: null, //["", ""],
                                nameAtBirth:{
                                    firstName: '', 
                                    middleName: '', 
                                    lastName: '',
                                },
                                deceasedCity: '',
                                deceasedCityDetails:null,
                                deceasedDate: null,
                            }
                        }
                        if(!_.has(this.spouse,'motherInfo') || !this.checkProperty(this.spouse,'motherInfo')){
                            this.spouse['motherInfo']= { 
                                name: '', 
                                firstName: '', 
                                middleName: '', 
                                lastName: '', 
                                hasOtherNames: null, 
                                otherNames: [{ 
                                    _id: 0, 
                                    name: '', 
                                    firstName: '', 
                                    middleName: '', 
                                    lastName: '', 
                                }], 
                                dateOfBirth: null, 
                                countryOfBirth: '', 
                                countryOfBirthDetails: null, 
                                provinceOfBirth: '', 
                                provinceOfBirthDetails: null, 
                                locationOfBirth: '', 
                                currentAddress: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                                isUSCitizen: null, 
                                dateFromUSCitizen: null, //["", ""],
                                nameAtBirth:{
                                    firstName: '', 
                                    middleName: '', 
                                    lastName: '',
                                },
                                deceasedCity: '',
                                deceasedCityDetails:null,
                                deceasedDate: null,
                            }
                        }
                        if((_.has(this.spouse,'height') && !this.checkProperty(this.spouse,'height')) || !_.has(this.spouse,'height')  ){
                            this.spouse['height']= {
                                feet: '',
                                inches: ''
                            }
                        }
                        if( (_.has(this.spouse,'associations') || !this.checkProperty(this.spouse,'associations')) || !_.has(this.spouse,'associations') ){
                            this.spouse['associations']= [{
                                name:'', 
                                address:{
                                    locationId: null,
                                    locationDetails: null,
                                    stateId: null,
                                    stateDetails: null,
                                    countryId: null,
                                    countryDetails: null,
                                },
                                startDate: null,
                                endDate:null,
                                natureofAssociations:'',
                            }]
                        }

                        if(!_.has(this.spouse,'prevEmploymentOutsideUS') || !this.checkProperty(this.spouse,'prevEmploymentOutsideUS')){
                            this.spouse['prevEmploymentOutsideUS'] = [{
                                _id: 0,
                                employerName: '',
                                address: {
                                    line1: null,
                                    line2: null,
                                    aptType: null,
                                    locationId: null,
                                    locationDetails: null,
                                    stateId: null,
                                    stateDetails: null,
                                    countryId: null,
                                    countryDetails: null,
                                    zipcode: null
                                },
                                businessType: null,
                                jobTitle: null,
                                jobDuties: null,
                                startDate: null,
                                endDate: null,
                                currentEmployer: null  
                            }]
                        }
                        if(!_.has(this.spouse,'previousSpouse') || !this.checkProperty(this.spouse,'previousSpouse')){
                            this.spouse['previousSpouse'] = {
                            hasOtherNames:null,
                            otherNames: [{
                                _id: 0,
                                name: '',
                                firstName: '',
                                middleName: '',
                                lastName: '',
                            }],
                            maidenName:'',
                            marriageEndedDueTo:null,
                            marriageEndedOtherInfo:'',
                            firstName: '',
                            middleName: '',
                            lastName: '',
                            dateOfBirth: null,
                            dateOfMarriage:null,
                            dateOfMarriageEnd:null,
    
                              //Place of Marriage
                            countryOfMarriage: '',
                            countryOfMarriageDetails: null,
                            provinceOfMarriage: '',
                            provinceOfMarriageDetails: null,
                            locationOfMarriage: '',
    
                            //Place of Termination
                            countryOfMarriageTermination: '',
                            countryOfMarriageTerminationDetails: null,
                            provinceOfMarriageTermination: '',
                            provinceOfMarriageTerminationDetails: null,
                            locationOfMarriageTermination: '',
                            obtainPermResidenceThroughSpouse:null  
                          
                            }
                        }
                        if(!_.has(this.spouse,'addressOfLastNYears') || !this.checkProperty(this.spouse,'addressOfLastNYears')){
                            this.spouse['addressOfLastNYears'] = [{
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null,
                                startDate: null,
                                endDate: null,
                        }]
                        }
                        if(!_.has(this.spouse,'addressOutsideUSMoreThanYear') || !this.checkProperty(this.spouse,'addressOutsideUSMoreThanYear')){
                            this.spouse['addressOutsideUSMoreThanYear'] = [{
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null,
                                startDate: null,
                                endDate: null,
                        }]
                        }
                    }
                    else if(this.petition && _.has(this.petition,'dependentsInfo') && this.checkProperty(this.petition,'dependentsInfo') && this.checkProperty(this.petition,'dependentsInfo','spouse')
                        && this.checkProperty(this.petition['dependentsInfo'],'spouse','firstName') && this.prefillAction == false ){
                        this.spouse = _.cloneDeep(this.petition.dependentsInfo.spouse);
                        if(!_.has(this.spouse,'prevEmploymentInfo') || !this.checkProperty(this.spouse,'prevEmploymentInfo')){
                            this.spouse['prevEmploymentInfo'] = [{
                                _id: 0,
                                employerName: '',
                                address: {
                                    line1: null,
                                    line2: null,
                                    aptType: null,
                                    locationId: null,
                                    locationDetails: null,
                                    stateId: null,
                                    stateDetails: null,
                                    countryId: null,
                                    countryDetails: null,
                                    zipcode: null
                                },
                                businessType: null,
                                jobTitle: null,
                                jobDuties: null,
                                startDate: null,
                                endDate: null,
                                salary: null,
                                currentEmployer: true
                            }]
                        }
                        if(!_.has(this.spouse,'fatherInfo') || !this.checkProperty(this.spouse,'fatherInfo')){
                         
                            this.spouse['fatherInfo']= { 
                                name: '', 
                                firstName: '', 
                                middleName: '', 
                                lastName: '', 
                                hasOtherNames: null, 
                                otherNames: [{ 
                                    _id: 0, 
                                    name: '', 
                                    firstName: '', 
                                    middleName: '', 
                                    lastName: '', 
                                }], 
                                dateOfBirth: null, 
                                countryOfBirth: '', 
                                countryOfBirthDetails: null, 
                                provinceOfBirth: '', 
                                provinceOfBirthDetails: null, 
                                locationOfBirth: '', 
                                currentAddress: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                                isUSCitizen: null, 
                                dateFromUSCitizen: null, //["", ""],
                                nameAtBirth:{
                                    firstName: '', 
                                    middleName: '', 
                                    lastName: '',
                                },
                                deceasedCity: '',
                                deceasedCityDetails:null,
                                deceasedDate: null,
                            }
                        }
                        if(!_.has(this.spouse,'motherInfo') || !this.checkProperty(this.spouse,'motherInfo')){
                            this.spouse['motherInfo']= { 
                                name: '', 
                                firstName: '', 
                                middleName: '', 
                                lastName: '', 
                                hasOtherNames: null, 
                                otherNames: [{ 
                                    _id: 0, 
                                    name: '', 
                                    firstName: '', 
                                    middleName: '', 
                                    lastName: '', 
                                }], 
                                dateOfBirth: null, 
                                countryOfBirth: '', 
                                countryOfBirthDetails: null, 
                                provinceOfBirth: '', 
                                provinceOfBirthDetails: null, 
                                locationOfBirth: '', 
                                currentAddress: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                                isUSCitizen: null, 
                                dateFromUSCitizen: null, //["", ""],
                                nameAtBirth:{
                                    firstName: '', 
                                    middleName: '', 
                                    lastName: '',
                                },
                                deceasedCity: '',
                                deceasedCityDetails:null,
                                deceasedDate: null,
                            }
                        }
                        if((_.has(this.spouse,'height') && !this.checkProperty(this.spouse,'height')) || !_.has(this.spouse,'height')  ){
                            this.spouse['height']= {
                                feet: '',
                                inches: ''
                            }
                        }
                       
                        if(!_.has(this.spouse,'associations') || !this.checkProperty(this.spouse,'associations') ){
                            
                            this.spouse['associations']= [ {
                                name:'', 
                                address:{
                                    locationId: null,
                                    locationDetails: null,
                                    stateId: null,
                                    stateDetails: null,
                                    countryId: null,
                                    countryDetails: null,
                                },
                                startDate: null,
                                endDate:null,
                                natureofAssociations:'',
                            }]
                        }
                        if(!_.has(this.spouse,'addressOfLastNYears') || !this.checkProperty(this.spouse,'addressOfLastNYears')){
                            this.spouse['addressOfLastNYears'] = [{
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null,
                                startDate: null,
                                endDate: null,
                            }]
                        }
                        if(!_.has(this.spouse,'addressOutsideUSMoreThanYear') || !this.checkProperty(this.spouse,'addressOutsideUSMoreThanYear')){
                            this.spouse['addressOutsideUSMoreThanYear'] = [{
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null,
                                startDate: null,
                                endDate: null,
                            }]
                        }
                    }
                    else{
                       
                        this.spouse = _spouse;
                    }
                    
                    this.spouseModalForm = true;
    
                } else {
                    this.spouseModalForm = false;
                    this.spouse = _spouse;
                    this.petition.dependentsInfo.spouse  = _spouse;
                    this.petition.dependentsInfo.spouse.h4Required = false;
    
                }
                
            },
            editSpouse(item) {
                  if(item){
                        var childocs = item.documents;
                        if(childocs && childocs.passport == null)  item.documents.passport =[];
                        if(childocs && childocs.visa == null)  item.documents.visa =[];
                        if(childocs && childocs.formI94 == null)  item.documents.formI94 =[];
                        if(childocs && childocs.formI797 == null)  item.documents.formI797 =[];
                        if(childocs && childocs.formI20 == null)  item.documents.formI20 =[];
                        if(childocs && childocs.marriageCertificate == null)  item.documents.marriageCertificate =[];
                        if(childocs && childocs.noticeOfApprovalOfH1Status == null)  item.documents.noticeOfApprovalOfH1Status =[];
                        if(childocs && childocs.approvalNoticeOfPrevH4 == null)  item.documents.approvalNoticeOfPrevH4 =[];
                        if(childocs && childocs.other == null)  item.documents.other =[];
    
                }      
    
                this.spouseModalForm = true;
                this.$validator.reset();
            },
            checkMarriageCerti(){
                if(this.petition.beneficiaryInfo && this.petition.beneficiaryInfo.maritalStatusDetails && this.petition.beneficiaryInfo.maritalStatusDetails.id !=1){
                    let isExist = _.find(this.bendocslist ,{"key":'marriageCertificate'});
                    if(!isExist){
                        this.bendocslist.push( { required: false,  key: "marriageCertificate", fieldName: 'marriageCertificate', label: "Marriage Certificate (if spouse is on H-1B, L-1, or F-1 status) " });
                    }

                    let bnfSpouseLatestI797Exist = _.find(this.bendocslist ,{"key":'bnfSpouseLatestI797'});
                    if(!bnfSpouseLatestI797Exist){
                        this.bendocslist.push( { required: false,  key: "bnfSpouseLatestI797", fieldName: 'bnfSpouseLatestI797', label: "Latest I-797, Notice of Approval of the spouse (if spouse is on H-1B or L-1 status)" });
                    }

                    let bnfSpousePassportExist = _.find(this.bendocslist ,{"key":'bnfSpousePassport'});
                    if(!bnfSpousePassportExist){
                        this.bendocslist.push( { required: false,  key: "bnfSpousePassport", fieldName: 'bnfSpousePassport', label: "Spouse’s Passport- First page with photo, Visa page and last page with address" });
                    }

                    let bnfSpouseRecentPayStubsExist = _.find(this.bendocslist ,{"key":'bnfSpouseRecentPayStubs'});
                    if(!bnfSpouseRecentPayStubsExist){
                        this.bendocslist.push( { required: false,  key: "bnfSpouseRecentPayStubs", fieldName: 'bnfSpouseRecentPayStubs', label: "Three recent pay stubs (if spouse is on H-1B or L-1 status)" });
                    }

                    let bnfSpouseFormAllI20ExistExist = _.find(this.bendocslist ,{"key":'bnfSpouseFormAllI20'});
                    if(!bnfSpouseFormAllI20ExistExist){
                        this.bendocslist.push( { required: false,  key: "bnfSpouseFormAllI20", fieldName: 'bnfSpouseFormAllI20', label: "Spouse’s all Form I-20s (if spouse is on F-1 status)" });
                    }
                }else{
                    let isExist = _.find(this.bendocslist ,{"key":'marriageCertificate'});
                    if(isExist){
                        this.bendocslist.splice(this.bendocslist.indexOf(isExist),1)
                        if(_.has(this.petition['documents'],'marriageCertificate')){
                            this.petition.documents['marriageCertificate'] = [];
                        }                 
                    }


                    let bnfSpouseLatestI797Exist = _.find(this.bendocslist ,{"key":'bnfSpouseLatestI797'});
                    if(bnfSpouseLatestI797Exist){
                        this.bendocslist.splice(this.bendocslist.indexOf(bnfSpouseLatestI797Exist),1)
                        if(_.has(this.petition['documents'],'bnfSpouseLatestI797')){
                            this.petition.documents['bnfSpouseLatestI797'] = [];
                        }                 
                    }


                    let bnfSpousePassportExist = _.find(this.bendocslist ,{"key":'bnfSpousePassport'});
                    if(bnfSpousePassportExist){
                        this.bendocslist.splice(this.bendocslist.indexOf(bnfSpousePassportExist),1)
                        if(_.has(this.petition['documents'],'bnfSpousePassport')){
                            this.petition.documents['bnfSpousePassport'] = [];
                        }                 
                    }


                    let bnfSpouseRecentPayStubsExist = _.find(this.bendocslist ,{"key":'bnfSpouseRecentPayStubs'});
                    if(bnfSpouseRecentPayStubsExist){
                        this.bendocslist.splice(this.bendocslist.indexOf(bnfSpouseRecentPayStubsExist),1)
                        if(_.has(this.petition['documents'],'bnfSpouseRecentPayStubs')){
                            this.petition.documents['bnfSpouseRecentPayStubs'] = [];
                        }                 
                    }


                    let bnfSpouseFormAllI20Exist = _.find(this.bendocslist ,{"key":'bnfSpouseFormAllI20'});
                    if(bnfSpouseFormAllI20Exist){
                        this.bendocslist.splice(this.bendocslist.indexOf(bnfSpouseFormAllI20Exist),1)
                        if(_.has(this.petition['documents'],'bnfSpouseFormAllI20')){
                            this.petition.documents['bnfSpouseFormAllI20'] = [];
                        }                 
                    }








                }
                this.removeMarriageDocs()
            },
            removeMarriageDocs(){
                if( (this.petition.beneficiaryInfo && this.petition.beneficiaryInfo.maritalStatusDetails && this.petition.beneficiaryInfo.maritalStatusDetails.id ==1)
                    || (this.checkProperty( this.petition,'beneficiaryInfo','curNonImmigrantVisaStatus') && this.checkProperty( this.petition,'beneficiaryInfo','curNonImmigrantVisaStatus')!=7)){
                    let isExist = _.find(this.bendocslist ,{"key":'marriageCertificate'});
                    if(isExist){
                        this.bendocslist.splice(this.bendocslist.indexOf(isExist),1)
                        if(_.has(this.petition['documents'],'marriageCertificate')){
                            this.petition.documents['marriageCertificate'] = [];
                        }                 
                    }
                }
            },
            submitSpouse() {
                this.$validator.validateAll("dependentsInfoformmodal").then((result) => {
                    if (result ) {
                        //this.spouse.saved = true;
                        if( (this.canRenderField( 'anyOtherPersonEmployedInUS', this.questionnaireDetails ,false, 'dependentsInfo.spouse') && _.has(this.spouse,'anyOtherPersonEmployedInUS') && !this.checkProperty(this.spouse,'anyOtherPersonEmployedInUS'))){
                            this.spouse['prevEmploymentInfo'] = [{
                                _id: 0,
                                employerName: '',
                                address: {
                                    line1: null,
                                    line2: null,
                                    aptType: null,
                                    locationId: null,
                                    locationDetails: null,
                                    stateId: null,
                                    stateDetails: null,
                                    countryId: null,
                                    countryDetails: null,
                                    zipcode: null
                                },
                                businessType: null,
                                jobTitle: null,
                                jobDuties: null,
                                startDate: null,
                                endDate: null,
                                salary: null,
                                currentEmployer: true
                            }]
                        }
                        if(!this.spouse['h4EADRequired']){
                            this.spouse['stateOfLastEntryInUS'] = null;
                            this.spouse['placeOfLastEntryInUS'] = null;
                            this.spouse['lastArrivalDate'] = null; 
                            this.spouse['stateDetailsOfLastEntryInUS'] = null;
                            this.spouse['anyOtherPersonEmployedInUS'] = false;
                            this.spouse['prevEmploymentInfo'] = [{
                                _id: 0,
                                employerName: '',
                                    address: {
                                    line1: null,
                                    line2: null,
                                    aptType: null,
                                    locationId: null,
                                    locationDetails: null,
                                    stateId: null,
                                    stateDetails: null,
                                    countryId: null,
                                    countryDetails: null,
                                    zipcode: null
                                },
                                businessType: null,
                                jobTitle: null,
                                jobDuties: null,
                                startDate: null,
                                endDate: null,
                                salary: null,
                                currentEmployer: true
                            }]
                        }
                        if(this.canRenderField('haveYouEverTravelledToUS',this.questionnaireDetails,false ,'dependentsInfo.spouse') && _.has(this.spouse,'haveYouEverTravelledToUS') && !this.checkProperty(this.spouse,'haveYouEverTravelledToUS')  ){
                            this.spouse['priorPeriodOfStayInUS'] = [{
                                _id: 0,
                                enteredNumber: null,
                                departedNumber: null,
                                visaStatus: null,
                                visaStatusDetails: null,
                                noOfDays: null,
                                dateerror: false
                            }]
                        }
                        if(this.canRenderField('currentlyInUS',this.questionnaireDetails, false, 'dependentsInfo.spouse' ) && _.has(this.spouse,'currentlyInUS') && !this.checkProperty(this.spouse,'currentlyInUS')){
                            this.spouse.currentStatusDetails = null
                            this.spouse.currentStatus  = null
                            this.spouse.isDSExpiryDate = null
                            this.spouse.statusExpiryDate = null
                            this.spouse.I94 = null
                            this.spouse.isI94DSExpiryDate = null
                            this.spouse.I94ExpiryDate = null
                            this.spouse.eadNumber = null
                            this.spouse.sevisNumber = null
                            this.spouse.physicalAddress = {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            }
                        }
                        this.petition.dependentsInfo.spouse = _.cloneDeep(this.spouse)
                        this.petition.dependentsInfo.spouse.h4Required = true;
                        this.spouse.saved = true;
                        //this.petition.dependentsInfo.spouse.saved = true;
                        this.saveCase(false, true)
                    } else{
                        const $ = JQuery;
                        if($('.text-danger:visible')){
                             $('.modal_cnt').scrollTop($('.text-danger:visible').first().parent().offset().top-30);
                        }
                    }
                })
    
            },
            customvalidations() {
                var valid = true;
                if(this.petition.beneficiaryInfo.priorPeriodOfStayInUS && this.checkProperty(this.petition['beneficiaryInfo'],'priorPeriodOfStayInUS','length')>0){
                this.petition.beneficiaryInfo.priorPeriodOfStayInUS.forEach((element, index) => {
    
                    if (element.dateerror) {
                        valid = false;
                        return valid;
                    }
    
                });
            }
    
                return valid;
            },
            checkEducationTab(){
                let returnVal = true
                if(this.currentTab == 'education' && this.canRenderField('hasMasterDegreeInUS', this.questionnaireDetails ,false,'beneficiaryInfo')  && this.checkProperty(this.petition,'beneficiaryInfo','educations') &&
                this.checkProperty(this.petition['beneficiaryInfo'],'educations','length')>0){
                   let mastDExists = _.find(this.petition['beneficiaryInfo']['educations'], { 'highestDegree': 6 });
                   let bDexists = _.find(this.petition['beneficiaryInfo']['educations'], { 'highestDegree': 4 });
                   if(mastDExists ){
                    if(!bDexists){
                        this.educationErrorMsg="Seems you have not submitted Bachelor's information. Please fill to continue"
                        returnVal = false
                    }
                   }else{
                    if(this.checkProperty(this.petition,'beneficiaryInfo','hasMasterDegreeInUS')){
                        returnVal = false
                        this.educationErrorMsg="Seems you have not submitted Master's information. Please fill to continue"
                    }
                   } 
                }
                return returnVal
            },
            validateandScroll() {
                var $self = this;
                const $ = JQuery;
                var el = _.find(this.errors["items"], function (item) {
                    return item.scope == $self.currentTab + "form"
                })
                if (el) {
                    const ele = $("[name=" + el.field + "]").parents(".vx-col");
                    var _top = 0;
                    if (ele) {
                        _top = ele.position().top;
                    }
                }
                document.getElementById("scrollableques").scrollTo({
                    top: _top,
                    left: 0,
                    behavior: 'smooth'
                })
    
            },
            submitCase() {
                this.$validator.validateAll(this.currentTab + "form").then((result) => {
                    if (result){
                        if (this.getIndexOfActivetab < this.tabslist.length) {
                        this.setActiveTab(this.tabslist[this.getIndexOfActivetab].key);
                        setTimeout(function () {
                            document.getElementById("scrollableques").scrollTo({
                                top: 0,
                                left: 0,
                                behavior: 'smooth'
                            })
                        }, 500)
                        } 
                        else {
                            this.saveCase(true, false);
                            // if (this.petition.questionnaireFilled) {
                            //     this.$vs.loading();
                            //     this.saveCase(true, false);
                            // }
                            // else{
                            //     this.setSameaddress(false);

                            //     this.checkPreviousSpouse();
                            //     this.callQuestionairePrefill();
                            //     let temp_save =false;
                            //     this.questionnairePreviewData = {
                            //     submittedWithLink:false,
                            //     petitionId: this.$route.params.itemId,
                            //     userName: this.$store.state.user.name,
                            //     typeName: this.petition.typeDetails.name,
                            //     subTypeName: this.petition.subTypeDetails.name,
                            //     subTypeDetails:this.petition.subTypeDetails,
                            //     typeDetails: this.petition.typeDetails,
                            //     action: temp_save ? "BENEFICIARY_INFO_UPDATE" : "SUBMIT_BY_BENEFICIARY",
                            //     currentDate: moment().format("YYYY-MM-DD"),
                            //     beneficiaryInfo: this.petition.beneficiaryInfo,
                            //     dependentsInfo: this.petition.dependentsInfo,
                            //     documents: this.petition.documents,
                            //     fatherInfo: this.petition.fatherInfo,
                            //     motherInfo: this.petition.motherInfo,
                            //     temp_save: temp_save,
                            //     questionnaireFilled: temp_save ? false : true
                            //     };
                            //     this.questionnairePreviewData['noOfDaysStayInUS'] = this.gettotalDays;
                            //     if(!this.checkProperty(this.petition ,'permId') && this.checkProperty(this.petition ,'subTypeDetails' ,'id') ==16 && this.checkProperty(this.petition ,'jobDetails') ){
                            //         this.questionnairePreviewData = Object.assign( this.questionnairePreviewData , { 'jobDetails': this.petition['jobDetails']} );

                            //     }
                            //     if(!this.checkCurrentUrl){
                            //         this.questionnairePreviewData['submittedWithLink'] =true;
                            //     }
                            //     this.questionnairePreview = true;
                            
                            // }

                            

                        }
                    }else{
                        this.validateandScroll();
                    }
                    
                })
            },
            saveCase(detailsRedirect = false, show_message = true) {
               this.setSameaddress(false);
                this.callQuestionairePrefill();
                this.checkPreviousSpouse();
          
                
                this.$vs.loading();
                this.petition.noOfDaysStayInUS = this.gettotalDays;
               
                var postpetition = {
                    userId: this.$route.params.itemId,
                    currentDate: moment().format("YYYY-MM-DD"),
                    beneficiaryInfo: this.petition.beneficiaryInfo,
                    dependentsInfo: this.petition.dependentsInfo,
                    documents: this.petition.documents,
                    fatherInfo: this.petition.fatherInfo,
                    motherInfo: this.petition.motherInfo,
                   
                };
                let path = '/beneficiary-profile/update-beneficiary-profile'
                this.$store.dispatch("commonAction", {data:postpetition,path:path})
                // this.$store.dispatch("petitioner/petitionupdate", postpetition)
                    .then((response) => {
                        if(show_message){
                            this.showToster({
                                message: response.message,
                                isError: false,
                            });
                                
                            }
                            this.spouseModalForm = false;
                            this.childModalForm = false;
                            this.$vs.loading.close();
                       
                            if(detailsRedirect){
                                this.$router.push("/beneficiaries-details/"+this.$route.params.itemId)
                            }
                            
    
                        // if (this.checkProperty(response, "error")) {
    
                        //     if (show_message) {
    
                        //         this.showToster({
                        //             message: response.error.message,
                        //             isError: true,
                        //         });
                        //     } else {
    
                        //         this.$vs.loading.close();
                        //     }
    
                        // } else {
    
                        //     this.spouseModalForm = false;
                        //     this.childModalForm = false;
                        //     if (show_message) {
                                
                              
                        //         if (!temp_save) {
                        //             this.SuccessQuestionnaire = true;
                        //         } else {
    
                        //             this.showToster({
                        //                 message: "Questionnaire saved successfully",
                        //                 isError: false,
                        //             });
                        //         }
    
                        //     } else {


                        //         let currentRoute = this.$route;

                        //         if (  !this.checkCurrentUrl &&   _.get(currentRoute, "name", "") == "fill-questionnaire" &&  _.has(currentRoute, "meta.getTokenFromUrl") &&
                        //         _.has(currentRoute, "query.token")
                        //         ) {
                        //             let token = _.get(currentRoute, "query.token", "");
                        //              let url = "/filled-case-details/" +this.$route.params.itemId + "?token=" + token;
                        //         //   window.location.href = window.location.origin+'/app'+url

                        //             this.showToster({  message: "Questionnaire saved successfully",  isError: false,  });
                                
                        //              this.$router.push(url) //petitionId

                        //         }else if (this.petition.questionnaireFilled) {
                        //             this.showToster({ message: "Questionnaire updated successfully",   isError: false,  });

                        //             if (this.checkProperty(this.petition, "rfeCase")) {
                        //                 this.$router.push("/rfe-petition-details/" + this.$route.params.itemId);
                        //            } else {
                        //               this.$router.push("/petition-details/" + this.$route.params.itemId);
                        //             }
    
                        //         } else {
                                    
    
                        //             if (!temp_save) {
                        //                 this.questionnairePreview = false;
                        //                 this.$vs.loading.close();
                        //                 this.SuccessQuestionnaire = true;
                        //                 document.addEventListener("click", this.reloadthePage);
    
                        //             } else {
                        //                 this.questionnairePreview = false;
                        //                this.showToster({ message: "Questionnaire updated successfully",   isError: false,  });
                        //                 this.$vs.loading.close();

                        //                 if (this.checkProperty(this.petition, "rfeCase")) {
                        //                     this.$router.push("/rfe-petition-details/" + this.$route.params.itemId);
                        //                 } else {
                        //                     this.$router.push("/petition-details/" + this.$route.params.itemId);
                        //                 }
                        //             }
    
                        //         }
    
                        //     }
                        // }
    
                        // this.$vs.loading.close();
    
                }).catch((err)=>{
                    this.showToster({
                                    message: err,
                                    isError: true,
                                });
                                this.$vs.loading.close();
                })
      
            },
            reloadthePage() {
                let routeTest = this.$route.params.itemId;
    
                var _self = this;
                if (this.SuccessQuestionnaire) {
                    this.SuccessQuestionnaire = false;
                }
                setTimeout(() => {
                    let currentRoute = _self.$route;
    
                    if (
                        _.get(currentRoute, "name", "") == "fill-questionnaire" &&
                        _.has(currentRoute, "meta.getTokenFromUrl") &&
                        _.has(currentRoute, "query.token")
                    ) {
                        let token = _.get(currentRoute, "query.token", "");
                        let url = "/filled-case-details/" + routeTest + "?token=" + token;
                        //   window.location.href = window.location.origin+'/app'+url
                        _self.$router.push(url);
                    } else {
                        if (_self.checkProperty(_self.petition, "rfeCase")) {
                            _self.$router.push("/rfe-petition-details/" + routeTest);
                        } else {
                            _self.$router.push("/petition-details/" + routeTest);
                        }
                    }
                }, 10);
            },
            goBack() {
                this.setActiveTab(this.tabslist[this.getIndexOfActivetab - 2].key)
    
            },

            formatName(item) {
    
                var _t = '';
                if (item.name != '' && item.name != null) return _t.name;
                if (item.first_name != null && item.first_name != '') _t = item.first_name;
                if (item.middle_name != null && item.middle_name != '') _t + " " + item.middle_name;
                if (item.last_name != null && item.last_name != '') _t + " " + item.last_name;
    
                return _t;
            },
            setActiveTab(item, validate = false) {
                if (validate) {
                    this.$validator.validateAll(this.currentTab + "form").then((result) => {
                        if (result) {
                            this.currentTab = item;
                            setTimeout(function () {
                                document.getElementById("scrollableques").scrollTo({
                                    top: 0,
                                    left: 0,
                                    behavior: 'smooth'
                                })
                            }, 500)
                        }else{
                            this.validateandScroll();
                        }
                    })
                }else {
                    this.currentTab = item;
    
                    setTimeout(function () {
                        document.getElementById("scrollableques").scrollTo({
                            top: 0,
                            left: 0,
                            behavior: 'smooth'
                        })
                    }, 500)
    
                }
            },
            changeBfProvince(value) {
                this.petition.beneficiaryInfo.countryOfBirth = this.petition.beneficiaryInfo.countryOfBirthDetails.id;
                this.petition.beneficiaryInfo.provinceOfBirth = null
                
                 this.petition.beneficiaryInfo.provinceOfBirthDetails = null;
                this.bfeprovinceStates = [];
    
                this.loadStatesByCountry('bfeprovinceStates', value.id)
            },
            changeCountryMarriage(value){
    
                this.petition.beneficiaryInfo.countryOfMarriage = this.petition.beneficiaryInfo.countryOfMarriageDetails.id;
                this.petition.beneficiaryInfo.provinceOfMarriage = null;
                this.petition.beneficiaryInfo.provinceOfMarriageDetails = null;
                this.statesOfMarriage = [];
    
                this.loadStatesByCountry('statesOfMarriage', value.id)
            },
            setOutsideAddress() {
    
                if (this.petition.beneficiaryInfo.currentlyInUS) {
                    this.petition.beneficiaryInfo.addressOutsideUS = {
                        line1: null,
                        line2: null,
                        aptType: null,
                        locationId: null,
                        locationDetails: null,
                        stateId: null,
                        stateDetails: null,
                        countryId: null,
                        countryDetails: null,
                        zipcode: null
                    };
                } 
                // else {
    
                //     this.petition.beneficiaryInfo.addressOutsideUS = {
                //         line1: null,
                //         line2: null,
                //         aptType: null,
                //         locationId: null,
                //         locationDetails: null,
                //         stateId: null,
                //         stateDetails: null,
                //         countryId: null,
                //         countryDetails: null,
                //         zipcode: null
                //     };
                // }
    
            },
            addOtherNames() {
                let item = {
                    firstName: "",
                    middleName: "",
                    lastName: ""
                };
                this.petition.beneficiaryInfo["otherNames"].push(item);
            },
            removeOtherName(index) {
                this.petition.beneficiaryInfo["otherNames"].splice(index, 1);
            },
            resetOtherNames($event) {
                this.petition.beneficiaryInfo["otherNames"] = [];
                this.addOtherNames();
    
            },

            loadStatesByCountry(model, countryId) {
    
                this.$store.dispatch("getstates", countryId).then((response) => {
                    switch (model) {
                        case "bfeprovinceStates":
                            this.bfeprovinceStates = response;
                            break;
                        case "usastates":
                            this.usastates = response;
                        break;
                        case "statesOfMarriage":
                            this.statesOfMarriage = response;
                        break;    
                    }
    
                   // var provinceOfBirth = this.petition.beneficiaryInfo.provinceOfBirth;
                    // if (provinceOfBirth != null) {
                    //     var item = _.find(this.bfeprovinceStates, function (item) {
    
                    //         return item.id == provinceOfBirth
                    //     })
                    //     if (!item) {
                    //         this.petition.beneficiaryInfo.provinceOfBirth = null;
                    //         this.petition.beneficiaryInfo.provinceOfBirthDetails = {};
                    //     }
                    // }
    
                });
    
            },
            setTheInitData() {
                var $self = this;
                if (this.petition.beneficiaryInfo.countryOfBirthDetails && this.petition.beneficiaryInfo.countryOfBirth != null) {
    
                    this.loadStatesByCountry('bfeprovinceStates', this.petition.beneficiaryInfo.countryOfBirth)
    
                }
                
                let provinceOfBirth = this.checkProperty(this.petition ,'beneficiaryInfo' ,'provinceOfBirth');
                   if (provinceOfBirth != null) { 
                     let provinceOfBirthDetails = _.find(this.bfeprovinceStates, function (item) {  return item.id == provinceOfBirth  })
                         if(provinceOfBirthDetails){
                             this.petition.beneficiaryInfo.provinceOfBirthDetails = provinceOfBirthDetails;
                         }
                    }
                let highestDegree = this.checkProperty(this.petition['beneficiaryInfo'],'education','highestDegree');
                if (highestDegree != null) {
                    let highestDegreeDetails  = _.find(this.education_types, function (item) {return item.id == highestDegree})
                    if(highestDegreeDetails){
                        this.petition.beneficiaryInfo.education.highestDegreeDetails = highestDegreeDetails
                    }
                    
                }
                let maritualStatus = this.checkProperty(this.petition,'beneficiaryInfo','maritalStatus');
                if (maritualStatus) {
                    let maritualStatusDetails  = _.find(this.marital_statuses, function (item) {return item.id == maritualStatus})
                    if(maritualStatusDetails){
                        this.petition.beneficiaryInfo.maritalStatusDetails = maritualStatusDetails
                    }
                    
                }
    
    
                let curNonImmigrantVisaStatus = this.petition.beneficiaryInfo.curNonImmigrantVisaStatus;
                if (curNonImmigrantVisaStatus != null) {
                    this.petition.beneficiaryInfo.curNonImmigrantVisaStatusDetails = _.find(this.visastatuses, function (item) {
    
                        return item.id == curNonImmigrantVisaStatus
                    })
                }
    
                if (this.petition.beneficiaryInfo.priorPeriodOfStayInUS && this.petition.beneficiaryInfo.priorPeriodOfStayInUS.length == 1 && this.petition.beneficiaryInfo.priorPeriodOfStayInUS[0].departedDate == null && this.petition.beneficiaryInfo.priorPeriodOfStayInUS[0].enteredDate == null) {
    
                    this.petition.beneficiaryInfo.priorPeriodOfStayInUS = [{
                        _id: 0,
                        enteredNumber: null,
                        departedNumber: null,
                        visaStatus: null,
                        visaStatusDetails: null,
                        noOfDays: null,
                        dateerror: null
                    }]
                }
    
                if (this.petition.beneficiaryInfo && this.petition.beneficiaryInfo.educations == null) {
                    this.petition.beneficiaryInfo.educations = [{
                        _id: 0,
                        name: null,
                        address: {
                            line1: null,
                            line2: null,
                            aptType: null,
                            locationId: null,
                            locationDetails: null,
                            stateId: null,
                            stateDetails: null,
                            countryId: null,
                            countryDetails: null,
                            zipcode: null
                        },
                        highestDegree: null,
                        highestDegreeDetails: null,
                        majorFieldOfStudy: null,
                        attendedFrom: null,
                        attendedTo: null,
                        graduatedYear: null,
                        degreereceived: null,
                        isAccredited: null,
                        graduatedDate:null,
                        isForProfit: null
                    }]
                }
                if(this.petition.dependentsInfo && this.petition.dependentsInfo.spouse && this.petition.dependentsInfo.spouse.prevEmploymentInfo == null){
                    this.petition.dependentsInfo.spouse.prevEmploymentInfo = [{
                            _id: 0,
                            employerName: '',
                            address: {
                                line1: null, 
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                            businessType: null,
                            jobTitle: null,
                            jobDuties: null,
                            startDate: null,
                            endDate: null,
                            salary: null,
                            currentEmployer: true
                        }]
                        this.spouse.prevEmploymentInfo = [{
                            _id: 0,
                            employerName: '',
                            address: {
                                line1: null, 
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                            businessType: null,
                            jobTitle: null,
                            jobDuties: null,
                            startDate: null,
                            endDate: null,
                            salary: null,
                            currentEmployer: true
                        }]
                }
    
                if (this.petition.beneficiaryInfo && this.petition.beneficiaryInfo.prevEmploymentInfo == null) {
                    this.petition.beneficiaryInfo.prevEmploymentInfo = [{
                        _id: 0,
                        employerName: '',
                        address: {
                            line1: null,
                            line2: null,
                            aptType: null,
                            locationId: null,
                            locationDetails: null,
                            stateId: null,
                            stateDetails: null,
                            countryId: null,
                            countryDetails: null,
                            zipcode: null
                        },
                        businessType: null,
                        jobTitle: null,
                        jobDuties: null,
                        startDate: null,
                        endDate: null,
                        salary:null,
                        currentEmployer: false
                    }]
                }

                this.featureDates = new Date();
    
                if (this.petition.dependentsInfo.childrens && this.petition.dependentsInfo.childrens.length > 0 && this.petition.dependentsInfo.childrens[0].firstName != '' && this.petition.dependentsInfo.childrens[0].firstName != null) {
                    this.petition.h4RequiredForChild = true;
                }
    
                this.petition.dependentsInfo.childrens.forEach((element, index) => {
                    if(!_.has(element,'anyOtherPersonEmployedInUS')){
                        Object.assign(element,{'anyOtherPersonEmployedInUS':false})
                    }
                    if(!_.has(element,'prevEmploymentInfo') || (element && element['prevEmploymentInfo'] && element['prevEmploymentInfo'] == null) ){
                        Object.assign(element,{'prevEmploymentInfo':[{
                            _id: 0,
                            employerName: '',
                            address: {
                                line1: null, 
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                            businessType: null,
                            jobTitle: null,
                            jobDuties: null,
                            startDate: null,
                            endDate: null,
                            salary: null,
                            currentEmployer: true
                        }]})
                    }
                    if (element.firstName != '' && element.firstName != null) {
                        this.petition.dependentsInfo.childrens[index].saved = true;
                    }
    
                });
    
                if (this.petition.dependentsInfo.spouse.firstName != null && this.petition.dependentsInfo.spouse.firstName != '') {
    
                    this.petition.dependentsInfo.spouse.saved = true;
                    this.spouse.saved = true;
                }
                   if(this.petition.beneficiaryInfo.priorPeriodOfStayInUS && this.checkProperty(this.petition['beneficiaryInfo'],'priorPeriodOfStayInUS','length')>0){
                     this.petition.beneficiaryInfo.priorPeriodOfStayInUS.forEach(function (item, index) {
                    
                   $self.petition.beneficiaryInfo.priorPeriodOfStayInUS[index].visaStatusDetails = _.find($self.petition.visaStatusList, function (aitem) {
    
                        return aitem.id == item.visaStatus
                    })
                    })
                }
                setTimeout(()=>{
                    $self.mamageVisaStatusDocuments()
                } ,500);
                this.$vs.loading.close();

            },
            getCountries(){
                this.$store.dispatch("getcountries").then((response) => {
                    this.countries = response;
                    if(this.checkProperty(this.countries, 'length')>0){
                        this.countriesWithoutUS = _.filter(this.countries,(item)=> {
                            return item.id != 231;
                        });
                    }
    
                });
            },
            init() {
                this.$store.dispatch("getcountries").then((response) => {
                    this.countries = response;
                    if(this.checkProperty(this.countries, 'length')>0){
                        this.countriesWithoutUS = _.filter(this.countries,(item)=> {
                            return item.id != 231;
                        });
                    }
    
                });
    
                this.$store.dispatch("getmasterdata", "visa_status").then((response) => {
                    this.visastatuses = response;
                });
                this.$store.dispatch("getmasterdata", "eye_colors").then((response) => {
                    this.eye_colorList = response;
                });
                this.$store.dispatch("getmasterdata", "hair_colors").then((response) => {
                    this.hair_colorsList = response;
                });
                this.$store.dispatch("getmasterdata", "races").then((response) => {
                    this.races_list = response;
                });
                this.$store
                    .dispatch("getmasterdata", "marital_status")
                    .then((response) => {
                        this.marital_statuses = response;
                    });
    
                this.$store
                    .dispatch("getmasterdata", "education_types")
                    .then((response) => {
                        this.education_types = response;
                    });
                    let path = '/beneficiary-profile/get-profile-details'
                    let postData = {
                        userId:this.$route.params.itemId
                    }

                    this.$store.dispatch("commonAction", {data:postData,path:path})
                    .then((response) => {
                       
                        if(response){
                            var data = _.merge(this.petition, response);
                            this.petition = data;   
                            this.mamageVisaStatusDocuments();
                            this.setTheInitData()
                            this.$vs.loading.close();
                            this.petition['visaStatusList'] = this.visastatuses
                            this.petition['highestDegreeList'] = this.education_types;
                            if(_.has(this.petition,'dependentsInfo') && this.checkProperty(this.petition,'dependentsInfo','spouse')){
                                let spouseDt = _.merge(this.spouse, this.petition.dependentsInfo.spouse);
                                this.spouse = spouseDt;
                            }
                            // if(this.petition && !this.petition['visaStatusList']){
                                
                                
                            // }
                        }else{
                            path = 'petition-common/get-recent-by-beneficiary';
                            this.$store.dispatch("commonAction", {"data":postData ,"path":path})
                            .then((response) => {
                                if(response && response['caseDetails']){
                                    let data = _.merge(this.petition, response['caseDetails']);
                                    this.petition = data;
                                    this.petition['visaStatusList'] = this.visastatuses
                                    this.petition['highestDegreeList'] = this.education_types;
                                    if(!_.has(this.petition['beneficiaryInfo'],'cellPhoneCountryCode') || !this.checkProperty(this.petition['beneficiaryInfo'],'cellPhoneCountryCode')){
                                        this.petition['beneficiaryInfo']['cellPhoneCountryCode'] ={
                                            countryCode: '',
                                            countryCallingCode: ''
                                        }
                                    }
                                    if(!_.has(this.petition['beneficiaryInfo'],'homePhoneCountryCode') || !this.checkProperty(this.petition['beneficiaryInfo'],'homePhoneCountryCode')){
                                        this.petition['beneficiaryInfo']['homePhoneCountryCode'] ={
                                            countryCode: '',
                                            countryCallingCode: ''
                                        }
                                    }
                                    if(!_.has(this.petition['beneficiaryInfo'],'workPhoneCountryCode') || !this.checkProperty(this.petition['beneficiaryInfo'],'workPhoneCountryCode')){
                                        this.petition['beneficiaryInfo']['workPhoneCountryCode'] ={
                                            countryCode: '',
                                            countryCallingCode: ''
                                        }
                                    }
                                    if(!_.has(this.petition['beneficiaryInfo'],'faxCountryCode') || !this.checkProperty(this.petition['beneficiaryInfo'],'faxCountryCode')){
                                        this.petition['beneficiaryInfo']['faxCountryCode'] ={
                                            countryCode: '',
                                            countryCallingCode: ''
                                        }
                                    }
                                    this.$vs.loading.close();
                                    this.setTheInitData()
                                }
                                else{
                                    if(response && response['userDetails']){
                                        this.userDetails = response['userDetails']; 
                                        if(this.checkProperty(response ,'userDetails' ,'email' ) && !this.checkProperty(this.petition ,'beneficiaryInfo' ,'email')){
                                            this.petition['beneficiaryInfo']['email'] = this.checkProperty(response ,'userDetails' ,'email' )
                                        }
                                        if(this.checkProperty(response ,'userDetails' ,'firstName' ) && !this.checkProperty(this.petition ,'beneficiaryInfo' ,'firstName')){
                                            this.petition['beneficiaryInfo']['firstName'] = this.checkProperty(response ,'userDetails' ,'firstName' );
                                        }
                                        if(this.checkProperty(response ,'userDetails' ,'middleName' )  && !this.checkProperty(this.petition ,'beneficiaryInfo' ,'middleName') ){
                                            this.petition['beneficiaryInfo']['firstName'] = this.checkProperty(response ,'userDetails' ,'middleName' );
                                        }
                                        if(this.checkProperty(response ,'userDetails' ,'lastName' ) && !this.checkProperty(this.petition ,'beneficiaryInfo' ,'lastName') ){
                                            this.petition['beneficiaryInfo']['lastName'] = this.checkProperty(response ,'userDetails' ,'lastName' );
                                        }
                                        if(this.checkProperty(response ,'userDetails' ,'phone' ) && !this.checkProperty(this.petition ,'beneficiaryInfo' ,'phone') ){
                                            this.petition['beneficiaryInfo']['cellPhoneNumber'] = this.checkProperty(response ,'userDetails' ,'phone' );
                                        }
                                        if(this.checkProperty(response ,'userDetails' ,'phoneCountryCode' ) && this.checkProperty(response['userDetails'] ,'phoneCountryCode','countryCallingCode' ) ){
                                            this.petition['beneficiaryInfo']['cellPhoneCountryCode'] = this.checkProperty(response ,'userDetails' ,'phoneCountryCode' );
                                        }
                                        this.petition['visaStatusList'] = this.visastatuses
                                        this.petition['highestDegreeList'] = this.education_types;
                                        this.removeFields();
                                        this.$vs.loading.close();
                                        this.setTheInitData()
                                    }
                                    
                                }
                            }).catch((err)=>{
                                this.$vs.loading.close();
                            })
                            this.petition['visaStatusList'] = this.visastatuses
                            this.petition['highestDegreeList'] = this.education_types;
                            this.$vs.loading.close();
                        }
                       
                      
                    }).catch((err)=>{
                        this.$vs.loading.close();
                    })
            },
            getChildObject() {
                let childAddress= {
                    sevisNumber: null,
                    eadNumber: null,
                    haveYouEverTravelledToUS:null,
                    isI94DSExpiryDate:false,
                    isDSExpiryDate:false,
                    email: '',
                    phoneNumber: '',
                    phoneCountryCode: {
                        countryCode: '',
                        countryCallingCode: ''
                    },
                    relationship: '',
                    currentlyInUS: null,
                    hasOtherNames: null, 
                    otherNames: [{
                        _id: 0,
                        name: '',
                        firstName: '',
                        middleName: '',
                        lastName: '',
                    }],
                    alienNumber: '',
                    lastArrivalNumber: null,
                    lastArrivalDate:null,
                    stateOfLastEntryInUS: '',
                    stateDetailsOfLastEntryInUS: null,
                    placeOfLastEntryInUS: '',
                    physicalAddress: {
                        line1: null,
                        line2: null,
                        aptType: null,
                        locationId: null,
                        locationDetails: {
                            id: null,
                            name: null,
                            stateId: null,
                            countryId: null
                        },
                        stateId: null,
                        stateDetails: {
                            id: null,
                            name: null,
                            countryId: null
                        },
                        countryId: null,
                        countryDetails: {
                            id: null,
                            name: null,
                            shortName: null,
                            phoneCode: null,
                            countryId: null,
                            currencySymbol: null,
                            currencyCode: null,
                            zipcodeLength: null
                        },
                        zipcode: null
                    },
                    addressOutsideUS: {
                        line1: null,
                        line2: null,
                        aptType: null,
                        locationId: null,
                        locationDetails: {
                            id: null,
                            name: null,
                            stateId: null,
                            countryId: null
                        },
                        stateId: null,
                        stateDetails: {
                            id: null,
                            name: null,
                            countryId: null
                        },
                        countryId: null,
                        countryDetails: {
                            id: null,
                            name: null,
                            shortName: null,
                            phoneCode: null,
                            countryId: null,
                            currencySymbol: null,
                            currencyCode: null,
                            zipcodeLength: null
                        },
                        zipcode: null
                    },
                    passportIssuedNumber: null,
                    priorPeriodOfStayInUS: [{
                        _id: 0,
                        enteredNumber: null,
                        dateerror: false,
                        noOfDays: null,
                        departedNumber: null,
                        visaStatus: null
                    }],
                    prevEmploymentInfo: [{
                        _id: 0,
                        employerName: '',
                        address: {
                            line1: null,
                            line2: null,
                            aptType: null,
                            locationId: null,
                            locationDetails: null,
                            stateId: null,
                            stateDetails: null,
                            countryId: null,
                            countryDetails: null,
                            zipcode: null
                        },
                        businessType: null,
                        jobTitle: null,
                        jobDuties: null,
                        startDate: null,
                        endDate: null,
                        payFrequency:null,
                        salary: null,
                        currentEmployer: null
                    }],
                    anyOtherPersonEmployedInUS:null,
                    haveYouEverEmployed:null,
                    h4Required: null,
                    name: '',
                    firstName: '',
                    middleName: '',
                    lastName: '',
                    dateOfBirth: null,
                    countryOfBirth: null,
                    countryOfBirthDetails: null,
                    provinceOfBirth: null,
                    provinceOfBirthDetails: null,
                    locationOfBirth: '',
                    locationOfBirthDetails: null,
                    countryOfCitizenship: null,
                    countryOfCitizenshipDetails: null,
                    passportNumber: '',
                    passportExpiryNumber: null,
                    I94: '',
                    I94ExpiryNumber: null,
                    currentStatus: null,
                    statusExpiryNumber: null,
                    documents: {
                        passport: [],
                        visa: [],
                        formI94: [],
                        birthCertificate: [],
                        approvalNotice: [],
                        approvalNoticeOfPrevH4: [],
                        other: []
                    },
    
                   
                }
                let addBenificiaryAdd = false;
                _.forEach(childAddress['physicalAddress'],(item,key)=>{                    
                    if(this.checkProperty( childAddress['physicalAddress']  ,key) !=null && ['line1','line2','aptType' ,'stateId','countryId'  ,'locationId','zipcode'].indexOf(key)>-1){
                        addBenificiaryAdd = true;
                       return false;
                    }
                })
                if(!addBenificiaryAdd){
                    childAddress['physicalAddress'] = _.cloneDeep(this.petition.beneficiaryInfo.address)
                }
                return childAddress
    
     
    
            },
    
            setBasicData(){
                let _self =this;
                //this.latestPetition beneficiaryInfo
                //email  firstName middleName lastName
                if(this.checkProperty(this.latestPetition ,'beneficiaryInfo' ,'email' )){
    
                    this.petition['beneficiaryInfo']['email'] = this.checkProperty(this.latestPetition ,'beneficiaryInfo' ,'email' )
                    
    
                }
                if(this.checkProperty(this.latestPetition ,'beneficiaryInfo' ,'firstName' )){
                    this.petition['beneficiaryInfo']['firstName'] = this.checkProperty(this.latestPetition ,'beneficiaryInfo' ,'firstName' );
                }
                if(this.checkProperty(this.latestPetition ,'beneficiaryInfo' ,'middleName' )){
                    this.petition['beneficiaryInfo']['middleName'] = this.checkProperty(this.latestPetition ,'beneficiaryInfo' ,'middleName' );
                }
                if(this.checkProperty(this.latestPetition ,'beneficiaryInfo' ,'lastName' )){
                    this.petition['beneficiaryInfo']['lastName'] = this.checkProperty(this.latestPetition ,'beneficiaryInfo' ,'lastName' );
                }

                setTimeout(()=>{
                    _self.mamageVisaStatusDocuments()
                } ,500);
    
    
            },
            prefilltheDeta() {
    
                var childres = []
                if(this.checkProperty(this.latestPetition['dependentsInfo'], 'childrens') && this.checkProperty(this.latestPetition['dependentsInfo'], 'childrens','length')>0 ){
                    this.latestPetition.dependentsInfo.childrens.forEach((element, index) => {
        
                        if (element.firstName != null && element.firstName != "") {
                            childres.push(element)
                        }
        
                    });
                }
                if (childres.length > 0) {
                    this.latestPetition.dependentsInfo.childrens = childres;
                } else {
                    if(this.checkProperty(this.latestPetition['dependentsInfo'], 'childrens')){
                        this.latestPetition.dependentsInfo.childrens = this.getChildObject()
                    }
                    
                }
    
                var data = _.merge(this.petition, this.latestPetition);
    
                this.petition = data;
                this.setTheInitData()
                
            },
            prefilltheDetails(){
                let tempPetition = _.cloneDeep(this.latestPetition);
                if(_.has(tempPetition,'dependentsInfo')){
                    delete tempPetition["dependentsInfo"]
                }
                var data = _.merge(this.petition, tempPetition);
                if(_.has(data,'beneficiaryInfo') && _.has(data['beneficiaryInfo'], 'prevEmploymentOutsideUS') && !this.checkProperty(data['beneficiaryInfo'], 'prevEmploymentOutsideUS') ){
                    data['beneficiaryInfo']['prevEmploymentOutsideUS']=[{
                            _id: 0,
                            employerName: '',
                            address: {
                                line1: null,
                                line2: null,
                                aptType: null,
                                locationId: null,
                                locationDetails: null,
                                stateId: null,
                                stateDetails: null,
                                countryId: null,
                                countryDetails: null,
                                zipcode: null
                            },
                            businessType: null,
                            jobTitle: null,
                            jobDuties: null,
                            startDate: null,
                            endDate: null,
                            currentEmployer: false  
                        }]
                }
                if(_.has(data,'beneficiaryInfo') && ((_.has(data['beneficiaryInfo'], 'addressOfLastNYears') && !this.checkProperty(data['beneficiaryInfo'], 'addressOfLastNYears'))||
                !_.has(data['beneficiaryInfo'], 'addressOfLastNYears')) ){
                    data['beneficiaryInfo']['addressOfLastNYears']=[{
                        line1: null,
                        line2: null,
                        aptType: null,
                        locationId: null,
                        locationDetails: null,
                        stateId: null,
                        stateDetails: null,
                        countryId: null,
                        countryDetails: null,
                        zipcode: null,
                        startDate: null,
                        endDate: null,
                    }]
                }
                if(_.has(data,'beneficiaryInfo') && ((_.has(data['beneficiaryInfo'], 'addressOutsideUSMoreThanYear') && !this.checkProperty(data['beneficiaryInfo'], 'addressOutsideUSMoreThanYear'))||
                !_.has(data['beneficiaryInfo'], 'addressOutsideUSMoreThanYear')) ){
                    data['beneficiaryInfo']['addressOutsideUSMoreThanYear']=[{
                        line1: null,
                        line2: null,
                        aptType: null,
                        locationId: null,
                        locationDetails: null,
                        stateId: null,
                        stateDetails: null,
                        countryId: null,
                        countryDetails: null,
                        zipcode: null,
                        startDate: null,
                        endDate: null,
                    }]
                }
                this.petition = data;

                this.setTheInitData()
            }
    
        },
        beforeDestroy() {
            const $ = JQuery;
            document.removeEventListener("click", this.reloadthePage);
    
            $('body').removeClass('questionnairetpl')
        },
        mounted() {
            this.getMasterSocList();
            const $ = JQuery;
            this.$vs.loading();
            $('body').addClass('questionnairetpl')
            this.init();
            this.getGlobalConfigDetails();
            //this.$validator.reset();
            this.loadStatesByCountry('usastates', 231)
            this.loadStatesByCountry('bfeprovinceStates', 231)
    
    
        },
        components: {
            monthAndYear,
            InfoIcon,
            EyeIcon,
            FileUpload,
            Datepicker,
            immitextfield,
            XIcon,
             genderField,
            immiInput,
            addressField,
            Trash2Icon,
            datepickerField,
            selectField,
            immiPhone,
            immiMask,
            immiyesorno,
            immiuploader,
            immipriorstay,
            immitextarea,
            immieducations,
            immiswitchyesno,
            casedocumentslist,
            immiemployment,
            PetitionDetails,
            VuePerfectScrollbar,
            petitionsinformation,
            petitionImmigranInfo,
            personalinfo,
            childpersonalinfo,
    
         // 485 Components
         previousSpouseForm ,
         immigrationForm,
        
        
         financialForm,
         assestsForm,
         liabilitiesForm,
         publicBenefitsForm,
         parentForm,
    
    
        },
        watch: {
    
        }
    }; 
    </script>