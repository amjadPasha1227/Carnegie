<template>
    <div class="main-tabs-content"
       :class="{ 'petetion__details_full_width': !loadedFromPreview, 'anonymouslogin': !checkCurrentUrl }">
       <div class="tabs-layout-header cpr_heading" v-if="!loadedFromPreview">
 
          <div class="case-no-panel">
             <div class="casenumber_sec">
                <div class="case_number">
                   <div class="d-flex align-items-center">
                      Case No
                   </div>
                   <span>{{ checkProperty(petition, "caseNo") }}
                   </span>
                    <i class="material-icons"
                      v-if="!loadedFromPreview && checkCurrentUrl && checkProperty(petitions, 'length') > 0">arrow_drop_down</i>
                </div>
                 <div class="case_number_list"
                   v-if="!loadedFromPreview && checkCurrentUrl && checkProperty(petitions, 'length') > 0">
                   <VuePerfectScrollbar class="scroll-area">
                      <ul v-if="petitions">
                         <li @click="petetionChange(petition._id)" v-for="(petition, index) in petitions" :key="index">{{
                            petition.caseNo }}
                         </li>
                      </ul>
                   </VuePerfectScrollbar>
                </div>
             </div>
          </div>
          <pwdCaseProcess ref="pwd_process_flow" v-bind:petition="petition" @updatepetition="reloadPetition"
         
            @download_or_view="download_or_view" :loadedFromPreview="loadedFromPreview" />
       </div>
 
       <div class="main-tabs-content tabs_mob petetion__details_page  petetion__details_full_width">
          <div class="
               tabs-content
               detail_page_sec
               petetion__details
               case-details-box-width
              petetion__details_full_width">
             <section class="petition__details_section cap_page"
                :class="{ 'cap_page_full_--': checkCurrentUrl && !loadedFromPreview && [50, 51].indexOf(getUserRoleId) > -1 }">
                <div class="pd_left">
                   <ul>
                     <li v-if="petition && petition.completedActivities &&  (petition.completedActivities.indexOf('CREATE_JOB_DESC')>-1||
                     petition.completedActivities.indexOf('PWD_CERTIFID')>-1|| petition.completedActivities.indexOf('EFILE_PWD')>-1)"
                      :class="{
                         current_child: getPetitionTab == 'Petition Updates',
                      }" @click="setActivetab('Petition Updates', true)">
                         <a>Case Updates </a>
                      </li>
                     <li :class="{
                         current_child: getPetitionTab == 'Job Details',
                      }" @click="setActivetab('Job Details', true)">
                         <a>PWD Info </a>
                      </li>
                      <li v-if="checkCompletedActivity('COLLECT_ADV_EVIDENCE')"
                        :class="{
                        current_child: getPetitionTab == 'Advertise Info',
                        }"
                        @click="setActivetab('Advertise Info', true)"
                     >
                        <a>Advertise Info </a>
                     </li>
                      
                     
                   </ul>
                </div>
              
                <div class="pd_right petition__details_cnt">
                   <div class="pd_right_cnt">
                      <template>
                        <div
                           class="pad20"
                           v-if="
                           
                           getPetitionTab == 'Petition Updates'   && getUserRoleId !=51 && !loadedFromPreview
                           "
                        >
                           <pwdCaseUpdates
                           v-bind:petition="petition"
                           @download_or_view="download_or_view"
                           :currentCaseDetails = "caseCurrentDetails"
                           @openActions="openActionMenu"
                           @reloadPetitionMe="setActivetab"
                           @updatepetition="reloadPetition"
                           
                           
                           />
                        </div>
                        <div v-if="getPetitionTab == 'Job Details'">
                     
                           <permJobDetails
                              v-bind:petition="petition"
                              @download_or_view="download_or_view"
                           />
                        </div>
                        <div
                  v-if="
                    
                    getPetitionTab == 'Advertise Info'
                  "
                >
                  <permAdvertiseInfo
                    v-bind:petition="petition"
                    @download_or_view="download_or_view"
                    @openAdv="openActionMenu"
                    :loadedFromPwdLibrary="true"


                  />
                </div>
                      </template>
 
                      <div>
 
                      </div>
                   </div>
 
                </div>
             </section>
             <vs-col
          vs-type="flex"
          class="padr0 padl0 mob-right activies_list_wrap status_wrap"
          style="width: 300px; flex-direction: column;"
          v-if="!loadedFromPreview && checkCurrentUrl && [51].indexOf(getUserRoleId)<=-1"
        >
        <!-- Newly Added -->
          <ul v-if="checkCurrentUrl && !loadedFromPreview">
            <li class="ptstatusBar "  v-if="[51].indexOf(getUserRoleId)<0">
              <div class="status_activities" :class="{'status_activities_full':[50,51].indexOf(getUserRoleId)>-1}">
                <label :class="{ 'active':getCaseStatusTab =='showCaseStatus' || ([50,51].indexOf(getUserRoleId)>-1 && getCaseStatusTab !='showCaseStatus')}" @click=" $store.commit('toggleCaseStatusTab','showCaseStatus')"  >Status</label>
                <label v-if="[50,51 ].indexOf(getUserRoleId)<=-1" :class="{ 'active':getCaseStatusTab !='showCaseStatus'}"  @click="$store.commit('toggleCaseStatusTab','showActivities')" >Activities </label>
              </div>
            </li>
          </ul>
          
          <div class="status_list gc_status" v-if="(getCaseStatusTab=='showCaseStatus' ) || ([50,51].indexOf(getUserRoleId)>-1 && getCaseStatusTab !='showCaseStatus')">
            
            <VuePerfectScrollbar class="scroll-area" >
              <pwdCaseStatusList :currentCaseDetails = "caseCurrentDetails"   :petition="petition"   />
            </VuePerfectScrollbar>
            <div class="deadline" v-if=" ( checkProperty(petition ,'deadlineDate') && [1, 2,51].indexOf(getUserRoleId) < 0)" > Deadline {{petition.deadlineDate | formatDate}}</div>  
            <!-- <div class="deadline" v-if=" ( checkProperty(petition ,'permFileDeadlineDate') && [1, 2,51].indexOf(getUserRoleId) < 0)" >PERM File Deadline is {{petition.permFileDeadlineDate | formatDate}}</div>   -->
          </div>
          <div v-else class="history-sidebar petition_history activies_list pwd_activies">
            <div class="vs-sidebar">
              <div class="petition_updated" v-if="petitionhistory.length == 0">
                Last Updated -
                {{ checkProperty(petition, "updatedOn") | formatDateTime }}
              </div>
              <div class="petition_updated" v-if="petitionhistory.length > 0">
                Last Updated - {{ petitionhistory[0].createdOn | formatDateTime }}
              </div>

              <div class="vs-sidebar--items">
                <VuePerfectScrollbar class="scroll-area">
                  <div class="timeline-sidebar 2">
                    <ul>
                      <li
                        v-for="(history, index) in petitionhistory"
                        :key="index"
                      >
                     
                        <div class="timeline-icon">
                          <i class="icon IP-tick-sign"></i>
                        </div>
                        <div class="timeline-info">
                          <button class="btn active-green ml-0">
                            {{ history.createdByRoleName }}
                          </button>
                          <ul>
                            <li>
                              <h3><span>
                                {{ history.title }}
                              </span>
                                <div
                                  v-if="
                                    history.comment && history.comment != ''
                                  "
                                  class="title_des"
                                >
                                  <small></small>
                                  <div class="dec-content">
                                    <p v-html="history.comment"></p>
                                    <span v-if="checkProperty(history, 'comment', 'length') >45"  class="view_more" @click="showHistoryComment(history)"> View More</span>
                                  </div>
                                </div>
                              </h3>

                              <span>{{ history.description }}</span>
                             <span>{{
                                history.createdOn | formatDateTime
                              }}</span>
                                
                               <p calss="cursor-pointer" style="margin-top: 5px;cursor: pointer; "   v-if="checkProperty(history ,'action' ) =='MANAGE_PREMIUM_PROCESS'&&checkProperty(history ,'documents' ,'length')>0" @click="downloads3file(history['documents'][0])">
                                 <docmentType :title="checkProperty(history['documents'][0] ,'name')"  :item="history['documents'][0]" />
                                 <!----<figcaption>{{checkProperty(history['documents'][0] ,'name')}}</figcaption>-->
                            
                             
                              </p>
                            </li>
                          </ul>
                        </div>
                      </li>
                    </ul>
                  </div>
                </VuePerfectScrollbar>
              </div>
            </div>
          </div>
          


        </vs-col>
             <!-- <div vs-type="flex" class="padr0 padl0 mob-right activies_list_wrap status_wrap cap_activies_list_wrap"
                v-if="!loadedFromPreview && checkCurrentUrl && [50, 51].indexOf(getUserRoleId) <= -1">
                <ul v-if="checkCurrentUrl && !loadedFromPreview">
                   <li class="ptstatusBar " v-if="[50, 51].indexOf(getUserRoleId) < 0">
                      <div class="status_activities" style="justify-content:center">
                         <label class="active">Activities </label>
                      </div>
                   </li>
                </ul>
                <div class="history-sidebar petition_history activies_list cap_details_activies_list">
                   <div class="vs-sidebar">
                      <div class="petition_updated" v-if="petitionhistory.length == 0">
                         Last Updated -
                         {{ checkProperty(petition, "updatedOn") | formatDateTime }}
                      </div>
                      <div class="petition_updated" v-if="petitionhistory.length > 0">
                         Last Updated - {{ petitionhistory[0].createdOn | formatDateTime }}
                      </div>
 
                      <div class="vs-sidebar--items">
                         <VuePerfectScrollbar class="scroll-area">
                            <div class="timeline-sidebar 2">
                               <ul>
                                  <li v-for="(history, index) in petitionhistory" :key="index">
                                     <div class="timeline-icon">
                                        <i class="icon IP-tick-sign"></i>
                                     </div>
                                     <div class="timeline-info">
                                        <button class="btn active-green ml-0">
                                           {{ history.createdByRoleName }}
                                        </button>
                                        <ul>
                                           <li>
                                              <h3><span>
                                                    {{ history.title }}
                                                 </span>
                                                 <div v-if="
                                                    history.comment && history.comment != ''
                                                 " class="title_des">
                                                    <small></small>
                                                    <div class="dec-content">
                                                       <p v-html="history.comment"></p>
                                                    </div>
                                                 </div>
                                              </h3>
 
                                              <span>{{ history.description }}</span>
                                              <span>{{
                                                 history.createdOn | formatDateTime
                                              }}</span>
 
                                              <p class="m-0"
                                                 v-if="checkProperty(history, 'documents', 'length') > 0"
                                                 >
                                                 
                                                    <ul class="activities_doc_list">
                                                    <template v-for="(doc,indoc) in history['documents']" >
                                                      <li class="cursor-pointer" @click="download_or_view(doc)" >
                                                       <docmentType :title="checkProperty(doc, 'name')" :item="doc" />
                                                      </li>
                                                    
                                                   </template>
                                                   </ul>
                                              </p>
                                           </li>
                                        </ul>
                                     </div>
                                  </li>
                               </ul>
                            </div>
                         </VuePerfectScrollbar>
                      </div>
                   </div>
                </div>
 
 
 
             </div> -->
          </div>
       </div>
       <vs-popup class="document_modal document_modal-v2"
       :class="{ expand: expandModal }" :title="checkProperty(selectedFile, 'name')" :active.sync="docPrivew">
       <div class="document_actions" @click="expandModal = !expandModal">
      <figure v-if="!expandModal" class="maximize-img"><img src="@/assets/images/maximize.png"  width="18" height="18"/></figure>
      <figure v-else class="minimize-img"><img src="@/assets/images/minimize.png"  width="20" height="20"/></figure>
    </div>
          <h2> <img :class="{
             pdf_view_download: docType == 'pdf',
             office_view_download: docType == 'office',
             image_view_download: docType == 'image',
          }" class="download-button" @click="downloads3file(selectedFile)" src="@/assets/images/download.svg" /></h2>
 
          <div class="pdf_loader">
             <figure v-if="formSubmited" class="loader loader2"><img src="@/assets/images/main/loader.gif" /></figure>
 
             <!-- <span :class="{'pdf_view_close':docType == 'pdf', 'office_view_close':docType == 'office'  , 'image_view_close 33':docType =='image'}" class="close close2" @click="docPrivew= false"></span> -->
             <template v-if="docType == 'office'">
                <div style="height:90vh">
 
                   <div id="placeholder" style="height:100%"></div>
                </div>
             </template>
             <template v-else-if="docType == 'image'">
                <img :src="docValue" />
             </template>
             <template v-else-if="docType == 'pdf'">
                <div class="pdf" style="height:90vh">
 
                   <iframe v-if="docValue != ''" border="0" style="border:0px;" :src="docValue" height="100%" width="100%">
 
                   </iframe>
                </div>
             </template>
          </div>
       </vs-popup> 

       <modal
      name="historyCommentPwd"
      classes="v-modal-sec"
      :min-width="200"
      :min-height="200"
      :scrollable="true"
      :reset="true"
      width="800px"
      height="auto"
    >
      <div class="v-modal">
        <div class="popup-header fromDetailsPage">
          <h2 class="popup-title">Comment</h2>
          <span @click="$modal.hide('historyCommentPwd');selectedHistory=null">
            <em class="material-icons">close</em> 
          </span>
        </div>

        <div class="form-container">
                <div class="vx-row mb-2">
                    <div class="vx-col w-full comment_modal">
                        <p style="line-height: 20px" v-html="checkProperty(selectedHistory ,'comment')">
                         
                        </p>
                    </div>
                </div>
            </div>
            <div class="popup-footer">
                <vs-button color="dark" class="cancel" type="filled" @click="$modal.hide('historyCommentPwd');selectedHistory=null">Cancel</vs-button>
                
            </div>

       
        </div>
    </modal> 
       
 
    </div>
 </template>
 
 <script>
 import Vue from 'vue';
 Vue.use(CKEditor);
 import _ from "lodash";
 import pwdCaseUpdates from "@/views/pwd/pwdCaseUpdates.vue";
 import permAdvertiseInfo from "@/views/petition/perm/permAdvertiseInfo.vue";
 import permJobDetails from "@/views/petition/perm/permJobDetails.vue";
 import CKEditor from '@ckeditor/ckeditor5-vue2';
 import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
 import docmentType from "@/views/common/docType.vue"
 import VuePerfectScrollbar from "vue-perfect-scrollbar";
 import capCaseUpdates from "@/views/cap/capCaseUpdates.vue";
 import pwdCaseProcess from "@/views/pwd/pwdCaseProcess.vue";
 import pwdCaseStatusList from "@/views/pwd/pwdCaseStatusList.vue";
 import pwdCaseDocs from "@/views/pwd/pwdCaseDocs.vue";
 import notes from "@/views/notes.vue";
 import educationInfo from "@/views/petition/subtabs/educationsVersion2.vue";
 import personalInfo from "@/views/cap/capPersonalDetails.vue";
 import immiInput from "@/views/forms/fields/simpleinput.vue";
 import immitextarea from "@/views/forms/fields/simpletextarea.vue";
 import selectField from "@/views/forms/fields/simpleselect.vue";
 import FileUpload from "vue-upload-component/src";
 import axios from '@/axios.js';
 export default {
    provide() {
       return {
          parentValidator: this.$validator,
       };
    },
    data: () => ({
      selectedHistory:null,
      expandModal: false,
      caseCurrentDetails:[],
        petitionDetails:null,

       editor: ClassicEditor,
       editorConfig: {
          toolbar: ['bold', 'italic', '|', 'undo', 'redo', 'NumberedList', 'BulletedList',],
       },
       petitionhistory: [],
       formSubmited: false,
       selectedFile: '',
       docValue: "",
       docPrivew: false,
       docType: false,
       petitions: [],
       currentRole: null,
       setTab: false,
       visastatuses: [],
       getPetitionTab: null,
       petitionId: null,
       petition: null,
       ///////////////////////////
       activeTab: 'caseUpdate',
       routeId: '',
       routeQuery: '',
       linkShareToemailsText: "",
       users: [
          {
             "id": "B-1",
             "name": "24 September 2013",
             "email": "12 June 2013",
          },
          {
             "id": "H-1B",
             "name": "08 March 2017",
             "email": "18 January 2014",
          }
       ],
       USCISstatus: [
          { "name": 'Selected', 'id': 'Selected' },
          { "name": 'Not Selected', 'id': 'Not Selected' },
          { "name": 'Denied', 'id': 'Denied' },
          { "name": 'Invalidated-Failed Payment', 'id': 'Invalidated-Failed Payment' }
       ],
       casetype: [
          { "name": 'H-1B', 'id': 'H-1B' }
       ],
       casesubtype: [
          { "name": 'Master Cap - Consular Processing', 'id': 'Master' },
          { "name": 'Regular Cap - Consular Processing', 'id': 'Regular' }
       ],
       branchList: [
          { "name": 'Head Office', 'id': 'Head Office' }
       ],
       PetitionerList: [
          { "name": 'Berkshare LLP', 'id': 'Berkshare LLP' }
       ],
       BeneficiaryList: [
          { "name": 'Wasim Pathan', 'id': 'Wasim Pathan' }
       ],
 
 
       SubmitParalegal: false,
       SuccessQuestionnaire: false,
       branchvalue: { "name": 'Head Office', 'id': 'Head Office' },
       Petitionervalue: { "name": 'Berkshare LLP', 'id': 'Berkshare LLP' },
       Beneficiaryvalue: { "name": 'Wasim Pathan', 'id': 'Wasim Pathan' },
       assignLawOfficeModal:false,
       assignToModal:false,
       updateStatusModal:false,
 
    }),
    components: {
      pwdCaseUpdates,
      pwdCaseStatusList,
      permAdvertiseInfo,
      permJobDetails,
      notes,
       docmentType,
       VuePerfectScrollbar,
       capCaseUpdates,
       pwdCaseProcess,
       
       pwdCaseDocs,
       //ProcessFlow,
       personalInfo,
       educationInfo,
       immiInput,
       FileUpload,
       selectField,
       immitextarea
    },
    methods: {

      showHistoryComment(item=null){
      
      this.selectedHistory = item;
      if(this.checkProperty(this.selectedHistory ,'comment')){
        this.$modal.show('historyCommentPwd');
      }else{
        this.$modal.hide('historyCommentPwd');
      }

    },
      getWorkflowDetails(responce) {
      

        

     
        let payLoad = {
          path: "/workflow/details",
          data: { workflowId: responce.workflowId },
        };
        this.$store
          .dispatch("commonAction", payLoad)
          .then((workFlowDetails) => {
            responce['workFlowDetails'] = workFlowDetails;
            this.processPetitionData(responce);

          })
          .catch((error) => {

            this.processPetitionData(responce);
          });
      
    },
      openActionMenu(code){
         if(code){
            try {
               switch (code){
                  case 'COLLECT_ADV_EVIDENCE_EDIT':
                     this.$refs['pwd_process_flow'].$refs['pwd_actionsMenu'].$refs["pdwActionsPopup"].openPermAdvrtisementModal()
                  break;

                  case 'JOB_DESC_SUGGESSION':
                     this.$refs['pwd_process_flow'].$refs['pwd_actionsMenu'].$refs["pdwActionsPopup"].openPermJobDescActionsModal('JOB_DESC_SUGGESSION')
                  break;

                  case 'APPROVE_JOB_DESC':
                     this.$refs['pwd_process_flow'].$refs['pwd_actionsMenu'].$refs["pdwActionsPopup"].openPermJobDescActionsModal('APPROVE_JOB_DESC')
                  break;

                  case 'JOB_DESC_APPROVE_OR_SUGGESSION': 
                     this.$refs['pwd_process_flow'].$refs['pwd_actionsMenu'].$refs["pdwActionsPopup"].openPermJobDescActionsModal('JOB_DESC_APPROVE_OR_SUGGESSION')
                  break;
                  case 'FINALIZE_JOB_DESC':
                     this.$refs['pwd_process_flow'].$refs['pwd_actionsMenu'].$refs["pdwActionsPopup"].openPermJobDescActionsModal('FINALIZE_JOB_DESC')
                  break;
                  case 'REQUEST_JOB_DESC_REVIEW':
                     this.$refs['pwd_process_flow'].$refs['pwd_actionsMenu'].$refs["pdwActionsPopup"].openPermJobDescActionsModal('REQUEST_JOB_DESC_REVIEW')
                  break;
                  case 'APPROVE_JOB_DESC_EDIT':
                     this.$refs['pwd_process_flow'].$refs['pwd_actionsMenu'].$refs["pdwActionsPopup"].openJobDescription('JOB_DESC_SUGGESSION'); 
                  break;
                  case 'SUGGEST_JOB_DESC_EDIT':
                     this.$refs['pwd_process_flow'].$refs['pwd_actionsMenu'].$refs["pdwActionsPopup"].openPermJobDescActionsModal('JOB_DESC_SUGGESSION');
                  break;
                  case 'EFILE_PWD_DOL':
                     this.$refs['pwd_process_flow'].$refs['pwd_actionsMenu'].$refs["pdwActionsPopup"].openPwdEfilingDOL();
                  break;
                  case 'EFILE_PWD':
                     this.$refs['pwd_process_flow'].$refs['pwd_actionsMenu'].$refs["pdwActionsPopup"].openPwdEfiling();
                  break;
                  case 'UPDATE_PWD_RESPONSE':
                     this.$refs['pwd_process_flow'].$refs['pwd_actionsMenu'].$refs["pdwActionsPopup"].openUpdatePwdResponse();
                  break;
                  case 'SUBMIT_RFI_RESPONSE':
                     this.$refs['pwd_process_flow'].$refs['pwd_actionsMenu'].$refs["pdwActionsPopup"].openPermJobDescActionsModal('SUBMIT_RFI_RESPONSE');
                  break;
                  case 'COLLECT_ADV_EVIDENCE':
                     this.$refs['pwd_process_flow'].$refs['pwd_actionsMenu'].$refs["pdwActionsPopup"].openPermAdvrtisementModal();
                  break;
                  case 'COLLECT_ADV_EVIDENCE_EDIT':
                     this.$refs['pwd_process_flow'].$refs['pwd_actionsMenu'].$refs["pdwActionsPopup"].openPermAdvrtisementModal();
                  break;
               }
            }catch(e){
              
            }
         }
      },
      processPetitionData(response){


     if(this.checkProperty(response ,'completedActivities')){
      if(response['completedActivities'].indexOf('PWD_MISSING_EFILE_INFO')<=-1){


   
            let moreJobDetails = {
            "jobId": "",
            "noOfPositions": "",
            "salary": "",
            "jobType": "",
            "jobShift": "",
            "hoursPerWeek": null,
            "applicationInfo": {
                "applyByMail": "",
                "jobStartsOn": "",
                "jobEndOn": ""
            }
        }
        moreJobDetails['noOfPositions']= this.checkProperty( response , 'noOfPositions');
       let wageInfo = {
            "trackingNumber": "",
            "preferredSocCode": '',
            "preferredWageRate": "",
            "payFrequency": "", // Year, Month, Bi-Weekly, Week, Hour
            "wageSource": "", // OES, CBA, Employer Conducted Survey, DBA, SCA, Other
            "wageSourceOtherDesc": "",
            "determinationDate": "",
            "expirationDate": ""
        }
        let wageOfferInfo= {
            "minWage": "",
            "maxWage": "",
            "payFrequency": "" // Year, Month, Bi-Weekly, Week, Hour
        }
        let jobOpportunityInfo= {
      
                  workAddresses: [
                  {
               "companyName": "",
               "workLocation": true,
               line1: "",
               line2: "",
               zipcode: "",
               countryId: "231",
               stateId: "",
               locationId: "",
               "countryDetails": { "_id": "626a8f03a972fa4d60681140", "id": 231, "name": "United States", "phoneCode": 1, "order": 1, "currencySymbol": "$", "currencyCode": "USD", "zipcodeLength": 5, "sortName": "united states" },
               stateDetails: null,
               locationDetails: null,
               aptType:''
            }
                  ],
                  jobTitle: '',
                  minDegree: null,
                  majorFieldsOfStudy: null,
                  isTrainigRequired: 'No', // Yes/No // Is training required for the job opportunity?
                  noOfTraningMonths: null, //  If Yes, number of months of training required
                  fieldOfTraining: '', // Indicate the field of training:
                  isExpRequired: 'No', // Yes/No // Is experience in the job offered required for the job?
                  noOfExpMonths: null, //  If Yes, number of months experience required
                  isAltFieldOfStudyAccept: 'No', // Yes/No // Is there an alternate field of study that is acceptable?
                  altMajorFieldOfStudy: '', //  If Yes, specify the major field of study
                  isAltCombOfEduAndExpAccept: 'No', // Yes/No // Is there an alternate combination of education and experience that is acceptable
                  altLevelOfEdu: null, // If Yes, specify the alternate level of education required
                  altAcceptExpInYears: null, // If applicable, indicate the number of years experience acceptable
                  foreignEduEqAccept: 'No', // Yes/No // Is a foreign educational equivalent acceptable?
                  isExpInAltOccuAccept: 'No', // Yes/No // Is experience in an alternate occupation acceptable?
                  noOfExpMonthsInAltOccu: null, // If Yes, number of months experience in alternate occupation required
                  jobTitleOfAcceptAltOccu: '', // Identify the job title of the acceptable alternate occupation
                  jobDuties: '', // Job duties – If submitting by mail, add attachment if necessary. Job duties description must begin in this space
                  jobOppoReqForNormalOccu: 'No', // Yes/No // Are the job opportunity’s requirements normal for the occupation?
                  isForiegnLangRequired: 'No', // Yes/No // Is knowledge of a foreign language required to perform the job duties?
                  skills: [], // Specific skills or other requirements – If submitting by mail, add attachment if necessary. Skills description must begin in this space. 
                  isApplInvolJobOppoInclCombOfOccu: 'No', // Yes/No // Does this application involve a job opportunity that includes a combination of occupations?
                  positionOfferToAlien: 'No', // Yes/No // Is the position identified in this application being offered to the alien identified in Section J?
                  alienReqToLiveEmplrPrimisis: 'No', // Yes/No //  Does the job require the alien to live on the employer’s premises?
                  applLiveInHouseDomWorker: 'No', // Yes/No // Is the application for a live-in household domestic service worker?
                  emplrProviedAlienCopyOfContract: 'NA' // Yes/No/NA // If Yes, have the employer and the alien executed the required employment contract and has the employer provided a copy of the contract to the alien?
                  
            }
        
        response =Object.assign(response ,{"moreJobDetails":moreJobDetails,"wageInfo":wageInfo,"wageOfferInfo":wageOfferInfo ,"jobOpportunityInfo":jobOpportunityInfo });

        response =_.cloneDeep(response)
        

         

      }


     }



         if(_.has( response ,'jobDetails.minDegree') && _.has( response ,'highestDegreeList') ){
                    let minDegreeDetails = _.find(response['highestDegreeList'] ,{"id":response['jobDetails']['minDegree'] });
                    if(minDegreeDetails && _.has(minDegreeDetails ,'name')){
                     response['jobDetails']['minDegreeDetails'] = minDegreeDetails
                    }
               }
               if(_.has( response ,'noOfPositions')  ){
                  response['jobDetails']['noOfPositions'] = response['noOfPositions'];
               }
               this.$vs.loading.close();
               this.petition = null;
               this.petition = null;
                this.petition = _.cloneDeep(response);                
                this.petitions =[];
                if (this.checkProperty(this.petition, "petitionerId")) {
                   let postdata = {
                      matcher: {getMasterDataOnly: false, petitionerIds: []},
                      "page": 1,
                      "perpage": 100
                   }
                    postdata['matcher']['petitionerIds'].push(this.petition['petitionerId']);
                  
                   
                   this.$store.dispatch("getList", { data: postdata, path: '/pwd/list', }).then((response) => {
                      this.petitions = response['list'];
                   });
                }
                if(this.petition && this.petition.completedActivities &&  (this.petition.completedActivities.indexOf('CREATE_JOB_DESC')>-1||
                  this.petition.completedActivities.indexOf('PWD_CERTIFID')>-1|| this.petition.completedActivities.indexOf('EFILE_PWD')>-1)){
                        this.setActivetab('Petition Updates', true);
                }else{
                  this.setActivetab('Job Details', true);
                }
              
                this.getcaseHistory();
      },
       loadPetetion(tab = "") {
         let self =this;
          let paylaod = {
            pwdId: ''
          }
          if (this.petition == null) {
            this.$vs.loading();
         }
          let path = '/pwd/details'
          paylaod['pwdId'] = this.petitionId
          this.getCaseCurrentDetails();
          this.getPetitionTab = "Case Details";
          this.$store.dispatch("commonAction", { "data": paylaod, "path": path })
             .then((response) => {
               response = Object.assign(response, {"workFlowDetails":null});
               response['workFlowDetails'] = null;
               if (self.checkProperty(response ,'workflowId')) {
                  self.getWorkflowDetails(response);
               }else{
                  self.processPetitionData(response);
               }
                
             }).catch((err) => {
               self.$vs.loading.close();
             })
       },
       setActivetab(stab = "Case Details", callFromClick = false) {
          if (!stab) {
             stab = "Case Details";
          }
          if(stab){
            this.getPetitionTab = null;
            this.getPetitionTab = stab
          }
         
 
       },
       reloadPetition(tab = "Case Details") {
          if (tab != "") {
          
             this.$store.dispatch("setPetitionTab", tab)
                .then(() => {
 
                   this.init(tab);
                })
                .catch((err) => {
 
                   this.init();
                });
          } else {
             this.$store.dispatch("setPetitionTab", "Case Details");
             this.init();
          }
       },
       getcaseHistory() {
          if (this.petitionId) {
          
             let postData = {
                "pwdId": '', "page": 1,
                "perpage": 500
             };
             postData['pwdId'] = this.petitionId;
 
             this.$store
                .dispatch("getList", {
                   data: postData,
                   path: '/pwd/activity-list',
                }).then((response) => {
 
                   this.petitionhistory = response['list'];
                });
 
          }
 
 
       },
       init(tab = '') {
          //this.updatePetiotionActionBtn(false);
          this.currentRole = this.$store.state.user.loginRoleId;
          this.currentUserId = this.$store.state.user._id;
          this.loadPetetion(tab);
          this.$store.dispatch("getmasterdata", "visa_status").then((response) => {
             this.visastatuses = response;
          });
       },
       petetionChange(id) {
          this.setActivetab("Case Details", true);
          this.petition = null;
          this.petitionId = id;

          setTimeout(() => {
                   this.init();
                }, 5);
                setTimeout(() => {
                   this.init();
                }, 5);
          
          this.updateUrl();
       },
       updateUrl() {
            this.$route["params"]["itemId"] = _.cloneDeep(this.petitionId);
      },
       download_or_view(docItem) {
 
 
          let value = _.cloneDeep(docItem);
          this.expandModal= false;
         //  if (this.checkProperty(this.getPetitionDetails, 'caseNo') && this.checkProperty(value, 'name')) {
         //     let docName = _.cloneDeep(value['name']);
         //     value['name'] = this.checkProperty(this.getPetitionDetails, 'caseNo') + "_" + docName;
         //  }
          let docName = _.cloneDeep(value['name']);
             value['name'] = docName;
 
 
          var _self = this;
          this.formSubmited = false;
          if (_.has(value, "path")) {
             value["url"] = value["path"];
             value["document"] = value["path"];
          }
 
          if (_.has(value, "url")) {
             value["path"] = value["url"];
             value["document"] = value["url"];
          }
 
          if (_.has(value, "document")) {
             value["path"] = value["document"];
             value["url"] = value["document"];
          }
          value = Object.assign(value, { 'petitionId': this.petition['_id'] })
          value = Object.assign(value, { 'subTypeDetails': this.petition['subTypeDetails'] })
 
 
          this.selectedFile = value;
          this.docValue = "";
          this.docPrivew = false;
          this.docType = false;
          this.docType = this.findmsDoctype(value);
 
          if ((this.docType == "office" || this.docType == "image" || this.docType == "pdf")) {
             //if ( (this.docType == "office" || this.docType == "image" || this.docType == "pdf") && value.download == false ) {
             value.url = value.url.replace(this.$globalgonfig._S3URL, "");
             value.url = value.url.replace(this.$globalgonfig._S3URLAWS, "");
             let postdata = {
                keyName: value.url,
                "petitionId": value['petitionId'],
 
                // entityType:value['petitionId']
                // "fileName":value.name?value.name:''
             };
             if (this.checkProperty(value, 'subTypeDetails', 'id') == 15) {
                postdata['entityType'] = 'perm'
             } else {
                postdata['entityType'] = 'case'
             }
 
 
             this.$store.dispatch("getSignedUrl", postdata).then((response) => {
                this.docValue = response.data.result.data;
 
                if (this.docType == "office") {
                   document.getElementById("placeholder").innerHTML = "  <div  id='placeholder2' style='height:100%'></div>";
                   let _editing = true;
 
                   if ([50, 51].indexOf(this.getUserRoleId) > -1) {
                      _editing = false;
                   }
 
                   if (value.viewmode) {
                      _editing = false;
                   }
                   var _ob = {}
                   if (value.editedDocument) {
                      _ob = {
 
                         petitionId: this.petition._id,
                         name: value.name,
                         _id: value._id,
                         "extn": "docx",
                         "formLetterType": "Letter",
                         parentId: value.parentId
                      }
 
                   } else {
 
                      _ob = {
 
                         name: value.name,
                         petitionId: this.petition._id,
                         _id: value._id,
                         "extn": "docx",
                         "formLetterType": "Letter",
                         parentId: value._id
 
                      }
 
                   }
 
 
                   window.docEditor = new DocsAPI.DocEditor("placeholder2",
                      {
 
                         "document": {
                            "c": "forcesave",
                            "fileType": "docx",
                            "key": value._id,
                            "userdata": JSON.stringify(_ob),
                            "title": value.name,
                            "url": response.data.result.data,
                            permissions: {
                               edit: _editing,
                               download: true,
                               reader: false,
                               review: false,
                               comment: false
                            }
                         },
 
                         "documentType": "word",
                         "height": "100%",
                         "width": "100%",
 
                         "editorConfig": {
                            "userdata": JSON.stringify(_ob),
                            "callbackUrl": "https://immibox.com/api/perm/post-edited-document?payload=" + JSON.stringify(_ob) + "&token=" + _self.$store.state.token + "&name=" + value.name.replace('.docx', ''),
                            "customization": {
                               "logo": {
                                  "image": "https://immibox.com/app/favicon.png",
                                  "imageDark": "https://immibox.com/app/favicon.png",
                                  "url": "https://immibox.com"
                               },
                               "anonymous": {
                                  "request": false,
                                  "label": "Guest"
                               },
                               "chat": false,
                               "comments": false,
                               "compactHeader": false,
                               "compactToolbar": true,
                               "compatibleFeatures": false,
                               "feedback": {
                                  "visible": false
                               },
                               "forcesave": true,
                               "help": false,
                               "hideNotes": true,
                               "hideRightMenu": true,
                               "hideRulers": true,
                               layout: {
                                  toolbar: {
                                     "collaboration": false,
                                  },
                               },
                               "macros": false,
                               "macrosMode": "warn",
                               "mentionShare": false,
                               "plugins": false,
                               "spellcheck": false,
                               "toolbarHideFileName": true,
                               "toolbarNoTabs": true,
                               "uiTheme": "theme-light",
                               "unit": "cm",
                               "zoom": 100
                            },
                         }, events: {
                            onReady: function () {
 
                            },
                            onDocumentStateChange: function (event) {
                               var url = event.data;
                               if (!event.data) {
 
                                  if (value.editedDocument) {
 
                                  }
 
                               }
                            }
 
                         }
                      });
                   //this.docValue = encodeURIComponent(response.data.result.data);
                }
 
                if (this.docType == "pdf") {
 
                   // this.downloadFile(this.docValue, value.mimetype, value.name)
 
                   // return
                   var _vid = value._id;
                   if (value.parentId) {
                      _vid = value.parentId;
                   }
                   var viewmode = 1; // Enable edit
                   viewmode = 0; //Disabled Edit
                   if (value.viewmode) {
                      viewmode = 0;
                   }

                   let pdfViewUrl ='https://immibox.com/viewer/pdfjs-dist/web/viewerv2.html';            
                  if(_.has(this.$globalgonfig, 'PDF_VIEW_URL')){
                     pdfViewUrl = this.$globalgonfig['PDF_VIEW_URL']; //PDF_EDIT_URL
                  }
                  if(viewmode==1){
                     if(_.has(this.$globalgonfig, 'PDF_EDIT_URL')){
                        pdfViewUrl = this.$globalgonfig['PDF_EDIT_URL'];
                     }
                 }

                   this.docValue = pdfViewUrl+"?view=" + viewmode + "+&file=" + encodeURIComponent(response.data.result.data);
                }
                 this.docPrivew = true;
             });
          } else {
 
 
 
             this.downloads3file(value);
          }
 
       },
 
       downloadFile(url, mimetype, fireName) {
          axios({
             url: url,
             method: 'GET',
             responseType: 'blob',
          }).then((res) => {
             var FILE = window.URL.createObjectURL(new Blob([res.data], { type: mimetype }));
 
             var docUrl = document.createElement('x');
             docUrl.href = FILE;
             docUrl.setAttribute('download', fireName);
             document.body.appendChild(docUrl);
             docUrl.click();
          });
       },
       getCaseCurrentDetails(){
         if(this.petitionId){
         let self = this;
         let postData ={
            "pwdId":self.petitionId,
         }
         this.caseCurrentDetails =[];
         this.$store.dispatch("commonAction", {data:postData,path:'/pwd/get-current-at-details'}).then((response) =>{ 
            if(this.checkProperty(response ,"agingLogs"  )){
               this.caseCurrentDetails = response['agingLogs'];  
            }
         })
         }
      },

    },
    mounted() {
       if (this.$route.params && this.$route.params.itemId) {
          this.petitionId = this.$route.params.itemId;
          if (this.loadedFromPreview && this.previewData) {
             this.setActivetab('Job Details', true);
             this.petition = _.cloneDeep(this.previewData);
          } else {
             this.init();
          }
       }
       //this.loadPetetion();
    },
    props: {
       loadedFromPreview: false,
       previewData: null,
    },
    computed: {
      checkCompletedActivity(){
      return (activityCode)=>{
      if(this.checkProperty(this.petition ,'completedActivities' ,'length')>0){
        if(this.petition['completedActivities'].indexOf(activityCode)>-1){
          return true
        }
        else{
          return false
        }
      }else{
        return false
      }
    }
    },
       checkCaseStatus() {
          if (this.checkProperty(this.petition, 'intStatusDetails', 'id') == 1) {
             return this.checkProperty(this.petition, 'intStatusDetails', 'id')
          }
          else {
             return 4
          }
       },
       checkCaseCreatedLogin() {
          let returnVal = true
          let createdBy = null;
          if (this.petition && this.checkProperty(this.petition, 'createdBy')) {
             createdBy = this.checkProperty(this.petition, 'createdBy')
             if (this.checkProperty(this.getUserData, 'userId') && (createdBy == this.checkProperty(this.getUserData, 'userId'))) {
                returnVal = true
             } else {
                returnVal = false
             }
          }
          return returnVal
       }
    }
 }
 </script>