<template>
   
      <modal
            name="createPwdPopUp"
            classes="v-modal-sec"
            :min-width="200"
            :min-height="200"
            :scrollable="true"
            :reset="true"
            width="650px"
            height="auto"
          >
          <!-------UPDATE_PWD_RESPONSE == PWD_CERTIFID EFILE_PWD-->
          <div class="v-modal profile_details_modal error-modal-space pwd_popup" >
            <div class="popup-header fromDetailsPage">
              <h2 class="popup-title" v-if="ACTIVITYCODE=='UPDATE_PWD_RESPONSE'">Update PWD Response</h2>
              <h2 class="popup-title" v-if="ACTIVITYCODE=='EFILE_PWD'">Update PWD Tracking Info</h2>
              <h2 class="popup-title" v-if="ACTIVITYCODE=='EFILE_PWD_DOL'">E-File PWD</h2>
              <h2 class="popup-title" >Update PWD</h2>
              <span @click="showPopup=false;$modal.hide('createPwdPopUp');"> 
                <em class="material-icons">close</em>
              </span>
            </div>
            <div class="form-container" v-if="ACTIVITYCODE=='EFILE_PWD_DOL'">
              

              <div class="modal-confirm-msg">
                    <p>Using our Browser Extension PERM details can be filled automatically
                     </p>
                    <div class="popup-footer pl-0 pr-0">
                  <a @click="showPopup=false;$modal.hide('createPwdPopUp');"  href="https://flag.dol.gov/auth/auth/login-gov/login/loa-1" target="_blank"> <vs-button color="success" class="save" type="filled">Click here to proceed</vs-button>
                  </a></div>
               </div>
            </div>
           
            <form  @submit.prevent data-vv-scope="uscisstatus" class="trackingform">
                <div class="form-container pb-0" @click="pewResponceUpdateStatusError='';showDocumentsError=false">
                  <template >
                        
                  <div class="vx-row" >

                    
                    <div class="vx-col  w-full" v-if="ACTIVITYCODE=='UPDATE_PWD_RESPONSE'" >
                      <div class="form_group">
                        <label class="form_label">PWD Action<em>*</em></label>
                      <div class="con-select w-full DT_multiselect">                  
                        <multiselect
                          name="casestatus"
                          v-validate="'required'"
                          v-model="actionData.pwdAction"
                          :show-labels="false"
                          :data-vv-as="'PWD Action'"
                          track-by="id"
                          label="name"
                           @input="pwdActionchanged"
                          placeholder="Choose Action"
                          :options="pwdActionsList"
                          :searchable="true"
                          :allow-empty="false"
                        ></multiselect>
                      </div>
                      <span
                        class="text-danger text-sm"
                        v-show="errors.has('uscisstatus.casestatus')"
                      >{{ errors.first("uscisstatus.casestatus") }}</span>
                      </div>
                    </div>
                   
                                       
                    <div class="vs-col w-full" v-if="['PWD_CERTIFID','PWD_RFI_RECEIVED'].indexOf(ACTIVITYCODE)>-1"  >
                      
                        
                       
                       
                      <div class="vx-row">
                        
                       <!-------->
                         <template v-if="this.checkProperty(this.actionData ,'pwdAction','id')=='PWD_CERTIFID'" >
                        <immiInput  :wrapclass="'md:w-1/2'" :display="true" cid="jobTitle" :formscope="'uscisstatus'" v-model="actionData.jobTitle" :required="true" fieldName="jobTitle" label=" Job Title" placeHolder=" Job Title"  />
                        <immiInput :onlyNumbers="true" :wrapclass="'md:w-1/2'" :display="true" :cid="'wageRate'" :formscope="'uscisstatus'" v-model="actionData.wageRate" :required="true" fieldName="wageRate" label="Wage Rate per Year" placeHolder="Wage Rate"  />
                        <selectField :wrapclass="'md:w-1/2'" :required="true"  cid="socCode"  :formscope="'uscisstatus'" :optionslist="masterSocList" v-model="actionData.socCodeDetails" @input="updatesocCode"   fieldName="socCod" label="SOC Code " placeHolder="SOC Code "   />  
                      </template>                         
                          
                      
                           <datepickerField 
                             v-if="ACTIVITYCODE=='PWD_CERTIFID'"
                              wrapclass="md:w-1/2"
                              @input="updateissuedDate($event)"
                              :display="true"  
                              v-model="actionData.issuedDate" 
                              :formscope="'uscisstatus'"  
                              fieldName="issuedDate" 
                              :dateEnableTo="new Date()" 
                              label="Receipt Date" 
                              :validationRequired="true" 
                                />
                      

                        <datepickerField 
                            wrapclass="md:w-1/2" 
                           
                            :display="true"  
                            v-model="actionData.receivedDate" 
                            :formscope="'uscisstatus'"  
                            fieldName="receivedDate" 
                           
                            :dateEnableTo="new Date()" 
                            label="Received Date" 
                            :validationRequired="true"
                           />    
                        
                        <datepickerField  :isDisabled="!actionData.issuedDate && ACTIVITYCODE==='PWD_CERTIFID'"
                        wrapclass="md:w-1/2" 
                        :display="true"  
                        v-model="actionData.dueDate" 
                        :formscope="'uscisstatus'"  
                        fieldName="dueDate" 
                        :dateEnableFrom="actionData.receivedDate" 
                        :label="ACTIVITYCODE==='PWD_RFI_RECEIVED'?'Due Date':'Expiration Date'" 
                        :validationRequired="true"   />
                      </div>
                    </div>
                    
                   
                    <div class="vx-col w-full" v-if="['PWD_CERTIFID', 'PWD_RFI_RECEIVED','SUBMIT_RFI_RESPONSE'].indexOf(ACTIVITYCODE)>-1">
                    <div class="form_group">
                      <label class="form_label">Comments<em>*</em></label>
                      
                      <ckeditor  data-vv-as="Comments"
                        v-validate="'required'"
                        v-model="actionData.description"
                        name="usciscomments"
                        class="w-full" :editor="editor" :config="editorConfig"></ckeditor>

                      <span
                        class="text-danger text-sm"
                        v-show="errors.has('uscisstatus.usciscomments')"
                      ><em>*</em> Comments are required</span>
                    </div>
                    </div>
                  
                
                    
                    
                  </div>
                  <!------v-if="ACTIVITYCODE=='EFILE_PWD'"-->
                  <template v-if="ACTIVITYCODE=='EFILE_PWD'"  >
                    <div class="vx-row">
                      
                      <immiInput :maxCharacters="25" :wrapclass="'md:w-full'" :display="true" :cid="'trackingNumber'" :formscope="'uscisstatus'" v-model="actionData.trackingNumber" :required="true" fieldName="trackingNumber" label="Tracking Number" placeHolder="Tracking Number"  />
                    </div>
                  </template>


                  <div  class="vx-row" @click="documentModel=[];pwdDocFormatError=''" >

                   
                    <div  class="vx-col w-full mt-2" v-if="ACTIVITYCODE=='PWD_CERTIFID'"  >
                      <div class="form_group">
                        <label class="form_label">Document Type<em>*</em></label>
                        <div class="con-select w-full DT_multiselect">  
                        
                          <multiselect
                            :name="'documentType'"
                            v-validate="'required'"
                            v-model="actionData.documentType"
                            :show-labels="false"
                            :disabled="['EFILE_PWD'].indexOf(ACTIVITYCODE)>-1"
                            data-vv-as="Document Type"
                            placeholder="Document Type"
                            :options="documentTypes"
                            :searchable="true"
                            :allow-empty="false"
                          >
                          </multiselect>
                        
                          <span  class="text-danger text-sm"  v-show="errors.has('uscisstatus.documentType')"  >{{ errors.first('uscisstatus.documentType') }}</span>
                        </div>
                      </div>
                    </div>
                   
                   <!---- v-if="ACTIVITYCODE !='INITIATED_PWD'"--->
                    <div div class="vx-col w-full" v-if="[ 'EFILE_PWD','PWD_CERTIFID' ,'PWD_RFI_RECEIVED','SUBMIT_RFI_RESPONSE'].indexOf(ACTIVITYCODE)>-1" >
                      <div class="form_group">
                        <label class="form_label d-flex" style="text-transform: capitalize"> 
                           <template v-if="[ 'EFILE_PWD'].indexOf(ACTIVITYCODE)>-1" >PWD Acknowledgment <em>*</em></template>
                           <template v-else-if="[ 'UPDATE_PWD_RESPONSE'].indexOf(ACTIVITYCODE)>-1" >
                          
                            {{ACTIVITYCODE=='PWD_CERTIFID'?'Certified PWD':'Documents'}}
                            
                          
                          </template>
                          <template v-else>Documents</template>
                          
                        
                          <template v-if="[ 'EFILE_PWD','PWD_CERTIFID'].indexOf(ACTIVITYCODE)>-1">
                          <em >{{ACTIVITYCODE=='PWD_CERTIFID'?'*':''}}</em>
                          <div class="IB_tooltip"   >
                            <span ><info-icon size="1.5x" class="custom-class"></info-icon ></span>
                            <div class="tooltip_cnt"   > 
                               <p v-if="[ 'EFILE_PWD'].indexOf(ACTIVITYCODE)>-1">  Make sure to upload the acknowledgment of PWD Filed.</p>
                               <p v-if="[ 'PWD_CERTIFID'].indexOf(ACTIVITYCODE)>-1"> 
                                 Make sure to upload Certified PWD.</p>
                            </div>
                          </div>
                        </template>
                        </label>
                      <div class="uploadsec_wrap upload_uscis">
                        <div class="w-full">
                            <div class="relative">
                              <file-upload
                                v-model="documentModel"
                                class="file-upload-input mb-0"
                                style="height:50px;"
                                name="trackingdoc"
                                :multiple="true"
                               
                                data-vv-as="Documents"
                                :accept="pdfDocEntity"
                                @input="uploadDocuments()"
                              >
                                <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                                Upload
                              </file-upload>
                              <span class="loader" v-if="filesAreuploading"><img src="@/assets/images/main/loader.gif"></span>
                              <span v-if="showDocumentsError && actionData['documents'].length<=0 "  class="text-danger text-sm"  ><em>*</em> 
                                <template v-if="[ 'EFILE_PWD'].indexOf(ACTIVITYCODE)>-1" >PWD Acknowledgment is required</template>
                                <template v-if="[ 'PWD_CERTIFID'].indexOf(ACTIVITYCODE)>-1" >Certified PWD is required</template>
                                </span>
                  
                            </div>
                          <span class="file-type">(File Type: PDF)</span>
                          
                          
                              
                                <div class="uploded-files_wrap mb-5" v-if="actionData['documents'].length >0 ">
                                    <template v-for="(fil, fileindex) in actionData['documents']">
                                      <div class="w-full"  :key="fileindex" >
                                          <div class="uploded-files">
                                              <vx-input-group class="form-input-group">
                                                <vs-input v-on:keyup="fileNameChenged(fil)"  v-validate="'required'" class="w-full" :name="'fName'+fileindex" v-model="actionData['documents'][fileindex]['name']" data-vv-as="File Name" />
                                                  <span class="text-danger text-sm" v-show="errors.has('uscisstatus.fName'+fileindex)">{{ errors.first('uscisstatus.fName'+fileindex) }}</span>

                                                  
                                              </vx-input-group>

                                              <div class="form_group">
                                              

                                                
                                              <div class="delete" style="z-index:999" @click="remove(fileindex , actionData['documents']) ;resetPrefedKyes()">
                                                      <img src="@/assets/images/main/delete-row-img.svg" />
                                                  </div>
                                              </div>
                                          </div>
                                      </div>
                                   </template>
                                </div>
                            
                          </div>
                      </div>
                      </div>
                    </div>

                   

                  
                  </div>

                </template>
                  
                  
                </div>
                
                <div @click="pewResponceUpdateStatusError=''" class="text-danger text-sm formerrors" v-if="pewResponceUpdateStatusError!=''">
                          <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ pewResponceUpdateStatusError }}</vs-alert>
                </div>

                <div class="popup-footer relative">
                <span class="loader" v-if="pwdResUpdating"><img src="@/assets/images/main/loader.gif"></span>
                  <vs-button color="dark" class="cancel" type="filled" @click="documentModel=[]; hideMe()">Cancel</vs-button>
                  <vs-button color="success" :disabled="pwdResUpdating" @click="submitForm()" class="save" type="filled">Submit</vs-button>
                </div>
            </form>
            </div>
          </modal>  
</template>
<script>
  import { InfoIcon } from "vue-feather-icons";

import moment from "moment";
import FileUpload from "vue-upload-component/src";
import { EyeIcon } from "vue-feather-icons";
import docType from "@/views/common/docType.vue";
import Datepicker from "vuejs-datepicker-inv";
import datepickerField from "@/views/forms/fields/datepicker.vue";
import * as _ from "lodash";
import immiInput from "@/views/forms/fields/simpleinput.vue";
import immitextarea from "@/views/forms/fields/simpletextarea.vue";
import selectField from "@/views/forms/fields/simpleselect.vue";
import Vue from 'vue';
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';

export default {
  provide() {
          return {
             parentValidator: this.$validator,
          };
      },
  components: {
    InfoIcon,
    docType,
    EyeIcon,
    FileUpload,
    Datepicker,
    immiInput,
    immitextarea,
    selectField,
    datepickerField
  },
  methods: {
    prefillcheckStatus(){
      var _dt;
      
    if(this.actionData['documents'].length>0){
     
    
    let path ="/common/extract-data-from-pdf";
    let postData ={
      "docType": "pwd",
      documents:[],
    };
    //postData['documents'] = this.pwdResponse['documents']
    _.forEach(this.actionData['documents'] ,(doc)=>{
        postData['documents'].push(doc.path)
        //return doc.path;
    });
    this.$vs.loading();
    this.$store.dispatch('commonAction', {"data":postData ,"path":path})
        .then((response)=>{
         
          let responseData = response['jobDetails'];
        
          if(this.checkProperty(responseData ,"pwdStatus") !='Filed' ){
            this.showToster({message:"It seems, You haven't uploaded the Filed document. Upload a valid document to continue.",isError:true });
           // this.showToster({"message":"It seems, You haven't uploaded the Filed document. Upload a valid document to continue." ,"isError":true});
              
              this.actionData['documents'] =[];
             
            }
          
          
          this.$vs.loading.close();
        }).catch((errr)=>{
          this.showToster({message:"It seems, You haven't uploaded the Filed document. Upload a valid document to continue.",isError:true });
          this.$vs.loading.close();
          this.actionData['documents'] =[];
         
        });
      }

    },
    pwdActionchanged(){
     
    
      this.actionData.issuedDate =null;
      this.actionData.jobTitle ='';
      this.actionData.wageRate ='';
      this.actionData.socCodeDetails =null;
      this.actionData.socCode =null;      
      this.actionData.documentType ='Original';
      this.pwdDocFormatError ='';
     // this.ACTIVITYCODE =   this.checkProperty(this.actionData ,'pwdAction','id');
      this.actionData['action']=  this.checkProperty(this.actionData ,'pwdAction','id');
      this.actionData['statusId']=  this.checkProperty(this.actionData ,'pwdAction','statusId');
    
            
   
    },
    resetPrefedKyes(){
      let tempActionData = {
          // "petitionId": "",
          // "action": 'UPDATE_PWD_RESPONSE',//"EFILE_PWD",'UPDATE_PWD_RESPONSE'
          // "typeName": "t",
          // "subTypeName": "",

          wageRate: "",
          socOccuTitle: "",
          preferredSocOccuTitle:"",

          /**** Required for UPDATE_PWD_RESPONSE ****/
          "issuedDate": null,
          "receivedDate": null,
          "dueDate": null,
          "description": "",
          "documents": [],
          "documentType": "Original",
          //pwdStatus:'',
        
          "socCode": null,//4, // Type Number when updating from ImmiBox App
          "socCodeDetails": null,//"13-1111.00", // Type String when update from DOL
          "isSocCodeDetails":false,// true, // Send as true when update from DOL
          "wageRate": "",
          trackingNumber:'',
          "jobTitle":'',
        }
      _.forEach(this.actionData , (item ,key)=>{
            if(this.prefilledKyes.indexOf(key)>-1){
              this.actionData[key] = null;
              if(_.has(tempActionData , key)){
                this.actionData[key] = tempActionData[key];
              }else{
                this.actionData[key] = null;
              }
            }
        });  
        
        this.$validator.reset();

    },
    prefillJobDetails(){
      this.pwdDocFormatError ='';
      if(this.actionData.documents.length>0){
        this.$vs.loading();
      this.filesAreuploading = true;  
       this.pwdResUpdating =true;
      let path ="/common/extract-data-from-pdf";
      let postData ={
      "docType": "pwd",
      documents:[],
      };
      //postData['documents'] = this.pwdResponse['documents']
      _.forEach(this.actionData['documents'] ,(doc)=>{
      postData['documents'].push(doc.path)
        //return doc.path;
      })
      this.$store.dispatch('commonAction', {"data":postData ,"path":path})
        .then((response)=>{
          this.filesAreuploading = false;  
          this.pwdResUpdating =false;
          let responseData = _.cloneDeep(response['jobDetails']);
            let pwdStatus = _.get(responseData ,"pwdStatus");
           
          _.forEach( this.actionData, (item ,key)=>{
           
            if((_.has(responseData ,key) && responseData[key]  ) && pwdStatus && pwdStatus =='Certified' ){
              this.actionData['pwdAction'] = {'name':'Certified' ,'id':'PWD_CERTIFID'}
              
                if(key!='pwdAction' && key !='description' ){

                  this.actionData[key] = responseData[key];
                  this.prefilledKyes.push(key);

                }

              
             
            
            }

          });
          if(['EFILE_PWD'].indexOf(this.ACTIVITYCODE>-1)){
            this.actionData.documentType ="Electronic";
          }
          
          this.$vs.loading.close();
        }).catch((errr)=>{
          this.pwdDocFormatError =errr;
          this.filesAreuploading = false;  
          this.pwdResUpdating =false;
          this.$vs.loading.close();
          if(['EFILE_PWD'].indexOf(this.ACTIVITYCODE>-1)){
           this.actionData.documentType ="Electronic";
          }
        });
      }

    },
    updateissuedDate(val){
      if(val){
        if(this.actionData['receivedDate']){
        let startData = moment(val);
        let endData= moment(this.actionData['receivedDate'])
        if(startData.isAfter(endData , 'day')){
          this.actionData['receivedDate'] = null
        }
      }
      if(this.actionData['dueDate']){
        let startDate = moment(val);
        let endDate= moment(this.actionData['dueDate'])
        if(startDate.isAfter(endDate , 'day')){
          this.actionData['dueDate'] = null
        }
      }
      }
    },
      updatesocCode(item){ 

        if(_.has( item ,'id')){
        this.actionData['socCode'] = item['id'];
        }
      },
    getMasterSocList(){

              let query = {};
              query["page"] = 1;
              query["perpage"] = 10000;
              query["matcher"] = {};
              query["category"] = "soc_codes";


              this.$store
              .dispatch("getMasterData", query)
              .then((response) => {
              this.masterSocList = response.list;

              if(['EFILE_PWD'].indexOf(this.ACTIVITYCODE>-1)){
              this.actionData.documentType ="Electronic";
              }


              //alert(this.perpage);
              })
              .catch(() => {
              this.masterSocList = [];

              });

    },
    remove(index ,docs){
      docs.splice(index ,1);
      this.showDocumentsError =false;
      if(this.actionData['documents'].length<=0){
        this.showDocumentsError =true;
    }

    },
    /**
     * 
     * @param userType | String
     * @param typeId | String
     * @param childrenId | String
     * @param userName | String
     */
    uploadDocuments(){
      this.pwdDocFormatError ='';
         let docs =_.cloneDeep(this.documentModel);
         this.documentModel=[];
         var self = this;
            docs = docs.map(
                (item) =>{
                    item = {
                        name: item.name,
                        file: item.file,
                        path: "",
                        mimetype: item.type,
                        extn:item.extn?item.extn:'',
                        documentType:item.documentType?item.documentType:null,
                        userName:'',
                        uploadedBy: self.checkProperty(self.getUserData, 'userId'),
                        uploadedByName: self.checkProperty(self.getUserData, 'name'),
                        uploadedByRoleId: self.getUserRoleId,
                        uploadedByRoleName: self.checkProperty(self.getUserData, 'loginRoleName'),
                        size:item.size ? item.size : null,

                       
                    }
                   
                    
                return item;

              }
            );
           
            if (docs.length > 0) {
               
                this.filesAreuploading = true;
                
                let count =0;
                docs.forEach(function (doc) {
                 
                if( (self.ACTIVITYCODE=='UPDATE_PWD_RESPONSE' || self.ACTIVITYCODE=='EFILE_PWD') && !( doc.mimetype=='application/pdf' )  ){
                   self.filesAreuploading = false;  
                   self.pwdDocFormatError ="Upload only pdf documents";         
                  return false;

                }
                    let formData = new FormData();
                    formData.append("files", doc.file);
                    formData.append("secureType", "private");
                    formData.append("getDetails", true);
                    self.$store.dispatch("uploadS3File", formData).then((response) => {
                      count = count+1;
                        if (response.data && response.data.result) {
                            response.data.result.forEach((urlGenerated) => {
                              //alert(JSON.stringify(urlGenerated))
                                // doc.url = urlGenerated;
                                 doc.path = urlGenerated['path'];
                                 doc.mimetype = urlGenerated['mimetype'];
                                  doc.extn = urlGenerated['extn'];
                                 
                                delete doc.file;
                                if(urlGenerated['path']){
                                  if(self.ACTIVITYCODE=='UPDATE_PWD_RESPONSE' || self.ACTIVITYCODE=='EFILE_PWD'){
                                    self.actionData['documents'] =[];
                                  }
                                   self.actionData['documents'].push(doc)
                                 //  self.statusDocuments.push(doc)
                                 self.showDocumentsError =false;
                                }
                                if(self.ACTIVITYCODE=='UPDATE_PWD_RESPONSE' ){
                                  //&& self.checkProperty(self.actionData ,'pwdAction','id') && self.checkProperty(self.actionData ,'pwdAction','id')!='PWD_RFI_RECEIVED'
                                  self.prefillJobDetails()
                                }
                                
                                if(parseInt(count)>=docs.length){
                                   self.filesAreuploading = false;
                                   self.pwdResUpdating =false;
                                   if([ 'EFILE_PWD'].indexOf(self.ACTIVITYCODE)>-1){
                                     self.prefillcheckStatus();

                                   }
                                 

                                }
                            });
                            if(count>=docs.length){

                              
                              self.filesAreuploading = false;
                              self.pwdResUpdating =false;
                              if([ 'EFILE_PWD'].indexOf(self.ACTIVITYCODE)>-1){
                               // self.prefillcheckStatus();

                              }
                           

                            }
                            
                        }
                       
                    });
                });
            }
    },
   
      
    fileNameChenged(index, fileindex) {
            this.disable_uploadBtn = false;

            _.forEach(this.actionData['documents'], (doc, value) => {
                let fname = doc.name;
                fname = fname.trim();

                if (!fname) {
                    this.disable_uploadBtn = true;
                }
            });

        },

  
      
    submitForm() {
      
            this.pewResponceUpdateStatusError='';
            this.showDocumentsError =false;
            this.pwdDocFormatError ='';
         
            this.$validator.validateAll("uscisstatus").then((result) => {
              //Documents are optional for EFILE_PWD  
              if(this.checkProperty(this.actionData ,'documents' ,'length')<=0 && [ 'EFILE_PWD',"UPDATE_PWD_RESPONSE"].indexOf(this.ACTIVITYCODE)>-1 ){
                if([ "UPDATE_PWD_RESPONSE"].indexOf(this.ACTIVITYCODE)>-1 ){
                  if(this.checkProperty(this.actionData ,'pwdAction','id')=='PWD_CERTIFID'){
                    this.showDocumentsError =true;
                  }else{
                    this.showDocumentsError =false;
                  }

                }else{
                  this.showDocumentsError =true;
                }
                
              }

               if(!this.showDocumentsError && result && !this.filesAreuploading){
                this.pwdResUpdating =true;
                let path ="/pwd/manage-pwd";
                let data
                if(this.ACTIVITYCODE =="UPDATE_PWD_RESPONSE"){
                   data = this.actionData;
                    data['action']  ='UPDATE_PWD_RESPONSE'; 
                    if(this.checkProperty( this.actionData ,'pwdAction' ,'id')){
                    
                      data['action']  =this.actionData['pwdAction']['id'];
                      if(this.actionData['pwdAction']['id'] =='PWD_RFI_RECEIVED'){

                         data = {
                              "pwdId": "",
                              "action": 'PWD_RFI_RECEIVED',
                              "typeName": "",
                              "subTypeName": "",
                              "receivedDate": null,
                              "dueDate": null,
                              "description": "",
                              "documents": [],
                              "documentType": "Original",
                             
                           }
                           data['action'] = 'PWD_RFI_RECEIVED';
                           data['receivedDate'] =this.actionData['receivedDate'];
                           data['dueDate'] =this.actionData['dueDate'];
                           data['description'] =this.actionData['description'];
                           data['documents'] =this.actionData['documents'];



                      }
                      
                      
                    }
                    
                }else if(this.ACTIVITYCODE =="EFILE_PWD"){
                    data = { 'trackingNumber':'' ,'petitionId':'' ,"typeName": "", 	"subTypeName": "", "action":'EFILE_PWD' ,"documentType":'Electronic',"documents":[]}; 
                    data['trackingNumber'] = this.actionData['trackingNumber'];
                 //   data['documentType'] = this.actionData['documentType'];
                    data['documents'] = this.actionData['documents'];
                   
                   
                }
               

               // data['typeName'] = this.checkProperty( this.petitionDetails , 'typeDetails','name');
               // data['subTypeName'] = this.checkProperty( this.petitionDetails ,'subTypeDetails','name');
                data['petitionId'] = this.checkProperty( this.petitionDetails ,'_id');
                this.$store.dispatch('commonAction' ,{ "data":data ,'path':path})
                .then((res)=>{
                  this.showToster({message:res['message'],isError:false });
                  this.hideMe(true);
                })
                .catch((error)=>{
                  this.pewResponceUpdateStatusError =error;
                  this.pwdResUpdating =false;
                 })

                

               }
            });
    },
    hideMe(reloadList =false) {

      this.$emit("hideMe" ,reloadList);
      setTimeout(()=>{
          this.$modal.hide('createPwdPopUp');
        },10);
    },
  },
  watch: {
    showPopup(val) {
      if (!val){
        this.$emit("hideMe");
        this.$modal.hide('createPwdPopUp');
      } 
    },
  },
  mounted() {
   
    
      this.getMasterSocList();
      this.showPopup = true;
      this.$modal.show('createPwdPopUp');
      if(_.has(this.petitionDetails ,'pwdStatus')){

        // this.actionData.pwdStatus  =this.petitionDetails['pwdStatus'];
        // if(this.petitionDetails['pwdStatus'] =="Filed"){
        //   this.actionData.pwdStatus ="Certified";
        //   this.pwdStatusList = ["Certified"]

        // }
      }
      if(['EFILE_PWD'].indexOf(this.ACTIVITYCODE>-1)){
           this.actionData.documentType ="Electronic";
      }

      if( ['UPDATE_PWD_RESPONSE' ].indexOf(this.ACTIVITYCODE)>-1 ){
              this.actionData = Object.assign(this.actionData ,{'pwdAction':null });
              this.actionData = _.cloneDeep(this.actionData);
            
          }
    
  },
  data: () => ({
   
    editor: ClassicEditor,
 editorConfig: {
     toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
 },
 /*
 {

            1: 'CREATE_JOB_DESC',

            2: 'REQUEST_JOB_DESC_REVIEW',

            3: 'REVIEW_JOB_DESC_SUGGESSION',

            4: 'APPROVE_JOB_DESC',

            5: 'FINALIZE_JOB_DESC',

            6: 'EFILE_PWD',

            7: 'PWD_RFI_RECEIVED',

            8: 'SUBMIT_RFI_RESPONSE',

            9: 'PWD_CERTIFID',

            10: 'COLLECT_ADV_EVIDENCE'

        }
 */
//"EFILE_PWD", // PWD_CERTIFID / PWD_RFI_RECEIVED / SUBMIT_RFI_RESPONSE

    pwdActionsList:[
   // {'name':'Initiate PWD' ,'id':'CREATE_JOB_DESC' ,'statusId':1}, //INITIATED_PWD
    {'name':'E-File PWD' ,'id':'EFILE_PWD','statusId':6},
    {'name':'Certified PWD' ,'id':'PWD_CERTIFID','statusId':9},
    {'name':'RFI Received' ,'id':'PWD_RFI_RECEIVED' ,'statusId':7},
   {'name':'Submit RFI Response' ,'id':'SUBMIT_RFI_RESPONSE','statusId':8},
     
    ],
    pwdStatusList:["Filed" ,"Certified"],
    prefilledKyes:[],
    pwdDocFormatError:'',
    showDocumentsError:false,
    masterSocList:[],
    pwdResUpdating:false,
    pewResponceUpdateStatusError:'',
    actionData:{
    "petitionId": "",
		"action": 'UPDATE_PWD_RESPONSE',//"EFILE_PWD",'UPDATE_PWD_RESPONSE'
		"typeName": "",
		"subTypeName": "",
    "pwdStatus": "", //"Initiated", //'Filed' //Certified // Received RFI //Submit RFI Response
    "noOfPositions" : 0,
    "statusId": null,//1, //2 //3 //4 //5
    "statusDetails":null,
    pwdAction:null,

    /**** Required for PWD_CERTIFID / PWD_RFI_RECEIVED / SUBMIT_RFI_RESPONSE ****/
    "issuedDate": null,
		"receivedDate": null,
		"dueDate": null,
		"description": "",
   /**** Required for EFILE_PWD PWD_CERTIFID / PWD_RFI_RECEIVED / SUBMIT_RFI_RESPONSE ****/  
    "documents": [], 

   /****Required for PWD_CERTIFID *****/
		"documentType": "Original",
    "socCode": '',//"13-1111.00", // Type String when update from DOL
    "socCodeDetails": null,//4, // Type Number when updating from ImmiBox App
	  "isSocCodeDetails":false,// true, // Send as true when update from DOL
		"wageRate": "",
    "jobTitle":'',

    /****Required for EFILE_PWD  *****/
    trackingNumber:'',
   
  },

   
    
   documentTypes:["Original" ,"Electronic" ],
    documentModel:[],
    statusDocuments:[],
   filesAreuploading: false,
    
    uploading: false,
    courierList: [],
    tracking: { documents: [], receiptNumber: null, receiptName: null },
    
    
    openDate: new Date().setFullYear(new Date().getFullYear()),
    startEligibleDate: new Date().setFullYear(new Date().getFullYear()),
    
    disabled_btn: false,
    showPopup: false,
    documents: [],
   
  }),
  props: {
    ACTIVITYCODE:{
      type: String,
      default: 'PWD_CERTIFID',
    },
    petitionDetails: {
      type: Object,
      default: null,
    },
  },
  destroyed() {
    this.hideMe();
  }
};
</script>
