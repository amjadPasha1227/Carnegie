<template>
    
                
  <div class="download_documents_list download__docs">
    <template >
      <vs-tabs>
          <vs-tab label="Saved Documents" @click="changedDocumentsTab('savedDocuments')" >
              <div class="con-tab-ejemplo" v-if="documentActiveTab=='savedDocuments'" >
                  <div class="doc_modal scrool_auto">
                     
                      <!---<VuePerfectScrollbar class="scrollbardoc">--->
                       
                          <vs-row vs-w="12">
                            
                             
                              <template v-if="checkActiveDocuments(beneficiaryDocumentsList) "  >
                                  <vs-col vs-lg="12" vs-sm="12" vs-xs="12" id="mainCategory_beneficiaryDocumentsList" >
                                     <div class="list_elements drag-items">
                                      <h2 class="small-header">Petition  Documents</h2>
                                      <vs-collapse accordion>
                                        <draggable :list="beneficiaryDocumentsList" group="people">
                                          
                                          <template v-for="(categoryDocs, index) in beneficiaryDocumentsList">
                                           
                                              <!-----{"category":category,"documents":categoryDocuments}-->
                                            <vs-collapse-item v-if="checktSavedDocuments(categoryDocs['documents'])"  :key="index" >
                                             
                                              <div slot="header" class="d_header_title"  :id="'docTypeOrder_ben_'+categoryDocs['category']"  >
                                               <!---- {{1+index}} - {{categoryDocs['category'] | formatdoctype}} --->
                                               {{categoryDocs['category'] | formatdoctype}}
                                                <span  @click="moveToTrash('beneficiaryDocumentsList' ,categoryDocs['category']);"  >
                                                  <img src="@/assets/images/main/delete-row-img.svg" />
                                                  <em>Remove from the list</em>
                                                </span>
                                              </div>
                                              <div>
                                                <div class="dragBox" v-if="categoryDocs['documents'] && categoryDocs['documents'].length > 0">
                                                  <div class="dragNested">
                                                    <draggable class="list-group" :list="categoryDocs['documents']" group="people" >
                                                    <template  v-for="(document,sindex) in  categoryDocs['documents']">
                                                     
                                                      <div
                                                        :id="'order_ben_'+categoryDocs['category']+'_docPath_'+document['path']"
                                                        :docPath="document['path']"
                                                        
                                                        v-bind:key="sindex"
                                                        class="drab_sublist"
                                                         v-if="!checkProperty( document,'isTrashDocument')"
                                                      >
                                                        <div class="subdragHead" :documentssubcategory="categoryDocs['category']" :categoryOrder="index"  :documentPath="checkProperty(document ,'path')"   >{{document.name}}
                                                        
                                                        </div>
                                                       
                                                        <div class="downloadPopup-actions d-flex align-center">
                                                            <span @click="downloadfile(document)" class="sub_delete" >
                                                              <img width="14" src="@/assets/images/main/eye.png" />
                                                              <em>View/Download</em>
                                                            </span>
                                                              <span  @click="document['isTrashDocument']=true ;savedDocumentsAction()"  class="sub_delete ml-4"   >
                                                                <img src="@/assets/images/main/cross.svg" />
                                                                <em>Remove from the list</em>
                                                              </span>
                                                          </div>
                                                      </div>
                                                      </template>
                                                    </draggable>
                                                  </div>
                                                </div>
                                              </div>
                                            </vs-collapse-item>
                                          </template>
                                        </draggable>
                                      </vs-collapse>
                                    </div>
                                  </vs-col>
                              </template>
                              <!-------Spouse Documents MM DD YYYY --> 
                              <template v-if=" (checkProperty(petition ,'subTypeDetails' ,'id') !=16 || true) && checkActiveDocuments(suposeDocumentsList)"  >
                                  <vs-col vs-lg="12" vs-sm="12" vs-xs="12" id="mainCategory_suposeDocumentsList">
                                      <h2 class="small-header">Spouse Documents</h2>
                                     <div class="list_elements drag-items">
                                      <vs-collapse accordion>
                                        <draggable :list="suposeDocumentsList" group="people">
                                          <template v-for="(categoryDocs, index) in suposeDocumentsList">
                                              <!-----{"category":category,"documents":categoryDocuments}-->
                                            <vs-collapse-item v-if="checktSavedDocuments(categoryDocs['documents'])"  :key="index" >
                                              <div slot="header" class="d_header_title" :id="'docTypeOrder_sup_'+categoryDocs['category']" >
                                               <!--- {{1+index}} - {{categoryDocs['category'] | formatdoctype}} --->
                                                {{categoryDocs['category'] | formatdoctype}}
                                                <span  @click="moveToTrash('suposeDocumentsList',categoryDocs['category'])"  >
                                                  <img src="@/assets/images/main/delete-row-img.svg" />
                                                  <em>Remove from the list</em>
                                                </span>
                                              </div>
                                              <div>
                                                <div class="dragBox" v-if="categoryDocs['documents'] && categoryDocs['documents'].length > 0">
                                                  <div class="dragNested">
                                                    <draggable class="list-group" :list="categoryDocs['documents']" group="people" >
                                                    <template  v-for="(document,sindex) in  categoryDocs['documents']">
                                                      <div
                                                        :id="'order_sup_'+categoryDocs['category']+'_docPath_'+document['path']"
                                                        :docPath="document['path']"
                                                        
                                                        v-bind:key="sindex"
                                                        class="drab_sublist"
                                                         v-if="!checkProperty( document,'isTrashDocument')"
                                                      >
                                                        <div class="subdragHead" :documentssubcategory="categoryDocs['category']" :categoryOrder="index"  :documentPath="checkProperty(document ,'path')"   >{{document.name}}</div>
                                                       
                                                        <div class="downloadPopup-actions d-flex align-center">
                                                            <span @click="downloadfile(document)" class="sub_delete" >
                                                              <img width="14" src="@/assets/images/main/eye.png" />
                                                              <em>View/Download</em>
                                                            </span>
                                                              <span  @click="document['isTrashDocument']=true;savedDocumentsAction()"  class="sub_delete ml-4"   >
                                                                <img src="@/assets/images/main/cross.svg" />
                                                                <em>Remove from the list</em>
                                                              </span>
                                                          </div>
                                                      </div>
                                                      </template>
                                                    </draggable>
                                                  </div>
                                                </div>
                                              </div>
                                            </vs-collapse-item>
                                          </template>
                                        </draggable>
                                      </vs-collapse>
                                    </div>
                                  </vs-col>
                              </template>

                              <!-------------Child documents-->
                              <template v-if="  (checkProperty(petition ,'subTypeDetails' ,'id') !=16 || true)  && checkProperty(childrenDocuments  ,'length')>0">
                               
                                  <template v-for="(child , chind) in childrenDocuments" >
                                   
                                      <template v-if="checkActiveDocuments(child['documents'])"  >
                                        <vs-col vs-lg="12" vs-sm="12" vs-xs="12" :key="chind" id="mainCategory_childrenDocuments">
                                            <h2 class="small-header">Child {{child['name']}} Documents</h2>
                                           <div class="list_elements drag-items">
                                            <vs-collapse accordion>
                                              <draggable :list="child['documents']" group="people" :groupp="'spouse_'+index">
                                                <template v-for="(categoryDocs, index) in child['documents']">
                                                    
                                                  <vs-collapse-item v-if="checktSavedDocuments(categoryDocs['documents'])"  :key="index" >
                                                    <div slot="header" class="d_header_title" :id="'docTypeOrder_'+child['_id']+'_'+categoryDocs['category']"  >
                                                      <!----{{1+index}} - {{categoryDocs['category'] | formatdoctype}}--->
                                                      {{categoryDocs['category'] | formatdoctype}}
                                                      <span  @click="moveToTrash('childrenDocuments',categoryDocs['category'] ,chind)"  >
                                                        <img src="@/assets/images/main/delete-row-img.svg" />
                                                        <em>Remove from the list</em>
                                                      </span>
                                                    </div>
                                                    <div>
                                                      <div class="dragBox" v-if="categoryDocs['documents'] && categoryDocs['documents'].length > 0">
                                                        <div class="dragNested">
                                                          <draggable class="list-group" :list="categoryDocs['documents']" group="people" >
                                                          <template  v-for="(document,sindex) in  categoryDocs['documents']">
                                                            <div
                                                            :id="'order_chi_'+categoryDocs['category']+'_'+child['_id']+'_docPath_'+document['path']"
                                                              :docPath="document['path']"
                                                        
                                                              v-bind:key="sindex"
                                                              class="drab_sublist"
                                                               v-if="!checkProperty( document,'isTrashDocument')"
                                                            >
                                                              <div class="subdragHead" :documentssubcategory="categoryDocs['category']" :categoryOrder="index"  :documentPath="checkProperty(document ,'path')"   >{{document.name}}</div>
                                                             
                                                              <div class="downloadPopup-actions d-flex align-center">
                                                                  <span @click="downloadfile(document)" class="sub_delete" >
                                                                    <img width="14" src="@/assets/images/main/eye.png" />
                                                                    <em>View/Download</em>
                                                                  </span>
                                                                    <span  @click="document['isTrashDocument']=true;savedDocumentsAction()"  class="sub_delete ml-4"   >
                                                                      <img src="@/assets/images/main/cross.svg" />
                                                                      <em>Remove from the list</em>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                            </template>
                                                          </draggable>
                                                        </div>
                                                      </div>
                                                    </div>
                                                  </vs-collapse-item>
                                                </template>
                                              </draggable>
                                            </vs-collapse>
                                          </div>
                                        </vs-col>
                                    </template>

                                   

                                  </template>
                              </template>

                              <!-----filteredLetters-->
                              <template  v-if="checkActiveDocuments(filteredLetters)" >
                                  <vs-col vs-lg="12" vs-sm="12" vs-xs="12" id="mainCategory_filteredLetters">
                                     <div class="list_elements drag-items">
                                      <h2 class="small-header">Forms And Letters</h2>
                                      <vs-collapse accordion>
                                        <draggable :list="filteredLetters" group="people">
                                          
                                          <template v-for="(categoryDocs, index) in filteredLetters">
                                          
                                              <!-----{"category":category,"documents":categoryDocuments}-->
                                            <vs-collapse-item v-if="checktSavedDocuments(categoryDocs['documents'])"  :key="index" >
                                             
                                              <div :category="categoryDocs['category']" slot="header" class="d_header_title"  :id="'docTypeOrder_filteredLetters_'+categoryDocs['category']"  >
                                              
                                                {{categoryDocs['category'] | formatdoctype }}
                                                <span  @click="moveToTrash('filteredLetters' ,categoryDocs['category']);"  >
                                                  <img src="@/assets/images/main/delete-row-img.svg" />
                                                  <em>Remove from the list</em>
                                                </span>
                                              </div>
                                              <div>
                                                <div class="dragBox" v-if="categoryDocs['documents'] && categoryDocs['documents'].length > 0">
                                                  <div class="dragNested">
                                                    <draggable class="list-group" :list="categoryDocs['documents']" group="people" >
                                                    <template  v-for="(document,sindex) in  categoryDocs['documents']">
                                                     
                                                      <div
                                                        :id="'order_filteredLetters_'+categoryDocs['category']+'_docPath_'+document['path']"
                                                        :docPath="document['path']"
                                                        
                                                        v-bind:key="sindex"
                                                        class="drab_sublist"
                                                         v-if="!checkProperty( document,'isTrashDocument')"
                                                      >
                                                        <div class="subdragHead" :documentssubcategory="categoryDocs['category']" :categoryOrder="index"  :documentPath="checkProperty(document ,'path')"   >{{document.name}}
                                                        
                                                        </div>
                                                       
                                                        <div class="downloadPopup-actions d-flex align-center">
                                                            <span @click="downloadfile(document)" class="sub_delete" >
                                                              <img width="14" src="@/assets/images/main/eye.png" />
                                                              <em>View/Download</em>
                                                            </span>
                                                              <span  @click="document['isTrashDocument']=true ;savedDocumentsAction()"  class="sub_delete ml-4"   >
                                                                <img src="@/assets/images/main/cross.svg" />
                                                                <em>Remove from the list</em>
                                                              </span>
                                                          </div>
                                                      </div>
                                                      </template>
                                                    </draggable>
                                                  </div>
                                                </div>
                                              </div>
                                            </vs-collapse-item>
                                          </template>
                                        </draggable>
                                      </vs-collapse>
                                    </div>
                                  </vs-col>
                              </template>
                              <!----scannedDocsCatList-->
                              
                              <template  v-if=" checkActiveDocuments(scannedDocsCatList)" >
                                  <vs-col vs-lg="12" vs-sm="12" vs-xs="12" id="mainCategory_scannedDocsCatList">
                                     <div class="list_elements drag-items">
                                      <h2 class="small-header">Scanned/Signed Documents</h2>
                                      <vs-collapse accordion>
                                        <draggable :list="scannedDocsCatList" group="people">
                                          
                                          <template v-for="(categoryDocs, index) in scannedDocsCatList">
                                          
                                              <!-----{"category":category,"documents":categoryDocuments}-->
                                            <vs-collapse-item v-if="checktSavedDocuments(categoryDocs['documents'])"  :key="index" >
                                             
                                              <div slot="header" class="d_header_title"  :id="'docTypeOrder_scannedDocsCatList_'+categoryDocs['category']"  >
                                              {{ categoryDocs['category'] | formatdoctype }} Scanned Documents
                                               <!---- {{categoryDocs['category'] |formatdoctype }}--->
                                                <span  @click="moveToTrash('scannedDocsCatList' ,categoryDocs['category']);"  >
                                                  <img src="@/assets/images/main/delete-row-img.svg" />
                                                  <em>Remove from the list</em>
                                                </span>
                                              </div>
                                              <div>
                                                <div class="dragBox" v-if="categoryDocs['documents'] && categoryDocs['documents'].length > 0">
                                                  <div class="dragNested">
                                                    <draggable class="list-group" :list="categoryDocs['documents']" group="people" >
                                                    <template  v-for="(document,sindex) in  categoryDocs['documents']">
                                                     
                                                      <div
                                                        :id="'order_scannedDocsCatList_'+categoryDocs['category']+'_docPath_'+document['path']"
                                                        :docPath="document['path']"
                                                        
                                                        v-bind:key="sindex"
                                                        class="drab_sublist"
                                                         v-if="!checkProperty( document,'isTrashDocument')"
                                                      >
                                                        <div class="subdragHead" :documentssubcategory="categoryDocs['category']" :categoryOrder="index"  :documentPath="checkProperty(document ,'path')"   >{{document.name}}
                                                         
                                                        
                                                        </div>
                                                       
                                                        <div class="downloadPopup-actions d-flex align-center">
                                                            <span @click="downloadfile(document)" class="sub_delete" >
                                                              <img width="14" src="@/assets/images/main/eye.png" />
                                                              <em>View/Download</em>
                                                            </span>
                                                              <span  @click="document['isTrashDocument']=true ;savedDocumentsAction()"  class="sub_delete ml-4"   >
                                                                <img src="@/assets/images/main/cross.svg" />
                                                                <em>Remove from the list</em>
                                                              </span>
                                                          </div>
                                                      </div>
                                                      </template>
                                                    </draggable>
                                                  </div>
                                                </div>
                                              </div>
                                            </vs-collapse-item>
                                          </template>
                                        </draggable>
                                      </vs-collapse>
                                    </div>
                                  </vs-col>
                              </template>

                              <!-----processedChequeDocs -->
                              <template  v-if="checkActiveDocuments(processedChequeDocs)" >
                                  <vs-col vs-lg="12" vs-sm="12" vs-xs="12" id="mainCategory_processedChequeDocs">
                                     <div class="list_elements drag-items">
                                      <h2 class="small-header">Cheques</h2>
                                      <vs-collapse accordion>
                                        <draggable :list="processedChequeDocs" group="people">
                                          
                                          <template v-for="(categoryDocs, index) in processedChequeDocs">
                                          
                                              <!-----{"category":category,"documents":categoryDocuments}-->
                                            <vs-collapse-item v-if="checktSavedDocuments(categoryDocs['documents'])"  :key="index" >
                                             
                                              <div slot="header" class="d_header_title"  :id="'docTypeOrder_processedChequeDocs_'+categoryDocs['category']"  >
                                              
                                                 {{categoryDocs['category'] |formatdoctype }}
                                                <span  @click="moveToTrash('processedChequeDocs' ,categoryDocs['category']);"  >
                                                  <img src="@/assets/images/main/delete-row-img.svg" />
                                                  <em>Remove from the list</em>
                                                </span>
                                              </div>
                                              <div>
                                                <div class="dragBox" v-if="categoryDocs['documents'] && categoryDocs['documents'].length > 0">
                                                  <div class="dragNested">
                                                    <draggable class="list-group" :list="categoryDocs['documents']" group="people" >
                                                    <template  v-for="(document,sindex) in  categoryDocs['documents']">
                                                     
                                                      <div
                                                        :id="'order_processedChequeDocs_'+categoryDocs['category']+'_docPath_'+document['path']"
                                                        :docPath="document['path']"
                                                        
                                                        v-bind:key="sindex"
                                                        class="drab_sublist"
                                                         v-if="!checkProperty( document,'isTrashDocument')"
                                                      >
                                                        <div class="subdragHead" :documentssubcategory="categoryDocs['category']" :categoryOrder="index"  :documentPath="checkProperty(document ,'path')"   >{{document.name}}
                                                         
                                                        
                                                        </div>
                                                       
                                                        <div class="downloadPopup-actions d-flex align-center">
                                                            <span @click="downloadfile(document)" class="sub_delete" >
                                                              <img width="14" src="@/assets/images/main/eye.png" />
                                                              <em>View/Download</em>
                                                            </span>
                                                              <span  @click="document['isTrashDocument']=true ;savedDocumentsAction()"  class="sub_delete ml-4"   >
                                                                <img src="@/assets/images/main/cross.svg" />
                                                                <em>Remove from the list</em>
                                                              </span>
                                                          </div>
                                                      </div>
                                                      </template>
                                                    </draggable>
                                                  </div>
                                                </div>
                                              </div>
                                            </vs-collapse-item>
                                          </template>
                                        </draggable>
                                      </vs-collapse>
                                    </div>
                                  </vs-col>
                              </template>

                               <!---- companyDocs -->
                              
                               <template  v-if="checkProperty(petition,'petitionerId') && checkActiveDocuments(companyDocs)" >
                                  <vs-col vs-lg="12" vs-sm="12" vs-xs="12" id="mainCategory_companyDocs">
                                     <div class="list_elements drag-items">
                                      <h2 class="small-header">Company Documents</h2>
                                      <vs-collapse accordion>
                                        <draggable :list="companyDocs" group="people">
                                          
                                          <template v-for="(categoryDocs, index) in companyDocs">
                                          
                                              <!-----{"category":category,"documents":categoryDocuments}-->
                                            <vs-collapse-item v-if="checktSavedDocuments(categoryDocs['documents'])"  :key="index" >
                                             
                                              <div slot="header" class="d_header_title"  :id="'docTypeOrder_companyDocs_'+categoryDocs['category']"  >
                                              
                                               {{'Company' | formatdoctype }}  Documents
                                                <span  @click="moveToTrash('companyDocs' ,categoryDocs['category']);"  >
                                                  <img src="@/assets/images/main/delete-row-img.svg" />
                                                  <em>Remove from the list</em>
                                                </span>
                                              </div>
                                              <div>
                                                <div class="dragBox" v-if="categoryDocs['documents'] && categoryDocs['documents'].length > 0">
                                                  <div class="dragNested">
                                                    <draggable class="list-group" :list="categoryDocs['documents']" group="people" >
                                                    <template  v-for="(document,sindex) in  categoryDocs['documents']">
                                                     
                                                      <div
                                                        :id="'order_companyDocs_'+categoryDocs['category']+'_docPath_'+document['path']"
                                                        :docPath="document['path']"
                                                        
                                                        v-bind:key="sindex"
                                                        class="drab_sublist"
                                                         v-if="!checkProperty( document,'isTrashDocument')"
                                                      >
                                                        <div class="subdragHead" :documentssubcategory="categoryDocs['category']" :categoryOrder="index"  :documentPath="checkProperty(document ,'path')"   >{{document.name}}
                                                         
                                                        
                                                        </div>
                                                       
                                                        <div class="downloadPopup-actions d-flex align-center">
                                                            <span @click="downloadfile(document)" class="sub_delete" >
                                                              <img width="14" src="@/assets/images/main/eye.png" />
                                                              <em>View/Download</em>
                                                            </span>
                                                              <span  @click="document['isTrashDocument']=true ;savedDocumentsAction()"  class="sub_delete ml-4"   >
                                                                <img src="@/assets/images/main/cross.svg" />
                                                                <em>Remove from the list</em>
                                                              </span>
                                                          </div>
                                                      </div>
                                                      </template>
                                                    </draggable>
                                                  </div>
                                                </div>
                                              </div>
                                            </vs-collapse-item>
                                          </template>
                                        </draggable>
                                      </vs-collapse>
                                    </div>
                                  </vs-col>
                              </template>

                              <!-----USCISDocs-->
                             
                              <template  v-if="checkActiveDocuments(USCISDocs)" >
                                  <vs-col vs-lg="12" vs-sm="12" vs-xs="12" id="mainCategory_USCISDocs">
                                     <div class="list_elements drag-items">
                                      <h2 class="small-header">USCIS Documents</h2>
                                      <vs-collapse accordion>
                                        <draggable :list="USCISDocs" group="people">
                                          
                                          <template v-for="(categoryDocs, index) in USCISDocs">
                                          
                                              <!-----{"category":category,"documents":categoryDocuments}-->
                                            <vs-collapse-item v-if="checktSavedDocuments(categoryDocs['documents'])"  :key="index" >
                                             
                                              <div slot="header" class="d_header_title"  :id="'docTypeOrder_USCISDocs_'+categoryDocs['category']"  >
                                                {{'USCIS' | formatdoctype }}  Documents
                                               
                                                <span  @click="moveToTrash('USCISDocs' ,categoryDocs['category']);"  >
                                                  <img src="@/assets/images/main/delete-row-img.svg" />
                                                  <em>Remove from the list</em>
                                                </span>
                                              </div>
                                              <div>
                                                <div class="dragBox" v-if="categoryDocs['documents'] && categoryDocs['documents'].length > 0">
                                                  <div class="dragNested">
                                                    <draggable class="list-group" :list="categoryDocs['documents']" group="people" >
                                                    <template  v-for="(document,sindex) in  categoryDocs['documents']">
                                                     
                                                      <div
                                                        :id="'order_USCISDocs_'+categoryDocs['category']+'_docPath_'+document['path']"
                                                        :docPath="document['path']"
                                                        
                                                        v-bind:key="sindex"
                                                        class="drab_sublist"
                                                         v-if="!checkProperty( document,'isTrashDocument')"
                                                      >
                                                        <div class="subdragHead" :documentssubcategory="categoryDocs['category']" :categoryOrder="index"  :documentPath="checkProperty(document ,'path')"   >{{document.name}}
                                                         
                                                        
                                                        </div>
                                                       
                                                        <div class="downloadPopup-actions d-flex align-center">
                                                            <span @click="downloadfile(document)" class="sub_delete" >
                                                              <img width="14" src="@/assets/images/main/eye.png" />
                                                              <em>View/Download</em>
                                                            </span>
                                                              <span  @click="document['isTrashDocument']=true ;savedDocumentsAction()"  class="sub_delete ml-4"   >
                                                                <img src="@/assets/images/main/cross.svg" />
                                                                <em>Remove from the list</em>
                                                              </span>
                                                          </div>
                                                      </div>
                                                      </template>
                                                    </draggable>
                                                  </div>
                                                </div>
                                              </div>
                                            </vs-collapse-item>
                                          </template>
                                        </draggable>
                                      </vs-collapse>
                                    </div>
                                  </vs-col>
                              </template>

                            
                             
                             
                            <!------Other Merge Documents -->
                            <template  v-if="checkActiveDocuments(otherMergeDocuments)" >
                                  <vs-col vs-lg="12" vs-sm="12" vs-xs="12" id="mainCategory_USCISDocs">
                                     <div class="list_elements drag-items">
                                      <h2 class="small-header">Other  Documents</h2>
                                      <vs-collapse accordion>
                                        <draggable :list="otherMergeDocuments" group="people">
                                          
                                          <template v-for="(categoryDocs, index) in otherMergeDocuments">
                                          
                                              <!-----{"category":category,"documents":categoryDocuments}-->
                                            <vs-collapse-item v-if="checktSavedDocuments(categoryDocs['documents'])"  :key="index" >
                                             
                                              <div slot="header" class="d_header_title"  :id="'docTypeOrder_otherMergeDocuments_'+categoryDocs['category']"  >
                                              
                                                Other  Documents
                                                <span  @click="moveToTrash('otherMergeDocuments' ,categoryDocs['category']);"  >
                                                  <img src="@/assets/images/main/delete-row-img.svg" />
                                                  <em>Remove from the list</em>
                                                </span>
                                              </div>
                                              <div>
                                                <div class="dragBox" v-if="categoryDocs['documents'] && categoryDocs['documents'].length > 0">
                                                  <div class="dragNested">
                                                    <draggable class="list-group" :list="categoryDocs['documents']" group="people" >
                                                    <template  v-for="(document,sindex) in  categoryDocs['documents']">
                                                     
                                                      <div
                                                        :id="'order_otherMergeDocuments_'+categoryDocs['category']+'_docPath_'+document['path']"
                                                        :docPath="document['path']"
                                                        
                                                        v-bind:key="sindex"
                                                        class="drab_sublist"
                                                         v-if="!checkProperty( document,'isTrashDocument')"
                                                      >
                                                        <div class="subdragHead" :documentssubcategory="categoryDocs['category']" :categoryOrder="index"  :documentPath="checkProperty(document ,'path')"   >{{document.name}}
                                                         
                                                        
                                                        </div>
                                                       
                                                        <div class="downloadPopup-actions d-flex align-center">
                                                            <span @click="downloadfile(document)" class="sub_delete" >
                                                              <img width="14" src="@/assets/images/main/eye.png" />
                                                              <em>View/Download</em>
                                                            </span>
                                                              <span  @click="document['isTrashDocument']=true ;savedDocumentsAction()"  class="sub_delete ml-4"   >
                                                                <img src="@/assets/images/main/cross.svg" />
                                                                <em>Remove from the list</em>
                                                              </span>
                                                          </div>
                                                      </div>
                                                      </template>
                                                    </draggable>
                                                  </div>
                                                </div>
                                              </div>
                                            </vs-collapse-item>
                                          </template>
                                        </draggable>
                                      </vs-collapse>
                                    </div>
                                  </vs-col>
                              </template>

                              <template  v-if="checkActiveDocuments(reecentDocuments) && false" >
                                  <vs-col vs-lg="12" vs-sm="12" vs-xs="12" id="mainCategory_reecentDocuments">
                                     <div class="list_elements drag-items">
                                      <h2 class="small-header">Recent Downloads</h2>
                                      <vs-collapse accordion>
                                        <draggable :list="reecentDocuments" group="people">
                                         
                                          <template v-for="(categoryDocs, index) in reecentDocuments">
                                          
                                              <!-----{"category":category,"documents":categoryDocuments}-->
                                            <vs-collapse-item v-if="checktSavedDocuments(categoryDocs['documents'])"  :key="index" >
                                             
                                              <div slot="header" class="d_header_title"  :id="'docTypeOrder_reecentDocuments_'+categoryDocs['category']"  >
                                                {{categoryDocs['category'] | formatdoctype }}
                                               
                                                <span  @click="moveToTrash('reecentDocuments' ,categoryDocs['category']);"  >
                                                  <img src="@/assets/images/main/delete-row-img.svg" />
                                                  <em>Remove from the list</em>
                                                </span>
                                              </div>
                                              <div>
                                                <div class="dragBox" v-if="categoryDocs['documents'] && categoryDocs['documents'].length > 0">
                                                  <div class="dragNested">
                                                    <draggable class="list-group" :list="categoryDocs['documents']" group="people" >
                                                    <template  v-for="(document,sindex) in  categoryDocs['documents']">
                                                     
                                                      <div
                                                        :id="'order_reecentDocuments_'+categoryDocs['category']+'_docPath_'+document['path']"
                                                        :docPath="document['path']"
                                                        
                                                        v-bind:key="sindex"
                                                        class="drab_sublist"
                                                         v-if="!checkProperty( document,'isTrashDocument')"
                                                      >
                                                        <div class="subdragHead" :documentssubcategory="categoryDocs['category']" :categoryOrder="index"  :documentPath="checkProperty(document ,'path')"   >{{document.name}}
                                                         
                                                        
                                                        </div>
                                                       
                                                        <div class="downloadPopup-actions d-flex align-center">
                                                            <span @click="downloadfile(document)" class="sub_delete" >
                                                              <img width="14" src="@/assets/images/main/eye.png" />
                                                              <em>View/Download</em>
                                                            </span>
                                                              <span  @click="document['isTrashDocument']=true ;savedDocumentsAction()"  class="sub_delete ml-4"   >
                                                                <img src="@/assets/images/main/cross.svg" />
                                                                <em>Remove from the list</em>
                                                              </span>
                                                          </div>
                                                      </div>
                                                      </template>
                                                    </draggable>
                                                  </div>
                                                </div>
                                              </div>
                                            </vs-collapse-item>
                                          </template>
                                        </draggable>
                                      </vs-collapse>
                                    </div>
                                  </vs-col>
                              </template>
                             

                           
                              
                              <template v-if="!checkActiveDocuments(companyDocs) && !checkActiveDocuments(otherMergeDocuments) &&!checkActiveDocuments(USCISDocs) && !checkActiveDocuments(processedChequeDocs) && !checkActiveDocuments(scannedDocsCatList) && !checkActiveDocuments(beneficiaryDocumentsList) && !checkActiveDocuments(suposeDocumentsList) && !checkChildActiveDocuments" >
                                <div class="vs-col vs-xs-12 vs-sm-12 vs-lg-12">
                                   <NoDataFound ref="NoDataFoundRef" :loading="false" :checkLocading="false"  content="" :heading="'No Documents Found'" type='Documents' />
                                </div>  
                              </template>
                              

                          </vs-row>
                          
                      <!-----</VuePerfectScrollbar>--->    
                  </div>
              </div>

          </vs-tab>
          <vs-tab label="Trashed Documents" @click="changedDocumentsTab('trashedDocuments')" >
              <div class="con-tab-ejemplo" v-if="documentActiveTab=='trashedDocuments'" >
                  <div class="doc_modal scrool_auto">
                      
                      <!---VuePerfectScrollbar class="scrollbardoc">-->
                          <vs-row vs-w="12">
                           
                              <template  v-if="checkInActiveDocuments(beneficiaryDocumentsList)"  >
                                  <vs-col vs-lg="12" vs-sm="12" vs-xs="12">
                                     <div class="list_elements drag-items">
                                      <h2 class="small-header">Petition  Documents</h2>
                                      <vs-collapse accordion>
                                        <draggable :list="beneficiaryDocumentsList" group="people">
                                          <template v-for="(categoryDocs, index) in beneficiaryDocumentsList">
                                              <!-----{"category":category,"documents":categoryDocuments}-->
                                            <vs-collapse-item v-if="checktTrashedDocuments(categoryDocs['documents'])"  :key="index" >
                                              <div slot="header" class="d_header_title">
                                               <!----- {{1+index}} - {{categoryDocs["category"] | formatdoctype}}--->
                                                {{categoryDocs["category"] | formatdoctype}}
                                                <span  @click="moveToSave('beneficiaryDocumentsList', categoryDocs['category'])"  >
                                                  <img src="@/assets/images/main/delete-row-img.svg" />
                                                  <em>Remove from the list</em>
                                                </span>
                                              </div>
                                              <div>
                                                <div class="dragBox" v-if="categoryDocs['documents'] && categoryDocs['documents'].length > 0">
                                                  <div class="dragNested">
                                                    <draggable class="list-group" :list="categoryDocs['documents']" group="people" >
                                                    <template  v-for="(document,sindex) in  categoryDocs['documents']">
                                                      <div
                                                      
                                                        v-bind:key="sindex"
                                                        class="drab_sublist"
                                                         v-if="checkProperty( document,'isTrashDocument')"
                                                      >
                                                        <div class="subdragHead"    >{{document.name}}</div>
                                                       
                                                        <div class="downloadPopup-actions d-flex align-center">
                                                            <span @click="downloadfile(document)" class="sub_delete" >
                                                              <img width="14" src="@/assets/images/main/eye.png" />
                                                              <em>View/Download</em>
                                                            </span>
                                                              <span  @click="document['isTrashDocument']=false;savedDocumentsAction()"  class="sub_delete ml-4"   >
                                                                <img src="@/assets/images/main/cross.svg" />
                                                                <em>Remove from the list</em>
                                                              </span>
                                                          </div>
                                                      </div>
                                                      </template>
                                                    </draggable>
                                                  </div>
                                                </div>
                                              </div>
                                            </vs-collapse-item>
                                          </template>
                                        </draggable>
                                      </vs-collapse>
                                    </div>
                                  </vs-col>
                              </template>
                              <!-------Spouse Documents MM DD YYYY --> 
                              <template v-if="checkInActiveDocuments(suposeDocumentsList)"  >
                                  <vs-col vs-lg="12" vs-sm="12" vs-xs="12">
                                    <h2 class="small-header">Spouse Documents</h2>
                                     
                                     <div class="list_elements drag-items">
                                      <vs-collapse accordion>
                                        <draggable :list="suposeDocumentsList" group="Trashedspouse">
                                          <template v-for="(categoryDocs, index) in suposeDocumentsList">
                                              <!-----{"category":category,"documents":categoryDocuments}-->
                                            <vs-collapse-item v-if="checktTrashedDocuments(categoryDocs['documents'])"  :key="index" >
                                              <div slot="header" class="d_header_title">
                                               <!------ {{1+index}} - {{categoryDocs['category'] | formatdoctype}}--->
                                               {{categoryDocs['category'] | formatdoctype}}
                                                <span  @click="moveToSave('suposeDocumentsList' ,categoryDocs['category'])"  >
                                                  <img src="@/assets/images/main/delete-row-img.svg" />
                                                  <em>Remove from the list</em>
                                                </span>
                                              </div>
                                              <div>
                                                <div class="dragBox" v-if="categoryDocs['documents'] && categoryDocs['documents'].length > 0">
                                                  <div class="dragNested">
                                                    <draggable class="list-group" :list="categoryDocs['documents']" group="people" >
                                                    <template  v-for="(document,sindex) in  categoryDocs['documents']">
                                                      <div
                                                      
                                                        v-bind:key="sindex"
                                                        class="drab_sublist"
                                                         v-if="checkProperty( document,'isTrashDocument')"
                                                      >
                                                        <div class="subdragHead" :documentssubcategory="categoryDocs['category']" :categoryOrder="index"  :documentPath="checkProperty(document ,'path')"   >{{document.name}}</div>
                                                       
                                                        <div class="downloadPopup-actions d-flex align-center">
                                                            <span @click="downloadfile(document)" class="sub_delete" >
                                                              <img width="14" src="@/assets/images/main/eye.png" />
                                                              <em>View/Download</em>
                                                            </span>
                                                              <span  @click="document['isTrashDocument']=false;savedDocumentsAction()"  class="sub_delete ml-4"   >
                                                                <img src="@/assets/images/main/cross.svg" />
                                                                <em>Remove from the list</em>
                                                              </span>
                                                          </div>
                                                      </div>
                                                      </template>
                                                    </draggable>
                                                  </div>
                                                </div>
                                              </div>
                                            </vs-collapse-item>
                                          </template>
                                        </draggable>
                                      </vs-collapse>
                                    </div>
                                  </vs-col>
                              </template>
                              <!-------------Child documents-->
                              <template v-if="checkProperty(childrenDocuments  ,'length')>0">
                               
                                <template v-for="(child , chind) in childrenDocuments" >
                                  <template v-if="checkInActiveDocuments(child['documents'])"  >
                                    <vs-col vs-lg="12" vs-sm="12" vs-xs="12" :key="chind">
                                        <h2 class="small-header">Child {{child['name']}} Documents</h2>
                                       <div class="list_elements drag-items">
                                        <vs-collapse accordion>
                                          <draggable :list="child['documents']" :group="'child_'+chind['_id']">
                                            <template v-for="(categoryDocs, index) in child['documents']">
                                                
                                              <vs-collapse-item v-if="checktTrashedDocuments(categoryDocs['documents'])"  :key="index" >
                                                <div slot="header" class="d_header_title">
                                                 <!---- {{1+index}} - {{categoryDocs['category'] | formatdoctype}}-->
                                                    {{categoryDocs['category'] | formatdoctype}}
                                                  <span  @click="moveToSave( 'childrenDocuments' ,categoryDocs['category'] ,chind)"  >
                                                    <img src="@/assets/images/main/delete-row-img.svg" />
                                                    <em>Remove from the list</em>
                                                  </span>
                                                </div>
                                                <div>
                                                  <div class="dragBox" v-if="categoryDocs['documents'] && categoryDocs['documents'].length > 0">
                                                    <div class="dragNested">
                                                      <draggable class="list-group" :list="categoryDocs['documents']" group="people" >
                                                      <template  v-for="(document,sindex) in  categoryDocs['documents']">
                                                        <div
                                                        
                                                          v-bind:key="sindex"
                                                          class="drab_sublist"
                                                           v-if="checkProperty( document,'isTrashDocument')"
                                                        >
                                                          <div class="subdragHead" :documentssubcategory="categoryDocs['category']" :categoryOrder="index"  :documentPath="checkProperty(document ,'path')"   >{{document.name}}</div>
                                                         
                                                          <div class="downloadPopup-actions d-flex align-center">
                                                              <span @click="downloadfile(document)" class="sub_delete" >
                                                                <img width="14" src="@/assets/images/main/eye.png" />
                                                                <em>View/Download</em>
                                                              </span>
                                                                <span  @click="document['isTrashDocument']=false;savedDocumentsAction()"  class="sub_delete ml-4"   >
                                                                  <img src="@/assets/images/main/cross.svg" />
                                                                  <em>Remove from the list</em>
                                                                </span>
                                                            </div>
                                                        </div>
                                                        </template>
                                                      </draggable>
                                                    </div>
                                                  </div>
                                                </div>
                                              </vs-collapse-item>
                                            </template>
                                          </draggable>
                                        </vs-collapse>
                                      </div>
                                    </vs-col>
                                </template>
                                  
                                    
                                </template>
                              </template> 
                         
                              <!-----filteredLetters-->
                              <template  v-if="checkInActiveDocuments(filteredLetters)"  >
                                  <vs-col vs-lg="12" vs-sm="12" vs-xs="12">
                                     <div class="list_elements drag-items">
                                      <h2 class="small-header">Forms And Letters</h2>
                                      <vs-collapse accordion>
                                        <draggable :list="filteredLetters" group="people">
                                          <template v-for="(categoryDocs, index) in filteredLetters">
                                              <!-----{"category":category,"documents":categoryDocuments}-->
                                            <vs-collapse-item v-if="checktTrashedDocuments(categoryDocs['documents'])"  :key="index" >
                                              <div slot="header" class="d_header_title">
                                               <!----- {{1+index}} - {{categoryDocs["category"] | formatdoctype}}--->
                                               {{categoryDocs['category'] | formatdoctype }}
                                                <span  @click="moveToSave('filteredLetters', categoryDocs['category'])"  >
                                                  <img src="@/assets/images/main/delete-row-img.svg" />
                                                  <em>Remove from the list</em>
                                                </span>
                                              </div>
                                              <div>
                                                <div class="dragBox" v-if="categoryDocs['documents'] && categoryDocs['documents'].length > 0">
                                                  <div class="dragNested">
                                                    <draggable class="list-group" :list="categoryDocs['documents']" group="people" >
                                                    <template  v-for="(document,sindex) in  categoryDocs['documents']">
                                                      <div
                                                      
                                                        v-bind:key="sindex"
                                                        class="drab_sublist"
                                                         v-if="checkProperty( document,'isTrashDocument')"
                                                      >
                                                        <div class="subdragHead"    >{{document.name}}</div>
                                                       
                                                        <div class="downloadPopup-actions d-flex align-center">
                                                            <span @click="downloadfile(document)" class="sub_delete" >
                                                              <img width="14" src="@/assets/images/main/eye.png" />
                                                              <em>View/Download</em>
                                                            </span>
                                                              <span  @click="document['isTrashDocument']=false;savedDocumentsAction()"  class="sub_delete ml-4"   >
                                                                <img src="@/assets/images/main/cross.svg" />
                                                                <em>Remove from the list</em>
                                                              </span>
                                                          </div>
                                                      </div>
                                                      </template>
                                                    </draggable>
                                                  </div>
                                                </div>
                                              </div>
                                            </vs-collapse-item>
                                          </template>
                                        </draggable>
                                      </vs-collapse>
                                    </div>
                                  </vs-col>
                              </template>
                              <!-----scannedDocsCatList-->
                              <template  v-if="checkInActiveDocuments(scannedDocsCatList)"  >
                                  <vs-col vs-lg="12" vs-sm="12" vs-xs="12">
                                     <div class="list_elements drag-items">
                                      <h2 class="small-header">Scanned/Signed Documents</h2>
                                      <vs-collapse accordion>
                                        <draggable :list="scannedDocsCatList" group="people">
                                          <template v-for="(categoryDocs, index) in scannedDocsCatList">
                                              <!-----{"category":category,"documents":categoryDocuments}-->
                                            <vs-collapse-item v-if="checktTrashedDocuments(categoryDocs['documents'])"  :key="index" >
                                              <div slot="header" class="d_header_title">
                                               <!----- {{1+index}} - {{categoryDocs["category"] | formatdoctype}}--->
                                                {{categoryDocs["category"] }} Scanned Documents
                                                <span  @click="moveToSave('scannedDocsCatList', categoryDocs['category'])"  >
                                                  <img src="@/assets/images/main/delete-row-img.svg" />
                                                  <em>Remove from the list</em>
                                                </span>
                                              </div>
                                              <div>
                                                <div class="dragBox" v-if="categoryDocs['documents'] && categoryDocs['documents'].length > 0">
                                                  <div class="dragNested">
                                                    <draggable class="list-group" :list="categoryDocs['documents']" group="people" >
                                                    <template  v-for="(document,sindex) in  categoryDocs['documents']">
                                                      <div
                                                      
                                                        v-bind:key="sindex"
                                                        class="drab_sublist"
                                                         v-if="checkProperty( document,'isTrashDocument')"
                                                      >
                                                        <div class="subdragHead"    >{{document.name}}</div>
                                                       
                                                        <div class="downloadPopup-actions d-flex align-center">
                                                            <span @click="downloadfile(document)" class="sub_delete" >
                                                              <img width="14" src="@/assets/images/main/eye.png" />
                                                              <em>View/Download</em>
                                                            </span>
                                                              <span  @click="document['isTrashDocument']=false;savedDocumentsAction()"  class="sub_delete ml-4"   >
                                                                <img src="@/assets/images/main/cross.svg" />
                                                                <em>Remove from the list</em>
                                                              </span>
                                                          </div>
                                                      </div>
                                                      </template>
                                                    </draggable>
                                                  </div>
                                                </div>
                                              </div>
                                            </vs-collapse-item>
                                          </template>
                                        </draggable>
                                      </vs-collapse>
                                    </div>
                                  </vs-col>
                              </template>
                              <!-----processedChequeDocs -->
                              <template  v-if="checkInActiveDocuments(processedChequeDocs)"  >
                                  <vs-col vs-lg="12" vs-sm="12" vs-xs="12">
                                     <div class="list_elements drag-items">
                                      <h2 class="small-header">Cheques</h2>
                                      <vs-collapse accordion>
                                        <draggable :list="processedChequeDocs" group="people">
                                          <template v-for="(categoryDocs, index) in processedChequeDocs">
                                              <!-----{"category":category,"documents":categoryDocuments}-->
                                            <vs-collapse-item v-if="checktTrashedDocuments(categoryDocs['documents'])"  :key="index" >
                                              <div slot="header" class="d_header_title">
                                               <!----- {{1+index}} - {{categoryDocs["category"] | formatdoctype}}--->
                                                {{categoryDocs["category"] }}
                                                <span  @click="moveToSave('scannedDocsCatList', categoryDocs['category'])"  >
                                                  <img src="@/assets/images/main/delete-row-img.svg" />
                                                  <em>Remove from the list</em>
                                                </span>
                                              </div>
                                              <div>
                                                <div class="dragBox" v-if="categoryDocs['documents'] && categoryDocs['documents'].length > 0">
                                                  <div class="dragNested">
                                                    <draggable class="list-group" :list="categoryDocs['documents']" group="people" >
                                                    <template  v-for="(document,sindex) in  categoryDocs['documents']">
                                                      <div
                                                      
                                                        v-bind:key="sindex"
                                                        class="drab_sublist"
                                                         v-if="checkProperty( document,'isTrashDocument')"
                                                      >
                                                        <div class="subdragHead"    >{{document.name}}</div>
                                                       
                                                        <div class="downloadPopup-actions d-flex align-center">
                                                            <span @click="downloadfile(document)" class="sub_delete" >
                                                              <img width="14" src="@/assets/images/main/eye.png" />
                                                              <em>View/Download</em>
                                                            </span>
                                                              <span  @click="document['isTrashDocument']=false;savedDocumentsAction()"  class="sub_delete ml-4"   >
                                                                <img src="@/assets/images/main/cross.svg" />
                                                                <em>Remove from the list</em>
                                                              </span>
                                                          </div>
                                                      </div>
                                                      </template>
                                                    </draggable>
                                                  </div>
                                                </div>
                                              </div>
                                            </vs-collapse-item>
                                          </template>
                                        </draggable>
                                      </vs-collapse>
                                    </div>
                                  </vs-col>
                              </template>
                              <!---- companyDocs -->
                              <template  v-if="checkInActiveDocuments(companyDocs)"  >
                                  <vs-col vs-lg="12" vs-sm="12" vs-xs="12">
                                     <div class="list_elements drag-items">
                                      <h2 class="small-header">Company Documents</h2>
                                      <vs-collapse accordion>
                                        <draggable :list="companyDocs" group="people">
                                          <template v-for="(categoryDocs, index) in companyDocs">
                                              <!-----{"category":category,"documents":categoryDocuments}-->
                                            <vs-collapse-item v-if="checktTrashedDocuments(categoryDocs['documents'])"  :key="index" >
                                              <div slot="header" class="d_header_title">
                                               <!----- {{1+index}} - {{categoryDocs["category"] | formatdoctype}}
                                                {{categoryDocs["category"] }}--->
                                                Company Documents
                                                <span  @click="moveToSave('companyDocs', categoryDocs['category'])"  >
                                                  <img src="@/assets/images/main/delete-row-img.svg" />
                                                  <em>Remove from the list</em>
                                                </span>
                                              </div>
                                              <div>
                                                <div class="dragBox" v-if="categoryDocs['documents'] && categoryDocs['documents'].length > 0">
                                                  <div class="dragNested">
                                                    <draggable class="list-group" :list="categoryDocs['documents']" group="people">
                                                    <template  v-for="(document,sindex) in  categoryDocs['documents']">
                                                      <div
                                                      
                                                        v-bind:key="sindex"
                                                        class="drab_sublist"
                                                         v-if="checkProperty( document,'isTrashDocument')"
                                                      >
                                                        <div class="subdragHead"    >{{document.name}}</div>
                                                       
                                                        <div class="downloadPopup-actions d-flex align-center">
                                                            <span @click="downloadfile(document)" class="sub_delete" >
                                                              <img width="14" src="@/assets/images/main/eye.png" />
                                                              <em>View/Download</em>
                                                            </span>
                                                              <span  @click="document['isTrashDocument']=false;savedDocumentsAction()"  class="sub_delete ml-4"   >
                                                                <img src="@/assets/images/main/cross.svg" />
                                                                <em>Remove from the list</em>
                                                              </span>
                                                          </div>
                                                      </div>
                                                      </template>
                                                    </draggable>
                                                  </div>
                                                </div>
                                              </div>
                                            </vs-collapse-item>
                                          </template>
                                        </draggable>
                                      </vs-collapse>
                                    </div>
                                  </vs-col>
                              </template>
                              <!----USCISDocs-->
                              <template  v-if="checkInActiveDocuments(USCISDocs)"  >
                                  <vs-col vs-lg="12" vs-sm="12" vs-xs="12">
                                     <div class="list_elements drag-items">
                                      <h2 class="small-header">USCIS Documents</h2>
                                      <vs-collapse accordion>
                                        <draggable :list="USCISDocs" group="people">
                                          <template v-for="(categoryDocs, index) in USCISDocs">
                                              <!-----{"category":category,"documents":categoryDocuments}-->
                                            <vs-collapse-item v-if="checktTrashedDocuments(categoryDocs['documents'])"  :key="index" >
                                              <div slot="header" class="d_header_title">
                                               <!----- {{1+index}} - {{categoryDocs["category"] | formatdoctype}}
                                                {{categoryDocs["category"] }}--->
                                                USCIS Documents
                                                <span  @click="moveToSave('USCISDocs', categoryDocs['category'])"  >
                                                  <img src="@/assets/images/main/delete-row-img.svg" />
                                                  <em>Remove from the list</em>
                                                </span>
                                              </div>
                                              <div>
                                                <div class="dragBox" v-if="categoryDocs['documents'] && categoryDocs['documents'].length > 0">
                                                  <div class="dragNested">
                                                    <draggable class="list-group" :list="categoryDocs['documents']" group="people" >
                                                    <template  v-for="(document,sindex) in  categoryDocs['documents']">
                                                      <div
                                                      
                                                        v-bind:key="sindex"
                                                        class="drab_sublist"
                                                         v-if="checkProperty( document,'isTrashDocument')"
                                                      >
                                                        <div class="subdragHead"    >{{document.name}}</div>
                                                       
                                                        <div class="downloadPopup-actions d-flex align-center">
                                                            <span @click="downloadfile(document)" class="sub_delete" >
                                                              <img width="14" src="@/assets/images/main/eye.png" />
                                                              <em>View/Download</em>
                                                            </span>
                                                              <span  @click="document['isTrashDocument']=false;savedDocumentsAction()"  class="sub_delete ml-4"   >
                                                                <img src="@/assets/images/main/cross.svg" />
                                                                <em>Remove from the list</em>
                                                              </span>
                                                          </div>
                                                      </div>
                                                      </template>
                                                    </draggable>
                                                  </div>
                                                </div>
                                              </div>
                                            </vs-collapse-item>
                                          </template>
                                        </draggable>
                                      </vs-collapse>
                                    </div>
                                  </vs-col>
                              </template>
                             <!------otherMergeDocuments-->
                             <template  v-if="checkInActiveDocuments(otherMergeDocuments)"  >
                                  <vs-col vs-lg="12" vs-sm="12" vs-xs="12">
                                     <div class="list_elements drag-items">
                                      <h2 class="small-header">Other Documents</h2>
                                      <vs-collapse accordion>
                                        <draggable :list="otherMergeDocuments" group="people">
                                          <template v-for="(categoryDocs, index) in otherMergeDocuments">
                                              <!-----{"category":category,"documents":categoryDocuments}-->
                                            <vs-collapse-item v-if="checktTrashedDocuments(categoryDocs['documents'])"  :key="index" >
                                              <div slot="header" class="d_header_title">
                                               <!----- {{1+index}} - {{categoryDocs["category"] | formatdoctype}}
                                                {{categoryDocs["category"] }}--->
                                                Other Documents
                                                <span  @click="moveToSave('otherMergeDocuments', categoryDocs['category'])"  >
                                                  <img src="@/assets/images/main/delete-row-img.svg" />
                                                  <em>Remove from the list</em>
                                                </span>
                                              </div>
                                              <div>
                                                <div class="dragBox" v-if="categoryDocs['documents'] && categoryDocs['documents'].length > 0">
                                                  <div class="dragNested">
                                                    <draggable class="list-group" :list="categoryDocs['documents']" group="people" >
                                                    <template  v-for="(document,sindex) in  categoryDocs['documents']">
                                                      <div
                                                      
                                                        v-bind:key="sindex"
                                                        class="drab_sublist"
                                                         v-if="checkProperty( document,'isTrashDocument')"
                                                      >
                                                        <div class="subdragHead"    >{{document.name}}</div>
                                                       
                                                        <div class="downloadPopup-actions d-flex align-center">
                                                            <span @click="downloadfile(document)" class="sub_delete" >
                                                              <img width="14" src="@/assets/images/main/eye.png" />
                                                              <em>View/Download</em>
                                                            </span>
                                                              <span  @click="document['isTrashDocument']=false;savedDocumentsAction()"  class="sub_delete ml-4"   >
                                                                <img src="@/assets/images/main/cross.svg" />
                                                                <em>Remove from the list</em>
                                                              </span>
                                                          </div>
                                                      </div>
                                                      </template>
                                                    </draggable>
                                                  </div>
                                                </div>
                                              </div>
                                            </vs-collapse-item>
                                          </template>
                                        </draggable>
                                      </vs-collapse>
                                    </div>
                                  </vs-col>
                              </template>
                              <!----reecentDocuments-->
                              <template  v-if="checkInActiveDocuments(reecentDocuments) && false"  >
                                  <vs-col vs-lg="12" vs-sm="12" vs-xs="12">
                                     <div class="list_elements drag-items">
                                      <h2 class="small-header">Recent Downloads</h2>
                                      <vs-collapse accordion>
                                        <draggable :list="reecentDocuments" group="people">
                                          <template v-for="(categoryDocs, index) in reecentDocuments">
                                              <!-----{"category":category,"documents":categoryDocuments}-->
                                            <vs-collapse-item v-if="checktTrashedDocuments(categoryDocs['documents'])"  :key="index" >
                                              <div slot="header" class="d_header_title">
                                               <!----- {{1+index}} - {{categoryDocs["category"] | formatdoctype}} --->
                                                {{categoryDocs["category"] | formatdoctype }} Documents
                                               
                                                <span  @click="moveToSave('reecentDocuments', categoryDocs['category'])"  >
                                                  <img src="@/assets/images/main/delete-row-img.svg" />
                                                  <em>Remove from the list</em>
                                                </span>
                                              </div>
                                              <div>
                                                <div class="dragBox" v-if="categoryDocs['documents'] && categoryDocs['documents'].length > 0">
                                                  <div class="dragNested">
                                                    <draggable class="list-group" :list="categoryDocs['documents']" group="people" >
                                                    <template  v-for="(document,sindex) in  categoryDocs['documents']">
                                                      <div
                                                      
                                                        v-bind:key="sindex"
                                                        class="drab_sublist"
                                                         v-if="checkProperty( document,'isTrashDocument')"
                                                      >
                                                        <div class="subdragHead"    >{{document.name}}</div>
                                                       
                                                        <div class="downloadPopup-actions d-flex align-center">
                                                            <span @click="downloadfile(document)" class="sub_delete" >
                                                              <img width="14" src="@/assets/images/main/eye.png" />
                                                              <em>View/Download</em>
                                                            </span>
                                                              <span  @click="document['isTrashDocument']=false;savedDocumentsAction()"  class="sub_delete ml-4"   >
                                                                <img src="@/assets/images/main/cross.svg" />
                                                                <em>Remove from the list</em>
                                                              </span>
                                                          </div>
                                                      </div>
                                                      </template>
                                                    </draggable>
                                                  </div>
                                                </div>
                                              </div>
                                            </vs-collapse-item>
                                          </template>
                                        </draggable>
                                      </vs-collapse>
                                    </div>
                                  </vs-col>
                              </template>
                              

                              <template v-if="!checkInActiveDocuments(otherMergeDocuments) && !checkInActiveDocuments(companyDocs) && !checkInActiveDocuments(processedChequeDocs) && !checkInActiveDocuments(filteredLetters) && !checkInActiveDocuments(beneficiaryDocumentsList) && !checkInActiveDocuments(suposeDocumentsList) && !checkChildInActiveDocuments" >
                                <div class="vs-col vs-xs-12 vs-sm-12 vs-lg-12">
                                   <NoDataFound ref="NoDataFoundRef" :loading="false" :checkLocading="false"  content="" :heading="'No Documents Found'" type='Documents' />
                                </div>  
                              </template>

                          </vs-row>
                      <!---</VuePerfectScrollbar>  -->  
                  </div>
              </div>

          </vs-tab>
      </vs-tabs>
    
      <div class="popup-footer relative">
        <div>
         
          <button v-if="documentActiveTab=='savedDocuments'" class="edit-doc upload_doc"  @click=" disable_uploadBtn = false;fuploder = false;fileuploadPopup=true;formerrors.msg='' , uploadMainDocuments=[] ,uploadFinalMainDocuments=[]">Upload <img src="@/assets/images/main/upload.svg" /></button> 
        </div>
        <div class="d-flex">
          <button  @click="$emit('closeMe');downloadDocList = false" class="cancel" type="filled" color="dark">Cancel</button>
          <vs-button
            v-if="documentActiveTab=='savedDocuments'"
            color="success"
            :disabled="filesDownloading|| ( !checkActiveDocuments(USCISDocs) && !checkActiveDocuments(processedChequeDocs) && !checkActiveDocuments(scannedDocsCatList) && !checkActiveDocuments(beneficiaryDocumentsList) && !checkActiveDocuments(beneficiaryDocumentsList) && !checkActiveDocuments(suposeDocumentsList) && !checkChildActiveDocuments)"
            @click="downloadcombine"
            class="marl15 save"
            type="filled"
          >Download</vs-button>
        </div>
        <span v-if="filesDownloading" class="loader"><img src="@/assets/images/main/loader.gif"></span>
      </div>
    <vs-popup class="Change_petition_wrap" :title="'Upload Documents'" :active.sync="fileuploadPopup">
        <div class="Change_petition" @click="formerrors.msg=''">
            <div class="vx-col w-full">
            
                
                    <div class="vx-row">
                        <div class="vx-col w-full">
                            <vx-input-group class="form-input-group select-upload-group">
                                <div class="uploadsec_wrap">
                                    <div class="w-full">
                                     <!-- :accept="acceptedFiles"  -->

                                        <div  @click="uploadMainDocuments=[]">
                                            <div class="relative">
                                                <file-upload v-model="uploadMainDocuments"  :accept="allDocEntity"                                         
                                                class="file-upload-input mb-0" style="height:50px; padding:0px;" :name="'pdocuments'" :multiple="true" :hideSelected="true" v-validate="'required'" label="Forms and Letters" data-vv-as="Forms and Letters"  @input="uploadToS3MainDocuments(uploadMainDocuments)">
                                                    <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                                                    Upload
                                                </file-upload>
                                                <span v-if="fileUploading" class="loader"><img src="@/assets/images/main/loader.gif"></span>   
                                            </div>
                                            <span class="file-type mb-0">(File Type: PDF, DOC, JPEG, PNG. Max file size: 1MB)</span>
                                            <span class="text-danger text-sm" v-show="errors.has('pdocuments')">{{ errors.first('documents'+index) }}</span>
                                        </div>

                                        <VuePerfectScrollbar class="scrollbardoc">
                                            <div class="uploded-files_wrap mt-3" v-if="uploadFinalMainDocuments && uploadFinalMainDocuments.length >0 ">
                                                <div class="w-full" v-for="(fil, fileindex) in uploadFinalMainDocuments" :key="fileindex">                                                   
                                                    <div class="uploded-files">
                                                        <vx-input-group class="form-input-group">
                                                            <vs-input v-on:keyup="filameChenged(fileindex)"  v-validate="'required'" class="w-full" :name="'fName'+fileindex" v-model="fil['name']" data-vv-as="File Name" />
                                                            <span class="text-danger text-sm" v-show="errors.has('fName'+fileindex)">{{ errors.first('fName'+fileindex) }}</span>

                                                            <div class="delete" style="z-index:999" @click="remove(fil, uploadFinalMainDocuments ,fileindex)">
                                                                <img src="@/assets/images/main/cross.svg" />
                                                            </div>
                                                        </vx-input-group>
                                                    </div>
                                                </div>
                                            </div>
                                        </VuePerfectScrollbar>
                                    </div>
                                </div>
                            </vx-input-group>
                        </div>
                    </div>
                
            </div>
             <div class="text-danger text-sm formerrors" v-show="formerrors.msg" @click="formerrors.msg=''">
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius mb-0 mt-3" icon-pack="IntakePortal"
              icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
          </div>
        </div>
        <!-----v-if="fuploder"-->
        
        <div class="popup-footer relative">
            <button @click="fileuploadPopup=false;cancelpopups() ; fuploder=false" class="btn cancel">Cancel</button>
            <button class="btn save" v-bind:disble="disable_uploadBtn || uploadFinalMainDocuments.length <=0" @click="updateFormsAndDocuments()">
                <figure v-if="fuploder"  class="loader"><img src="@/assets/images/main/loader.gif" /></figure> 
                Upload
            </button>
        </div>
    </vs-popup>
    </template>

    

    
    
  </div>





</template>
<script>
import JQuery from "jquery";
import FileUpload from "vue-upload-component/src";
import draggable from "vuedraggable";
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import NoDataFound from "@/views/common/noData.vue";

import { XIcon } from 'vue-feather-icons'
import * as _ from "lodash";
export default {
computed:{
  checkIsChildh4Required(){
            let returVal = false;
            if(this.checkProperty( this.petition['dependentsInfo'] ,'childrens')){
               _.forEach(this.petition['dependentsInfo']['childrens'],( item)=>{
                   if(item.h4Required==true){
                       returVal =true;
                   }
                })
            }
            return returVal;
        },
checktSavedDocuments(){
  let _self= this;
  return (docsList)=>{
     
      let savedDocs=_.filter(docsList ,{"isTrashDocument":false});
      
      if(savedDocs && _self.checkProperty(savedDocs ,'length')>0){
          return true
      }else{
          return false;
      }

  }
},
checktTrashedDocuments(){
  let _self= this;
  return (docsList)=>{
     
      let savedDocs=_.filter(docsList ,{"isTrashDocument":true});
      
      if(savedDocs &&savedDocs.length>0){
          return true
      }else{
          return false;
      }

  }
},

checkActiveDocuments(){
  let _self =this;
  return (allDocs)=>{
      let count =0;
      if(allDocs.length>0){
       
          _.forEach(allDocs ,(catDocs)=>{
            
             //alert(JSON.stringify(catDocs))
              if(_.has(catDocs,'documents') && catDocs['documents'].length>0){
                
                let activDocs = _.filter(catDocs['documents'] ,{"isTrashDocument":false});
                
                      if(activDocs && activDocs.length>0){
                          count =count+1;
                      }

                  

              }

          });
          if(count>0){
             return true;
          }else{
              return false;
          }
          
      }else{
          return false;
      }

  }
},
checkInActiveDocuments(){
  let _self =this;
  return (allDocs)=>{
      let count =0;
      if(allDocs.length>0){
       
          _.forEach(allDocs ,(catDocs)=>{
            
             //alert(JSON.stringify(catDocs))
              if(_.has(catDocs,'documents') && catDocs['documents'].length>0){
                
                let activDocs = _.filter(catDocs['documents'] ,{"isTrashDocument":true});
                
                      if(activDocs && activDocs.length>0){
                          count =count+1;
                      }

                  

              }

          });
          if(count>0){
             return true;
          }else{
              return false;
          }
          
      }else{
          return false;
      }

  }
},
checkChildActiveDocuments(){
let count =0;
this.childrenDocuments.map((child ,indx)=>{
if(_.has( child ,'documents')){

  child['documents'].map((items)=>{
  if( _.has(items ,'documents') && items['documents'].length>0 ){
   
   let alctiveDocuments = _.filter(items['documents'] ,{"isTrashDocument":false})
    if(alctiveDocuments && alctiveDocuments.length>0){
      
      count =count+1;
    }
  }


});

}


});
if(count>0){
return true
}else{
return false;
}

},
checkChildInActiveDocuments(){
let count =0;
this.childrenDocuments.map((child ,indx)=>{
if(_.has( child ,'documents')){

  child['documents'].map((items)=>{
  if( _.has(items ,'documents') && items['documents'].length>0 ){
   
   let alctiveDocuments = _.filter(items['documents'] ,{"isTrashDocument":true})
    if(alctiveDocuments && alctiveDocuments.length>0){
      
      count =count+1;
    }
  }


});

}


});
if(count>0){
return true
}else{
return false;
}

},


},
data() {
return {

  formerrors: {
        msg: ""
      },
      fuploder: false,
        rfuploder: false,
        disable_uploadBtn: false,
        fileUploading:false,
      reversion_fileuploadPopup: false,
  fileuploadPopup: false,
  uploadMainDocuments:[],
  uploadFinalMainDocuments:[],
tempData:null,
filesDownloading:false,
beneficiaryDocuments:{},
beneficiaryDocumentsList:[],

suposeDocuments:{},
suposeDocumentsList:[],
childrenDocuments:[],
savedDocumentsList:[],
isDocumentsAreSaved:false,
downloadDocList:true,
documentActiveTab:'savedDocuments',


formsAndLettersList:[],
allFormsAndLettersList:[],
filteredLetters:[],

scannedDocsList:[],
scannedDocsCatList:[],

processedChequeDocs:[],
companyDocs:[],

USCISDocs:[],
otherMergeDocuments:[],
petition:null,
reecentDocuments:[],




}
},
methods: {
  getDocumentsList(){
    this.reecentDocuments = [];
        let payLoad={
            petitionId: this.checkProperty(this.petition,'_id') ,
		    categories: ['forms_and_letters','beneficiary_docs','scanned_copies'],
            entityType:'case',
            typeName: this.checkProperty(this.petition,'typeDetails','name'),
            subTypeName:this.checkProperty(this.petition,'subTypeDetails','name'),
        }
        if(this.checkProperty(this.petition,'subTypeDetails','id')==15){
            payLoad['entityType'] ='perm'
        }
        let path = '/petition-common/get-recent-downloads'
        this.$store.dispatch("commonAction" ,{data:payLoad,'path':path}).then((response) =>{
            let list = response
            let formAndLettersList =[];
            let beneficiaryDocsList =[];
            let scannedDocsList =[];
            _.forEach( list,(doc)=>{

              doc = Object.assign(doc ,{"isTrashDocument": false});

                       if(this.isDocumentsAreSaved && this.savedDocumentsList && this.savedDocumentsList.length>0){
                        let isSaved = _.find(this.savedDocumentsList ,{"path":doc['path']});
                        if(isSaved){
                          doc = Object.assign(doc ,{"isTrashDocument":false});
                        }else{
                          doc = Object.assign(doc ,{"isTrashDocument":true});
                        }

                      }
                      if(this.checkProperty(doc ,'category') =='forms_and_letters'){
                        formAndLettersList.push(doc);
                      }
                      if(this.checkProperty(doc ,'category') =='beneficiary_docs'){
                        beneficiaryDocsList.push(doc);
                      }
                      if(this.checkProperty(doc ,'category') =='scanned_copies'){
                        scannedDocsList.push(doc);
                      }

            });
             

            if(beneficiaryDocsList && beneficiaryDocsList.length>0){
               let items =   { "category": "recent_beneficiary_docs", "documents": beneficiaryDocsList,'docTypeOrder':1000000 };
               
               this.reecentDocuments.push(items);
            }
            if(formAndLettersList && formAndLettersList.length>0){
               let items =    { "category": "recent_forms_and_letters", "documents": formAndLettersList,'docTypeOrder':1000000 };
               
               this.reecentDocuments.push(items);
            }
            if(scannedDocsList && scannedDocsList.length>0){
               let items =   { "category": "recent_scanned_copies", "documents": scannedDocsList,'docTypeOrder':1000000 };
               
               this.reecentDocuments.push(items);
            }
            //recent_forms_and_letters
           // recent_beneficiary_docs
            //recent_scanned_copies

            
          })
          .catch((err) =>{})

    },
  processOtherMergeDocuments(){
   
    this.otherMergeDocuments =[];
    let obj = {'documents':[] ,"category":'other' ,"isTrashDocument":false} 
            if(this.checkProperty(this.petition,'caseDocs') && this.checkProperty(this.petition,'caseDocs','otherMerge') && this.checkProperty(this.petition['caseDocs'],'otherMerge','length')>0){
             
              _.forEach(this.petition['caseDocs']['otherMerge'],(item)=>{
                      let doc =_.cloneDeep(item);
                       doc = Object.assign(doc ,{"isTrashDocument": false});

                       if(this.isDocumentsAreSaved && this.savedDocumentsList && this.savedDocumentsList.length>0){
                        let isSaved = _.find(this.savedDocumentsList ,{"path":doc['path']});
                        if(isSaved){
                          doc = Object.assign(doc ,{"isTrashDocument":false});
                        }else{
                          doc = Object.assign(doc ,{"isTrashDocument":true});
                        }

                      }
                       obj['documents'].push(doc)
                })
            }
           
            if(this.checkProperty(obj ,'documents' ,'length')>0){
              this.otherMergeDocuments =[];
              this.otherMergeDocuments.push(obj);
           }
           


  },
  remove(item, type) {
            type.splice(type.indexOf(item), 1);
            return false;
        },
  updateFormsAndDocuments() {
             
             Object.assign( this.formerrors ,{ msg:''})
            if (this.disable_uploadBtn) {
                return false;
            }
           // this.fileuploadPopup = false;

            let postData = {
              petitionId: this.checkProperty(this.petition, '_id'),
              docType: "otherMerge",
              documents:[],
                

            };
            // if(this.parentId){
            //     postData = Object.assign(postData ,{"parentId":this.parentId})
            // }
            if(this.uploadFinalMainDocuments.length>0){

                    this.uploadFinalMainDocuments.forEach((doc)=>{
                       
                        let document = doc.document
                        document = Object.assign(document ,{ name:doc.name})
                        document['uploadedBy'] =this.checkProperty(this.getUserData,'userId')!=''?this.checkProperty(this.getUserData,'userId'):null,
                        document['uploadedByName'] =this.checkProperty(this.getUserData,'name')!=''?this.checkProperty(this.getUserData,'name'):'',
                        document['uploadedByRoleId'] = this.getUserRoleId?this.getUserRoleId:null,
                        document['uploadedByRoleName'] =this.checkProperty(this.getUserData,'loginRoleName'),
                        postData['documents'].push(document);
                        
                    })
                   

                
            this.fuploder = true;
            this.disable_uploadBtn = true;
            let count = 0;
           
        this.$store.dispatch("commonAction", { "data": postData,"path":"/petition/upload-case-docs"}).then(response => {
                        
                         this.fileuploadPopup = false;
                         this.showToster({message:response.message ,isError:false })
                         this.fuploder = false;
                         this.disable_uploadBtn = false;
                         this.fileuploadPopup = false;
                         this.fileUploading =false;

                       
                        let otherMerge =[];
                        if(this.checkProperty(this.petition,'caseDocs') && this.checkProperty(this.petition,'caseDocs','otherMerge')){
                          _.forEach(postData['documents'],(document)=>{
                            document = Object.assign(document ,{"isTrashDocument": false});
                            
                              this.petition['caseDocs']['otherMerge'].push(document);
                              this.petitionDetails['caseDocs']['otherMerge'].push(document);
                              otherMerge.push(document);
                           
                           
                           
                          })
                        }else{
                           
                          _.forEach(postData['documents'],(document)=>{
                            document = Object.assign(document ,{"isTrashDocument": false});
                            otherMerge.push(document);

                           
                          })

                         

                        }

                         
                        
                          if(this.otherMergeDocuments.length>0){
                            _.forEach(otherMerge ,(document)=>{

                              let isExists =_.find(this.otherMergeDocuments[0], {"path":document['path']} );
                            if(!isExists){
                              this.otherMergeDocuments[0]['documents'].push(document);
                            }
                              
                              this.otherMergeDocuments =_.cloneDeep(this.otherMergeDocuments);
                            })
                            
                             
                          }else{
                            let obj = {'documents':[] ,"category":'other' ,"isTrashDocument":false}
                            this.otherMergeDocuments =[];
                            obj['documents'] =otherMerge
                            this.otherMergeDocuments.push(obj) 
                          }

                        
                       
                        
                        
                     })
                    .catch((error) => {

                       this.uploadFinalMainDocuments =[];
                        Object.assign(this.formerrors ,{'msg':error})
                        //this.showToster({ message: error, isError: true });
                        this.fuploder = false;
                        this.disable_uploadBtn = false;
                    });
             
       }else{
            Object.assign( this.formerrors ,{ msg:'Upload atleast one document'})

      }
    
         
       
       },

  cancelpopups() {
            this.documentData = [{
                type: "Forms, Letters and Others",
                documentUploaded: []
            }]
        },
  uploadToS3MainDocuments(docs) {
    this.uploadFinalMainDocuments =[];
      docs = docs.map(
        (item) =>
          (item = {
            name: item.name,
            file: item.file,
            document: "",
            path: "",
            mimetype: item.type,
          })
      );
      this.formerrors.msg = "";

      if (docs.length > 0) {
        let filIndex = 0;

        docs.forEach((doc) => {
         
         
            this.disable_uploadBtn = true;
            this.fuploder = true;
            let formData = new FormData();
            formData.append("files", doc.file);
            formData.append("secureType", "private");
            formData.append("getDetails", true);

            this.$store.dispatch("uploadS3File", formData).then((response) => {
              filIndex++;
              if (filIndex >= this.uploadMainDocuments.length) {
                this.fuploder = false;
                this.disable_uploadBtn = false;
              }

              response.data.result.forEach((urlGenerated) => {
                //alert(JSON.stringify(urlGenerated));
                doc.document = urlGenerated;
                doc.path = urlGenerated;
                //this.uploadMainDocuments.push(doc);
               
                this.uploadFinalMainDocuments.push(doc);
              });
            });
          
          
        });
      }
    },
  processUscisDocuments(){
    this.USCISDocs =[];
    let USCISDocs = [];
    let obj = {'documents':[] ,"category":'USCISDocs' ,"isTrashDocument":false} 
            if(this.checkProperty(this.petition,'caseDocs') && this.checkProperty(this.petition,'caseDocs','uscisNotices') && this.checkProperty(this.petition['caseDocs'],'uscisNotices','length')>0){
             
              _.forEach(this.petition['caseDocs']['uscisNotices'],(item)=>{
                      let doc =_.cloneDeep(item);
                       doc = Object.assign(doc ,{"isTrashDocument": false});

                       if(this.isDocumentsAreSaved && this.savedDocumentsList && this.savedDocumentsList.length>0){
                        let isSaved = _.find(this.savedDocumentsList ,{"path":doc['path']});
                        if(isSaved){
                          doc = Object.assign(doc ,{"isTrashDocument":false});
                        }else{
                          doc = Object.assign(doc ,{"isTrashDocument":true});
                        }

                      }
                       obj['documents'].push(doc)
                })
            }
            if(this.checkProperty(this.petition,'rfeNotice') && this.checkProperty(this.petition,'rfeNotice','documents') && this.checkProperty(this.petition['rfeNotice'],'documents','length')>0){
             
              _.forEach(this.petition['rfeNotice']['documents'],(item)=>{
                     let doc =_.cloneDeep(item);
                       doc = Object.assign(doc ,{"isTrashDocument": false});
                       if(this.isDocumentsAreSaved && this.savedDocumentsList && this.savedDocumentsList.length>0){
                        let isSaved = _.find(this.savedDocumentsList ,{"path":doc['path']});
                        if(isSaved){
                          doc = Object.assign(doc ,{"isTrashDocument":false});
                        }else{
                          doc = Object.assign(doc ,{"isTrashDocument":true});
                        }

                      }
                       obj['documents'].push(doc)
                })
                
            }
            if(this.checkProperty(obj ,'documents' ,'length')>0){
              this.USCISDocs =[];
              this.USCISDocs.push(obj);
           }
           

           

  },
  getCompanyDocs(){
            this.companyDocs = [];
            let postData ={companyId:this.checkProperty(this.petition, 'companyDetails', '_id') ,'page':1 ,'perpage':100000};
            this.$store.dispatch("getList" ,{data:postData,path:"/company/documents-list"})
            .then(response => {
              let list =[];
                let tempList = response.list
                let obj = {'documents':[] ,"category":'companyDocs' ,"isTrashDocument":false}
                // if(this.checkProperty(this.petition,'caseDocs') && this.checkProperty(this.petition,'caseDocs','company') && this.checkProperty(this.petition['caseDocs'],'company','length')>0){
                //     _.forEach(this.petition['caseDocs']['company'],(item)=>{
                //       let doc =_.cloneDeep(item);
                //       doc = Object.assign(doc ,{"isTrashDocument": false});

                //         list.push(doc)
                //     })
                // }
                if(tempList.length>0){

                  _.forEach(tempList,(item)=>{
                       let doc =_.cloneDeep(item);
                       doc = Object.assign(doc ,{"isTrashDocument": false});
                       if(this.isDocumentsAreSaved && this.savedDocumentsList && this.savedDocumentsList.length>0){
                        let isSaved = _.find(this.savedDocumentsList ,{"path":doc['path']});
                        if(isSaved){
                          doc = Object.assign(doc ,{"isTrashDocument":false});
                        }else{
                          doc = Object.assign(doc ,{"isTrashDocument":true});
                        }

                      }

                       list.push(doc)
                     })

                }
                if(list && this.checkProperty(list,'length')>0){
                    Object.assign(obj,{'documents':list ,"category":'companyDocs' ,"isTrashDocument":false})
                }
                if(this.checkProperty(obj ,'documents' ,'length')>0){
                  this.companyDocs = [];
                    this.companyDocs =[obj]//

                    
                }
               
            })
            .catch((err)=>{})
        },
  processAllDocuments(){
    this.getDocumentsList();
    this.processFormsAndLetters();
    this.processScannedDocs();
    this.processChequesDocs();
    this.processUscisDocuments();
    this.processOtherMergeDocuments();

   },
    closeMe(){
    this.$emit('closeMe')
    },
    savedDocumentsAction(callFromDownload=false){
    if(callFromDownload ==false){
    return ;
    }
    setTimeout(()=>{


    const $ = JQuery;
    let postData = { "petitionId":'', 'docList':[] ,"entityType": "case"  ,"category": "merge_all_docs"};



    // alert(JSON.stringify(benCategoryOrders));

    postData = { "petitionId":'', 'docList':[] ,"entityType": "case" };
    let processDocuments =(documents ,category='benficiary' ,childrenId='' )=>{

    let benCategoryOrders ={};
    let benDocOrders ={};
    let supCategoryOrders ={};
    let chlCategoryOrders ={};
    if(category=='benficiary'){
      $("[id^='docTypeOrder_ben_']").each( (i, el)=> {
      
        let category = el.id.substr(17);
        benCategoryOrders[category] = i;
      
      });

      



    }else if(category=='spouse'){
    $("[id^='docTypeOrder_sup_']").each( (i, el)=> {
    //   alert(el.id.substr(4))
    let category = el.id.substr(17);
    supCategoryOrders[category] = i;

    });

    }else if(category=='children'){ 
    $("[id^='docTypeOrder_"+childrenId+"_']").each( (i, el)=> {
    //   alert(el.id.substr(4))
    let id = el.id;
    let arr= id.split("_");
    if(arr.length>2){
      let category = arr[2];
    chlCategoryOrders[category] = i;
    }


    });
    //  alert(JSON.stringify(chlCategoryOrders));
    }else if(category=='benficiary'){
      $("[id^='docTypeOrder_'"+category+"'_']").each( (i, el)=> {
      
        let category = el.id.substr(17);
        benCategoryOrders[category] = i;
      
      });

      



    }
        _.forEach(
          documents,
        (item ,index)=> {
          
            if( this.checkProperty(item  ,'category')){
            if( this.checkProperty(item['documents'] ,'length')>0){
              let documentCategory =item['category'];
      
                let activeRecords = [];
                _.forEach(item['documents'] ,(doc)=>{
                    let order =1000000
                if(category=='benficiary'){
                  $("[id^='order_ben_"+documentCategory+"']").each( (i, el)=> {
                  
                    if(el.id){
                      let id =el.id;
                      //_docPath_
                      let docPathArr = id.split("_docPath_");
                      if(docPathArr.length>1){
                        let path =docPathArr[1];
                        if(path==doc['path']){
                          order =i;
                        }
                      
                      }
                    }
                    ;

                  })
                }else if(category=='spouse'){
                  $("[id^='order_sup_"+documentCategory+"']").each( (i, el)=> {
                  
                    if(el.id){
                      let id =el.id;
                      //_docPath_
                      let docPathArr = id.split("_docPath_");
                      if(docPathArr.length>1){
                        let path =docPathArr[1];
                        if(path==doc['path']){
                          order =i;
                        }
                      
                      }
                    }
                    

                  })
                } else if(category=='children'){ 
                    $("[id^='order_chi_"+documentCategory+"_"+childrenId+"']").each( (i, el)=> {
                      if(el.id){
                      let id =el.id;
                      //_docPath_
                      let docPathArr = id.split("_docPath_");
                      if(docPathArr.length>1){
                        let path =docPathArr[1];
                        if(path==doc['path']){
                          order =i;
                        }
                      
                      }
                    }
                      
                      
                      });

                }else {
                  $("[id^='order_"+documentCategory+"']").each( (i, el)=> {
                  
                    if(el.id){
                      let id =el.id;
                      //_docPath_
                      let docPathArr = id.split("_docPath_");
                      if(docPathArr.length>1){
                        let path =docPathArr[1];
                        if(path==doc['path']){
                          order =i;
                        }
                      
                      }
                    }
                    ;

                  })
                }
                  
                let isAlreadyExista = _.find(postData['docList'] ,{'path':doc['path']});
                  if( !doc['isTrashDocument'] ){
                    
                    let docListItem ={
                      "path":doc['path'],
                      "order": order,
                        "docType": documentCategory,
                        "docTypeOrder": 10000,
                        "category": category,
                        "childrenId": childrenId,
                        "documentCategory":documentCategory



                    }
                    if(_.has(benCategoryOrders ,documentCategory) && category=='benficiary'){
                      docListItem['docTypeOrder'] =benCategoryOrders[documentCategory];
                    // alert(JSON.stringify(docListItem));
                    }else if(_.has(supCategoryOrders ,documentCategory) && category=='spouse'){
                      docListItem['docTypeOrder'] =supCategoryOrders[documentCategory];
                    // alert(JSON.stringify(docListItem));
                    }else if(category==='children' && _.has(chlCategoryOrders ,documentCategory)  ){
                      
                      docListItem['docTypeOrder'] =chlCategoryOrders[documentCategory];
                      //alert(JSON.stringify(docListItem));
                    } 
                    
                    postData['docList'].push(docListItem);
                  }

                })

                

              }
        }
              
        });
    }
    //beneficiaryDocuments:{}, suposeDocuments:{},childrenDocuments:[],
     // beneficiaryDocumentsList  suposeDocumentsList childrenDocuments filteredLetters scannedDocsCatList processedChequeDocs companyDocs USCISDocs

     $("[id^='mainCategory_']").each( (i, el)=> {
      // beneficiaryDocumentsList  suposeDocumentsList childrenDocuments filteredLetters scannedDocsCatList processedChequeDocs companyDocs USCISDocs
                            

    let mainCategory = el.id.substr(13);
    
    if(mainCategory=="beneficiaryDocumentsList"){
      processDocuments(this.beneficiaryDocumentsList ,"benficiary");
    }else if(mainCategory=="suposeDocumentsList"){
      processDocuments(this.suposeDocumentsList ,"spouse");
    }else if(mainCategory=="childrenDocuments"){
      if(this.checkProperty(this.childrenDocuments ,'length')>0){
    _.forEach(this.childrenDocuments ,(child)=>{
      if(this.checkProperty(child ,'documents')){
        processDocuments(child['documents'] ,"children" ,child['_id']);
      }

    });
    }

    }else if(mainCategory=="filteredLetters"){
      processDocuments(this.filteredLetters ,'filteredLetters' );
   }else if(mainCategory=="scannedDocsCatList"){
    processDocuments(this.scannedDocsCatList ,'scannedDocsCatList' );

    }else if(mainCategory=="processedChequeDocs"){
      processDocuments(this.processedChequeDocs ,'processedChequeDocs' );

    }else if(mainCategory=="companyDocs"){
      processDocuments(this.companyDocs ,'companyDocs' );
    }else if(mainCategory=="USCISDocs"){
      processDocuments(this.USCISDocs ,'USCISDocs' );

    }


  });

  
   
   
    let path ="/petition-common/save-docs-selected-config";
    let childrenDocs =_.filter(postData['docList'] ,{ 'category':'children'});
    // alert(JSON.stringify(childrenDocs));
    if(this.checkProperty(postData ,'docList','length') >0 && this.checkProperty(this.petition ,'_id')  ){
    postData['petitionId'] =this.petition._id;
    // path ="/petition/save-docs-selected-config";

    if(this.checkProperty(this.petition, 'type')==3 &&  [15].indexOf(this.checkProperty(this.petition,'subTypeDetails', 'id' )) >-1 ){
      //path ="/perm/save-docs-selected-config";
      postData['entityType'] ='perm'
    }



    this.$store.dispatch("commonAction" ,{data:postData,'path':path})
    .then((rx) =>{
    //  alert(JSON.stringify(rx));
    this.getSavedDocuments();


    }).catch((err)=>{
    //alert(err);
    })
    }

    },5);

    },
    downloadfile(item){

    let tempItem  =item
    tempItem = Object.assign( tempItem, {"viewmode":true});
    this.$emit('downloadfile' ,tempItem)
    },
    moveToTrash(type='beneficiaryDocumentsList',category='' ,childIndex=-1){
    if(type=='childrenDocuments' && childIndex>-1){
    let childrenDocuments =[];
    this.childrenDocuments.map((child ,indx)=>{
    if(indx ==childIndex){

      child['documents'].map((items)=>{
      if(_.has(items ,'category') && category==items['category'] && _.has(items ,'documents') && items['documents'].length>0 ){
        items['documents'].map((item)=>{
          item['isTrashDocument'] =true;
        });
      }


    });

    }
    childrenDocuments.push(child);

    });

    this.childrenDocuments =[];
    this.childrenDocuments = _.cloneDeep(childrenDocuments);

    }else if(type=="beneficiaryDocumentsList"){
    this.beneficiaryDocumentsList.map((items)=>{
    if(_.has(items ,'category') && category==items['category'] && _.has(items ,'documents') && items['documents'].length>0 ){
      items['documents'].map((item)=>{
        item['isTrashDocument'] =true;
      });
    }


    });

    }else if(type=="suposeDocumentsList"){
      this.suposeDocumentsList.map((items)=>{
      if(_.has(items ,'category') && category==items['category'] && _.has(items ,'documents') && items['documents'].length>0 ){
        items['documents'].map((item)=>{
          item['isTrashDocument'] =true;
        });
      }


      });

    }else if(_.has(this ,type)) {
     
      this[type].map((items)=>{
      if(_.has(items ,'category') && category==items['category'] && _.has(items ,'documents') && items['documents'].length>0 ){
        items['documents'].map((item)=>{
          item['isTrashDocument'] =true;
        });
      }


      });

    }

    setTimeout(()=>{
    // this.savedDocumentsAction(true);
    },100);

    },
    moveToSave(type='beneficiaryDocumentsList',category='' ,childIndex=-1){
    if(type=='childrenDocuments' && childIndex>-1){
    this.childrenDocuments.map((child ,indx)=>{
    if(indx ==childIndex){

      child['documents'].map((items)=>{
      if(_.has(items ,'category') && category==items['category'] && _.has(items ,'documents') && items['documents'].length>0 ){
        items['documents'].map((item)=>{
          item['isTrashDocument'] =false;
        });
      }


    });

    }


    });
    let childrenDocuments = _.cloneDeep(this.childrenDocuments);
    this.childrenDocuments =[];
    this.childrenDocuments = _.cloneDeep(childrenDocuments);

    }else if(type=="beneficiaryDocumentsList"){
    this.beneficiaryDocumentsList.map((items)=>{
    if(_.has(items ,'category') && category==items['category'] && _.has(items ,'documents') && items['documents'].length>0 ){
      items['documents'].map((item)=>{
        item['isTrashDocument'] =false;
      });
    }


    });

    }else if(type=="suposeDocumentsList"){
    this.suposeDocumentsList.map((items)=>{
    if(_.has(items ,'category') && category==items['category'] && _.has(items ,'documents') && items['documents'].length>0 ){
      items['documents'].map((item)=>{
        item['isTrashDocument'] =false;
      });
    }


    });

    }else if(_.has(this ,type)) {
    
      this[type].map((items)=>{
      if(_.has(items ,'category') && category==items['category'] && _.has(items ,'documents') && items['documents'].length>0 ){
        items['documents'].map((item)=>{
          item['isTrashDocument'] =false;
        });
      }


      });

    }

    setTimeout(()=>{
    // this.savedDocumentsAction(true);
    },100);

    },

    changedDocumentsTab(tabName='savedDocuments'){
    this.documentActiveTab = tabName;
    setTimeout(()=>{
        this.updateLoading(false);
    } ,10);

    },
    getSavedDocuments(){

    let postData ={
    'petitionId':'',
    'entityType':'case',
    "category": "merge_all_docs"
    };
    postData['petitionId'] =this.petition._id;
    this.isDocumentsAreSaved =false;
    let path ="/petition/get-docs-selected-config";
      path ="/petition-common/get-docs-selected-config";
    if(this.checkProperty(this.petition, 'type')==3 &&  [15].indexOf(this.checkProperty(this.petition,'subTypeDetails', 'id' )) >-1 ){
    //  path ="/perm/get-docs-selected-config";
      postData['entityType'] ='perm'
    }
    this.$store.dispatch("commonAction" ,{data:postData,'path':path})
    .then((rx) =>{
    if(rx){

      if(this.checkProperty( rx,'docList')){
      
        
      this.isDocumentsAreSaved =true;
      this.savedDocumentsList =_.cloneDeep(rx['docList']);

      }else{

          this.savedDocumentsList=[];
        this.isDocumentsAreSaved =false;

      }
      

    }else{
      this.savedDocumentsList=[];
      this.isDocumentsAreSaved =false;

    }

    this.init();

    }).catch((e)=>{

    this.savedDocumentsList=[];
    this.isDocumentsAreSaved =false;
    this.init();
    
    });
    },
    
    init(){


    let _self =this;
    this.beneficiaryDocuments ={};
    this.beneficiaryDocumentsList =[];

    this.suposeDocuments ={};
    this.suposeDocumentsList =[];
    this.childrenDocuments =[];


    //benficiary documents
    let catDocuments =Object.entries(this.petition['documents']);
    let benFinalDocuments ={};
    _.forEach(catDocuments ,(item)=>{
      if(item.length>1){
          let category =_.cloneDeep(item[0]);
          let categoryOrders =null;
          if(item[1].length>0){
              let documents =_.cloneDeep(item[1]);
              let categoryDocuments =[];
              _.forEach(documents ,(document)=>{
                  if(_self.checkProperty(document ,'status') !=false){
                      document = Object.assign(document ,{ "isTrashDocument":false});
                      document['isTrashDocument'] =false;
                      document['order']=100000;
                      document['docTypeOrder']=100000;
                      
                      if(_self.isDocumentsAreSaved){
                        let bencategoryDocs = _.filter(_self.savedDocumentsList ,{'category':'benficiary'});

                      
                      
                        if(bencategoryDocs.length>0){
                          
                          categoryOrders = _.find(bencategoryDocs,{'docType':category ,'category':'benficiary'});
                          
                        
                      
                        let isSaveDoc = _.find(bencategoryDocs,{'path':document['path']});
                        if(isSaveDoc && _.has(isSaveDoc ,'order')){
                          document['order']= isSaveDoc['order'];

                        }
                        if(isSaveDoc && _.has(isSaveDoc ,'docTypeOrder')){
                          document['docTypeOrder']= isSaveDoc['docTypeOrder'];

                        }else  if(categoryOrders && _.has(categoryOrders ,'docTypeOrder')){
                            document['docTypeOrder'] = categoryOrders['docTypeOrder'];
                          }
                        
                          if(!isSaveDoc){
                              document['isTrashDocument']=true;
                          }
                        }else{
                          document['isTrashDocument']=true;
                        }

                      }
                      categoryDocuments.push(_.cloneDeep(document));
                    

                  }

              })
              if(categoryDocuments.length>0 && category !='slgOfferLetter'){
                categoryDocuments =_.orderBy(categoryDocuments, ['order'],  ['asc']);
                  benFinalDocuments[category] = categoryDocuments;
                  if(!_.find(this.beneficiaryDocumentsList ,{'category':category})){
                  let tempData = {"category":category,"documents":categoryDocuments ,'docTypeOrder':1000000};
                  if(categoryOrders && _.has(categoryOrders ,'docTypeOrder') ){
                    tempData['docTypeOrder'] = categoryOrders['docTypeOrder'];
                    }
                  
                  this.beneficiaryDocumentsList.push(tempData);
                  //this.beneficiaryDocumentsList =
                  this.beneficiaryDocumentsList =_.orderBy(this.beneficiaryDocumentsList, ['docTypeOrder'],  ['asc']);

                  }
                }

          }

      }

    });
    this.beneficiaryDocuments  =_.cloneDeep(benFinalDocuments);


    //process spouse documents
    if(_self.checkProperty( _self.petition ,"dependentsInfo" ,'spouse') &&  _self.checkProperty(_self.petition['dependentsInfo']['spouse'], 'h4Required')==true){
    
      if(_self.checkProperty(_self.petition['dependentsInfo']['spouse'] ,'documents'  )){
          
          let catDocuments =Object.entries(_self.petition['dependentsInfo']['spouse']['documents']);
        let spoUseFinalDocuments ={};
        
        _.forEach(catDocuments ,(item)=>{
              if(item.length>1){
                  let category =_.cloneDeep(item[0]);
                  let categoryOrders =null; 
                  
                  if(item[1].length>0){
                      let documents =_.cloneDeep(item[1]);
                      let spousecategoryDocuments =[];
                      _.forEach(documents ,(document)=>{
                        document['order']= 10000;
                        document['docTypeOrder'] =1000;
                          if(_self.checkProperty(document ,'status') !=false){
                            
                              document = Object.assign(document ,{ "isTrashDocument":false});
                              if(_self.isDocumentsAreSaved){
                                let spousecategoryDocs = _.filter(_self.savedDocumentsList ,{'category':'spouse'});


                                if(spousecategoryDocs.length>0){

                                  categoryOrders = _.find(spousecategoryDocs,{'docType':category ,'category':'spouse'});
                              

                                  let isSaveDoc = _.find(spousecategoryDocs,{'path':document['path']});
                                  if(isSaveDoc && _.has(isSaveDoc ,'order')){
                                    document['order']= isSaveDoc['order'];

                                  }
                                  if(isSaveDoc && _.has(isSaveDoc ,'docTypeOrder')){
                                    document['docTypeOrder']= isSaveDoc['docTypeOrder'];

                                  }else  if(categoryOrders && _.has(categoryOrders ,'docTypeOrder')){
                                    document['docTypeOrder'] = categoryOrders['docTypeOrder'];
                                  }

                                  if(!isSaveDoc){
                                      document['isTrashDocument']=true;
                                  }
                                }else{
                                  document['isTrashDocument']=true;
                                }

                              }
                              spousecategoryDocuments.push(_.cloneDeep(document));
                            

                          }

                      })
                    
                      if(spousecategoryDocuments.length>0){
                        spousecategoryDocuments =_.orderBy(spousecategoryDocuments, ['order'],  ['asc']);
                          spoUseFinalDocuments[category] = _.cloneDeep(spousecategoryDocuments);
                          if(!_.find(this.suposeDocumentsList ,{'category':category})){
                            let tempData = {"category":category,"documents":spousecategoryDocuments ,'docTypeOrder':100000}
                            if(categoryOrders && _.has(categoryOrders ,'docTypeOrder')){
                              tempData['docTypeOrder'] = categoryOrders['docTypeOrder'];
                            }
                                                    
                          this.suposeDocumentsList.push(tempData);
                          this.suposeDocumentsList =_.orderBy(this.suposeDocumentsList, ['docTypeOrder'],  ['asc']);

                          }
                          
                          
                      }

                  }

              }

      });
        _self.suposeDocuments  =_.cloneDeep(spoUseFinalDocuments);
        
        

      }

    }
    
    //process childern Documents
    let finalChildrens =[];
    if(_self.checkProperty( _self.petition ,"dependentsInfo" ,'childrens') && _self.checkIsChildh4Required){
      if(_self.checkProperty( _self.petition["dependentsInfo"] ,'childrens' ,'length')>0){

          _.forEach( _self.petition["dependentsInfo"]['childrens'] ,(child)=>{
            
              let childActiveDocuments =[];
              if(_self.checkProperty(child ,'documents')){
                
                  let catDocuments =Object.entries(child['documents']);
                  if(catDocuments.length>0){
                      let allCatDocuments =[];
                      let count =0;
                      _.forEach( catDocuments , (item)=>{
                        
                          if(item.length>1){
                            
                              if(item[1].length>0){
                                  let category = item[0];
                                  let categoryOrders =null; 
                                let categoyDocuments =[];
                                  _.forEach(item[1] ,(doument)=>{
                                      if(  _self.checkProperty(doument ,'status') !=false){
                                          doument = Object.assign(doument ,{ "isTrashDocument":false ,'order':100000 ,'docTypeOrder':10000});
                                          if(_self.isDocumentsAreSaved){
                                            let childrencategoryDocs = _.filter(_self.savedDocumentsList ,{'category':'children' ,'childrenId':child['_id']});
                                            
                                            if(childrencategoryDocs.length>0){
                                              categoryOrders = _.find(childrencategoryDocs,{'docType':category ,'category':'children','childrenId':child['_id']});

                                              let isSaveDoc = _.find(childrencategoryDocs,{'path':doument['path']});
                                              if(isSaveDoc && _.has(isSaveDoc ,'order')){
                                                doument['order']= isSaveDoc['order'];

                                              }

                                              if(isSaveDoc && _.has(isSaveDoc ,'docTypeOrder')){
                                                doument['docTypeOrder']= isSaveDoc['docTypeOrder'];

                                              }else  if(categoryOrders && _.has(categoryOrders ,'docTypeOrder')){
                                                doument['docTypeOrder'] = categoryOrders['docTypeOrder'];
                                              }
                                            
                                              if(!isSaveDoc){
                                                doument['isTrashDocument']=true;
                                              }
                                            }else{
                                              doument['isTrashDocument']=true;
                                            }

                                          }
                                          categoyDocuments.push(doument);
                                          count =count+1;

                                      }

                                  })
                                  
                                  if(categoyDocuments.length>0){
                                    categoyDocuments =_.orderBy(categoyDocuments, ['order'],  ['asc']);
                                      allCatDocuments[category]  =_.cloneDeep(categoyDocuments);
                                      if(!_.find(allCatDocuments ,{'category':category})){

                                        let dc = {'category':category,'documents':categoyDocuments,'docTypeOrder':1000000};
                                          if(categoryOrders && _.has(categoryOrders ,'docTypeOrder')){
                                            dc['docTypeOrder'] = categoryOrders['docTypeOrder'];
                                          }

                                        allCatDocuments.push(dc);
                                        allCatDocuments=_.orderBy(allCatDocuments, ['docTypeOrder'],  ['asc']);

                                      }
                                    
                                  }

                              }


                          }

                      })
                    
                    
                      if(count>0){
                        
                          let tempChildDocs ={
                              "name":'',
                              "_id":child['_id'],
                              "documents":[]
                        };
                        if(_self.checkProperty(child ,'name')){
                              tempChildDocs['name'] = child['name']
                          }else{
                              tempChildDocs['name'] = _self.checkProperty(child ,'firstName')+" "+_self.checkProperty(child ,'lastName')
                          }
                          tempChildDocs['documents'] = _.cloneDeep(allCatDocuments);
                          finalChildrens.push(tempChildDocs);
                          allCatDocuments =[];


                      }else{
                          allCatDocuments =[];
                      }
                  
                  }
                
                

              }

          });

          _self.childrenDocuments = _.cloneDeep(finalChildrens);
    }

    }

  
   this.processAllDocuments();

    setTimeout(()=>{
    this.updateLoading(false);
    setTimeout(()=>{
    this.updateLoading(false);
    } ,10);
    setTimeout(()=>{
    this.updateLoading(false);
    } ,10);
    } ,10);



    },

    downloadcombine() {
    let _APIURL = this.$globalgonfig._APIURL
    var self = this;
    var docs = [];
      let combailDocuments = (alDocs ,category='beneficiary' ,childrenId='')=>{
            
          //{"category":category,"documents":categoryDocuments}
          let allDocuments =[];
          let categoryOrders ={}
          let order =1000000


          if(category=='beneficiary'){
          $("[id^='docTypeOrder_ben_']").each( (i, el)=> {

          let category = el.id.substr(17);
          categoryOrders[category] = i;

          });


          }else if(category=='spouse'){
          $("[id^='docTypeOrder_sup_']").each( (i, el)=> {
          //   alert(el.id.substr(4))
          let category = el.id.substr(17);
          categoryOrders[category] = i;

          });

          }else if(category=='children'){ 
          $("[id^='docTypeOrder_"+childrenId+"_']").each( (i, el)=> {
          //   alert(el.id.substr(4))
          let id = el.id;
          let arr= id.split("_");
          if(arr.length>2){
            let category = arr[2];
            categoryOrders[category] = i;
          }


          });
          //  alert(JSON.stringify(chlCategoryOrders));
          }else if(category=='filteredLetters'){
          $("[id^='docTypeOrder_filteredLetters_']").each( (i, el)=> {

          let category = el.id.substr(29);
          categoryOrders[category] = i;

          });


          }else if(category=='scannedDocsCatList'){
          $("[id^='docTypeOrder_scannedDocsCatList_']").each( (i, el)=> {

          let category = el.id.substr(32);
          categoryOrders[category] = i;

          });


          }else if(category=='processedChequeDocs'){
          $("[id^='docTypeOrder_processedChequeDocs_']").each( (i, el)=> {

                let category = el.id.substr(33);
              categoryOrders[category] = i;

          });


          }else if(category=='companyDocs'){
          $("[id^='docTypeOrder_companyDocs_']").each( (i, el)=> {

                let category = el.id.substr(25);
              categoryOrders[category] = i;

          });


          }else if(category=='USCISDocs'){
          $("[id^='docTypeOrder_USCISDocs_']").each( (i, el)=> {

                let category = el.id.substr(23);
              categoryOrders[category] = i;

          });


          }
          // beneficiaryDocumentsList  suposeDocumentsList childrenDocuments filteredLetters scannedDocsCatList processedChequeDocs companyDocs USCISDocs
          //processedChequeDocs
          //docTypeOrder_scannedDocsCatList_
          //filteredLetters
          _.forEach(alDocs ,(tempList)=>{
          let documentCategory = tempList['category'];

          let trashedItems = _.filter(tempList['documents'] ,{isTrashDocument:false});
          // alert(JSON.stringify(docsList))
          if(trashedItems && trashedItems.length>0){
          let item =trashedItems[0];
          if(item && _.has(item,'docTypeOrder')){
          tempList['docTypeOrder'] = item['docTypeOrder'];
          }else{
          tempList['docTypeOrder'] =100000;
          }
          if(_.has(categoryOrders ,documentCategory)){
          tempList['docTypeOrder'] =categoryOrders[documentCategory];
          }

          let tempDocuments =[];
          _.forEach(trashedItems ,(docItem)=>{

              if(category=='benficiary'){
                $("[id^='order_ben_"+documentCategory+"']").each( (i, el)=> {
                  
                  if(el.id){
                    let id =el.id;
                    //_docPath_
                    let docPathArr = id.split("_docPath_");
                    if(docPathArr.length>1){
                      let path =docPathArr[1];
                      if(path==docItem['path']){
                        order =i;
                      }
                      
                    }
                  }
                  ;

                })
              }else if(category=='spouse'){
                $("[id^='order_sup_"+documentCategory+"']").each( (i, el)=> {
                  
                  if(el.id){
                    let id =el.id;
                    //_docPath_
                    let docPathArr = id.split("_docPath_");
                    if(docPathArr.length>1){
                      let path =docPathArr[1];
                      if(path==docItem['path']){
                        order =i;
                      }
                      
                    }
                  }
                  

                })
              } else if(category=='children'){ 
                  $("[id^='order_chi_"+documentCategory+"_"+childrenId+"']").each( (i, el)=> {
                    if(el.id){
                    let id =el.id;
                    //_docPath_
                    let docPathArr = id.split("_docPath_");
                    if(docPathArr.length>1){
                      let path =docPathArr[1];
                      if(path==docItem['path']){
                        order =i;
                      }
                      
                    }
                  }
                    
                    
                    });

              }else {
                $("[id^='order_"+documentCategory+"']").each( (i, el)=> {
                  
                  if(el.id){
                    let id =el.id;
                    //_docPath_
                    let docPathArr = id.split("_docPath_");
                    if(docPathArr.length>1){
                      let path =docPathArr[1];
                      if(path==docItem['path']){
                        order =i;
                      }
                      
                    }
                  }
                  ;

                })
              }
              docItem['order'] = order;
            tempDocuments.push(docItem);
            })

          tempDocuments =_.orderBy(tempDocuments, ['order'],  ['asc']);
          tempList['documents'] =tempDocuments;
          allDocuments.push(tempList);
          allDocuments =_.orderBy(allDocuments, ['docTypeOrder'],  ['asc']);
          }



          });
          _.forEach(allDocuments ,(doc ,index)=> {

          if(this.checkProperty(doc ,'documents','length') >0){
          // if(this.checkProperty(doc[1] ,'length') >0){
          //alert(JSON.stringify(doc))

          doc['documents'].forEach(i=> {
            if(i.path!=null && i.path !='' && !this.checkProperty(i ,'isTrashDocument')   ){ 
              if(docs.indexOf(i.path)<=-1){
                docs.push(i.path);
              }
              
            }else if(i.url!=null && i.url !='' && !this.checkProperty(i ,'isTrashDocument')  ){ 
              if(docs.indexOf(i.path)<=-1){
                docs.push(i.path);
              }
            }
          })
          //}
          }
          })
      }
    
    $("[id^='mainCategory_']").each( (i, el)=> {
      // beneficiaryDocumentsList  suposeDocumentsList childrenDocuments filteredLetters scannedDocsCatList processedChequeDocs companyDocs USCISDocs
                            

    let mainCategory = el.id.substr(13);
    
    if(mainCategory=="beneficiaryDocumentsList"){
      combailDocuments(this.beneficiaryDocumentsList ,'beneficiary' );
    }else if(mainCategory=="suposeDocumentsList"){
      combailDocuments(this.suposeDocumentsList ,'spouse' );
    }else if(mainCategory=="childrenDocuments"){
      if(this.checkProperty(this.childrenDocuments ,'length')>0){
      _.forEach(this.childrenDocuments ,(child)=>{
        if(this.checkProperty(child ,'documents')){
        combailDocuments(child['documents'] ,'children' ,child['_id']);
        }

      });
    }

    }else if(mainCategory=="filteredLetters"){
      combailDocuments(this.filteredLetters ,'filteredLetters' );
   }else if(mainCategory=="scannedDocsCatList"){
     combailDocuments(this.scannedDocsCatList ,'scannedDocsCatList' );

    }else if(mainCategory=="processedChequeDocs"){
      combailDocuments(this.processedChequeDocs ,'processedChequeDocs' );

    }else if(mainCategory=="companyDocs"){
        combailDocuments(this.companyDocs ,'companyDocs' );
    }else if(mainCategory=="USCISDocs"){
      combailDocuments(this.USCISDocs ,'USCISDocs' );

    }


  });

  


    let postdata = {
    petitionId: this.petition._id,
    documents: docs,
    };


    if(postdata['documents'].length>0){
    this.filesDownloading =true;
    let actionPath ="downloaddocsbyorder";
    if(this.checkProperty(this.petition, 'type')==3  && this.checkProperty(this.petition, 'subType')==15){
    actionPath ="downloaddocsbyorderPerm";
    }  

    this.$store
    .dispatch(actionPath, postdata)
    .then((response) => {
    this.savedDocumentsAction(true);
    this.filesDownloading =false;

    self.downloadDocumentPop = true;
    // alert( _APIURL+"/common/viewfile?path="+response.data.result.path);
    window.open(
    _APIURL+"/common/viewfile?path=" +
    response.data.result.path,
    "_blank"
    );
    }).catch((error)=>{
    this.filesDownloading =false;
    this.showToster({ message:error , isError: true})

    });

    } 
    },


    getFormsAndLetters(callFromMenu =false,code='') {
         
            this.formsAndLettersList = [];
            this.allFormsAndLettersList = [];
            let finalList = [];

            let postData = {
            petitionId: this.petition._id,
            matcher: { typeIds: ["Form" ,'Letter'] },
            page: 1,
            perpage: 100000,
            };
            this.updateLoading(true);
            this.$store
            .dispatch("getList", {
                data: postData,
                path: "/filled-forms-and-letters/list",
            })
            .then((response) => {
                this.allFormsAndLettersList = response.list;
                let lst = [];
                    _.forEach(response.list, (mainItem) => {
                        mainItem = Object.assign(mainItem, {
                        reverse_document_versions: [],
                        mainParentId: "",
                        showMe: true,
                        selectedForDownload: false,
                        "viewmode":true,
                        });
                        if (mainItem.parentId) {
                        mainItem["mainParentId"] = mainItem["parentId"];
                        } else {
                        mainItem["mainParentId"] = mainItem["_id"];
                        }
                        mainItem = Object.assign(mainItem ,{"isTrashDocument":false});
                        //

                        lst.push(mainItem);
                    });
                    let subList = [];

                    //reverse_document_versions
                    _.forEach(lst, (mainItem) => {
                         mainItem = Object.assign(mainItem ,{"isTrashDocument":false});
                        if (this.checkProperty(mainItem, "depType") != "child") {
                        _.forEach(lst, (subItem) => {
                            if (
                            mainItem.parentId &&
                            (mainItem.parentId == subItem["parentId"] ||
                                mainItem.parentId == subItem["_id"]) &&
                            mainItem["_id"] != subItem["_id"]
                            ) {
                            subItem["showMe"] = false;
                            if (subList.indexOf(subItem["_id"]) <= -1) {
                                mainItem["reverse_document_versions"].push(subItem);
                                this.previousExisted = true;
                                subList.push(subItem["_id"]);
                            }
                            }
                        });

                        if (mainItem.showMe) {
                            finalList.push(_.cloneDeep(mainItem));
                        }
                        } else {
                        _.forEach(lst, (subItem) => {
                            if (
                            this.checkProperty(mainItem, "depType") ==
                                this.checkProperty(subItem, "depType") &&
                            this.checkProperty(mainItem, "depLabel") ==
                                this.checkProperty(subItem, "depLabel") &&
                            mainItem.parentId &&
                            (mainItem.parentId == subItem["parentId"] ||
                                mainItem.parentId == subItem["_id"]) &&
                            mainItem["_id"] != subItem["_id"]
                            ) {
                            subItem["showMe"] = false;
                            if (subList.indexOf(subItem["_id"]) <= -1) {
                                mainItem["reverse_document_versions"].push(subItem);
                                this.previousExisted = true;
                                subList.push(subItem["_id"]);
                            }

                            // mainItem['showMe'] =true;
                            }
                        });
                            if (mainItem.showMe) {
                                finalList.push(_.cloneDeep(mainItem));
                            }
                        }
                    });
                    this.formsAndLettersList = _.cloneDeep(finalList); // JSON.parse(JSON.stringify(finalList));
                    // this.formsAndLetters =this.formsAndLettersList;  
                    this.processFormsAndLetters();
                })
                .catch((err) => {

                    this.formsAndLettersList = [];
                });
        },
    processFormsAndLetters(){
      this.filteredLetters =[];
    //this.savedDocumentsList
        if(this.formsAndLettersList && this.checkProperty(this.formsAndLettersList,'length')>0){
            let allItems =[];
            let letters = [];
            
              _.forEach(this.formsAndLettersList,(item)=>{
              item = Object.assign(item ,{"isTrashDocument":false});
              if(this.isDocumentsAreSaved && this.savedDocumentsList && this.savedDocumentsList.length>0){
                let isSaved = _.find(this.savedDocumentsList ,{"path":item['path']});
                if(isSaved){
                  item = Object.assign(item ,{"isTrashDocument":false});
                }else{
                  item = Object.assign(item ,{"isTrashDocument":true});
                }

              }
               
              allItems.push(item);
                
            })
           
          
            
           
            if(allItems && allItems.length>0){
             
              let groupedItems = _.groupBy(allItems ,'depLabel');
             
              if(groupedItems && Object.keys(groupedItems).length>0){
                _.forEach(groupedItems,(grouPitems ,key)=>{
                 
                  if(grouPitems.length>0){
                  if(key =='beneficiary'){
                    let tempitem=  { "category": "beneficiary_forms_and_letters", "documents":[] ,'docTypeOrder':1000000};
                    tempitem['documents'] = grouPitems;
                    this.filteredLetters.push(tempitem);
                  }else {

                    //depType :child ,docUserType:Dependent
                    let spouseDocs = _.filter( grouPitems ,{ 'depType':'spouse' ,'docUserType':'Dependent'});
                    if(spouseDocs && spouseDocs.length>0){

                      let tempitem=  { "category": "spouse_forms_and_letters", "documents":[] ,'docTypeOrder':1000000};
                      tempitem['documents'] = grouPitems;
                      this.filteredLetters.push(tempitem);


                    }else{
                      let childDocs = _.filter( grouPitems ,{ 'depType':'child' ,'docUserType':'Dependent'});
                      if(childDocs &&childDocs.length>0){
                        let tempitem=  { "category": "", "documents":[] ,'docTypeOrder':1000000};
                         tempitem['documents'] = grouPitems;
                         tempitem['category'] = childDocs[0]['depLabel']
                         this.filteredLetters.push(tempitem);
                      }


                    }


                    

                  }
                }


                });

              }
            }
            

        }
    },
    getScannedDocuments(){
           
            this.scannedDocsList =[];
            let finalList =[];
            let postData ={petitionId:'','page':1 ,'perpage':100000};
            postData['petitionId']= this.petition._id; 
            this.$store.dispatch("getList" ,{data:postData,path:"/petition/scanned-copies-list"}).then(response => {
                this.updateLoading(false);
                let lst = [];
                _.forEach(response.list ,(mainItem)=>{
                 
                    mainItem = Object.assign(mainItem,{"isTrashDocument":false ,"reverse_document_versions":[] ,"mainParentId":'',showMe:true ,selectedForDownload:false});
                    if(mainItem.parentId){
                        mainItem['mainParentId'] = mainItem['parentId']
                    }else{
                            mainItem['mainParentId'] = mainItem['_id']
                    }
                        lst.push(mainItem);
                });
                let subList=[];
            //reverse_document_versions
                _.forEach(lst ,(mainItem)=>{
                    _.forEach(lst ,(subItem)=>{
                        if( mainItem.parentId && (mainItem.parentId == subItem['parentId'] ||  mainItem.parentId == subItem['_id']   ) &&  mainItem['_id'] != subItem['_id']){                            
                            subItem['showMe'] =false;
                            if(subList.indexOf(subItem['_id']<=-1)){
                                mainItem['reverse_document_versions'].push(subItem);
                                subList.push(subItem['_id']);
                            }
                        }
                    })            
                    if(mainItem.showMe){
                        finalList.push(mainItem);
                    }
                })
              
                this.scannedDocsList =  finalList;
                this.processScannedDocs();
               
                }).catch((err)=>{
                    this.scannedDocsList  =[];
                    //this.updateLoading(false);
                })
        },
    processScannedDocs(){
      this.scannedDocsCatList =[];
      let petitioner =[]
      let beneficiaryDocs =[];
      let internalDocs =[];
        if(this.scannedDocsList && this.checkProperty(this.scannedDocsList,'length')>0){
          _.forEach(this.scannedDocsList,(item)=>{
            item = Object.assign(item ,{"isTrashDocument":false});
          if(this.isDocumentsAreSaved && this.savedDocumentsList && this.savedDocumentsList.length>0){
            let isSaved = _.find(this.savedDocumentsList ,{"path":item['path']});
            if(isSaved){
              item = Object.assign(item ,{"isTrashDocument":false});
            }else{
              item = Object.assign(item ,{"isTrashDocument":true});
            }

          }
              if(item['docUserType'] == 'Petitioner'){
              petitioner.push(item);

            }else if(item['docUserType'] == 'Beneficiary'){
              beneficiaryDocs.push(item);
            }else if(item['docUserType'] == 'Internal'){
              internalDocs.push(item);

            }
                
            })

            if(petitioner.length>0){
              let tempitem=  { "category": "Petitioner", "documents":[],'docTypeOrder':1000000}
              tempitem['documents'] = petitioner;
              this.scannedDocsCatList.push(tempitem);

            }
            if(beneficiaryDocs.length>0){
              let tempitem=  { "category": "Beneficiary", "documents":[],'docTypeOrder':1000000}
              tempitem['documents'] = beneficiaryDocs;
              this.scannedDocsCatList.push(tempitem);

            }
            if(internalDocs.length>0){
              let tempitem=  { "category": "Law Firm", "documents":[] ,'docTypeOrder':1000000}
              tempitem['documents'] = internalDocs;
              this.scannedDocsCatList.push(tempitem);

            }

        
            

        }
    },
    processChequesDocs(){
           this.processedChequeDocs =[]
            if(this.checkProperty(this.petition,'filingFeeDocs') && this.checkProperty(this.petition ,'filingFeeDocs', 'cheques') && this.checkProperty(this.petition['filingFeeDocs'],'cheques','length')>0){
                let documents = [] ;
                _.forEach(this.petition['filingFeeDocs']['cheques'] ,(item)=>{

                item = Object.assign(item ,{"isTrashDocument":false});
                if(this.isDocumentsAreSaved && this.savedDocumentsList && this.savedDocumentsList.length>0){
                  let isSaved = _.find(this.savedDocumentsList ,{"path":item['path']});
                if(isSaved){
                   item = Object.assign(item ,{"isTrashDocument":false});
                }else{
                    item = Object.assign(item ,{"isTrashDocument":true});
                }

                }
                documents.push(item);

                })

                this.processedChequeDocs =  [  { "category": "cheques", "documents": documents,'docTypeOrder':1000000 }];
                this.processedChequeDocs = _.cloneDeep(this.processedChequeDocs);
            }
        }



    },
    props: {
    loadedFromPreview:{type: Boolean , default: false},
    
    petitionDetails: {
      type: Object,
      default: null,
    },
    tasks: {
      required: true,
      type: Array,
      default:[] //[ { "name": "task 1", "tasks": [ { "name": "task 5", "tasks": [] }, { "name": "task 2", "tasks": [] } ] }, { "name": "task 3", "tasks": [ { "name": "task 4", "tasks": [] } ] } ]
    }

},
mounted(){
  this.petition = _.cloneDeep(this.petitionDetails);
  setTimeout(()=>{
    this.petition = _.cloneDeep(this.petitionDetails);
    if(this.petition){

      this.getFormsAndLetters();
      this.getScannedDocuments();
      this.getCompanyDocs();
      this.filesDownloading =false;
      setTimeout(()=>{
      this.getSavedDocuments();
      },10);

    }

  },10);
  
 

},
components:{
draggable,
FileUpload,
VuePerfectScrollbar,
NoDataFound,
XIcon
}
,
watch:{
downloadDocList:(val)=>{
if(!val){
this.$emit('closeMe');
}
}
}    
}
</script>
