<template>
   <div class="lca-view-details">
          <div class="lca-view-details-top bg-white">
            <div class="lca-top-content mr-6" v-if="lcaDetails.number">
              <p>
                DOL Reference Number
                <span>{{lcaDetails.number}}</span>
              </p>
            </div>

            <div class="form-container flex items-center">
              <div
                class="vx-col md:w-1/2 w-full p-0"
                v-if="lcaDetails.documents.certifiedLCA && lcaDetails.documents.certifiedLCA.length > 0"
              >
                <span class="flex items-center">
                  <img class="mr-2" src="@/assets/images/main/icon-pdf.svg" />
                  <a @click="fetchSignedUrl(lcaDetails.documents.certifiedLCA[0].url)">Certified LCA Document</a>
                </span>
              </div>
              <vs-col
                class="vx-col md:w-1/2 w-full p-0"
                v-if="lcaDetails.documents.certifiedLCA && lcaDetails.documents.certifiedLCA.length === 0 && lcaDetails.number"
              >
                <label class="custom-label">Upload Certified LCA</label>
                <file-upload
                  v-model="lcaDetails.documents.certifiedLCA"
                  class="file-upload-input"
                  name="certifiedLca"
                  :multiple="false"
                  :accept="allDocEntity"
                  @input="uploadCertificate"
                >
                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" /> Upload
                </file-upload>
              </vs-col>
            </div>
          </div>

          <div class="lca-view-details-top bg-white pl-10" v-if="!lcaDetails.number">
            <div class="form-container w-1/2">
              <div class="vx-col w-full">
                <!-- <vs-input class="w-full" label="Enter FedEx tracking number" /> -->

                <vx-input-group>
                  <vs-input
                    name="lcaNumber"
                    v-model="number"
                    data-vv-as="DOL Reference Number"
                    v-validate="'required'"
                    label="DOL Reference Number"
                    placeholder="DOL Reference Number"
                  />
                  <span
                    class="text-danger text-sm"
                    v-show="errors.has('lcaNumber')"
                  >{{ errors.first("lcaNumber") }}</span>
                  <template slot="append">
                    <a class="btn btn-brown" @click="submitSOCCode">Submit</a>
                  </template>
                </vx-input-group>
              </div>
            </div>
          </div>

          <div class="lca-view-details-bottom">

                     <LCADetails
                    v-if="lcaDetails!=null"
                    v-bind:lcaDetails="lcaDetails"
                  />
          </div>
        </div>
</template>

<!--for active tab-->
<script>
import FileUpload from "vue-upload-component/src";
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import LCADetails from "./LCADetails";

export default {
  components: {
    VuePerfectScrollbar,
    FileUpload,
    LCADetails
  },
  name: "app",
  methods: {
    fetchSignedUrl(value) {
      value.document = value.document.replace(this.$globalgonfig._S3URL,"")
      let postdata = {
        keyName: value.document
      };
      
      this.$store
      .dispatch("getSignedUrl", postdata)
      .then(response => {
        window.open(response.data.result.data, '_blank');
      });
    },
    scrollHandle(evt) {},
    generateUrlLink(item) {
      let postdata = {
        keyName: item.url
          .toString()
          .replace(this.$globalgonfig._S3URL,"")
      };
      this.$store
      .dispatch("getSignedUrl", postdata)
      .then((response, index) => {
        this.hrefEachFile = response.data.result.data;
      });
    },
    remove(item, type) {
      type.splice(type.indexOf(item), 1);
      let updateFormsData = {
        documents: this.lcaDetails.documents,
        updateType: "documents",
        action: "UPLOAD_DOCUMENTS",
        lcaId: this.lcaDetails._id
      };
      this.$store
        .dispatch("updateLcaDetails", updateFormsData)
        .then(response => {});
      return false;
    },
    updatestatus(index, value) {
      let postdata = {
        lcaId: this.lcaDetails._id,
        statusId: index + 1,
        statusName: value
      };
      this.$store.dispatch("updateLcaStatus", postdata).then(response => {
        if (response.status === 200) {
          this.$router.go(this.$route.name);
        }
        // this.$router.go(this.$route.name);
      });
    },
    fetchDetails() {
      this.formsAndLetterSignedUrls = [];
      this.$store
        .dispatch("fetchLcaDetails", this.$route.params.itemId)
        .then(response => {
          this.lcaDetails = response.data.result;
        });
    },
    submitSOCCode() {
      if (this.number === null) {
        return false;
      } else {
        let updatedValue = {
          lcaId: this.lcaDetails._id,
          number: this.number,
          action: "UPDATE_BASIC_INFO",
          updateType: "lca-number"
        };
        this.$store
          .dispatch("updateLcaDetails", updatedValue)
          .then(response => {
            this.$router.go(this.$route.name);
          });
      }
    },
    fetchStatusMasterData() {
      this.$store
        .dispatch("getmasterdata", "lca_inventory_status")
        .then(response => {
          this.allLcaStatuses = response;
        });
    },
    uploadForms() {
      let formData = new FormData();
      this.lcaDetails.documents.formETA9035And9035E = this.lcaDetails.documents.formETA9035And9035E.map(item =>item = {
        name: item.name,
        file: item.file,
        url: "",
        mimetype: item.type
      });
      this.lcaDetails.documents.formETA9035And9035E.forEach(files => {
        formData.append("files", files.file);
        formData.append("secureType", "private");
        this.$store.dispatch("uploadS3File", formData).then(response => {
          response.data.result.forEach(urlGenerated=> {
            files.url = urlGenerated;
            delete files.file
          })
          let updateFormsData = {
            documents: this.lcaDetails.documents,
            updateType: "documents",
            action: "UPLOAD_DOCUMENTS",
            lcaId: this.lcaDetails._id
          };
          this.$store
            .dispatch("updateLcaDetails", updateFormsData)
            .then(response => {
              this.$router.go(this.$route.name);
            });
          
        });
      });
    },
    uploadCertificate() {
      let formData = new FormData();
      this.lcaDetails.documents.certifiedLCA = this.lcaDetails.documents.certifiedLCA.map(
        item =>
          (item = {
            name: item.name,
            file: item.file,
            url: "",
            mimetype: item.type
          })
      );
      this.lcaDetails.documents.certifiedLCA.forEach(files => {
        formData.append("files", files.file);
        formData.append("secureType", "private");
        this.$store.dispatch("uploadS3File", formData).then(response => {
          files.url = response.data.result;
          let updateFormsData = {
            documents: this.lcaDetails.documents,
            updateType: "documents",
            action: "UPLOAD_DOCUMENTS",
            lcaId: this.lcaDetails._id
          };
          this.$store
            .dispatch("updateLcaDetails", updateFormsData)
            .then(response => {
              this.$router.go(this.$route.name);
            });
        });
      });
    },
    fetchActivityList() {
      let postdata = {
        lcaId: this.$route.params.itemId,
        page: 1,
        perpage: 10
      };
      this.$store.dispatch("fetchLCAactivities", postdata).then(response => {
        this.activityList = response.data.result.list;
      });
    }
  },
  data: () => ({
    active: false,
    active_tab: 4,
    tabs: [
      { index: 0 },
      { index: 1 },
      { index: 2 },
      { index: 3 },
      { index: 4 }
    ],
    lcaDetails: [],
    number: "",
    address: "",
    address2: "",
    certifiedLCA: "",
    lcaStatus: "",
    allLcaStatuses: [],
    formFiles: [],
    certificateFiles: [],
    documentsUploaded: [],
    certificateSignedUrls: '',
    formsAndLetterSignedUrls: [],
    selected_status: "",
    activityList: [],
    hrefEachFile: ''
  }),
  mounted() {
    this.fetchDetails();
    this.fetchStatusMasterData();
    this.fetchActivityList();
  }
};
</script>