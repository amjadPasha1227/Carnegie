<template>
  <div class="vx-col w-full mb-base wizard-container">
    <vx-card>
      <vs-popup class="holamundo main-popup" title="Comments" :active.sync="Comments">
        <div class="form-container mt-6">
          <div class="vx-row">

            <div class="vx-col w-full">
              <!-- <vs-textarea v-model="textarea" label="Comments…" class="w-full" /> -->
              <ckeditor v-model="textarea" label="Comments…" class="w-full"    :editor="editor" :config="editorConfig"></ckeditor>

            </div>
          </div>
        </div>
        <div class="popup-footer">
          <vs-button color="dark" class="cancel" type="filled">Cancel</vs-button>
          <vs-button color="success" class="save" type="filled">Save</vs-button>
        </div>
      </vs-popup>
    </vx-card>
  </div>

</template>
<script>

import Vue from 'vue';
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
  import { CheckCircleIcon } from 'vue-feather-icons'
  export default {
    data() {
      return {
        editor: ClassicEditor,
        editorConfig: {
          toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
        },

        date: null,
        Comments: true,
      }
    },
    components: {
      CheckCircleIcon
    }
  }
</script>