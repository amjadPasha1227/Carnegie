<template>
  <div class="tabs-layout-header-items">
    <div class="items-left">

      <ul class="peoples_list">
        <li v-if="petition.paralegalDetails!=null">
          <figure>
            <img class="user-image" src="@/assets/images/main/avatar2.svg" />
          </figure>
          <div class="peoples-dropdown">
            <h6>
              {{petition.paralegalDetails.name}}
              <span>Paralegal</span>
            </h6>
            <p>
              <a href="#">{{petition.paralegalDetails.email}}</a>
              <span>{{petition.paralegalDetails.phone}}</span>
            </p>
          </div>
        </li>

        <li v-if="petition.supervisorDetails!=null">
          <figure>
            <img class="user-image" src="@/assets/images/main/avatar2.svg" />
          </figure>
          <div class="peoples-dropdown">
            <h6>
              {{petition.supervisorDetails.name}}
              <span>Supervisor</span>
            </h6>
            <p>
              <a href="#">{{petition.supervisorDetails.email}}</a>
              <span>{{petition.supervisorDetails.phone}}</span>
            </p>
          </div>
        </li>

        <li v-if="petition.attorneyDetails!=null">
          <figure>
            <img class="user-image" src="@/assets/images/main/avatar2.svg" />
          </figure>
          <div class="peoples-dropdown">
            <h6>
              {{petition.attorneyDetails.name}}
              <span>Attorney</span>
            </h6>
            <p>
              <a href="#">{{petition.attorneyDetails.email}}</a>
              <span>{{petition.attorneyDetails.phone}}</span>
            </p>
          </div>
        </li>
      </ul>
    </div>

    <div class="items-right">
      <ul>
        <li v-if="checkActionconditions" >
          <vs-dropdown vs-custom-content vs-trigger-click>
            <vs-button
              color="primary"
              class="actions-btn"
              type="border"
              icon-pack="feather"
              icon="icon-chevron-down"
              icon-after
            >Actions</vs-button>
            <vs-dropdown-menu ref="filter_menu" class="actions-content petition-action-content">
              <ul>
                 <li  v-if="currentRole && [6].includes(currentRole) && petition.questionnaireFilled && petition.statusId == 1

              &&  petition.currentActivity!='QUESTIONNIRE_APPROVED'
            ">
                  <a href="javascript:;"  @click="approveOrreject('approved')">Approve Questionnaire</a>
                </li>
                 <li  v-if="currentRole && [6].includes(currentRole) && petition.questionnaireFilled && petition.statusId == 1

              &&  petition.currentActivity!='QUESTIONNIRE_APPROVED'
            ">
                  <a href="javascript:;"  @click="approveOrreject('rejected')">Reject Questionnaire</a>
                </li>

                <li v-if="currentRole && currentRole==2 && petition.paralegalDetails==null">
                  <a href="javascript:;" @click="AssignParalegal=true">Assign Paralegal</a>
                </li>
                <li v-if="currentRole && currentRole==2 && petition.supervisorDetails==null">
                  <a href="javascript:;" @click="SubmitParalegal=true">Submit to Supervisor</a>
                </li>
                <li
                  v-if="currentRole && currentRole==3 &&!petition.paralegalApproved"
                >
                  <a href="javascript:;" @click="approveparalegal()">Approve Paralegal</a>
                </li>
                <li
                  v-if="currentRole && currentRole==3 && !petition.paralegalApproved"
                >
                  <a href="javascript:;" @click="replaceparalegal()">Replace Paralegal</a>
                </li>
                 <li v-if="currentRole && currentRole==4 && petition.offshoreUserDetails == null" >
                  <a href="javascript:;" @click="assigntorole(9)">Submit to Offshore </a>
                </li>
                  <li v-if="currentRole && currentRole==4 && petition.attorneyDetails == null" >
                  <a href="javascript:;" @click="assigntorole(5)">Submit to Attorney </a>
                </li>
                 <li v-if="currentRole && currentRole==5  && petition.attorneyDetails != null && petition.statusId!=7" >
                  <a href="javascript:;" @click="caseapprovedpop('CASE_APPROVED')">Case Approved </a>
                </li>
                 <li v-if="currentRole &&  petition.statusId == 7  && (currentRole == 5  || currentRole==3 )" >
                  <a href="javascript:;" @click="caseapprovedpop('READY_FOR_FILING')">Ready For Filing </a>
                </li>
                 <li v-if="currentRole && currentRole==3  && petition.attorneyDetails != null && !petition.petitionerSignRequested" >
                  <a href="javascript:;" @click="requestpetitionersign()">Enter Filing fees </a>
                </li>
              </ul>
            </vs-dropdown-menu>
          </vs-dropdown>
        </li>
        <li>
          <div class="dropdown-button-container">
            <vs-button>
              <span
                class="status_approved"
                v-if="petition.currentActivity =='QUESTIONNIRE_REJECTED'"
              >Questionnire Rejected</span>
              <span v-else class="status_approved">{{petition.statusDetails.name}}</span>
            </vs-button>
          </div>
        </li>

        <!--    <li><button class="btn btn-brown" @click="AssignParalegal=true" >Assign Paralegal</button></li>
                  <li><button class="btn btn-brown" @click="SubmitParalegal=true">Submit to Supervisor</button></li>
        -->
        <!-- *********************** using html  ********************

        -->
        <li>
          <!-- history side bar-->
          <template lang="html">
            <div id="parentx">
              <img
                @click.stop="active=true"
                class="cursor-pointer"
                src="@/assets/images/main/settings.svg"
              />
              <vs-sidebar
                position-right
                parent="body"
                default-index="1"
                class="sidebarx history-sidebar"
                spacer
                v-model="active"
              >
                <div class="header-sidebar" slot="header">
                  <h4>Petition History</h4>
                  <figure>
                    <img
                      @click="active=false;gethistory()"
                      src="@/assets/images/main/icon-remove.svg"
                    />
                  </figure>
                </div>
                <VuePerfectScrollbar class="scroll-area">
                  <div class="timeline-sidebar">
                    <ul>
                      <li v-for="(history, index) in petitionhistory" :key="index">
                        <div class="timeline-icon">
                          <i class="icon IP-tick-sign"></i>
                        </div>
                        <div class="timeline-info">
                          <button class="btn active-green ml-0">{{history.createdByRoleName}}</button>
                          <ul>
                            <li>
                              <h3>{{history.title}}</h3>
                              <span>{{history.description}}</span>

                              <span>{{history.createdOn | formatDateTime}}</span>
                            </li>
                          </ul>
                        </div>
                      </li>
                    </ul>
                  </div>
                </VuePerfectScrollbar>
              </vs-sidebar>
            </div>
          </template>
        </li>
      </ul>


 <vs-popup
        class="holamundo main-popup"
        :title="caseapprovedpopuptitle"
        :active.sync="caseapprovedpopup"
      >
        <form data-vv-scope="caseapprovedpopupform">
          <div class="form-container">


 <div class="vx-row ">
             

                 <div class="vx-col w-full">
                <vs-textarea
                 v-model="caseapprovednotes"
                  data-vv-as="Comments"
                  v-validate="'required'"
                   name="caseapprovednotes" 
                  label="Comments"
                  class="w-full"
                />

             
              </div>
                

              </div>
        
          </div>

      
           
          <div class="popup-footer">
            <vs-button
              color="success"
              @click="submitcaseapproval"
              class="save"
              type="filled"
            >Submit</vs-button>
          </div>
        </form>
      </vs-popup>



        <vs-popup
        class="holamundo main-popup"
        title="Filing Fees"
        :active.sync="filingFeesPopup"
      >
        <form data-vv-scope="filingFeesform">
          <div class="form-container csttxt" style="position:relative" >


 <div class="vx-row " style="position:relative"  v-for="(filingFee, index) in filingFeeData" :key="index">
              <div class="vx-col w-full" >
                                                            <vx-input-group>

                <vs-input 
                 v-model="filingFee.amount"
                  data-vv-as="Amount"
                 v-validate="'required'"
                :name="'filingamount'+index" 
                 label="Amount($)"
                  />
                                                            </vx-input-group>

            </div>

                 <div class="vx-col w-full">
                <vs-textarea
                 v-model="filingFee.description"
                  data-vv-as="Comments"
                  v-validate="'required'"
                   :name="'filingdescription'+index" 
                  label="Description"
                  class="w-full"
                />

             
              </div>
                  <div class="delete" style="position:absolute;right:-10px;bottom:10px" v-if="filingFeeData.length > 1">
                        <a @click="removefilingfee(index)">
                          <img src="@/assets/images/main/delete-row-img.svg">
                        </a>
                      </div>

              </div>
        
          </div>

            <vs-col class="m-auto float-none" vs-type="flex" >
              <a @click="addfilingfee"  style="margin-left:15px;" class="add-more" type="filled">
                <span>+</span> More
              </a>
            </vs-col>
           
          <div class="popup-footer">
            <vs-button
              color="success"
              @click="submifFilingFees"
              class="save"
              type="filled"
            >Submit</vs-button>
          </div>
        </form>
      </vs-popup>


      <vs-popup
        class="holamundo main-popup"
        :title="assigntoRoletitle"
        :active.sync="assigntoRolePopup"
      >
        <form data-vv-scope="assignroleform">
          <div class="form-container">
            <div class="vx-row">
              <div class="vx-col w-full" >
                <div class="con-select w-full select-large">
                  <multiselect
                    name="assigntorole"
                    v-validate="'required'"
                    v-model="assigntoroleModel"
                    :show-labels="false"
                    track-by="id"
                    label="name"
                    :data-vv-as="assigntoroletxt"
                    :placeholder="chooseassigntorole"
                    :options="selectedroleslist"
                    :searchable="true"
                    :allow-empty="false"
                  ></multiselect>
                </div>

                <span
                  class="text-danger text-sm"
                  v-show="errors.has('assignroleform.assigntorole')"
                >{{ errors.first("assignroleform.assigntorole") }}</span>
              </div>

              <div class="vx-col w-full">
                <vs-textarea
                  data-vv-as="Comments"
                  v-validate="'required'"
                  v-model="assignedrolecomments"
                  name="assignedrolecomments"
                  label="Comments…"
                  class="w-full"
                />

                <span
                  class="text-danger text-sm"
                  v-show="errors.has('assignroleform.assignedrolecomments')"
                >{{ errors.first("assignroleform.assignedrolecomments") }}</span>
              </div>
            </div>
            <div class="text-danger text-sm formerrors" v-show="paralegalformerrors">
              <vs-alert
                color="warning"
                class="warning-alert reg-warning-alert no-border-radius"
                icon-pack="IntakePortal"
                icon="IP-information-button"
                active="true"
              >{{ paralegalformerrors }}</vs-alert>
            </div>
          </div>
          <div class="popup-footer">
            <vs-button
              color="success"
              @click="submitassignrole"
              class="save"
              type="filled"
            >Assign</vs-button>
          </div>
        </form>
      </vs-popup>







      <vs-popup
        class="holamundo main-popup"
        :title="replaceParalegaltitle"
        :active.sync="replaceParalegal"
      >
        <form data-vv-scope="approveparalegalfoform">
          <div class="form-container">
            <div class="vx-row">
              <div class="vx-col w-full" v-if="!approveParalegalform">
                <div class="con-select w-full select-large">
                  <multiselect
                    name="paralegal"
                    v-validate="'required'"
                    v-model="paralegalModel"
                    :show-labels="false"
                    track-by="id"
                    label="name"
                    data-vv-as="Paralegal"
                    placeholder="Choose Paralegal"
                    :options="paralegallist"
                    :searchable="true"
                    :allow-empty="false"
                  ></multiselect>
                </div>

                <span
                  class="text-danger text-sm"
                  v-show="errors.has('approveparalegalfoform.paralegal')"
                >{{ errors.first("approveparalegalfoform.paralegal") }}</span>
              </div>

              <div class="vx-col w-full">
                <vs-textarea
                  data-vv-as="Comments"
                  v-validate="'required'"
                  v-model="paralegalcomments"
                  name="paralegalcomments"
                  label="Comments…"
                  class="w-full"
                />

                <span
                  class="text-danger text-sm"
                  v-show="errors.has('approveparalegalfoform.paralegalcomments')"
                >{{ errors.first("approveparalegalfoform.paralegalcomments") }}</span>
              </div>
            </div>
            <div class="text-danger text-sm formerrors" v-show="paralegalformerrors">
              <vs-alert
                color="warning"
                class="warning-alert reg-warning-alert no-border-radius"
                icon-pack="IntakePortal"
                icon="IP-information-button"
                active="true"
              >{{ paralegalformerrors }}</vs-alert>
            </div>
          </div>
          <div class="popup-footer">
            <vs-button
              color="success"
              @click="submitapproveparalegal"
              class="save"
              type="filled"
            >Assign</vs-button>
          </div>
        </form>
      </vs-popup>

      <vs-popup
        class="holamundo main-popup"
        title="Submit to Supervisor"
        :active.sync="SubmitParalegal"
      >
        <form data-vv-scope="supervisorform">
          <div class="form-container">
            <div class="vx-row">
              <div class="vx-col w-full">
                <div class="con-select w-full select-large">
                  <label for class="vs-select--label">Supervisor</label>
                  <multiselect
                    name="supervisor"
                    v-validate="'required'"
                    v-model="supervisorMode"
                    :show-labels="false"
                    data-vv-as="Supervisor"
                    label="name"
                    placeholder="Select Supervisor"
                    :options="supervisorlist"
                    :searchable="true"
                    :allow-empty="false"
                  ></multiselect>
                </div>

                <span
                  class="text-danger text-sm"
                  v-show="errors.has('supervisorform.supervisor')"
                >{{ errors.first("supervisorform.supervisor") }}</span>
              </div>
              <div class="vx-col w-full">
                <vs-textarea
                  data-vv-as="Comments"
                  v-validate="'required'"
                  name="supervisorcomments"
                  v-model="supervisorcomments"
                  label="Comments…"
                  class="w-full"
                />

                <span
                  class="text-danger text-sm"
                  v-show="errors.has('supervisorform.supervisorcomments')"
                >{{ errors.first("supervisorform.supervisorcomments") }}</span>
              </div>
            </div>
          </div>
          <div class="popup-footer">
            <vs-button color="success" @click="assignsupervisorform" class="save" type="filled">Save</vs-button>
          </div>
        </form>
      </vs-popup>
      <vs-popup
        class="holamundo main-popup"
        title="Assign Paralegal"
        :active.sync="AssignParalegal"
      >
        <form data-vv-scope="paralegalfoform">
          <div class="form-container">
            <div class="vx-row">
              <div class="vx-col w-full">
                <div class="con-select w-full select-large">
                  <label for class="vs-select--label">Paralegal</label>
                  <multiselect
                    name="paralegal"
                    v-validate="'required'"
                    v-model="paralegalModel"
                    :show-labels="false"
                    track-by="id"
                    label="name"
                    data-vv-as="Paralegal"
                    placeholder="Select Paralegal"
                    :options="paralegallist"
                    :searchable="true"
                    :allow-empty="false"
                  ></multiselect>
                </div>

                <span
                  class="text-danger text-sm"
                  v-show="errors.has('paralegalfoform.paralegal')"
                >{{ errors.first("paralegalfoform.paralegal") }}</span>
              </div>
              <div class="vx-col w-full">
                <vs-textarea
                  data-vv-as="Comments"
                  v-validate="'required'"
                  v-model="paralegalcomments"
                  name="paralegalcomments"
                  label="Comments…"
                  class="w-full"
                />

                <span
                  class="text-danger text-sm"
                  v-show="errors.has('paralegalfoform.paralegalcomments')"
                >{{ errors.first("paralegalfoform.paralegalcomments") }}</span>
              </div>
            </div>
            <div class="text-danger text-sm formerrors" v-show="paralegalformerrors">
              <vs-alert
                color="warning"
                class="warning-alert reg-warning-alert no-border-radius"
                icon-pack="IntakePortal"
                icon="IP-information-button"
                active="true"
              >{{ paralegalformerrors }}</vs-alert>
            </div>
          </div>
          <div class="popup-footer">
            <vs-button
              color="success"
              @click="assignparalegalform"
              class="save"
              type="filled"
            >Assign</vs-button>
          </div>
        </form>
      </vs-popup>

      <vs-popup
        class="holamundo main-popup"
        v-bind:title="approveRejectTitle"
        :active.sync="approveRejectPop"
      >
        <form data-vv-scope="approverejectquestion">
          <div class="media-header" v-if="petition.beneficiaryInfo.name">
            <img src="@/assets/images/main/avatar2.svg" />
            <div class="media-content">
              <p>{{petition.beneficiaryInfo.name}}</p>
            </div>
          </div>
          <div class="form-container">
            <div v-if="approveaction" class="requestlcaform">
              <p v-if="!petition.lcaId">In Order to Submit Case, Please upload/request for LCA.</p>

              <!-- <p v-if="petition.lcaId" >LCAID ==  {{petition.lcaId }} </p> -->

              <div class="vx-row" v-if="petition.lcaId">
                <div class="vx-col w-full">
                  <vs-textarea
                    name="approveRejec_Instructions"
                    data-vv-as="Instructions"
                    class="w-full"
                    label="Comments"
                    v-model="approveRejecInstructions"
                  />
                  <span
                    class="text-danger text-sm"
                    v-show="errors.has('approverejectquestion.approveRejec_Instructions')"
                  >{{ errors.first("approverejectquestion.approveRejec_Instructions") }}</span>
                </div>
              </div>

              <vs-button
                color="success"
                v-if="petition.lcaId"
                @click="saveApproveOrreject"
                class="save"
                type="filled"
              >Send</vs-button>

              <router-link
                v-if="!petition.lcaId"
                :to="{ name: 'requestlca', params: { itemId: petition._id } }"
              >
                <button @click="approveRejectPop=false" class="btn btn-brown">Request LCA</button>
              </router-link>

              <router-link
                v-if="!petition.lcaId"
                :to="{ name: 'requestlca', params: { itemId: petition._id, upload:true } }"
              >
                <button @click="approveRejectPop=false" class="btn btn-brown">Upload LCA</button>
              </router-link>
            </div>

            <div class="vx-row" v-if="!approveaction">
              <div class="vx-col w-full">
                <vs-textarea
                  name="approveRejec_Instructions"
                  data-vv-as="Instructions"
                  class="w-full"
                  label="Comments"
                  v-model="approveRejecInstructions"
                />
                <span
                  class="text-danger text-sm"
                  v-show="errors.has('approverejectquestion.approveRejec_Instructions')"
                >{{ errors.first("approverejectquestion.approveRejec_Instructions") }}</span>
              </div>
            </div>
          </div>
          <div class="popup-footer" v-if="!approveaction">
            <vs-button
              color="dark"
              @click="approveRejectPop=false"
              class="cancel"
              type="filled"
            >Cancel</vs-button>
            <vs-button color="success" @click="saveApproveOrreject" class="save" type="filled">Send</vs-button>
          </div>
        </form>
      </vs-popup>
    </div>
  </div>
</template>
<script>
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import Vue from 'vue'

export default {
  components: {
    VuePerfectScrollbar
  },
  props: {
    petition: {
      type: Object,
      default: null
    },
    currentRole: {
      type: Number,
      default: null
    }
  },
  computed: {
checkActionconditions(){
if(this.currentRole && this.currentRole==7){
  return false;
}
if(this.currentRole && this.currentRole==9){
  return false;
}
if(this.currentRole && this.currentRole==6){
  if(this.petition.questionnaireFilled && this.petition.statusId == 1 &&  this.petition.currentActivity!='QUESTIONNIRE_APPROVED'){
   return false;
  }

}
if(this.currentRole && this.currentRole==4 && this.petition.attorneyDetails!=null && this.petition.offshoreUserDetails!=null){
   return false;

}
if(this.currentRole && this.currentRole==2 && this.petition.paralegalDetails!=null && this.petition.supervisorDetails!=null){
   return false;

}
if(this.currentRole && this.currentRole==2 && this.petition.paralegalApproved){
   return false;
}

return true;
}
  },
  methods: {



  },
  data: () => ({
    filingFeeData:[
        {
          amount:null,
          description:''
        }

    ],
    caseapprovedpopup:false,
    caseapprovedpopuptitle:"Case Approved",
    caseapprovednotes:'',
    filingFeesPopup:false,
    assigntoRoletitle:"",
    assigntoroletxt:"",
    chooseassigntorole:"",
    assignedRoleId:null,
    assigntoRolePopup:false,
    approvalstatus: false,
    approveaction: false,
    rolesubmitaction:"",
    replaceParalegaltitle: "Replace Paralegal",
    paralegalformerrors: "",
    supervisorcomments: "",
    assignedrolecomments:"",
    paralegalcomments: "",
    petitionhistory: [],
    SubmitParalegal: false,
    SuccessQuestionnaire: false,
    AssignParalegal: false,
    paralegalModel: [],
    assigntoroleModel:[],
    supervisorMode: [],
    paralegallist: [],
    supervisorlist: [],
    selectedroleslist:[],
    replaceParalegal: false,
    approveParalegalform: false,
    active: false,
    approveRejectPop: false,
    approveRejectTitle: "Approve Questionnire",
    approveRejecInstructions: "",
    actionType: "approved",
    is_change_paralegal: false,
    is_change_superwiser: false,
    actionType:"CASE_APPROVED"
  }),
  methods: {
    submitcaseapproval(){
  
          let payload_data = {
            petitionId: this.petition._id,
            comment: this.caseapprovednotes,
            "action":this.actionType
          };
 

     this.$store
            .dispatch("manageApproval_process", payload_data)
            .then(response => {
              this.showMessages(response.message);
              window.location.reload();
            });

    },
    submifFilingFees(){

            var postdata = {
            petitionId: this.petition._id,
            filingFeeData:this.filingFeeData
          };

    this.$store.dispatch("submifFilingFees", postdata).then(response => {

                  this.showMessages(response.message);
            window.location.reload();

    });
    },
      addfilingfee: function () {
        this.filingFeeData.push({
          amount:null,
          description:''
        });
      },
      removefilingfee: function (index) {
        Vue.delete(this.filingFeeData, index)
      },
      caseapprovedpop(action){
      this.caseapprovedpopup = true;
      this.actionType = action;
      if(action == 'READY_FOR_FILING') this.caseapprovedpopuptitle ="Ready For Filing";
 if(action == 'CASE_APPROVED') this.caseapprovedpopuptitle ="Case Approved";
    },
    requestpetitionersign(){
      this.filingFeesPopup = true;

    },
    assigntorole(roleId){
      this.assigntoRolePopup = true;
      this.assignedRoleId = roleId;
      if(roleId == 9){
        this.assigntoRoletitle = "Submit to Offshore";
        this.assigntoroletxt = "Offshore";
        this.chooseassigntorole = "Choose Offshore";
        this.rolesubmitaction = "ASSIGN_OFFSHORE_USER";
      }
       if(roleId == 5){
        this.assigntoRoletitle = "Submit to Attorney";
         this.assigntoroletxt = "Attorney";
          this.chooseassigntorole = "Choose Attorney";
           this.rolesubmitaction = "ASSIGN_ATTORNEY";
      }

    this.$store.dispatch("getusersByrole", roleId).then(response => {
      this.selectedroleslist = response.list;
    });
    


    },
    submitassignrole(){

         this.$validator.validateAll("assignroleform").then(result => {
        if (result) {
    
          var postdata = {
            petitionId: this.petition._id,
            userId: this.assigntoroleModel._id,
            userName: this.assigntoroleModel.name,
            roleId: this.assignedRoleId,
            typeName: this.petition.typeDetails.name,
            subTypeName: this.petition.subTypeDetails.name,
            comment: this.assignedrolecomments,
            action: this.rolesubmitaction,
            submitted: true
          };



          this.$store.dispatch("assigntoarole", postdata).then(response => {
            this.showMessages(response.message);
            window.location.reload();
          });
        }
      });
      


    },
    change_superwiser() {
      if (this.currentRole == 5) {
        this.SubmitParalegal = true;
        this.is_change_superwiser = true;
      }
    },
    change_paralegal() {
      if (this.currentRole == 5 || this.currentRole == 3) {
        this.replaceParalegaltitle = "Replace Paralegal";
        this.replaceParalegal = true;
        this.approveParalegalform = false;
        this.is_change_paralegal = true;
      }

      //alert("change_paralegal");
    },

    replaceparalegal() {
      this.replaceParalegaltitle = "Replace Paralegal";
      this.replaceParalegal = true;
      this.approveParalegalform = false;
      this.is_change_paralegal = false;
    },
    approveparalegal() {
      this.replaceParalegaltitle = "Approve Paralegal";
      this.replaceParalegal = true;
      this.approveParalegalform = true;
    },
    submitapproveparalegal() {
      this.$validator.validateAll("approveparalegalfoform").then(result => {
        if (result) {
          var paralegalid = this.petition.paralegalDetails._id;
          var userName = this.petition.paralegalDetails.name;
          if (
            this.paralegalModel != null &&
            this.approveParalegalform == false
          ) {
            paralegalid = this.paralegalModel._id;
            userName = this.paralegalModel.name;
          }
          var postdata = {
            petitionId: this.petition._id,
            userId: this.petition.paralegalDetails._id,
            userName: this.petition.paralegalDetails.name,
            roleId: 4,
            typeName: this.petition.typeDetails.name,
            subTypeName: this.petition.subTypeDetails.name,
            comment: this.supervisorcomments,
            action: "ASSIGN_PARALEGAL",
            submitted: true
          };

          if (this.is_change_paralegal) {
            //alert("ACTION");
            postdata["userId"] = this.paralegalModel._id;
            postdata["userName"] = this.paralegalModel.name;
            postdata["typeName"] = this.paralegalModel.roleDetails[0]["name"];
            postdata["action"] = "REPLACE_PARALEGAL";
            postdata["lastUserName"] = this.petition.paralegalDetails.name;
            //return false;
          }
          //petition/assign-a-role

          this.$store.dispatch("assigntoarole", postdata).then(response => {
            this.showMessages(response.message);
            window.location.reload();
          });
        }
      });
    },
    assignparalegalform() {
      this.$validator.validateAll("paralegalfoform").then(result => {
        if (result) {
          var postdata = {
            petitionId: this.petition._id,
            userId: this.paralegalModel._id,
            userName: this.paralegalModel.name,
            roleId: 4,
            typeName: this.petition.typeDetails.name,
            subTypeName: this.petition.subTypeDetails.name,
            comment: this.supervisorcomments,
            action: "ASSIGN_PARALEGAL"
          };

          this.$store.dispatch("assigntoarole", postdata).then(response => {
            this.showMessages(response.message);

            window.location.reload();
          });
        }
      });
    },
    
    assignsupervisorform() {
      this.$validator.validateAll("supervisorform").then(result => {
        if (result) {
          var postdata = {
            petitionId: this.petition._id,
            userId: this.supervisorMode._id,
            userName: this.supervisorMode.name,
            roleId: 3,
            typeName: this.petition.typeDetails.name,
            subTypeName: this.petition.subTypeDetails.name,
            comment: this.paralegalcomments,
            action: "ASSIGN_SUPERVISOR",
            submitted: true
          };

          this.$store.dispatch("assigntoarole", postdata).then(response => {
            this.showMessages(response.message);

            window.location.reload();
          });
        }
      });
    },
    approveOrreject(action_type = 1) {
      this.approveRejectTitle = "Approve Questionnaire";
      this.actionType = "approved";
      this.approveRejecInstructions = "";

      this.actionType = 1;
      if (action_type == "approved") {
        this.actionType = "approved";
        this.approveRejectTitle = "Approve Questionnaire";
        this.approveaction = true;
        this.$emit("passparent", 3);
      }
      if (action_type == "rejected") {
        this.actionType = "rejected";
        this.approveRejectTitle = "Reject Questionnaire";
        this.approveaction = false;
        this.approveRejectPop = true;
      }
    },
    saveApproveOrreject() {
      //alert(this.approveRejecInstructions);

      this.$validator.validateAll("approverejectquestion").then(result => {
        if (result) {
          // this.approveRejec_Instructions="* Instructions is required"

          let payload_data = {
            petitionId: this.petition._id,
            comment: this.approveRejecInstructions
          };
          // "action": "QUESTIONNIRE_APPROVED" // "QUESTIONNIRE_REJECTED" / "CASE_APPROVED" / "LCA_CERTIFIED_FOR_PETITION" / "READY_FOR_FILING" / "USCIS_APPROVED" / "USCIS_RECEIVED_RFE" / "USCIS_DENIED"

          if (this.actionType == "approved") {
            payload_data["action"] = "QUESTIONNIRE_APPROVED";
          } else {
            payload_data["action"] = "QUESTIONNIRE_REJECTED";
          }
          this.$store
            .dispatch("manageApproval_process", payload_data)
            .then(response => {
              this.showMessages(response.message);
              window.location.reload();
            });
        }
      });
    },
    gethistory() {
      this.$store
        .dispatch("petitionhistory", this.petition._id)
        .then(response => {
          this.petitionhistory = response.result.list;
        });
    },
    showMessages(message) {
      this.$vs.notify({
        title: "Success",
        position: "top-right",
        color: "success",
        iconPack: "feather",
        icon: "icon-check",
        text: message
      });
    }
  },
  mounted() {
    this.$store.dispatch("getusersByrole", 4).then(response => {
      this.paralegallist = response.list;
    });
    this.$store.dispatch("getusersByrole", 3).then(response => {
      this.supervisorlist = response.list;
    });
    
    this.gethistory();
  }
};
</script>