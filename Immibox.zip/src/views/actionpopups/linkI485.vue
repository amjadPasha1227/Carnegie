
<template>
    <modal
      name="linkI140PopupModal"
      classes="v-modal-sec"
      :min-width="200"
      :min-height="200"
      :scrollable="true"
      :reset="true"
      width="400px"
      height="auto"
    >
      <div class="v-modal profile_details_modal">
        <div class="popup-header fromDetailsPage">
          <h2 class="popup-title" v-if="checkProperty(petitionDetails,'i140Id')">Change I-140</h2>
          <h2 class="popup-title" v-else>Link I-140</h2>
          <span  @click="hideMe()">
            <em class="material-icons">close</em>
          </span>
        </div>
        <form @submit.prevent data-vv-scope="linkI140Form">
          <div class="form-container">

            <div class="vx-row" @click="premiumProcessingFormErrors = ''">
                <selectField :display="true"  @input="changesDocs" :wrapclass="'md:w-full'"
                :required="true" :optionslist="casesList" v-model="selectedCase" :fieldName="'selectedCase'"
                 :formscope="'linkI140Form'" label="Select Case" placeHolder="Select Case" />
            </div>
            <div class="vx-row">
              <div class="vx-col w-full">
                <div
                  class="form_group mb-5"
                  @click="
                    value = [];
                    premiumProcessingFilesUploading = false;
                  "
                >
                  <label class="form_label">Documents<em>*</em></label>
                  <div class="vs-component relative mb-1">                  
                    <file-upload
                      :multiple="true"
                      :hideSelected="true"
                      v-model="value"
                      class="file-upload-input file_upload justify-center"
                      :name="'140Documents'"
                      :accept="allDocEntity"
                      @input="uploadPremiumProcessingDocuments(value,'140Documents')"
                    >
                      <img
                        class="file-icon"
                        src="@/assets/images/main/file-upload.svg"
                      />
                      Upload
                    </file-upload>
                    <span v-if="uploading && false" class="loader"><img src="@/assets/images/main/loader.gif"   /></span>
                  </div>
                  <input type="hidden" :name="'140Documents'" v-validate="'required'"  data-vv-as="140 Documents"  v-model="premiumProcessingFiles">
                  <span class="text-danger text-sm" v-show="errors.has('linkI140Form.140Documents')">*Documents are required</span>
                  <span class="loader" v-if="premiumProcessingFilesUploading"
                      ><img src="@/assets/images/main/loader.gif"
                    /></span>
                    
                  <ul
                    class="uploaded-list note_uploads"
                    v-if="checkProperty(premiumProcessingFiles, 'length') > 0"
                  >
                    <template v-for="(file, fileindex) in premiumProcessingFiles">
                      <vs-chip
                        type="button"
                        @click="removePremiumProcessingFiles(fileindex)"
                        :key="fileindex"
                        v-if="file.status !== false"
                        closable
                        >{{ file.name }}
                      </vs-chip>
                    </template>
                  </ul>
                </div>
              </div>
  
              <div class="vx-col w-full">
                <div class="form_group">
                  <label class="form_label">Comments</label>
                   <ckeditor data-vv-as="Comments"
                  
                    v-model="premiumProcessingComment"
                    name="comments"
                    class="w-full" :editor="editor" :config="editorConfig"></ckeditor>
  
                  <!-- <span
                    class="text-danger text-sm"
                    v-show="errors.has('linkI140Form.comments')"
                    >Comments are required</span
                  > -->
                </div>
              </div>
  
              <div class="vx-col w-full pp-col mar0">
              </div>
            </div>
            <div v-show="premiumProcessingFormErrors">
              <vs-alert
                color="warning"
                class="warning-alert reg-warning-alert no-border-radius"
                icon-pack="IntakePortal"
                icon="IP-information-button"
                active="true"
                >{{ premiumProcessingFormErrors }}</vs-alert
              >
            </div>
          </div>
          <div class="popup-footer relative">
            <span class="loader" v-if="updatingPremiumProcessing"
              ><img src="@/assets/images/main/loader.gif"
            /></span>
  
            <vs-button
              color="dark"
              @click="hideMe()"
              class="cancel"
              type="filled"
              >Cancel</vs-button
            >
            <vs-button
              color="success"
              :disabled="
                updatingPremiumProcessing || premiumProcessingFilesUploading
              "
              @click="submitForm()"
              class="save"
              type="filled"
              >Update
            </vs-button>
          </div>        
        </form>
      </div>
    </modal>
  </template>
  <script>
  import selectField from "@/views/forms/fields/simpleselect.vue";
  import moment from "moment";
  import FileUpload from "vue-upload-component/src";
  import { EyeIcon } from 'vue-feather-icons'
  import docType from "@/views/common/docType.vue"
  import Vue from 'vue';
  Vue.use( CKEditor );
  import CKEditor from '@ckeditor/ckeditor5-vue2';
  import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
  import * as _ from "lodash";

  export default {
    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
      components: {
        selectField,
      docType,
      EyeIcon,
      FileUpload
    },
    methods: {
      removePremiumProcessingFiles(index){
        this.premiumProcessingFiles.splice(index ,1)
      },
      getI140List(){
            let postdata = {
            matcher:{  rfeCases:'', getMasterDataOnly:true,  beneficiaryIds:'',statusIds: [22],
            typeIds:[3],
            subTypeIds:[16]
            },
                "page": 1,
                "perpage": 10000
            }
            postdata['matcher']['userId'] = this.petitionDetails['userId'];
            postdata['matcher']['petitionerIds'] = [this.petitionDetails.petitionerId];
            if(_.has(this.petitionDetails ,"rfeCase" )){
                postdata['matcher']['isRfeCase'] = this.petitionDetails['rfeCase']
            }
            if(this.checkProperty( this.petitionDetails  ,'petitionerId')){
              postdata['matcher']['petitionerIds'] = [this.petitionDetails['petitionerId']];
            }

            if(this.checkProperty( this.petitionDetails  , "beneficiaryDetails",'_id')){
              postdata['matcher']['beneficiaryIds'] = [this.petitionDetails["beneficiaryDetails"]['_id']];
            }
            this.$store.dispatch("commonAction", {data: postdata,path: 'petition-common/list',}).then((response) => {
                let tempList = [];
                _.forEach(response['list'],(item)=>{
                    if(_.has(item,'caseNo')){
                        item =Object.assign(item,{ 'name':item['caseNo'],'id':item['_id']});
                        tempList.push(item)
                    }
                })
                this.casesList = tempList;
                if(this.checkProperty(this.petitionDetails,'i140Id')){
                    let i140Id = this.petitionDetails['i140Id'];
                    let selectedCase = _.find(this.casesList ,{"_id": i140Id});
                    if(selectedCase){
                        this.changesDocs(this.selectedCase);
                        this.selectedCase =selectedCase;
                        this.$validator.reset();
                    }
                    //alert(JSON.stringify(selectedCase))
                }
            });
        },
        changesDocs(item){
            this.selectedCase = item
            if(this.checkProperty(this.selectedCase,'i140Docs')){
                this.premiumProcessingFiles = this.checkProperty(this.selectedCase,'i140Docs')
            }
        },
      uploadPremiumProcessingDocuments(model,category='') {
             this.premiumProcessingFormErrors = ''
              let temp_count = 0;
              
            
              this.disabled_btn = true;
              let mapper = model.map(
                  item =>
                  (item = {
                      name: item.name,
                      file: item.file ? item.file : null,
                      path: item.path ? item.path : "",
                      status: item.status?true:false,
                      mimetype: item.type ? item.type : item.mimetype,
                  })
              );

               this.premiumProcessingFilesUploading =true;
               if (mapper.length > 0) {
                  this.uploading =true,
                  mapper.forEach((doc, index) => {
                      let formData = new FormData();
                      formData.append("files", doc.file);
                      formData.append("secureType", "private");
                      this.$store.dispatch("uploadS3File", formData).then(response => {
                          temp_count++;
                          response.data.result.forEach(urlGenerated => {
                              doc.status = true;
                              doc.path = urlGenerated;
                              delete doc.file;
                               this.premiumProcessingFiles =[];
                               if(category == '140Documents'){
                                this.premiumProcessingFiles.push(doc);
                               }
                             
                              mapper[index] = doc;
                              if (temp_count >= mapper.length) {
                                this.uploading =false,
                                this.disabled_btn = false;
                                this.documents =[];
                                this.premiumProcessingFilesUploading =false;
                              }
                          });
                      });
                  });
                  model.splice(0, mapper.length, ...mapper);
              }
      },
      submitForm() {
        this.$validator.validateAll('linkI140Form').then((result) => {
        let self =this;
            if (result) {
            let postData ={
                caseNo:self.checkProperty(self.selectedCase,'caseNo'),
                petitionId :self.checkProperty(self.petitionDetails ,'_id'),
                i140Docs:[],
                today: moment().format("YYYY-MM-DD"),
                comments:self.premiumProcessingComment,
                typeName:self.checkProperty(self.petitionDetails ,'typeDetails','name'),
                subTypeName:self.checkProperty(self.petitionDetails ,'subTypeDetails','name'),
                i140Id:self.checkProperty(self.petitionDetails, 'i140Id')
            }
            if(this.premiumProcessingFiles && this.checkProperty(this.premiumProcessingFiles,'length')>0){
                postData['i140Docs'] = this.premiumProcessingFiles;
            }
            this.updatingPremiumProcessing =true;
            
            this.$store.dispatch("commonAction", {"data":postData ,"path":"/petition/manage-i140"})
            .then(response => {
                this.updatingPremiumProcessings =false;
                this.hideMe();
                this.showToster({message:response.message,isError:false });
                this.$emit("updatepetition", "Case Details");             
            })
            .catch((error)=>{
                this.premiumProcessingFormErrors =error;
                this.updatingPremiumProcessing =false;
            }) 
            }
        });
      },
      hideMe() {
        this.$emit("hideMe");
      },
    },
    watch: {
      showPopup(val) {
        if (!val) this.$emit("hideMe");
      },
    },
    mounted() {
        this.premiumProcessingComment = '',
        this.premiumProcessingFiles = [];
        this.selectedCase = null;
        this.getI140List();
      this.$modal.show("linkI140PopupModal");
    },
    data: () => ({
      value:[],
      uploading:false,
        selectedCase:null,
        casesList:[],
      editor: ClassicEditor,
      editorConfig: {
          toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
      },
      loading: false,
      showPopup: false,
      comments: false,
      formerrors: {
        msg: "",
      },
       documents:[],
  
      premiumProcessingFormErrors:'',
      premiumProcessingComment:'',
      premiumProcessing:false,
      updatingPremiumProcessing:false,
      premiumProcessingFiles:[],
      premiumProcessingFilesUploading:false,
    }),
    props: {
      caseNumber: {
        type: String,
        default: null,
      },
      isCaseNumberEdit: {
        type: Boolean,
        default: false,
      },
      petitionDetails: {
        type: Object,
        default: null,
      },
    },
  };
  </script>