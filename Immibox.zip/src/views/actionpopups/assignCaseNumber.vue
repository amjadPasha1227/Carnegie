
<template>
  <vs-popup
    class="holamundo main-popup"
    :title="isCaseNumberEdit ? 'Edit Case Number' : 'Assign Case Number'"
    :active.sync="showPopup"
  >
    <form data-vv-scope="newCaseNumberForm" @submit.prevent @keydown.enter.prevent>
      <div class="popup-accounts-content edit_password">
        <div class="form-container padb20">
          <div class="form_group">
            <!-- <i class="placeholder-icon IP-hide-1"></i> -->
            <label class="form_label">Case Number<em>*</em></label>
            <vs-input
              type="text"
              v-validate="'required|min:4|max:30'"
              oninput="this.value = this.value.replace(/[^a-z A-Z 0-9 -]/g, '');"
              data-vv-as="Case Number"
              name="caseNumber"
              v-model="caseNumber"
              placeholder="Case Number"
              class="w-full no-icon-border mb-0"
              ref="caseCode"
            />
            <span
              class="text-danger text-sm"
              v-show="errors.has('newCaseNumberForm.caseNumber')"
              >{{ errors.first("newCaseNumberForm.caseNumber") }}<br
            /></span>
          </div>

          <div class="text-danger text-sm formerrors" v-show="formerrors.msg">
            <vs-alert
              color="warning"
              class="warning-alert reg-warning-alert no-border-radius"
              icon-pack="IntakePortal"
              icon="IP-information-button"
              active="true"
            >
              {{ formerrors.msg }}
            </vs-alert>
          </div>
        </div>
        <div class="popup-footer relative">
          <!-- <div class="password-count">
          <i class="icon IP-lock"></i> Password must contain 6 to 15 characters
        </div> -->
          <div class="d-flex">
            <vs-button
              color="dark"
              @click="hideMe()"
              class="cancel"
              type="filled"
              >Cancel</vs-button
            >

            <vs-button
              class="save"
              type="filled"
              @click="submitForm"
              :disabled="settingCaseNumber"
            >
              <figure v-if="settingCaseNumber" class="loader">
                <img src="@/assets/images/main/loader.gif" />
              </figure>
              {{ isCaseNumberEdit ? "Update" : "Assign" }}
            </vs-button>
          </div>
        </div>
      </div>
    </form>
  </vs-popup>
</template>
<script>
export default {
  methods: {
    submitForm() {
      this.$validator.validateAll("newCaseNumberForm").then((result) => {
        if (result) {
          let self = this;
          let postData = {
            caseNo: self.caseNumber.trim(),
            petitionId: self.petitionDetails["_id"],
            subTypeName: self.checkProperty(
              self.petitionDetails,
              "subTypeDetails",
              "name"
            ),
            typeName: self.checkProperty(
              self.petitionDetails,
              "typeDetails",
              "name"
            ),
          };
          this.settingCaseNumber = true;
          let path ="/petition/assign-custom-caseno";
          if([3].indexOf(this.checkProperty(this.petitionDetails,'typeDetails', 'id' )) >-1 &&  [15].indexOf(this.checkProperty(this.petitionDetails,'subTypeDetails', 'id' )) >-1){
                  path ="/perm/assign-custom-caseno";
               }
          this.$store
            .dispatch("commonAction", {
              data: postData,
              path: path,
            })
            .then((response) => {
              this.showToster({ message: response.message, isError: false });
              this.$validator.reset("newCaseNumberForm");
              this.settingCaseNumber = false;
              this.$emit("updatepetition", "Case Details");
               this.hideMe()
            })
            .catch((err) => {
              this.settingCaseNumber = false;
              this.showToster({ message: err, isError: true });
            });
        }
      });
    },
    hideMe() {
      this.$emit("hideMe");
    },
  },
  watch: {
    showPopup(val) {
      if (!val) this.$emit("hideMe");
    },
  },
  mounted() {
    this.showPopup = true;
    this.caseNumber = this.petitionDetails.caseNo;
  },
  data: () => ({
    showPopup: false,
    settingCaseNumber: false,
    formerrors: {
      msg: "",
    },
  }),
  props: {
    caseNumber: {
      type: String,
      default: null,
    },
    isCaseNumberEdit: {
      type: Boolean,
      default: false,
    },
    petitionDetails: {
      type: Object,
      default: null,
    },
  },
};
</script>