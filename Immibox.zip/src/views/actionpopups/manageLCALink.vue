<template>
    <vs-popup class="holamundo main-popup" :title="popUpTitle" :active.sync="showPopup">

        <form data-vv-scope="assignmentForm" class="relative" @submit.prevent @keydown.enter.prevent>
            <div class="popup_info" v-if="checkProperty(selectedCaseNos,'length') >0" @click="formErrors = ''">
                <span><eye-icon size="1.5x" class="custom-class"></eye-icon></span>
                <div class="info_list">
                    <ul v-if="checkProperty(selectedCaseNos,'length') >0">
                        <template v-for="(usr, usrIndx) in selectedCaseNos">
                            <li :key="usrIndx">{{ usr["caseNo"] }}</li>
                        </template>
                    </ul>
                </div>
            </div>
            <div class="form-container">
                <div class="vx-row">
                    <div class="vx-col w-full" v-if="['LINK_LCA'].indexOf(ACTIVITYCODE) > -1">
                        <div class="form_group">
                            <label for class="form_label">{{ dropdownTitle }}<em>*</em></label>
                            <div class="con-select w-full select-large">
                                
                                <multiselect name="caseNos" v-model="selectedCaseNos" :close-on-select="isFromPetition"
                                    v-validate="'required'" :multiple="!isFromPetition" :show-labels="false" label="caseNo"
                                    :data-vv-as="dropdownTitle" :placeholder="'Select ' + dropdownTitle"
                                    :options="casesList" :allow-empty="true" track-by="_id"
                                    :preserve-search="true" @search-change="casesSearch">
                                    <template slot="selection" slot-scope="{ values, isOpen }">
                                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{
                                            values.length }} selected</span>
                                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                                    </template>
                                </multiselect>
                            </div>

                            <span class="text-danger text-sm" v-show="errors.has('assignmentForm.caseNos')">{{
                                errors.first("assignmentForm.caseNos") }}</span>
                        </div>
                    </div>

                    <div class="vx-col w-full">
                        <div class="form_group mb-4">
                            <label class="form_label">Comments<em>*</em></label>
                            <!-- <vs-textarea
                  data-vv-as="Comments"
                  v-validate="'required'"
                  v-model="comments"
                  name="comments"
                  class="w-full mb-5"
                /> -->
                            <ckeditor data-vv-as="Comments" v-validate="'required'" v-model="comments" name="comments"
                                class="w-full mb-5" :editor="editor" :config="editorConfig"></ckeditor>
                            <span class="text-danger text-sm" v-show="errors.has('assignmentForm.comments')">Comments are
                                required</span>
                        </div>
                    </div>
                </div>

                <div class="text-danger text-sm formerrors my-2" v-show="formErrors">
                    <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius"
                        icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ formErrors }}</vs-alert>
                </div>
            </div>

            <div class="popup-footer relative">
                <span class="loader" v-if="loading"><img src="@/assets/images/main/loader.gif" /></span>
                <vs-button color="dark" @click="showPopup = false" class="cancel" type="filled">Cancel</vs-button>


                <vs-button :disabled="loading" color="success" @click="submitForm()" class="save" type="filled">
                    <template v-if="isFromPetition && lcaId != ''">Change LCA</template>
                    <template v-else>Link with Case</template>

                </vs-button>

            </div>
        </form>
    </vs-popup>
</template>
<script>
import moment from "moment";

import * as _ from "lodash";
import Vue from 'vue';
Vue.use(CKEditor);
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';

export default {
    methods: {
        getLCADetails() {
            // this.$vs.loading();
            this.$store.dispatch("fetchLcaDetails", this.lcaId)
                .then((response) => {
                    // this.$vs.loading.close();
                    this.lcaInfo = response.data.result;
                    if (this.isFromPetition) {
                        this.selectedCaseNos = [{ '_id': this.lcaInfo['_id'], 'caseNo': this.lcaInfo['_id', 'caseNo'] }]
                    } else {
                        if (this.checkProperty(this.lcaInfo, 'petitionList') && this.checkProperty(this.lcaInfo, 'petitionList', 'length') > 0) {
                            this.selectedCaseNos = this.checkProperty(this.lcaInfo, 'petitionList')
                        }
                    }
                    if (!this.isFromPetition) {
                        this.getCasesList()
                    }
                })
                .catch((error) => {
                    // this.$vs.loading.close();
                    this.showToster({ message: error, isError: true });
                    this.$emit("updatepetition", "LCA");
                });
        },

        getCasesList() {
            // let postdata = {
            //     matcher: { rfeCases: '', getMasterDataOnly: true, beneficiaryIds: [], },
            //     "page": 1,
            //     "perpage": 100
            // }
            // postdata['userId'] = this.lcaInfo['userId'];
            // if (_.has(this.petition, "rfeCase")) {
            //     postdata['matcher']['isRfeCase'] = false
            // }
            let postdata = { matcher: { searchString: this.searchString } }
            if(this.checkProperty(this.lcaInfo,'petitionerDetails','_id'))
            {
                postdata.matcher['petitionerIds']=[this.checkProperty(this.lcaInfo,'petitionerDetails','_id')];
            }
            this.$store.dispatch("commonAction", { "data": postdata, "path": 'petition/get-petition-list-for-lca' }).then(response => {
                this.casesList = response;


            }).catch(() => {

            })
        },
        getLcaList() {
            let obj = {
                page: 1,
                perpage: 1000,
                sorting: { 'updatedOn': 1 },
                matcher: {
                    searchString: this.searchString,
                    petitionerIds: [],
                    statusIds: [1, 2, 3],
                    getMasterDataOnly: true,
                }
            };
            if (this.checkProperty(this.petitionDetails, 'petitionerDetails', '_id')) {
                obj['matcher']['petitionerIds'] = [this.checkProperty(this.petitionDetails, 'petitionerDetails', '_id')]
            }
            //   if (this.beneficiaryIds && this.beneficiaryIds.length > 0) {
            //     obj['matcher']['beneficiaryIds'] = this.beneficiaryIds.map((item) => { return item['_id'] })
            //   }


            this.$store.dispatch("fetchlcalist", obj).then(response => {
               // this.casesList = response.data.result.list;
               this.casesList  = [];
                let list = _.cloneDeep(response.data.result.list);
                _.forEach(list ,(item)=>{
                    if(this.checkProperty(item ,'statusDetails' ,'name')){
                        item['caseNo'] =   item['caseNo']+" ("+item['statusDetails']['name']+")";
                    }

                    this.casesList.push(item);

                });
               
            }).catch(() => {
            })
        },


        submitForm() {

            this.$validator.validateAll("assignmentForm").then((result) => {
                if (result) {


                    if (this.isFromPetition) {
                        let postData = {
                            petitionIds: [],
                            "removePetitionIds": [],
                            comment: this.comments,
                            "lcaId": this.lcaId,
                            "caseNo": '',
                            today: moment().format('YYYY-MM-DD')
                        };
                        postData.petitionIds = [this.checkProperty(this.petitionDetails, '_id')]
                        if (this.checkProperty(this.selectedCaseNos, '_id')) {
                            postData['lcaId'] = this.selectedCaseNos['_id']
                            postData['caseNo'] = this.selectedCaseNos['caseNo']
                        }
                        if (this.checkProperty(this.lcaInfo, 'caseNo')) {
                            postData['oldCaseNo'] = this.lcaInfo['caseNo']
                        }

                        let path = "/petition/manage-lca";

                        // alert(JSON.stringify(postData))
                        this.loading = true;
                        this.$store
                            .dispatch("commonAction", { "data": postData, "path": path })
                            .then(response => {
                                this.showPopup = false;
                                this.openAtornyPopup = false;
                                this.showToster({ message: response.message, isError: false });
                                this.loading = false;
                                this.$emit("updatepetition", '');
                                this.$emit("hideMe");
                            })
                            .catch((error) => {

                                this.formErrors = error;
                                this.loading = false;
                            })


                    }
                    else {
                        let postData = {
                            petitionIds: [],
                            "removePetitionIds": [],
                            comment: this.comments,
                            "lcaId": this.lcaId,
                            "caseNo": this.lcaInfo.caseNo,
                            today: moment().format('YYYY-MM-DD')

                        };
                        postData.petitionIds = this.selectedCaseNos.map((item) => { return item['_id'] })

                        let removedIds = []
                        if (this.checkProperty(this.lcaInfo, 'petitionList') && this.checkProperty(this.lcaInfo, 'petitionList', 'length') > 0) {
                            let caseList = this.checkProperty(this.lcaInfo, 'petitionList')
                            _.forEach(caseList, (item) => {
                                if (postData.petitionIds.indexOf(item['_id']) < 0) {
                                    removedIds.push(item['_id'])
                                }
                            });
                        }

                        postData.removePetitionIds = removedIds

                        let path = "/petition/manage-lca";

                        // alert(JSON.stringify(postData))
                        this.loading = true;
                        this.$store
                            .dispatch("commonAction", { "data": postData, "path": path })
                            .then(response => {
                                this.showPopup = false;
                                this.openAtornyPopup = false;
                                this.showToster({ message: response.message, isError: false });
                                this.loading = false;
                                this.$emit("updatepetition", '');
                                this.$emit("hideMe");




                            })
                            .catch((error) => {

                                this.formErrors = error;
                                this.loading = false;
                            })


                    }


                }
            });
        },
        hideMe() {
            this.$emit("hideMe");
        },
        casesSearch(searchValue) {
            this.searchString = searchValue;
            if (!this.isFromPetition && this.lcaId != '') {
               

                clearTimeout(this.debounce)
                this.debounce = setTimeout(() => {
                    this.getCasesList()
                }, 900)
            }
            if (this.isFromPetition) {
                clearTimeout(this.debounce)
                this.debounce = setTimeout(() => {
                    this.getLcaList()
                }, 900)
               
                
            }
        },

    },
    watch: {
        showPopup(val) {
            if (!val) this.$emit("hideMe");
        },
    },
    mounted() {

        this.showPopup = true;
        this.searchString="";
        if (!this.isFromPetition && this.lcaId != '') {
            this.getLCADetails()
        }
        if (this.isFromPetition) {
            this.dropdownTitle = 'LCA No'
            this.lcaInfo = this.lcaDetails
            if (this.lcaId != '') {
                this.getLCADetails()
            }
            this.getLcaList()
        }

        
        //this.getCasesList()
    },
    data: () => ({
        debounce:null,
        editor: ClassicEditor,
        editorConfig: {
            toolbar: ['bold', 'italic', '|', 'undo', 'redo', 'NumberedList', 'BulletedList',],
        },
        loading: false,
        comments: null,
        showPopup: false,
        formErrors: null,
        lcaInfo: null,
        casesList: [],
        linkedCaseList: [],
        selectedCaseNos: [],
        dropdownTitle: 'Case No',
        searchString: ''

    }),
    props: {
        ACTIVITYCODE: {
            type: String,
            default: null,
        },
        rolesList: [],
        popUpTitle: {
            type: String,
            default: null,
        },
        petitionDetails: {
            type: Object,
            default: null,
        },
        lcaId: {
            type: String,
            default: '',
        },
        lcaDetails: {
            type: Object,
            default: '',
        },
        isFromPetition: {
            type: Boolean,
            default: null,
        },


    },
};
</script>
  