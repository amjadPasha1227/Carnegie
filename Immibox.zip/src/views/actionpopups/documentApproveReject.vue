<template>
   
    <modal
          name="approveOrRejectDocsFormModal"
          classes="v-modal-sec"
          :min-width="200"
          :min-height="200"
          :scrollable="true"
          :reset="true"
          width="650px"
          height="auto"
        >
        <div class="v-modal profile_details_modal error-modal-space" >
          <div class="popup-header fromDetailsPage">
            <h2 class="popup-title">
                <!----"UPLOAD_BY_DOC_EXECUTIVE",//APPROVED_BY_DOC_MANAGER, REJECT_BY_DOC_MANAGER --->
              
               
               
                <template v-if="ACTIVITYCODE=='UPLOAD_BY_DOC_EXECUTIVE'">Send documents for review </template>
                <template v-else>Approve or Reject Documents</template>
                
                

               </h2>
            <span @click="hideMe();">
              <em class="material-icons">close</em>
            </span>
          </div>
        
          <form data-vv-scope="approveOrRejectDocsForm">
            <div class="form-container">
            <div class="vx-row">
                <div class="vx-col w-full">
                <div class="form_group">
                    <label class="form_label">Comments<em>*</em></label>
                    <!-- <vs-textarea
                    data-vv-as="Comments"
                    v-validate="'required'"
                    v-model="comments"
                    name="comments"
                    class="w-full"
                    /> -->
                    <ckeditor data-vv-as="Comments"
                    v-validate="'required'"
                    v-model="comments"
                    name="comments"
                    class="w-full"  :editor="editor" :config="editorConfig"></ckeditor>
                    <span
                    class="text-danger text-sm"
                    v-show="errors.has('approveOrRejectDocsForm.comments')"
                    >{{ errors.first("approveOrRejectDocsForm.comments") }}</span
                    >
                </div>
                </div>
            </div>
            <div class="text-danger text-sm formerrors" v-show="formErrors">
                <vs-alert
                color="warning"
                class="warning-alert reg-warning-alert no-border-radius"
                icon-pack="IntakePortal"
                icon="IP-information-button"
                active="true"
                >{{ formErrors }}</vs-alert
                >
            </div>
            </div>
            <div class="popup-footer relative">
              <span class="loader" v-if="uploading"><img src="@/assets/images/main/loader.gif"></span>
              
          <vs-button
            color="dark"
            @click="showPopup =false;hideMe()"
            class="btn cancel"
            type="filled"
            >Cancel
          </vs-button>

          <template v-if="ACTIVITYCODE!='UPLOAD_BY_DOC_EXECUTIVE'">

          <vs-button
          
            color="success"
            @click="approveOrRejectDocsAction('REJECT_BY_DOC_MANAGER')"
            class="save"
            type="filled"
            >Reject</vs-button
          >
          <vs-button
            
            color="success"
            @click="approveOrRejectDocsAction('APPROVED_BY_DOC_MANAGER')"
            class="save"
            type="filled"
            >Approve</vs-button
          >
        </template>
        <template v-else>
          <vs-button  color="success"  @click="approveOrRejectDocsAction('UPLOAD_BY_DOC_EXECUTIVE')" class="save"  type="filled"
            >Send</vs-button
          >
        </template>
        </div>
      </form>
          </div>
        </modal>  
</template>
<script>
import { InfoIcon } from "vue-feather-icons";

import moment from "moment";
import FileUpload from "vue-upload-component/src";
import { EyeIcon } from "vue-feather-icons";
import docType from "@/views/common/docType.vue";
import Datepicker from "vuejs-datepicker-inv";
import * as _ from "lodash";
import immiInput from "@/views/forms/fields/simpleinput.vue";
import immitextarea from "@/views/forms/fields/simpletextarea.vue";
import selectField from "@/views/forms/fields/simpleselect.vue";
import Vue from 'vue';
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';

export default {
provide() {
        return {
           parentValidator: this.$validator,
        };
    },
components: {
  InfoIcon,
  docType,
  EyeIcon,
  FileUpload,
  Datepicker,
  immiInput,
  immitextarea,
  selectField
},
methods: {
    
      approveOrRejectDocsAction(action = "") {
      
    
      this.formErrors = "";

      this.$validator.validateAll("approveOrRejectDocsForm").then((result) => {
       
      
        if (result) {
          this.uploading = true;
          var postData = {
            petitionId: this.checkProperty(this.petitionDetails, "_id"),
            typeName: this.checkProperty(this.petitionDetails, "typeDetails", "name"),
            subTypeName: this.checkProperty(this.petitionDetails, "subTypeDetails", "name"),
            comment: this.comments, // Required on APPROVED_BY_DOC_MANAGER and REJECT_BY_DOC_MANAGER
            action: action, //"UPLOAD_BY_DOC_EXECUTIVE",//APPROVED_BY_DOC_MANAGER, REJECT_BY_DOC_MANAGER
            today: moment().format("YYYY-MM-DD"),
          };
          //this.loading = true;
          this.$store
            .dispatch("commonAction", {
              data: postData,
              path: "/petition/manage-offshore-document-upload",
            })
            .then((response) => {
              this.uploading = false;
              this.showToster({ message: response.message, isError: false });
              this.$emit("updatepetition");
            })
            .catch((error) => {
              this.uploading = false;
              this.formErrors = error;
              // this.loading = false;
            });
        }
      });
    },
  hideMe() {
   
    this.$emit("hideMe");
   
    setTimeout(()=>{
      this.showPopup =false;
        this.$modal.hide('approveOrRejectDocsFormModal');
      },10);
  },
},
watch: {
  showPopup(val) {
    if (!val){
      this.$emit("hideMe");
      this.$modal.hide('approveOrRejectDocsFormModal');
    } 
  },
},
mounted() {
 
  
   
    this.showPopup = true;
    this.$modal.show('approveOrRejectDocsFormModal');
        
          
  
},
data: () => ({
  editor: ClassicEditor,
 editorConfig: {
     toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
 },
    formErrors:'',
    comments:'',
    uploading:false,
  showPopup: false,
  
 
}),
props: {
  ACTIVITYCODE: {
    type: String,
    default: null,
  },
  petitionDetails: {
    type: Object,
    default: null,
  },
},
};
</script>
