<template>
  <modal
    name="trackingDetailsForm"
    classes="v-modal-sec"
    :min-width="500"
    :min-height="200"
    :scrollable="true"
    :reset="true"
    width="500px"
    height="auto"
  >
    <div class="v-modal profile_details_modal update-tracking-details-modal">
      <div class="popup-header fromDetailsPage">
        <h2 class="popup-title"  v-if="['COURIER_TRACKING'].indexOf(ACTIVITYCODE)>-1">Update Tracking Details</h2>
        <h2 class="popup-title"  v-if="['RFE_COURIER_TRACKING'].indexOf(ACTIVITYCODE)>-1">RFE Update Tracking Details</h2>
        <h2 class="popup-title"  v-if="['UPDATE_USCIS_RECEIPT_NUMBER'].indexOf(ACTIVITYCODE)>-1">Update USCIS Receipt</h2>
        <h2 class="popup-title"  v-if="['RFE_UPDATE_USCIS_RECEIPT_NUMBER'].indexOf(ACTIVITYCODE)>-1">RFE Update USCIS Receipt</h2>
        <span @click="hideMe()">
          <em class="material-icons">close</em>
        </span>
      </div>
      <form @submit.prevent data-vv-scope="trackingform" class="trackingform">
        <div 
          class="form-container pad0"
          @keyup="trackingErrors = ''"
          @click="trackingErrors = ''"
        >
          <template
            v-if="['COURIER_TRACKING','RFE_COURIER_TRACKING'].indexOf(ACTIVITYCODE)>-1 && updateTrackingFormData"
          >
            <template v-for="(item, index) in updateTrackingFormData['items']">
              <div class="vx-row pad20" :key="index">
                <div class="vx-col w-full">
                  <div class="form_group">
                    <vs-input
                      style="width: 100%"
                      data-vv-as="Tracking ID"
                      v-validate="'required'"
                      v-model="item.trackingId"
                      name="trackingId"
                      label="Tracking ID*"
                    />
                    <span
                      class="text-danger text-sm"
                      v-show="errors.has('trackingform.trackingId')"
                      >{{ errors.first("trackingform.trackingId") }}</span
                    >
                  </div>
                </div>
                <div class="vx-col w-full">
                  <div class="form_group">
                    <label for class="form_label">Courier<em>*</em></label>
                    <div class="con-select">
                      <multiselect
                        data-vv-as="Courier"
                        v-model="item.courierDetails"
                        @input="changedCourierInfo(item)"
                        :options="courierList"
                        :multiple="false"
                        :close-on-select="true"
                        :clear-on-select="false"
                        :preserve-search="true"
                        placeholder="Select Courier"
                        label="name"
                        track-by="name"
                        :preselect-first="false"
                        name="Courier"
                        v-validate="'required'"
                      >
                        <template
                          slot="selection"
                          slot-scope="{ values, isOpen }"
                        >
                          <span
                            class="multiselect__single"
                            v-if="values.length &amp;&amp; !isOpen"
                            >{{ values.length }} options selected</span
                          >
                        </template>
                      </multiselect>
                    </div>
                    <span
                      class="text-danger text-sm"
                      v-show="errors.has('trackingform.Courier')"
                      >{{ errors.first("trackingform.Courier") }}</span
                    >
                  </div>
                </div>


                <div class="vx-col w-full">
                  <div class="form_group mb-0">
                    <label class="form_label">Sent Date<em>*</em></label>
                   
                    <DatePickerField  :validationRequired="true"  :dateEnableTo="currentDate" v-model="item.sentDate" formscope="trackingform" fieldname="Sent Date" label="Sent Date" class=" mb-0"/>

                 </div>
                </div>
              </div>
            </template>
          </template>
          <template
            v-if="
             ['UPDATE_USCIS_RECEIPT_NUMBER','RFE_UPDATE_USCIS_RECEIPT_NUMBER'].indexOf(ACTIVITYCODE)>-1  &&
              updateTrackingFormData
            "
          >
            
              
                <div class="trackinglist" v-for="(item, index) in updateTrackingFormData['items']" :key="index">
                  <label class="trackingtitle" ><strong>{{ item["userName"] }}</strong><template v-if="checkProperty(item ,'userType')">({{ item["userType"] }})</template> </label>
                  <div class="vx-row" :key="index">
                    <div class="vx-col w-1/2" v-if="false">
                      <div class="form_group">
                        <vs-input
                          style="width: 100%"
                          data-vv-as="USCIS Receipt"
                          v-validate="'required'"
                          v-model="item.receiptName"
                          :name="'uscisreceipt' + index"
                          label="USCIS Receipt*"
                        />
                        <span
                          class="text-danger text-sm"
                          v-show="errors.has('trackingform.uscisreceipt' + index)"
                          >{{
                            errors.first("trackingform.uscisreceipt" + index)
                          }}</span
                        >
                      </div>
                    </div>
                    <div class="vx-col w-full">
                      <div class="form_group">
                        <vs-input
                          style="width: 100%"
                          data-vv-as="Receipt Number"
                          v-validate="'required|max:20'"
                          v-model="item.receiptNumber"
                          :name="'receiptNumber' + index"
                          label="Receipt Number*"
                        />
                        <span
                          class="text-danger text-sm"
                          v-show="errors.has('trackingform.receiptNumber' + index)"
                          >{{
                            errors.first("trackingform.receiptNumber" + index)
                          }}</span
                        >
                      </div>
                    </div>

                     <div class="vx-col w-full">
                      <div class="form_group">
                        <label class="form_label">Received Date<em>*</em></label>
                      
                        <DatePickerField  :validationRequired="true"  :dateEnableTo="currentDate" v-model="item.receivedDate" formscope="trackingform" :fieldname="'Received Date'+ index" label="Received Date" />

                      </div>
                    </div>

                    <div class="vx-col w-full">
                      <div class="uploadsec_wrap">
                        <div class="w-full">
                          <div @click="uploadMainDocuments = []">
                            <file-upload
                              v-model="uploadMainDocuments"
                              class="file-upload-input mb-0"
                              style="height: 50px; padding: 0px"
                              :name="'uploadrecptdocuments' + index"
                              :multiple="false"
                              :hideSelected="true"
                              :accept="allDocEntity"
                              label="Documents"
                              @input="
                                uploadToS3MainDocuments(uploadMainDocuments, item)
                              "
                            >
                              <img
                                class="file-icon"
                                src="@/assets/images/main/file-upload.svg"
                              />
                              Upload
                            </file-upload>
                            <span class="loader" v-if="item.filesAreuploading"
                              ><img src="@/assets/images/main/loader.gif"
                            /></span>

                            <!--<span class="file-type mb-0">(File Type: PDF, DOC, JPEG, PNG. Max file size: 1MB)</span>-->
                          </div>
                        </div>
                      </div>
                      
                      

                      <ul
                        class="uploaded-list"
                        v-if="checkProperty(item, 'documents', 'length') > 0"
                      >
                        <template v-for="(fil, fileindex) in item['documents']">
                          <vs-chip
                            @click="remove(item['documents'], fileindex)"
                            :key="fileindex"
                            closable
                          >
                            {{ fil.name }}
                          </vs-chip>
                        </template>
                      </ul>
                    </div>
                  </div>
                </div>
               
            
          </template>

          <div class="vx-row padlr20 pb-6" v-if="getTenantTypeId != 2 && checkProperty(petitionDetails, 'petitionerId')" >
            <div class="vx-col w-full"   >
              <ul
                class="demo-alignment custom-radio notify_checks"
                vs-type="flex"
                vs-align="center">
                <li>
                  <vs-checkbox
                    vs-name="notifyPetitioner"
                    v-model="notifyPetitioner"
                  ><span>Notify Petitioner</span>
                  </vs-checkbox>
                </li>
              </ul>
            </div>
          </div>
        </div>
         

        <div class="text-danger text-sm formerrors" v-if="trackingErrors != ''">
          <vs-alert
            color="warning"
            class="warning-alert reg-warning-alert no-border-radius"
            icon-pack="IntakePortal"
            icon="IP-information-button"
            active="true"
            >{{ trackingErrors }}</vs-alert
          >
        </div>
       
        <div class="popup-footer relative">
          <span class="loader" v-if="updateTrackingLoading"
            ><img src="@/assets/images/main/loader.gif"
          /></span>
          <vs-button
            color="dark"
            class="cancel"
            :disabled="updateTrackingLoading || filesAreuploading"
            type="filled"
            @click="hideMe()"
            >Cancel</vs-button
          >
          <vs-button
            color="success"
            :disabled="updateTrackingLoading || filesAreuploading"
            @click="submitForm()"
            class="save"
            type="filled"
            >Submit</vs-button
          >
        </div>
      </form>
    </div>
  </modal>
</template>
<script>
import moment from "moment";
import FileUpload from "vue-upload-component/src";
import { EyeIcon } from "vue-feather-icons";
import docType from "@/views/common/docType.vue";
import Datepicker from "vuejs-datepicker-inv";
import DatePickerField from "@/views/common/datePickerField.vue";

import * as _ from "lodash";

export default {
  provide() {
        return {
            parentValidator: this.$validator,
        };
  },
  components: {
    docType,
    EyeIcon,
    FileUpload,
    Datepicker,
    DatePickerField,
  },
  methods: {
    remove(docList, indx) {
      docList.splice(indx, 1);
            return false;
        },
    getGlobalConfigDetails(){
            let postData ={}
          //  this.configDetails =null
            let path = 'global-config/details'
             this.$store.dispatch("commonAction", {data:postData,path:path})
           .then((response) =>{ 
               
               if(this.checkProperty(response ,"config"  )){
                this.configDetails =response['config'];
                //defaultCourierId
                this.setDefaultCouriar();
               }
              })
           },
    setDefaultCouriar(){
      if(['COURIER_TRACKING','RFE_COURIER_TRACKING'].indexOf(this.ACTIVITYCODE)>-1 ){
    let finalCourierId ='';
    if(this.checkProperty( this.petitionDetails ,'finalCourierId')){
      finalCourierId = this.petitionDetails['finalCourierId']
    }else  if(this.checkProperty( this.configDetails ,'defaultCourierId')){
      finalCourierId = this.configDetails['defaultCourierId']
    }

      if(finalCourierId){
      let defaultCourierDetails = _.find( this.courierList ,{"id":finalCourierId})
      _.forEach(this.updateTrackingFormData['items'] ,(item)=>{
        item.courierDetails =defaultCourierDetails;
        this.changedCourierInfo(item);

      });
    }
    }
    },
     uploadToS3MainDocuments( docs  , item){
      let self = this;
             docs = docs.map(
                item =>
                (item = {
                    status:true,
                    name: item.name,
                    file: item.file,
                    document: "",
                    path:'',
                    size:item.size ? item.size : null,
                    mimetype: item.type,
                    uploadedBy:item.uploadedBy?item.uploadedBy:this.checkProperty(this.getUserData,'userId')!=''?this.checkProperty(this.getUserData,'userId'):null,
                    uploadedByName:item.uploadedByName?item.uploadedByName:this.checkProperty(this.getUserData,'name')!=''?this.checkProperty(this.getUserData,'name'):'',
                    uploadedByRoleId:item.uploadedByRoleId?item.uploadedByRoleId:this.getUserRoleId?this.getUserRoleId:null,
                    uploadedByRoleName:item.uploadedByRoleName?item.uploadedByRoleName:this.checkProperty(this.getUserData,'loginRoleName'),
               
})
            );


            if (docs.length > 0) {
                let filIndex = 0;
                this.filesAreuploading = true;
                this.disable_uploadBtn = true;
                item['filesAreuploading'] =true;
                docs.forEach(doc => {
                         
                    let formData = new FormData();
                    formData.append("files", doc.file);
                    formData.append("secureType", "private");
                     formData.append("getDetails", true);
                    
                       
                    this.$store.dispatch("uploadS3File", formData).then(response => {
                         filIndex++;
                         if (filIndex >= this.uploadMainDocuments.length) {
                                this.filesAreuploading = false;
                                this.disable_uploadBtn = false;
                                item['filesAreuploading'] =false;
                            }
                        

                        response.data.result.forEach(urlGenerated => {
                            //alert(JSON.stringify(urlGenerated));

                            Object.assign(urlGenerated, {uploadedOn: moment().format("YYYY-MM-DD"), uploadedBy: self.checkProperty(self.getUserData, 'userId'), uploadedByName: self.checkProperty(self.getUserData, 'name'), uploadedByRoleId: self.getUserRoleId, uploadedByRoleName: self.checkProperty(self.getUserData, 'loginRoleName') });
                    
                            doc.document = urlGenerated;
                            doc.path = urlGenerated["path"];
                            if(_.has(urlGenerated ,'size' )){
                                    doc['size'] = urlGenerated['size'];
                            }
                           //this.uploadMainDocuments.push(doc);
                            urlGenerated.status = true;
                           item['documents'].push( urlGenerated);
                        });

                        
                      
                    });
                
                    
                });
            }

        },

    getCourierList() {
      let postdata = {};

      this.$store.dispatch("getCourierList", postdata).then((response) => {
        // alert(JSON.stringify(response))
        //this.courierList = response;
      });
      //tracking/list
      this.$store
        .dispatch("getList", { data: postdata, path: "/tracking/courierlist" })
        .then((response) => {
          if (this.checkProperty(response, "list")) {
            this.courierList = response.list;
          }
        });
    },
    changedCourierInfo(item) {
      if (item) {
        item["courier"] = "";
        item["courierCode"] = "";
        item["trackingUrl"] = "";

        item["courier"] = this.checkProperty(item, "courierDetails", "name");
        item["courierCode"] = this.checkProperty(
          item,
          "courierDetails",
          "code"
        );
        item["trackingUrl"] = this.checkProperty(
          item,
          "courierDetails",
          "track_url"
        );
      }
    },
    submitForm() {
      this.trackingErrors = "";
      this.$validator.validateAll("trackingform").then((result) => {
       let self =this;
        if (result) {
          let path = "/petition/manage-tracking-details";
          this.updateTrackingLoading = true;
          this.updateTrackingFormData["petitionId"] = this.checkProperty(
            this.petitionDetails,
            "_id"
          );
          if(this.getTenantTypeId != 2){
          this.updateTrackingFormData["notifyPetitioner"] = this.notifyPetitioner
        }

        this.updateTrackingFormData['action'] = self.ACTIVITYCODE;
          
          let postData = _.cloneDeep(this.updateTrackingFormData);

          this.$store
            .dispatch("commonAction", { data: postData, path: path })
            .then((rx) => {
              this.trackingErrors = "";
              this.filesAreuploading = false;
              this.updateTrackingLoading = false;
              this.showToster({ message: rx.message, isError: false });
              this.$emit("updatepetition", "Petition Updates");
              this.hideMe();
            })
            .catch((err) => {
              this.trackingErrors = err;
              this.filesAreuploading = false;
              this.updateTrackingLoading = false;
              //this.showToster({message:err,isError:true });
            });
        }
      });
    },
    hideMe() {
      this.$emit("hideMe");
    },
  },
  watch: {
    showPopup(val) {
      if (!val) this.$emit("hideMe");
    },
  },
  mounted() {
    this.getGlobalConfigDetails();
    this.$store
      .dispatch("getList", { data: {}, path: "/tracking/courierlist" })
      .then((response) => {
        if (this.checkProperty(response, "list")) {
          this.courierList = response.list;
        }

        this.updateTrackingFormData = {
          petitionId: "",
          notifyPetitioner:false,
          action: "COURIER_TRACKING", // "UPDATE_USCIS_RECEIPT_NUMBER",
          items: [
            {
              trackingId: "",
              trackingUrl: "",
              courier: "",
              courierCode: "",
              courierDetails: null,
              sentDate:null
            },
          ],
        };
        this.updateTrackingFormData["petitionId"] = this.checkProperty(
          this.petitionDetails,
          "_id"
        );

        if(['UPDATE_USCIS_RECEIPT_NUMBER','RFE_UPDATE_USCIS_RECEIPT_NUMBER'].indexOf(this.ACTIVITYCODE)>-1 ){
       
          this.updateTrackingFormData = {
            petitionId: "",
            notifyPetitioner:false,
            action: "UPDATE_USCIS_RECEIPT_NUMBER", // "COURIER_TRACKING",
            items: [],
          };

          let benItem = {
            receiptName: "",
            receiptNumber: "",
            documents: [],
            userType: "Beneficiary",
            userName: "Bnf Name",
            filesAreuploading: false,
            receivedDate:null,

          };
          benItem["userName"] = this.checkProperty(
            this.petitionDetails,
            "beneficiaryInfo",
            "name"
          );

          this.updateTrackingFormData["items"].push(benItem);

          if (
            this.checkProperty(this.petitionDetails, "beneficiaryInfo", "maritalStatus") !=1 &&
            this.checkProperty(this.petitionDetails, "dependentsInfo", "spouse") && this.checkProperty(this.petitionDetails.dependentsInfo, "spouse", "firstName")
          ) {
            if (
              this.checkProperty(
                this.petitionDetails["dependentsInfo"]["spouse"],
                "h4Required"
              )
            ) {
              let spouseItem = {
                receiptName: "",
                receiptNumber: "",
                documents: [],
                userType: "Spouse",
                userName: "Bnf Name",
                filesAreuploading: false,
                receivedDate:null,
              };
              spouseItem["userName"] = this.checkProperty(
                this.petitionDetails["dependentsInfo"]["spouse"],
                "name"
              );
              this.updateTrackingFormData["items"].push(spouseItem);
            }
          }

          //child
          if (
            this.checkProperty(this.petitionDetails, "beneficiaryInfo", "maritalStatus") !=1 &&
            this.checkProperty(
              this.petitionDetails,
              "dependentsInfo",
              "childrens"
            )
          ) {
            if (
              this.checkProperty(
                this.petitionDetails["dependentsInfo"],
                "childrens",
                "length"
              ) > 0
            ) {
              _.forEach(
                this.petitionDetails["dependentsInfo"]["childrens"],
                (child) => {
                  if (this.checkProperty(child, "h4Required") && this.checkProperty(child, "firstName")) {
                    let childItem = {
                      receiptName: "",
                      receiptNumber: "",
                      documents: [],
                      userType: "Children",
                      userName: "Bnf Name",
                      filesAreuploading: false,
                      childrenId: "",
                      receivedDate:null,
                    };
                    childItem["childrenId"] = this.checkProperty(child, "_id");
                    childItem["userName"] = this.checkProperty(child, "name");
                    this.updateTrackingFormData["items"].push(childItem);
                  }
                }
              );
            }
          }
        }

        this.updateTrackingFormData['action'] =this.ACTIVITYCODE;

        this.setDefaultCouriar()
        this.$modal.show("trackingDetailsForm");
      });
  },
  data: () => ({
    configDetails:null,
    uploadMainDocuments:[],
    disable_uploadBtn:false,
      currentDate: new Date(),
      notifyPetitioner:false,
    updateTrackingFormData: null,
    updateTrackingLoading: false,
    trackingErrors: "",
    filesAreuploading: false,
    editFilngFee: false,
    uploading: false,
    courierList: [],
    tracking: { documents: [], receiptNumber: null, receiptName: null },
    uscisdocument: [],
    dueDate: null,
    usciscomments: "",
    trackingdoc: [],
    issuedDate: null,
    receivedDate: null,
    dueDate: null,
    openDate: new Date().setFullYear(new Date().getFullYear()),
    startEligibleDate: new Date().setFullYear(new Date().getFullYear()),
    updateTrackingPopup: false,
    updateUSCISstatusPopup: false,
    usciscUpdateStatusError: "",
    usciscUpdating: false,
    actioncomment: "",
    paralegalformerrors: "",
    disabled_btn: false,
    loading: false,
    showPopup: false,
    comments: false,
    formerrors: {
      msg: "",
    },
    uploading: false,
    validateLcaFiles: true,
    updateLca: false,
    filedDate: null,
    certifiedDate: null,
    lcastatuses: [],
    lcaDocuments: [],
    masterSocList: [],
    lcastatusSelected: null,
    documents: [],
    showDataPicker: true,
    number: "",
    updatingLca: false,
    lcaUpdateForm: false,
  }),
  props: {
    ACTIVITYCODE: {
      type: String,
      default: null,
    },
    petitionDetails: {
      type: Object,
      default: null,
    },
  },
};
</script>
