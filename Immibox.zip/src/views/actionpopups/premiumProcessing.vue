
<template>
  <modal
    name="premiumProcessingPopupModal"
    classes="v-modal-sec"
    :min-width="200"
    :min-height="200"
    :scrollable="true"
    :reset="true"
    width="400px"
    height="auto"
  >
    <div class="v-modal profile_details_modal">
      <div class="popup-header fromDetailsPage">
        <h2 class="popup-title">Update Premium Processing</h2>
        <span  @click="hideMe()">
          <em class="material-icons">close</em>
        </span>
      </div>

      <form @submit.prevent data-vv-scope="premiumprocessingForm">
        <div class="form-container">
          <div class="vx-row" @click="premiumProcessingFormErrors = ''">
            <div class="vx-col w-full">
              <div
                class="form_group mb-5"
                @click="
                  documents = [];
                  premiumProcessingFilesUploading = false;
                "
              >
                <label class="form_label">Documents</label>
                <div class="vs-component relative mb-1">                  
                  <file-upload
                    :multiple="false"
                    :hideSelected="true"
                    v-model="documents"
                    class="file-upload-input file_upload justify-center"
                    name="documentsUpload"
                    :accept="allDocEntity"
                    @input="uploadPremiumProcessingDocuments(documents)"
                  >
                    <img
                      class="file-icon"
                      src="@/assets/images/main/file-upload.svg"
                    />
                    Upload<em v-if="premiumProcessing && false">*</em>
                  </file-upload>
                  <span class="loader" v-if="premiumProcessingFilesUploading"
                    ><img src="@/assets/images/main/loader.gif"
                  /></span>
                  <!-- <span v-if="uploading" class="loader"><img src="@/assets/images/main/loader.gif"></span>-->
                 
                </div>
                <input  type="hidden" data-vv-as="Document" name="document"  v-model="premiumProcessingFiles" />

                <ul
                  class="uploaded-list note_uploads"
                  v-if="checkProperty(premiumProcessingFiles, 'length') > 0"
                >
                  <template v-for="(file, fileindex) in premiumProcessingFiles">
                    <!--- @click="removeLcaDocument(fileindex, premiumProcessingFiles)" --->
                    <vs-chip
                      type="button"
                      @click="removePremiumProcessingFiles(fileindex)"
                      :key="fileindex"
                      v-if="file.status !== false"
                      closable
                      >{{ file.name }}
                    </vs-chip>
                  </template>
                </ul>
              </div>
            </div>

            <div class="vx-col w-full">
              <div class="form_group">
                <label class="form_label">Comments<em v-if="false">*</em></label>
                <!-- <vs-textarea
                  data-vv-as="Comments"
                  v-validate="'required'"
                  v-model="premiumProcessingComment"
                  name="comments"
                  class="w-full"
                /> -->
                 <ckeditor data-vv-as="Comments" v-model="premiumProcessingComment"  name="comments" class="w-full" :editor="editor" :config="editorConfig"></ckeditor>
                 <!-- <span class="text-danger text-sm"  v-show="errors.has('premiumprocessingForm.comments')">Comments are required</span> -->
              </div>
            </div>

            <div class="vx-col w-full pp-col mar0">
              <!-- <vs-checkbox  id="premium" name="premiumProcessing"  v-model="premiumProcessing"   
                         >Premium Processing</vs-checkbox> -->

              <!-- <span class="text-danger text-sm"  v-show="errors.has('finalDeterminationFromDOL')">{{ errors.first("finalDeterminationFromDOL") }}</span> -->
            </div>
          </div>
          <div v-show="premiumProcessingFormErrors">
            <vs-alert
              color="warning"
              class="warning-alert reg-warning-alert no-border-radius"
              icon-pack="IntakePortal"
              icon="IP-information-button"
              active="true"
              >{{ premiumProcessingFormErrors }}</vs-alert
            >
          </div>
        </div>
        <div class="popup-footer relative">
          <span class="loader" v-if="updatingPremiumProcessing"
            ><img src="@/assets/images/main/loader.gif"
          /></span>

          <vs-button
            color="dark"
            @click="hideMe()"
            class="cancel"
            type="filled"
            >Cancel</vs-button
          >
          <vs-button
            color="success"
            :disabled="
              updatingPremiumProcessing || premiumProcessingFilesUploading
            "
            @click="submitForm()"
            class="save"
            type="filled"
            >Update
          </vs-button>
        </div>        
      </form>
    </div>
  </modal>
</template>
<script>
import moment from "moment";
import FileUpload from "vue-upload-component/src";
import { EyeIcon } from 'vue-feather-icons'
import docType from "@/views/common/docType.vue"
import Vue from 'vue';
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';

export default {
    components: {
    docType,
    EyeIcon,
    FileUpload
  },
  methods: {
    removePremiumProcessingFiles(index){
      this.premiumProcessingFiles.splice(index ,1)
    },

    uploadPremiumProcessingDocuments(model) {

            let temp_count = 0;
            
          
            this.disabled_btn = true;
            let mapper = model.map(
                item =>
                (item = {
                    name: item.name,
                    file: item.file ? item.file : null,
                    size:item.size ? item.size : null,
                    path: item.path ? item.path : "",
                    status: item.status?true:false,
                    mimetype: item.type ? item.type : item.mimetype,
                    //comment:this.actioncomment?this.actioncomment:''
                })
            );
             //this.$vs.loading();
             this.premiumProcessingFilesUploading =true;
             if (mapper.length > 0) {
              
                mapper.forEach((doc, index) => {
                    let formData = new FormData();
                    formData.append("files", doc.file);
                    formData.append("secureType", "private");
                    formData.append("getDetails", true);
                    this.$store.dispatch("uploadS3File", formData).then(response => {
                        temp_count++;
                        response.data.result.forEach(urlGenerated => {

                            
                            doc.status = true;
                            doc.path = urlGenerated["path"];
                            if(_.has(urlGenerated ,'size' )){
                                doc['size'] = urlGenerated['size'];
                            }
                            delete doc.file;
                             this.premiumProcessingFiles =[];
                            this.premiumProcessingFiles.push(doc);
                            mapper[index] = doc;
                            if (temp_count >= mapper.length) {
                                this.disabled_btn = false;
                               // this.$vs.loading.close();
                                this.documents =[];
                                  this.premiumProcessingFilesUploading =false;
                            }
                            

                        });
                    });

                });
                model.splice(0, mapper.length, ...mapper);
            }
    },
    submitForm() {
       this.$validator.validateAll('premiumprocessingForm').then((result) => {
         let self =this;
            if (result) {
              let postData ={
                petitionId :self.checkProperty(self.petitionDetails ,'_id'),
                documents:[],
                today: moment().format("YYYY-MM-DD"),
                comments:self.premiumProcessingComment,
                typeName:self.checkProperty(self.petitionDetails ,'typeDetails','name'),
                subTypeName:self.checkProperty(self.petitionDetails ,'subTypeDetails','name'),
                premiumProcessing: self.premiumProcessing
                
              }
              postData['documents'] = self.premiumProcessingFiles;
              this.updatingPremiumProcessing =true;
              
               this.$store
              .dispatch("commonAction", {"data":postData ,"path":"/petition/manage-premium-process"})
              .then(response => {
               
                this.updatingPremiumProcessings =false;
                this.hideMe();
                this.showToster({message:response.message,isError:false });
                this.$emit("updatepetition", "Case Details");

                                
                                
              })
              .catch((error)=>{
                this.premiumProcessingFormErrors =error;
                this.updatingPremiumProcessing =false;
              })
       
       

              
            }
          });

    },
    hideMe() {
      this.$emit("hideMe");
    },
  },
  watch: {
    showPopup(val) {
      if (!val) this.$emit("hideMe");
    },
  },
  mounted() {
    this.$modal.show("premiumProcessingPopupModal");
    this.premiumProcessing = !this.petitionDetails.premiumProcessing

  },
  data: () => ({
    editor: ClassicEditor,
    editorConfig: {
        toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
    },
    loading: false,
    showPopup: false,
    comments: false,
    formerrors: {
      msg: "",
    },
     documents:[],

    premiumProcessingFormErrors:'',
    premiumProcessingComment:'',
    premiumProcessing:false,
    updatingPremiumProcessing:false,
    premiumProcessingFiles:[],
    premiumProcessingFilesUploading:false,
  }),
  props: {
    caseNumber: {
      type: String,
      default: null,
    },
    isCaseNumberEdit: {
      type: Boolean,
      default: false,
    },
    petitionDetails: {
      type: Object,
      default: null,
    },
  },
};
</script>