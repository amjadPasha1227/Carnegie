<template>
    <div>
        <template>
        <modal
        name="manageLcaPopupModal"
        classes="v-modal-sec linklca"
        :min-width="200"
        :min-height="200"
        :scrollable="true"
        :reset="true"
        width="1300px"
        height="auto"
        >
        <div class="v-modal">
        <div class="popup-header fromDetailsPage"> 
        <h2 class="popup-title">
          {{popUpTitle}}

        </h2>
        <span @click="$modal.hide('manageLcaPopupModal');hideMe()">
          <em class="material-icons">close</em>
        </span>
        </div>
        <form data-vv-scope="newCaseNumberForm" @submit.prevent @keydown.enter.prevent>
            <div class="popup_info" v-if="checkProperty(selectedCaseNos,'length') >0" @click="formErrors = ''">
                <span><eye-icon size="1.5x" class="custom-class"></eye-icon></span>
                <div class="info_list">
                    <ul v-if="checkProperty(selectedCaseNos,'length') >0">
                        <template v-for="(usr, usrIndx) in selectedCaseNos">
                            <li :key="usrIndx">{{ usr["caseNo"] }}</li>
                        </template>
                    </ul>
                </div>
            </div>
          <div class="linklca_form" @click="formErrors=''">
            <div class=" linklca_form_header" v-if="['LINK_LCA'].indexOf(ACTIVITYCODE) > -1">
                <!-- <label for class="form_label">{{ dropdownTitle }}<em>*</em></label> -->
                <div class="search">
                    <vs-input icon-pack="feather" icon="icon-search"
                        :placeholder="'Search by ID/Client/LCA No/Location/Job Title/SOC Code'"
                        class="is-label-placeholder" v-model.lazy="searchString" @input="casesSearch" />
                </div>
                <button 
                    class="light-blue-btn primary-btn"
                    @click="createLCA=true;reloadList()" 
                    >New LCA</button>
            </div>
            <div class="form-container pad0">
                
                <div class="accordian-table custom-table no-wrap relative">
                    <div class="search_LCA" v-if="!checksearchString"> 
                        <img src="@/assets/images/main/no-data.jpg"   />
                        <label>Search by ID/Client/LCA No/Location/Job Title/SOC Code </label>
                    </div>
                  
                    <NoDataFound ref="NoDataFoundRef" :loading="isListLoading" v-if="casesList.length == 0 && checksearchString" content=""
                    :heading="'No Results Found'" type='petitions' />
                    <template v-if="casesList.length > 0 && checksearchString">
                    <vs-table :data="casesList ">
                        <template v-if="casesList.length > 0" slot="thead">     
                            <vs-th class="mw-280">
                                <a @click="sortMe('caseNo')" v-bind:class="{'sort_ascending':sortKeys['caseNo']==1, 'sort_descending':sortKeys['caseNo']!=1}">Case No </a>            
                            </vs-th>
                            <vs-th v-if=" [50].indexOf(getUserRoleId) <= -1  &&  getTenantTypeId !=2 && !isFromPetition"> Petitioner Name </vs-th>
                            <vs-th > Beneficiary Name </vs-th>
                            <vs-th> Case(s) </vs-th>
                            <vs-th> Requested Date </vs-th>
                            <vs-th>
                                <a @click="sortMe('updatedOn')"
                                v-bind:class="{ 'sort_ascending': sortKeys['updatedOn'] == 1, 'sort_descending': sortKeys['updatedOn'] != 1 }">
                                Last Updated</a>
                            </vs-th>
                            <vs-th>
                                <a @click="sortMe('statusName')"
                                    v-bind:class="{ 'sort_ascending': sortKeys['statusName'] == 1, 'sort_descending': sortKeys['statusName'] != 1 }">
                                    Status
                                </a>
                            </vs-th>
                        </template>
                        <template slot-scope="{ data }">
                            <vs-tr :data="tr" :key="indextr" v-for="(tr, indextr) in data" class="vs-table--tr">
                                <vs-td>
                                    <vs-checkbox
                                        @change="selectForLca(tr)" :name="'selected_'+tr.index"
                                        v-model="tr.selectedForLca" class=""></vs-checkbox>
                                    <div  > {{ checkProperty(tr, 'caseNo') }} </div>
                                </vs-td>
                                <vs-td v-if="[50].indexOf(getUserRoleId) <= -1  &&  getTenantTypeId !=2 && !isFromPetition ">
                                    <div  > {{ checkProperty(tr, 'petitionerDetails','name') }} </div>
                                </vs-td>
                                <vs-td >
                                    <template v-if="checkProperty(tr ,'benificiaryNameList' ,'length') >0 ">
                                        {{tr.benificiaryNameList[0] }}
                                    </template>
                                    <div class="menu_dropdown flexible_actions email_list right ml-2" v-if="checkProperty(tr ,'benificiaryNameList' ,'length') >1">
                                            <em class="more_count ">
                                            +{{ tr['benificiaryNameList'].length-1 }}
                                            </em>
                                            <div class="menu_list_wrap" v-if="checkProperty(tr ,'benificiaryNameList' ,'length') >1">
                                            <ul class="">
                                                <VuePerfectScrollbar ref="mainSidebarPs" class="scroll-area--main-sidebar"
                                                :settings="settings" @ps-scroll-y="psSectionScroll">
                                                <template v-for="( name ,eind ) in tr['benificiaryNameList']">
                                                    <li v-if="eind>0" :key="eind">{{ name }}</li>
                                                </template>
                                                </VuePerfectScrollbar>
                                            </ul>
                                            </div>
                                        </div>
                                    </vs-td>
      

                                    <vs-td>
                                        <div class="cursor-pointer subtypes__list">
                                        <ul>
                                            <li>
                                            {{ (checkProperty(tr, 'petitionList') && checkProperty(tr, 'petitionList', 'length') > 0) ?
                                                checkProperty(tr, 'petitionList')[0]['caseNo']
                                                : ''
                                            }}</li>
                                            <li v-if="checkProperty(tr, 'petitionList', 'length') > 1">
                                            <div class="menu_dropdown flexible_actions right ml-2">
                                                <em class="more_count ">
                                                +{{ (checkProperty(tr, 'petitionList', 'length')) - 1 }}
                                                </em>
                                                <div class="menu_list_wrap">
                                                <ul class="">
                                                    <VuePerfectScrollbar ref="mainSidebarPs" class="scroll-area--main-sidebar"
                                                    :settings="settings" @ps-scroll-y="psSectionScroll">
                                                    <template v-for="(user, indx ) in tr['petitionList']">
                                                        <li :key="indx" v-if="indx > 0" > {{
                                                        checkProperty(user
                                                            , 'caseNo') }}</li>
                                                    </template>
                                                    </VuePerfectScrollbar>
                                                </ul>
                                                </div>
                                            </div>
                                            </li>
                                        </ul>
                                        </div>
                                    </vs-td>

                                    <vs-td class="td_label">
                                        <div  >
                                        {{ checkProperty(tr, 'createdOn') | formatDate }}
                                        </div>
                                    </vs-td>
                                    <vs-td>
                                        <div >
                                        <template v-if="checkProperty(tr, 'updatedOn')">
                                            {{ checkProperty(tr, 'updatedOn') | formatDate }}
                                        </template>
                                        <template v-else-if="checkProperty(tr, 'createdOn')">
                                            {{ checkProperty(tr, 'createdOn') | formatDate }}
                                        </template>
                                        </div>
                                    </vs-td>
                                    <vs-td>
                                        <span   v-bind:class="{
                                        'lca_created': checkProperty(tr, 'statusDetails', 'id') == 1,
                                        'lca_filed': checkProperty(tr, 'statusDetails', 'id') == 2,
                                        'lca_certified': checkProperty(tr, 'statusDetails', 'id') == 3,
                                        'lca_denied': checkProperty(tr, 'statusDetails', 'id') == 4,
                                        'lca_request_for_withdrawal': checkProperty(tr, 'statusDetails', 'id') == 5,
                                        'lca_withdrawn': checkProperty(tr, 'statusDetails', 'id') == 6,
                                        'lca_expired': checkProperty(tr, 'statusDetails', 'id') == 7,
                                        'lca_rfe': checkProperty(tr, 'statusDetails', 'id') == 8,
                                        'status_draft': checkProperty(tr, 'statusDetails', 'id') == 99,
                                        }">{{ tr.statusDetails.name }}</span>

                                    </vs-td>
                            </vs-tr>
                        </template>
                    </vs-table>
                    </template>
                </div>            
                <div class="text-danger text-sm formerrors my-2" v-show="formErrors">
                    <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius"
                        icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ formErrors }}</vs-alert>
                </div>
            </div>

            <div class="popup-footer relative">
                <span class="loader" v-if="loading"><img src="@/assets/images/main/loader.gif" /></span>
                <vs-button color="dark" @click="showPopup = false" class="cancel" type="filled">Cancel</vs-button>


                <vs-button :disabled="loading || !checkSubmitBtn || checkProperty( casesList,'length')<=0" color="success" @click="submitForm()" class="save" type="filled">
                    <template v-if="isFromPetition && lcaId != ''">Change LCA</template>
                    <template v-else>Link with Case</template>

                </vs-button>

            </div>
          </div>
        </form>
      </div>
        </modal>
        </template>
        <template>
        <div v-if="createLCA" class="custom_modal_sec documents__modal custom_modal-v2" :class="{ modalopen: createLCA }">
            <div class="custom_modal_overlay"></div>
            <div class="custom_modal_cnt">
                <div class="modal_title">
                <h2>New LCA </h2>
                <span class="close" @click="createLCA = false;searchString=''"><x-icon size="1.5x"></x-icon></span>
                </div>
                <RequestLCA v-bind:petitionDetails="null" v-bind:workFlowDetails="null" 
                @editLca="false" :isFromLCAList="true" :callFromActionPopup="true" @changeLCA="changeLCA" @lcaRequestCancel="createLCA = false;searchString=''"/>

            </div>
        </div>
    </template>
    </div>
 
</template>
<script>
import RequestLCA from "@/views/RequestLCA";
import moment from "moment";
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import * as _ from "lodash";
import { XIcon, MoreVerticalIcon } from 'vue-feather-icons'
import Vue from 'vue';
Vue.use(CKEditor);
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import NoDataFound from "@/views/common/noData.vue";

export default {
    methods: {
        reloadList(){
            if(this.checkProperty(this.casesList,'length')>0){
                _.forEach(this.casesList ,(item)=>{
                    item['selectedForLca']=false
                });
            }
            
        },
        changeLCA(val){
            let LcaId = val;
            this.createLCA = false;
            this.searchString=''
            this.submitForm(true, val)
        },
        // createLca(){
        //     this.showPopup = false;
        //     this.$modal.hide('manageLcaPopupModal')
        //     this.$emit('openRequestLCA')
        // },
        psSectionScroll(){},
        getLCADetails() {
            // this.$vs.loading();
            this.$store.dispatch("fetchLcaDetails", this.lcaId)
                .then((response) => {
                    // this.$vs.loading.close();
                    this.lcaInfo = response.data.result;
                    if (this.isFromPetition) {
                        this.selectedCaseNos = [{ '_id': this.lcaInfo['_id'], 'caseNo': this.lcaInfo['_id', 'caseNo'] }]
                    } else {
                        if (this.checkProperty(this.lcaInfo, 'petitionList') && this.checkProperty(this.lcaInfo, 'petitionList', 'length') > 0) {
                            this.selectedCaseNos = this.checkProperty(this.lcaInfo, 'petitionList')
                        }
                    }
                    if (!this.isFromPetition) {
                        this.getCasesList()
                    }
                })
                .catch((error) => {
                    // this.$vs.loading.close();
                    this.showToster({ message: error, isError: true });
                    this.$emit("updatepetition", "LCA");
                });
        },
        sortMe(sort_key = '') {
            if (sort_key != '') {
                this.sortKeys[sort_key] = this.sortKeys[sort_key] == 1 ? -1 : 1
                this.sortKey = {};
                this.sortKey = { "path": sort_key, "order": this.sortKeys[sort_key] }
                localStorage.setItem('lca_sort_key', sort_key);
                localStorage.setItem('lca_sort_value', this.sortKey[sort_key]);
                this.getLcaList();
            }
        },
        selectForLca(tr){
            self = this;
            if(this.checkProperty(tr ,'selectedForLca') && self.checkProperty(tr,'_id') && this.checkProperty(this.casesList,'length')>0 ){
                _.forEach( this.casesList,(item) => {
                    if(item['_id'] != self.checkProperty(tr,'_id') ){
                        item['selectedForLca'] = false;
                    }
                })
            }
        },
        getCasesList() {
            let postdata = { matcher: { searchString: this.searchString } }
            if(this.checkProperty(this.lcaInfo,'petitionerDetails','_id'))
            {
                postdata.matcher['petitionerIds']=[this.checkProperty(this.lcaInfo,'petitionerDetails','_id')];
            }
            this.$store.dispatch("commonAction", { "data": postdata, "path": 'petition/get-petition-list-for-lca' }).then(response => {
                this.casesList = response;


            }).catch(() => {

            })
        },
        getLcaList() {
            let obj = {
                page: 1,
                perpage: 1000,
                sorting: this.sortKey,
                matcher: {
                    searchString: this.searchString.trim(),
                    petitionerIds: [],
                    statusIds: [1, 2, 3],
                    // getMasterDataOnly: true,
                }
            };
            if (this.checkProperty(this.petitionDetails, 'petitionerDetails', '_id')) {
                obj['matcher']['petitionerIds'] = [this.checkProperty(this.petitionDetails, 'petitionerDetails', '_id')]
            }
            this.updateLoading(true);
            this.$store.dispatch("fetchlcalist", obj).then(response => {
               this.casesList  = [];
               this.updateLoading(false);
               setTimeout(()=>{
                this.updateLoading(false);
               })
                let list = _.cloneDeep(response.data.result.list);
                let tempList = [];
                if(this.lcaId){
                    tempList = _.filter(list,(ite)=>{
                     return ite['_id'] != this.lcaId
                    })
                }else{
                    tempList = _.cloneDeep(list)
                }
                let modifiedList = [];
                _.forEach(tempList ,(item)=>{
                    item =Object.assign(item,{ 'selectedForLca':false});
                    modifiedList.push(item);

                });
                if(modifiedList && this.checkProperty(modifiedList,'length')>0){
                    _.forEach(modifiedList,(item)=>{
                        if(_.has(item,'benificiaryName') && this.checkProperty(item, 'benificiaryName')){
                        let tempWord = item['benificiaryName'].split(',')
                        if(tempWord){
                            Object.assign(item,{'benificiaryNameList':tempWord})
                        }
                        }
                    })
                    this.casesList = _.cloneDeep(modifiedList);
                }
               
            }).catch(() => {
                this.updateLoading(false);
            })
        },


        submitForm(callFromLca = false, lCAId = '') {

            this.$validator.validateAll("assignmentForm").then((result) => {
                let findItem = _.find(this.casesList,{ 'selectedForLca':true})
                if (findItem || callFromLca) {

                        let postData = {
                            petitionIds: [],
                            "removePetitionIds": [],
                          
                            "lcaId": this.lcaId,
                            "caseNo": '',
                            today: moment().format('YYYY-MM-DD')
                        };
                        postData.petitionIds = [this.checkProperty(this.petitionDetails, '_id')]
                        if (this.checkProperty(findItem, '_id')) {
                            postData['lcaId'] = findItem['_id']
                            postData['caseNo'] = findItem['caseNo']
                        }
                        if(lCAId){
                            postData['lcaId'] = this.checkProperty(lCAId,'_id');
                            postData['caseNo'] = this.checkProperty(lCAId,'caseNo');
                        }
                        if (this.checkProperty(this.lcaInfo, 'caseNo')) {
                            postData['oldCaseNo'] = this.lcaInfo['caseNo']
                        }

                        let path = "/petition/manage-lca";
                        this.loading = true;
                        this.$store
                            .dispatch("commonAction", { "data": postData, "path": path })
                            .then(response => {
                                this.showPopup = false;
                                this.$modal.hide('manageLcaPopupModal')
                                this.openAtornyPopup = false;
                                this.showToster({ message: response.message, isError: false });
                                this.loading = false;
                                this.$emit("updatepetition", '');
                                this.$emit("hideMe");
                                this.createLCA = false;
                            })
                            .catch((error) => {

                                this.formErrors = error;
                                this.loading = false;
                            })
                }else{
                    this.showToster({ message: 'Please select an LCA', isError: true });
                    //this.formErrors = 'Select LCA'
                   
                }
            });
        },
        hideMe() {
            this.$emit("hideMe");
        },
        casesSearch(searchValue) {
            // let text = this.searchString.trim();
              this.casesList =[];
            if(this.checksearchString){
                //this.searchString = searchValue;
                if (!this.isFromPetition && this.lcaId != '') {
                clearTimeout(this.debounce)
                    this.debounce = setTimeout(() => {
                    this.getCasesList()
                    }, 900)
                }
                if (this.isFromPetition) {
                clearTimeout(this.debounce)
                this.debounce = setTimeout(() => {
                    this.getLcaList()
                }, 900)        
                }
            }else{
                this.casesList = [];
            }
            
        },

    },
    watch: {
        showPopup(val) {
            if (!val) this.$emit("hideMe");
            if(!val){
                this.$modal.hide('manageLcaPopupModal');
            }
            
        },
        // searchtxt(){
        //     clearTimeout(this.debounce)
        //         this.debounce = setTimeout(() => {
        //             this.getLcaList()
        //         }, 900)
        // }
    },
    mounted() {
        this.updateLoading(false);
             this.casesList = [];
             setTimeout(() =>{
                this.updateLoading(false);
               })
        this.createLCA = false;
        this.showPopup = true;
        this.$modal.show('manageLcaPopupModal');
        this.searchString="";
        if (!this.isFromPetition && this.lcaId != '') {
            this.getLCADetails()
        }
        // if (this.isFromPetition) {
        //     this.dropdownTitle = 'LCA No'
        //     this.lcaInfo = this.lcaDetails
        //     if (this.lcaId != '') {
        //         this.getLCADetails()
        //     }
        //     this.getLcaList()
        // };
        this.sortKeys = {
            'caseNo': 1,
            'createdByName': 1,
            "statusName": 1,
            "updatedOn": -11,
            createdOn: -1
        },

        this.sortKey['updatedOn'] = 1;

        if (localStorage.getItem('lca_sort_key') && localStorage.getItem('lca_sort_value') && localStorage.getItem('lca_sort_value') >= -1) {
            this.sortKey = {};
            this.sortKey[localStorage.getItem('lca_sort_key')] = parseInt(localStorage.getItem('lca_sort_value'));
            this.sortKeys[localStorage.getItem('lca_sort_key')] = this.sortKey[localStorage.getItem('lca_sort_key')];
        }
    },
    data: () => ({
        settings: { 
            swipeEasing: true,
        },
        isListLoading:false,
        createLCA:false,
        sortKeys: {},
        sortKey: {},
        searchtxt:'',
        debounce:null,
        editor: ClassicEditor,
        editorConfig: {
            toolbar: ['bold', 'italic', '|', 'undo', 'redo', 'NumberedList', 'BulletedList',],
        },
        loading: false,
        comments: null,
        showPopup: false,
        formErrors: null,
        lcaInfo: null,
        casesList: [],
        linkedCaseList: [],
        selectedCaseNos: [],
        dropdownTitle: 'Case No',
        searchString: ''

    }),
    props: {
        ACTIVITYCODE: {
            type: String,
            default: null,
        },
        rolesList: [],
        popUpTitle: {
            type: String,
            default: null,
        },
        petitionDetails: {
            type: Object,
            default: null,
        },
        lcaId: {
            type: String,
            default: '',
        },
        lcaDetails: {
            type: Object,
            default: '',
        },
        isFromPetition: {
            type: Boolean,
            default: null,
        },


    },
    components:{
        XIcon,
        NoDataFound,
    MoreVerticalIcon,
        RequestLCA,
        VuePerfectScrollbar
    },
    computed:{
        checkSubmitBtn(){
           if( _.find( this.casesList, {'selectedForLca':true })){
            return true;

           }else{
            return false
           }
        },
        checksearchString(){
            let returnVal = false;
            let text = this.searchString.trim();
            if(text.length>=1){
                returnVal = true;
            }
            return returnVal
        }
        
    }
};
</script>
  