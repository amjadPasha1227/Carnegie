<template>
  <modal
    name="setDeadlinePopupModal"
    classes="v-modal-sec"
    :min-width="200"
    :min-height="200"
    :scrollable="true"
    :reset="true"
    width="400px"
    height="auto"
  >
    <div class="v-modal profile_details_modal">
      <div class="popup-header fromDetailsPage">
        <h2 class="popup-title">Update Deadline</h2>
        <span @click="hideMe()">
          <em class="material-icons">close</em>
        </span>
      </div>
      <div
        class="i94alert"
        v-if="petitionDetails.subTypeDetails.id != 15 && 
          petitionDetails.beneficiaryInfo &&
          petitionDetails.beneficiaryInfo.I94ExpiryDate
        "
      >
        <p>
          I-94 expiry date for this petition is
          {{ petitionDetails.beneficiaryInfo.I94ExpiryDate | formatDate }}
        </p>
      </div>
      <form @submit.prevent data-vv-scope="deadlineForm">
        <div class="form-container pb-0">
          <div class="vx-row" @click="deadLineformErrors = ''">
            <div class="vx-col w-full">
              <div class="form_group">
                <label class="form_label">Deadline Date<em>*</em></label>
                <div class="vs-component">
                  <datepicker
                    :format="customFormatter"
                    :typeable="true"
                    name="DeadlineDate"
                    :disabled-dates="{ to: new Date() }"
                    v-validate="'required'"
                    v-model="deadlineDate"
                    data-vv-as="Deadline Date"
                    placeholder="MM/DD/YYYY"
                  ></datepicker>
                  <span
                    class="text-danger text-sm"
                    v-show="errors.has('deadlineForm.DeadlineDate')"
                  >
                    {{ errors.first("deadlineForm.DeadlineDate") }}
                  </span>
                </div>
              </div>
            </div>
          </div>
          <div v-show="deadLineformErrors">
            <vs-alert
              color="warning"
              class="warning-alert reg-warning-alert no-border-radius"
              icon-pack="IntakePortal"
              icon="IP-information-button"
              active="true"
              >{{ deadLineformErrors }}</vs-alert
            >
          </div>
        </div>
        <div class="popup-footer relative">
          <!--<span class="loader" v-if="settingDeadLine" ><img src="@/assets/images/main/loader.gif"></span>-->
          <vs-button color="dark" @click="hideMe()" class="cancel" type="filled"
            >Cancel</vs-button
          >
          <vs-button
            color="success"
            :disabled="settingDeadLine"
            @click="submitForm()"
            class="save"
            type="filled"
            >Submit</vs-button
          >
        </div>
      </form>
    </div>
  </modal>
</template>
<script>
import moment from "moment";
import Datepicker from "vuejs-datepicker-inv";

export default {
    components: {
    Datepicker,
  },
  methods: {
    submitForm() {
      this.$validator.validateAll("deadlineForm").then((result) => {
        let self = this;
        
       
       //this.deadlineDate = 
        if (result) {


          let today = moment()
          let deadlineDate =  moment(self.deadlineDate);
           let dif = deadlineDate.diff(today,'days');
           if(dif<0){
           // self.deadlineDate = null;
           self.deadLineformErrors = "Select Only future Date";
            return false;
           }
          
           self.deadLineformErrors ='';
          let postData = {
            petitionId: self.checkProperty(self.petitionDetails, "_id"),
            today: moment().format("YYYY-MM-DD"),
            typeName: self.checkProperty(self.petitionDetails, "typeDetails", "name"),
            subTypeName: self.checkProperty(
              self.petitionDetails,
              "subTypeDetails",
              "name"
            ),
            deadlineDate: moment(self.deadlineDate).format("YYYY-MM-DD"),
          };
          this.settingDeadLine = true;
             let path ="/petition/update-deadline";
          if(this.checkProperty(this.petitionDetails, "typeDetails" ,'id') == 3 &&  [15].indexOf(this.checkProperty(this.petitionDetails,'subTypeDetails', 'id' )) >-1){
            path ="/perm/update-deadline"
          }

          this.$store
            .dispatch("commonAction", {
              data: postData,
              path: path,
            })
            .then((response) => {
              this.settingDeadLine = false;
              
              this.showToster({ message: response.message, isError: false });
            
                let tabName = this.getPetitionTab;
                this.$emit("updatepetition", tabName);
            
              this.hideMe()
            })
            .catch((error) => {
              this.settingDeadLine = false;
              this.deadLineformErrors = error;
            });
        }
      });
    },
    hideMe() {
      this.$emit("hideMe");
    },
  },
  watch: {
    showPopup(val) {
      if (!val) this.$emit("hideMe");
    },
  },
  mounted() {
    this.$modal.show("setDeadlinePopupModal");
    if(this.checkProperty(this.petitionDetails, "deadlineDate")){

   
    this.deadlineDate = moment(
      this.checkProperty(this.petitionDetails, "deadlineDate")
    ).format("YYYY-MM-DD");
    }
  },
  data: () => ({
    settingDeadLine: false,
    deadLineformErrors: "",
    deadlineDate:null,
    formerrors: {
      msg: "",
    },
  }),
  props: {
    petitionDetails: {
      type: Object,
      default: null,
    },
  },
};
</script>
