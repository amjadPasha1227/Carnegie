<template>
    <vs-popup
      class="holamundo main-popup"
      :title="popUpTitle"
      :active.sync="showPopup"
    >
    
      <form data-vv-scope="assignmentForm" class="relative" @submit.prevent @keydown.enter.prevent>
        
        <div
          class="popup_info"
          v-if="usersList.length > 0"
          @click="formErrors = ''"
        >
          <span><eye-icon size="1.5x" class="custom-class"></eye-icon></span>
          <div class="info_list">
            <ul v-if="usersList.length > 0">
              <template v-for="(usr, usrIndx) in usersListReviewrsRolesList">
                <li :key="usrIndx">{{ usr["roleName"] }}</li>
              </template>
            </ul>
          </div>
        </div>
        <div class="form-container">
          <div class="vx-row" >
            <div class="vx-col w-full" v-if="usersList.length > 0 && ['CASE_APPROVED' ,'SUPERVISOR_FORMS_REVIEW' ,'SUBMIT_TO_USCIS'].indexOf(ACTIVITYCODE)<=-1">
              <div class="form_group">
                <label for class="form_label">User<em>*</em></label>             
                <div class="con-select w-full select-large">
                  <multiselect
                    name="users"
                    v-model="selectedUser"
                    :close-on-select="true"
                    v-validate="'required'"
                    :multiple="false"
                    :show-labels="false"
                    @input="selectUesr"
                    label="tempName"
                    data-vv-as="User"
                    placeholder="Select User"
                    :options="usersList"
                    :searchable="true"
                    :allow-empty="false"
                  >
                    <template slot="selection" slot-scope="{ values, isOpen }">
                      <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} selected</span
                      >
                      <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                      ></span>
                    </template>
                  </multiselect>
                </div>
  
                <span
                  class="text-danger text-sm"
                  v-show="errors.has('assignmentForm.users')"
                  >{{ errors.first("assignmentForm.users") }}</span
                >
              </div>
            </div>
  
            <div class="vx-col w-full">
              <div class="form_group mb-4">
                <label class="form_label">Comments<em>*</em></label>
                <!-- <vs-textarea
                  data-vv-as="Comments"
                  v-validate="'required'"
                  v-model="comments"
                  name="comments"
                  class="w-full mb-5"
                /> -->
                <ckeditor  data-vv-as="Comments"
                  v-validate="'required'"
                  v-model="comments"
                  name="comments"
                  class="w-full mb-5" :editor="editor" :config="editorConfig"></ckeditor>
                <span
                  class="text-danger text-sm"
                  v-show="errors.has('assignmentForm.comments')"
                  >Comments are required</span
                >
              </div>
            </div>
          </div>
  
          <div class="text-danger text-sm formerrors my-2" v-show="formErrors">
            <vs-alert
              color="warning"
              class="warning-alert reg-warning-alert no-border-radius"
              icon-pack="IntakePortal"
              icon="IP-information-button"
              active="true"
              >{{ formErrors }}</vs-alert
            >
          </div>
        </div>
  
        <div class="popup-footer relative">
          <span class="loader" v-if="loading"
            ><img src="@/assets/images/main/loader.gif"
          /></span>
          <vs-button
            color="dark"
            @click="showPopup = false"
            class="cancel"
            type="filled"
            >Cancel</vs-button
          >
          
  
          <vs-button
            
            :disabled="loading"
            color="success"
            @click="submitreAssignAction()"
            class="save"
            type="filled"
            >
            <template v-if="ACTIVITYCODE =='BACK_TO_ASSIGN'">Report Back</template>
            <template v-else>Assign</template>
            
          </vs-button>
         
        </div>
      </form>
    </vs-popup>
  </template>
  <script>
  import moment from "moment";
  
  import * as _ from "lodash";
  import Vue from 'vue';
  Vue.use( CKEditor );
  import CKEditor from '@ckeditor/ckeditor5-vue2';
  import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
  
  export default {
    methods: {
  
      getLcaExecuitiveList(){
        this.selectedSigner =null
        // {{workFlowDetails}}
      
         
        
  
             //let companyIdRoles =[50,51];
             let branchIdRoles =[14];
              let postData ={
                "matcher":{ "roleIds": [14], "branchId":"",},              
                "page": 1,	
                "perpage":100000000,
                
              };
             
                
                
  
              if(this.checkProperty(this.petitionDetails ,'branchId')){
                  postData['matcher']['branchId'] = this.checkProperty(this.petitionDetails ,'branchId');
                }
                
  
              
              this.$store.dispatch("getList",{data:postData ,path:'/petition/assign-user-list'} ).then(response => {
               //alert(JSON.stringify(response.list));
               let lst = []
              
              _.forEach(response.list ,(item)=>{
  
                item['tempName']= item['name'];
            if (
              _.has(item, "name") &&
              _.has(item, "roleName") &&
              item._id != this.getUserData["userId"]
            ) {
              item.tempName = item.name + " (" + item.roleName + ")";
              lst.push(item);
            }
                
              
  
  
              });
              this.usersList = lst;
  
  
              })
  
  
  
          
        
  
      },
  
      selectUesr(item){
        
      },
      openReAssignToReviewerPopUp(){
    this.selectedUser =null;
    this.comments = '';
    this.loading =false;
     this.comments ="Case "+this.petitionDetails.typeDetails.name+", "+this.petitionDetails.subTypeDetails.name+" is being re-assigned for corrections/changes/updates."
  
     if(this.usersList.length==1){
      
      this.selectedUser = _.cloneDeep(this.usersList[0]);
     
     }
     if(this.ACTIVITYCODE !='BACK_TO_ASSIGN'){
     if([50].indexOf(this.getUserRoleId)>-1){
       this.selectedUser = _.find(this.usersList ,{'roleId':51});
       
     }else if([51].indexOf(this.getUserRoleId)>-1){
        this.usersList = _.filter(this.usersList ,{'roleId':50});
       this.selectedUser = _.find(this.usersList ,{'roleId':50});
     }
    }
  
  
     this.$validator.reset();
  
  },
      submitreAssignAction(){
         
        this.$validator.validateAll("assignmentForm").then((result) => {
     
          if(result){
             
              let postData ={
                  "petitionId": "",
                  "userId": "",
               //   "userName": "",
                  //"roleId": '',
                  "typeName": "",
                  "subTypeName": "",
                  "comment": ""
              };
            postData['petitionId'] = this.checkProperty(this.petitionDetails ,'_id'); 
            postData['userId'] = this.checkProperty(this.selectedUser ,"_id"),
           // postData['userName'] = self.checkProperty(self.selectedAssignToReviewer ,'roleName'); 
         //   postData['roleId'] = self.checkProperty(self.selectedAssignToReviewer ,'roleId'); 
            postData['typeName'] = this.checkProperty(this.petitionDetails,'typeDetails','name'); 
            postData['subTypeName'] = this.checkProperty(this.petitionDetails,'subTypeDetails','name');
            postData['comment'] = this.comments; 
            this.loading =true;
            let url ="/petition/reassign"; 
            if([3].indexOf(this.checkProperty(this.petitionDetails,'typeDetails', 'id' )) >-1 &&  [15].indexOf(this.checkProperty(this.petitionDetails,'subTypeDetails', 'id' )) >-1 ){
              url = "/perm/reassign"; 
            }
            this.formErrors ='';
      this.$store.dispatch("commonAction" ,{data:postData,path:url})
          .then(response => {
            this.showPopup =false;
                  
                  this.showToster({message:response.message,isError:false });
                    this.loading =false;
                     this.$emit("updatepetition" ,'');
                     this.$emit("hideMe");                
                  
  
              
          }).catch((err)=>{
             
              this.formErrors =err;
              this.loading =false;
            
          })
          }
  
        })
  
  
      },
  
      submitForm() {
   
      this.$validator.validateAll("assignmentForm").then((result) => {
              if (result) {
                let postData = {
                 petitionId: this.petitionDetails['_id'],
                  comment: this.comments,
                    "userId": this.checkProperty(this.selectedUser ,"_id"),
                    "userName": this.checkProperty(this.selectedUser ,"name"),
                    "roleId":  this.checkProperty(this.selectedUser ,"roleId"),
                    "assignRoleName":  this.checkProperty(this.selectedUser ,"roleName"),
                    subTypeName:this.checkProperty(this.petitionDetails,'subTypeDetails','name'),
                    typeName:this.checkProperty(this.petitionDetails,'typeDetails','name'),
                     "action":this.ACTIVITYCODE, //"ASSIGN_SUPERVISOR", // "ASSIGN_PARALEGAL" / "ASSIGN_DOCUMENTATION_MANAGER" / "ASSIGN_DOCUMENTATION_EXECUTIVE" / "ASSIGN_ATTORNEY"
                   isSkippedAction:false
  
                };
              let path = "/petition/assign-a-role";
                if(this.ACTIVITYCODE == "SUPERVISOR_FORMS_REVIEW" || this.ACTIVITYCODE == "CASE_APPROVED" || this.ACTIVITYCODE == "SUBMIT_TO_USCIS"){
                  path = "/petition/manage-approval-process";
                   postData = {
                  petitionId: this.petitionDetails['_id'],
                  comment: this.comments,
                  subTypeName:this.checkProperty(this.petitionDetails,'subTypeDetails','name'),
                  typeName:this.checkProperty(this.petitionDetails,'typeDetails','name'),
                   "action":this.ACTIVITYCODE, //"ASSIGN_SUPERVISOR", // "ASSIGN_PARALEGAL" / "ASSIGN_DOCUMENTATION_MANAGER" / "ASSIGN_DOCUMENTATION_EXECUTIVE" / "ASSIGN_ATTORNEY"
  today: moment().format('YYYY-MM-DD')
                }
  
                }
  
                if([3].indexOf(this.checkProperty(this.petitionDetails,'typeDetails', 'id' )) >-1 &&  [15].indexOf(this.checkProperty(this.petitionDetails,'subTypeDetails', 'id' )) >-1){
                    path ="/perm/assign-a-role";
                    if(this.ACTIVITYCODE == "CASE_APPROVED" || this.ACTIVITYCODE == "SUBMIT_TO_USCIS"){
                      path = "/perm/manage-approval-process";
                    }
  
                 }
                
                
  
      
  
                
                //alert(JSON.stringify(postData))
                 this.loading =true;
                 this.$store
                .dispatch("commonAction", {"data":postData ,"path":path})
                .then(response => {
                  this.showPopup =false;
                  this.openAtornyPopup =false;
                  this.showToster({message:response.message,isError:false });
                    this.loading =false;
                     this.$emit("updatepetition" ,'');
                     this.$emit("hideMe");
                  
                  
                  
                                  
                })
                .catch((error)=>{
                  
                  this.formErrors =error;
                  this.loading =false;
                })
                
         
         
  
                
              }
            });
      },
      hideMe() {
        this.$emit("hideMe");
      },
    },
    watch: {
      showPopup(val) {
        if (!val) this.$emit("hideMe");
      },
    },
    mounted() {
      this.showPopup = true;
  
  
   
        let self = this;
        this.caseUsers = [];
        let postData = {
          petitionId: self.petitionDetails['_id'],
          page: 1,
          perpage: 2500,
        };
  
        let url ="/petition/assigned-user-list"; 
            if([3].indexOf(this.checkProperty(this.petitionDetails,'typeDetails', 'id' )) >-1 &&  [15].indexOf(this.checkProperty(this.petitionDetails,'subTypeDetails', 'id' )) >-1){
              url = "/perm/assigned-user-list"; 
            }
        this.$store
          .dispatch("getList", {
            data: postData,
            path:url,
          })
          .then((response) => {
            if (self.checkProperty(response, "list")) {
              let list = [];
              let responseList = response["list"];
              let notAllowUserRolles =[]
              if([3,4,5,6,7,8,9,10,11,12,13,14].indexOf(this.getUserRoleId)>-1 && this.getTenantTypeId !=2){
                
                notAllowUserRolles =[51]
              }else if([50].indexOf(this.getUserRoleId) >-1){
                notAllowUserRolles =[];
              }else if([51].indexOf(this.getUserRoleId) >-1 && this.getTenantTypeId !=2){
                notAllowUserRolles =[3,4,5,6,7,8,9,10,11,12,13,14]
             }

            
             if(notAllowUserRolles.length>0){
              responseList = _.filter(responseList ,( item)=>{
               return notAllowUserRolles.indexOf(item.roleId)<=-1

              })

             }

             if([14].indexOf(this.getUserRoleId) >-1 && this.workFlowDetails && _.has(this.workFlowDetails ,'config')){

             
              let lcaRequired = _.find(this.workFlowDetails.config , {"code":'LCA_REQUEST'});
              let lcaSubmit = _.find(this.workFlowDetails.config , {"code":'LCA_SUBMIT'});
              
              if(lcaRequired['actionRequired'] =="Yes" &&  (lcaRequired && lcaRequired.editors) || (lcaSubmit && lcaSubmit['editors']) ){
                  let lcaRequestEditors = _.filter(lcaRequired["editors"] ,(ed)=>{
                                            return ed['roleId'] !=50
                                          })
              let reqEditors = _.map(lcaRequestEditors, 'roleId');

              let lcaSubmitEditors = _.filter(lcaSubmit["editors"] ,(ed)=>{
                  return ed['roleId'] !=50
              })
              let lcaSubmitAllEditors = _.map(lcaSubmitEditors, 'roleId');

              
              responseList = _.filter(responseList ,( item)=>{
                return reqEditors.indexOf(item.roleId)>-1 || lcaSubmitAllEditors.indexOf(item.roleId)>-1

                })
          
                
              }
            }
              _.forEach(responseList, (user) => {
                user['tempName']= user['name'];
                if (_.has(user, "roleName")) {
                   user["tempName"] =
                    user["name"] + " (" + user["roleName"] + ")";
                }
                if(this.ACTIVITYCODE=='BACK_TO_ASSIGN'){
                    if(_.has(this.petitionDetails, 'reassignLogs')){
                      let userId = this.getUserData['userId'];
                      let myItems = _.filter(this.petitionDetails['reassignLogs'] ,{"assignedBack":false,"createdBy":user['userId']  ,'toUserId':userId});
                      if(myItems && myItems.length>0){
                        list.push(user);
                      }

                    }


                }else{
                  list.push(user);
                }
                
              });
              self.usersList = list;

              
            }
            self.openReAssignToReviewerPopUp();
          }).catch((err)=>{
            self.openReAssignToReviewerPopUp();
          })
  
  
   
      },
    data: () => ({
      editor: ClassicEditor,
   editorConfig: {
       toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
   },
      usersListReviewrsRolesList:[],
      loading:false,
      comments:null,
      usersList: [],
      showPopup: false,
      settingCaseNumber: false,
          selectedUser:null,
      formErrors: null,
    }),
    props: {
      ACTIVITYCODE: {
        type: String,
        default: null,
      },
      rolesList: [],
      popUpTitle: {
        type: String,
        default: null,
      },
      petitionDetails: {
        type: Object,
        default: null,
      },
      workFlowDetails: {
      type: Object,
      default: null,
    },
    },
  };
  </script>
  