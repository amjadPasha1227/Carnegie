<template>
    <div>
        <template>
        <modal
        name="managePwdPopupModal"
        classes="v-modal-sec linklca"
        :min-width="200"
        :min-height="200"
        :scrollable="true"
        :reset="true"
        width="1300px"
        height="auto"
        >
        <div class="v-modal">
        <div class="popup-header fromDetailsPage"> 
        <h2 v-if="callfromActionPopup" class="popup-title"> {{popUpTitle}} </h2>
        <h2 v-else class="popup-title"> Link PWD </h2>
        <span @click="$modal.hide('managePwdPopupModal');hideMe()"> <em class="material-icons">close</em> </span>
        </div>
        <form data-vv-scope="newCaseNumberForm" @submit.prevent @keydown.enter.prevent>
          <div class="linklca_form" @click="formErrors=''">
            <div class=" linklca_form_header">
                <!-- <label for class="form_label">{{ dropdownTitle }}<em>*</em></label> -->
                <div class="search">
                    <vs-input icon-pack="feather" icon="icon-search"
                        :placeholder="'Search by Case No/PWD Number/Location/Job Title/SOC Code'"
                        class="is-label-placeholder" v-model.lazy="searchString" @input="casesSearch" />
                </div>
                <!-- <button 
                    class="light-blue-btn primary-btn"
                    @click="createLCA=true;reloadList()" 
                    >New LCA</button> -->
            </div>
            <div class="form-container pad0">
                
                <div class="accordian-table custom-table no-wrap relative">
                    <div class="search_LCA" v-if="!checksearchString"> 
                        <img src="@/assets/images/main/no-data.jpg"   />
                        <label>Search by PWD Number/Location/Job Title/SOC Code </label>
                    </div>
                    
                    <NoDataFound ref="NoDataFoundRef" :loading="isListLoading" v-if="casesList.length == 0 && checksearchString" content=""
                    :heading="'No Results Found'" type='petitions' />
                    <template v-if="casesList.length > 0 && checksearchString">
                    <vs-table :data="casesList ">
                        <template v-if="casesList.length > 0" slot="thead">
                            <vs-th class="mw-280">
                                <a @click="sortMe('caseNo')" v-bind:class="{'sort_ascending':sortKeys['caseNo']==1, 'sort_descending':sortKeys['caseNo']!=1}">Case No </a>            
                            </vs-th>
                            <vs-th>
                                PWD Number            
                            </vs-th>
                            <!-- <vs-th v-if=" [50].indexOf(getUserRoleId) <= -1  &&  getTenantTypeId !=2"> Petitioner Name </vs-th> -->
                            <!-- <vs-th > Case(s) </vs-th> -->
                            <vs-th>
                                <a @click="sortMe('updatedOn')"
                                v-bind:class="{ 'sort_ascending': sortKeys['updatedOn'] == 1, 'sort_descending': sortKeys['updatedOn'] != 1 }">
                                Last Updated</a>
                            </vs-th>
                            <vs-th>
                                <a @click="sortMe('statusName')"
                                    v-bind:class="{ 'sort_ascending': sortKeys['statusName'] == 1, 'sort_descending': sortKeys['statusName'] != 1 }">
                                    Status
                                </a>
                            </vs-th>
                        </template>
                        <template slot-scope="{ data }">
                            <vs-tr :data="tr" :key="indextr" v-for="(tr, indextr) in data" class="vs-table--tr">
                                <vs-td>
                                    <vs-checkbox
                                        @change="selectForLca(tr)" :name="'selected_'+tr.index"
                                        v-model="tr.selectedForPwd" class=""></vs-checkbox>
                                    <div  > {{ checkProperty(tr, 'caseNo') }} </div>
                                </vs-td>
                                <vs-td>
                                    <span class="cursor-pointer" @click="petitionlink(tr)">{{
                                        checkProperty(tr ,'pwdDocCaseNo')}}</span>
                                </vs-td>
                                <!-- <vs-td v-if="[50].indexOf(getUserRoleId) <= -1  &&  getTenantTypeId !=2 ">
                                    <div  > {{ checkProperty(tr, 'petitionerDetails','name') }} </div>
                                </vs-td> -->
                                <!-- <vs-td>
                                 
                                    <template v-if="checkProperty(tr ,'petitionList' ,'length') >0 ">
                                        {{tr.petitionList[0]['caseNo'] }}
                                    </template>
                                    <div class="menu_dropdown flexible_actions email_list right ml-2" v-if="checkProperty(tr ,'petitionList' ,'length') >1">
                                            <em class="more_count ">
                                            +{{ tr['petitionList'].length-1 }}
                                            </em>
                                            <div class="menu_list_wrap" v-if="checkProperty(tr ,'petitionList' ,'length') >1">
                                            <ul class="">
                                                <VuePerfectScrollbar ref="mainSidebarPs" class="scroll-area--main-sidebar"
                                                :settings="settings" @ps-scroll-y="psSectionScroll">
                                                <template v-for="( name ,eind ) in tr['petitionList']">
                                                    <li v-if="eind>0" :key="eind">{{  checkProperty(name, 'caseNo')}}</li>
                                                </template>
                                                </VuePerfectScrollbar>
                                            </ul>
                                            </div>
                                    </div>
                                    </vs-td> -->
                                    <vs-td>
                                        <div >
                                        <template v-if="checkProperty(tr, 'updatedOn')">
                                            {{ checkProperty(tr, 'updatedOn') | formatDate }}
                                        </template>
                                        <template v-else-if="checkProperty(tr, 'createdOn')">
                                            {{ checkProperty(tr, 'createdOn') | formatDate }}
                                        </template>
                                        </div>
                                    </vs-td>
                                    <vs-td>
                                        <span   v-bind:class="{
                                        'status_created': checkProperty(tr ,'statusDetails','id') == 1,
                                        'status_submited': checkProperty(tr ,'statusDetails','id') == 2,
                                        'status_inProcess': checkProperty(tr ,'statusDetails','id') == 3,
                                        'status_waiting': checkProperty(tr ,'statusDetails','id') == 4,
                                        'status_ready_for_filing':[5, 8].indexOf(checkProperty(tr, 'statusId')) > -1,
                                        'status_sent_for_signatures': [6, 9].indexOf(checkProperty(tr, 'statusId')) > -1,
                                        'staus_filed_with_USCIS':[7, 18].indexOf(checkProperty(tr, 'statusId')) > -1,
                                        'received_signed_forms': checkProperty(tr ,'statusDetails','id') == 10,
                                        'RFE_Received': [11, 24].indexOf(checkProperty(tr, 'statusId')) > -1,
                                        'status_submited-USCIS': checkProperty(tr ,'statusDetails','id') == 12,
                                        'response_to_RFE_Received': checkProperty(tr ,'statusDetails','id') == 13,
                                        'status_jobdescription': checkProperty(tr ,'statusDetails','id') == 14,
                                        'status_pwd_filed': checkProperty(tr ,'statusDetails','id') == 15,
                                        'status_pwd_response': checkProperty(tr ,'statusDetails','id') == 16,
                                        'staus_advertisements': checkProperty(tr ,'statusDetails','id') == 17,
                                        'Status_received_by_USCIS': checkProperty(tr ,'statusDetails','id') == 19,
                                        'Perm_drft_approved': checkProperty(tr ,'statusDetails','id') == 20,
                                        'Perm_submited_dol': checkProperty(tr ,'statusDetails','id') == 21,
                                        'status_approved': checkProperty(tr ,'statusId') == 22,
                                        'status_denied': checkProperty(tr ,'statusDetails','id') == 23,
                                        'notice_supervisory_audit': checkProperty(tr ,'statusDetails','id') == 27,
                                        'status_supervisory_audit': checkProperty(tr ,'statusDetails','id') == 28,
                                        'status_withdrawn': checkProperty(tr ,'statusDetails','id') == 31
                                        }">{{ checkProperty(tr, 'statusDetails', 'name')}}</span>

                                    </vs-td>
                            </vs-tr>
                        </template>
                    </vs-table>
                    </template>
                </div>            
                <div class="text-danger text-sm formerrors my-2" v-show="formErrors">
                    <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius"
                        icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ formErrors }}</vs-alert>
                </div>
            </div>

            <div class="popup-footer relative">
                <span class="loader" v-if="loading"><img src="@/assets/images/main/loader.gif" /></span>
                <vs-button color="dark" @click="showPopup = false;hideMe()" class="cancel" type="filled">Cancel</vs-button>


                <vs-button :disabled="loading || !checkSubmitBtn || checkProperty( casesList,'length')<=0" color="success" @click="submitForm()" class="save" type="filled">
                    <template v-if="callfromActionPopup">{{popUpTitle}}</template>
                    <template v-else>Link PWD</template>

                </vs-button>

            </div>
          </div>
        </form>
      </div>
        </modal>
        </template>
        <template>
    </template>
    </div>
 
</template>
<script>
import RequestLCA from "@/views/RequestLCA";
import moment from "moment";
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import * as _ from "lodash";
import { XIcon, MoreVerticalIcon } from 'vue-feather-icons'
import Vue from 'vue';
Vue.use(CKEditor);
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import NoDataFound from "@/views/common/noData.vue";

export default {
    methods: {
        reloadList(){
            if(this.checkProperty(this.casesList,'length')>0){
                _.forEach(this.casesList ,(item)=>{
                    item['selectedForPwd']=false
                });
            }
            
        },
        changeLCA(val){
            let pwdId = val;
            this.createLCA = false;
            this.searchString=''
            this.submitForm(true, val)
        },
        
        psSectionScroll(){},
        sortMe(sort_key = '') {
            if (sort_key != '') {
                this.sortKeys[sort_key] = this.sortKeys[sort_key] == 1 ? -1 : 1
                this.sortKey = {};
                this.sortKey = { "path": sort_key, "order": this.sortKeys[sort_key] }
                localStorage.setItem('lca_sort_key', sort_key);
                localStorage.setItem('lca_sort_value', this.sortKey[sort_key]);
                this.getPwdList();
            }
        },
        selectForLca(tr){
            self = this;
            if(this.checkProperty(tr ,'selectedForPwd') && self.checkProperty(tr,'_id') && this.checkProperty(this.casesList,'length')>0 ){
                _.forEach( this.casesList,(item) => {
                    if(item['_id'] != self.checkProperty(tr,'_id') ){
                        item['selectedForPwd'] = false;
                    }
                })
            }
        },
        getPwdListsdfgh() {
            let obj = {
                page: 1,
                perpage: 1000,
                sorting: this.sortKey,
                matcher: {
                    searchString: this.searchString.trim(),
                    petitionerIds: [],
                    statusIds: [1, 2, 3],
                    // getMasterDataOnly: true,
                }
            };
           
           
            if (this.checkProperty(this.petitionDetails, 'petitionerDetails', '_id')) {
                obj['matcher']['petitionerIds'] = [this.checkProperty(this.petitionDetails, 'petitionerDetails', '_id')]
            }
            this.updateLoading(true);
            this.$store.dispatch("fetchlcalist", obj).then(response => {
               this.casesList  = [];
               this.updateLoading(false);
               setTimeout(()=>{
                this.updateLoading(false);
               })
                let list = _.cloneDeep(response.data.result.list);
                let tempList = [];
                if(this.pwdId){
                    tempList = _.filter(list,(ite)=>{
                     return ite['_id'] != this.pwdId
                    })
                }else{
                    tempList = _.cloneDeep(list)
                }
                _.forEach(tempList ,(item)=>{
                    item =Object.assign(item,{ 'selectedForPwd':false});
                    this.casesList.push(item);

                });
               
            }).catch(() => {
                this.updateLoading(false);
            })
        },
        submitForm(callFromLca = false, pwdId = '') {

            this.$validator.validateAll("assignmentForm").then((result) => {
                let findItem = _.find(this.casesList,{ 'selectedForPwd':true})
                if (findItem) {
                    if(this.callFormCasePopup){
                        this.$emit('emitPwd',findItem);
                        this.showPopup = false;
                        this.$modal.hide('managePwdPopupModal');
                    }else{
                    let postData ={
                        caseNo:self.checkProperty(findItem,'caseNo'),
                        petitionIds :[] ,
                        comments:'',
                        pwdId: self.checkProperty(findItem, '_id')
                    }
                    postData.petitionIds = [this.checkProperty(this.petitionDetails, '_id')]
                    let path = "/pwd/manage-pwd-linking";
                    this.loading = true;
                    this.$store .dispatch("commonAction", { "data": postData, "path": path }) .then(response => {
                        this.showPopup = false;
                        this.$modal.hide('managePwdPopupModal');
                        this.showToster({ message: response.message, isError: false });
                        this.loading = false;
                        this.$emit("updatepetition", '');
                        this.$emit("hideMe");
                        this.createLCA = false;
                    })
                    .catch((error) => {
                        this.formErrors = error;
                        this.loading = false;
                    })
                    }
                    
                }
            });
        },
        hideMe() {
            this.$emit("hideMe");
            this.$emit('emitPwd')
        },
        casesSearch(searchValue) {
              this.casesList =[];
            if(this.checksearchString){
                clearTimeout(this.debounce)
                this.debounce = setTimeout(() => {
                    this.getPwdList()
                }, 900)        
            }else{
                this.casesList = [];
            }
        },
        //getPwdList
        getPwdList(){
         
         let postdata = {
            matcher: {
                "searchString":this.searchString.trim(),
                // getMasterDataOnly: true, 
                petitionerIds: [],
                statusIds: [9 ,10],
                linkPwd:true
            },
                "page": 1,
                "perpage": 1000,
                sorting: this.sortKey,
            } 
            //console.log(JSON.stringify(this.selectedPetitioner))
            if(this.checkProperty(this.selectedPetitioner,'userId') && this.callFormCasePopup){
                postdata['matcher']['petitionerIds'] = [this.checkProperty(this.selectedPetitioner,'userId')]
            }
            if(this.checkProperty( this.petitionDetails  ,'petitionerId')){
            postdata['matcher']['petitionerIds'] = [this.petitionDetails['petitionerId']];
            }
            this.casesList = [];
            this.updateLoading(true);
            this.$store.dispatch("getList", {data: postdata,path: '/pwd/list',}).then((response) => {
                
                let list = _.cloneDeep(response.list);
                let tempList = [];
               
                if(this.pwdId){
                    tempList = _.filter(list,(ite)=>{
                     return ite['_id'] != this.pwdId
                    })
                }else{
                    tempList = _.cloneDeep(list)
                }
                _.forEach(tempList ,(item)=>{
                    item =Object.assign(item,{ 'selectedForPwd':false});
                    this.casesList.push(item);

                });
                this.updateLoading(false);
                setTimeout(()=>{
                    this.updateLoading(false);
                })
            });
     },

    },
    watch: {
        showPopup(val) {
            if (!val) this.$emit("hideMe");
            if(!val){
                this.$modal.hide('managePwdPopupModal');
            }
            
        },
    },
    mounted() {
        this.updateLoading(false);
             this.casesList = [];
             setTimeout(() =>{
                this.updateLoading(false);
               })
        this.createLCA = false;
        this.showPopup = true;
        this.$modal.show('managePwdPopupModal');
        this.searchString="";
        this.sortKeys = {
            'caseNo': 1,
            'createdByName': 1,
            "statusName": 1,
            "updatedOn": -11,
            createdOn: -1
        },

        this.sortKey['updatedOn'] = 1;

        if (localStorage.getItem('lca_sort_key') && localStorage.getItem('lca_sort_value') && localStorage.getItem('lca_sort_value') >= -1) {
            this.sortKey = {};
            this.sortKey[localStorage.getItem('lca_sort_key')] = parseInt(localStorage.getItem('lca_sort_value'));
            this.sortKeys[localStorage.getItem('lca_sort_key')] = this.sortKey[localStorage.getItem('lca_sort_key')];
        }
    },
    data: () => ({
        settings: { 
            swipeEasing: true,
        },
        isListLoading:false,
        createLCA:false,
        sortKeys: {},
        sortKey: {},
        searchtxt:'',
        debounce:null,
        editor: ClassicEditor,
        editorConfig: {
            toolbar: ['bold', 'italic', '|', 'undo', 'redo', 'NumberedList', 'BulletedList',],
        },
        loading: false,
        comments: null,
        showPopup: false,
        formErrors: null,
        lcaInfo: null,
        casesList: [],
        linkedCaseList: [],
        selectedCaseNos: [],
        dropdownTitle: 'Case No',
        searchString: ''

    }),
    props: {
        selectedPetitioner:{
            type: Object,
            default: null,
        },
       value:null,
        callfromActionPopup:{
            type: Boolean,
            default: false,
        },
        callFormCasePopup:{
            type: Boolean,
            default: false,
        },
        ACTIVITYCODE: {
            type: String,
            default: null,
        },
        rolesList: [],
        popUpTitle: {
            type: String,
            default: null,
        },
        petitionDetails: {
            type: Object,
            default: null,
        },
        pwdId: {
            type: String,
            default: '',
        },
        isFromPetition: {
            type: Boolean,
            default: null,
        },


    },
    components:{
        XIcon,
        NoDataFound,
    MoreVerticalIcon,
        RequestLCA,
        VuePerfectScrollbar
    },
    computed:{
        checkSubmitBtn(){
           if( _.find( this.casesList, {'selectedForPwd':true })){
            return true;

           }else{
            return false
           }
        },
        checksearchString(){
            let returnVal = false;
            let text = this.searchString.trim();
            if(text.length>=1){
                returnVal = true;
            }
            return returnVal
        }
        
    }
};
</script>
  