<template> 
  <modal
    name="changeCaseTypeModal"
    classes="v-modal-sec"
    :min-width="200"
    :min-height="200"
    :scrollable="true"
    :reset="true"
    width="600px"
    height="auto"
  >
    <div class="v-modal profile_details_modal">
      <div class="popup-header fromDetailsPage">
        <h2 class="popup-title">Change Case Subtype</h2>
        <span @click="hideMe()">
          <em class="material-icons">close</em>
        </span>
      </div>

      <form @submit.prevent data-vv-scope="changeCaseTypeForm" @submit.prevent @keydown.enter.prevent>
        <div class="form-container">
          <div class="vx-row">
            <div class="vx-col w-1/2">
              <div class="form_group">
                <div class="con-select w-full select-large">
                  <label for="" class="form_label">Case Type<em>*</em></label>

                  <multiselect
                    name="visatype"
                    data-vv-as="Case Type"
                    v-validate="'required'"
                    v-model="selectedCaseType"
                    :disabled="true"
                    :show-labels="false"
                    track-by="id"
                    label="name"
                    placeholder="Select Case Type"
                    :options="visatypes"
                    :searchable="true"
                    :allow-empty="false"
                  >
                  </multiselect>
                </div>
                <span
                  class="text-danger text-sm"
                  v-show="errors.has('changeCaseTypeForm.visatype')"
                  >{{ errors.first("changeCaseTypeForm.visatype") }}</span
                >
              </div>
            </div>
            <div class="vx-col w-1/2">
              <div class="form_group">
                <div class="con-select w-full select-large">
                  <label for="" class="form_label"
                    >Case Subtype<em>*</em></label
                  >

                  <multiselect
                    name="visasubtype"
                    data-vv-as="Case Subtype"
                    v-validate="'required'"
                    v-model="selectedCaseSubType"
                    :show-labels="false"
                    track-by="id"
                    label="name"
                    placeholder="Select Subtype"
                    :options="visasubtypes"
                    :searchable="true"
                    :allow-empty="false"
                    @input="formerrors.msg = ''"
                  >
                  </multiselect>
                </div>
                <span
                  class="text-danger text-sm"
                  v-show="errors.has('changeCaseTypeForm.visasubtype')"
                  >{{ errors.first("changeCaseTypeForm.visasubtype") }}</span
                >
              </div>
            </div>

            <div class="vx-col w-full">
              <div class="form_group">
                <div class="con-select w-full select-large">
                  <label for="" class="form_label">Notify Users</label>

                  <multiselect
                    name="users"
                    data-vv-as="Notify Users"
                    v-model="selectedAssignedUsers"
                    :show-labels="false"
                    track-by="_id"
                    label="name"
                    placeholder="Select Notify Users"
                    :options="assignedUsersList"
                    :searchable="true"
                    :allow-empty="true"
                    :close-on-select="false"
                    :hideSelected="true"
                    :multiple="true"
                    @input="formerrors.msg = ''"
                  >
                    <template slot="selection" slot-scope="{ values, isOpen }">
                      <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} User(s) Selected</span
                      >
                      <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                      ></span>
                    </template>
                  </multiselect>
                </div>
                <span
                  class="text-danger text-sm"
                  v-show="errors.has('changeCaseTypeForm.users')"
                  >{{ errors.first("changeCaseTypeForm.users") }}</span
                >
              </div>
            </div>
          </div>

          <div v-show="formerrors.msg">
            <vs-alert
              color="warning"
              class="warning-alert reg-warning-alert no-border-radius"
              icon-pack="IntakePortal"
              icon="IP-information-button"
              active="true"
              >{{ formerrors.msg }}</vs-alert
            >
          </div>
          
        </div>
        <div class="popup-footer relative">
          <span class="loader" v-if="caseTypeCahnging"
            ><img src="@/assets/images/main/loader.gif"
          /></span>

          <vs-button
            color="dark"
            @click="hideMe()"
            class="cancel"
            type="filled"
            >Cancel</vs-button
          >
          <vs-button
            color="success"
            @click="submitForm()"
            class="save"
            type="filled"
            >Update
          </vs-button>
        </div>
      </form>
    </div>
  </modal>
</template>
<script>
export default {
  methods: {
    submitForm() {
      this.$validator.validateAll("changeCaseTypeForm").then((result) => {
        this.caseTypeCahnging = false;
        if (result) {
          Object.assign(this.formerrors, { msg: "" });
          let postData = {
            petitionId: this.petitionDetails._id,
            subType: this.selectedCaseSubType.id,
            typeName: this.selectedCaseType.name,
            subTypeName: this.selectedCaseSubType.name,
            oldSubTypeName: this.currentCaseSubType.name,
            notifyUserIds:[],
          };
          if(this.selectedAssignedUsers && this.selectedAssignedUsers.length > 0){

              postData["notifyUserIds"] = this.selectedAssignedUsers.map((item) => item._id)
          }
          this.caseTypeCahnging = true;
          let url = "/petition/change-subtype";
          if([3].indexOf(this.checkProperty(this.petitionDetails,'typeDetails', 'id' )) >-1){
            url = "/petition/change-subtype"; 
          }
          this.$store
            .dispatch("commonAction", {
              data: postData,
              path: url,
            })
            .then((response) => {
              this.showToster({ message: response.message, isError: false });
              this.caseTypeCahnging = false;
              this.$emit("updatepetition", "Case Details");
              this.hideMe()
            })
            .catch((error) => {
              this.caseTypeCahnging = false;
              Object.assign(this.formerrors, { msg: error });
            });
        }
      });
    },
    hideMe() {
      this.$modal.hide("changeCaseTypeModal");
      this.$emit("hideMe");
    },
    getvisasubtypes() {
      Object.assign(this.formerrors, { msg: "" });
      if (this.selectedCaseType && _.has(this.selectedCaseType, "id")) {
        this.visasubtypes = [];
        this.selectedCaseSubType = null;
        let item = {
          matcher: {
            petitionType: parseInt(this.selectedCaseType["id"]),
          },
          page: 1,
          perpage: 1000,
          category: "petition_sub_types",
        };

        this.$store.dispatch("getMasterData", item).then((response) => {
          this.visasubtypes = response.list;
          this.visasubtypes = _.filter(response.list, (item) => {
            return (
              this.checkProperty(
                this.getPetitionDetails,
                "subTypeDetails",
                "id"
              ) != item["id"]
            );
          });
        });
        this.$validator.reset();
      }
    },
  },
  mounted() {
    this.$modal.show("changeCaseTypeModal");
    this.getvisasubtypes();

  },
  data: () => ({
    caseTypeCahnging: false,
    formerrors: {
      msg: "",
    },
    selectedAssignedUsers: [],
    selectedCaseSubType: null,
    visasubtypes: [],
  }),
  props: {
    petitionDetails: {
      type: Object,
      default: null,
    },
    currentCaseSubType: {
      type: Object,
      default: null,
    },
    selectedCaseType: {
      type: Object,
      default: null,
    },
    assignedUsersList: {
      type: Array,
      default: null,
    },
    visatypes: {
      type: Array,
      default: null,
    },
  },
};
</script>