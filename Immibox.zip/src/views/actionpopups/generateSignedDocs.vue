<template>
    <modal
      name="generateSignedDocsPop"
      classes="v-modal-sec"
      :min-width="200"
      :min-height="200"
      :scrollable="true"
      :reset="true"
      width="600px"
      height="auto"
    >
      <div class="v-modal">
        <div class="popup-header fromDetailsPage">
          <h2 class="popup-title">Generate Signed Documents</h2>
          <span @click="hideMe()">
            <em class="material-icons">close</em>
          </span>
        </div>
        <form @submit.prevent>
          <div class="form-container" @click="trackingErrors = ''">
            <!--- FORMS AND LATTERS SECTOION   item["createdBy"] this.getUserData['_id'] signerList:[],
      selectedSigners:[] -->
  
            <div
              class="vx-col w-full"
              @keyup="requestsignCommentError = false"
              v-if="getTenantTypeId == 2"
            >
              <div class="form_group">
                <label class="form_label">Select Authorized Signatory<em>*</em> </label>
                <div class="con-select w-full select-large">
                  <multiselect
                    name="signersList"
                    v-model="selectedSigner"
                    :close-on-select="true"
                    v-validate="'required'"
                    :multiple="false"
                    :show-labels="false"
                    label="name"
                    data-vv-as="Authorized Signatory"
                    placeholder="Select Authorized Signatory"
                    :options="signerList"
                    :searchable="true"
                    :allow-empty="false"
                  >
                    <template slot="selection" slot-scope="{ values, isOpen }">
                      <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} selected</span
                      >
                      <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                      ></span>
                    </template>
                  </multiselect>
                </div>
              </div>
              <span class="text-danger text-sm" v-if="errors.has('signersList')"   > {{ errors.first("signersList") }} </span>
            </div>
            <div class="vx-col w-full required_doc">
              <div>
                <h4 class="formsandlettes_title mb-4">Required Documents</h4>
                <ul class="formsandlettes req_docs_checks">
                  <template v-for="(forms, index) in formsAndLettersList">
                    
                    <li :key="index" v-if="forms.statusId == 2 && checkProperty(petitionDetails, 'subTypeDetails', 'id') == 15 ">
                      
                      <vs-checkbox
                        @change="selectFormsandLatters(index, forms)"
                        :name="'selectedForSigning_' + index"
                        v-model="forms.selectedForSigning"
                        class=""
                        :title="forms.name">
                        
                        {{ forms.name }}
                        
                        </vs-checkbox
                      >
                    </li>
                    
                    <li :key="index" v-if="checkProperty(petitionDetails, 'subTypeDetails', 'id') != 15 && forms.statusId == 2 && ( (forms['type']=='Form') || (forms['type']=='Letter' && !(forms['entityId'] !='support_letter') ) )">
                      
                      <vs-checkbox
                        @change="selectFormsandLatters(index, forms)"
                        :name="'selectedForSigning_' + index"
                        v-model="forms.selectedForSigning"
                        class=""
                        :title="forms.name">{{ forms.name }}
                        <small class="support_letter_text" v-if=" forms['entityId'] =='support_letter'">(Support Letter)</small>
                        <small  class="support_letter_text" v-if=" forms['entityId'] =='cover_letter'">(Cover Letter)</small>
                        <small class="support_letter_text"  v-if="forms['docUserType'] =='Beneficiary'">(Beneficiary)</small>
                        <small class="support_letter_text"  v-if="forms['docUserType'] =='Dependent'">(Dependent)</small>
                        </vs-checkbox
                      >
                    </li>
                  </template>
                </ul>
              </div>
            </div>
            <div class="vx-col w-full" v-if="!petitionerSignPath && companyDetailsLoaded">
                <div
                  class="form_group mb-5"
                  @click="
                    documents = [];
                    premiumProcessingFilesUploading = false;
                  "
                >
                  <label class="form_label">
                    <template v-if="getTenantTypeId==2">Signer Electronic Signature</template>
                    <template v-else>  Petitioner Electronic Signature</template>

                   
                    <em>*</em></label>
                    <customCropImage @input="updateCropDataPetitioner" :vvas="'Electronic Signature'"  :display="true" :cid="'ElectronicDocumentsPetitioner'"  :formscope="''" :fieldName="'ElectronicDocumentsPetitioner'" :required="true"/>
                
                  <div class="vs-component relative mb-1" v-if="false">                  
                    <file-upload
                      :multiple="false"
                      :hideSelected="true"
                      v-model="documents"
                      class="file-upload-input file_upload justify-center"
                      :name="'permDocuments'"
                      accept="image/*"
                      @input="uploadDocuments(documents,'petitionerSign')"
                    >
                      <img
                        class="file-icon"
                        src="@/assets/images/main/file-upload.svg"
                      />
                      Upload
                    </file-upload>
                    <span class="loader" v-if="premiumProcessingFilesUploading"><img src="@/assets/images/main/loader.gif" /></span>
                    <span class="file-type mb-0">(File Type: JPEG,PNG,JPG. Max file size: 1MB)</span>
                   
                  </div>
                  <input
                    type="hidden"
                    v-validate="'required'"  data-vv-as="perm Documents"
                    :name="'permDocuments_petitionerSign'"
                    v-model="petitionerSign"
                  />
                  <span class="text-danger text-sm" v-show="errors.has('permDocuments_petitionerSign')">*Document is required</span>

                  <ul
                    class="uploaded-list note_uploads mt-3"
                    v-if="checkProperty(petitionerSign, 'length') > 0"
                  >
                    <template v-for="(file, fileindex) in petitionerSign">
                      <vs-chip
                        type="button"
                        @click="removePremiumProcessingFiles(fileindex,'petitionerSign')"
                        :key="fileindex"
                        v-if="file.status !== false"
                        closable
                        ><img src="@/assets/images/main/down-arrow2.svg" @click="downloads3file(file)" /> 
                        {{ file.name }}
                      </vs-chip>
                    </template>
                  </ul>
                </div>
            </div>
            <div class="vx-col w-full" v-if="(!attroneySignPath && attroneyDetailsLoaded ) " >
            <div
                class="form_group mb-5"
                @click="
                documents = [];
                autornyFilesUploading = false;
                "
            >
                <label class="form_label">Attorney Electronic Signature<em>*</em></label>
                <customCropImage @input="updateCropData" :vvas="'Electronic Signature'"  :display="true" :cid="'ElectronicDocumentsAttorney'"  :formscope="''" :fieldName="'ElectronicDocumentsAttorney'" :required="true"/>
                <div class="vs-component relative mb-1" v-if="false">                  
                <file-upload
                    :multiple="false"
                    :hideSelected="true"
                    v-model="documents"
                    class="file-upload-input file_upload justify-center"
                    :name="'autornyFilesUploading'"
                    accept="image/*,"
                    @input="uploadDocuments(documents,'attorneySign')" 
                >
                    <img
                    class="file-icon"
                    src="@/assets/images/main/file-upload.svg"
                    />
                    Upload 
                </file-upload>
                <span class="loader" v-if="autornyFilesUploading"><img src="@/assets/images/main/loader.gif"
                /></span>
                 <span class="file-type mb-0">(File Type: JPEG,PNG,JPG. Max file size: 1MB)</span>
                
                </div>
                <input
                type="hidden"
                v-validate="'required'"  data-vv-as="perm Documents"
                :name="'autornyFilesUploading_attorneySign'"
                v-model="attorneySign"
                />
                <span class="text-danger text-sm" v-show="errors.has('autornyFilesUploading_attorneySign')">*Document is required</span>

                <ul
                class="uploaded-list note_uploads mt-3"
                v-if="checkProperty(attorneySign, 'length') > 0"
                >
                <template v-for="(file, fileindex) in attorneySign">
                    <vs-chip
                    type="button"
                    @click="removePremiumProcessingFiles(fileindex,'attorneySign')"
                    :key="fileindex"
                    v-if="file.status !== false"
                    closable
                    ><img src="@/assets/images/main/down-arrow2.svg" @click="downloads3file(file)" /> {{ file.name }}
                    </vs-chip>
                </template>
                </ul>
            </div>
            </div>

           
            <div
              class="text-danger text-sm formerrors mt-4"
              v-if="trackingErrors != ''"
            >
              <vs-alert
                color="warning"
                class="warning-alert reg-warning-alert no-border-radius"
                icon-pack="IntakePortal"
                icon="IP-information-button"
                active="true"
                >{{ trackingErrors }}</vs-alert
              >
            </div>
          </div>
  
          <div class="popup-footer relative">
            <span class="loader" v-if="requestsigning"
              ><img src="@/assets/images/main/loader.gif"
            /></span>
            <vs-button color="dark" class="cancel" type="filled" @click="hideMe()"
              >Cancel</vs-button
            >
  
            <vs-button
              :disabled="requestsigning"
              color="success"
              @click="submitForm"
              class="save"
              type="filled"
              >Submit
            </vs-button>
          </div>
        </form>
      </div>
    </modal>
  </template>
  <script>
  import customCropImage from '@/views/forms/fields/customCropImage.vue'
  import moment from "moment";
  import FileUpload from "vue-upload-component/src";
  import { EyeIcon } from "vue-feather-icons";
  import docType from "@/views/common/docType.vue";
  import Datepicker from "vuejs-datepicker-inv";
  import * as _ from "lodash";
  import Vue from 'vue';
  Vue.use( CKEditor );
  import CKEditor from '@ckeditor/ckeditor5-vue2';
  import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
  
  
  export default {
    components: {
      docType,
      EyeIcon,
      FileUpload,
      Datepicker,
      customCropImage
    },
    methods: {
      updateCropDataPetitioner(data){
        this.petitionerSign =[];
        this.petitionerSign.push(data);
      },
      updateCropData(data){
        // if(category == 'petitionerSign'){
        //                         this.petitionerSign =[];
        //                         this.petitionerSign.push(doc);
        //                        }
        //                        if(category == 'attorneySign'){
        //                         this.attorneySign = [];
        //                         this.attorneySign.push(doc);
        //                        }

        this.attorneySign = [];
        this.attorneySign.push(data);

        },
      fetchWorkFlowDetails(){
        
        if (this.checkProperty(this.petitionDetails ,'workflowId')) {
  
          let payLoad = {
            path: "/workflow/details",
            data: { workflowId: this.petitionDetails.workflowId },
          };
          this.$store
            .dispatch("commonAction", payLoad)
            .then((res) => {
              this.workFlowDetails = res;
              this.getSignerList();
            })
      }
    },
      getFormsAndLetters(callFromMenu =false) {
        this.$vs.loading();
  this.formsAndLettersList = [];
  
  let finalList = [];
  
  let postData = {
    
  
    petitionId: this.petitionDetails._id,
    matcher: {
       typeIds: ["Form" ,'Letter'],
    docUserTypeList : ["Beneficiary", "Dependent"]
  },
    page: 1,
    perpage: 100000,
  };
  
  postData['matcher']['docUserTypeList'] =['Beneficiary'];
  
  if (
    this.checkProperty(this.petitionDetails, "typeDetails", "id") == 3 &&
    this.checkProperty(this.petitionDetails, "subTypeDetails", "id") == 15
  ) {
    postData["matcher"]["typeIds"] = ["Audit Response"];
    this.formLetterType = "Audit Response";
    //audit_response
  }
  this.updateLoading(true);
  this.$store
    .dispatch("getList", {
      data: postData,
      // path:"/petition/filled-forms-and-letters-list"
      path: "/filled-forms-and-letters/list",
    })
    .then((response) => {
      
     
      let lst = [];
  
            _.forEach(response.list, (mainItem) => {
              mainItem = Object.assign(mainItem, {
                reverse_document_versions: [],
                mainParentId: "",
                showMe: true,
                selectedForDownload: false,
                "viewmode":true,
                "selectedForSigning":false
              });
              if (mainItem.parentId) {
                mainItem["mainParentId"] = mainItem["parentId"];
              } else {
                mainItem["mainParentId"] = mainItem["_id"];
              }
  
              lst.push(mainItem);
            });
            // if(response){
            //    this.ActiveList = _.filter(response.list, (item) => {
            //     return item.statusId != 1
            //    });
            // }
            let subList = [];
  
            //reverse_document_versions
            _.forEach(lst, (mainItem) => {
              if (this.checkProperty(mainItem, "depType") != "child") {
                _.forEach(lst, (subItem) => {
                  if (
                    mainItem.parentId &&
                    (mainItem.parentId == subItem["parentId"] ||
                      mainItem.parentId == subItem["_id"]) &&
                    mainItem["_id"] != subItem["_id"]
                  ) {
                    subItem["showMe"] = false;
                    subItem["selectedForSigning"] =false;
                    if (subList.indexOf(subItem["_id"]) <= -1) {
                      mainItem["reverse_document_versions"].push(subItem);
                      this.previousExisted = true;
                      subList.push(subItem["_id"]);
                    }
  
                    // mainItem['showMe'] =true;
                  }
                });
  
                if (mainItem.showMe) {
                  finalList.push(_.cloneDeep(mainItem));
                }
              } else {
                _.forEach(lst, (subItem) => {
                  if (
                    this.checkProperty(mainItem, "depType") ==
                      this.checkProperty(subItem, "depType") &&
                    this.checkProperty(mainItem, "depLabel") ==
                      this.checkProperty(subItem, "depLabel") &&
                    mainItem.parentId &&
                    (mainItem.parentId == subItem["parentId"] ||
                      mainItem.parentId == subItem["_id"]) &&
                    mainItem["_id"] != subItem["_id"]
                  ) {
                       subItem["showMe"] = false;
                    if (subList.indexOf(subItem["_id"]) <= -1) {
                      mainItem["selectedForSigning"] =false;
                      mainItem["reverse_document_versions"].push(subItem);
                      this.previousExisted = true;
                      subList.push(subItem["_id"]);
                    }
  
                    // mainItem['showMe'] =true;
                  }
                });
  
                if (mainItem.showMe) {
                  finalList.push(_.cloneDeep(mainItem));
                }
              }
            });
  
            this.formsAndLettersList = _.cloneDeep(finalList); // JSON.parse(JSON.stringify(finalList));
           // this.formsAndLetters =this.formsAndLettersList;
           this.$vs.loading.close(); 
      
  
      
    })
    .catch((err) => {
      this.$vs.loading.close(); 
      this.formsAndLettersList = [];
      if(callFromMenu && this.formsAndLettersList && this.formsAndLettersList.length == 0 || !this.checkActiveFormsAndLatters){
             this.showToster({
              message:
                "Required at least one forms and letters documents to send for signature.",
              isError: true,
            });
  
             this.$emit("updatepetition", "Forms and Letters");
             return false
  
      }
      
    });
      },
      checkSendAttachments(action=''){
        setTimeout(() =>{
              if(this.notifyPetitioner && action=='notifyPetitioner'){
            //  this.emailDocsForSign =true;
           
              }
              
              if(this.emailDocsForSign && action=='emailDocsForSign'){
                this.notifyPetitioner =true;
              }
  
        } ,10)
        
      },
      selectFormsandLatters(index ,forms){
    // if( !this.formsAndLettersList[index]['selectedForSigning'] ){
      
    //   forms['selectedForSigning'] =true;
    //   this.formsAndLettersList[index]['selectedForSigning'] = true
    // }else{
    //     forms['selectedForSigning'] =false;
    //   this.formsAndLetters[index]['selectedForSigning'] = false;
    // }
  
  
  
    // alert(this.petition.formsAndLetters[index]['selectedForSigning']);
  
    },
      getSignerList(){
        this.selectedSigner =null
        // {{workFlowDetails}}
      
        
  
             let companyIdRoles =[50,51];
             let branchIdRoles =[4, 5, 6, 7, 8, 9, 10, 11 ,12];
              let postData ={
                "matcher":{
                   "roleIds": [], 
                "branchId":"",},              
                "page": 1,	
                "perpage":100000000,
                petitionId:'',
                "action":'DOC_SIGNER_LIST',
               "entityType": "case", // perm
                
              };
              if(this.workFlowDetails && this.checkProperty(this.workFlowDetails,'config' ,'length')>0){
                let signerListActivity = _.find(this.workFlowDetails['config'] ,{'code':'DOC_SIGNER_LIST'});
                if(signerListActivity && signerListActivity.editors){
                let signerList = _.map(signerListActivity.editors, 'roleId');
               }
              }
              
              //DOC_SIGNER_LIST['editors']
               _.forEach( this.rolesList ,(item)=>{
                
                
                postData.matcher.roleIds.push(item);
                 if(companyIdRoles.indexOf(item)>-1 && this.checkProperty(this.petitionDetails ,'companyDetails' ,'_id')){
                  postData = Object.assign(postData ,{"companyId":this.checkProperty(this.petitionDetails ,'companyDetails' ,'_id') })
                }
  
              if(branchIdRoles.indexOf(item)>-1 && this.checkProperty(this.petitionDetails ,'branchId')){
                  postData['matcher']['branchId'] = this.checkProperty(this.petitionDetails ,'branchId');
                }
                
  
              });
              postData['petitionId'] = this.checkProperty(this.petitionDetails ,'_id');
  
              let path ='/petition/assign-user-list';
              if(this.checkProperty(this.petitionDetails,'subTypeDetails','id') ==15){
                path = "/perm/assign-user-list";
                postData['entityType'] = 'perm';
    
              }
              path = "/petition-common/get-users-for-assign";
              this.$store.dispatch("getList",{data:postData ,path:path} ).then(response => {
               //alert(JSON.stringify(response.list));
               let lst = []
              
              _.forEach(response ,(item)=>{
                if(_.has(item ,'name') && _.has(item ,'roleName') && ( item._id !=this.getUserData['userId'])){
                    item.name = item.name+" ("+item.roleName+")";
                    lst.push(item);
                }
              
  
  
              });
              this.signerList = lst;
  
  
              })
  
  
  
          
        
  
      },
      submitForm() {
       
        this.$validator.validateAll().then((result)=>{ 
       
         
          if(result){
           
         
        this.trackingErrors = "";
        this.requestsignCommentError = false;
        // if (
        //   this.requestsignformcomments == "" ||
        //   this.requestsignformcomments.trim() == ""
        // ) {
        //   this.requestsignCommentError = true;
        //   return true;
        // }
        let selectedDocuments = _.filter(this.formsAndLettersList, {
          selectedForSigning: true,
        });
        if ( !selectedDocuments || this.checkProperty(selectedDocuments, "length") <= 0) {
          this.trackingErrors = "Atleast select one document is required.";
          result = false;
        }
  
        let self = this;
        var postdata = {
        //   'action':'REQUEST_PETITIONER_SIGN',
          petitionId: this.petitionDetails._id,
          entityType: this.checkProperty( this.petitionDetails,'typeDetails','id' )==15?'perm':'case',
          subTypeName: this.checkProperty(
            this.petitionDetails,
            "subTypeDetails",
            "name"
          ),
          typeName: this.checkProperty(
            this.petitionDetails,
            "typeDetails",
            "name"
          ),
          documents: [],
          
        };
        _.forEach(this.formsAndLettersList, (item) => {
          if (item["selectedForSigning"]) {
            postdata["documents"].push(item);
          }
        });
        postdata["attorneySign"] =''
        postdata["petitionerSign"] = ''

        if(this.petitionerSignPath){
            postdata["petitionerSign"] = this.petitionerSignPath
        }else{
            if(this.petitionerSign && this.checkProperty(this.petitionerSign,'length')>0 && this.petitionerSign[0] ){
                postdata["petitionerSign"] =this.petitionerSign[0]
            }
        }
        if(this.attroneySignPath){
            postdata["attorneySign"] = this.attroneySignPath
        }else{
            if(this.attorneySign && this.checkProperty(this.attorneySign,'length')>0 && this.attorneySign[0] ){
                postdata["attorneySign"] =this.attorneySign[0]
            }
        }
      
        if (postdata["documents"].length > 0) {
            
          this.requestsigning = true;
          if (this.getTenantTypeId == 2 && _.has(this.selectedSigner, "_id")) {
            postdata = Object.assign(postdata, {
              userId: self.selectedSigner["_id"],
            });
          }
         
         
         
          this.$store.dispatch("commonAction", {"data":postdata ,"path":"/petition/generate-sign-docs"})
            .then((response) => {
  
                
  
              this.showToster({ message: response.message, isError: false });
               
               setTimeout(()=>{                           
                           
                           this.$route['params']['tabname']= 'Scanned Documents';
                           this.$emit("updatepetition" ,'Scanned Documents');                              
                       } ,100);
  
              this.hideMe();
            })
            .catch((error) => {
              this.trackingErrors = error;
              this.requestsignCommentError = false;
              this.requestsigning = false;
            });
        } else {
          this.trackingErrors = "Select atleast one document!";
          this.requestsigning = false;
          this.checkFormsandLatters = true;
        }
  
        }
  
  })
      },
      hideMe() {
        this.$emit("hideMe");
      },
        getCompanyDetail(){
            if(this.checkProperty(this.petitionDetails,'companyId')){
                let postData={
                companyId : this.checkProperty(this.petitionDetails,'companyId')
                }
                this.$store.dispatch("commonAction", {"data":postData ,"path":"/company/details"}).then((response)=>{
                this.companyDetails= response
                this.companyDetailsLoaded=true; 
                if(this.companyDetails && _.has(this.companyDetails,'signDocs') && this.checkProperty(this.companyDetails,'signDocs') && this.checkProperty(this.companyDetails,'signDocs','length')>0){
                    this.petitionerSignPath = this.companyDetails['signDocs'][0]
                }
                }).catch((error)=>{
                  this.companyDetailsLoaded=true; 
                })
            }
        },
        getAttorneyDetails(){
            if(this.checkProperty(this.petitionDetails,'attorneyId')){
                let postData={
                    userId : this.checkProperty(this.petitionDetails,'attorneyId')
                }
                this.$store.dispatch("commonAction", {"data":postData ,"path":"/users/details"}).then((response)=>{
                this.attroneyDetails= response
                 this.attroneyDetailsLoaded =true;
                if(this.attroneyDetails && _.has(this.attroneyDetails,'signDocs') && this.checkProperty(this.attroneyDetails,'signDocs') && this.checkProperty(this.attroneyDetails,'signDocs','length')>0){
                    this.attroneySignPath = this.attroneyDetails['signDocs'][0]
                }
                }).catch((error)=>{
                  this.attroneyDetailsLoaded =true;
                })
            }
        },
    uploadDocuments(documents,category='') {
      let self =this;
      let  model = _.cloneDeep(documents);
        this.premiumProcessingFormErrors = ''
              let temp_count = 0;
              
            
              this.disabled_btn = true;
              let mapper = model.map(
                  item =>
                  (item = {
                      name: item.name,
                      extn:item.extn ? item.extn : "",
                      size:item.size ? item.size : null,
                      file: item.file ? item.file : null,
                      path: item.path ? item.path : "",
                      status: item.status?true:false,
                      mimetype: item.type ? item.type : item.mimetype,
                      uploadedBy:item.uploadedBy?item.uploadedBy:this.checkProperty(this.getUserData,'userId')!=''?this.checkProperty(this.getUserData,'userId'):null,
                        uploadedByName:item.uploadedByName?item.uploadedByName:this.checkProperty(this.getUserData,'name')!=''?this.checkProperty(this.getUserData,'name'):'',
                        uploadedByRoleId:item.uploadedByRoleId?item.uploadedByRoleId:this.getUserRoleId?this.getUserRoleId:null,
                        uploadedByRoleName:item.uploadedByRoleName?item.uploadedByRoleName:this.checkProperty(this.getUserData,'loginRoleName'),
                  })
              );

              //'attorneySign')" autornyFilesUploading
              

              let allFiles =[];
              let imageMymTypes =['image/bmp','image/jpeg','image/x-png','image/png'];
              mapper.forEach((doc, index) => {
                if(imageMymTypes.indexOf(doc.mimetype) >-1){
                  allFiles.push(doc);
                }
              })
       
               if (allFiles.length > 0) {
                if(category=='attorneySign'){
                  this.autornyFilesUploading =true;
                }else{
                  this.premiumProcessingFilesUploading =true;
                }
                
                  mapper.forEach((doc, index) => {
                      let formData = new FormData();
                      formData.append("files", doc.file);
                      formData.append("secureType", "public");
                      formData.append("getDetails", true);
                      this.$store.dispatch("uploadS3File", formData).then(response => {
                          temp_count++;
                          response.data.result.forEach(urlGenerated => {
                              doc.status = true;
                              doc.path = urlGenerated.path;
                              if(self.checkProperty( urlGenerated,'extn')){
                                doc.extn = urlGenerated['extn'];
                               }
                              if(_.has(urlGenerated ,'size' )){
                                  doc['size'] = urlGenerated['size'];
                              }
                              delete doc.file;
                              
                              
                               if(category == 'petitionerSign'){
                                this.petitionerSign =[];
                                this.petitionerSign.push(doc);
                               }
                               if(category == 'attorneySign'){
                                this.attorneySign = [];
                                this.attorneySign.push(doc);
                               }
                              //this.premiumProcessingFiles.push(doc); 
                              mapper[index] = doc;
                              if (temp_count >= mapper.length) {
                                this.disabled_btn = false;
                                this.documents =[];
                                if(category=='attorneySign'){
                                   this.autornyFilesUploading =false;
                                }else{
                                this.premiumProcessingFilesUploading =false;
                                }
                              }
                          });
                      });
                  });
                  model.splice(0, mapper.length, ...mapper);
              }else{
              if(category=='attorneySign'){
                  this.autornyFilesUploading =false;
              }else{
              this.premiumProcessingFilesUploading =false;
              }
                this.showToster({  message: "Upload only image files",  isError: true,  });

              }
      },
      removePremiumProcessingFiles(index ,category){
        if(category == 'petitionerSign' ){
            this.petitionerSign.splice(index ,1)
        }
        if(category == 'attorneySign' ){
            this.attorneySign.splice(index ,1)
        }
       
      },
    },
    watch: {
      showPopup(val) {
        if (!val) this.$emit("hideMe");
      },
    },
    mounted() {
      this.previousExisted =false;
      this.formsAndLettersList =[];
      this.petitionerSign=[];
      this.attorneySign = [];
      this.signerList =[];
      this.selectedSigner =null;
    this.getCompanyDetail();
    this.getAttorneyDetails();
      this.$modal.show("generateSignedDocsPop");
      this.getFormsAndLetters();
      setTimeout(()=>{
        this.fetchWorkFlowDetails();
      });
     
      
    },
    data: () => ({
      companyDetailsLoaded:false,
      attroneyDetailsLoaded:false,
      previousExisted:false,
        premiumProcessingFormErrors:'',
       
        premiumProcessingFilesUploading:false,
        autornyFilesUploading:false,
        documents:[],
        petitionerSign:[],
        attorneySign:[],
        attroneyDetails:'',
        petitionerSignPath:null,
        attroneySignPath:null,
        companyDetails:null,
        workFlowDetails:null,
        editor: ClassicEditor,
        editorConfig: {
            toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
        },
      notifyPetitioner: false,
      emailDocsForSign: false,
      signerList:[],
      selectedSigner:null,
      formsAndLettersList: [],
      requestsignformcomments: "",
      requestsignCommentError: false,
      requestsigning: false,
      trackingErrors: "",
      emailDocsForSign: false,
      actioncomment: "",
      paralegalformerrors: "",
      disabled_btn: false,
      loading: false,
      showPopup: false,
      comments: false,
      formerrors: null,
      uploading: false,
      validateLcaFiles: true,
      updateLca: false,
      filedDate: null,
      certifiedDate: null,
      lcastatuses: [],
      lcaDocuments: [],
      masterSocList: [],
      lcastatusSelected: null,
      documents: [],
      showDataPicker: true,
      number: "",
      updatingLca: false,
      lcaUpdateForm: false,
    }),
    props: {
      petitionDetails: {
        type: Object,
        default: null,
      },
      rolesList: [],
      formsAndLetters: {
        type: Array,
        default: null,
      },
    },
  };
  </script>
  