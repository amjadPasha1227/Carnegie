
<template>
    <modal
      name="linkPwdPopupModal"
      classes="v-modal-sec"
      :min-width="200"
      :min-height="200"
      :scrollable="true"
      :reset="true"
      width="400px"
      height="auto"
    >
      <div class="v-modal profile_details_modal">
        <div class="popup-header fromDetailsPage">
          <h2 class="popup-title" v-if="checkProperty(petitionDetails,'pwdLinked') || checkProperty( petitionDetails ,'pwdId')">Change PWD</h2>
          <h2 class="popup-title" v-else>Link PWD</h2>
          <span  @click="hideMe()">
            <em class="material-icons">close</em>
          </span>
        </div>
  
        <form @submit.prevent data-vv-scope="linkPermForm">
          <div class="form-container" @click="premiumProcessingFormErrors =''">
          
            <div class="vx-row" @click="premiumProcessingFormErrors = ''">
              <div class="vx-col  w-full md:w-full">
                <div class="form_group">
                <div class="form_label">Select PWD <em>*</em></div>
                <div class="con-select w-full">
                  <multiselect
                    name="selectedCase" 
                    v-model="selectedCase" 
                    :close-on-select="true"
                    v-validate="'required'"
                    :multiple="false" 
                    :show-labels="false"
                    label="name" 
                    :formscope="'linkPermForm'"
                    :placeholder="'PWD' "
                    :options="casesList" 
                    :allow-empty="true"
                    :data-vv-as="'PWD '"
                    :preserve-search="true"
                    @search-change="serachPwd"
                  >
                <template slot="selection" slot-scope="{ values, isOpen }">
                    <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{
                        values.length }} selected</span>
                    <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                </template>
              </multiselect>
                </div>

                <span class="text-danger text-sm" v-show="errors.has('linkPermForm.selectedCase')">{{
                                errors.first("linkPermForm.selectedCase") }}</span>
              </div>
              </div>
              
              

                <selectField
                 v-if="false"
                 :display="true" 
                  @input="changesDocs"
                 :wrapclass="'md:w-full'"
                :data-vv-as="'PWD '"
                 data-vv-as="PWD"
                :required="true" 
                :preserve-search="true"
                @search-change="serachPwd"
                :optionslist="casesList"
                 v-model="selectedCase" 
                 :fieldName="'selectedCase'"
                 :formscope="'linkPermForm'" 
                 label="Select PWD" 
                 placeHolder="PWD" />
            </div>
            <div class="vx-row"  @click="premiumProcessingFormErrors = ''">
              <div class="vx-col w-full">
                <div class="form_group">
                  <label class="form_label">Comments</label>
                   <ckeditor data-vv-as="Comments"
                  
                    v-model="premiumProcessingComment"
                    name="comments"
                    class="w-full" :editor="editor" :config="editorConfig"></ckeditor>
                </div>
              </div>
  
              <div class="vx-col w-full pp-col mar0">
              </div>
            </div>
            <div v-show="premiumProcessingFormErrors"  @click="premiumProcessingFormErrors = ''">
              <vs-alert
                color="warning"
                class="warning-alert reg-warning-alert no-border-radius"
                icon-pack="IntakePortal"
                icon="IP-information-button"
                active="true"
                >{{ premiumProcessingFormErrors }}</vs-alert
              >
            </div>
          </div>
          <div class="popup-footer relative">
            <span class="loader" v-if="updatingPremiumProcessing">
              <img src="@/assets/images/main/loader.gif" />
            </span>
  
            <vs-button  color="dark"  @click="hideMe()" class="cancel"   type="filled"  >Cancel</vs-button>
            <vs-button  color="success" :disabled="updatingPremiumProcessing"  @click="submitForm()" class="save" type="filled">
              <template v-if="checkProperty(petitionDetails,'pwdLinked') || checkProperty( petitionDetails ,'pwdId')">Update</template>
              <template v-else>Link PWD</template>
              
            </vs-button>
          </div>        
        </form>
      </div>
    </modal>
  </template>
  <script>
import selectField from "@/views/forms/fields/simpleselect.vue";
  import moment from "moment";
  import FileUpload from "vue-upload-component/src";
  import { EyeIcon } from 'vue-feather-icons'
  import docType from "@/views/common/docType.vue"
  import Vue from 'vue';
  Vue.use( CKEditor );
  import CKEditor from '@ckeditor/ckeditor5-vue2';
  import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
  import * as _ from "lodash";

  export default {
    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
      components: {
        selectField,
      docType,
      EyeIcon,
      FileUpload
    },
    methods: {
      serachPwd(text=''){
        
        clearTimeout(this.debounce)
      this.debounce = setTimeout(() => {
        this.getPwdList(text);
      }, 900)
      },
      removePremiumProcessingFiles(index){
        this.premiumProcessingFiles.splice(index ,1)
      },
        getPwdList(searchString){
         
            let postdata = {
                      matcher: {
                        "searchString":"",
                        getMasterDataOnly: true, 
                        petitionerIds: [],
                        statusIds: [9 ,10],
                        linkPwd:true
                      },
                      "page": 1,
                      "perpage": 1000
                   }

            if(searchString){
             postdata['matcher']['searchString'] =searchString
            }   
            if(this.checkProperty( this.petitionDetails  ,'petitionerId')){
              postdata['matcher']['petitionerIds'] = [this.petitionDetails['petitionerId']];
            }

            this.$store.dispatch("getList", {data: postdata,path: '/pwd/list',}).then((response) => {
                let tempList = [];
                _.forEach(response['list'],(item)=>{
                    if(_.has(item,'caseNo')){
                        item =Object.assign(item,{ 'name':item['caseNo'],'id':item['_id']});
                        tempList.push(item)
                    }
                })
                this.casesList = tempList;
                if(this.checkProperty(this.petitionDetails,'pwdId')){
                    let pwdId = this.petitionDetails['pwdId'];
                    let selectedCase = _.find(this.casesList ,{"_id": pwdId});
                    if(selectedCase){
                     
                        this.selectedCase =selectedCase;
                        this.changesDocs(this.selectedCase);
                        this.$validator.reset();
                    }
                    //alert(JSON.stringify(selectedCase))
                }
            });
        },
        changesDocs(item){
            this.selectedCase = item
            if(this.checkProperty(this.selectedCase,'permDocs')){
                this.premiumProcessingFiles = this.checkProperty(this.selectedCase,'permDocs')
            }
        },

      submitForm() {
        this.premiumProcessingFormErrors ='';
        this.$validator.validateAll('linkPermForm').then((result) => {
        let self =this;
            if (result) {
              if(this.checkProperty(this.petitionDetails,'pwdId') == self.checkProperty(self.selectedCase, '_id')){
                this.showToster({message:"Selected PWD is already assigned",isError:true });
                return false;
              }
            let postData ={
                caseNo:self.checkProperty(self.selectedCase,'caseNo'),
                petitionIds :[] ,
                
             //   today: moment().format("YYYY-MM-DD"),
                comments:self.premiumProcessingComment,
               // typeName:self.checkProperty(self.petitionDetails ,'typeDetails','name'),
               // subTypeName:self.checkProperty(self.petitionDetails ,'subTypeDetails','name'),
                pwdId: self.checkProperty(self.selectedCase, '_id')
            }

            postData['petitionIds'].push(self.checkProperty(self.petitionDetails ,'_id'));
            
           
            this.updatingPremiumProcessing =true;
            
            this.$store.dispatch("commonAction", {"data":postData ,"path":"/pwd/manage-pwd-linking"})
            .then(response => {
                this.updatingPremiumProcessings =false;
                this.hideMe();
                this.showToster({message:response.message,isError:false });
                this.$emit("updatepetition", "Case Details");             
            })
            .catch((error)=>{
                this.premiumProcessingFormErrors =error;
                this.updatingPremiumProcessing =false;
            }) 
            }
        });
      },
      hideMe() {
        this.$emit("hideMe");
      },
    },
    watch: {
      showPopup(val) {
        if (!val) this.$emit("hideMe");
      },
    },
    mounted() {
        this.premiumProcessingComment = '',
        this.premiumProcessingFiles = [];
        this.selectedCase = null;
        this.getPwdList()
      this.$modal.show("linkPwdPopupModal");
    },
    data: () => ({
      debounce:null,
        updatingPremiumProcessing:false,
        selectedCase:null,
        casesList:[],
        editor: ClassicEditor,
        editorConfig: {
            toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
        },
        loading: false,
        showPopup: false,
        comments: false,
        formerrors: {
            msg: "",
        },
        premiumProcessingFormErrors:'',
        premiumProcessingComment:'',
        premiumProcessing:false, 
    }),
    props: {
      caseNumber: {
        type: String,
        default: null,
      },
      isCaseNumberEdit: {
        type: Boolean,
        default: false,
      },
      petitionDetails: {
        type: Object,
        default: null,
      },
    },
  };
  </script>