<template> 
  <modal
    name="generatePinModal"
    classes="v-modal-sec"
    :min-width="200"
    :min-height="200"
    :scrollable="true"
    :reset="true"
    width="600px"
    height="auto"
  >
    <div class="v-modal profile_details_modal">
      <div class="popup-header fromDetailsPage">
        <h2 class="popup-title">

            <template v-if="checkProperty( petitionDetails ,'qstPinSet')">Verify PIN</template>
            <template v-else-if="!checkProperty( petitionDetails ,'qstPinSet')">Set PIN</template>
        </h2>
        <span @click="hideMe()" v-if="false">
          <em class="material-icons">close</em>
        </span>
      </div>

      <form @submit.prevent data-vv-scope="generatePinForm" @submit.prevent @keydown.enter.prevent>
        <div class="form-container" @click="formerrors.msg=''">
    
          <div class="vx-row" >

             <vs-col class="w-full p-0" >
                <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal" icon="IP-information-button" active="true">
                    
                    <template v-if="checkProperty( petitionDetails ,'qstPinSet')">You are required to verify PIN to continue with questionnaire.</template>
                    <template v-else>You are required to setup the PIN to continue.</template>
                  </vs-alert>
            </vs-col>
          </div>
       
        <div  class="vx-row ">
          <immiInput 
           :wrapclass="'vx-col w-full'" 
            :display="true"
             cid="conformPin"
            :formscope="'generatePinForm'"
            v-model="conformPin"
            :required="true" 
            fieldName="conformPin"
            @input="processPin()"
            label="PIN"
             placeHolder="PIN" 
             :maxLength="4"
             :helpText="checkProperty( petitionDetails ,'qstPinSet')?'':''"
             />
                  
               <div class="vx-col w-full" v-if="false">
                  <div class="form_group">
                    <span>You are required to setup the PIN to continue</span>
                    <vs-input 

                      @input="processPin()"
                      style="width: 100%"
                      data-vv-as="PIN"
                      v-validate="'required'"
                      v-model="conformPin"
                      name="conformPin"
                      label="PIN*"
                    />
                    <span
                      class="text-danger text-sm"
                      v-show="errors.has('generatePinForm.conformPin')"
                      >{{ errors.first("generatePinForm.conformPin") }}</span
                    >
                  </div>

                  <div v-if="checkProperty( petitionDetails ,'qstPinSet') && false" class="flex flex-wrap justify-between my-5 remember-password"   vs-align="center">
                    
                <vs-checkbox v-model="rememberPin">Remember this browser</vs-checkbox>
               
              </div>
                </div>

        </div>

          <div v-show="formerrors.msg">
            <vs-alert
              color="warning"
              class="warning-alert reg-warning-alert no-border-radius"
              icon-pack="IntakePortal"
              icon="IP-information-button"
              active="true"
              >{{ formerrors.msg }}</vs-alert
            >
          </div>
          
        </div>
        <div class="popup-footer relative">
          <span class="loader" v-if="caseTypeCahnging"  ><img src="@/assets/images/main/loader.gif"  /></span>

          <vs-button v-if="false" color="dark"  @click="hideMe()" class="cancel"  type="filled"  >Cancel</vs-button>

          <vs-button  color="success"  @click="submitForm()"  class="save" type="filled" >
            <template v-if="!checkProperty( petitionDetails ,'qstPinSet')"> Set PIN</template>
              <template v-else>Verify</template>
        
        </vs-button>
        </div>
      </form>
    </div>
  </modal>
</template>
<script>
import immiInput from "@/views/forms/fields/simpleinput.vue";
export default {
  methods: {
    processPin(){
      
      this.conformPin = this.conformPin.replace(/[^a-z A-Z 0-9]/g, '')
      this.conformPin = this.conformPin.replace(/(\..*)\./g, '$1');
      this.conformPin = this.conformPin.replace(/ /g,'');
     // alert(this.conformPin)
     this.conformPin = this.conformPin.slice(0, 4);
    },
    dontAskThisBrowser(callFromVerify=false){
      let self =this;
      let userData = this.getUserData;
      let localData = localStorage.getItem("pinAccessData");
      let dt = {"userId":'', "petitionId":''};
     if(this.checkProperty(userData ,"userId")){
    
        dt['userId'] = userData['userId'];
        dt['petitionId'] = this.petitionDetails._id;

     }
     if(localData){
       localData = JSON.parse(atob(localData));
       
       
     }else{
      localData =[];
     }

    
      
      if(this.rememberPin){
      if(!_.find(localData ,{ "userId":userData["userId"],"petitionId": self.petitionDetails._id })){
        localData.push(dt);
      }

      }else{
      localData  =_.filter(localData,(item)=>{
        return item['userId'] !=userData["userId"]
      });
     }
     
     const string = JSON.stringify(localData) // convert Object to a String
     let encodingString = btoa(string)
     localStorage.setItem("pinAccessData",encodingString);

      
     



      

    
     
     
     


    },
    submitForm() {
      this.$validator.validateAll("generatePinForm").then((result) => {
        this.caseTypeCahnging = false;
        if (result) {
          Object.assign(this.formerrors, { msg: "" });
          let postData = {
            "pin":this.conformPin,
            petitionId: this.petitionDetails._id,
          //  subType: this.checkProperty( this.petitionDetails ,'typeDetails' ,'id'),
         //   typeName: this.checkProperty( this.petitionDetails ,'typeDetails' ,'name'),
          //  subTypeName: this.checkProperty( this.petitionDetails ,'subTypeDetails' ,'name'),
            "entityType": "case" //perm lca
           
          };
          
          this.caseTypeCahnging = true;
          let url = "/petition-common/set-pin";
          if(this.checkProperty(this.petitionDetails ,'qstPinSet')){
            url = "/petition-common/verify-pin";
            
          }
          if( !this.loadedFromLca &&[15].indexOf(this.checkProperty(this.petitionDetails,'subTypeDetails', 'id' )) >-1){
            postData['entityType'] = "perm"
          }
          if(this.loadedFromLca){
            postData['entityType'] = "lca"
          }
          this.$store
            .dispatch("commonAction", {
              data: postData,
              path: url,
            })
            .then((response) => {
              if(this.rememberPin && url=="/petition-common/verify-pin" ){
               this.dontAskThisBrowser(true);
              }
              this.showToster({ message: response.message, isError: false });
              this.caseTypeCahnging = false;
              this.$emit("updateVerificationStatus", true);
              this.hideMe()
            })
            .catch((error) => {
              this.caseTypeCahnging = false;
              Object.assign(this.formerrors, { msg: error });
            });
        }
      });
    },
    hideMe() {
      this.$modal.hide("generatePinModal");
      this.$emit("hideMe");
    },
    getvisasubtypes() {
      Object.assign(this.formerrors, { msg: "" });
      if (this.selectedCaseType && _.has(this.selectedCaseType, "id")) {
        this.visasubtypes = [];
        this.selectedCaseSubType = null;
        let item = {
          matcher: {
            petitionType: parseInt(this.selectedCaseType["id"]),
          },
          page: 1,
          perpage: 1000,
          category: "petition_sub_types",
        };

        this.$store.dispatch("getMasterData", item).then((response) => {
          this.visasubtypes = response.list;
          this.visasubtypes = _.filter(response.list, (item) => {
            return (
              this.checkProperty(
                this.getPetitionDetails,
                "subTypeDetails",
                "id"
              ) != item["id"]
            );
          });
        });
        this.$validator.reset();
      }
    },
  },
  mounted() {
    this.$modal.show("generatePinModal");
    //this.getvisasubtypes();
    

  },
  data: () => ({
    rememberPin:false,
    conformPin:'',
    caseTypeCahnging: false,
    formerrors: {
      msg: "",
    },
    selectedAssignedUsers: [],
    selectedCaseSubType: null,
    visasubtypes: [],
  }),
  props: {
    loadedFromLca:{
      type:Boolean,
      default:false
    },
    petitionDetails: {
      type: Object,
      default: null,
    },
    currentCaseSubType: {
      type: Object,
      default: null,
    },
    selectedCaseType: {
      type: Object,
      default: null,
    },
    assignedUsersList: {
      type: Array,
      default: null,
    },
    visatypes: {
      type: Array,
      default: null,
    },
  },
  provide() {
            return {
                parentValidator: this.$validator,
            };
        },
  components: {
    immiInput
    
  }
};
</script>