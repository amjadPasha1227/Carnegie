<template>
   
    <modal
          name="updateUscisStatus"
          classes="v-modal-sec"
          :min-width="200"
          :min-height="200"
          :scrollable="true"
          :reset="true"
          width="650px"
          height="auto"
        >
        <div class="v-modal profile_details_modal error-modal-space" >
          <div class="popup-header fromDetailsPage">
            <h2 class="popup-title">              
              <template v-if="ACTIVITYCODE=='EFILE_PREM_APPLICATION_DRAFT'">Submit PERM to DOL (E-File)</template>

                <template v-if="ACTIVITYCODE=='EFILE_PREM_APPLICATION'">Prepare PERM Draft at DOL (E-File)</template>
                <template v-if="ACTIVITYCODE=='REQUEST_PERM_DRAFT_REVIEW'">
                  <template v-if="getTenantTypeId ==2">Request for PERM Draft Review</template>
                  <template v-else>Request Petitioner for PERM Draft Review</template>
                  
                </template>
            </h2>
            <span @click="showPopup=false;$modal.hide('updateUscisStatus');">
              <em class="material-icons">close</em>
            </span>
          </div>
          <form @submit.prevent data-vv-scope="uscisstatus" class="trackingform">
              <div class="form-container" @click="pewResponceUpdateStatusError='';showDocumentsError=false">
                <template v-if="ACTIVITYCODE=='REQUEST_PERM_DRAFT_REVIEW'">
                      
                    <div  class="vx-row" @click="documentModel=[]" >
                    
                    <div div class="vx-col w-full">
                        <div class="form_group">
                          <label class="form_label" style="text-transform: capitalize"> Documents<em>*</em></label>
                        <div class="uploadsec_wrap upload_uscis">
                        <div class="w-full">
                            <div class="relative">
                                <file-upload
                                v-model="documentModel"
                                class="file-upload-input mb-0"
                                style="height:50px;"
                                name="trackingdoc"
                                :multiple="false"
                                
                                data-vv-as="Documents"
                                :accept="allDocEntity"
                                @input="uploadDocuments()"
                                >
                                <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                                Upload
                                </file-upload>
                                <span class="loader" v-if="filesAreuploading"><img src="@/assets/images/main/loader.gif"></span>
                            </div>
                            <span class="file-type">(File Type: PDF, DOC, JPEG, PNG. Max file size: 1MB)</span>
                            <span class="text-danger text-sm document-error" v-if="showDocumentsError && actionData['documents'].length<=0 "><em>*</em> Documents are required</span>
                            <!-- <VuePerfectScrollbar class="scrollbardoc"> -->
                                
                                <div class="uploded-files_wrap mb-5" v-if="actionData['documents'].length >0 ">
                                    <template v-for="(fil, fileindex) in actionData['documents']">
                                        <div class="w-full"  :key="fileindex" >
                                            <div class="uploded-files">
                                                <vx-input-group class="form-input-group">
                                                <vs-input v-on:keyup="fileNameChenged(fil)"  v-validate="'required'" class="w-full" :name="'fName'+fileindex" v-model="actionData['documents'][fileindex]['name']" data-vv-as="File Name" />
                                                    <span class="text-danger text-sm" v-show="errors.has('uscisstatus.fName'+fileindex)">{{ errors.first('uscisstatus.fName'+fileindex) }}</span>

                                                    
                                                </vx-input-group>

                                                <div class="form_group">
                                                

                                                
                                                <div class="delete" style="z-index:999" @click="remove(fileindex , actionData['documents'])">
                                                        <img src="@/assets/images/main/delete-row-img.svg" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </template>
                                </div>
                            <!-- </VuePerfectScrollbar> -->
                            </div>
                        </div>
                        </div>
                    </div>

                    <div class="vx-col w-full">
                    <div class="form_group">
                      <label class="form_label">Comments<em>*</em></label>
                      <!-- <vs-textarea
                        data-vv-as="Comments"
                        v-validate="'required'"
                        v-model="actionData.comment"
                        name="usciscomments"
                        class="w-full"
                      /> -->
                      <ckeditor  data-vv-as="Comments"
                        v-validate="'required'"
                        v-model="actionData.comment"
                        name="usciscomments"
                        class="w-full" :editor="editor" :config="editorConfig"></ckeditor>

                      <span
                        class="text-danger text-sm"
                        v-show="errors.has('uscisstatus.usciscomments')"
                      >* Comments are required</span>
                    </div>
                    </div>
                    
                    </div>

              </template>
              <template  v-if="ACTIVITYCODE=='EFILE_PREM_APPLICATION_DRAFT'"> 
                  <div class="modal-confirm-msg">
                    <p>Using our Browser Extension PERM Draft can be prepared at DOL</p>
                    <div class="popup-footer pl-0 pr-0">
                <!-- <a @click="showPopup=false;redirectDolSite();$modal.hide('updateUscisStatus');"  href="https://www.plc.doleta.gov/eta_start.cfm?actiontype=home" target="_blank"> <vs-button color="success" class="save" type="filled">Click here to proceed</vs-button>
</a> -->
<a @click="redirectDolSite();"  > <vs-button color="success" class="save" type="filled">Click here to proceed</vs-button>
</a>

</div>
            </div>
                 
                </template>
                <template  v-if="ACTIVITYCODE=='EFILE_PREM_APPLICATION'"> 
                  <div class="modal-confirm-msg" >
              <p>Using our Browser Extension PERM Draft can be prepared at DOL</p>
              <div class="popup-footer pl-0 pr-0">
                <!-- <a  @click="showPopup=false;redirectDolSite();$modal.hide('updateUscisStatus');"  href="https://www.plc.doleta.gov/eta_start.cfm?actiontype=home" target="_blank"> <vs-button color="success" class="save" type="filled">Click here to proceed</vs-button>
</a> -->
<a @click="redirectDolSite();"  > <vs-button color="success" class="save" type="filled">Click here to proceed</vs-button>
</a>
</div>
            </div>
                  <div class="vx-row mt-5">
                    <immiInput :maxCharacters ="20" :wrapclass="'md:w-full'" :display="true" :cid="'permApplicationNo'" :formscope="'uscisstatus'" v-model="actionData.permApplicationNo" :required="true" fieldName="permApplicationNo" label="PERM Application Number" placeHolder="PERM Application Number"  />
                    <datepickerField  :formscope="'uscisstatus'"  :dateEnableTo="new Date()"   wrapclass="md:w-full"  v-model="actionData.priorityDate" :cid="'filedDate'"  :fieldName="'filedDate'" label="Filed Date" :validationRequired="true" />
                 
                  </div>
                    


                  <!------priorityDate-->
                </template>

                
              </div>
              
              <div @click="pewResponceUpdateStatusError=''" class="text-danger text-sm formerrors" v-if="pewResponceUpdateStatusError!=''">
                        <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ pewResponceUpdateStatusError }}</vs-alert>
              </div>

              <div class="popup-footer relative"  v-if="ACTIVITYCODE!='EFILE_PREM_APPLICATION_DRAFT'">
              
              <span class="loader" v-if="pwdResUpdating"><img src="@/assets/images/main/loader.gif"></span>
                <vs-button color="dark" class="cancel" type="filled" @click="documentModel=[]; hideMe()">Cancel</vs-button>
                <vs-button color="success" :disabled="pwdResUpdating" @click="submitForm()" class="save" type="filled">Submit</vs-button>
              </div>
          </form>
          </div>
        </modal>  
</template>
<script>

import moment from "moment";
import FileUpload from "vue-upload-component/src";
import { EyeIcon } from "vue-feather-icons";
import docType from "@/views/common/docType.vue";
import Datepicker from "vuejs-datepicker-inv";
import * as _ from "lodash";
import immiInput from "@/views/forms/fields/simpleinput.vue";
import immitextarea from "@/views/forms/fields/simpletextarea.vue";
import selectField from "@/views/forms/fields/simpleselect.vue";
import datepickerField from "@/views/forms/fields/datepicker.vue";
import Vue from 'vue';
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';

export default {
provide() {
        return {
           parentValidator: this.$validator,
        };
    },
components: {
  docType,
  EyeIcon,
  FileUpload,
  Datepicker,
  immiInput,
  //immitextarea,
  datepickerField,
  selectField
},
methods: {
  redirectDolSite(){
    this.showPopup=false;
    this.$modal.hide('updateUscisStatus');
    if(_.has(this.petitionDetails,'completedActivities') && this.checkProperty(this.petitionDetails,'completedActivities') && this.petitionDetails['completedActivities'].indexOf('PERM_MISSING_EFILE_INFO')<=-1 ){
      this.$emit('openNewPermFieldsPopup')
    }else{
      //window.open("https://flag.dol.gov/auth/auth/login-gov/login/loa-1");
      window.open("https://www.plc.doleta.gov/eta_start.cfm");
    }

  },
    updatesocCode(item){ 

      if(_.has( item ,'id')){
      this.actionData['socCode'] = item['id'];
      }
    },
  getMasterSocList(){

            let query = {};
            query["page"] = 1;
            query["perpage"] = 10000;
            query["matcher"] = {};
            query["category"] = "soc_codes";


            this.$store
            .dispatch("getMasterData", query)
            .then((response) => {
            this.masterSocList = response.list;


            //alert(this.perpage);
            })
            .catch(() => {
            this.masterSocList = [];

            });

  },
  remove(index ,docs){
    docs.splice(index ,1);
    if(this.actionData['documents'].length<=0){
        this.showDocumentsError =true;
    }
    this.showDocumentsError =false;
      
  },
  /**
   * 
   * @param userType | String
   * @param typeId | String
   * @param childrenId | String
   * @param userName | String
   */
  uploadDocuments(){
       let docs =_.cloneDeep(this.documentModel);
       this.documentModel=[];
        
          docs = docs.map(
              (item) =>{
                  item = {
                      name: item.name,
                      file: item.file,
                      path: "",
                      mimetype: item.type,
                      extn:item.extn?item.extn:'',
                      documentType:item.documentType?item.documentType:null,
                      userName:'',
                      status:true
                     
                  }
                 
                  
              return item;

            }
          );
         
          if (docs.length > 0) {
              var self = this;
              this.filesAreuploading = true;
              
              let count =0;
              docs.forEach(function (doc) {
                  let formData = new FormData();
                  formData.append("files", doc.file);
                  formData.append("secureType", "private");
                  formData.append("getDetails", true);
                  self.$store.dispatch("uploadS3File", formData).then((response) => {
                    count = count+1;
                      if (response.data && response.data.result) {
                          response.data.result.forEach((urlGenerated) => {
                            //alert(JSON.stringify(urlGenerated))
                              // doc.url = urlGenerated;
                               doc.path = urlGenerated['path'];
                               doc.mimetype = urlGenerated['mimetype'];
                                doc.extn = urlGenerated['extn'];
                                doc['status'] =true;
                               
                              delete doc.file;
                              if(urlGenerated['path']){
                                 self.actionData['documents'].push(doc)
                               //  self.statusDocuments.push(doc)
                               self.showDocumentsError =false;
                              }
                              
                              if(parseInt(count)>=docs.length){
                                 self.filesAreuploading = false;
                                 self.pwdResUpdating =false;
                               

                              }
                          });
                          if(count>=docs.length){
                            self.filesAreuploading = false;
                            self.pwdResUpdating =false;
                         

                          }
                          
                      }
                     
                  });
              });
          }
  },
 
    
  fileNameChenged(index, fileindex) {
          this.disable_uploadBtn = false;

          _.forEach(this.actionData['documents'], (doc, value) => {
              let fname = doc.name;
              fname = fname.trim();

              if (!fname) {
                  this.disable_uploadBtn = true;
              }
          });

      },


    
  submitForm() {
     //alert(this.approveRejecInstructions);
          this.pewResponceUpdateStatusError='';
          this.showDocumentsError =false;
          this.$validator.validateAll("uscisstatus").then((result) => {
            if(this.checkProperty(this.actionData ,'documents' ,'length')<=0 && this.ACTIVITYCODE !="EFILE_PREM_APPLICATION"){
                this.showDocumentsError =true;
              }
             // alert(result+" ===="+!this.filesAreuploading + " === " +!this.showDocumentsError)

             if(result && !this.filesAreuploading && !this.showDocumentsError){
              this.pwdResUpdating =true;
              let path ="/perm/manage-perm-application";
              let data = {
                "petitionId": "",
                "typeName": "",
                "subTypeName": "",

                // REQUEST_PERM_DRAFT_REVIEW
                "action": 'REQUEST_PERM_DRAFT_REVIEW',//"REQUEST_PERM_DRAFT_REVIEW",'EFILE_PREM_APPLICATION'
                "comment": "",
                "documents": [],
                
                // EFILE_PREM_APPLICATION
                permApplicationNo:''
            }
             
              if(this.ACTIVITYCODE =="EFILE_PREM_APPLICATION"){
                  data = { 'permApplicationNo':'' ,'petitionId':'' ,"typeName": "", 	"subTypeName": "", "action":'EFILE_PREM_APPLICATION' ,"priorityDate":null}; 
                  if(this.checkProperty(this.actionData ,'priorityDate')){
                    data['priorityDate'] = moment(this.actionData['priorityDate']).format( "YYYY-MM-DD");
                  }
                 

                  data['permApplicationNo'] = this.actionData['permApplicationNo'];
                  data['permApplicationNo'] = data['permApplicationNo'].trim();

                 
              }else if(this.ACTIVITYCODE =="REQUEST_PERM_DRAFT_REVIEW"){
                
                data = { 'petitionId':'' ,"typeName": "", 	"subTypeName": "", "action":'REQUEST_PERM_DRAFT_REVIEW' ,"comment": "", "documents": []}; 
                data['comment'] =this.actionData['comment'];
                data['documents'] =this.actionData['documents'];

              }
              data['petitionId'] = this.checkProperty( this.petitionDetails ,'_id');
              data['typeName'] = this.checkProperty( this.petitionDetails , 'typeDetails','name');
              data['subTypeName'] = this.checkProperty( this.petitionDetails ,'subTypeDetails','name');
              data['action']  =this.ACTIVITYCODE; 

             
              this.$store.dispatch('commonAction' ,{ "data":data ,'path':path})
              .then((res)=>{
                this.showToster({message:res['message'],isError:false });
                this.hideMe();
                this.$emit("updatepetition");
              })
              .catch((error)=>{
                this.pewResponceUpdateStatusError =error;
                this.pwdResUpdating =false;
               })

              

             }
          });
  },
  hideMe() {

    this.$emit("hideMe");
    setTimeout(()=>{
        this.$modal.hide('updateUscisStatus');
      },10);
  },
},
watch: {
  showPopup(val) {
    if (!val){
      this.$emit("hideMe");
      this.$modal.hide('updateUscisStatus');
    } 
  },
},
mounted() {
 
  
    this.getMasterSocList();
    this.showPopup = true;
    this.$modal.show('updateUscisStatus');
  
},
data: () => ({
  editor: ClassicEditor,
 editorConfig: {
     toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
 },
  showDocumentsError:false,
  masterSocList:[],
  pwdResUpdating:false,
  pewResponceUpdateStatusError:'',
  actionData:{
     "petitionId": "",
     "typeName": "t",
      "subTypeName": "",
      "priorityDate":null,
      // REQUEST_PERM_DRAFT_REVIEW
      "action": 'REQUEST_PERM_DRAFT_REVIEW',//"REQUEST_PERM_DRAFT_REVIEW",'EFILE_PREM_APPLICATION'
      "comment": "",
      "documents": [],
     
      // EFILE_PREM_APPLICATION
      permApplicationNo:''
},

 
  
 documentTypes:["Original" ,"Electronic" ],
  documentModel:[],
  statusDocuments:[],
 filesAreuploading: false,
  
  uploading: false,
  courierList: [],
  tracking: { documents: [], receiptNumber: null, receiptName: null },
  
  
  openDate: new Date().setFullYear(new Date().getFullYear()),
  startEligibleDate: new Date().setFullYear(new Date().getFullYear()),
  
  disabled_btn: false,
  showPopup: false,
  documents: [],
 
}),
props: {
  workFlowDetails:{
    type: Object,
    default: null,
  },
  ACTIVITYCODE: {
    type: String,
    default: null,
  },
  petitionDetails: {
    type: Object,
    default: null,
  },
},
computed:{

  getActivityRoles(){
    let allRoles=''
    return (activityCode)=>{
      if(this.workFlowDetails && _.has(this.workFlowDetails ,'config' )){
        let actiVity = _.find(this.workFlowDetails.config , {"code":activityCode });
        if(actiVity && _.has(actiVity ,'editors' )){
          let activityRoles = _.map(actiVity['editors'], (editor)=>editor['roleName']);
          allRoles = activityRoles.join(' / ')
        }
       
      
      }
return allRoles

    }
  }
  
}
};
</script>
