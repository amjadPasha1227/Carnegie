<template>
    <div class="vx-col " @keydown.enter.prevent > 
     <template>
        <div class="vx-row " @keyup="updateData()" >
        <immiInput :wrapclass="'md:w-1/2'" :display="true" :cid="'Job Title'" :formscope="formscope"  v-model="value.jobTitle" :required="true" fieldName="Job Title" label="Job Title" placeHolder="Job Title"   />
        <immiInput :onlyNumbers="true" :allowFloatingPoint="false" :wrapclass="'md:w-1/2 custom_form_group'" :display="true" cid="noOfPositions" :formscope="formscope"  v-model="value.noOfPositions" :required="true" fieldName="noOfPositions" label="Number of Positions" placeHolder="Number of Positions"  :maxLength="5" />
        
        <!-- <immiInput :wrapclass="'md:w-1/3'" :display="true" :cid="'SOC Occupation Title'" :formscope="formscope"  v-model="petitionDetails['jobDetails'].JobTitle" :required="true" fieldName="SOC Occupation Title" label="SOC Occupation Title" placeHolder="SOC Occupation Title"   /> -->
        <selectField :listContainsId="false" :wrapclass="'md:w-1/2'" :required="true"  cid="Classification "  :formscope="formscope" :optionslist="category" v-model="value.classification"    fieldName="Classification" label="Classification" placeHolder="Classification"   /> 
        <selectField :wrapclass="'md:w-1/2'" :required="true"  cid="preferredSocCode" :showOptionItemStatus="true" :formscope="formscope" :optionslist="masterSocList" v-model="value.preferredSocCodeDetails" @input="updatepreferredsocCode"   fieldName="preferredSocCode" label="Preferred SOC Code" placeHolder="Preferred SOC Code"   /> 
        <immiInput    :wrapclass="'md:w-1/2'" :display="true" cid="preferredSocOccuTitle" :formscope="formscope"  v-model="value.preferredSocOccuTitle" :required="true" fieldName="preferredSocOccuTitle" label="Preferred SOC Occupation Title" placeHolder="Preferred SOC Occupation Title"   />

        <selectField v-show="certifedVisible" :display="certifedVisible" :wrapclass="'md:w-1/2'" :required="certifedVisible"  cid="socCode"  :formscope="formscope" :optionslist="masterSocList" v-model="value.socCodeDetails" @input="updatesocCode"   fieldName="socCode" label="SOC Code" placeHolder="SOC Code"   />
        <immiInput   v-show="certifedVisible" :wrapclass="'md:w-1/2'" :display="certifedVisible" cid="socOccuTitle" :formscope="formscope"  v-model="value.socOccuTitle" :required="certifedVisible" fieldName="socOccuTitle" label="SOC Occupation Title" placeHolder="SOC Occupation Title"   />   
        <selectField :wrapclass="'md:w-1/2'" :required="true"  cid="Education"  :formscope="formscope" :optionslist="educationTypes" v-model="value.minDegreeDetails" @input="value.minDegree=value.minDegreeDetails['id']"   fieldName="Education" label="Minimum Education" placeHolder="Minimum Education"   />  
         <immiInput :wrapclass="'md:w-1/2'" :display="true" :cid="'majorFieldsOfStudy'" :formscope="formscope"  v-model="value.majorFieldsOfStudy" :required="true" fieldName="majorFieldsOfStudy" label="Major Field of Study" placeHolder="Major Field of Study"   />
        <immiInput :onlyNumbers="true" :allowFloatingPoint="false" :wrapclass="'md:w-1/2 custom_form_group'" :display="true" cid="expInYears" :formscope="formscope"  v-model="value.expInYears" :required="true" fieldName="expInYears" label="Experience in Months" placeHolder="Experience"  :maxLength="5" />
        <immiInput v-show="certifedVisible" :onlyNumbers="true" :display="certifedVisible"  :wrapclass="'md:w-1/2'" cid="wageRate" :formscope="formscope"  v-model="value.wageRate" :required="certifedVisible" fieldName="wageRate" label="Prevailing Wage" placeHolder="Prevailing Wage"   />

        
        
        
        <!-- <immiInput :onlyNumbers="true" :wrapclass="'md:w-1/3'" :display="true" cid="wageRate" :formscope="'wageInfo'" v-model="petitionDetails.wageInfo.wageRate" :required="true" fieldName="wageRate" label="Preferred Wage Rate" placeHolder="Preferred Wage Rate" :maxLength="9" /> -->
        <template >
            <div class="vx-col w-full mt-2">
                <div class="skilladdsec">
                    <label>Skills Required</label>
                    <ul>
                        <li v-for="(skil , index ) in value['skills']" :key="index">
                            <span class="skill-label">{{skil}}</span>                                  
                            <span  @click="removeSkill(index)" class="row_btn">
                                <img src="@/assets/images/main/delete-row-img.svg">
                            </span>
                        </li>
                    </ul>
                    <div class="add-input-sec" >
                        
                        <div  @keyup="addSkill=true;skillTextError=false" class="skill-text" :class="{'skill-text-error':skillTextError}">
                            <immiInput @keyEnter="addSkill=true;skillTextError=false;addNewSkill()" :wrapclass="'w-full'"  :display="true" cid="addSkill" :formscope="'jobOpptInfo'"  v-model="newSkill" :required="false" fieldName="altAcceptExpInYears" placeHolder=""  />
                             <!-- v-if="addSkill" -->
                            <span   @click="addNewSkill()" class="add-more">Add</span>
                        </div>
                    </div>
                </div>
            </div>
        </template> 

        <div class="vx-row ml-0 mr-0" v-if="checkProperty(value ,'altJobRequirements')">


<redioButtons  :wrapclass="'md:w-full'"  :required="true"  :cid="'Alternative Job Requirements'"  @input="updatedAlternateJobDetails($event)"
      :formscope="formscope" v-model="value.altJobRequirements.areAltSetsOfEducation" fieldName="Alternative Job Requirements"
      label="Are alternate sets of Education, Training, and/or Experience accepted?" placeHolder="" />
    <!-----Specify the alternate level of education: U.S. diploma/degree accepted §-->
    <template v-if="checkProperty(value,'altJobRequirements','areAltSetsOfEducation')=='Yes'">

        <selectField :wrapclass="'md:w-1/2'" :required="true"  cid="alternativeEducation"  :formscope="formscope" :optionslist="educationTypes" v-model="value.altJobRequirements.altevelOfEducationDetails" @input="updatedAlternativeEducation"   fieldName="Education" label="Alternate level of education" placeHolder="Alternate level of education"   />  
        <template v-if="checkProperty(value,'altJobRequirements','altevelOfEducation')==8">
        <!-----If Other Dgree Selected -->
            <immiInput :wrapclass="'md:w-1/2'" :display="true" :cid="'Other degree'" :formscope="formscope"  v-model="value.altJobRequirements.usDiplomaOrDegreeAccepted" :required="true" fieldName="Other Degree" label="Other Degree" placeHolder="Other Degree"   />
            <immiInput :wrapclass="'md:w-1/2'" :display="true" :cid="'Other Degree Field'" :formscope="formscope"  v-model="value.altJobRequirements.majorsOrFieldsOfStudyAccepted" :required="false" fieldName="Majors Field of Other Degree " label="Majors Field of Other Degree" placeHolder="Majors Field of Other Degree"   />
    </template>
  </template>
    <redioButtons :wrapclass="'md:w-full'" :required="true"   :cid="'Alternative Training'"
      @input="updatedAlternateTraining($event)"  :formscope="formscope"  v-model="value.altJobRequirements.isAltTrainingForTheJobOpporAccepted"
      fieldName="Alternative Training"  label="Alternate training for the job opportunity accepted?"
      placeHolder="" />
    
    <template v-if="checkProperty(value,'altJobRequirements','isAltTrainingForTheJobOpporAccepted')=='Yes'">
     <!-----If Alternative Training Selected specify the number of months of alternate training accepted   -->
       <immiInput :onlyNumbers="true" :allowFloatingPoint="false" :wrapclass="'md:w-1/2 custom_form_group'" :display="true" cid="noOfMonthsOfAltTrainingAccepted" :formscope="formscope" @input="updatednoOfMonthsOfAltTrainingAccepted" v-model="value.altJobRequirements.noOfMonthsOfAltTrainingAccepted" :required="true" fieldName="expInYears" label="Alternative Training Experience in Months" placeHolder="Alternative Training Experience"  :maxLength="5" />
       <immiInput :wrapclass="'md:w-1/2'" :display="true" :cid="'Alternate Training Field'" :formscope="formscope"  v-model="value.altJobRequirements.filedsOrNamesOfTrainingAccepted" :required="false" fieldName="Majors Field of Alternate Training Field" label="Majors Field of Alternate Training Field" placeHolder="Majors Field of Alternate Training Field"   />
      
    </template>
     <redioButtons @input="updatedAltEmpExpAccepted" :required="true"  :cid="'Alternative Employment Experience'"
     :wrapclass="'md:w-full'" 
      :formscope="formscope"
      v-model="value.altJobRequirements.altEmpExpAccepted"
      fieldName="Alternative Employment Experience"
      label="Alternate employment experience accepted?"
      placeHolder=""
    />
    <immiInput @input="updatednoOfMonthsOfAltTrainingAccepted" v-if="checkProperty(value,'altJobRequirements','altEmpExpAccepted')=='Yes'" :onlyNumbers="true" :allowFloatingPoint="false" :wrapclass="'md:w-1/2 custom_form_group'" :display="true" cid="noOfMonthsAltEmpExpAccepted" :formscope="formscope"  v-model="value.altJobRequirements.noOfMonthsAltEmpExpAccepted" :required="true" fieldName="expInYears" label="Number of months of alternate experience" placeHolder="Number of months of alternate experience"  :maxLength="5" />
       

    <redioButtons @input="updatedSplSkillOrOtherRequi" :required="true"  :cid="'Other requirements'"
     :wrapclass="'md:w-full'" 
      :formscope="formscope"
      v-model="value.altJobRequirements.splSkillOrOtherRequi"
      fieldName="Does the employer require any specific or other requirements?"
      label="Does the employer require any specific or other requirements?"
      placeHolder="Other requirements"
    />
    <template v-if="checkProperty(value,'altJobRequirements','splSkillOrOtherRequi')=='Yes'">


    
     <immiInput :wrapclass="'md:w-1/2'" :display="true" :cid="'ForeignLanguage'" :formscope="formscope"  v-model="value.altJobRequirements.ForeignLanguage"             :required="toggleRequired['ForeignLanguage']" @input="checkisRequirement()" fieldName="Foreign language" label="Foreign language" placeHolder="Foreign language"   />
     <immiInput :wrapclass="'md:w-1/2'" :display="true" :cid="'License/Certification'" :formscope="formscope"  v-model="value.altJobRequirements.LicenseCertification"  :required="toggleRequired['LicenseCertification']"  @input="checkisRequirement()" fieldName="License/Certification" label="License/Certification" placeHolder="License/Certification"   />
    <immiInput :wrapclass="'md:w-1/2'" :display="true" :cid="'residencyFellowship'" :formscope="formscope"  v-model="value.altJobRequirements.residencyFellowship" :required="toggleRequired['residencyFellowship']" @input="checkisRequirement()" fieldName="residencyFellowship" label="Residency/Fellowship" placeHolder="Residency/Fellowship"   />
    <immiInput :wrapclass="'md:w-1/2'" :display="true" :cid="'otherSplSkillsOrRequi'" :formscope="formscope"  v-model="value.altJobRequirements.otherSplSkillsOrRequi" :required="toggleRequired['otherSplSkillsOrRequi']"  @input="checkisRequirement()" fieldName="otherSplSkillsOrRequi" label="Other Special Skills or Requirements" placeHolder="Other Special Skills or Requirements"   />


</template>

</div>


        <immitextfield  wrapclass="md:w-1/1"  :formscope="formscope"  v-model="value.description" :required="true" fieldName="description" label="Job Description" placeHolder="Job Description"></immitextfield> 
        
       <div class="vx-col w-full" v-if="countries.length>0"    vs-type="flex"  vs-justify="center" vs-align="center" vs-lg=" "  vs-sm=" "  >
            <div class="addMoreAddress">                   
                <h3 class="small-header mt-0 pt-3">Work Location </h3>
                <template v-for="(addr ,addind ) in value['workAddresses']" >
                    <div class="vx-row mar0" :key="addind"  >
                        <addressFields
                            :formscope="formscope"
                            :key="addind"
                            :name="'PrimaryWork_Location'+addind"
                            :disableCountry="true"
                            :addFormContainerCls="false"
                            :validationRequired="true"
                            :showaptType="true"
                            :countries="countries"
                            v-model="value['workAddresses'][addind]"
                            :cid="'Primary_Work_Location'+addind"
                        />
                    </div>
                </template>
            </div>    
        </div>
        
        </div>
    </template>
    </div>  
</template>
<script>

import redioButtons from "@/views/forms/fields/redioButtons.vue";
import Vue from "vue";
import immiInput from "@/views/forms/fields/simpleinput.vue";
import selectField from "@/views/forms/fields/simpleselect.vue";
import immitextfield from "@/views/forms/fields/simpleTextField.vue";
import immieducations from "@/views/forms/fields/educations.vue";
import addressFields from "@/views/forms/fields/address.vue";
import * as _ from "lodash";
import moment from "moment";
import { XIcon } from 'vue-feather-icons'
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';

export default {
    components: {
        redioButtons,
        immiInput,
        selectField,
        immitextfield,
        immieducations,
        addressFields,
        XIcon
    },
    data() {
     return {
        toggleRequired:{
            ForeignLanguage:true,
            LicenseCertification:true,
            residencyFellowship:true,
            otherSplSkillsOrRequi:true
        },
        redioButton1:'',
        certifedVisible:false,
        skillTextError:false,
        educationTypes:[],
        editor: ClassicEditor,
        editorConfig: {
         toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
        },
        masterSocList:[],
        category:['EB2','EB3','EB3S'],
        newSkill:'',
        addSkill:true,
     }
    },
    methods: {
        checkisRequirement(){

            /*
             toggleRequired:{
            ForeignLanguage:true,
            LicenseCertification:false,
            residencyFellowship:false,
            otherSplSkillsOrRequi:false
        }
            */

        
        
            if( this.checkProperty(this.value ,'altJobRequirements' ,'ForeignLanguage') ){
                this.toggleRequired = {
                    ForeignLanguage:true,
                    LicenseCertification:false,
                    residencyFellowship:false,
                    otherSplSkillsOrRequi:false
                }

            } else if( this.checkProperty(this.value ,'altJobRequirements' ,'LicenseCertification') ){
                this.toggleRequired = {
                    ForeignLanguage:false,
                    LicenseCertification:true,
                    residencyFellowship:false,
                    otherSplSkillsOrRequi:false
                }
                

            }else if( this.checkProperty(this.value ,'altJobRequirements' ,'otherSplSkillsOrRequi') ){
                this.toggleRequired = {
                    ForeignLanguage:false,
                    LicenseCertification:false,
                    residencyFellowship:false,
                    otherSplSkillsOrRequi:true
                }
                

            }else if( this.checkProperty(this.value ,'altJobRequirements' ,'residencyFellowship') ){
                this.toggleRequired = {
                    ForeignLanguage:false,
                    LicenseCertification:false,
                    residencyFellowship:true,
                    otherSplSkillsOrRequi:false
                }
               

            }else{
                this.toggleRequired = {
                    ForeignLanguage:true,
                    LicenseCertification:true,
                    residencyFellowship:true,
                    otherSplSkillsOrRequi:true
                }

            }
          

        
       },
        updatedSplSkillOrOtherRequi(){
            if(this.checkProperty(this.value, 'altJobRequirements','splSkillOrOtherRequi') !='Yes'){
               
                this.value.altJobRequirements['ForeignLanguage'] ="";
                this.value.altJobRequirements['LicenseCertification'] ="";
                this.value.altJobRequirements['residencyFellowship'] ="";
                this.value.altJobRequirements['otherSplSkillsOrRequi'] ="";
                this.toggleRequired = {
                    ForeignLanguage:true,
                    LicenseCertification:true,
                    residencyFellowship:true,
                    otherSplSkillsOrRequi:true
                }
            }

        },
        updatedAltEmpExpAccepted(){
            if(this.checkProperty(this.value, 'altJobRequirements','altEmpExpAccepted') !='Yes'){
                this.value.altJobRequirements.noOfMonthsAltEmpExpAccepted =null;
            }
        },
        updatednoOfMonthsOfAltTrainingAccepted(){
            if(this.checkProperty(this.value ,"altJobRequirements" ,"noOfMonthsOfAltTrainingAccepted")){
                
                this.value.altJobRequirements.noOfMonthsOfAltTrainingAccepted = parseInt(this.value.altJobRequirements.noOfMonthsOfAltTrainingAccepted);
            }

            if(this.checkProperty(this.value ,"altJobRequirements" ,"noOfMonthsAltEmpExpAccepted")){
                
                this.value.altJobRequirements.noOfMonthsAltEmpExpAccepted = parseInt(this.value.altJobRequirements.noOfMonthsAltEmpExpAccepted);
            }

        },
        updatedAlternativeEducation(){ 
            if(this.checkProperty(this.value.altJobRequirements ,'altevelOfEducationDetails','id')){
                this.value.altJobRequirements.altevelOfEducation= this.checkProperty(this.value.altJobRequirements ,'altevelOfEducationDetails','id');

            }
            if(this.checkProperty(this.value ,'altJobRequirements' ,'altevelOfEducation') !=8){
                this.value.usDiplomaOrDegreeAccepted='';
                this.value.majorsOrFieldsOfStudyAccepted="";

            }
           
    },
        updatedAlternateTraining(item){

            if(this.checkProperty(this.value ,'altJobRequirements' ,'isAltTrainingForTheJobOpporAccepted') !="Yes"){
                this.value.altJobRequirements.filedsOrNamesOfTrainingAccepted ='';
                this.value.altJobRequirements.noOfMonthsOfAltTrainingAccepted =null;
             }
            //value.altJobRequirements.filedsOrNamesOfTrainingAccepted  value.altJobRequirements.noOfMonthsOfAltTrainingAccepted

        },
        updatedAlternateJobDetails(item){
           // alert(item)
           if(this.checkProperty(this.value,'altJobRequirements','areAltSetsOfEducation') !='Yes'){

           
            this.value.altJobRequirements.altevelOfEducation=null;
            this.value.altJobRequirements.altevelOfEducationDetails=null;
            this.value.altJobRequirements.usDiplomaOrDegreeAccepted='';
            this.value.altJobRequirements.majorsOrFieldsOfStudyAccepted='';
             
            // this.value.altJobRequirements.isAltTrainingForTheJobOpporAccepted ='';
            // this.value.altJobRequirements.filedsOrNamesOfTrainingAccepted ='';
            // this.value.altJobRequirements.noOfMonthsOfAltTrainingAccepted ='';


            // this.value.altJobRequirements.altEmpExpAccepted ='';
            // this.value.altJobRequirements.noOfMonthsAltEmpExpAccepted =null;
            // this.value.altJobRequirements['splSkillOrOtherRequi'] ="";
            // this.value.altJobRequirements['ForeignLanguage'] ="";
            // this.value.altJobRequirements['LicenseCertification'] ="";
            // this.value.altJobRequirements['residencyFellowship'] ="";
            // this.value.altJobRequirements['otherSplSkillsOrRequi'] ="";

            



           }

        },
        checkVislibilty(field=''){
            // alert(field)
            if(field == 'Certified'){
                this.certifedVisible = true
            }
            else{
                this.certifedVisible = false
                this.value.socCode = ''
                this.value.socOccuTitle = ''
                this.value.wageRate = ''
            }

        },
        addWorkAddress(){

            let address = {
				"companyName": "",
				"line1" : "",
				"line2" : "",
				"aptType": "",
				"locationId" :null,
				"stateId" : null,
				"countryId" : 231,
				"zipcode" : "",
				"locationDetails" : {
					"id" : '',
					"name" : "",
					"stateId" : null,
					"countryId" : null
				},
				"stateDetails" : {
					"id" : null,
					"name" : "",
					"shortName" : "",
					"countryId" : null
				},
				"countryDetails" : {
                    "id" : 231,
                    "shortName" : "US",
                    "name" : "United States",
                    "phoneCode" : 1,
                    "order" : 1,
                    "currencySymbol" : "$",
                    "currencyCode" : "USD",
                    "zipcodeLength" : 5
                },
				"workLocation": true
			}
            if(this.value['workAddresses'].length<=0){
                this.value['workAddresses'].push(address);
                this.value['workAddresses'] = _.cloneDeep(this.value['workAddresses']);

            }
            

        },
        updateData() {
      this.$emit('input', this.value)
    },
        getEducationList(){
            this.$store
                .dispatch("getmasterdata", "education_types")
                .then((response) => {
                    this.educationTypes = response;
                    if(this.checkProperty(this.value ,'minDegree' )){
                    this.value['minDegreeDetails'] = _.find(this.educationTypes, {"id": parseInt(this.value['minDegree'])});

                   }

                   if(this.checkProperty( this.value , "altJobRequirements" ,"altevelOfEducation")){
                    
                     this.value.altJobRequirements.altevelOfEducationDetails=_.find(this.educationTypes, {"id": parseInt(this.value['altJobRequirements']['altevelOfEducation'])});
                    this.updatedAlternativeEducation();
                    }
                })
                },
        addNewSkill(){
            
            this.skillTextError =false;
            if(this.newSkill && this.newSkill.trim() !=''){

                let skil = this.newSkill.trim();
                if(this.value['skills'].indexOf(skil) <=-1){
                    this.value['skills'].push(skil);
                }

               
                this.newSkill ='';
                this.addSkill =false;
            }else{
                this.skillTextError =true;
            }
        },
        removeSkill(index ){
            
            this.value['skills'].splice(index ,1);
           // this.$emit('input', this.value);
        },
        getMasterSocList(){
            let query = {};
            query["page"] = 1;
            query["perpage"] = 10000;
            query["matcher"] = {
               // getInactiveListAlso:true
             };
            query["category"] = "soc_codes";
            this.$store
            .dispatch("getMasterData", query)
            .then((response) => {
                this.masterSocList = response.list;

                //:optionslist="masterSocList" v-model="value.preferredSocCodeDetails" @input="updatepreferredsocCode" 
                if(this.checkProperty(this.value ,'preferredSocCode' )){
                   this.value['preferredSocCodeDetails'] = _.find(this.masterSocList, {"id": parseInt(this.value['preferredSocCode'])});
                }
            })
            .catch(() => {
            this.masterSocList = [];
            });
        },
        updatepreferredsocCode(item){ 
            if(_.has( item ,'id')){
                this.value['preferredSocCode'] = item['id'];
            }
        },
        updatesocCode(item){ 
            if(_.has( item ,'id')){
                this.value['socCode'] = item['id'];
            }
        },
       
    },
    props: {
        loadedFromPwdLibrary:{
      type: Boolean,
      default: false,

    },
        ACTIVITYCODE: {
            type: String,
            default: null,
        },
        value: null,
        formscope:{
            type:String,
            default:''

        },
        petitionDetails: {
            type: Object,
             default: null,
        },
        countries:{
            type: Array,
            default: [],
        } 

    },
    mounted(){
        
        this.getEducationList();
        this.getMasterSocList();
        if(!this.checkProperty(this.value,'workAddresses') ||  this.checkProperty(this.value,'workAddresses' ,'length')<=0){
            this.value['workAddresses'] =[];
            let self =this;
           
            setTimeout(()=>{
                self.addWorkAddress();

                if(_.has( self.value ,'noOfPositions')){
                    self.value['noOfPositions'] =null;
                }
                self.checkisRequirement()
            },10);
            
           // this.$emit('input', this.value)
        }
        
        if(!this.checkProperty(this.value,'skills') ||  this.checkProperty(this.value,'skills' ,'length')<=0){
            this.value['skills'] = [];
           // this.$emit('input', this.value);
        }

        if(!this.checkProperty(this.value,'altJobRequirements') ){
            this.value['altJobRequirements'] = {

                    // Are alternate sets of Education, Training, and/or Experience accepted? "Yes", "No"

                    areAltSetsOfEducation:"",// { type: String},
                    altevelOfEducation: null,//{ type: Schema.Types.ObjectId, default: null  }, //0bjectId
                    altevelOfEducationDetails:null,
                    usDiplomaOrDegreeAccepted:'', //{type: String},
                    majorsOrFieldsOfStudyAccepted: '',//{type: String},
                    isAltTrainingForTheJobOpporAccepted: '',//"Yes" Or "No"
                    noOfMonthsOfAltTrainingAccepted: null,//{type: String},
                    filedsOrNamesOfTrainingAccepted: "",//{ type: String },
                    altEmpExpAccepted: "" ,//"Yes" Or "No"
                    noOfMonthsAltEmpExpAccepted:null,
                    splSkillOrOtherRequi:'',
                    ForeignLanguage:'',
                    LicenseCertification:'',
                    residencyFellowship:'',
                    otherSplSkillsOrRequi:''

            }
        }
        this.checkisRequirement();
        setTimeout(()=>{
            this.checkisRequirement();

        },10)
       
    },
    computed:{
      

    }
}

</script>