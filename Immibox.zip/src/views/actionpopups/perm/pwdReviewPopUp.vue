<template>
   
    <modal
          name="pdwReviewModal"
          classes="v-modal-sec"
          :min-width="200"
          :min-height="200"
          :scrollable="true"
          :reset="true"
          width="650px"
          height="auto"
        >
        <div class="v-modal profile_details_modal error-modal-space" >
          <div class="popup-header fromDetailsPage">
            <h2 class="popup-title">
              
               
               <template v-if="ACTIVITYCODE=='REQUEST_PWD_PET_REVIEW'">
               
                <template v-if="getTenantTypeId ==2">Request for reviewing the PWD</template>
                <template v-else> Request Petitioner for reviewing the PWD</template>
                  
              </template>
              <template v-else>
                Reviewing the PWD
              </template>
               
                
               
                

               </h2>
            <span @click="showPopup=false;$modal.hide('pdwReviewModal');">
              <em class="material-icons">close</em>
            </span>
          </div>
        
          <form @submit.prevent data-vv-scope="pdwReviewScope" class="trackingform">
              <div class="form-container" @click="pewResponceUpdateStatusError=''">
                <template >
                      
                <div class="vx-row">

                   
                  <div class="vx-col  w-full"  >
                   <div class="form_group">
                     <label class="form_label">Comments<em >*</em></label>
                        <ckeditor  name="Comments" v-model="actionData.comment" v-validate="'required'"  class="w-full" :data-vv-as="'Comments'"  :editor="editor" :config="editorConfig"></ckeditor>
                         <p v-show="errors.has('pdwReviewScope.Comments')" class="text-danger text-sm"><em>*</em>Comments are required</p>
                    </div>
                    
                  </div>
                  
                  
                </div>

             

              </template>
               
                
              </div>
              
              <div @click="pewResponceUpdateStatusError=''" class="text-danger text-sm formerrors" v-if="pewResponceUpdateStatusError!=''">
                        <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ pewResponceUpdateStatusError }}</vs-alert>
              </div>

              <div class="popup-footer relative">
              <span class="loader" v-if="pwdResUpdating"><img src="@/assets/images/main/loader.gif"></span>
                <vs-button color="dark" class="cancel" type="filled" @click="documentModel=[]; hideMe()">Cancel</vs-button>
                <vs-button color="success" :disabled="(pwdResUpdating || filesAreuploading)" @click="submitForm()" class="save" type="filled">
                
                
                <template >Submit</template>
                
                
                </vs-button>
              </div>
          </form>
          </div>
        </modal>  
</template>
<script>
import { InfoIcon } from "vue-feather-icons";

import moment from "moment";
import FileUpload from "vue-upload-component/src";
import { EyeIcon } from "vue-feather-icons";
import docType from "@/views/common/docType.vue";
import Datepicker from "vuejs-datepicker-inv";
import * as _ from "lodash";
import immiInput from "@/views/forms/fields/simpleinput.vue";
import immitextarea from "@/views/forms/fields/simpletextarea.vue";
import selectField from "@/views/forms/fields/simpleselect.vue";
import Vue from 'vue';
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
export default {
provide() {
        return {
           parentValidator: this.$validator,
        };
    },
components: {
  InfoIcon,
  docType,
  EyeIcon,
  FileUpload,
  Datepicker,
  immiInput,
  immitextarea,
  selectField
},
methods: {
    updatesocCode(item){ 

      if(_.has( item ,'id')){
      this.actionData['socCode'] = item['id'];
      }
    },
  getMasterSocList(){

            let query = {};
            query["page"] = 1;
            query["perpage"] = 10000;
            query["matcher"] = {};
            query["category"] = "soc_codes";


            this.$store
            .dispatch("getMasterData", query)
            .then((response) => {
            this.masterSocList = response.list;


            //alert(this.perpage);
            })
            .catch(() => {
            this.masterSocList = [];

            });

  },
  remove(index ,docs){
    docs.splice(index ,1);

  },
  /**
   * 
   * @param userType | String
   * @param typeId | String
   * @param childrenId | String
   * @param userName | String
   */
  uploadDocuments(){
    var self = this;
       let docs =_.cloneDeep(this.documentModel);
       this.documentModel=[];
        
          docs = docs.map(
              (item) =>{
                  item = {
                      name: item.name,
                      file: item.file,
                      path: "",
                      mimetype: item.type,
                      extn:item.extn?item.extn:'',
                      documentType:item.documentType?item.documentType:null,
                      userName:'',
                      uploadedBy: self.checkProperty(self.getUserData, 'userId'),
                        uploadedByName: self.checkProperty(self.getUserData, 'name'),
                        uploadedByRoleId: self.getUserRoleId,
                        uploadedByRoleName: self.checkProperty(self.getUserData, 'loginRoleName'),
                        size:item.size ? item.size : null,
                     
                  }
                 
                  
              return item;

            }
          );
         
          if (docs.length > 0) {
             
              this.filesAreuploading = true;
              
              let count =0;
              docs.forEach(function (doc) {
                  let formData = new FormData();
                  formData.append("files", doc.file);
                  formData.append("secureType", "private");
                  formData.append("getDetails", true);
                  self.$store.dispatch("uploadS3File", formData).then((response) => {
                    count = count+1;
                      if (response.data && response.data.result) {
                          response.data.result.forEach((urlGenerated) => {
                            //alert(JSON.stringify(urlGenerated))
                              // doc.url = urlGenerated;
                               doc.path = urlGenerated['path'];
                               doc.mimetype = urlGenerated['mimetype'];
                                doc.extn = urlGenerated['extn'];
                                doc.size = urlGenerated['size'];
                               
                              delete doc.file;
                              if(urlGenerated['path']){
                                 self.actionData['documents'].push(doc)
                               //  self.statusDocuments.push(doc)
                              }
                              
                              if(parseInt(count)>=docs.length){
                                 self.filesAreuploading = false;
                                 self.pwdResUpdating =false;
                               

                              }
                          });
                          if(count>=docs.length){
                            self.filesAreuploading = false;
                            self.pwdResUpdating =false;
                         

                          }
                          
                      }
                     
                  });
              });
          }
  },
 
    
  fileNameChenged(index, fileindex) {
          this.disable_uploadBtn = false;

          _.forEach(this.statusDocuments, (doc, value) => {
              let fname = doc.name;
              fname = fname.trim();

              if (!fname) {
                  this.disable_uploadBtn = true;
              }
          });

      },


    
  submitForm() {
     //alert(this.approveRejecInstructions);
          this.pewResponceUpdateStatusError='';
       
          this.$validator.validateAll("pdwReviewScope").then((result) => {

             if(result && !this.filesAreuploading){
              this.pwdResUpdating =true;
              let path ="/perm/manage-job-description";
              let data ={
                action:'' ,
              'petitionId':'' ,
              "typeName": "", 
              "subTypeName": "",
               comment:'',
                  jobDescSuggessionType:''
                }
               
              
             

              data['action'] = this.ACTIVITYCODE;
              data['comment'] = this.actionData['comment'];
              data['typeName'] = this.checkProperty( this.petitionDetails , 'typeDetails','name');
              data['subTypeName'] = this.checkProperty( this.petitionDetails ,'subTypeDetails','name');
              data['petitionId'] = this.checkProperty( this.petitionDetails ,'_id');
              
             
             
              if(this.loadedFromPwdLibrary){
                data['pwdId'] =this.checkProperty( this.petitionDetails ,'_id');
                path ="/pwd/manage-job-description";

                
              }
              this.$store.dispatch('commonAction' ,{ "data":data ,'path':path})
              .then((res)=>{
                this.$emit("updatepetition");
                this.showToster({message:res['message'],isError:false });
                setTimeout(()=>{
                  this.hideMe();
                })
               
              })
              .catch((error)=>{
                this.pewResponceUpdateStatusError =error;
                this.pwdResUpdating =false;
               })

              

             }
          });
  },
  hideMe() {

    this.$emit("hideMe");
    setTimeout(()=>{
        this.$modal.hide('pdwReviewModal');
      },10);
  },
},
watch: {
  showPopup(val) {
    if (!val){
      this.$emit("hideMe");
      this.pwdResUpdating =false;
      this.$modal.hide('pdwReviewModal');
    } 
  },
},
mounted() {
 
    this.pwdResUpdating =false;
    this.getMasterSocList();
    this.showPopup = true;
    this.$modal.show('pdwReviewModal');
             
  
},
data: () => ({
  editor: ClassicEditor,
 editorConfig: {
     toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
 },
  permApplicationNo:'',
 
  masterSocList:[],
  pwdResUpdating:false,
  pewResponceUpdateStatusError:'',
  actionData:{
      "petitionId": "",
      "action": '',//"EFILE_PWD",'UPDATE_PWD_RESPONSE'
      "actionDetails":null,
      "typeName": "t",
      "subTypeName": "",
      "jobDescSuggessionType":'',
      comment:'',
      "documents": [],
      
},

 
  
 documentTypes:["Original" ,"Electronic" ],
  documentModel:[],
  statusDocuments:[],
 filesAreuploading: false,
  
  uploading: false,
  courierList: [],
  tracking: { documents: [], receiptNumber: null, receiptName: null },
  
  
  openDate: new Date().setFullYear(new Date().getFullYear()),
  startEligibleDate: new Date().setFullYear(new Date().getFullYear()),
  
  disabled_btn: false,
  showPopup: false,
  documents: [],
 
}),
props: {
  loadedFromPwdLibrary:{
      type: Boolean,
      default: false,

    },
  ACTIVITYCODE: {
    type: String,
    default: null,
  },
  petitionDetails: {
    type: Object,
    default: null,
  },
},
};
</script>
