<template>
   
  <modal
        name="initiatePaymentModal"
        classes="v-modal-sec"
        :min-width="200"
        :min-height="200"
        :scrollable="true"
        :reset="true"
        width="650px"
        height="auto"
      >
      <div class="v-modal profile_details_modal error-modal-space" >
        <div class="popup-header fromDetailsPage">
          <h2 class="popup-title">
            Reminder for Invoice
              

             </h2>
          <span @click="showPopup=false;hideMe()">
            <em class="material-icons">close</em>
          </span>
        </div>
        <form data-vv-scope="reminderForm" class="relative" @submit.prevent @keydown.enter.prevent>
      <div
        class="popup_info"
       
        @click="formErrors = ''"
      >
       
        
      </div>
      <div class="form-container">
        <div class="vx-row" >
          
          <div class="vx-col w-full">
            <div class="form_group">
              <label class="form_label">Comments<em>*</em></label>
              <!-- <vs-textarea
                data-vv-as="Comments"
                v-validate="'required'"
                v-model="comments"
                name="comments"
                class="w-full mb-5"
              /> -->
              <ckeditor  data-vv-as="Comments"
                v-validate="'required'"
                v-model="comments"
                name="comments"
                class="w-full mb-5" :editor="editor" :config="editorConfig"></ckeditor>

              <span
                class="text-danger text-sm"
                v-show="errors.has('reminderForm.comments')"
                >* Comments are required</span
              >
            </div>
          </div>
        </div>

        <div class="text-danger text-sm formerrors" v-show="formErrors">
          <vs-alert
            color="warning"
            class="warning-alert reg-warning-alert no-border-radius"
            icon-pack="IntakePortal"
            icon="IP-information-button"
            active="true"
            >{{ formErrors }}</vs-alert
          >
        </div>
      </div>

      <div class="popup-footer relative">
        <span class="loader" v-if="loading"
          ><img src="@/assets/images/main/loader.gif"
        /></span>
        <vs-button
          color="dark"
          @click="showPopup = false"
          class="cancel"
          type="filled"
          >Cancel</vs-button
        >
        

        <vs-button
         
          :disabled="loading"
          color="success"
          @click="submitRemindAction()"
          class="save"
          type="filled"
          >  Remind <!----Initiate--->
        </vs-button>
        
        
        
      </div>
    </form>
        </div>
      </modal>  
</template>
<script>

import moment from "moment";
import Vue from 'vue';
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';


export default {
provide() {
      return {
         parentValidator: this.$validator,
         editor: ClassicEditor,
          editorConfig: {
              toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
          },
      };
  },
components: {
},
methods: {

submitRemindAction() {
 
 this.$validator.validateAll("reminderForm").then((result) => {
         if (result) {
           let postData = {
             petitionId: this.petitionDetails['_id'],
             comment: this.comments,
             subTypeName:this.checkProperty(this.petitionDetails,'subTypeDetails','name'),
             typeName:this.checkProperty(this.petitionDetails,'typeDetails','name'),
             today:moment().format('YYYY-MM-DD')
             
           };
         let path = "/perm/remind-invoice";
           
           
           //alert(JSON.stringify(postData))
            this.loading =true;
            this.$store.dispatch("commonAction", {"data":postData ,"path":path}).then(response => {
             this.showPopup =false;
             
             this.showToster({message:response.message,isError:false });
               this.loading =false;
                this.$emit("updatepetition" ,'');
                this.$emit("hideMe");
                                               
           })
           .catch((error)=>{
             
             this.formErrors =error;
             this.loading =false;
           })
           
    
    

           
         }
       });
 },

hideMe() {

  this.$emit("hideMe");
  setTimeout(()=>{
      this.$modal.hide('initiatePaymentModal');
    },10);
},
},
watch: {
showPopup(val) {
  if (!val){
    this.$emit("hideMe");
    this.$modal.hide('initiatePaymentModal');
  } 
},
},
mounted() {


  
  this.showPopup = true;
  this.$modal.show('initiatePaymentModal');

},
data: () => ({
  editor: ClassicEditor,
 editorConfig: {
     toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
 },
loading:false,
    comments:null,
    showPopup: false,
    formErrors: null,

}),
props: {
ACTIVITYCODE: {
      type: String,
      default: null,
    },
    rolesList: [],
    popUpTitle: {
      type: String,
      default: null,
    },
    petitionDetails: {
      type: Object,
      default: null,
    },
},
computed:{
},
};
</script>
