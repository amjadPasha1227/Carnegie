
<template>
    <modal
      name="addPopUpModal"
      classes="v-modal-sec"
      :min-width="200"
      :min-height="200"
      :scrollable="true"
      :reset="true"
      width="400px"
      height="auto"
    >
      <div class="v-modal profile_details_modal">
        <div class="popup-header fromDetailsPage">
      
          <h2 class="popup-title" >

            <template v-if="checkProperty( petitionDetails,'pwdApplicationNo')">Update PWD Application Number</template>
            <template v-else>Add PWD Application Number</template>
            
          </h2>
          <span  @click="hideMe()">
            <em class="material-icons">close</em>
          </span>
        </div>
  
        <form @submit.prevent data-vv-scope="pwdApplicationNoScope">
          <div class="form-container" @click="this.premiumProcessingFormErrors =''">
          
          
            <div class="vx-row">
                
              <div class="vx-col w-full pp-col ">
                <immiInput
                        :wrapclass="'w-full'"
                      :display="true"
                      cid="pwdApplicationNo"
                      :formscope="'pwdApplicationNoScope'"
                      v-model="newform.pwdApplicationNo"
                      :required="true"
                      fieldName="pwdApplicationNo"
                      label="Application Number"
                      placeHolder="Application Number"
                        />
              </div>

              <div class="vx-col w-full">
                <div class="form_group custom-radio_wrap">
                  <ul class="custom-radio" vs-type="flex" vs-align="center">
                    <li>
                      <!-- "pwdApplicationNo":'',
        "efilePwdAs": "Attorney" // Agent -->
                      
                    <vs-radio    name="efilePwdAs"  vs-value="Attorney" v-model="newform.efilePwdAs" class="w-full"
                            ><span ref="Free-Flow">Attorney</span></vs-radio > 

                    
                    </li>
                          <li>
                
                        <vs-radio   ref="Sequential"  name="efilePwdAs"  vs-value="Agent"   v-model="newform.efilePwdAs" class="w-full"
                            > <span ref="Sequential">Agent</span></vs-radio > 
                    
                          </li>
                      
                  </ul>
               </div>
              </div>

            </div>
            <div v-show="premiumProcessingFormErrors">
              <vs-alert
                color="warning"
                class="warning-alert reg-warning-alert no-border-radius"
                icon-pack="IntakePortal"
                icon="IP-information-button"
                active="true"
                >{{ premiumProcessingFormErrors }}</vs-alert
              >
            </div>
          </div>
          <div class="popup-footer relative">
            <span class="loader" v-if="updatingPremiumProcessing">
              <img src="@/assets/images/main/loader.gif" />
            </span>
  
            <vs-button  color="dark"  @click="hideMe()" class="cancel"   type="filled"  >Cancel</vs-button>
            <vs-button  color="success" :disabled="updatingPremiumProcessing"  @click="submitForm()" class="save" type="filled">
              <template v-if="checkProperty(petitionDetails,'pwdApplicationNo')">Update</template>
              <template v-else>Add Application Number</template>
              
            </vs-button>
          </div>        
        </form>
      </div>
    </modal>
  </template>
  <script>
  
import immiInput from "@/views/forms/fields/simpleinput.vue";
  import moment from "moment";
  import FileUpload from "vue-upload-component/src";
  import { EyeIcon } from 'vue-feather-icons'
  import docType from "@/views/common/docType.vue"
  import Vue from 'vue';
  Vue.use( CKEditor );
  import CKEditor from '@ckeditor/ckeditor5-vue2';
  import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
  import * as _ from "lodash";

  export default {
    provide() {
        return {
            parentValidator: this.$validator,
        };
    },
      components: {
        immiInput,
      docType,
      EyeIcon,
      FileUpload
    },
    methods: {
     
       
      

      submitForm() {
        this.premiumProcessingFormErrors ='';
        this.$validator.validateAll('pwdApplicationNoScope').then((result) => {
        let self =this;
            if (result) {
            let postData ={ 

              "pwdId": "",
              "pwdApplicationNo": "",
               "efilePwdAs": "Attorney" // Agent
             }

            postData['pwdId'] = self.checkProperty(self.petitionDetails ,'_id');
            postData['pwdApplicationNo'] = self.checkProperty(self.newform ,'pwdApplicationNo');
            postData['efilePwdAs'] = self.checkProperty(self.newform ,'efilePwdAs');
            
            
           
            this.updatingPremiumProcessing =true;
            
            this.$store.dispatch("commonAction", {"data":postData ,"path":"/pwd/add-pwd-application-number"})
            .then(response => {
                this.updatingPremiumProcessings =false;
                this.hideMe();
                this.showToster({message:response.message,isError:false });
                this.$emit("updatepetition", "Case Details");             
            })
            .catch((error)=>{
                this.premiumProcessingFormErrors =error;
                this.updatingPremiumProcessing =false;
            }) 
            }
        });
      },
      hideMe() {
        this.$emit("hideMe");
      },
    },
    watch: {
      showPopup(val) {
        if (!val) this.$emit("hideMe");
      },
    },
    mounted() {
       
       
      this.$modal.show("addPopUpModal");
    },
    data: () => ({
      newform:{
        "pwdId":'',
        "pwdApplicationNo":'',
        "efilePwdAs": "Attorney" // Agent
      },
        updatingPremiumProcessing:false,
        selectedCase:null,
       
        editor: ClassicEditor,
        editorConfig: {
            toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
        },
       
        showPopup: false,
        premiumProcessingFormErrors:'',
       
       
    }),
    props: {
     
      petitionDetails: {
        type: Object,
        default: null,
      },
    },
  };
  </script>