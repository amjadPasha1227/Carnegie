<template>
    <div class="custom_modal_cnt">
        <div class="modal_title">      
            <h2> PERM E-File Info  </h2>                
            <span class="close" @click="hideMe()"><x-icon size="1.5x"></x-icon></span>
        </div>
        <div>
            <!-- jobOpptInfo -->
            <div class="custom-tabs">
                <ul class="d-flex">
                    <li  :class="{'active':activeTab=='jobOpptInfo'}" @click="tabChanged('jobOpptInfo')">Job Oppurtunity Information</li>
                    <li :class="{'active':activeTab=='otherInfo'}" @click="tabChanged('otherInfo')">Other Information</li>
                    
                </ul>
            </div>
            <div v-if="petitionDetails">
                <div v-if="activeTab=='jobOpptInfo'">
                            
                            <div class="modal_cnt withTabButtons">
                                <form @click="jdUpdateStatusError=''"  data-vv-scope="jobOpptInfo" @submit.prevent="" @keydown.enter.prevent="" >
                                <div class="form-container">
                                    <VuePerfectScrollbar	
                                            ref="mainSidebarPs"	
                                            class="scroll-area--main-sidebar"	
                                            :settings="settings"	
                                        
                                        > 
                                        <div class="infoSec">
                                            <div class="vx-row">
                                            <redioButtons   :wrapclass="''" :cid="'isTrainigRequired'" @input="updateIsTrainigRequired" :formscope="'jobOpptInfo'" v-model="petitionDetails.jobOpportunityInfo.isTrainigRequired" fieldName="isTrainigRequired" label="Is training required for the job opportunity?" placeHolder="" />
                                            <immiInput v-if="checkProperty(petitionDetails ,'jobOpportunityInfo','isTrainigRequired')=='Yes'" :onlyNumbers="true" :wrapclass="'md:w-1/2'" :display="true" cid="noOfTraningMonths" :formscope="'jobOpptInfo'" v-model="petitionDetails.jobOpportunityInfo.noOfTraningMonths" :required="true" fieldName="noOfTraningMonths" label="No of months training required" placeHolder="No of months training" :maxLength="3"  />
                                            <immiInput v-if="checkProperty(petitionDetails ,'jobOpportunityInfo','isTrainigRequired')=='Yes'" :wrapclass="'md:w-1/2'" :display="true" cid="fieldOfTraining" :formscope="'jobOpptInfo'" v-model="petitionDetails.jobOpportunityInfo.fieldOfTraining" :required="true" fieldName="fieldOfTraining" label="Indicate the field of training" placeHolder="Indicate the field of training"  />
                                            
                                            
                                            <redioButtons  :wrapclass="''" :cid="'isExpRequired'" @input="updateisExpRequired" formscope="jobOpptInfo" v-model="petitionDetails.jobOpportunityInfo.isExpRequired" fieldName="isExpRequired" label="Is experience in the job offered required for the job?" placeHolder="" />
                                            <immiInput v-if="checkProperty(petitionDetails ,'jobOpportunityInfo','isExpRequired')=='Yes'" :onlyNumbers="true" :wrapclass="'md:w-1/2'" :display="true" cid="noOfExpMonths" :formscope="'jobOpptInfo'" v-model="petitionDetails.jobOpportunityInfo.noOfExpMonths" :required="true" fieldName="noOfTraningMonths" label="No of months of experience required" placeHolder="No of months of experience " :maxLength="3"  />
                                            


                                            <redioButtons  :wrapclass="''" :cid="'isAltFieldOfStudyAccept'" @input="updateisAltFieldOfStudyAccept" formscope="jobOpptInfo" v-model="petitionDetails.jobOpportunityInfo.isAltFieldOfStudyAccept" fieldName="isAltFieldOfStudyAccept" label="Is there an alternate field of study that is acceptable?" placeHolder="" />
                                            <immiInput v-if="checkProperty(petitionDetails ,'jobOpportunityInfo','isAltFieldOfStudyAccept')=='Yes'"  :wrapclass="'md:w-1/2'" :display="true" cid="altMajorFieldOfStudy" :formscope="'jobOpptInfo'" v-model="petitionDetails.jobOpportunityInfo.altMajorFieldOfStudy" :required="true" fieldName="altMajorFieldOfStudy" label="Specify alternate field of study" placeHolder="Specify alternate of study"  />
                                            

                                            <redioButtons  :wrapclass="''" :cid="'isAltCombOfEduAndExpAccept'" @input="updateisAltCombOfEduAndExpAccept" formscope="jobOpptInfo" v-model="petitionDetails.jobOpportunityInfo.isAltCombOfEduAndExpAccept" fieldName="isAltCombOfEduAndExpAccept" label="Is there an alternate combination of education and experience that is acceptable?" placeHolder="" />
                                            <selectField v-if="checkProperty(petitionDetails ,'jobOpportunityInfo','isAltCombOfEduAndExpAccept')=='Yes'" :wrapclass="'md:w-1/3'" :required="true" :optionslist="educationTypes" v-model="petitionDetails.jobOpportunityInfo.altLevelOfEduDetails" @input="petitionDetails.jobOpportunityInfo.altLevelOfEdu= checkProperty(petitionDetails.jobOpportunityInfo ,'altLevelOfEduDetails' ,'id')" :formscope="'jobOpptInfo'"  fieldName="altLevelOfEdu" label="Alternate Level of Education" placeHolder="Alternate Level of Education"   />  
                                            
                                            <immiInput v-if="checkProperty(petitionDetails ,'jobOpportunityInfo','isAltCombOfEduAndExpAccept')=='Yes'" :allowFloatingPoint="true" :onlyNumbers="true" :wrapclass="'md:w-1/2'" :display="true" cid="altAcceptExpInYears" :formscope="'jobOpptInfo'" v-model="petitionDetails.jobOpportunityInfo.altAcceptExpInYears" :required="true" fieldName="altAcceptExpInYears" label="Indicate the number of years experience acceptable" placeHolder="No of years experience" :maxLength="5" />
                                            

                                            <redioButtons  :wrapclass="''" :cid="'foreignEduEqAccept'"  formscope="jobOpptInfo" v-model="petitionDetails.jobOpportunityInfo.foreignEduEqAccept" fieldName="foreignEduEqAccept" label="Is a foreign educational equivalent acceptable?" placeHolder="" />
                                            
                                            <redioButtons  :wrapclass="''" :cid="'isExpInAltOccuAccept'" @input="updateisExpInAltOccuAccept" formscope="jobOpptInfo" v-model="petitionDetails.jobOpportunityInfo.isExpInAltOccuAccept" fieldName="isExpInAltOccuAccept" label="Is experience in an alternate occupation acceptable?" placeHolder="" />
                                            <immiInput v-if="checkProperty(petitionDetails ,'jobOpportunityInfo','isExpInAltOccuAccept')=='Yes'" :wrapclass="'md:w-1/2'" :display="true" cid="jobTitleOfAcceptAltOccu" :formscope="'jobOpptInfo'" v-model="petitionDetails.jobOpportunityInfo.jobTitleOfAcceptAltOccu" :required="true" fieldName="jobTitleOfAcceptAltOccu" label="Identify the job title of the acceptable alternate occupation" placeHolder="Job title"  />
                                            <immiInput v-if="checkProperty(petitionDetails ,'jobOpportunityInfo','isExpInAltOccuAccept')=='Yes'" :onlyNumbers="true" :wrapclass="'md:w-1/2'" :display="true" cid="noOfExpMonthsInAltOccu" :formscope="'jobOpptInfo'" v-model="petitionDetails.jobOpportunityInfo.noOfExpMonthsInAltOccu" :required="true" fieldName="noOfExpMonthsInAltOccu" label="No of months experience in alternate occupation required" placeHolder="No of months experience" :maxLength="3"  />
                                            <redioButtons :formscope="'jobOpptInfo'" :wrapclass="''" :cid="'jobOppoReqForNormalOccu'"  :showNA="false" formscope="jobOpptInfo" v-model="petitionDetails.jobOpportunityInfo.jobOppoReqForNormalOccu" fieldName="jobOppoReqForNormalOccu" label="Are the job opportunity’s requirements normal for the occupation?" placeHolder="" />                                      
                                       

                                        <div class="vx-col  w-full" v-if="false" >
                                            <div class="form_group">
                                               <label class="form_label">Job Duties<em >*</em></label>
                                                     <ckeditor :editor="editor" :config="editorConfig" :name="'Jobduties'" v-model="petitionDetails.jobOpportunityInfo.jobDuties" v-validate="'required'"  class="w-full" :data-vv-as="'Job Duties'" />
                                                     <p v-show="errors.has('jobOpptInfo.Jobduties')" class="text-danger text-sm">{{ errors.first('jobOpptInfo.Jobduties') }}</p>
                                            </div>
                                         </div>
                                    <redioButtons  :wrapclass="''" :cid="'isForiegnLangRequired'" @input="updateisForiegnLangRequired" formscope="jobOpptInfo" v-model="petitionDetails.jobOpportunityInfo.isForiegnLangRequired" fieldName="isForiegnLangRequired" label="Is knowledge of a foreign language required to perform the job duties?" placeHolder="" />
                                    <template v-if="false" >
                                        <div class="vx-col w-full">
                                            <div class="skilladdsec">
                                                <label>Specific skills or other requirements </label>
                                                <ul>
                                                    <li v-for="(skil , index ) in petitionDetails['jobOpportunityInfo']['skills']" :key="index">
                                                        <span class="skill-label">{{skil}}</span>
                                                    

                                                        <span  @click="removeSkill(index)" class="row_btn">
                                                            <img src="@/assets/images/main/delete-row-img.svg">
                                                        </span>
                                                    </li>
                                                </ul>
                                                <div class="add-input-sec">
                                                    <div @keyup.enter.native="addNewSkill()" @keyup="addSkill=true">
                                                        <immiInput  :wrapclass="'w-full'"  :display="true" cid="addSkill" :formscope="'jobOpptInfo'"  v-model="newSkill" :required="false" fieldName="altAcceptExpInYears" placeHolder=""  />
                                                        <span v-if="addSkill"  @click="addNewSkill()" class="add-more">Add</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </template> 
                                    
                                    <redioButtons  :wrapclass="''" :cid="'isApplInvolJobOppoInclCombOfOccu'"  formscope="jobOpptInfo" v-model="petitionDetails.jobOpportunityInfo.isApplInvolJobOppoInclCombOfOccu" fieldName="isApplInvolJobOppoInclCombOfOccu" label="Does this application involve a job opportunity that includes a combination of occupations?" placeHolder="" />
                                    <redioButtons  :wrapclass="''" :cid="'positionOfferToAlien'"  formscope="jobOpptInfo" v-model="petitionDetails.jobOpportunityInfo.positionOfferToAlien" fieldName="positionOfferToAlien" label="Is the position identified in this application being offered to the alien identified" placeHolder="" />
                                    <redioButtons  :wrapclass="''" :cid="'alienReqToLiveEmplrPrimisis'"  formscope="jobOpptInfo" v-model="petitionDetails.jobOpportunityInfo.alienReqToLiveEmplrPrimisis" fieldName="alienReqToLiveEmplrPrimisis" label="Does the job require the alien to live on the employer’s premises?" placeHolder="" />
                                    <redioButtons  :wrapclass="''" :cid="'applLiveInHouseDomWorker'"  formscope="jobOpptInfo" v-model="petitionDetails.jobOpportunityInfo.applLiveInHouseDomWorker" fieldName="applLiveInHouseDomWorker" label="Is the application for a live-in household domestic service worker?" placeHolder="" />
                                    <redioButtons v-if="checkProperty(petitionDetails['jobOpportunityInfo'],'applLiveInHouseDomWorker')=='Yes'" :wrapclass="''" :cid="'emplrProviedAlienCopyOfContract'"  :showNA="false" formscope="jobOpptInfo" v-model="petitionDetails.jobOpportunityInfo.emplrProviedAlienCopyOfContract" fieldName="emplrProviedAlienCopyOfContract" label="The employer and the alien executed the required employment contract and has the employer provided a copy of the contract to the alien?" placeHolder="" />

                                        </div>
                                    <template v-if="false">
                                        <div class="divider mt-0"></div> 
                                        <div class="vx-col w-full" v-if="countries.length>0"    vs-type="flex"  vs-justify="center" vs-align="center" vs-lg=" "  vs-sm=" "  >
                                            <div class="addMoreAddress">
                                                
                                            <h3 class="small-header mt-0">Primary Worksite </h3>
                                            <template v-for="(addr ,addind ) in petitionDetails['jobOpportunityInfo']['workAddresses']" >
                                                <div class="vx-row mar0" :key="addind"  >
                                                        <addressFields
                                                            :formscope="'jobOpptInfo'"
                                                            :key="addind"
                                                            :name="'PrimaryWork_Location'+addind"
                                                            :disableCountry="true"
                                                            :addFormContainerCls="false"
                                                            :validationRequired="true"
                                                            :showaptType="true"
                                                            :countries="countries"
                                                            v-model="petitionDetails['jobOpportunityInfo']['workAddresses'][addind]"
                                                            :cid="'Primary_Work_Location'+addind"
                                                        />
                                                    </div>
                                        </template>
                                        
                                            </div>    
                                        </div>
                                    </template>
                                    <div @click="jdUpdateStatusError=''" class="text-danger text-sm formerrors mt-5" v-if="jdUpdateStatusError!=''">
                                    <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ jdUpdateStatusError }} </vs-alert>
                                </div>
                                    </div>
                                    </VuePerfectScrollbar>
                                </div>
                                

                                
                            </form>
                            </div>
                            <div class="popup-footer">
                                <span class="loader" v-if="jdUpdating"><img src="@/assets/images/main/loader.gif"></span>
                                <vs-button color="success" :disabled="jdUpdating" @click="tabChanged('otherInfo')" class="save" type="filled">Next</vs-button>        
                            </div>
                </div>
                <div v-if="activeTab=='otherInfo'">
                    <div class="modal_cnt withTabButtons PERM-E-File-otherInfo">
                        <form data-vv-scope="otherInfo" @submit.prevent="" @keydown.enter.prevent="" >
                            <div @click="jdUpdateStatusError=''" class="form-container">
                                <VuePerfectScrollbar	ref="mainSidebarPs"	class="scroll-area--main-sidebar"	:settings="settings">
                                    <div class="infoSec">
                                        <div class="vx-row" > 
                                            <template >
                                                <redioButtons :wrapclass="''" :cid="'supportOfAScheduleASheepherder '"   :fieldName="'supportOfAScheduleASheepherder'" placeHolder=""
                                                formscope="otherInfo" v-model="petitionDetails.permEfileInfo.supportOfAScheduleASheepherder" :display="true"
                                                label="Is this application in support of a Schedule A or Sheepherder occupation?"
                                                />
                                                <redioButtons :wrapclass="''" :cid="'isEmployerInvolved '"   :fieldName="'isEmployerInvolved'" placeHolder=""
                                                formscope="otherInfo" v-model="petitionDetails.permEfileInfo.isEmployerInvolved" :display="true"
                                                label="Is the employer a closely held corporation, partnership, or sole proprietorship in which the alien has an ownership interest, or is there a familial relationship between the owners, stockholders, partners, corporate officers, or incorporators, and the alien?"
                                                />
                                                <selectField :listContainsId="false" :wrapclass="'md:w-1/3'" :required="true" :optionslist="classofAdminssionList" v-model="petitionDetails.permEfileInfo.classOfAdmission"
                                                :formscope="'otherInfo'"  fieldName="classOfAdmission" label="Class of Admission" placeHolder="Class of Admission"   />
                                                <selectField :listContainsId="false" :wrapclass="'md:w-1/3'" :required="true" :optionslist="skillLevelList" v-model="petitionDetails.permEfileInfo.skillLevel"
                                                :formscope="'otherInfo'"  fieldName="skillLevel" label="Skills Level" placeHolder="Skills Level"   />  
                                            </template>
                                        </div>
                                        <div @click="jdUpdateStatusError=''" class="text-danger text-sm formerrors" v-if="jdUpdateStatusError!=''"> 
                                            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ jdUpdateStatusError }}</vs-alert>
                                        </div>
                                
                                    </div> 
                                
                                </VuePerfectScrollbar>

                            </div>
                        </form>
                    </div>
                    <!-- <div class="popup-footer">
                        <span class="loader" v-if="jdUpdating"><img src="@/assets/images/main/loader.gif"></span>
                        <vs-button color="success" :disabled="jdUpdating" @click="tabChanged('wageInfo')" class="save" type="filled">Next</vs-button>        
                    </div> -->
                    <div class="popup-footer">
                        <span class="loader" v-if="jdUpdating"><img src="@/assets/images/main/loader.gif"></span>
                        <vs-button color="dark" class="cancel" type="filled" :disabled="jdUpdating" @click="tabChanged('jobOpptInfo', true)" >Back</vs-button>
                        <vs-button color="success" :disabled="jdUpdating" @click="submitForm()" class="save" type="filled">Submit</vs-button>
                    </div>
                </div>
                
            </div>
        </div>
    </div> 
   
</template>
<script>
import Vue from "vue";
import immiswitchyesno from "@/views/forms/fields/switchyesno.vue";
import immiyesorno from "@/views/forms/fields/yesorno.vue";
import addressFields from "@/views/forms/fields/address.vue";
import immitextarea from "@/views/forms/fields/simpletextarea.vue";
import immitextfield from "@/views/forms/fields/simpleTextField.vue";
 import immiInput from "@/views/forms/fields/simpleinput.vue";
 import selectField from "@/views/forms/fields/simpleselect.vue";
 import datepickerField from "@/views/forms/fields/datepicker.vue";
 import VuePerfectScrollbar from "vue-perfect-scrollbar";
 import redioButtons from "@/views/forms/fields/redioButtons.vue";
import * as _ from "lodash";
import moment from "moment";
import { XIcon } from 'vue-feather-icons'
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import JQuery from "jquery";

export default {
    computed: {
        
    },
    provide() {
      return {
         parentValidator: this.$validator,
      };
  },
  created() {
    //this.$validator = this.parentValidator;
   },
    components: {
        addressFields,
        immitextarea,
        immitextfield,
        immiInput,
        selectField,
        datepickerField,
        XIcon,
       immiswitchyesno,
       immiyesorno,
       redioButtons,
       VuePerfectScrollbar
    },

    data() {
     return {   
        skillLevelList:['Level I','Level II','Level III','Level IV','N/A',],
        classofAdminssionList:['G-2','G-3','G-4','G-5','H-1A','H-1B','H-1B1','H-1C','H-2A','H-2B','H-3','H-4','I','J-1','J-2','K-1','K-2','K-3','K-4','L-1',
        'L-2','M-1','M-2','N','Not in USA','O-1','O-2','O-3','P-1','P-2','P-3','P-4','Parolee','Q','R-1','R-2','S-5','S-6','S-7','T-1','T-2','T-3','T-4',
        'TD','TN','TPS','U-1','U-2','U-3','U-4','V-1','V-2','VWB','VWT',],
        classificationList:['EB2','EB3','EB3S'],
        maxWaseError:'',
        completedtabs:[],
        editor: ClassicEditor,
        editorConfig: {
         toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
        },
        settings: {
   
          wheelSpeed: 0.6,
        },
        tempAddresses: {
                aptType:'',
                companyName: "",
                line1: "",
                line2: "",
                countryId: "",
                stateId: "",
                locationId: "",
                zipcode: "",
                countryDetails: null,
                stateDetails: null,
                locationDetails: null,
                workLocation:true
            },
        comments:'',
        jobSuggssionComments:false,
        valiedjobDetailsForm:false,
        valiedwageInfoFrorm:false,
        valiedjobOpptInfoForm:false,


        newSkill:'',
        addSkill:true,
        countries: [],
        permjobDetailsPopUp:true,
        activeTab:'jobOpptInfo',
       
        educationTypes:[],
        masterSocList:[],
        wageSourceList:['OES', 'CBA', 'Employer Conducted Survey', 'DBA', 'SCA', 'Other'],
        payFrequencyList:[ "Hour","Week","Month","Year" ],
        jdUpdateStatusError:'',
        jdUpdating:false

     }
    },
    methods: {
        tabChanged(tab='jobOpptInfo',back = false){
            let currentTab = _.cloneDeep(this.activeTab);
            this.maxWaseError=''; 
            this.$validator.validateAll(this.activeTab).then((result) => {
            if(result || back || this.completedtabs.indexOf(tab) > -1){
                if(result)  this.completedtabs.push(tab)
                this.activeTab = tab;
            }else{
                const $ = JQuery;
                if($('.text-danger:visible')){
                    $('.withTabButtons').scrollTop($('.text-danger:visible').first().parent().offset().top-50);
                }
            }

        })
            this.jdUpdateStatusError ='';
        },
        
        submitForm() {
        this.jdUpdateStatusError='';
        this.$validator.validateAll(this.activeTab).then((result) => {
           if(result && !this.filesAreuploading){
            this.jdUpdating =true;
            let path ="/perm/update-perm-info-for-efile";
            let data = {
                "petitionId": "",
                "userName": "",
                "typeName": "",
                "subTypeName": "",
                //jobDetails:{},
                permEfileInfo:{},
                jobOpportunityInfo:{},
                action: "PERM_MISSING_EFILE_INFO"
               
            }
            data['petitionId'] = this.checkProperty( this.petitionDetails ,'_id');
            data['userName'] = this.checkProperty( this.getUserData , 'loginRoleName');
            data['typeName'] = this.checkProperty( this.petitionDetails , 'typeDetails','name');
            data['subTypeName'] = this.checkProperty( this.petitionDetails ,'subTypeDetails','name');              
            data['jobOpportunityInfo'] = this.checkProperty( this.petitionDetails , 'jobOpportunityInfo');
            data['permEfileInfo'] = this.checkProperty( this.petitionDetails , 'permEfileInfo');  
            this.$store.dispatch('commonAction' ,{ "data":data ,'path':path})
            .then((res)=>{
              this.showToster({message:res['message'],isError:false });
              this.hideMe();
              this.$emit("updatepetition");
              window.open("https://www.plc.doleta.gov/eta_start.cfm?actiontype=home");
            })
            .catch((error)=>{
              this.jdUpdateStatusError =error;
              this.jdUpdating =false;
             })
           }
            else{
                const $ = JQuery;
                if($('.text-danger:visible')){
                    $('.withTabButtons').scrollTop($('.text-danger:visible').first().parent().offset().top-50);
                }
            }
        });
       },
        addAddress(){

            let newAddress = {
                "companyName": "",
                "workLocation": false,
                line1: "",
                line2: "",
                zipcode: "",
                countryId: "231",
                stateId: "",
                locationId: "",
                "countryDetails": { "_id": "626a8f03a972fa4d60681140", "id": 231, "name": "United States", "phoneCode": 1, "order": 1, "currencySymbol": "$", "currencyCode": "USD", "zipcodeLength": 5, "sortName": "united states" },
                stateDetails: null,
                locationDetails: null,
                aptType:''
            };
            this.petitionDetails['jobOpportunityInfo']['workAddresses'].push(newAddress);
            //this.$validator.reset();

        },
        removeAddress(index){
            this.petitionDetails['jobOpportunityInfo']['workAddresses'].splice(index ,1);

        },
        hideMe(){
            this.permjobDetailsPopUp =false;
            this.$emit('hideMe');

        },
        getMasterSocList(){

        let query = {};
        query["page"] = 1;
        query["perpage"] = 10000;
        query["matcher"] = { 
            // "getInactiveListAlso": true
             };
        query["category"] = "soc_codes";
       

        this.$store
        .dispatch("getMasterData", query)
        .then((response) => {
            this.masterSocList = response.list;
            if(this.checkProperty(this.petitionDetails ,'wageInfo' ,'socCode' )){
                this.petitionDetails['wageInfo']['socCodeDetails'] = _.find(this.masterSocList, {"id": this.petitionDetails['wageInfo']['socCode']});
            }


        //alert(this.perpage);
        })
        .catch(() => {
        this.masterSocList = [];

        });

       },
        updatesocCode(item){ 

            if(_.has( item ,'id')){
            this.petitionDetails['wageInfo']['socCode'] = item['id'];
            }
        },
        getEducationList(){
            this.$store
                .dispatch("getmasterdata", "education_types")
                .then((response) => {
                    this.educationTypes = response;
                    /*
                    petitionDetails['jobDetails'].minDegreeDetails =this.petitionDetails['jobDetails']['minDegree']
                    petitionDetails.jobOpportunityInfo.altLevelOfEduDetails ===== petitionDetails.jobOpportunityInfo.altLevelOfEdu
                    petitionDetails['jobOpportunityInfo'].minDegreeDetails === this.petitionDetails['jobOpportunityInfo']['minDegree']
                    */
                  
                    

                   if(this.checkProperty(this.petitionDetails ,'jobDetails' ,'minDegree' )){
                     this.petitionDetails['jobDetails'].minDegreeDetails = _.find(this.educationTypes ,{'id':this.petitionDetails['jobDetails']['minDegree']});
                   }

                   if(this.checkProperty(this.petitionDetails ,'jobOpportunityInfo' ,'minDegree' )){
                     this.petitionDetails.jobOpportunityInfo.minDegreeDetails = _.find(this.educationTypes ,{'id':this.petitionDetails['jobOpportunityInfo']['minDegree']});
                   }

                   if(this.checkProperty(this.petitionDetails ,'jobOpportunityInfo' ,'altLevelOfEdu' )){
                     this.petitionDetails.jobOpportunityInfo.altLevelOfEduDetails = _.find(this.educationTypes ,{'id':this.petitionDetails['jobOpportunityInfo']['altLevelOfEdu']});
                   }

                });

        },
        updateisAltFieldOfStudyAccept(){
            
            if(this.checkProperty(this.petitionDetails ,'jobOpportunityInfo','isAltFieldOfStudyAccept') !='Yes'){
               
                this.petitionDetails['jobOpportunityInfo']['altMajorFieldOfStudy'] ='';
            }

        },
        
        updateisExpRequired(){
            
            if(this.checkProperty(this.petitionDetails ,'jobOpportunityInfo','isExpRequired') !='Yes'){
               
                this.petitionDetails['jobOpportunityInfo']['noOfExpMonths'] =null;
            }

        },
        updateIsTrainigRequired(){
            
            if(this.checkProperty(this.petitionDetails ,'jobOpportunityInfo','isTrainigRequired') !='Yes'){
               
                this.petitionDetails['jobOpportunityInfo']['noOfTraningMonths'] =null;
                this.petitionDetails['jobOpportunityInfo']['fieldOfTraining'] ='';
                
            }

        },
        updateisForiegnLangRequired(){
            if(this.checkProperty(this.petitionDetails ,'jobOpportunityInfo','isForiegnLangRequired') !='Yes'){
               
               this.petitionDetails['jobOpportunityInfo']['skills'] =[];
              
               
           }

        },
        updateisExpInAltOccuAccept(){
            
            if(this.checkProperty(this.petitionDetails ,'jobOpportunityInfo','isExpInAltOccuAccept') !='Yes'){
               
                this.petitionDetails['jobOpportunityInfo']['noOfExpMonthsInAltOccu'] =null;
                this.petitionDetails['jobOpportunityInfo']['jobTitleOfAcceptAltOccu'] ='';
                
            }

        },
        updateisAltCombOfEduAndExpAccept(){
            
            if(this.checkProperty(this.petitionDetails ,'jobOpportunityInfo','isAltCombOfEduAndExpAccept') !='Yes'){
               
                this.petitionDetails['jobOpportunityInfo']['altLevelOfEdu'] =null;
                this.petitionDetails['jobOpportunityInfo']['altAcceptExpInYears'] ='';
                
            }

        },

    },
    props: {
        ACTIVITYCODE: {
            type: String,
            default: null,
        },
        value: null,
        formscope:{
            type:String,
            default:''

        },

        petitionDetails: {
            type: Object,
             default: null,
        },

    },
    mounted(){
      
        this.getMasterSocList()
        this.activeTab = 'jobOpptInfo';
        this.$store
            .dispatch("getmasterdata", "education_types")
            .then((response) => {
                this.educationTypes = response;
                // this.upDatehighestDegree();
            });
        this.$store.dispatch("getcountries").then(response => {
        this.countries = response;
        });


    }

}

</script>