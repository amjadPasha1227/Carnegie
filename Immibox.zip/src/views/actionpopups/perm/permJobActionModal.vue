<template>
   
    <modal
          name="jobDescPopModal"
          classes="v-modal-sec"
          :min-width="200"
          :min-height="200"
          :scrollable="true"
          :reset="true"
          width="650px"
          height="auto"
        >
        <div class="v-modal profile_details_modal error-modal-space" >
          <div class="popup-header fromDetailsPage">
            <h2 class="popup-title">
              
              <template v-if="ACTIVITYCODE=='INTERNAL_REQUEST_JOB_DESC_REVIEW'">Request for review of Job Description - Internal</template>
              <template v-if="ACTIVITYCODE=='INTERNAL_JOB_DESC_SUGGESSION'">Suggest Changes/Approve Job Description - Internal</template>
              <template v-if="ACTIVITYCODE=='INTERNAL_APPROVE_JOB_DESC'">Suggest Changes/Approve Job Description - Internal</template>

               <template v-if="ACTIVITYCODE=='SUBMIT_TO_DOL'">Submit to DOL</template>
               <template v-if="ACTIVITYCODE=='PERM_DRAFT_SUGGESSION'">Suggest Changes / Approve PERM Draft</template>
               <template v-if="ACTIVITYCODE=='REQUEST_JOB_DESC_REVIEW'">
               
                <template v-if="getTenantTypeId ==2"> Request for reviewing the Job Description</template>
                <template v-else> Request Petitioner for reviewing the Job Description</template>
                  
              </template>

               
                <template v-if="ACTIVITYCODE=='JOB_DESC_SUGGESSION'">Job Description Suggestion </template>
                <template v-if="ACTIVITYCODE=='APPROVE_JOB_DESC'">Approve Job Description </template>
                <template v-if="ACTIVITYCODE=='JOB_DESC_APPROVE_OR_SUGGESSION'">Suggest Changes / Approve Job Description</template>
                <template v-if="ACTIVITYCODE=='FINALIZE_JOB_DESC'">Finalize Job Description</template>
                <template v-if="ACTIVITYCODE=='APPROVE_PERM_APPLICATION'">Approve PERM Application</template>
                <template v-if="ACTIVITYCODE=='UPLOAD_PERM_ACK'">Upload PERM Acknowledgement</template>
                <template v-if="ACTIVITYCODE=='SUBMIT_RFI_RESPONSE'">Response Submitted to RFI</template>
                <template v-if="ACTIVITYCODE=='ACCOUNTANT_APPORVAL_REQUEST'">Request for Approval from Accounts</template>
                <template v-if="ACTIVITYCODE=='ACCOUNTANT_APPORVAL_GRANT'">Approve request to move forward</template>
               
               
                

               </h2>
            <span @click="showPopup=false;$modal.hide('jobDescPopModal');">
              <em class="material-icons">close</em>
            </span>
          </div>
        
          <form @submit.prevent data-vv-scope="uscisstatus" class="trackingform">
              <div class="form-container" @click="pewResponceUpdateStatusError=''">
                <template >
                      
                <div class="vx-row">
                  <div class="vx-col  w-full" v-if="ACTIVITYCODE=='INTERNAL_APPROVE_JOB_DESC'"  >
                      <div class="form_group">
                        <label class="form_label">Action<em>*</em></label>
                      <div class="con-select w-full DT_multiselect">
                            
                        <multiselect
                          name="jobAction"
                          v-validate="'required'"
                          v-model="actionData.actionDetails"
                          :show-labels="false"
                          :data-vv-as="'Action'"
                          track-by="id"
                          label="name"
                         
                          placeholder="Choose Action"
                          :options="internanlJobActionList"
                          :searchable="true"
                          :allow-empty="false"
                        ></multiselect>
                      </div>
                      <span
                        class="text-danger text-sm"
                        v-show="errors.has('uscisstatus.jobAction')"
                      >{{ errors.first("uscisstatus.jobAction") }}</span>
                      </div>
                    </div>

                  <div class="vx-col  w-full" v-if="ACTIVITYCODE=='JOB_DESC_APPROVE_OR_SUGGESSION'"  >
                      <div class="form_group">
                        <label class="form_label">Action<em>*</em></label>
                      <div class="con-select w-full DT_multiselect">
                                    
                        <multiselect
                          name="jobAction"
                          v-validate="'required'"
                          v-model="actionData.actionDetails"
                          :show-labels="false"
                          :data-vv-as="'Action'"
                          track-by="id"
                          label="name"
                         
                          placeholder="Choose Action"
                          :options="jobActionList"
                          :searchable="true"
                          :allow-empty="false"
                        ></multiselect>
                      </div>
                      <span
                        class="text-danger text-sm"
                        v-show="errors.has('uscisstatus.jobAction')"
                      >{{ errors.first("uscisstatus.jobAction") }}</span>
                      </div>
                    </div>
                   
                    <div class="vx-col w-full" v-if="(['Yes','No'].indexOf(checkProperty( petitionDetails , 'hasAnyRelationWithBeneficiary'))<=-1 && ['PERM_DRAFT_SUGGESSION' ,'APPROVE_PERM_APPLICATION'].indexOf(ACTIVITYCODE)>-1 && [50].indexOf(getUserRoleId)>-1)">
                    <div class="form_group custom-radio_wrap" >
                      <label class="message-label d-flex align-center mb-3">Do you have any relationship with the Beneficiary?<em>*</em>
                        <div class="IB_tooltip"  >
                          <span ><info-icon size="1.5x" class="custom-class"></info-icon ></span>
                          <div class="tooltip_cnt">
                              <p>The relation may be biological or business interests. Please note that your response will play an important role in approval of the case. Hence, this is an important information to disclose.</p>
                          </div>
                        </div>
                      </label>
                      <ul class="custom-radio" vs-type="flex" vs-align="center">
                        <li>
                          
                        <vs-radio    name="workflowType"  vs-value="Yes" v-model="actionData.hasAnyRelationWithBeneficiary" class="w-full mb-0"
                                ><span ref="hasAnyRelationWithBeneficiary-Yes">Yes</span></vs-radio > 

                        
                        </li>
                              <li>
                    
                            <vs-radio   name="workflowType"  vs-value="No"   v-model="actionData.hasAnyRelationWithBeneficiary" class="w-full mb-0"
                                > <span ref="hasAnyRelationWithBeneficiary-No">No</span></vs-radio > 
                        
                              </li>
                          
                      </ul>
                      <input type="hidden" name="hasAnyRelationWithBeneficiary" v-model="actionData.hasAnyRelationWithBeneficiary" v-validate="'required'"  class="w-full" :data-vv-as="'Comments'" />
                         <p v-show="errors.has('uscisstatus.hasAnyRelationWithBeneficiary')" class="text-danger text-sm" style="margin-top: -18px;"><em>*</em>Relation with Beneficiary is required</p>
                    </div>
                  </div>                  
                  <div class="vx-col  w-full" v-if="ACTIVITYCODE =='PERM_DRAFT_SUGGESSION'" >
                      <div class="form_group">
                        <label class="form_label">Action<em>*</em></label>
                      <div class="con-select w-full DT_multiselect">                  
                        <multiselect
                          name="casestatus"
                          v-validate="'required'"
                          v-model="actionData.permStatus"
                          :show-labels="false"
                          :data-vv-as="'Action'"
                          track-by="id"
                          label="name"
                         
                          placeholder="Choose Action"
                          :options="permStatusList"
                          :searchable="true"
                          :allow-empty="false"
                        ></multiselect>
                      </div>
                      <span
                        class="text-danger text-sm"
                        v-show="errors.has('uscisstatus.casestatus')"
                      >{{ errors.first("uscisstatus.casestatus") }}</span>
                      </div>
                    </div>
                   
                    <immiInput v-if="['UPLOAD_PERM_ACK'].indexOf(ACTIVITYCODE)>-1" :maxCharacters ="20" :wrapclass="'md:w-full'" :display="true" :cid="'uscisstatuspermApplicationNo'" :formscope="'uscisstatus'" v-model="permApplicationNo" :required="true" fieldName="permApplicationNo" label="PERM Application Number" placeHolder="PERM Application Number"  />
                  
                  
                  <div class="vx-col  w-full"  >
                   <div class="form_group">
                     <label class="form_label">Comments<em >*</em></label>
                             <!-- <vs-textarea name="Comments" v-model="actionData.comment" v-validate="'required'"  class="w-full" :data-vv-as="'Comments'" /> -->
                             <ckeditor  name="Comments" v-model="actionData.comment" v-validate="'required'"  class="w-full" :data-vv-as="'Comments'"  :editor="editor" :config="editorConfig"></ckeditor>
                         <p v-show="errors.has('uscisstatus.Comments')" class="text-danger text-sm"><em>*</em>Comments are required</p>
                    </div>
                    <vs-col class="w-full p-0" v-if="ACTIVITYCODE=='ACCOUNTANT_APPORVAL_GRANT'">
                      <vs-alert color="warning" class="warning-alert approval_grant_alert" icon-pack="IntakePortal" icon="IP-information-button" active="true">
                        Note that this approval only enables the team to complete further actions. This approval will not have any impact on Invoice/Payment status.
                      </vs-alert>
                    </vs-col>
                  </div>
                  
                  
                </div>

                <div v-if="['SUBMIT_RFI_RESPONSE', 'SUBMIT_TO_DOL','UPLOAD_PERM_ACK'].indexOf(ACTIVITYCODE)>-1"  class="vx-row" @click="documentModel=[]" >
                  
                  <div class="vx-col w-full">
                    <div class="form_group">
                      <label class="form_label" style="text-transform: capitalize"> Documents</label>
                      <div class="uploadsec_wrap upload_uscis">
                        <div class="w-full">
                            <div class="relative">
                              <file-upload
                                v-model="documentModel"
                                class="file-upload-input mb-0"
                                style="height:50px;"
                                name="trackingdoc"
                                :multiple="false"
                              
                                data-vv-as="Documents"
                                :accept="allDocEntity"
                                @input="uploadDocuments()"
                              >
                                <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                                Upload
                              </file-upload>
                              <span class="loader" v-if="filesAreuploading"><img src="@/assets/images/main/loader.gif"></span>
                            </div>
                          <span class="file-type">(File Type: PDF, DOC, JPEG, PNG. Max file size: 1MB)</span>
                          <span class="text-danger text-sm" v-show="errors.has('uscisstatus.trackingdoc')">{{ errors.first("uscisstatus.trackingdoc") }}</span>
                            <!-- <VuePerfectScrollbar class="scrollbardoc"> -->
                              
                                <div class="uploded-files_wrap mb-5" v-if="actionData['documents'].length >0 ">
                                    <template v-for="(fil, fileindex) in actionData['documents']">
                                      <div class="w-full"  :key="fileindex" >
                                          <div class="uploded-files">
                                              <vx-input-group class="form-input-group">
                                                <vs-input v-on:keyup="fileNameChenged(fil)"  v-validate="'required'" class="w-full" :name="'fName'+fileindex" v-model="actionData['documents'][fileindex]['name']" data-vv-as="File Name" />
                                                  <span class="text-danger text-sm" v-show="errors.has('uscisstatus.fName'+fileindex)">{{ errors.first('uscisstatus.fName'+fileindex) }}</span>

                                                  
                                              </vx-input-group>

                                              <div class="form_group">
                                              

                                                
                                              <div class="delete" style="z-index:999" @click="remove(fileindex , actionData['documents'])">
                                                      <img src="@/assets/images/main/delete-row-img.svg" />
                                                  </div>
                                              </div>
                                          </div>
                                      </div>
                                  </template>
                                </div>
                            <!-- </VuePerfectScrollbar> -->
                          </div>
                      </div>
                    </div>
                  </div>

                 

                
                </div>

              </template>
               
                
              </div>
              
              <div @click="pewResponceUpdateStatusError=''" class="text-danger text-sm formerrors" v-if="pewResponceUpdateStatusError!=''">
                        <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ pewResponceUpdateStatusError }}</vs-alert>
              </div>

              <div class="popup-footer relative">
              <span class="loader" v-if="pwdResUpdating"><img src="@/assets/images/main/loader.gif"></span>
                <vs-button color="dark" class="cancel" type="filled" @click="documentModel=[]; hideMe()">Cancel</vs-button>
                <vs-button color="success" :disabled="(pwdResUpdating || filesAreuploading)" @click="submitForm()" class="save" type="filled">
                
                  <template v-if="ACTIVITYCODE=='REQUEST_JOB_DESC_REVIEW'">Request</template>
                <template v-else-if="ACTIVITYCODE=='JOB_DESC_SUGGESSION'">Send</template>
                <template v-else-if="ACTIVITYCODE=='APPROVE_JOB_DESC'">Approve</template>
                <template v-else-if="ACTIVITYCODE=='FINALIZE_JOB_DESC'">Finalize</template>
                <template v-else-if="ACTIVITYCODE=='APPROVE_PERM_APPLICATION'">Approve</template>
                <template v-else-if="ACTIVITYCODE=='ACCOUNTANT_APPORVAL_REQUEST'">Send</template>
                <template v-else-if="ACTIVITYCODE=='ACCOUNTANT_APPORVAL_GRANT'">Approve</template>
                <template v-else>Submit</template>
                
                
                </vs-button>
              </div>
          </form>
          </div>
        </modal>  
</template>
<script>
import { InfoIcon } from "vue-feather-icons";

import moment from "moment";
import FileUpload from "vue-upload-component/src";
import { EyeIcon } from "vue-feather-icons";
import docType from "@/views/common/docType.vue";
import Datepicker from "vuejs-datepicker-inv";
import * as _ from "lodash";
import immiInput from "@/views/forms/fields/simpleinput.vue";
import immitextarea from "@/views/forms/fields/simpletextarea.vue";
import selectField from "@/views/forms/fields/simpleselect.vue";
import Vue from 'vue';
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
export default {
provide() {
        return {
           parentValidator: this.$validator,
        };
    },
components: {
  InfoIcon,
  docType,
  EyeIcon,
  FileUpload,
  Datepicker,
  immiInput,
  immitextarea,
  selectField
},
methods: {
    updatesocCode(item){ 

      if(_.has( item ,'id')){
      this.actionData['socCode'] = item['id'];
      }
    },
  getMasterSocList(){

            let query = {};
            query["page"] = 1;
            query["perpage"] = 10000;
            query["matcher"] = {};
            query["category"] = "soc_codes";


            this.$store
            .dispatch("getMasterData", query)
            .then((response) => {
            this.masterSocList = response.list;


            //alert(this.perpage);
            })
            .catch(() => {
            this.masterSocList = [];

            });

  },
  remove(index ,docs){
    docs.splice(index ,1);

  },
  /**
   * 
   * @param userType | String
   * @param typeId | String
   * @param childrenId | String
   * @param userName | String
   */
  uploadDocuments(){
    var self = this;
       let docs =_.cloneDeep(this.documentModel);
       this.documentModel=[];
        
          docs = docs.map(
              (item) =>{
                  item = {
                      name: item.name,
                      file: item.file,
                      path: "",
                      mimetype: item.type,
                      extn:item.extn?item.extn:'',
                      documentType:item.documentType?item.documentType:null,
                      userName:'',
                      uploadedBy: self.checkProperty(self.getUserData, 'userId'),
                        uploadedByName: self.checkProperty(self.getUserData, 'name'),
                        uploadedByRoleId: self.getUserRoleId,
                        uploadedByRoleName: self.checkProperty(self.getUserData, 'loginRoleName'),
                        size:item.size ? item.size : null,
                     
                  }
                 
                  
              return item;

            }
          );
         
          if (docs.length > 0) {
             
              this.filesAreuploading = true;
              
              let count =0;
              docs.forEach(function (doc) {
                  let formData = new FormData();
                  formData.append("files", doc.file);
                  formData.append("secureType", "private");
                  formData.append("getDetails", true);
                  self.$store.dispatch("uploadS3File", formData).then((response) => {
                    count = count+1;
                      if (response.data && response.data.result) {
                          response.data.result.forEach((urlGenerated) => {
                            //alert(JSON.stringify(urlGenerated))
                              // doc.url = urlGenerated;
                               doc.path = urlGenerated['path'];
                               doc.mimetype = urlGenerated['mimetype'];
                                doc.extn = urlGenerated['extn'];
                                doc.size = urlGenerated['size'];
                               
                              delete doc.file;
                              if(urlGenerated['path']){
                                 self.actionData['documents'].push(doc)
                               //  self.statusDocuments.push(doc)
                              }
                              
                              if(parseInt(count)>=docs.length){
                                 self.filesAreuploading = false;
                                 self.pwdResUpdating =false;
                               

                              }
                          });
                          if(count>=docs.length){
                            self.filesAreuploading = false;
                            self.pwdResUpdating =false;
                         

                          }
                          
                      }
                     
                  });
              });
          }
  },
 
    
  fileNameChenged(index, fileindex) {
          this.disable_uploadBtn = false;

          _.forEach(this.statusDocuments, (doc, value) => {
              let fname = doc.name;
              fname = fname.trim();

              if (!fname) {
                  this.disable_uploadBtn = true;
              }
          });

      },


    
  submitForm() {
     //alert(this.approveRejecInstructions);
          this.pewResponceUpdateStatusError='';
       
          this.$validator.validateAll("uscisstatus").then((result) => {

             if(result && !this.filesAreuploading){
              this.pwdResUpdating =true;
              let path ="/perm/manage-job-description";
              let data ={'entityType':'case', action:'' ,'petitionId':'' ,"typeName": "", 	"subTypeName": "", comment:'', jobDescSuggessionType:''}
               
              
             
              if( ['JOB_DESC_APPROVE_OR_SUGGESSION','JOB_DESC_SUGGESSION' ,'APPROVE_JOB_DESC','FINALIZE_JOB_DESC', 'INTERNAL_JOB_DESC_SUGGESSION', 'INTERNAL_APPROVE_JOB_DESC'].indexOf(this.ACTIVITYCODE) >-1  ){
                data['jobDescSuggessionType'] ='comments';
                 
              }
              if(this.ACTIVITYCODE =='APPROVE_PERM_APPLICATION'){
                data ={action:'' ,'petitionId':'' ,"typeName": "", 	"subTypeName": "", comment:''};

                if([50].indexOf(this.getUserRoleId)>-1){
                  data ={action:'' ,'petitionId':'' ,"typeName": "", 	"subTypeName": "", comment:'' ,'hasAnyRelationWithBeneficiary':'No'};
                  data['hasAnyRelationWithBeneficiary'] = this.actionData['hasAnyRelationWithBeneficiary'];
                }

                path ="/perm/manage-perm-application";
              }
              //actionData.permStatus
              data['action'] = this.ACTIVITYCODE;
              
              if( ['PERM_DRAFT_SUGGESSION'].indexOf(this.ACTIVITYCODE) >-1  ){
                path = "/perm/manage-perm-application";
                data['permDraftSuggessionType'] ='comments';
                data['jobDescSuggessionType'] ='';
                data['action'] = this.checkProperty(this.actionData ,'permStatus' ,'id')

                if([50].indexOf(this.getUserRoleId)>-1){
                  
                  data['hasAnyRelationWithBeneficiary'] = this.actionData['hasAnyRelationWithBeneficiary'];
                }
              } 
              if(['Yes','No'].indexOf(this.checkProperty(this.petitionDetails , 'hasAnyRelationWithBeneficiary'))>-1 && ['PERM_DRAFT_SUGGESSION' ,'APPROVE_PERM_APPLICATION'].indexOf(this.ACTIVITYCODE)>-1 && [50].indexOf(this.getUserRoleId)>-1){
                data['hasAnyRelationWithBeneficiary'] ='';
              }

              //SUBMIT_RFI_RESPONSE
              if(this.ACTIVITYCODE =='SUBMIT_RFI_RESPONSE'){
                path ="/perm/manage-pwd";
                data['documents'] = this.actionData['documents'];
                data['today'] = moment().format('YYYY-MM-DD');
                data['description']=this.actionData['comment'];


              }
              if(['ACCOUNTANT_APPORVAL_REQUEST','ACCOUNTANT_APPORVAL_GRANT' ,].indexOf(this.ACTIVITYCODE)>-1){
                   path ="/petition/manage-accountant-approval-for-payment";
                if( this.checkProperty(this.petitionDetails,'typeDetails','id')==3 && this.checkProperty(this.petitionDetails,'subTypeDetails','id')==15){
                    path ="/perm/manage-accountant-approval-for-payment";
                }

              }
              

              if( ['JOB_DESC_APPROVE_OR_SUGGESSION' ,'INTERNAL_APPROVE_JOB_DESC'].indexOf(this.ACTIVITYCODE) >-1  ){
                data['action'] = this.actionData['actionDetails']['id'];
              }


              if( this.checkProperty(this.petitionDetails,'typeDetails','id')==3 && this.checkProperty(this.petitionDetails,'subTypeDetails','id')==15){
                data['entityType'] = "perm";  
              }

             
              data['comment'] = this.actionData['comment']
              data['typeName'] = this.checkProperty( this.petitionDetails , 'typeDetails','name');
              data['subTypeName'] = this.checkProperty( this.petitionDetails ,'subTypeDetails','name');
              data['petitionId'] = this.checkProperty( this.petitionDetails ,'_id');
              if([ 'SUBMIT_TO_DOL'].indexOf(this.ACTIVITYCODE)>-1 ){
                path = "/perm/manage-approval-process";
                data['documents'] = this.actionData['documents'];
                data['today'] = moment().format('YYYY-MM-DD');
              }
             
              if(['UPLOAD_PERM_ACK' ].indexOf(this.ACTIVITYCODE)>-1 ){
                path = "/perm/manage-perm-application";
                data['documents'] = this.actionData['documents'];
                data['today'] = moment().format('YYYY-MM-DD');
                data['permApplicationNo'] = this.permApplicationNo.trim();
                
              }
              if(this.loadedFromPwdLibrary){
                data['pwdId'] =this.checkProperty( this.petitionDetails ,'_id');
                path ="/pwd/manage-job-description";

                if(this.checkProperty( this.petitionDetails ,'petitionList' ,'length')==1 && this.petitionDetails['completedActivities'].indexOf('PWD_CERTIFID')<=-1 ){
                    path ="/perm/manage-job-description";
                    data["typeName"] ="GC-Employment";
                    data["subTypeName"] ="GC-Employment";
                    data['petitionId'] = this.petitionDetails['petitionList'][0]['_id'];
                }
              }
              this.$store.dispatch('commonAction' ,{ "data":data ,'path':path})
              .then((res)=>{
                this.$emit("updatepetition");
                this.showToster({message:res['message'],isError:false });
                setTimeout(()=>{
                  this.hideMe();
                })
               
              })
              .catch((error)=>{
                this.pewResponceUpdateStatusError =error;
                this.pwdResUpdating =false;
               })

              

             }
          });
  },
  hideMe() {

    this.$emit("hideMe");
    setTimeout(()=>{
        this.$modal.hide('jobDescPopModal');
      },10);
  },
},
watch: {
  showPopup(val) {
    if (!val){
      this.$emit("hideMe");
      this.pwdResUpdating =false;
      this.$modal.hide('jobDescPopModal');
    } 
  },
},
mounted() {
 
    this.pwdResUpdating =false;
    this.getMasterSocList();
    this.showPopup = true;
    this.$modal.show('jobDescPopModal');
        if( ['PERM_DRAFT_SUGGESSION' ,'APPROVE_PERM_APPLICATION'].indexOf(this.ACTIVITYCODE)>-1 ){
          

            if([50].indexOf(this.getUserRoleId)>-1){
              this.actionData = Object.assign(this.actionData ,{'hasAnyRelationWithBeneficiary':'' });
              this.actionData = _.cloneDeep(this.actionData);
             
            }

           
          }
          if( ['PERM_DRAFT_SUGGESSION' ].indexOf(this.ACTIVITYCODE)>-1 ){
              this.actionData = Object.assign(this.actionData ,{'permStatus':'' });
              this.actionData = _.cloneDeep(this.actionData);
            
          }
          if(['UPLOAD_PERM_ACK' ].indexOf(this.ACTIVITYCODE)>-1 ){
          this.permApplicationNo = this.checkProperty(this.petitionDetails ,'permApplicationNo')
          }

          //ACCOUNTANT_APPORVAL_REQUEST ACCOUNTANT_APPORVAL_GRAN
          if(['ACCOUNTANT_APPORVAL_REQUEST' ].indexOf(this.ACTIVITYCODE)>-1 ){
            if(this.checkProperty(this.petitionDetails ,'invoiceId')){
              this.actionData.comment='Invoice is seen still unpaid. We need you to provide your approval to complete next steps.';
          
            }else{

              //this.actionData.comment='Filing cannot happen since the invoice is not paid yet. Request your action/approval.';
              this.actionData.comment='Invoice is seen still unpaid. We need you to provide your approval to complete next steps.';
          
              
            }
         }
          
  
},
data: () => ({
  editor: ClassicEditor,
 editorConfig: {
     toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
 },
  permApplicationNo:'',
  jobActionList:[

  
  {'id':'JOB_DESC_SUGGESSION' ,name:'Suggest Changes to Job Description'},
  {'id':'APPROVE_JOB_DESC' ,name:'Approve Job Description'},
  //{'id':'REQUEST_JOB_DESC_REVIEW' ,name:'Request Petitioner for reviewing the Job Description'}

  ],
  internanlJobActionList:[

  
  {'id':'INTERNAL_JOB_DESC_SUGGESSION' ,name:'Suggest Changes to Job Description'},
  {'id':'INTERNAL_APPROVE_JOB_DESC' ,name:'Approve Job Description'},
  //{'id':'REQUEST_JOB_DESC_REVIEW' ,name:'Request Petitioner for reviewing the Job Description'}

  ],
  permStatusList:[
    
    
    
    { 'id':'PERM_DRAFT_SUGGESSION' ,'name':'Suggest Changes to PERM Draft'},
    { 'id':'APPROVE_PERM_APPLICATION' ,'name':'Approve PERM Draft'},
  ], 
  masterSocList:[],
  pwdResUpdating:false,
  pewResponceUpdateStatusError:'',
  actionData:{
      "petitionId": "",
      "action": '',//"EFILE_PWD",'UPDATE_PWD_RESPONSE'
      "actionDetails":null,
      "typeName": "t",
      "subTypeName": "",
      "jobDescSuggessionType":'',
      comment:'',
      "documents": [],
      
},

 
  
 documentTypes:["Original" ,"Electronic" ],
  documentModel:[],
  statusDocuments:[],
 filesAreuploading: false,
  
  uploading: false,
  courierList: [],
  tracking: { documents: [], receiptNumber: null, receiptName: null },
  
  
  openDate: new Date().setFullYear(new Date().getFullYear()),
  startEligibleDate: new Date().setFullYear(new Date().getFullYear()),
  
  disabled_btn: false,
  showPopup: false,
  documents: [],
 
}),
props: {
  loadedFromPwdLibrary:{
      type: Boolean,
      default: false,

    },
  ACTIVITYCODE: {
    type: String,
    default: null,
  },
  petitionDetails: {
    type: Object,
    default: null,
  },
},
};
</script>
