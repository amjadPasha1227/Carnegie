<template>
   
    <modal
          name="jobDescPopModal"
          classes="v-modal-sec"
          :min-width="200"
          :min-height="200"
          :scrollable="true"
          :reset="true"
          width="750px"
          height="auto"
        >
        <div class="v-modal profile_details_modal error-modal-space " >
          <div class="popup-header fromDetailsPage">
            <h2 class="popup-title" :ACTIVITYCODE="ACTIVITYCODE" >
              
              
               
                <template >Edit Job Description</template>
              
                

               </h2>
            <span @click="hideMe();">
              <em class="material-icons">close</em>
            </span>
          </div>
          <!-----FROM START -->
          <form @submit.prevent data-vv-scope="jobCreation" class="trackingform" @click="jdUpdateStatusError=''">
            <div class="form-container somecls">
               
            <permJobCreationForm v-if="countries.length>0" :ACTIVITYCODE="ACTIVITYCODE" :countries="countries"  :formscope="'jobCreation'" :petitionDetails="petitionDetails" v-model="jobDetails" />
            <div class="text-danger text-sm formerrors" v-if="jdUpdateStatusError" >
               <vs-alert  color="warning" class="warning-alert reg-warning-alert no-border-radius"  icon-pack="IntakePortal"
              icon="IP-information-button"  active="true"  >{{ jdUpdateStatusError }}</vs-alert>
          </div>  
        </div>
        <div class="popup-footer relative">
                    <span class="loader" v-if="jdUpdating"><img src="@/assets/images/main/loader.gif"></span>
                    <vs-button color="dark" class="cancel" type="filled" :disabled="jdUpdating" @click="hideMe()" >Cancel</vs-button>
                    <vs-button color="success" :disabled="jdUpdating" @click="submitForm()" class="save" type="filled">Update</vs-button>

                </div> 
          </form>

        </div>  

   </modal>  
</template>
<script>

import JQuery from "jquery";

import * as _ from "lodash";
import { EyeIcon } from "vue-feather-icons";
import permJobCreationForm from "@/views/actionpopups/perm/permJobCreationForm.vue"

export default {
provide() {
        return {
           parentValidator: this.$validator,
        };
    },
components: {
  
  EyeIcon,
  permJobCreationForm,
},
methods: {

    

    
    submitForm() {
   //alert(this.approveRejecInstructions);
        this.jdUpdateStatusError='';
     
        this.$validator.validateAll('jobCreation').then((result) => {

           if(result ){
            this.jdUpdating =true;
            let path ="/perm/manage-job-description";
            let data ={
                "petitionId": "",
                "userName": "",
                "action": "CREATE_JOB_DESC", // 'CREATE_JOB_DESC','REQUEST_JOB_DESC_REVIEW', 'JOB_DESC_SUGGESSION', 'APPROVE_JOB_DESC', 'FINALIZE_JOB_DESC'
                "jobDescSuggessionType": "", // comments job_desc_update // Required for 'JOB_DESC_SUGGESSION'
                "comment": "", // Requied for jobDescSuggessionType = 'comments'
                "typeName": "",
                "subTypeName": "",
                jobDetails:{},
                wageInfo:{},
                wageOfferInfo:{},
                jobOpportunityInfo:{},
            }
            

             data['jobDescSuggessionType'] ='';
             let curWorkflowActivity ='';
              if(this.loadedFromPwdLibrary){
                curWorkflowActivity =this.checkProperty(this.petitionDetails ,'currentActivity')
              }else{
                curWorkflowActivity =this.checkProperty(this.petitionDetails ,'curWorkflowActivity')

              }
             if( ['JOB_DESC_SUGGESSION','JOB_DESC_APPROVE_OR_SUGGESSION' ,'INTERNAL_JOB_DESC_SUGGESSION'].indexOf(curWorkflowActivity) >-1){
                data['jobDescSuggessionType'] = 'job_desc_update';
             }
            data['action']  = this.ACTIVITYCODE; 
            data['petitionId'] = this.checkProperty( this.petitionDetails ,'_id');
            data['userName'] = this.checkProperty( this.getUserData , 'loginRoleName');
           
            data['typeName'] = this.checkProperty( this.petitionDetails , 'typeDetails','name');
            data['subTypeName'] = this.checkProperty( this.petitionDetails ,'subTypeDetails','name');              
           

            if(this.checkProperty(this.jobDetails ,'noOfPositions')){
              this.jobDetails['noOfPositions'] = parseInt(this.jobDetails['noOfPositions']);
              data['noOfPositions'] = parseInt(this.jobDetails['noOfPositions']); 
            }
           
            if(this.ACTIVITYCODE =="CREATE_JOB_DESC"){
              data['hasJobDetails']  =true;
            }
            data['jobDetails'] = this.jobDetails; 
           
             
            //data['wageInfo'] = this.checkProperty( this.petitionDetails , 'wageInfo');
          //  data['wageOfferInfo'] = this.checkProperty( this.petitionDetails , 'wageOfferInfo');
           // data['jobOpportunityInfo'] = this.checkProperty( this.petitionDetails , 'jobOpportunityInfo');  
           
           // alert(JSON.stringify(data));
           if(this.loadedFromPwdLibrary){
            
            path ="/pwd/manage-job-description";
            data['pwdId'] = this.checkProperty( this.petitionDetails ,'_id');
            
            	
            if(this.checkProperty( this.petitionDetails ,'petitionList' ,'length')==1 && this.petitionDetails['completedActivities'].indexOf('PWD_CERTIFID')<=-1 ){
              path ="/perm/manage-job-description";
              data["typeName"] ="GC-Employment";
              data["subTypeName"] ="GC-Employment";
              data['petitionId'] = this.petitionDetails['petitionList'][0]['_id'];
            }

           }
            this.$store.dispatch('commonAction' ,{ "data":data ,'path':path})
            .then((res)=>{
              this.showToster({message:res['message'],isError:false });
              this.hideMe();
              this.$emit("updatepetition");
            })
            .catch((error)=>{
              this.jdUpdateStatusError =error;
              this.jdUpdating =false;
             })

            

           }else{
                    const $ = JQuery;

                    if($('.text-danger:visible')){
                        $('.somecls').scrollTop($('.text-danger:visible').first().parent().offset().top-50);
                     }
      
                }
        });
       },
  hideMe() {

    this.$emit("hideMe");
    setTimeout(()=>{
        this.$modal.hide('jobDescPopModal');
      },10);
  },
},
watch: {
  showPopup(val) {
    if (!val){
      this.$emit("hideMe");
      this.$modal.hide('jobDescPopModal');
    } 
  },
},
mounted() {
    this.jobDetails = _.cloneDeep(this.petitionDetails['jobDetails']);
    if(!this.checkProperty(this.jobDetails ,"altJobRequirements")){
      this.jobDetails['altJobRequirements'] =  {

          areAltSetsOfEducation:"",// { type: String},
          altevelOfEducation: null,//{ type: Schema.Types.ObjectId, default: null  }, //0bjectId
          altevelOfEducationDetails:null,
          usDiplomaOrDegreeAccepted:'', //{type: String},
          majorsOrFieldsOfStudyAccepted: '',//{type: String},
          isAltTrainingForTheJobOpporAccepted: '',//"Yes" Or "No"
          noOfMonthsOfAltTrainingAccepted: null,//{type: String},
          filedsOrNamesOfTrainingAccepted: "",//{ type: String },
          altEmpExpAccepted: "", //"Yes" Or "No"
          noOfMonthsAltEmpExpAccepted:null,
          splSkillOrOtherRequi:'',
          ForeignLanguage:'',
          LicenseCertification:'',
          residencyFellowship:'',
          otherSplSkillsOrRequi:''

          }
          
    }
    this.$vs.loading();
    this.$store.dispatch("getcountries").then((response) => {
       
         
        this.jobDetails = _.cloneDeep(this.petitionDetails['jobDetails']);
        if(!this.checkProperty(this.jobDetails,'workAddresses') ||  this.checkProperty(this.jobDetails,'workAddresses' ,'length')<=0){
            this.jobDetails['workAddresses'] =[];

            let address = {
				"companyName": "",
				"line1" : "",
				"line2" : "",
				"aptType": "",
				"locationId" :null,
				"stateId" : null,
				"countryId" : 231,
				"zipcode" : "",
				"locationDetails" : {
					"id" : '',
					"name" : "",
					"stateId" : null,
					"countryId" : null
				},
				"stateDetails" : {
					"id" : null,
					"name" : "",
					"shortName" : "",
					"countryId" : null
				},
				"countryDetails" : {
                    "id" : 231,
                    "shortName" : "US",
                    "name" : "United States",
                    "phoneCode" : 1,
                    "order" : 1,
                    "currencySymbol" : "$",
                    "currencyCode" : "USD",
                    "zipcodeLength" : 5
                },
				"workLocation": true
		       	}
           this.jobDetails['workAddresses'].push(address);
           this.jobDetails['workAddresses'] = _.cloneDeep(this.jobDetails['workAddresses']);
           this.jobDetails = _.cloneDeep(this.jobDetails);
         
          }


         this.countries = response;
         this.$vs.loading.close();
          
         

    });
    this.$modal.show('jobDescPopModal');

    
    
  
},
data: () => ({
    educationTypes:[],
    jobDetails: {
        jobTitle: "",
        preferredSocCode: '',
        preferredSocCodeDetails:{},
        classification: "",
        description: "",
        skills: [],
        minDegree: '',
        minDegreeDetails:null,
        majorFieldsOfStudy: "",
        expInYears: "",
        altJobRequirements: {

  // Are alternate sets of Education, Training, and/or Experience accepted? "Yes", "No"

  areAltSetsOfEducation:"",// { type: String},
  altevelOfEducation: null,//{ type: Schema.Types.ObjectId, default: null  }, //0bjectId
  altevelOfEducationDetails:null,
  usDiplomaOrDegreeAccepted:'', //{type: String},
  majorsOrFieldsOfStudyAccepted: '',//{type: String},
  isAltTrainingForTheJobOpporAccepted: '',//"Yes" Or "No"
  noOfMonthsOfAltTrainingAccepted: null,//{type: String},
  filedsOrNamesOfTrainingAccepted: "",//{ type: String },
  altEmpExpAccepted: "", //"Yes" Or "No"
  noOfMonthsAltEmpExpAccepted:null,
  splSkillOrOtherRequi:'',
  ForeignLanguage:'',
  LicenseCertification:'',
  residencyFellowship:'',
  otherSplSkillsOrRequi:''

  },
        workAddresses: [{
          "companyName": "",
          "line1" : "",
          "line2" : "",
          "aptType": "",
          "locationId" :'' ,
          "stateId" :'' ,
          "countryId" :'' ,
          "zipcode" : "",
          "locationDetails" : {
            "id" : '',
            "name" : "",
            "stateId" : '',
            "countryId" :'' 
          },
          "stateDetails" : {
            "id" :'' ,
            "name" : "",
            "shortName" : "",
            "countryId" : ''
          },
          "countryDetails" : {
            "id" : 231,
            "shortName" : "US",
            "name" : "United States",
            "phoneCode" : 1,
            "order" : 1,
            "currencySymbol" : "$",
            "currencyCode" : "USD",
            "zipcodeLength" : 5
          },
          "workLocation": true
			}]
		   },
    jdUpdating:false,
    jdUpdateStatusError:'',
  countries:[],
  disabled_btn: false,
  showPopup: false,
  
 
}),
props: {
  loadedFromPwdLibrary:{
      type: Boolean,
      default: false,

    },
  ACTIVITYCODE: {
    type: String,
    default: null,
  },
  petitionDetails: {
    type: Object,
    default: null,
  },
},
};
</script>

