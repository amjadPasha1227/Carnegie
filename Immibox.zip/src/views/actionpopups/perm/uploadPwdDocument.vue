<template>
   
    <modal
          name="jobDescPopModal"
          classes="v-modal-sec"
          :min-width="200"
          :min-height="200"
          :scrollable="true"
          :reset="true"
          width="650px"
          height="auto"
        >
        <div class="v-modal profile_details_modal error-modal-space " >
          <div class="popup-header fromDetailsPage">
            <h2 class="popup-title">
              
              
               
                <template > Upload Filed/Certified PWD </template>
              
                

               </h2>
            <span @click="hideMe();">
              <em class="material-icons">close</em>
            </span>
          </div>
          <!-----FROM START -->
          <form @submit.prevent data-vv-scope="uploadPwdDoc" class="trackingform">
            <div class="form-container somecls">

                <div div class="vx-col w-full">
                    <label class="form_label" style="text-transform: capitalize"> Documents<em>*</em></label>
                    <div class="uploadsec_wrap upload_uscis">
                      <div class="w-full">
                          <div class="relative">
                            <file-upload
                              v-model="documentModel"
                              class="file-upload-input mb-0"
                              style="height:50px;"
                              name="trackingdoc"
                              :multiple="false"
                             
                              data-vv-as="Documents"
                              :accept="allDocEntity"
                              @input="uploadDocuments()"
                            >
                              <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                              Upload
                            </file-upload>
                            <span class="loader" v-if="filesAreuploading"><img src="@/assets/images/main/loader.gif"></span>
                          </div>
                        <span class="file-type">(File Type: PDF, DOC, JPEG, PNG. Max file size: 1MB)</span>
                        <span v-if="showDocumentsError && actionData['documents'].length<=0 "  class="text-danger text-sm"  ><em>* </em>Documents are required</span>

                          <!-- <VuePerfectScrollbar class="scrollbardoc"> -->
                            
                              <div class="uploded-files_wrap mb-5" v-if="actionData['documents'].length >0 ">
                                  <template v-for="(fil, fileindex) in actionData['documents']">
                                    <div class="w-full"  :key="fileindex" >
                                        <div class="uploded-files">
                                            <vx-input-group class="form-input-group">
                                              <vs-input v-on:keyup="fileNameChenged(fil)"  v-validate="'required'" class="w-full" :name="'fName'+fileindex" v-model="actionData['documents'][fileindex]['name']" data-vv-as="File Name" />
                                                <span class="text-danger text-sm" v-show="errors.has('uscisstatus.fName'+fileindex)">{{ errors.first('uscisstatus.fName'+fileindex) }}</span>

                                                
                                            </vx-input-group>

                                            <div class="form_group">
                                            

                                              
                                            <div class="delete" style="z-index:999" @click="remove(fileindex , actionData['documents'])">
                                                    <img src="@/assets/images/main/delete-row-img.svg" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                 </template>
                              </div>
                          <!-- </VuePerfectScrollbar> -->
                        </div>
                    </div>
                  </div>
               
            <div class="popup-footer relative">
                    <span class="loader" v-if="jdUpdating"><img src="@/assets/images/main/loader.gif"></span>
                    <vs-button color="dark" class="cancel" type="filled" :disabled="jdUpdating" @click="hideMe()" >Cancel</vs-button>
                    <vs-button color="success" :disabled="jdUpdating" @click="submitForm()" class="save" type="filled">Submit</vs-button>

                </div>   
        </div>
          </form>

        </div>  

   </modal>  
</template>
<script>

import JQuery from "jquery";

import FileUpload from "vue-upload-component/src";
import * as _ from "lodash";
import { EyeIcon } from "vue-feather-icons";

export default {
provide() {
        return {
           parentValidator: this.$validator,
        };
    },
components: {
  
  EyeIcon,
  FileUpload
},
methods: {
    remove(index ,docs){
    docs.splice(index ,1);
    this.showDocumentsError =false;
    if(this.actionData['documents'].length<=0){
        this.showDocumentsError =true;
    }

  },
    uploadDocuments(){
       let docs =_.cloneDeep(this.documentModel);
       this.documentModel=[];
        
          docs = docs.map(
              (item) =>{
                  item = {
                      name: item.name,
                      file: item.file,
                      path: "",
                      mimetype: item.type,
                      extn:item.extn?item.extn:'',
                      documentType:item.documentType?item.documentType:null,
                      userName:''
                     
                  }
                 
                  
              return item;

            }
          );
         
          if (docs.length > 0) {
              var self = this;
              this.filesAreuploading = true;
              
              let count =0;
              docs.forEach(function (doc) {
                  let formData = new FormData();
                  formData.append("files", doc.file);
                  formData.append("secureType", "private");
                  formData.append("getDetails", true);
                  self.$store.dispatch("uploadS3File", formData).then((response) => {
                    count = count+1;
                      if (response.data && response.data.result) {
                          response.data.result.forEach((urlGenerated) => {
                            //alert(JSON.stringify(urlGenerated))
                              // doc.url = urlGenerated;
                               doc.path = urlGenerated['path'];
                               doc.mimetype = urlGenerated['mimetype'];
                                doc.extn = urlGenerated['extn'];
                               
                              delete doc.file;
                              if(urlGenerated['path']){
                                 self.actionData['documents'].push(doc);
                                 self.showDocumentsError =false;
                               //  self.statusDocuments.push(doc)
                              }
                              
                              if(parseInt(count)>=docs.length){
                                 self.filesAreuploading = false;
                                 self.jdUpdating =false;
                                 
                               

                              }
                          });
                          if(count>=docs.length){
                            self.filesAreuploading = false;
                            self.jdUpdating =false;
                         

                          }
                          
                      }
                     
                  });
              });
          }
  },
 
    
  fileNameChenged(index, fileindex) {
          this.disable_uploadBtn = false;

          _.forEach(this.actionData['documents'], (doc, value) => {
              let fname = doc.name;
              fname = fname.trim();

              if (!fname) {
                  this.disable_uploadBtn = true;
              }
          });

      },


    

    
    submitForm() {
   //alert(this.approveRejecInstructions);
        this.jdUpdateStatusError='';
     
        this.$validator.validateAll('uploadPwdDoc').then((result) => {

           if(result ){
            this.jdUpdating =true;
            let path ="/perm/manage-job-description";
            let data ={
                "petitionId": "",
                "userName": "",
                "action": "CREATE_JOB_DESC", // 'CREATE_JOB_DESC','REQUEST_JOB_DESC_REVIEW', 'JOB_DESC_SUGGESSION', 'APPROVE_JOB_DESC', 'FINALIZE_JOB_DESC'
                "jobDescSuggessionType": "comments", //job_desc_update // Required for 'JOB_DESC_SUGGESSION'
                "comment": "", // Requied for jobDescSuggessionType = 'comments'
                "typeName": "",
                "subTypeName": "",
                jobDetails:{},
                wageInfo:{},
                wageOfferInfo:{},
                jobOpportunityInfo:{},
            }
            if(this.ACTIVITYCODE=='JOB_DESC_SUGGESSION'){
                data['jobDescSuggessionType'] = 'job_desc_update';
            }
            // if(this.checkProperty(this.petitionDetails['jobOpportunityInfo']['workAddresses'],'length') ==0){
            //     this.petitionDetails['jobOpportunityInfo']['workAddresses'].push(this.tempAddresses);
            // }
            data['petitionId'] = this.checkProperty( this.petitionDetails ,'_id');
            data['userName'] = this.checkProperty( this.getUserData , 'loginRoleName');
            data['action']  = this.ACTIVITYCODE; 
            data['typeName'] = this.checkProperty( this.petitionDetails , 'typeDetails','name');
            data['subTypeName'] = this.checkProperty( this.petitionDetails ,'subTypeDetails','name');              
          
            //data['wageInfo'] = this.checkProperty( this.petitionDetails , 'wageInfo');
          //  data['wageOfferInfo'] = this.checkProperty( this.petitionDetails , 'wageOfferInfo');
           // data['jobOpportunityInfo'] = this.checkProperty( this.petitionDetails , 'jobOpportunityInfo');  
           
           // alert(JSON.stringify(data));
            this.$store.dispatch('commonAction' ,{ "data":data ,'path':path})
            .then((res)=>{
              this.showToster({message:res['message'],isError:false });
              this.hideMe();
              this.$emit("updatepetition");
            })
            .catch((error)=>{
              this.jdUpdateStatusError =error;
              this.jdUpdating =false;
             })

            

           }else{
                    const $ = JQuery;

                    if($('.text-danger:visible')){
                        $('.somecls').scrollTop($('.text-danger:visible').first().parent().offset().top-50);
                     }
      
                }
        });
       },
  hideMe() {

    this.$emit("hideMe");
    setTimeout(()=>{
        this.$modal.hide('jobDescPopModal');
      },10);
  },
},
watch: {
  showPopup(val) {
    if (!val){
      this.$emit("hideMe");
      this.$modal.hide('jobDescPopModal');
    } 
  },
},
mounted() {
    this.jobDetails = _.cloneDeep(this.petitionDetails['jobDetails']);
 
    this.$store.dispatch("getcountries").then((response) => {
       
         
        this.jobDetails = _.cloneDeep(this.petitionDetails['jobDetails']);
         this.countries = response;
          
         

    });
    this.$modal.show('jobDescPopModal');

    
    
  
},
data: () => ({
    actionData:{
        documents:[]
    },
    documentModel:[],
    filesAreuploading:false,
    pwdResUpdating:false,
    disable_uploadBtn:false,
    showDocumentsError:'',

    
    educationTypes:[],
    jobDetails: {
        jobTitle: "",
        preferredSocCode: '',
        preferredSocCodeDetails:{},
        classification: "",
        description: "",
        skills: [],
        minDegree: '',
        minDegreeDetails:null,
        majorFieldsOfStudy: "",
        expInYears: "",
        workAddresses: [{
          "companyName": "",
          "line1" : "",
          "line2" : "",
          "aptType": "",
          "locationId" :'' ,
          "stateId" :'' ,
          "countryId" :'' ,
          "zipcode" : "",
          "locationDetails" : {
            "id" : '',
            "name" : "",
            "stateId" : '',
            "countryId" :'' 
          },
          "stateDetails" : {
            "id" :'' ,
            "name" : "",
            "shortName" : "",
            "countryId" : ''
          },
          "countryDetails" : {
            "id" : 231,
            "shortName" : "US",
            "name" : "United States",
            "phoneCode" : 1,
            "order" : 1,
            "currencySymbol" : "$",
            "currencyCode" : "USD",
            "zipcodeLength" : 5
          },
          "workLocation": true
			}]
		   },
    jdUpdating:false,
    jdUpdateStatusError:'',
  countries:[],
  disabled_btn: false,
  showPopup: false,
  
 
}),
props: {
  ACTIVITYCODE: {
    type: String,
    default: null,
  },
  petitionDetails: {
    type: Object,
    default: null,
  },
},
};
</script>

