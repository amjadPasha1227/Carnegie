<template>
     <modal
          name="dolAuditPopModal"
          classes="v-modal-sec"
          :min-width="200"
          :min-height="200"
          :scrollable="true"
          :reset="true"
          width="650px"
          height="auto"
        >
        <div class="v-modal profile_details_modal error-modal-space" >
          <div class="popup-header fromDetailsPage">
            <h2 class="popup-title">
               Update DOL Audit Report
               </h2>
            <span @click="showPopup=false;$modal.hide('dolAuditPopModal');">
              <em class="material-icons">close</em>
            </span>
          </div>
          <form @submit.prevent data-vv-scope="uscisstatus" class="trackingform">
              <div class="form-container" @click="dolAuditError=''">
                <template >
                     
                <div class="vx-row" v-for="(item , indexx) in auditTemplate" :key="indexx">
                    <div class="vx-col w-full pp-col" >
                        <vs-checkbox id="isSelected" name="isSelected" v-model="item.isSelected">{{item.name}}
                        </vs-checkbox>
                     </div>
                </div>            
                </template>
              </div> 
              <div @click="dolAuditError=''" class="text-danger text-sm formerrors padremove" v-if="dolAuditError!=''">
                    <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ dolAuditError }}</vs-alert>
              </div>

              <div class="popup-footer relative">
                <span class="loader" v-if="updateDolAudit"><img src="@/assets/images/main/loader.gif"></span>
                <vs-button color="dark" class="cancel" type="filled" @click="hideMe()">Cancel</vs-button>
                <vs-button color="success" :disabled="updateDolAudit" @click="submitForm()" class="save" type="filled">
                <template>Submit</template>
                </vs-button>
              </div>
          </form>
          </div>
        </modal>  
</template>
<script>
import immiInput from "@/views/forms/fields/simpleinput.vue";
import * as _ from "lodash";
export default {

    provide() {
        return {
           parentValidator: this.$validator,
        };
    },
    data: () => ({
        updateDolAudit:false,
        dolAuditError:'',
        auditTemplate:[
            {_id:1,name:'sai',isSelected:false},
            {_id:4,name:'manish',isSelected:false},
            {_id:5,name:'pavan',isSelected:false},
            {_id:6,name:'ravi',isSelected:false},
            {_id:2,name:'dileep',isSelected:false},
            {_id:3,name:'shyam',isSelected:false}
        ]
    }),
    components: {
        immiInput,
    },
    methods: {
        submitForm(){
            this.dolAuditError = '';
            let count = 0
            if(this.auditTemplate){
                _.forEach(this.auditTemplate,(item)=>{
                    if(_.has(item, 'isSelected') && item['isSelected'] ){
                        count++
                    }
                })
            }
            if(count<=0){
                this.dolAuditError = "Select atleast one item"
            }
            // else{
            //     _.forEach(this.auditTemplate, (item) => {
            //         if (item["isSelected"]) {
            //         postdata["dolAudit"].push(item["_id"]);
            //         }
            //     });
            //     this.$store
            //     .dispatch("commonAction", { "path": path, "data": postData })
            //     .then((response) => {
            //     this.showToster({ message: response.message, isError: false });
            //     this.hideMe();
            //     })
            //     .catch((error) => {
            //     this.updating = false;
            //     });
                 
            // }
        },
        hideMe() {
          this.$modal.hide('dolAuditPopModal');
        },
    },
    mounted() {
        //this.$modal.show('dolAuditPopModal');
    },
    
}
</script>