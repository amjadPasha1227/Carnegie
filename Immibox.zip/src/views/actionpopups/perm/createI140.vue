<template>
  <div>
    <modal name="newcasePopModal" classes="v-modal-sec" :min-width="200" :min-height="200" :scrollable="true"
      :reset="true" width="650px" height="auto">
      <div class="v-modal profile_details_modal error-modal-space">
        <div class="popup-header fromDetailsPage">
          <h2 class="popup-title">New Case</h2>
          <span @click="hideMe()">
            <em class="material-icons">close</em>
          </span>
        </div>
        <form data-vv-scope="newpetitionform">
          <div class="form-container">
            <div class="vx-row" @keyup="formerrors.msg = ''" @click="formerrors.msg = ''">
              <template>
                <div class="vx-col" :class="{
                  'w-full': getTenantTypeId == 2,
                  'w-1/2': !(getTenantTypeId == 2),
                }">
                  <div class="form_group">
                    <div class="con-select w-full select-large">
                      <label for="" class="form_label">Case Type<em>*</em></label>
                      <multiselect name="visatype" data-vv-as="Case Type" v-validate="'required'" v-model="visatype"
                        :show-labels="false" track-by="id" label="name" placeholder="Select Case Type"
                        :options="activeVisatypes" :searchable="true" :allow-empty="false" @input="getvisasubtypes"
                        :disabled="true">
                      </multiselect>
                    </div>
                    <span class="text-danger text-sm" v-show="errors.has('newpetitionform.visatype')">{{
                      errors.first("newpetitionform.visatype") }}</span>
                  </div>
                </div>

                <div class="vx-col" :class="{
                  'w-full': getTenantTypeId == 2,
                  'w-1/2': getTenantTypeId != 2,
                }">
                  <div class="form_group">
                    <div class="con-select w-full select-large">
                      <label for="" class="form_label">Case Subtype<em>*</em></label>
                      <multiselect name="visasubtype" data-vv-as="Case Subtype" v-validate="'required'"
                        v-model="visasubtype" :show-labels="false" track-by="id" label="name" :disabled="true"
                        placeholder="Select Case Subtype" :options="visasubtypes" :searchable="true" :allow-empty="false"
                        @input="formerrors.msg = ''">
                      </multiselect>
                    </div>
                    <span class="text-danger text-sm" v-show="errors.has('newpetitionform.visasubtype')">{{
                      errors.first("newpetitionform.visasubtype") }}</span>
                  </div>
                </div>
                <div class="vx-col" :class="{
                  'w-full': getTenantTypeId == 2,
                  'w-1/2': !(getTenantTypeId == 2),
                }">
                  <div class="form_group">
                    <div class="con-select w-full select-large">
                      <label for="" class="form_label">Classification<em>*</em></label>
                      <multiselect name="classification" data-vv-as="Classification" v-validate="'required'"
                        v-model="classification" :show-labels="false" placeholder="Classification"
                        :options="classificationList" :searchable="true" :allow-empty="false">
                      </multiselect>
                    </div>
                    <span class="text-danger text-sm" v-show="errors.has('newpetitionform.classification')">{{
                      errors.first("newpetitionform.classification") }}</span>
                  </div>
                </div>
                <div class="vx-col" :class="{
                  'w-full': getTenantTypeId == 2,
                  'w-1/2': !(getTenantTypeId == 2),
                }">
                  <div class="form_group">
                    <div class="con-select w-full select-large">
                      <label for="" class="form_label">Category<em>*</em></label>
                      <multiselect name="category" data-vv-as="Category" track-by="id" label="name"
                        v-validate="'required'" v-model="category" :show-labels="false" placeholder="Category"
                        :options="permCategoryList" :searchable="true" :allow-empty="false">
                      </multiselect>
                    </div>
                    <span class="text-danger text-sm" v-show="errors.has('newpetitionform.category')">{{
                      errors.first("newpetitionform.category") }}</span>
                  </div>
                </div>
                <div class="vx-col w-full pp-col">
                  <vs-checkbox id="premium" name="premiumProcessing" v-model="premiumProcessing">Premium Processing
                  </vs-checkbox>

                  <!-- <span class="text-danger text-sm"  v-show="errors.has('finalDeterminationFromDOL')">{{ errors.first("finalDeterminationFromDOL") }}</span> -->
                </div>
              </template>
            </div>

            <div class="text-danger text-sm formerrors" v-show="formerrors.msg">
              <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
                icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
            </div>
          </div>

          <div class="popup-footer">
            <vs-button color="dark" @click="hideMe()" class="cancel" type="filled">Cancel
            </vs-button>
            <vs-button color="success" :disabled="newPetitionFormSubmited" @click="createNewPetition(false)" class="save"
              type="filled">Submit</vs-button>
          </div>
        </form>
      </div>
    </modal>
    <vs-popup class="Change_petition_wrap" title="Create Case Confirmation" :active.sync="classificationConformPopup">
      <div class="Change_petition">
        <div class="form-container py-0">
          <div class="vx-row">
            <div class="vx-col w-full">
              <p class="text-center p-0">{{ i140CreationMessage }}</p>
            </div>
          </div>
        </div>
      </div>
      <div class="popup-footer relative">
        <span class="loader" v-if="newPetitionFormSubmited"><img src="@/assets/images/main/loader.gif" /></span>
        <vs-button color="dark" @click="classificationConformPopup = false ; formerrors.msg = ''; classification = ''"
          class="cancel" type="filled">No
        </vs-button>
        <vs-button color="success" :disabled="newPetitionFormSubmited" @click="createNewPetition(true)" class="save"
          type="filled">Yes</vs-button>
      </div>

    </vs-popup>
  </div>
</template>
<script>
import moment from "moment";
import FileUpload from "vue-upload-component/src";
import { EyeIcon } from "vue-feather-icons";
import docType from "@/views/common/docType.vue";
import Datepicker from "vuejs-datepicker-inv";
import * as _ from "lodash";
import immiInput from "@/views/forms/fields/simpleinput.vue";
import immitextarea from "@/views/forms/fields/simpletextarea.vue";
import selectField from "@/views/forms/fields/simpleselect.vue";
import datepickerField from "@/views/forms/fields/datepicker.vue";

export default {
  provide() {
    return {
      parentValidator: this.$validator,
    };
  },
  components: {
    datepickerField,
    docType,
    EyeIcon,
    FileUpload,
    Datepicker,
    immiInput,
    immitextarea,
    selectField,
  },
  methods: {
    classificationfun() {
      let Payload = {
        "matcher": {
          "searchString": "",
          "typeIds": [3],//[3],
          "subTypeIds": [16],// [16],
          "classificationList": [],// ["EB3"],
          "petitionerIds": [],
          "beneficiaryIds": [],
          "statusIds": [],
          "createdDateRange": [],
          "premiumProcessing": []
        }
      }
      //  if(this.visatype.id && this.visasubtype.id){
      //    Payload["matcher"]["typeIds"] = [this.visatype.id];
      //    Payload["matcher"]["subTypeIds"] = [this.visasubtype.id];  
      //  }
      //  if(this.selectedPetitioner && _.has(this.selectedPetitioner,'_id')){
      //    Payload["matcher"]["petitionerIds"] = [this.selectedPetitioner._id]
      //  }
      if (this.selectedBeneficiary && _.has(this.selectedBeneficiary, '_id')) {
        Payload["matcher"]["beneficiaryIds"] = [this.selectedBeneficiary._id]
      }
      if (this.classification) {
        Payload["matcher"]["classificationList"] = [this.classification]
      }

      this.newPetitionFormSubmited = true;
      this.$store.dispatch("getList", { data: Payload, path: '/petition-common/get-case-count' })
        .then(response => {
          this.classificationResultList = response;

          if (this.classificationResultList > 0) {
            this.classificationConformPopup = true;
            this.newPetitionFormSubmited = false;
          } else {
            this.newPetitionFormSubmited = false;
            this.classificationConformPopup = false;
            this.createNewPetition(true);
          }

        }).catch((err) => {
          this.classificationConformPopup = false;
          this.newPetitionFormSubmited = false;
        })



    },
    getvisatypes() {
      this.$store.dispatch("getvisatypes").then((response) => {
        this.visatypes = response;
        this.activeVisatypes = response;
      });
    },
    getvisaforNewCase() {
      let item = {
        matcher: {
          // "searchString":this.searchtxt,

          getActiveList: true,
        },
        page: this.page,
        perpage: this.perpage,
        category: "petition_types",
      };
      this.visatype = null;
      this.$store.dispatch("getMasterData", item).then((response) => {
        this.activeVisatypes = response.list;

        if (this.checkProperty(this.activeVisatypes, "length") > 0) {
          this.visatype = _.find(this.activeVisatypes, { id: 3 });

          this.getvisasubtypes(this.visatype);
        }
      });
    },
    getvisasubtypes(vsType) {
      Object.assign(this.formerrors, { msg: "" });

      if (this.visatype && _.has(this.visatype, "id")) {
        this.visasubtypes = [];
        this.visasubtype = null;

        let item = {
          matcher: {
            // "searchString":this.searchtxt,
            petitionType: parseInt(this.visatype["id"]),
            getActiveList: true,
          },
          page: this.page,
          perpage: this.perpage,
          category: "petition_sub_types",
        };

        this.$store.dispatch("getMasterData", item).then((response) => {
          this.visasubtypes = response.list;
          this.visasubtype = _.find(this.visasubtypes, { id: 16 });
        });
        this.$validator.reset();
      }
    },
    hideMe() {
      this.$emit("hideMe");
      setTimeout(() => {
        this.$modal.hide("newcasePopModal");
      }, 10);
    },
    createNewPetition(callFromConform = false) {
      Object.assign(this.formerrors, {
        msg: "",
      });

      this.$validator.validateAll("newpetitionform").then((result) => {
        if (result) {
          if (this.checkProperty(this.visasubtype, 'id') == 16 && !callFromConform) {
            this.classificationfun();
            this.newPetitionFormSubmited = true;
            return false;
          }
          let self = this;
          var postdata = {
            type: this.visatype.id,
            userId: this.petitionDetails.beneficiaryDetails._id,
            userName: this.petitionDetails.beneficiaryDetails.name,
            typeName: this.visatype.name,
            subType: this.visasubtype.id,
            subTypeName: this.visasubtype.name,
            petitionerId: null,//this.petitionDetails.petitionerDetails._id,
            premiumProcessing: this.premiumProcessing,
            branchId: this.petitionDetails.branchId,
            today: moment().format("YYYY-MM-DD"),

          };

          if (this.checkProperty(this.petitionDetails, 'petitionerDetails', '_id')) {
            postdata['petitionerId'] = this.petitionDetails.petitionerDetails._id
          }

          if (
            this.checkProperty(this.visatype, "id") == 3 &&
            this.checkProperty(this.visasubtype, "id") == 16) {
            postdata["categoryId"] = this.checkProperty(this.category, 'id');
            postdata["permId"] = this.petitionDetails._id;
            postdata["classification"] = this.classification;
            postdata["permDocs"] = [];
            if (_.has(this.petitionDetails, 'dolResponse') && _.has(this.petitionDetails['dolResponse'], 'documents') && this.petitionDetails['dolResponse']['documents'].length > 0) {

              postdata["permDocs"] = this.petitionDetails['dolResponse']['documents']
            }

          }

          if (!this.newPetitionFormSubmited) {
            this.newPetitionFormSubmited = true;
            this.$store
              .dispatch("petitioner/createnewpetition", postdata)
              .then((response) => {
                this.premiumProcessing = false;
                if (response.error) {
                  Object.assign(this.formerrors, {
                    msg: response.error.message,
                  });
                  this.newPetitionFormSubmited = false;
                } else {

                  let dt = {
                    petitionId: response._id,
                    userName: this.selectedUsername,
                    email: this.selectedUseremail,
                    typeName: this.visatype.name,
                    subTypeName: this.visasubtype.id,
                    instructions: null,
                  };


                  this.showToster({
                    message: response.message,
                    isError: false,
                  });

                  this.newPetitionFormSubmited = false
                  this.classificationConformPopup = false

                  setTimeout(() => {
                    this.$emit("hideMe");
                    this.$emit("updatepetition");
                  }, 10);
                }
              })
              .catch((error) => {
                //this.showToster({message:error,isError:true});
                this.newPetitionFormSubmited = false;

                Object.assign(this.formerrors, {
                  msg: error,
                });
              });
          }
        }
      });
    },
    getCategoryForCase() {
      let item = {
        matcher: {

        },
        page: this.page,
        perpage: 10000,
        category: "case_category",
      };
      this.$store.dispatch("getMasterData", item).then(response => {
        this.permCategoryList = response.list;

      });
    },
    getCommonMessages() {
      let payLoad = {
        "category": ["COMMON_MESSAGES"]
      }
      this.$store.dispatch("commonAction", { "data": payLoad, "path": "/messages/list" }).then((response) => {
        if (_.has(response['messages']['COMMON_MESSAGES'], 'i140DuplicateCase')) {
          this.i140CreationMessage = response['messages']['COMMON_MESSAGES']['i140DuplicateCase']
        }
      }).catch((error) => {})
    }
  },
  watch: {
    showPopup(val) {
      if (!val) {
        this.$emit("hideMe");
        this.$modal.hide("newcasePopModal");
      }
    },
  },
  mounted() {
    this.getCommonMessages();
    this.getCategoryForCase()
    this.visatype = {
      id: 3,
      name: "GC-Employment",
    };

    this.getvisasubtypes(this.visatype);

    this.getvisatypes();
    this.getvisaforNewCase();
    this.username = this.$store.state.user.name;
    if (this.checkProperty(this.petitionDetails, "jobDetails", "classification")) {
      //classification
      // this.category =this.petitionDetails.jobDetails.classification
      // alert(JSON.stringify(this.petitionDetails.jobDetails.classification))
      this.permCategory = this.checkProperty(this.petitionDetails, "jobDetails", "classification");
    }
    this.showPopup = true;
    this.$modal.show("newcasePopModal");
  },
  data: () => ({
    i140CreationMessage: '',
    classificationConformPopup: false,
    classificationResultList: [],
    formerrors: {
      msg: "",
    },
    branchList: [],
    selectedBranch: null,
    petitionersList: [],
    selectedPetitioner: null,
    premiumProcessingList: [
      { name: "Yes", _id: true },
      { name: "No", _id: false },
    ],
    selectedpremiumProcessing: [],
    premiumProcessing: false,
    beneficiaryMasterDataList: [],
    selectedUser: "",
    selectedUsername: "",
    visatypes: [],
    activeVisatypes: [],
    activeVisaSubTypes: [],
    classification: null,
    category: null,
    permCategory: null,
    permCategoryList: [],
    classificationList: ["EB2", 'EB3', "EB3S"],
    visatype: null,
    visasubtypes: [],
    visasubtype: null,
    selectedBeneficiary: null,
    newPetitionFormSubmited: false,
    selecteduser: {
      petitionId: null,
      userName: null,
      email: null,
      typeName: null,
      subTypeName: null,
      instructions: null,
    },
  }),
  props: {
    ACTIVITYCODE: {
      type: String,
      default: null,
    },
    petitionDetails: {
      type: Object,
      default: null,
    },
  },
  computed: {},
};
</script>
