<template>
    <div class="custom_modal_cnt">
        <div class="modal_title">      
            <h2> Job Details  </h2>                
                <span class="close--" @click="hideMe()"><x-icon size="1.5x"></x-icon></span>
        </div>
            <div>
            <div class="custom-tabs">
                <ul class="d-flex">
                    <li :class="{'active':activeTab=='jobDetails'}" @click="tabChanged('jobDetails')">Job Information</li>
                    <li  :class="{'active':activeTab=='wageInfo'}" @click="tabChanged('wageInfo')">Wage Information</li>
                    <!-- <li  :class="{'active':activeTab=='jobOpptInfo'}" @click="tabChanged('jobOpptInfo')">Job Opportunity Information</li> -->
                </ul>
            </div>
                <div v-if="petitionDetails">
                        <div v-if="activeTab=='jobDetails'">
                            <div class="modal_cnt withTabButtons">
                                <form data-vv-scope="jobDetails" @submit.prevent="" @keydown.enter.prevent="" >
                                    <div @click="jdUpdateStatusError=''" class="form-container">
                                        <VuePerfectScrollbar	
                                            ref="mainSidebarPs"	
                                            class="scroll-area--main-sidebar"	
                                            :settings="settings"	
                                        >
                                        <div class="infoSec">
                                            <div class="vx-row" > 
                                                <template v-if="false">
                                                    <immiInput :wrapclass="'md:w-1/3'" :display="true" :cid="'jobTitle'" :formscope="'jobDetails'"  v-model="petitionDetails['jobDetails'].jobTitle" :required="true" fieldName="jobTitle" label="Job Title" placeHolder="Job Title"   />
                                                    <selectField :wrapclass="'md:w-1/3'" :required="true"  cid="preferredSocCode"  :formscope="'jobDetails'" :optionslist="masterSocList" v-model="petitionDetails['jobDetails'].preferredSocCodeDetails" @input="petitionDetails['jobDetails'].preferredSocCode = petitionDetails['jobDetails'].preferredSocCodeDetails['id']"   fieldName="preferredSocCode" label="Preferred SOC Code" placeHolder="Preferred SOC Code "   />  
                                                    <immiInput :wrapclass="'md:w-1/3'" :display="true" :cid="'preferredSocOccuTitle'" :formscope="'jobDetails'" v-model="petitionDetails['jobDetails'].preferredSocOccuTitle"   :required="true" fieldName="preferredSocOccuTitle" label="Preferred SOC Title" placeHolder="Preferred SOC Title" />
                                                    <selectField :wrapclass="'md:w-1/3'" :required="true"  cid="socCode"  :formscope="'jobDetails'" :optionslist="masterSocList" v-model="petitionDetails['jobDetails'].socCodeDetails" @input="petitionDetails['jobDetails'].socCode = petitionDetails['jobDetails'].socCodeDetails['id']"   fieldName="socCod" label="SOC Code" placeHolder="SOC Code "   />  
                                                    <immiInput :wrapclass="'md:w-1/3'" :display="true" :cid="'socOccuTitle'" :formscope="'jobDetails'" v-model="petitionDetails['jobDetails'].socOccuTitle"   :required="true" fieldName="socOccuTitle" label="SOC Title" placeHolder="SOC Title" />
                                                    <selectField :listContainsId="false" :display="true" :wrapclass="'md:w-1/3'" :formscope="'jobDetails'" :required="true"  cid="classification"   :optionslist="classificationList" v-model="petitionDetails['jobDetails'].classification" label="Classification"  fieldName="classification" placeHolder="Classification"   /> 
                                                    <selectField :wrapclass="'md:w-1/3'" :required="true" :optionslist="educationTypes" v-model="petitionDetails['jobDetails'].minDegreeDetails" @input="petitionDetails['jobDetails'].minDegree = petitionDetails['jobDetails'].minDegreeDetails['id']" :formscope="'jobDetails'"  fieldName="minDegree" label="Minimum Education Level" placeHolder="Minimum Education Level"   />  
                                                    <immiInput :wrapclass="'md:w-1/3'" :display="true" :cid="'majorFieldsOfStudy'" :formscope="'jobDetails'" v-model="petitionDetails['jobDetails'].majorFieldsOfStudy"   :required="true" fieldName="majorFieldsOfStudy" label="Major Field of Study" placeHolder="Major Field of Study" />
                                                    <immiInput :onlyNumbers="true" :allowFloatingPoint="true" :wrapclass="'md:w-1/3'" :display="true" cid="expInYears" :formscope="'jobDetails'"  v-model="petitionDetails['jobDetails'].expInYears" :required="true" fieldName="expInYears" label="Experience in Years" placeHolder="Experience"  :maxLength="5" />
                                                    <immiInput :onlyNumbers="true" :allowFloatingPoint="true" :wrapclass="'md:w-1/3'" :display="true" cid="wageRate" :formscope="'jobDetails'" v-model="petitionDetails['jobDetails'].wageRate" :required="true" fieldName="wageRate" label="Preferred Wage Rate" placeHolder="Preferred Wage Rate" :maxLength="10" />
                                                <template >
                                                <div class="vx-col w-full">
                                                    <div class="skilladdsec">
                                                        <label>Specific skills or other requirements </label>
                                                        <ul>
                                                            <li v-for="(skil , index ) in petitionDetails['jobDetails']['skills']" :key="index">
                                                                <span class="skill-label">{{skil}}</span>
                                                            

                                                                <span  @click="removeSkill(index)" class="row_btn">
                                                                    <img src="@/assets/images/main/delete-row-img.svg">
                                                                </span>
                                                            </li>
                                                        </ul>
                                                        <div class="add-input-sec">
                                                            <div @keyup.enter.native="addNewSkill()" @keyup="addSkill=true">
                                                                <immiInput  :wrapclass="'w-full'"  :display="true" cid="addSkill" :formscope="'jobOpptInfo'"  v-model="newSkill" :required="false" fieldName="altAcceptExpInYears" placeHolder=""  />
                                                                <span v-if="addSkill"  @click="addNewSkill()" class="add-more">Add</span>
                                                            </div>

                                                            <!-- <li v-if="!addSkill"  @click="newSkill =''" > <span class="add-more">+ More</span></li> -->
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                                </template> 
                                                <immitextfield  wrapclass="md:w-1/1"  :formscope="'jobDetails'"  v-model="petitionDetails['jobDetails'].description" :required="true" fieldName="description" label="Job Description" placeHolder="Job Description"></immitextfield>
                                                <div class="vx-col w-full" v-if="countries.length>0"    vs-type="flex"  vs-justify="center" vs-align="center" vs-lg=" "  vs-sm=" "  >
                                                <div class="addMoreAddress">
                                                    
                                                <h3 class="small-header mt-0">Primary Worksite </h3>
                                                <template v-for="(addr ,addind ) in petitionDetails['jobDetails']['workAddresses']" >
                                                    <div class="vx-row mar0" :key="addind"  >
                                                            <addressFields
                                                                :formscope="'jobOpptInfo'"
                                                                :key="addind"
                                                                :name="'PrimaryWork_Location'+addind"
                                                                :disableCountry="true"
                                                                :addFormContainerCls="false"
                                                                :validationRequired="true"
                                                                :showaptType="true"
                                                                :countries="countries"
                                                                v-model="petitionDetails['jobDetails']['workAddresses'][addind]"
                                                                :cid="'Primary_Work_Location'+addind"
                                                            />
                                                        </div>
                                                </template>
                                                </div>    
                                                </div>
                                            <div class="divider mt-0"></div>
                                                </template>
                                                <template>
                                                    <immiInput :wrapclass="'md:w-1/3'" :display="true" :cid="'jobId'" :formscope="'jobDetails'"  v-model="petitionDetails['moreJobDetails'].jobId" :required="true" fieldName="jobId" label="Job Id" placeHolder="Job Id"   />
                                                    <immiInput v-if="!checkProperty( this.petitionDetails , 'noOfPositions')" :onlyNumbers="true" :allowFloatingPoint="false" :wrapclass="'md:w-1/3'" :display="true" :cid="'noOfPositionss'" :formscope="'jobDetails'" v-model="petitionDetails['moreJobDetails'].noOfPositions" :maxLength="4"  :required="true" fieldName="noOfPositions" label="No of Positions" placeHolder="No of Positions" />
                                                    <immiInput :onlyNumbers="true" :wrapclass="'md:w-1/3'" :display="true" cid="salary" :formscope="'jobDetails'"  v-model="petitionDetails['moreJobDetails'].salary" :required="true" fieldName="salary" label="Salary per Year" placeHolder="Salary"   />                                   
                                                    <selectField :listContainsId="false" :wrapclass="'md:w-1/3'" cid="jobType"  :required="true" :optionslist="['Full Time', 'Part Time']" v-model="petitionDetails['moreJobDetails'].jobType" :formscope="'jobDetails'"  fieldName="jobType"  label="Job Type" placeHolder="Job Type"  />                                     
                                                    <selectField :listContainsId="false" :wrapclass="'md:w-1/3'" cid="jobShift"  :required="true" :optionslist="['Day', 'Night']" v-model="petitionDetails['moreJobDetails'].jobShift" :formscope="'jobDetails'"  fieldName="jobShift"  label="Job Shift" placeHolder="Job Shift"   />                                     
                                                    <immiInput :maxvalueData="'maxval:168'" :ref="'updateHoursPerWeek'" :allowFloatingPoint="false" :onlyNumbers="true" @input="updateHoursWeek($event)" :wrapclass="'md:w-1/3'" :display="true" cid="hoursPerWeek" :formscope="'jobDetails'"  v-model="petitionDetails['moreJobDetails'].hoursPerWeek" :required="true" fieldName="hoursPerWeek" label="Hours per Week" placeHolder="Hours per Week"  :maxLength="3" />
                                                    <!-- <immiInput  :wrapclass="'md:w-1/3'" :display="true" cid="applyByMail" :formscope="'jobDetails'"  v-model="petitionDetails['moreJobDetails'].applicationInfo.applyByMail" :required="true" fieldName="applyByMail" label="Apply By Mail" placeHolder="Apply By Mail"   /> -->
                                                    <immitextarea  wrapclass="md:w-1/1"  :formscope="'jobDetails'" v-model="petitionDetails['moreJobDetails'].applicationInfo.applyByMail" :required="true" fieldName="applyByMail" label="Apply by Mail" placeHolder="Apply by Mail"></immitextarea>
                                                    <!----:dateEnableTo="new Date()"-->
                                                    <datepickerField wrapclass="md:w-1/3" @input="updateJobStartDate($event)"    :display="true"  v-model="petitionDetails['moreJobDetails'].applicationInfo.jobStartsOn" :formscope="'jobDetails'"  fieldName="jobStartsOn"  label="Job Start Date" :validationRequired="true"   />
                                                    <datepickerField wrapclass="md:w-1/3" :isDisabled="!petitionDetails['moreJobDetails'].applicationInfo.jobStartsOn" :dateOpenFrom="petitionDetails['moreJobDetails'].applicationInfo.jobStartsOn"  :display="true"   v-model="petitionDetails['moreJobDetails'].applicationInfo.jobEndOn" :formscope="'jobDetails'"  fieldName="jobEndOn" :dateEnableFrom="petitionDetails['moreJobDetails'].applicationInfo.jobStartsOn"  label="Job End Date"  :validationRequired="true"   />
                            



                                                    <!-- <selectField :wrapclass="'md:w-1/3'" :required="true" :optionslist="educationTypes" v-model="petitionDetails['jobDetails'].minDegreeDetails" @input="updateMainDegree" :formscope="'jobDetails'"  fieldName="minDegree" label="Minimum Education Level" placeHolder="Minimum Education Level"   />  
                                                    <immiInput :onlyNumbers="true" :allowFloatingPoint="true" :wrapclass="'md:w-1/3'" :display="true" cid="expInYears" :formscope="'jobDetails'"  v-model="petitionDetails['jobDetails'].expInYears" :required="true" fieldName="expInYears" label="Experience in Years" placeHolder="Experience"  :maxLength="5" /> -->
                                                </template> 
                                            </div>
                                            <div @click="jdUpdateStatusError=''" class="text-danger text-sm formerrors" v-if="jdUpdateStatusError!=''"> 
                                                <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ jdUpdateStatusError }}</vs-alert>
                                            </div>
                                        </div> 
                                    </VuePerfectScrollbar>

                                    </div>
                                </form>
                            </div>
                            <div class="popup-footer">
                                    <span class="loader" v-if="jdUpdating"><img src="@/assets/images/main/loader.gif"></span>
                                    <vs-button color="dark" class="cancel" type="filled" @click="hideMe()">Cancel</vs-button>
                                    <vs-button color="success" :disabled="jdUpdating" @click="tabChanged('wageInfo')" class="save" type="filled">Next</vs-button>
                                    
                                    
                                   
                                   <!----
                                     <vs-button color="success" :disabled="jdUpdating" @click="submitForm()" class="save" type="filled">Submit</vs-button>
                                    -->
                                    </div>

                        </div>
                        <div v-if="activeTab=='wageInfo'">
                            <div class="modal_cnt withTabButtons">
                                <form data-vv-scope="wageInfo" @submit.prevent="" @keydown.enter.prevent="" >
                                <div @click="jdUpdateStatusError='';"  class="form-container">
                                    <VuePerfectScrollbar	
                                                ref="mainSidebarPs"	
                                                class="scroll-area--main-sidebar"	
                                                :settings="settings"	
                                            
                                            > 
                                    <div class="infoSec">
                                        <h4>Wage Information</h4>
                                        <div class="vx-row">
                                            <immiInput :wrapclass="'md:w-1/3'" :display="true" cid="trackingNumber" :formscope="'wageInfo'" v-model="petitionDetails.wageInfo.trackingNumber" :required="true" fieldName="trackingNumber" label="Tracking Number" placeHolder="Tracking Number" />
                                            <selectField :wrapclass="'md:w-1/3'" :required="true"  cid="preferredSocCode"  :formscope="'wageInfo'" :optionslist="masterSocList" v-model="petitionDetails.wageInfo.preferredSocCodeDetails" @input="petitionDetails.wageInfo.preferredSocCode = petitionDetails.wageInfo.preferredSocCodeDetails['id']"   fieldName="preferredSocCode" label="Preferred SOC Code" placeHolder="Preferred SOC Code "   />  
                                            <immiInput :onlyNumbers="true" :allowFloatingPoint="true" :wrapclass="'md:w-1/3'" :display="true" cid="preferredWageRate" :formscope="'wageInfo'" v-model="petitionDetails.wageInfo.preferredWageRate" :required="true" fieldName="preferredWageRate" label="Preferred Wage Rate" placeHolder="Preferred Wage Rate" :maxLength="10" />
                                            <selectField :listContainsId="false" :wrapclass="'md:w-1/3'" :required="true"  :formscope="'wageInfo'" cid="offerpayFrequency"  :optionslist="payFrequencyList" v-model="petitionDetails.wageInfo.payFrequency"  fieldName="offerpayFrequency" label="Pay Frequency" placeHolder="Pay Frequency"   />  
                                            <selectField :listContainsId="false" :wrapclass="'md:w-1/3'" :required="true" :formscope="'wageInfo'" cid="wageSource"  :optionslist="wageSourceList" v-model="petitionDetails.wageInfo.wageSource"   fieldName="wageSource" label="Source of Wage" placeHolder="Source of Wage"   />  
                                            <datepickerField wrapclass="md:w-1/3" :dateEnableTo="new Date()" @input="updateDeterminationDate($event)" :display="true"  v-model="petitionDetails.wageInfo.determinationDate" :formscope="'wageInfo'" fieldName="determinationDate"  label="Determination Date" :validationRequired="true" />
                                            <datepickerField :isDisabled="!petitionDetails.wageInfo.determinationDate" wrapclass="md:w-1/3"  :display="true"   v-model="petitionDetails.wageInfo.expirationDate" :formscope="'wageInfo'" fieldName="expirationDate" :dateEnableFrom="petitionDetails.wageInfo.determinationDate" label="Expiration Date"  :validationRequired="true" />
                                            <immitextarea v-if="checkProperty(petitionDetails,'wageInfo','wageSource') == 'Other'"  wrapclass="md:w-1/1"  :formscope="'wageInfo'" v-model="petitionDetails.wageInfo.wageSourceOtherDesc" :required="true" fieldName="wageSourceOtherDesc" label="Wage Source Description" placeHolder="Wage Source Description"></immitextarea>

                                        </div>
                                    <div class="divider mt-0"></div>
                                    <h4>Wage Offer Information</h4>
                                        <div class="vx-row">
                                        <div class="vx-col  w-full md:w-1/3" >
                                             <div class="form_group">
                                                   <label class="form_label">Minimum Wage<em >*</em></label>
                                                   <vs-input  oninput="petitionDetails.wageOfferInfo.minWage = petitionDetails.wageOfferInfo.minWage.replace(/[^0-9 .]/g, '').replace(/(\..*)\./g, '$1'); petitionDetails.wageOfferInfo.minWage = petitionDetails.wageOfferInfo.minWage.replace(/ /g,'')"  name="wageminimum" v-model="petitionDetails.wageOfferInfo.minWage" v-validate="'required|numeric' "  :maxLength="9" class="w-full" :data-vv-as="'Minimum Wage'"  />
                                                   <p v-show="errors.has('wageInfo.wageminimum')" class="text-danger text-sm">{{ errors.first('wageInfo.wageminimum') }}</p>
                                                </div>
                                         </div>
                                         <div class="vx-col  w-full md:w-1/3" >
                                             <div class="form_group">
                                                   <label class="form_label">Maximum Wage<em >*</em></label>
                                                   <vs-input @input="maxWaseError=''"  oninput="petitionDetails.wageOfferInfo.maxWage = petitionDetails.wageOfferInfo.maxWage.replace(/[^0-9 .]/g, '').replace(/(\..*)\./g, '$1'); petitionDetails.wageOfferInfo.maxWage = petitionDetails.wageOfferInfo.maxWage.replace(/ /g,'');"  name="MaximumWage" v-model="petitionDetails.wageOfferInfo.maxWage" v-validate="'required|numeric' "  :maxLength="9" class="w-full" :data-vv-as="'Maximum Wage'"  />
                                                   
                                                   <p v-if="maxWaseError" class="text-danger text-sm">{{ maxWaseError }}</p>
                                                   <p v-else-if="errors.has('wageInfo.MaximumWage')" class="text-danger text-sm">{{ errors.first('wageInfo.MaximumWage') }}</p>
                                                  
                                                   
                                                </div>
                                         </div>
                                         <div class="vx-col  w-full md:w-1/3" >
                                             <div class="form_group">
                                                   <label class="form_label">Pay Frequency<em >*</em></label>
                                                   <div class="con-select w-full">
                                                    <multiselect  
                                                        name="PayFrequency"
                                                        :multiple="false" 
                                                        v-validate="'required'"
                                                        v-model="petitionDetails.wageOfferInfo.payFrequency" 
                                                        :close-on-select="true"
                                                        data-vv-as="Pay Frequency" 
                                                        placeholder="Pay Frequency"  
                                                        :options="payFrequencyList"
                                                        :searchable="true" 
                                                        :allow-empty="false" 
                                                        >
                                                    </multiselect>
                                                   </div>
                                                   <p v-show="errors.has('wageInfo.PayFrequency')" class="text-danger text-sm">{{ errors.first('wageInfo.PayFrequency') }}</p>
                                                </div>
                                         </div>
                                           
                                            <!-- <selectField :listContainsId="false" :wrapclass="'md:w-1/3'" :required="true"   :formscope="'wageInfo'"  cid="infopayFrequency"  :optionslist="payFrequencyList" v-model="petitionDetails.wageOfferInfo.payFrequency"  fieldName="infopayFrequency" label="Pay Frequency" placeHolder="Pay Frequency"   />   -->
                                            

                                        </div>
                                            <div @click="jdUpdateStatusError=''" class="text-danger text-sm formerrors" v-if="jdUpdateStatusError!=''">
                                            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ jdUpdateStatusError }}</vs-alert>
                                            </div>  
                                    </div>
                                    </VuePerfectScrollbar>
                                </div>
                                
                                
                                </form>
                            </div>
                            <div class="popup-footer">
                                <span class="loader" v-if="jdUpdating"><img src="@/assets/images/main/loader.gif"></span>
                                <vs-button color="dark" class="cancel" type="filled" @click="hideMe()">Cancel</vs-button>
                                <vs-button color="dark" class="cancel" type="filled" :disabled="jdUpdating" @click="tabChanged('jobDetails', true)" >Back</vs-button>
                                <vs-button color="success" :disabled="jdUpdating" @click="submitForm()" class="save" type="filled">Submit</vs-button>
                              
                               
                                <!-----
                                     <vs-button color="success" :disabled="jdUpdating" @click="submitForm()" class="save" type="filled">Submit</vs-button>
                                --->
                            </div>
                        </div>
                        

                </div>

            </div>
                

            <vs-popup class="holamundo main-popup" title="Comments" :active.sync="jobSuggssionComments">
                <div class="form-container mt-6">
                <div class="vx-row">

                <div class="vx-col w-full">
                <!-- <vs-textarea v-model="comments" label="Comments…" class="w-full" /> -->
                <ckeditor  v-model="comments" label="Comments…" class="w-full"  :editor="editor" :config="editorConfig"></ckeditor>

                </div>
                </div>
                </div>
                <div class="popup-footer">
                    <span class="loader" v-if="jdUpdating"><img src="@/assets/images/main/loader.gif"></span>
                    <vs-button color="dark" class="cancel" type="filled" :disabled="jdUpdating" @click="tabChanged('wageInfo')" >Back</vs-button>
                    <vs-button color="success" :disabled="jdUpdating" @click="submitForm()" class="save" type="filled">Submit</vs-button>

                </div>
            </vs-popup>
           </div> 
   
</template>
<script>
import Vue from "vue";
import immiswitchyesno from "@/views/forms/fields/switchyesno.vue";
import immiyesorno from "@/views/forms/fields/yesorno.vue";
import addressFields from "@/views/forms/fields/address.vue";
import immitextarea from "@/views/forms/fields/simpletextarea.vue";
import immitextfield from "@/views/forms/fields/simpleTextField.vue";
 import immiInput from "@/views/forms/fields/simpleinput.vue";
 import selectField from "@/views/forms/fields/simpleselect.vue";
 import datepickerField from "@/views/forms/fields/datepicker.vue";
 import VuePerfectScrollbar from "vue-perfect-scrollbar";
 import redioButtons from "@/views/forms/fields/redioButtons.vue";
import * as _ from "lodash";
import moment from "moment";
import { XIcon } from 'vue-feather-icons'
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import JQuery from "jquery";

export default {
    computed: {
        //getJobStartDate petitionDetails.applicationInfo.jobEndOn
        getJobStartDate(){
            if(this.petitionDetails['jobDetails'].applicationInfo.jobEndOn){
                try {
                    return moment(this.petitionDetails['jobDetails'].applicationInfo.jobEndOn).format("YYYY-MM-DD");
                }catch(err){
                    return new Date(); 
                }

            }else{
                return new Date();
            }

        }
        
    },
    provide() {
      return {
         parentValidator: this.$validator,
      };
  },
  created() {
    //this.$validator = this.parentValidator;
   },
    components: {
        addressFields,
        immitextarea,
        immitextfield,
        immiInput,
        selectField,
        datepickerField,
        XIcon,
       immiswitchyesno,
       immiyesorno,
       redioButtons,
       VuePerfectScrollbar
    },

    data() {
     return {
        moreJobDetails: {
            jobId: "",
            noOfPositions: "",
            salary: "",
            jobType: "",
            jobShift: "",
            hoursPerWeek: '',
            applicationInfo: {
                applyByMail: "",
                jobStartsOn: null,
                jobEndOn: null
            }
        },
        wageInfo: {
            trackingNumber: "",
            preferredSocCode: '',
            preferredWageRate: "",
            payFrequency: "", 
            wageSource: "", 
            wageSourceOtherDesc: "",
            determinationDate: null,
            expirationDate: null
        },
        wageOfferInfo: {
            minWage: "",
            maxWage: "",
            payFrequency: "" 
        },
        classificationList:['EB2','EB3','EB3S'],
        maxWaseError:'',
        completedtabs:[],
        editor: ClassicEditor,
        editorConfig: {
         toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
        },
        settings: {
   
          wheelSpeed: 0.6,
        },
        tempAddresses: {
                aptType:'',
                companyName: "",
                line1: "",
                line2: "",
                countryId: "",
                stateId: "",
                locationId: "",
                zipcode: "",
                countryDetails: null,
                stateDetails: null,
                locationDetails: null,
                workLocation:true
            },
        comments:'',
        jobSuggssionComments:false,
        valiedjobDetailsForm:false,
        valiedwageInfoFrorm:false,
        valiedjobOpptInfoForm:false,


        newSkill:'',
        addSkill:true,
        countries: [],
        permjobDetailsPopUp:true,
        activeTab:'jobDetails',
       
        educationTypes:[],
        masterSocList:[],
        wageSourceList:['OES', 'CBA', 'Employer Conducted', 'DBA', 'SCA', 'Other'],
        payFrequencyList:[ 'Bi-Weekly',"Hour","Week","Month","Year" ],
        jdUpdateStatusError:'',
        jdUpdating:false,
        errorMessage:''

     }
    },
    methods: {
        minimumWageMethod(){
            let maxWagee = null
            let minWagee = null
            
            this.maxWaseError = '';
            if(this.petitionDetails.wageOfferInfo.maxWage){
                maxWagee = this.petitionDetails.wageOfferInfo.maxWage
            }
            if(this.petitionDetails.wageOfferInfo.minWage){
                minWagee = this.petitionDetails.wageOfferInfo.minWage
            }

            if(parseInt(minWagee) > parseInt(maxWagee)){
               
                this.petitionDetails.wageOfferInfo.maxWage = null;
                this.maxWaseError ='Maximum Wage is must be greater than or equal to Minimum Wage';
            }
        },
        maximumWageMethod(){
            let maxWagee = null
            let minWagee = null
            if(this.petitionDetails.wageOfferInfo.minWage){
                minWagee = this.petitionDetails.wageOfferInfo.minWage
            }
            if(this.petitionDetails.wageOfferInfo.maxWage){
                maxWagee = this.petitionDetails.wageOfferInfo.maxWage
            }
            if(parseInt(minWagee) > parseInt(maxWagee)){
                this.petitionDetails.wageOfferInfo.minWage = null
            }
        },
        updateHoursWeek(val){
            // if(val ){
            //     let item = parseInt(val)
            //     if(item > 168){
            //         this.$refs['updateHoursPerWeek'].updateErrorMsg(true, 'Hours should not be greater than 168')
            //         this.errorMessage = 'Hours should not be greater than 168';
            //         //this.petitionDetails['moreJobDetails'].hoursPerWeek = null;
            //     }else{
            //         this.$refs['updateHoursPerWeek'].updateErrorMsg(false, '')
            //         this.errorMessage = ''
            //     }
            // }
        },
        updateJobStartDate(val){
            if(val){
                let startDate = moment(val);
                if(this.petitionDetails['moreJobDetails'].applicationInfo.jobEndOn){
                    let endDate= moment(this.petitionDetails['moreJobDetails'].applicationInfo.jobEndOn)
                    if(startDate.isAfter(endDate , 'day')){
                        this.petitionDetails['moreJobDetails'].applicationInfo.jobEndOn = null
                    }
                }
            }else{
                this.petitionDetails['moreJobDetails'].applicationInfo.jobEndOn = null
            }
        },
        updateDeterminationDate(val){
            if(val){
                let startDate = moment(val);
                if(this.petitionDetails['wageInfo'].expirationDate){
                    let endDate= moment(this.petitionDetails['wageInfo'].expirationDate)
                    if(startDate.isAfter(endDate , 'day')){
                        this.petitionDetails['wageInfo'].expirationDate = null;
                    }
                }
            }else{
                this.petitionDetails['wageInfo'].expirationDate = null;
            }
        },
        setWorkLocation(indexx){
            setTimeout(()=>{
                _.map(this.petitionDetails['jobOpportunityInfo']['workAddresses'] , (item ,ind)=>{
                if(ind != indexx){
                    item.workLocation =false;
                }
                })
            });
        },
        getComments(){
            this.$validator.validateAll(this.activeTab).then((result) => {
                this.jobSuggssionComments = true;
            })

        },

        tabChanged(tab='jobDetails',back = false){
            let currentTab = _.cloneDeep(this.activeTab);
            this.maxWaseError='';

           // maximumWageMethod(); minimumWageMethod();tabChanged('wageInfo')
           if(tab =='wageInfo'){
            
            this.minimumWageMethod();
            //this.maximumWageMethod(); 
            

           }
           
            this.$validator.validateAll(this.activeTab).then((result) => {
                if((result && this.errorMessage == '') || (back && this.errorMessage == '') || this.completedtabs.indexOf(tab) > -1 ){
                    
                    if(result)  this.completedtabs.push(tab)
                   this.activeTab = tab;
                  
                }else{
                    const $ = JQuery;

                    if($('.text-danger:visible')){
                        $('.withTabButtons').scrollTop($('.text-danger:visible').first().parent().offset().top-50);
                     }
      
                }

        })
            // if(!this.jdUpdating){
            //     this.activeTab = tab;
            // }
            this.jdUpdateStatusError ='';
            
        },
        
        submitForm() {
        this.jdUpdateStatusError='';
        this.minimumWageMethod();
        this.$validator.validateAll(this.activeTab).then((result) => {
           if(result && !this.filesAreuploading && this.maxWaseError ==''){
            this.jdUpdating =true;
            let path ="/perm/update-job-description-for-efile";
            let data = {
                "petitionId": "",
                "userName": "",
                //"action": "", // 'CREATE_JOB_DESC','REQUEST_JOB_DESC_REVIEW', 'JOB_DESC_SUGGESSION', 'APPROVE_JOB_DESC', 'FINALIZE_JOB_DESC'
                //"jobDescSuggessionType": "comments", //job_desc_update // Required for 'JOB_DESC_SUGGESSION'
                //"comment": "", // Requied for jobDescSuggessionType = 'comments' 
                "typeName": "",
                "subTypeName": "",
                //jobDetails:{},
                wageInfo:{},
                wageOfferInfo:{},
                moreJobDetails:{},
            }
            // if(this.ACTIVITYCODE=='JOB_DESC_SUGGESSION'){
            //     data['jobDescSuggessionType'] = 'job_desc_update';
            // }
            data['petitionId'] = this.checkProperty( this.petitionDetails ,'_id');
            data['userName'] = this.checkProperty( this.getUserData , 'loginRoleName');
            // data['action']  = this.ACTIVITYCODE; 
            //data['action']  = 'JOB_DESC_SUGGESSION'; 
            data['typeName'] = this.checkProperty( this.petitionDetails , 'typeDetails','name');
            data['subTypeName'] = this.checkProperty( this.petitionDetails ,'subTypeDetails','name');              
            //data['jobDetails'] = this.checkProperty( this.petitionDetails , 'jobDetails');
            data['wageInfo'] = this.checkProperty( this.petitionDetails , 'wageInfo');
            data['wageOfferInfo'] = this.checkProperty( this.petitionDetails , 'wageOfferInfo');
            data['moreJobDetails'] = this.checkProperty( this.petitionDetails , 'moreJobDetails');  
           
            if(this.loadedFromPwdLibrary){
                path = "/pwd/update-job-description-for-efile";
                data['pwdId'] = this.checkProperty( this.petitionDetails ,'_id');

                if(this.checkProperty( this.petitionDetails ,'petitionList' ,'length')==1 && this.petitionDetails['completedActivities'].indexOf('PWD_CERTIFID')<=-1 ){
                    path ="/perm/update-job-description-for-efile";
                    data["typeName"] ="GC-Employment";
                    data["subTypeName"] ="GC-Employment";
                    data['petitionId'] = this.petitionDetails['petitionList'][0]['_id'];
                }
            }
            this.$store.dispatch('commonAction' ,{ "data":data ,'path':path})
            .then((res)=>{
              this.showToster({message:res['message'],isError:false });
              this.hideMe();
              this.$emit("updatepetition");
              window.open("https://flag.dol.gov/auth/auth/login-gov/login/loa-1");
            })
            .catch((error)=>{
              this.jdUpdateStatusError =error;
              this.jdUpdating =false;
             })
           }
            else{
                const $ = JQuery;
                if($('.text-danger:visible')){
                    $('.withTabButtons').scrollTop($('.text-danger:visible').first().parent().offset().top-50);
                }
            }
        });
       },
        addNewSkill(){
            if(this.newSkill && this.newSkill.trim() !=''){
                let skil = this.newSkill.trim();
                if(this.petitionDetails['jobDetails']['skills'].indexOf(skil) <=-1){
                    this.petitionDetails['jobDetails']['skills'].push(skil);
                }
                
                this.newSkill ='';
                this.addSkill =false;
            }
           

        },
        removeSkill(index){
            this.petitionDetails['jobDetails']['skills'].splice(index ,1)

        },

        updateisForiegnLangRequired(){
            if(this.checkProperty(this.petitionDetails ,'jobOpportunityInfo','isForiegnLangRequired') !='Yes'){
               
               this.petitionDetails['jobOpportunityInfo']['skills'] =[];
              
               
           }

        },
        updateisExpInAltOccuAccept(){
            
            if(this.checkProperty(this.petitionDetails ,'jobOpportunityInfo','isExpInAltOccuAccept') !='Yes'){
               
                this.petitionDetails['jobOpportunityInfo']['noOfExpMonthsInAltOccu'] =null;
                this.petitionDetails['jobOpportunityInfo']['jobTitleOfAcceptAltOccu'] ='';
                
            }

        },
        updateisAltCombOfEduAndExpAccept(){
            
            if(this.checkProperty(this.petitionDetails ,'jobOpportunityInfo','isAltCombOfEduAndExpAccept') !='Yes'){
               
                this.petitionDetails['jobOpportunityInfo']['altLevelOfEdu'] =null;
                this.petitionDetails['jobOpportunityInfo']['altAcceptExpInYears'] ='';
                
            }

        },
        updateisAltFieldOfStudyAccept(){
            
            if(this.checkProperty(this.petitionDetails ,'jobOpportunityInfo','isAltFieldOfStudyAccept') !='Yes'){
               
                this.petitionDetails['jobOpportunityInfo']['altMajorFieldOfStudy'] ='';
            }

        },
        
        updateisExpRequired(){
            
            if(this.checkProperty(this.petitionDetails ,'jobOpportunityInfo','isExpRequired') !='Yes'){
               
                this.petitionDetails['jobOpportunityInfo']['noOfExpMonths'] =null;
            }

        },
        updateIsTrainigRequired(){
            
            if(this.checkProperty(this.petitionDetails ,'jobOpportunityInfo','isTrainigRequired') !='Yes'){
               
                this.petitionDetails['jobOpportunityInfo']['noOfTraningMonths'] =null;
                this.petitionDetails['jobOpportunityInfo']['fieldOfTraining'] ='';
                
            }

        },
        addAddress(){

            let newAddress = {
                "companyName": "",
                "workLocation": false,
                line1: "",
                line2: "",
                zipcode: "",
                countryId: "231",
                stateId: "",
                locationId: "",
                "countryDetails": { "_id": "626a8f03a972fa4d60681140", "id": 231, "name": "United States", "phoneCode": 1, "order": 1, "currencySymbol": "$", "currencyCode": "USD", "zipcodeLength": 5, "sortName": "united states" },
                stateDetails: null,
                locationDetails: null,
                aptType:''
            };
            this.petitionDetails['jobOpportunityInfo']['workAddresses'].push(newAddress);
            //this.$validator.reset();

        },
        removeAddress(index){
            this.petitionDetails['jobOpportunityInfo']['workAddresses'].splice(index ,1);

        },
        hideMe(){
            this.$validator.reset();
            this.permjobDetailsPopUp =false;
            this.$emit('hideMe');

        },
        getMasterSocList(){

        let query = {};
        query["page"] = 1;
        query["perpage"] = 10000;
        query["matcher"] = { 
            // "getInactiveListAlso": true
             };
        query["category"] = "soc_codes";
       

        this.$store
        .dispatch("getMasterData", query)
        .then((response) => {
            this.masterSocList = response.list;
            if(this.checkProperty(this.petitionDetails ,'wageInfo' ,'socCode' )){
                this.petitionDetails['wageInfo']['socCodeDetails'] = _.find(this.masterSocList, {"id": this.petitionDetails['wageInfo']['socCode']});
            }


        //alert(this.perpage);
        })
        .catch(() => {
        this.masterSocList = [];

        });

       },
       
        updateMainDegree(item){ 

            if(_.has( item ,'id')){
                this.petitionDetails['jobDetails']['minDegree'] = item['id'];
            }
        },
      
        jobOppupdateMainDegree(item){
            
            if(_.has( item ,'id')){
                this.petitionDetails['jobOpportunityInfo']['minDegree'] = item['id'];
            }
        },
        updatesocCode(item){ 

            if(_.has( item ,'id')){
            this.petitionDetails['wageInfo']['socCode'] = item['id'];
            }
        },

        //petitionDetails.jobOpportunityInfo.altLevelOfEdu
        //petitionDetails['jobOpportunityInfo'].minDegreeDetails
        getEducationList(){
            this.$store
                .dispatch("getmasterdata", "education_types")
                .then((response) => {
                    this.educationTypes = response;
                    /*
                    petitionDetails['jobDetails'].minDegreeDetails =this.petitionDetails['jobDetails']['minDegree']
                    petitionDetails.jobOpportunityInfo.altLevelOfEduDetails ===== petitionDetails.jobOpportunityInfo.altLevelOfEdu
                    petitionDetails['jobOpportunityInfo'].minDegreeDetails === this.petitionDetails['jobOpportunityInfo']['minDegree']
                    */
                  
                    

                   if(this.checkProperty(this.petitionDetails ,'jobDetails' ,'minDegree' )){
                     this.petitionDetails['jobDetails'].minDegreeDetails = _.find(this.educationTypes ,{'id':this.petitionDetails['jobDetails']['minDegree']});
                   }

                   if(this.checkProperty(this.petitionDetails ,'jobOpportunityInfo' ,'minDegree' )){
                     this.petitionDetails.jobOpportunityInfo.minDegreeDetails = _.find(this.educationTypes ,{'id':this.petitionDetails['jobOpportunityInfo']['minDegree']});
                   }

                   if(this.checkProperty(this.petitionDetails ,'jobOpportunityInfo' ,'altLevelOfEdu' )){
                     this.petitionDetails.jobOpportunityInfo.altLevelOfEduDetails = _.find(this.educationTypes ,{'id':this.petitionDetails['jobOpportunityInfo']['altLevelOfEdu']});
                   }

                });

        },

    },
    props: {
        ACTIVITYCODE: {
            type: String,
            default: null,
        },
        value: null,
        formscope:{
            type:String,
            default:''

        },

        petitionDetails: {
            type: Object,
             default: null,
        },
        loadedFromPwdLibrary:{
      type: Boolean,
      default: false,

    },

    },
    mounted(){
        
        if(!_.has(this.petitionDetails,'moreJobDetails')){
            this.petitionDetails = Object.assign(this.petitionDetails,{'moreJobDetails':this.moreJobDetails})
        }
        if(!_.has(this.petitionDetails,'wageInfo')){
            this.petitionDetails = Object.assign(this.petitionDetails,{'wageInfo':this.wageInfo})
        }
        if(!_.has(this.petitionDetails,'wageOfferInfo')){
            this.petitionDetails = Object.assign(this.petitionDetails,{'wageOfferInfo':this.wageOfferInfo})
        }
        this.getMasterSocList()
        this.activeTab = 'jobDetails';
        this.$store
            .dispatch("getmasterdata", "education_types")
            .then((response) => {
                this.educationTypes = response;
                // this.upDatehighestDegree();
            });
        this.$store.dispatch("getcountries").then(response => {
        this.countries = response;
        });


    }

}

</script>