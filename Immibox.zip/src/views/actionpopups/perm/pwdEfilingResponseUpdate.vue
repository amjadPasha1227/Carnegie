<template>
   
      <modal
            name="updateUscisStatus"
            classes="v-modal-sec"
            :min-width="200"
            :min-height="200"
            :scrollable="true"
            :reset="true"
            width="650px"
            height="auto"
          >
          <div class="v-modal profile_details_modal error-modal-space pwd_popup" >
            <div class="popup-header fromDetailsPage" :ACTIVITYCODE="ACTIVITYCODE">
              
              <h2 class="popup-title" v-if="ACTIVITYCODE=='UPDATE_PWD_RESPONSE'">Update PWD Response</h2>
              <h2 class="popup-title" v-if="ACTIVITYCODE=='EFILE_PWD'">Update PWD Tracking Info</h2>
              <h2 class="popup-title" v-if="ACTIVITYCODE=='EFILE_PWD_DOL'">E-File PWD</h2>
              <span @click="showPopup=false;$modal.hide('updateUscisStatus');"> 
                <em class="material-icons">close</em>
              </span>
            </div>
            <div class="form-container" v-if="ACTIVITYCODE=='EFILE_PWD_DOL'">
              

              <div class="modal-confirm-msg">
                    <p>Using our Browser Extension PERM details can be filled automatically
                     </p>
                    <div class="popup-footer pl-0 pr-0">
                  <a @click="showPopup=false;$modal.hide('updateUscisStatus');"  href="https://flag.dol.gov/auth/auth/login-gov/login/loa-1" target="_blank"> <vs-button color="success" class="save" type="filled">Click here to proceed</vs-button>
                  </a></div>
               </div>
            </div>
           
            <form v-if="ACTIVITYCODE!='EFILE_PWD_DOL'" @submit.prevent data-vv-scope="uscisstatus" class="trackingform">
                <div class="form-container pb-0" @click="pewResponceUpdateStatusError='';showDocumentsError=false">
                  <template v-if="ACTIVITYCODE=='UPDATE_PWD_RESPONSE' || ACTIVITYCODE=='EFILE_PWD'">
                        
                  <div class="vx-row" v-if="ACTIVITYCODE=='UPDATE_PWD_RESPONSE'">

                    <div class="vx-col  w-full" v-if="ACTIVITYCODE =='UPDATE_PWD_RESPONSE'" >
                      <div class="form_group">
                        <label class="form_label">PWD Action<em>*</em></label>
                      <div class="con-select w-full DT_multiselect">                  
                        <multiselect
                          name="casestatus"
                          v-validate="'required'"
                          v-model="actionData.pwdAction"
                          :show-labels="false"
                          :data-vv-as="'PWD Action'"
                          track-by="id"
                          label="name"
                           @input="pwdActionchanged"
                          placeholder="Choose Action"
                          :options="pwdActionsList"
                          :searchable="true"
                          :allow-empty="false"
                        ></multiselect>
                      </div>
                      <span
                        class="text-danger text-sm"
                        v-show="errors.has('uscisstatus.casestatus')"
                      >{{ errors.first("uscisstatus.casestatus") }}</span>
                      </div>
                    </div>
                    <template   @click="documentModel=[];pwdDocFormatError=''"  v-if="ACTIVITYCODE =='UPDATE_PWD_RESPONSE'">

                      

                      <div div class="vx-col w-full" >
                        <div class="form_group">
                          <label class="form_label d-flex" style="text-transform: capitalize">
                            <template v-if="[ 'EFILE_PWD'].indexOf(ACTIVITYCODE)>-1" >PWD Acknowledgment <em>*</em></template>
                            <template v-if="[ 'UPDATE_PWD_RESPONSE'].indexOf(ACTIVITYCODE)>-1" >
                            
                              {{checkProperty(actionData ,'pwdAction','id')=='PWD_CERTIFID'?'Certified PWD':'Documents'}}
                              
                            
                            </template>
                            <em v-if="[ 'EFILE_PWD','UPDATE_PWD_RESPONSE'].indexOf(ACTIVITYCODE)>-1">{{checkProperty(actionData ,'pwdAction','id')=='PWD_CERTIFID'?'*':''}}</em>
                            <div class="IB_tooltip" v-if="checkProperty(actionData ,'pwdAction','id')!='PWD_RFI_RECEIVED'"  >
                              <span ><info-icon size="1.5x" class="custom-class"></info-icon ></span>
                              <div class="tooltip_cnt tooltip_cnt_md"> 
                                <p v-if="[ 'EFILE_PWD'].indexOf(ACTIVITYCODE)>-1">  Make sure to upload the acknowledgment of PWD Filed.</p>
                                <p v-if="[ 'UPDATE_PWD_RESPONSE'].indexOf(ACTIVITYCODE)>-1"> 
                                  Make sure to upload Certified PWD.</p>
                              </div>
                            </div>
                          </label>
                        <div class="uploadsec_wrap upload_uscis">
                          <div class="w-full">
                              <div class="relative">
                                <file-upload
                                  v-model="documentModel"
                                  class="file-upload-input mb-0"
                                  style="height:50px;"
                                  name="trackingdoc"
                                  :multiple="true"
                                
                                  data-vv-as="Documents"
                                  :accept="pdfDocEntity"
                                  @input="uploadDocuments()"
                                >
                                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                                  Upload
                                </file-upload>
                                <span class="loader" v-if="filesAreuploading"><img src="@/assets/images/main/loader.gif"></span>
                                <span v-if="showDocumentsError && actionData['documents'].length<=0 "  class="text-danger text-sm"  ><em>*</em> 
                                  <template v-if="[ 'EFILE_PWD'].indexOf(ACTIVITYCODE)>-1" >PWD Acknowledgment is required</template>
                                  <template v-if="[ 'UPDATE_PWD_RESPONSE'].indexOf(ACTIVITYCODE)>-1" >Certified PWD is required</template>
                                  </span>

                              </div>
                            <span class="file-type">(File Type: PDF)</span>
                            
                            <span @click="pwdDocFormatError=''"  v-if="pwdDocFormatError"  class="text-danger text-sm"  >{{pwdDocFormatError}}</span>
                            
                            <!-- <VuePerfectScrollbar class="scrollbardoc"> -->
                                
                                  <div class="uploded-files_wrap mb-5" v-if="actionData['documents'].length >0 ">
                                      <template v-for="(fil, fileindex) in actionData['documents']">
                                        <div class="w-full"  :key="fileindex" >
                                            <div class="uploded-files">
                                                <vx-input-group class="form-input-group">
                                                  <vs-input v-on:keyup="fileNameChenged(fil)"  v-validate="'required'" class="w-full" :name="'fName'+fileindex" v-model="actionData['documents'][fileindex]['name']" data-vv-as="File Name" />
                                                    <span class="text-danger text-sm" v-show="errors.has('uscisstatus.fName'+fileindex)">{{ errors.first('uscisstatus.fName'+fileindex) }}</span>

                                                    
                                                </vx-input-group>

                                                <div class="delete" style="z-index:999" @click="pwdDocFormatError='';remove(fileindex , actionData['documents']) ;resetPrefedKyes()">
                                                    <img src="@/assets/images/main/delete-row-img.svg" />
                                                </div>
                                            </div>
                                        </div>
                                    </template>
                                  </div>
                              <!-- </VuePerfectScrollbar> -->
                            </div>
                        </div>
                        </div>
                      </div>
                      <div  class="vx-col w-full mt-2" v-if="checkProperty(actionData ,'pwdAction','id')==='PWD_CERTIFID'">
                        <div class="form_group">
                          <label class="form_label">Document Type<em>*</em></label>
                          <div class="con-select w-full DT_multiselect">  
                          <!-- {{documentType}}      ['EFILE_PWD'].indexOf(ACTIVITYCODE)   actionData.documentType        -->
                            <multiselect
                              :name="'documentType'"
                              v-validate="'required'"
                              v-model="actionData.documentType"
                              :show-labels="false"
                              :disabled="['EFILE_PWD'].indexOf(ACTIVITYCODE)>-1"
                              data-vv-as="Document Type"
                              placeholder="Document Type"
                              :options="documentTypes"
                              :searchable="true"
                              :allow-empty="false"
                            >
                            </multiselect>
                          
                            <span  class="text-danger text-sm"  v-show="errors.has('uscisstatus.documentType')"  >{{ errors.first('uscisstatus.documentType') }}</span>
                          </div>
                        </div>
                      </div>




                    </template>

                   
                                       
                    <div class="vs-col w-full"  >
                      
                      <!-- PWD_RFI_RECEIVED
                        {'name':'Response Submitted to RFI' ,'id':'PWD_RFI_RECEIVED'},
                           {'name':'Certify PWD' ,'id':'PWD_CERTIFID '},
                          actionData:{
                          "petitionId": "",
                          "action": 'UPDATE_PWD_RESPONSE',//"EFILE_PWD", // 
                          "typeName": "t",
                          "subTypeName": "",
                          /**** Required for UPDATE_PWD_RESPONSE ****/
                          "issuedDate": null,
                          "receivedDate": null,
                          "dueDate": null,
                          "description": "Some Description",
                          "documents": [],
                          "documentType": "Original",
                          },
                          --->
                       
                       
                      <div class="vx-row">
                        

                         <template v-if="checkProperty(actionData ,'pwdAction','id')=='PWD_CERTIFID'">
                        <immiInput  :wrapclass="'md:w-1/2'" :display="true" cid="jobTitle" :formscope="'uscisstatus'" v-model="actionData.jobTitle" :required="true" fieldName="jobTitle" label=" Job Title" placeHolder=" Job Title"  />
                        <immiInput :onlyNumbers="true" :wrapclass="'md:w-1/2'" :display="true" :cid="'wageRate'" :formscope="'uscisstatus'" v-model="actionData.wageRate" :required="true" fieldName="wageRate" label="Wage Rate per Year" placeHolder="Wage Rate"  />
                        <selectField :wrapclass="'md:w-1/2'" :required="true"  cid="socCode"  :formscope="'uscisstatus'" :optionslist="masterSocList" v-model="actionData.socCodeDetails" @input="updatesocCode"   fieldName="socCod" label="SOC Code " placeHolder="SOC Code "   />  
                      </template>                         
                      <!-- this.prefilledKyes.includes("issuedDate") && this.actionData.issuedDate && pwdStatus =='Certified') 
           -->
                           <datepickerField 
                             v-if="checkProperty(actionData ,'pwdAction','id')=='PWD_CERTIFID'"
                             :isDisabled="(prefilledKyes.indexOf('issuedDate')>-1 && actionData.issuedDate !==null && PWDCerttified =='Certified')"
                              wrapclass="md:w-1/2"
                              @input="updateissuedDate($event)"
                              :display="true"  
                              v-model="actionData.issuedDate" 
                              :formscope="'uscisstatus'"  
                              fieldName="issuedDate" 
                              :dateEnableTo="new Date()" 
                              label="Receipt Date" 
                              :validationRequired="true" 
                                />
                        <datepickerField 
                            wrapclass="md:w-1/2" 
                            :isDisabled="(prefilledKyes.indexOf('receivedDate')>-1 && actionData.receivedDate !==null && PWDCerttified =='Certified')"
                            :display="true"  
                            v-model="actionData.receivedDate" 
                            :formscope="'uscisstatus'"  
                            fieldName="receivedDate"  
                            :dateEnableTo="new Date()" 
                            label="Received Date" 
                            :validationRequired="true"
                           />    
                        <!-- <div class="vs-col w-1/2">
                          <div class="form_group">
                          <label class="form_label">Issued Date<em>*</em></label>
                          <div class="vs-component">
                          <datepicker  :typeable="true"
                            icon-pack="IntakePortal"
                            icon-after
                            name="issuedDate"
                            v-model="actionData.issuedDate"
                            v-validate="'required'"
                            icon="IP-calendar-1"
                            data-vv-as="Issued Date"
                            placeholder="DD/MM/YYYY"
                            :open-date="new Date(openDate)"
                            :disabled-dates="{from: new Date(startEligibleDate)}"
                          ></datepicker>
                          </div>
                          <span
                            class="text-danger text-sm"
                            v-show="errors.has('uscisstatus.issuedDate')"
                          >{{ errors.first("uscisstatus.issuedDate") }}</span>
                          </div>
                        </div> -->


                        <!-- <div class="vs-col w-1/2">
                          <div class="form_group">
                          <label class="form_label">Due Date<em>*</em></label>
                          <div class="vs-component">
                          <datepicker  :typeable="true"
                            icon-pack="IntakePortal"
                            icon-after
                            name="dueDate"
                            v-model="actionData.dueDate"
                            v-validate="'required'"
                            icon="IP-calendar-1"
                            data-vv-as=" Due Date"
                            placeholder="DD/MM/YYYY"
                            :open-date="new Date(openDate)"
                            :disabled-dates="{from: new Date(startEligibleDate)}"
                          ></datepicker>
                          </div>
                          <span
                            class="text-danger text-sm"
                            v-show="errors.has('uscisstatus.dueDate')"
                          >{{ errors.first("uscisstatus.dueDate") }}</span>
                          </div>
                        </div> -->
                        <datepickerField 
                        :isDisabled="(!actionData.issuedDate && checkProperty(actionData ,'pwdAction','id')==='PWD_CERTIFID') || (prefilledKyes.indexOf('dueDate')>-1 && actionData.dueDate !==null && PWDCerttified =='Certified')"
                        wrapclass="md:w-1/2" 
                        :display="true"  
                        v-model="actionData.dueDate" 
                        :formscope="'uscisstatus'"  
                        fieldName="dueDate" 
                        :dateEnableFrom="actionData.issuedDate" 
                        :label="checkProperty(actionData ,'pwdAction','id')==='PWD_RFI_RECEIVED'?'Due Date':'Expiration Date'" 
                        :validationRequired="true"   />
                      </div>
                    </div>
                    
                   
                    <div class="vx-col w-full">
                    <div class="form_group">
                      <label class="form_label">Comments<em>*</em></label>
                      <!-- <vs-textarea
                        data-vv-as="Comments"
                        v-validate="'required'"
                        v-model="actionData.description"
                        name="usciscomments"
                        class="w-full"
                      /> -->
                      <ckeditor  data-vv-as="Comments"
                        v-validate="'required'"
                        v-model="actionData.description"
                        name="usciscomments"
                        class="w-full" :editor="editor" :config="editorConfig"></ckeditor>

                      <span
                        class="text-danger text-sm"
                        v-show="errors.has('uscisstatus.usciscomments')"
                      ><em>*</em> Comments are required</span>
                    </div>
                    </div>
                  
                  <!----
                    <immitextarea  wrapclass="w-full"  :formscope="'uscisstatus'"  v-model="actionData.description" :required="true" fieldName="wageSourceOtherDesc" label="Comments" placeHolder="Comments"></immitextarea>
                -->

                    
                    
                  </div>
                  <template  v-if="ACTIVITYCODE=='EFILE_PWD'">
                    <div class="vx-row">
                      
                      <immiInput :maxCharacters="25" :wrapclass="'md:w-full'" :display="true" :cid="'trackingNumber'" :formscope="'uscisstatus'" v-model="actionData.trackingNumber" :required="true" fieldName="trackingNumber" label="Tracking Number" placeHolder="Tracking Number"  />
                    </div>
                  </template>


                  <div  class="vx-row" @click="documentModel=[];pwdDocFormatError=''"  v-if="ACTIVITYCODE !='UPDATE_PWD_RESPONSE'">

                    <div  class="vx-col w-full mt-2" v-if="checkProperty(actionData ,'pwdAction','id')==='PWD_CERTIFID'">
                      <div class="form_group">
                        <label class="form_label">Document Type<em>*</em></label>
                        <div class="con-select w-full DT_multiselect">  
                        <!-- {{documentType}}      ['EFILE_PWD'].indexOf(ACTIVITYCODE)   actionData.documentType        -->
                          <multiselect
                            :name="'documentType'"
                            v-validate="'required'"
                            v-model="actionData.documentType"
                            :show-labels="false"
                            :disabled="['EFILE_PWD'].indexOf(ACTIVITYCODE)>-1"
                            data-vv-as="Document Type"
                            placeholder="Document Type"
                            :options="documentTypes"
                            :searchable="true"
                            :allow-empty="false"
                          >
                          </multiselect>
                        
                          <span  class="text-danger text-sm"  v-show="errors.has('uscisstatus.documentType')"  >{{ errors.first('uscisstatus.documentType') }}</span>
                        </div>
                      </div>
                    </div>
                    
                    <div div class="vx-col w-full" @click="pwdDocFormatError=''" >
                      <div class="form_group">
                        <label class="form_label d-flex" style="text-transform: capitalize">
                           <template v-if="[ 'EFILE_PWD'].indexOf(ACTIVITYCODE)>-1" >PWD Acknowledgment <em>*</em></template>
                           <template v-if="[ 'UPDATE_PWD_RESPONSE'].indexOf(ACTIVITYCODE)>-1" >
                          
                            {{checkProperty(actionData ,'pwdAction','id')=='PWD_CERTIFID'?'Certified PWD':'Documents'}}
                            
                          
                          </template>
                          <em v-if="[ 'EFILE_PWD','UPDATE_PWD_RESPONSE'].indexOf(ACTIVITYCODE)>-1">{{checkProperty(actionData ,'pwdAction','id')=='PWD_CERTIFID'?'*':''}}</em>
                          <div class="IB_tooltip" v-if="checkProperty(actionData ,'pwdAction','id')!='PWD_RFI_RECEIVED'"  >
                            <span ><info-icon size="1.5x" class="custom-class"></info-icon ></span>
                            <div class="tooltip_cnt tooltip_cnt_md"> 
                               <p v-if="[ 'EFILE_PWD'].indexOf(ACTIVITYCODE)>-1">  Make sure to upload the acknowledgment of PWD Filed.</p>
                               <p v-if="[ 'UPDATE_PWD_RESPONSE'].indexOf(ACTIVITYCODE)>-1"> 
                                 Make sure to upload Certified PWD.</p>
                            </div>
                          </div>
                        </label>
                      <div class="uploadsec_wrap upload_uscis">
                        <div class="w-full">
                            <div class="relative">
                              <file-upload
                                v-model="documentModel"
                                class="file-upload-input mb-0"
                                style="height:50px;"
                                name="trackingdoc"
                                :multiple="true"
                               
                                data-vv-as="Documents"
                                :accept="pdfDocEntity"
                                @input="uploadDocuments()"
                              >
                                <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                                Upload
                              </file-upload>
                              <span class="loader" v-if="filesAreuploading"><img src="@/assets/images/main/loader.gif"></span>
                              <span v-if="showDocumentsError && actionData['documents'].length<=0 "  class="text-danger text-sm"  ><em>*</em> 
                                <template v-if="[ 'EFILE_PWD'].indexOf(ACTIVITYCODE)>-1" >PWD Acknowledgment is required</template>
                                <template v-if="[ 'UPDATE_PWD_RESPONSE'].indexOf(ACTIVITYCODE)>-1" >Certified PWD is required</template>
                                </span>
                  
                            </div>
                          <span class="file-type">(File Type: PDF)</span>
                          
                           <span @click="pwdDocFormatError=''"  v-if="pwdDocFormatError"  class="text-danger text-sm"  >{{pwdDocFormatError}}</span>
                          
                          <!-- <VuePerfectScrollbar class="scrollbardoc"> -->
                              
                                <div class="uploded-files_wrap mb-5" v-if="actionData['documents'].length >0 ">
                                    <template v-for="(fil, fileindex) in actionData['documents']">
                                      <div class="w-full"  :key="fileindex" >
                                          <div class="uploded-files">
                                              <vx-input-group class="form-input-group">
                                                <vs-input v-on:keyup="fileNameChenged(fil)"  v-validate="'required'" class="w-full" :name="'fName'+fileindex" v-model="actionData['documents'][fileindex]['name']" data-vv-as="File Name" />
                                                  <span class="text-danger text-sm" v-show="errors.has('uscisstatus.fName'+fileindex)">{{ errors.first('uscisstatus.fName'+fileindex) }}</span>

                                                  
                                              </vx-input-group>

                                              <div class="delete" style="z-index:999" @click="remove(fileindex , actionData['documents']) ;resetPrefedKyes()">
                                                  <img src="@/assets/images/main/delete-row-img.svg" />
                                              </div>
                                          </div>
                                      </div>
                                   </template>
                                </div>
                            <!-- </VuePerfectScrollbar> -->
                          </div>
                      </div>
                      </div>
                    </div>

                   

                  
                  </div>

                </template>
                  
                  
                </div>
                
                <div @click="pewResponceUpdateStatusError=''" class="text-danger text-sm formerrors" v-if="pewResponceUpdateStatusError!=''">
                          <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ pewResponceUpdateStatusError }}</vs-alert>
                </div>

                <div class="popup-footer relative">
                <span class="loader" v-if="pwdResUpdating"><img src="@/assets/images/main/loader.gif"></span>
                  <vs-button color="dark" class="cancel" type="filled" @click="documentModel=[]; hideMe()">Cancel</vs-button>
                  <vs-button color="success" :disabled="pwdResUpdating" @click="submitForm()" class="save" type="filled">Submit</vs-button>
                </div>
            </form>
            </div>
          </modal>  
</template>
<script>
  import { InfoIcon } from "vue-feather-icons";

import moment from "moment";
import FileUpload from "vue-upload-component/src";
import { EyeIcon } from "vue-feather-icons";
import docType from "@/views/common/docType.vue";
import Datepicker from "vuejs-datepicker-inv";
import datepickerField from "@/views/forms/fields/datepicker.vue";
import * as _ from "lodash";
import immiInput from "@/views/forms/fields/simpleinput.vue";
import immitextarea from "@/views/forms/fields/simpletextarea.vue";
import selectField from "@/views/forms/fields/simpleselect.vue";
import Vue from 'vue';
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';

export default {
  provide() {
          return {
             parentValidator: this.$validator,
          };
      },
  components: {
    InfoIcon,
    docType,
    EyeIcon,
    FileUpload,
    Datepicker,
    immiInput,
    immitextarea,
    selectField,
    datepickerField
  },
  methods: {
    prefillcheckStatus(){
      var _dt;
      
    if(this.actionData['documents'].length>0){
     
    
    let path ="/common/extract-data-from-pdf";
    let postData ={
      "docType": "pwd",
      documents:[],
    };
    //postData['documents'] = this.pwdResponse['documents']
    _.forEach(this.actionData['documents'] ,(doc)=>{
        postData['documents'].push(doc.path)
        //return doc.path;
    });
    this.$vs.loading();
    this.$store.dispatch('commonAction', {"data":postData ,"path":path})
        .then((response)=>{
         
          let responseData = response['jobDetails'];
        
          if(this.checkProperty(responseData ,"pwdStatus") !='Filed' ){
            this.showToster({message:"It seems, You haven't uploaded the Filed document. Upload a valid document to continue.",isError:true });
           // this.showToster({"message":"It seems, You haven't uploaded the Filed document. Upload a valid document to continue." ,"isError":true});
              
              this.actionData['documents'] =[];
             
            }
          
          
          this.$vs.loading.close();
        }).catch((errr)=>{
          this.showToster({message:"It seems, You haven't uploaded the Filed document. Upload a valid document to continue.",isError:true });
          this.$vs.loading.close();
          this.actionData['documents'] =[];
         
        });
      }

    },
    pwdActionchanged(){
     
    
      this.actionData.issuedDate =null;
      this.actionData.jobTitle ='';
      this.actionData.wageRate ='';
      this.actionData.socCodeDetails =null;
      this.actionData.socCode =null;      
      this.actionData.documentType ='Original';
      this.pwdDocFormatError ='';
            
   
    },
    resetPrefedKyes(){
      let tempActionData = {
          // "petitionId": "",
          // "action": 'UPDATE_PWD_RESPONSE',//"EFILE_PWD",'UPDATE_PWD_RESPONSE'
          // "typeName": "t",
          // "subTypeName": "",

          wageRate: "",
          socOccuTitle: "",
          preferredSocOccuTitle:"",

          /**** Required for UPDATE_PWD_RESPONSE ****/
          "issuedDate": null,
          "receivedDate": null,
          "dueDate": null,
          "description": "",
          "documents": [],
          "documentType": "Original",
          //pwdStatus:'',
        
          "socCode": null,//4, // Type Number when updating from ImmiBox App
          "socCodeDetails": null,//"13-1111.00", // Type String when update from DOL
          "isSocCodeDetails":false,// true, // Send as true when update from DOL
          "wageRate": "",
          trackingNumber:'',
          "jobTitle":'',
        }
      _.forEach(this.actionData , (item ,key)=>{
            if(this.prefilledKyes.indexOf(key)>-1){
              this.actionData[key] = null;
              if(_.has(tempActionData , key)){
                this.actionData[key] = tempActionData[key];
              }else{
                this.actionData[key] = null;
              }
            }
      });
        this.prefilledKyes = []
        this.$validator.reset();

    },
    prefillJobDetails(){
      this.pwdDocFormatError ='';
      if(this.actionData.documents.length>0){
        this.$vs.loading();
      this.filesAreuploading = true;  
       this.pwdResUpdating =true;
      let path ="/common/extract-data-from-pdf";
      let postData ={
      "docType": "pwd",
      documents:[],
      };
      //postData['documents'] = this.pwdResponse['documents']
      _.forEach(this.actionData['documents'] ,(doc)=>{
      postData['documents'].push(doc.path)
        //return doc.path;
      })
      this.$store.dispatch('commonAction', {"data":postData ,"path":path})
        .then((response)=>{
          this.filesAreuploading = false;  
          this.pwdResUpdating =false;
          let responseData = _.cloneDeep(response['jobDetails']);
            let pwdStatus = _.get(responseData ,"pwdStatus");
           this.PWDCerttified = pwdStatus
          _.forEach( this.actionData, (item ,key)=>{
           
            if((_.has(responseData ,key) && responseData[key]  ) && pwdStatus && pwdStatus =='Certified' ){
              this.actionData['pwdAction'] = {'name':'Certified' ,'id':'PWD_CERTIFID'}
              
                if(key!='pwdAction' && key !='description' ){

                  this.actionData[key] = responseData[key];
                  this.prefilledKyes.push(key);

                }

              
             
            
            }

          });
          if(['EFILE_PWD'].indexOf(this.ACTIVITYCODE>-1)){
            this.actionData.documentType ="Electronic";
          }
          
          this.$vs.loading.close();
        }).catch((errr)=>{
          this.pwdDocFormatError =errr;
          this.filesAreuploading = false;  
          this.pwdResUpdating =false;
          this.$vs.loading.close();
          if(['EFILE_PWD'].indexOf(this.ACTIVITYCODE>-1)){
           this.actionData.documentType ="Electronic";
          }
        });
      }

    },
    updateissuedDate(val){
      if(val){
      //   if(this.actionData['receivedDate']){
      //   let startData = moment(val);
      //   let endData= moment(this.actionData['receivedDate'])
      //   if(startData.isAfter(endData , 'day')){
      //     this.actionData['receivedDate'] = null
      //   }
      // }
      
      if(this.actionData['dueDate']){
        let startDate = moment(val);
        let endDate= moment(this.actionData['dueDate'])
        if(startDate.isAfter(endDate , 'day')){
          this.actionData['dueDate'] = null
        }
      }
      }
      if(val == null){
         this.actionData.dueDate = null
      }
    },
      updatesocCode(item){ 

        if(_.has( item ,'id')){
        this.actionData['socCode'] = item['id'];
        }
      },
    getMasterSocList(){

              let query = {};
              query["page"] = 1;
              query["perpage"] = 10000;
              query["matcher"] = {};
              query["category"] = "soc_codes";


              this.$store
              .dispatch("getMasterData", query)
              .then((response) => {
              this.masterSocList = response.list;

              if(['EFILE_PWD'].indexOf(this.ACTIVITYCODE>-1)){
              this.actionData.documentType ="Electronic";
              }


              //alert(this.perpage);
              })
              .catch(() => {
              this.masterSocList = [];

              });

    },
    remove(index ,docs){
      docs.splice(index ,1);
      this.showDocumentsError =false;
      if(this.actionData['documents'].length<=0){
        this.showDocumentsError =true;
    }

    },
    /**
     * 
     * @param userType | String
     * @param typeId | String
     * @param childrenId | String
     * @param userName | String
     */
    uploadDocuments(){
      var self = this;
      this.pwdDocFormatError ='';
         let docs =_.cloneDeep(this.documentModel);
         this.documentModel=[];
         var self = this;
            docs = docs.map(
                (item) =>{
                    item = {
                        name: item.name,
                        file: item.file,
                        path: "",
                        size:item.size?item.size:'',
                        extn:item.extn?item.extn:'',
                        mimetype: item.type,
                        documentType:item.documentType?item.documentType:null,
                        userName:'',
                        uploadedBy: self.checkProperty(self.getUserData, 'userId'),
                        uploadedByName: self.checkProperty(self.getUserData, 'name'),
                        uploadedByRoleId: self.getUserRoleId,
                        uploadedByRoleName: self.checkProperty(self.getUserData, 'loginRoleName'),
                        size:item.size ? item.size : null,
                       
                    }
                   
                    
                return item;

              }
            );
           
            if (docs.length > 0) {
               
                this.filesAreuploading = true;
                
                let count =0;
                docs.forEach(function (doc) {
                 
                if( (self.ACTIVITYCODE=='UPDATE_PWD_RESPONSE' || self.ACTIVITYCODE=='EFILE_PWD') && !( doc.mimetype=='application/pdf' )  ){
                   self.filesAreuploading = false;  
                   self.pwdDocFormatError ="Upload only pdf documents";         
                  return false;

                }
                
                    let formData = new FormData();
                    formData.append("files", doc.file);
                    formData.append("secureType", "private");
                    formData.append("getDetails", true);
                    self.$store.dispatch("uploadS3File", formData).then((response) => {
                      count = count+1;
                        if (response.data && response.data.result) {
                            response.data.result.forEach((urlGenerated) => {
                              //alert(JSON.stringify(urlGenerated))
                                // doc.url = urlGenerated;
                                 doc.path = urlGenerated['path'];
                                 doc.mimetype = urlGenerated['mimetype'];
                                doc.extn = urlGenerated['extn'];
                                doc.size = urlGenerated['size'];
                                 
                                delete doc.file;
                                if(urlGenerated['path']){
                                  if(self.ACTIVITYCODE=='UPDATE_PWD_RESPONSE' || self.ACTIVITYCODE=='EFILE_PWD'){
                                    self.actionData['documents'] =[];
                                  }
                                   self.actionData['documents'].push(doc)
                                 //  self.statusDocuments.push(doc)
                                 self.showDocumentsError =false;
                                }
                               
                                if(self.ACTIVITYCODE=='UPDATE_PWD_RESPONSE' && self.ACTIVITYCODE != 'SUBMIT_RFI_RESPONSE' && ['PWD_RFI_RECEIVED' ].indexOf(self.checkProperty(self.actionData ,'pwdAction','id') )<=-1 ){
                                  //&& self.checkProperty(self.actionData ,'pwdAction','id') && self.checkProperty(self.actionData ,'pwdAction','id')!='PWD_RFI_RECEIVED'
                                  self.prefillJobDetails()
                                }
                                
                                if(parseInt(count)>=docs.length ){
                                   self.filesAreuploading = false;
                                   self.pwdResUpdating =false;
                                   if([ 'EFILE_PWD'].indexOf(self.ACTIVITYCODE)>-1 && !this.loadedFromPwdLibrary){
                                     self.prefillcheckStatus();

                                   }
                                 

                                }
                            });
                            if(count>=docs.length){

                              
                              self.filesAreuploading = false;
                              self.pwdResUpdating =false;
                              if([ 'EFILE_PWD'].indexOf(self.ACTIVITYCODE)>-1){
                               // self.prefillcheckStatus();

                              }
                           

                            }
                            
                        }
                       
                    });
                });
            }
    },
   
      
    fileNameChenged(index, fileindex) {
            this.disable_uploadBtn = false;

            _.forEach(this.actionData['documents'], (doc, value) => {
                let fname = doc.name;
                fname = fname.trim();

                if (!fname) {
                    this.disable_uploadBtn = true;
                }
            });

        },

  
      
    submitForm() {
      
            this.pewResponceUpdateStatusError='';
            this.showDocumentsError =false;
            this.pwdDocFormatError ='';
         
            this.$validator.validateAll("uscisstatus").then((result) => {
              //Documents are optional for EFILE_PWD  checkProperty(actionData ,'pwdAction','id')=='PWD_CERTIFID'
              if(this.checkProperty(this.actionData ,'documents' ,'length')<=0 && [ 'EFILE_PWD',"UPDATE_PWD_RESPONSE"].indexOf(this.ACTIVITYCODE)>-1 ){
                if([ "UPDATE_PWD_RESPONSE"].indexOf(this.ACTIVITYCODE)>-1 ){
                  if(this.checkProperty(this.actionData ,'pwdAction','id')=='PWD_CERTIFID'){
                    this.showDocumentsError =true;
                  }else{
                    this.showDocumentsError =false;
                  }

                }else{
                  this.showDocumentsError =true;
                }
                
              }

               if(!this.showDocumentsError && result && !this.filesAreuploading){
                this.pwdResUpdating =true;
                let path ="/perm/manage-pwd";
                let data
                if(this.ACTIVITYCODE =="UPDATE_PWD_RESPONSE"){
                   data = this.actionData;
                    data['action']  ='UPDATE_PWD_RESPONSE'; 
                    if(this.checkProperty( this.actionData ,'pwdAction' ,'id')){
                      path ="/perm/manage-pwd";
                      data['action']  =this.actionData['pwdAction']['id'];
                      if(this.actionData['pwdAction']['id'] =='PWD_RFI_RECEIVED'){

                         data = {
                              "petitionId": "",
                              "action": 'PWD_RFI_RECEIVED',
                              "typeName": "",
                              "subTypeName": "",
                              "receivedDate": null,
                              "dueDate": null,
                              "description": "",
                              "documents": [],
                              "documentType": "Original",
                             
                           }
                           data['action'] = 'PWD_RFI_RECEIVED';
                           data['receivedDate'] =this.actionData['receivedDate'];
                           data['dueDate'] =this.actionData['dueDate'];
                           data['description'] =this.actionData['description'];
                           data['documents'] =this.actionData['documents'];



                      }
                      
                      
                    }
                    
                }
                if(this.ACTIVITYCODE =="EFILE_PWD"){
                    data = { 'trackingNumber':'' ,'petitionId':'' ,"typeName": "", 	"subTypeName": "", "action":'EFILE_PWD' ,"documentType":'Electronic',"documents":[]}; 
                    data['trackingNumber'] = this.actionData['trackingNumber'];
                 //   data['documentType'] = this.actionData['documentType'];
                    data['documents'] = this.actionData['documents'];
                   
                   
                }
               

                data['typeName'] = this.checkProperty( this.petitionDetails , 'typeDetails','name');
                data['subTypeName'] = this.checkProperty( this.petitionDetails ,'subTypeDetails','name');
                data['petitionId'] = this.checkProperty( this.petitionDetails ,'_id');
                if(this.loadedFromPwdLibrary){
                  data['pwdId'] =this.checkProperty( this.petitionDetails ,'_id');
                  path= "/pwd/manage-pwd";
                
                  if(this.checkProperty( this.petitionDetails ,'petitionList' ,'length')==1 && this.petitionDetails['completedActivities'].indexOf('PWD_CERTIFID')<=-1 ){
                    path ="/perm/manage-pwd";
                    data["typeName"] ="GC-Employment";
                    data["subTypeName"] ="GC-Employment";
                    data['petitionId'] = this.petitionDetails['petitionList'][0]['_id'];
                   
                  }
                }
                this.$store.dispatch('commonAction' ,{ "data":data ,'path':path})
                .then((res)=>{
                  this.showToster({message:res['message'],isError:false });
                  this.hideMe();
                  this.$emit("updatepetition");
                })
                .catch((error)=>{
                  this.pewResponceUpdateStatusError =error;
                  this.pwdResUpdating =false;
                 })

                

               }
            });
    },
    hideMe() {

      this.$emit("hideMe");
      setTimeout(()=>{
          this.$modal.hide('updateUscisStatus');
        },10);
    },
  },
  watch: {
    showPopup(val) {
      if (!val){
        this.$emit("hideMe");
        this.$modal.hide('updateUscisStatus');
      } 
    },
  },
  mounted() {
   
      this.getMasterSocList();
      this.showPopup = true;
      this.$modal.show('updateUscisStatus');
      if(_.has(this.petitionDetails ,'pwdStatus')){

        // this.actionData.pwdStatus  =this.petitionDetails['pwdStatus'];
        // if(this.petitionDetails['pwdStatus'] =="Filed"){
        //   this.actionData.pwdStatus ="Certified";
        //   this.pwdStatusList = ["Certified"]

        // }
      }
      if(['EFILE_PWD'].indexOf(this.ACTIVITYCODE>-1)){
           this.actionData.documentType ="Electronic";
      }

      if( ['UPDATE_PWD_RESPONSE' ].indexOf(this.ACTIVITYCODE)>-1 ){
              this.actionData = Object.assign(this.actionData ,{'pwdAction':null });
              this.actionData = _.cloneDeep(this.actionData);
            
          }
    
  },
  data: () => ({
    PWDCerttified:'',
    editor: ClassicEditor,
 editorConfig: {
     toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
 },
    pwdActionsList:[
      {'name':'RFI Received' ,'id':'PWD_RFI_RECEIVED'},
      {'name':'Certified' ,'id':'PWD_CERTIFID'},
    ],
    pwdStatusList:["Filed" ,"Certified"],
    prefilledKyes:[],
    pwdDocFormatError:'',
    showDocumentsError:false,
    masterSocList:[],
    pwdResUpdating:false,
    pewResponceUpdateStatusError:'',
    actionData:{
    "petitionId": "",
		"action": 'UPDATE_PWD_RESPONSE',//"EFILE_PWD",'UPDATE_PWD_RESPONSE'
		"typeName": "",
		"subTypeName": "",
		/**** Required for UPDATE_PWD_RESPONSE ****/
   // pwdStatus:'',
     pwdAction:null,
		"issuedDate": null,
		"receivedDate": null,
		"dueDate": null,
		"description": "",
		"documents": [],
		"documentType": "Original",
   
		"socCodeDetails": null,//4, // Type Number when updating from ImmiBox App
		"socCode": '',//"13-1111.00", // Type String when update from DOL
		"isSocCodeDetails":false,// true, // Send as true when update from DOL
		"wageRate": "",
    trackingNumber:'',
    "jobTitle":'',
  },

   
    
   documentTypes:["Original" ,"Electronic" ],
    documentModel:[],
    statusDocuments:[],
   filesAreuploading: false,
    
    uploading: false,
    courierList: [],
    tracking: { documents: [], receiptNumber: null, receiptName: null },
    
    
    openDate: new Date().setFullYear(new Date().getFullYear()),
    startEligibleDate: new Date().setFullYear(new Date().getFullYear()),
    
    disabled_btn: false,
    showPopup: false,
    documents: [],
   
  }),
  props: {
    loadedFromPwdLibrary:{
      type: Boolean,
      default: false,

    },
    ACTIVITYCODE: {
      type: String,
      default: null,
    },
    petitionDetails: {
      type: Object,
      default: null,
    },
  },
};
</script>
