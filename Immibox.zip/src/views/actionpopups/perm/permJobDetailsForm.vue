<template>
    <div class="custom_modal_cnt">
        <div class="modal_title">      
            <h2> Job Details  </h2>                
                <span class="close" @click="hideMe()"><x-icon size="1.5x"></x-icon></span>
        </div>
            <div>
            <div class="custom-tabs">
                <ul class="d-flex">
                    <li :class="{'active':activeTab=='jobDetails'}" @click="tabChanged('jobDetails')">Job Information</li>
                    <li  :class="{'active':activeTab=='wageInfo'}" @click="tabChanged('wageInfo')">Wage Information</li>
                    <li  :class="{'active':activeTab=='jobOpptInfo'}" @click="tabChanged('jobOpptInfo')">Job Opportunity Information</li>
                </ul>
            </div>
                <div v-if="petitionDetails">
                        <div v-if="activeTab=='jobDetails'">
                            <div class="modal_cnt withTabButtons">
                                <form data-vv-scope="jobDetails" @submit.prevent="" @keydown.enter.prevent="" >
                                    <div @click="jdUpdateStatusError=''" class="form-container">
                                        <VuePerfectScrollbar	
                                                ref="mainSidebarPs"	
                                                class="scroll-area--main-sidebar"	
                                                :settings="settings"	
                                            
                                            >
                                            <div class="infoSec">
                                                <div class="vx-row" > 
                                        
                                        <immiInput :wrapclass="'md:w-1/3'" :display="true" :cid="'job-Id'" :formscope="'jobDetails'"  v-model="petitionDetails['jobDetails'].jobId" :required="true" fieldName="Job Id" label="Job ID" placeHolder="Job ID" :maxLength="15"  />
                                        <immiInput :onlyNumbers="true" :allowFloatingPoint="false" :wrapclass="'md:w-1/3'" :display="true" :cid="'noOfPositionss'" :formscope="'jobDetails'" v-model="petitionDetails['jobDetails'].noOfPositions" :maxLength="4"  :required="true" fieldName="noOfPositions" label="No of Positions" placeHolder="No of Positions" />
                                        <selectField :wrapclass="'md:w-1/3'" :required="true" :optionslist="educationTypes" v-model="petitionDetails['jobDetails'].minDegreeDetails" @input="updateMainDegree" :formscope="'jobDetails'"  fieldName="minDegree" label="Minimum Education Level" placeHolder="Minimum Education Level"   />  
                                        <immiInput :onlyNumbers="true" :allowFloatingPoint="true" :wrapclass="'md:w-1/3'" :display="true" cid="expInYears" :formscope="'jobDetails'"  v-model="petitionDetails['jobDetails'].expInYears" :required="true" fieldName="expInYears" label="Experience in Years" placeHolder="Experience"  :maxLength="5" />
                                        <immiInput :onlyNumbers="true" :wrapclass="'md:w-1/3'" :display="true" cid="salary" :formscope="'jobDetails'"  v-model="petitionDetails['jobDetails'].salary" :required="true" fieldName="salary" label="Salary per Year" placeHolder="Salary"   />
                                       
                                        <selectField :listContainsId="false" :wrapclass="'md:w-1/3'" cid="jobType"  :required="true" :optionslist="['Full Time', 'Part Time']" v-model="petitionDetails['jobDetails'].jobType" :formscope="'jobDetails'"  fieldName="jobType"  label="Job Type" placeHolder="Job Type"  />  
                                       
                                        <selectField :listContainsId="false" :wrapclass="'md:w-1/3'" cid="jobShift"  :required="true" :optionslist="['Day', 'Night']" v-model="petitionDetails['jobDetails'].jobShift" :formscope="'jobDetails'"  fieldName="jobShift"  label="Job Shift" placeHolder="Job Shift"   />  
                                       
                                        <immiInput :onlyNumbers="true" :wrapclass="'md:w-1/3'" :display="true" cid="hoursPerWeek" :formscope="'jobDetails'"  v-model="petitionDetails['jobDetails'].hoursPerWeek" :required="true" fieldName="hoursPerWeek" label="Hours per Week" placeHolder="Hours per Week"  :maxLength="3" />
                                        <datepickerField wrapclass="md:w-1/3" @input="updateJobStartDate($event)" :dateOpenFrom="petitionDetails['jobDetails'].applicationInfo.jobEndOn"   :display="true"  v-model="petitionDetails['jobDetails'].applicationInfo.jobStartsOn" :formscope="'jobDetails'"  fieldName="jobStartsOn"  label="Job Start Date" :validationRequired="true"   />
                                        <datepickerField wrapclass="md:w-1/3" :dateOpenFrom="petitionDetails['jobDetails'].applicationInfo.jobStartsOn"  :display="true"   v-model="petitionDetails['jobDetails'].applicationInfo.jobEndOn" :formscope="'jobDetails'"  fieldName="jobEndOn" :dateEnableFrom="petitionDetails['jobDetails'].applicationInfo.jobStartsOn"  label="Job End Date"  :validationRequired="true"   />
                                        <immitextfield  wrapclass="md:w-1/1"  :formscope="'jobDetails'"  v-model="petitionDetails['jobDetails'].description" :required="true" fieldName="description" label="Job Description" placeHolder="Job Description"></immitextfield>
                                            </div>
                                            <div @click="jdUpdateStatusError=''" class="text-danger text-sm formerrors" v-if="jdUpdateStatusError!=''"> 
                                            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ jdUpdateStatusError }}</vs-alert>
                                            </div>
                                            </div>
                                        </VuePerfectScrollbar>

                                    </div>
                                </form>
                            </div>
                            <div class="popup-footer">
                                    <span class="loader" v-if="jdUpdating"><img src="@/assets/images/main/loader.gif"></span>

                                    <vs-button color="success" :disabled="jdUpdating" @click="tabChanged('wageInfo')" class="save" type="filled">Next</vs-button>
                                    
                                    <!----
                                    <vs-button color="dark" class="cancel" type="filled" @click="hideMe()">Cancel</vs-button>
                                    <vs-button color="success" :disabled="jdUpdating" @click="submitForm()" class="save" type="filled">Submit</vs-button>
                                    -->
                                    </div>

                        </div>
                        <div v-if="activeTab=='wageInfo'">
                            <div class="modal_cnt withTabButtons">
                                <form data-vv-scope="wageInfo" @submit.prevent="" @keydown.enter.prevent="" >
                                <div @click="jdUpdateStatusError='';"  class="form-container">
                                    <VuePerfectScrollbar	
                                                ref="mainSidebarPs"	
                                                class="scroll-area--main-sidebar"	
                                                :settings="settings"	
                                            
                                            > 
                                    <div class="infoSec">
                                        <h4>Wage Information</h4>
                                        <div class="vx-row">
                                            <!-- trackingNumber: String,
                                            socCode: Number,
                                            wageRate: String,
                                            payFrequency: String, // Year, Month, Bi-Weekly, Week, Hour
                                            wageSource: String, // OES, CBA, Employer Conducted Survey, DBA, SCA, Other
                                            wageSourceOtherDesc: String,
                                            determinationDate: Date,
                                            expirationDate: Date -->
                                            <!----
                                            <immiInput :wrapclass="'md:w-1/3'" :display="true" cid="trackingNumber" :formscope="'wageInfo'" v-model="petitionDetails.wageInfo.trackingNumber" :required="true" fieldName="trackingNumber" label="Tracking Number" placeHolder="Tracking Number" />
                                            -->
                                            <selectField :wrapclass="'md:w-1/3'" :required="true"  cid="socCode"  :formscope="'wageInfo'" :optionslist="masterSocList" v-model="petitionDetails.wageInfo.socCodeDetails" @input="updatesocCode"   fieldName="socCod" label="Preferred SOC Code" placeHolder="Preferred SOC Code "   />  
                                            <immiInput :onlyNumbers="true" :allowFloatingPoint="true" :wrapclass="'md:w-1/3'" :display="true" cid="wageRate" :formscope="'wageInfo'" v-model="petitionDetails.wageInfo.wageRate" :required="true" fieldName="wageRate" label="Preferred Wage Rate" placeHolder="Preferred Wage Rate" :maxLength="10" />
                                            <selectField :listContainsId="false" :wrapclass="'md:w-1/3'" :required="true"  :formscope="'wageInfo'" cid="offerpayFrequency"  :optionslist="payFrequencyList" v-model="petitionDetails.wageInfo.payFrequency"  fieldName="offerpayFrequency" label="Pay Frequency" placeHolder="Pay Frequency"   />  
                                            <selectField :listContainsId="false" :wrapclass="'md:w-1/3'" :required="true" :formscope="'wageInfo'" cid="wageSource"  :optionslist="wageSourceList" v-model="petitionDetails.wageInfo.wageSource"   fieldName="wageSource" label="Source of Wage" placeHolder="Source of Wage"   />  
                                            <datepickerField wrapclass="md:w-1/3" @input="updateDeterminationDate($event)" :display="true"  v-model="petitionDetails.wageInfo.determinationDate" :formscope="'wageInfo'" fieldName="determinationDate"  label="Determination Date" :validationRequired="true" />
                                            <datepickerField :isDisabled="!petitionDetails.wageInfo.determinationDate" wrapclass="md:w-1/3"  :display="true"   v-model="petitionDetails.wageInfo.expirationDate" :formscope="'wageInfo'" fieldName="expirationDate" :dateEnableFrom="petitionDetails.wageInfo.determinationDate" label="Expiration Date"  :validationRequired="true" />
                                            <immitextarea  wrapclass="md:w-1/1"  :formscope="'wageInfo'" v-model="petitionDetails.wageInfo.wageSourceOtherDesc" :required="true" fieldName="wageSourceOtherDesc" label="Wage Source Description" placeHolder="Wage Source Description"></immitextarea>

                                        </div>
                                    <div class="divider mt-0"></div>
                                    <h4>Wage Offer Information</h4>
                                        <div class="vx-row">
                                            <!-- wageOfferInfo: {
                                                minWage: String,
                                                maxWage: String,
                                                payFrequency: String, // Year, Month, Bi-Weekly, Week, Hour
                                            } -->
                                        

                                        <div class="vx-col  w-full md:w-1/3" >
                                             <div class="form_group">
                                                   <label class="form_label">Minimum Wage<em >*</em></label>
                                                   <vs-input  oninput="petitionDetails.wageOfferInfo.minWage = petitionDetails.wageOfferInfo.minWage.replace(/[^0-9 .]/g, '').replace(/(\..*)\./g, '$1'); petitionDetails.wageOfferInfo.minWage = petitionDetails.wageOfferInfo.minWage.replace(/ /g,'')"  name="wageminimum" v-model="petitionDetails.wageOfferInfo.minWage" v-validate="'required|numeric' "  :maxLength="9" class="w-full" :data-vv-as="'Minimum Wage'"  />
                                                   <p v-show="errors.has('wageInfo.wageminimum')" class="text-danger text-sm">{{ errors.first('wageInfo.wageminimum') }}</p>
                                                </div>
                                         </div>
                                         <div class="vx-col  w-full md:w-1/3" >
                                             <div class="form_group">
                                                   <label class="form_label">Maximum Wage<em >*</em></label>
                                                   <vs-input @input="maxWaseError=''"  oninput="petitionDetails.wageOfferInfo.maxWage = petitionDetails.wageOfferInfo.maxWage.replace(/[^0-9 .]/g, '').replace(/(\..*)\./g, '$1'); petitionDetails.wageOfferInfo.maxWage = petitionDetails.wageOfferInfo.maxWage.replace(/ /g,'');"  name="MaximumWage" v-model="petitionDetails.wageOfferInfo.maxWage" v-validate="'required|numeric' "  :maxLength="9" class="w-full" :data-vv-as="'Maximum Wage'"  />
                                                   
                                                   <p v-if="maxWaseError" class="text-danger text-sm">{{ maxWaseError }}</p>
                                                   <p v-else-if="errors.has('wageInfo.MaximumWage')" class="text-danger text-sm">{{ errors.first('wageInfo.MaximumWage') }}</p>
                                                  
                                                   
                                                </div>
                                         </div>
                                         <div class="vx-col  w-full md:w-1/3" >
                                             <div class="form_group">
                                                   <label class="form_label">Pay Frequency<em >*</em></label>
                                                   <div class="con-select w-full">
                                                    <multiselect  
                                                        name="PayFrequency"
                                                        :multiple="false" 
                                                        v-validate="'required'"
                                                        v-model="petitionDetails.wageOfferInfo.payFrequency" 
                                                        :close-on-select="true"
                                                        data-vv-as="Pay Frequency" 
                                                        placeholder="Pay Frequency"  
                                                        :options="payFrequencyList"
                                                        :searchable="true" 
                                                        :allow-empty="false" 
                                                        >
                                                    </multiselect>
                                                   </div>
                                                   <p v-show="errors.has('wageInfo.PayFrequency')" class="text-danger text-sm">{{ errors.first('wageInfo.PayFrequency') }}</p>
                                                </div>
                                         </div>
                                           
                                            <!-- <selectField :listContainsId="false" :wrapclass="'md:w-1/3'" :required="true"   :formscope="'wageInfo'"  cid="infopayFrequency"  :optionslist="payFrequencyList" v-model="petitionDetails.wageOfferInfo.payFrequency"  fieldName="infopayFrequency" label="Pay Frequency" placeHolder="Pay Frequency"   />   -->
                                            

                                        </div>
                                            <div @click="jdUpdateStatusError=''" class="text-danger text-sm formerrors" v-if="jdUpdateStatusError!=''">
                                            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ jdUpdateStatusError }}</vs-alert>
                                            </div>  
                                    </div>
                                    </VuePerfectScrollbar>
                                </div>
                                
                                
                            </form>
                            </div>
                            <div class="popup-footer">
                                <span class="loader" v-if="jdUpdating"><img src="@/assets/images/main/loader.gif"></span>
                                <vs-button color="dark" class="cancel" type="filled" :disabled="jdUpdating" @click="tabChanged('jobDetails', true)" >Back</vs-button>
                                <vs-button color="success" :disabled="jdUpdating" @click="tabChanged('jobOpptInfo')" class="save" type="filled">Next</vs-button>
                                <!-----
                                <vs-button color="dark" class="cancel" type="filled" @click="hideMe()">Cancel</vs-button>
                                <vs-button color="success" :disabled="jdUpdating" @click="submitForm()" class="save" type="filled">Submit</vs-button>
                                --->
                            </div>
                        </div>
                        <div v-if="activeTab=='jobOpptInfo'">
                            
                            <div class="modal_cnt withTabButtons">
                                <form @click="jdUpdateStatusError=''"  data-vv-scope="jobOpptInfo" @submit.prevent="" @keydown.enter.prevent="" >
                                <div class="form-container">
                                    <VuePerfectScrollbar	
                                            ref="mainSidebarPs"	
                                            class="scroll-area--main-sidebar"	
                                            :settings="settings"	
                                        
                                        > 
                                        <div class="infoSec">
                                            <div class="vx-row">
                                              
                                            <div class="vx-col  w-full md:w-1/3" >
                                                  <div class="form_group">
                                                   <label class="form_label">Preferred Job Title<em >*</em></label>
                                                   <vs-input   name="jobTitle" v-model="petitionDetails.jobOpportunityInfo.jobTitle" v-validate="'required' "  class="w-full" :data-vv-as="'Preferred Job Title'"  />
                                                   <p v-show="errors.has('jobOpptInfo.jobTitle')" class="text-danger text-sm">{{ errors.first('jobOpptInfo.jobTitle') }}</p>
                                                </div>
                                            </div> 
                                            <!-- <div class="vx-col  w-full md:w-1/3" >
                                             <div class="form_group">
                                                   <label class="form_label">Education<em >*</em></label>
                                                   <div class="con-select w-full">
                                                    <multiselect  
                                                       @input="jobOppupdateMainDegree"
                                                        name="education"
                                                        :multiple="false" 
                                                        track-by="id" label="name"
                                                        v-validate="'required'"
                                                        v-model="petitionDetails.jobOpportunityInfo.minDegreeDetails" 
                                                        :close-on-select="true"
                                                        data-vv-as="Education" 
                                                        placeholder="Education"  
                                                        :options="educationTypes"
                                                        :searchable="true" 
                                                        :allow-empty="false" 
                                                        >
                                                    </multiselect>
                                                   </div>
                                                   <p v-show="errors.has('jobOpptInfo.education')" class="text-danger text-sm">{{ errors.first('jobOpptInfo.education') }}</p>
                                                </div>
                                            </div>     -->
                                            <!-- <selectField :formscope="'jobOpptInfo'" :wrapclass="'md:w-1/3'" :required="true" :optionslist="educationTypes" v-model="petitionDetails['jobOpportunityInfo'].minDegreeDetails" @input="jobOppupdateMainDegree"   fieldName="minDegree" label="Education" placeHolder="Education"   />   -->
                                            
 
                                            <div class="vx-col  w-full md:w-1/3" >
                                                  <div class="form_group">
                                                   <label class="form_label">Major Field of Study<em >*</em></label>
                                                   <vs-input   name="majorFieldsOfStudy" v-model="petitionDetails.jobOpportunityInfo.majorFieldsOfStudy" v-validate="'required' "  class="w-full" :data-vv-as="'Preferred Job Title'"  />
                                                   <p v-show="errors.has('jobOpptInfo.majorFieldsOfStudy')" class="text-danger text-sm">{{ errors.first('jobOpptInfo.majorFieldsOfStudy') }}</p>
                                                </div>
                                            </div>
                                            <redioButtons   :wrapclass="''" :cid="'isTrainigRequired'" @input="updateIsTrainigRequired" :formscope="'jobOpptInfo'" v-model="petitionDetails.jobOpportunityInfo.isTrainigRequired" fieldName="isTrainigRequired" label="Is training required for the job opportunity?" placeHolder="" />
                                            <immiInput v-if="checkProperty(petitionDetails ,'jobOpportunityInfo','isTrainigRequired')=='Yes'" :onlyNumbers="true" :wrapclass="'md:w-1/2'" :display="true" cid="noOfTraningMonths" :formscope="'jobOpptInfo'" v-model="petitionDetails.jobOpportunityInfo.noOfTraningMonths" :required="true" fieldName="noOfTraningMonths" label="No of months training required" placeHolder="No of months training" :maxLength="3"  />
                                            <immiInput v-if="checkProperty(petitionDetails ,'jobOpportunityInfo','isTrainigRequired')=='Yes'" :wrapclass="'md:w-1/2'" :display="true" cid="fieldOfTraining" :formscope="'jobOpptInfo'" v-model="petitionDetails.jobOpportunityInfo.fieldOfTraining" :required="true" fieldName="fieldOfTraining" label="Indicate the field of training" placeHolder="Indicate the field of training"  />
                                            
                                            
                                            <redioButtons  :wrapclass="''" :cid="'isExpRequired'" @input="updateisExpRequired" formscope="jobOpptInfo" v-model="petitionDetails.jobOpportunityInfo.isExpRequired" fieldName="isExpRequired" label="Is experience in the job offered required for the job?" placeHolder="" />
                                            <immiInput v-if="checkProperty(petitionDetails ,'jobOpportunityInfo','isExpRequired')=='Yes'" :onlyNumbers="true" :wrapclass="'md:w-1/2'" :display="true" cid="noOfExpMonths" :formscope="'jobOpptInfo'" v-model="petitionDetails.jobOpportunityInfo.noOfExpMonths" :required="true" fieldName="noOfTraningMonths" label="No of months of experience required" placeHolder="No of months of experience " :maxLength="3"  />
                                            


                                            <redioButtons  :wrapclass="''" :cid="'isAltFieldOfStudyAccept'" @input="updateisAltFieldOfStudyAccept" formscope="jobOpptInfo" v-model="petitionDetails.jobOpportunityInfo.isAltFieldOfStudyAccept" fieldName="isAltFieldOfStudyAccept" label="Is there an alternate field of study that is acceptable?" placeHolder="" />
                                            <immiInput v-if="checkProperty(petitionDetails ,'jobOpportunityInfo','isAltFieldOfStudyAccept')=='Yes'"  :wrapclass="'md:w-1/2'" :display="true" cid="altMajorFieldOfStudy" :formscope="'jobOpptInfo'" v-model="petitionDetails.jobOpportunityInfo.altMajorFieldOfStudy" :required="true" fieldName="altMajorFieldOfStudy" label="Specify alternate field of study" placeHolder="Specify alternate of study"  />
                                            

                                            <redioButtons  :wrapclass="''" :cid="'isAltCombOfEduAndExpAccept'" @input="updateisAltCombOfEduAndExpAccept" formscope="jobOpptInfo" v-model="petitionDetails.jobOpportunityInfo.isAltCombOfEduAndExpAccept" fieldName="isAltCombOfEduAndExpAccept" label="Is there an alternate combination of education and experience that is acceptable?" placeHolder="" />
                                            <selectField v-if="checkProperty(petitionDetails ,'jobOpportunityInfo','isAltCombOfEduAndExpAccept')=='Yes'" :wrapclass="'md:w-1/3'" :required="true" :optionslist="educationTypes" v-model="petitionDetails.jobOpportunityInfo.altLevelOfEduDetails" @input="petitionDetails.jobOpportunityInfo.altLevelOfEdu= checkProperty(petitionDetails.jobOpportunityInfo ,'altLevelOfEduDetails' ,'id')" :formscope="'jobOpptInfo'"  fieldName="altLevelOfEdu" label="Alternate Level of Education" placeHolder="Alternate Level of Education"   />  
                                            
                                            <immiInput v-if="checkProperty(petitionDetails ,'jobOpportunityInfo','isAltCombOfEduAndExpAccept')=='Yes'" :allowFloatingPoint="true" :onlyNumbers="true" :wrapclass="'md:w-1/2'" :display="true" cid="altAcceptExpInYears" :formscope="'jobOpptInfo'" v-model="petitionDetails.jobOpportunityInfo.altAcceptExpInYears" :required="true" fieldName="altAcceptExpInYears" label="Indicate the number of years experience acceptable" placeHolder="No of years experience" :maxLength="5" />
                                            

                                            <redioButtons  :wrapclass="''" :cid="'foreignEduEqAccept'"  formscope="jobOpptInfo" v-model="petitionDetails.jobOpportunityInfo.foreignEduEqAccept" fieldName="foreignEduEqAccept" label="Is a foreign educational equivalent acceptable?" placeHolder="" />
                                            
                                            <redioButtons  :wrapclass="''" :cid="'isExpInAltOccuAccept'" @input="updateisExpInAltOccuAccept" formscope="jobOpptInfo" v-model="petitionDetails.jobOpportunityInfo.isExpInAltOccuAccept" fieldName="isExpInAltOccuAccept" label="Is experience in an alternate occupation acceptable?" placeHolder="" />
                                            <immiInput v-if="checkProperty(petitionDetails ,'jobOpportunityInfo','isExpInAltOccuAccept')=='Yes'" :wrapclass="'md:w-1/2'" :display="true" cid="jobTitleOfAcceptAltOccu" :formscope="'jobOpptInfo'" v-model="petitionDetails.jobOpportunityInfo.jobTitleOfAcceptAltOccu" :required="true" fieldName="jobTitleOfAcceptAltOccu" label="Identify the job title of the acceptable alternate occupation" placeHolder="Job title"  />
                                            <immiInput v-if="checkProperty(petitionDetails ,'jobOpportunityInfo','isExpInAltOccuAccept')=='Yes'" :onlyNumbers="true" :wrapclass="'md:w-1/2'" :display="true" cid="noOfExpMonthsInAltOccu" :formscope="'jobOpptInfo'" v-model="petitionDetails.jobOpportunityInfo.noOfExpMonthsInAltOccu" :required="true" fieldName="noOfExpMonthsInAltOccu" label="No of months experience in alternate occupation required" placeHolder="No of months experience" :maxLength="3"  />
                                            
                                        <!-- // jobDuties: String, // Job duties – If submitting by mail, add attachment if necessary. Job duties description must begin in this space
                                        // jobOppoReqForNormalOccu: String, // Yes/No // Are the job opportunity’s requirements normal for the occupation? -->
                                        <redioButtons :formscope="'jobOpptInfo'" :wrapclass="''" :cid="'jobOppoReqForNormalOccu'"  :showNA="false" formscope="jobOpptInfo" v-model="petitionDetails.jobOpportunityInfo.jobOppoReqForNormalOccu" fieldName="jobOppoReqForNormalOccu" label="Are the job opportunity’s requirements normal for the occupation?" placeHolder="" />                                      
                                       

                                        <div class="vx-col  w-full" >
                                            <div class="form_group">
                                               <label class="form_label">Job Duties<em >*</em></label>
                                                     <ckeditor :editor="editor" :config="editorConfig" :name="'Jobduties'" v-model="petitionDetails.jobOpportunityInfo.jobDuties" v-validate="'required'"  class="w-full" :data-vv-as="'Job Duties'" />
                                                     <p v-show="errors.has('jobOpptInfo.Jobduties')" class="text-danger text-sm">{{ errors.first('jobOpptInfo.Jobduties') }}</p>
                                            </div>
                                         </div>



                                        <!-- //   isForiegnLangRequired: String, // Yes/No // Is knowledge of a foreign language required to perform the job duties?
                                    //   skills: Array, // Specific skills or other requirements – If submitting by mail, add attachment if necessary. Skills description must begin in this space.  -->
                                    <redioButtons  :wrapclass="''" :cid="'isForiegnLangRequired'" @input="updateisForiegnLangRequired" formscope="jobOpptInfo" v-model="petitionDetails.jobOpportunityInfo.isForiegnLangRequired" fieldName="isForiegnLangRequired" label="Is knowledge of a foreign language required to perform the job duties?" placeHolder="" />
                                    <!-- v-if="checkProperty(petitionDetails ,'jobOpportunityInfo','isForiegnLangRequired')=='Yes'" -->
                                    <template >
                                        <div class="vx-col w-full">
                                            <div class="skilladdsec">
                                                <label>Specific skills or other requirements </label>
                                                <ul>
                                                    <li v-for="(skil , index ) in petitionDetails['jobOpportunityInfo']['skills']" :key="index">
                                                        <span class="skill-label">{{skil}}</span>
                                                    

                                                        <span  @click="removeSkill(index)" class="row_btn">
                                                            <img src="@/assets/images/main/delete-row-img.svg">
                                                        </span>
                                                    </li>
                                                </ul>
                                                <div class="add-input-sec">
                                                    <div @keyup.enter.native="addNewSkill()" @keyup="addSkill=true">
                                                        <immiInput  :wrapclass="'w-full'"  :display="true" cid="addSkill" :formscope="'jobOpptInfo'"  v-model="newSkill" :required="false" fieldName="altAcceptExpInYears" placeHolder=""  />
                                                        <span v-if="addSkill"  @click="addNewSkill()" class="add-more">Add</span>
                                                    </div>

                                                    <!-- <li v-if="!addSkill"  @click="newSkill =''" > <span class="add-more">+ More</span></li> -->
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </template> 
                                    
                                    <redioButtons  :wrapclass="''" :cid="'isApplInvolJobOppoInclCombOfOccu'"  formscope="jobOpptInfo" v-model="petitionDetails.jobOpportunityInfo.isApplInvolJobOppoInclCombOfOccu" fieldName="isApplInvolJobOppoInclCombOfOccu" label="Does this application involve a job opportunity that includes a combination of occupations?" placeHolder="" />
                                    <redioButtons  :wrapclass="''" :cid="'positionOfferToAlien'"  formscope="jobOpptInfo" v-model="petitionDetails.jobOpportunityInfo.positionOfferToAlien" fieldName="positionOfferToAlien" label="Is the position identified in this application being offered to the alien identified" placeHolder="" />
                                    <redioButtons  :wrapclass="''" :cid="'alienReqToLiveEmplrPrimisis'"  formscope="jobOpptInfo" v-model="petitionDetails.jobOpportunityInfo.alienReqToLiveEmplrPrimisis" fieldName="alienReqToLiveEmplrPrimisis" label="Does the job require the alien to live on the employer’s premises?" placeHolder="" />
                                    <redioButtons  :wrapclass="''" :cid="'applLiveInHouseDomWorker'"  formscope="jobOpptInfo" v-model="petitionDetails.jobOpportunityInfo.applLiveInHouseDomWorker" fieldName="applLiveInHouseDomWorker" label="Is the application for a live-in household domestic service worker?" placeHolder="" />
                                    <redioButtons v-if="checkProperty(petitionDetails['jobOpportunityInfo'],'applLiveInHouseDomWorker')=='Yes'" :wrapclass="''" :cid="'emplrProviedAlienCopyOfContract'"  :showNA="false" formscope="jobOpptInfo" v-model="petitionDetails.jobOpportunityInfo.emplrProviedAlienCopyOfContract" fieldName="emplrProviedAlienCopyOfContract" label="The employer and the alien executed the required employment contract and has the employer provided a copy of the contract to the alien?" placeHolder="" />

                                        </div>
                                        
                                        <div class="divider mt-0"></div>
                                        
                                    <div class="vx-col w-full" v-if="countries.length>0"    vs-type="flex"  vs-justify="center" vs-align="center" vs-lg=" "  vs-sm=" "  >
                                        <div class="addMoreAddress">
                                            
                                        <h3 class="small-header mt-0">Primary Worksite </h3>
                                        <template v-for="(addr ,addind ) in petitionDetails['jobOpportunityInfo']['workAddresses']" >
                                            <div class="vx-row mar0" :key="addind"  >
                                        <!-- <addressFields
                                        
                                                        :formscope="'jobOpptInfo'"
                                                        :name="'PrimaryWork_Location'"
                                                        :disableCountry="true"
                                                        :addFormContainerCls="false"
                                                        :validationRequired="true"
                                                        :showaptType="true"
                                                        :countries="countries"
                                                        v-model="tempAddresses"
                                                        :cid="'Primary_Work_Location'"
                                                    /> -->
                                                    <addressFields
                                                        :formscope="'jobOpptInfo'"
                                                        :key="addind"
                                                        :name="'PrimaryWork_Location'+addind"
                                                        :disableCountry="true"
                                                        :addFormContainerCls="false"
                                                        :validationRequired="true"
                                                        :showaptType="true"
                                                        :countries="countries"
                                                        v-model="petitionDetails['jobOpportunityInfo']['workAddresses'][addind]"
                                                        :cid="'Primary_Work_Location'+addind"
                                                    />
                                                </div>
                                      </template>
                                        <div v-if="false">
                                                <template v-for="(addr ,addind ) in petitionDetails['jobOpportunityInfo']['workAddresses']" >
                                                    <div class="vx-row mar0" :key="addind"  >

                                                    
                                                        <addressFields
                                                        :formscope="'jobOpptInfo'"
                                                        :key="addind"
                                                        :name="'PrimaryWork_Location'+addind"
                                                        :disableCountry="true"
                                                        :addFormContainerCls="false"
                                                        :validationRequired="true"
                                                        :showaptType="true"
                                                        :countries="countries"
                                                        v-model="petitionDetails['jobOpportunityInfo']['workAddresses'][addind]"
                                                        :cid="'Primary_Work_Location'+addind"
                                                    />
                                                    <template >
                                                    <div class="vx-col w-full pad0">
                                                        <div class="form_group custom-radio_wrap">
                                                        <h6>Is this Work Location address?</h6>
                                                        <ul class="custom-radio" vs-type="flex" vs-align="center">
                                                            <li>
                                                            <vs-radio
                                                                @change="setWorkLocation(addind)"
                                                                :vs-name="'workLocation'+addind"
                                                                v-model="addr.workLocation"
                                                                :vs-value="true"
                                                            >Yes</vs-radio>
                                                            </li>
                                                            <li>
                                                            <vs-radio
                                                            :vs-name="'workLocation'+addind"
                                                                
                                                                v-model="addr.workLocation"
                                                                :vs-value="false"
                                                            >No</vs-radio>
                                                            </li>
                                                        </ul>
                                                        </div>
                                                    </div>
                                                    <div class="vx-col w-full p-0" v-if="false">
                                                        <div class="form_group">
                                                            <label class="form_label">Work Location/Company Name</label>
                                                        <vs-input
                                                            class="w-full"
                                                        
                                                            data-vv-as="Work Location/Company Name"
                                                            :name="'workAddressCompanyName'+addind"
                                                            v-model="addr.companyName" 
                                                        />
                                                        <span
                                                            class="text-danger text-sm"
                                                            v-show="errors.has('workAddressCompanyName')"
                                                        >{{ errors.first("workAddressCompanyName") }}</span>
                                                        </div>
                                                    </div>
                                                </template>
                                                    <span v-if="petitionDetails['jobOpportunityInfo']['workAddresses'].length>1"  @click="removeAddress(addind)" class="row_btn">
                                                        <img src="@/assets/images/main/delete-row-img.svg">
                                                    </span>
                                                    <div v-if="petitionDetails['jobOpportunityInfo']['workAddresses'].length>1 && addind !=(petitionDetails['jobOpportunityInfo']['workAddresses'].length)-1" class="divider full-divider mb-10"></div>
                                                    </div>
                                                

                                                </template>
                                            <div class="vx-row mar0" >
                                            <span @click="addAddress()" class="add-more">+ More</span>
                                            </div>
                                         </div> 
                                        </div>    
                                    </div>
                                    <div @click="jdUpdateStatusError=''" class="text-danger text-sm formerrors mt-5" v-if="jdUpdateStatusError!=''">
                                    <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ jdUpdateStatusError }} </vs-alert>
                                </div>
                                    </div>
                                    </VuePerfectScrollbar>
                                </div>
                                

                                
                            </form>
                            </div>
                            <div class="popup-footer">
                                <span class="loader" v-if="jdUpdating"><img src="@/assets/images/main/loader.gif"></span>
                                <vs-button color="dark" class="cancel" type="filled" :disabled="jdUpdating" @click="tabChanged('wageInfo', true)" >Back</vs-button>
                                <vs-button color="success" v-if="ACTIVITYCODE!='JOB_DESC_SUGGESSION'" :disabled="jdUpdating" @click="submitForm()" class="save" type="filled">Submit</vs-button>
                                <vs-button color="success" v-else :disabled="jdUpdating" @click="submitForm()" class="save" type="filled">Update</vs-button>
                                </div>
                        </div>

                </div>

            </div>
                

            <vs-popup class="holamundo main-popup" title="Comments" :active.sync="jobSuggssionComments">
                <div class="form-container mt-6">
                <div class="vx-row">

                <div class="vx-col w-full">
                <!-- <vs-textarea v-model="comments" label="Comments…" class="w-full" /> -->
                <ckeditor  v-model="comments" label="Comments…" class="w-full"  :editor="editor" :config="editorConfig"></ckeditor>

                </div>
                </div>
                </div>
                <div class="popup-footer">
                    <span class="loader" v-if="jdUpdating"><img src="@/assets/images/main/loader.gif"></span>
                    <vs-button color="dark" class="cancel" type="filled" :disabled="jdUpdating" @click="tabChanged('wageInfo')" >Back</vs-button>
                    <vs-button color="success" :disabled="jdUpdating" @click="submitForm()" class="save" type="filled">Submit</vs-button>

                </div>
            </vs-popup>
           </div> 
   
</template>
<script>
import Vue from "vue";
import immiswitchyesno from "@/views/forms/fields/switchyesno.vue";
import immiyesorno from "@/views/forms/fields/yesorno.vue";
import addressFields from "@/views/forms/fields/address.vue";
import immitextarea from "@/views/forms/fields/simpletextarea.vue";
import immitextfield from "@/views/forms/fields/simpleTextField.vue";
 import immiInput from "@/views/forms/fields/simpleinput.vue";
 import selectField from "@/views/forms/fields/simpleselect.vue";
 import datepickerField from "@/views/forms/fields/datepicker.vue";
 import VuePerfectScrollbar from "vue-perfect-scrollbar";
 import redioButtons from "@/views/forms/fields/redioButtons.vue";
import * as _ from "lodash";
import moment from "moment";
import { XIcon } from 'vue-feather-icons'
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import JQuery from "jquery";

export default {
    computed: {
        //getJobStartDate petitionDetails.applicationInfo.jobEndOn
        getJobStartDate(){
            if(this.petitionDetails['jobDetails'].applicationInfo.jobEndOn){
                try {
                    return moment(this.petitionDetails['jobDetails'].applicationInfo.jobEndOn).format("YYYY-MM-DD");
                }catch(err){
                    return new Date(); 
                }

            }else{
                return new Date();
            }

        }
        
    },
    provide() {
      return {
         parentValidator: this.$validator,
      };
  },
  created() {
    //this.$validator = this.parentValidator;
   },
    components: {
        addressFields,
        immitextarea,
        immitextfield,
        immiInput,
        selectField,
        datepickerField,
        XIcon,
       immiswitchyesno,
       immiyesorno,
       redioButtons,
       VuePerfectScrollbar
    },

    data() {
     return {
        maxWaseError:'',
        completedtabs:[],
        editor: ClassicEditor,
        editorConfig: {
         toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
        },
        settings: {
   
          wheelSpeed: 0.6,
        },
        tempAddresses: {
                aptType:'',
                companyName: "",
                line1: "",
                line2: "",
                countryId: "",
                stateId: "",
                locationId: "",
                zipcode: "",
                countryDetails: null,
                stateDetails: null,
                locationDetails: null,
                workLocation:true
            },
        comments:'',
        jobSuggssionComments:false,
        valiedjobDetailsForm:false,
        valiedwageInfoFrorm:false,
        valiedjobOpptInfoForm:false,


        newSkill:'',
        addSkill:true,
        countries: [],
        permjobDetailsPopUp:true,
        activeTab:'jobDetails',
       
        educationTypes:[],
        masterSocList:[],
        wageSourceList:['OES', 'CBA', 'Employer Conducted Survey', 'DBA', 'SCA', 'Other'],
        payFrequencyList:[ "Hour","Week","Month","Year" ],
        jdUpdateStatusError:'',
        jdUpdating:false

     }
    },
    methods: {
        minimumWageMethod(){
            let maxWagee = null
            let minWagee = null
            if(this.petitionDetails.wageOfferInfo.maxWage){
                maxWagee = this.petitionDetails.wageOfferInfo.maxWage
            }
            if(this.petitionDetails.wageOfferInfo.minWage){
                minWagee = this.petitionDetails.wageOfferInfo.minWage
            }

            if(parseInt(minWagee) > parseInt(maxWagee)){
               
                this.petitionDetails.wageOfferInfo.maxWage = null;
                this.maxWaseError ='Maximum Wage is must be greater than Minimum Wage';
            }
        },
        maximumWageMethod(){
            let maxWagee = null
            let minWagee = null
            if(this.petitionDetails.wageOfferInfo.minWage){
                minWagee = this.petitionDetails.wageOfferInfo.minWage
            }
            if(this.petitionDetails.wageOfferInfo.maxWage){
                maxWagee = this.petitionDetails.wageOfferInfo.maxWage
            }
            if(parseInt(minWagee) > parseInt(maxWagee)){
                this.petitionDetails.wageOfferInfo.minWage = null
            }
        },
        updateJobStartDate(val){
            if(val){
                let startDate = moment(val);
                if(this.petitionDetails['jobDetails'].applicationInfo.jobEndOn){
                let endDate= moment(this.petitionDetails['jobDetails'].applicationInfo.jobEndOn)
                if(startDate.isAfter(endDate , 'day')){
                    this.petitionDetails['jobDetails'].applicationInfo.jobEndOn = null
                }
                }
            }
        },
        updateDeterminationDate(val){
            if(val){
                let startDate = moment(val);
                if(this.petitionDetails['wageInfo'].expirationDate){
                let endDate= moment(this.petitionDetails['wageInfo'].expirationDate)
                if(startDate.isAfter(endDate , 'day')){
                    this.petitionDetails['wageInfo'].expirationDate = null
                }
                }
            }
        },
        setWorkLocation(indexx){
            setTimeout(()=>{
                _.map(this.petitionDetails['jobOpportunityInfo']['workAddresses'] , (item ,ind)=>{
                if(ind != indexx){
                    item.workLocation =false;
                }
                })
            });
        },
        getComments(){
            this.$validator.validateAll(this.activeTab).then((result) => {
                this.jobSuggssionComments = true;
            })

        },

        tabChanged(tab='jobDetails',back = false){
            let currentTab = _.cloneDeep(this.activeTab);
            this.maxWaseError='';

           // maximumWageMethod(); minimumWageMethod();tabChanged('wageInfo')
           if(tab =='jobOpptInfo'){
            
            this.minimumWageMethod();
            //this.maximumWageMethod(); 
            

           }
           
            this.$validator.validateAll(this.activeTab).then((result) => {
                
                /*
                    valiedjobDetailsForm:false,
                    valiedwageInfoFrorm:false,
                    valiedjobOpptInfoForm:false;
                */
                // if(tab=='jobDetails'){
                //     if(result){
                //         this.valiedjobDetailsForm =true;
                //     }else{
                //         this.valiedjobDetailsForm =false;
                //     }

                // }else if(tab=='wageInfo'){
                //     if(result){
                //         this.valiedwageInfoFrorm =true;
                //     }else{
                //         this.valiedwageInfoFrorm =false;
                //     }

                // }
                // else if(tab=='jobOpptInfo'){
                //     if(result){
                //         this.valiedjobOpptInfoForm =true;
                //     }else{
                //         this.valiedjobOpptInfoForm =false;
                //     }

                // }
                 
              
                if(result || back || this.completedtabs.indexOf(tab) > -1){
                    
                    if(result)  this.completedtabs.push(tab)
                   this.activeTab = tab;
                  
                }else{
                    const $ = JQuery;

                    if($('.text-danger:visible')){
                        $('.withTabButtons').scrollTop($('.text-danger:visible').first().parent().offset().top-50);
                     }
      
                }

        })
            // if(!this.jdUpdating){
            //     this.activeTab = tab;
            // }
            this.jdUpdateStatusError ='';
            
        },
        submitForm() {
   //alert(this.approveRejecInstructions);
        this.jdUpdateStatusError='';
     
        this.$validator.validateAll(this.activeTab).then((result) => {

           if(result && !this.filesAreuploading){
            this.jdUpdating =true;
            let path ="/perm/manage-job-description";
            let data ={
                "petitionId": "",
                "userName": "",
                "action": "", // 'CREATE_JOB_DESC','REQUEST_JOB_DESC_REVIEW', 'JOB_DESC_SUGGESSION', 'APPROVE_JOB_DESC', 'FINALIZE_JOB_DESC'
                "jobDescSuggessionType": "comments", //job_desc_update // Required for 'JOB_DESC_SUGGESSION'
                "comment": "", // Requied for jobDescSuggessionType = 'comments'
                "typeName": "",
                "subTypeName": "",
                jobDetails:{},
                wageInfo:{},
                wageOfferInfo:{},
                jobOpportunityInfo:{},
            }
            if(this.ACTIVITYCODE=='JOB_DESC_SUGGESSION'){
                data['jobDescSuggessionType'] = 'job_desc_update';
            }
            // if(this.checkProperty(this.petitionDetails['jobOpportunityInfo']['workAddresses'],'length') ==0){
            //     this.petitionDetails['jobOpportunityInfo']['workAddresses'].push(this.tempAddresses);
            // }
            data['petitionId'] = this.checkProperty( this.petitionDetails ,'_id');
            data['userName'] = this.checkProperty( this.getUserData , 'loginRoleName');
            data['action']  = this.ACTIVITYCODE; 
            data['typeName'] = this.checkProperty( this.petitionDetails , 'typeDetails','name');
            data['subTypeName'] = this.checkProperty( this.petitionDetails ,'subTypeDetails','name');              
            data['jobDetails'] = this.checkProperty( this.petitionDetails , 'jobDetails');
            data['wageInfo'] = this.checkProperty( this.petitionDetails , 'wageInfo');
            data['wageOfferInfo'] = this.checkProperty( this.petitionDetails , 'wageOfferInfo');
            data['jobOpportunityInfo'] = this.checkProperty( this.petitionDetails , 'jobOpportunityInfo');  
           
          
            this.$store.dispatch('commonAction' ,{ "data":data ,'path':path})
            .then((res)=>{
              this.showToster({message:res['message'],isError:false });
              this.hideMe();
              this.$emit("updatepetition");
            })
            .catch((error)=>{
              this.jdUpdateStatusError =error;
              this.jdUpdating =false;
             })

            

           }else{
                    const $ = JQuery;

                    if($('.text-danger:visible')){
                        $('.withTabButtons').scrollTop($('.text-danger:visible').first().parent().offset().top-50);
                     }
      
                }
        });
       },
        addNewSkill(){
            if(this.newSkill && this.newSkill.trim() !=''){
                let skil = this.newSkill.trim();
                if(this.petitionDetails['jobOpportunityInfo']['skills'].indexOf(skil) <=-1){
                    this.petitionDetails['jobOpportunityInfo']['skills'].push(skil);
                }
                
                this.newSkill ='';
                this.addSkill =false;
            }
           

        },
        removeSkill(index){
            this.petitionDetails['jobOpportunityInfo']['skills'].splice(index ,1)

        },

        updateisForiegnLangRequired(){
            if(this.checkProperty(this.petitionDetails ,'jobOpportunityInfo','isForiegnLangRequired') !='Yes'){
               
               this.petitionDetails['jobOpportunityInfo']['skills'] =[];
              
               
           }

        },
        updateisExpInAltOccuAccept(){
            
            if(this.checkProperty(this.petitionDetails ,'jobOpportunityInfo','isExpInAltOccuAccept') !='Yes'){
               
                this.petitionDetails['jobOpportunityInfo']['noOfExpMonthsInAltOccu'] =null;
                this.petitionDetails['jobOpportunityInfo']['jobTitleOfAcceptAltOccu'] ='';
                
            }

        },
        updateisAltCombOfEduAndExpAccept(){
            
            if(this.checkProperty(this.petitionDetails ,'jobOpportunityInfo','isAltCombOfEduAndExpAccept') !='Yes'){
               
                this.petitionDetails['jobOpportunityInfo']['altLevelOfEdu'] =null;
                this.petitionDetails['jobOpportunityInfo']['altAcceptExpInYears'] ='';
                
            }

        },
        updateisAltFieldOfStudyAccept(){
            
            if(this.checkProperty(this.petitionDetails ,'jobOpportunityInfo','isAltFieldOfStudyAccept') !='Yes'){
               
                this.petitionDetails['jobOpportunityInfo']['altMajorFieldOfStudy'] ='';
            }

        },
        
        updateisExpRequired(){
            
            if(this.checkProperty(this.petitionDetails ,'jobOpportunityInfo','isExpRequired') !='Yes'){
               
                this.petitionDetails['jobOpportunityInfo']['noOfExpMonths'] =null;
            }

        },
        updateIsTrainigRequired(){
            
            if(this.checkProperty(this.petitionDetails ,'jobOpportunityInfo','isTrainigRequired') !='Yes'){
               
                this.petitionDetails['jobOpportunityInfo']['noOfTraningMonths'] =null;
                this.petitionDetails['jobOpportunityInfo']['fieldOfTraining'] ='';
                
            }

        },
        addAddress(){

            let newAddress = {
                "companyName": "",
                "workLocation": false,
                line1: "",
                line2: "",
                zipcode: "",
                countryId: "231",
                stateId: "",
                locationId: "",
                "countryDetails": { "_id": "626a8f03a972fa4d60681140", "id": 231, "name": "United States", "phoneCode": 1, "order": 1, "currencySymbol": "$", "currencyCode": "USD", "zipcodeLength": 5, "sortName": "united states" },
                stateDetails: null,
                locationDetails: null,
                aptType:''
            };
            this.petitionDetails['jobOpportunityInfo']['workAddresses'].push(newAddress);
            //this.$validator.reset();

        },
        removeAddress(index){
            this.petitionDetails['jobOpportunityInfo']['workAddresses'].splice(index ,1);

        },
        hideMe(){
            this.permjobDetailsPopUp =false;
            this.$emit('hideMe');

        },
        getMasterSocList(){

        let query = {};
        query["page"] = 1;
        query["perpage"] = 10000;
        query["matcher"] = { 
            // "getInactiveListAlso": true
             };
        query["category"] = "soc_codes";
       

        this.$store
        .dispatch("getMasterData", query)
        .then((response) => {
            this.masterSocList = response.list;
            if(this.checkProperty(this.petitionDetails ,'wageInfo' ,'socCode' )){
                this.petitionDetails['wageInfo']['socCodeDetails'] = _.find(this.masterSocList, {"id": this.petitionDetails['wageInfo']['socCode']});
            }


        //alert(this.perpage);
        })
        .catch(() => {
        this.masterSocList = [];

        });

       },
       
        updateMainDegree(item){ 

            if(_.has( item ,'id')){
                this.petitionDetails['jobDetails']['minDegree'] = item['id'];
            }
        },
      
        jobOppupdateMainDegree(item){
            
            if(_.has( item ,'id')){
                this.petitionDetails['jobOpportunityInfo']['minDegree'] = item['id'];
            }
        },
        updatesocCode(item){ 

            if(_.has( item ,'id')){
            this.petitionDetails['wageInfo']['socCode'] = item['id'];
            }
        },

        //petitionDetails.jobOpportunityInfo.altLevelOfEdu
        //petitionDetails['jobOpportunityInfo'].minDegreeDetails
        getEducationList(){
            this.$store
                .dispatch("getmasterdata", "education_types")
                .then((response) => {
                    this.educationTypes = response;
                    /*
                    petitionDetails['jobDetails'].minDegreeDetails =this.petitionDetails['jobDetails']['minDegree']
                    petitionDetails.jobOpportunityInfo.altLevelOfEduDetails ===== petitionDetails.jobOpportunityInfo.altLevelOfEdu
                    petitionDetails['jobOpportunityInfo'].minDegreeDetails === this.petitionDetails['jobOpportunityInfo']['minDegree']
                    */
                  
                    

                   if(this.checkProperty(this.petitionDetails ,'jobDetails' ,'minDegree' )){
                     this.petitionDetails['jobDetails'].minDegreeDetails = _.find(this.educationTypes ,{'id':this.petitionDetails['jobDetails']['minDegree']});
                   }

                   if(this.checkProperty(this.petitionDetails ,'jobOpportunityInfo' ,'minDegree' )){
                     this.petitionDetails.jobOpportunityInfo.minDegreeDetails = _.find(this.educationTypes ,{'id':this.petitionDetails['jobOpportunityInfo']['minDegree']});
                   }

                   if(this.checkProperty(this.petitionDetails ,'jobOpportunityInfo' ,'altLevelOfEdu' )){
                     this.petitionDetails.jobOpportunityInfo.altLevelOfEduDetails = _.find(this.educationTypes ,{'id':this.petitionDetails['jobOpportunityInfo']['altLevelOfEdu']});
                   }

                });

        },

    },
    props: {
        ACTIVITYCODE: {
            type: String,
            default: null,
        },
        value: null,
        formscope:{
            type:String,
            default:''

        },

        petitionDetails: {
            type: Object,
             default: null,
        },

    },
    mounted(){
        this.getMasterSocList()
        this.activeTab = 'jobDetails';
        this.$store
            .dispatch("getmasterdata", "education_types")
            .then((response) => {
                this.educationTypes = response;
                // this.upDatehighestDegree();
            });
        this.$store.dispatch("getcountries").then(response => {
        this.countries = response;
        });


    }

}

</script>