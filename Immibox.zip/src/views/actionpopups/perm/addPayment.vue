<template>
   
    <modal
          name="addPaymentModal"
          classes="v-modal-sec"
          :min-width="200"
          :min-height="200"
          :scrollable="true"
          :reset="true"
          width="650px"
          height="auto"
        >
        <div class="v-modal profile_details_modal error-modal-space" >
          <div class="popup-header fromDetailsPage">
            <h2 class="popup-title">
              Complete Payment
            </h2>
            <span @click="showPopup=false;hideMe()">
              <em class="material-icons">close</em>
            </span>
          </div>
          <form data-vv-scope="addPaymentForm" class="relative" @submit.prevent @keydown.enter.prevent>
        <div
          class="popup_info"
         
          @click="formErrors = ''"
        >
         
          
        </div>
        <div class="form-container">
          <div class="vx-row" >
            <selectField :wrapclass="'md:w-1/2'" :required="true" :optionslist="PaymentsStatusList" v-model="newPayment.paymentStatus" @input="checkPaymentStatus($event)"  :formscope="'addPaymentForm'"  fieldName="paymentStatus" label="Payment Status" placeHolder="Payment Status"   />  
            <selectField :wrapclass="'md:w-1/2'" :required="true" :optionslist="modeofPaymentsList" v-model="newPayment.modeOfPayment"  :formscope="'addPaymentForm'"  fieldName="modeOfPayment" label="Mode of Payment" placeHolder="Mode of Payment"   />  
            <immiInput :onlyNumbers="false" :allowFloatingPoint="false" :wrapclass="'md:w-1/2'" :display="true" :cid="'referenceNumber'" :formscope="'addPaymentForm'" v-model="newPayment.referenceNumber"  :required="true" fieldName="referenceNumber" label="Reference Number" placeHolder="Reference Number" />
            <immiInput :onlyNumbers="true" :allowFloatingPoint="true"  :wrapclass="'md:w-1/2'" :disabled="isDisableAmount" :display="true" :cid="'amount'" :formscope="'addPaymentForm'" v-model="newPayment.amount"   :required="true" fieldName="amount" label="Amount($)" placeHolder="Amount" />
            <datepickerField wrapclass="md:w-1/2"    :display="true" :dateEnableTo="new Date()"  v-model="newPayment.paymentDate" :formscope="'addPaymentForm'"  fieldName="paymentDate"  label="Payment Date" :validationRequired="true"   />

            <div class="vx-col w-full">
              <div class="form_group">
                <label class="form_label">Comments<em>*</em></label>
                <!-- <vs-textarea
                  data-vv-as="Comments"
                  v-validate="'required'"
                  v-model="newPayment.comments"
                  name="comments"
                  class="w-full mb-5"
                /> -->
                <ckeditor  data-vv-as="Comments"
                  v-validate="'required'"
                  v-model="newPayment.comments"
                  name="comments"
                  class="w-full mb-5" :editor="editor" :config="editorConfig"></ckeditor>

                <span
                  class="text-danger text-sm"
                  v-show="errors.has('addPaymentForm.comments')"
                  >* Comments are required</span
                >
              </div>
            </div>
          </div>
  
          <div class="text-danger text-sm formerrors padding" v-show="formErrors">
            <vs-alert
              color="warning"
              class="warning-alert reg-warning-alert no-border-radius"
              icon-pack="IntakePortal"
              icon="IP-information-button"
              active="true"
              >{{ formErrors }}</vs-alert
            >
          </div>
          <div class="text-danger text-sm formerrors padding" v-show="PaidAmountErrorMsg">
            <vs-alert
              color="warning"
              class="warning-alert reg-warning-alert no-border-radius"
              icon-pack="IntakePortal"
              icon="IP-information-button"
              active="true"
              >{{ PaidAmountErrorMsg }}</vs-alert
            >
          </div>
        </div>
  
        <div class="popup-footer relative">
          <span class="loader" v-if="loading"
            ><img src="@/assets/images/main/loader.gif"
          /></span>
          <vs-button
            color="dark"
            @click="showPopup = false"
            class="cancel"
            type="filled"
            >Cancel</vs-button>
          <vs-button
            :disabled="loading"
            color="success"
            @click="submitRemindAction()"
            class="save"
            type="filled"
            >Submit 
          </vs-button>
        </div>
      </form>
          </div>
        </modal>  
  </template>
  <script>
  
  import moment from "moment";
  import datepickerField from "@/views/forms/fields/datepicker.vue";
  import immiInput from "@/views/forms/fields/simpleinput.vue";
 import selectField from "@/views/forms/fields/simpleselect.vue";
 import Vue from 'vue';
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';

  export default {
  provide() {
        return {
           parentValidator: this.$validator,
        };
    },
  components: {
    datepickerField,
    immiInput,
    selectField
  },
  methods: {
    checkPaymentStatus(val){
      if(val['id'] == 6){
        if(this.newPayment['amount'] && this.totalInvoiceAmountPaid ){
          let difff = this.totalInvoiceAmountPaid - this.partlyPaidAmountt
          this.newPayment.amount = difff
          this.isDisableAmount = true
        }
        else{
          this.newPayment.amount = this.totalInvoiceAmountPaid
          this.isDisableAmount = true
        }
      }
      else{
        this.isDisableAmount = false
      }
    },
    checkPaidAmount(){
      let totalInvoiceAmount = 0
      let totalPaidAmount = 0
      if(this.checkProperty(this.petitionDetails,'filingFeeDetails','feeDetails') && this.checkProperty(this.petitionDetails['filingFeeDetails'],'feeDetails','length')>0 ){
        let filingfeeList = _.cloneDeep(this.checkProperty(this.petitionDetails,'filingFeeDetails','feeDetails'))
        filingfeeList.forEach(item => {
          if(!item.invoice){
            totalInvoiceAmount += item.amount;
          }
        });
      }
      if(totalInvoiceAmount != 0){
        this.totalInvoiceAmountPaid = totalInvoiceAmount
        //alert(this.totalInvoiceAmountPaid)
      }
      if(this.checkProperty(this.petitionDetails,'filingFeeDetails','partlyPaidLogs') && this.checkProperty(this.petitionDetails['filingFeeDetails'],'partlyPaidLogs','length')>0 ){
        let filingfeeList = _.cloneDeep(this.checkProperty(this.petitionDetails,'filingFeeDetails','partlyPaidLogs'))
        filingfeeList.forEach(item => {
          totalPaidAmount += item.amount;
        });
      }
      if(totalPaidAmount != 0){
        this.partlyPaidAmountt= totalPaidAmount
      }
      
    },
    getmasterDataList(){
        this.$store.dispatch("getmasterdata", "invoice_status").then((response) => {
          let list = response
           this.PaymentsStatusList = _.filter(list,(item)=>{
            return [5,6].indexOf(item['id']) >-1
           })
        });
        this.$store.dispatch("getmasterdata", "invoice_payment_methods").then((response) => {
           this.modeofPaymentsList = response;
        });
    },
    checkPaymentValidation(){
      this.PaidAmountErrorMsg =''
      if(this.newPayment['amount'] && this.totalInvoiceAmountPaid ){
        let difff = this.totalInvoiceAmountPaid - this.partlyPaidAmountt
        if(this.newPayment['amount'] > this.totalInvoiceAmountPaid || this.newPayment['amount'] > difff ){
          this.PaidAmountErrorMsg ='You cannot pay more than due amount'
        }
        if((this.newPayment['amount'] == this.totalInvoiceAmountPaid || this.newPayment['amount'] == difff ) && this.checkProperty(this.newPayment['paymentStatus'],'id')==5  ){
          this.PaidAmountErrorMsg ='It seems your paying full amount. Change the payment status to fully paid'
        }
      }
    },
    submitRemindAction() {
        this.$validator.validateAll("addPaymentForm").then((result) => {
          this.checkPaymentValidation()
           if (result && this.PaidAmountErrorMsg == '' ) {
            let postData= {
                entityType: "case", // perm,
                invoiceId: this.checkProperty(this.petitionDetails,'invoiceId'),
                statusId: this.checkProperty(this.newPayment,'paymentStatus','id'),
                statusName: this.checkProperty(this.newPayment,'paymentStatus','name'),
                paymentDate: this.checkProperty(this.newPayment, 'paymentDate'),
                comment: this.checkProperty(this.newPayment, 'comments'),
                partlyPaidAmount: this.checkProperty(this.newPayment, 'amount'),
                paymentMethodId: this.checkProperty(this.newPayment,'modeOfPayment','id'),
                paymentRefNo: this.checkProperty(this.newPayment, 'referenceNumber'),
                typeName : this.checkProperty( this.petitionDetails , 'typeDetails','name'),
                subTypeName : this.checkProperty( this.petitionDetails ,'subTypeDetails','name'),
                petitionId : this.checkProperty( this.petitionDetails ,'_id')
            }
            if(this.checkProperty(this.petitionDetails,'subTypeDetails','id')==15){
              postData['entityType'] = "perm"
            }
            // if(this.checkProperty(this.petitionDetails,'filingFeeDetails','feeDetails') && this.checkProperty(this.petitionDetails['filingFeeDetails'],'feeDetails','length')>0 ){
            //     let filingfeeList = _.cloneDeep(this.checkProperty(this.petitionDetails,'filingFeeDetails','feeDetails'))
            //     // filingfeeList = filingfeeList.map((item)=>item.amount)
            //     let totalAmount = 0
            //     filingfeeList.forEach(item => {
            //         totalAmount += item.amount;
            //     });
                
            //     if(totalAmount == this.checkProperty(this.newPayment, 'amount') ||  this.checkProperty(this.newPayment, 'amount') > totalAmount  ){
            //         postData['statusId'] = 6
            //         postData['statusName'] = 'Paid'
            //     }
            // }
            if(this.newPayment['amount'] && this.totalInvoiceAmountPaid ){
              let difff = this.totalInvoiceAmountPaid - this.partlyPaidAmountt
              if(this.newPayment['amount'] == difff ){
                postData['statusId'] = 6
                postData['statusName'] = 'Fully Paid'
              }
            }
           let path = "/invoices/update-payment";
              this.loading =true;
              this.$store.dispatch("commonAction", {"data":postData ,"path":path}).then(response => {
               this.showPopup =false;
               
               this.showToster({message:response.message,isError:false });
                 this.loading =false;
                  this.$emit("updatepetition" ,'Fees/Invoices');
                  this.$emit("hideMe");
                                                 
             })
             .catch((error)=>{
              this.PaidAmountErrorMsg =''
               this.formErrors =error;
               this.loading =false;
             })
             
      
      
  
             
           }
         });
    },
    hideMe() {
    
        this.$emit("hideMe");
        setTimeout(()=>{
            this.$modal.hide('addPaymentModal');
        },10);
        this.PaidAmountErrorMsg =''
    },
  },
  watch: {
    showPopup(val) {
        if (!val){
            this.$emit("hideMe");
            this.$modal.hide('addPaymentModal');
        } 
    },
  },
  mounted() {
    this.PaidAmountErrorMsg =''
    this.getmasterDataList()
    this.showPopup = true;
    this.$modal.show('addPaymentModal');
    this.checkPaidAmount()
  },
  data: () => ({
    editor: ClassicEditor,
 editorConfig: {
     toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
 },
    PaidAmountErrorMsg:'',
    partlyPaidAmountt:0,
    totalInvoiceAmountPaid:0,
    isDisableAmount:false,
    PaymentsStatusList:[],
    modeofPaymentsList:[],
    newPayment:{
        paymentStatus:null,
        modeOfPayment:null,
        referenceNumber:'',
        amount:null,
        paymentDate:'',
        comments:'',
        
    },
    loading:false,
    showPopup: false,
    formErrors: null,
  }),
  props: {
    ACTIVITYCODE: {
        type: String,
        default: null,
    },
    rolesList: [],
    popUpTitle: {
        type: String,
        default: null,
    },
    petitionDetails: {
        type: Object,
        default: null,
    },
  },
  computed:{
  },
  };
  </script>
  