<template>
    <div class="custom_modal_cnt">
        <div class="modal_title">
          <h2>PERM Application</h2>
          <span class="close" @click="hideMe()"
            ><x-icon size="1.5x"></x-icon
          ></span>
        </div>
        <div class="modal_cnt">
              
              <form @submit.prevent data-vv-scope="permApplicationScope" class="trackingform">
                <div class="form-container" @click="pewResponceUpdateStatusError=''">
                  <VuePerfectScrollbar class="scrollbardoc">
                    <div class="infoSec">
                      <h4>Alien Information</h4>
                      <div class="vx-row">
                      
                      <div class="vs-col w-full"  >
                          <redioButtons
                          :wrapclass="''"
                          :cid="'isTrainigRequired'"
                          
                          formscope="permApplicationScope"
                          v-model="petitionDetails.alienInfo.isTrainigRequired"
                          fieldName="isTrainigRequired"
                          label="Is training required for the job opportunity?"
                          placeHolder=""
                          />
  
                          <redioButtons
                          :wrapclass="''"
                          :cid="'isExpRequired'"
                          
                          formscope="permApplicationScope"
                          v-model="petitionDetails.alienInfo.isExpRequired"
                          fieldName="isExpRequired"
                          label="Is experience in the job offered required for the job?"
                          placeHolder=""
                          />
  
                          <redioButtons
                          :wrapclass="''"
                          :cid="'isAltCombOfEduAndExpAccept'"
                          
                          formscope="permApplicationScope"
                          v-model="petitionDetails.alienInfo.isAltCombOfEduAndExpAccept"
                          fieldName="isAltCombOfEduAndExpAccept"
                          label="Is there an alternate combination of education and experience that is acceptable"
                          placeHolder=""
                          />
  
                          <redioButtons
                          :wrapclass="''"
                          :cid="'isExpInAltOccuAccept'"
                          
                          formscope="permApplicationScope"
                          v-model="petitionDetails.alienInfo.isExpInAltOccuAccept"
                          fieldName="isExpInAltOccuAccept"
                          label="Is experience in an alternate occupation acceptable?"
                          placeHolder=""
                          />
  
                          <redioButtons
                          :wrapclass="''"
                          :cid="'hasGainAnyExpWithEmplr'"
                          
                          formscope="permApplicationScope"
                          v-model="petitionDetails.alienInfo.hasGainAnyExpWithEmplr"
                          fieldName="hasGainAnyExpWithEmplr"
                          label="Did the alien gain any of the qualifying experience with the employer in a position substantially comparable to the job opportunity requested?"
                          placeHolder=""
                          />
  
                          <redioButtons
                          :wrapclass="''"
                          :cid="'didEmplrPayForEdu'"
                          
                          formscope="permApplicationScope"
                          v-model="petitionDetails.alienInfo.didEmplrPayForEdu"
                          fieldName="didEmplrPayForEdu"
                          label="Did the employer pay for any of the alien’s education or training necessary to satisfy any of the employer’s job requirements for this position?"
                          placeHolder=""
                          />
  
                          <redioButtons
                          :wrapclass="''"
                          :cid="'isWorkingWithPetngEmplr'"
                          
                          formscope="permApplicationScope"
                          v-model="petitionDetails.alienInfo.isWorkingWithPetngEmplr"
                          fieldName="isWorkingWithPetngEmplr"
                          label="Is the alien currently employed by the petitioning employer?"
                          placeHolder=""
                          />
                          
  
  
                    </div>
                    </div>
                    <div class="divider"></div>
                    <h4>Refiling Instructions </h4>
                    <div class="vx-row">
                        
                        <div class="vs-col w-full">
                            <redioButtons
                            :wrapclass="''"
                            :cid="'refilingInstructions'"
                            
                            formscope="permApplicationScope"
                            v-model="petitionDetails.alienInfo.refilingInstructions"
                            fieldName="refilingInstructions"
                            label="Are you seeking to utilize the filing date from a previously submitted application for Alien Employment Certification (ETA 750)?"
                            placeHolder=""
                            />
                          <datepickerField
                            wrapclass="md:w-1/2"
                            :display="true"
                            v-model="
                                petitionDetails['refilingInstructions'].prevFilingDate
                            "
                            
                            :formscope="'permApplicationScope'"
                            fieldName="prevFilingDate"
                            label="Previous filing date"
                            :validationRequired="true"
                            />
    
                        <immiInput
                        :wrapclass="'md:w-1/2'"
                      :display="true"
                      cid="prevSWAOrLocalCaseNo"
                      :formscope="'permApplicationScope'"
                      v-model="petitionDetails['refilingInstructions'].prevSWAOrLocalCaseNo"
                      :required="true"
                      fieldName="prevSWAOrLocalCaseNo"
                      label="Indicate the previous SWA or local office case number OR if not available, specify state where case was originally filed"
                      placeHolder="Previous SWA or local office case number"
                        />
    
                    
    
                    <selectField v-if="petitionDetails['refilingInstructions'].prevSWAOrLocalCaseNo" :wrapclass="'md:w-1/2'" :required="true"  cid="caseFiledStateId"  :formscope="'permApplicationScope'" :optionslist="usStatusList" v-model="petitionDetails['refilingInstructions'].caseFiledStateDetails" @input="updateState"   fieldName="caseFiledStateId" label="Specify state where case was originally filed" placeHolder="State"   />  
                            
                    
    
                        </div>
                    </div>
                    </div>
                  </VuePerfectScrollbar>      
                        
                        
              </div>
  
              
            </form> 
        </div>
        <div @click="pewResponceUpdateStatusError=''" class="text-danger text-sm formerrors" v-if="pewResponceUpdateStatusError!=''">
              <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ pewResponceUpdateStatusError }}</vs-alert>
         </div>
  
              <div class="popup-footer relative">
                  <span class="loader" v-if="pwdResUpdating"><img src="@/assets/images/main/loader.gif"></span>
                    <vs-button color="dark" class="cancel" type="filled" @click="documentModel=[]; hideMe()">Cancel</vs-button>
                    <vs-button color="success" :disabled="pwdResUpdating" @click="submitForm()" class="save" type="filled">Submit</vs-button>
                  </div>
    </div>
</template>      


<script>
    /*
     alienInfo: {
        isTrainigRequired: 'No',//String, // Yes/No // Is training required for the job opportunity?
        isExpRequired: 'No',//String, // Yes/No // Is experience in the job offered required for the job?
        isAltCombOfEduAndExpAccept:'No',// String, // Yes/No // Is there an alternate combination of education and experience that is acceptable

        isExpInAltOccuAccept:'No',// String, // Yes/No // Is experience in an alternate occupation acceptable?

        hasGainAnyExpWithEmplr: 'No',//String, // Yes/No // Did the alien gain any of the qualifying experience with the employer in a position substantially comparable to the job opportunity requested?
       
        didEmplrPayForEdu: 'No',//String, // Yes/No // Did the employer pay for any of the alien’s education or training necessary to satisfy any of the employer’s job requirements for this position?
        isWorkingWithPetngEmplr:'No',// String, // Yes/No // Is the alien currently employed by the petitioning employer?
      },
      refilingInstructions: {
          useFilingDateFromPrevSubtn: 'No',//String, // Yes/No // Are you seeking to utilize the filing date from a previously submitted Yes No Application for Alien Employment Certification (ETA 750)? 
          prevFilingDate: null ,//Date, // enter the previous filing date
          prevSWAOrLocalCaseNo: '',//String, // Indicate the previous SWA or local office case number OR if not available, specify state where case was originally filed
          caseFiledStateId: null,//Number, // Indicate the previous SWA or local office case number OR if not available, specify state where case was originally filed
          caseFiledStateDetails: null, //Object // Indicate the previous SWA or local office case number OR if not available, specify state where case was originally filed
      },
    
    */

import moment from "moment";

import * as _ from "lodash";
import immiInput from "@/views/forms/fields/simpleinput.vue";
import immitextarea from "@/views/forms/fields/simpletextarea.vue";
import selectField from "@/views/forms/fields/simpleselect.vue";
import redioButtons from "@/views/forms/fields/redioButtons.vue";
import datepickerField from "@/views/forms/fields/datepicker.vue";
import { XIcon } from 'vue-feather-icons'
import VuePerfectScrollbar from "vue-perfect-scrollbar";
export default {
provide() {
       return {
          parentValidator: this.$validator,
       };
   },
components: {
    redioButtons,
 datepickerField,
 immiInput,
 immitextarea,
 selectField,
 XIcon,
 VuePerfectScrollbar
 
},
methods: {

    updateState(item){
     if(_.has( item ,'id')){
         this.petitionDetails['refilingInstructions']['caseFiledStateId'] =item['id'];
     }
    },
   
   //usStatusList
getUsStatusList(){

       


        this.$store .dispatch("getstates", 231) .then((response) => {
      
               this.usStatusList = response;


       
        })
        .catch(() => {
        this.usStatusList = [];

        });

},
 getMasterSocList(){

           let query = {};
           query["page"] = 1;
           query["perpage"] = 10000;
           query["matcher"] = {};
           query["category"] = "soc_codes";


           this.$store
           .dispatch("getMasterData", query)
           .then((response) => {
           this.masterSocList = response.list;


           //alert(this.perpage);
           })
           .catch(() => {
           this.masterSocList = [];

           });

 },
 remove(index ,docs){
   docs.splice(index ,1);

 },
 
   
 submitForm() {
    //alert(this.approveRejecInstructions);
         this.pewResponceUpdateStatusError='';
      
         this.$validator.validateAll("permApplicationScope").then((result) => {

            if(result && !this.filesAreuploading){
             this.pwdResUpdating =true;
             let path ="/perm/manage-perm-application";
             let data ={
                petitionId:'',
                action:'',
                "typeName": "",
		        "subTypeName": "",
                alienInfo:{},
                refilingInstructions:{}

             };
            
             data['petitionId'] = this.checkProperty( this.petitionDetails ,'_id');
             data['action'] = this.ACTIVITYCODE;
             data['typeName'] = this.checkProperty( this.petitionDetails , 'typeDetails','name');
             data['subTypeName'] = this.checkProperty( this.petitionDetails ,'subTypeDetails','_id');
             data['alienInfo'] = this.checkProperty( this.petitionDetails ,'alienInfo');
             data['refilingInstructions'] = this.checkProperty( this.petitionDetails ,'refilingInstructions');
             data['refilingInstructions']['caseFiledStateDetails']['countryId'] =231;

             
            
            
             this.$store.dispatch('commonAction' ,{ "data":data ,'path':path})
             .then((res)=>{
               this.showToster({message:res['message'],isError:false });
               this.hideMe();
               this.$emit("updatepetition");
             })
             .catch((error)=>{
               this.pewResponceUpdateStatusError =error;
               this.pwdResUpdating =false;
              })

             

            }
         });
 },
 hideMe() {

   this.$emit("hideMe");
   setTimeout(()=>{
      
     },10);
 },
},
watch: {
 showPopup(val) {
   if (!val){
     this.$emit("hideMe");
    
   } 
 },
},
mounted() {

 
   this.getUsStatusList();
   this.showPopup = true;
   
 
},
data: () => ({
    usStatusList:[],
 masterSocList:[],
 pwdResUpdating:false,
 pewResponceUpdateStatusError:'',
 


 
documentTypes:["Original" ,"Electronic" ],
 documentModel:[],
 statusDocuments:[],
filesAreuploading: false,
 
 uploading: false,
 courierList: [],
 tracking: { documents: [], receiptNumber: null, receiptName: null },
 
 
 openDate: new Date().setFullYear(new Date().getFullYear()),
 startEligibleDate: new Date().setFullYear(new Date().getFullYear()),
 
 disabled_btn: false,
 showPopup: false,
 documents: [],

}),
props: {
 ACTIVITYCODE: {
   type: String,
   default: null,
 },
 petitionDetails: {
   type: Object,
   default: null,
 },
},
};
</script>

    
   