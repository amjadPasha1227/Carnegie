<template>
  
    <div class="custom_modal_cnt" v-if="petitionDetails">
      <div class="modal_title">
        <h2 >
          <template v-if="petitionDetails && petitionDetails.completedActivities.indexOf('COLLECT_ADV_EVIDENCE') >-1">Update Evidence of Advertisements</template>
          <template v-else>Collect Evidence of Advertisements</template>
          
        </h2>
        <span class="close" @click="hideMe()"
          ><x-icon size="1.5x"></x-icon
        ></span>
      </div>
        <div class="modal_cnt">
           


          <form
          data-vv-scope="permAdvetisementForm"
          @submit.prevent=""
          @keydown.enter.prevent=""
          v-if="(petitionDetails && checkProperty( petitionDetails,'recruitmentInfo'))"
        >
          <div class="form-container" @click="checkAdvertiseValidation=''">
            <VuePerfectScrollbar class="scrollbardoc">
            <div class="infoSec permAdvertisement">
               
              <div class="vx-col w-full">
              <!-- a. Occupation Type – All must complete this section. -->
              <h4>Occupation Type </h4>
              <div class="vx-row">
                <redioButtons
                  :wrapclass="''"
                  :cid="'applForProfOcc'"
                  @input="updateapplForProfOcc"
                  formscope="permAdvetisementForm"
                  v-model="petitionDetails['recruitmentInfo'].applForProfOcc"
                  fieldName="applForProfOcc"
                  label="Is this application for a professional occupation, other than a college or university teacher? Professional occupations are those for which a bachelor’s degree (or equivalent) is normally required."
                  placeHolder=""
                />
                <redioButtons
                  :wrapclass="''"
                  :cid="'applForColOrUniTeacher'"
                  @input="updateapplForColOrUniTeacher"
                  formscope="permAdvetisementForm"
                  v-model="
                    petitionDetails['recruitmentInfo'].applForColOrUniTeacher
                  "
                  fieldName="applForColOrUniTeacher"
                  label="Is this application for a college or university teacher?"
                  placeHolder="Is this application for a college or university teacher"
                />
                <redioButtons
                v-if="checkProperty(petitionDetails['recruitmentInfo'],'applForColOrUniTeacher')=='Yes'"
                :wrapclass="''"
                :cid="'selCandiadateByCompRecru'"
                
                formscope="permAdvetisementForm"
                v-model="
                  petitionDetails.recruitmentInfo.selCandiadateByCompRecru
                "
                fieldName="selCandiadateByCompRecru"
                label="Did you select the candidate using a competitive recruitment and selection process?"
                placeHolder=""
              />
              <redioButtons
              v-if="checkProperty(petitionDetails['recruitmentInfo'],'applForColOrUniTeacher')=='Yes'"
                :wrapclass="''"
                :cid="'useBasicRecruProcForProfOccu'"
               
                formscope="permAdvetisementForm"
                v-model="
                  petitionDetails.recruitmentInfo.useBasicRecruProcForProfOccu
                "
                fieldName="useBasicRecruProcForProfOccu"
                label="Did you use the basic recruitment process for professional occupations?"
                placeHolder=""
              />
              </div>
              <div class="divider"></div>
              <!-- b. Special Recruitment and Documentation Procedures for College
              and University Teachers -->
              <template v-if="checkProperty(petitionDetails['recruitmentInfo'],'applForColOrUniTeacher')=='Yes'">
              <h4>
                  Special Recruitment and Documentation Procedures for College
                  and University Teachers
                </h4>
              <div class="vx-row">
                
                <datepickerField
                  wrapclass="md:w-1/2"
                  :display="true"
                  v-model="petitionDetails['recruitmentInfo'].dateAlienSelected"
                  :formscope="'permAdvetisementForm'"
                  fieldName="dateAlienSelected"
                  label="Date of alien selected"
                  :dateEnableTo="new Date()"
                  :validationRequired="true"
                />
                <immiInput
                  :wrapclass="'md:w-1/2'"
                  :display="true"
                  cid="nameOfNationalProfJourAdvPlaced"
                  :formscope="'permAdvetisementForm'"
                  v-model="petitionDetails['recruitmentInfo'].nameOfNationalProfJourAdvPlaced"
                  :required="true"
                  fieldName="nameOfNationalProfJourAdvPlaced"
                  label="Name and date of national professional journal in which advertisement was placed"
                  placeHolder="Name and date of national professional journal in which advertisement was placed"
                />
                <!-- <datepickerField
                  wrapclass="md:w-1/2"
                  :display="true"
                  v-model="
                    petitionDetails['recruitmentInfo']
                      .dateOfNationalProfJourAdvPlaced
                  "
                  :formscope="'permAdvetisementForm'"
                  fieldName="dateOfNationalProfJourAdvPlaced"
                  label="Date of national professional journal in which advertisement was placed"
                  :validationRequired="true"
                /> -->
                <immiInput
                  :wrapclass="'md:w-1/2'"
                  :display="true"
                  cid="addiRecruInfo"
                  :formscope="'permAdvetisementForm'"
                  v-model="petitionDetails['recruitmentInfo'].addiRecruInfo"
                  :required="false"
                  fieldName="addiRecruInfo"
                  label="Specify additional recruitment information."
                  placeHolder="Additional recruitment information"
                />
              </div>
              <div class="divider"></div>
            </template>
              <!--  c. Professional/Non-Professional Information -->
              <h4>
                  Professional/Non-Professional Information
                </h4>
              <div class="vx-row">
                <datepickerField
                  wrapclass="md:w-1/2"
                  @input="checkEndDateEligibility('swaStartDate','swaEndDate') ;"
                  :display="true"
                  v-model="petitionDetails['recruitmentInfo'].swaStartDate"
                  
                  :formscope="'permAdvetisementForm'"
                  fieldName="swaStartDate"
                  label="Start date for the SWA job order"
                  :validationRequired="true"
                />
                <datepickerField
                  wrapclass="md:w-1/2"
                  :display="true"
                  v-model="petitionDetails['recruitmentInfo'].swaEndDate"
                 
                  :dateEnableFrom="checkEndDate({'dataVar':petitionDetails['recruitmentInfo'].swaStartDate})"
                  :formscope="'permAdvetisementForm'"
                  fieldName="swaEndDate"
                  label="End date for the SWA job order"
                  :validationRequired="true"
                />             
                <redioButtons
                  :wrapclass="''"
                  :cid="'hasSundayEditionOfNewsPaper'"
                  @input="updatehasSundayEditionOfNewsPaper($event)"
                  formscope="permAdvetisementForm"
                  v-model="
                    petitionDetails.recruitmentInfo.hasSundayEditionOfNewsPaper
                  "
                  fieldName="hasSundayEditionOfNewsPaper"
                  label="Is there a Sunday edition of the newspaper in the area of intended employment?"
                  placeHolder=""
                />
                <div class="advertise_dates">
                  <datepickerField
                  v-if="petitionDetails.recruitmentInfo.hasSundayEditionOfNewsPaper == 'Yes'"
                    wrapclass="md:w-1/2"
                    :display="true"
                    :dateEnableTo="new Date()"
                    v-model="
                      petitionDetails['recruitmentInfo'].startDateOfSundayNewsPaper
                    "
                    :validationRequired="petitionDetails.recruitmentInfo.hasSundayEditionOfNewsPaper == 'Yes'"
                    @input="petitionDetails['recruitmentInfo'].endDateOfSundayNewsPaper = petitionDetails['recruitmentInfo'].startDateOfSundayNewsPaper;updateStartDateOfAdvAtJobFair($event,'startDateOfSundayNewsPaper')"
                    :enableDays="[0]"
                    :formscope="'permAdvetisementForm'"
                    fieldName="startDateOfSundayNewsPaper"
                    label="Start date of Sunday edition of the newspaper"
                    
                  />
                  <datepickerField
                  v-if="petitionDetails.recruitmentInfo.hasSundayEditionOfNewsPaper == 'Yes'"
                    wrapclass="md:w-1/2"
                    :display="true"
                    :dateEnableFrom="petitionDetails['recruitmentInfo'].startDateOfSundayNewsPaper"
                    v-model="
                      petitionDetails['recruitmentInfo'].endDateOfSundayNewsPaper
                    "
                    :isDisabled="true"
                    :dateEnableTo="new Date()"
                    :formscope="'permAdvetisementForm'"
                    fieldName="endDateOfSundayNewsPaper"
                    label="End date of Sunday edition of the newspaper"
                    :validationRequired="petitionDetails['recruitmentInfo'].endDateOfSundayNewsPaper != null"
                  />
                  <span class="text-danger text-sm startDateError"  v-if="checkProperty(endDateErrors ,'startDateOfSundayNewsPaper')"> {{checkProperty(endDateErrors ,'startDateOfSundayNewsPaper')}}</span>
                </div>
               
                <vs-col :class="{'form-desabled': checkDocumentEnable({'startKey':petitionDetails['recruitmentInfo'].startDateOfSundayNewsPaper,'endKey':petitionDetails['recruitmentInfo'].endDateOfSundayNewsPaper,'documentKey':'sunday'}) }" 
                 v-if="petitionDetails.recruitmentInfo.hasSundayEditionOfNewsPaper == 'Yes'"  vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12">
                 
                 <casedocumentslist @emitUploadingAction="emitUploadingAction" :docMainCategory="'sunday'" :showTitle="false" :docslist="sunday" :deleteDocPermenantly="true" formscope="permAdvetisementForm" :fieldsArray="[]" v-model="petitionDetails['recruitmentInfo']['documents']"></casedocumentslist>
                </vs-col>
                <immiInput
                  :wrapclass="'md:w-1/2'"
                  :display="true"
                  cid="nameOfNewsPaperFirstAdvPlaced"
                  :formscope="'permAdvetisementForm'"
                  v-model="
                    petitionDetails['recruitmentInfo']
                      .nameOfNewsPaperFirstAdvPlaced
                  "
                  :required="true"
                  fieldName="nameOfNewsPaperFirstAdvPlaced"
                  label="Name of newspaper (of general circulation) in which the first advertisement was placed"
                  placeHolder="Name of newspaper"
                />
                <datepickerField
                  wrapclass="md:w-1/2"
                  :display="true"
                  :dateEnableTo="new Date()"
                  v-model="
                    petitionDetails['recruitmentInfo'].dateOfFirstAdvtIdentified
                  "
                  @input="updatedateOfFirstAdvtIdentified($event)"
                  :formscope="'permAdvetisementForm'"
                  fieldName="dateOfFirstAdvtIdentified"
                  label="Date of first advertisement identified"
                  :validationRequired="true"
                />
                <immiInput
                  :wrapclass="'md:w-1/2'"
                  :display="true"
                  cid="nameOfNewsPaperOrJourSecondAdvPlaced"
                  :formscope="'permAdvetisementForm'"
                  v-model=" petitionDetails['recruitmentInfo'].nameOfNewsPaperOrJourSecondAdvPlaced
                  "
                  :required="false"
                  fieldName="nameOfNewsPaperOrJourSecondAdvPlaced"
                  label="Name of newspaper or professional journal (if applicable) in which second advertisement was placed"
                  placeHolder="Name of newspaper"
                />

                <immiInput
                  :wrapclass="'md:w-1/2'"
                  :display="true"
                  cid="isNewsPaperOrJournal"
                  :formscope="'permAdvetisementForm'"
                  v-model="
                    petitionDetails['recruitmentInfo'].isNewsPaperOrJournal
                  "
                  :required="checkProperty(petitionDetails ,'recruitmentInfo' ,'nameOfNewsPaperOrJourSecondAdvPlaced')?true:false"
                  fieldName="isNewsPaperOrJournal"
                  label="Is it Newspaper/Journal?"
                  placeHolder="Newspaper/Journal"
                />
                <datepickerField
                  wrapclass="md:w-1/2"
                  :display="true"
                  v-model="
                    petitionDetails['recruitmentInfo'].dateOfSecondAdvIdentified
                  "
                  :dateEnableTo="new Date()"
                  :formscope="'permAdvetisementForm'"
                  fieldName="dateOfSecondAdvIdentified"
                  label="Date of second newspaper advertisement or date of publication of journal identified"
                  :validationRequired="false"
                />
              </div>
              <div class="divider"></div>
              <!-- d. Professional Recruitment Information -->
              <h4 id="professional_advert">
                  Professional Recruitment Information
                </h4>
              <div class="vx-row Professional_info_blocks">
                <div class="Professional_info_block">
                  <div class="advertise_dates">
                    <datepickerField
                      wrapclass="md:w-1/2"
                      :display="true"
                      v-model="
                        petitionDetails['recruitmentInfo'].startDateOfAdvAtJobFair
                      "
                      @input="checkEndDateEligibility('startDateOfAdvAtJobFair','endDateOfAdvAtJobFair')"
                      :validationRequired="petitionDetails['recruitmentInfo'].endDateOfAdvAtJobFair != null"
                      :formscope="'permAdvetisementForm'"
                      fieldName="startDateOfAdvAtJobFair"
                      label="Start date of advertised at job fair"
                    />
                    <datepickerField
                      wrapclass="md:w-1/2"  
                      :display="true"
                      v-model="
                        petitionDetails['recruitmentInfo'].endDateOfAdvAtJobFair
                      "
                      ref="endDateOfAdvAtJobFairr"
                      @input="updateStartDateOfAdvAtJobFair($event,'endDateOfAdvAtJobFair')"
                      :dateEnableFrom="checkEndDate({'dataVar':petitionDetails['recruitmentInfo'].startDateOfAdvAtJobFair})"
                      :validationRequired="petitionDetails['recruitmentInfo'].startDateOfAdvAtJobFair != null"
                      :formscope="'permAdvetisementForm'"
                      fieldName="endDateOfAdvAtJobFair"
                      label="End date of advertised at job fair"
                    />
                    <span class="text-danger text-sm"  v-if="checkProperty(endDateErrors ,'endDateOfAdvAtJobFair')"> {{checkProperty(endDateErrors ,'endDateOfAdvAtJobFair')}}</span>
                  </div>
                  <vs-col :class="{'form-desabled': checkDocumentEnable({'startKey':petitionDetails['recruitmentInfo'].startDateOfAdvAtJobFair,'endKey':petitionDetails['recruitmentInfo'].endDateOfAdvAtJobFair}) }"
                   class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12">
                    <casedocumentslist @emitUploadingAction="emitUploadingAction" :docMainCategory="'jobFair'" :showTitle="false" :docslist="jobFair" :deleteDocPermenantly="true" formscope="permAdvetisementForm" :fieldsArray="[]" v-model="petitionDetails['recruitmentInfo']['documents']"></casedocumentslist>
                  </vs-col>
                </div>
                <div class="Professional_info_block">
                  <div class="advertise_dates">
                  <datepickerField
                    wrapclass="md:w-1/2"
                    :display="true"
                    v-model="
                      petitionDetails['recruitmentInfo'].startDateOfNonCampusRecru
                    "
                    @input="checkEndDateEligibility('startDateOfNonCampusRecru','endDateOfNonCampusRecru')"
                    :validationRequired="petitionDetails['recruitmentInfo'].endDateOfNonCampusRecru != null"
                    :formscope="'permAdvetisementForm'"
                    fieldName="startDateOfNonCampusRecru"
                    label="Start date of on-campus recruiting"
                  />
                  <datepickerField
                    wrapclass="md:w-1/2"
                    :display="true"
                    v-model="
                      petitionDetails['recruitmentInfo'].endDateOfNonCampusRecru
                    "
                    @input="updateStartDateOfAdvAtJobFair($event,'endDateOfNonCampusRecru')"
                    :validationRequired="petitionDetails['recruitmentInfo'].startDateOfNonCampusRecru != null"
                    :dateEnableFrom="checkEndDate({'dataVar':petitionDetails['recruitmentInfo'].startDateOfNonCampusRecru})"
                    :formscope="'permAdvetisementForm'"
                    fieldName="endDateOfNonCampusRecru"
                    label="End date of on-campus recruiting"
                  />
                  <span class="text-danger text-sm "  v-if="checkProperty(endDateErrors ,'endDateOfNonCampusRecru')"> {{checkProperty(endDateErrors ,'endDateOfNonCampusRecru')}}</span>
                  </div>
                  <vs-col :class="{'form-desabled': checkDocumentEnable({'startKey':petitionDetails['recruitmentInfo'].startDateOfNonCampusRecru,'endKey':petitionDetails['recruitmentInfo'].endDateOfNonCampusRecru}) }"
                   class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12">
                    <casedocumentslist @emitUploadingAction="emitUploadingAction" :docMainCategory="'campusRecruitment'" :showTitle="false" :docslist="campusRecruitment" :deleteDocPermenantly="true" formscope="permAdvetisementForm" :fieldsArray="[]" v-model="petitionDetails['recruitmentInfo']['documents']"></casedocumentslist>
                  </vs-col>
                </div>
                <div class="Professional_info_block">
                  <div class="advertise_dates">
                    <datepickerField
                      wrapclass="md:w-1/2"
                      :display="true"
                      v-model="
                        petitionDetails['recruitmentInfo'].startDateOfEmplrWebsitePosted
                      "
                        @input="checkEndDateEligibility('startDateOfEmplrWebsitePosted','endDateOfEmplrWebsitePosted')"
                        :validationRequired="petitionDetails['recruitmentInfo'].endDateOfEmplrWebsitePosted != null"
                      :formscope="'permAdvetisementForm'"
                      fieldName="startDateOfEmplrWebsitePosted"
                      label="Start date posted on employer website"
                 
                    />
                    <datepickerField
                      wrapclass="md:w-1/2"
                      :display="true"
                      v-model="
                        petitionDetails['recruitmentInfo']
                          .endDateOfEmplrWebsitePosted
                      "
                      @input="updateStartDateOfAdvAtJobFair($event,'endDateOfEmplrWebsitePosted')"
                      :dateEnableFrom="checkEndDate({'dataVar':petitionDetails['recruitmentInfo'].startDateOfEmplrWebsitePosted})"
                      :formscope="'permAdvetisementForm'"
                      fieldName="endDateOfEmplrWebsitePosted"
                      label="End date posted on employer website"
                      :validationRequired="petitionDetails['recruitmentInfo'].startDateOfEmplrWebsitePosted != null"
                    />
                    <span class="text-danger text-sm"  v-if="checkProperty(endDateErrors ,'endDateOfEmplrWebsitePosted')"> {{checkProperty(endDateErrors ,'endDateOfEmplrWebsitePosted')}}</span>
                  </div>  
                  <vs-col :class="{'form-desabled': checkDocumentEnable({'startKey':petitionDetails['recruitmentInfo'].startDateOfEmplrWebsitePosted,'endKey':petitionDetails['recruitmentInfo'].endDateOfEmplrWebsitePosted}) }"
                   class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12">
                    <casedocumentslist @emitUploadingAction="emitUploadingAction" :docMainCategory="'empWebsite'"  :showTitle="false" :docslist="empWebsite" :deleteDocPermenantly="true" formscope="permAdvetisementForm" :fieldsArray="[]" v-model="petitionDetails['recruitmentInfo']['documents']"></casedocumentslist>                     
                  </vs-col>
                </div>
                <div class="Professional_info_block">
                  <div class="advertise_dates">
                    <datepickerField
                      wrapclass="md:w-1/2"
                      :display="true"
                      v-model="
                        petitionDetails['recruitmentInfo']
                          .startDateOfAdvWithTradeOrProfOrg
                      "
                      :validationRequired="petitionDetails['recruitmentInfo'].endDateOfAdvWithTradeOrProfOrg != null"
                      @input="checkEndDateEligibility('startDateOfAdvWithTradeOrProfOrg','endDateOfAdvWithTradeOrProfOrg')"
                      :formscope="'permAdvetisementForm'"
                      fieldName="startDateOfAdvWithTradeOrProfOrg"
                      label="Start date advertised with trade or professional organization"
                    />
                    <datepickerField
                      wrapclass="md:w-1/2"
                      :display="true"
                      v-model="
                        petitionDetails['recruitmentInfo']
                          .endDateOfAdvWithTradeOrProfOrg
                      "
                      @input="updateStartDateOfAdvAtJobFair($event,'endDateOfAdvWithTradeOrProfOrg')"
                      :dateEnableFrom="checkEndDate({'dataVar':petitionDetails['recruitmentInfo'].startDateOfAdvWithTradeOrProfOrg})"
                      :validationRequired="petitionDetails['recruitmentInfo'].startDateOfAdvWithTradeOrProfOrg != null"
                      :formscope="'permAdvetisementForm'"
                      fieldName="endDateOfAdvWithTradeOrProfOrg"
                      label="End date advertised with trade or professional organization"
                    />
                    <span class="text-danger text-sm"  v-if="checkProperty(endDateErrors ,'endDateOfAdvWithTradeOrProfOrg')"> {{checkProperty(endDateErrors ,'endDateOfAdvWithTradeOrProfOrg')}}</span>
                  </div>  
                  <vs-col :class="{'form-desabled': checkDocumentEnable({'startKey':petitionDetails['recruitmentInfo'].startDateOfAdvWithTradeOrProfOrg,'endKey':petitionDetails['recruitmentInfo'].endDateOfAdvWithTradeOrProfOrg}) }"
                   class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12">
                    <casedocumentslist @emitUploadingAction="emitUploadingAction" :docMainCategory="'profOrgOrTrade'" :showTitle="false" :docslist="profOrgOrTrade" :deleteDocPermenantly="true" formscope="permAdvetisementForm" :fieldsArray="[]" v-model="petitionDetails['recruitmentInfo']['documents']"></casedocumentslist>
                  </vs-col>
                </div>
                <div class="Professional_info_block">
                  <div class="advertise_dates">
                    <datepickerField
                      wrapclass="md:w-1/2"
                      :display="true"
                      v-model="
                        petitionDetails['recruitmentInfo'].startDateOfListedInJobSite
                      "
                      @input="checkEndDateEligibility('startDateOfListedInJobSite','endDateOfListedInJobSite')"
                      :formscope="'permAdvetisementForm'"
                      fieldName="startDateOfListedInJobSite"
                      label="Start date listed with job search website"
                      :validationRequired="petitionDetails['recruitmentInfo'].endDateOfListedInJobSite != null"
                    />
                    <datepickerField
                      wrapclass="md:w-1/2"
                      :display="true"
                      v-model="
                        petitionDetails['recruitmentInfo'].endDateOfListedInJobSite
                      "
                      @input="updateStartDateOfAdvAtJobFair($event,'endDateOfListedInJobSite')"
                      :dateEnableFrom="checkEndDate({'dataVar':petitionDetails['recruitmentInfo'].startDateOfListedInJobSite})"
                      :formscope="'permAdvetisementForm'"
                      fieldName="endDateOfListedInJobSite"
                      label="End date listed with job search website"
                      :validationRequired="petitionDetails['recruitmentInfo'].startDateOfListedInJobSite != null"
                    />
                    <span class="text-danger text-sm"  v-if="checkProperty(endDateErrors ,'endDateOfListedInJobSite')"> {{checkProperty(endDateErrors ,'endDateOfListedInJobSite')}}</span>
                  </div>
                  <vs-col :class="{'form-desabled': checkDocumentEnable({'startKey':petitionDetails['recruitmentInfo'].startDateOfListedInJobSite,'endKey':petitionDetails['recruitmentInfo'].endDateOfListedInJobSite}) }"
                   class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12">
                    <casedocumentslist @emitUploadingAction="emitUploadingAction" :docMainCategory="'jobSearchWebsite'" :showTitle="false" :docslist="jobSearchWebsite" :deleteDocPermenantly="true" formscope="permAdvetisementForm" :fieldsArray="[]" v-model="petitionDetails['recruitmentInfo']['documents']"></casedocumentslist>
                  </vs-col>
                </div>
                <div class="Professional_info_block">
                  <div class="advertise_dates">
                    <datepickerField
                      wrapclass="md:w-1/2"
                      :display="true"
                      v-model="
                        petitionDetails['recruitmentInfo'].startDateOfListedInPrivateEmpFirm
                      "
                      :validationRequired="petitionDetails['recruitmentInfo'].endDateOfListedInPrivateEmpFirm != null"
                      @input="checkEndDateEligibility('startDateOfListedInPrivateEmpFirm','endDateOfListedInPrivateEmpFirm')"
                      :formscope="'permAdvetisementForm'"
                      fieldName="startDateOfListedInPrivateEmpFirm"
                      label="Start date listed with private employment firm"
                    />
                    <datepickerField
                      wrapclass="md:w-1/2"
                      :display="true"
                      v-model="
                        petitionDetails['recruitmentInfo']
                          .endDateOfListedInPrivateEmpFirm
                      "
                      @input="updateStartDateOfAdvAtJobFair($event,'endDateOfListedInPrivateEmpFirm')"
                      :dateEnableFrom="checkEndDate({'dataVar':petitionDetails['recruitmentInfo'].startDateOfListedInPrivateEmpFirm})"
                      :validationRequired="petitionDetails['recruitmentInfo'].startDateOfListedInPrivateEmpFirm != null"
                      :formscope="'permAdvetisementForm'"
                      fieldName="endDateOfListedInPrivateEmpFirm"
                      label="End date listed with private employment firm"
                    />
                    <span class="text-danger text-sm"  v-if="checkProperty(endDateErrors ,'endDateOfListedInPrivateEmpFirm')"> {{checkProperty(endDateErrors ,'endDateOfListedInPrivateEmpFirm')}}</span>
                  </div>
                  <vs-col :class="{'form-desabled': checkDocumentEnable({'startKey':petitionDetails['recruitmentInfo'].startDateOfListedInPrivateEmpFirm,'endKey':petitionDetails['recruitmentInfo'].endDateOfListedInPrivateEmpFirm}) }"
                   class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12">
                    <casedocumentslist  @emitUploadingAction="emitUploadingAction" :docMainCategory="'pvtEmpmtFirm'"  :showTitle="false" :docslist="pvtEmpmtFirm" :deleteDocPermenantly="true" formscope="permAdvetisementForm" :fieldsArray="[]" v-model="petitionDetails['recruitmentInfo']['documents']"></casedocumentslist>
                  </vs-col>
                </div>
                <div class="Professional_info_block">
                  <div class="advertise_dates">
                    <datepickerField
                      wrapclass="md:w-1/2"
                      :display="true"
                      v-model="
                        petitionDetails['recruitmentInfo'].startDateOfAdvEmpRefProgram
                      "
                      :validationRequired="petitionDetails['recruitmentInfo'].endDateOfAdvEmpRefProgram != null"
                      @input="checkEndDateEligibility('startDateOfAdvEmpRefProgram','endDateOfAdvEmpRefProgram')"
                      :formscope="'permAdvetisementForm'"
                      fieldName="startDateOfAdvEmpRefProgram"
                      label="Start date advertised with employee referral program"
                    />
                    <datepickerField
                      wrapclass="md:w-1/2"
                      :display="true"
                      v-model="
                        petitionDetails['recruitmentInfo'].endDateOfAdvEmpRefProgram
                      "
                      @input="updateStartDateOfAdvAtJobFair($event,'endDateOfAdvEmpRefProgram')"
                      :dateEnableFrom="checkEndDate({'dataVar':petitionDetails['recruitmentInfo'].startDateOfAdvEmpRefProgram})"
                      :validationRequired="petitionDetails['recruitmentInfo'].startDateOfAdvEmpRefProgram != null"
                      :formscope="'permAdvetisementForm'"
                      fieldName="endDateOfAdvEmpRefProgram"
                      label="End date advertised with employee referral program"
                    />
                    <span class="text-danger text-sm"  v-if="checkProperty(endDateErrors ,'endDateOfAdvEmpRefProgram')"> {{checkProperty(endDateErrors ,'endDateOfAdvEmpRefProgram')}}</span>
                  </div>  
                  <vs-col :class="{'form-desabled': checkDocumentEnable({'startKey':petitionDetails['recruitmentInfo'].startDateOfAdvEmpRefProgram,'endKey':petitionDetails['recruitmentInfo'].endDateOfAdvEmpRefProgram}) }"
                   class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12">
                    <casedocumentslist  @emitUploadingAction="emitUploadingAction" :docMainCategory="'empRefProgram'"  :showTitle="false" :docslist="empRefProgram" :deleteDocPermenantly="true" formscope="permAdvetisementForm" :fieldsArray="[]" v-model="petitionDetails['recruitmentInfo']['documents']"></casedocumentslist>
                  </vs-col>
                </div>
                <div class="Professional_info_block">
                  <div class="advertise_dates">
                    <datepickerField
                      wrapclass="md:w-1/2"
                      :display="true"
                      v-model="
                        petitionDetails['recruitmentInfo'].startDateOfAdvCampusPlacOfc
                      "
                      :validationRequired="petitionDetails['recruitmentInfo'].endDateOfAdvCampusPlacOfc != null"
                      @input="checkEndDateEligibility('startDateOfAdvCampusPlacOfc','endDateOfAdvCampusPlacOfc')"
                      :formscope="'permAdvetisementForm'"
                      fieldName="startDateOfAdvCampusPlacOfc"
                      label="Start date advertised with campus placement office"
                    />
                    <datepickerField
                      wrapclass="md:w-1/2"
                      :display="true"
                      v-model="
                        petitionDetails['recruitmentInfo'].endDateOfAdvCampusPlacOfc
                      "
                      @input="updateStartDateOfAdvAtJobFair($event,'endDateOfAdvCampusPlacOfc')"
                      :dateEnableFrom="checkEndDate({'dataVar':petitionDetails['recruitmentInfo'].startDateOfAdvCampusPlacOfc})"
                      :validationRequired="petitionDetails['recruitmentInfo'].startDateOfAdvCampusPlacOfc != null"
                      :formscope="'permAdvetisementForm'"
                      fieldName="endDateOfAdvCampusPlacOfc"
                      label="End date advertised with campus placement office"
                    /> 
                    <span class="text-danger text-sm"  v-if="checkProperty(endDateErrors ,'endDateOfAdvCampusPlacOfc')"> {{checkProperty(endDateErrors ,'endDateOfAdvCampusPlacOfc')}}</span>
                  </div>
                  <vs-col :class="{'form-desabled': checkDocumentEnable({'startKey':petitionDetails['recruitmentInfo'].startDateOfAdvCampusPlacOfc,'endKey':petitionDetails['recruitmentInfo'].endDateOfAdvCampusPlacOfc}) }" 
                   class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12">
                    <casedocumentslist @emitUploadingAction="emitUploadingAction" :docMainCategory="'campusPlacement'" :showTitle="false" :docslist="campusPlacement" :deleteDocPermenantly="true" formscope="permAdvetisementForm" :fieldsArray="[]" v-model="petitionDetails['recruitmentInfo']['documents']"></casedocumentslist>
                  </vs-col>
                </div>
                <div class="Professional_info_block">
                  <div class="advertise_dates">
                    <datepickerField
                      wrapclass="md:w-1/2"
                      :display="true"
                      v-model="
                        petitionDetails['recruitmentInfo'].startDateOfAdvLocalNewsPaper
                      "
                      @input="petitionDetails['recruitmentInfo'].endDateOfAdvLocalNewsPaper = petitionDetails['recruitmentInfo'].startDateOfAdvLocalNewsPaper;updateStartDateOfAdvAtJobFair($event,'startDateOfAdvLocalNewsPaper')"
                    
                      :formscope="'permAdvetisementForm'"
                      fieldName="startDateOfAdvLocalNewsPaper"
                      label="Start date advertised with local or ethnic newspaper"
                    />
                    <!-- updatestartDateOfAdvLocalNewsPaper($event) -->
                    <datepickerField
                      wrapclass="md:w-1/2"
                      :display="true"
                      v-model="
                        petitionDetails['recruitmentInfo'].endDateOfAdvLocalNewsPaper
                      "

                      :isDisabled="true"
                      :dateEnableFrom="
                        petitionDetails.recruitmentInfo.startDateOfAdvLocalNewsPaper
                      "
                      :formscope="'permAdvetisementForm'"
                      fieldName="endDateOfAdvLocalNewsPaper"
                      label="End date advertised with local or ethnic newspaper"

                    />
                    <span class="text-danger text-sm startDateError"  v-if="checkProperty(endDateErrors ,'startDateOfAdvLocalNewsPaper')"> {{checkProperty(endDateErrors ,'startDateOfAdvLocalNewsPaper')}}</span>
                  </div>
                  <vs-col :class="{'form-desabled': checkDocumentEnable({'startKey':petitionDetails['recruitmentInfo'].startDateOfAdvLocalNewsPaper,'endKey':petitionDetails['recruitmentInfo'].endDateOfAdvLocalNewsPaper}) }" 
                   class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12">
                    <casedocumentslist @emitUploadingAction="emitUploadingAction" :docMainCategory="'localNewsPaper'" :showTitle="false" :docslist="localNewsPaper" :deleteDocPermenantly="true" formscope="permAdvetisementForm" :fieldsArray="[]" v-model="petitionDetails['recruitmentInfo']['documents']"></casedocumentslist>
                  </vs-col>
                </div>
                <div class="Professional_info_block">
                  <div class="advertise_dates">
                    <datepickerField
                      wrapclass="md:w-1/2"
                      :display="true"
                      v-model="
                        petitionDetails['recruitmentInfo'].startDateOfAdvInTVOrRadio
                      "
                      @input="petitionDetails['recruitmentInfo'].endDateOfAdvInTVOrRadio = petitionDetails['recruitmentInfo'].startDateOfAdvInTVOrRadio;updateStartDateOfAdvAtJobFair($event,'startDateOfAdvInTVOrRadio') "
                      
                      :formscope="'permAdvetisementForm'"
                      fieldName="startDateOfAdvInTVOrRadio"
                      label="Start date advertised with radio or TV ads"
                    />
                    <!-- updatestartDateOfAdvInTVOrRadio($event) -->
                    <datepickerField
                      wrapclass="md:w-1/2"
                      :display="true"
                      v-model="
                        petitionDetails['recruitmentInfo'].endDateOfAdvInTVOrRadio
                      "
                      :dateEnableFrom="
                        petitionDetails['recruitmentInfo'].startDateOfAdvInTVOrRadio
                      "
                      :isDisabled="true"
                      :formscope="'permAdvetisementForm'"
                      fieldName="endDateOfAdvInTVOrRadio"
                      label="End date advertised with radio or TV ads"
                    />
                    <span class="text-danger text-sm startDateError"  v-if="checkProperty(endDateErrors ,'startDateOfAdvInTVOrRadio')"> {{checkProperty(endDateErrors ,'startDateOfAdvInTVOrRadio')}}</span>
                  </div>  
                  <vs-col :class="{'form-desabled': checkDocumentEnable({'startKey':petitionDetails['recruitmentInfo'].startDateOfAdvInTVOrRadio,'endKey':petitionDetails['recruitmentInfo'].endDateOfAdvInTVOrRadio}) }" 
                   class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12">
                    <casedocumentslist  @emitUploadingAction="emitUploadingAction" :docMainCategory="'tvAds'" :showTitle="false" :docslist="tvAds" :deleteDocPermenantly="true" formscope="permAdvetisementForm" :fieldsArray="[]" v-model="petitionDetails['recruitmentInfo']['documents']"></casedocumentslist>
                  </vs-col>
                </div>
              </div>
              <div class="divider"></div>
              <h4>
                Inter Office Memorandum
                </h4>
                <div class="vx-row">
                  <datepickerField
                      wrapclass="md:w-1/2"
                      :display="true"
                      v-model="
                        petitionDetails['recruitmentInfo'].startDateOfPostedIntrOfcMemorandum
                      "
                      :validationRequired="petitionDetails['recruitmentInfo'].endDateOfPostedIntrOfcMemorandum != null"
                      @input="updateSignedDate($event,'endDateOfPostedIntrOfcMemorandum')"
                      :formscope="'permAdvetisementForm'"
                      fieldName="startDateOfPostedIntrOfcMemorandum"
                      label="Start date "
                    />
                    <datepickerField 
                      wrapclass="md:w-1/2"
                      :display="true"
                      v-model="
                        petitionDetails['recruitmentInfo'].endDateOfPostedIntrOfcMemorandum    
                      "
                      :dateEnableFrom="
                        petitionDetails['recruitmentInfo'].startDateOfPostedIntrOfcMemorandum
                      "
                      :validationRequired="petitionDetails['recruitmentInfo'].startDateOfPostedIntrOfcMemorandum != null"
                      :formscope="'permAdvetisementForm'"
                      fieldName="endDateOfPostedIntrOfcMemorandum"
                      label="End date "
                    />
                   
                    <vs-col :class="{'form-desabled': checkDocumentEnable({'startKey':petitionDetails['recruitmentInfo'].startDateOfPostedIntrOfcMemorandum,'endKey':petitionDetails['recruitmentInfo'].endDateOfPostedIntrOfcMemorandum}) }"
                     class="" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12">
                      <casedocumentslist @emitUploadingAction="emitUploadingAction" :docMainCategory="'intrOfcMemomandum'" :showTitle="false" :docslist="intrOfcMemomandum" :deleteDocPermenantly="true" formscope="permAdvetisementForm" :fieldsArray="[]" v-model="petitionDetails['recruitmentInfo']['documents']"></casedocumentslist>
                    </vs-col>
                </div>

              <!-- <div class="vx-row">
                
                <vs-col  class="" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12">
                  <casedocumentslist :showTitle="false" :docslist="recruReportSummary" :deleteDocPermenantly="true" formscope="permAdvetisementForm" :fieldsArray="[]" v-model="petitionDetails['recruitmentInfo']['documents']"></casedocumentslist>
                </vs-col>
                <vs-col  class="" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12">
                  <casedocumentslist :showTitle="false" :docslist="busNecLetterByEplr" :deleteDocPermenantly="true" formscope="permAdvetisementForm" :fieldsArray="[]" v-model="petitionDetails['recruitmentInfo']['documents']"></casedocumentslist>
                </vs-col>
              </div> -->
              <div class="divider"></div>
              <!-- e. General Information -->
              <h4>General Information</h4>
              <div class="vx-row">
                <redioButtons
                  :wrapclass="''"
                  :cid="'hasEmplrRecPayForSubAppl'"
                  @input="updatehasEmplrRecPayForSubAppl"
                  formscope="permAdvetisementForm"
                  v-model="
                    petitionDetails.recruitmentInfo.hasEmplrRecPayForSubAppl
                  "
                  fieldName="hasEmplrRecPayForSubAppl"
                  label="Has the employer received payment of any kind for the submission of this application?"
                  placeHolder=""
                />
                <immiInput
                 v-if="checkProperty(petitionDetails['recruitmentInfo'],'hasEmplrRecPayForSubAppl')=='Yes'"
                  :wrapclass="''"
                  :display="true"
                  cid="amountRecivedPurposeAndDateForSubAppl"
                  :formscope="'permAdvetisementForm'"
                  v-model="
                    petitionDetails['recruitmentInfo']
                      .amountRecivedPurposeAndDateForSubAppl
                  "
                  :required="true"
                  fieldName="amountRecivedPurposeAndDateForSubAppl"
                  label="Describe details of the payment including the amount, date and purpose of the payment"
                  placeHolder="Details of the payment including the amount, date and purpose of the payment"
                />

                <redioButtons
                  :wrapclass="''"
                  :cid="'hasBargainRepreForWorkerInOccu'"
                  :showNA="true"
                  @input="updatehasBargainRepreForWorkerInOccu"
                  formscope="permAdvetisementForm"
                  v-model="
                    petitionDetails.recruitmentInfo
                      .hasBargainRepreForWorkerInOccu
                  "
                  fieldName="hasBargainRepreForWorkerInOccu"
                  label="Has the bargaining representative for workers in the occupation in which the alien will be employed been provided with notice of this filing at least 30 days but not more than 180 days before the date the application is filed?"
                  placeHolder=""
                />

                <redioButtons
                  :wrapclass="''"
                  :cid="'noBargainRepreHasNotice'"
                  :showNA="true"
                  @input="updatenoBargainRepreHasNotice"
                  formscope="permAdvetisementForm"
                  v-model="
                    petitionDetails.recruitmentInfo.noBargainRepreHasNotice
                  "
                  fieldName="noBargainRepreHasNotice"
                  label="If there is no bargaining representative, has a notice of this filing been posted for 10 business days in a conspicuous location at the place of employment, ending at least 30 days before but not more than 180 days before the date the application is filed?"
                  placeHolder=""
                />
                <redioButtons
                  :wrapclass="''"
                  :cid="'hasEmplrHadLayoffInArea'"
                  @input="updatehasEmplrHadLayoffInArea"
                  formscope="permAdvetisementForm"
                  v-model="
                    petitionDetails.recruitmentInfo.hasEmplrHadLayoffInArea
                  "
                  fieldName="hasEmplrHadLayoffInArea"
                  label="Has the employer had a layoff in the area of intended employment in the occupation involved in this application or in a related occupation within the six months immediately preceding the filing of this application?"
                  placeHolder=""
                />
                <redioButtons
                  v-if="
                    checkProperty(
                      petitionDetails,
                      'recruitmentInfo',
                      'hasEmplrHadLayoffInArea'
                    ) == 'Yes'
                  "
                  :wrapclass="''"
                  :cid="'wereLaidOffUSWorker'"
                  :showNA="true"
                   @input="updatewereLaidOffUSWorker" 
                  formscope="permAdvetisementForm"
                  v-model="petitionDetails.recruitmentInfo.wereLaidOffUSWorker"
                  fieldName="wereLaidOffUSWorker"
                  label="Were the laid off U.S. workers notified and considered for the job opportunity for which certification is sought?"
                  placeHolder=""
                />
                <!-- <vs-col class="m-auto float-none" vs-type="flex" vs-justify="center" vs-align="center" vs-lg="12" vs-sm="12">
                  <casedocumentslist  :docslist="advdocslist" :deleteDocPermenantly="true" formscope="permAdvetisementForm" :fieldsArray="[]" v-model="petitionDetails['recruitmentInfo']['documents']"></casedocumentslist>
                </vs-col> -->
              </div>
            
              
            </div>
            <!-- <div class="text-danger text-sm formerrors" v-if="checkAdvertiseValidation != ''" @click="checkAdvertiseValidation=''">
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
              icon="IP-information-button" active="true">{{ checkAdvertiseValidation }}</vs-alert>
            </div> -->
            </div>
            </VuePerfectScrollbar>
          </div>
          
        </form>
        </div>
       
     
          <div class="popup-footer relative">
                <span class="loader" v-if="updating"><img src="@/assets/images/main/loader.gif"></span>
              <vs-button
                color="dark"
                @click="hideMe()"
                class="cancel"
                type="filled"
                >Cancel
              </vs-button>
              <vs-button
                color="success"
                :disabled="updating || documentUploading"
                @click="submitForm()"
                class="save"
                type="filled"
                >
                
                <template v-if="petitionDetails.completedActivities.indexOf('COLLECT_ADV_EVIDENCE') >-1">Update</template>
                <template v-else>Submit</template>
                </vs-button
              >
            </div>
      
    </div>
  
</template>
<script>
import FileUpload from "vue-upload-component/src";
import immiswitchyesno from "@/views/forms/fields/switchyesno.vue";
import immiyesorno from "@/views/forms/fields/yesorno.vue";
import addressFields from "@/views/forms/fields/address.vue";
import immitextarea from "@/views/forms/fields/simpletextarea.vue";
import immiInput from "@/views/forms/fields/simpleinput.vue";
import selectField from "@/views/forms/fields/simpleselect.vue";
import datepickerField from "@/views/forms/fields/datepicker.vue";
import casedocumentslist from "@/views/common/casedocuments.vue";
import redioButtons from "@/views/forms/fields/redioButtons.vue";
import * as _ from "lodash";
import moment from "moment";
import { XIcon } from "vue-feather-icons";
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import JQuery from "jquery";

export default {
  computed: {
    checkEndDate(){
      return(data)=>{
        let advCoolingPeriod = 0;
        if(this.checkProperty(this.petitionDetails,'advMinDuration') && this.checkProperty(this.petitionDetails,'advMinDuration')>0){
          let CoolingPeriod = parseInt(this.checkProperty(this.petitionDetails,'advMinDuration'))
          advCoolingPeriod = CoolingPeriod -1
        }
        if(this.checkProperty(data , 'field') == 'start'){
         if(_.has( data ,'dataVar')  && this.checkProperty(data , 'dataVar')){
            let startDate = data['dataVar'];
            let dueDate = moment(startDate).subtract(advCoolingPeriod, "days");
            return dueDate          
          }else{
            return null
          }
        }else{
            if(_.has( data ,'dataVar')  && this.checkProperty(data , 'dataVar')){
            let startDate = data['dataVar'];
            let dueDate = moment(startDate).add( advCoolingPeriod, 'days');        
            return dueDate          
          }else{
            return null
          } 
        }     
      }   
    },
    checkDocumentEnable(){
      return(data)=>{
        if(data['startKey']==null || data['endKey']==null){
          return true
        }
        if(data['startKey']==null && data['endKey']==null){
          this.petitionDetails['recruitmentInfo']['documents'].data['documentKey'] = []
          return true
        }
        else{
          return false
        }
      }
    }
  },
  
  provide() {
    return {
      parentValidator: this.$validator,
    };
  },
  created() {
    //this.$validator = this.parentValidator;
  },
  components: {
    casedocumentslist,
    FileUpload,
    //     addressFields,
    //     immitextarea,
    immiInput,
    //     selectField,
    datepickerField,
    XIcon,
    //    immiswitchyesno,
    //    immiyesorno,
    redioButtons,
    VuePerfectScrollbar,
  },

  data() {
    return {
      documentUploading:false,
      petitionDetails:null,
      endDateErrors:{
        "startDateOfSundayNewsPaper":'',
        "endDateOfAdvAtJobFair":'',
        "endDateOfNonCampusRecru":'',
        "endDateOfEmplrWebsitePosted":'',
        "endDateOfAdvWithTradeOrProfOrg":'',
        "endDateOfListedInJobSite":'',
        "endDateOfListedInPrivateEmpFirm":'',
        "endDateOfAdvEmpRefProgram":'',
        "endDateOfAdvCampusPlacOfc":'',
        "startDateOfAdvLocalNewsPaper":'',
        "startDateOfAdvInTVOrRadio":''
      },
      intrOfcMemomandum:[
      {
        fileUploading:false,
        key:'intrOfcMemomandum',
        fieldName:'intrOfcMemomandum',
        required: false,
        label: 'Signed copies',
        display:true
      }
      ],
      recruReportSummary:[
      {
        fileUploading:false,
        key:'recruReportSummary',
        fieldName:'recruReportSummary',
        required: false,
        label: 'Recruitment Report and Summary describing the recruitment efforts and results',
        display:true
      }
      ],
      busNecLetterByEplr:[
      {
        fileUploading:false,
        key:'busNecLetterByEplr',
        fieldName:'busNecLetterByEplr',
        required: false,
        label: 'Business Necessity Letter Provided by Employer',
        display:true
      }
      ],
      sunday:[{
        key:'sunday',
        fieldName:'sunday',
        required: false,
        label: 'Copy of Advertisement',
        display:true,
        fileUploading:false,
      }],
      jobFair:[{
        fileUploading:false,
        key: 'jobFair',
        fieldName: 'jobFair',
        required: false,
        label: 'Copy of Advertisement',
        display:true}
      ],
      campusRecruitment:[{
        fileUploading:false,
        key: 'campusRecruitment',
        fieldName: 'campusRecruitment',
        required: false,
        label: 'Copy of Advertisement',
        display:true
      }],
      empWebsite:[{
        fileUploading:false,
        key: 'empWebsite',
        fieldName: 'empWebsite',
        required: false,
        label: 'Copy of Advertisement',
        display:true
      }],
      profOrgOrTrade:[{
        fileUploading:false,
        key: 'profOrgOrTrade',
        fieldName: 'profOrgOrTrade',
        required: false,
        label: 'Copy of Advertisement',
        display:true
      }],
      pvtEmpmtFirm:[{
        fileUploading:false,
        key: 'pvtEmpmtFirm',
        fieldName: 'pvtEmpmtFirm',
        required: false,
        label: 'Copy of Advertisement',
        display:true
      }],
      jobSearchWebsite:[{
        fileUploading:false,
        key: 'jobSearchWebsite',
        fieldName: 'jobSearchWebsite',
        required: false,
        label: 'Copy of Advertisement',
        display:true
      }],
      empRefProgram:[{
        fileUploading:false,
        key: 'empRefProgram',
        fieldName: 'empRefProgram',
        required: false,
        label: 'Copy of Advertisement',
        display:true
      }],
      campusPlacement:[{
        fileUploading:false,
        key: 'campusPlacement',
        fieldName: 'campusPlacement',
        required: false,
        label: 'Copy of Advertisement ',
        display:true
      }],
      localNewsPaper:[{
        fileUploading:false,
        key: 'localNewsPaper',
        fieldName: 'localNewsPaper',
        required: false,
        label: 'Copy of Advertisement',
        display:true
      }],
      tvAds:[{
        fileUploading:false,
          key: 'tvAds',
          fieldName: 'tvAds',
          required: false,
          label: 'Copy of Advertisement',
          display:true
      }],
      checkValidationList:[
        {
          startDateKey:'startDateOfAdvAtJobFair',
          endDateKey:'endDateOfAdvAtJobFair',
          documentKey:'jobFair'
        },
        {
          startDateKey:'startDateOfNonCampusRecru',
          endDateKey:'endDateOfNonCampusRecru',
          documentKey:'campusRecruitment'
        },
        {
          startDateKey:'startDateOfEmplrWebsitePosted',
          endDateKey:'endDateOfEmplrWebsitePosted',
          documentKey:'empWebsite'
        },
        {
          startDateKey:'startDateOfAdvWithTradeOrProfOrg',
          endDateKey:'startDateOfAdvWithTradeOrProfOrg',
          documentKey:'profOrgOrTrade'
        },
        {
          startDateKey:'startDateOfAdvEmpRefProgram',
          endDateKey:'endDateOfAdvEmpRefProgram',
          documentKey:'empRefProgram'
        },
        {
          startDateKey:'startDateOfListedInJobSite',
          endDateKey:'endDateOfListedInJobSite',
          documentKey:'jobSearchWebsite'
        },
        {
          startDateKey:'startDateOfListedInPrivateEmpFirm',
          endDateKey:'endDateOfListedInPrivateEmpFirm',
          documentKey:'pvtEmpmtFirm'
        },
        {
          startDateKey:'startDateOfAdvCampusPlacOfc',
          endDateKey:'endDateOfAdvCampusPlacOfc',
          documentKey:'campusPlacement'
        },
        {
          startDateKey:'startDateOfAdvLocalNewsPaper',
          endDateKey:'endDateOfAdvLocalNewsPaper',
          documentKey:'localNewsPaper'
        },
        {
          startDateKey:'startDateOfAdvInTVOrRadio',
          endDateKey:'endDateOfAdvInTVOrRadio',
          documentKey:'tvAds'
        },
      ],
      uploading:false,
      countries: [],
      documents:[],
      values:[],
      permadvertisePopUp: true,
      educationTypes: [],
      masterSocList: [],
      wageSourceList: [
        "OES",
        "CBA",
        "Employer Conducted Survey",
        "DBA",
        "SCA",
        "Other",
      ],
      payFrequencyList: ["Hour", "Week", "Month", "Year"],
      updating: false,
      checkAdvertiseValidation:'',
      startDateEnableFrom:null,
      
    };
  },
  methods: {
    checkSubmitBtn(){

      this.documentUploading = false;
      let tempArray = [
        "intrOfcMemomandum",
        "recruReportSummary",
        "busNecLetterByEplr",
        "sunday",
        "jobFair",
        "campusRecruitment",
        "empWebsite",
        "profOrgOrTrade",
        "pvtEmpmtFirm",
        "jobSearchWebsite",
        "empRefProgram",
        "campusPlacement",
        "localNewsPaper",
        "tvAds",
        ];
        _.forEach(tempArray ,(docMainCategoryList)=>{
          let uploadingList = _.filter(this[docMainCategoryList],(document)=>{
            return _.get(document , "fileUploading" ,false)==true;

          });
          if(uploadingList && uploadingList.length>0){
            this.documentUploading = true;

          }

        });
        
        return _.cloneDeep(this.documentUploading);
               
            },
    emitUploadingAction(data){

      
      
        if(_.has(data,'docMainCategory')){
            _.map(this[data['docMainCategory']],(item)=>{
                if(item['fieldName'] == data['fieldName']){
                    item = Object.assign( item ,{ "fileUploading": false})
                    item['fileUploading'] = data['action'] 
                }
            })
        }
        this.checkSubmitBtn()
            },
    init(){
      this.petitionDetails = _.cloneDeep(this.petition);
    },
    updateSignedDate(val , item=''){
      if(this.petitionDetails['recruitmentInfo'][item]){
        let dateVal = moment(val);
        let endDate= moment(this.petitionDetails['recruitmentInfo'][item])
        if(dateVal.isAfter(endDate , 'day')){
          this.petitionDetails['recruitmentInfo'][item] = null
        }
      }
    },
    checkEndDateEligibility(startKey='',endKey=''){
      if(this.checkProperty(this.petitionDetails, 'recruitmentInfo',startKey) && this.checkProperty(this.petitionDetails, 'recruitmentInfo',endKey)){
        let startDate = this.checkProperty(this.petitionDetails, 'recruitmentInfo',startKey)
        let endDate = this.checkProperty(this.petitionDetails, 'recruitmentInfo',endKey)
        let advCoolingPeriod = 0;
        if(this.checkProperty(this.petitionDetails,'advMinDuration') && this.checkProperty(this.petitionDetails,'advMinDuration')>0){
          let CoolingPeriod = parseInt(this.checkProperty(this.petitionDetails,'advMinDuration'))
          advCoolingPeriod = CoolingPeriod -1
        }
        let disablePeriod = moment(startDate).add(advCoolingPeriod, "days");
        if(this.startDateEnableFrom != null){
          if(!(moment(endDate).isAfter(disablePeriod , 'day') && moment(endDate).isBefore(this.startDateEnableFrom ,'day') )){
            
           this.petitionDetails['recruitmentInfo'][endKey] =null
           this.updateStartDateOfAdvAtJobFair(this.petitionDetails['recruitmentInfo'][endKey], endKey )
          }
        }
        else{
          if(!(endDate.isAfter(disablePeriod , 'day'))){
           this.petitionDetails['recruitmentInfo'][endKey] =null
           this.updateStartDateOfAdvAtJobFair(this.petitionDetails['recruitmentInfo'][endKey], endKey )
          }
        }
      }
    },
    updateStartDateOfAdvAtJobFair(val , item=''){
      if( _.has( this.endDateErrors ,item)){
        this.endDateErrors[item]="";
        if(val && item != ''  ){
          let dateVal = moment(val);
          if(this.startDateEnableFrom != null && dateVal){
            if(!(moment(dateVal).isBefore(moment(this.startDateEnableFrom)) || moment(dateVal).isSame(moment(this.startDateEnableFrom))) ){
              //this.petitionDetails['recruitmentInfo'][item] = null
              this.endDateErrors[item]= "Date should be prior to PWD Expiry Date";
            }
          }
        }
    }
    },
    getStartDateEligibilty(){
      let pwdDetails = null;
      let startDate = null;
      if(this.checkProperty(this.petitionDetails,'pwdResponse')){
        pwdDetails = _.cloneDeep(this.petitionDetails.pwdResponse)
      if(this.checkProperty(pwdDetails,'dueDate')){
        startDate =pwdDetails['dueDate']
        this.startDateEnableFrom = startDate
      }
      
    }else{
      this.startDateEnableFrom = null
    }
    },
    checkadvertiseValidation(){
      this.checkAdvertiseValidation = ''
      let count = 0
      _.forEach(this.checkValidationList, (item)=>{
        let startDateKey = item['startDateKey'];
        let endDateKey = item['endDateKey'];
        let documentKey = item['documentKey'];
          
        if(
          (_.has(this.petitionDetails['recruitmentInfo'] ,startDateKey) && this.petitionDetails['recruitmentInfo'][startDateKey] )&&
          (_.has(this.petitionDetails['recruitmentInfo'] ,endDateKey) && this.petitionDetails['recruitmentInfo'][endDateKey] )
        ){
          count++
          // if( this.petitionDetails['recruitmentInfo']['documents'][documentKey] && this.checkProperty(this.petitionDetails['recruitmentInfo']['documents'][documentKey],'length')>0 ){
            
          // }else{
          //   alert(documentKey)
          //   this[documentKey]['required'] = true
          //   alert(this[documentKey]['required'])

          // }
        }
        if(!(
          (_.has(this.petitionDetails['recruitmentInfo'] ,startDateKey) && this.petitionDetails['recruitmentInfo'][startDateKey] )&&
          (_.has(this.petitionDetails['recruitmentInfo'] ,endDateKey) && this.petitionDetails['recruitmentInfo'][endDateKey] ))
        ){
          this.petitionDetails['recruitmentInfo']['documents'][documentKey] = []
        }
      })
      if(count<3){
          this.checkAdvertiseValidation="Select at least three Professional Recruitment Advertisements"
          this.showToster({ message: this.checkAdvertiseValidation, isError: true });
      }
    },
    upload(fils) {
       let  model =_.cloneDeep(fils);
       this.values =[];
       var _current = this;
       // this.$vs.loading();
 
       let efiles = [];
       efiles = _.filter(model, (e) => {
         return e.url != null && e.url != "";
       });
       let nfiles = _.filter(model, (e) => {
         return e.url == null || e.url == undefined;
       });
 
       let mapper = nfiles.map(
         (item) =>
           (item = {
             name: item.name,
             file: item.file ? item.file : null,
             url: item.url ? item.url : "",
             path: item.path ? item.path : "",
             status: true,
             mimetype: item.type ? item.type : item.mimetype,
             uploadedBy: _current.checkProperty(_current.getUserData, 'userId'),
            uploadedByName: _current.checkProperty(_current.getUserData, 'name'),
            uploadedByRoleId: _current.getUserRoleId,
            uploadedByRoleName: _current.checkProperty(_current.getUserData, 'loginRoleName'),
            size:item.size ? item.size : null,
           })  
       );
       let tempFiles = [];
       if (mapper.length > 0) {
         this.uploading = true;
         let count = 0;
         mapper.forEach((doc, index) => {
          if(  !( doc.mimetype=='application/pdf' )  ){
            this.uploading = false;  
                  
            return false;

          }
           let formData = new FormData();
           formData.append("files", doc.file);
           formData.append("secureType", "private");
           formData.append("getDetails", true);
           count++;
 
           this.$store.dispatch("uploadS3File", formData).then((response) => {
             response.data.result.forEach((urlGenerated) => {
               //alert(JSON.stringify(urlGenerated))
               //  this.CommentPayload.documents.push(urlGenerated)
              // if (  _.has(urlGenerated, "name") &&  tempFiles.indexOf(urlGenerated["name"]) <= -1 ) {
                let tempUrl = urlGenerated
                tempUrl = Object.assign(tempUrl, { uploadedBy: _current.checkProperty(_current.getUserData, 'userId'), uploadedByName: _current.checkProperty(_current.getUserData, 'name'), uploadedByRoleId: _current.getUserRoleId, uploadedByRoleName: _current.checkProperty(_current.getUserData, 'loginRoleName') });
                 tempFiles.push(urlGenerated["name"]);
                
                 
                
                  this.petitionDetails['recruitmentInfo']['documents']['evidences'].push(tempUrl);
                  this.uploading = false; 
                 
            //   }
               doc.url = urlGenerated;
               doc.path = urlGenerated;
               doc["mimetype"] = urlGenerated["mimetype"];
               doc["type"] = urlGenerated["mimetype"];
               doc["size"] = urlGenerated["size"];
               delete doc.file;
               mapper[index] = doc;
             });
             if (index >= mapper.length - 1) {
               this.uploading = false;
               // _current.$vs.loading.close();
             }
           });
         });
         if (efiles.length > 0) efiles.push(...mapper);
         //this.CommentPayload["documents"] = efiles
       }
     },
      remove(item, data, filindex) {
       data.splice(filindex, 1);
     },
    updatedateOfFirstAdvtIdentified(val){
      if(val){
        let startDate = moment(val);
        if(this.petitionDetails['recruitmentInfo'].dateOfSecondAdvIdentified){
          let endDate= moment(this.petitionDetails['recruitmentInfo'].dateOfSecondAdvIdentified)
          if(startDate.isAfter(endDate , 'day')){
            this.petitionDetails['recruitmentInfo'].dateOfSecondAdvIdentified = null
          }
        }
      }
    },
    updateswaStartDate(val){
      if(val){
        let startDate = moment(val);
        if(this.petitionDetails['recruitmentInfo'].swaEndDate){
          let endDate= moment(this.petitionDetails['recruitmentInfo'].swaEndDate)
          if(startDate.isAfter(endDate , 'day')){
            this.petitionDetails['recruitmentInfo'].swaEndDate = null
          }
        }
      }
    },
    updateStartdateOfFirstAdvtIdentified(val){
      if(val){
        let startDate = moment(val);
        if(this.petitionDetails['recruitmentInfo'].endDateOfAdvAtJobFair){
          let endDate= moment(this.petitionDetails['recruitmentInfo'].endDateOfAdvAtJobFair)
          this.petitionDetails['recruitmentInfo'].endDateOfAdvAtJobFair = null
          // if(startDate.isAfter(endDate , 'day')){
          //   this.petitionDetails['recruitmentInfo'].endDateOfNonCampusRecru = null
          // }
        }
      }
    },
  
    updatestartDateOfNonCampusRecru(val){
      if(val){
        let startDate = moment(val);
        if(this.petitionDetails['recruitmentInfo'].endDateOfNonCampusRecru){
          let endDate= moment(this.petitionDetails['recruitmentInfo'].endDateOfNonCampusRecru)
          this.petitionDetails['recruitmentInfo'].endDateOfNonCampusRecru = null
          // if(startDate.isAfter(endDate , 'day')){
          //   this.petitionDetails['recruitmentInfo'].endDateOfNonCampusRecru = null
          // }
        }
      }
    },
    updatestartDateOfEmplrWebsitePosted(val){
      if(val){
        let startDate = moment(val);
        if(this.petitionDetails['recruitmentInfo'].endDateOfEmplrWebsitePosted){
          let endDate= moment(this.petitionDetails['recruitmentInfo'].endDateOfEmplrWebsitePosted)
          this.petitionDetails['recruitmentInfo'].endDateOfEmplrWebsitePosted = null
          // if(startDate.isAfter(endDate , 'day')){
          //   this.petitionDetails['recruitmentInfo'].endDateOfEmplrWebsitePosted = null
          // }
        }
      }
    },
    updatestartDateOfAdvWithTradeOrProfOrg(val){
      if(val){
        let startDate = moment(val);
        if(this.petitionDetails['recruitmentInfo'].endDateOfAdvWithTradeOrProfOrg){
          let endDate= moment(this.petitionDetails['recruitmentInfo'].endDateOfAdvWithTradeOrProfOrg)
          this.petitionDetails['recruitmentInfo'].endDateOfAdvWithTradeOrProfOrg = null
          // if(startDate.isAfter(endDate , 'day')){
          //   this.petitionDetails['recruitmentInfo'].endDateOfAdvWithTradeOrProfOrg = null
          // }
        }
      }
    },
    updatestartDateOfListedInJobSite(val){
      if(val){
        let startDate = moment(val);
        if(this.petitionDetails['recruitmentInfo'].endDateOfListedInJobSite){
          let endDate= moment(this.petitionDetails['recruitmentInfo'].endDateOfListedInJobSite)
          this.petitionDetails['recruitmentInfo'].endDateOfListedInJobSite = null
          // if(startDate.isAfter(endDate , 'day')){
          //   this.petitionDetails['recruitmentInfo'].endDateOfListedInJobSite = null
          // }
        }
      }
    },
    updatestartDateOfListedInPrivateEmpFirm(val){
      if(val){
        let startDate = moment(val);
        if(this.petitionDetails['recruitmentInfo'].endDateOfListedInPrivateEmpFirm){
          let endDate= moment(this.petitionDetails['recruitmentInfo'].endDateOfListedInPrivateEmpFirm)
          this.petitionDetails['recruitmentInfo'].endDateOfListedInPrivateEmpFirm = null
          // if(startDate.isAfter(endDate , 'day')){
          //   this.petitionDetails['recruitmentInfo'].endDateOfListedInPrivateEmpFirm = null
          // }
        }
      }
    },
    updatestartDateOfAdvEmpRefProgram(val){
      if(val){
        let startDate = moment(val);
        if(this.petitionDetails['recruitmentInfo'].endDateOfAdvEmpRefProgram){
          let endDate= moment(this.petitionDetails['recruitmentInfo'].endDateOfAdvEmpRefProgram)
          this.petitionDetails['recruitmentInfo'].endDateOfAdvEmpRefProgram = null
          // if(startDate.isAfter(endDate , 'day')){
          //   this.petitionDetails['recruitmentInfo'].endDateOfAdvEmpRefProgram = null
          // }
        }
      }
    },
    updatestartDateOfAdvCampusPlacOfc(val){
      if(val){
        let startDate = moment(val);
        if(this.petitionDetails['recruitmentInfo'].endDateOfAdvCampusPlacOfc){
          let endDate= moment(this.petitionDetails['recruitmentInfo'].endDateOfAdvCampusPlacOfc)
          this.petitionDetails['recruitmentInfo'].endDateOfAdvCampusPlacOfc = null
          // if(startDate.isAfter(endDate , 'day')){
          //   this.petitionDetails['recruitmentInfo'].endDateOfAdvCampusPlacOfc = null
          // }
        }
      }
    },
    updatestartDateOfAdvLocalNewsPaper(val){
      if(val){
        let startDate = moment(val);
        if(this.petitionDetails['recruitmentInfo'].endDateOfAdvLocalNewsPaper){
          let endDate= moment(this.petitionDetails['recruitmentInfo'].endDateOfAdvLocalNewsPaper)
          if(startDate.isAfter(endDate , 'day')){
            this.petitionDetails['recruitmentInfo'].endDateOfAdvLocalNewsPaper = null
          }
        }
      }
    },
    updatestartDateOfAdvInTVOrRadio(val){
      if(val){
        let startDate = moment(val);
        if(this.petitionDetails['recruitmentInfo'].endDateOfAdvInTVOrRadio){
          let endDate= moment(this.petitionDetails['recruitmentInfo'].endDateOfAdvInTVOrRadio)
          if(startDate.isAfter(endDate , 'day')){
            this.petitionDetails['recruitmentInfo'].endDateOfAdvInTVOrRadio = null
          }
        }
      }
    },
    updatewereLaidOffUSWorker(){},
    updatehasEmplrHadLayoffInArea() {
         if(this.checkProperty(this.petitionDetails ,'recruitmentInfo','hasEmplrHadLayoffInArea') !='Yes'){
                   
                    // this.petitionDetails['recruitmentInfo']['noOfExpMonthsInAltOccu'] =null;
                    // this.petitionDetails['recruitmentInfo']['jobTitleOfAcceptAltOccu'] ='';
                    
                }
     },
    updatenoBargainRepreHasNotice() { },
    updatehasBargainRepreForWorkerInOccu() { },
     updatehasEmplrRecPayForSubAppl(){},
      updatehasSundayEditionOfNewsPaper(item){
        if(item == 'No'){
          this.petitionDetails['recruitmentInfo'].startDateOfSundayNewsPaper = null
          this.petitionDetails['recruitmentInfo'].endDateOfSundayNewsPaper = null
          this.petitionDetails['recruitmentInfo']['documents']['sunday'] = []
          this.updateStartDateOfAdvAtJobFair(null,'startDateOfSundayNewsPaper')
        }
      },
      updateapplForColOrUniTeacher(item){
        if(item == 'No'){
          this.petitionDetails.recruitmentInfo.selCandiadateByCompRecru = null
          this.petitionDetails.recruitmentInfo.useBasicRecruProcForProfOccu = null
          this.petitionDetails['recruitmentInfo'].dateAlienSelected  = null
          this.petitionDetails['recruitmentInfo'].nameOfNationalProfJourAdvPlaced  = null
          this.petitionDetails['recruitmentInfo'].addiRecruInfo  = null
        }
       },
      updateselCandiadateByCompRecru(){},
      updateuseBasicRecruProcForProfOccu(){},
      updateapplForProfOcc(){},
    hideMe() {
      this.permadvertisePopUp = false;
      this.$emit("hideMe");
    },
    getMasterSocList() {
      let query = {};
      query["page"] = 1;
      query["perpage"] = 10000;
      query["matcher"] = {};
      query["category"] = "soc_codes";

      this.$store
        .dispatch("getMasterData", query)
        .then((response) => {
          this.masterSocList = response.list;

          //alert(this.perpage);
        })
        .catch(() => {
          this.masterSocList = [];
        });
    },

    submitForm() {
      this.checkAdvertiseValidation = ''
     
      this.checkadvertiseValidation()
      
      this.$validator.validateAll("permAdvetisementForm").then((result) => {

        //alert(result +"===="+ this.checkAdvertiseValidation)
        if (this.checkAdvertiseValidation == '' && result) {
          let count = 0;
          _.forEach( this.endDateErrors, (vl ,item)=>{
            this.endDateErrors[item] ='';
            let val = this.checkProperty(this.petitionDetails ,'recruitmentInfo',item);
            if(val && item != ''){
            let dateVal = moment(val);
            if(this.startDateEnableFrom != null && dateVal){
              if(!(moment(dateVal).isBefore(moment(this.startDateEnableFrom)) || moment(dateVal).isSame(moment(this.startDateEnableFrom))) ){
                //this.petitionDetails['recruitmentInfo'][item] = null
                this.endDateErrors[item]= "Date should be prior to PWD Expiry Date";
                count++;
              }
            }
          }
        
      })
      if(count>0){
        return false;
      }
     // alert('count==='+count)

         
          let path = "/perm/update-adv-evidences";
         let postData = {
            petitionId: null,
            subTypeName: null,
            typeName: null,
            recruitmentInfo: null,
            'action':'COLLECT_ADV_EVIDENCE'
          };
            
          postData.petitionId = this.checkProperty(this.petitionDetails,"_id");
          postData.typeName = this.checkProperty(this.petitionDetails['typeDetails'] ,'name');
          postData.subTypeName = this.checkProperty(this.petitionDetails['subTypeDetails'] ,'name');
          postData.recruitmentInfo = this.checkProperty(this.petitionDetails, 'recruitmentInfo');
          
          this.updating = true;
          if(this.petitionDetails.completedActivities.indexOf('COLLECT_ADV_EVIDENCE') >-1){
            postData['action'] = 'EDIT_ADV_EVIDENCE';
          }
         
          if(this.loadedFromPwdLibrary){
            postData['pwdId'] = this.checkProperty(this.petitionDetails,"_id");
            path = "/pwd/update-adv-evidences";

            if(this.checkProperty( this.petitionDetails ,'petitionList' ,'length')==1 && this.petitionDetails['completedActivities'].indexOf('PWD_CERTIFID')<=-1 ){
                    path ="/perm/update-adv-evidences";
                    data["typeName"] ="GC-Employment";
                    data["subTypeName"] ="GC-Employment";
                    data['petitionId'] = this.petitionDetails['petitionList'][0]['_id'];
            }
          }
          this.$store
            .dispatch("commonAction", { "path": path, "data": postData })
            .then((response) => {
              this.updating = false;
              this.showToster({ message: response.message, isError: false });
              this.hideMe();
              this.$emit("updatepetition");
            })
            .catch((error) => {
              this.updating = false;
              this.showToster({ message: error, isError: true });
            });
        }else{
          if(result && this.checkAdvertiseValidation != '' ){
            var elmnt = document.getElementById("professional_advert");
            elmnt.scrollIntoView();
            // const $ = JQuery;
            // setTimeout(() => {
            // $('.modal_cnt').scrollTop($('#professional_advert').first().offset().top-30);
            // }, 100)
           
          }else{
            const $ = JQuery;
            if($('.text-danger:visible')){
                $('.modal_cnt').scrollTop($('.text-danger:visible').first().parent().offset().top-30);
            }
          }
            

        }
       
      });
    },
  },
  props: {
    loadedFromPwdLibrary:{
      type: Boolean,
      default: false,

    },
    value: null,
    formscope: {
      type: String,
      default: "",
    },

    petition: {
      type: Object,
      default: null,
    },
  },
  mounted() {
    this.checkAdvertiseValidation=''
     this.activeTab = "jobDetails";
     this.init();
    // this.petitionDetails = _.cloneDeep(this.petition);
    setTimeout(()=>{
    //  this.petitionDetails = _.cloneDeep(this.petition);
      this.getStartDateEligibilty();
      this.init();
    },100);
  },
};
</script>