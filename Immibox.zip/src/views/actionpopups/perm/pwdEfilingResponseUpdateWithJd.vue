<template>
   
    <modal
          name="updateUscisStatus"
          classes="v-modal-sec"
          :min-width="200"
          :min-height="200"
          :scrollable="true"
          :reset="true"
          width="750px"
          height="auto"
        >
        <div class="v-modal profile_details_modal error-modal-space" >
          
          <div class="popup-header fromDetailsPage">
            <h2 class="popup-title" >
              <template v-if="this.petitionDetails['pwdStatus'] =='Filed'" >Upload Certified PWD</template>
              <template v-else>Upload Filed/Certified PWD</template>

            </h2>
           
            <span @click="showPopup=false;$modal.hide('updateUscisStatus');"> 
              <em class="material-icons">close</em>
            </span>
          </div>
         
          <form  @submit.prevent data-vv-scope="uscisstatus" class="trackingform">
              <div class="form-container errorScroll" @click="pewResponceUpdateStatusError='';showDocumentsError=false">
                <template >
                      
                <div class="vx-row">
                                     
                  <div class="vs-col w-full"   >
                    <!----this.petitionDetails['pwdStatus'] =="Filed"-->
                     
                      
                    <div class="vx-row">
                      <selectField @input="checkPwdStatus();loadingFields($event)"  :isDisabled="prefilledKyes.indexOf('pwdStatus')>-1"  :listContainsId="false" :wrapclass="'md:w-full'" cid="pwdStatus"  :required="true" :optionslist="pwdStatusList" v-model="pwdStatus" :formscope="'uscisstatus'"  fieldName="pwdStatus"  label="PWD Status" placeHolder="PWD Status"  />  
                                           
                        
                         <datepickerField 
                           v-if="pwdStatus =='Certified'"
                            wrapclass="md:w-1/2"
                            :isDisabled="(prefilledKyes.indexOf('issuedDate')>-1 && pwdResponse.issuedDate !==null && pwdStatus =='Certified')"
                            @input="updateissuedDate($event)"
                            :display="true"  
                            v-model="pwdResponse.issuedDate" 
                            :formscope="'uscisstatus'"  
                            fieldName="issuedDate" 
                            :dateEnableTo="new Date()" 
                            label="Receipt Date" 
                            :validationRequired="true" 
                              />

                      <datepickerField 
                          v-if="pwdStatus =='Certified'"
                          :isDisabled="(prefilledKyes.indexOf('receivedDate')>-1 && pwdResponse.receivedDate !==null && pwdStatus =='Certified')"
                          wrapclass="md:w-1/2" 
                          :display="true"  
                          v-model="pwdResponse.receivedDate" 
                          :formscope="'uscisstatus'"  
                          fieldName="receivedDate"  
                          :dateEnableTo="new Date()" 
                          label="Received Date" 
                          :validationRequired="true"
                         />    
                      
                      
                      <datepickerField 
                      v-if="pwdStatus =='Certified'"
                      :isDisabled="(!pwdResponse.issuedDate) || (prefilledKyes.indexOf('dueDate')>-1 && pwdResponse.dueDate !==null && pwdStatus =='Certified')"
                      wrapclass="md:w-1/2" 
                      :display="true"  
                      v-model="pwdResponse.dueDate" 
                      :formscope="'uscisstatus'"  
                      fieldName="dueDate" 
                      :dateEnableFrom="pwdResponse.issuedDate" 
                      label="Expiration Date" 
                      :validationRequired="true"   />
                    </div>
                  </div>
                  
                 
                 
                <!----
                  <immitextarea  wrapclass="w-full"  :formscope="'uscisstatus'"  v-model="pwdResponse.description" :required="true" fieldName="wageSourceOtherDesc" label="Comments" placeHolder="Comments"></immitextarea>
              -->

                  <div class="vx-col w-full" v-if="false">
                    <div class="form_group">
                      <label class="form_label">Document Type<em>*</em></label>
                      <div class="con-select w-full DT_multiselect">  
                      <!-- {{documentType}}                 -->
                        <multiselect
                          :name="'documentType'"
                          v-validate="'required'"
                          v-model="pwdResponse.documentType"
                          :show-labels="false"
                          
                          data-vv-as="Document Type"
                          placeholder="Document Type"
                          :options="documentTypes"
                          :searchable="true"
                          :allow-empty="false"
                        >
                        </multiselect>
                      
                        <span  class="text-danger text-sm"  v-show="errors.has('uscisstatus.documentType')"  >{{ errors.first('uscisstatus.documentType') }}</span>
                      </div>
                    </div>
                  </div>
                  
                </div>

                <div  class="vx-row" @click="documentModel=[];pwdDocFormatError='';disablePWDstatus=false;prefillJobDetailsError=''" >
                  
                  <div div class="vx-col w-full">
                    <div class="form_group">
                      <label class="form_label" style="text-transform: capitalize"> Documents<em>*</em></label>
                    <div class="uploadsec_wrap upload_uscis">
                      <div class="w-full">
                          <div class="relative">
                            <file-upload
                              v-model="documentModel"
                              class="file-upload-input mb-0"
                              style="height:50px;"
                              name="trackingdoc"
                              :multiple="false"
                             
                              data-vv-as="Documents"
                              :accept="pdfDocEntity"
                              @input="uploadDocuments()"
                            >
                              <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                              Upload
                            </file-upload>
                            <span class="loader" v-if="filesAreuploading"><img src="@/assets/images/main/loader.gif"></span>
                          </div>
                        <span class="file-type">(File Type: PDF)</span>
                        <span v-if="pwdDocFormatError" class="text-danger text-sm" >{{pwdDocFormatError}}</span>
                        <span v-else-if="showDocumentsError && pwdResponse['documents'].length<=0 "  class="text-danger text-sm"  ><em>*</em> Documents are required</span>
                 <!-- <VuePerfectScrollbar class="scrollbardoc"> -->
                            
                              <div class="uploded-files_wrap mb-5" v-if="pwdResponse['documents'].length >0 ">
                                  <template v-for="(fil, fileindex) in pwdResponse['documents']">
                                    <div class="w-full"  :key="fileindex" >
                                        <div class="uploded-files">
                                            <vx-input-group class="form-input-group">
                                              <vs-input v-on:keyup="fileNameChenged(fil)"  v-validate="'required'" class="w-full" :name="'fName'+fileindex" v-model="pwdResponse['documents'][fileindex]['name']" data-vv-as="File Name" />
                                                <span class="text-danger text-sm" v-show="errors.has('uscisstatus.fName'+fileindex)">{{ errors.first('uscisstatus.fName'+fileindex) }}</span>

                                                
                                            </vx-input-group>

                                            <div class="form_group">
                                            

                                              
                                            <div class="delete" style="z-index:999" @click="remove(fileindex , pwdResponse['documents']);resetPrefedKyes()">
                                                    <img src="@/assets/images/main/delete-row-img.svg" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                 </template>
                                 <div @click="prefillJobDetailsError=''" class="text-danger text-sm formerrors position_static" v-if="prefillJobDetailsError!=''">
                                    <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ prefillJobDetailsError }}</vs-alert>
                                  </div>
                              </div>
                          <!-- </VuePerfectScrollbar> -->
                        </div>
                    </div>
                    </div>
                  </div>

                 

                
                </div>

                <div class="vx-row" v-if="false">

                  <div class="vx-col w-full">
                  <div class="form_group">
                    <label class="form_label">Comments</label>
                    <!-- <vs-textarea
                      data-vv-as="Comments"
                      
                      v-model="pwdResponse.description"
                      name="usciscomments"
                      class="w-full"
                    /> -->
                    <ckeditor data-vv-as="Comments"
                      
                      v-model="pwdResponse.description"
                      name="usciscomments"
                      class="w-full"  :editor="editor" :config="editorConfig"></ckeditor>


                    <span
                      class="text-danger text-sm"
                      v-show="errors.has('uscisstatus.usciscomments')"
                    ><em>*</em> Comments are required</span>
                  </div>
                  </div>
                
                </div>

                <permJobCreationForm v-if="jobDetails" ref="jobComponent" v-model="jobDetails"  :formscope="'uscisstatus'" :countries="countries" />
                  

              </template>
               
                
              </div>
              
              <div @click="pewResponceUpdateStatusError=''" class="text-danger text-sm formerrors" v-if="pewResponceUpdateStatusError!=''">
                        <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ pewResponceUpdateStatusError }}</vs-alert>
              </div>

              <div class="popup-footer relative">
              <span class="loader" v-if="pwdResUpdating"><img src="@/assets/images/main/loader.gif"></span>
                <vs-button color="dark" class="cancel" type="filled" @click="documentModel=[]; hideMe()">Cancel</vs-button>
                <vs-button color="success" :disabled="pwdResUpdating" @click="submitForm()" class="save" type="filled">Submit</vs-button>
              </div>
          </form>
          </div>
        </modal>  
</template>
<script>

import moment from "moment";
import FileUpload from "vue-upload-component/src";
import { EyeIcon } from "vue-feather-icons";
import docType from "@/views/common/docType.vue";
import Datepicker from "vuejs-datepicker-inv";
import datepickerField from "@/views/forms/fields/datepicker.vue";
import * as _ from "lodash";
import immiInput from "@/views/forms/fields/simpleinput.vue";
import immitextarea from "@/views/forms/fields/simpletextarea.vue";
import selectField from "@/views/forms/fields/simpleselect.vue";
import Vue from 'vue';
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';

import permJobCreationForm from "@/views/actionpopups/perm/permJobCreationForm.vue"
import JQuery from "jquery";

export default {
provide() {
        return {
           parentValidator: this.$validator,
        };
    },
components: {
  permJobCreationForm,
  docType,
  EyeIcon,
  FileUpload,
  Datepicker,
  immiInput,
  immitextarea,
  selectField,
  datepickerField
},
methods: {
  initData(){
    let documents = []
    if(_.has(this.petitionDetails ,"refPwdData" )){
     
      if(this.checkProperty( this.petitionDetails["refPwdData"] ,'pwdResponse' ,'documents' )){
        this.pwdResponse['documents'] = _.cloneDeep(this.petitionDetails["refPwdData"]['pwdResponse']['documents'])
      }

      /*
        documentType: String, // Original/Electronic

            issuedDate: { type: Date },

            receivedDate: { type: Date },

            dueDate: { type: Date },
      */
      if(this.checkProperty( this.petitionDetails["refPwdData"] ,'pwdResponse' ,'documentType' )){
        this.pwdResponse['documentType'] = this.petitionDetails["refPwdData"]['pwdResponse']['documentType'] 
      }
      if(this.checkProperty( this.petitionDetails["refPwdData"] ,'pwdResponse' ,'issuedDate' )){
        this.pwdResponse['issuedDate'] = this.petitionDetails["refPwdData"]['pwdResponse']['issuedDate'] 
      }
      if(this.checkProperty( this.petitionDetails["refPwdData"] ,'pwdResponse' ,'receivedDate' )){
        this.pwdResponse['receivedDate'] = this.petitionDetails["refPwdData"]['pwdResponse']['receivedDate'] 
      }
      if(this.checkProperty( this.petitionDetails["refPwdData"] ,'pwdResponse' ,'dueDate' )){
        this.pwdResponse['dueDate'] = this.petitionDetails["refPwdData"]['pwdResponse']['dueDate'] 
      }


    }
      
    

  },
  loadingFields(item){
      this.$refs['jobComponent'].checkVislibilty(item)
    },
  resetPrefedKyes(){
    this.pwdStatus ='';
    let tempJobDetails = {
      
      wageRate: "",
      socOccuTitle: "",
      preferredSocOccuTitle:"",
      socCode: "",
      socCodeDetails:null,
      preferredSocCodeDetails:null,

			jobTitle: "",
			preferredSocCode: '',
     
			classification: "",
			description: "",
			skills: [],
			minDegree: '',
			majorFieldsOfStudy: "",
			expInYears: "",
			workAddresses: [{
				"companyName": "",
				"line1" : "",
				"line2" : "",
				"aptType": "",
				"locationId" :'' ,
				"stateId" :'' ,
				"countryId" :'' ,
				"zipcode" : "",
				"locationDetails" : {
					"id" : '',
					"name" : "",
					"stateId" : '',
					"countryId" :'' 
				},
				"stateDetails" : {
					"id" :'' ,
					"name" : "",
					"shortName" : "",
					"countryId" : ''
				},
				"countryDetails" : {
					"id" : 231,
					"shortName" : "US",
					"name" : "United States",
					"phoneCode" : 1,
					"order" : 1,
					"currencySymbol" : "$",
					"currencyCode" : "USD",
					"zipcodeLength" : 5
				},
				"workLocation": true
			}],
      altJobRequirements: {

        // Are alternate sets of Education, Training, and/or Experience accepted? "Yes", "No"

        areAltSetsOfEducation:"",// { type: String},
        altevelOfEducation: null,//{ type: Schema.Types.ObjectId, default: null  }, //0bjectId
        altevelOfEducationDetails:null,
        usDiplomaOrDegreeAccepted:'', //{type: String},
        majorsOrFieldsOfStudyAccepted: '',//{type: String},
        isAltTrainingForTheJobOpporAccepted: '',//"Yes" Or "No"
        noOfMonthsOfAltTrainingAccepted: null,//{type: String},
        filedsOrNamesOfTrainingAccepted: "",//{ type: String },
        altEmpExpAccepted: "", //"Yes" Or "No"
        noOfMonthsAltEmpExpAccepted:null,
        splSkillOrOtherRequi:'',
        ForeignLanguage:'',
        LicenseCertification:'',
        residencyFellowship:'',
        otherSplSkillsOrRequi:''

        },
		}
      _.forEach(this.jobDetails , (item ,key)=>{
            if(this.prefilledKyes.indexOf(key)>-1){
              this.jobDetails[key] = null;
              if(_.has(tempJobDetails , key)){
                this.jobDetails[key] = tempJobDetails[key];
              }else{
                this.jobDetails[key] = null;
              }
            }
        });  

        if(  this.prefilledKyes.indexOf('issuedDate')>-1){
          this.pwdResponse['issuedDate'] = null;
        }
        if( this.prefilledKyes.indexOf('receivedDate')>-1){
          this.pwdResponse['receivedDate'] = null;
        }
        if( this.prefilledKyes.indexOf('dueDate')>-1){
          this.pwdResponse['dueDate'] = null;
        }
        this.prefilledKyes =[];
        this.$validator.reset();

    },

  // getJobDetails(){
  //     let path ="";
  //     let postData ={};
  //     this.$store.dispatch('commonAction', {"data":postData ,"path":path})
  //         .then((response)=>{
  //           let responseData = response;
  //           _.forEach(this.jobDetails , (item ,key)=>{
  //             if(_.has(responseData ,key) && responseData[key]){

  //               this.jobDetails[key] = responseData[key];


  //             }

  //           });
  //           this.jobDetails =_.cloneDeep(this.jobDetails);
  //         })

  //   },
    prefillJobDetails(){
      var _dt;
      this.prefillJobDetailsError=''
      this.prefilledKyes =[];
    if(this.pwdResponse.documents.length>0){
     
    this.filesAreuploading = true;  
    this.pwdResUpdating = true
    let path ="/common/extract-data-from-pdf";
    let postData ={
      "docType": "pwd",
      documents:[],
    };
    //postData['documents'] = this.pwdResponse['documents']
    _.forEach(this.pwdResponse['documents'] ,(doc)=>{
      postData['documents'].push(doc.path)
        //return doc.path;
    })
    this.$store.dispatch('commonAction', {"data":postData ,"path":path})
        .then((response)=>{
          this.filesAreuploading = false; 
          this.pwdResUpdating = false 
          let responseData = response['jobDetails'];
          _dt = _.cloneDeep(response['jobDetails']);
          if(_.has(responseData ,"pwdStatus") ){
              this.pwdStatus =responseData['pwdStatus'];
              this.prefilledKyes.push('pwdStatus');
            }
          _.forEach(this.jobDetails , (item ,key)=>{
            if(_.has(responseData ,key) && responseData[key]){

              this.jobDetails[key] = responseData[key];
              this.prefilledKyes.push(key);

            }
            _.forEach(this.pwdResponse , (item ,key)=>{
            if(_.has(responseData ,key) && responseData[key]){
              this.pwdResponse[key] = responseData[key];
              this.prefilledKyes.push(key);
            }

          });
            if(this.checkProperty(responseData,'pwdStatus')){
            this.pwdStatus = this.checkProperty(responseData,'pwdStatus')
            this.disablePWDstatus = true
            this.loadingFields(this.pwdStatus)
          }
          else{
            this.disablePWDstatus = false
          }

          var _self = this;

          setTimeout(function(){

            if(_.has(responseData,'issuedDate')){
            _self.pwdResponse['issuedDate'] = _.cloneDeep(_dt['issuedDate']);
            }
            if(_.has(responseData,'receivedDate')){
            _self.pwdResponse['receivedDate'] = _.cloneDeep(_dt['receivedDate']);
            }
            if(_.has(responseData,'dueDate')){
            _self.pwdResponse['dueDate'] = _.cloneDeep(_dt['dueDate']);
            }

            _self.jobDetails.workAddresses[0].stateDetails = _dt.workAddresses[0].stateDetails;
            _self.jobDetails.workAddresses[0].stateId = _dt.workAddresses[0].stateId;
          },500)

          setTimeout(function(){
             _self.jobDetails.workAddresses[0].locationId = _dt.workAddresses[0].locationId;
             _self.jobDetails.workAddresses[0].locationDetails = _dt.workAddresses[0].locationDetails;
          },800)



          

          });
          this.jobDetails =_.cloneDeep(this.jobDetails);
          this.$vs.loading.close();
        }).catch((errr)=>{
          // this.showToster({message:errr,isError:true });
          this.prefillJobDetailsError = errr
          this.filesAreuploading = false;  
          this.pwdResUpdating = false ;
          this.$vs.loading.close();
        });
      }

    },
  checkPwdStatus(){
    if(_.has(this.petitionDetails ,'pwdStatus')){

      
      if(this.petitionDetails['pwdStatus'] =="Filed" && this.pwdStatus =="Filed" ){
        //this.pwdStatus ='';
      }
      //   pwdStatusList:["Filed" ,"Certified"],
    }
  },
  updateissuedDate(val){
    if(val){
    //   if(this.pwdResponse['receivedDate']){
    //   let startData = moment(val);
    //   let endData= moment(this.pwdResponse['receivedDate'])
    //   if(startData.isAfter(endData , 'day')){
    //     this.pwdResponse['receivedDate'] = null
    //   }
    // }
    if(this.pwdResponse['dueDate']){
      let startDate = moment(val);
      let endDate= moment(this.pwdResponse['dueDate'])
      if(startDate.isAfter(endDate , 'day')){
        this.pwdResponse['dueDate'] = null
      }
    }
    }
    else{
      this.pwdResponse['dueDate'] = null
    }
  },
    updatesocCode(item){ 

      if(_.has( item ,'id')){
      this.pwdResponse['socCode'] = item['id'];
      }
    },
  getMasterSocList(){

            let query = {};
            query["page"] = 1;
            query["perpage"] = 10000;
            query["matcher"] = {};
            query["category"] = "soc_codes";


            this.$store
            .dispatch("getMasterData", query)
            .then((response) => {
            this.masterSocList = response.list;

            if(this.jobDetails['preferredSocCode']){
              this.jobDetails['preferredSocCodeDetails'] =_.find(this.masterSocList ,{"id":this.jobDetails['preferredSocCode']})
              this.$validator.reset()
            }


            //alert(this.perpage);
            })
            .catch(() => {
            this.masterSocList = [];

            });

  },
  remove(index ,docs){
    docs.splice(index ,1);
    this.showDocumentsError =false;
    this.prefillJobDetailsError=''
    if(this.pwdResponse['documents'].length<=0){
      this.showDocumentsError =true;
  }

  },
  /**
   * 
   * @param userType | String
   * @param typeId | String
   * @param childrenId | String
   * @param userName | String
   */
  uploadDocuments(){
    
    let self = this;
    this.pwdDocFormatError ='';
       let docs =_.cloneDeep(this.documentModel);
       this.documentModel=[];
        
          docs = docs.map(
              (item) =>{
                  item = {
                      size: item.size?item.size:0,
                      name: item.name,
                      file: item.file,
                      path: "",
                      mimetype: item.type,
                      extn:item.extn?item.extn:'',
                      documentType:item.documentType?item.documentType:null,
                      userName:''
                     
                  }
                 
                  
              return item;

            }
          );
         
          if (docs.length > 0) {
             
         
           
              
              let count =0;
              docs.forEach(function (doc) {

                if( !( doc.mimetype=='application/pdf' )  ){
                  self.filesAreuploading = false;  
                  self.pwdDocFormatError ="Upload only pdf documents";     
                  self.$vs.loading.close();    
                return false;

              }else{

              }
                 self.filesAreuploading = true;
                 self.$vs.loading();
                  let formData = new FormData();
                  formData.append("files", doc.file);
                  formData.append("secureType", "private");
                  formData.append("getDetails", true);
                  self.$store.dispatch("uploadS3File", formData).then((response) => {
                    count = count+1;
                      if (response.data && response.data.result) {
                          response.data.result.forEach((urlGenerated) => {
                            //alert(JSON.stringify(urlGenerated))
                              // doc.url = urlGenerated;
                               doc.path = urlGenerated['path'];
                               doc.mimetype = urlGenerated['mimetype'];
                                doc.extn = urlGenerated['extn'];
                                if(_.has(urlGenerated ,'size')){
                                  doc['size'] = urlGenerated['size']
                                }
                                
                               
                              delete doc.file;
                              if(urlGenerated['path']){
                                self.pwdResponse['documents'] =[];
                                 self.pwdResponse['documents'].push(doc)
                                 self.prefillJobDetails()
                               //  self.statusDocuments.push(doc)
                               self.showDocumentsError =false;
                              }
                              
                              if(parseInt(count)>=docs.length){
                                 self.filesAreuploading = false;
                                 self.pwdResUpdating =false;
                               

                              }
                          });
                          if(count>=docs.length){
                            self.filesAreuploading = false;
                            self.pwdResUpdating =false;
                         

                          }
                          
                      }
                     
                  });
              });
          }
  },
 
    
  fileNameChenged(index, fileindex) {
          this.disable_uploadBtn = false;

          _.forEach(this.pwdResponse['documents'], (doc, value) => {
              let fname = doc.name;
              fname = fname.trim();

              if (!fname) {
                  this.disable_uploadBtn = true;
              }
          });

      },


    
  submitForm() {
    
          this.pewResponceUpdateStatusError='';
          this.showDocumentsError =false;
          
       this.prefillJobDetailsError='';
          this.$validator.validateAll("uscisstatus").then((result) => {
            if(this.checkProperty(this.pwdResponse ,'documents' ,'length')<=0 && this.ACTIVITYCODE !='EFILE_PWD'){
              this.showDocumentsError =true;
            }

             if(!this.showDocumentsError && result && !this.filesAreuploading){
              this.pwdResUpdating =true;
              let path ="/perm/upload-job-details";
              let data ={
                
                petitionId: "",
               "typeName": "",
              "subTypeName":"",
              "isPwdFiled": true,
              "hasJobDetails":true,
              "pwdStatus": "Filed", 
              "pwdResponse": null,
              "jobDetails":null,

              } 
              data['action'] ="CREATE_JOB_DESC"
              data['petitionId'] = this.checkProperty( this.petitionDetails ,'_id');
              data['pwdId'] = this.checkProperty( this.petitionDetails ,'_id');
              if(this.loadedFromPwdLibrary){
                path ="/pwd/upload-job-details";

                data['pwdId'] = this.checkProperty( this.petitionDetails ,'_id');

                if(this.checkProperty( this.petitionDetails ,'petitionList' ,'length')==1 && this.petitionDetails['completedActivities'].indexOf('PWD_CERTIFID')<=-1 ){
                    path ="/perm/upload-job-details";
                    data["typeName"] ="GC-Employment";
                    data["subTypeName"] ="GC-Employment";
                    data['petitionId'] = this.petitionDetails['petitionList'][0]['_id'];
                }
              }
              if(_.has(this.jobDetails ,'noOfPositions' )){
                this.jobDetails['noOfPositions'] = parseInt(this.jobDetails['noOfPositions']);
              }
             
              data['jobDetails'] = this.jobDetails;
              data['pwdStatus'] =  this.pwdStatus;
              data['pwdResponse'] = this.pwdResponse;
             
              data['typeName'] = this.checkProperty( this.petitionDetails , 'typeDetails','name');
              data['subTypeName'] = this.checkProperty( this.petitionDetails ,'subTypeDetails','name');
              
              //alert(path);

              this.$store.dispatch('commonAction' ,{ "data":data ,'path':path})
              .then((res)=>{
                this.showToster({message:res['message'],isError:false });
                this.hideMe();
                this.$emit("updatepetition");
              })
              .catch((error)=>{
                this.pewResponceUpdateStatusError =error;
                this.pwdResUpdating =false;
               })

              

             }else{
              const $ = JQuery;
              if($('.text-danger:visible')){
                  $('.errorScroll').scrollTop($('.text-danger:visible').first().parent().offset().top-50);
                }
             }
          });
  },
  hideMe() {

    this.$emit("hideMe");
    setTimeout(()=>{
        this.$modal.hide('updateUscisStatus');
      },10);
  },

},
watch: {
  showPopup(val) {
    if (!val){
      this.$emit("hideMe");
      this.$modal.hide('updateUscisStatus');
    } 
  },
},
mounted() {
  this.$store.dispatch("getcountries").then(response => {
      this.countries = response;
    });
  
    this.getMasterSocList();
    this.showPopup = true;
    this.$modal.show('updateUscisStatus');
    if(_.has(this.petitionDetails ,'pwdStatus')){
      if(["Filed","Certified"].indexOf(this.petitionDetails['pwdStatus']) >-1){
        this.pwdStatus =this.petitionDetails['pwdStatus'];
      }
        
     if(this.petitionDetails['pwdStatus'] =="Filed"){
       this.pwdStatus ="Certified";
       //this.pwdStatusList = ["Certified"]

     }
    }

     if(_.has(this.petitionDetails ,'jobDetails')){
     
      _.forEach(this.jobDetails , (item ,key)=>{
       
          if(_.has(this.petitionDetails['jobDetails'] ,key) && this.petitionDetails['jobDetails'][key]){

            this.jobDetails[key] = _.cloneDeep(this.petitionDetails['jobDetails'][key]);
            


          }

        });

        if(!this.checkProperty(this.jobDetails ,"altJobRequirements")){
            this.jobDetails['altJobRequirements'] =  {

                areAltSetsOfEducation:"",// { type: String},
                altevelOfEducation: null,//{ type: Schema.Types.ObjectId, default: null  }, //0bjectId
                altevelOfEducationDetails:null,
                usDiplomaOrDegreeAccepted:'', //{type: String},
                majorsOrFieldsOfStudyAccepted: '',//{type: String},
                isAltTrainingForTheJobOpporAccepted: '',//"Yes" Or "No"
                noOfMonthsOfAltTrainingAccepted: null,//{type: String},
                filedsOrNamesOfTrainingAccepted: "",//{ type: String },
                altEmpExpAccepted: "", //"Yes" Or "No"
                noOfMonthsAltEmpExpAccepted:null,
                splSkillOrOtherRequi:'',
                ForeignLanguage:'',
                LicenseCertification:'',
                residencyFellowship:'',
                otherSplSkillsOrRequi:''

                }
                
          }
        this.jobDetails =_.cloneDeep(this.jobDetails);
    }
    this.initData();
    
   
  
},
data: () => ({
  editor: ClassicEditor,
 editorConfig: {
     toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
 },
  prefillJobDetailsError:'',
  disablePWDstatus:false,
  prefilledKyes:[],
  pwdDocFormatError:'',
  countries: [],
  jobDetails: {
    noOfPositions:'',
  wageRate: "",
  socOccuTitle: "",
  preferredSocOccuTitle:"",

  socCode: "",
  socCodeDetails:null,
  jobTitle: "",
  preferredSocCode: '',
  preferredSocCodeDetails:null,
  classification: "",
  description: "",
  skills: [],
  minDegree: '',
  majorFieldsOfStudy: "",
  expInYears: "",
  altJobRequirements: {

    // Are alternate sets of Education, Training, and/or Experience accepted? "Yes", "No"

    areAltSetsOfEducation:"",// { type: String},
    altevelOfEducation: null,//{ type: Schema.Types.ObjectId, default: null  }, //0bjectId
    altevelOfEducationDetails:null,
    usDiplomaOrDegreeAccepted:'', //{type: String},
    majorsOrFieldsOfStudyAccepted: '',//{type: String},
    isAltTrainingForTheJobOpporAccepted: '',//"Yes" Or "No"
    noOfMonthsOfAltTrainingAccepted: null,//{type: String},
    filedsOrNamesOfTrainingAccepted: "",//{ type: String },
    altEmpExpAccepted: "" ,//"Yes" Or "No"
    noOfMonthsAltEmpExpAccepted:null,
    splSkillOrOtherRequi:'',
    ForeignLanguage:'',
    LicenseCertification:'',
    residencyFellowship:'',
    otherSplSkillsOrRequi:''

    },
      workAddresses: [{
        "companyName": "",
        "line1" : "",
        "line2" : "",
        "aptType": "",
        "locationId" :'' ,
        "stateId" :'' ,
        "countryId" :'' ,
        "zipcode" : "",
        "locationDetails" : {
          "id" : '',
          "name" : "",
          "stateId" : '',
          "countryId" :'' 
        },
        "stateDetails" : {
          "id" :'' ,
          "name" : "",
          "shortName" : "",
          "countryId" : ''
        },
        "countryDetails" : {
          "id" : 231,
          "shortName" : "US",
          "name" : "United States",
          "phoneCode" : 1,
          "order" : 1,
          "currencySymbol" : "$",
          "currencyCode" : "USD",
          "zipcodeLength" : 5
        },
        "workLocation": true
      }]
    },
  showDocumentsError:false,
  masterSocList:[],
  pwdResUpdating:false,
  pewResponceUpdateStatusError:'',
  pwdResponse:{
      "issuedDate": null,
      "receivedDate": null,
      "dueDate": null,
      "description": "",
      "documents": [],
      "documentType": "",

    },
    pwdStatus:'',
    pwdStatusList:["Filed" ,"Certified"],

 
  
 documentTypes:["Original" ,"Electronic" ],
  documentModel:[],
  statusDocuments:[],
 filesAreuploading: false,
  
  uploading: false,
  courierList: [],
  tracking: { documents: [], receiptNumber: null, receiptName: null },
  
  
  openDate: new Date().setFullYear(new Date().getFullYear()),
  startEligibleDate: new Date().setFullYear(new Date().getFullYear()),
  
  disabled_btn: false,
  showPopup: false,
  documents: [],
 
}),
props: {
  loadedFromPwdLibrary:{
    type:Boolean,
    default:false
    },
  ACTIVITYCODE: {
    type: String,
    default: null,
  },
  petitionDetails: {
    type: Object,
    default: null,
  },
},
};
</script>
