
<template>
  <vs-popup
    class="holamundo main-popup"
    title="Submit to Law Firm"
    :active.sync="showPopup"
  >
    <form data-vv-scope="submittolawfirmform" @submit.prevent @keydown.enter.prevent>
      <div class="form-container">
        <div class="vx-row">
          <div class="vx-col w-full">
            <div class="form_group mb-4">
              <label class="form_label">Comments</label>
              <!-- <vs-textarea
                data-vv-as="Comments"
                v-validate="'required'"
                v-model="comments"
                name="comments"
                class="w-full"
              /> -->
              <ckeditor data-vv-as="Comments"
                v-validate="'required'"
                v-model="comments"
                name="comments"
                class="w-full"  :editor="editor" :config="editorConfig"></ckeditor>

              <span
                class="text-danger text-sm"
                v-show="errors.has('submittolawfirmform.comments')"
                >{{ errors.first("submittolawfirmform.comments") }}</span
              >
            </div>
          </div>
        </div>
        <div class="text-danger text-sm formerrors mt-2" v-show="formErrors">
          <vs-alert
            color="warning"
            class="warning-alert reg-warning-alert no-border-radius"
            icon-pack="IntakePortal"
            icon="IP-information-button"
            active="true"
            >{{ formErrors }}</vs-alert
          >
        </div>
      </div>
      <div class="popup-footer">
        <span class="loader" v-if="loading"
          ><img src="@/assets/images/main/loader.gif"
        /></span>
        <vs-button
          color="dark"
          @click="showPopup = false"
          class="cancel"
          type="filled"
          >Cancel</vs-button
        >
        <vs-button
          :disabled="comments == '' || comments.trim() == '' || loading"
          color="success"
          @click="submitForm()"
          class="save"
          type="filled"
          >Submit</vs-button
        >
      </div>
    </form>
  </vs-popup>
</template>
<script>
import moment from 'moment'
import Vue from 'vue';
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';

export default {
  methods: {
    submitForm() {
         this.formErrors ='';
         let postData = {
             petitionId: this.petitionDetails['_id'],
            comment: this.comments,
            action:'SUBMIT_TO_LAW_FIRM', 
            today: moment().format('YYYY-MM-DD'), 
           subTypeName:this.checkProperty(this.petitionDetails,'subTypeDetails','name'),
           typeName:this.checkProperty(this.petitionDetails,'typeDetails','name'),

         };
         
         this.$validator.validateAll("submittolawfirmform").then((result) => {
            if (result) {
               this.loading =true;
               let path ="/petition/manage-approval-process";
               if([3].indexOf(this.checkProperty(this.petitionDetails,'typeDetails', 'id' )) >-1 &&  [15].indexOf(this.checkProperty(this.petitionDetails,'subTypeDetails', 'id' )) >-1){
                  path ="/perm/manage-approval-process";
               }
               
               this.$store
              .dispatch("commonAction", {"data":postData ,"path":path})
              .then(response => {
                
                 this.showToster({message:response.message,isError:false });
                 this.showPopup =false;
                  this.loading =false;
                    this.$emit("updatepetition", "Case Details");
                  this.hideMe()
           
                
                
                                
              })
              .catch((error)=>{
                 this.loading =false;
                this.formErrors =error;
              })
       
       

              
            }
          });
    },
    hideMe() {
      this.$emit("hideMe");
    },
  },
  watch: {
    showPopup(val) {
      if (!val) this.$emit("hideMe");
    },
  },
  mounted() {
    this.showPopup = true;

    if ([50].indexOf(this.getUserRoleId) > -1) {
      this.comments =
        "Case is being submitted to " +
        this.petitionDetails.tenantDetails.name +
        " for further actions.";
    } else {
      this.comments =
        "Case " +
        this.petitionDetails.typeDetails.name +
        ", " +
        this.petitionDetails.subTypeDetails.name +
        " is being assigned for further actions";
    }
  },
  data: () => ({
    editor: ClassicEditor,
 editorConfig: {
     toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
 },
  formErrors:"",
    loading:false,
    showPopup: false,
    comments: false,
    formerrors: {
      msg: "",
    },
  }),
  props: {
    caseNumber: {
      type: String,
      default: null,
    },
    isCaseNumberEdit: {
      type: Boolean,
      default: false,
    },
    petitionDetails: {
      type: Object,
      default: null,
    },
  },
};
</script>