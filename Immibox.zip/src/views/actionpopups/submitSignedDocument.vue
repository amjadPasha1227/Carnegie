<template>
  <vs-popup
    class="Change_petition_wrap"
    :title="popTitle"
    :active.sync="showPopup"
    v-if="showPopup"
  >
    <div class="Change_petition">
      <div class="vx-col w-full">
        
        <!---
         fileModel:[],
        uploadScanedFilsList:[],
         --->
        
         <div @click="paralegalformerrors = ''" class="vx-row form-container pad0" v-if="ACTIVITYCODE !='UPLOAD_BENEFICIARY_SCANNED_COPY' && [50,51].indexOf(getUserRoleId)<=-1 && ACTIVITYCODE !='RFE_RESPONSE_UPLOAD_DOCS'">
              <div class="custom-radio_wrap wf_radio">
                
                <ul class="custom-radio mb-1" v-if="showOptions">
                  <li v-if="([2,10].indexOf(checkProperty(petitionDetails, 'type' ))>-1 && checkProperty(petitionDetails, 'petitionerId') ) ||  [2,10].indexOf(checkProperty(petitionDetails, 'type' ))<=-1 ">
                      <vs-radio    name="workflowType"  @input="updateDocUserType" vs-value="Petitioner"   v-model="docUserType" class="w-full"
                      >Petitioner</vs-radio> 
                  </li>
                  <li>
                    
                    <vs-radio  v-if="checkH4Required || [2,10].indexOf(checkProperty(petitionDetails, 'type' ))>-1"  name="workflowType" @input="updateDocUserType" vs-value="Beneficiary" v-model="docUserType" class="w-full"
                      >Beneficiary</vs-radio> 
                  </li>
                  
                  <li>
                      <vs-radio    name="workflowType"  @input="updateDocUserType" vs-value="Internal"   v-model="docUserType" class="w-full"
                      >Law Firm</vs-radio> 
                  </li>
                </ul>
              </div>
        </div>
       
        <div class="vx-row mt-3">
          <div class="vx-col w-full" @click="paralegalformerrors = ''">
            <vx-input-group class="form-input-group select-upload-group">
              <div class="uploadsec_wrap">
                <div class="w-full" @click="fileModel = []">
                  <div class="relative">
                    <file-upload
                      v-model="fileModel"
                      class="file-upload-input mb-0"
                      style="height: 50px"
                      :name="'pdocumentUpload'"
                      :multiple="true"
                      :hideSelected="true"
                    
                      label="Forms and Letters"
                     
                      accept="application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                      @input="upload(fileModel)"
                    >
                      <img
                        class="file-icon"
                        src="@/assets/images/main/file-upload.svg"
                      />
                      Upload
                    </file-upload>
                    <span class="loader" v-if="filesAreuploading"
                      ><img src="@/assets/images/main/loader.gif"
                    /></span>
                  </div>
                 
                  <span class="file-type mb-0"
                    >(File Type: PDF, DOC, Max file size: 1MB)</span
                  >
                  <input  type="hidden" data-vv-as="Documents"  v-validate="'required|docsValidate'" v-model="uploadScanedFilsList" name="pdocuments" >
              
                  <span class="text-danger text-sm"   v-show="errors.has('pdocuments')">Documents are required</span>
                  <VuePerfectScrollbar class="scrollbardoc">
                    <div
                      class="uploded-files_wrap mt-5"
                      v-if="
                        uploadScanedFilsList && uploadScanedFilsList.length > 0
                      "
                    >
                      <div
                        class="w-full"
                        v-for="(fil, fileindex) in uploadScanedFilsList"
                        :key="fileindex"
                      >
                        <div class="uploded-files">
                          <vx-input-group class="form-input-group">
                            <vs-input
                              v-on:keyup="
                                fileNameChengedScannedFiles(fileindex)
                              "
                              v-validate="'required'"
                              required
                              class="w-full"
                              :name="'fName' + fileindex"
                              v-model="uploadScanedFilsList[fileindex]['name']"
                              data-vv-as="File Name"
                            />

                            <span
                              class="text-danger text-sm"
                              v-if="errors.has('fName' + fileindex)"
                              >{{ errors.first("fName" + fileindex) }}</span
                            >
                            <span
                              class="text-danger text-sm"
                              v-else-if="
                                !uploadScanedFilsList[fileindex]['name']
                              "
                              >* File Name is required</span
                            >

                            <div
                              class="delete"
                              style="z-index: 999"
                              @click="remove(fileindex, uploadScanedFilsList)"
                            >
                              <img src="@/assets/images/main/cross.svg" />
                            </div>
                          </vx-input-group>
                        </div>
                      </div>
                    </div>
                  </VuePerfectScrollbar>
                </div>
              </div>
            </vx-input-group>
          </div>
        </div>

        

      </div>

      <div
        class="text-danger text-sm formerrors"
        v-if="paralegalformerrors != ''"
      >
        <vs-alert
          color="warning"
          class="warning-alert reg-warning-alert no-border-radius"
          icon-pack="IntakePortal"
          icon="IP-information-button"
          active="true"
          >{{ paralegalformerrors }}</vs-alert
        >
      </div>
    </div>
    <div class="popup-footer">
   
      <button
        @click="hideMe()"
        class="btn cancel"
      >
        Cancel
      </button>
      <button
        class="btn save"
        v-bind:disabled="
        
          filesAreuploading 
        "
        @click="submitForm()"
      >
        <img
          class="loader"
          v-if="fuploder"
          src="@/assets/images/main/loader.gif"
        />Submit
      </button>
    </div>
  </vs-popup>
</template>
<script>
import moment from "moment";
import FileUpload from "vue-upload-component/src";
import docType from "@/views/common/docType.vue";
import VuePerfectScrollbar from "vue-perfect-scrollbar";

export default {
    components: {
    docType,
    FileUpload,
    VuePerfectScrollbar
  },
  methods: {
    updateDocUserType(){

    },
    remove(index ,docs){
      docs.splice(index ,1);
    },
    upload(docs) {
      this.paralegalformerrors ='';
      if (docs.length > 0) {
        var self = this;

        let invaliedFiles =[];
        docs.forEach(function (doc) {
          if(
            (doc.mimetype == "application/pdf" || doc.type == "application/pdf") ||
            (
                doc.mimetype == "application/msword" ||  doc.type == "application/msword" ||
                doc.mimetype ==  "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||
                doc.type ==  "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            )
                  
            ){}else{
              invaliedFiles.push(doc);
            }

        });
        if(invaliedFiles.length>0){
          self.fileModel =[];
          self.paralegalformerrors ="Upload Only Pdf/MS Word Files"
          self.showToster({ message: "Upload Only Pdf/MS Word Files ", isError: true });
          return false;
        }

       
        let count = 0;
        docs.forEach(function (doc) {
          let formData = new FormData();
          formData.append("files", doc.file);
          formData.append("secureType", "private");
          formData.append("getDetails", true);
          if(
            (doc.mimetype == "application/pdf" || doc.type == "application/pdf") ||
            (
                doc.mimetype == "application/msword" ||  doc.type == "application/msword" ||
                doc.mimetype ==  "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||
                doc.type ==  "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            )
                  
            ){

              self.filesAreuploading = true;

          self.$store.dispatch("uploadS3File", formData).then((response) => {
            count = count + 1;
            if (response.data && response.data.result) {
              response.data.result.forEach((urlGenerated) => {
                urlGenerated['status'] =true; 
                let tempUrl = urlGenerated
                tempUrl = Object.assign(tempUrl, { uploadedBy: self.checkProperty(self.getUserData, 'userId'), uploadedByName: self.checkProperty(self.getUserData, 'name'), uploadedByRoleId: self.getUserRoleId, uploadedByRoleName: self.checkProperty(self.getUserData, 'loginRoleName') });
                self.uploadScanedFilsList.push(tempUrl);
                self.uploadScanedFilsList = _.cloneDeep(
                  self.uploadScanedFilsList
                );
                if (parseInt(count) >= docs.length) {
                  self.filesAreuploading = false;
                }
              });
              if (count >= docs.length) {
                self.filesAreuploading = false;
              }
            }
          });
        }else{
          self.showToster({ message: "Upload Only Pdf/MS Word Files ", isError: true });

        }
        });
      }
    },

    getscannedCopiesList() {
      this.formsAndLettersList = [];
      let finalList = [];
      let postData = {
        petitionId: this.petition._id,
        page: 1,
        perpage: 100000,
      };
      this.$store
        .dispatch("getList", {
          data: postData,
          path: "/petition/scanned-copies-list",
        })
        .then((response) => {
          if (_.has(response, "list")) {
            this.scannedCopiesList = response["list"];
          }
        });
    },
    checkuploadScnnedFiles() {
      let val = false;
      if (this.uploadScanedFilsList.length > 0) {
        _.forEach(this.uploadScanedFilsList, (item) => {
          if (
            !_.has(item, "name") ||
            item["name"] == "" ||
            item["name"].trim() == ""
          ) {
            val = true;
          }
        });
      } else {
        val = true;
      }
      return val;
    },
    submitForm() {
      this.paralegalformerrors = "";
      
      this.$validator.validateAll().then((result) => {
      if(!result){
         return false;
      }
      
        if (this.uploadScanedFilsList.length > 0) {
          let uploadPayload = {
            documents: this.uploadScanedFilsList,
            petitionId: this.petitionDetails._id,
            today: moment().format("YYYY-MM-DD"),
            "docUserType":"Petitioner"
          };
         if(this.ACTIVITYCODE=='RFE_RESPONSE_UPLOAD_DOCS'){
          //alert(JSON.stringify(uploadPayload))
          //uploadPayload = Object.assign(uploadPayload ,{"docUserType":'Beneficiary'})
         }
         else if(this.ACTIVITYCODE=='UPLOAD_BENEFICIARY_SCANNED_COPY'){

            uploadPayload = Object.assign(uploadPayload ,{"docUserType":'Beneficiary'})
          }else{

              if([50].indexOf(this.getUserRoleId)>-1){
                uploadPayload['docUserType'] = 'Petitioner';

              }else if([51].indexOf(this.getUserRoleId)>-1){
                uploadPayload['docUserType'] = 'Beneficiary';

              }else{
                uploadPayload['docUserType'] = this.docUserType;

              }
          }
          if([2,10].indexOf(this.checkProperty(this.petitionDetails, 'type' ))>-1 && !this.checkProperty(this.petitionDetails, 'petitionerId') ){
            //uploadPayload['docUserType'] = 'Beneficiary';
          }

          this.$store
            .dispatch("uploadScannedCopies", uploadPayload)
            .then((response) => {
              this.showToster({ message: response.message, isError: false });
              this.uploadSignedPopup = false;
              this.checkuploadScnnedFiles = [];
              this.hideMe();
              this.$emit("updatepetition");
            })
            .catch((error) => {
              this.paralegalformerrors = error;
              //this.showToster({ message: error, isError: true });
            });
        } else {
          this.paralegalformerrors = "Documents are required";
        }
      });
    },
    hideMe() {
      this.$emit("hideMe");
    },
  },
  watch: {
    showPopup(val) {
      if (!val) this.$emit("hideMe");
    },
  },
  mounted() {
  
   
    this.popTitle= 'Upload Signed Documents 234567';
    if(this.ACTIVITYCODE=='UPLOAD_SIGNED_DOCUMENTS' && this.petitionDetails["completedActivities"].indexOf("RFE_REQUEST_PETITIONER_SIGN")>-1){
      this.popTitle= 'RFE Upload Signed Documents';  
    }
    this.showPopup = true;
    if(this.ACTIVITYCODE=='UPLOAD_BENEFICIARY_SCANNED_COPY'){
      this.docUserType = 'Beneficiary';
      this.popTitle= 'Upload Beneficiary Signed Documents';
      if([51].indexOf(this.getUserRoleId)>-1){
        this.popTitle= 'Upload Signed Documents';
      }
    }
    if(this.ACTIVITYCODE=='RFE_RESPONSE_UPLOAD_DOCS'){
      this.popTitle= 'Response Documents';  
    }
    if([2,10].indexOf(this.checkProperty(this.petitionDetails, 'type' ))>-1 && !this.checkProperty(this.petitionDetails, 'petitionerId') ){
      this.docUserType = 'Beneficiary';
    }
    
    setTimeout(()=>{

    
    if([50].indexOf(this.getUserRoleId)>-1){
      this.docUserType = 'Petitioner';

    }else if([51].indexOf(this.getUserRoleId)>-1){
      this.docUserType = 'Beneficiary';

    }else if(!this.checkH4Required){
      
      this.docUserType = 'Petitioner';

    }

    if([2,10].indexOf(this.checkProperty(this.petitionDetails, 'type' ))>-1 && !this.checkProperty(this.petitionDetails, 'petitionerId') ){
      this.docUserType = 'Beneficiary';
    }
    this.showOptions =true;
  },100);

  
  },
  data: () => ({
    showOptions:false,
    popTitle:'Upload Signed Documents',
    docUserType:'Beneficiary',
            fuploder: false,

    paralegalformerrors:'',
disabled_btn:false,
    fileModel: [],
    uploadScanedFilsList: [],
    filesAreuploading: false,
    loading: false,
    showPopup: false,
    comments: false,
    formerrors: {
      msg: "",
    },
  }),
  props: {
    ACTIVITYCODE: {
      type: String,
      default: null,
    },
    petitionDetails: {
      type: Object,
      default: null,
    },
    workFlowDetails:{
      type: Object,
      default: null,
    }

  },
  computed:{
    
    checkH4Required(){
      let h4Required = false;
       if(this.checkProperty(this.petitionDetails ,'beneficiaryInfo' ,'maritalStatus') !=1){
       
        if(this.checkProperty(this.petitionDetails['dependentsInfo'],'spouse' ,'h4Required') ==true){
          h4Required =true;
        }
        if(this.checkProperty( this.petitionDetails['dependentsInfo'] ,'childrens')){
               _.forEach(this.petitionDetails['dependentsInfo']['childrens'],(item)=>{
                   if(item.h4Required==true){
                    h4Required =true;
                   }
                })
        }
      
       }
       return h4Required;
    }
  }
};
</script>
