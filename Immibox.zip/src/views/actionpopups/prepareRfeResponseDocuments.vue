<template>


<div>
  <modal
      name="modalForm"
      classes="v-modal-sec"
      :min-width="200"
      :min-height="200"
      :scrollable="true"
      :reset="true"
      width="600px"
      height="auto"
    >
      <div class="v-modal">
        <div class="popup-header fromDetailsPage">
          <h2 class="popup-title">{{ popTitle }}</h2>
          <span @click="hideMe()">
            <em class="material-icons">close</em>
          </span>
        </div>
        <form  @submit.prevent  class="trackingform">
          <div class="form-container" @click="paralegalformerrors = ''">
            <div class="vx-row mt-3">
              <div class="vx-col w-full" @click="paralegalformerrors = ''" v-if="ACTIVITYCODE=='RFE_PREPARE_RESPONSE_DOCS'">
                  <div class="uploadsec_wrap">
                    <div class="form_group w-full" @click="fileModel = []">
                      <label class="form_label">Documents<em>*</em></label>
                      <div class="relative">
                        <file-upload
                          v-model="fileModel"
                          class="file-upload-input mb-0"
                          style="height: 50px"
                          :name="'pdocumentUpload'"
                          :multiple="true"
                          :hideSelected="true"
                        
                          label="Forms and Letters"
                          
                          accept="application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                          @input="upload(fileModel)"
                        >
                          <img
                            class="file-icon"
                            src="@/assets/images/main/file-upload.svg"
                          />
                          Upload
                        </file-upload>
                        <span class="loader" v-if="filesAreuploading"
                          ><img src="@/assets/images/main/loader.gif"
                        /></span>
                      </div>
                      
                      <span class="file-type mb-0"
                        >(File Type: PDF, DOC, Max file size: 1MB)</span
                      >
                      <input  type="hidden" data-vv-as="Documents"  v-validate="'required|docsValidate'" v-model="uploadScanedFilsList" name="pdocuments" >
                  
                      <span class="text-danger text-sm"   v-show="errors.has('pdocuments')">*Documents are required</span>
                      <VuePerfectScrollbar class="scrollbardoc">
                        <div
                          class="uploded-files_wrap mt-5"
                          v-if="
                            uploadScanedFilsList && uploadScanedFilsList.length > 0
                          "
                        >
                          <div
                            class="w-full"
                            v-for="(fil, fileindex) in uploadScanedFilsList"
                            :key="fileindex"
                          >
                            <div class="uploded-files">
                              <vx-input-group class="form-input-group">
                                <vs-input
                                  v-on:keyup="
                                    fileNameChengedScannedFiles(fileindex)
                                  "
                                  v-validate="'required'"
                                  required
                                  class="w-full"
                                  :name="'fName' + fileindex"
                                  v-model="uploadScanedFilsList[fileindex]['name']"
                                  data-vv-as="File Name"
                                />

                                <span
                                  class="text-danger text-sm"
                                  v-if="errors.has('fName' + fileindex)"
                                  >{{ errors.first("fName" + fileindex) }}</span
                                >
                                <span
                                  class="text-danger text-sm"
                                  v-else-if="
                                    !uploadScanedFilsList[fileindex]['name']
                                  "
                                  >* File Name is required</span
                                >

                                <div
                                  class="delete"
                                  style="z-index: 999"
                                  @click="remove(fileindex, uploadScanedFilsList)"
                                >
                                  <img src="@/assets/images/main/cross.svg" />
                                </div>
                              </vx-input-group>
                            </div>
                          </div>
                        </div>
                      </VuePerfectScrollbar>
                    </div>
                  </div>
              </div>
              <div class="vx-col w-full mt-1"   >
                        <div class="form_group">
                          <label class="form_label">Comments<em>*</em></label>
                          
                          <ckeditor
                            data-vv-as="Comments"
                            v-validate="'required'"
                            v-model="description"
                            name="usciscomments"
                            class="w-full" :editor="editor" :config="editorConfig"></ckeditor>

                          <span
                            class="text-danger text-sm"
                            v-show="errors.has('usciscomments')"
                          >* Comments are required</span>
                        </div>
                        </div>
            </div>
          </div>
          <div class="popup-footer relative">
            <span class="loader" v-if="uploadSignedPopup"  ><img src="@/assets/images/main/loader.gif" /></span>
    
            <button
              @click="hideMe()"
              class="btn cancel"
              :disabled="uploadSignedPopup"
            >
              Cancel
            </button>
            <button
              class="btn save"
              v-bind:disabled="
              
                filesAreuploading || uploadSignedPopup
              "
              @click="submitForm()"
            >
              <img
                class="loader"
                v-if="fuploder"
                src="@/assets/images/main/loader.gif"
              />Submit
            </button>
          </div>
        </form>

        </div>
  </modal>

</div>
 
</template>
<script>
import moment from "moment";
import FileUpload from "vue-upload-component/src";
import docType from "@/views/common/docType.vue";
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import Vue from 'vue';
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';

export default {
    provide() {
      return {
          parentValidator: this.$validator,
      };
  },
    components: {
    docType,
    FileUpload,
    VuePerfectScrollbar
  },
  methods: {
    updateDocUserType(){

    },
    remove(index ,docs){
      docs.splice(index ,1);
    },
    upload(docs) {
      this.paralegalformerrors ='';
      if (docs.length > 0) {
        var self = this;

        let invaliedFiles =[];
        docs.forEach(function (doc) {
          if(
            (doc.mimetype == "application/pdf" || doc.type == "application/pdf") ||
            (
                doc.mimetype == "application/msword" ||  doc.type == "application/msword" ||
                doc.mimetype ==  "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||
                doc.type ==  "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            )
                  
            ){}else{
              invaliedFiles.push(doc);
            }

        });
        if(invaliedFiles.length>0){
          self.fileModel =[];
          self.paralegalformerrors ="Upload Only Pdf/MS Word Files"
          self.showToster({ message: "Upload Only Pdf/MS Word Files ", isError: true });
          return false;
        }

       
        let count = 0;
        docs.forEach(function (doc) {
          let formData = new FormData();
          formData.append("files", doc.file);
          formData.append("secureType", "private");
          formData.append("getDetails", true);
          if(
            (doc.mimetype == "application/pdf" || doc.type == "application/pdf") ||
            (
                doc.mimetype == "application/msword" ||  doc.type == "application/msword" ||
                doc.mimetype ==  "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||
                doc.type ==  "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            )
                  
            ){

              self.filesAreuploading = true;

          self.$store.dispatch("uploadS3File", formData).then((response) => {
            count = count + 1;
            if (response.data && response.data.result) {
              response.data.result.forEach((urlGenerated) => {
                urlGenerated['status'] =true; 
                let tempUrl = urlGenerated
                tempUrl = Object.assign(tempUrl, { uploadedBy: self.checkProperty(self.getUserData, 'userId'), uploadedByName: self.checkProperty(self.getUserData, 'name'), uploadedByRoleId: self.getUserRoleId, uploadedByRoleName: self.checkProperty(self.getUserData, 'loginRoleName') });
                self.uploadScanedFilsList.push(tempUrl);
                self.uploadScanedFilsList = _.cloneDeep(
                  self.uploadScanedFilsList
                );
                if (parseInt(count) >= docs.length) {
                  self.filesAreuploading = false;
                }
              });
              if (count >= docs.length) {
                self.filesAreuploading = false;
              }
            }
          });
        }else{
          self.showToster({ message: "Upload Only Pdf/MS Word Files ", isError: true });

        }
        });
      }
    },

  
    checkuploadScnnedFiles() {
      let val = false;
      if (this.uploadScanedFilsList.length > 0) {
        _.forEach(this.uploadScanedFilsList, (item) => {
          if (
            !_.has(item, "name") ||
            item["name"] == "" ||
            item["name"].trim() == ""
          ) {
            val = true;
          }
        });
      } else {
        val = true;
      }
      return val;
    },
    submitForm() {
      this.paralegalformerrors = "";
      
      this.$validator.validateAll().then((result) => {
       
      if(!result){
         return false;
      }
      
        if (this.uploadScanedFilsList.length <= 0 && this.ACTIVITYCODE=='RFE_PREPARE_RESPONSE_DOCS'){
          this.paralegalformerrors = "Documents are required";
          return false;
        }
       
          let uploadPayload = {
            documents: this.uploadScanedFilsList,
            petitionId: this.petitionDetails._id,
            today: moment().format("YYYY-MM-DD"),
            subTypeName: this.checkProperty(this.petitionDetails,"subTypeDetails", "name"),
            typeName: this.checkProperty(this.petitionDetails,  "typeDetails",  "name"),
            "comment":'',
            "action":''
          };
          uploadPayload['action']= this.ACTIVITYCODE;
          uploadPayload['comment']= this.description
          this.uploadSignedPopup =true;
          //path ="/petition/upload-rfe-response-docs,"
          let dispatch ="updateRfeReesponseDocs";
          if(this.ACTIVITYCODE=='RFE_REVIEW_RESPONSE_DOCS'){
            dispatch ="sendForRfeReesponseReview";
          }
           this.$store
            .dispatch(dispatch, uploadPayload)
            .then((response) => {
              this.showToster({ message: response.message, isError: false });
              this.uploadSignedPopup = false;
              this.checkuploadScnnedFiles = [];
              this.hideMe();
              this.$emit("updatepetition");
            })
            .catch((error) =>{
              this.paralegalformerrors = error;
              //this.showToster({ message: error, isError: true });
            });
        
      });
    },
    hideMe() {
      this.$emit("hideMe");
    },
  },
  watch: {
    showPopup(val) {
      if (!val) {
        this.$emit("hideMe")
        this.$modal.hide("modalForm");
       
    };
    },
  },
  mounted() {
  
   
    this.popTitle= 'Prepare RFE Response Documents';
    this.showPopup = true;
    this.$modal.show("modalForm");
    if(this.ACTIVITYCODE=='RFE_REVIEW_RESPONSE_DOCS'){
      
      this.popTitle= 'Send RFE Response Docs For Approval';
      
    }
   
    setTimeout(()=>{

    
    if([50].indexOf(this.getUserRoleId)>-1){
      this.docUserType = 'Petitioner';

    }else if([51].indexOf(this.getUserRoleId)>-1){
      this.docUserType = 'Beneficiary';

    }else if(!this.checkH4Required){
      
      this.docUserType = 'Petitioner';

    }
    this.$validator.reset();
  },100);

  
  },
  data: () => ({
    uploadSignedPopup:false,
    description:'',
    editor: ClassicEditor,
 editorConfig: {
     toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
 },
    popTitle:'Upload Signed Documents',
    docUserType:'Beneficiary',
            fuploder: false,

    paralegalformerrors:'',
disabled_btn:false,
    fileModel: [],
    uploadScanedFilsList: [],
    filesAreuploading: false,
    loading: false,
    showPopup: false,
    comments: false,
    formerrors: {
      msg: "",
    },
  }),
  props: {
    ACTIVITYCODE: {
      type: String,
      default: null,
    },
    petitionDetails: {
      type: Object,
      default: null,
    },
  },
  computed:{
    
    checkH4Required(){
      let h4Required = false;
       if(this.checkProperty(this.petitionDetails ,'beneficiaryInfo' ,'maritalStatus') !=1){
       
        if(this.checkProperty(this.petitionDetails['dependentsInfo'],'spouse' ,'h4Required') ==true){
          h4Required =true;
        }
        if(this.checkProperty( this.petitionDetails['dependentsInfo'] ,'childrens')){
               _.forEach(this.petitionDetails['dependentsInfo']['childrens'],(item)=>{
                   if(item.h4Required==true){
                    h4Required =true;
                   }
                })
        }
      
       }
       return h4Required;
    }
  }
};
</script>
