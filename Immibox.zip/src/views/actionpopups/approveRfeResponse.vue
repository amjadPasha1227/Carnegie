<template>
  <modal
    name="modalForm"
    classes="v-modal-sec"
    :min-width="200"
    :min-height="200"
    :scrollable="true"
    :reset="true"
    width="600px"
    height="auto"
  >
    <div class="v-modal">
      <div class="popup-header fromDetailsPage">
        <h2 class="popup-title" v-if="ACTIVITYCODE=='RFE_REQUEST_PETITIONER_SIGN'">RFE Submit for Petitioner Signing</h2>
        <h2 class="popup-title" v-else>Submit for Petitioner Signing</h2>
        <span @click="hideMe()">
          <em class="material-icons">close</em>
        </span>
      </div>
      <form @submit.prevent>
        <div class="form-container" @click="trackingErrors = ''">
          <!--- FORMS AND LATTERS SECTOION   item["createdBy"] this.getUserData['_id'] signerList:[],
    selectedSigners:[] -->

          <div  class="vx-col w-full" @keyup="requestsignCommentError = false"  v-if="false &&getTenantTypeId == 2"
          >
            <div class="form_group">
              <label class="form_label">Select Authorized Signatory<em>*</em> </label>
              <div class="con-select w-full select-large">
                <multiselect
                  name="signersList"
                  v-model="selectedSigner"
                  :close-on-select="true"
                  v-validate="'required'"
                  :multiple="false"
                  :show-labels="false"
                  label="name"
                  data-vv-as="Authorized Signatory"
                  placeholder="Select Authorized Signatory"
                  :options="signerList"
                  :searchable="true"
                  :allow-empty="false"
                >
                  <template slot="selection" slot-scope="{ values, isOpen }">
                    <span
                      class="multiselect__selectcustom"
                      v-if="values.length && !isOpen"
                      >{{ values.length }} selected</span
                    >
                    <span
                      class="multiselect__selectcustom"
                      v-if="values.length && isOpen"
                    ></span>
                  </template>
                </multiselect>
              </div>
            </div>
            <span class="text-danger text-sm" v-if="errors.has('signersList')"   > {{ errors.first("signersList") }} </span>
          </div>      
          <div class="vx-col w-full required_doc">
            <div>
              <h4 class="formsandlettes_title mb-4">Required Documents</h4>
              <ul class="formsandlettes req_docs_checks">
                <template v-for="(forms, index) in formsAndLettersList">
                  
                  <li :key="index">
                    
                    <vs-checkbox
                      @change="selectFormsandLatters(index, forms)"
                      :name="'selectedForSigning_' + index"
                      v-model="forms.selectedForSigning"
                      class=""
                      :title="forms.name">
                      
                      {{ forms.name }}
                      
                      </vs-checkbox
                    >
                  </li>
                  
                 
                </template>
              </ul>
            </div>
          </div>

          <div class="vx-col w-full" @keyup="requestsignCommentError = false">
            <div class="form_group">
              <label class="form_label">Comments<em>*</em></label>
              <!-- <vs-textarea
                data-vv-as="Comments"
                v-validate="'required'"
                v-model="requestsignformcomments"
                name="requestsignformcomments"
                class="w-full"
              /> -->
              <ckeditor  data-vv-as="Comments"
                v-validate="'required'"
                v-model="requestsignformcomments"
                name="requestsignformcomments"
                class="w-full"  :editor="editor" :config="editorConfig"></ckeditor>


              <span
                class="text-danger text-sm"
                v-if="errors.has('requestsignformcomments')"
              >
                Comments are required
              </span>
              <span
                class="text-danger text-sm"
                v-else-if="requestsignCommentError"
              >
                * Comments are required
              </span>
            </div>
          </div>

          <div v-if="false" class="vx-col w-full" style="margin-bottom: 20px">
            <!--- notifyPetitioner==  {{notifyPetitioner}} --  emailDocsForSign == {{ emailDocsForSign}} checkSendAttachments()-->

            <ul
              class="demo-alignment custom-radio notify_checks"
              vs-type="flex"
              vs-align="center"
            >
              <li>
                <vs-checkbox
                  @change="checkSendAttachments('notifyPetitioner')"
                  vs-name="workLocation"
                  v-model="notifyPetitioner"
                  :disabled="emailDocsForSign"
                >
                <span v-if="getTenantTypeId == 2">Notify Authorized Signatory</span>
                <span v-if="getTenantTypeId == 1">Notify Signer </span>
                </vs-checkbox>
              </li>
              <li>
                <vs-checkbox
                  vs-name="emailDocsForSign"
                  @change="checkSendAttachments('emailDocsForSign')"
                  v-model="emailDocsForSign"
                  >Send Documents by Email
                </vs-checkbox>
              </li>
            </ul>
          </div>

          <div
            class="text-danger text-sm formerrors mt-4"
            v-if="trackingErrors != ''"
          >
            <vs-alert
              color="warning"
              class="warning-alert reg-warning-alert no-border-radius"
              icon-pack="IntakePortal"
              icon="IP-information-button"
              active="true"
              >{{ trackingErrors }}</vs-alert
            >
          </div>
        </div>

        <div class="popup-footer relative">
          <span class="loader" v-if="requestsigning"
            ><img src="@/assets/images/main/loader.gif"
          /></span>
          <vs-button color="dark" class="cancel" type="filled" @click="hideMe()"
            >Cancel</vs-button
          >

          <vs-button
            :disabled="requestsigning"
            color="success"
            @click="submitForm"
            class="save"
            type="filled"
            >Submit
          </vs-button>
        </div>
      </form>
    </div>
  </modal>
</template>
<script>
import moment from "moment";
import FileUpload from "vue-upload-component/src";
import { EyeIcon } from "vue-feather-icons";
import docType from "@/views/common/docType.vue";
import Datepicker from "vuejs-datepicker-inv";
import * as _ from "lodash";
import Vue from 'vue';
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';


export default {
  components: {
    docType,
    EyeIcon,
    FileUpload,
    Datepicker,
  },
  methods: {
    fetchWorkFlowDetails(){
      
      if (this.checkProperty(this.petitionDetails ,'workflowId')) {

        let payLoad = {
          path: "/workflow/details",
          data: { workflowId: this.petitionDetails.workflowId },
        };
        this.$store
          .dispatch("commonAction", payLoad)
          .then((res) => {
            this.workFlowDetails = res;
            this.getSignerList();
          })
    }
  },
    getFormsAndLetters(callFromMenu =false) {
      this.$vs.loading();
      this.formsAndLettersList = []; 
       let finalList = [];


this.updateLoading(true);


this.$store.dispatch("getpetition", this.petitionDetails._id).then((response) => {
             
        this.$vs.loading.close();
       
        if (response && response.data && response.data.result ) {
            let petitionData = response.data.result;
            let lst = [];
            let rfeDocs = [];
            if(this.checkProperty(petitionData,'caseDocs') && this.checkProperty(petitionData['caseDocs'],'rfeResDocs','length') >0 ){
                rfeDocs = petitionData['caseDocs']['rfeResDocs'];
            
            
           
            _.forEach(rfeDocs, (mainItem) => {
                mainItem = Object.assign(mainItem, {
                reverse_document_versions: [],
                mainParentId: "",
                showMe: true,
                selectedForDownload: false,
                "viewmode":true,
                "selectedForSigning":false
                });
               lst.push(mainItem);
            });
          this.formsAndLettersList = _.cloneDeep(lst);
        }
          
        }
       
           
    })
  .catch((err) => {

    this.$vs.loading.close(); 
    this.formsAndLettersList = [];
    this.showToster({  message: err,  isError: true, });

    
    
  });
    },
    checkSendAttachments(action=''){
      setTimeout(() =>{
            if(this.notifyPetitioner && action=='notifyPetitioner'){
          //  this.emailDocsForSign =true;
         
            }
            
            if(this.emailDocsForSign && action=='emailDocsForSign'){
              this.notifyPetitioner =true;
            }

      } ,10)
      
    },
    selectFormsandLatters(index ,forms){
  // if( !this.formsAndLettersList[index]['selectedForSigning'] ){
    
  //   forms['selectedForSigning'] =true;
  //   this.formsAndLettersList[index]['selectedForSigning'] = true
  // }else{
  //     forms['selectedForSigning'] =false;
  //   this.formsAndLetters[index]['selectedForSigning'] = false;
  // }



  // alert(this.petition.formsAndLetters[index]['selectedForSigning']);

  },
    getSignerList(){
      this.selectedSigner =null
      // {{workFlowDetails}}
    
      

           let companyIdRoles =[50,51];
           let branchIdRoles =[4, 5, 6, 7, 8, 9, 10, 11 ,12];
            let postData ={
              "matcher":{
                 "roleIds": [], 
              "branchId":"",},              
              "page": 1,	
              "perpage":100000000,
              petitionId:'',
              "action":'DOC_SIGNER_LIST',
             "entityType": "case", // perm
              
            };
            if(this.workFlowDetails && this.checkProperty(this.workFlowDetails,'config' ,'length')>0){
              let signerListActivity = _.find(this.workFlowDetails['config'] ,{'code':'DOC_SIGNER_LIST'});
              if(signerListActivity && signerListActivity.editors){
              let signerList = _.map(signerListActivity.editors, 'roleId');
             }
            }
            
            //DOC_SIGNER_LIST['editors']
             _.forEach( this.rolesList ,(item)=>{
              
              
              postData.matcher.roleIds.push(item);
               if(companyIdRoles.indexOf(item)>-1 && this.checkProperty(this.petitionDetails ,'companyDetails' ,'_id')){
                postData = Object.assign(postData ,{"companyId":this.checkProperty(this.petitionDetails ,'companyDetails' ,'_id') })
              }

            if(branchIdRoles.indexOf(item)>-1 && this.checkProperty(this.petitionDetails ,'branchId')){
                postData['matcher']['branchId'] = this.checkProperty(this.petitionDetails ,'branchId');
              }
              

            });
            postData['petitionId'] = this.checkProperty(this.petitionDetails ,'_id');

            let path ='/petition/assign-user-list';
            if(this.checkProperty(this.petitionDetails,'subTypeDetails','id') ==15){
              path = "/perm/assign-user-list";
              postData['entityType'] = 'perm';
  
            }
            path = "/petition-common/get-users-for-assign";
            this.$store.dispatch("getList",{data:postData ,path:path} ).then(response => {
             //alert(JSON.stringify(response.list));
             let lst = []
            
            _.forEach(response ,(item)=>{
              if(_.has(item ,'name') && _.has(item ,'roleName') && ( item._id !=this.getUserData['userId'])){
                  item.name = item.name+" ("+item.roleName+")";
                  lst.push(item);
              }
            


            });
            this.signerList = lst;


            })



        
      

    },
    submitForm() {
     
      this.$validator.validateAll().then((result)=>{ 
     
       
        if(result){

       
      this.trackingErrors = "";
      this.requestsignCommentError = false;
      // if (
      //   this.requestsignformcomments == "" ||
      //   this.requestsignformcomments.trim() == ""
      // ) {
      //   this.requestsignCommentError = true;
      //   return true;
      // }
      let selectedDocuments = _.filter(this.formsAndLettersList, {
        selectedForSigning: true,
      });
      if (
        !selectedDocuments ||
        this.checkProperty(selectedDocuments, "length") <= 0
      ) {
        this.trackingErrors = "Atleast select one document is required.";
        result = false;
      }
      let self = this;
      var postdata = {
        'action':'REQUEST_PETITIONER_SIGN',
        petitionId: this.petitionDetails._id,
        comment: this.requestsignformcomments,
        subTypeName: this.checkProperty(
          this.petitionDetails,
          "subTypeDetails",
          "name"
        ),
        typeName: this.checkProperty(
          this.petitionDetails,
          "typeDetails",
          "name"
        ),
        documents: [],
        notifyPetitioner: false,
        emailDocsForSign: false,
      };
      if(['REQUEST_PETITIONER_SIGN','RFE_REQUEST_PETITIONER_SIGN'].indexOf(this.ACTIVITYCODE)>-1){
        postdata['action'] = this.ACTIVITYCODE;
      }
      _.forEach(this.formsAndLettersList, (item) => {
        if (item["selectedForSigning"]) {
          postdata["documents"].push(item);
        }
      });

      postdata["notifyPetitioner"] = this.notifyPetitioner;
      postdata["emailDocsForSign"] = this.emailDocsForSign;

      if (postdata["documents"].length > 0) {
        this.requestsigning = true;
        let path ="/petition/upload-rfe-response-docs"
        path = '/petition/request-for-petitioner-sign'
       console.log(postdata);
      
        this.$store.dispatch("commonAction", {data:postdata,path:path})
          .then((response) => {

            this.showToster({ message: response.message, isError: false });
             this.$emit("updatepetition", "Petition Updates");
            this.$store
              .dispatch("setPetitionTab", "Petition Updates")
              .then(() => {
                this.$emit("updatepetition", "Petition Updates");
              })
              .catch(() => {
                this.$emit("updatepetition", "Petition Updates");
              });

            this.hideMe();
          })
          .catch((error) => {
            this.trackingErrors = error;
            //Object.assign(this.formerrors ,{'msg':error});
            //this.showToster({ message: error, isError: true });
            this.requestsignCommentError = false;
            this.requestsigning = false;
          });
      } else {
        this.trackingErrors = "Select atleast one document!";
        this.requestsigning = false;
        this.checkFormsandLatters = true;
      }

    }

})
    },
    hideMe() {
      this.$emit("hideMe");
    },
  },
  watch: {
    showPopup(val) {
      if (!val) this.$emit("hideMe");
    },
  },
  mounted() {
    this.formsAndLettersList =[];
    this.signerList =[];
    this.selectedSigner =null;
   
    this.$modal.show("modalForm");
    this.getFormsAndLetters();
    setTimeout(()=>{
      this.fetchWorkFlowDetails();
    });
   
    
  },
  data: () => ({

    workFlowDetails:null,
    
    editor: ClassicEditor,
 editorConfig: {
     toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
 },
    notifyPetitioner: false,
    emailDocsForSign: false,
    signerList:[],
    selectedSigner:null,
    formsAndLettersList: [],
    requestsignformcomments: "",
    requestsignCommentError: false,
    requestsigning: false,
    trackingErrors: "",
    emailDocsForSign: false,
    actioncomment: "",
    paralegalformerrors: "",
    disabled_btn: false,
    loading: false,
    showPopup: false,
    comments: false,
    formerrors: null,
    uploading: false,
    validateLcaFiles: true,
    updateLca: false,
    filedDate: null,
    certifiedDate: null,
    lcastatuses: [],
    lcaDocuments: [],
    masterSocList: [],
    lcastatusSelected: null,
    documents: [],
    showDataPicker: true,
    number: "",
    updatingLca: false,
    lcaUpdateForm: false,
  }),
  props: {
    ACTIVITYCODE:{
      type:String,
      default:'REQUEST_PETITIONER_SIGN'
    },
    petitionDetails: {
      type: Object,
      default: null,
    },
    rolesList: [],
    formsAndLetters: {
      type: Array,
      default: null,
    },
  },
};
</script>
