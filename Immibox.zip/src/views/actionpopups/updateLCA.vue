<template>
  <div>
  <modal name="updateLcaModal" classes="v-modal-sec" :min-width="200" :min-height="200" :scrollable="true" :reset="true"
    width="600px" height="auto">
    <div class="v-modal">
      <div class="popup-header fromDetailsPage">
        <h2 v-if="!isFromLCAList" class="popup-title">Update LCA Status</h2>
        <h2 v-if="isFromLCAList" class="popup-title">Update Status</h2>
        <span @click="hideMe()">
          <em class="material-icons">close</em>
        </span>
      </div>
      <form data-vv-scope="lcaupdateform" @submit.prevent @keydown.enter.prevent>
        <div class="form-container" v-if="lcaDetails">
          <div class="vx-row">
            <div class="vx-col" :class="{
              'w-1/2 w-full':
                lcaDetails && checkProperty(lcastatusSelected, 'id') == 2,
              'w-full': !(
                lcaDetails && checkProperty(lcastatusSelected, 'id') == 2
              ),
            }">
              <div class="form_group">
                <label for class="form_label">LCA Status<em>*</em></label>
                <div class="con-select">
                  <multiselect :disabled="checkProperty(lcaDetails, 'statusId') == 7" name="lcastatus"
                    v-validate="'required'" :close-on-select="true" v-model="lcastatusSelected" :show-labels="false"
                    track-by="id" label="name" data-vv-as="LCA Status" placeholder="Select LCA Status"
                    :options="lcastatuses" :multiple="false" :searchable="true" :allow-empty="false"
                    @input="selectLcaStatus"></multiselect>
                  <span class="text-danger text-sm" v-show="errors.has('lcaupdateform.lcastatus')">{{
                    errors.first("lcaupdateform.lcastatus") }}</span>
                </div>
              </div>
            </div>
            <div class="vx-col w-full" v-if="((checkProperty(lcastatusSelected, 'id') && checkProperty(lcastatusSelected, 'id') != 7))">
              <div class="form_group">
                <div class="vs-component relative" @click="uploading = false">
                  <label class="form_label"
                    v-if="checkProperty(lcastatusSelected, 'id') == 2 || checkProperty(lcastatusSelected, 'id') == 3">Documents<em>*</em></label>
                  <label class="form_label"
                    v-if="checkProperty(lcastatusSelected, 'id') != 2 && checkProperty(lcastatusSelected, 'id') != 3">Acknowledgement<em>*</em></label>
                  <file-upload data-vv-as="Document" v-validate="{ required: validateLcaFiles }" :multiple="false"
                    :hideSelected="true" v-model="documents" class="file-upload-input file_upload justify-center"
                    name="certifiedLca" :accept="pdfDocEntity" @input="uploadLcaDocuments(documents)">
                    <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                    Upload<em>*</em>
                    <span class="loader" v-if="disabled_btn"><img src="@/assets/images/main/loader.gif" /></span>
                  </file-upload>
                  <!-- <span v-if="uploading" class="loader"><img src="@/assets/images/main/loader.gif"></span>-->
                  <span v-if="checkProperty(lcastatusSelected, 'id') == 2 || checkProperty(lcastatusSelected, 'id') == 3"
                    class="text-danger text-sm" v-show="errors.has('lcaupdateform.certifiedLca')">Documents are
                    required</span>
                  <span v-if="checkProperty(lcastatusSelected, 'id') != 2 && checkProperty(lcastatusSelected, 'id') != 3"
                    class="text-danger text-sm" v-show="errors.has('lcaupdateform.certifiedLca')">Acknowledgement is
                    required</span>
                </div>
                <ul class="uploaded-list note_uploads">
                  <template v-for="(file, fileindex) in lcaDocuments">
                    <vs-chip type="button" @click="removeLcaDocument(fileindex, lcaDocuments)" :key="fileindex"
                      v-if="file.status !== false" closable>{{ file.name }}
                    </vs-chip>
                  </template>
                </ul>
              </div>
            </div>
            <div class="vx-col w-full" v-if="lcaDetails && checkProperty(lcastatusSelected, 'id') == 2">
              <div class="form_group">
                <label class="form_label">DOL Reference Number<em>*</em></label>
                <vs-input class="w-100" name="lcaNumber" v-model="number" data-vv-as="DOL Reference Number"
                  v-validate="'required'" />
                <span class="text-danger text-sm" v-show="errors.has('lcaupdateform.lcaNumber')">{{
                  errors.first("lcaupdateform.lcaNumber") }}</span>
              </div>
            </div>
          </div>

          <div
            v-if="lcaDetails && (checkProperty(lcastatusSelected, 'id') == 2 || checkProperty(lcastatusSelected, 'id') == 3)"
            class="vx-row">
            <div class="vx-col w-full">
              <div class="form_group">
                <label for class="form_label">Preferred SOC Code</label>
                <div class="con-select">
                  <multiselect name="preferredSocCode" :close-on-select="true" v-model="lcaDetails.preferredSocDetails"
                    :show-labels="false" label="name" track-by="id" data-vv-as="Preferred SOC Code"
                    placeholder="Preferred SOC Code" :multiple="false" :options="masterSocList" :searchable="true" @search-change="pre_soc_search_fun"
                    :allow-empty="false"></multiselect>
                  <span class="text-danger text-sm" v-show="errors.has('lcaupdateform.preferredSocCode')">{{
                    errors.first("lcaupdateform.preferredSocCode") }}</span>
                </div>
              </div>
            </div>
            <div class="vx-col w-full">
              <div class="form_group">
                <label for class="form_label">SOC Code<em>*</em></label>
                <div class="con-select">
                  <multiselect name="socCode" v-validate="'required'" :close-on-select="true"
                    v-model="lcaDetails.socDetails" :show-labels="false" label="name" track-by="id" data-vv-as="SOC Code"
                    placeholder=" SOC Code" :multiple="false" :options="masterSocList" :searchable="true" @search-change="soc_search_fun"
                    :allow-empty="false"></multiselect>
                  <span class="text-danger text-sm" v-show="errors.has('lcaupdateform.socCode')">{{
                    errors.first("lcaupdateform.socCode") }}</span>
                </div>
              </div>
            </div>
          </div>

          <div class="vx-row">
            <div class="vx-col w-full">
              <template v-if="showDataPicker">
                <div class="form_group" v-if="lcaDetails && checkProperty(lcastatusSelected, 'id') == 2 && false">
                  <label class="form_label">Filed Date<em>*</em></label>
                  <div class="vs-component">
                    <datepicker :typeable="true" name="filedDate" :disabled-dates="{ from: new Date() }"
                      v-validate="'required'" v-model="filedDate" data-vv-as="Filed Date" placeholder="DD/MM/YYYY">
                    </datepicker>
                    <span class="text-danger text-sm" v-show="errors.has('lcaupdateform.filedDate')">
                      {{ errors.first("lcaupdateform.filedDate") }}
                    </span>
                  </div>
                </div>

                <datepickerField v-if="lcaDetails && checkProperty(lcastatusSelected, 'id') == 2" wrapclass="md:w-full"
                  :display="true" :dateEnableTo="new Date()" v-model="filedDate" :formscope="'lcaupdateform'"
                  fieldName="filedDate" label="Filed Date" :validationRequired="true" />
                <datepickerField v-if="lcaDetails && checkProperty(lcastatusSelected, 'id') == 3" wrapclass="md:w-full"
                  :display="true" :dateEnableTo="new Date()" v-model="certifiedDate" :formscope="'lcaupdateform'"
                  fieldName="certifiedDate" label="Certified Date" :validationRequired="true" />
                <div class="form_group" v-if="lcaDetails && checkProperty(lcastatusSelected, 'id') == 3 && false">
                  <label class="form_label">Certified Date<em>*</em></label>
                  <div class="vs-component">
                    <datepicker :typeable="true" name="lcacertifiedDate" :disabled-dates="{ from: new Date() }"
                      v-validate="'required'" v-model="certifiedDate" data-vv-as="Certified Date"
                      placeholder="DD/MM/YYYY"></datepicker>
                    <span class="text-danger text-sm" v-show="errors.has('lcaupdateform.lcacertifiedDate')">
                      {{ errors.first("lcaupdateform.lcacertifiedDate") }}
                    </span>
                  </div>
                </div>
              </template>
              <div
                v-if="lcaDetails && (checkProperty(lcastatusSelected, 'id') == 5 || checkProperty(lcastatusSelected, 'id') == 6)"
                class="form_group mb-5">
                <div class="vs-component relative mb-1" @click="uploading = false">
                  <label class="form_label">Reason for Withdrawal<em>*</em></label>
                  <div class="con-select">
                    <multiselect name="reasonForWithdrawal" :close-on-select="true" v-model="withdrawReasonDetails"
                      :show-labels="false" label="name" track-by="id" data-vv-as="Reason for Withdrawal"
                      placeholder="Reason for Withdrawal" :multiple="false" :options="reasonForWithdrawalList"
                      :searchable="false" :allow-empty="false" v-validate="'required'"></multiselect>
                    <span class="text-danger text-sm" v-show="errors.has('lcaupdateform.reasonForWithdrawal')">{{
                      errors.first("lcaupdateform.reasonForWithdrawal") }}</span>
                  </div>
                </div>
              </div>
              <div v-if="lcaDetails && (checkProperty(lcastatusSelected, 'id') == 5) && getTenantTypeId == 2"
                class="form_group mb-5">
                <div class="vs-component relative mb-1" @click="uploading = false">
                  <label class="form_label">Attorney</label>
                  <div class="con-select">
                    <multiselect name="withdrawalAttorney" :close-on-select="true" v-model="attroneyDetails"
                      :show-labels="false" label="name" track-by="_id" data-vv-as="Attorney" placeholder="Attorney"
                      :multiple="false" :options="attorneyList" :searchable="false" :allow-empty="false"></multiselect>
                    <span class="text-danger text-sm" v-show="errors.has('lcaupdateform.withdrawalAttorney')">{{
                      errors.first("lcaupdateform.withdrawalAttorney") }}</span>
                  </div>
                </div>
              </div>
              
            </div>

            <div class="vx-col w-full">
              <div class="form_group">
                <label class="form_label">Comments </label>
                <!-- <vs-textarea
                  data-vv-as="Comments"
                  v-validate="'required'"
                  v-model="actioncomment"
                  name="actioncomment"
                  class="w-full"
                /> -->
                <ckeditor data-vv-as="Comments" v-model="actioncomment" name="actioncomment" class="w-full"
                  :editor="editor" :config="editorConfig"></ckeditor>

                <span class="text-danger text-sm" v-show="errors.has('lcaupdateform.actioncomment')">Comments are
                  required</span>
              </div>
            </div>
          </div>
          <div class="vx-col w-full" @click="value = [];OtherUpload = false">
                <div class="form_group file_group">
                  <div class="vs-component marb10">
                    <label class="form_label">Others</label>
                    <div class="relative">
                      <file-upload v-model="value" class="file-upload-input upload_file justify-center"
                        :accept="allDocEntity"
                        :name="'Others'" :multiple="true" :hideSelected="true" @input="upload(value)">
                        <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                        Upload
                      </file-upload>
                      <span v-if="OtherUpload" class="loader"><img src="@/assets/images/main/loader.gif" /></span>
                    </div>
                  </div>

                  <ul class="uploaded-list note_uploads">
                    <template v-for="(item, index) in others">
                      <vs-chip @click="remove(item, others, index)" :key="index" closable>
                        {{ item.name }}
                      </vs-chip>
                    </template>
                  </ul>
                </div>
              </div>
          <div class="text-danger text-sm formerrors" v-if="paralegalformerrors != ''">
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
              icon="IP-information-button" active="true">{{ paralegalformerrors }}</vs-alert>
          </div>
        </div>

        <div class="popup-footer relative">
          <span class="loader" v-if="updatingLca"><img src="@/assets/images/main/loader.gif" /></span>
          <vs-button color="dark" class="cancel" type="filled" @click="hideMe()">Cancel</vs-button>
          <vs-button color="success" :disabled="updatingLca || disabled_btn" @click="submitForm" class="save"
            type="filled">Submit</vs-button>
        </div>
      </form>
    </div>
  </modal>

  <vs-popup class="holamundo main-popup qcomment" :title="'Conformation'" :active.sync="approveConformpopUp">
      
      <div class="form-container">

        <div class="vx-row">
          <div class="vx-col w-full">
            
            <p>{{documentExtractedMsg}}</p>
          </div>

        </div>

        

      </div>
      <div class="popup-footer">
        <vs-button color="dark" class="cancel" type="filled" @click="fillExtractedData(false)">Cancel </vs-button>
        <vs-button  color="success" class="save" type="filled" v-on:click.stop.prevent="fillExtractedData(true)">
          Continue
        </vs-button>
       
      </div>
    </vs-popup>
  </div>
</template>
<script>
import datepickerField from "@/views/forms/fields/datepicker.vue";
import moment from "moment";
import FileUpload from "vue-upload-component/src";
import { EyeIcon } from "vue-feather-icons";
import docType from "@/views/common/docType.vue";
import Datepicker from "vuejs-datepicker-inv";
import * as _ from "lodash";
import Vue from 'vue';
Vue.use(CKEditor);
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
export default {
  computed: {
    isSubmitUscisCompleted() {

      if (

        (this.petitionDetails)
        &&
        (_.has(this.petitionDetails, 'completedActivities')

          && this.petitionDetails.completedActivities.indexOf('SUBMIT_TO_USCIS') > -1

        )

      ) {
        return true;

      } else {
        return false
      }
    },
  },
  provide() {
    return {
      parentValidator: this.$validator,
    };
  },
  components: {
    datepickerField,
    docType,
    EyeIcon,
    FileUpload,
    Datepicker,
  },
  methods: {
    soc_search_fun(searchValue){
     // clearTimeout(this.debounce)
      //this.debounce =
       setTimeout(() => {
        this.soc_search_value = searchValue;
        this.getMasterSocList();
      }, 900)
    },
    pre_soc_search_fun(searchValue){
      setTimeout(() => {
        this.soc_search_value = searchValue;
        this.getMasterSocList();
      }, 900)
    },
    fillExtractedData( callFRomConform=false){
      let self = this;
      if(callFRomConform){
        let response = this.documentExtractedData;
        if (_.has(response, 'lcaDocCaseNo')) {
              this.lcaDocCaseNo = response['lcaDocCaseNo'];
            }
            // if (_.has(response, 'caseStatus')) {
            //   let caseStatus = response['caseStatus'];
            //   if (caseStatus == 'In Process') {
            //     caseStatus = 'Filed'
            //   }
            //   if (caseStatus) {
            //     if (this.checkProperty(this.lcastatusSelected, 'name')
            //       && caseStatus != this.checkProperty(this.lcastatusSelected, 'name')) {
            //       this.lcaDocCaseNo = ""
            //       this.showToster({ message: "Please upload " + this.checkProperty(this.lcastatusSelected, 'name') + " LCA only", isError: true });
            //       this.lcaDocuments = []
            //     }
            //   }
            // }
            if (_.has(response, 'socDetails') && response['socDetails']) {
              if (JSON.stringify(response['socDetails']) != JSON.stringify({})) {
                this.lcaDetails.socDetails = response['socDetails'];
              } 
              // else {
              //   if (this.checkProperty(response, 'jobDetails', 'socCodeName')) {
              //     // alert(JSON.stringify(_.find(this.masterSocList, { 'name': this.checkProperty(response, 'jobDetails', 'socCodeName') })))
              //     if (_.find(this.masterSocList, { 'name': this.checkProperty(response, 'jobDetails', 'socCodeName') })) {
              //       this.lcaDetails.socDetails = _.find(this.masterSocList, { 'name': this.checkProperty(response, 'jobDetails', 'socCodeName') });
              //     }
              //   }
              // }

            }

            if (_.has(response, 'certifiedDate') && response['certifiedDate']) {
              let lcaStatusDate = moment(response['certifiedDate']).format("YYYY-MM-DD");
              this.certifiedDate = lcaStatusDate
            }
            if (_.has(response, 'filedDate') && response['filedDate']) {
              let lcaStatusDate = moment(response['filedDate']).format("YYYY-MM-DD");
              this.filedDate = lcaStatusDate
            }

            this.disabled_btn = false;
            this.uploading = false;
      }else{
        this.lcaDocCaseNo = "";
        self.lcaDocuments = [];
        this.disabled_btn = false;
        this.uploading = false;
        this.checkDocuments();

      }
      this.approveConformpopUp = false;

    },

    extractFileData(fileUrl = '') {
      let self = this;
      this.disabled_btn = true;
      this.uploading = true;
      let data = {
        "lcaDocument": ''
      };
      if (fileUrl != '') {
        data['lcaDocument'] = fileUrl;
        let path = "/petition/extract-lca-data-from-pdf"
        this.$store.dispatch('commonCaseAction', { "data": data, 'path': path })
          .then((response) => {
            this.documentExtractedData = _.cloneDeep(response);
            this.documentExtractedMsg =this.checkProperty(response ,'message') ;
            if(this.checkProperty(response ,'code') =='LCA_DOC_CASE_NO_ALREADY_USED' && this.checkProperty(response ,'message')){

              if (_.has(response, 'caseStatus')) {
              let caseStatus = response['caseStatus'];
              if (caseStatus == 'In Process') {
                caseStatus = 'Filed'
              }
              if (caseStatus) {
                if (this.checkProperty(this.lcastatusSelected, 'name')
                  && caseStatus != this.checkProperty(this.lcastatusSelected, 'name')) {
                    self.lcaDocCaseNo = ""
                    self.showToster({ message: "Please upload " + self.checkProperty(self.lcastatusSelected, 'name') + " LCA only", isError: true });
                    self.lcaDocuments = [];
                    self.disabled_btn = false;
                    self.uploading = false;
                    self.checkDocuments();
                }else{
                  this.approveConformpopUp = true;
                }
              }else{
                this.approveConformpopUp = true;
              }
            }else{
              this.approveConformpopUp = true;
            }
             
             
              
            }else{
              this.fillExtractedData(true);
              

            }

            
          })
          .catch((error) => {

            self.disabled_btn = false;
            self.uploading = false;
            if (_.get(error, 'result.error.code') == 'LCA_DOC_CASE_NO_ALREADY_USED') {
              this.lcaDocCaseNo = ""
              self.showToster({ message: self.checkProperty(error, "message"), isError: true });
              self.lcaDocuments = []
            }
            this.checkDocuments();
          })
      } else {
        this.disabled_btn = false;
        this.uploading = false;
        this.fileUploaded = true;
      }

    },

    getMasterSocList() {
      let query = {};
      query["page"] = 1;
      query["perpage"] = 10000;
      query["matcher"] = {
        // "getInactiveListAlso": true
        searchString: this.soc_search_value,
      };
      query["category"] = "soc_codes";
      query["sorting"] = this.sortKey;

      this.$store
        .dispatch("getMasterData", query)
        .then((response) => {
          this.masterSocList = response.list;
        })
        .catch(() => {
          this.masterSocList = [];
        });
    },

    getMasterReqForWithdrawalList() {
      let query = {};
      query["page"] = 1;
      query["perpage"] = 10000;
      query["matcher"] = {
        // "getInactiveListAlso": true
      };
      query["category"] = "lca_withdraw_reasons";
      query["sorting"] = this.sortKey;

      this.$store
        .dispatch("getMasterData", query)
        .then((response) => {
          this.reasonForWithdrawalList = response.list;

          if (this.checkProperty(this.lcaDetails, 'withdrawReasonDetails')) {
            this.withdrawReasonDetails = this.checkProperty(this.lcaDetails, 'withdrawReasonDetails')
            this.withdrawReason = this.checkProperty(this.lcaDetails, 'withdrawReasonDetails', 'id')
          }

        })
        .catch(() => {
          this.reasonForWithdrawalList = [];
        });
    },

    removePremiumProcessingFiles(index) {
      this.premiumProcessingFiles.splice(index, 1);
    },
    checkDocuments() {
      let documents = _.filter(this.lcaDocuments, { status: true });
      if (documents && documents.length > 0) {
        this.validateLcaFiles = false;
      } else {
        this.validateLcaFiles = true;
      }
    },
    uploadLcaDocuments(model) {
      let temp_count = 0;

      this.disabled_btn = true;
      let mapper = model.map(
        (item) =>
        (item = {
          name: item.name,
          size:item.size ? item.size : null,
          file: item.file ? item.file : null,
          path: item.path ? item.path : "",
          status:
            item.status === false || item.status === true
              ? item.status
              : true,
          statusId: this.lcastatusSelected["id"]
            ? this.lcastatusSelected["id"]
            : "",
          certified: this.lcastatusSelected.id == 3 ? true : false,
          mimetype: item.type ? item.type : item.mimetype,
          comment: this.actioncomment ? this.actioncomment : "",
          uploadedBy:item.uploadedBy?item.uploadedBy:this.checkProperty(this.getUserData,'userId')!=''?this.checkProperty(this.getUserData,'userId'):null,
          uploadedByName:item.uploadedByName?item.uploadedByName:this.checkProperty(this.getUserData,'name')!=''?this.checkProperty(this.getUserData,'name'):'',
          uploadedByRoleId:item.uploadedByRoleId?item.uploadedByRoleId:this.getUserRoleId?this.getUserRoleId:null,
          uploadedByRoleName:item.uploadedByRoleName?item.uploadedByRoleName:this.checkProperty(this.getUserData,'loginRoleName'),
        })
      );
      //this.$vs.loading();
      this.uploading = true;
      if (mapper.length > 0) {
        mapper.forEach((doc, index) => {
          let formData = new FormData();
          formData.append("files", doc.file);
          formData.append("secureType", "private");
          formData.append("getDetails", true);
          this.$store.dispatch("uploadS3File", formData).then((response) => {
            temp_count++;
            response.data.result.forEach((urlGenerated) => {
              doc.status = true;
              doc.path = urlGenerated["path"];
              if(_.has(urlGenerated ,'size' )){
                  doc['size'] = urlGenerated['size'];
              }
              delete doc.file;
              this.lcaDocuments = []
              this.lcaDocuments.push(doc);
              mapper[index] = doc;
              if (temp_count >= mapper.length) {
                this.disabled_btn = false;
                // this.$vs.loading.close();
                this.documents = [];
                this.uploading = false;
              }
              this.checkDocuments();
              if ([2, 3].indexOf(this.lcastatusSelected["id"]) > -1) {
                this.extractFileData(urlGenerated);
              }
            });
          });
        });
        model.splice(0, mapper.length, ...mapper);
      }
    },

    removeLcaDocument(index, type) {
      let selectedItemPath = this.lcaDocuments[index]["path"];
      let dbDocuments = [];
      if (this.lcaDetails.statusId == 2) {
        dbDocuments = _.cloneDeep(this.lcaDetails["documents"]["filed"]);
      } else if (this.checkProperty(this.lcaDetails, "statusId") == 3) {
        dbDocuments = _.cloneDeep(this.lcaDetails["documents"]["certified"]);
      } else if ([4, 5, 6, 8].indexOf(this.checkProperty(this.lcaDetails, 'statusId')) > -1) {
        let statusLog = _.find(this.lcaDetails['statusLogs'], (itemValue) => { return itemValue.statusId == this.checkProperty(this.lcaDetails, 'statusId') })
        if (this.checkProperty(statusLog, 'documents') && this.checkProperty(statusLog, 'documents', 'length') > 0) {
          dbDocuments = this.checkProperty(statusLog, 'documents')
        }
      }

      if (
        dbDocuments.length > 0 &&
        _.find(dbDocuments, { path: selectedItemPath })
      ) {
        //this.lcaDocuments[index]['status'] =false;
        Object.assign(this.lcaDocuments[index], { status: false });
      } else {
        type.splice(type.indexOf(index), 1);
      }

      this.checkDocuments();
      return true;
    },
    upload(model) {
      let efiles = [];
      efiles = _.filter(model, (e) => {
        return e.url != null && e.url != "";
      });
      let nfiles = _.filter(model, (e) => {
        return e.url == null || e.url == undefined;
      });

      let mapper = nfiles.map(
        (item) =>
          (item = {
            name: item.name,
            file: item.file ? item.file : null,
            size:item.size ? item.size : null,
            url: item.url ? item.url : "",
            path: item.path ? item.path : "",
            status:item.status === false || item.status === true ? item.status : true,
            mimetype: item.type ? item.type : item.mimetype,
            uploadedBy:item.uploadedBy?item.uploadedBy:this.checkProperty(this.getUserData,'userId')!=''?this.checkProperty(this.getUserData,'userId'):null,
            uploadedByName:item.uploadedByName?item.uploadedByName:this.checkProperty(this.getUserData,'name')!=''?this.checkProperty(this.getUserData,'name'):'',
            uploadedByRoleId:item.uploadedByRoleId?item.uploadedByRoleId:this.getUserRoleId?this.getUserRoleId:null,
            uploadedByRoleName:item.uploadedByRoleName?item.uploadedByRoleName:this.checkProperty(this.getUserData,'loginRoleName'),
          })
      );
      if (mapper.length > 0) {
        this.OtherUpload = true;
        let count = 0;
        mapper.forEach((doc, index) => {
          let formData = new FormData();
          formData.append("files", doc.file);
          formData.append("secureType", "private");
          formData.append("getDetails", true);
          count++;

          this.$store.dispatch("uploadS3File", formData).then((response) => {
            response.data.result.forEach((urlGenerated) => {
                this.others.push(doc);
              if(_.has(urlGenerated ,'size' )){
                  doc['size'] = urlGenerated['size'];
              }
              doc.path = urlGenerated['path'];
              doc["mimetype"] = urlGenerated["mimetype"];
              doc["type"] = urlGenerated["mimetype"];
              delete doc.url;
              delete doc.file;
              mapper[index] = doc;
              if (index >= mapper.length - 1) {
              this.OtherUpload = false;
            }
          
          });
        });
        if (efiles.length > 0) efiles.push(...mapper);
      })
    }
    },
   
    remove(item, data, filindex) {
      data.splice(filindex, 1);
    },
    selectLcaStatus(item) {
      this.showDataPicker = false;
      this.lcastatusSelected = item;
      this.lcaDocuments = [];
      if (item.id == 2) {
        this.lcaDocuments = _.cloneDeep(this.lcaDetails["documents"]["filed"]);
      } else if (item.id == 3) {
        this.lcaDocuments = _.cloneDeep(
          this.lcaDetails["documents"]["certified"]
        );
      }



      this.checkDocuments();
      setTimeout(() => {
        this.showDataPicker = true;
        this.$validator.reset();
      }, 1);

      setTimeout(() => {

        if ([4, 5, 6, 8].indexOf(item.id) > -1) {
          if (this.checkProperty(this.lcaDetails, 'statusLogs') && this.checkProperty(this.lcaDetails, 'statusLogs', 'length') > 0) {
            let statusLog = _.find(this.lcaDetails['statusLogs'], (itemValue) => { return itemValue.statusId == item.id })

            if (this.checkProperty(statusLog, 'withdrawReasonDetails')) {
              this.withdrawReasonDetails = this.checkProperty(statusLog, 'withdrawReasonDetails')
              this.withdrawReason = this.checkProperty(statusLog, 'withdrawReasonDetails', 'id')
            }

            if (item.id == 5 && this.checkProperty(statusLog, 'attroneyDetails')) {
              this.attroneyDetails = this.checkProperty(statusLog, 'attroneyDetails')
              this.attroneyId = this.checkProperty(statusLog, 'attroneyDetails', 'id')
            }

            if (this.checkProperty(statusLog, 'documents') && this.checkProperty(statusLog, 'documents', 'length') > 0) {
              this.lcaDocuments = []
              this.lcaDocuments = this.checkProperty(statusLog, 'documents')
            }
          }
        }
        this.checkDocuments();
        this.$validator.reset();
      }, 100);
    },
    uploadPremiumProcessingDocuments(model) {
      let temp_count = 0;

      this.disabled_btn = true;
      let mapper = model.map(
        (item) =>
        (item = {
          name: item.name,
          file: item.file ? item.file : null,
          path: item.path ? item.path : "",
          status: item.status ? true : false,
          mimetype: item.type ? item.type : item.mimetype,
          //comment:this.actioncomment?this.actioncomment:''
        })
      );
      //this.$vs.loading();
      this.premiumProcessingFilesUploading = true;
      if (mapper.length > 0) {
        mapper.forEach((doc, index) => {
          let formData = new FormData();
          formData.append("files", doc.file);
          formData.append("secureType", "private");
          this.$store.dispatch("uploadS3File", formData).then((response) => {
            temp_count++;
            response.data.result.forEach((urlGenerated) => {
              doc.status = true;
              doc.path = urlGenerated;
              delete doc.file;
              this.premiumProcessingFiles = [];
              this.premiumProcessingFiles.push(doc);
              mapper[index] = doc;
              if (temp_count >= mapper.length) {
                this.disabled_btn = false;
                // this.$vs.loading.close();
                this.documents = [];
                this.premiumProcessingFilesUploading = false;
              }
            });
          });
        });
        model.splice(0, mapper.length, ...mapper);
      }
    },
    submitForm() {
      this.paralegalformerrors = "";
      this.$validator.validateAll("lcaupdateform").then((result) => {
        this.lcastatusSelected.lcaId = this.lcaDetails["_id"];
        let self = this;
        if (result) {
          this.updatingLca = true;
          let updatedValue = {
            lcaId: this.lcaDetails._id,
            number: this.number,
            action: "LCA_SUBMIT",// LCA_DENIED, LCA_REQ_FOR_WITHDRAW, LCA_WITHDRAWN, LCA_EXPIRED, LCA_RFE_RECEIVED
            actionTitle: "Basic information updated",
            innerAction: "UPDATE_DETAILS_AND_DOCUMENTS",
            updateType: "details-and-documents",
            statusName: this.lcastatusSelected.name,
            statusId: this.lcastatusSelected.id,
            comment: this.actioncomment,
            actionDescription: this.actioncomment,
            documents: this.lcaDetails["documents"],
            today: moment().format("YYYY-MM-DD"),
            //  payFrequency: self.checkProperty(self.lcaDetails ,'payFrequency' )
            preferredSOCCode: self.checkProperty(self.lcaDetails, 'preferredSocDetails', 'id'),
            desiredSOCCode: self.checkProperty(
              self.lcaDetails,
              "socDetails",
              "id"
            ),
            clientName: self.checkProperty(self.lcaDetails, "clientName"),
          };

          if (this.checkProperty(this.lcaDetails, 'petitionDetails', 'caseNo')) {
            Object.assign(updatedValue, { caseNo: this.lcaDetails.petitionDetails.caseNo });
          }
          //filedDate certifiedDate this.lcastatusSelected.id ==


          if (updatedValue.statusId == 2) {
            updatedValue["documents"]["filed"] = this.lcaDocuments;
          } else if (updatedValue.statusId == 3) {
            updatedValue["documents"]["certified"] = this.lcaDocuments;
          } else if (updatedValue.statusId != 7) {
            updatedValue["documents"] =  _.filter(this.lcaDocuments, { status: true })
          }
          updatedValue["documents"]['others']= [];
            if(this.checkProperty(this.others,'length')> 0){
              updatedValue["documents"]['others']= this.others;
            }
           
          if (this.filedDate && this.lcastatusSelected.id == 2) {
            let filedDate = moment(this.filedDate).format("YYYY-MM-DD"); //filedDate certifiedDate this.lcastatusSelected.id ==
            Object.assign(updatedValue, { filedDate: filedDate });
          }
          if (this.certifiedDate && this.lcastatusSelected.id == 3) {
            let certifiedDate = moment(this.certifiedDate).format("YYYY-MM-DD");
            Object.assign(updatedValue, { certifiedDate: certifiedDate });
          }
          if (updatedValue.statusId == 5 || updatedValue.statusId == 6) {
            Object.assign(updatedValue, { withdrawReasonDetails: this.withdrawReasonDetails });
            Object.assign(updatedValue, { withdrawReason: this.withdrawReasonDetails.id });
          }
          if (updatedValue.statusId == 5 && this.getTenantTypeId == 2 && this.checkProperty(this.attroneyDetails, '_id')) {
            Object.assign(updatedValue, { attroneyDetails: this.attroneyDetails });
            Object.assign(updatedValue, { attroneyId: this.attroneyDetails._id });
          }
          if ((this.lcastatusSelected.id == 2 || this.lcastatusSelected.id == 3) && this.lcaDocCaseNo && this.lcaDocCaseNo !='' ) {
            Object.assign(updatedValue, { 'lcaDocCaseNo': this.lcaDocCaseNo });
          }


          if (updatedValue.statusId == 4) {
            updatedValue["action"] = 'LCA_DENIED'
          } else if (updatedValue.statusId == 5) {
            updatedValue["action"] = 'LCA_REQ_FOR_WITHDRAW'
          } else if (updatedValue.statusId == 6) {
            updatedValue["action"] = 'LCA_WITHDRAWN'
          } else if (updatedValue.statusId == 7) {
            updatedValue["action"] = 'LCA_EXPIRED'
          } else if (updatedValue.statusId == 8) {
            updatedValue["action"] = 'LCA_RFE_RECEIVED'
          }
          

          this.updatingLca = true;
          this.$store
            .dispatch("updateLcaDetails", updatedValue)
            .then((response) => {
              this.lcaUpdateForm = false;
              this.updatingLca = false;
              this.showToster({
                message: this.checkProperty(response, "data", "message"),
                isError: false,
              });
              setTimeout(() => {
                this.disabled_btn = false;
                this.$store
                  .dispatch("setPetitionTab", "LCA")
                  .then(() => {
                    this.$emit("updatepetition", "LCA");
                  })
                  .catch(() => {
                    this.$emit("updatepetition", "LCA");
                  });
              }, 100);
              this.$emit("updatepetition", "LCA");
              this.hideMe()
            })
            .catch((error) => {
              this.updatingLca = false;
              this.disabled_btn = false;
              this.paralegalformerrors = error;
            });
        }
      });
    },
    hideMe() {
      this.$emit("hideMe");
    },
  },
  watch: {
    showPopup(val) {
      if (!val) this.$emit("hideMe");
    },
  },
  mounted() {
    this.getMasterSocList();
    this.getMasterReqForWithdrawalList();
    this.$store
      .dispatch("getmasterdata", "lca_inventory_status")
      .then((response) => {
        //  if (this.isFromLCAList) {
           //alert(JSON.stringify(this.lcaDetails))
        // alert(JSON.stringify(response))
        if (this.lcaDetails.statusId == 1 || this.lcaDetails.statusId == 99) {
          this.lcastatuses = _.filter(response, (item) => {
            if ([2, 3, 8].indexOf(item.id) > -1) {
              return item.id;
            }
          });
        }
       else if (this.lcaDetails.statusId == 2) {
          this.lcastatuses = _.filter(response, (item) => {
            if ([2, 3, 4, 8].indexOf(item.id) > -1) {
              return item.id;
            }
          });
        }
       else if (this.lcaDetails.statusId == 3) {
          this.lcastatuses = _.filter(response, (item) => {
            if ([3, 5, 6, 7].indexOf(item.id) > -1) {
              return item.id;
            }
          });
        }
     
       else if (this.lcaDetails.statusId == 5) {
          this.lcastatuses = _.filter(response, (item) => {
            if ([5, 6, 7].indexOf(item.id) > -1) {
              return item.id;
            }
          });
        }
       else if (this.lcaDetails.statusId == 6) {
          this.lcastatuses = _.filter(response, (item) => {
            if ([6, 7].indexOf(item.id) > -1) {
              return item.id;
            }
          });
        }
      else if (this.lcaDetails.statusId == 8) {
          this.lcastatuses = _.filter(response, (item) => {
            if ([8, 3, 4].indexOf(item.id) > -1) {
              return item.id;
            }
          });
        }

        this.lcastatusSelected = _.find(this.lcastatuses, {
          id: this.lcaDetails.statusId,
        });

        if (this.lcastatusSelected) {
          this.selectLcaStatus(this.lcastatusSelected);
        }

        if (this.lcaDetails.statusId == 2 || this.lcaDetails.statusId == 3) {
          this.number = "";
          if (_.has(this.lcaDetails, "number")) {
            this.number = this.lcaDetails.number;
          }
          //let  filedDate =  moment(this.filedDate).format("YYYY-MM-DD");  //filedDate certifiedDate this.lcastatusSelected.id ==
          if (this.checkProperty(this.lcaDetails, "filedDate")) {
            this.filedDate = moment(this.lcaDetails["filedDate"]).format(
              "YYYY-MM-DD"
            );
          }
          if (this.checkProperty(this.lcaDetails, "certifiedDate")) {
            this.certifiedDate = moment(this.lcaDetails["certifiedDate"]).format(
              "YYYY-MM-DD"
            );
          }
        }

        // }
        // else {
        //   this.lcastatuses = _.filter(response, (item) => {
        //     return item.id == 2 || item.id == 3;
        //   });
        //   this.lcastatusSelected = _.find(this.lcastatuses, {
        //     id: this.lcaDetails.statusId,
        //   });
        //   if (this.lcastatusSelected) {
        //     this.selectLcaStatus(this.lcastatusSelected);
        //   }

        // }

        this.$modal.show("updateLcaModal");
      });

    //  "getMasterDataOnly": true, 
    if (this.getTenantTypeId == 2) {
      let query = {};
      query["page"] = 1;
      query["perpage"] = 500;
      query["matcher"] = {
        "roleId": [6],
      };
      query["category"] = "users_list";
      query["sorting"] = { "path": "name", "order": 1 };

      this.$store
        .dispatch("getMasterData", query)
        .then((response) => {
          this.attorneyList = response.list;
        })
        .catch(() => {
          this.attorneyList = [];
        });
    }

    if (this.checkProperty(this.lcaDetails, 'statusId') && [4, 5, 6, 8].indexOf(this.checkProperty(this.lcaDetails, 'statusId')) > -1
      && this.checkProperty(this.lcaDetails, 'statusLogs', 'length') > 0) {

      let logsList = this.checkProperty(this.lcaDetails, 'statusLogs')
      if (_.find(logsList, { 'statusId': this.checkProperty(this.lcaDetails, 'statusId') })) {

        let statusLog = _.find(logsList, { 'statusId': this.checkProperty(this.lcaDetails, 'statusId') })
        if (this.checkProperty(statusLog, 'documents', 'length') > 0) {
          this.lcaDocuments = statusLog.documents
          this.checkDocuments();
        }
      }
    }

  },
  data: () => ({
    soc_search_value: "",
    approveConformpopUp:false,
    documentExtractedMsg:'',
    documentExtractedData:null,

    editor: ClassicEditor,
    editorConfig: {
      toolbar: ['bold', 'italic', '|', 'undo', 'redo', 'NumberedList', 'BulletedList',],
    },
    actioncomment: "",
    paralegalformerrors: "",
    disabled_btn: false,
    loading: false,
    showPopup: false,
    comments: false,
    formerrors: {
      msg: "",
    },
    uploading: false,
    OtherUpload:false,
    value: [],
    validateLcaFiles: true,
    updateLca: false,
    filedDate: null,
    certifiedDate: null,
    lcastatuses: [],
    lcaDocuments: [],
    others:[],
    masterSocList: [],
    reasonForWithdrawalList: [],
    lcastatusSelected: null,
    documents: [],
    showDataPicker: true,
    number: "",
    updatingLca: false,
    lcaUpdateForm: false,
    withdrawReasonDetails: null,
    attorneyList: [],
    attroneyDetails: null,
    lcaDocCaseNo: ''

  }),
  props: {
    caseNumber: {
      type: String,
      default: null,
    },
    isCaseNumberEdit: {
      type: Boolean,
      default: false,
    },
    petitionDetails: {
      type: Object,
      default: null,
    },
    lcaDetails: {
      type: Object,
      default: null,
    },
    isFromLCAList: {
      type: Boolean,
      default: false,
    },
  },
};
</script>
