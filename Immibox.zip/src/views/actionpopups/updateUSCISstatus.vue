<template>
   
      <modal
            style="z-index:999999"
            z-index="9999"
            name="updateUscisStatus"
            classes="v-modal-sec"
            :min-width="200"
            :min-height="200"
            :scrollable="true"
            :reset="true"
            width="750px"
            height="auto"
          >
          <div class="v-modal profile_details_modal error-modal-space" >
            <div class="popup-header fromDetailsPage">
              <h2 class="popup-title">
                <template v-if="checkUscisStatusAutoUpdated">Upload USCIS Documents</template>
                <template v-if="ACTIVITYCODE=='RFE_UPDATE_USCIS_RESPONSE'">Update RFE USCIS Status</template>
                <template v-else>Update USCIS Status</template>
                
              </h2>
              <span @click="showPopup=false;$modal.hide('updateUscisStatus');">
                <em class="material-icons">close</em>
              </span>
            </div>
            <form @submit.prevent data-vv-scope="uscisstatus" class="trackingform">
                <div class="form-container" @click="usciscUpdateStatusError=''">
                  <div class="vx-row">
                    <div class="vx-col md:w-1/2">
                      <div class="form_group">
                        <label class="form_label">Case Status<em>*</em></label>
                      <div class="con-select w-full DT_multiselect">                  
                        <multiselect
                          name="casestatus"
                          v-validate="'required'"
                          v-model="casestatus"
                          :show-labels="false"
                          track-by="value"
                          label="text"
                          @input="clearDateFilled"
                          data-vv-as="Status"
                          placeholder="Choose Status"
                          :options="uscisstatuslist"
                          :searchable="true"
                          :allow-empty="false"
                          :disabled="disabledStatus"
                        ></multiselect>
                      </div>
                      <span
                        class="text-danger text-sm"
                        v-show="errors.has('uscisstatus.casestatus')"
                      >{{ errors.first("uscisstatus.casestatus") }}</span>
                      </div>
                    </div>
                    <div class="vx-col md:w-1/2">
                      <div class="form_group">
                        <label class="form_label">Document Type<em>*</em></label>
                        <div class="con-select w-full DT_multiselect">  
                        <!-- {{documentType}}                 -->
                          <multiselect
                            :name="'documentType'"
                            v-validate="'required'"
                            v-model="documentType"
                            :show-labels="false"
                            
                            data-vv-as="Document Type"
                            placeholder="Document Type"
                            :options="documentTypes"
                            :searchable="true"
                            :allow-empty="false"
                          >
                          </multiselect>
                        
                          <span  class="text-danger text-sm"  v-show="errors.has('uscisstatus.documentType')"  >{{ errors.first('uscisstatus.documentType') }}</span>
                        </div>
                      </div>
                    </div>
                    <div div class="vx-col w-full" @click="documentModel=[];pwdDocFormatError=''" >
                      <div class="form_group">
                        <label class="form_label" style="text-transform: capitalize">{{checkProperty(petitionDetails ,'beneficiaryInfo' ,'name')}} Documents<em v-if="checkProperty(statusDocuments ,'length')<=0">*</em></label>
                        <div class="uploadsec_wrap upload_uscis">
                          <div class="w-full">
                              <div class="relative">
                                <file-upload
                                  v-model="documentModel"
                                  class="file-upload-input mb-0"
                                  style="height:50px;"
                                  name="trackingdoc"
                                  :multiple="false"
                                
                                  data-vv-as="Documents"
                                  :accept="allDocEntity"
                                  @input="uploadDocuments({userType:'beneficiary' , typeId:1, childrenId:'' ,userName:checkProperty(petitionDetails ,'beneficiaryInfo' ,'name')})"
                                >
                                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                                  Upload
                                </file-upload>
                                <span class="loader" v-if="checkProperty(documentsUploading ,'beneficiary')"><img src="@/assets/images/main/loader.gif"></span>
                              </div>
                            <span class="file-type mb-0">(File Type: PDF, DOC, JPEG, PNG. Max file size: 1MB)</span>
                            <span v-if="pwdDocFormatError" class="text-danger text-sm" >{{pwdDocFormatError}}</span>
                            <span class="text-danger text-sm" v-else-if="errors.has('uscisstatus.trackingdoc')">{{ errors.first("uscisstatus.trackingdoc") }}</span>
                              <!-- <VuePerfectScrollbar class="scrollbardoc"> -->
                                  <div class="uploded-files_wrap mb-5" v-if="statusDocuments.length >0 ">
                                      <template v-for="(fil, fileindex) in statusDocuments">
                                        <div class="w-full"  :key="fileindex" v-if="checkProperty(fil ,'userType') =='beneficiary'">
                                            <div class="uploded-files">
                                                <vx-input-group class="form-input-group">
                                                  <vs-input v-on:keyup="fileNameChenged(fil)"  v-validate="'required'" class="w-full" :name="'fName'+fileindex" v-model="statusDocuments[fileindex]['name']" data-vv-as="File Name" />
                                                    <span class="text-danger text-sm" v-show="errors.has('uscisstatus.fName'+fileindex)">{{ errors.first('uscisstatus.fName'+fileindex) }}</span>
                                                </vx-input-group>
                                                <div class="form_group">
                                                <div class="delete" style="z-index:999" @click="remove(fileindex , statusDocuments);resetPrefedKyes()">
                                                        <img src="@/assets/images/main/delete-row-img.svg" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </template>
                                  </div>
                            </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="vx-row" v-if="statusDocuments.length >0 && checkProperty(casestatus ,'value')">
                                      
                   
                    
                    <datepickerField wrapclass="md:w-1/2" @input="updateRfeIssuedDate($event)"
                     v-if="checkProperty(casestatus ,'value') =='USCIS_RECEIVED_RFE'" :dateEnableTo="new Date()" 
                     :display="true"  v-model="issuedDate" :formscope="'uscisstatus'" fieldName="issuedDate" 
                      label="RFE Issued Date" :validationRequired="true" :isDisabled="prefilledKyes.indexOf('issuedDate')>-1 && issuedDate"  /> 
                      <datepickerField wrapclass="md:w-1/2"  :display="true" :dateEnableFrom="issuedDate" :dateEnableTo="new Date()"
                     v-model="receivedDate" :formscope="'uscisstatus'" fieldName="receivedDate" 
                      label="Received Date" :validationRequired="true" :isDisabled="(prefilledKyes.indexOf('receivedDate')>-1 && receivedDate) ||  (issuedDate == null && checkProperty(casestatus ,'value') =='USCIS_RECEIVED_RFE')"  />  
                     
                    <datepickerField wrapclass="md:w-1/2" v-if="checkProperty(casestatus ,'value') =='USCIS_RECEIVED_RFE'"  
                    :dateEnableFrom="issuedDate" :display="true"  v-model="dueDate" :formscope="'uscisstatus'" fieldName="dueDate" 
                     label="RFE Due Date" :validationRequired="true" :isDisabled="(prefilledKyes.indexOf('dueDate')>-1 && dueDate) || (issuedDate == null && checkProperty(casestatus ,'value') =='USCIS_RECEIVED_RFE')" />
                
                    <div class="vx-col w-full">
                        <div class="form_group">
                          <label class="form_label">Comments<em>*</em></label>
                          <!-- <vs-textarea
                            data-vv-as="Comments"
                            v-validate="'required'"
                            v-model="usciscomments"
                            name="usciscomments"
                            class="w-full"
                          /> -->
                          <ckeditor  data-vv-as="Comments"
                            v-validate="'required'"
                            v-model="usciscomments"
                            name="usciscomments"
                            class="w-full" :editor="editor" :config="editorConfig"></ckeditor>

                          <span
                            class="text-danger text-sm"
                            v-show="errors.has('uscisstatus.usciscomments')"
                          >* Comments are required</span>
                        </div>
                    </div>

                    
                    
                  </div>

                  <div  class="vx-row" @click="documentModel=[]" v-if="false" >
                    
                    <div div class="vx-col w-full" @click="documentModel=[]" >
                      <div class="form_group">
                        <label class="form_label" style="text-transform: capitalize">{{checkProperty(petitionDetails ,'beneficiaryInfo' ,'name')}} Documents<em v-if="checkProperty(statusDocuments ,'length')<=0">*</em></label>
                        <div class="uploadsec_wrap upload_uscis">
                          <div class="w-full">
                              <div class="relative">
                                <file-upload
                                  v-model="documentModel"
                                  class="file-upload-input mb-0"
                                  style="height:50px;"
                                  name="trackingdoc"
                                  :multiple="false"
                                
                                  data-vv-as="Documents"
                                  :accept="allDocEntity"
                                  @input="uploadDocuments({userType:'beneficiary' , typeId:1, childrenId:'' ,userName:checkProperty(petitionDetails ,'beneficiaryInfo' ,'name')})"
                                >
                                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                                  Upload
                                </file-upload>
                                <span class="loader" v-if="checkProperty(documentsUploading ,'beneficiary')"><img src="@/assets/images/main/loader.gif"></span>
                              </div>
                            <span class="file-type mb-0">(File Type: PDF, DOC, JPEG, PNG. Max file size: 1MB)</span>
                            <span class="text-danger text-sm" v-show="errors.has('uscisstatus.trackingdoc')">{{ errors.first("uscisstatus.trackingdoc") }}</span>
                              <!-- <VuePerfectScrollbar class="scrollbardoc"> -->
                                  <div class="uploded-files_wrap mb-5" v-if="statusDocuments.length >0 ">
                                      <template v-for="(fil, fileindex) in statusDocuments">
                                        <div class="w-full"  :key="fileindex" v-if="checkProperty(fil ,'userType') =='beneficiary'">
                                            <div class="uploded-files">
                                                <vx-input-group class="form-input-group">
                                                  <vs-input v-on:keyup="fileNameChenged(fil)"  v-validate="'required'" class="w-full" :name="'fName'+fileindex" v-model="statusDocuments[fileindex]['name']" data-vv-as="File Name" />
                                                    <span class="text-danger text-sm" v-show="errors.has('uscisstatus.fName'+fileindex)">{{ errors.first('uscisstatus.fName'+fileindex) }}</span>

                                                    
                                                </vx-input-group>

                                                <div class="form_group">
                                                

                                                  
                                                <div class="delete" style="z-index:999" @click="remove(fileindex , statusDocuments)">
                                                        <img src="@/assets/images/main/delete-row-img.svg" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </template>
                                  </div>
                              <!-- </VuePerfectScrollbar> -->
                            </div>
                        </div>
                      </div>
                    </div>

                   <template  v-if="checkProperty(petitionDetails ,'beneficiaryInfo' ,'maritalStatus') !=1 && false">
                      <div div class="vx-col w-full" v-if="checkProperty(petitionDetails['dependentsInfo'] ,'spouse' ,'name') && checkProperty(petitionDetails['dependentsInfo'] ,'spouse' ,'h4Required') ==true">
                        <div class="form_group">
                         
                          <label class="form_label" style="text-transform: capitalize">
                        {{checkProperty(petitionDetails['dependentsInfo'] ,'spouse' ,'name')?checkProperty(petitionDetails['dependentsInfo'] ,'spouse' ,'name'):'Spouse'}} Documents<em v-if="checkProperty(statusDocuments ,'length')<=0">*</em></label>
                        <div class="uploadsec_wrap upload_uscis">
                          <div class="w-full">
                              <div class="relative">
                                <file-upload
                                  v-model="documentModel"
                                  class="file-upload-input mb-0"
                                  style="height:50px;"
                                  name="spouseDocuments"
                                  :multiple="false"
                                
                                  data-vv-as="Documents"
                                  :accept="allDocEntity"
                                  @input="uploadDocuments({userType:'spouse' , typeId:2, childrenId:'' ,userName:checkProperty(petitionDetails['dependentsInfo'] ,'spouse' ,'name')})"
                                >
                                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                                  Upload
                                </file-upload>
                                <span class="loader" v-if="checkProperty(documentsUploading ,'spouse')"><img src="@/assets/images/main/loader.gif"></span>
                              </div>
                            <span class="file-type mb-0">(File Type: PDF, DOC, JPEG, PNG. Max file size: 1MB)</span>
                            <span class="text-danger text-sm" v-show="errors.has('uscisstatus.spouseDocuments')">{{ errors.first("uscisstatus.spouseDocuments") }}</span>
                              <!-- <VuePerfectScrollbar class="scrollbardoc"> -->
                                  <div class="uploded-files_wrap mb-5" v-if="statusDocuments.length >0 ">
                                      <template v-for="(fil, fileindex) in statusDocuments">
                                        <div class="w-full"  :key="fileindex" v-if="checkProperty(fil ,'userType') =='spouse'">
                                            <div class="uploded-files">
                                                <vx-input-group class="form-input-group">
                                                  <vs-input v-on:keyup="fileNameChenged(fil)"  v-validate="'required'" class="w-full" :name="'fName'+fileindex" v-model="statusDocuments[fileindex]['name']" data-vv-as="File Name" />
                                                    <span class="text-danger text-sm" v-show="errors.has('uscisstatus.fName'+fileindex)">{{ errors.first('uscisstatus.fName'+fileindex) }}</span>

                                                    
                                                </vx-input-group>

                                                <div class="form_group">
                                                
                                                <div class="delete" style="z-index:999" @click="remove(fileindex , statusDocuments)">
                                                        <img src="@/assets/images/main/delete-row-img.svg" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </template>
                                  </div>
                              <!-- </VuePerfectScrollbar> -->
                            </div>
                        </div>
                        </div>
                      </div>

                      <template v-if="checkProperty(petitionDetails, 'beneficiaryInfo', 'maritalStatus') !=1 && checkProperty(petitionDetails ,'dependentsInfo' ,'childrens') && checkProperty(petitionDetails['dependentsInfo'] ,'childrens' ,'length')>0">
                         <template v-for="(child ,ind) in petitionDetails['dependentsInfo']['childrens']" >
                            <div v-if="checkProperty(child,'h4Required') ==true && checkProperty(child,'name') "  div class="vx-col w-full"  :key="ind"  >

                              <div class="form_group">
                                <label class="form_label" style="text-transform: capitalize">{{child['name']}} Documents<em v-if="checkProperty(statusDocuments ,'length')<=0">*</em></label>
                                <div class="uploadsec_wrap upload_uscis">
                                <div class="w-full">
                                    <div class="relative">
                                      <file-upload
                                        v-model="documentModel"
                                        class="file-upload-input mb-0"
                                        style="height:50px;"
                                        :name="'child'+ind"
                                        :multiple="false"
                                      
                                        data-vv-as="Documents"
                                        :accept="allDocEntity"
                                        @input="uploadDocuments({userType:'children' , typeId:3, childrenId:child['_id'] ,userName:child['name']})"
                                      >
                                        <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                                        Upload
                                      </file-upload>
                                      <span class="loader" v-if="checkProperty(documentsUploading ,child['_id'])"><img src="@/assets/images/main/loader.gif"></span>
                                    </div>
                                  <span class="file-type mb-0">(File Type: PDF, DOC, JPEG, PNG. Max file size: 1MB)</span>
                                  <span class="text-danger text-sm" v-show="errors.has('uscisstatus.child'+ind)">{{ errors.first("uscisstatus.child"+ind) }}</span>
                                    <!-- <VuePerfectScrollbar class="scrollbardoc"> -->
                                        <div class="uploded-files_wrap mb-5" v-if="statusDocuments.length >0 ">
                                            <template v-for="(fil, fileindex) in statusDocuments">
                                              <div class="w-full"  :key="fileindex" v-if="checkProperty(fil ,'userType') =='children' &&checkProperty(fil ,'childrenId')==child['_id'] ">
                                                  <div class="uploded-files">
                                                      <vx-input-group class="form-input-group">
                                                        <vs-input v-on:keyup="fileNameChenged(fil)"  v-validate="'required'" class="w-full" :name="'fName'+fileindex" v-model="statusDocuments[fileindex]['name']" data-vv-as="File Name" />
                                                          <span class="text-danger text-sm" v-show="errors.has('uscisstatus.fName'+fileindex)">{{ errors.first('uscisstatus.fName'+fileindex) }}</span>

                                                          
                                                      </vx-input-group>

                                                      <div class="form_group">
                                                      

                                                      <div class="delete" style="z-index:999" @click="remove(fileindex , statusDocuments)">
                                                              <img src="@/assets/images/main/delete-row-img.svg" />
                                                          </div>
                                                      </div>
                                                  </div>
                                              </div>
                                          </template>
                                        </div>
                                    <!-- </VuePerfectScrollbar> -->
                                  </div>
                                </div>
                              </div>

                            </div>
                        </template>
                      </template>
                    </template>


                  
                  </div>

                  
                </div>
                
                <div @click="usciscUpdateStatusError=''" class="text-danger text-sm formerrors" v-if="usciscUpdateStatusError!=''">
                          <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ usciscUpdateStatusError }}</vs-alert>
                </div>

                <div class="popup-footer relative">
                <span class="loader" v-if="usciscUpdating"><img src="@/assets/images/main/loader.gif"></span>
                  <vs-button color="dark" class="cancel" type="filled" @click="documentModel=[]; hideMe()">Cancel</vs-button>
                  <vs-button color="success" :disabled="usciscUpdating || checkProperty(documentsUploading ,'beneficiary') || checkProperty(documentsUploading ,'spouse')" @click="submitForm()" class="save" type="filled">Submit</vs-button>
                </div>
            </form>
            </div>
          </modal>  
</template>
<script>
import moment from "moment";
import FileUpload from "vue-upload-component/src";
import { EyeIcon } from "vue-feather-icons";
import docType from "@/views/common/docType.vue";
import Datepicker from "vuejs-datepicker-inv";
import * as _ from "lodash";
import datepickerField from "@/views/forms/fields/datepicker.vue";
import Vue from 'vue';
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';

export default {
  provide() {
      return {
          parentValidator: this.$validator,
      };
  },
  components: {
    docType,
    EyeIcon,
    FileUpload,
    Datepicker,
    datepickerField
  },
  computed: {
    checkUscisStatusAutoUpdated(){
      if(this.checkProperty(this.petitionDetails ,'uploadUscisDocs')!=true && this.checkProperty(this.petitionDetails ,'autoUscisStatusUpdate') ==true){
           return true
      }else{
        return false;
      }
    },
    checkEligibleDate(){
     
      if(this.checkProperty(this.casestatus ,'value') =='USCIS_RECEIVED_RFE' && this.issuedDate){
        return this.issuedDate
      }else{
        return new Date()
      }
    }
  },
  methods: {
    clearDateFilled(){
      this.statusDocuments= [];
      this.documentType=null;
      this.pwdDocFormatError='';
      // if(this.checkProperty(this.casestatus ,'value')=='USCIS_RECEIVED_RFE'){
      //     this.statusDocuments= [];
      // }
      this.receivedDate = null
      this.dueDate = null
      this.issuedDate = null
      this.usciscomments =''
    },
    updateRfeIssuedDate(val){
      if(val){
        if(this.receivedDate){
        let startData = moment(val);
        let endData= moment(this.receivedDate)
        if(startData.isAfter(endData , 'day')){
          this.receivedDate = null
        }
      }
      if(this.dueDate){
        let startDate = moment(val);
        let endDate= moment(this.dueDate)
        if(startDate.isAfter(endDate , 'day')){
          this.dueDate = null
        }
      }
      }
      else{
        this.dueDate = null
        this.receivedDate= null
      }
    },
    remove(index ,docs){
      docs.splice(index ,1);
      this.usciscomments =''
      this.receivedDate = null
    },
    /**
     * 
     * @param userType | String
     * @param typeId | String
     * @param childrenId | String
     * @param userName | String
     */
    uploadDocuments({userType='' , typeId='', childrenId='' ,userName=''}){
         let docs =_.cloneDeep(this.documentModel);
         var self = this;
         this.documentModel=[];
          
            docs = docs.map(
                (item) =>{
                    item = {
                        name: item.name,
                        file: item.file,
                        path: "",
                        size:item.size ? item.size : null,
                        mimetype: item.type,
                        extn:item.extn?item.extn:'',
                        documentType:item.documentType?item.documentType:null,
                        userName:'',
                        uploadedBy:item.uploadedBy?item.uploadedBy:self.checkProperty(self.getUserData,'userId')!=''?self.checkProperty(self.getUserData,'userId'):null,
                        uploadedByName:item.uploadedByName?item.uploadedByName:self.checkProperty(self.getUserData,'name')!=''?self.checkProperty(self.getUserData,'name'):'',
                        uploadedByRoleId:item.uploadedByRoleId?item.uploadedByRoleId:self.getUserRoleId?self.getUserRoleId:null,
                        uploadedByRoleName:item.uploadedByRoleName?item.uploadedByRoleName:self.checkProperty(self.getUserData,'loginRoleName'),
                    
                       
                    }
                    if(typeId){
                      item  = Object.assign(item ,{"typeId":typeId});
                    }
                    if(childrenId){
                      item  = Object.assign(item ,{"childrenId":childrenId});
                    }
                    if(userType){
                      item  = Object.assign(item ,{"userType":userType});
                    }
                     if(userName){
                      item  = Object.assign(item ,{"userName":userName});
                    }
                    
                return item;

              }
            );
           
            if (docs.length > 0) {
               
                this.filesAreuploading = false;
               
                if(userType && !childrenId ){
                  this.documentsUploading[userType] =true;
                }else if(childrenId){
                   this.documentsUploading[childrenId] =true;
                }
                
                let count =0;
                docs.forEach(function (doc) {
                    let formData = new FormData();
                    formData.append("files", doc.file);
                    formData.append("secureType", "private");
                    formData.append("getDetails", true);
                    self.$store.dispatch("uploadS3File", formData).then((response) => {
                      count = count+1;
                        if (response.data && response.data.result) {
                            response.data.result.forEach((urlGenerated) => {
                              //alert(JSON.stringify(urlGenerated))
                                // doc.url = urlGenerated;
                                 doc.path = urlGenerated['path'];
                                 doc.mimetype = urlGenerated['mimetype'];
                                  doc.extn = urlGenerated['extn'];
                                  if(_.has(urlGenerated ,'size' )){
                                     doc['size'] = urlGenerated['size'];
                                   }
                                delete doc.file;
                                if(urlGenerated['path']){
                                    if(userType && !childrenId ){

                                      self.statusDocuments =_.filter(self.statusDocuments ,(item)=>{
                                          return item['userType'] !=userType
                                      })

                                    }else{
                                       self.statusDocuments =_.filter(self.statusDocuments ,(item)=>{
                                          return item['childrenId'] !=childrenId
                                      })

                                    }
                                    Object.assign(doc, {uploadedOn: moment().format("YYYY-MM-DD"), uploadedBy: self.checkProperty(self.getUserData, 'userId'), uploadedByName: self.checkProperty(self.getUserData, 'name'), uploadedByRoleId: self.getUserRoleId, uploadedByRoleName: self.checkProperty(self.getUserData, 'loginRoleName') });
                    
                                   self.statusDocuments.push(doc)
                                }
                                self.prefillRfeNoticeDoc()
                                if(parseInt(count)>=docs.length){
                                   self.filesAreuploading = false;
                                   self.usciscUpdating =false;
                                  if(userType && !childrenId ){
                                    self.documentsUploading[userType] =false;
                                  }else if(childrenId){
                                    self.documentsUploading[childrenId] =false;
                                  }

                                };
                                
                            });
                            if(count>=docs.length){
                              self.filesAreuploading = false;
                              self.usciscUpdating =false;
                            if(userType && !childrenId ){
                              self.documentsUploading[userType] =false;
                            }else if(childrenId){
                              self.documentsUploading[childrenId] =false;
                            }

                            }
                            
                        }
                       
                    });
                });
            }
    },
   
        selectedDocuments(index, fls) {

          let docs =_.cloneDeep(fls)
            let formData = new FormData();
            docs = docs.map(
                (item) =>
                (item = {
                    name: item.name,
                    file: item.file,
                    url: "",
                    path: "",
                    mimetype: item.type,
                    documentType:item.documentType?item.documentType:null,
                })
            );
           
            if (docs.length > 0) {
                var self = this;
                this.filesAreuploading = true;
                let count =0;
                docs.forEach(function (doc) {
                    formData.append("files", doc.file);
                    formData.append("secureType", "private");
                    self.$store.dispatch("uploadS3File", formData).then((response) => {
                      count = count+1;
                        if (response.data && response.data.result) {
                            response.data.result.forEach((urlGenerated) => {
                                doc.url = urlGenerated;
                                 doc.path = urlGenerated;
                                delete doc.file;
                                self.tracking.documents = docs;
                                self.uscisdocument = docs;
                                self.trackingdoc = docs;
                                self.documentData.documentUploaded = docs;
                                    
                                 if(parseInt(count)>=docs.length){
                                   self.filesAreuploading = false;
                                  

                                }
                            });
                            if(count>=docs.length){
                              self.filesAreuploading = false;

                            }
                            
                        }
                       
                    });
                });
            }
        },
    fileNameChenged(index, fileindex) {
            this.disable_uploadBtn = false;

            _.forEach(this.documentData, (doc, value) => {
                if (doc.documentUploaded.length > 0) {
                    _.forEach(doc.documentUploaded, (fl, value) => {
                        let fname = fl.name;
                        fname = fname.trim();

                        if (!fname) {
                            this.disable_uploadBtn = true;
                        }
                    });
                }
            });

        },

   fileNameChengedScannedFiles( fileindex) {
            this.disable_uploadBtn = false;

           
                if (this.uploadScanedFilsList.length > 0) {
                    _.forEach(this.uploadScanedFilsList, (fl, value) => {
                        let fname = fl.name;
                        fname = fname.trim();

                        if (!fname) {
                            this.disable_uploadBtn = true;
                        }
                    });
                }
          

        },
        upload( docs) {
            
            
           
            if (docs.length > 0) {
                var self = this;
                self.filesAreuploading = true;
                let count =0;
                docs.forEach(function (doc) {
                  let formData = new FormData();
                    formData.append("files", doc.file);
                    formData.append("secureType", "private");
                     formData.append("getDetails",true);
                    
                    self.$store.dispatch("uploadS3File", formData).then((response) => {
                      count = count+1;
                        if (response.data && response.data.result) {
                            response.data.result.forEach((urlGenerated) => {
                              let tempUrl = urlGenerated
                              tempUrl = Object.assign(tempUrl, { uploadedBy: this.checkProperty(this.getUserData, 'userId'), uploadedByName: this.checkProperty(this.getUserData, 'name'), uploadedByRoleId: this.getUserRoleId, uploadedByRoleName: this.checkProperty(this.getUserData, 'loginRoleName') });
  
                                self.uploadScanedFilsList.push(tempUrl) ;  
                                self.uploadScanedFilsList = _.cloneDeep(self.uploadScanedFilsList);
                                 if(parseInt(count)>=docs.length){
                                   self.filesAreuploading = false;
                                  

                                }
                            });
                            if(count>=docs.length){
                              self.filesAreuploading = false;

                            }
                            
                        }
                       
                    });
                });
            }
        },
        prefillRfeNoticeDoc(){
          this.draftExtractInfo = null;
          this.pwdDocFormatError = '';
          var _dt;
          this.prefilledKyes =[];
          this.$validator.reset();
          if(this.checkProperty(this.statusDocuments, 'length' )>0){
                
            this.uploading = true;  
            let path ="/common/extract-data-from-pdf";
            
            //  9014077715 --- 325
          
        
            let postData ={
              "category": "rfe_notice",
              "docType": "rfe_notice",
              documents:[],
              "lcaDocument":''
            };
          
            let doc = this.statusDocuments[0];
            postData['lcaDocument'] = doc.path;
            postData['documents'].push(doc.path);
            this.$vs.loading();
            this.pwdDocFormatError = '';
            this.$store.dispatch('commonAction', {"data":postData ,"path":path})
                .then((response)=>{
                  this.$vs.loading.close();
                  this.pwdDocFormatError = '';
                  this.uploading = false;  
                  //this.casestatus = { "value": "USCIS_RECEIVED_RFE", "text": "RFE Received" }
                  this.draftExtractInfo =response;

                  if(this.checkProperty(this.draftExtractInfo ,'receivedDate')){
                    this.receivedDate = this.draftExtractInfo['receivedDate']; 
                    this.prefilledKyes.push('receivedDate');
                  }

                  if(this.checkProperty(this.draftExtractInfo ,'rfeIssuedDate')){
                this.issuedDate = this.draftExtractInfo['rfeIssuedDate']; 
                this.prefilledKyes.push('issuedDate');
              }
              if(this.checkProperty(this.draftExtractInfo ,'uscisDeadlineDate')){
                this.dueDate = this.draftExtractInfo['uscisDeadlineDate']; 
                this.prefilledKyes.push('dueDate');
              }

              
                  // if(this.checkProperty(this.draftExtractInfo ,'uscisReceiptNumber')){
                  //   this.rfeData['uscisReceiptNumber'] = this.draftExtractInfo['uscisReceiptNumber'];
                  //   this.prefilledKyes.push('uscisReceiptNumber');
                  // } { "value": "USCIS_RECEIVED_RFE", "text": "RFE Received" }
                
                  

                }).catch((errr)=>{
                 this.$vs.loading.close();
                 if(this.checkProperty(this.casestatus ,'value') =='USCIS_RECEIVED_RFE' ){
                  this.pwdDocFormatError = errr;
                  this.receivedDate = null
                  this.dueDate = null
                  this.issuedDate = null
                 }
                  //this.pwdDocFormatError = errr
                  //this.uploading = false;  
                });
          }

        },
        resetPrefedKyes(){
          this.draftExtractInfo =null;
          if( this.prefilledKyes.indexOf('issuedDate')>-1){
            this.issuedDate =  null;
          }
          if( this.prefilledKyes.indexOf('receivedDate')>-1){
            this.receivedDate = null;
          }
          if( this.prefilledKyes.indexOf('dueDate')>-1){
            this.dueDate = null;
          }
          this.prefilledKyes =[];
          this.draftExtractInfo =null;
          this.$validator.reset();
        },
    submitForm() {
       //alert(this.approveRejecInstructions);
            this.usciscUpdateStatusError='';
            let self =this;
            this.$validator.validateAll("uscisstatus").then((result) => {

               if(this.checkProperty( this.statusDocuments ,'length')<=0){
                       this.usciscUpdateStatusError ="Upload atleast one document.";
                       //this.showToster({ message:"Upload atleast one document." , isError: true})

                       return true;
                    }
                if (result && this.checkProperty( this.statusDocuments ,'length')>0) {
                  
	                
                    // this.approveRejec_Instructions="* Instructions is required"

                    let payload_data = {
                        petitionId: this.petitionDetails._id,
                        comment: this.usciscomments,
                        action: this.casestatus.value,
                         "today": moment().format("YYYY-MM-DD"),
                         "typeId": self.checkProperty(self.petitionDetails,'typeDetails','id' ),
                         "typeName":self.checkProperty(self.petitionDetails,'typeDetails','name' ),
                         "subTypeId":self.checkProperty(self.petitionDetails,'subTypeDetails','id' ), 
                         "subTypeName":self.checkProperty(self.petitionDetails,'subTypeDetails','name' ),
                          'documentType':self.documentType,
                        
                         "subTypeId": 1,
                    };

                    let rfepayload = {
                        petitionId: this.petitionDetails._id,
                        comment: this.usciscomments,
                        description: this.usciscomments,
                        action: this.casestatus.value, //'UPDATE_USCIS_RESPONSE'
                         "today": moment().format("YYYY-MM-DD"),
                         "typeId": this.checkProperty(this.petitionDetails,'typeDetails','id' ),
                         "typeName":this.checkProperty(this.petitionDetails,'typeDetails','name' ),
                         "subTypeId":this.checkProperty(this.petitionDetails,'subTypeDetails','id' ), 
                         "subTypeName":this.checkProperty(this.petitionDetails,'subTypeDetails','name' ),
                         'documentType':this.documentType
                    };
                    // "action": "QUESTIONNIRE_APPROVED" // "QUESTIONNIRE_REJECTED" / "CASE_APPROVED" / "LCA_CERTIFIED_FOR_PETITION" / "READY_FOR_FILING" / "USCIS_APPROVED" / "USCIS_RECEIVED_RFE" / "USCIS_DENIED"

                    if (this.casestatus.value == "USCIS_RECEIVED_RFE") {
                        payload_data["today"] = moment().format("YYYY-MM-DD");
                        payload_data["typeName"] = this.checkProperty(this.petitionDetails,'typeDetails','name' );
                        payload_data["subTypeName"] = this.checkProperty(this.petitionDetails,'subTypeDetails','name' );

                        rfepayload["today"] = moment().format("YYYY-MM-DD");
                        rfepayload["typeName"] = this.checkProperty(this.petitionDetails,'typeDetails','name' );
                        rfepayload["subTypeName"] = this.checkProperty(this.petitionDetails,'subTypeDetails','name' );

                        rfepayload["issuedDate"] = moment(this.issuedDate).format(
                            "YYYY-MM-DD"
                        );
                        rfepayload["receivedDate"] = moment(this.receivedDate).format(
                            "YYYY-MM-DD"
                        );
                        rfepayload["dueDate"] = moment(this.dueDate).format("YYYY-MM-DD");
                       
                    }

                    if(this.receivedDate){
                     rfepayload["receivedDate"] = moment(this.receivedDate).format(
                            "YYYY-MM-DD"
                        );
                     }
                  
                    rfepayload["documents"] = this.statusDocuments;
                   
                    this.usciscUpdating =true;
                    this.filesAreuploading =false;
                    rfepayload["today"] = moment().format("YYYY-MM-DD");
                   
                    let dispatchAction ='manageApproval_process';
                    if(this.checkUscisStatusAutoUpdated){
                      dispatchAction = "uploadUscisResponseDocs";
                    }
                   // rfepayload['uploadUscisDocs'] = false;
                    //rfepayload['autoUscisStatusUpdate'] = true;
                    let actionCode = this.checkProperty(this.casestatus,'value');
                    if(this.ACTIVITYCODE =='RFE_UPDATE_USCIS_RESPONSE'){
                      rfepayload['action'] ='RFE_'+actionCode;
                    }
                      

                    this.$store
                        .dispatch(dispatchAction, rfepayload)
                        .then((response) => {
                            if (self.casestatus.value == "USCIS_RECEIVED_RFE") {
                                self.$store.dispatch("fileRFE", rfepayload).then((response) => {
                                    self.showToster({ message:response.message , isError: false})

                                      this.$emit("updatepetition", "Petition Updates");
                                      self.hideMe();
                                });
                            } else {
                             
                               
                                // this.showMessages(response.message);
                                self.showToster({ message:response.message , isError: false})
                                this.$emit("updatepetition", "Petition Updates");
                                self.hideMe();
                            }
                              this.usciscUpdating =false;
                        })
                        .catch((error) => {
                           this.usciscUpdating =false;
                           this.filesAreuploading =false;
                           this.usciscUpdateStatusError =error;
                          //this.showToster({ message: error, isError: true });
                        });
                }else{
                 // this.showToster({ message:"Invalid data" , isError: true});
                }
            });
    },
    hideMe() {

      this.$emit("hideMe");
       this.$modal.hide('updateUscisStatus');
    },
  },
  watch: {
    showPopup(val) {
      if (!val){
        this.$emit("hideMe");
        this.$modal.hide('updateUscisStatus');
      } 
    },
  },
  mounted() {
    let documentsUploading={
      "beneficiary":false,
      "spouse":false,

    };
    if(this.checkProperty(this.petitionDetails ,'dependentsInfo','childrens')){
      _.forEach(this.petitionDetails['dependentsInfo']['childrens'] ,(item)=>{
        if(this.checkProperty(item ,'_id')){
           documentsUploading[item['_id']] = false;
        }
         
      })

    }
      this.documentsUploading =_.cloneDeep(documentsUploading);
      this.showPopup = true;
      

      //casestatus
      //uscisstatuslist
      this.disabledStatus =false;
      setTimeout(() => {
        if(this.petitionDetails && _.has(this.petitionDetails ,'currentActivity') && _.find(this.uscisstatuslist ,{"value":this.petitionDetails['currentActivity']}) ){
           this.casestatus = _.find(this.uscisstatuslist ,{"value":this.petitionDetails['currentActivity']});
           this.disabledStatus =true;
           
           if(_.has( this.petitionDetails,'rfeNotice') && (_.has( this.petitionDetails['rfeNotice'],'receivedDate'))){
              this.receivedDate = this.petitionDetails['rfeNotice']['receivedDate'];
           }
        }

        
      }, 100);
      this.pwdDocFormatError = '';
      this.$modal.show('updateUscisStatus');
    
  },
  data: () => ({
    pwdDocFormatError:'',
    prefilledKyes:[],
    draftExtractInfo:null,
    editor: ClassicEditor,
 editorConfig: {
     toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
 },
    documentsUploading:{
      "beneficiary":false,
      "spouse":false,

    },
    documentType:null,
    disabledStatus:false,
     uscisstatuslist: [
      {
        value: "USCIS_APPROVED",
        text: "Case Approved",
      },
      {
        value: "USCIS_RECEIVED_RFE",
        text: "RFE Received",
      },
      {
        value: "USCIS_DENIED",
        text: "Case Denied",
      },
      {
        value: "USCIS_WITHDRAWN",
        text: "Case Withdrawn",
      },
    ],
        documentData: [
      {
        type: "Forms, Letters and Others",
        documentUploaded: [],
      },
    ],
    documentTypes:["Original" ,"Electronic" ],
    documentModel:[],
    statusDocuments:[],
    casestatus: null,
    uscisdocument: [],
    dueDate:null,
    usciscomments: "",
    receivedDate:null,
    issuedDate:null,
    updateTrackingFormData: null,
    updateTrackingLoading: false,
    trackingErrors: "",
    filesAreuploading: false,
    editFilngFee: false,
    uploading: false,
    courierList: [],
    tracking: { documents: [], receiptNumber: null, receiptName: null },
    uscisdocument: [],
    dueDate: null,
    usciscomments: "",
    trackingdoc: [],
    issuedDate: null,
    receivedDate: null,
    dueDate: null,
    openDate: new Date().setFullYear(new Date().getFullYear()),
    startEligibleDate: new Date().setFullYear(new Date().getFullYear()),
    updateTrackingPopup: false,
    updateUSCISstatusPopup: false,
    usciscUpdateStatusError: "",
    usciscUpdating: false,
    actioncomment: "",
    paralegalformerrors: "",
    disabled_btn: false,
    loading: false,
    showPopup: false,
    comments: false,
    formerrors: {
      msg: "",
    },
    uploading: false,
    validateLcaFiles: true,
    updateLca: false,
    filedDate: null,
    certifiedDate: null,
    lcastatuses: [],
    lcaDocuments: [],
    masterSocList: [],
    lcastatusSelected: null,
    documents: [],
    showDataPicker: true,
    number: "",
    updatingLca: false,
    lcaUpdateForm: false,
  }),
  props: {
    ACTIVITYCODE: {
      type: String,
      default: null,
    },
    petitionDetails: {
      type: Object,
      default: null,
    },
  },
};
</script>
