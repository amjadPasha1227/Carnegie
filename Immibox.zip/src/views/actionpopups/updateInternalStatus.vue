
<template>
    <vs-popup
      class="holamundo main-popup"
      :title="popUpTitle"
      :active.sync="showPopup"
    >
      <form data-vv-scope="updateInteranalStatusForm" @submit.prevent @keydown.enter.prevent>
        <div class="form-container">
          <!-- <selectField  :display="true" :wrapclass="'md:w-full '" :formscope="'updateInteranalStatusForm'" :required="true"  cid="internalStatusDetails"   :optionslist="internalStatusList" v-model="internalStatusDetails" label="Internal Status" @input="checkDeletedDocs"  fieldName="internalStatusDetails" placeHolder="Internal Status"   />  -->
          <div class="vx-col w-full" v-if="checkProperty(internalStatusList ,'length')>0">
                <div class="form_group">
                  <div class="con-select w-full select-large">
                   
                <label class="form_label">Select Status<em>*</em></label>
                <multiselect  v-model="internalStatusDetails" :options="internalStatusList" :multiple="false"
                  :hideSelected="false" :close-on-select="true" :clear-on-select="false" :preserve-search="true"
                  :select-label="'Search Internal Status'" placeholder="Select Status" label="name" track-by="name"
                  :preselect-first="false" :searchable="true" name="internalStatus"
                  data-vv-as="Status"  v-validate="'required'"  @input="checkDeletedDocs"
                  >
                </multiselect>
                </div>
                </div>
                <span class="text-danger text-sm"
                 v-show="errors.has('updateInteranalStatusForm.internalStatus')" 
                 >{{ errors.first("updateInteranalStatusForm.internalStatus") }}</span>
              
              </div>
          <div class="vx-row">
            <template v-if="[50].indexOf(getUserRoleId)<=-1 && ( checkProperty(internalStatusDetails,'id') == 2 || checkProperty(internalStatusDetails,'id') == 3) ">
              <div class="vx-col w-full" @click="value = []">
                <div class="form_group file_group">
                  <div class="vs-component marb20">
                   <label class="form_label">Documents</label>
                    <div class="relative">
                   <file-upload
                      v-model="value"
                      class="file-upload-input upload_file justify-center"
                      :accept="allDocEntity"
                      :name="'documents'"
                      :multiple="true"
                      
                      :hideSelected="true"
                      @input="upload(value ,'delete')"
                    >
                      <img
                        class="file-icon"
                        src="@/assets/images/main/file-upload.svg"
                      />
                      Upload 
                    </file-upload>
                    <span  v-if="uploading" class="loader"   ><img src="@/assets/images/main/loader.gif"   /></span>
                    </div>
                    <!---
                      
                    <input type="hidden" v-model="newTask.documents"  data-vv-as="Documents"  v-validate="'required'" name="tdocs">
                    <span  class="text-danger text-sm" v-show="errors.has('tdocs')"   >{{ errors.first('tdocs') }}</span >
                    -->
                    <input type="hidden" :name="'permDeleteDocs'"   data-vv-as="PERM Documents"  v-model="permDeleteDocs">
                    <!-- <span class="text-danger text-sm" v-show="errors.has('updateInteranalStatusForm.permDeleteDocs')">*Documents are required</span> -->
                
                  </div>
                 

                  <ul class="uploaded-list note_uploads" v-if="checkProperty(permDeleteDocs,'length')>0">
                    <template v-for="(item, index) in permDeleteDocs">
                      <vs-chip
                      @click="remove(item, permDeleteDocs, index)"
                        :key="index"
                        closable
                      >
                      {{ item.name }}
                      </vs-chip>
                    </template>
                  </ul>
                </div>
                </div>
            </template>
            <div class="vx-col w-full "  >
                <div class="form_group">
                  <div class="con-select w-full select-large">
                  <label class="form_label">Comments<em>*</em></label>
                  <!-- <vs-textarea
                    data-vv-as="Comments"
                    v-validate="'required'"
                    v-model="internalComments"
                    name="internalcomments"
                    class="w-full"
                  
                  /> -->
                  <ckeditor data-vv-as="Comments"
                    v-validate="'required'"
                    v-model="internalComments"
                    name="internalcomments"
                    class="w-full"  :editor="editor" :config="editorConfig"></ckeditor>

                  </div>
                  <span
                    class="text-danger text-sm"
                    v-show="errors.has('updateInteranalStatusForm.internalcomments')"
                  ><em>*</em> Comments are required</span>
                </div>
              </div>
          </div>
          <div class="text-danger text-sm formerrors" v-show="formErrors">
            <vs-alert
              color="warning"
              class="warning-alert reg-warning-alert no-border-radius"
              icon-pack="IntakePortal"
              icon="IP-information-button"
              active="true"
              >{{ formErrors }}</vs-alert
            >
          </div>
        </div>
        <div class="popup-footer">
          <span class="loader" v-if="loading"
            ><img src="@/assets/images/main/loader.gif"
          /></span>
          <vs-button
            color="dark"
            @click="showPopup = false"
            class="cancel"
            type="filled"
            >Cancel</vs-button
          >
          <vs-button
            :disabled="loading"
            color="success"
            @click="submitForm()"
            class="save"
            type="filled"
            >Submit</vs-button
          >
        </div>
      </form>
    </vs-popup>
  </template>
  <script>
  import FileUpload from "vue-upload-component/src";
  import _ from "lodash";
  import moment from 'moment'
  import selectField from "@/views/forms/fields/simpleselect.vue";
  import Vue from 'vue';
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
  export default {
    provide() {
      return {
         parentValidator: this.$validator,
      };
    },
    components: {
      selectField,
      FileUpload,
    },
    methods: {
      updatePopupTitle(){

        //masterDataList this.internalStatusList
        if(this.petitionDetails['intStatusId'] ==1){
            if([50].indexOf(this.getUserRoleId) >-1){
              this.popUpTitle ="Hold/Abandon Case";
              this.internalStatusList = _.filter(this.masterDataList, (item)=>{
                [2,3].indexOf(item.id)>-1
              })
            }
            //else if([3].indexOf(this.getUserRoleId) >-1){   
            else if(this.adminsList.indexOf(this.getUserRoleId) > -1  ){  
                    
              this.popUpTitle ="Hold/Abandon/Delete Case";
              this.internalStatusList = _.filter(this.masterDataList, (item)=>{
                [2,3,4].indexOf(item.id)>-1
              })
            }else{
              this.popUpTitle ="Hold/Abandon/Delete Case";
              this.internalStatusList = _.filter(this.masterDataList, (item)=>{
                [2,3,4].indexOf(item.id)>-1
              })
            }
        }else if(this.petitionDetails['intStatusId'] ==2){
            if([50].indexOf(this.getUserRoleId) >-1){
              this.popUpTitle ="Abandon Case";
              this.internalStatusList = _.filter(this.masterDataList, (item)=>{
                [3].indexOf(item.id)>-1
              })
            }
              else if([3].indexOf(this.getUserRoleId) >-1){
              this.popUpTitle ="Active/Abandon/Delete Case";
              this.internalStatusList = _.filter(this.masterDataList, (item)=>{
                [1,3,4].indexOf(item.id)>-1
              })
            }else{
              this.popUpTitle ='Abandon/Delete Case';
              this.internalStatusList = _.filter(this.masterDataList, (item)=>{
                [3,4].indexOf(item.id)>-1
              })
            }
        }else if(this.petitionDetails['intStatusId'] ==3){
            if([50].indexOf(this.getUserRoleId) >-1){
              this.popUpTitle ='Hold Case';
              this.internalStatusList = _.filter(this.masterDataList, (item)=>{
                [2].indexOf(item.id)>-1
              })
            } else if([3].indexOf(this.getUserRoleId) >-1){
              this.popUpTitle ='Active/Hold/Delete Case';
              this.internalStatusList = _.filter(this.masterDataList, (item)=>{
                [1,2,4].indexOf(item.id)>-1
              })
            }else{
              this.popUpTitle ='Hold/Delete Case';
              this.internalStatusList = _.filter(this.masterDataList, (item)=>{
                [2,4].indexOf(item.id)>-1
              })
            }
        }
      },
      submitForm() {
           this.formErrors ='';  
           this.$validator.validateAll("updateInteranalStatusForm").then((result) => {
              if (result) {
                  let postData ={
                    "petitionIds":[],
                    "intStatusId": '', 
                    "comments": "",
                    "documents":[]
                  };
                  postData['intStatusId']= this.internalStatusDetails['id']
                  postData['comments']= this.internalComments;
                  if(this.checkProperty(this.petitionDetails,'_id')){
                    postData['petitionIds'].push(this.checkProperty(this.petitionDetails,'_id'))
                  }
                 
                  if(this.checkProperty(this.internalStatusDetails, 'id') ==2 || this.checkProperty(this.internalStatusDetails, 'id') ==3){
                    if(this.permDeleteDocs){
                      postData['documents']= this.permDeleteDocs;
                    }
                  }
                  else{
                    this.permDeleteDocs = [];
                    postData['documents'] = [];
                  }
                 this.loading =true;
                 let path ="/petition-common/update-internal-status";
                 if([3].indexOf(this.checkProperty(this.petitionDetails,'typeDetails', 'id' )) >-1 &&  [15].indexOf(this.checkProperty(this.petitionDetails,'subTypeDetails', 'id' )) >-1){
                    path ="/petition-common/update-internal-status";
                 }
                 
                 this.$store
                .dispatch("commonAction", {"data":postData ,"path":path})
                .then(response => {
                  
                   this.showToster({message:response.message,isError:false });
                   this.showPopup =false;
                    this.loading =false;
                      this.$emit("updatepetition", "Case Details");
                    this.hideMe()
             
                  
                  
                                  
                })
                .catch((error)=>{
                   this.loading =false;
                  this.formErrors =error;
                })
         
         
  
                
              }
            });
      },
      hideMe() {
        this.$emit("hideMe");
      },
      upload(fils, category='') {
      this.disablePWDstatus=false;
      this.pwdDocFormatError ='';
       let  model =_.cloneDeep(fils);
       this.value =[];
       var _current = this;
       // this.$vs.loading();
       if(category == 'PWD'){
          this.$vs.loading();

       }
 
       let efiles = [];
       efiles = _.filter(model, (e) => {
         return e.url != null && e.url != "";
       });
       let nfiles = _.filter(model, (e) => {
         return e.url == null || e.url == undefined;
       });
 
       let mapper = nfiles.map(
         (item) =>
           (item = {
             name: item.name,
             file: item.file ? item.file : null,
             url: item.url ? item.url : "",
             path: item.path ? item.path : "",
             status: true,
             mimetype: item.type ? item.type : item.mimetype,
           })  
       );
       let tempFiles = [];
       if (mapper.length > 0) {
         this.uploading = true;
         let count = 0;
         mapper.forEach((doc, index) => {
          if((category == 'PWD') && !( doc.mimetype=='application/pdf' )  ){
            this.pwdDocFormatError ="Upload only pdf documents";
            this.uploading = false;  
                  
            return false;

          }
           let formData = new FormData();
           formData.append("files", doc.file);
           formData.append("secureType", "private");
           formData.append("getDetails", true);
           count++;
           this.$store.dispatch("uploadS3File", formData).then((response) => {
             response.data.result.forEach((urlGenerated) => {
               //alert(JSON.stringify(urlGenerated))
               //  this.CommentPayload.documents.push(urlGenerated)
              // if (  _.has(urlGenerated, "name") &&  tempFiles.indexOf(urlGenerated["name"]) <= -1 ) {
                let tempUrl = urlGenerated
                tempUrl = Object.assign(tempUrl, { uploadedBy: this.checkProperty(this.getUserData, 'userId'), uploadedByName: this.checkProperty(this.getUserData, 'name'), uploadedByRoleId: this.getUserRoleId, uploadedByRoleName: this.checkProperty(this.getUserData, 'loginRoleName') });
                 tempFiles.push(urlGenerated["name"]);
                 if(category == 'delete'){
                  this.permDeleteDocs.push(tempUrl);
                 }
                 
            //   }
               doc.url = urlGenerated;
               doc.path = urlGenerated;
               doc["mimetype"] = urlGenerated["mimetype"];
               doc["type"] = urlGenerated["mimetype"];
               delete doc.file;
               mapper[index] = doc;
             });
             if (index >= mapper.length - 1) {
               this.uploading = false;
               // _current.$vs.loading.close();
             }
           });
         });
         if (efiles.length > 0) efiles.push(...mapper);
         //this.CommentPayload["documents"] = efiles
       }
      },
      remove(item, data, filindex) {
       data.splice(filindex, 1);
      },
      getInternalStatusList(){
        let postData ={
            page:1,
          perpage: 1000,
          category:"case_internal_status",      
        }
        this.$store.dispatch("getMasterData",postData ).then(response => {
        this.masterDataList = response.list;
        this.updatePopupTitle();
        let petitionStatusId = null
        if(this.checkProperty(this.petitionDetails,'intStatusDetails','id')){
          petitionStatusId = this.checkProperty(this.petitionDetails,'intStatusDetails','id')
        }
        if( petitionStatusId){
          this.internalStatusList =_.filter(response.list ,(item)=>{
          return [petitionStatusId].indexOf(item.id)<=-1
          })
        }
        if([50].indexOf(this.getUserRoleId)>-1){
          this.internalStatusList = _.filter(this.internalStatusList ,(item)=>{
            return item.id !=4;

          });
        }
       
        });
      },
      checkDeletedDocs(val){
      this.formErrors=''
      if(this.checkProperty(val, 'id')==1 ||this.checkProperty(val, 'id')==4 ){
        this.permDeleteDocs = []
      }
    },
    },
    watch: {
      showPopup(val) {
        if (!val) this.$emit("hideMe");
      },
    },
    mounted() {
      this. getInternalStatusList()
      let adminsactiVityList = _.find(this.workFlowDetails.config , {"code":'MANAGER_LIST'});
    if(adminsactiVityList && adminsactiVityList.editors){
    this.adminsList = _.map(adminsactiVityList.editors, 'roleId');
    }
    // let isAdmin = this.adminsList.indexOf(this.getUserRoleId) > -1
      this.showPopup = true;
      
      if([50].indexOf(this.getUserRoleId) >-1){

     
      this.popUpTitle ='Hold/Abandon Case';

      }
    //  this.updatePopupTitle();

       
     
    },
    
    data: () => ({
      editor: ClassicEditor,
 editorConfig: {
     toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
 },
      masterDataList:[],
      adminsList:[3, 4],
      popUpTitle:'',
      internalStatusList:[],
      internalStatusDetails:null,
      loading:false,
      showPopup: false,
      formErrors:'',
      formerrors: '',
      value:[],
      permDeleteDocs:[],
      uploading:false,
      internalComments:'',
    }),
    props: {
      caseNumber: {
        type: String,
        default: null,
      },
      isCaseNumberEdit: {
        type: Boolean,
        default: false,
      },
      petitionDetails: {
        type: Object,
        default: null,
      },
      workFlowDetails: {
      type: Object,
      default: null,
    },
    },
  };
  </script>