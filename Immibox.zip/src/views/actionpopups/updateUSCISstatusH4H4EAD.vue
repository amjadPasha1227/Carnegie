<template>
   
    <modal
          style="z-index:999999"
          z-index="9999"
          name="updateUscisStatus"
          classes="v-modal-sec"
          :min-width="200"
          :min-height="200"
          :scrollable="true"
          :reset="true"
          width="750px"
          height="auto"
        >
        <div class="v-modal profile_details_modal error-modal-space" >
          <div class="popup-header fromDetailsPage">
            <h2 class="popup-title">
              <template v-if="dependentType=='h4Required'">Update USCIS H4 Status </template>
              <template v-else-if="dependentType=='h4EADRequired'">Update USCIS H4 EAD Status </template>
              <template v-else-if="checkUscisStatusAutoUpdated">Upload USCIS Documents</template>
              <template v-else>Update USCIS Status</template>
              
              
            </h2>
            <span @click="showPopup=false;$modal.hide('updateUscisStatus');">
              <em class="material-icons">close</em>
            </span>
          </div>
          <form @submit.prevent data-vv-scope="uscisstatus" class="trackingform" >
              <div class="form-container" @click="usciscUpdateStatusError=''"  >
                <template v-if="(dependentType == 'h4EADRequired' || dependentType == 'h4Required') && (checkProperty(petitionDetails['dependentsInfo'],'spouse') &&
                (checkProperty(petitionDetails['dependentsInfo'],'spouse','h4EADRequired') || checkProperty(petitionDetails['dependentsInfo'],'spouse','h4Required') )
                )">
                <h3 class="small-header pt-0">Spouse</h3>
                  <div class="vx-row">
                    <div class="vx-col md:w-1/2 ">
                      <div class="form_group">
                        <label class="form_label">Case Status<em>*</em></label>
                      <div class="con-select w-full DT_multiselect">                  
                        <multiselect
                          name="casestatus"
                          v-validate="'required'"
                          v-model="spouseData.action"
                          :show-labels="false"
                          track-by="value"
                          label="text"
                          @input="clearDateFilled('spouse')"
                          data-vv-as="Status"
                          placeholder="Choose Status"
                          :options="uscisstatuslist"
                          :searchable="true"
                          :allow-empty="false"
                         
                        ></multiselect>
                      </div>
                      <span
                        class="text-danger text-sm"
                        v-show="errors.has('uscisstatus.casestatus')"
                      >{{ errors.first("uscisstatus.casestatus") }}</span>
                      </div>
                    </div>

                    <div class="vx-col md:w-1/2">
                      <div class="form_group">
                        <label class="form_label">Document Type<em>*</em></label>
                        <div class="con-select w-full DT_multiselect">  
                        <!-- {{documentType}}                 -->
                          <multiselect
                            :name="'documeType'"
                            v-validate="'required'"
                            v-model="spouseData.documentType"
                            :show-labels="false"
                            
                            data-vv-as="Document Type"
                            placeholder="Document Type"
                            :options="documentTypes"
                            :searchable="true"
                            :allow-empty="false"
                          >
                          </multiselect>
                        
                          <span  class="text-danger text-sm"  v-show="errors.has('uscisstatus.documeType')"  >{{ errors.first('uscisstatus.documeType') }}</span>
                        </div>
                      </div>
                    </div>

                    <div div class="vx-col w-full" @click="spouseDocs=[]">
                      <div class="form_group">
                        <label class="form_label" style="text-transform: capitalize"> Documents<em v-if="checkProperty(spouseData,'documents' ,'length')<=0">*</em></label>
                        <div class="uploadsec_wrap upload_uscis">
                          <div class="w-full">
                              <div class="relative">
                                <file-upload
                                  v-model="spouseDocs"
                                  class="file-upload-input mb-0"
                                  style="height:50px;"
                                  name="spouseDocs"
                                  :multiple="false"
                                
                                  data-vv-as="Documents"
                                  :accept="allDocEntity"
                                  @input="uploadDocuments({userType:'spouse' , typeId:1, childrenId:'' ,userName:checkProperty(petitionDetails ,'beneficiaryInfo' ,'name'),category:'spouse'})"
                                >
                                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                                  Upload
                                </file-upload>
                                <span class="loader" v-if="checkProperty(documentUpload ,'spouse')"><img src="@/assets/images/main/loader.gif"></span>
                              </div>
                            <span class="file-type mb-0">(File Type: PDF, DOC, JPEG, PNG. Max file size: 1MB)</span>
                            <span v-if="pwdDocFormatError" class="text-danger text-sm" >{{pwdDocFormatError}}</span>
                            <input type="hidden" :name="'spouseDocuments'" v-validate="'required'"  data-vv-as="Documents"  v-model="spouseData.documents">
                          <span class="text-danger text-sm" v-if="errors.has('uscisstatus.spouseDocuments')">{{ errors.first('uscisstatus.spouseDocuments') }}</span>
                            <!-- <span class="text-danger text-sm" v-show="errors.has('uscisstatus.trackingdoc')">{{ errors.first("uscisstatus.trackingdoc") }}</span> -->
                              <!-- <VuePerfectScrollbar class="scrollbardoc"> -->
                                  <div class="uploded-files_wrap mb-5" v-if="spouseData.documents.length >0 ">
                                      <template v-for="(fil, fileindex) in spouseData.documents">
                                        <div class="w-full"  :key="fileindex" v-if="checkProperty(fil ,'userType') =='spouse'">
                                            <div class="uploded-files">
                                                <vx-input-group class="form-input-group">
                                                  <vs-input v-on:keyup="fileNameChenged(fil)"  v-validate="'required'" class="w-full" :name="'fName'+fileindex" v-model="spouseData.documents[fileindex]['name']" data-vv-as="File Name" />
                                                    <span class="text-danger text-sm" v-show="errors.has('uscisstatus.fName'+fileindex)">{{ errors.first('uscisstatus.fName'+fileindex) }}</span>

                                                    
                                                </vx-input-group>

                                                <div class="form_group">
                                                

                                                  
                                                <div class="delete" style="z-index:999" @click="remove(fileindex , 'spouse')">
                                                        <img src="@/assets/images/main/delete-row-img.svg" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </template>
                                  </div>
                              <!-- </VuePerfectScrollbar> -->
                            </div>
                        </div>
                      </div>
                    </div>

                    
                  </div>
                  <div  class="vx-row" v-if="checkProperty(spouseData,'documents','length') >0 && checkProperty(spouseData ,'action') "  >
                     <datepickerField :isDisabled="prefilledKyes.indexOf('spouseDataissuedDate')>-1 && checkProperty(spouseData,'issuedDate')" wrapclass="md:w-1/2" @input="updateRfeIssuedDate($event,'spouse')" v-if="checkProperty(spouseData,'action' ,'value') =='USCIS_RECEIVED_RFE'" :dateEnableTo="new Date()" :display="true"  v-model="spouseData.issuedDate" :formscope="'uscisstatus'" fieldName="issuedDate"  label="RFE Issued Date" :validationRequired="true" />
                     <datepickerField :isDisabled="(prefilledKyes.indexOf('spouseDatareceivedDate')>-1 && checkProperty(spouseData,'receivedDate')) || (checkProperty(spouseData,'issuedDate') == null && checkProperty(spouseData,'action' ,'value') =='USCIS_RECEIVED_RFE')" wrapclass="md:w-1/2"  :display="true" :dateEnableFrom="spouseData.issuedDate" :dateEnableTo="new Date()" v-model="spouseData.receivedDate" :formscope="'uscisstatus'" fieldName="receivedDate"  label="Received Date" :validationRequired="true" />  
                     <datepickerField :isDisabled="(prefilledKyes.indexOf('spouseDatadueDate')>-1 && checkProperty(spouseData,'dueDate')) || (checkProperty(spouseData,'issuedDate') == null && checkProperty(spouseData,'action' ,'value') =='USCIS_RECEIVED_RFE')" wrapclass="md:w-1/2"
                       v-if="checkProperty(spouseData,'action' ,'value') =='USCIS_RECEIVED_RFE'"  :dateEnableFrom="spouseData.issuedDate" :display="true"  v-model="spouseData.dueDate" :formscope="'uscisstatus'" fieldName="dueDate"  label="RFE Due Date" :validationRequired="true" />
                

                    <div class="vx-col w-full">
                      <div class="form_group">
                        <label class="form_label">Comments<em>*</em></label>
                        <ckeditor  data-vv-as="Comments"
                          v-validate="'required'"
                          v-model="spouseData.description"
                          name="spouseData.description"
                          class="w-full" :editor="editor" :config="editorConfig"></ckeditor>

                        <span
                          class="text-danger text-sm"
                          v-show="errors.has('uscisstatus.spouseData.description')"
                        >* Comments are required</span>
                      </div>
                    </div>
                    
                    
                
                  </div>
                </template>
                <template v-if="dependentType == 'h4Required'  && checkChildH4">
                  <h3 class="small-header pt-0">Children</h3>
                  <div class="vx-row">
                    <div class="vx-col md:w-1/2 ">
                      <div class="form_group">
                        <!----:disabled="disabledStatus"-->
                        <label class="form_label">Case Status<em>*</em></label>
                      <div class="con-select w-full DT_multiselect">                  
                        <multiselect
                          name="casestatuscasestatus"
                          v-validate="'required'"
                          v-model="childrenData.action"
                          :show-labels="false"
                          track-by="value"
                          label="text"
                          @input="clearDateFilled('child')"
                          data-vv-as="Status"
                          placeholder="Choose Status"
                          :options="uscisstatuslist"
                          :searchable="true"
                          :allow-empty="false"
                          
                        ></multiselect>
                      </div>
                      <span
                        class="text-danger text-sm"
                        v-show="errors.has('uscisstatus.casestatuscasestatus')"
                      >{{ errors.first("uscisstatus.casestatuscasestatus") }}</span>
                      </div>
                    </div>

                    <div class="vx-col md:w-1/2">
                      <div class="form_group">
                        <label class="form_label">Document Type<em>*</em></label>
                        <div class="con-select w-full DT_multiselect">  
                        <!-- {{documentType}}                 -->
                          <multiselect
                            :name="'childrenData.documentType'"
                            v-validate="'required'"
                            v-model="childrenData.documentType"
                            :show-labels="false"
                            
                            data-vv-as="Document Type"
                            placeholder="Document Type"
                            :options="documentTypes"
                            :searchable="true"
                            :allow-empty="false"
                          >
                          </multiselect>
                        
                          <span  class="text-danger text-sm"  v-show="errors.has('uscisstatus.childrenData.documentType')"  >{{ errors.first('uscisstatus.childrenData.documentType') }}</span>
                        </div>
                      </div>
                    </div>

                    <div div class="vx-col w-full" @click="childDocs=[]">
                      <div class="form_group">
                        <label class="form_label" style="text-transform: capitalize"> Documents<em v-if="checkProperty(childrenData.documents ,'length')<=0">*</em></label>
                        <div class="uploadsec_wrap upload_uscis">
                          <div class="w-full">
                              <div class="relative">
                                <file-upload
                                  v-model="childDocs"
                                  class="file-upload-input mb-0"
                                  style="height:50px;"
                                  name="trackingdoc"
                                  :multiple="false"
                                  data-vv-as="Documents"
                                  :accept="allDocEntity"
                                  @input="uploadDocuments({userType:'children' , typeId:1, childrenId:'' ,userName:'',category:'child'})"
                                >
                                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                                  Upload
                                </file-upload>
                                <span class="loader" v-if="checkProperty(documentUpload ,'child')"><img src="@/assets/images/main/loader.gif"></span>
                              </div>
                              
                            <span class="file-type mb-0">(File Type: PDF, DOC, JPEG, PNG. Max file size: 1MB)</span>
                            <span v-if="pwdDocChildFormatError" class="text-danger text-sm" >{{pwdDocChildFormatError}}</span>
                            <input type="hidden" :name="'childDocuments'" v-validate="'required'"  data-vv-as="Documents"  v-model="childrenData.documents">
                          <span class="text-danger text-sm" v-if="errors.first('uscisstatus.childDocuments')">{{ errors.first('uscisstatus.childDocuments') }}</span>
                            <!-- <span class="text-danger text-sm" v-show="errors.has('uscisstatus.trackingdoc')">{{ errors.first("uscisstatus.trackingdoc") }}</span> -->
                                  <div class="uploded-files_wrap mb-5" v-if="childrenData.documents.length >0 ">
                                      <template v-for="(fil, fileindex) in childrenData.documents">
                                        <div class="w-full"  :key="fileindex" v-if="checkProperty(fil ,'userType') =='children'">
                                            <div class="uploded-files">
                                                <vx-input-group class="form-input-group">
                                                  <vs-input v-on:keyup="fileNameChenged(fil)"  v-validate="'required'" class="w-full" :name="'fName'+fileindex" v-model="childrenData.documents[fileindex]['name']" data-vv-as="File Name" />
                                                    <span class="text-danger text-sm" v-show="errors.has('uscisstatus.fName'+fileindex)">{{ errors.first('uscisstatus.fName'+fileindex) }}</span>

                                                    
                                                </vx-input-group>

                                                <div class="form_group">
                                                

                                                  
                                                <div class="delete" style="z-index:999" @click="remove(fileindex , 'child')">
                                                        <img src="@/assets/images/main/delete-row-img.svg" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </template>
                                  </div>
                            </div>
                        </div>
                      </div>
                    </div>
                  
                    
                  </div>
                  <div  class="vx-row" v-if="checkProperty(childrenData,'documents','length' ) >0 && checkProperty(childrenData,'action' ,'value') " >
                    <datepickerField wrapclass="md:w-1/2"  :isDisabled="prefilledKyes.indexOf('childrenDataissuedDate')>-1 && checkProperty(childrenData,'issuedDate')" @input="updateRfeIssuedDate($event,'child');" v-if="checkProperty(childrenData,'action' ,'value') =='USCIS_RECEIVED_RFE'" :dateEnableTo="new Date()" :display="true"  v-model="childrenData.issuedDate" :formscope="'uscisstatus'" fieldName="childrenDataissuedDate"  label="RFE Issued Date" :validationRequired="true" />              
                    <datepickerField wrapclass="md:w-1/2" :isDisabled="(prefilledKyes.indexOf('childrenDatareceivedDate')>-1 && checkProperty(childrenData,'receivedDate')) || (checkProperty(childrenData,'issuedDate') == null && checkProperty(childrenData,'action' ,'value') =='USCIS_RECEIVED_RFE')"  :display="true" :dateEnableFrom="childrenData.issuedDate" :dateEnableTo="new Date()" v-model="childrenData.receivedDate" :formscope="'uscisstatus'" fieldName="childrenDatareceivedDate"  label="Received Date" :validationRequired="true" />  
                   <datepickerField wrapclass="md:w-1/2" :isDisabled="(prefilledKyes.indexOf('childrenDatadueDate')>-1 && checkProperty(childrenData,'dueDate')) || (checkProperty(childrenData,'issuedDate') == null && checkProperty(childrenData,'action' ,'value') =='USCIS_RECEIVED_RFE')"   v-if="checkProperty(childrenData,'action' ,'value') =='USCIS_RECEIVED_RFE'"  :dateEnableFrom="childrenData.issuedDate" :display="true"  v-model="childrenData.dueDate" :formscope="'uscisstatus'" fieldName="childrenDatadueDate"  label="RFE Due Date" :validationRequired="true" />
                



                    <div class="vx-col w-full">
                    <div class="form_group">
                      <label class="form_label">Comments<em>*</em></label>
                      <ckeditor  data-vv-as="Comments"
                        v-validate="'required'"
                        v-model="childrenData.description"
                        name="childrenData.description"
                        class="w-full" :editor="editor" :config="editorConfig"></ckeditor>

                      <span
                        class="text-danger text-sm"
                        v-show="errors.has('uscisstatus.childrenData.description')"
                      >* Comments are required</span>
                    </div>
                    </div>
                
                  </div>
                </template>
              </div>
              
              <div @click="usciscUpdateStatusError=''" class="text-danger text-sm formerrors" v-if="usciscUpdateStatusError!=''">
                        <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ usciscUpdateStatusError }}</vs-alert>
              </div>

              <div class="popup-footer relative">
              <span class="loader" v-if="usciscUpdating"><img src="@/assets/images/main/loader.gif"></span>
                <vs-button color="dark" class="cancel" type="filled" @click="documentModel=[]; hideMe()">Cancel</vs-button>
                <vs-button color="success" :disabled="usciscUpdating || checkProperty(documentUpload ,'child') || checkProperty(documentUpload ,'spouse')" @click="submitForm()" class="save" type="filled">Submit</vs-button>
              </div>
          </form>
          </div>
        </modal>  
</template>
<script>
import moment from "moment";
import FileUpload from "vue-upload-component/src";
import { EyeIcon } from "vue-feather-icons";
import docType from "@/views/common/docType.vue";
import Datepicker from "vuejs-datepicker-inv";
import * as _ from "lodash";
import datepickerField from "@/views/forms/fields/datepicker.vue";
import Vue from 'vue';
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';

export default {
provide() {
    return {
        parentValidator: this.$validator,
    };
},
components: {
  docType,
  EyeIcon,
  FileUpload,
  Datepicker,
  datepickerField
},
computed: {
  checkUscisStatusAutoUpdated(){
    if(this.checkProperty(this.petitionDetails ,'uploadUscisDocs')!=true && this.checkProperty(this.petitionDetails ,'autoUscisStatusUpdate') ==true){
         return true
    }else{
      return false;
    }
  },
  checkChildH4(){
    let returnVal = false;
    if(this.checkProperty(this.petitionDetails,'dependentsInfo','childrens') && this.checkProperty(this.petitionDetails['dependentsInfo'],'childrens','length')>0 ){
      let findObj = _.find(this.petitionDetails['dependentsInfo']['childrens'],{'h4Required':true});
      if(findObj){
        returnVal = true;
        return returnVal;
      }
    }
    return returnVal;
  },
  checkEligibleDate(){
   
    if(this.checkProperty(this.casestatus ,'value') =='USCIS_RECEIVED_RFE' && this.issuedDate){
      return this.issuedDate
    }else{
      return new Date()
    }
  }
},
methods: {
  clearDateFilled(category=''){
    //this.receivedDate = null
    if(category=='spouse'){
      this.pwdDocFormatError='';
      this.spouseData.documents =[];
      this.prefilledKyes =[];
      this.spouseData.documentType=null;
      this.spouseData.dueDate = null
      this.spouseData.issuedDate = null
      this.spouseData.receivedDate = null
      this.spouseData.description =''
    }
    if(category=='child'){
      this.childrenData.documents =[];
      this.prefilledKyes =[];
      this.pwdDocChildFormatError='';
      this.childrenData.documentType=null;
      this.childrenData.dueDate = null
      this.childrenData.issuedDate = null
      this.childrenData.receivedDate = null
      this.childrenData.description =''
    }
  },
  updateRfeIssuedDate(val, category=''){
    if(category=='spouse'){
      if(val){
      if(this.receivedDate){
      let startData = moment(val);
      let endData= moment(this.receivedDate)
      if(startData.isAfter(endData , 'day')){
        this.receivedDate = null
      }
    }
    if(this.dueDate){
      let startDate = moment(val);
      let endDate= moment(this.dueDate)
      if(startDate.isAfter(endDate , 'day')){
        this.dueDate = null
      }
    }
    }
    else{
      this.spouseData.receivedDate=null   
      this.spouseData.dueDate=null
      

    }
    }
    if(category=='child'){
      if(val){
      if(this.receivedDate){
      let startData = moment(val);
      let endData= moment(this.receivedDate)
      if(startData.isAfter(endData , 'day')){
        this.receivedDate = null
      }
    }
    if(this.dueDate){
      let startDate = moment(val);
      let endDate= moment(this.dueDate)
      if(startDate.isAfter(endDate , 'day')){
        this.dueDate = null
      }
    }
    }
    else{
      this.childrenData.receivedDate =null 
      this.childrenData.dueDate=null
    }
    }
  },
 
  remove(index ,docs){


    if(this.prefilledKyes.indexOf('spouseDatareceivedDate')>-1){
        this.spouseData.receivedDate = null;
    }
    if(this.prefilledKyes.indexOf('spouseDataissuedDate')>-1){
        this.spouseData.issuedDate = null;
    }
    if(this.prefilledKyes.indexOf('spouseDatadueDate')>-1){
        this.spouseData.dueDate = null;
    }

    if(this.prefilledKyes.indexOf('childrenDatareceivedDate')>-1){
        this.childrenData.receivedDate = null;
    }
    if(this.prefilledKyes.indexOf('childrenDataissuedDate')>-1){
        this.childrenData.issuedDate = null;
    }
    if(this.prefilledKyes.indexOf('childrenDatadueDate')>-1){
        this.childrenData.dueDate = null;
    }


    this.prefilledKyes =[];

    if(docs == 'spouse'){
      this.spouseData.documents.splice(index ,1)
      this.pwdDocFormatError='';
      this.spouseData.receivedDate = null
      this.spouseData.description =''

    }
    if(docs == 'child'){
      this.childrenData.documents.splice(index ,1)
      this.pwdDocChildFormatError='';
      this.childrenData.receivedDate = null
      this.childrenData.description =''
    }
    //docs.splice(index ,1);
  },
  /**
   * 
   * @param userType | String
   * @param typeId | String
   * @param childrenId | String
   * @param userName | String
   */
  uploadDocuments({userType='' , typeId='', childrenId='' ,userName='',category=''}){
    let docs = [];
    if(category=='spouse'){
      docs = _.cloneDeep(this.spouseDocs)
    }
    if(category=='child'){
      docs = _.cloneDeep(this.childDocs)
    }
      //  let docs =_.cloneDeep(this.documentModel);
       var self = this;
       this.documentModel=[];
       
          docs = docs.map(
              (item) =>{
                  item = {
                      name: item.name,
                      file: item.file,
                      path: "",
                      size:item.size ? item.size : null,
                      mimetype: item.type,
                      extn:item.extn?item.extn:'',
                      documentType:item.documentType?item.documentType:null,
                      userName:'',
                      uploadedBy:item.uploadedBy?item.uploadedBy:self.checkProperty(self.getUserData,'userId')!=''?self.checkProperty(self.getUserData,'userId'):null,
                      uploadedByName:item.uploadedByName?item.uploadedByName:self.checkProperty(self.getUserData,'name')!=''?self.checkProperty(self.getUserData,'name'):'',
                      uploadedByRoleId:item.uploadedByRoleId?item.uploadedByRoleId:self.getUserRoleId?self.getUserRoleId:null,
                      uploadedByRoleName:item.uploadedByRoleName?item.uploadedByRoleName:self.checkProperty(self.getUserData,'loginRoleName'),
                  
                     
                  }
                  if(typeId){
                    item  = Object.assign(item ,{"typeId":typeId});
                  }
                  if(childrenId){
                    item  = Object.assign(item ,{"childrenId":childrenId});
                  }
                  if(userType){
                    item  = Object.assign(item ,{"userType":userType});
                  }
                   if(userName){
                    item  = Object.assign(item ,{"userName":userName});
                  }
                  
              return item;

            }
          );
         
          if (docs.length > 0) {
             
              this.filesAreuploading = false;
             if(category){
              this.documentUpload[category] = true;
             }
              if(userType && !childrenId ){
                this.documentsUploading[userType] =true;
              }else if(childrenId){
                 this.documentsUploading[childrenId] =true;
              }
              
              let count =0;
              docs.forEach(function (doc) {
                  let formData = new FormData();
                  formData.append("files", doc.file);
                  formData.append("secureType", "private");
                  formData.append("getDetails", true);
                  self.$store.dispatch("uploadS3File", formData).then((response) => {
                    count = count+1;
                      if (response.data && response.data.result) {
                          response.data.result.forEach((urlGenerated) => {
                            //alert(JSON.stringify(urlGenerated))
                              // doc.url = urlGenerated;
                               doc.path = urlGenerated['path'];
                               doc.mimetype = urlGenerated['mimetype'];
                                doc.extn = urlGenerated['extn'];
                                if(_.has(urlGenerated ,'size' )){
                                   doc['size'] = urlGenerated['size'];
                                 }
                              delete doc.file;
                              if(urlGenerated['path']){
                                  if(userType && !childrenId ){

                                    self.statusDocuments =_.filter(self.statusDocuments ,(item)=>{
                                        return item['userType'] !=userType
                                    })

                                  }else{
                                     self.statusDocuments =_.filter(self.statusDocuments ,(item)=>{
                                        return item['childrenId'] !=childrenId
                                    })

                                  }
                                  Object.assign(doc, {uploadedOn: moment().format("YYYY-MM-DD"), uploadedBy: self.checkProperty(self.getUserData, 'userId'), uploadedByName: self.checkProperty(self.getUserData, 'name'), uploadedByRoleId: self.getUserRoleId, uploadedByRoleName: self.checkProperty(self.getUserData, 'loginRoleName') });
                                  let docval = [];
                                  docval.push(doc)
                                  if(category == 'spouse'){
                                    self.spouseData.documents= docval;
                                  }
                                  if(category == 'child'){
                                    self.childrenData.documents= docval;
                                  }
                                  
                                 
                                //  self.statusDocuments.push(doc)
                              }
                              
                              if(parseInt(count)>=docs.length){
                                 self.filesAreuploading = false;
                                 self.usciscUpdating =false;
                                 self.prefillRfeNoticeDoc(category);
                                 if(category){
                                  self.documentUpload[category] = false;
                                }
                                if(userType && !childrenId ){
                                  self.documentsUploading[userType] =false;
                                }else if(childrenId){
                                  self.documentsUploading[childrenId] =false;
                                }

                              }
                          });
                          if(count>=docs.length){
                            self.filesAreuploading = false;
                            self.usciscUpdating =false;
                            if(category){
                              self.documentUpload[category] = false;
                            }
                          if(userType && !childrenId ){
                            self.documentsUploading[userType] =false;
                          }else if(childrenId){
                            self.documentsUploading[childrenId] =false;
                          }

                          }
                          
                      }
                     
                  });
              });
          }
  },
 
      selectedDocuments(index, fls) {

        let docs =_.cloneDeep(fls)
          let formData = new FormData();
          docs = docs.map(
              (item) =>
              (item = {
                  name: item.name,
                  file: item.file,
                  url: "",
                  path: "",
                  mimetype: item.type,
                  documentType:item.documentType?item.documentType:null,
              })
          );
         
          if (docs.length > 0) {
              var self = this;
              this.filesAreuploading = true;
              let count =0;
              docs.forEach(function (doc) {
                  formData.append("files", doc.file);
                  formData.append("secureType", "private");
                  self.$store.dispatch("uploadS3File", formData).then((response) => {
                    count = count+1;
                      if (response.data && response.data.result) {
                          response.data.result.forEach((urlGenerated) => {
                              doc.url = urlGenerated;
                               doc.path = urlGenerated;
                              delete doc.file;
                              self.tracking.documents = docs;
                              self.uscisdocument = docs;
                              self.trackingdoc = docs;
                              self.documentData.documentUploaded = docs;
                                  
                               if(parseInt(count)>=docs.length){
                                 self.filesAreuploading = false;
                                

                              }
                          });
                          if(count>=docs.length){
                            self.filesAreuploading = false;

                          }
                          
                      }
                     
                  });
              });
          }
      },
  fileNameChenged(index, fileindex) {
          this.disable_uploadBtn = false;

          _.forEach(this.documentData, (doc, value) => {
              if (doc.documentUploaded.length > 0) {
                  _.forEach(doc.documentUploaded, (fl, value) => {
                      let fname = fl.name;
                      fname = fname.trim();

                      if (!fname) {
                          this.disable_uploadBtn = true;
                      }
                  });
              }
          });

      },

 fileNameChengedScannedFiles( fileindex) {
          this.disable_uploadBtn = false;

         
              if (this.uploadScanedFilsList.length > 0) {
                  _.forEach(this.uploadScanedFilsList, (fl, value) => {
                      let fname = fl.name;
                      fname = fname.trim();

                      if (!fname) {
                          this.disable_uploadBtn = true;
                      }
                  });
              }
        

      },
      upload( docs) {
          
          
         
          if (docs.length > 0) {
              var self = this;
              self.filesAreuploading = true;
              let count =0;
              docs.forEach(function (doc) {
                let formData = new FormData();
                  formData.append("files", doc.file);
                  formData.append("secureType", "private");
                   formData.append("getDetails",true);
                  
                  self.$store.dispatch("uploadS3File", formData).then((response) => {
                    count = count+1;
                      if (response.data && response.data.result) {
                          response.data.result.forEach((urlGenerated) => {
                            let tempUrl = urlGenerated
                            tempUrl = Object.assign(tempUrl, { uploadedBy: this.checkProperty(this.getUserData, 'userId'), uploadedByName: this.checkProperty(this.getUserData, 'name'), uploadedByRoleId: this.getUserRoleId, uploadedByRoleName: this.checkProperty(this.getUserData, 'loginRoleName') });

                              self.uploadScanedFilsList.push(tempUrl) ;  
                              self.uploadScanedFilsList = _.cloneDeep(self.uploadScanedFilsList);
                               if(parseInt(count)>=docs.length){
                                 self.filesAreuploading = false;
                                
                                

                              }
                          });
                          if(count>=docs.length){
                            self.filesAreuploading = false;

                          }
                          
                      }
                     
                  });
              });
          }
      },
      prefillRfeNoticeDoc(category){
        let self =this;
          this.draftExtractInfo = null;
          this.pwdDocFormatError = '';
          this.pwdDocChildFormatError = '';
          var _dt;
          this.prefilledKyes =[];
          this.$validator.reset();
          let statusDocuments = [];
          if(category=='spouse'){
              statusDocuments= self.spouseData.documents;
          }else if(category=='child'){
            statusDocuments =  self.childrenData.documents;
          }
          if(this.checkProperty(statusDocuments, 'length' )>0){
                
            this.uploading = true;  
            let path ="/common/extract-data-from-pdf";
            let postData ={
              "category": "rfe_notice",
              "docType": "rfe_notice",
              documents:[],
              "lcaDocument":''
            };
          
            let doc = statusDocuments[0];
            postData['lcaDocument'] = doc.path;
            postData['documents'].push(doc.path);
            this.$vs.loading();
            this.pwdDocFormatError = '';
            this.pwdDocChildFormatError='';
            this.$store.dispatch('commonAction', {"data":postData ,"path":path})
                .then((response)=>{
                  this.$vs.loading.close();
                  this.pwdDocFormatError = '';
                  this.pwdDocChildFormatError ='';
                  this.uploading = false;  
                  //this.casestatus = { "value": "USCIS_RECEIVED_RFE", "text": "RFE Received" }
                  this.draftExtractInfo =response;
                  if(category=='spouse'){
                 

                  if(self.checkProperty(self.draftExtractInfo ,'receivedDate')){
                    self.spouseData.receivedDate = self.draftExtractInfo['receivedDate']; 
                    self.prefilledKyes.push('spouseDatareceivedDate');
                  }

                  if(self.checkProperty(self.draftExtractInfo ,'rfeIssuedDate')){
                    self.spouseData.issuedDate = self.draftExtractInfo['rfeIssuedDate']; 
                    self.prefilledKyes.push('spouseDataissuedDate');
                  }
                  if(self.checkProperty(self.draftExtractInfo ,'uscisDeadlineDate')){
                    self.spouseData.dueDate = self.draftExtractInfo['uscisDeadlineDate']; 
                    self.prefilledKyes.push('spouseDatadueDate');
                  }



                }else if(category=='child'){
            

            if(self.checkProperty(self.draftExtractInfo ,'receivedDate')){
                    self.childrenData.receivedDate = self.draftExtractInfo['receivedDate']; 
                    self.prefilledKyes.push('childrenDatareceivedDate');
                  }

                  if(self.checkProperty(self.draftExtractInfo ,'rfeIssuedDate')){
                    self.childrenData.issuedDate = self.draftExtractInfo['rfeIssuedDate']; 
                    self.prefilledKyes.push('childrenDataissuedDate');
                  }
                  if(self.checkProperty(self.draftExtractInfo ,'uscisDeadlineDate')){
                    self.childrenData.dueDate = self.draftExtractInfo['uscisDeadlineDate']; 
                    self.prefilledKyes.push('childrenDatadueDate');
                  }


           


          }

                 

              
                  // if(this.checkProperty(this.draftExtractInfo ,'uscisReceiptNumber')){
                  //   this.rfeData['uscisReceiptNumber'] = this.draftExtractInfo['uscisReceiptNumber'];
                  //   this.prefilledKyes.push('uscisReceiptNumber');
                  // } { "value": "USCIS_RECEIVED_RFE", "text": "RFE Received" }
                
                  

                }).catch((errr)=>{
                 
                 this.$vs.loading.close();
                 if(this.checkProperty(this.spouseData ,'action' ,'value') =='USCIS_RECEIVED_RFE' &&  category=='spouse'){
                  this.pwdDocFormatError = errr;
                  this.spouseData.dueDate = null
                  this.spouseData.issuedDate = null
                  this.spouseData.receivedDate = null

                 }
                 if(this.checkProperty(this.childrenData ,'action' ,'value') =='USCIS_RECEIVED_RFE' && category=='child' ){
                  this.pwdDocChildFormatError = errr;
                  this.childrenData.dueDate = null
                  this.childrenData.issuedDate = null
                  this.childrenData.receivedDate = null
                 }
                 
                  //this.pwdDocFormatError = errr
                  //this.uploading = false;  
                });
          }

        },
        resetPrefedKyes(){
          this.draftExtractInfo =null;
          if( this.prefilledKyes.indexOf('issuedDate')>-1){
            this.issuedDate =  null;
          }
          if( this.prefilledKyes.indexOf('receivedDate')>-1){
            this.receivedDate = null;
          }
          if( this.prefilledKyes.indexOf('dueDate')>-1){
            this.dueDate = null;
          }
          this.prefilledKyes =[];
          this.draftExtractInfo =null;
          this.$validator.reset();
        },
  submitForm() {
          this.usciscUpdateStatusError='';
          let self =this;
          this.$validator.validateAll("uscisstatus").then((result) => {
              if (result) {
                  let payload = {
                    petitionId: this.petitionDetails._id,
                    category: this.usciscomments,
                    today: moment().format("YYYY-MM-DD"),
                    "typeId": self.checkProperty(self.petitionDetails,'typeDetails','id' ),
                    "typeName":self.checkProperty(self.petitionDetails,'typeDetails','name' ),
                    "subTypeId":self.checkProperty(self.petitionDetails,'subTypeDetails','id' ), 
                    "subTypeName":self.checkProperty(self.petitionDetails,'subTypeDetails','name' ),
                    items:[] 
                  };
                  if(this.dependentType == 'h4Required'){
                    payload['category'] = 'h4'
                  }
                  if(this.dependentType == 'h4EADRequired'){
                    payload['category'] = 'h4ead'
                  }
                  if(this.dependentType == 'h4Required'){
                    if(this.checkProperty(this.petitionDetails['dependentsInfo'],'spouse') && this.checkProperty(this.petitionDetails['dependentsInfo'],'spouse','h4Required')){
                      let spousedt = _.cloneDeep(this.spouseData);
                      spousedt['userName'] = this.checkProperty(this.petitionDetails['dependentsInfo'],'spouse','name');
                      if(this.spouseData['action']){
                        spousedt['action'] = this.checkProperty(this.spouseData['action'],'value');

                        if(['RFE_UPDATE_USCIS_RESPONSE_H4','RFE_UPDATE_USCIS_RESPONSE_H4EAD'].indexOf(this.ACTIVITYCODE)>-1 ){
                          spousedt['action'] ='RFE_'+spousedt['action'];
                         }
                      }
                      payload['items'].push(spousedt)
                    }
                    if(this.checkProperty(this.petitionDetails,'dependentsInfo','childrens') && this.checkProperty(this.petitionDetails['dependentsInfo'],'childrens','length')>0 ){
                      let findObj = _.find(this.petitionDetails['dependentsInfo']['childrens'],{'h4Required':true});
                      if(findObj){
                        let childt = _.cloneDeep(this.childrenData);
                        if(this.childrenData['action']){
                          childt['action'] = this.checkProperty(this.childrenData['action'],'value');
                          if(['RFE_UPDATE_USCIS_RESPONSE_H4','RFE_UPDATE_USCIS_RESPONSE_H4EAD',].indexOf(this.ACTIVITYCODE)>-1 ){
                            childt['action'] ='RFE_'+childt['action'] ;
                         }
                          payload['items'].push(childt)
                      }
                      }
                    }
                  }
                  if(this.dependentType == 'h4EADRequired'){
                    if(this.checkProperty(this.petitionDetails['dependentsInfo'],'spouse') && this.checkProperty(this.petitionDetails['dependentsInfo'],'spouse','h4EADRequired')){
                      let spousedt = _.cloneDeep(this.spouseData);
                      spousedt['userName'] = this.checkProperty(this.petitionDetails['dependentsInfo'],'spouse','name');
                      if(this.spouseData['action']){
                        spousedt['action'] = this.checkProperty(this.spouseData['action'],'value')
                        if(['RFE_UPDATE_USCIS_RESPONSE_H4','RFE_UPDATE_USCIS_RESPONSE_H4EAD',].indexOf(this.ACTIVITYCODE)>-1 ){
                          spousedt['action'] ='RFE_'+spousedt['action'] ;
                         }
                      }
                      payload['items'].push(spousedt)
                    }
                  }
                  this.usciscUpdating =true;
                  this.filesAreuploading =false;
                  
                 
                  let path ='/petition/manage-approval-process-h4-h4ead';
                  this.$store.dispatch('commonAction', {'data':payload,'path':path})
                      .then((response) => {
                        this.$emit("updatepetition", "Petition Updates");
                        self.hideMe();
                          if (self.casestatus.value == "USCIS_RECEIVED_RFE") {
                              self.$store.dispatch("fileRFE", rfepayload).then((response) => {
                                  self.showToster({ message:response.message , isError: false})

                                    this.$emit("updatepetition", "Petition Updates");
                                    self.hideMe();
                              });
                          } else {
                           
                             
                              // this.showMessages(response.message);
                              self.showToster({ message:response.message , isError: false})
                              this.$emit("updatepetition", "Petition Updates");
                              self.hideMe();
                          }
                            this.usciscUpdating =false;
                      })
                      .catch((error) => {
                         this.usciscUpdating =false;
                         this.filesAreuploading =false;
                         this.usciscUpdateStatusError =error;
                        //this.showToster({ message: error, isError: true });
                      });
              }else{
               // this.showToster({ message:"Invalid data" , isError: true});
              }
          });
  },
  hideMe() {

    this.$emit("hideMe");
     this.$modal.hide('updateUscisStatus');
  },
  init(){
    let uscisList = [];
    if(this.checkProperty(this.petitionDetails['dependentsInfo'],'spouse',this.dependentType) == true){
        let tempobj={
            description:'',
            issuedDate:null,
            receivedDate:null,
            dueDate:null,
            documents:[],
            label:'',
            action:null
        };
        let templabe = this.checkProperty(this.petitionDetails['dependentsInfo'] ,'spouse' ,'name');
        let findspouse = _.find(uscisList,{'label':templabe});
        tempobj['label'] = templabe;
        uscisList.push(tempobj);
    }
    if(this.checkProperty(this.petitionDetails['dependentsInfo'],'childrens') && this.checkProperty(this.petitionDetails['dependentsInfo'],'childrens','length')>0){
        let obj={
            description:'',
            issuedDate:null,
            receivedDate:null,
            dueDate:null,
            documents:[],
            label:'',
            action:null
        };
        _.forEach(this.checkProperty(this.petitionDetails['dependentsInfo'],'childrens'),(item)=>{
            if(this.checkProperty(item,this.dependentType) == true){
                let labe = this.checkProperty(item ,'name');
                let findchild = _.find(uscisList,{'label':labe});
                if(!findchild){
                    obj['label'] = labe;
                    uscisList.push(obj);
                }
            }
        })
        
    }
    if(uscisList){
        this.uscisList = _.cloneDeep(uscisList)
    }
  }
},
watch: {
  showPopup(val) {
    if (!val){
      this.$emit("hideMe");
      this.$modal.hide('updateUscisStatus');
    } 
  },
},
mounted() {
    this.init();
  let documentsUploading={
    "beneficiary":false,
    "spouse":false,

  };
  if(this.checkProperty(this.petitionDetails ,'dependentsInfo','childrens')){
    _.forEach(this.petitionDetails['dependentsInfo']['childrens'] ,(item)=>{
      if(this.checkProperty(item ,'_id')){
         documentsUploading[item['_id']] = false;
      }
       
    })

  }
    this.documentsUploading =_.cloneDeep(documentsUploading);
    this.showPopup = true;
    

    //casestatus
    //uscisstatuslist
    this.disabledStatus =false;
    setTimeout(() => {
      if(this.petitionDetails && _.has(this.petitionDetails ,'currentActivity') && _.find(this.uscisstatuslist ,{"value":this.petitionDetails['currentActivity']}) ){
         this.casestatus = _.find(this.uscisstatuslist ,{"value":this.petitionDetails['currentActivity']});
         this.disabledStatus =true;
         
         if(_.has( this.petitionDetails,'rfeNotice') && (_.has( this.petitionDetails['rfeNotice'],'receivedDate'))){
            this.receivedDate = this.petitionDetails['rfeNotice']['receivedDate'];
         }
      }

      
    }, 100);
    this.$modal.show('updateUscisStatus');
  
},
data: () => ({
  prefilledKyes:[],
  draftExtractInfo:null,
  pwdDocFormatError:'',
  pwdDocChildFormatError:'',
  spouseDocs:[],
  childDocs:[],
  spouseData:{
    userType:'spouse',
    userName:'',
    action:'',
    description:'',
    issuedDate:null,
    receivedDate:null,
    dueDate:null,
    documents:[],
    documentType:''
  },
  childrenData:{
    userType:'children',
    userName:'',
    action:'',
    description:'',
    issuedDate:null,
    receivedDate:null,
    dueDate:null,
    documents:[],
    documentType:''
  },
    uscisstatuslist: [
      {
        value: "USCIS_APPROVED",
        text: "Case Approved",
      },
      {
        value: "USCIS_RECEIVED_RFE",
        text: "RFE Received",
      },
      {
        value: "USCIS_DENIED",
        text: "Case Denied",
      },
      {
        value: "USCIS_WITHDRAWN",
        text: "Case Withdrawn",
      },
    ],
    uscisList:[],
  editor: ClassicEditor,
editorConfig: {
   toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],

},
documentUpload:{
    "child":false,
    "spouse":false,

  },
  documentsUploading:{
    "beneficiary":false,
    "spouse":false,

  },
  documentType:null,
  disabledStatus:false,
   uscisstatuslist: [
    {
      value: "USCIS_APPROVED",
      text: "Case Approved",
    },
    {
      value: "USCIS_RECEIVED_RFE",
      text: "RFE Received",
    },
    {
      value: "USCIS_DENIED",
      text: "Case Denied",
    },
    {
      value: "USCIS_WITHDRAWN",
      text: "Case Withdrawn",
    },
  ],
      documentData: [
    {
      type: "Forms, Letters and Others",
      documentUploaded: [],
    },
  ],
  documentTypes:["Original" ,"Electronic" ],
  documentModel:[],
  statusDocuments:[],
  casestatus: null,
  uscisdocument: [],
  dueDate:null,
  usciscomments: "",
  receivedDate:null,
  issuedDate:null,
  updateTrackingFormData: null,
  updateTrackingLoading: false,
  trackingErrors: "",
  filesAreuploading: false,
  editFilngFee: false,
  uploading: false,
  courierList: [],
  tracking: { documents: [], receiptNumber: null, receiptName: null },
  uscisdocument: [],
  dueDate: null,
  usciscomments: "",
  trackingdoc: [],
  issuedDate: null,
  receivedDate: null,
  dueDate: null,
  openDate: new Date().setFullYear(new Date().getFullYear()),
  startEligibleDate: new Date().setFullYear(new Date().getFullYear()),
  updateTrackingPopup: false,
  updateUSCISstatusPopup: false,
  usciscUpdateStatusError: "",
  usciscUpdating: false,
  actioncomment: "",
  paralegalformerrors: "",
  disabled_btn: false,
  loading: false,
  showPopup: false,
  comments: false,
  formerrors: {
    msg: "",
  },
  uploading: false,
  validateLcaFiles: true,
  updateLca: false,
  filedDate: null,
  certifiedDate: null,
  lcastatuses: [],
  lcaDocuments: [],
  masterSocList: [],
  lcastatusSelected: null,
  documents: [],
  showDataPicker: true,
  number: "",
  updatingLca: false,
  lcaUpdateForm: false,
}),
props: {
    dependentType:{
        type: String,
        default: null,
    },
  ACTIVITYCODE: {
    type: String,
    default: null,
  },
  petitionDetails: {
    type: Object,
    default: null,
  },
},
};
</script>
