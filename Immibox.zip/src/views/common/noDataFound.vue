<template>
<div class="nodataTemplate">
 
  <div class="wrapTpl" v-if="!cloading" > 
      <img src="@/assets/images/main/nodata_global.svg"   />
      <h3 v-if="heading">{{heading}}</h3>
      <p v-if="content">{{content}}</p>      
  </div>

</div>
</template>

<script>
export default {
    props: {
     loading:true,
     type:null,
     heading:null,
     content:null  
    },
     watch: { 
      	loading: function(newVal, oldVal) { // watch it
        }
      },
      data() {
        return {
         cloading:true
        };
    },
    mounted(){
        var _s = this;
       setTimeout(function(){

           // _s.cloading =_s.loading;
           
       },500)
      
    },
    methods: {
      updateLoading(value){
        this.cloading = value;
      
      }
    }
}
</script>

