<template>
<div id="page-login-wrap">
   <template v-if="checkTenant">
       <petitionerRegistration />
   </template>     
    <template v-else>
    <tenantRegistration />
   </template> 
</div>
</template>
<script>
import petitionerRegistration from "@/views/registration/petitionerRegistration.vue";
import tenantRegistration from "@/views/registration/tenantRegistration.vue";
export default {
    data() {
        return {
         tenantId:null
        };
    },
    mounted(){
     this.tenantId = this.$store.getters['common/getTenantId'];
    
     if(this.getTenantType ==2){         

         this.$router.push("/")
     }
    },
    components: {
        petitionerRegistration,
        tenantRegistration
    },
    computed:{
        checkTenant(){
            return this.$store.getters['common/getTenantId']?this.$store.getters['common/getTenantId']:false;

        }
    }
};
</script>
