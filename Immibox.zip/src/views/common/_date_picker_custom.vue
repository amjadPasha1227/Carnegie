
<template>
  <div
    v-click-outside="onClickOutside"
    class="grid_filters"
    :class="{ open: isOpenDateFilter }"
  >
  
    <div @click="togleDateFIlter()">
      <label>{{ filterText }}</label>
    </div>
    <div class="grid_filters_cnt" v-if="isOpenDateFilter" >
      <div class="date_picker">
        <date-range-picker
          ref="startDatePicker"
          :opens="'left'"
          :maxDate="new Date()"
          :ranges="false"
          customRangeLabel="Custom Range"
          name="picker"
          :label="'Place Holder'"
                                              @update="generateDate('Custom_date')"
          v-model="selected_createdDateRange"
        ></date-range-picker>
      </div>
      <ul>
          <li
         
          v-bind:class="{'current':tab=='All'}" 
          @click="
              tab='All';
            generateDate('All');
          "
        >
          All
        </li>
        <li
         
          v-bind:class="{'current':tab=='Today'}" 
          @click="
              tab='Today';
            generateDate('Today');
          "
        >
          Today
        </li>
        <li
         v-bind:class="{'current':tab=='This Week'}" 
          @click="
             tab='This Week';
            generateDate('This Week');
          "
        >
          This Week
        </li>
        <li
          v-bind:class="{'current':tab=='This Month'}" 
          @click="
            tab='This Month';
            generateDate('This Month');
          "
        >
          This Month
        </li>
        <li class="custom"
         v-bind:class="{'current':tab=='Custom_date'}" 
          @click="
            tab='Custom_date';
            showdp();
          "
        >
          Custom
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
import DateRangePicker from "vue2-daterange-picker";
import moment from "moment";
import vClickOutside from "v-click-outside";

export default {
     directives: {
      clickOutside: vClickOutside.directive
    },
  components: {
    DateRangePicker
  },
  props: {
    value: null,
  },
  data() {
    return {
      isOpenDateFilter: false,
      filterText: "All",
      tab:"All",
      selected_createdDateRange: [new Date(),new Date()],
    };
  },
  mounted() {},
  methods: {
      showdp(){
            var _this =this;
         //   this.$refs.startDatePicker.togglePicker(true, false);
            setTimeout(function(){
_this.$refs["startDatePicker"].togglePicker(true);
      },100)
      },
    togleDateFIlter() {
      if(this.isOpenDateFilter){
 this.isOpenDateFilter = false;

      }else{

this.isOpenDateFilter = true;
      }
      var _this =this;
      setTimeout(function(){
_this.$refs["startDatePicker"].togglePicker(true);
      },100)
      // if(this.isOpenDateFilter){
      //     document.addEventListener("click", ()=>{
      //         this.isOpenDateFilter =false;

      //     });
      // }
    },
    onClickOutside(event) {
      this.isOpenDateFilter =false;
    },
    updateDate() {
      const monthValue = this.$refs.monthPicker.value;
      const yearValue = this.$refs.yearPicker.value;
      this.$emit("input", `${monthValue}/${yearValue}`);
    },
    generateDate(type = "") {
      let startDate = moment().startOf("day").format("YYYY-MM-DD");
      let endDate = moment().endOf("day").format("YYYY-MM-DD");
      this.filterText = "Today";
      this.isOpenDateFilter = true;
      if (type == "Today") {
        this.filterText = "Today";
        startDate = moment().startOf("day").format("YYYY-MM-DD");
        endDate = moment().endOf("day").format("YYYY-MM-DD");
      } else if (type == "This Week") {
        this.filterText = "This Week";
        startDate = moment().startOf("week").format("YYYY-MM-DD");
        endDate = moment().endOf("week").format("YYYY-MM-DD");
      } else if (type == "This Month") {
        this.filterText = "This Month";
        startDate = moment().startOf("month").format("YYYY-MM-DD");
        endDate = moment().endOf("month").format("YYYY-MM-DD");
      } else if (type == "Custom_date") {
        startDate = this.selected_createdDateRange["startDate"];
        endDate = this.selected_createdDateRange["endDate"];
        startDate = moment(startDate).format("YYYY-MM-DD");
        endDate = moment(endDate).format("YYYY-MM-DD");

        this.filterText = startDate + " - " + endDate;
      }

      this.isOpenDateFilter = false;
    
      var _cbdata = {startDate:startDate,endDate:endDate}
     
      if (type == "All") {
         this.filterText = "All";
        this.$emit("ondateSelection", {});
      }else{
         this.selected_createdDateRange = _cbdata
        this.$emit("ondateSelection", _cbdata);
      } 
      //this.wallFilterData["filters"]["createdDateRange"] = [];
      //this.wallFilterData["filters"]["createdDateRange"] = [startDate, endDate];
      // this.wallList();
    },
  },
};
</script>