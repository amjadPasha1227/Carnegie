<template>
   
    <form>
        <div class="form-container">

                <div class="vx-row" v-if="selectedIItem == null">
                
                <div class="vx-col pb-5" @keyup="formerrors.msg=''" @click="formerrors.msg=''"  >
                    <div class="custom-radio custom-radio_btns" >  
                              
                    <vs-radio class="mr-6"  v-model="wiseSelection" vs-value="true" @change="updateSelection()">Create Account for Beneficiary</vs-radio>
                    <vs-radio v-model="wiseSelection" vs-value="false"  @change="updateSelection()">Continue without Account</vs-radio>
                    </div> 
                </div>
                </div>
                  <div class="vx-row" @keyup="formerrors.msg=''" @click="formerrors.msg=''" >

                    <div class="vx-col w-1/2">
                      <div class="form_group">
                        <label class="form_label">First Name<em>*</em></label>
                        <vs-input
                          v-model="beneficiary.firstName"
                          name="beneficiaryname"
                          data-vv-as="First Name"
                          v-validate="'required'"
                          class="w-full" />
                        <span
                          class="text-danger text-sm"
                          v-show="errors.has('beneficiaryname')"
                        >{{ errors.first("beneficiaryname") }}</span>
                      </div>
                    </div>
                    <div class="vx-col w-1/2">
                      <div class="form_group">
                        <label class="form_label">Last Name<em>*</em></label>
                        <vs-input
                          v-model="beneficiary.lastName"
                          name="beneficiarylastname"
                          data-vv-as="Last Name"
                          v-validate="'required'"
                          class="w-full" />
                        <span
                          class="text-danger text-sm"
                          v-show="errors.has('beneficiarylastname')"
                        >{{ errors.first("beneficiarylastname") }}</span>
                      </div>
                  
                    </div>
                    <template v-if="!anonymousUser" >
                    <div class="vx-col w-1/2">
                      <div class="form_group">
                        <label class="form_label">Email<em v-if="!anonymousUser">*</em></label>
                        <vs-input
                          class="w-full"
                          name="beneficiaryemail"
                          v-model="beneficiary.email"
                          data-vv-as="Email"
                          v-validate="{'required':!anonymousUser ,'email':true}"
                        />
                        <span
                          class="text-danger text-sm"
                          v-show="errors.has('beneficiaryemail')"
                        >{{ errors.first("beneficiaryemail") }}</span>
                      </div>
                    </div>
                 
                    <!-- <immiPhone :fieldsArray="['cell_phone_number']" :display="true" @updatephoneCountryCode="updatecellPhoneCountryCode" :countrycode="checkProperty(beneficiary ,'phoneCountryCode' ,'countryCode')" cid="bencellPhoneNumber"   v-model="beneficiary.phone"  :required="true" fieldName="cell_phone_number" label="Phone Number" placeHolder="Phone Number" /> -->
                        
                  
                    <div class="vx-col w-1/2">
                      <div class="form_group ph_number">
                        <label class="form_label">Phone Number<em v-if="!anonymousUser">*</em></label>
                        <div class="vs-component">                  
                          <VuePhoneNumberInput
                              icon-pack="feather"
                              class="w-full no-icon-border"
                              :no-example="false"
                              v-validate="{'required':!anonymousUser}"
                                key="phone"
                                v-bind="vuePhone.props"
                              data-vv-as="Phone Number"
                              name="phone"
                              :default-country-code="checkProperty(beneficiary['phoneCountryCode'] ,'countryCode')"
                              placeholder="Phone Number"
                              :no-country-selector="false"
                            v-model="beneficiary.phone" 
                              @update="updatePhone"
                              :preferred-countries="['US', 'IN']"
                              />
                          <span class="text-danger text-sm"   v-show="!isPhoneValid && !errors.has('phone')" >*Invalid phone number - Please enter a valid one</span>
            
                          <span class="text-danger text-sm"  v-show="errors.has('phone')">{{ errors.first("phone") }}</span>

                        

                        </div>
                      </div>
                    </div>
                    </template>

                    <template v-if="([3,4].indexOf(getUserRoleId)>-1 && getTenantTypeId !=2 ) && selectedIItem == null"> 
                          <div class="vx-col w-full">
                            <div class="form_group">
                              <div class="con-select w-full select-large">
                              <label class="form_label">Select Petitioner</label>
                                <multiselect
                                  v-model="selectedPetitioner"
                                  :options="petitionersList"
                                  :multiple="false" 
                                  :hideSelected="false"
                                  :close-on-select="true"
                                  :clear-on-select="false"
                                  :preserve-search="true"
                                  :select-label="'Search Petitioner'"
                                  placeholder="Select Petitioner"
                                  label="name"
                                  track-by="name"
                                  :preselect-first="false"
                                  name="Petitioner"
                                   data-vv-as="Petitioner"
                                   v-validate="'required'"
                                     tag-placeholder="Invite Petitioner"
                                  
                                  :searchable="true"
                                   @search-change="searchPet" 
                                
                                  >
                                
                                  <template slot="selection" slot-scope="{ values, isOpen }">
                                    <span
                                    class="multiselect__selectcustom"
                                    v-if="values.length && !isOpen"
                                    >{{ values.length }} options selected</span
                                    >
                                    <span
                                    class="multiselect__selectcustom"
                                    v-if="values.length && isOpen"
                                    ></span>
                                  </template>
                                </multiselect>
                              </div>
                              <span class="text-danger text-sm"  v-show="errors.has('Petitioner')">{{ errors.first("Petitioner") }}</span>
                            
                            </div> 
                            <p class="createnew">Not found?<span  @click="addNewPet()">Invite Customer</span> </p> 
                            
                          </div>

                    </template>
                   
               
                  
                  </div>
                  <div class="text-danger text-sm formerrors" v-show="formerrors.msg">
                          <vs-alert
                            color="warning"
                            class="warning-alert reg-warning-alert no-border-radius"
                            icon-pack="IntakePortal"
                            icon="IP-information-button"
                            active="true"
                          >{{ formerrors.msg }}</vs-alert>
                    </div> 
        </div>
        <div class="popup-footer">
        <vs-button color="dark" @click="selectedBeneficiary =null;closeAddBenPopUp();AddBeneficiary=false ;saveBenbtn=false" class="cancel" type="filled">Cancel</vs-button>
        <vs-button color="success" :disabled="saveBenbtn" @click="savebeneficiary" class="save" type="filled">Submit</vs-button>
        </div>

    </form>
  
</template>


<script>


import Datepicker from "vuejs-datepicker-inv";

import DateRangePicker from "vue2-daterange-picker";
import "vue2-daterange-picker/dist/vue2-daterange-picker.css";
import moment from 'moment'
import PhoneMaskInput from "vue-phone-mask-input";
import * as _ from "lodash";
import VuePhoneNumberInput from 'vue-phone-number-input';
import 'vue-phone-number-input/dist/vue-phone-number-input.css';  

import immiPhone from "@/views/forms/fields/phonenumber.vue";

export default {
  provide() {
        return {
            parentValidator: this.$validator,
        };
    },

  components: {
    immiPhone,
    VuePhoneNumberInput,
    Datepicker,
    DateRangePicker,
    moment,
    PhoneMaskInput
  },
  data: () => ({
    anonymousUser:false,
    wiseSelection:'true',
    selectedBeneficiary:null,
    count:0,
    vuePhone:{
        props:{
          translations:{
            phoneNumberLabel:"Phone Number"
          }
        }

      },

    formerrors: {
      msg: ""
    },
    beneficiary: {
      name: "",
      email: "",
      phone:"",
      phoneCountryCode :{countryCode:'',countryCallingCode:''}
    },
    saveBenbtn:false,
    AddBeneficiary:false,
    isPhoneValid:true,
    selectedPetitioner:null,
    petitionersList:[], 

       
  }),
  props: {
    petitioner:null,
    selectedIItem:{
      type:Object,
      default:null
    }
   
  },
  methods:{
    updatecellPhoneCountryCode(data){
      this.beneficiary['phoneCountryCode'] =data
    },
    updateSelection(){
     
      if(this.wiseSelection=='true'){
        this.anonymousUser = false;
   

      }else{
         this.anonymousUser = true;
         this.beneficiary.email='';
        this.beneficiary.phone =''
        this.beneficiary.phoneCountryCode = {countryCode:'',countryCallingCode:''};
      }
     
    // this.resetForm();
    },
    setPetDetails(selectedPetitioner=null){
      
      this.selectedPetitioner =selectedPetitioner
    },
    addNewBeneficiary(){
      this.selectedPetitioner=null;
      this.beneficiary = {
      firstName:'',
      lastName:'',  
      name: "",
      email: "",
      phone:"",
      phoneCountryCode :{countryCode:'',countryCallingCode:''}
    }
    Object.assign(this.formerrors, {
                  msg: ''  });
   
    this.AddBeneficiary = true;
   this.$validator.reset();
   this.isPhoneValid =true;
   this.saveBenbtn =false;
  

    },
    updatePhone(item) {
         
       this.isPhoneValid =true;
       
      if (item.isValid  ) {
        
       this.beneficiary.phoneCountryCode = {countryCode:item.countryCode,countryCallingCode:item.countryCallingCode};
       this.beneficiary.phone = item.nationalNumber;
       
      }else{
        if(this.count>5)
          this.isPhoneValid =false;
      }
      this.count++;
    },
    savebeneficiary() {
      this.$validator.validateAll().then(result => {

        this.saveBenbtn =false;
        if (result) {
          let self =this;
          this.beneficiary = Object.assign(this.beneficiary,{"roleId":51});
          this.beneficiary['name'] =  this.beneficiary['firstName'].trim()+" "+this.beneficiary['lastName'].trim();
          this.beneficiary['firstName'] =  this.beneficiary['firstName'].trim();
          this.beneficiary['lastName'] =  this.beneficiary['lastName'].trim();
          this.beneficiary['name'] =  this.beneficiary['name'].trim();
          this.saveBenbtn =true;
          let postData = this.beneficiary;
          if(this.checkProperty(this.selectedIItem,'_id')){
            postData['userId']= this.checkProperty(this.selectedIItem,'_id')
            postData['accountType'] =  "Individual"
          }
          if(this.selectedIItem == null){
            if(self.selectedPetitioner && _.has(self.selectedPetitioner ,"_id")){
                postData = Object.assign(postData,{ "companyId": self.selectedPetitioner['_id']})
            }
          }
          let path= "/users/register"
          if(this.checkProperty(this.selectedIItem,'_id')){
            path= "/users/invite-temp-user-to-individual"
          }

          this.$store
            .dispatch("commonAction", {"data":postData ,"path":path})
            .then(response => {
              this.saveBenbtn =false;
              if (response.error) {
             
                Object.assign(this.formerrors, {
                  msg: response.error.message
                });
              } else {
               
                this.AddBeneficiary =false;
                this.selectedBeneficiary =response
                this.showToster({message:response.message,isError:false });
                this.closeAddBenPopUp();
              }

              // this.$router.go('/beneficiaries');
            })
            .catch((err)=>{
              
              this.saveBenbtn =false;
                //this.showToster({message:err,isError:true })
                Object.assign(this.formerrors, {
                  msg: err
                });

            });
        }
      });
    },
    searchPet(searchText){
        let _self =this;
    
    this.enableAddNewpet =false;
    let filteredData =[];
    _.forEach(_self.petitionersList ,(item)=>{
            if( item && ( _.has(item ,'name') || _.has(item ,'email')  )){

                        if((_.has(item ,'name') && item['name'].includes(searchText)) || (_.has(item ,'email') && item['email'].includes(searchText)) ){
                        filteredData.push(item)
                        }else{
                        return false;
                        }

            }else{
                return false;
            }
            
        
        })
    if( filteredData.length<=0 || !searchText  ){

        //this.enableAddNewpet =true;
    // this   this.addNewPete = true;
        this.getPetitioners( true , searchText);
    }
        
    },
    getPetitioners(callFromSerch=false,searchText='' ) {
      
         let _self =this;
         let query ={
          "matcher":{
            "searchString": searchText,
            "statusIds": [],
            "countryIds": [],
            "stateIds": [],
            "locationIds": [],
            "createdDateRange": []
          },
        "sorting": { 	"path": "createdOn", 	"order": 1 	},
        "page": 1,
        "perpage": 25,
        getMasterData:true
	}
       
      
        this.$store.dispatch("getList",{data:query ,path:'/company/list'} ).then(response => {
            
            _self.petitionersList = response.list;

        }).catch((err)=>{
            this.petitionersList =[];
           
        })
    },
    addNewPet(){
       this.$emit("openAddpetPopUp" );
    },
    closeAddBenPopUp(){
      let self =this;
      if(this.checkProperty(this.selectedBeneficiary ,"_id")){
       
        this.selectedBeneficiary = Object.assign(this.selectedBeneficiary ,{"anonymousUser": self.anonymousUser});

      }
        this.$emit("closeAddBenPopUp" ,this.selectedBeneficiary);
    },
  },
  mounted() {
    if(this.selectedIItem != null){
      setTimeout(()=>{
      if(this.checkProperty(this.selectedIItem,'firstName') ){
        this.beneficiary.firstName = this.checkProperty(this.selectedIItem,'firstName')
      }
      if(this.checkProperty(this.selectedIItem,'lastName')){
        this.beneficiary.lastName = this.checkProperty(this.selectedIItem,'lastName')
      }
      // if(this.checkProperty(this.selectedIItem,'email')){
      //   this.beneficiary.email = this.checkProperty(this.selectedIItem,'email')
      // }
      if(this.checkProperty(this.selectedIItem,'phone')){
        this.beneficiary.phone = this.checkProperty(this.selectedIItem,'phone')
      }
      if(this.checkProperty(this.selectedIItem,'phoneCountryCode','countryCode')){
        this.beneficiary['phoneCountryCode'].countryCode = this.checkProperty(this.selectedIItem,'phoneCountryCode','countryCode')
      }
      if(this.checkProperty(this.selectedIItem,'phoneCountryCode','countryCallingCode')){
        this.beneficiary['phoneCountryCode'].countryCallingCode = this.checkProperty(this.selectedIItem,'phoneCountryCode','countryCallingCode')
      }
      if(this.checkProperty(this.selectedIItem,'petitions') || this.checkProperty(this.selectedIItem,'perms')){
        let beneficiaryEmailList = []
        let beneficiaryemail = ''
        _.forEach(this.selectedIItem['petitions'],(item)=>{
          if(_.has(item,'email')){
            beneficiaryEmailList.push(item)
          }
        })
        _.forEach(this.selectedIItem['petitions'],(item)=>{
          if(_.has(item,'email')){
            beneficiaryEmailList.push(item)
          }
        })
        if(this.checkProperty(beneficiaryEmailList,'length')){
          //alert(beneficiaryEmailList)
          beneficiaryEmailList= _.orderBy(beneficiaryEmailList, 'updatedOn' ,'desc');
          _.forEach(beneficiaryEmailList,(item)=>{
            beneficiaryemail = item.email
            return false;
          })
          if(beneficiaryemail != ''){
            this.beneficiary.email = beneficiaryemail
          }
        }
      }
    },10)
    }
    this.selectedBeneficiary =null;
    this.addNewBeneficiary();
    this.getPetitioners();
    this.selectedPetitioner =this.petitioner;
    this.AddBeneficiary =true;
    this.count =0;
        
  }
};
</script>