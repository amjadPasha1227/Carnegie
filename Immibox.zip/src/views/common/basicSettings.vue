<template>
  <div id="page-login-wrap">
    <template v-if="[1, 2, 3, 4].indexOf(roleId) > -1">
      <profileSttings />
    </template>
    <template v-if="roleId == 50">
      <petitionerProfile />
    </template>
  </div>
</template>
<script>
import petitionerProfile from "@/views/petitioner/editProfile.vue";
import profileSttings from "@/views/tenant/profileSettings.vue";
export default {
  data() {
    return {
      roleId: null,
    };
  },
  mounted() {
    this.roleId = this.$store.getters.getuser.loginRoleId;
   // this.$store.dispatch("updateSidebarWidth", "extended");
  },
  components: {
    petitionerProfile,
    profileSttings,
  },
};
</script>
