<template>
  <span  v-show="showMe">

    
<actionsPopup @caseNumberAssigned="caseNumberAssigned" @updatepetition="updatepetition" :workFlowDetails="workFlowDetails" :formsAndLetters="formsAndLettersList" :lcaDetails="lcaDetails" ref="actionsPopup" :petitionDetails="petitionDetails" />

<vs-popup class="holamundo main-popup" :title="'Change LCA'" :active.sync="showConformTocangeLca">
      <!-- (checkProperty(selectedUser,'statusId') ==2?'Inactivate ':' Activate')+' User' -->
      <div class="form-container">

        <div class="vx-row">
          <div class="vx-col w-full">
            <p>Support Letter(s) are already generated. Changing LCA now will require regeneration of the Support Letter(s).</p>
            <p v-if="false">Support Letter(s) are already generated. Changing the LCA requires generate the Support Letter(s) again.</p>
          </div>

        </div>

        

      </div>
      <div class="popup-footer">
        <vs-button color="dark" class="cancel" type="filled" @click="showConformTocangeLca = false">Cancel </vs-button>
        
        <vs-button  color="success" class="save" :disabled="loading" type="filled"  @click="showConformTocangeLca=false;$refs['actionsPopup'].openLinkLCA();">
          Ok
        </vs-button>
      </div>
</vs-popup>


<vs-popup class="holamundo main-popup  confirm_modal"  title="Edit Or Suggest Job Description" :active.sync="suggestOrEditJobDescription">
      <div class="form-container">
        
        <div class="vx-row">
          <div class="vx-col w-full text-center">
          <p>Do you want to edit job description </p>
            OR
          <p>Do you want to suggest job description </p>
            
          </div>
          
        </div>

        <!------this.$refs["actionsPopup"].openPermJobDescActionsModal('JOB_DESC_SUGGESSION');
          this.$refs["actionsPopup"].openJobDescription('JOB_DESC_SUGGESSION'); suggestJobDesc-->

       
       
      </div>
      <div class="popup-footer relative">
          <vs-button color="dark" @click="suggestOrEditJobDescription=false"    class="cancel" type="filled">Cancel</vs-button>
          <vs-button  color="success" @click="suggestOrEditJobDescription=false; suggestJobDesc(false)"  class="save"  type="filled"> Suggest</vs-button>
        
          <vs-button  color="success" @click="suggestOrEditJobDescription=false; suggestJobDesc(true)"  class="save"  type="filled"> Edit</vs-button>
        
        </div>
</vs-popup>

<vs-popup class="holamundo main-popup  confirm_modal"  
:title="( checkProperty(petitionDetails,'typeDetails','id')==3 && checkProperty(petitionDetails,'subTypeDetails','id')==15)?'Prepare PERM Draft at DOL (E-File)':' Submitted to USCIS'"
 :active.sync="checkAdvValidation">
      <div class="form-container">
        <!---Review and Finalize PERM Questionnaire---->
        
        <div class="vx-row">
          <div class="vx-col w-full text-center">
          
          <!-- <div class="primary-alert"> v-if="preparePermInvoiceError">{{preparePermInvoiceError}} </div> -->
          <vs-alert class="primary-alert mb-4" v-if="preparePermInvoiceError">{{preparePermInvoiceError}}</vs-alert>
          <vs-alert class="primary-alert mb-1" v-if="checkAdvValidationMsg">{{checkAdvValidationMsg}}</vs-alert>
            
          </div>
          
        </div>

              
       
      </div>
      <div class="popup-footer relative">
        <span class="loader" v-if="gettingInvoiceStatus"><img src="@/assets/images/main/loader.gif"></span>
        <template v-if=" ( checkProperty(petitionDetails,'typeDetails','id')==3 && checkProperty(petitionDetails,'subTypeDetails','id')==15)">
          <template v-if="!preparePermInvoiceError">
            <template v-if="preparePermApplicationActivity && checkProperty(preparePermApplicationActivity ,'restrictPermDraftByAdvConfig') !='Yes'" >
            <vs-button color="dark" @click="checkAdvValidation=false"    class="cancel" type="filled">Cancel</vs-button>
            <vs-button  color="success" @click="checkAdvValidation=false;checkAdvValidation=false; checkAdvValidation=false; efilePermApplicationRestriction()"  class="save"  type="filled"> Proceed</vs-button>
            </template>
            <template v-else>
              <vs-button color="dark" @click="checkAdvValidation=false"    class="cancel" type="filled">Cancel</vs-button>
            </template>

          </template>
          <template v-else>
            <template v-if="preparePermInvoiceError || (enableAccountantApprovalRequest || enableAccountantApprovalGrant )">
              <template v-if="(enableAccountantApprovalRequest || enableAccountantApprovalGrant)">
                <vs-button  v-if="enableAccountantApprovalRequest"  color="success"  @click="checkAdvValidation=false;checkAdvValidation=false;checkAdvValidation=false;$refs['actionsPopup'].openPermJobDescActionsModal('ACCOUNTANT_APPORVAL_REQUEST')"  class="save"  type="filled"> Request for Payment Approval</vs-button>
                <vs-button  v-else-if="enableAccountantApprovalGrant"  color="success"  @click="checkAdvValidation=false;checkAdvValidation=false;checkAdvValidation=false;$refs['actionsPopup'].openPermJobDescActionsModal('ACCOUNTANT_APPORVAL_GRANT')"  class="save"  type="filled">Approve Payment</vs-button>
            </template>
              <template v-else>
                <vs-button  v-if="checkProperty(petitionDetails ,'invoiceId' ) && ( canFilingFee || adminsList.indexOf(getUserRoleId) > -1) && enableFilingFee"  color="success" @click="checkAdvValidation=false;checkAdvValidation=false;$refs['actionsPopup'].openaddPaymentPopup('ADD_PAYMENT')"  class="save"  type="filled"> Complete Payment</vs-button>
              <vs-button  v-else-if=" preparePermApplicationActivity && checkProperty(preparePermApplicationActivity ,'restrictPermDraftByAdvConfig') =='Yes' || preparePermInvoiceError"  color="success" @click="checkAdvValidation=false;checkAdvValidation=false;$route['params']['tabname'] ='Fees/Invoices';$emit('updatepetition', 'Fees/Invoices')"  class="save"  type="filled"> Ok</vs-button>
              <vs-button  v-else  color="success" @click="checkAdvValidation=false"  class="save"  type="filled"> Ok</vs-button>   
              </template>
            </template>
            <template v-else>
            
            <vs-button  v-if="preparePermApplicationActivity && checkProperty(preparePermApplicationActivity ,'restrictPermDraftByAdvConfig') =='Yes' || preparePermInvoiceError"  color="success" @click="checkAdvValidation=false"  class="save"  type="filled"> Ok</vs-button>
          </template>
          </template>
        </template>
        <template v-else>

          <vs-button  color="success" @click="checkAdvValidation=false;checkAdvValidation=false;$route['params']['tabname'] ='Fees/Invoices';$emit('updatepetition', 'Fees/Invoices')"  class="save"  type="filled"> Ok</vs-button>

        </template> 
        </div>
</vs-popup>
<vs-popup class="holamundo main-popup  confirm_modal"  title="Update Evidence of Advertisements" :active.sync="showPermInfo">
      <div class="form-container">
        <div class="vx-row">
          <div class="vx-col w-full text-center">
          
          <vs-alert class="primary-alert mb-1" style="height: auto;">The changes you make will not apply to draft application in DOL website. Please make sure to apply these changes in DOL portal manually.</vs-alert>
          
            
          </div>
          
        </div>

              
       
      </div>
      <div class="popup-footer relative">
       
        <template >
               
          <vs-button  color="success" @click="showPermInfo=false;showPermInfo=false;showPermInfo=false;$refs['actionsPopup'].openPermAdvrtisementModal()"  class="save"  type="filled"> Ok</vs-button>
        </template> 
        </div>
</vs-popup>


<vs-popup class="holamundo main-popup  confirm_modal" v-if="createRfeCase"  title="Create RFE Case" :active.sync="createRfeCase">
      <div class="form-container">
        <div class="vx-row">
          <div class="vx-col w-full text-center">
          
          <vs-alert class="primary-alert mb-1" style="height: auto;">Are you sure to Create RFE Case?</vs-alert>
          
            
          </div>
          
          
        </div>

              
       
      </div>
      <div @click="createRfeError=''" class="text-danger text-sm formerrors" v-if="createRfeError" >
                          <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ createRfeError }}</vs-alert>
                </div>
      <div class="popup-footer relative">
       
        <template >
          <span class="loader" v-if="creatingrfeCase"><img src="@/assets/images/main/loader.gif"></span>
           <vs-button color="dark" @click="createRfeError='';createRfeCase=false ;creatingrfeCase=false"    class="cancel" type="filled">Cancel</vs-button>
          <vs-button  color="success" @click="createRfeCaseAction()"  class="save"  type="filled"> Create</vs-button>
        </template> 
        </div>
</vs-popup>

    <template v-if="checkNoNotifyUserIds && ((checkProperty(petitionDetails,'intStatusDetails','id')==1 || ([2,3].indexOf(checkProperty(petitionDetails,'intStatusDetails','id') )>-1 && adminsList.indexOf(getUserRoleId) > -1 )) && (checkActionButton ||  checkUserAccessBtn))">
    <button class="actions_btn actions_btn_v2" >Actions</button>
    <div class="menu_list_wrap menu_v2"  :class="{'ben_action_menu':getUserRoleId ==51 }"   >
      <VuePerfectScrollbar>
        <div class="menu_list" v-if="loaded && workFlowDetails && workFlowDetails.config ">
          <template  v-for="(menuItem, index) in menuItems">
           
            <template v-if="checkProperty(petitionDetails,'intStatusDetails','id')==1 || ([2,3].indexOf(checkProperty(petitionDetails,'intStatusDetails','id') )>-1 && adminsList.indexOf(getUserRoleId) > -1 && 'UPDATE_INTERNAL_STATUS'== menuItem['code'] )" >
              <div v-if="checkActionRequired(menuItem,index)" @click="triggerAction(menuItem)" class="menu_item drop_menu_items" :key="index" :itemCode="menuItem['code']">
                <!--  :title="getAssignmentText(menuItem['code'])" || :title="menuItem.actionLable" ||  :title="menuItem.actionLable"-->
                
                <a  v-if="menuItem['code'] =='ASSIGN_CASE_APPROVER'" ><template v-if="checkProperty(petitionDetails,'typeDetails','id')==3 && [16,17].indexOf(checkProperty(petitionDetails ,'subTypeDetails','id' ) )>-1">Paralegal Review</template> <template v-else>{{  menuItem.actionLable }}</template></a>
              <a  v-else-if="assignmentActivityList.indexOf(menuItem['code'])>-1" >
                
                  <template>{{ getAssignmentText(menuItem['code'] , menuItem.actionLable )  }}</template>
                </a>
                <a  v-else-if="'UPDATE_PWD_RESPONSE_WITH_JD'==menuItem['code']" >
                <template v-if="checkProperty( petitionDetails ,'pwdStatus')=='Filed'">Update PWD Response</template>
                  <template v-else>{{menuItem.actionLable}}</template>
                </a>
                <a  v-else-if="'LINK_PERM'==menuItem['code']" >
                <template v-if="checkProperty( petitionDetails ,'permId')">Change PERM</template>
                  <template v-else>{{menuItem.actionLable}}</template>
                </a>
                <a  v-else-if="'LINK_140'==menuItem['code']" >
                <template v-if="checkProperty( petitionDetails ,'i140Id')">Change I-140</template>
                  <template v-else>{{menuItem.actionLable}}</template>
                </a>
                <a  v-else-if="'LINK_LCA'==menuItem['code']" >
                <template v-if="checkProperty( petitionDetails ,'lcaId')">Change LCA</template>
                  <template v-else>{{menuItem.actionLable}}</template>
                </a>
                <a  v-else-if="'LINK_PWD'==menuItem['code']" >
                <template v-if="checkProperty( petitionDetails ,'pwdLinked') || checkProperty( petitionDetails ,'pwdId')">Change PWD</template>
                  <template v-else>{{menuItem.actionLable}}</template>
                </a>
                <a  v-else-if="'CASE_APPROVED'==menuItem['code'] && checkProperty(petitionDetails, 'type')==9"><template>Approve Response Docs</template></a>
                <a  v-else-if="'RFE_REQUEST_PETITIONER_SIGN'==menuItem['code'] && getTenantTypeId != 2"><template>Send for Petitioner Signature</template></a>
                <a  v-else >{{ menuItem.actionLable }}</a>
              </div>
          </template>
          </template>
        </div>
      </VuePerfectScrollbar>
    </div>
  </template>
  </span>
</template>

<script>
import actionsPopup from "./actionsPopup.vue";
import * as _ from "lodash";

import moment from "moment";
import VuePerfectScrollbar from "vue-perfect-scrollbar";
export default {
  components: {
    actionsPopup,
    VuePerfectScrollbar
  },
  props: {
    isLcaRequiredForPetition: {
      type:Boolean,
      default:false
    },
    workFlowDetails: {
      type: Object,
      default: null,
    },
    petitionDetails: {
      type: Object,
      default: null,
    },
    lcaDetails: {
      type: Object,
      default: null,
    },
    hideMe: {
      type: Boolean,
      default: false,
    },
    formsAndLetters: {
      type: Array,
      default: null,
    },
  },
  methods: {
    createRfeCaseAction(){
      var postdata ={
        type: 9,
        userId:this.checkProperty(this.petitionDetails,'beneficiaryDetails', '_id'),
        userName:this.checkProperty(this.petitionDetails,'beneficiaryDetails', 'name'),
        typeName:'RFE',
        subType:26,
        subTypeName:'H1B RFE',
        petitionerId:this.checkProperty(this.petitionDetails,'petitionerDetails', '_id'),
        premiumProcessing:false,
        branchId:this.checkProperty(this.petitionDetails,'branchId'),
        rfeIntExtOption:'internal',
        h1bCaseId:this.checkProperty(this.petitionDetails,'_id'),
        today: moment().format('YYYY-MM-DD')
      };
      this.creatingrfeCase =true;
      this.createRfeError ='';
      this.$store.dispatch("petitioner/createnewpetition", postdata).then((response)=>{
       
        this.showToster({message:response.message ,isError:false});
        this.createRfeCase = false;
        this.createRfeCase = false;
        this.creatingrfeCase =false;
        let caseId = this.checkProperty(response, '_id')
        setTimeout(()=>{
          this.createRfeCase = false;
        this.createRfeCase = false;
        this.creatingrfeCase =false;
          this.$router.push({ name: 'petition-details', params: { itemId:caseId } ,query: {'filter':''} }).catch(err => {});
        })
        
        //this.$emit("updatepetition", "Petition Updates");
        
      }).catch((err)=>{
        this.creatingrfeCase =false;
        this.createRfeError =err.message;
       // this.showToster({message:err.message,isError:true});
      })
    },
   
    getScannedCopyList(docUserType='') {
      if(docUserType=='Petitioner'){
        this.petitionerScannedCopyList = [];
      }else if(docUserType=='Beneficiary'){
        this.beneficiaryScannedCopyList = [];
      }else{
        this.scannedCopyList =[];
      }
           
            let finalList = [];
           
            let postData ={
                petitionId:'',
                'page':1 ,
                'perpage':100000,
                matcher: { 
                    docUserTypeList: []
                }
            };
            postData['petitionId']= this.petitionDetails._id; 
            //postData['petitionId']= '63a55489e973d734f8d74387'; 
            if(docUserType){
                postData['matcher']['docUserTypeList'] = [docUserType]
            }
           
            this.$store
                .dispatch("getList", {
                data: postData,
                path: "/petition/scanned-copies-list",
                })
                .then((response) => {
                let lst = [];

                _.forEach(response.list, (mainItem) => {
                    mainItem = Object.assign(mainItem, {
                    reverse_document_versions: [],
                    mainParentId: "",
                    showMe: true,
                    selectedForDownload: false,
                    "viewmode":true,
                    });
                    if (mainItem.parentId) {
                    mainItem["mainParentId"] = mainItem["parentId"];
                    } else {
                    mainItem["mainParentId"] = mainItem["_id"];
                    }

                    lst.push(mainItem);
                });
                let subList = [];

                //reverse_document_versions
                _.forEach(lst, (mainItem) => {
                    if (this.checkProperty(mainItem, "depType") != "child") {
                    _.forEach(lst, (subItem) => {
                        if (
                        mainItem.parentId &&
                        (mainItem.parentId == subItem["parentId"] ||
                            mainItem.parentId == subItem["_id"]) &&
                        mainItem["_id"] != subItem["_id"]
                        ) {
                        subItem["showMe"] = false;
                        if (subList.indexOf(subItem["_id"]) <= -1) {
                            mainItem["reverse_document_versions"].push(subItem);
                           
                            subList.push(subItem["_id"]);
                        }

                        // mainItem['showMe'] =true;
                        }
                    });

                    if (mainItem.showMe) {
                        finalList.push(_.cloneDeep(mainItem));
                    }
                    } else {
                    _.forEach(lst, (subItem) => {
                        if (
                        this.checkProperty(mainItem, "depType") ==
                            this.checkProperty(subItem, "depType") &&
                        this.checkProperty(mainItem, "depLabel") ==
                            this.checkProperty(subItem, "depLabel") &&
                        mainItem.parentId &&
                        (mainItem.parentId == subItem["parentId"] ||
                            mainItem.parentId == subItem["_id"]) &&
                        mainItem["_id"] != subItem["_id"]
                        ) {
                        subItem["showMe"] = false;
                        if (subList.indexOf(subItem["_id"]) <= -1) {
                            mainItem["reverse_document_versions"].push(subItem);
                            
                            subList.push(subItem["_id"]);
                        }

                        // mainItem['showMe'] =true;
                        }
                    });

                    if (mainItem.showMe) {
                        finalList.push(_.cloneDeep(mainItem));
                    }
                    }
                });

                if(docUserType=='Petitioner'){
                this.petitionerScannedCopyList = finalList;
                }else if(docUserType=='Beneficiary'){
                this.beneficiaryScannedCopyList = finalList;
                }else{
                     this.scannedCopyList =finalList;
               }
                

                
                })
                .catch((err) => {
                  
                      if(docUserType=='Petitioner'){
                        this.petitionerScannedCopyList = [];
                      }else if(docUserType=='Beneficiary'){
                        this.beneficiaryScannedCopyList = [];
                      }else{
                        this.scannedCopyList =[];
                      }
                    });
        },
    getListcat(){
      this.invoiceNotification ='';
      this.removedInvoiceItems =[];
      this.newlyAddInvoiceItems =[];
      let self = this;
      let payload={  petitionId:'' }
    
      payload['petitionId'] = this.petitionDetails['_id']
      self.$store.dispatch("getList",{data:payload ,path:'/invoices/get-filing-fee-categories'} )
      .then((response) => {
        self.invoicecategoryList = response;


        if(this.checkProperty(this.petitionDetails ,'invoiceId')  && this.checkProperty(this.petitionDetails ,'filingFeeCategoryType') =="pre_defined" && this.invoicecategoryList.length>0){
         let filingFeeData = _.cloneDeep(this.petitionDetails.filingFeeDetails.feeDetails);
         //descriptionId
         let finalItems =[];
         _.forEach(filingFeeData ,(dbInvoice)=>{
            let isExistsInML = _.find(this.invoicecategoryList ,{ "id": dbInvoice['descriptionId']});
            if(isExistsInML){
              finalItems.push(dbInvoice);
            }else{
              this.removedInvoiceItems.push(dbInvoice);
            }

         })
         _.forEach(this.invoicecategoryList ,(invCat)=>{
            let isExistsInML = _.find(filingFeeData ,{ "descriptionId": invCat['id']});
            let isAlreadyExists  = _.find(finalItems ,{ "descriptionId": invCat['id']});

            if(!isExistsInML && !isAlreadyExists){

            let item = {  amount: null, description: "",  invoice: false,"descriptionId":''  };

            item['description'] = this.checkProperty(invCat ,"name");
            item['amount'] = this.checkProperty(invCat ,"amount");
            item['descriptionId'] = this.checkProperty(invCat ,"id");
            item['descriptionType'] = this.checkProperty(invCat,"type");
            item['newly_add'] = true;
            finalItems.push(item);
            }

         })
         /*
         this.totalInvoiceAmountPaid
         this.partlyPaidAmountt
         this.totalDueAmount
         */


        
      //this.totalPaidAmount;
      let newlyAddedfeeItems = _.filter(finalItems,{'newly_add':true} );
     
     if(newlyAddedfeeItems && this.checkProperty(newlyAddedfeeItems ,'length' )>0 ){
      this.newlyAddInvoiceItems = _.cloneDeep(newlyAddedfeeItems);
      let allItemsDescription = [];
    _.forEach(newlyAddedfeeItems ,(item)=>{
      if(self.checkProperty(item ,'description' )){
            allItemsDescription.push(item.description)
          }
          if(allItemsDescription.length>0){
            self.invoiceNotification =allItemsDescription.join();
          }
        });

        let totalInvoiceAmount = 0
      
        finalItems.forEach(item => {
          if(!item.invoice){
            totalInvoiceAmount += parseInt(item.amount);

          }
          
        });
       // alert("totalInvoiceAmount ="+totalInvoiceAmount +" old totalInvoiceAmount ="+self.partlyPaidAmountt);
        // if(totalInvoiceAmount> self.totalInvoiceAmountPaid){
        // }


      }
     
         

        }

          
              
      }).catch((err)=>{
        
      });
    
    },
    caseNumberAssigned(){
     this.caseNumberIsUpdated = true;
    },

    checkInvoiceForSubmitUscis(menuItem){
      //this.enableFilingFee = false; this.filingEditors //fileAfterInvoice this.fileAfterPayment
      if(this.enableFilingFee){
       
       this.checkInvoiceFroPreparePerm(menuItem);
       
      }else{
        this.getRoleslist(menuItem.code);
        this.$refs["actionsPopup"].openassignActivityPopup(this.rolesList,menuItem.popUpTitle,menuItem.popUpTitle.replace("Assign ",''),menuItem.code);
    
      }
      
      
    },
    showPermInfoPopup(){
      //
     
      if(this.petitionDetails.completedActivities.indexOf('APPROVE_PERM_APPLICATION')>-1){
         this.showPermInfo =true;
      }else{
        this.$refs["actionsPopup"].openPermAdvrtisementModal();
      }
      
    },
    checkInvoiceFroPreparePerm(menuItem){
      this.gettingInvoiceStatus =true;
     this.preparePermInvoiceError='';
     let  path ="/petition/check-invoice-status";
     let postData ={
      "petitionId":null
     };

    if( this.checkProperty(this.petitionDetails,'typeDetails','id')==3 && this.checkProperty(this.petitionDetails,'subTypeDetails','id')==15){
      path ="/perm/check-invoice-status";
    } 

     postData['petitionId'] =this.petitionDetails['_id'];
    //enableFilingFee fileAfterInvoice fileAfterPayment
     if(this.enableFilingFee){
      this.$vs.loading();
     
      this.$store.dispatch("commonAction", {data:postData,path:path})
      .then((response) => { 
        
        this.gettingInvoiceStatus =false;
        this.$vs.loading.close();
        if( this.checkProperty(this.petitionDetails,'typeDetails','id')==3 && this.checkProperty(this.petitionDetails,'subTypeDetails','id')==15){
     
        this.checKPreParePermApplicationAdvRestriction();
        }else if(menuItem){
          this.getRoleslist(menuItem.code);
          this.$refs["actionsPopup"].openassignActivityPopup(this.rolesList,menuItem.popUpTitle,menuItem.popUpTitle.replace("Assign ",''),menuItem.code);
    
        }
          
      }).catch((error) => { 
       
        if(error){
          this.preparePermInvoiceError=error;
        }
        this.gettingInvoiceStatus =false;
        this.checkAdvValidation =true;
        this.$vs.loading.close();
        if( this.checkProperty(this.petitionDetails,'typeDetails','id')==3 && this.checkProperty(this.petitionDetails,'subTypeDetails','id')==15){
     
           this.checKPreParePermApplicationAdvRestriction();
        }
       
        });
      }else{
        this.gettingInvoiceStatus =false;
        this.checKPreParePermApplicationAdvRestriction();
      }
    },

    
    getFormsAndLetters(callFromMenu =false,code='') {
      this.showConformTocangeLca =false;
this.formsAndLettersList = [];
this.allFormsAndLettersList = [];
let finalList = [];

let postData = {
  petitionId: this.petitionDetails._id,
  matcher: { typeIds: ["Form" ,'Letter'] },
  page: 1,
  perpage: 100000,
};


if (
  this.checkProperty(this.petitionDetails, "typeDetails", "id") == 3 &&
  this.checkProperty(this.petitionDetails, "subTypeDetails", "id") == 15
) {
  postData["matcher"]["typeIds"] = ["Audit Response"];
  this.formLetterType = "Audit Response";
  //audit_response
}
this.updateLoading(true);
this.$store
  .dispatch("getList", {
    data: postData,
    // path:"/petition/filled-forms-and-letters-list"
    path: "/filled-forms-and-letters/list",
  })
  .then((response) => {
    
    this.allFormsAndLettersList = response.list;
    let lst = [];

          _.forEach(response.list, (mainItem) => {
            mainItem = Object.assign(mainItem, {
              reverse_document_versions: [],
              mainParentId: "",
              showMe: true,
              selectedForDownload: false,
              "viewmode":true,
            });
            if (mainItem.parentId) {
              mainItem["mainParentId"] = mainItem["parentId"];
            } else {
              mainItem["mainParentId"] = mainItem["_id"];
            }

            lst.push(mainItem);
          });
          // if(response){
          //    this.ActiveList = _.filter(response.list, (item) => {
          //     return item.statusId != 1
          //    });
          // }
          
          let subList = [];

          //reverse_document_versions
          _.forEach(lst, (mainItem) => {
            if (this.checkProperty(mainItem, "depType") != "child") {
              _.forEach(lst, (subItem) => {
                if (
                  mainItem.parentId &&
                  (mainItem.parentId == subItem["parentId"] ||
                    mainItem.parentId == subItem["_id"]) &&
                  mainItem["_id"] != subItem["_id"]
                ) {
                  subItem["showMe"] = false;
                  if (subList.indexOf(subItem["_id"]) <= -1) {
                    mainItem["reverse_document_versions"].push(subItem);
                    this.previousExisted = true;
                    subList.push(subItem["_id"]);
                 
                  }

                  // mainItem['showMe'] =true;
                }
              });

              if (mainItem.showMe) {
                finalList.push(_.cloneDeep(mainItem));
              }
            } else {
              _.forEach(lst, (subItem) => {
                if (
                  this.checkProperty(mainItem, "depType") ==
                    this.checkProperty(subItem, "depType") &&
                  this.checkProperty(mainItem, "depLabel") ==
                    this.checkProperty(subItem, "depLabel") &&
                  mainItem.parentId &&
                  (mainItem.parentId == subItem["parentId"] ||
                    mainItem.parentId == subItem["_id"]) &&
                  mainItem["_id"] != subItem["_id"]
                ) {
                  subItem["showMe"] = false;
                  if (subList.indexOf(subItem["_id"]) <= -1) {
                    mainItem["reverse_document_versions"].push(subItem);
                    this.previousExisted = true;
                    subList.push(subItem["_id"]);
                 
                  }

                  // mainItem['showMe'] =true;
                }
              });

              if (mainItem.showMe) {
                finalList.push(_.cloneDeep(mainItem));
              }
            }
          });

          this.formsAndLettersList = _.cloneDeep(finalList); // JSON.parse(JSON.stringify(finalList));
         // this.formsAndLetters =this.formsAndLettersList;

        
        if(code=='LINK_LCA'){
          let supportLetters  = _.filter(this.formsAndLettersList ,{"entityId":'support_letter'}); //forms['entityId'] =='support_letter'
          if(supportLetters && supportLetters.length>0){
            this.showConformTocangeLca =true;
            
          }else{
            
           this.$refs["actionsPopup"].openLinkLCA();
          }
         
        }
        
    
  })
  .catch((err) => {
  
    this.formsAndLettersList = [];
    if(callFromMenu && this.formsAndLettersList && this.formsAndLettersList.length == 0 || !this.checkActiveFormsAndLatters){
           this.showToster({
            message:
              "Required at least one forms and letters documents to send for signature.",
            isError: true,
          });

           this.$emit("updatepetition", "Forms and Letters");
           return false

    }
    
  });
    },
    efilePermApplicationRestriction(){
     
     let pwdResponseDueDate=null;
     let today = moment().format("YYYY-MM-DD");
     try{
      if(this.checkProperty(this.petitionDetails,'pwdResponse')){
        pwdDetails = _.cloneDeep(this.petitionDetails.pwdResponse)
        if(this.checkProperty(pwdDetails,'dueDate')){
          startDate =pwdDetails['dueDate']
          pwdResponseDueDate = moment(startDate).format("YYYY-MM-DD");
        }
      
      }
    }catch(err){

      pwdResponseDueDate=null;
    }
      if(_.has(this.petitionDetails , 'completedActivities') && this.petitionDetails['completedActivities'].indexOf('PREPARE_PERM_APPLICATION')>-1){

      let allAvertise =[];
      
      
         // startDateKey:'startDateOfAdvAtJobFair',
          //endDateKey:'endDateOfAdvAtJobFair',
      _.forEach(this.avertisementList ,(item)=>{
        let tempItem = {
          startDateVal:'',
          endDateVal:''
        }
        if(_.has(this.petitionDetails['recruitmentInfo'], item['startDateKey'] ) && this.checkProperty(this.petitionDetails['recruitmentInfo'] ,item['startDateKey'])  ){
            try{
              let startDateVal = this.petitionDetails['recruitmentInfo'][item['startDateKey']];
              tempItem['startDateVal'] =moment(startDateVal).format("YYYY-MM-DD");
             
            }catch(err){}
        }
        if(_.has(this.petitionDetails['recruitmentInfo'], item['endDateKey'] ) && this.checkProperty(this.petitionDetails['recruitmentInfo'], item['endDateKey'])  ){
            try{
              let endDateVal = this.petitionDetails['recruitmentInfo'][item['endDateKey']];
              tempItem['endDateVal'] =moment(endDateVal).format("YYYY-MM-DD");

            }catch(err){}
        }
        if(tempItem['startDateVal'] && tempItem['endDateVal'] ){
          allAvertise.push(tempItem);
        }

      });
     
      allAvertise = _.orderBy(allAvertise ,['startDateVal'] ,['asc']);
     if(this.checkProperty(allAvertise ,'length') >0){
        let lastAdverStartDate = moment(allAvertise[0]['startDateVal']);
       let dateDif = moment().diff(lastAdverStartDate, 'days') ;
      

      if(dateDif>179 || ( pwdResponseDueDate && pwdResponseDueDate !=null && ( today>pwdResponseDueDate)  )  ){  
          
          let msg ="PERM should be filed within 179 days from the date of first advertisement released";
          if(( pwdResponseDueDate && pwdResponseDueDate !=null && ( today>pwdResponseDueDate)  )){
            msg = "PERM should be filed prior to the date when PERM expires";
          }
          this.showToster({message:msg,isError:true });
          return false;
        
      }else{
        this.$refs["actionsPopup"].openPerDraftForm('EFILE_PREM_APPLICATION');
        
      }

     }else{
      this.$refs["actionsPopup"].openPerDraftForm('EFILE_PREM_APPLICATION');
     }
    
    }else{
      this.$refs["actionsPopup"].openPerDraftForm('EFILE_PREM_APPLICATION');
    }

     // 
    },
     

    checKPreParePermApplicationAdvRestriction(){
      
     
          
      this.preparePermApplicationActivity = _.find(this.workFlowDetails.config , {"code":'PREPARE_PERM_APPLICATION'});
      this.checkAdvValidationMsg ='';
     
      

      let advCoolingPeriod =0;
         if(this.checkProperty(this.petitionDetails,'advCoolingPeriod') >0){
            advCoolingPeriod =parseInt(this.petitionDetails['advCoolingPeriod']);
         }
         
      if(_.has(this.petitionDetails , 'completedActivities') && this.petitionDetails['completedActivities'].indexOf('PREPARE_PERM_APPLICATION')>-1 && this.petitionDetails['completedActivities'].indexOf('EFILE_PREM_APPLICATION')<=-1){

      let allAvertise =[];
      let today = moment().format("YYYY-MM-DD");
      
         // startDateKey:'startDateOfAdvAtJobFair',
          //endDateKey:'endDateOfAdvAtJobFair',
      _.forEach(this.avertisementList ,(item)=>{
        let tempItem = {
          startDateVal:'',
          endDateVal:''
        }
      
        if(_.has(this.petitionDetails['recruitmentInfo'], item['startDateKey'] ) && this.checkProperty(this.petitionDetails['recruitmentInfo'] ,item['startDateKey'])  ){
            try{
              let startDateVal = this.petitionDetails['recruitmentInfo'][item['startDateKey']];
              tempItem['startDateVal'] =moment(startDateVal).format("YYYY-MM-DD");
             
            }catch(err){
            

            }
        }
        if(_.has(this.petitionDetails['recruitmentInfo'], item['endDateKey'] ) && this.checkProperty(this.petitionDetails['recruitmentInfo'], item['endDateKey'])  ){
            try{
              let endDateVal = this.petitionDetails['recruitmentInfo'][item['endDateKey']];
              tempItem['endDateVal'] =moment(endDateVal).format("YYYY-MM-DD");

            }catch(err){}
        }
        if(tempItem['startDateVal'] && tempItem['endDateVal'] ){
          allAvertise.push(tempItem);
        }

      });
     
      allAvertise = _.orderBy(allAvertise ,['endDateVal'] ,['desc']);
     if(this.checkProperty(allAvertise ,'length') >0){
        let lastAdverStartDate = moment(allAvertise[0]['endDateVal']);
       let dateDif = moment().diff(lastAdverStartDate, 'days') ;

      

      if(dateDif < advCoolingPeriod ){  
        let remainingDays = advCoolingPeriod-dateDif;
       
       
        let msg ="It is recommended that a cooling period of "+advCoolingPeriod+" days must be maintained before the PERM Draft is created";
       
        if(dateDif<0){         
          if(lastAdverStartDate.isAfter(moment() ,'day')){
              
            remainingDays = advCoolingPeriod+(lastAdverStartDate.diff(moment(), 'days'))

          }   

            msg ="It is recommended that a cooling period of "+remainingDays+" days must be maintained before the PERM Draft is created";
         }else if(dateDif>0){
          msg ="It has been "+dateDif+" days since the last advertisement is placed. It is recommended that a cooling period of "+advCoolingPeriod+" days must be maintained before the PERM Draft is created"
       

        }
        this.checkAdvValidation =true;
        this.checkAdvValidationMsg=msg;
      

      }else{
        if(this.preparePermInvoiceError ==''){
          this.checkAdvValidation =false;
         // this.editQuestionnaire('PREPARE_PERM_APPLICATION');
          this.efilePermApplicationRestriction();
         
        }else{
          this.checkAdvValidation =true;
        }
        
      }

     }else{
        if(this.preparePermInvoiceError ==''){
             this.checkAdvValidation =false;
            //this.editQuestionnaire('PREPARE_PERM_APPLICATION');
            this.efilePermApplicationRestriction();
          }else{
            this.checkAdvValidation =true;
          }
     }
    
    }else{ 
      if(this.preparePermInvoiceError ==''){
          this.checkAdvValidation =false;
          //this.editQuestionnaire('PREPARE_PERM_APPLICATION');
          this.efilePermApplicationRestriction();
        }else{
          this.checkAdvValidation =true;
        }
    }

     // 
    },
         

    completReview(){
 
      let dispatchAction ="completereview"

      if([3].indexOf(this.checkProperty(this.petitionDetails,'typeDetails', 'id' )) >-1 && [15].indexOf(this.checkProperty(this.petitionDetails,'subTypeDetails', 'id' )) >-1){
        dispatchAction ="completePermReview";
      }
      

this.$store
      .dispatch(dispatchAction, { petitionId: this.petitionDetails._id })
      .then((response) => {
        this.showToster({ message: response.message, isError: false });

        this.$emit("updatepetition", "Case Details");

      })
      .catch((error) => {


      });

    },
        
    suggestJobDesc(isEdit=false ,activity='JOB_DESC_SUGGESSION'){
      if(isEdit){
        this.$refs["actionsPopup"].openJobDescription(activity); 
      }else{
        this.$refs["actionsPopup"].openPermJobDescActionsModal(activity);

      }

    },
    getAssignmentText(code ,actionLable){
      let listcode='';
      if(code == "ASSIGN_CASE_APPROVER"){
        listcode="CASE_APPROVED"
      }
      if(code == "ASSIGN_SUPERVISOR"){
        listcode="SUPERVISOR_LIST"
      }
       if(code == "ASSIGN_PARALEGAL"){
        listcode="PARALEGAL_LIST"
      }
       if(code == "ASSIGN_DOCUMENTATION_MANAGER"){
        listcode="DOCUMENTATION_MANAGER_LIST"
      }
      if(code == "ASSIGN_DOCUMENTATION_EXECUTIVE"){
        listcode="DOCUMENTATION_EXECUTIVE_LIST"
      }
      if(code == "ASSIGN_ATTORNEY"){
        listcode="ATTORNEY_LIST"
      }
      if(code == "REQUEST_PETITIONER_SIGN"){
        listcode="DOC_SIGNER_LIST"
      }
      let roleNames=[];
        if(listcode!=''){
        let tempList =[];
        let activytList =  _.find(this.workFlowDetails.config , {"code":listcode}); 
        _.forEach(activytList.editors,(item)=>{
          if(tempList.indexOf(item['roleId']) <=-1){
            roleNames.push(item['roleName']);
            tempList.push(item['roleId']);
          }
         
         
        })
        
       
        }
        if(roleNames.length>0){
          return 'Assign '+roleNames.join(' / ')

        }else{
          return actionLable;
        }

    },
    updatepetition(){
        this.$emit("updatepetition", "Case Details");
    },
    editQuestionnaire(activityCode=''){
     
      if([3].indexOf(this.checkProperty(this.petitionDetails,'typeDetails', 'id' )) >-1 && [15].indexOf(this.checkProperty(this.petitionDetails,'subTypeDetails', 'id' )) >-1){
        
        if(activityCode =="PREPARE_PERM_APPLICATION"){
          this.$router.push("/permapplication-questionnaire/"+this.petitionDetails._id+"?fromedit=true");
        }else  if(activityCode =="PERM_DRAFT_SUGGESSION"){
          this.$router.push("/permapplicationSuggession-questionnaire/"+this.petitionDetails._id+"?fromedit=true");
         
        }else{
          this.$router.push("/perm-questionnaire/"+this.petitionDetails._id+"?fromedit=true");

        }
        
       
        //permapplication-questionnaire/
        //permapplicationSuggession-questionnaire
       
      }else{
        this.$router.push("/questionnaire/"+this.petitionDetails._id+"?fromedit=true");
      }
    
  },
    checkActionRequired(item,index){
      
        var $self = this;
        let isAdmin = this.adminsList.indexOf(this.getUserRoleId) > -1
        let isRecevier = this.recevierList.indexOf(this.getUserRoleId) > -1
        let isPetitioner = this.petitionersList.indexOf(this.getUserRoleId) > -1
        let isBeneficiary = this.beneficiarysList.indexOf(this.getUserRoleId) > -1
        let islcaReqUser = this.lcarequestList.indexOf(this.getUserRoleId) > -1
        let islcaManager = this.lcasubmitList.indexOf(this.getUserRoleId) > -1;
        let isLcaExeCuitive = [1].indexOf(this.getUserRoleId) > -1
        let isCasenoAssigned=this.petitionDetails.completedActivities.indexOf('ASSIGN_CUSTOM_CASE_NO')>-1
        if(this.checkProperty(this.petitionDetails , 'allowCustomCaseNo') !=true){
          isCasenoAssigned = true;
        }

        isCasenoAssigned = true;
        let checkDependentH4 = this.checkDependenth4;
        let checkDependentH4EAD = this.checkDependenth4EAD;
       

        let isdocManager = this.docmangerList.indexOf(this.getUserRoleId) > -1
        let assignUsersOncreation = this.workFlowDetails.assignUsersOn == "case-created"?true:false;
        let isFreeflow = this.workFlowDetails.workflowType == "Free-Flow"?true:false;
        let canAssignParalegal = this.paralegalmanagerList.indexOf(this.getUserRoleId) > -1;
        let canAssignAttorneyorDocManager = this.attorneymanagerList.indexOf(this.getUserRoleId) > -1;
         let canAssignDocm = this.docmList.indexOf(this.getUserRoleId) > -1;
        let canCaseApprove =  this.caseApprovalList.indexOf(this.getUserRoleId) > -1;
        let canRequestSign = this.signerRequestersList.indexOf(this.getUserRoleId) > -1;
        let isSigner = this.signersList.indexOf(this.getUserRoleId) > -1;
        let canSubmittoUSCIS = this.submitUSCISList.indexOf(this.getUserRoleId) > -1;
        let cansupervisorFormsReview = this.supervisorFormsReviewEditors.indexOf(this.getUserRoleId) > -1;
        let canSubmitTracking = this.submitTrackingList.indexOf(this.getUserRoleId) > -1;
        let canSubmitReceipt = this.submitUSCISReceiptList.indexOf(this.getUserRoleId) > -1;
        let canSubmitResponse = this.submitUSCISResponseList.indexOf(this.getUserRoleId) > -1;

        let isendForSignInRequired = _.find(this.workFlowDetails.config , {"code":'REQUEST_PETITIONER_SIGN' ,'actionRequired':'Yes'});
        
        let isenJobDescriptionReviewRequired =false;
        if( _.find(this.workFlowDetails.config , {"code":'REQUEST_JOB_DESC_REVIEW' ,'actionRequired':'Yes'})){
          isenJobDescriptionReviewRequired = true;
        }
        
        

       //this.approvedPwdReqForAdvEvidences
       let isPwdFiled =true;
       if(_.has(this.petitionDetails , 'isPwdFiled')){
          isPwdFiled = this.petitionDetails['isPwdFiled'];
       }

      
       let pwdStatus ='';
       if(_.has(this.petitionDetails , 'pwdStatus') && ['Filed' ,'Certified'].indexOf(this.petitionDetails['pwdStatus'])>-1 ){
        pwdStatus = this.petitionDetails['pwdStatus'];
       }
       let hasJobDetails =false;
       if(_.has(this.petitionDetails , 'hasJobDetails')){
          hasJobDetails = this.petitionDetails['hasJobDetails'];
       }
       
       

        /*
    permJobDesEditorsList
    reqJobDesReview:[],
   
    permJobApprove:[],
    finnailizePermJob:[],
    
    
    */

    
    if(this.getTenantTypeId==2  ){
     let editors= [12];
     //canRequestSign = editors.indexOf(this.getUserRoleId) > -1;
    }

   let isPermCase =false;
       if(this.checkProperty(this.petitionDetails ,'typeDetails','id' )==3 && this.checkProperty(this.petitionDetails ,'subTypeDetails','id' )==15){
        isPermCase =true;
       }
  let isI140Case =false;
  let isI485Case =false;
    if(this.checkProperty(this.petitionDetails ,'typeDetails','id' )==3 && [16].indexOf(this.checkProperty(this.petitionDetails ,'subTypeDetails','id' ) )>-1 ){
    isI140Case =true;
       } 
      
       if(this.checkProperty(this.petitionDetails ,'typeDetails','id' )==3 && this.checkProperty(this.petitionDetails ,'subTypeDetails','id' )==17){
        isI485Case =true;
       }   
        let canEditPermJobDesc =this.permJobDesEditorsList.indexOf(this.getUserRoleId) > -1; 
        let canReqJobDesReview =this.reqJobDesReview.indexOf(this.getUserRoleId) > -1; 
       
        let canPermJobApprove =this.permJobApprove.indexOf(this.getUserRoleId) > -1; 
        let canFinnailizePermJob =this.finnailizePermJob.indexOf(this.getUserRoleId) > -1; 



        let canEditPermAdvertisement =this.jobAdvertismentActivity.indexOf(this.getUserRoleId) > -1; 
        let canPerformpwdEfileActivity =this.pwdEfileActivity.indexOf(this.getUserRoleId) > -1; 
        let pwdUpdateResponseUpdateActivity =this.pwdResponseUpdateActivity.indexOf(this.getUserRoleId) > -1; 
        let canPreParePermApplication = this.preparePermActivity.indexOf(this.getUserRoleId) > -1; 
        let canPreParePermApplicationSuggssion = this.permSuggssitionActivity.indexOf(this.getUserRoleId) > -1; 
        let canApprovePermApplication = this.approvePermApplication.indexOf(this.getUserRoleId) > -1; 


        let canefilePermActivity = this.efilePermActivity.indexOf(this.getUserRoleId) > -1; 
        let canRequestPermDraftReview = this.requestPermDraftReview.indexOf(this.getUserRoleId) > -1; 
        let canAcknowledgePerm = this.permAcknowledgementEditors.indexOf(this.getUserRoleId) > -1; 
       
        let canUpdateDolResponse =  this.updateDolResponseEditors.indexOf(this.getUserRoleId) > -1; 
        let canFilingFee =  this.filingEditors.indexOf(this.getUserRoleId) > -1; 

        let  canAssignCaseApprovers = this.assignCaseApproverEditors.indexOf(this.getUserRoleId) > -1;  
        
        
        let nextWorkflowActivityList = [];
        if(this.checkProperty(this.petitionDetails ,'nextWorkflowActivity' ,'length') >0 ){
          nextWorkflowActivityList =   this.petitionDetails['nextWorkflowActivity'];
          
        }
        
        let dolResopnseCompleted =false;
        let dolResponseList =['DOL_APPROVED' ,'DOL_RECEIVED_RFE' ,'DOL_DENIED','DOL_WITHDRAWN' ,'DOL_SUPERVISORY_AUDIT'];
        _.forEach(this.petitionDetails.completedActivities ,(item)=>{
          if(dolResponseList.indexOf(item) >-1){
            dolResopnseCompleted =true;
          }

        });


       
        if(index == (this.menuItems.length-1)){
            setTimeout(function(){
                if(document.getElementsByClassName("drop_menu_items").length > 0){
                    $self.showMe = true;
                }
            },100)
        }

        let createJDPermissions =false;
        if( 
          ( this.petitionDetails.completedActivities.indexOf('EFILE_PWD') <=-1 && this.petitionDetails.completedActivities.indexOf('PWD_CERTIFID') <=-1 && ['Filed' ,'Certified'].indexOf(this.checkProperty( this.petitionDetails ,'pwdStatus'))<=-1 )
          && (
          (this.petitionDetails.completedActivities.indexOf('CREATE_JOB_DESC') <=-1 && this.isActiveCode("CREATE_JOB_DESC"))
          &&
           (
             ( !hasJobDetails && this.checkAssignments && isPermCase &&  isCasenoAssigned && this.petitionDetails.completedActivities.indexOf('SUBMIT_TO_LAW_FIRM') >-1 &&  (canEditPermJobDesc || isAdmin) )
             || (isPermCase &&  isCasenoAssigned && this.petitionDetails.completedActivities.indexOf('SUBMIT_TO_LAW_FIRM') >-1 && (canEditPermJobDesc || isAdmin) && this.checkProperty( this.workFlowDetails,'workflowType')=='Free-Flow' )
           )
          )
           ){
          createJDPermissions  = true;
        }

        //beneficiaryInfo.maritalStatus 
       // dependentsInfo.spouse.h4Required
       // dependentsInfo.spouse.h4EADRequired
       let h4Required = false;
       if(this.checkProperty(this.petitionDetails ,'beneficiaryInfo' ,'maritalStatus') !=1){
        if(this.checkProperty(this.petitionDetails['dependentsInfo'],'spouse' ,'h4Required') ==true || this.checkChildH4required){
          h4Required =true;
        }
      
       }

       /*Handle Rfe with in h1b*/
       /*
        
        prePareRfeResDocsEditors:[], //RFE_PREPARE_RESPONSE_DOCS
        rfeCaseApprovedEditors:[],//RFE_CASE_APPROVED
        rfeReqPetEditors:[],//RFE_REQUEST_PETITIONER_SIGN // OR RFE_DOC_SIGNER_LIST
        rfeSubmitToUscisEditors:[],//RFE_SUBMIT_TO_USCIS
        rfeUpdateUscisEditors:[],//RFE_UPDATE_USCIS_RESPONSE
        */
       let canPrePareRfeResDocs = this.prePareRfeResDocsEditors.indexOf(this.getUserRoleId) > -1; 
       let canRfeCaseApproved = this.rfeCaseApprovedEditors.indexOf(this.getUserRoleId) > -1; 
       let canRfeCourierTracking = this.rfeCourierTrackingEditors.indexOf(this.getUserRoleId) > -1;
       let canUpdateRfeUscisReceiptNumber = this.updateRfeUscisReceiptNumberEditors.indexOf(this.getUserRoleId) > -1;
       let canRfeReqPet = this.rfeReqPetEditors.indexOf(this.getUserRoleId) > -1; ;
       let canRfeSubmitToUscis = this.rfeSubmitToUscisEditors.indexOf(this.getUserRoleId) > -1; ;
       let canRfeUpdateUscis = this.rfeUpdateUscisEditors.indexOf(this.getUserRoleId) > -1; ;




        switch (item.code) {
        case "CHANGE_CASE_TYPE":
          //if admin and case is not approved yet  < 9
         
          if ( ([2,9,10].indexOf( this.checkProperty(this.petitionDetails, "type"))<=-1 ) && (isAdmin || this.checkNoNotifyUserIds  ) &&  [50,51].indexOf(this.getUserRoleId)<=-1   && this.petitionDetails.statusId  && !isPermCase && this.checkProperty(this.petitionDetails ,'typeDetails','id' )!=3  ){
            return true
          } else{
            
            return false
          }
          
          break;
        case "GENERATE_FORMS":
            //alert(this.checkOpenGenerateFormsAndletters)
            if(isI140Case && this.checkOpenGenerateFormsAndletters && [14,50,51].indexOf(this.getUserRoleId)<0){
              return true;
            }
            else if(isI485Case && this.checkOpenGenerateFormsAndletters && [14,50,51].indexOf(this.getUserRoleId)<0){
              return true;
            }
            return false; 
            break; 
        case "ASSIGN_CASE_NUMBER":
          
          
          if ( this.petitionDetails.completedActivities.indexOf('ASSIGN_CUSTOM_CASE_NO') <=-1 && this.petitionDetails.allowCustomCaseNo && (isRecevier || isAdmin) &&  ((!isPermCase && this.petitionDetails.statusId <= 12 ) || ( ( isPermCase && this.petitionDetails.statusId < 18 ) ||true )  ) ) return true
          return false
          break;
        case "ASSIGN_CASE_APPROVER":

        //assignCaseApproverEditors
           
            if((canAssignCaseApprovers || isAdmin || (isRecevier && isFreeflow && this.canAssignAllatonce) ) && this.petitionDetails.completedActivities.indexOf('ASSIGN_CASE_APPROVER') < 0  && this.petitionDetails.nextWorkflowActivity.indexOf('ASSIGN_CASE_APPROVER')>-1  ){
             return true
            }else{
              return false;
            }
            
          
        case "EDIT_QUESTIONNAIRE":
             if(([9].indexOf( this.checkProperty(this.petitionDetails, "type"))>-1 )){
              return false;
             }
           
             if(this.checkBackToAssign && [51].indexOf(this.getUserRoleId) >-1 && this.petitionDetails.completedActivities.indexOf('SUBMIT_TO_USCIS') < 0){
               return true;

             }else  if(this.checkProperty(this.petitionDetails ,'typeDetails' ,'id' )==3 && this.checkProperty(this.petitionDetails ,'subTypeDetails' ,'id' )==15 ){
                if(this.petitionDetails.completedActivities.indexOf('APPROVE_JOB_DESC') <=-1){
                    if ( isBeneficiary && this.petitionDetails.completedActivities.indexOf('SUBMIT_TO_LAW_FIRM') < 0) return true
                    if ( isPetitioner && this.petitionDetails.completedActivities.indexOf('SUBMIT_TO_LAW_FIRM') < 0) return true  
                    if ( (isAdmin || [6,8].indexOf(this.getUserRoleId) >-1) && this.petitionDetails.statusId < 17) return true
                }
              }
              else if(this.checkProperty(this.petitionDetails ,'typeDetails' ,'id' )==3 && this.checkProperty(this.petitionDetails ,'subTypeDetails' ,'id' )!=15 ){
                if(this.petitionDetails.completedActivities.indexOf('UPDATE_USCIS_RESPONSE') <=-1){
                    if ( isBeneficiary &&  this.petitionDetails.completedActivities.indexOf('SUBMIT_TO_LAW_FIRM') < 0 && !this.checkActivityCompleted('UPDATE_USCIS_RECEIPT_NUMBER') ) return true
                    if ( isPetitioner && this.petitionDetails.completedActivities.indexOf('SUBMIT_TO_LAW_FIRM') < 0 && !this.checkActivityCompleted('UPDATE_USCIS_RECEIPT_NUMBER') ) return true  
                    //if ( isAdmin && this.petitionDetails.statusId < 12) return true
                    if ( (isAdmin || [6,8].indexOf(this.getUserRoleId) >-1) && this.petitionDetails.completedActivities.indexOf('SUBMIT_TO_USCIS') < 0 && !this.checkActivityCompleted('UPDATE_USCIS_RECEIPT_NUMBER') )return true
                } 
              }
              else{
                if ( isBeneficiary && this.petitionDetails.completedActivities.indexOf('SUBMIT_TO_LAW_FIRM') < 0 && !this.checkActivityCompleted('UPDATE_USCIS_RECEIPT_NUMBER') ) return true
                if ( isPetitioner && this.petitionDetails.completedActivities.indexOf('SUBMIT_TO_LAW_FIRM') < 0 && !this.checkActivityCompleted('UPDATE_USCIS_RECEIPT_NUMBER') ) return true  
                //if ( isAdmin && this.petitionDetails.statusId < 12) return true
                if ( (isAdmin || [6,8].indexOf(this.getUserRoleId) >-1) && this.petitionDetails.completedActivities.indexOf('SUBMIT_TO_USCIS') < 0 && !this.checkActivityCompleted('UPDATE_USCIS_RECEIPT_NUMBER') )return true
              }
            
          return false
          break; 
        case "SUBMIT_CASE":
          if ( isPetitioner  && this.petitionDetails.completedActivities.indexOf('SUBMIT_BY_BENEFICIARY') > -1 && this.petitionDetails.completedActivities.indexOf('SUBMIT_TO_LAW_FIRM') < 0) return true  
          if ( isAdmin && this.petitionDetails.completedActivities.indexOf('SUBMIT_BY_BENEFICIARY') > -1 && this.petitionDetails.completedActivities.indexOf('SUBMIT_TO_LAW_FIRM') < 0) return true
          return false
          break;
        //UPDATE_USCIS_RECEIPT_NUMBER //UPDATE_USCIS_RESPONSE
        case "LINK_PERM":
          if([50,51].indexOf(this.getUserRoleId)<=-1 &&  this.petitionDetails['completedActivities'].indexOf('SUBMIT_TO_USCIS') < 0 && isI140Case && !isI485Case  ) return true
          return false
        break;
        case "DELETE_PWD":
          
          if(  this.checkAssignments && isPermCase && this.checkProperty(this.petitionDetails ,"pwdId") && isAdmin && this.petitionDetails.completedActivities.indexOf('PREPARE_PERM_APPLICATION') <=-1){
            return true
          }else{
            return false
          }
        case "LINK_PWD":
          return (this.petitionDetails.completedActivities.indexOf('EFILE_PWD')<=-1 && createJDPermissions) || ( (canEditPermJobDesc || isAdmin) && this.checkProperty(this.petitionDetails ,'pwdLinkedOn') && this.petitionDetails.completedActivities.indexOf('PREPARE_PERM_APPLICATION') <=-1 )
          
        break;
        case "LINK_140":
          if([50,51].indexOf(this.getUserRoleId)<=-1 &&  this.petitionDetails['completedActivities'].indexOf('SUBMIT_TO_USCIS') < 0 && isI485Case  ) return true
          return false
          break;
        case "PREMIUM_PROCESS":
          if (  
            !(this.petitionDetails.completedActivities.indexOf('UPDATE_USCIS_RESPONSE') >-1 
                || this.petitionDetails['completedActivities'].indexOf('DOL_APPROVED')>-1
                 ||  this.petitionDetails['completedActivities'].indexOf('DOL_RECEIVED_RFE')>-1
                 ||  this.petitionDetails['completedActivities'].indexOf('DOL_AUDIT')>-1
                 ||  this.petitionDetails['completedActivities'].indexOf('PREPARE_AUDIT_RESPONSE')>-1
                 ||  this.petitionDetails['completedActivities'].indexOf('DOL_SUPERVISORY_AUDIT')>-1
                 ||  this.petitionDetails['completedActivities'].indexOf('DOL_DENIED')>-1
                ||  this.petitionDetails['completedActivities'].indexOf('DOL_WITHDRAWN')>-1
                 ||  this.petitionDetails['completedActivities'].indexOf('UPDATE_DOL_RESPONSE')>-1
               )  
          && ( ([14,50,51].indexOf(this.getUserRoleId)<=-1 || this.checkIsLcaExcuitive) && this.petitionDetails.premiumProcessing == false && !isPermCase)
          && ([2,9,10].indexOf( this.checkProperty(this.petitionDetails, "type"))<=-1 )
          ) return true
          return false
          break;
        case "UPDATE_INTERNAL_STATUS":
          if(

            ( [3,4,50].indexOf(this.getUserRoleId)>-1 || isAdmin)
            
            && ( 
                                
                      this.petitionDetails.completedActivities.indexOf('UPDATE_USCIS_RECEIPT_NUMBER') <= -1

                      && this.petitionDetails['completedActivities'].indexOf('USCIS_APPROVED')<=-1
                      && this.petitionDetails['completedActivities'].indexOf('USCIS_RECEIVED_RFE')<=-1
                      && this.petitionDetails['completedActivities'].indexOf('USCIS_DENIED')<=-1
                       && this.petitionDetails['completedActivities'].indexOf('USCIS_WITHDRAWN')<=-1
                      && this.petitionDetails['completedActivities'].indexOf('UPDATE_USCIS_RESPONSE')<=-1
                      

                      && this.petitionDetails['completedActivities'].indexOf('DOL_APPROVED')<=-1
                      &&  this.petitionDetails['completedActivities'].indexOf('DOL_RECEIVED_RFE')<=-1
                      &&  this.petitionDetails['completedActivities'].indexOf('DOL_AUDIT')<=-1
                      &&  this.petitionDetails['completedActivities'].indexOf('PREPARE_AUDIT_RESPONSE')<=-1
                      &&  this.petitionDetails['completedActivities'].indexOf('DOL_SUPERVISORY_AUDIT')<=-1
                      &&  this.petitionDetails['completedActivities'].indexOf('DOL_DENIED')<=-1
                      &&  this.petitionDetails['completedActivities'].indexOf('DOL_WITHDRAWN')<=-1
                      &&  this.petitionDetails['completedActivities'].indexOf('UPDATE_DOL_RESPONSE')<=-1
                  
                 
            )){
            return true

          }else{
            return false
          }
          
          break;  
        case "NORMAL_PROCESS":
          if ( this.petitionDetails.completedActivities.indexOf('UPDATE_USCIS_RESPONSE') <= -1 && ([14,50,51].indexOf(this.getUserRoleId)<=-1 || this.checkIsLcaExcuitive )&& this.petitionDetails.premiumProcessing  && !isPermCase) return true
          return false
        break; 
        case "RE_ASSIGN":
        if([51].indexOf(this.getUserRoleId)<=-1){
          if(!isPermCase){
            if(( this.petitionDetails.completedActivities.indexOf('SUBMIT_TO_USCIS') <=-1 && this.petitionDetails.completedActivities.indexOf('SUBMIT_TO_LAW_FIRM') >= 0 ) && !this.checkActivityCompleted('UPDATE_USCIS_RESPONSE')){
                if([50,51].indexOf(this.getUserRoleId)>-1){
                  return true
                  // if(([51].indexOf(this.getUserRoleId)>-1 && this.checkProperty( this.petitionDetails ,'benfReassignRefUserId')) || ( [50].indexOf(this.getUserRoleId)>-1 && this.checkProperty( this.petitionDetails ,'ptnrReassignRefUserId'))){
                  //    return true
                  // }

                }else{
                  return true
                }
            }

          }else if( this.petitionDetails.completedActivities.indexOf('SUBMIT_TO_LAW_FIRM') >= 0 && ( isPermCase && [ 'DOL_AUDIT' ,'DOL_SUPERVISORY_AUDIT','PREPARE_AUDIT_RESPONSE','SUBMIT_TO_DOL' ,'DOL_APPROVED' ,'DOL_RECEIVED_RFE' ,'DOL_DENIED' ,'DOL_WITHDRAWN'].indexOf(this.petitionDetails.curWorkflowActivity)<=-1)){
              if([50,51].indexOf(this.getUserRoleId)>-1){
                return true
              // if(([51].indexOf(this.getUserRoleId)>-1 && this.checkProperty( this.petitionDetails ,'benfReassignRefUserId')) || ( [50].indexOf(this.getUserRoleId)>-1 && this.checkProperty( this.petitionDetails ,'ptnrReassignRefUserId'))){
              // return true
              // }

              }else{
              return true
              }
          }
        }
          return false
          
        break;
        case "BACK_TO_ASSIGN":
          //reassignLogs
          if( this.checkBackToAssign && ( this.petitionDetails.completedActivities.indexOf('SUBMIT_TO_USCIS') <=-1 && this.petitionDetails.completedActivities.indexOf('SUBMIT_TO_LAW_FIRM') >= 0 )){
            return true;
            
          }
          return false
          
        break; 
        case "UPDATE_LCA":
          if ( ( this.checkProperty( this.petitionDetails ,'lcaDetails' ,'statusDetails') && [4,7,99].indexOf(this.petitionDetails['lcaDetails']['statusDetails']['id'])<=-1 ) && (isAdmin || islcaReqUser || islcaManager || this.checkIsLcaExcuitive || ([50].indexOf(this.getUserRoleId)>-1 && this.checkPetitionsDetails)  ) && this.petitionDetails.lcaRequested && !isPermCase && !this.checkActivityCompleted('UPDATE_USCIS_RECEIPT_NUMBER') ) return true
          return false
        break;
        case "UPDATE_DEADLINE":
          if ( (isAdmin || isRecevier || [8].indexOf(this.getUserRoleId)>-1) && this.petitionDetails.statusId < 12) return true
          return false
        break;
        case "ASSIGN_SUPERVISOR":
          if ( (assignUsersOncreation || ( !assignUsersOncreation && (this.checkProperty(this.petitionDetails ,'questionnaireFilled') || this.checkProperty(this.petitionDetails ,'type')==9  ) )) && this.checkNoNotifyUserIds && this.petitionDetails.completedActivities.indexOf('SUBMIT_TO_USCIS') <=-1 && this.isActiveCode("ASSIGN_SUPERVISOR") &&  ((!isPermCase && this.petitionDetails.statusId <= 12 || ( this.checkProperty(this.petitionDetails ,'type')==9 && [32,33].indexOf(this.petitionDetails.statusId) >-1) ) || (isPermCase && this.petitionDetails.statusId <= 18 )) &&  (isAdmin || isRecevier) &&  this.petitionDetails.completedActivities.indexOf('ASSIGN_SUPERVISOR') < 0) return true
          return false
        break;  
        case "ASSIGN_PARALEGAL":
          if ((assignUsersOncreation || ( !assignUsersOncreation && (this.checkProperty(this.petitionDetails ,'questionnaireFilled') || this.checkProperty(this.petitionDetails ,'type')==9  ) )) &&  this.checkNoNotifyUserIds && this.petitionDetails.completedActivities.indexOf('SUBMIT_TO_USCIS') <=-1 && this.isActiveCode("ASSIGN_PARALEGAL") &&  ((!isPermCase && this.petitionDetails.statusId <= 12 || ( this.checkProperty(this.petitionDetails ,'type')==9 && [32,33].indexOf(this.petitionDetails.statusId)>-1 ) ) || (isPermCase && this.petitionDetails.statusId <= 18 )) && ( isAdmin || (canAssignParalegal && !this.confirmrequriedchecked)  || (isRecevier && isFreeflow && this.canAssignAllatonce )) &&  this.petitionDetails.completedActivities.indexOf('ASSIGN_PARALEGAL') < 0) return true
          return false
        break;
        case "ASSIGN_DOCUMENTATION_MANAGER":
          
          if ( (assignUsersOncreation || ( !assignUsersOncreation && (this.checkProperty(this.petitionDetails ,'questionnaireFilled') || this.checkProperty(this.petitionDetails ,'type')==9  ) )) && this.checkNoNotifyUserIds && this.petitionDetails.completedActivities.indexOf('SUBMIT_TO_USCIS') <=-1   && this.isActiveCode("ASSIGN_DOCUMENTATION_MANAGER") &&  ((!isPermCase && this.petitionDetails.statusId <= 12 || ( this.checkProperty(this.petitionDetails ,'type')==9 && [32,33].indexOf(this.petitionDetails.statusId)>-1 ) ) || (isPermCase && this.petitionDetails.statusId <= 18 )) && ( isAdmin || ( (canAssignAttorneyorDocManager || canAssignDocm) && !this.confirmrequriedchecked)  || (isRecevier && isFreeflow && this.canAssignAllatonce )) &&  this.petitionDetails.completedActivities.indexOf('ASSIGN_DOCUMENTATION_MANAGER') < 0) return true
          return false
        break; 
        case "ASSIGN_ATTORNEY":
          if ( 
            (assignUsersOncreation || ( !assignUsersOncreation && (this.checkProperty(this.petitionDetails ,'questionnaireFilled') || this.checkProperty(this.petitionDetails ,'type')==9 ) ))
              && this.checkNoNotifyUserIds && this.petitionDetails.completedActivities.indexOf('SUBMIT_TO_USCIS') <=-1 && this.isActiveCode("ASSIGN_ATTORNEY") && 
            ( ( this.checkProperty( this.petitionDetails,'type' )==9 && nextWorkflowActivityList.indexOf("ASSIGN_ATTORNEY")>-1) || (!isPermCase && this.petitionDetails.statusId <= 12 || ( this.checkProperty(this.petitionDetails ,'type')==9 && [32,33].indexOf(this.petitionDetails.statusId)>-1 ) ) || (isPermCase && this.petitionDetails.statusId <= 18 )) 
            && ( isAdmin || (canAssignAttorneyorDocManager && !this.confirmrequriedchecked)  ||  (isRecevier && isFreeflow && this.canAssignAllatonce )) &&  this.petitionDetails.completedActivities.indexOf('ASSIGN_ATTORNEY') < 0) {
            return true
          }
          return false
        break; 
        case "ASSIGN_DOCUMENTATION_EXECUTIVE":
          if(this.checkProperty(this.petitionDetails, 'type' ) ==9){
            if(!this.checkWorkActivityisRequires('ASSIGN_DOCUMENTATION_EXECUTIVE')){
              return false
            }

          }
          if ((assignUsersOncreation || ( !assignUsersOncreation && (this.checkProperty(this.petitionDetails ,'questionnaireFilled') ||  this.checkProperty(this.petitionDetails ,'type')==9) )) && this.checkNoNotifyUserIds && this.petitionDetails.completedActivities.indexOf('SUBMIT_TO_USCIS') <=-1 &&  this.isActiveCode("ASSIGN_DOCUMENTATION_EXECUTIVE") && ((!isPermCase && this.petitionDetails.statusId <= 12 || ( this.checkProperty(this.petitionDetails ,'type')==9 && [32,33].indexOf(this.petitionDetails.statusId)>-1 ) ) || (isPermCase && this.petitionDetails.statusId <= 18 )) && ((isAdmin && isFreeflow && this.canAssignAllatonce ) || (isdocManager && !this.confirmrequriedchecked) ) && isCasenoAssigned && this.petitionDetails.completedActivities.indexOf('ASSIGN_DOCUMENTATION_MANAGER') >= 0 && this.petitionDetails.completedActivities.indexOf('ASSIGN_DOCUMENTATION_EXECUTIVE') < 0) return true
          return false
        case "ASSIGN_LCA_EXECUTIVE--":
          if(  this.checkProperty(this.petitionDetails ,'lcaId' ) && this.checkNoNotifyUserIds && this.checkLcarequired &&  (this.canLcaRequested || this.canLcaSubmit) && !isPermCase && this.petitionDetails.completedActivities.indexOf('ASSIGN_LCA_EXECUTIVE')<=-1 && this.petitionDetails.completedActivities.indexOf('SUBMIT_TO_USCIS') <=-1){
            return false;  
          }
          return false;  
        break; 
        case "CREATE_JOB_DESC":
          //perm Action  
          return this.petitionDetails.completedActivities.indexOf('EFILE_PWD')<=-1 && createJDPermissions
          break;
        case "REQUEST_JOB_DESC_REVIEW":
          //perm Action 
          if ( 
           
            (!this.internamJobDesApproveRequired || ( this.internamJobDesApproveRequired  && this.checkProperty(this.petitionDetails ,'curWorkflowActivity') !='INTERNAL_REQUEST_JOB_DESC_REVIEW' ) && (this.petitionDetails.completedActivities.indexOf('INTERNAL_JOB_DESC_SUGGESSION') >-1 || this.petitionDetails.completedActivities.indexOf('INTERNAL_APPROVE_JOB_DESC') >-1 ) )
           && ( this.petitionDetails.completedActivities.indexOf('PWD_CERTIFID') <=-1 && this.petitionDetails.completedActivities.indexOf('EFILE_PWD') <=-1 && this.petitionDetails.completedActivities.indexOf('COLLECT_ADV_EVIDENCE')   )
            &&  (!hasJobDetails && this.checkAssignments && ['REQUEST_JOB_DESC_REVIEW' ,'INTERNAL_REQUEST_JOB_DESC_REVIEW'].indexOf(this.checkProperty(this.petitionDetails ,'curWorkflowActivity')) <=-1  &&  this.isActiveCode("REQUEST_JOB_DESC_REVIEW")) 
          && (canReqJobDesReview || isAdmin) 
          && (this.petitionDetails.completedActivities.indexOf('CREATE_JOB_DESC') >-1 && this.petitionDetails.completedActivities.indexOf('APPROVE_JOB_DESC') <=-1)
           ) {return true}

          return false
          break;
        case "JOB_DESC_SUGGESSION":
          //perm Action
          if ( !hasJobDetails && this.checkAssignments && this.isActiveCode("JOB_DESC_SUGGESSION") && (canPermJobApprove || isAdmin) && this.petitionDetails.completedActivities.indexOf('CREATE_JOB_DESC') >-1 ){
           
            return true
          } 

          return false
          break;
        case "INTERNAL_REQUEST_JOB_DESC_REVIEW":
          if(  this.petitionDetails.completedActivities.indexOf('REQUEST_JOB_DESC_REVIEW') <=-1 && this.checkAssignments && this.internamJobDesApproveRequired && this.petitionDetails.nextWorkflowActivity.indexOf('INTERNAL_REQUEST_JOB_DESC_REVIEW') >-1 &&  this.petitionDetails.completedActivities.indexOf('CREATE_JOB_DESC') >-1 && (canEditPermJobDesc || isAdmin)){
            return true;
          }else{
            return false;
          }
          break

        case "INTERNAL_APPROVE_JOB_DESC":
           
           if(
            
            this.petitionDetails.completedActivities.indexOf('REQUEST_JOB_DESC_REVIEW') <=-1 &&
            this.internamJobDesApproveRequired && this.checkAssignments
            && this.petitionDetails.nextWorkflowActivity.indexOf('INTERNAL_APPROVE_JOB_DESC') >-1
            && this.petitionDetails.completedActivities.indexOf('INTERNAL_APPROVE_JOB_DESC') <=-1
             &&   this.petitionDetails.completedActivities.indexOf('CREATE_JOB_DESC') >-1 
            &&  this.petitionDetails.completedActivities.indexOf('APPROVE_JOB_DESC') <=-1 
            && (this.internamJobDesApprove.indexOf(this.getUserRoleId) >-1 )
            
            ){
             return true;
           }else{
             return false;

           }
          
           break  
        case "APPROVE_JOB_DESC":
          //perm Action
          if (
            (this.checkProperty(this.petitionDetails ,'petiApprovReqPWDDoc') || ( !this.checkProperty(this.petitionDetails ,'petiApprovReqPWDDoc') &&  this.petitionDetails.completedActivities.indexOf('PWD_CERTIFID') <=-1  && this.petitionDetails.completedActivities.indexOf('EFILE_PWD') <=-1 ) )
            && (
            (!this.internamJobDesApproveRequired || ( this.internamJobDesApproveRequired  && this.checkProperty(this.petitionDetails ,'curWorkflowActivity') !='INTERNAL_REQUEST_JOB_DESC_REVIEW' ) && (this.petitionDetails.completedActivities.indexOf('INTERNAL_JOB_DESC_SUGGESSION') >-1 || this.petitionDetails.completedActivities.indexOf('INTERNAL_APPROVE_JOB_DESC') >-1 ) )
            && (!hasJobDetails && this.checkAssignments && this.isActiveCode("APPROVE_JOB_DESC") && (canPermJobApprove || isAdmin) && this.petitionDetails.completedActivities.indexOf('CREATE_JOB_DESC') >-1 && this.petitionDetails.completedActivities.indexOf('APPROVE_JOB_DESC') <=-1 )
            && !(this.checkProperty(this.petitionDetails ,'curWorkflowActivity') =='REQUEST_JOB_DESC_REVIEW' && this.jobdescriptionapprovallist.indexOf(this.getUserRoleId) > -1 )
            )
            && ( !isenJobDescriptionReviewRequired || ( isenJobDescriptionReviewRequired && this.petitionDetails.completedActivities.indexOf('REQUEST_JOB_DESC_REVIEW') >-1) )
           
            )
            
            {
            
            return true;
            }

          return false
          break;
        case "JOB_DESC_APPROVE_OR_SUGGESSION":
          // if APPROVE_JOB_DESC && SUGGEST_JOB_DESC_EDIT
         
          if(
            (!hasJobDetails && this.checkAssignments && this.isActiveCode("APPROVE_JOB_DESC") && (canPermJobApprove || isAdmin) && this.petitionDetails.completedActivities.indexOf('CREATE_JOB_DESC') >-1 && this.petitionDetails.completedActivities.indexOf('APPROVE_JOB_DESC') <=-1 )
             && (this.checkProperty(this.petitionDetails ,'curWorkflowActivity') =='REQUEST_JOB_DESC_REVIEW' && this.jobdescriptionapprovallist.indexOf(this.getUserRoleId) > -1 )
            ){
            return true;

          }else{
            
            return false
          }
         
          break;   
        case "FINALIZE_JOB_DESC":
          //perm Action
          if (!hasJobDetails && this.checkAssignments && this.isActiveCode("FINALIZE_JOB_DESC") && (canFinnailizePermJob || isAdmin) && this.petitionDetails.completedActivities.indexOf('APPROVE_JOB_DESC') >-1 && this.petitionDetails.completedActivities.indexOf('FINALIZE_JOB_DESC') <=-1)  return true

          return false
          break;
        case 'SUGGEST_JOB_DESC_EDIT':
          if(
            (this.checkProperty(this.petitionDetails ,'curWorkflowActivity') =='REQUEST_JOB_DESC_REVIEW' && this.jobdescriptionapprovallist.indexOf(this.getUserRoleId) > -1)
          &&  !(!hasJobDetails && this.checkAssignments && this.isActiveCode("APPROVE_JOB_DESC") && (canPermJobApprove || isAdmin) && this.petitionDetails.completedActivities.indexOf('CREATE_JOB_DESC') >-1 && this.petitionDetails.completedActivities.indexOf('APPROVE_JOB_DESC') <=-1 ) // this is approve job Description condation
              
          ){
            
          return true;
          }

          return false
          break;
        case "EDIT_JOB_DESC":
         // alert(this.permJobDesEditorsList.indexOf(this.getUserRoleId)>-1)
          if((this.permJobDesEditorsList.indexOf(this.getUserRoleId)>-1 || isAdmin ) && ( ['JOB_DESC_SUGGESSION' ,'INTERNAL_JOB_DESC_SUGGESSION' ,'REQUEST_JOB_DESC_REVIEW'].indexOf(this.checkProperty(this.petitionDetails ,'curWorkflowActivity'))>-1    ) &&  (  this.petitionDetails.completedActivities.indexOf('CREATE_JOB_DESC') >-1 && this.petitionDetails.completedActivities.indexOf('APPROVE_JOB_DESC') <=-1 ) ){
            return true
          }else{
            return false

          } 
          break; 
        case 'APPROVE_JOB_DESC_EDIT':

        if( this.jobdescriptionapprovallist.indexOf(this.getUserRoleId) > -1 ){


        }else{

            //JOB_DESC_SUGGESSION
         // alert(nextWorkflowActivityList.indexOf('REQUEST_JOB_DESC_REVIEW'));
         //this.checkProperty(this.petitionDetails ,'curWorkflowActivity') =='JOB_DESC_SUGGESSION'
         if ( !hasJobDetails && this.checkAssignments &&
            (nextWorkflowActivityList.indexOf('REQUEST_JOB_DESC_REVIEW')<=-1 && this.isActiveCode("APPROVE_JOB_DESC") && (canPermJobApprove || isAdmin) && this.petitionDetails.completedActivities.indexOf('REQUEST_JOB_DESC_REVIEW') >-1 && this.petitionDetails.completedActivities.indexOf('APPROVE_JOB_DESC') <=-1 ) || (this.checkProperty(this.petitionDetails ,'curWorkflowActivity') =='JOB_DESC_SUGGESSION' ) && (canEditPermJobDesc || isAdmin)
            || (this.checkProperty(this.petitionDetails ,'curWorkflowActivity') =='JOB_DESC_SUGGESSION' && (canEditPermJobDesc || isAdmin) )
            ){

            return false
          } 

            return false


        }
        
            break; 
        case "EFILE_PWD_DOL":
            //perm Action
            if ( !( this.petitionDetails.completedActivities.indexOf('PWD_CERTIFID')>-1 || this.petitionDetails.completedActivities.indexOf('EFILE_PWD')>-1    ) &&  this.checkAssignments && this.isActiveCode("EFILE_PWD") && (canPerformpwdEfileActivity || isAdmin)  && this.petitionDetails.completedActivities.indexOf('FINALIZE_JOB_DESC')>-1   ) return true

            return false
            break
        case "EFILE_PWD":
            //perm Action
            if ( (this.checkProperty( this.petitionDetails ,'pwdStatus') !='Certified' ) && this.checkAssignments && this.isActiveCode("EFILE_PWD") && (canPerformpwdEfileActivity || isAdmin) && this.petitionDetails.completedActivities.indexOf('EFILE_PWD')<=-1 && this.petitionDetails.completedActivities.indexOf('PWD_CERTIFID')<=-1 && this.petitionDetails.completedActivities.indexOf('FINALIZE_JOB_DESC')>-1   ) return true

            return false
            break
        case "UPDATE_PWD_RESPONSE":
           //alert(!isPwdFiled)
          //perm Action
          if ( 
            isPermCase &&(this.petitionDetails.completedActivities.indexOf('EFILE_PWD')>-1 || !isPwdFiled ) &&  this.isActiveCode("UPDATE_PWD_RESPONSE") && (pwdUpdateResponseUpdateActivity || isAdmin ) && this.checkAssignments
            && (
               
               (
                  (
                     this.petitionDetails.completedActivities.indexOf('PWD_CERTIFID')<0  || ( this.checkProperty(this.petitionDetails ,'curWorkflowActivity') =='UPDATE_PWD_RESPONSE' &&  this.checkProperty(this.petitionDetails ,'pwdStatus')=='Filed'  )
                  ) || 
                  (this.petitionDetails.nextWorkflowActivity.indexOf('UPDATE_PWD_RESPONSE')>-1)
              )
               && (this.petitionDetails.completedActivities.indexOf('EFILE_PWD')>-1  )
              // && ( (this.petitionDetails.completedActivities.indexOf('CREATE_JOB_DESC')<=-1) || (this.petitionDetails.completedActivities.indexOf('CREATE_JOB_DESC')>-1 && this.petitionDetails.completedActivities.indexOf('FINALIZE_JOB_DESC')>-1  )   )
               && ( this.petitionDetails.nextWorkflowActivity.indexOf('SUBMIT_RFI_RESPONSE')<=-1)
            ) 
            
           ){
           
            return true
          }else{

            return false

          } 

          
          break
        case "SUBMIT_RFI_RESPONSE":
          
          //perm Action
            if ( isPermCase && 
              (this.checkAssignments && ((pwdUpdateResponseUpdateActivity || isAdmin ) && ( this.petitionDetails.nextWorkflowActivity && this.petitionDetails.nextWorkflowActivity.indexOf('SUBMIT_RFI_RESPONSE')>-1) )
               
                
              ) 
              
            ){
              return true
            }else{

              return false

            } 

          
           break
        case "UPDATE_PWD_RESPONSE_WITH_JD": 
          if (
            (this.petitionDetails.completedActivities.indexOf('PWD_CERTIFID') <=-1 && this.petitionDetails.completedActivities.indexOf('PWD_CERTIFID') <=-1)
          && (
            (
                this.petitionDetails.completedActivities.indexOf('EFILE_PWD')<=-1
              && ( (this.petitionDetails.completedActivities.indexOf('CREATE_JOB_DESC')<=-1) || (this.petitionDetails.completedActivities.indexOf('CREATE_JOB_DESC')>-1 && this.petitionDetails.completedActivities.indexOf('FINALIZE_JOB_DESC')>-1  )   )
              && this.checkProperty( this.petitionDetails ,'pwdStatus') !='Certified' 
              && isPermCase && this.petitionDetails.nextWorkflowActivity && this.petitionDetails.nextWorkflowActivity.indexOf('SUBMIT_RFI_RESPONSE')<=-1 &&
                (this.petitionDetails.completedActivities.indexOf('SUBMIT_TO_LAW_FIRM') > -1 && (['Certified'].indexOf(pwdStatus)<=-1  ) &&
                    
                  (this.checkAssignments && (this.isActiveCode("UPDATE_PWD_RESPONSE") && (pwdUpdateResponseUpdateActivity || isAdmin ) && this.petitionDetails.completedActivities.indexOf('PWD_CERTIFID')<0 )
                    &&  (this.petitionDetails.completedActivities.indexOf('EFILE_PWD')<=-1 || (['Filed'].indexOf(pwdStatus)>-1 && isPwdFiled ) )
                  ) 
                  || (createJDPermissions)
              )
          ) || ( !this.checkProperty(this.petitionDetails, 'pwdLinkedOn') && this.checkAssignments   && isPermCase && this.checkAssignments && (pwdUpdateResponseUpdateActivity || isAdmin ) && this.petitionDetails.completedActivities.indexOf('EFILE_PWD')<=-1 && this.petitionDetails.completedActivities.indexOf('SUBMIT_TO_LAW_FIRM') > -1)    
          )  
          ){
              return true
            }else{

              return false

            } 

          
          break  
        case "COLLECT_ADV_EVIDENCE":
            //perm Action ['Filed'].indexOf('pwdStatus')>-1
           // alert(this.approvedPwdReqForAdvEvidences);
            if (
              this.checkAssignments &&
               this.isActiveCode("COLLECT_ADV_EVIDENCE") && (canEditPermAdvertisement || isAdmin) && this.petitionDetails.completedActivities.indexOf('COLLECT_ADV_EVIDENCE') <=-1
                &&(

                 (this.petitionDetails.completedActivities.indexOf('PWD_CERTIFID') >-1 )
                 || ( ( (['Filed'].indexOf(pwdStatus)>-1 || this.petitionDetails.completedActivities.indexOf('EFILE_PWD')>-1    ) && !this.approvedPwdReqForAdvEvidences)  || (['Certified'].indexOf(pwdStatus)>-1  ) )
                 

                 )
              
               ){
                return true
              }else{
                return false
              } 

           
            break
        case "COLLECT_ADV_EVIDENCE_EDIT":
            //perm Action ['Filed'].indexOf('pwdStatus')>-1
           // alert(this.approvedPwdReqForAdvEvidences);
            if (
              this.checkAssignments &&
               this.isActiveCode("COLLECT_ADV_EVIDENCE") && (canEditPermAdvertisement || isAdmin) 
               && this.petitionDetails.completedActivities.indexOf('COLLECT_ADV_EVIDENCE') >-1 
               && this.petitionDetails.completedActivities.indexOf('UPLOAD_PERM_ACK') <=-1 
                // &&(

                //  (this.petitionDetails.completedActivities.indexOf('PWD_CERTIFID') >-1 )
                //  || ( ( (['Filed'].indexOf(pwdStatus)>-1 || this.petitionDetails.completedActivities.indexOf('EFILE_PWD')>-1    ) )  || (['Certified'].indexOf(pwdStatus)>-1  ) )
                 

                //  )
              
               ){
                return true
              }else{
                return false
              } 

           
            break
        case "APPROVE_PERM_APPLICATION":
          //perm Action
          if (
            (
              this.petitionDetails.completedActivities.indexOf('EFILE_PREM_APPLICATION')>-1  
                 && this.isActiveCode("APPROVE_PERM_APPLICATION") 
              && (canApprovePermApplication || isAdmin) 
              && this.petitionDetails.completedActivities.indexOf('PREPARE_PERM_APPLICATION')>0 
             && this.petitionDetails.completedActivities.indexOf('APPROVE_PERM_APPLICATION')<=-1
          )&& !(
                ( this.petitionDetails.completedActivities.indexOf('APPROVE_PERM_APPLICATION')<=-1 
                  &&  this.isActiveCode("APPROVE_PERM_APPLICATION") && (canPreParePermApplicationSuggssion ) 
                  && this.petitionDetails.completedActivities.indexOf('PREPARE_PERM_APPLICATION')>=0 
                ) 
               && this.checkProperty(this.petitionDetails ,'curWorkflowActivity') !='PERM_DRAFT_SUGGESSION'
             
             ) 
          
          ){

           return true
          }

          return false
          break 
        case "PREPARE_PERM_APPLICATION":
          //alert(( (['Certified'].indexOf(pwdStatus)>-1  && this.checkProperty(this.petitionDetails,'isPwdFiled' )) || !this.checkProperty(this.petitionDetails,'isPwdFiled' )   ))
          //perm Action (['Certified'].indexOf(pwdStatus)>-1  && this.checkProperty(this.petitionDetails,'isPwdFiled' )  )
          if ( this.isActiveCode("PREPARE_PERM_APPLICATION") && (canPreParePermApplication || isAdmin)
        //  && this.petitionDetails.completedActivities.indexOf('PWD_CERTIFID')>-1 
          &&( ( (['Certified'].indexOf(pwdStatus)>-1  && this.checkProperty(this.petitionDetails,'isPwdFiled' )) || !this.checkProperty(this.petitionDetails,'isPwdFiled' )   ) || this.petitionDetails.nextWorkflowActivity.indexOf('PREPARE_PERM_APPLICATION')>-1)
          && this.petitionDetails.completedActivities.indexOf('COLLECT_ADV_EVIDENCE')>-1 
          && this.petitionDetails.completedActivities.indexOf('PREPARE_PERM_APPLICATION')<=-1 ) return true

          return false
          break
        case "INITIATE_REMINDER":
           //canApprovePermApplication
          if(this.petitionDetails.completedActivities.indexOf('SUBMIT_TO_LAW_FIRM') > -1 && isPermCase && ( canPreParePermApplication || isAdmin) && !this.checkProperty(this.petitionDetails ,'invoiceId') && this.enableFilingFee  ){
            return true
          } 
          
        return false
        break
        case "REQUEST_PERM_DRAFT_REVIEW":
              //perm Action
              if( ( 
                (this.petitionDetails.completedActivities.indexOf('FINALIZE_JOB_DESC') >-1 || (['Filed' ,'Certified'].indexOf(pwdStatus)>-1 || this.petitionDetails.completedActivities.indexOf('EFILE_PWD')>-1 || this.petitionDetails.completedActivities.indexOf('PWD_CERTIFID')>-1 ))
                && this.petitionDetails.completedActivities.indexOf('EFILE_PREM_APPLICATION')>-1  
                && this.petitionDetails.completedActivities.indexOf('APPROVE_PERM_APPLICATION')<=-1 
                && this.checkProperty(this.petitionDetails ,'curWorkflowActivity') !='REQUEST_PERM_DRAFT_REVIEW' 
                && !dolResopnseCompleted && this.isActiveCode("REQUEST_PERM_DRAFT_REVIEW") 
                && !( nextWorkflowActivityList.indexOf('APPROVE_PERM_APPLICATION')<=-1 && this.petitionDetails.completedActivities.indexOf('REQUEST_PERM_DRAFT_REVIEW')>-1)
                && (canRequestPermDraftReview || isAdmin) 
                && this.petitionDetails.completedActivities.indexOf('PREPARE_PERM_APPLICATION')>-1  
                ) || (this.checkProperty(this.petitionDetails ,'curWorkflowActivity') =='PERM_DRAFT_SUGGESSION' && (canRequestPermDraftReview || isAdmin)  )) return true

              return false
              break
        case "UPLOAD_PWD_DOCS":
              //perm Action
            
              return false
              break      
        case "PERM_DRAFT_SUGGESSION":
          //perm Action curWorkflowActivity
          if 
          (
            
          (( this.petitionDetails.completedActivities.indexOf('APPROVE_PERM_APPLICATION')<=-1 
          &&  this.isActiveCode("APPROVE_PERM_APPLICATION") && (canPreParePermApplicationSuggssion ) 
          && this.petitionDetails.completedActivities.indexOf('PREPARE_PERM_APPLICATION')>=0 )
          && this.petitionDetails.completedActivities.indexOf('EFILE_PREM_APPLICATION')>=0 
          && this.checkProperty(this.petitionDetails ,'curWorkflowActivity') =='REQUEST_PERM_DRAFT_REVIEW' )
          
          ) {
            return true
          }

          return false
          break
        case "PERM_DRAFT_SUGGESSION_EDIT":
          //perm Action 
          if (
          (  
            (canPreParePermApplication || isAdmin) 
            && (nextWorkflowActivityList.indexOf('REQUEST_PERM_DRAFT_REVIEW')>-1 || nextWorkflowActivityList.indexOf('APPROVE_PERM_APPLICATION')>-1 ) 
            && this.petitionDetails.completedActivities.indexOf('REQUEST_PERM_DRAFT_REVIEW')>-1 
            && this.petitionDetails.completedActivities.indexOf('APPROVE_PERM_APPLICATION')<=-1 
            && this.isActiveCode("PREPARE_PERM_APPLICATION") 
            && this.petitionDetails.completedActivities.indexOf('PREPARE_PERM_APPLICATION')>-1 
          )

          //perm PERM_DRAFT_SUGGESSION
          || (
            
            (( this.petitionDetails.completedActivities.indexOf('APPROVE_PERM_APPLICATION')<=-1 
            &&  this.isActiveCode("APPROVE_PERM_APPLICATION") && (canPreParePermApplicationSuggssion ) 
            && this.petitionDetails.completedActivities.indexOf('PREPARE_PERM_APPLICATION')>=0 )
            && this.petitionDetails.completedActivities.indexOf('EFILE_PREM_APPLICATION')>=0 
            && this.checkProperty(this.petitionDetails ,'curWorkflowActivity') =='REQUEST_PERM_DRAFT_REVIEW' )
            
            )
             &&  [50].indexOf(this.getUserRoleId)<=-1
       
          ) {
             return true
            
            }

          return false
          break  
        case "EFILE_PREM_APPLICATION":
              //perm Action
              if ( this.petitionDetails.completedActivities.indexOf('PREPARE_PERM_APPLICATION') >-1 
              && isPermCase && this.isActiveCode("EFILE_PREM_APPLICATION") 
              && (canefilePermActivity || isAdmin)  
              && this.petitionDetails.completedActivities.indexOf('EFILE_PREM_APPLICATION')<=-1 ) return true

              return false
              break
        case "EFILE_PREM_APPLICATION_DRAFT":
              //perm Action
              if ( !dolResopnseCompleted  && this.isActiveCode("UPDATE_DOL_RESPONSE") 
              && (canUpdateDolResponse || isAdmin) 
              && this.petitionDetails.completedActivities.indexOf('UPLOAD_PERM_ACK')<=-1 
              && this.petitionDetails.completedActivities.indexOf('APPROVE_PERM_APPLICATION')>-1 
              && this.petitionDetails.completedActivities.indexOf('EFILE_PREM_APPLICATION')>-1
              && ['DOL_AUDIT' ,'DOL_SUPERVISORY_AUDIT','PREPARE_AUDIT_RESPONSE','SUBMIT_TO_DOL' ,'DOL_APPROVED' ,'DOL_RECEIVED_RFE' ,'DOL_DENIED' ,'DOL_WITHDRAWN'].indexOf(this.petitionDetails.curWorkflowActivity)<=-1
              ) return true

              return false
              break
        case "UPLOAD_PERM_ACK":
          //permAcknowledgementEditors canAcknowledgePerm
          if ( !dolResopnseCompleted  && this.isActiveCode("UPLOAD_PERM_ACK") 
              && (canAcknowledgePerm || isAdmin) 
              && this.petitionDetails.completedActivities.indexOf('APPROVE_PERM_APPLICATION')>-1
              && this.petitionDetails.nextWorkflowActivity.indexOf('UPLOAD_PERM_ACK')>-1 
              && this.petitionDetails.completedActivities.indexOf('UPLOAD_PERM_ACK')<=-1 
              //&& this.petitionDetails.completedActivities.indexOf('EFILE_PREM_APPLICATION')>-1
              && ['DOL_AUDIT' ,'DOL_SUPERVISORY_AUDIT','PREPARE_AUDIT_RESPONSE','SUBMIT_TO_DOL' ,'DOL_APPROVED' ,'DOL_RECEIVED_RFE' ,'DOL_DENIED' ,'DOL_WITHDRAWN'].indexOf(this.petitionDetails.curWorkflowActivity)<=-1
              ) return true

          return false
          break
        case "PREPARE_AUDIT_RESPONSE":
            //
            if(
              ['DOL_SUPERVISORY_AUDIT','SUBMIT_TO_DOL' ,'DOL_APPROVED' ,'DOL_RECEIVED_RFE' ,'DOL_DENIED' ,'DOL_WITHDRAWN'].indexOf(this.petitionDetails.curWorkflowActivity)<=-1 &&
              this.petitionDetails.completedActivities.indexOf('DOL_AUDIT')>-1
              && this.petitionDetails.completedActivities.indexOf('DOL_SUPERVISORY_AUDIT') <=-1
               && (canefilePermActivity || isAdmin)

            ) return true;

            return false;
            break;
        case 'FILING_FEE':
          //{{  invoiceNotification }} ---- {{ removedInvoiceItems }} <br>{{ newlyAddInvoiceItems }}
          if( (this.petitionDetails.completedActivities.indexOf('SUBMIT_TO_LAW_FIRM') >-1  || [9].indexOf(this.checkProperty(this.petitionDetails,'typeDetails', 'id')) >-1) && (canFilingFee || isAdmin)  && ( (this.checkProperty(this.petitionDetails ,'invoiceDetails' ,'statusId' ) < 5  || ( this.checkProperty(this.petitionDetails ,'filingFeeDetails' )))  || ( this.newlyAddInvoiceItems.length>0 || this.removedInvoiceItems.length >0 ) ) && this.checklawTenant){
            return true;
          }
          else{
            return false
          }
          break    
        case "ADD_PAYMENT":
           //canApprovePermApplication
          if(this.checkProperty(this.petitionDetails ,'invoiceId' ) && this.petitionDetails.invoiceDetails && this.petitionDetails.invoiceDetails.statusId < 6 &&  ( canFilingFee || isAdmin) && this.enableFilingFee  ){
            return true
          } 
          
        return false
        break  
        case 'ACCOUNTANT_APPORVAL_REQUEST':
          //// enableFilingFee fileAfterInvoice fileAfterPayment
               
          if(
            isPermCase && (

            ( 
              (this.petitionDetails.completedActivities.indexOf('PREPARE_PERM_APPLICATION') >-1 
              && isPermCase && this.isActiveCode("EFILE_PREM_APPLICATION") 
              && (canefilePermActivity || isAdmin)
              && this.petitionDetails.completedActivities.indexOf('EFILE_PREM_APPLICATION')<=-1
              ) || !isPermCase
              
           )
           &&
            (
              this.checkProperty(this.petitionDetails ,'invoiceDetails' ,'statusId' ) !=6 && 
              this.checkProperty(this.petitionDetails ,'invoiceId' ) && this.fileAfterPayment && !this.checkProperty(this.petitionDetails ,'accApprovalInfo' ,'requestedOn') && !this.checkProperty(this.petitionDetails ,'accApprovalInfo' ,'approvedOn')
           )
          )
          ){
            
            this.enableAccountantApprovalRequest=true;
            this.enableAccountantApprovalGrant=false;
            return true;
            
          }else{
            this.enableAccountantApprovalRequest=false;
            return false;
          } 

          
          break;            
        case 'ACCOUNTANT_APPORVAL_GRANT':
          if((canFilingFee  ) && this.checkProperty(this.petitionDetails ,'invoiceDetails' ,'statusId' ) !=6  &&  this.checkProperty(this.petitionDetails ,'accApprovalInfo' ,'requestedOn') && !this.checkProperty(this.petitionDetails ,'accApprovalInfo' ,'approvedOn') ){
            this.enableAccountantApprovalRequest=false;
            this.enableAccountantApprovalGrant=true;
            return true;
            
          }else{
            this.enableAccountantApprovalGrant=false;
            return false;
          }
          break;            
        case "SUBMIT_TO_DOL":
            if(
              ( nextWorkflowActivityList.indexOf('PREPARE_AUDIT_RESPONSE')>-1  ||
                this.checkProperty(this.petitionDetails ,'curWorkflowActivity') =='DOL_AUDIT'
               ) 
               && this.petitionDetails.completedActivities.indexOf('DOL_SUPERVISORY_AUDIT') <=-1
                && this.checkProperty(this.formsAndLettersList ,'length' )>0 &&
               (canefilePermActivity || isAdmin)

            ) return true;

            return false;
            break;
        case "DOL_SUPERVISORY_AUDIT": 
            if ( 
              (this.checkProperty(this.petitionDetails ,'curWorkflowActivity') =='DOL_AUDIT'   ) 
              && this.petitionDetails.completedActivities.indexOf('DOL_SUPERVISORY_AUDIT') <=-1
              && (canUpdateDolResponse || isAdmin) 
              && this.petitionDetails.completedActivities.indexOf('APPROVE_PERM_APPLICATION')>-1 
              && this.petitionDetails.completedActivities.indexOf('EFILE_PREM_APPLICATION')>-1 ) return true

              return false
              break                       
        case "UPDATE_DOL_RESPONSE":
          //perm Action UPLOAD_PERM_ACK
          if ( !dolResopnseCompleted  && this.isActiveCode("UPDATE_DOL_RESPONSE")
          && this.petitionDetails.completedActivities.indexOf('UPLOAD_PERM_ACK') >-1
          && this.petitionDetails.completedActivities.indexOf('DOL_SUPERVISORY_AUDIT') <=-1
          && (this.checkProperty(this.petitionDetails ,'curWorkflowActivity') !='DOL_AUDIT' || this.checkProperty(this.petitionDetails ,'curWorkflowActivity') =='PREPARE_AUDIT_RESPONSE'   ) 
          && (canUpdateDolResponse || isAdmin) 
          && this.petitionDetails.completedActivities.indexOf('APPROVE_PERM_APPLICATION')>-1 
          && this.petitionDetails.completedActivities.indexOf('EFILE_PREM_APPLICATION')>-1 ) return true

          return false
          break  
        case "FILE_I140":
          //perm Action
          if (  (canUpdateDolResponse || isAdmin) 
          && this.checkProperty(this.petitionDetails ,'i140notCreateReason') !=1
          && this.petitionDetails['completedActivities'].indexOf('DOL_APPROVED')>-1 
          && this.petitionDetails['i140Case'] ==null ) return true

          return false
          break       
        case "CASE_APPROVED":
         
          if(this.checkProperty(this.petitionDetails ,'type')==9){
           
            if( (isAdmin || canCaseApprove) && this.petitionDetails.completedActivities.indexOf('RFE_REVIEW_RESPONSE_DOCS') >-1 && this.petitionDetails.completedActivities.indexOf('RFE_PREPARE_RESPONSE_DOCS') >-1 && this.petitionDetails.completedActivities.indexOf('CASE_APPROVED') <=-1){
              //( this.petitionDetails.completedActivities.indexOf('RFE_PREPARE_RESPONSE_DOCS') >-1 && this.checkProperty(this.petitionDetails ,'type')==9 )
              return true;
            }else{
              return false;
            }
            break
            
          }else{
            
              if ( this.checkCaseApprovedAction && !isI140Case && !isI485Case &!isPermCase && (isAdmin || canCaseApprove) && isCasenoAssigned && this.petitionDetails.completedActivities.indexOf('CASE_APPROVED') < 0 && (isAdmin || this.petitionDetails.completedActivities.indexOf('ASSIGN_ATTORNEY') >= 0)  && ( this.petitionDetails.completedActivities.indexOf('SUBMIT_TO_LAW_FIRM') >-1  )  ){
              return true
              }else if(this.checkCaseApprovedAction && (isI140Case  || isI485Case) && this.checkActiveFormsAndLetters() && (isAdmin || canCaseApprove) && isCasenoAssigned  && this.petitionDetails.completedActivities.indexOf('CASE_APPROVED') < 0 && this.petitionDetails.completedActivities.indexOf('SUBMIT_TO_LAW_FIRM') >-1 ){
                return true;
              }
            }
            return false
          break;
        case "SEND_DOCUMENTS":
          if(!isPermCase && this.checkProperty(this.formsAndLettersList, "length") > 0 && this.checkDoce && this.checkPendingDocs && ((this.checkProperty(this.petitionDetails , 'docsReviewedByDocManager') ==true && this.checkProperty(this.petitionDetails , 'docsUploadByDocExecutive') !=true )|| (this.checkProperty(this.petitionDetails , 'docsReviewedByDocManager') ==false && this.checkProperty(this.petitionDetails , 'docsUploadByDocExecutive') ==false )  )) return true
             return false
             break;
        case "APPROVE_DOCUMENTS":
             //alert(this.formsAndLettersList.length);
             if(!isPermCase && this.checkProperty(this.formsAndLettersList, "length") > 0 &&  this.checkDocM && this.checkPendingDocs && this.checkProperty(this.petitionDetails , 'docsReviewedByDocManager') !=true && this.checkProperty(this.petitionDetails , 'docsUploadByDocExecutive') ) return true
             return false
             break;  
        
        case "REQUEST_BENEFICIARY_SIGN":
          //alert(canRequestSign)
        // this.checkProperty(this.petitionDetails ,'spouse','h4EADRequired')
           //this.checkProperty(this.petitionDetails ,'beneficiaryInfo','maritalStatus')
           
        
            
           if ((h4Required || ([2,10].indexOf(this.checkProperty(this.petitionDetails, 'type' ))>-1)  ) && isendForSignInRequired && ( (isAdmin || canRequestSign) && isCasenoAssigned && (( this.checkCaseApprovedAction && this.petitionDetails.completedActivities.indexOf('CASE_APPROVED') >= 0) || !this.checkCaseApprovedAction ) &&  this.petitionDetails.completedActivities.indexOf('SUBMIT_TO_USCIS') < 0 )&& !this.checkActivityCompleted('UPDATE_USCIS_RECEIPT_NUMBER')){
            
            if(isI140Case){
              if(this.petitionDetails.completedActivities.indexOf('SUPERVISOR_FORMS_REVIEW') <=-1){
                
                return true
              }
              else if(isI485Case){
                if(this.petitionDetails.completedActivities.indexOf('SUPERVISOR_FORMS_REVIEW') <=-1){
                  return true
                }
                
              }

             }else{
             
             return true
             }
          }
            return false
          break;
        case "UPLOAD_BENEFICIARY_SCANNED_COPY":
             //isAdmin || canRequestSign || isSigner ||
          if ( ( ([2,10].indexOf(this.petitionDetails['type'])>-1 && isAdmin ) || (isSigner && this.getTenantTypeId==2) || [51].indexOf(this.getUserRoleId)>-1) && isCasenoAssigned && this.petitionDetails.completedActivities.indexOf('REQUEST_BENEFICIARY_SIGN') >= 0 && this.petitionDetails.completedActivities.indexOf('SUBMIT_TO_USCIS') < 0 && !this.checkActivityCompleted('UPDATE_USCIS_RECEIPT_NUMBER')){
             return true
             if(isI140Case){
              if(this.petitionDetails.completedActivities.indexOf('SUPERVISOR_FORMS_REVIEW') <=-1){
                return true
              }

             }
             else if(isI485Case){
              if(this.petitionDetails.completedActivities.indexOf('SUPERVISOR_FORMS_REVIEW') <=-1){
                return true
              }
             }
             else{
              return true
             }
            }
            return false
          break;
          
        case "REQUEST_PETITIONER_SIGN":
          //alert(canRequestSign)
          if([2,10].indexOf(this.checkProperty(this.petitionDetails, 'type' ))>-1){
            if(!this.checkProperty(this.petitionDetails,'petitionerId')){
              return false;
            }

          }
          if(this.checkProperty(this.petitionDetails, 'type' ) ==9){
            if(!this.checkWorkActivityisRequires('REQUEST_PETITIONER_SIGN')){
              return false
            }

          }
          if (isendForSignInRequired && ( (isAdmin || canRequestSign) && isCasenoAssigned && (( this.checkCaseApprovedAction && this.petitionDetails.completedActivities.indexOf('CASE_APPROVED') >= 0) || !this.checkCaseApprovedAction ) && this.petitionDetails.completedActivities.indexOf('SUBMIT_TO_USCIS') < 0 )&& !this.checkActivityCompleted('UPDATE_USCIS_RECEIPT_NUMBER') ){
            
            if(isI140Case && false){
              if(this.petitionDetails.completedActivities.indexOf('SUPERVISOR_FORMS_REVIEW') <=-1){
                
                return true
              }

             }
             else if(isI485Case && false){
              if(this.petitionDetails.completedActivities.indexOf('SUPERVISOR_FORMS_REVIEW') <=-1){
                
                return true
              }
             }
             else{
             
              return true
             }
          }
            return false
          break;
        case "GENERATED_SIGNED_DOCS":

        if([2,9,10].indexOf(this.checkProperty(this.petitionDetails, 'type'))>-1 ){
          return false;

        }else {
             
          if ( isendForSignInRequired && this.checkProperty(this.petitionDetails ,'ptnrAttorneySignByInternal') && ( (isAdmin || canRequestSign) && isCasenoAssigned && this.petitionDetails.completedActivities.indexOf('CASE_APPROVED') >= 0 && this.petitionDetails.completedActivities.indexOf('SUBMIT_TO_USCIS') < 0 )  && !this.checkActivityCompleted('UPDATE_USCIS_RECEIPT_NUMBER')){
            
            if(isI140Case){
              if(this.petitionDetails.completedActivities.indexOf('SUPERVISOR_FORMS_REVIEW') <=-1){
                
                return true
              }

              }
              else if(isI485Case){
              if(this.petitionDetails.completedActivities.indexOf('SUPERVISOR_FORMS_REVIEW') <=-1){
                
                return true
              }
              }
              else{
              
              return true
              }
          }
        }  
          return false;
          break;
        case "UPLOAD_SIGNED_DOCUMENTS":
          
          if (  (isAdmin || isSigner|| isPetitioner) && isCasenoAssigned && this.petitionDetails.completedActivities.indexOf('REQUEST_PETITIONER_SIGN') >= 0 && this.petitionDetails.completedActivities.indexOf('SUBMIT_TO_USCIS') < 0 && !this.checkActivityCompleted('UPDATE_USCIS_RECEIPT_NUMBER')){
             //return true
             if(isI140Case){
              if(this.petitionDetails.completedActivities.indexOf('SUPERVISOR_FORMS_REVIEW') <=-1){
                return true
              }

             }
             else if(isI485Case){
              if(this.petitionDetails.completedActivities.indexOf('SUPERVISOR_FORMS_REVIEW') <=-1){
                return true
              }
             }
             else{
              return true
             }
            }else  if([1].indexOf(this.checkProperty(this.petitionDetails ,'type')) >-1 && this.checkProperty(this.workFlowDetails ,'manageRfeCase') =='with_in_case'){
              if ((isAdmin || isSigner|| isPetitioner) && isCasenoAssigned && this.petitionDetails.completedActivities.indexOf('RFE_REQUEST_PETITIONER_SIGN') >= 0 && this.petitionDetails.completedActivities.indexOf('RFE_SUBMIT_TO_USCIS') < 0 && !this.checkActivityCompleted('RFE_UPDATE_USCIS_RECEIPT_NUMBER')){
                return true
              }

            }
            return false
          break;
        case "SUPERVISOR_FORMS_REVIEW":
          
          if(isI140Case &&(isAdmin || cansupervisorFormsReview ) && (this.petitionDetails.completedActivities.indexOf('REQUEST_PETITIONER_SIGN') >= 0 ||  this.petitionDetails.completedActivities.indexOf('GENERATED_SIGNED_DOCS')>-1 )&&  this.petitionDetails.completedActivities.indexOf('SUPERVISOR_FORMS_REVIEW') <= -1 &&  this.petitionDetails.completedActivities.indexOf('SUBMIT_TO_USCIS') <= -1  ){
            return true;
          }
          else if(isI485Case && (isAdmin || cansupervisorFormsReview ) && (this.petitionDetails.completedActivities.indexOf('REQUEST_PETITIONER_SIGN') >= 0 || this.petitionDetails.completedActivities.indexOf('GENERATED_SIGNED_DOCS')>-1) &&  this.petitionDetails.completedActivities.indexOf('SUPERVISOR_FORMS_REVIEW') <= -1 &&  this.petitionDetails.completedActivities.indexOf('SUBMIT_TO_USCIS') <= -1  ){
            return true;
          }
          return false
          break;
        case "SUBMIT_TO_USCIS":
          if ( (isAdmin || canSubmittoUSCIS) && isCasenoAssigned && 
          (  (this.checkProperty(this.petitionDetails, 'type')==9 && nextWorkflowActivityList.indexOf('SUBMIT_TO_USCIS')>-1 ) ||  (( ( [2,10].indexOf(this.petitionDetails['type'])>-1  && (this.petitionDetails.completedActivities.indexOf('REQUEST_PETITIONER_SIGN') >= 0 || this.petitionDetails.completedActivities.indexOf('REQUEST_BENEFICIARY_SIGN') >= 0  ) ) ||  ( [2,10].indexOf(this.petitionDetails['type'])<=-1 && this.petitionDetails.completedActivities.indexOf('REQUEST_PETITIONER_SIGN') >= 0) ) || this.petitionDetails.completedActivities.indexOf('GENERATED_SIGNED_DOCS')>-1)) 
          && this.petitionDetails.completedActivities.indexOf('SUBMIT_TO_USCIS') < 0 && (this.petitionDetails.completedActivities.indexOf('SUBMIT_TO_LAW_FIRM') >-1 || [9].indexOf(this.checkProperty(this.petitionDetails,'typeDetails','id'))>-1) && !this.checkActivityCompleted('UPDATE_USCIS_RECEIPT_NUMBER') ){
             if(isI140Case){
              if(this.petitionDetails.completedActivities.indexOf('SUPERVISOR_FORMS_REVIEW') >= 0){
                return true
              }

             }
             else if(isI485Case){
              if(this.petitionDetails.completedActivities.indexOf('SUPERVISOR_FORMS_REVIEW') >= 0){
                return true
              }
             }
             else{
              return true
             }  
            
          } 
          return false
        case "COURIER_TRACKING":
          if ( (isAdmin || canSubmitTracking) && isCasenoAssigned && this.petitionDetails.completedActivities.indexOf('SUBMIT_TO_USCIS') >= 0 && this.petitionDetails.completedActivities.indexOf('COURIER_TRACKING') < 0  && !this.checkActivityCompleted('UPDATE_USCIS_RECEIPT_NUMBER')) return true
          return false   
        case "UPDATE_USCIS_RECEIPT_NUMBER":
          if ( 
            this.checkProperty(this.petitionDetails ,'type') !=9 &&
            ((isAdmin || canSubmitReceipt) && isCasenoAssigned && this.petitionDetails.completedActivities.indexOf('COURIER_TRACKING') >= 0 && this.petitionDetails.completedActivities.indexOf('UPDATE_USCIS_RECEIPT_NUMBER') < 0 
             || (isAdmin && (this.petitionDetails.completedActivities.indexOf('REQUEST_PETITIONER_SIGN') >-1 || this.petitionDetails.completedActivities.indexOf('REQUEST_BENEFICIARY_SIGN')>-1 )  && this.petitionDetails.completedActivities.indexOf('UPDATE_USCIS_RECEIPT_NUMBER') <=-1))
          ){
            return true
          } 
          return false 
        case "REVIEW_COMPLETED":
          if ( this.confirmrequried ) return true
          return false 
        case "UPDATE_USCIS_RESPONSE":
          if ( (isAdmin || canSubmitResponse) && isCasenoAssigned && 
           (this.petitionDetails.completedActivities.indexOf('UPDATE_USCIS_RECEIPT_NUMBER') >= 0 ||( [9].indexOf(this.checkProperty(this.petitionDetails, 'typeDetails', 'id'))>-1 && this.petitionDetails.completedActivities.indexOf('COURIER_TRACKING')>-1 ) )
          && (
              (this.petitionDetails.completedActivities.indexOf('UPDATE_USCIS_RESPONSE') < 0 || ( this.petitionDetails.completedActivities.indexOf('UPDATE_USCIS_RESPONSE')>-1 && this.checkProperty(this.petitionDetails ,'autoUscisStatusUpdate')==true && this.checkProperty(this.petitionDetails ,'uploadUscisDocs') !=true   ) )
              || (isAdmin && this.petitionDetails.completedActivities.indexOf('UPDATE_USCIS_RECEIPT_NUMBER') >-1 && (this.petitionDetails.completedActivities.indexOf('UPDATE_USCIS_RESPONSE')<=-1 || ( this.petitionDetails.completedActivities.indexOf('UPDATE_USCIS_RESPONSE') >-1 && this.petitionDetails.uscisUpdateCategories.indexOf('beneficairy') <=-1 )  )  )
             )
          )
          {
            return true
          } 
          return false
        //case "RFE_UPDATE_USCIS_RESPONSE_H4EAD":    
        case "UPDATE_USCIS_RESPONSE_H4EAD":
          if (checkDependentH4EAD && (isAdmin || canSubmitResponse) && isCasenoAssigned && this.petitionDetails.completedActivities.indexOf('UPDATE_USCIS_RECEIPT_NUMBER') >= 0 
          && (this.petitionDetails.uscisUpdateCategories.indexOf('h4ead_spouse') < 0  )
          
          ){
            return true
          } 
          return false
        //case "RFE_UPDATE_USCIS_RESPONSE_H4":    
        case "UPDATE_USCIS_RESPONSE_H4":
          if (checkDependentH4 && (isAdmin || canSubmitResponse) && isCasenoAssigned && this.petitionDetails.completedActivities.indexOf('UPDATE_USCIS_RECEIPT_NUMBER') >= 0  
          && (  
               this.petitionDetails.uscisUpdateCategories.indexOf('h4_spouse') <= -1 
              // || this.petitionDetails.uscisUpdateCategories.indexOf('h4_children')<=-1 
             )
          ){
            return true
          } 
          return false  
        case "LINK_LCA":
          //if([51].indexOf(this.getUserRoleId)<=-1 && this.petitionDetails['completedActivities'].indexOf('SUBMIT_TO_USCIS') < 0 && (this.checkLCACreatePermisions||isAdmin    ) && !isPermCase && this.checkLcarequired)  return true
          if( this.checkLcarequired && [51].indexOf(this.getUserRoleId)<=-1 &&  ((isAdmin || islcaReqUser || islcaManager || this.checkIsLcaExcuitive   )  && !isPermCase  ) && !this.checkActivityCompleted('UPDATE_USCIS_RECEIPT_NUMBER')) return true
          
          return false
        break;
        case "RFE_PREPARE_RESPONSE_DOCS":
           if(this.checkProperty(this.petitionDetails ,'type')==9){

            
            if( ( nextWorkflowActivityList.indexOf('RFE_PREPARE_RESPONSE_DOCS')>-1 && ( isAdmin || this.checkDocM) ) && nextWorkflowActivityList.indexOf('RFE_PREPARE_RESPONSE_DOCS')>-1 && this.petitionDetails.completedActivities.indexOf('RFE_PREPARE_RESPONSE_DOCS') <=-1){
              
              return true;
            }
          }else if([1].indexOf(this.checkProperty(this.petitionDetails ,'type')) >-1 && this.checkProperty(this.workFlowDetails ,'manageRfeCase') =='with_in_case'){
            if( ( nextWorkflowActivityList.indexOf('RFE_PREPARE_RESPONSE_DOCS')>-1 && ( isAdmin || canPrePareRfeResDocs) ) && this.petitionDetails.completedActivities.indexOf('RFE_PREPARE_RESPONSE_DOCS') <=-1){
              
              return true;
            
          }
        }
                        
          
            return false ;
        case "CREATE_RFE_CASE": 
          
          if(this.checkProperty(this.workFlowDetails ,'manageRfeCase') !='with_in_case' && [1,2,10].indexOf(this.checkProperty(this.petitionDetails ,'type')) >-1 ){
            if( !this.checkProperty(this.petitionDetails,'rfeCaseId') &&  this.checkCaseCreatePermisions  && this.petitionDetails.completedActivities.indexOf('USCIS_RECEIVED_RFE') >-1){
              return true;
            }        
          }
        return false ;
        case "RFE_REVIEW_RESPONSE_DOCS":
              
          if((this.checkProperty(this.petitionDetails ,'type')==9) || ([1].indexOf(this.checkProperty(this.petitionDetails ,'type')) >-1 && this.checkProperty(this.workFlowDetails ,'manageRfeCase') =='with_in_case')){
            
            if( ( nextWorkflowActivityList.indexOf('RFE_REVIEW_RESPONSE_DOCS')>-1 && ( isAdmin || this.checkDocM) ) && this.petitionDetails.completedActivities.indexOf('RFE_REVIEW_RESPONSE_DOCS')<=-1 && this.petitionDetails.completedActivities.indexOf('RFE_PREPARE_RESPONSE_DOCS')>-1 ){
              
              return true; 
            }
                        
          }
            return false ;
        case "RFE_CASE_APPROVED":
           if([1].indexOf(this.checkProperty(this.petitionDetails ,'type')) >-1 && this.checkProperty(this.workFlowDetails ,'manageRfeCase') =='with_in_case'){
            if( ( nextWorkflowActivityList.indexOf('RFE_CASE_APPROVED')>-1 && ( isAdmin || canRfeCaseApproved) ) && this.petitionDetails.completedActivities.indexOf('RFE_CASE_APPROVED') <=-1){
              
              return true;
            
            }
           } 
           
          return false ;
        case "RFE_COURIER_TRACKING":
         
          //if([1].indexOf(this.checkProperty(this.petitionDetails ,'type')) >-1 && this.checkProperty(this.workFlowDetails ,'manageRfeCase') =='with_in_case'){
            
              if( ( nextWorkflowActivityList.indexOf('RFE_COURIER_TRACKING')>-1 && ( isAdmin || canRfeCourierTracking) ) && this.petitionDetails.completedActivities.indexOf('RFE_COURIER_TRACKING') <=-1){
                
                return true;
              
            }
          //  }
          return false;  
        case "RFE_UPDATE_USCIS_RECEIPT_NUMBER":
          if([1].indexOf(this.checkProperty(this.petitionDetails ,'type')) >-1 && this.checkProperty(this.workFlowDetails ,'manageRfeCase') =='with_in_case'){
                if( ( nextWorkflowActivityList.indexOf('RFE_UPDATE_USCIS_RECEIPT_NUMBER')>-1 && ( isAdmin || canUpdateRfeUscisReceiptNumber) ) && this.petitionDetails.completedActivities.indexOf('RFE_UPDATE_USCIS_RECEIPT_NUMBER') <=-1){
                  
                  return true;
                
              }
              }
            return false;  

        case "RFE_REQUEST_PETITIONER_SIGN":
           if([1].indexOf(this.checkProperty(this.petitionDetails ,'type')) >-1 && this.checkProperty(this.workFlowDetails ,'manageRfeCase') =='with_in_case'){
            if( ( nextWorkflowActivityList.indexOf('RFE_REQUEST_PETITIONER_SIGN')>-1 && ( isAdmin || canRfeReqPet) ) && this.petitionDetails.completedActivities.indexOf('RFE_REQUEST_PETITIONER_SIGN') <=-1){
              
              return true;
            
            }
           }
           return false
        case "RFE_SUBMIT_TO_USCIS":
           if([1].indexOf(this.checkProperty(this.petitionDetails ,'type')) >-1 && this.checkProperty(this.workFlowDetails ,'manageRfeCase') =='with_in_case'){
            if( ( nextWorkflowActivityList.indexOf('RFE_SUBMIT_TO_USCIS')>-1 && ( isAdmin || canRfeSubmitToUscis) ) && this.petitionDetails.completedActivities.indexOf('RFE_SUBMIT_TO_USCIS') <=-1){
              
              return true;
            
            }
           }     
           
          return false ; 
        case "RFE_UPDATE_USCIS_RESPONSE":
           if([1].indexOf(this.checkProperty(this.petitionDetails ,'type')) >-1 && this.checkProperty(this.workFlowDetails ,'manageRfeCase') =='with_in_case'){
            if( ( nextWorkflowActivityList.indexOf('RFE_UPDATE_USCIS_RESPONSE')>-1 && ( isAdmin || canRfeUpdateUscis) ) && this.petitionDetails.completedActivities.indexOf('RFE_UPDATE_USCIS_RESPONSE') <=-1){
              
              return true;
            
            }
           } 
           return false ;     
            

        default:   
          return false

        }

    },
    isActiveCode(listcode){

      let activytList =  _.find(this.workFlowDetails.config , {"code":listcode}); 
      if(activytList && activytList['include'] == 'Yes') return true;
      return false;
    },
    getRoleslist(code){
      let listcode='';
      if(code == "ASSIGN_CASE_APPROVER"){
        listcode="CASE_APPROVED"
      }
      if(code == "ASSIGN_SUPERVISOR"){
        listcode="SUPERVISOR_LIST"
      }
       if(code == "ASSIGN_PARALEGAL"){
        listcode="PARALEGAL_LIST"
      }
       if(code == "ASSIGN_DOCUMENTATION_MANAGER"){
        listcode="DOCUMENTATION_MANAGER_LIST"
      }
      if(code == "ASSIGN_DOCUMENTATION_EXECUTIVE"){
        listcode="DOCUMENTATION_EXECUTIVE_LIST"
      }
      if(code == "ASSIGN_ATTORNEY"){
        listcode="ATTORNEY_LIST"
      }
      if(code == "REQUEST_PETITIONER_SIGN"){
        if(code == "REQUEST_PETITIONER_SIGN" && this.getTenantTypeId==2){
          listcode="DOC_SIGNER_LIST"
        }
        else{
          listcode="REQUEST_PETITIONER_SIGN"
        }
      }
      
      

      if(listcode!=''){
       let activytList =  _.find(this.workFlowDetails.config , {"code":listcode}); 
      this.rolesList = _.map(activytList.editors, 'roleId');
      }
   
    


    },
    triggerAction(menuItem) {

      let canEditPermJobDesc =this.permJobDesEditorsList.indexOf(this.getUserRoleId) > -1; 
      let isAdmin = this.adminsList.indexOf(this.getUserRoleId) > -1;

      let isPermCase =false;
       if(this.checkProperty(this.petitionDetails ,'typeDetails','id' )==3){
        isPermCase =true;
       }
      switch (menuItem.code) {
        case "CREATE_RFE_CASE":
          this.createRfeError ='';
          this.creatingrfeCase =false;
         this.createRfeCase =true;
        break;
        case "GENERATE_FORMS":
        //  this.$route['params']['openGeneratePopup'] ='openGeneratePopup';
        //  this.$route['params']['tabname'] ='Forms and Letters';
        //  this.$route['query']['openGenForms'] ='openGenForms';
         // this.$emit('opengenFormsAndLatters');
          this.$emit("updatepetition", "opengenFormsAndLatters");
          break;
        case "REVIEW_COMPLETED":
         this.completReview()
        break;
        case "CHANGE_CASE_TYPE":
          this.$refs["actionsPopup"].changeCaseType();
          break;
        case "ASSIGN_CASE_NUMBER":
          this.$refs["actionsPopup"].assignCaseNumber();
         
          break;
        case "EDIT_QUESTIONNAIRE":
          this.editQuestionnaire();
          break;
        case "SUBMIT_CASE":
          //[4,7].indexOf(this.petitionDetails['lcaDetails']['statusDetails']['id'])<=-1
            if((this.petitionDetails.lcaId == null || (this.petitionDetails.lcaId && [99].indexOf(this.petitionDetails['lcaDetails']['statusDetails']['id'])>-1 )  ) && this.isLcaRequiredForPetition && !isPermCase  ){
            this.showToster({message:"LCA should be either Request/Submit/Link in order to submit the case." ,isError: true});
            this.$store.dispatch("setPetitionTab" , 'LCA')
            return false
          }  
          
          this.$refs["actionsPopup"].opensubmitToLawFirm();
          break;
        case "PREMIUM_PROCESS":
        case "NORMAL_PROCESS":
        this.$refs["actionsPopup"].openpremiumProcessing();
        break;
        case "LINK_PERM":
        this.$refs["actionsPopup"].openLinkPerm();
        break;
        case "DELETE_PWD":
          this.$refs["actionsPopup"].opendeletePwdModal();
        
        break;
        case "LINK_PWD":
        this.$refs["actionsPopup"].openLinkPwd();
        break;
        case "LINK_140":
        this.$refs["actionsPopup"].openLink140();
        break;
        case "UPDATE_INTERNAL_STATUS":
        this.$refs["actionsPopup"].openupdateInternalStatusModal();
        break;
        case "UPDATE_LCA":
        this.$refs["actionsPopup"].openupdateLCA();
        break;
        case "UPDATE_DEADLINE":
        this.$refs["actionsPopup"].opencaseDeadlinePopup();
        break;
        case "APPROVE_DOCUMENTS":
          this.$refs["actionsPopup"].opendocumentApproveRejectPopup('APPROVE_OR_REJECT_DOCUMENTS');
          break;
        case "SEND_DOCUMENTS":
          this.$refs["actionsPopup"].opendocumentApproveRejectPopup('UPLOAD_BY_DOC_EXECUTIVE');
          break;  
        
        case "REQUEST_BENEFICIARY_SIGN":
          let formsLettersType ="Dependent";
          if([2,10].indexOf(this.checkProperty(this.petitionDetails, 'type')) >-1 ){
            formsLettersType = 'Beneficiary'

          }
          
          if(this.formsAndLettersList && this.formsAndLettersList.length == 0 || !this.checkActiveFormsAndLetters(formsLettersType)){
            let msg ="Required at least one dependent form or letter to send for signature."
            if([2,10].indexOf(this.checkProperty(this.petitionDetails, 'type')) >-1 ){
              msg ="Required at least one beneficiary form or letter to send for signature."
            }
            this.showToster({  message:msg, isError: true, });
            this.getFormsAndLetters(false)
            this.$emit("updatepetition", "Forms and Letters");
            
              return false;
          }
          this.$refs["actionsPopup"].opensendforBenSignModal('REQUEST_BENEFICIARY_SIGN');
          break;
        case "UPLOAD_BENEFICIARY_SCANNED_COPY":
          this.$refs["actionsPopup"].openSignedDocumentModel('UPLOAD_BENEFICIARY_SCANNED_COPY');
         break;
      
        case "RFE_REQUEST_PETITIONER_SIGN":
        case "REQUEST_PETITIONER_SIGN":
         if( this.checkProperty(this.petitionDetails,'typeDetails','id')==9 || ( [1].indexOf(this.checkProperty(this.petitionDetails,'typeDetails','id'))>-1 && this.checkProperty(this.workFlowDetails ,'manageRfeCase') =='with_in_case' && menuItem.code=='RFE_REQUEST_PETITIONER_SIGN') ){
         
              if(this.checkProperty(this.petitionDetails,'caseDocs') && this.checkProperty(this.petitionDetails['caseDocs'],'rfeResDocs','length') >0 ){
                
                this.$refs["actionsPopup"].openReferesponsePopUp(menuItem.code);
              }else{
              // 'Upload atleast one document'
              this.$refs["actionsPopup"].openReferesponsePopUp(menuItem.code);
              this.showToster({ message:'Upload atleast one RFE Response document' , isError: true})
              }
            
            break
        }else{
            this.getRoleslist(menuItem.code);
            //this.getFormsAndLetters(true);
            
            if(this.formsAndLettersList && this.formsAndLettersList.length == 0 || !this.checkActiveFormsAndLetters('Beneficiary')){
              this.showToster({
                message:
                  "Required at least one beneficiary form or letter to send for signature.",
                isError: true,
              });
              this.getFormsAndLetters(false)
              this.$emit("updatepetition", "Forms and Letters");
              
                return false;
            }  
          this.$refs["actionsPopup"].opensendforSignModal(this.rolesList);
         }
       
        break;
        case "GENERATED_SIGNED_DOCS":
          
          //alert('Generate Signed Documents');
          if(this.allFormsAndLettersList.length >0){
            this.$refs["actionsPopup"].openGenerateSingedDocs();
          }else{
            this.showToster({  message: "Required at least one form or letter to generate signed documents.",  isError: true,  });
            this.$emit("updatepetition", "Forms and Letters");

          }
          
          return true;
          break;
        case "ASSIGN_CASE_APPROVER":
        case "ASSIGN_SUPERVISOR":
        case "ASSIGN_PARALEGAL":
        case "ASSIGN_DOCUMENTATION_MANAGER":
        case "ASSIGN_ATTORNEY":   
        case "ASSIGN_DOCUMENTATION_EXECUTIVE":
        case "ASSIGN_LCA_EXECUTIVE":
        case "RFE_CASE_APPROVED":  
        case "CASE_APPROVED":
           //alert(JSON.stringify(menuItem));
           if( this.checkProperty(this.petitionDetails,'typeDetails','id')==9 && menuItem.code=='CASE_APPROVED' && false){
              if(this.checkProperty(this.petitionDetails,'caseDocs') && this.checkProperty(this.petitionDetails['caseDocs'],'rfeResDocs','length') >0 ){
                this.$refs["actionsPopup"].openReferesponsePopUp();
              }else{
              // 'Upload atleast one document'
              this.$refs["actionsPopup"].openReferesponsePopUp();
              this.showToster({ message:'Upload atleast one RFE Response document' , isError: true})
              }
            
            break
           }else{
          
            this.getRoleslist(menuItem.code)
            let popUpTitle = menuItem.popUpTitle;

            //Approve Response Docs
            if((this.checkProperty(this.petitionDetails,'typeDetails','id')==9 && menuItem.code=='CASE_APPROVED') || ( [1].indexOf(this.checkProperty(this.petitionDetails,'typeDetails','id'))>-1 && menuItem.code=='RFE_CASE_APPROVED' && this.checkProperty(this.workFlowDetails ,'manageRfeCase') =='with_in_case' ) ){
              popUpTitle ="Approve Response Docs";
            }else  if(["CASE_APPROVED",'RFE_CASE_APPROVED'].indexOf(menuItem.code)>-1){
              popUpTitle ="Complete Review"
            }
            if( this.checkProperty(this.petitionDetails,'typeDetails','id')==3 && [16,17].indexOf(this.checkProperty(this.petitionDetails ,'subTypeDetails','id' ) )>-1){
              
              popUpTitle ="Paralegal Review";
              
              
              if(menuItem.code =="CASE_APPROVED"){
                  popUpTitle ="Paralegal Review";
              }
              //alert("sfg sdfhs djfs");
            }
            this.$refs["actionsPopup"].openassignActivityPopup(this.rolesList,popUpTitle,menuItem.popUpTitle.replace("Assign ",''),menuItem.code);
          }
            break
       
        case "SUPERVISOR_FORMS_REVIEW":
          this.$refs["actionsPopup"].openassignActivityPopup([],'Supervisory Review','Supervisory Review',menuItem.code);
    
        break; 
        case "RFE_SUBMIT_TO_USCIS":
        case "SUBMIT_TO_USCIS":
          /*
          this.getScannedCopyList();
      this.getScannedCopyList('Petitioner');
      this.getScannedCopyList('Beneficiary');
       petitionerScannedCopyList:[],
    beneficiaryScannedCopyList:[],
    scannedCopyList:[],
          */
          if( this.checkProperty(this.petitionDetails,'typeDetails','id')==3 && [16].indexOf(this.checkProperty(this.petitionDetails ,'subTypeDetails','id' ) )>-1  ){
                 if(!this.checkProperty(this.petitionDetails ,'permId')){

                      if(!this.checkProperty(this.petitionDetails ,'jobDetails' ,'jobTitle')){

                      this.$store.dispatch("setPetitionTab", 'PERM-INFO');
                      // this.$emit("updatepetition" ,'PERM-INFO');
                      this.showToster({message:"Job Details are required",isError:true });

                      }else{
                        this.checkInvoiceForSubmitUscis(menuItem);

                      }

                 }else{
                  this.checkInvoiceForSubmitUscis(menuItem);

                 }
          }else{

            if( [1].indexOf(this.checkProperty(this.petitionDetails,'typeDetails','id'))>-1 && this.checkProperty(this.workFlowDetails ,'manageRfeCase') =='with_in_case' && menuItem.code=='RFE_SUBMIT_TO_USCIS'){
              if(this.petitionerScannedCopyList.length <= 0 && !isAdmin ){

              this.showToster({message:"Required at least one Petitioner scanned document to submit to USCIS.", isError: true, });
              this.getScannedCopyList();
              this.getScannedCopyList('Petitioner');
              this.getScannedCopyList('Beneficiary');
              this.$emit("updatepetition", "Scanned Documents");
              return false;
            }
            this.checkInvoiceForSubmitUscis(menuItem);

            }else if(this.checkProperty(this.petitionDetails,'type')==9){
              //check Petitioner sign required or not
              
              if(this.checkWorkActivityisRequires('REQUEST_PETITIONER_SIGN')){

                if(this.petitionerScannedCopyList.length <= 0 && !isAdmin ){
           
                    this.showToster({message:"Required at least one Petitioner scanned document to submit to USCIS.", isError: true, });
                    this.getScannedCopyList();
                    this.getScannedCopyList('Petitioner');
                    this.getScannedCopyList('Beneficiary');
                    this.$emit("updatepetition", "Scanned Documents");
                    return false;
                }
                this.checkInvoiceForSubmitUscis(menuItem);

              }else{
                this.checkInvoiceForSubmitUscis(menuItem);
              }
              

            }else{

              //this.beneficiaryScannedCopyList
              if([2,10].indexOf(this.checkProperty(this.petitionDetails,'typeDetails','id'))>-1   ){
                  let msg = "Required at least one Beneficiary scanned document to submit to USCIS."
                  if(!this.checkProperty(this.petitionDetails,'petitionerId') && this.beneficiaryScannedCopyList.length <= 0 && !isAdmin ){
                    this.showToster({message:msg, isError: true, });
                    this.getScannedCopyList('Beneficiary');
                    return false;
                  }else  if(this.checkProperty(this.petitionDetails,'petitionerId') && this.petitionerScannedCopyList.length <= 0 && !isAdmin ){
                    let msg = "Required at least one Petitioner scanned document to submit to USCIS."
                    this.showToster({message:msg, isError: true, });
                    this.getScannedCopyList('Petitioner');
                    this.getScannedCopyList('Beneficiary');
                    return false;
                  }
                 

                }else if(this.petitionerScannedCopyList.length <= 0 && !isAdmin ){
                let msg = "Required at least one Petitioner scanned document to submit to USCIS."
                
           
                  this.showToster({message:msg, isError: true, });
                    this.getScannedCopyList();
                    this.getScannedCopyList('Petitioner');
                    this.getScannedCopyList('Beneficiary');

                  
                  
                  this.$emit("updatepetition", "Scanned Documents");
                  return false;
              }
              this.checkInvoiceForSubmitUscis(menuItem);
            }
           

          }
          break

        case "RE_ASSIGN":
          
          this.getRoleslist("SUBMIT_TO_USCIS")
          this.$refs["actionsPopup"].openReassignActivityPopup(this.rolesList,"Reassign","Reassign","RE_ASSIGN");
          break;
        case "BACK_TO_ASSIGN":
          
          this.getRoleslist("SUBMIT_TO_USCIS")
          this.$refs["actionsPopup"].openReassignActivityPopup(this.rolesList,"Report Back","Report Back","BACK_TO_ASSIGN");
          break;
          
        case "CREATE_JOB_DESC":
          this.$refs["actionsPopup"].openJobDescription('CREATE_JOB_DESC');
           break;
        case "SUGGEST_JOB_DESC_EDIT":
            this.suggestJobDesc(false);
        break;
        case "EDIT_JOB_DESC":
            let activityCode =  "JOB_DESC_SUGGESSION";
            if(['JOB_DESC_SUGGESSION','INTERNAL_JOB_DESC_SUGGESSION'].indexOf(this.checkProperty(this.petitionDetails ,'curWorkflowActivity')) >-1){
              activityCode  =this.checkProperty(this.petitionDetails ,'curWorkflowActivity');
            }
           
           this.$refs["actionsPopup"].openUpdateJdModal(activityCode);
           break;

        case "APPROVE_JOB_DESC_EDIT":
        //jobdescriptionapprovallisteditors   
      

        this.suggestJobDesc(true);
        break;
            // this.$refs["actionsPopup"].openJobDescription('JOB_DESC_SUGGESSION');
            //this.suggestOrEditJobDescription =true;
        
      case "REQUEST_JOB_DESC_REVIEW":
          this.$refs["actionsPopup"].openPermJobDescActionsModal('REQUEST_JOB_DESC_REVIEW');
           break;
      case "JOB_DESC_SUGGESSION":
          //this.$refs["actionsPopup"].openPermJobDescActionsModal('JOB_DESC_SUGGESSION');
          this.$refs["actionsPopup"].openJobDescription('JOB_DESC_SUGGESSION');
           break;
      case "INTERNAL_REQUEST_JOB_DESC_REVIEW":
        this.$refs["actionsPopup"].openPermJobDescActionsModal('INTERNAL_REQUEST_JOB_DESC_REVIEW');
         break     
      case "INTERNAL_APPROVE_JOB_DESC":
          this.$refs["actionsPopup"].openPermJobDescActionsModal('INTERNAL_APPROVE_JOB_DESC');
           break;     
          
      case "APPROVE_JOB_DESC":
          this.$refs["actionsPopup"].openPermJobDescActionsModal('APPROVE_JOB_DESC');
           break;
      case "JOB_DESC_APPROVE_OR_SUGGESSION":
          this.$refs["actionsPopup"].openPermJobDescActionsModal('JOB_DESC_APPROVE_OR_SUGGESSION');
           break;   
             
      case "FINALIZE_JOB_DESC":
          this.$refs["actionsPopup"].openPermJobDescActionsModal('FINALIZE_JOB_DESC');
           break;  
      case "UPLOAD_PWD_DOCS":
          this.$refs["actionsPopup"].openUploadPwdDocuments('UPLOAD_PWD_DOCS');
           break;  
    
           
                      
      case "COLLECT_ADV_EVIDENCE":
          if (this.checkProperty(this.petitionDetails, "questionnaireFilled")) {
            this.$refs["actionsPopup"].openPermAdvrtisementModal();
          }else{
            this.showToster(
              { 
                 message:  "Questionnaire Not Submitted Yet",
                isError: true,
          });
            
          }
          break;
      case "COLLECT_ADV_EVIDENCE_EDIT":
          this.showPermInfoPopup()
          
          break;
          
      case "EFILE_PWD_DOL":
          this.$refs["actionsPopup"].openPwdEfilingDOL();
          break;  
      case "EFILE_PWD":
          this.$refs["actionsPopup"].openPwdEfiling();
          break;
      case "UPDATE_PWD_RESPONSE":
          this.$refs["actionsPopup"].openUpdatePwdResponse();
          break;
      case "SUBMIT_RFI_RESPONSE":
          this.$refs["actionsPopup"].openPermJobDescActionsModal('SUBMIT_RFI_RESPONSE');
           break;    
      case "UPDATE_PWD_RESPONSE_WITH_JD":
          if(this.checkProperty( this.petitionDetails ,'pwdStatus') =='Filed--' ){
            this.$refs["actionsPopup"].openUpdatePwdResponse(); //Update PWD Response
          }else{
            this.$refs["actionsPopup"].openUpdatePwdResponseWithJd('UPDATE_PWD_RESPONSE_WITH_JD');
          }
         
          break;  
      case "INITIATE_REMINDER": 
          
          this.$refs["actionsPopup"].openInitiatePaymentPopup('INITIATE_REMINDER');
          break;  
      case "FILING_FEE":
          this.$emit('openFilingFee');
          break
      case "ADD_PAYMENT": 
          
          this.$refs["actionsPopup"].openaddPaymentPopup('ADD_PAYMENT');
          break; 
      case "PREPARE_PERM_APPLICATION":
          // this.checkAdvValidation =false;
          // this.checkInvoiceFroPreparePerm()
          //this.checKPreParePermApplicationAdvRestriction()
          if (this.checkProperty(this.petitionDetails, "questionnaireFilled")) {
            this.editQuestionnaire('PREPARE_PERM_APPLICATION');
          }else{
            this.showToster(
              { 
                 message:  "Questionnaire Not Submitted Yet",
                isError: true,
          });
            
          }
         
         
          break;
      case "PERM_DRAFT_SUGGESSION":
          //this.editQuestionnaire('PERM_DRAFT_SUGGESSION');
          this.$refs["actionsPopup"].openPermJobDescActionsModal('PERM_DRAFT_SUGGESSION');
          break;
      case "PERM_DRAFT_SUGGESSION_EDIT":
          this.editQuestionnaire('PERM_DRAFT_SUGGESSION');
         // this.$refs["actionsPopup"].openpreparePerForm();
          break;  
      case "APPROVE_PERM_APPLICATION":
          if (this.checkProperty(this.petitionDetails, "questionnaireFilled")) {
            this.$refs["actionsPopup"].openPermJobDescActionsModal('APPROVE_PERM_APPLICATION');
          }else{
              this.showToster(
                { 
                  message:  "Questionnaire Not Submitted Yet",
                  isError: true,
            });
              
          }
        
          //approvePermApplication
          break;    
      case "EFILE_PREM_APPLICATION":
            this.checkAdvValidation =false;
            this.checkInvoiceFroPreparePerm();
            //this.efilePermApplicationRestriction();
            
          break;
      case "EFILE_PREM_APPLICATION_DRAFT":
          this.$refs["actionsPopup"].openPerDraftForm('EFILE_PREM_APPLICATION_DRAFT');
          break;  
      case "REQUEST_PERM_DRAFT_REVIEW":
          this.$refs["actionsPopup"].openPerDraftForm('REQUEST_PERM_DRAFT_REVIEW');
          break;
      case 'UPLOAD_PERM_ACK': 
          this.$refs["actionsPopup"].openPermJobDescActionsModal('UPLOAD_PERM_ACK');
          break;
      case "SUBMIT_TO_DOL":

          if (this.checkProperty(this.petitionDetails, "questionnaireFilled")) {
            this.$refs["actionsPopup"].openPermJobDescActionsModal('SUBMIT_TO_DOL');
          }else{
              this.showToster(
                { 
                  message:  "Questionnaire Not Submitted Yet",
                  isError: true,
            });
              
          }
          
          
          break;
      case "ACCOUNTANT_APPORVAL_REQUEST":
          
          this.$refs["actionsPopup"].openPermJobDescActionsModal('ACCOUNTANT_APPORVAL_REQUEST');
          break;  
      case "ACCOUNTANT_APPORVAL_GRANT":
          
          this.$refs["actionsPopup"].openPermJobDescActionsModal('ACCOUNTANT_APPORVAL_GRANT');
          break;  
      case "DOL_AUDIT":
            this.$refs["actionsPopup"].openpermDollResponseModal('UPDATE_DOL_RESPONSE');
            break;
      case "PREPARE_AUDIT_RESPONSE":
             this.$route['params']['tabname'] ="Forms and Letters"
             this.$emit("updatepetition", "set_Forms and Letters");
             this.$emit("opengenFormsAndLatters", "opengenFormsAndLatters");
             break;
      case "DOL_SUPERVISORY_AUDIT":
            this.$refs["actionsPopup"].openpermDollResponseModal('DOL_SUPERVISORY_AUDIT');
            break;  
      case "UPDATE_DOL_RESPONSE":
          this.$refs["actionsPopup"].openpermDollResponseModal('UPDATE_DOL_RESPONSE');
          break;  
      case "FILE_I140":  
       this.$refs["actionsPopup"].openi140();

       break;  
      case "UPLOAD_SIGNED_DOCUMENTS":
        this.$refs["actionsPopup"].openSignedDocumentModel('UPLOAD_SIGNED_DOCUMENTS');
        break;

      
      case "COURIER_TRACKING":
        this.$refs["actionsPopup"].openTrackingModel("COURIER_TRACKING");
        break;  
      case "UPDATE_USCIS_RECEIPT_NUMBER":
        this.$refs["actionsPopup"].openTrackingModel("UPDATE_USCIS_RECEIPT_NUMBER");
        break;
      case "RFE_UPDATE_USCIS_RESPONSE":
      case "UPDATE_USCIS_RESPONSE":
        this.$refs["actionsPopup"].openuscisresponse(menuItem.code);
        break;
      case "RFE_UPDATE_USCIS_RESPONSE_H4EAD":   
      case "UPDATE_USCIS_RESPONSE_H4EAD":
        this.$refs["actionsPopup"].openuscisresponseH4HEAD('h4EADRequired',menuItem.code);
        break;
      case "RFE_UPDATE_USCIS_RESPONSE_H4":
      case "UPDATE_USCIS_RESPONSE_H4":
        this.$refs["actionsPopup"].openuscisresponseH4HEAD('h4Required' ,menuItem.code);
        break;
      case "LINK_LCA":
          if(this.checkProperty( this.petitionDetails ,'lcaId')){
            this.getFormsAndLetters(false,'LINK_LCA');
          }else{
            
            this.$refs["actionsPopup"].openLinkLCA();

          }
       
        break;
      case "RFE_PREPARE_RESPONSE_DOCS":
        this.$refs["actionsPopup"].openRefePrepareResDocsPopUp('RFE_PREPARE_RESPONSE_DOCS');
        break;
      case "RFE_REVIEW_RESPONSE_DOCS":
        this.$refs["actionsPopup"].openRefePrepareResDocsPopUp('RFE_REVIEW_RESPONSE_DOCS');
        break;
      case "RFE_COURIER_TRACKING":
        this.$refs["actionsPopup"].openTrackingModel("RFE_COURIER_TRACKING");
        break;
      case "RFE_UPDATE_USCIS_RECEIPT_NUMBER":
        this.$refs["actionsPopup"].openTrackingModel("RFE_UPDATE_USCIS_RECEIPT_NUMBER");
        break;    

        default:
      }
    },
    processMenuItems(){

      /*
  UPDATE_USCIS_RESPONSE
UPDATE_USCIS_RESPONSE_H4EAD
UPDATE_USCIS_RESPONSE_H4


 // {
      //   code: "UPDATE_USCIS_RESPONSE_H4",
      //   name: "Update USCIS Status H4",
      //    actionLable: "Update USCIS Status H4",
      //   forAdmins: true,
      //   roleIds: [3, 4],
      // },
      // {
      //   code: "UPDATE_USCIS_RESPONSE_H4EAD",
      //   name: "Update USCIS Status-H4 EAD",
      //    actionLable: "Update USCIS Status-H4EAD",
      //   forAdmins: true,
      //   roleIds: [3, 4],
      // },

      */
     let UPDATE_USCIS_RESPONSE_H4 = { code: "UPDATE_USCIS_RESPONSE_H4",  name: "Update USCIS Status H4",  actionLable: "Update USCIS Status H4",
        forAdmins: true,   roleIds: [3, 4],
      };
      let UPDATE_USCIS_RESPONSE_H4EAD = {
         code: "UPDATE_USCIS_RESPONSE_H4EAD", 
          name: "Update USCIS Status H4 EAD",
            actionLable: "Update USCIS Status H4 EAD",
          forAdmins: true, roleIds: [3, 4], 
         }
      let list = _.cloneDeep(this.menuItems); 
      let tempList =[]                                  
       _.map(list ,(item)=>{

        if(item['code']=='UPLOAD_BENEFICIARY_SCANNED_COPY'){
          if([51].indexOf(this.getUserRoleId)>-1){
            item.name= "Upload Signed Documents";
             item.actionLable= "Upload Signed Documents";
          }

        }

        if(item['code'] =='REQUEST_PETITIONER_SIGN'){
          item.name= "Send For Petitioner Signature";
          item.actionLable= "Send For Petitioner Signature";
        }
        if(item['code'] =='REQUEST_BENEFICIARY_SIGN'){
          item.name= "Send For Beneficiary Signature";
          item.actionLable= "Send For Beneficiary Signature";
        }
        

          if( item['code']=='CREATE_JOB_DESC' && this.petitionDetails.completedActivities.indexOf('CREATE_JOB_DESC')>-1){

          item.name= "Update Job Description";
          item.actionLable= "Update Job Description";

          }

          if( item['code']=='FILING_FEE' && this.checkProperty(this.petitionDetails ,'invoiceId' )){

          item.name= "Edit Filing Fees";
          item.actionLable= "Edit Filing Fees";

          }



          if( item['code']=='UPDATE_USCIS_RESPONSE' && this.checkProperty(this.petitionDetails ,'uploadUscisDocs' ) !=true && this.checkProperty(this.petitionDetails ,'autoUscisStatusUpdate' )==true){

          item.name= "Upload USCIS Documents";
          item.actionLable= "Upload USCIS Documents";

          }
         

          if( item['code']=='CASE_APPROVED' && (this.checkProperty(this.petitionDetails ,'typeDetails','id' )==3 && [16,17].indexOf(this.checkProperty(this.petitionDetails ,'subTypeDetails','id' ) )>-1 )){

            item.name= "Paralegal Review";
            item.actionLable= "Paralegal Review";

          }

           tempList.push(item);
          if(item['code']=='UPDATE_USCIS_RESPONSE'){
            tempList.push(UPDATE_USCIS_RESPONSE_H4)
            tempList.push(UPDATE_USCIS_RESPONSE_H4EAD)

            if( [1].indexOf(this.checkProperty(this.petitionDetails,'typeDetails','id'))>-1 && this.checkProperty(this.workFlowDetails ,'manageRfeCase') =='with_in_case'){

               if(!_.find(tempList,{'code':'RFE_UPDATE_USCIS_RESPONSE_H4'})){
                 
                  let tmpAction = _.cloneDeep(UPDATE_USCIS_RESPONSE_H4EAD);
                  tmpAction['code'] = 'RFE_UPDATE_USCIS_RESPONSE_H4';
                  tempList.push(tmpAction)

               }
               if(!_.find(tempList,{'code':'RFE_UPDATE_USCIS_RESPONSE_H4EAD'})){
                   let tmpAction = _.cloneDeep(UPDATE_USCIS_RESPONSE_H4EAD);
                   tmpAction['code'] = 'RFE_UPDATE_USCIS_RESPONSE_H4EAD'
                  tempList.push(tmpAction)

               }
            }
  
          }


          })

         this.menuItems = _.cloneDeep(tempList);
    }
  },
  mounted() {
    /*
    PERM StatusId Mapping - 
            1-1,
            2-2,
            3-14,
            4-15,
            5-16,
            6-17
            7-18
            8-19
            9-20
            10-21
            11-22
            12-23
            13-27
            14-28

    H1B, 140, 485 StatusId Mapping - 
            1-1,
            2-2,
            3-3,
            4-4,
            5-8,
            6-9
            7-12
            8-13
            9-22
            10-23
            11-24
            12-25
            13-26
            14-31
    */
   

    let adminsactiVityList = _.find(this.workFlowDetails.config , {"code":'MANAGER_LIST'});
    if(adminsactiVityList && adminsactiVityList.editors){
    this.adminsList = _.map(adminsactiVityList.editors, 'roleId');
    }

    let recevieractiVityList = _.find(this.workFlowDetails.config , {"code":'ASSIGN_SUPERVISOR'});
    if(recevieractiVityList && recevieractiVityList.canAssignAllUsers == "Yes"){
      this.canAssignAllatonce = true;
    }
    if(recevieractiVityList && recevieractiVityList.editors){
    this.recevierList = _.map(recevieractiVityList.editors, 'roleId');
    }


    let petitionersactiVityList = _.find(this.workFlowDetails.config , {"code":'CREATE_PETITION'});
    if(petitionersactiVityList && petitionersactiVityList.editors){
    this.petitionersList = _.map(petitionersactiVityList.editors, 'roleId');
    }
    //internamJobDesApprove:[],INTERNAL_APPROVE_JOB_DESC
    this.internamJobDesApproveRequired = false;
    let internamJobApprove = _.find(this.workFlowDetails.config , {"code":'INTERNAL_APPROVE_JOB_DESC',"actionRequired":"Yes"});
    if(internamJobApprove && internamJobApprove.editors){
     // this.adminsList
       this.internamJobDesApprove = _.map(internamJobApprove.editors, 'roleId');
       this.internamJobDesApproveRequired =true;
      
       
    }


    let beneficiarysactiVityList = _.find(this.workFlowDetails.config , {"code":'SUBMIT_BY_BENEFICIARY'});
    if(beneficiarysactiVityList && beneficiarysactiVityList.editors){
    this.beneficiarysList = _.map(beneficiarysactiVityList.editors, 'roleId');
    }
    let lcarequestactiVityList = _.find(this.workFlowDetails.config , {"code":'LCA_REQUEST' ,"actionRequired":'Yes'});
    if(lcarequestactiVityList && lcarequestactiVityList.editors){
    this.lcarequestList = _.map(lcarequestactiVityList.editors, 'roleId');
    }

    let lcasubmitactiVityList = _.find(this.workFlowDetails.config , {"code":'LCA_SUBMIT',"actionRequired":'Yes'});
    if(lcasubmitactiVityList && lcasubmitactiVityList.editors){
    this.lcasubmitList = _.map(lcasubmitactiVityList.editors, 'roleId');
    }

    

    let assignCaseApprover = _.find(this.workFlowDetails.config , {"code":'ASSIGN_CASE_APPROVER',"actionRequired":'Yes'});
    if(assignCaseApprover && assignCaseApprover.editors){
    this.assignCaseApproverEditors = _.map(assignCaseApprover.editors, 'roleId');
    }

    let caseapproversactiVityList = _.find(this.workFlowDetails.config , {"code":'CASE_APPROVED' });
    if(caseapproversactiVityList && caseapproversactiVityList.editors){
    this.caseapproversList = _.map(caseapproversactiVityList.editors, 'roleId');
    }

      let docmangeractiVityList = _.find(this.workFlowDetails.config , {"code":'ASSIGN_DOCUMENTATION_EXECUTIVE',"actionRequired":'Yes'});
    if(docmangeractiVityList && docmangeractiVityList.editors){
    this.docmangerList = _.map(docmangeractiVityList.editors, 'roleId');
    }
    
    let docmListActivity = _.find(this.workFlowDetails.config , {"code":'ASSIGN_DOCUMENTATION_MANAGER'});
    if(docmListActivity && docmListActivity.editors){
      this.docmList = _.map(docmListActivity.editors, 'roleId');
    }

     let paralegalactiVityList = _.find(this.workFlowDetails.config , {"code":'ASSIGN_PARALEGAL'});
    if(paralegalactiVityList && paralegalactiVityList.editors){
    this.paralegalmanagerList = _.map(paralegalactiVityList.editors, 'roleId');
    }

    let attorneyactiVityList = _.find(this.workFlowDetails.config , {"code":'ASSIGN_ATTORNEY' ,"actionRequired":'Yes'});
    if(attorneyactiVityList && attorneyactiVityList.editors){
    this.attorneymanagerList = _.map(attorneyactiVityList.editors, 'roleId');
    }

    let caseApprovalactiVityList = _.find(this.workFlowDetails.config , {"code":'CASE_APPROVED'});
    if(caseApprovalactiVityList && caseApprovalactiVityList.editors){
    this.caseApprovalList = _.map(caseApprovalactiVityList.editors, 'roleId');
    }

    
    let signrequesttersactiVityList = _.find(this.workFlowDetails.config , {"code":'REQUEST_PETITIONER_SIGN'});
    if(signrequesttersactiVityList && signrequesttersactiVityList.editors){
    this.signerRequestersList = _.map(signrequesttersactiVityList.editors, 'roleId');
    }

    this.signersList =[];
   if(this.getTenantTypeId ==2){
    let signersActiVityList = _.find(this.workFlowDetails.config , {"code":'DOC_SIGNER_LIST'});
    if(signersActiVityList && signersActiVityList.editors){
      this.signersList = _.map(signersActiVityList.editors, 'roleId');
    }
  }

      let submitUSCISactiVityList = _.find(this.workFlowDetails.config , {"code":'SUBMIT_TO_USCIS'});
    if(submitUSCISactiVityList && submitUSCISactiVityList.editors){
    this.submitUSCISList = _.map(submitUSCISactiVityList.editors, 'roleId');
    }

     let submitTrackingactiVityList = _.find(this.workFlowDetails.config , {"code":'COURIER_TRACKING'});
    if(submitTrackingactiVityList && submitTrackingactiVityList.editors){
    this.submitTrackingList = _.map(submitTrackingactiVityList.editors, 'roleId');
    }

     let submitUSCISReceiptactiVityList = _.find(this.workFlowDetails.config , {"code":'UPDATE_USCIS_RECEIPT_NUMBER'});
    if(submitUSCISReceiptactiVityList && submitUSCISReceiptactiVityList.editors){
    this.submitUSCISReceiptList = _.map(submitUSCISReceiptactiVityList.editors, 'roleId');
    }

    let submitUSCISResponseactiVityList = _.find(this.workFlowDetails.config , {"code":'UPDATE_USCIS_RESPONSE'});
    if(submitUSCISResponseactiVityList && submitUSCISResponseactiVityList.editors){
    this.submitUSCISResponseList = _.map(submitUSCISResponseactiVityList.editors, 'roleId');
    }

    this.supervisorFormsReviewEditors =[];   //i-140 SUPERVISOR_FORMS_REVIEW 
    let supervisorFormsReviewEditors = _.find(this.workFlowDetails.config , {"code":'SUPERVISOR_FORMS_REVIEW'});
    if(supervisorFormsReviewEditors && supervisorFormsReviewEditors.editors){
    this.supervisorFormsReviewEditors = _.map(supervisorFormsReviewEditors.editors, 'roleId');
    }

    if(this.checkProperty(this.workFlowDetails ,'manageRfeCase') =='with_in_case'){
          /*
        
        prePareRfeResDocsEditors:[], //RFE_PREPARE_RESPONSE_DOCS
        rfeCaseApprovedEditors:[],//RFE_CASE_APPROVED
        rfeReqPetEditors:[],//RFE_REQUEST_PETITIONER_SIGN // OR RFE_DOC_SIGNER_LIST
        rfeSubmitToUscisEditors:[],//RFE_SUBMIT_TO_USCIS
        rfeUpdateUscisEditors:[],//RFE_UPDATE_USCIS_RESPONSE
        */
          this.prePareRfeResDocsEditors =[];
          let prePareRfeResDocsEditors = _.find(this.workFlowDetails.config , {"code":'RFE_PREPARE_RESPONSE_DOCS' ,"actionRequired":'Yes'});
          if(prePareRfeResDocsEditors && prePareRfeResDocsEditors.editors){
            this.prePareRfeResDocsEditors = _.map(prePareRfeResDocsEditors.editors, 'roleId');
          }

          this.rfeCaseApprovedEditors =[];
          let rfeCaseApprovedEditors = _.find(this.workFlowDetails.config , {"code":'RFE_CASE_APPROVED' ,"actionRequired":'Yes'});
          if(rfeCaseApprovedEditors && rfeCaseApprovedEditors.editors){
            this.rfeCaseApprovedEditors = _.map(rfeCaseApprovedEditors.editors, 'roleId');
          }
          this.rfeCourierTrackingEditors = [];
          let rfeCourierTrackingEditors = _.find(this.workFlowDetails.config , {"code":'RFE_COURIER_TRACKING' ,"actionRequired":'Yes'});
          if(rfeCourierTrackingEditors && rfeCourierTrackingEditors.editors){
            this.rfeCourierTrackingEditors = _.map(rfeCourierTrackingEditors.editors, 'roleId');
          }
        
          this.updateRfeUscisReceiptNumberEditors = [];
          let updateRfeUscisReceiptNumberEditors = _.find(this.workFlowDetails.config , {"code":'RFE_UPDATE_USCIS_RECEIPT_NUMBER' ,"actionRequired":'Yes'});
          if(updateRfeUscisReceiptNumberEditors && updateRfeUscisReceiptNumberEditors.editors){
            this.updateRfeUscisReceiptNumberEditors = _.map(updateRfeUscisReceiptNumberEditors.editors, 'roleId');
          }


          this.rfeReqPetEditors =[];
          if(this.getTenantTypeId !=2){

          
          let rfeReqPetEditors = _.find(this.workFlowDetails.config , {"code":'RFE_REQUEST_PETITIONER_SIGN' ,"actionRequired":'Yes'});
          if(rfeReqPetEditors && rfeReqPetEditors.editors){
            this.rfeReqPetEditors = _.map(rfeReqPetEditors.editors, 'roleId');
          }
          }else{

            this.rfeReqPetEditors =[];
            let rfeReqPetEditors = _.find(this.workFlowDetails.config , {"code":'RFE_DOC_SIGNER_LIST' ,"actionRequired":'Yes'});
            if(rfeReqPetEditors && rfeReqPetEditors.editors){
              this.rfeReqPetEditors = _.map(rfeReqPetEditors.editors, 'roleId');
            }
          }

          this.rfeSubmitToUscisEditors =[];
          let rfeSubmitToUscisEditors = _.find(this.workFlowDetails.config , {"code":'RFE_SUBMIT_TO_USCIS'});
          if(rfeSubmitToUscisEditors && rfeSubmitToUscisEditors.editors){
            this.rfeSubmitToUscisEditors = _.map(rfeSubmitToUscisEditors.editors, 'roleId');
          }

          this.rfeUpdateUscisEditors =[];
          let rfeUpdateUscisEditors = _.find(this.workFlowDetails.config , {"code":'RFE_UPDATE_USCIS_RESPONSE'});
          if(rfeUpdateUscisEditors && rfeUpdateUscisEditors.editors){
            this.rfeUpdateUscisEditors = _.map(rfeUpdateUscisEditors.editors, 'roleId');
          }
    }
    
  




      var _self = this;
        _.forEach(this.workFlowDetails.config ,(item)=>{
          var found = _.find(item.editors , {"roleId":this.getUserRoleId})
          if(_self.checkProperty(_self.petitionDetails ,'reviewCompletedUserIds' )){
            var completed = _self.petitionDetails.reviewCompletedUserIds.indexOf(_self.$store.state.user.userId) 
            if(item.confirmRequired == "Yes" && found && completed < 0){
              _self.confirmrequried = true;
            }
            if(item.confirmRequired == "Yes" && found ){
                this.confirmrequriedchecked = true;
            }
          }
        });

      
    //Perm Veriables


    /*
    permJobDesEditorsList
    reqJobDesReview:[],
    
    permJobApprove:[],
    finnailizePermJob:[],
    
    */
    let permJobDesEditorsList = _.find(this.workFlowDetails.config , {"code":'CREATE_JOB_DESC'});
    if(permJobDesEditorsList && permJobDesEditorsList.editors){
    this.permJobDesEditorsList = _.map(permJobDesEditorsList.editors, 'roleId');
    }

    let reqJobDesReview = _.find(this.workFlowDetails.config , {"code":'REQUEST_JOB_DESC_REVIEW'});
    if(reqJobDesReview && reqJobDesReview.editors){
       this.reqJobDesReview = _.map(reqJobDesReview.editors, 'roleId');
    }
    

    let permJobApprove = _.find(this.workFlowDetails.config , {"code":'APPROVE_JOB_DESC'});
    if(permJobApprove && permJobApprove.editors){
       this.permJobApprove = _.map(permJobApprove.editors, 'roleId');
    }

    let finnailizePermJob = _.find(this.workFlowDetails.config , {"code":'FINALIZE_JOB_DESC'});
    if(finnailizePermJob && finnailizePermJob.editors){
       this.finnailizePermJob = _.map(finnailizePermJob.editors, 'roleId');
    }
    


    let jobAdvertismentActivity = _.find(this.workFlowDetails.config , {"code":'COLLECT_ADV_EVIDENCE'});
    if(jobAdvertismentActivity && jobAdvertismentActivity.editors){
      this.approvedPwdReqForAdvEvidences = false;
      if(_.has(jobAdvertismentActivity ,'approvedPwdReqForAdvEvidences') && jobAdvertismentActivity['approvedPwdReqForAdvEvidences'] =='Yes'){
        this.approvedPwdReqForAdvEvidences = jobAdvertismentActivity['approvedPwdReqForAdvEvidences']==='Yes'?true:false;
      }
      this.jobAdvertismentActivity = _.map(jobAdvertismentActivity.editors, 'roleId');
    }
    let pwdEfileActivity = _.find(this.workFlowDetails.config , {"code":'EFILE_PWD'});
    if(pwdEfileActivity && pwdEfileActivity.editors){
      this.pwdEfileActivity = _.map(pwdEfileActivity.editors, 'roleId');
    }
    
    let pwdResponseUpdateActivity = _.find(this.workFlowDetails.config , {"code":'UPDATE_PWD_RESPONSE'});
    if(pwdResponseUpdateActivity && pwdResponseUpdateActivity.editors){
      this.pwdResponseUpdateActivity = _.map(pwdResponseUpdateActivity.editors, 'roleId');
    }
    let preparePermActivity = _.find(this.workFlowDetails.config , {"code":'PREPARE_PERM_APPLICATION'});
    if(preparePermActivity && preparePermActivity.editors){
      this.preparePermActivity = _.map(preparePermActivity.editors, 'roleId');
    }

    let permDraftreview = _.find(this.workFlowDetails.config , {"code":'REQUEST_PERM_DRAFT_REVIEW'});
    if(permDraftreview && permDraftreview.editors){
      _.forEach(permDraftreview.editors ,(editor)=>{
        this.preparePermActivity.push(editor['roleId'])
      });
      
    }

    let permSuggssitionActivity = _.find(this.workFlowDetails.config , {"code":'PERM_DRAFT_SUGGESSION'});
     permSuggssitionActivity = _.find(this.workFlowDetails.config , {"code":'APPROVE_JOB_DESC'});
   if(permSuggssitionActivity && permSuggssitionActivity.editors){
      this.permSuggssitionActivity = _.map(permSuggssitionActivity.editors, 'roleId');
    }

    let approvePermApplication = _.find(this.workFlowDetails.config , {"code":'APPROVE_PERM_APPLICATION'});
    if(approvePermApplication && approvePermApplication.editors){
      this.approvePermApplication = _.map(approvePermApplication.editors, 'roleId');
    }
    
    
    
    let efilePermActivity = _.find(this.workFlowDetails.config , {"code":'EFILE_PREM_APPLICATION'});
    if(efilePermActivity && efilePermActivity.editors){
      this.efilePermActivity = _.map(efilePermActivity.editors, 'roleId');
    }
   
   let requestPermDraftReview = _.find(this.workFlowDetails.config , {"code":'REQUEST_PERM_DRAFT_REVIEW'});
    if(requestPermDraftReview && requestPermDraftReview.editors){
      this.requestPermDraftReview = _.map(requestPermDraftReview.editors, 'roleId');
    }

    let updateDolResponseEditors = _.find(this.workFlowDetails.config , {"code":'UPDATE_DOL_RESPONSE'});
    if(updateDolResponseEditors && updateDolResponseEditors.editors){
      this.updateDolResponseEditors = _.map(updateDolResponseEditors.editors, 'roleId');
    }


    let jobdescriptionapprovallisteditors= _.find(this.workFlowDetails.config , {"code":'APPROVE_JOB_DESC'});

    if(jobdescriptionapprovallisteditors && jobdescriptionapprovallisteditors.editors){
      this.jobdescriptionapprovallist = _.map(jobdescriptionapprovallisteditors.editors, 'roleId');
    }

    //this.petitionDetails.completedActivities.indexOf('CREATE_JOB_DESC')

    

     // enableFilingFee fileAfterInvoice
     this.enableFilingFee = false;
     this.filingEditors =[];
     let filingFeeActivity = _.find(this.workFlowDetails.config , {"code":'FILING_FEE'});
    if(filingFeeActivity && filingFeeActivity.actionRequired == "Yes"){
      this.enableFilingFee = true;
      this.filingEditors =_.map(filingFeeActivity.editors, 'roleId');
    }
    
    this.fileAfterInvoice =false;  //FILE_AFTER_INVOICE
    let FILE_AFTER_INVOICE = _.find(this.workFlowDetails.config , {"code":'FILE_AFTER_INVOICE' ,"actionRequired":"Yes"});
    if(FILE_AFTER_INVOICE && FILE_AFTER_INVOICE.actionRequired=="Yes" && this.enableFilingFee){
       this.fileAfterInvoice = true;
    }
    
   

    this.fileAfterPayment =false;  //FILE_AFTER_INVOICE_PAYMENT
    let FILE_AFTER_INVOICE_PAYMENT = _.find(this.workFlowDetails.config , {"code":'FILE_AFTER_INVOICE_PAYMENT' ,"actionRequired":"Yes"});
    if(FILE_AFTER_INVOICE_PAYMENT && FILE_AFTER_INVOICE_PAYMENT.actionRequired=="Yes" && this.enableFilingFee){
       this.fileAfterPayment = true;
    }
    

   // permAcknowledgementEditors:[],//UPLOAD_PERM_ACKpermAcknowledgementEditors:[],//UPLOAD_PERM_ACK
   this.permAcknowledgementEditors =[];
   let permAcknowledgement = _.find(this.workFlowDetails.config , {"code":'UPLOAD_PERM_ACK' ,"actionRequired":"Yes"});
    if(permAcknowledgement && permAcknowledgement.actionRequired=="Yes" && this.checkProperty(permAcknowledgement ,'editors' ,'length'>0) ){
       this.permAcknowledgementEditors =  _.map(permAcknowledgement.editors, 'roleId');
    }


    this.$store
      .dispatch("getList", {
        data: { category: "WORKFLOW" },
        path: "/messages/list",
      })
      .then((response) => {
        let menuItems = this.menuItems.concat(response.messages.WORKFLOW);
        let UPDATE_INTERNAL_STATUS = _.find(menuItems ,{'code':'UPDATE_INTERNAL_STATUS'});
        if(UPDATE_INTERNAL_STATUS){

          this.menuItems =[];
          _.forEach(menuItems ,(menu)=>{
            if(menu.code !='UPDATE_INTERNAL_STATUS'){
              this.menuItems.push(menu);
            }

          });

          this.menuItems.push(UPDATE_INTERNAL_STATUS);
          
        }else{
          this.menuItems = menuItems;
        }


        this.loaded = true;
       this.processMenuItems();
      })
      .catch((error) => {
        this.processMenuItems();
      });
      this.getFormsAndLetters();
      this.getScannedCopyList();
      this.getScannedCopyList('Petitioner');
      this.getScannedCopyList('Beneficiary');

      /*
       {
        code: "UPDATE_INTERNAL_STATUS",
        //name: "Update Internal Status",
       // actionLable: "Update Internal Status",
       name:"Hold/Abandon/Delete",
       actionLable:'Hold/Abandon/Delete',
        forAdmins: true,
      },
      */

      this.menuItems.map((item)=>{

        if(item.code=="UPDATE_INTERNAL_STATUS" ){
//           if(this.petitionDetails['intStatusId'] !=1){
//             item.actionLable ="Update Internal Status"
//             item.name ="Update Internal Status"
//           }else{
//             if([50].indexOf(this.getUserRoleId) >-1){

//               item.name ="Hold/Abandon Case";
//               item.actionLable ='Hold/Abandon Case';

//             }
// //adminsList.indexOf(this.getUserRoleId) > -1 
//           }
        
          if(this.petitionDetails['intStatusId'] ==1){

           if([50].indexOf(this.getUserRoleId) >-1){

            item.name ="Hold/Abandon Case";
            item.actionLable ='Hold/Abandon Case';

          }
          else if(this.adminsList.indexOf(this.getUserRoleId) > -1  ){
            item.name ="Hold/Abandon/Delete Case";
            item.actionLable ='Hold/Abandon/Delete Case';

          }else{
            item.name ="Hold/Abandon/Delete Case";
            item.actionLable ='Hold/Abandon/Delete Case';

          }
          }else if(this.petitionDetails['intStatusId'] ==2){
            
              if([50].indexOf(this.getUserRoleId) >-1){

              item.name ="Abandon Case";
              item.actionLable ='Abandon Case';

              }else if(this.adminsList.indexOf(this.getUserRoleId) > -1  ){
                 item.name ="Active/Abandon/Delete Case";
                 item.actionLable ='Active/Abandon/Delete Case';

              }else{
                 item.name ="Abandon/Delete Case";
                 item.actionLable ='Abandon/Delete Case';

              }
          }else if(this.petitionDetails['intStatusId'] ==3){
           
            if([50].indexOf(this.getUserRoleId) >-1){

            item.name ="Hold Case";
            item.actionLable ='Hold Case';

            }else if(this.adminsList.indexOf(this.getUserRoleId) > -1  ){
            item.name ="Active/Hold/Delete Case";
            item.actionLable ='Active/Hold/Delete Case';

            }else{
              item.name ="Hold/Delete Case";
              item.actionLable ='Hold/Delete Case';

            }
          }

        }
        if(item.code=="REQUEST_PERM_DRAFT_REVIEW" ){
          if(this.getTenantTypeId==2){
           
               item.name ="Request for PERM Draft Review";
               item.actionLable ='Request for PERM Draft Review';
          }else{

               item.name ="Request Petitioner for PERM Draft Review";
               item.actionLable ='Request Petitioner for PERM Draft Review';

          }


        }

        if(item.code=="REQUEST_JOB_DESC_REVIEW" ){
          if(this.getTenantTypeId==2){
           
               item.name ="Request for Job Description Review";
               item.actionLable ='Request for Job Description Review';
          }else{

               item.name ="Request Petitioner for Job Description Review";
               item.actionLable ='Request Petitioner for Job Description Review';

          }


        }
        //code: "REQUEST_JOB_DESC_REVIEW",
        //name: "Request Petitioner for Job Description Review",
        

      });
      this.getListcat();
     
  },
  data: () => ({
    createRfeError:'',
    createRfeCase:false,
    creatingrfeCase:false,
    petitionerScannedCopyList:[],
    beneficiaryScannedCopyList:[],
    scannedCopyList:[],

    invoicecategoryList:[],
    invoiceNotification:'',
    removedInvoiceItems:[],
    newlyAddInvoiceItems:[],
    loading:false,
    caseNumberIsUpdated:false,
    showConformTocangeLca:false,
    supervisorFormsReviewEditors:[],   //i-140 SUPERVISOR_FORMS_REVIEW 
    enabledApproveJobDsc:false,
    enabledJobDscSuggession:false,
    showPermInfo:false,
    gettingInvoiceStatus:false,
    preparePermInvoiceError:'',
    preparePermApplicationActivity:null,
    checkAdvValidation:false,
    checkAdvValidationMsg:'',
     fileAfterInvoice:false,  //FILE_AFTER_INVOICE
     fileAfterPayment:false, //FILE_AFTER_INVOICE_PAYMENT
    enableAccountantApprovalRequest:false,
    enableAccountantApprovalGrant:false,
    formsAndLettersList:[],
    allFormsAndLettersList:[],
    enableFilingFee:false,
    filingEditors:[],
    avertisementList:[
    
       /*{
          startDateKey:'swaStartDate',
          endDateKey:'swaEndDate',
          documentKey:'jobFair'
        },
        */

        {
          startDateKey:'startDateOfSundayNewsPaper',
          endDateKey:'endDateOfSundayNewsPaper',
          documentKey:'sunday'
        },
        
        {
          startDateKey:'startDateOfAdvAtJobFair',
          endDateKey:'endDateOfAdvAtJobFair',
          documentKey:'jobFair'
        },
        {
          startDateKey:'startDateOfNonCampusRecru',
          endDateKey:'endDateOfNonCampusRecru',
          documentKey:'campusRecruitment'
        },
        {
          startDateKey:'startDateOfEmplrWebsitePosted',
          endDateKey:'endDateOfEmplrWebsitePosted',
          documentKey:'empWebsite'
        },
        {
          startDateKey:'startDateOfAdvWithTradeOrProfOrg',
          endDateKey:'startDateOfAdvWithTradeOrProfOrg',
          documentKey:'profOrgOrTrade'
        },
        {
          startDateKey:'startDateOfAdvEmpRefProgram',
          endDateKey:'endDateOfAdvEmpRefProgram',
          documentKey:'empRefProgram'
        },
        {
          startDateKey:'startDateOfListedInJobSite',
          endDateKey:'endDateOfListedInJobSite',
          documentKey:'jobSearchWebsite'
        },
        {
          startDateKey:'startDateOfListedInPrivateEmpFirm',
          endDateKey:'endDateOfListedInPrivateEmpFirm',
          documentKey:'pvtEmpmtFirm'
        },
        {
          startDateKey:'startDateOfAdvCampusPlacOfc',
          endDateKey:'endDateOfAdvCampusPlacOfc',
          documentKey:'campusPlacement'
        },
        {
          startDateKey:'startDateOfAdvLocalNewsPaper',
          endDateKey:'endDateOfAdvLocalNewsPaper',
          documentKey:'localNewsPaper'
        },
        {
          startDateKey:'startDateOfAdvInTVOrRadio',
          endDateKey:'endDateOfAdvInTVOrRadio',
          documentKey:'tvAds'
        },
      ],
    approvedPwdReqForAdvEvidences:false,
    confirmrequried:false,
    confirmrequriedchecked:false,
    suggestOrEditJobDescription:false,
    rolesList:null,
    adminsList:[3, 4],
    recevierList:[],
    petitionersList:[],
    beneficiarysList:[],
    submittolawfirmList:[],
    lcarequestList:[],
    lcasubmitList:[],
    docmangerList:[],
    docmList:[],
    assignCaseApproverEditors:[],
    caseapproversList:[],
    paralegalmanagerList:[],
    attorneymanagerList:[],
    caseApprovalList:[],
    signerRequestersList:[],
    signersList:[],
    submitUSCISList:[],
    submitTrackingList:[],
    submitUSCISReceiptList:[],
    submitUSCISResponseList:[],
    jobdescriptionapprovallist:[],
    canAssignAllatonce:false,
    showMe:false,
    loaded:false,
    assignmentActivityList:['ASSIGN_CASE_APPROVER','ASSIGN_SUPERVISOR','ASSIGN_PARALEGAL' ,'ASSIGN_DOCUMENTATION_MANAGER' ,'ASSIGN_DOCUMENTATION_EXECUTIVE' ,'ASSIGN_ATTORNEY' ],
    menuItems: [
      {
        code: "CHANGE_CASE_TYPE",
        name: "Change Case Subtype",
        actionLable: "Change Case Subtype",
        forAdmins: true,
        roleIds: [3, 4],
        completedActivities:["SUBMIT_BY_BENEFICIARY","SUBMIT_TO_LAW_FIRM"]
      },
      {
        code: "GENERATE_FORMS",
        name: "Generate Forms and Letters",
        actionLable: "Generate Forms and Letters",
        forAdmins: true,
        roleIds: [3, 4],
        completedActivities:[]
      },
      //Generate
      {
        code: "ASSIGN_CASE_NUMBER",
        name: "Assign Case Number",
        actionLable: "Assign Case Number",
        forAdmins: true,
        roleIds: [3, 4],
        completedActivities:["ASSIGN_CUSTOM_CASE_NO"]
      },
      // {
      //   code: "ASSIGN_CASE_APPROVER",
      //   name: "Assign Case Approver",
      //   actionLable: "Assign Case Approver",
      //   forAdmins: true,
      //   roleIds: [3, 4],
      //   completedActivities:[]
      // },
      
      // {
      //   code: "ASSIGN_LCA_EXECUTIVE",
      //   name: "Assign LCA Ececutive",
      //   actionLable: "Assign LCA Ececutive",
      //   popUpTitle:"Assign LCA Ececutive",
      //   forAdmins: true,
      //   roleIds: [3, 4],
      //   completedActivities:["ASSIGN_LCA_EXECUTIVE"]
      // },
      
      {
        code: "EDIT_QUESTIONNAIRE",
        name: "Edit Questionnaire",
        actionLable: "Edit Questionnaire",
        forAdmins: true,
      },
      //perm Veriables
      {
        code: "CREATE_JOB_DESC",
        name: "Create Job Description",
        actionLable: "Create Job Description",
        roleIds: [3, 4],
        forAdmins: true,
      },

      {
        code: "REQUEST_JOB_DESC_REVIEW",
        name: "Request Petitioner for Job Description Review",
        actionLable: "Request Petitioner for Job Description Review",
        roleIds: [3, 4],
        forAdmins: true,
      },
      {
        code: "JOB_DESC_SUGGESSION",
        name: "Job Description Suggestion ",
        actionLable: "Job Description Suggestion ",
        roleIds: [3, 4],
        forAdmins: true,
      },
      
      {
        code: "INTERNAL_REQUEST_JOB_DESC_REVIEW",
        name: "Request for review of Job Description - Internal",
        actionLable: "Request for review of Job Description - Internal",
        roleIds: [3, 4],
        forAdmins: true,
      },
      {
        code: "INTERNAL_APPROVE_JOB_DESC", //INTERNAL_JOB_DESC_SUGGESSION
        name: "Suggest Changes/Approve Job Description - Internal",
        actionLable: "Suggest Changes/Approve Job Description - Internal",
        roleIds: [3, 4],
        forAdmins: true,
      },
      {
        code: "APPROVE_JOB_DESC",
        name: "Approve Job Description ",
        actionLable: "Approve Job Description",
        roleIds: [3, 4],
        forAdmins: true,
      },
      {
        code: "JOB_DESC_APPROVE_OR_SUGGESSION",
        name: "Suggest Changes / Approve Job Description",
        actionLable: "Suggest Changes / Approve Job Description",
        roleIds: [3, 4],
        forAdmins: true,
      },
      
      {
        code: "EDIT_JOB_DESC",
        name: "Update Job Description",
        actionLable: "Update Job Description",
        roleIds: [3, 4],
        forAdmins: true,
      },
      
      {
        code: "APPROVE_JOB_DESC_EDIT",
        name: "Edit Job Description",
        actionLable: "Edit Job Description",
        roleIds: [3, 4],
        forAdmins: true,
      },
      {
        code: "SUGGEST_JOB_DESC_EDIT",
        name: "Suggest changes to Job Description",
        actionLable: "Suggest changes to Job Description",
        roleIds: [3, 4],
        forAdmins: true,
      },
      
      {
        code: "FINALIZE_JOB_DESC",
        name: "Finalize Job Description ",
        actionLable: "Finalize Job Description ",
        roleIds: [3, 4],
        forAdmins: true,
      },

      {
        code: "UPLOAD_PWD_DOCS",
        name: "Upload Filed/Certified PWD ",
        actionLable: "Upload Filed/Certified PWD ",
        roleIds: [3, 4],
        forAdmins: true,
      },
      

     
      {
        code: "EFILE_PWD_DOL",
        name: "Prevailing Wage Determination",
        actionLable: "E-File PWD",
        roleIds: [3, 4],
        forAdmins: true,
      },
      {
        code: "EFILE_PWD",
        name: "Prevailing Wage Determination",
        actionLable: "Update PWD Tracking Info",
        roleIds: [3, 4],
        forAdmins: true,
      },
      {
        code: "UPDATE_PWD_RESPONSE",
        name: "Upload Certified PWD",
       // actionLable: "Upload Certified PWD",
       actionLable: "Update PWD Response",
        roleIds: [3, 4],
        forAdmins: true,
      },
      {
        code: "LINK_PWD",
        name: "Link PWD",
         actionLable: "Link PWD",
        forAdmins: true,
        roleIds: [3, 4],
      },
      
      {
        code: "SUBMIT_RFI_RESPONSE",
        name: "Response Submitted to RFI",
       // actionLable: "Upload Certified PWD",
       actionLable: "Response Submitted to RFI",
        roleIds: [3, 4],
        forAdmins: true,
      },
      {
        code: "COLLECT_ADV_EVIDENCE",
        name: "Collect Evidence of Advertisements",
        actionLable: "Collect Evidence of Advertisements",
        roleIds: [3, 4],
        forAdmins: true,
      },
      {
        code: "COLLECT_ADV_EVIDENCE_EDIT",
        name: "Update Evidence of Advertisements",
        actionLable: "Update Evidence of Advertisements",
        roleIds: [3, 4],
        forAdmins: true,
      },
      {
        code: "UPDATE_PWD_RESPONSE_WITH_JD",
        name: "Upload Filed/Certified PWD",
        actionLable: "Upload Filed/Certified PWD",
        roleIds: [3, 4],
        forAdmins: true,
      },
      {
        code: "PREPARE_PERM_APPLICATION",
        name: "Review and Finalize PERM Questionnaire",
        actionLable: "Review and Finalize PERM Questionnaire",
        roleIds: [3, 4],
        forAdmins: true,
      },

      
      
      
      {
        code: "PERM_DRAFT_SUGGESSION",
        //name: "Suggest changes to PERM Draft",
        //actionLable: "Suggest changes to PERM Draft",
        name: "Suggest Changes / Approve PERM Draft",
        actionLable:'Suggest Changes / Approve PERM Draft',
        roleIds: [3, 4],
        forAdmins: true,
      },

      {
        code: "PERM_DRAFT_SUGGESSION_EDIT",
        name: "Update PERM Questionnaire",
        actionLable: "Update PERM Questionnaire",
        roleIds: [3, 4],
        forAdmins: true,
      },
      


      {
        code: "APPROVE_PERM_APPLICATION",
        name: "Approve PERM Application",
        actionLable: "Approve PERM Application",
        roleIds: [3, 4],
        forAdmins: true,
      },
      //
      
      {
        code: "EFILE_PREM_APPLICATION",
        name: "E-File PERM Application",
        actionLable: "Prepare PERM Draft at DOL (E-File)",
        roleIds: [3, 4],
        forAdmins: true,
      },
      {
        code: "REQUEST_PERM_DRAFT_REVIEW",
        name: "Request Petitioner for PERM Draft Review",
        actionLable: "Request Petitioner for PERM Draft Review",
        roleIds: [3, 4],
        forAdmins: true,
      },

      {
        code: "EFILE_PREM_APPLICATION_DRAFT",
        name: "Submit PERM to DOL (E-File)",
        actionLable: "Submit PERM to DOL (E-File)",
        roleIds: [3, 4],
        forAdmins: true,
        
      },

      {
        code: "UPLOAD_PERM_ACK",
        name: "Upload PERM Acknowledgement",
        actionLable: "Upload PERM Acknowledgement",
        roleIds: [3, 4],
        forAdmins: true,
      },
      //E-File PERM at DOL
      // {
      //   code: "DOL_AUDIT",
      //   name: "Send For Audit",
      //   actionLable: "Send For Audit",
      //   roleIds: [3, 4],
      //   forAdmins: true,
      // },
      {
        code: "PREPARE_AUDIT_RESPONSE",
        name: "Generate Audit Response",
        actionLable: "Generate Audit Response",
        roleIds: [3, 4],
        forAdmins: true,
      },
      {
        code: "SUBMIT_TO_DOL",
        name: "Submit to DOL",
        actionLable: "Submit to DOL",
        roleIds: [3, 4],
        forAdmins: true,
      },
      {
        code: "DOL_SUPERVISORY_AUDIT",
        name: "Supervisory Audit",
        actionLable: "Supervisory Audit",
        roleIds: [3, 4],
        forAdmins: true,
      },
      
      
      {
        code: "UPDATE_DOL_RESPONSE",
        name: "Update DOL Response",
        actionLable: "Update DOL Response",
        roleIds: [3, 4],
        forAdmins: true,
      },
      {
        code: "FILE_I140",
        name: "File Immigrant Petition (I-140)",
        actionLable: "File Immigrant Petition (I-140)",
        roleIds: [3, 4],
        forAdmins: true,
      }, 
      
      
      //perm veriables
      
      {
        code: "SUBMIT_CASE",
        name: "Submit to Law Firm",
        actionLable: "Submit to Law Firm",
        forAdmins: true,
        roleIds: [3, 4],
      },
      {
        code: "RE_ASSIGN",
        name: "Reassign",
        actionLable: "Reassign",
        forAdmins: true,
        roleIds: [3, 4],
      },
      
      {
        code: "BACK_TO_ASSIGN",
        name: "Report Back",
        actionLable: "Report Back",
        forAdmins: true,
        roleIds: [3, 4],
      },
      
      
      {
        code: "UPDATE_DEADLINE",
        name: "Update Deadline",
        actionLable: "Update Deadline",
        forAdmins: true,
        roleIds: [3, 4],
      },
      {
        code: "NORMAL_PROCESS",
        name: "Revert to Normal Processing",
        actionLable: "Revert to Normal Processing",
        forAdmins: true,
        roleIds: [3, 4],
      },
      {
        code: "PREMIUM_PROCESS",
        name: "Upgrade to Premium Processing",
         actionLable: "Upgrade to Premium Processing",
        forAdmins: true,
        roleIds: [3, 4],
      },
      
      {
        code: "DELETE_PWD",
        name: "Delete PWD",
         actionLable: "Delete PWD",
        forAdmins: true,
        roleIds: [3, 4],
      },
      {
        code: "LINK_PERM",
        name: "Link PERM",
         actionLable: "Link PERM",
        forAdmins: true,
        roleIds: [3, 4],
      },
      
      {
        code: "LINK_140",
        name: "Link 140",
         actionLable: "Link 140",
        forAdmins: true,
        roleIds: [3, 4],
      },
      {
        code: "UPDATE_LCA",
        name: "Update LCA Status",
        actionLable: "Update LCA Status",
        forAdmins: true,
        roleIds: [3, 4],
      },
      {
        code: "SUBMIT_SIGNED_DOCUMENTS",
        name: "Submit Signed Documents",
          actionLable: "Submit Signed Documents",
        forAdmins: true,
        roleIds: [3, 4],
      },
      {
        code: "APPROVE_DOCUMENTS",
        name: "Approve Documents",
        actionLable: "Approve Documents",
        forAdmins: true,
        roleIds: [3, 4],
      },
      {
        code: "SEND_DOCUMENTS",
        name: "Send Documents For Review",
         actionLable: "Send Documents For Review",
        forAdmins: true,
        roleIds: [3, 4],
      },
      {
        code: "UPLOAD_DOCUMENTS",
        name: "Upload Documents",
        actionLable: "Upload Documents",
        forAdmins: true,
        roleIds: [3, 4],
      },
      {
        code: "SEND_FOR_SIGNING",
        name: "Send for Signing",
        actionLable: "Send for Signing",
        forAdmins: true,
        roleIds: [3, 4],
      },
//Generate Signed forms
     {
        code: "GENERATED_SIGNED_DOCS",
        name: "Generate Signed Documents",
        actionLable: "Generate Signed Documents",
        forAdmins: true,
        roleIds: [3, 4],
      },

      /*{
        code: "REQUEST_BENEFICIARY_SIGN",
        name: "Send for Beneficiary Signing",
        actionLable: "Send for Beneficiary Signing",
        forAdmins: true,
        roleIds: [3, 4],
      },
      */
      {
        code: "UPLOAD_BENEFICIARY_SCANNED_COPY",
        name: "Upload Beneficiary Signed Documents",
          actionLable: "Upload Beneficiary Signed Documents",
        forAdmins: true,
        roleIds: [50],
      },
      
    
      
      
      {
        code: "UPLOAD_SIGNED_DOCUMENTS",
        name: "Upload Signed Documents",
          actionLable: "Upload Signed Documents",
        forAdmins: true,
        roleIds: [50],
      },
      {
        code: "REVIEW_COMPLETED",
        name: "Complete Review",
        actionLable: "Complete Review",
        forAdmins: true,
      },
      {
        code: "UPDATE_INTERNAL_STATUS",
        //name: "Update Internal Status",
       // actionLable: "Update Internal Status",
       name:"Hold/Abandon/Delete Case",
       actionLable:'Hold/Abandon/Delete Case',
        forAdmins: true,
      },
      {
        code: "ACCOUNTANT_APPORVAL_REQUEST",
        name: "Approval from Accounts",
        actionLable: "Approval from Accounts",
        roleIds: [3, 4],
        forAdmins: true,
      },
      {
        code: "ACCOUNTANT_APPORVAL_GRANT",
        name: "Approve Request",
        actionLable: "Approve Request",
        roleIds: [3, 4],
        forAdmins: true,
      }, 
      
    /*  {
        code: "FILING_FEE",
        name: "Enter Filing Fees",
        actionLable: "Enter Filing Fees",
        roleIds: [3, 4],
        forAdmins: true,
      },
      */
      {
        code: "ADD_PAYMENT",
        name: "Add Payment",
        actionLable: "Complete Payment",
        roleIds: [3, 4],
        forAdmins: true,
      },
      {
        code: "INITIATE_REMINDER",
        name: "Reminder for Invoice",//Initiate Invoice for Payment
        actionLable: "Reminder for Invoice",
        roleIds: [3, 4],
        forAdmins: true,
      },
      {
        code: "SUPERVISOR_FORMS_REVIEW",
        name: "Supervisory Review",
        actionLable: "Supervisory Review",
        roleIds: [7],
        forAdmins: true,
      },
      {
        code: "LINK_LCA",
        name: "Link with LCA",
         actionLable: "Link with LCA",
        forAdmins: true,
        roleIds: [3, 4],
      },
      // {
      //   code: "UPDATE_USCIS_RESPONSE_H4",
      //   name: "Update USCIS Status-H4",
      //    actionLable: "Update USCIS Status-H4",
      //   forAdmins: true,
      //   roleIds: [3, 4],
      // },
      // {
      //   code: "UPDATE_USCIS_RESPONSE_H4EAD",
      //   name: "Update USCIS Status-H4 EAD",
      //    actionLable: "Update USCIS Status-H4EAD",
      //   forAdmins: true,
      //   roleIds: [3, 4],
      // },

      {
        code: "RFE_PREPARE_RESPONSE_DOCS",
        name: "Prepare RFE Response Documents",
          actionLable: "Prepare RFE Response Documents",
        forAdmins: true,
        roleIds: [50],
      },
      {
        code: "RFE_REVIEW_RESPONSE_DOCS",
        name: "Send Response Docs For Approval",
          actionLable: "Send Response Docs For Approval",
        forAdmins: true,
        roleIds: [50],
      },
      {
        code: "CREATE_RFE_CASE",
        name: "Create RFE Case",
          actionLable: "Create RFE Case",
        forAdmins: true,
        roleIds: [50],
      },
      

    ],

    //Perm Veriables
    permJobDesEditorsList:[],
    reqJobDesReview:[],
    
    permJobApprove:[],
    finnailizePermJob:[],
    internamJobDesApprove:[],
    internamJobDesApproveRequired:false,
    

    jobAdvertismentActivity:[],
    pwdEfileActivity:[],
    pwdResponseUpdateActivity:[],
    preparePermActivity:[],
    permSuggssitionActivity:[],
    approvePermApplication:[],
    efilePermActivity:[],
    requestPermDraftReview:[],
    permAcknowledgementEditors:[],//UPLOAD_PERM_ACK
    updateDolResponseEditors:[],//UPDATE_DOL_RESPONSE
    //Perm Veriables End

    prePareRfeResDocsEditors:[], //RFE_PREPARE_RESPONSE_DOCS
    rfeCaseApprovedEditors:[],//RFE_CASE_APPROVED
    rfeCourierTrackingEditors:[],
    updateRfeUscisReceiptNumberEditors:[],
    rfeReqPetEditors:[],//RFE_REQUEST_PETITIONER_SIGN // OR RFE_DOC_SIGNER_LIST
    rfeSubmitToUscisEditors:[],//RFE_SUBMIT_TO_USCIS
    rfeUpdateUscisEditors:[],//RFE_UPDATE_USCIS_RESPONSE


    
  }),
  
  computed:{
    
    checkWorkActivityisRequires(){
        return (code='')=>{
         
          if( _.has(this.workFlowDetails ,"config") && this.checkProperty(this.workFlowDetails ,'config', 'length')>0 ){
            let config = this.workFlowDetails['config'];
            let ilteredItem = _.find(config, {"code":code,"actionRequired":'Yes'});
            if(ilteredItem){
              return true;
            }
            return false;
            
            
          }else{
            return false;
          }
          
  
        }
      },
    checkActivityCompleted(){
      let returnVal = false;
      return (code)=>{
        if(this.checkProperty(this.petitionDetails, 'completedActivities') ){
          if(this.petitionDetails.completedActivities.indexOf(code) >-1){
            returnVal=true;
          }  
      }
      return returnVal;
      }
      
      
      
    },
    checkDependenth4(){
      let returnVal = false;
      if(this.checkProperty(this.petitionDetails,'dependentsInfo') && (_.has(this.petitionDetails['dependentsInfo'],'spouse') || _.has(this.petitionDetails['dependentsInfo'],'childrens'))){
        if(this.checkProperty(this.petitionDetails['dependentsInfo'],'spouse') && this.checkProperty(this.petitionDetails['dependentsInfo'],'spouse','h4Required')){
          returnVal = true;
          return returnVal;
        }else if(this.checkProperty(this.petitionDetails,'dependentsInfo','childrens') && this.checkProperty(this.petitionDetails['dependentsInfo'],'childrens','length')>0 ){
          let findObj = _.find(this.petitionDetails['dependentsInfo']['childrens'],{'h4Required':true});
          if(findObj){
            returnVal = true;
            return returnVal;
          }
        }
      }
      return returnVal;
    },
    checkDependenth4EAD(){
      let returnVal = false;
      if(this.checkProperty(this.petitionDetails,'dependentsInfo') && (_.has(this.petitionDetails['dependentsInfo'],'spouse') || _.has(this.petitionDetails['dependentsInfo'],'childrens'))){
        if(this.checkProperty(this.petitionDetails['dependentsInfo'],'spouse') && this.checkProperty(this.petitionDetails['dependentsInfo'],'spouse','h4EADRequired')){
          returnVal = true;
          return returnVal;
        }
        // else if(this.checkProperty(this.petitionDetails,'dependentsInfo','childrens') && this.checkProperty(this.petitionDetails['dependentsInfo'],'childrens','length')>0 ){
        //   let findObj = _.find(this.petitionDetails['dependentsInfo']['childrens'],{'h4EADRequired':true});
        //   if(findObj){
        //     returnVal = true;
        //     return returnVal;
        //   }
        // }
      }
      return returnVal;
    },
    checkPetitionsDetails(){
      let returnVal = false;
      const currentUrl = window.location.href
      if(currentUrl.includes('/petition-details')){
        returnVal = true;
      }
      return returnVal;
    },
    checkChildH4required(){
      //if(this.checkProperty(this.petitionDetails['dependentsInfo'],'spouse' ,'h4Required') ==true){
        let returnValue =false;
        if(this.checkProperty(this.petitionDetails['dependentsInfo'] ,'childrens' ,'length') >0){

          let h4RequirdChildrens =_.filter(this.petitionDetails['dependentsInfo']['childrens'] ,(child)=>{
            if(this.checkProperty(child ,'name') && this.checkProperty(child ,'h4Required') ==true ){
              return true
            }else{
              return false
            }

          });
          if(h4RequirdChildrens && this.checkProperty( h4RequirdChildrens ,'length') >0){
            returnValue =true;
          }

        }
        return returnValue;
    },
    checkNoNotifyUserIds(){
      let returnValue =true;
      if(_.has(this.petitionDetails, 'noNotifyUserIds')  ){
        if(this.petitionDetails['noNotifyUserIds'].length>0){
          if(this.petitionDetails['noNotifyUserIds'].indexOf(this.getUserData['userId']) >-1){
            returnValue = false;
          }

        }

      }
      return returnValue;
    },
    checkBackToAssign(){
      let returnValue =false
      if(_.has(this.petitionDetails, 'reassignLogs')){
        let userId = this.getUserData['userId'];
        let myItems = _.filter(this.petitionDetails['reassignLogs'] ,{"assignedBack":false,"toUserId":userId});
        if(myItems && myItems.length>0){
          returnValue =true;
        }

      }
      return returnValue;
    },
    checkIsLcaExcuitive(){
      let returnVal =false;
      if([14].indexOf(this.getUserRoleId)>-1 && this.petitionDetails.completedActivities.indexOf('ASSIGN_LCA_EXECUTIVE')>-1 ){
        returnVal =true;
      }
      return returnVal;
    },
    checklawTenant(){
      let returnVal = false;
      if(this.checkProperty(this.petitionDetails, 'tenantDetails', 'typeId') != 2){
          returnVal=true;
      }
      return returnVal;
    },
    checkLcarequired(){
      let returnVal =false;
    
    this.isLcaRequiredForPetition = false;
      let wf = _.cloneDeep(this.workFlowDetails);

      if (wf && _.has(wf, "config")) {
        let lcaRequired = _.find(wf["config"], { code: "LCA_REQUEST" });

        if (
          lcaRequired &&
          _.has(lcaRequired, "actionRequired") &&
           lcaRequired.actionRequired == "Yes"
        ) {
          
         
          returnVal =true;

        } 
      

    return returnVal;
      }

    },
    canLcaRequested(){
    let returnVal =false;
    let isAdmin = this.adminsList.indexOf(this.getUserRoleId) > -1

    this.isLcaRequiredForPetition = false;
      let wf = _.cloneDeep(this.workFlowDetails);

      if (wf && _.has(wf, "config")) {
        let lcaRequired = _.find(wf["config"], { code: "LCA_REQUEST" });

        if (
          lcaRequired &&
          _.has(lcaRequired, "editors") &&
          _.has(lcaRequired, "actionRequired") &&
          lcaRequired["editors"].length > 0 &&
          lcaRequired.actionRequired == "Yes"
        ) {

          let allEditors = _.filter(lcaRequired["editors"] ,(ed)=>{
            return ed['roleId'] !=50
          })
          let editors = _.map(allEditors, 'roleId');
          returnVal = editors.indexOf(this.getUserRoleId) > -1|| isAdmin; 

        } 
      

    return returnVal;
      }


    },
    canLcaSubmit(){
    let returnVal =false;
    let isAdmin = this.adminsList.indexOf(this.getUserRoleId) > -1

    this.isLcaRequiredForPetition = false;
      let wf = _.cloneDeep(this.workFlowDetails);

      if (wf && _.has(wf, "config")) {
        let lcaRequired = _.find(wf["config"], { code: "LCA_SUBMIT" });

        if (
          lcaRequired &&
          _.has(lcaRequired, "editors") &&
          _.has(lcaRequired, "actionRequired") &&
          lcaRequired["editors"].length > 0 
         
        ) {
          
          let allEditors = _.filter(lcaRequired["editors"] ,(ed)=>{
            return ed['roleId'] !=50
          })
          let editors = _.map(allEditors, 'roleId');

          returnVal = editors.indexOf(this.getUserRoleId) > -1||isAdmin; 

        } 
      

    return returnVal;
      }


    },
    checkActiveFormsAndLetters(){
    return  (docUserType='')=>{
      let returnVal=false;
    //  this.checkProperty(this.petitionDetails ,'maritalStatus') ==2
      if(this.allFormsAndLettersList.length>0){

        let query= {"statusId":2};
         if(docUserType=='Beneficiary' ){
          query = {"statusId":2 ,'docUserType':'Beneficiary'}
        } else if(docUserType=='Dependent'){
           query= {"statusId":2 ,'docUserType':'Dependent'};
        }
        let activeList = _.filter(this.allFormsAndLettersList, query);
        if(activeList && activeList.length>0){
             returnVal =true;
        }
 
      }
      

      return returnVal;

      }
    
      
      
    },
    checkOpenGenerateFormsAndletters(){
     let returnVal =false;
     //check autorney activity Is active
     if(_.has(this.workFlowDetails ,'config') && this.petitionDetails ){
      let isCasenoAssigned=this.petitionDetails.completedActivities.indexOf('ASSIGN_CUSTOM_CASE_NO')>-1 ;
      let iscaseApproved = this.petitionDetails.completedActivities.indexOf('CASE_APPROVED')>-1;
      let isAuttorneyAssigned = this.petitionDetails.completedActivities.indexOf('ASSIGN_ATTORNEY')>-1;
      let submitToUscisCompleted = this.petitionDetails.completedActivities.indexOf('SUBMIT_TO_USCIS')>-1
      let submitRolawFirm = this.petitionDetails.completedActivities.indexOf('SUBMIT_TO_LAW_FIRM') >-1
      let attorneyactiVity = _.find(this.workFlowDetails.config , {"code":'ASSIGN_ATTORNEY' ,"actionRequired":'Yes'});
      
      if(submitRolawFirm){

        if(attorneyactiVity&& attorneyactiVity['actionRequired'] =='Yes' ){
          if(isCasenoAssigned && isAuttorneyAssigned &&  !submitToUscisCompleted ){
            returnVal =true;
          }

        }else{

          if(isCasenoAssigned &&  !submitToUscisCompleted ){
            returnVal =true;
          }
          
        }
      }
      
    }
      

     return returnVal;
    },

    checkDoce() {
      let returnVal = false;
      let doceList =[];
      let adminsList =[];
      if(_.has( this.workFlowDetails ,'config')){
      let docsActivity = _.find(this.workFlowDetails.config, {
        code: "DOCUMENTATION_EXECUTIVE_LIST",
      });
      if (docsActivity && docsActivity.editors) {
        doceList = _.map(docsActivity.editors, "roleId");
      }
      if (doceList && doceList.indexOf(this.getUserRoleId)>-1) {
        returnVal = true;
      }
    }
      
     
      return returnVal;
    },
    checkDocM() {
      let returnVal = false;
      let docmManagerList =[];
      let adminsList =[];
      if(_.has( this.workFlowDetails ,'config')){
        let docManagerActivity = _.find(this.workFlowDetails.config, {
          code: "DOCUMENTATION_MANAGER_LIST",
        });
        if (docManagerActivity && docManagerActivity.editors) {
          docmManagerList = _.map(docManagerActivity.editors, "roleId");
        }
        if (docmManagerList && docmManagerList.indexOf(this.getUserRoleId)>-1) {
          returnVal = true;
        }
        let adminsactiVityList = _.find(this.workFlowDetails.config, {
          code: "MANAGER_LIST",
        });
        
        if (adminsactiVityList && adminsactiVityList.editors) {
          adminsList = _.map(adminsactiVityList.editors, "roleId");
        }
        
        if (adminsList && adminsList.indexOf(this.getUserRoleId) >-1) {
          returnVal = true;
        }
    }
     
      return returnVal;
    },
    checkPendingDocs() {
      let returnVal = false;
      if (this.checkDocM || this.checkDoce) {
        if (
          this.formsAndLettersList &&
          this.checkProperty(this.formsAndLettersList, "length") > 0
        ) {
          let falseStautsListPen = _.filter(this.formsAndLettersList, (item) => {
            return this.checkProperty(item, "statusId") == 1;
          });
          
          if ( (falseStautsListPen && this.checkProperty(falseStautsListPen, "length") > 0) ) {
            
              returnVal = true;
            
          }
        }
      }
      return returnVal;
    },
    checkActiveFormsAndLatters() {
      let returnVal = false;
      
        if (
          this.formsAndLettersList &&
          this.checkProperty(this.formsAndLettersList, "length") > 0
        ) {
          let falseStautsListPen = _.filter(this.formsAndLettersList, (item) => {
            return this.checkProperty(item, "statusId") == 2;
          });
          
          if ( (falseStautsListPen && this.checkProperty(falseStautsListPen, "length") > 0) ) {
            
              returnVal = true;
            
          }
        }
      
      return returnVal;
    },
    checkUserAccessBtn(){
      let returnVal = false;
      let accessRoleIds = this.checkProperty( this.petitionDetails ,'accessRoleIds')
      let accessUserIds = this.checkProperty( this.petitionDetails ,'accessUserIds' )
      let loginUserId = this.checkProperty(this.getUserData,'userId')
      // accessRoleIds.indexOf(this.getUserRoleId)>-1 || 
      if(accessUserIds.indexOf(loginUserId)>-1 ){
        returnVal = true
      }
      return returnVal
    },
    checkActionButton(){
      let returnVal = true
      if(this.checkProperty( this.petitionDetails ,'assignRoleLogs' ,'length')>0){
        let assignRoleLogs = this.checkProperty( this.petitionDetails ,'assignRoleLogs')
        let loginUserId = this.checkProperty(this.getUserData,'userId')
        let UserDetails = _.find(assignRoleLogs , {"userId":loginUserId})
        if(UserDetails ){
          let users = _.filter(assignRoleLogs , {"userId":loginUserId ,'hide':false})
          if(users && users.length>0){
            returnVal =true;
          }else{
            returnVal = false
          }
          
        }
        
      }
      return returnVal
    },
    checkAssignments(){
      let returnValue = true;

      let isPermCase =false;
       if(this.checkProperty(this.petitionDetails ,'typeDetails','id' )==3 && this.checkProperty(this.petitionDetails ,'subTypeDetails','id' )==15){
        isPermCase =true;
       }
      if(this.workFlowDetails && _.has(this.workFlowDetails ,'config' )){
        let assignSuperVisorActiVity = _.find(this.workFlowDetails.config , {"code":'ASSIGN_SUPERVISOR' ,"include":'Yes'});
        let paralegalactiVity = _.find(this.workFlowDetails.config , {"code":'ASSIGN_PARALEGAL',"include":'Yes'});
        let attorneyactiVity = _.find(this.workFlowDetails.config , {"code":'ASSIGN_ATTORNEY',"include":'Yes'});
        let docm = _.find(this.workFlowDetails.config , {"code":'ASSIGN_DOCUMENTATION_MANAGER',"include":'Yes'});

      
        if(assignSuperVisorActiVity && this.checkProperty(assignSuperVisorActiVity, 'editors' ,'length')>0 && this.petitionDetails.completedActivities.indexOf('ASSIGN_SUPERVISOR') <= -1 ){
          returnValue =false;
        }
        if(paralegalactiVity && this.checkProperty(paralegalactiVity, 'editors' ,'length')>0 &&  this.petitionDetails.completedActivities.indexOf('ASSIGN_PARALEGAL') <= -1 ){
          returnValue =false;
        }
        if(attorneyactiVity && this.checkProperty(attorneyactiVity, 'editors' ,'length')>0 && this.petitionDetails.completedActivities.indexOf('ASSIGN_ATTORNEY') <= -1 ){
          returnValue =false;
        }



        if(docm && this.checkProperty(docm, 'editors' ,'length')>0 && this.petitionDetails.completedActivities.indexOf('ASSIGN_DOCUMENTATION_MANAGER') <= -1 ){
          returnValue =false;
        }
       

        if(!returnValue && this.checkProperty(this.workFlowDetails ,'workflowType') =="Free-Flow" ){
          returnValue =true;
        }
        
      }

      

      return returnValue;

    },
    //check case approves a
    checkCaseApprovedAction(){
      //let caseapproversactiVityList = _.find(this.workFlowDetails.config , {"code":'CASE_APPROVED' ,"actionRequired":'Yes'});
      let returnValue =false;
      if(_.has(this.workFlowDetails ,'config')){

        let caseapproversactiVityList = _.find(this.workFlowDetails.config , {"code":'CASE_APPROVED' ,"actionRequired":'Yes'});
        if(caseapproversactiVityList){

          returnValue =true;

        }
      }
      return returnValue;
    }

  },
  watch: {
        $route() {
            this.checkAdvValidation =false;
        }
    },
};
</script>