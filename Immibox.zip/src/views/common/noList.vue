<template>
     <div class="loadingList">
        <template v-if="cloading">
          <div class="skelton_cards" v-for="index in 5" :key="index">
              <div class="skline picture"></div>
              <div class="lines_list"> 
                  <div class="skline line1"></div>
                  <div class="skline line2"></div>
                  <div class="skline line3"></div>
              </div>
          </div>
        </template>
        <template v-else>
          <div class="nolist_data">
            <h3 v-if="heading">{{heading}}</h3>
            <p v-if="content">{{content}}</p>
          </div>
        </template>
        </div>
</template>

<script>
export default {
    props: {
     loading:true,
     type:null,
     heading:null,
     content:null  
    },
     watch: { 
      	loading: function(newVal, oldVal) { // watch it
        }
      },
      data() {
        return {
         cloading:true
        };
    },
    mounted(){
        var _s = this;
       setTimeout(function(){

           // _s.cloading =_s.loading;
           
       },500)
      
    },
    methods: {
      updateLoading(value){
        this.cloading = value;
      
      }
    }
}
</script>

