

    <template>
         <div>
            <div class="doc_header pt-0 d"  >
                <h3 class="small-header mart25" >{{docTitle}}

                </h3>
            </div>
            
            <template v-if="!checkSectionValue({'dataVal':documentsList}) ">
              <template  v-for="(type,docs) in  documentsList">
                <template v-if="checkProperty( type ,'length')>0">
                  <div :key="docs" >
                    <vs-row  >
                        <vs-col class="padl0 padr0">
                        <div class="card-panels pad0">
                            <vs-card>
                            <div slot="header" >
                                <h3>{{docs | formatdoctype}}  </h3> 
                                
                            </div>
                            
                                <div>
                                
                                <template v-for="(item ,ind ) in  type"  >
                                
                                <div class="documents__list"  >
                                    <div class="documents__title" @click="downloadfile(item)">
                                    <figure> 
                                        <img v-if="checkFileFormat(item['mimetype']) =='pdf'" src="@/assets/images/main/pdf.svg" /> 
                                        <img v-else-if="checkFileFormat(item['mimetype']) =='video_mime_types'" src="@/assets/images/main/film.png" />
                                        <img v-else-if="checkFileFormat(item['mimetype']) =='msDoc'" src="@/assets/images/main/doc.svg" />
                                        <img v-else-if="checkFileFormat(item['mimetype']) =='zip'" src="@/assets/images/main/zip-file-format.png" />
                                        <img v-else-if="checkFileFormat(item['mimetype']) =='msPpt'" src="@/assets/images/main/ppt.svg" />
                                        <img v-else-if="checkFileFormat(item['mimetype']) =='msXl'" src="@/assets/images/main/xls.svg" />
                                        <img v-else-if="checkFileFormat(item['mimetype']) =='image'" src="@/assets/images/main/image.svg" />
                                        <img v-else src="@/assets/images/main/icon-img.svg" />
                                    </figure> 
                                    <!-- <span>{{item.name}}</span> -->
                                    <span >                   
                                        <em class="fl_scanned_docs" :title="item.name">{{item.name}}</em>
                                        <small class="uploaded_doc_small" > 
                                          <p><span v-if="getformated(item)"> {{ getformated(item) }}</span><span v-if="checkProperty(item,'uploadedByName')"> - Uploaded By {{ item['uploadedByName']}} <em v-if="checkProperty(item,'uploadedByRoleName')">({{ item['uploadedByRoleName'] }})</em></span></p>
                                        </small>                                                                        
                                      </span>
                                    </div>
                                    <div class="documents__actions">
                                    
                                    <button  @click="downloadfile(item)" class="view-btn">View</button>
                                    </div>
                                </div>
                                </template>
                                </div>
                            
                            </vs-card>
                        </div>
                        </vs-col>
                    </vs-row>
                  </div>
                </template>
              </template>
            </template>
            <template v-else>
              <NoDataFound  ref="NoDataFoundRef"   content="" heading="No Documents Found" type='documents' />
            </template>
       </div>
    
   </template>
    
  <script>
import NoDataFound from "@/views/common/noData.vue";
import { XIcon } from 'vue-feather-icons';
import * as _ from "lodash";
import moment, { relativeTimeThreshold } from "moment";
export default {
   provide() {
        return {
          //  parentValidator: this.$validator,
        };
    },
  components: {
    NoDataFound,
    XIcon
  },
  data() {
    return { };
  },
  watch: {
   
  },
  props: {
    docTitle:{
      type: String,
      default: 'Documents',
    },
    documentsList: {
      type: Object,
      default: null,
    },
    petitionDetails: {
      type: Object,
      default: null,
    },
  },
  mounted() {

  },
  methods: { 
    downloadfile(item){
        this.$emit("download_or_view" ,item);

    },
    getformated(item) {

if(item.uploadedOn){
     return (
     "Uploaded On  " +
     moment(item.uploadedOn).format("MMM DD, YYYY hh:mm:ss a")
   );
 }
 else {
 if( item.createdOn){
       return (
       "Uploaded On  " +
       moment(item.createdOn).format("MMM DD, YYYY hh:mm:ss a")
   );

 }
}
 },

  },
  computed:{
    checkSectionValue(){
      return(data)=>{
        let returnVal = false
        if(data && _.has(data,'dataVal') && this.checkProperty(data,'dataVal')){
          let catDocuments =Object.entries(this.checkProperty(data,'dataVal'));
          let documentsArray = [];
          _.forEach(catDocuments,(item)=>{
              let obj = {}
              if(item){
                  let category =_.cloneDeep(item[0]);
                  let tempSection= category
                  if(item[1].length>0){
                      let documents =_.cloneDeep(item[1]);
                      let filteredDocs =[]
                    _.forEach(documents,(docs)=>{
                      if(!_.has(docs,'status') || (_.has(docs,'status') && this.checkProperty(docs,'status'))){
                        filteredDocs.push(docs)
                      }
                    })
                    if(filteredDocs){
                      obj[tempSection] = filteredDocs
                    }
                  }
                  else{
                      obj[tempSection] = []
                  }
              }
              documentsArray.push(obj)
          })
          if(documentsArray){
            let valueCount = 0
            _.forEach(documentsArray,(docObj)=>{
              if(docObj){
                let catDocuments =Object.entries(docObj);
                if(catDocuments){
                  _.forEach(catDocuments,(item)=>{
                    if(item){
                        let category  =_.cloneDeep(item[0]);
                        if(this.checkProperty(docObj,category) && this.checkProperty(docObj,category,'length')>0  ){
                            valueCount++
                        }
                    }
                  })
                }
              }
            }) 
            if(valueCount>0){
                returnVal = false
            }else{
                returnVal = true
            }           
          }else{
            returnVal = true
          }
        }else{
          returnVal = true
        }
        if(returnVal){
            setTimeout(()=>{
                this.updateLoading(false)
            },10);
            
        }
        return returnVal
      }
    },


    
    checkDocumentsLength(){
     
       let finalDocuments =[];
      _.forEach(Object.entries(this.documentsList) , (category ,index)=>{
       
        if(this.checkProperty(category ,'length')>1){
          if(this.checkProperty(category[1] ,'length') >0){
            let activeDocuments = _.filter(category[1] ,(doc)=>{
              return doc['status'] == true || !_.has(doc ,'status')
            });
           
            if(activeDocuments && this.checkProperty(activeDocuments ,'length')>0){
             
              finalDocuments.push(category);
            }

          }
          //isTrashDocument
       

        }

      });
      if(finalDocuments.length>0){
        return true 
      }else {
       return false;
      }
         
     
     
    },
  }
};

</script>
