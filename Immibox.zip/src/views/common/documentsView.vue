<template>
    <div>
        <vs-row >
            <vs-col class="padl0 padr0">
                <div class="list-elements">
                    <template v-if="showTitle">
                        <h4>{{type | formatdoctype}}</h4>
                        <h4>{{label }}</h4>
                    </template>
                    <ul>
                        <li class="download_view_v2" v-for="(item ,ind ) in  documentsList"  v-tooltip="item.name">                            
                            <figure > 
                                <img v-if="checkFileFormat(item['mimetype']) =='pdf'" src="@/assets/images/main/pdf.svg" /> 
                                <img v-else-if="checkFileFormat(item['mimetype']) =='video_mime_types'" src="@/assets/images/main/film.png" />
                                <img v-else-if="checkFileFormat(item['mimetype']) =='msDoc'" src="@/assets/images/main/doc.svg" />
                                <img v-else-if="checkFileFormat(item['mimetype']) =='zip'" src="@/assets/images/main/zip-file-format.png" />
                                <img v-else-if="checkFileFormat(item['mimetype']) =='msPpt'" src="@/assets/images/main/ppt.svg" />
                                <img v-else-if="checkFileFormat(item['mimetype']) =='msXl'" src="@/assets/images/main/xls.svg" />
                                <img v-else-if="checkFileFormat(item['mimetype']) =='image'" src="@/assets/images/main/image.svg" />
                                <img v-else src="@/assets/images/main/icon-img.svg" />
                                <span class="download_icon_v2">
                                    <span @click="downloads3file(item)" ><img class="download_img" src="@/assets/images/main/download.png"></span>
                                    <span @click="downloadfile(item)"><img class="view_img" src="@/assets/images/main/view_hover.svg"></span>
                                </span>
                            </figure> 
                        </li>                         
                    </ul>
                </div> 
            </vs-col>
        </vs-row>
    </div>
</template>
<script> 
export default {
    
    methods: { 
    downloadfile(item){
        this.$emit("download_or_view" ,item);
    }
   },
   props: {
    documentsList: {
      type: Array,
      default: [],
    },
    petitionDetails: {
      type: Object,
      default: null,
    },
    type:{
        type: String,
        default: '',
    },
    label:{
        type: String,
        default: '', 
    },
    showTitle:{
        type: Boolean,
        default: true,
    }
  },
}



</script>