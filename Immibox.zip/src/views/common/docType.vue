<template>
    <figure> 
        <img v-if="checkFileFormat(item['mimetype']) =='pdf'" src="@/assets/images/main/pdf.svg" /> 
        <img v-else-if="checkFileFormat(item['mimetype']) =='video_mime_types'" src="@/assets/images/main/film.png" />
        <img v-else-if="checkFileFormat(item['mimetype']) =='msDoc'" src="@/assets/images/main/doc.svg" />
        <img v-else-if="checkFileFormat(item['mimetype']) =='zip'" src="@/assets/images/main/zip-file-format.png" />
        <img v-else-if="checkFileFormat(item['mimetype']) =='msPpt'" src="@/assets/images/main/ppt.svg" />
        <img v-else-if="checkFileFormat(item['mimetype']) =='msXl'" src="@/assets/images/main/xls.svg" />
        <img v-else-if="checkFileFormat(item['mimetype']) =='image'" src="@/assets/images/main/image.svg" />
        <img v-else src="@/assets/images/main/icon-img.svg" />
        <span v-if="downloadMe" class="download_icon"></span> 
      </figure>
</template>

<script>
export default {

    props:{
        item:null,
        downloadMe:{
            type:Boolean,
            default:false
            
        }

    }
}
</script>