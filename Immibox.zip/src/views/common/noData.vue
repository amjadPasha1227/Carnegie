<template>
<div class="nodataTemplate">

 <div class="accordian-table" v-if="cloading && checkLocading">
    <table  class="vs-table vs-table--tbody-table">
   <tr  v-for="item in  numberOfItems" class="tr-values vs-table--tr tr-table-state-null selected">
    <td class="td vs-table--td"><div class="skline"></div></td>
    <td class="td vs-table--td"><div class="skline"></div></td>
    <td class="td vs-table--td"><div class="skline"></div></td>
    <td class="td vs-table--td"><div class="skline"></div></td>
    <td class="td vs-table--td"><div class="skline"></div></td>
    <td class="td vs-table--td"><div class="skline"></div></td>
   </tr>
   <!--
   <tr class="tr-values vs-table--tr tr-table-state-null selected">
    <td class="td vs-table--td"><div class="skline"></div></td>
    <td class="td vs-table--td"><div class="skline"></div></td>
    <td class="td vs-table--td"><div class="skline"></div></td>
    <td class="td vs-table--td"><div class="skline"></div></td>
    <td class="td vs-table--td"><div class="skline"></div></td>
    <td class="td vs-table--td"><div class="skline"></div></td>
   </tr>
   <tr class="tr-values vs-table--tr tr-table-state-null selected">
    <td class="td vs-table--td"><div class="skline"></div></td>
    <td class="td vs-table--td"><div class="skline"></div></td>
    <td class="td vs-table--td"><div class="skline"></div></td>
    <td class="td vs-table--td"><div class="skline"></div></td>
    <td class="td vs-table--td"><div class="skline"></div></td>
    <td class="td vs-table--td"><div class="skline"></div></td>
   </tr>
   <tr class="tr-values vs-table--tr tr-table-state-null selected">
    <td class="td vs-table--td"><div class="skline"></div></td>
    <td class="td vs-table--td"><div class="skline"></div></td>
    <td class="td vs-table--td"><div class="skline"></div></td>
    <td class="td vs-table--td"><div class="skline"></div></td>
    <td class="td vs-table--td"><div class="skline"></div></td>
    <td class="td vs-table--td"><div class="skline"></div></td>
   </tr>
   <tr class="tr-values vs-table--tr tr-table-state-null selected">
    <td class="td vs-table--td"><div class="skline"></div></td>
    <td class="td vs-table--td"><div class="skline"></div></td>
    <td class="td vs-table--td"><div class="skline"></div></td>
    <td class="td vs-table--td"><div class="skline"></div></td>
    <td class="td vs-table--td"><div class="skline"></div></td>
    <td class="td vs-table--td"><div class="skline"></div></td>
   </tr>
   <tr class="tr-values vs-table--tr tr-table-state-null selected">
    <td class="td vs-table--td"><div class="skline"></div></td>
    <td class="td vs-table--td"><div class="skline"></div></td>
    <td class="td vs-table--td"><div class="skline"></div></td>
    <td class="td vs-table--td"><div class="skline"></div></td>
    <td class="td vs-table--td"><div class="skline"></div></td>
    <td class="td vs-table--td"><div class="skline"></div></td>
   </tr>
    -->
   </table>
 </div>
  <div class="wrapTpl" v-else >
      <!-- <img v-if="type=='workflow'" src="@/assets/images/emptystates/workflow.svg"   />
      <img v-else-if="type=='petitions'" src="@/assets/images/emptystates/petitions.svg"   />
       <img v-else-if="type=='branches'" src="@/assets/images/emptystates/branch.svg"   />
      <img v-else-if="type=='petitioner'" src="@/assets/images/emptystates/petitioner.svg"   />
      <img v-else-if="type=='documents'|| type=='Documents'" src="@/assets/images/emptystates/petitions.svg"   />
      <img v-else src="@/assets/images/emptystates/support.svg"   /> -->
      <img src="@/assets/images/main/nodata_global.svg"   />

   <h3 v-if="heading" v-html="heading">{{heading}}</h3>
   <p v-if="content" v-html="content">{{content}}</p>
  

         



</div>

</div>
</template>

<script>
export default {
    props: {
      numberOfItems:{
        type:Number,
        default:6
      },
     loading:true,
     type:null,
     heading:null,
     content:null,
     checkLocading:{
      type:Boolean,
      default:true
     },  
    },
     watch: { 
      	loading: function(newVal, oldVal) { // watch it
        }
      },
      data() {
        return {
         cloading:true
        };
    },
    mounted(){
        var _s = this;
       setTimeout(function(){

           // _s.cloading =_s.loading;
           
       },500)
      
    },
    methods: {
      updateLoading(value){
        this.cloading = value;
      
      }
    }
}
</script>

