<template>
  <div v-if="fieldname" class="mt-datepicker-wrap">
    <date-picker
      :editable="true"
      :typeable="true"
      value-type="YYYY-MM-DD"
      format="MM/DD/YYYY"
      :name="'df' + fieldname"
      @input="setModel"
      :data-vv-as="label"
      v-model="datestring"
      v-validate="{ required: validationRequired }"
      placeholder="MM/DD/YYYY"
      :default-value="openDate"
      :disabled-date="checkDisabled"
    >
    </date-picker>
    <span
      class="text-danger text-sm"
      v-show="errors.has(formscope + '.df' + fieldname)"
      >{{ errors.first(formscope + ".df" + fieldname) }}
    </span>
  </div>
</template>
<script>
import DatePicker from "vue2-datepicker";
import "vue2-datepicker/index.css";
import moment from "moment";

export default {
  inject: ["parentValidator"],

  props: {
    type: { type: String, defalt: "date" },
    validationRequired: { type: Boolean, default: false },
    value: String,
    formscope: String,
    label: String,
    fieldname: String,
    dateEnableFrom: null,
    dateEnableTo: null,
  },
  components: {
    DatePicker,
  },
  data() {
    return {
      datestring: null,
    };
  },
  computed: {
    openDate() {
      if (this.dateEnableTo) {
        return moment(this.dateEnableTo).format("YYYY-MM-DD");
      }
      return moment(new Date()).format("YYYY-MM-DD");
    },
  },
  methods: {
    checkDisabled(val) {
      try {
        if (val && moment(val)) {
          if (this.dateEnableTo && this.dateEnableFrom) {
            return moment(val) >= moment(this.dateEnableFrom) &&
              moment(val) <= moment(this.dateEnableTo)
              ? false
              : true;
          } else if (this.dateEnableTo) {
            return moment(this.dateEnableTo) <= moment(val);
          } else if (this.dateEnableFrom) {
            return moment(this.dateEnableFrom) >= moment(val);
          }
        }
      } catch (e) {}

      // return true;
    },
    setModel(value) {
      if (value) {
        var _t = moment(value).startOf("day").format("YYYY-MM-DDTHH:mm:ss");
        this.$emit("input", _t);
      }
    },
  },
  created() {
    this.$validator = this.parentValidator;
  },
  mounted() {
    setTimeout(() => {
      this.datestring = this.value;
    }, 10);
  },
};
</script>
