<template>
  <div>

    <assignCaseNumber
      @updatepetition="updatepetition"
      :petitionDetails="petitionDetails"
      :isCaseNumberEdit="isCaseNumberEdit"
      @hideMe="assignCaseNumberModal = false"
      v-if="assignCaseNumberModal"
    />

    <assignActivity
      @updatepetition="updatepetition"
      :petitionDetails="petitionDetails"
      :ACTIVITYCODE="ACTIVITYCODE"
      @hideMe="assignActivityPopup = false"
      :rolesList="rolesList"
      :popUpTitle="popUpTitle"
      :lableTitle="lableTitle"
      v-if="assignActivityPopup"
    />

    <reAssignActivity
      @updatepetition="updatepetition"
      :petitionDetails="petitionDetails"
      :ACTIVITYCODE="ACTIVITYCODE"
      @hideMe="reAssignAeactivityPopup = false"
      :rolesList="rolesList"
      :popUpTitle="popUpTitle"
      :lableTitle="lableTitle"
      v-if="reAssignAeactivityPopup"
      :workFlowDetails="workFlowDetails"
    />
    

    

    <submitToLawFirm
      @updatepetition="updatepetition"
      :petitionDetails="petitionDetails"
      @hideMe="submitToLawFirmModal = false"
      v-if="submitToLawFirmModal"
    />
    <updateInternalStatus
      @updatepetition="updatepetition"
      :petitionDetails="petitionDetails"
      @hideMe="updateInternalStatusModal = false"
      v-if="updateInternalStatusModal"
      :workFlowDetails="workFlowDetails"
    />
    

    <premiumProcessing
      @updatepetition="updatepetition"
      :petitionDetails="petitionDetails"
      @hideMe="premiumProcessingModal = false"
      v-if="premiumProcessingModal"
    />
    <updateLCA
      @updatepetition="updatepetition"
      :petitionDetails="petitionDetails"
      :lcaDetails="templcaDetails"
      @hideMe="updateLCAModal = false"
      v-if="updateLCAModal"
    />

    <updateDeadline
      @updatepetition="updatepetition"
      :petitionDetails="petitionDetails"
      @hideMe="caseDeadlinePopup = false"
      v-if="caseDeadlinePopup"
    />

    <sendForSign
    :formsAndLetters="formsAndLetters"
      @updatepetition="updatepetition"
      :petitionDetails="petitionDetails"
      @hideMe="sendforSignModal = false"
      :rolesList="rolesList" 
      v-if="sendforSignModal"
      :ACTIVITYCODE="ACTIVITYCODE"
    />

    <changeCaseType
      @updatepetition="updatepetition"
      :petitionDetails="petitionDetails"
      @hideMe="changeCaseTypeModal = false"
      v-if="changeCaseTypeModal"
      :visatypes="visatypes"
      :assignedUsersList="assignedUsersList"
      :currentCaseSubType="petitionDetails.subTypeDetails"
      :selectedCaseType="petitionDetails.typeDetails"
    />


    <sendForBenSign
      @updatepetition="updatepetition"
      :petitionDetails="petitionDetails"
      @hideMe="sendforBenSignModal = false"
      v-if="sendforBenSignModal"

    />

       <submitSignedDocument
      @updatepetition="updatepetition"
      :petitionDetails="petitionDetails"
      @hideMe="signedDocumentModal = false"
      v-if="signedDocumentModal"
      :ACTIVITYCODE="ACTIVITYCODE"
      :workFlowDetails="workFlowDetails"
    />

        <updateTracking
      @updatepetition="updatepetition"
      :petitionDetails="petitionDetails"
      :ACTIVITYCODE="ACTIVITYCODE"
      @hideMe="updateTrackingModal = false"
      v-if="updateTrackingModal"

    />

            <updateUSCISstatus
      @updatepetition="updatepetition"
      :petitionDetails="petitionDetails"
      :ACTIVITYCODE="ACTIVITYCODE"
      @hideMe="updateUSCISstatusModal = false"
      v-if="updateUSCISstatusModal"

    />
    <updateUSCISstatusH4HEAD
      @updatepetition="updatepetition"
      :petitionDetails="petitionDetails"
      :ACTIVITYCODE="ACTIVITYCODE"
      :dependentType="dependentType"
      @hideMe="updateUSCISstatusH4HEADModal = false"
      v-if="updateUSCISstatusH4HEADModal"

    />

    <createJobDecModal 
      :loadedFromPwdLibrary="loadedFromPwdLibrary"
       @updatepetition="updatepetition"
      :petitionDetails="petitionDetails"
      :ACTIVITYCODE="ACTIVITYCODE"
      @hideMe="hideJobDescription"
      v-if="editPermJobDescModal" /> 
      
      <!-- <linkPwd
      @updatepetition="updatepetition"
      :petitionDetails="petitionDetails"
      @hideMe="linkPwdModal = false"
      v-if="linkPwdModal"
    /> -->
    <linkPwdPopup
      @updatepetition="updatepetition"
      :petitionDetails="petitionDetails"
      :pwdId="checkProperty(petitionDetails,'pwdId')"
      @hideMe="linkPwdModal = false"
      :callfromActionPopup="true"
      :popUpTitle="checkProperty(petitionDetails,'pwdId')?'Change PWD':'Link PWD'"
      v-if="linkPwdModal"
    />

      <linkPerm
      @updatepetition="updatepetition"
      :petitionDetails="petitionDetails"
      @hideMe="linkPermModal = false"
      v-if="linkPermModal"
    />
    <generateSignedDocs
      @updatepetition="updatepetition"
      :petitionDetails="petitionDetails"
      @hideMe="generateSignedDocs = false"
      v-if="generateSignedDocs"
    />
    <linkI485
      @updatepetition="updatepetition"
      :petitionDetails="petitionDetails"
      @hideMe="linkI140Modal = false"
      v-if="linkI140Modal"
    />
    <linkLca 
    v-if="linkLCAModel" 
    @updatepetition="updatepetition" 
    :petitionDetails="petitionDetails"
    :lcaDetails="templcaDetails"
    @hideMe="linkLCAModel = false" 
    :isFromLCAList="true"
    :isFromPetition="true" 
    :popUpTitle="checkProperty(templcaDetails,'_id')?'Change LCA':'Link with Case'"
    :ACTIVITYCODE="'LINK_LCA'" 
    :lcaId="checkProperty(templcaDetails,'_id')?templcaDetails._id:''" />

<!-------PERM Popups-->
<!----
<div v-if="checkProperty(petitionDetails ,'type') == 3"  class=" custom_modal_sec documents__modal" :class="{  ' modalopen': editPermJobDescModal  }">
  <div class="custom_modal_overlay"  ></div> 
    <permJobDetailsForm
        @updatepetition="updatepetition"
        :petitionDetails="petitionDetails"
        @hideMe="hideJobDescription"
      
        :ACTIVITYCODE="ACTIVITYCODE"
      
      />
</div> 
--> 


<div v-if="checkProperty(petitionDetails ,'type') == 3 || loadedFromPwdLibrary"  class=" custom_modal_sec documents__modal" :class="{  ' modalopen': permAdvrtisementModal  }">
  <div class="custom_modal_overlay"  ></div> 

    <permAdvertisement
    :loadedFromPwdLibrary="loadedFromPwdLibrary"
      @updatepetition="updatepetition"
      :petition="petitionDetails"
      @hideMe="hideAdvrtisementModal"
     
     
    />
    </div>
   
    <div v-if="checkProperty(petitionDetails ,'type') == 3 && loadedFromPwdLibrary" class=" custom_modal_sec documents__modal" :class="{  ' modalopen': openPreparePermApplication  }">
        <div class="custom_modal_overlay"   ></div> 


      <permApplicationForm :loadedFromPwdLibrary="loadedFromPwdLibrary"  :petitionDetails="petitionDetails"   :ACTIVITYCODE="'PREPARE_PERM_APPLICATION'"  @hideMe="closepreparePerForm" />
  
    </div>
    <permJobActionModal
    :loadedFromPwdLibrary="loadedFromPwdLibrary"
    @updatepetition="updatepetition"
      :petitionDetails="petitionDetails"
      :ACTIVITYCODE="ACTIVITYCODE"
      @hideMe="openPermJobDescActions = false;"
      v-if="openPermJobDescActions"
    
    />
    <pwdReviewPopUp
    :loadedFromPwdLibrary="loadedFromPwdLibrary"
      @updatepetition="updatepetition"
      :petitionDetails="petitionDetails"
      :ACTIVITYCODE="ACTIVITYCODE"
      @hideMe="pwdReviewActions = false;"
      v-if="pwdReviewActions"
    
    />

   <uploadPwdDocument
   :loadedFromPwdLibrary="loadedFromPwdLibrary"
      @updatepetition="updatepetition"
      :petitionDetails="petitionDetails"
      :ACTIVITYCODE="ACTIVITYCODE"
      @hideMe="uploaPwdDocumentHide"
      v-if="uploaPwdDocumentPopUp"
      
      />
     

    <pwdEfilingResponseUpdate
    :loadedFromPwdLibrary="loadedFromPwdLibrary"
    @updatepetition="updatepetition"
      :petitionDetails="petitionDetails"
      :ACTIVITYCODE="'EFILE_PWD'"
      @hideMe="openPwdEfilingModal = false;"
      v-if="openPwdEfilingModal"

    />
    <pwdEfilingResponseUpdate
    
    :loadedFromPwdLibrary="loadedFromPwdLibrary"
    @updatepetition="updatepetition"
   :petitionDetails="petitionDetails"
   :ACTIVITYCODE="'EFILE_PWD_DOL'"
   @hideMe="openPwdEfilingModalDOL = false;"
   v-if="openPwdEfilingModalDOL"

 />
  <div v-if="checkProperty(petitionDetails ,'type') == 3 || loadedFromPwdLibrary"  class=" custom_modal_sec documents__modal" :class="{  ' modalopen': newPermJobDescModal  }">
    <div class="custom_modal_overlay"  ></div> 
      <newPermJobDescForm
         :loadedFromPwdLibrary="loadedFromPwdLibrary"
          @updatepetition="updatepetition"
          :petitionDetails="petitionDetails"
          @hideMe="hideNewJobDescription"
        
          :ACTIVITYCODE="ACTIVITYCODE"
        
        />
  </div>
  <div v-if="checkProperty(petitionDetails ,'type') == 3 || loadedFromPwdLibrary"  class=" custom_modal_sec documents__modal" :class="{  ' modalopen': newPermFieldsModal  }">
    <div class="custom_modal_overlay"  ></div> 
      <newPermFieldsForm
      :loadedFromPwdLibrary="loadedFromPwdLibrary"
          @updatepetition="updatepetition"
          :petitionDetails="petitionDetails"
          @hideMe="hideNewPermFields"
        
          :ACTIVITYCODE="ACTIVITYCODE"
        
        />
  </div>
    <pwdEfilingResponseUpdate
    :loadedFromPwdLibrary="loadedFromPwdLibrary"
    @updatepetition="updatepetition"
      :petitionDetails="petitionDetails"
      :ACTIVITYCODE="'UPDATE_PWD_RESPONSE'"
      @hideMe="openUpdatePwdResponseModal = false;"
      v-if="openUpdatePwdResponseModal"

    />
    <pwdEfilingResponseUpdateWithJd
    :loadedFromPwdLibrary="loadedFromPwdLibrary"
    @updatepetition="updatepetition"
      :petitionDetails="petitionDetails"
      :ACTIVITYCODE="ACTIVITYCODE"
      @hideMe="openUpdatePwdResponseWithJdModal = false;"
      v-if="openUpdatePwdResponseWithJdModal"

    />
    <updateJobDescription 
    
    :loadedFromPwdLibrary="loadedFromPwdLibrary"
      @updatepetition="updatepetition"
      :petitionDetails="petitionDetails"
      :ACTIVITYCODE="ACTIVITYCODE"
      @hideMe="updateJdModal = false;"
      v-if="updateJdModal"
    
    />

    
  
    

 <requestPermDraftReview
 :loadedFromPwdLibrary="loadedFromPwdLibrary"
 @openNewPermFieldsPopup="openNewPermFieldsPopup"
 @updatepetition="updatepetition"
   :petitionDetails="petitionDetails"
   :workFlowDetails="workFlowDetails"
   :ACTIVITYCODE="ACTIVITYCODE"
   @hideMe="openRequestPermDraftReview = false ;"
   v-if="openRequestPermDraftReview"
 />

 <permDollResponse 
 :loadedFromPwdLibrary="loadedFromPwdLibrary"
 @updatepetition="updatepetition"
 :petitionDetails="petitionDetails"
 :ACTIVITYCODE="ACTIVITYCODE"
 @hideMe="openpermDollResponse = false ;"
 v-if="openpermDollResponse"
 />

 <createI140   @updatepetition="updatepetition" :petitionDetails="petitionDetails"  @hideMe="openi140case = false ;"
 v-if="openi140case" >

  
 </createI140>

 <initiatePayment
      @updatepetition="updatepetition"
      :petitionDetails="petitionDetails"
      :ACTIVITYCODE="ACTIVITYCODE"
      @hideMe="initiatePaymentPopup = false ;"
      v-if="initiatePaymentPopup"
    />
    <addPayment
      @updatepetition="updatepetition"
      :petitionDetails="petitionDetails"
      :ACTIVITYCODE="ACTIVITYCODE"
      @hideMe="addPaymentPopup = false ;"
      v-if="addPaymentPopup"
    />
    <documentApproveReject 

    @updatepetition="updatepetition"
      :petitionDetails="petitionDetails"
      :ACTIVITYCODE="ACTIVITYCODE"
      @hideMe="documentApproveRejectPopup = false ;"
      v-if="documentApproveRejectPopup"
    />

    <addPwdApplicationNumber
    
      @updatepetition="updatepetition"
      :petitionDetails="petitionDetails"
      :ACTIVITYCODE="ACTIVITYCODE"
      @hideMe="openAddPwdApplicationNumber = false ;"
      v-if="openAddPwdApplicationNumber"
    />

    <deletedPwd
      @updatepetition="updatepetition"
      :petitionDetails="petitionDetails"
      @hideMe="deletePwdModal = false"
      v-if="deletePwdModal"
    />


    <vs-popup class="holamundo main-popup  confirm_modal"  title="Case Number" :active.sync="assignCaseNumberConformation">
    <div class="form-container">
      <div class="vx-row">
        <div class="vx-col w-full text-center">
        
        <vs-alert class="primary-alert mb-1" style="height: auto;">
          Case Number still not updated. Do you want to proceed with same Case Number?.
        </vs-alert>
        
          
        </div>
        
      </div>

            
     
    </div>
    <div class="popup-footer relative">
      <figure v-if="settingCaseNumber" class="loader"> <img src="@/assets/images/main/loader.gif" />
            </figure>
      
        <vs-button color="dark" @click="assignCaseNumberConformation=false;assignCaseNumberConformation=false;assignCaseNumberConformation=false;"   class="cancel" type="filled">Cancel</vs-button>
        <vs-button  color="success"  @click="updateCaseNumber()" class="save"  type="filled"> Yes</vs-button>
      
      </div>
</vs-popup>

<prepareRfeResponseDocuments
      @updatepetition="updatepetition"
      :petitionDetails="petitionDetails"
      @hideMe="openRefePrepareResDocsModal = false"
      v-if="openRefePrepareResDocsModal"
      :ACTIVITYCODE="ACTIVITYCODE"

    />
    <approveRfeResponse
    @updatepetition="updatepetition"
      :petitionDetails="petitionDetails"
      @hideMe="openReferesponseModal = false"
      v-if="openReferesponseModal"
      :ACTIVITYCODE="ACTIVITYCODE"
    />

  </div>
  
</template>

<script>
import linkPwdPopup from "@/views/actionpopups/linkPwdPopup.vue"
import createJobDecModal from "@/views/actionpopups/perm/createJobDecModal.vue"; 
import uploadPwdDocument from "@/views/actionpopups/perm/uploadPwdDocument.vue"; 
import changeCaseType from "@/views/actionpopups/changeCaseType.vue";
import assignCaseNumber from "@/views/actionpopups/assignCaseNumber.vue";
import submitToLawFirm from "@/views/actionpopups/submitToLawFirm.vue";
import updateInternalStatus from "@/views/actionpopups/updateInternalStatus.vue";
import generateSignedDocs from "@/views/actionpopups/generateSignedDocs.vue";
import premiumProcessing from "@/views/actionpopups/premiumProcessing.vue";
import updateLCA from "@/views/actionpopups/updateLCA.vue";
import assignActivity from "@/views/actionpopups/assignActivity.vue";
import reAssignActivity from "@/views/actionpopups/reAssign.vue";
import updateDeadline from "@/views/actionpopups/updateDeadline.vue";
import sendForSign from "@/views/actionpopups/sendForSign.vue";
import submitSignedDocument from "@/views/actionpopups/submitSignedDocument.vue";
import sendForBenSign from "@/views/actionpopups/sendForBenSign.vue";
import linkPerm from "@/views/actionpopups/linkPerm.vue";
import linkPwd from "@/views/actionpopups/linkPwd.vue";
import linkI485 from "@/views/actionpopups/linkI485.vue"
import linkLca from "@/views/actionpopups/linkLca.vue";

import updateTracking from "@/views/actionpopups/updateTracking.vue";
import updateUSCISstatus from "@/views/actionpopups/updateUSCISstatus.vue";
import updateUSCISstatusH4HEAD from "@/views/actionpopups/updateUSCISstatusH4H4EAD.vue";
import addPayment from "@/views/actionpopups/perm/addPayment.vue"; 

import newPermFieldsForm from "@/views/actionpopups/perm/newPermFieldsForm.vue";
import newPermJobDescForm from "@/views/actionpopups/perm/newPermJobDescForm.vue"; 
import  permJobDetailsForm from "@/views/actionpopups/perm/permJobDetailsForm.vue"; 
import permJobActionModal from "@/views/actionpopups/perm/permJobActionModal.vue";
import pwdReviewPopUp  from "@/views/actionpopups/perm/pwdReviewPopUp.vue";

import  permAdvertisement from "@/views/actionpopups/perm/permAdvertisement.vue"; 
import  pwdEfilingResponseUpdate from "@/views/actionpopups/perm/pwdEfilingResponseUpdate.vue"; 

import  pwdEfilingResponseUpdateWithJd from "@/views/actionpopups/perm/pwdEfilingResponseUpdateWithJd.vue"; 
import  updateJobDescription from "@/views/actionpopups/perm/updateJobDescription.vue"; 


import permApplicationForm from "@/views/actionpopups/perm/permApplicationForm.vue"; 
import requestPermDraftReview from "@/views/actionpopups/perm/requestPermDraft.vue"; 
import permDollResponse from "@/views/actionpopups/perm/permDollResponse.vue";
import initiatePayment from "@/views/actionpopups/perm/initiatePayment.vue"; 

import createI140 from "@/views/actionpopups/perm/createI140.vue";
import addPwdApplicationNumber from "@/views/actionpopups/perm/addPwdApplicationNumber.vue";
import documentApproveReject from "@/views/actionpopups/documentApproveReject.vue";
import deletedPwd from "@/views/actionpopups/perm/deletedPwd.vue";


//RFE POPUS
import prepareRfeResponseDocuments from "@/views/actionpopups/prepareRfeResponseDocuments.vue";
import approveRfeResponse from "@/views/actionpopups/approveRfeResponse.vue";


import * as _ from "lodash";


import JQuery from 'jquery';
  
export default {
  components: {
    linkPwdPopup,
    deletedPwd,
    addPwdApplicationNumber,
    linkI485,
    newPermFieldsForm,
    newPermJobDescForm,
    reAssignActivity,
    linkPerm,
    linkPwd,
    sendForBenSign,
    documentApproveReject,
    addPayment,
    updateInternalStatus,
    pwdEfilingResponseUpdateWithJd,
    updateJobDescription,
    createJobDecModal,
    uploadPwdDocument,
    createI140,
    changeCaseType,
    assignCaseNumber,
    submitToLawFirm,
    premiumProcessing,
    updateLCA,
    generateSignedDocs,
    assignActivity,
    updateDeadline,
    sendForSign,
    submitSignedDocument,
    updateTracking,
    updateUSCISstatus,
    updateUSCISstatusH4HEAD,
    permJobDetailsForm,
    permAdvertisement,
    pwdEfilingResponseUpdate,
    permApplicationForm,
    requestPermDraftReview,
    permJobActionModal, 
    permDollResponse,
    initiatePayment,
    linkLca,
    pwdReviewPopUp,

    //RFE 
    prepareRfeResponseDocuments,
    approveRfeResponse
  },
  props: {
    petitionDetails: {
      type: Object,
      default: null,
    },
    
    workFlowDetails: {
      type: Object,
      default: null,
    },
    lcaDetails: {
      type: Object,
      default: null,
    },
    formsAndLetters: {
      type: Array,
      default: null,
    },
    loadedFromPwdLibrary:{
      type: Boolean,
      default: false,

    }
  },
  methods: {



    opendeletePwdModal(){
      this.deletePwdModal = true;
    },
    
    openPwdReviewPopUpModal(activity){
      this.ACTIVITYCODE = activity;
      this.pwdReviewActions =true
    },
   
    openAddPwdApplicationNumberModal(activity){
      this.ACTIVITYCODE = activity;
       this.openAddPwdApplicationNumber =true;
    },


    updateCaseNumber(){
      
      let self = this;
      let postData = {
        caseNo: self.petitionDetails.caseNo.trim(),
        petitionId: self.petitionDetails["_id"],
        subTypeName: self.checkProperty(
          self.petitionDetails,
          "subTypeDetails",
          "name"
        ),
        typeName: self.checkProperty(
          self.petitionDetails,
          "typeDetails",
          "name"
        ),
      };
      this.settingCaseNumber = true;
      let path ="/petition/assign-custom-caseno";
      if([3].indexOf(this.checkProperty(this.petitionDetails,'typeDetails', 'id' )) >-1 &&  [15].indexOf(this.checkProperty(this.petitionDetails,'subTypeDetails', 'id' )) >-1){
              path ="/perm/assign-custom-caseno";
           }
      this.$store
        .dispatch("commonAction", {
          data: postData,
          path: path,
        })
        .then((response) => {
          self.showToster({ message: response.message, isError: false });
          self.assignCaseNumberConformation = false;
          self.settingCaseNumber = false;
          setTimeout(()=>{
         
          if(self.managePop  && _.has(self,self.managePop)){
            self[self.managePop] =true;
          }
          self.caseNumberIsUpdated = true;
          self.$emit('caseNumberAssigned')
         // self.updatepetition();
        });
         
    
    
    
        })
        .catch((err) => {
          this.settingCaseNumber = false;
          this.showToster({ message: err, isError: true });
        });
    
    },
    openAssignCnoPop(action=false ,managePop=''){
      //this.showToster({message:'New Case Number must be assigned to complete this action.',isError:true });
    this.settingCaseNumber =false;
    this.assignCaseNumberConformation = action;
    this.managePop =managePop;
    
    
    },



    updateCaseNumber(){
      
      let self = this;
      let postData = {
        caseNo: self.petitionDetails.caseNo.trim(),
        petitionId: self.petitionDetails["_id"],
        subTypeName: self.checkProperty(
          self.petitionDetails,
          "subTypeDetails",
          "name"
        ),
        typeName: self.checkProperty(
          self.petitionDetails,
          "typeDetails",
          "name"
        ),
      };
      this.settingCaseNumber = true;
      let path ="/petition/assign-custom-caseno";
      if([3].indexOf(this.checkProperty(this.petitionDetails,'typeDetails', 'id' )) >-1 &&  [15].indexOf(this.checkProperty(this.petitionDetails,'subTypeDetails', 'id' )) >-1){
              path ="/perm/assign-custom-caseno";
           }
      this.$store
        .dispatch("commonAction", {
          data: postData,
          path: path,
        })
        .then((response) => {
          self.showToster({ message: response.message, isError: false });
          self.assignCaseNumberConformation = false;
          self.settingCaseNumber = false;
          setTimeout(()=>{
         
          if(self.managePop  && _.has(self,self.managePop)){
            self[self.managePop] =true;
          }
          self.caseNumberIsUpdated = true;
          self.$emit('caseNumberAssigned')
         // self.updatepetition();
        });
         
    
    
    
        })
        .catch((err) => {
          this.settingCaseNumber = false;
          this.showToster({ message: err, isError: true });
        });
    
    },
    openAssignCnoPop(action=false ,managePop=''){
      //this.showToster({message:'New Case Number must be assigned to complete this action.',isError:true });
    this.settingCaseNumber =false;
    this.assignCaseNumberConformation = action;
    this.managePop =managePop;
    
    
    },

    opendocumentApproveRejectPopup(ACTIVITYCODE){
     
     this.ACTIVITYCODE = ACTIVITYCODE;
     this.documentApproveRejectPopup =true;
     
   },
    openupdateInternalStatusModal(){
      this.updateInternalStatusModal =true;
    },
    openInitiatePaymentPopup(ACTIVITYCODE){
     
      this.ACTIVITYCODE = ACTIVITYCODE;
      this.initiatePaymentPopup =true;
      
    },
    openaddPaymentPopup(ACTIVITYCODE){
     
     this.ACTIVITYCODE = ACTIVITYCODE;
     this.addPaymentPopup =true;
     
   },

    openUploadPwdDocuments(ACTIVITYCODE){
      this.ACTIVITYCODE = ACTIVITYCODE;
      this.uploaPwdDocumentPopUp =true
    },
   
      uploaPwdDocumentHide(){
        this.uploaPwdDocumentPopUp =false;

      },
    getAssignmentText(code ,actionLable){
      let listcode='';
      if(code == "ASSIGN_SUPERVISOR"){
        listcode="SUPERVISOR_LIST"
      }
       if(code == "ASSIGN_PARALEGAL"){
        listcode="PARALEGAL_LIST"
      }
       if(code == "ASSIGN_DOCUMENTATION_MANAGER"){
        listcode="DOCUMENTATION_MANAGER_LIST"
      }
      if(code == "ASSIGN_DOCUMENTATION_EXECUTIVE"){
        listcode="DOCUMENTATION_EXECUTIVE_LIST"
      }
      if(code == "ASSIGN_ATTORNEY"){
        listcode="ATTORNEY_LIST"
      }
      if(code == "REQUEST_PETITIONER_SIGN"){
        listcode="DOC_SIGNER_LIST"
      }
      if(code == "ASSIGN_LCA_EXECUTIVE"){
        listcode="ASSIGN_LCA_EXECUTIVE"
      }
      
      let roleNames=[];
        if(listcode!='' && _.has( this.workFlowDetails ,'config')){
        let tempList =[];
        let activytList =  _.find(this.workFlowDetails.config , {"code":listcode}); 
        _.forEach(activytList.editors,(item)=>{
          if(tempList.indexOf(item['roleId']) <=-1){
            roleNames.push(item['roleName']);
            tempList.push(item['roleId']);
          }
         
         
        })
        
       
        }
        if(roleNames.length>0){
          return 'Assign '+roleNames.join(' / ')

        }else{
          return actionLable;
        }

    },
    openpermDollResponseModal(ACTIVITYCODE){
      this.ACTIVITYCODE = ACTIVITYCODE;
      this.openpermDollResponse =true;
    },
    openi140() {
      this.openi140case =true;

    },
    updatepetition() {
      this.$emit("updatepetition", "Case Details");

    },
    changeCaseType() {
      this.changeCaseTypeModal = true;
    },
    assignCaseNumber(isEdit = false) {
      this.assignCaseNumberModal = true;
      if(isEdit){
        this.isCaseNumberEdit = isEdit;
      }
    },
    opensubmitToLawFirm() {
      this.submitToLawFirmModal = true;
    },
    openpremiumProcessing() {
      this.premiumProcessingModal = true;
    },
    openLinkPerm() {
      this.linkPermModal = true;
    },
    openLinkPwd() {
      this.linkPwdModal = true;
    },
    openLink140(){
      this.linkI140Modal = true;
    },
    openLinkLCA() {
      this.linkLCAModel = true;
    },
    openupdateLCA() {
      this.updateLCAModal = true;
    },
    getscannedCopiesList(isThisFromActionMenu=false){
    
        
             
               let finalList =[];
           if(this.checkProperty(this.petitionDetails ,'_id' )){    
             let postData ={petitionId:this.petitionDetails._id ,'page':1 ,'perpage':100000};
            this.$store.dispatch("getList" ,{data:postData,path:"/petition/scanned-copies-list"})
            .then(response => {
               
            if(_.has(response , 'list')){
              this.scannedCopiesList = response['list'];

              if(isThisFromActionMenu){
                if( this.checkProperty(this.scannedCopiesList , 'length') >0 || (this.checkProperty(this.scannedCopiesList , 'length') <=0 || [3,4].indexOf(this.getUserRoleId)>-1)){
                  this.assignActivityPopup =true;
                }else{
                  this.showToster({message:"Scanned Documents are required",isError:true });
                  this.$store.dispatch("setPetitionTab", 'Scanned Documents');
                 // alert('jdshjhsdh')
                }
               
              }
             
                 

            }

           
            
            })
          }
         }, 

openReassignActivityPopup(rolesList, popUpTitle, lableTitle, ACTIVITYCODE) {
   
   this.rolesList = rolesList;
       this.popUpTitle = popUpTitle;
       if(ACTIVITYCODE!='ASSIGN_LCA_EXECUTIVE' && this.getAssignmentText(ACTIVITYCODE)!=null ){
       this.popUpTitle = this.getAssignmentText(ACTIVITYCODE);
       }

       this.lableTitle = lableTitle;
       this.ACTIVITYCODE = ACTIVITYCODE;
   if( (ACTIVITYCODE=='SUBMIT_TO_USCIS' || ACTIVITYCODE=='SUPERVISOR_FORMS_REVIEW') && !( [3].indexOf(this.checkProperty(this.petitionDetails ,'typeDetails' ,'id'))>-1 && [15].indexOf(this.checkProperty(this.petitionDetails ,'subTypeDetails' ,'id'))>-1) ){
     this.getscannedCopiesList(true);

   }else{

       
       this.reAssignAeactivityPopup = true;
   }
   
 },     
    openassignActivityPopup(rolesList, popUpTitle, lableTitle, ACTIVITYCODE) {
     
        

      
   
         this.rolesList = rolesList;
          this.popUpTitle = popUpTitle;
          if(ACTIVITYCODE!='ASSIGN_LCA_EXECUTIVE' && this.getAssignmentText(ACTIVITYCODE)!=null ){
          this.popUpTitle = this.getAssignmentText(ACTIVITYCODE);
          }

          this.lableTitle = lableTitle;
          this.ACTIVITYCODE = ACTIVITYCODE;


        if( this.ACTIVITYCODE !='ASSIGN_LCA_EXECUTIVE' && this.caseNumberIsUpdated ==false &&  this.checkProperty(this.petitionDetails , 'allowCustomCaseNo') && this.petitionDetails.completedActivities.indexOf('ASSIGN_CUSTOM_CASE_NO')<=-1 ){
          ////this.showToster({message:'New Case Number must be assigned to complete this action.',isError:true });
          if((this.checkActivityRoles('MANAGER_LIST') || (this.checkActivityRoles('ASSIGN_SUPERVISOR') || ( !this.checkActivityRoles('ASSIGN_SUPERVISOR') && this.checkActivityRoles('ASSIGN_PARALEGAL') )  )   ) && this.checkNoNotifyUserIds){
            this.openAssignCnoPop(true ,'assignActivityPopup');
            return false;
          }else{
            this.showToster({message:'New Case Number must be assigned to complete this action.',isError:true });
            return false;
            
          }

          
        }
      if( (ACTIVITYCODE=='SUBMIT_TO_USCIS' || ACTIVITYCODE=='SUPERVISOR_FORMS_REVIEW') && !( [3].indexOf(this.checkProperty(this.petitionDetails ,'typeDetails' ,'id'))>-1 && [15].indexOf(this.checkProperty(this.petitionDetails ,'subTypeDetails' ,'id'))>-1) ){
        this.getscannedCopiesList(true);

      }else{

          
          this.assignActivityPopup = true;
      }
      
    },
    opencaseDeadlinePopup() {
      this.caseDeadlinePopup = true;
    },

    opensendforBenSignModal(ACTIVITYCODE) {
      this.ACTIVITYCODE = ACTIVITYCODE;
      this.sendforBenSignModal = true;
     
    },
    openGenerateSingedDocs(){
      this.generateSignedDocs = true;
    },
   

    opensendforSignModal(rolesList) {
      this.rolesList =rolesList;
      this.sendforSignModal = true;
    },
    openSignedDocumentModel(ACTIVITYCODE){
      
      this.ACTIVITYCODE = ACTIVITYCODE;
      this.signedDocumentModal= true;
    },
    openTrackingModel(ACTIVITYCODE){
      
      this.ACTIVITYCODE = ACTIVITYCODE;
      this.updateTrackingModal = true;
    },
    openuscisresponse(ACTIVITYCODE){
      this.ACTIVITYCODE = ACTIVITYCODE;
      this.updateUSCISstatusModal = true;
    },
    openuscisresponseH4HEAD(val ='',ACTIVITYCODE=''){
      this.ACTIVITYCODE = ACTIVITYCODE;
      this.dependentType = val
      this.updateUSCISstatusH4HEADModal = true;
    },
    getvisatypes() {
      this.$store.dispatch("getvisatypes").then((response) => {
        this.visatypes = response;
      });
    },
    getAssignedUserslist() {
      let postData = {
        "petitionId": '',
		   "page": 1,
		  "perpage":250000000
      };

      postData['petitionId'] = this.checkProperty(this.petitionDetails ,'_id');

      if(!this.checkProperty(this.petitionDetails ,'_id')){
        return false;
      }
      this.$store
        .dispatch("commonAction", {
          data: postData,
          path: "petition/assigned-user-list",
        })
        .then((response) => {
          if (this.checkProperty(response, "list", "length") > 0) {
            this.assignedUsersList = response["list"];
         
          }
        })
        .catch((error) => {});
    },

    //Perm methods
    openNewPermFieldsPopup(){
      const $ = JQuery;
      $('body').addClass('opened-side-modal')
      this.newPermFieldsModal = true;
    },
    openPerDraftForm(ACTIVITYCODE){
      this.ACTIVITYCODE = ACTIVITYCODE;
      const $ = JQuery;
      this.openRequestPermDraftReview = true
      // if(_.has(this.petitionDetails,'completedActivities') && this.checkProperty(this.petitionDetails,'completedActivities') && this.petitionDetails['completedActivities'].indexOf('PERM_MISSING_EFILE_INFO')<=-1 ){
      //   $('body').addClass('opened-side-modal')
      //   this.newPermFieldsModal = true;
      // }
      // else{
      //   this.openRequestPermDraftReview = true
      // }
    },
    hideNewPermFields(){
      this.newPermFieldsModal =false;
      this.updatepetition();
      const $ = JQuery;
      $('body').removeClass('opened-side-modal')
    },

    openPermJobDescActionsModal(ACTIVITYCODE){
      
      
      this.ACTIVITYCODE = ACTIVITYCODE;
      this.openPermJobDescActions =true;
    },
    openJobDescription(ACTIVITYCODE){
      this.ACTIVITYCODE = ACTIVITYCODE;
      const $ = JQuery;
     // $('body').addClass('opened-side-modal')
     if( this.caseNumberIsUpdated ==false &&  this.ACTIVITYCODE == 'CREATE_JOB_DESC' && this.checkProperty(this.petitionDetails , 'allowCustomCaseNo') && this.petitionDetails.completedActivities.indexOf('ASSIGN_CUSTOM_CASE_NO')<=-1 ){
      ////this.showToster({message:'New Case Number must be assigned to complete this action.',isError:true }); 
      this.managePop ='editPermJobDescModal'; 
      //alert(this.checkActivityRoles('ASSIGN_SUPERVISOR'))
      if((this.checkActivityRoles('MANAGER_LIST') || (this.checkActivityRoles('ASSIGN_SUPERVISOR') || ( !this.checkActivityRoles('ASSIGN_SUPERVISOR') && this.checkActivityRoles('ASSIGN_PARALEGAL') ) )   ) && this.checkNoNotifyUserIds){
        this.openAssignCnoPop(true ,'editPermJobDescModal');
        return false;
      }else{
        this.showToster({message:'New Case Number must be assigned to complete this action.',isError:true });
            return false;
        
      }
      }
     
     
      this.editPermJobDescModal =true;
    },
    hideJobDescription(){
      this.editPermJobDescModal =false;
      this.updatepetition();
      const $ = JQuery;
      $('body').removeClass('opened-side-modal')
     
     
    },
    openPermAdvrtisementModal(){
      const $ = JQuery;
         
          $('body').addClass('opened-side-modal')
     
      this.permAdvrtisementModal =true;
    },
    hideAdvrtisementModal(){
      $('body').removeClass('opened-side-modal')
      this.permAdvrtisementModal =false;
      this.updatepetition();
    },
    openPwdEfilingDOL(){
      //this.openPwdEfilingModalDOL =true;
      //this.ACTIVITYCODE = ACTIVITYCODE;
      const $ = JQuery;
      if(_.has(this.petitionDetails,'completedActivities') && this.checkProperty(this.petitionDetails,'completedActivities') && this.petitionDetails['completedActivities'].indexOf('PWD_MISSING_EFILE_INFO')<=-1){
        $('body').addClass('opened-side-modal')
       
        // if(this.loadedFromPwdLibrary){
        //   this.openPwdEfilingModalDOL =true;
        // }else{
        //   this.newPermJobDescModal = true; 
        // }

        this.newPermJobDescModal = true; 
       
       
      }
      else{
        this.openPwdEfilingModalDOL =true;
      }
  
   },
   hideNewJobDescription(){
      this.newPermJobDescModal =false;
      this.updatepetition();
      const $ = JQuery;
      $('body').removeClass('opened-side-modal')
     
     
    },
    openPwdEfiling(){
    
      this.openPwdEfilingModal =true;
   
    },
    openUpdatePwdResponse(){
      this.openUpdatePwdResponseModal= true;
    },
    openUpdatePwdResponseWithJd(ACTIVITYCODE ="UPDATE_PWD_RESPONSE_WITH_JD"){
      this.ACTIVITYCODE = ACTIVITYCODE;
     
      this.openUpdatePwdResponseWithJdModal= true;
    },
    openUpdateJdModal(ACTIVITYCODE){
      
      this.ACTIVITYCODE = ACTIVITYCODE;
      this.updateJdModal =true;
    },
    openpreparePerForm(){
      this.openPreparePermApplication = true;
      const $ = JQuery;
      $('body').addClass('opened-side-modal')
    },
    closepreparePerForm(){
      this.openPreparePermApplication = false;
      const $ = JQuery;
      $('body').removeClass('opened-side-modal');
      this.updatepetition();
    },
   
   //rfe actions
   openRefePrepareResDocsPopUp(ACTIVITYCODE){
      
      this.ACTIVITYCODE = ACTIVITYCODE;
      this.openRefePrepareResDocsModal= true;
    },
    //
    openReferesponsePopUp(ACTIVITYCODE){
      
      this.ACTIVITYCODE = ACTIVITYCODE;
      this.openReferesponseModal= true;
    },
   
  },
  mounted() {
    this.getAssignedUserslist();
    this.getscannedCopiesList();
    this.templcaDetails = _.cloneDeep(this.lcaDetails);
    setTimeout(()=>{
      this.templcaDetails =  _.cloneDeep(this.lcaDetails);
    } ,100)
  },
  data: () => ({
    deletePwdModal:false,
    pwdReviewActions:false,
    openAddPwdApplicationNumber:false,
    caseNumberIsUpdated:false,
    settingCaseNumber:false,
    assignCaseNumberConformation:false,
    managePop:'',
    templcaDetails:null,
    documentApproveRejectPopup:false,
    addPaymentPopup:false,
    updateInternalStatusModal:false,
    initiatePaymentPopup:false,
    uploaPwdDocumentPopUp:false,
    scannedCopiesList:[],
    formerrors: {
      msg: "",
    },
    openi140case:false,

    sendforBenSignModal:false,
    submitBenSignedDocument:false,
    generateSignedDocs:false,
    linkPermModal:false,
    linkPwdModal:false,
    linkI140Modal:false,
    linkLCAModel:false,
    signedDocumentModal:false,
    isCaseNumberEdit:false,
    sendforSignModal: false,
    updateLCAModal: false,
    ACTIVITY_CODE: null,
    popUpTitle: null,
    lableTitle: null,
    reAssignAeactivityPopup:false,
    assignActivityPopup: false,
    submitToLawFirmModal: false,
    assignCaseNumberModal: false,
    changeCaseTypeModal: false,
    premiumProcessingModal: false,
    updateTrackingModal:false,
    assignedUsersList: [],
    selectedAssignedUsers: null,
    visatypes: [],
    rolesList: [],
    selectedCaseType: null,
    caseDeadlinePopup: false,
    updateUSCISstatusModal:false,
    updateUSCISstatusH4HEADModal:false,
    dependentType:'',

    //Perm Veriables
    newPermFieldsModal:false,
    newPermJobDescModal:false,
    editPermJobDescModal:false,
    openPermJobDescActions:false,
    permAdvrtisementModal:false,
    openPwdEfilingModal:false,
    openPwdEfilingModalDOL:false,
    openUpdatePwdResponseModal:false,
    openUpdatePwdResponseWithJdModal:false,
    updateJdModal:false,
    openPreparePermApplication:false,
    openRequestPermDraftReview:false,
    ACTIVITYCODE:'',
    openpermDollResponse:false,

    //RFE 
    openRefePrepareResDocsModal:false,
    openReferesponseModal:false,

  }),
  computed:{
    checkNoNotifyUserIds(){
      let returnValue =true;
      if(_.has(this.petitionDetails, 'noNotifyUserIds')  ){
        if(this.petitionDetails['noNotifyUserIds'].length>0){
          if(this.petitionDetails['noNotifyUserIds'].indexOf(this.getUserData['userId']) >-1){
            returnValue = false;
          }

        }

      }
      return returnValue;
    },
    checkActivityRoles(){
      let returnValue =false;
     
      return (code='')=>{
        
        if(this.workFlowDetails && _.has(this.workFlowDetails ,'config')){
          let activity = _.find(this.workFlowDetails['config'] ,{'actionRequired':'Yes','code':code});
         
          if(activity && _.has(activity ,'editors') && activity['editors'].length>0){
            let editors =_.map(activity.editors, 'roleId');
            if(editors.indexOf(this.getUserRoleId) >-1){
              returnValue =true;
            }
          }



        }
        
        return returnValue;

      }
    }
  }
};
</script>
