<template>

 <form  data-vv-scope="newinvitepetitionerform">
          <div class="form-container">
            <div class="vx-row">
              <div class="vx-col w-full">
                <div class="form_group">
              <label class="form_label">Company Name<em>*</em></label>
                  <vs-input @click="formerrors.msg=''" type="text" class="w-full no-icon-border" name="companyname" data-vv-as="Company Name" v-model="newPetitioner.name" v-validate="'required'" />
                  <span class="text-danger text-sm" v-show="errors.has('newinvitepetitionerform.companyname')">{{ errors.first("newinvitepetitionerform.companyname") }}</span>
                </div>
              </div>
              
              <div class="vx-col w-1/2">
                <div class="form_group">
                  <label class="form_label">First Name<em>*</em></label>
                  <vs-input type="text" class="w-full no-icon-border" name="adminFirstName" data-vv-as="First Name" v-model="newPetitioner.adminFirstName" v-validate="'required'" />
                    <span class="text-danger text-sm" v-show="errors.has('newinvitepetitionerform.adminFirstName')">{{ errors.first("newinvitepetitionerform.adminFirstName") }}</span>
                </div>
              </div>
              <div class="vx-col w-1/2">
              <div class="form_group">
                  <label class="form_label"> Last Name<em>*</em></label>
                  <vs-input type="text" class="w-full no-icon-border" name="adminLastName" data-vv-as="Last Name" v-model="newPetitioner.adminLastName" v-validate="'required'" />
                  <span class="text-danger text-sm" v-show="errors.has('newinvitepetitionerform.adminLastName')">{{ errors.first("newinvitepetitionerform.adminLastName") }}</span>
                </div>
              
              </div>
              
              <div class="vx-col w-1/2">
                  <div class="form_group">
                  <label class="form_label">Email ID<em>*</em></label>
                  <vs-input v-model="newPetitioner.email" class="w-full no-icon-border" key="email" name="email" data-vv-as="Email" autocomplete="off" autocorrect="off" autocapitalize="none" v-validate="'required|email'" />
                  <span class="text-danger text-sm" v-show="errors.has('newinvitepetitionerform.email')">{{ errors.first("newinvitepetitionerform.email") }}</span>
                  </div>
                </div>
                <div class="vx-col w-1/2"  @click="formerrors.msg=''">
                <div class="form_group ph_number">
                <div class="vs-component">
                <label for="" class="form_label">Phone Number<em>*</em></label>
                <VuePhoneNumberInput
                  autocomplete="off" 
                  autocorrect="off"
                  icon-pack="feather"
                  class="w-full no-icon-border"
                  :no-example="false"
                  v-validate="'required'"
                  data-vv-as="Phone Number"
                  name="phone"
                  v-bind="vuePhone.props"
                  default-country-code="US"
                  placeholder="Number"
                  :no-country-selector="false"
                  v-model="newPetitioner.phone"
                    @update="updatePetitionerPhone"
                    :preferred-countries="['US', 'IN']"
                  /> 
                  <span class="text-danger text-sm"   v-show="!isPetitionerPhoneValid && !errors.has('newinvitepetitionerform.phone')" >*Invalid phone number - Please enter a valid one</span>
                <span class="text-danger text-sm" v-show="errors.has('newinvitepetitionerform.phone')">{{ errors.first("newinvitepetitionerform.phone") }}</span>
                </div>      
                </div>     
              </div>
            
            </div>

            <div class="text-danger text-sm formerrors" v-show="formerrors.msg">
              <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
                icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
            </div>
          </div>
          <div class="popup-footer">
            <vs-button color="dark" @click="closenewPetPopup()" class="cancel" type="filled">Cancel</vs-button>
            <vs-button color="success" @click="petitionerInvite()" class="save" type="filled">Submit</vs-button>
          </div>
         </form> 

</template>



<script>


import Datepicker from "vuejs-datepicker-inv";

import DateRangePicker from "vue2-daterange-picker";
import "vue2-daterange-picker/dist/vue2-daterange-picker.css";
import moment from 'moment'
import PhoneMaskInput from "vue-phone-mask-input";
import * as _ from "lodash";
import VuePhoneNumberInput from 'vue-phone-number-input';
import 'vue-phone-number-input/dist/vue-phone-number-input.css';  

export default {
  
  components: {
    
    VuePhoneNumberInput,
    Datepicker,
    DateRangePicker,
    moment,
    PhoneMaskInput
  },
  data: () => ({
      createdNetitioner:null,
      isPetitionerPhoneValid:true,
    newPetitioner: {
        firstName: "",
        lastName:"",
        adminFirstName: "",
        adminLastName:"",
        roleId:50,
        email: "",
        phone:"",
        active:true,
        accountType: "Corporate",
        address: {
          "line1": "",
          "line2": "",
          "locationId": "",
          "stateId": "",
          "countryId": 231,
          "zipcode": ""
        }
      },
    count:0,
    vuePhone:{
        props:{
          translations:{
            phoneNumberLabel:"Phone Number"
          }
        }

      },

    formerrors: {
      msg: ""
    },
   
    saveBenbtn:false,
    

       
  }),
  watch: {
   
  },
  methods:{
      closenewPetPopup(){
          this.$emit('closenewPetPopup' ,this.createdNetitioner )

      },

      updatePetitionerPhone(item) {
         
       this.isPetitionerPhoneValid =true;
      if (item.isValid) {
        
       this.newPetitioner.phoneCountryCode = {countryCode:item.countryCode,countryCallingCode:item.countryCallingCode};
       this.newPetitioner.phone = item.nationalNumber;
       
      }else{
        this.isPetitionerPhoneValid =false;
      }
     },


       petitionerInvite() {
           this.createdNetitioner =null;
        Object.assign(this.formerrors, {  msg: ''  });
       
        this.$validator.validateAll('newinvitepetitionerform').then(result => {
          if (result && this.isPetitionerPhoneValid) {
            this.$store.dispatch("commonAction", {
              data:this.newPetitioner,
              path: "/auth/invite-petitioner",})
              .then(response => {
               
                if (response.error) {
                  Object.assign(this.formerrors, {
                    msg: response.error.message
                  });
                } else {

                    this.createdNetitioner =response['data'];
                   this.showToster({message:response.data.message,isError:false});
                   this.closenewPetPopup();
                  
                }
               

                // this.$router.go('/beneficiaries');
              }).catch((err)=>{
                Object.assign(this.formerrors, {
                    msg: err
                  });

              })
          }
        });
      },
   
  },
  mounted() {
  
    this.count =0;
        
  }
};
</script>