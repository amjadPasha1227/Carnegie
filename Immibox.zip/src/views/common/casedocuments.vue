<template>
<div class="form-container mart20 casedocuments__" :class="wrapclass">
  <h3 class="small-header nowrap_whtspc" v-if="showTitle">

            <template v-if="title !=''"> {{ title }}</template>
            <template v-else> List of documents needs to be updated</template>
            <span class="file-type">(File Type: PDF, DOC, JPEG, PNG. Max file size: 1MB)</span>
        </h3>
            <!-- :display="checkProperty(item ,'display')?true:false" -->
    <div class="documents_group case_documents">
        <div class="vx-row delete-row" v-for="(item, index) in docslist" :key="index">
            <template v-if="true">
            <immiuploader
            :noteInfo="item.noteInfo"
            :docMainCategory="docMainCategory"
             @emitUploadingAction="emitUploadingAction" 
             :docslistIndex="index"
             :ref="'uploader_'+index"
              :popUpIndex="index" 
              :petition="petition" 
            :showToBeneficiary="showToBeneficiary" 
            :tplsection="tplsection" 
            :fileAcceptType="item['fileAcceptType']?item['fileAcceptType']:''"
             :callExtract="checkProperty(item,'callExtract')?true:false" 
             :tplkey="item.fieldName"
              :display="item.display?item.display:false"
            :deleteDocPermenantly="deleteDocPermenantly"
            :tooltip="item.tooltip" :multiple="true" 
            :wrapclass="''"
            :cid="item.cid?item.cid:cid"
            :fieldsArray="fieldsArray"
            :formscope="formscope" 
            :required="item.required"
            :fieldName="item.fieldName"
            v-model="value[item.fieldName]" 
            :label="item.label"
            :callfromPetitionDocs="callfromPetitionDocs"
            :vvas="'Document(s)'"
           
           />
           </template>
           <template v-else-if="checkProperty(item,'fieldName') && canRenderField(item.fieldName,fieldsArray, false,tplsection,checkProperty(item, 'fieldName'))">
            <div class="upload_blocks">
            <div class="upload_block"> 
                
                <label class="form_label" ><span v-html="getCustomLabel(item)" style="display:inline"></span>      <div class="IB_tooltip" v-if="checkProperty(item,'tooltip')">
                    <span>
                      <info-icon size="1.5x" class="custom-class"></info-icon>
                    </span>
                    <div class="tooltip_cnt">
                      <p>
                        {{tooltip}}
                      </p>
                    </div>
                  </div></label>
                <div class="upload_cnt" @click="openUploadesPop(item)">
                <img class="file-icon" src="@/assets/images/main/file-upload.svg" />Upload
                </div>
               <input type="hidden"  v-model="value[item.fieldName]" :name="(item.fieldName)+index"  :data-vv-as="'Document(s)'"
                v-validate="checkFieldIsRequired({'key':item.fieldName,'section':tplsection, 'fieldsArray':fieldsArray, 'required':item.required })? 'required':'' "
                >
                <p v-show="errors.has((formscope!=''?formscope+'.':'')+(item.fieldName)+index)" class="text-danger text-sm-doc">{{ errors.first((formscope!=''?formscope+'.':'')+(item.fieldName)+index) }} </p>
                <p v-show="showFileTypeError" class="text-danger text-sm-doc">{{ showFileTypeError }}</p>
            </div>
            <ul class="uploaded-list">
                <template v-for="(ditem, dind) in value[item.fieldName]">
                <template v-if="checkProperty(ditem,'uploadedByRoleId') &&  getUserRoleId == 51 && !showToBeneficiary  ">
                    <template v-if="checkProperty(ditem,'uploadedByRoleId') == 51">
                        <vs-chip v-if="ditem.status" @click="ditem.status=false;remove(dind ,item.fieldName)"  :key="dind" closable>
                            <img src="@/assets/images/main/down-arrow2.svg" @click="downloads3file(ditem)" />
                            {{ ditem.name }}
                        </vs-chip>
                    </template>
                </template>
                <template v-else>
                    <vs-chip v-if="ditem.status" @click="ditem.status=false;remove(dind,item.fieldName)"  :key="dind" closable>
                        <img src="@/assets/images/main/down-arrow2.svg" @click="downloads3file(ditem)" />
                        {{ ditem.name }}
                    </vs-chip>
                </template>
                </template>
            </ul>
        </div>


           </template>
        </div>

    </div>


    <modal
            :name="uploadPopUpName"
            classes="v-modal-sec"
            :min-width="200"
            :min-height="200"
            :scrollable="true"
            :reset="true"
            width="600px"
            height="auto"
           
            >
            <div class="v-modal">
                <div class="popup-header fromDetailsPage">
                <h2 class="popup-title">
                  <template v-if="getCustomLabel(selectedItem)"> <p v-html="getCustomLabel(selectedItem, false)" ></p>
                  </template>
                  <template v-else>
                  Upload Documents
                  </template>
                </h2>

                <span @click="togleUploadModal(false)">
                    <em class="material-icons">close</em>
                </span>
                </div>
                <uploadBlock
                @input="filesUploaded"
                @closeUploadPopUp="closeUploadPopUp"
                :lodedFromPopup="true"
                v-if="selectedItem"
                :ref="'uploader_'+1000"
              :popUpIndex="1000" :petition="petition" 
            :showToBeneficiary="showToBeneficiary" 
            :tplsection="tplsection" 
            :fileAcceptType="checkProperty(selectedItem,'fileAcceptType')"
             :callExtract="checkProperty(selectedItem,'callExtract')?true:false" 
             :tplkey="checkProperty(selectedItem,'fieldName')"
              :display="false"
            :deleteDocPermenantly="deleteDocPermenantly"
            :tooltip="checkProperty(selectedItem,'tooltip')"
             :multiple="true" 
            :wrapclass="''" 
            :fieldsArray="fieldsArray"
            :formscope="formscope" 
            :required="checkProperty(selectedItem,'required')?true:false "
            :fieldName="checkProperty(selectedItem,'fieldName')"
            v-model="value[checkProperty(selectedItem,'fieldName')]" 
            :label="checkProperty(selectedItem,'label')"
            :vvas="'Document(s)'"
                ></uploadBlock>
            </div>
    </modal>
</div>
</template>

<script>
import immiuploader from "@/views/forms/fields/fileupload.vue";
import uploadBlock from "@/views/documents/uploadBlock.vue";
import _ from "lodash";

import { InfoIcon } from 'vue-feather-icons'
export default {
    inject: ["parentValidator"],
    props: {
        cid:{
            type: String,
            default: '',
        },
        docMainCategory:{
            type: String,
            default: '',
        },
        showToBeneficiary:{
            type:Boolean,
            default:false
        },
        tplsection:{
            type: String,
            default: null,
        },
        wrapclass:{
            type: String,
            default: '',
        },
        title:{
            type: String,
            default: '',
        },
        showTitle:{
            type:Boolean,
            default:true
        },
        deleteDocPermenantly:{
            type:Boolean,
            default:false
        },
        value: null,
        docslist:Array,
        fieldsArray: Array,
           formscope: {
            type: String,
            default: null
        },
        petition: null,
        callfromPetitionDocs:{
            type:Boolean,
            default:false
        }
    },
    created() {
        this.uploadPopUpName ="customUploadFiles_"+Math.floor((Math.random() * 10000000) + 1);
        this.$validator = this.parentValidator;
    },
    data() {
        return {
            showFileTypeError:'',
            uploadPopUpName:'',
            selectedItem:null,
          fileType:"image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        };
    },
    mounted(){
        
        this.$validator.reset()
    },
    methods: {
        remove(index=-1 , fieldName=''){
           
            if(index>-1 && fieldName){
               
                if(_.has( this.value ,fieldName) && this.checkProperty(this.value ,fieldName ,'length')>0 ){
                   
                    this.value[fieldName].splice(index,1);
                    this.$emit('input', this.value)
                }

            }

        },
        closeUploadPopUp(){
            this.togleUploadModal(false);
        },
        filesUploaded(documents){
            let self =this;
           
            _.map(this.value ,(item ,fieldName)=>{
                if(self.checkProperty(self.selectedItem,'fieldName') ==fieldName ){
                   
                    item = documents;
                    this.value[fieldName] =_.cloneDeep(documents);
                    this.updateData();
                   
                    
                }
            })
           
            
            setTimeout(()=>{
                this.togleUploadModal(false);
            })
        },
        togleUploadModal(show=false){
        let self =this;
          if(show){
           
            this.$modal.show(self.uploadPopUpName);
          }else{
           
            
            
              this.$modal.hide(self.uploadPopUpName);
              self.selectedItem =null
           
           
          }

       },
        openUploadesPop(item){
            this.selectedItem =item;
            this.togleUploadModal(true);
        },
        emitUploadingAction(data){
            
             this.$emit("emitUploadingAction" ,data );

        },
        getkey(value) {
            var find = _.find(this.docslist, {
                'fieldName': value
            });
            return find ? find.key : "";
        },
        getLabel(value) {
            var find = _.find(this.docslist, {
                'fieldName': value
            });
            return find ? find.label : "";
        },
        updateData() {
            this.$emit('input', this.value)
        }
    },
    components: {
        uploadBlock,
        immiuploader,
        InfoIcon
    },
    computed:{
        getCustomLabel(){
           return (item ,showRequired=true)=>{

            let label ='';
            if(item && _.has(item ,'label')){

            
             label = _.cloneDeep(item.label);
             if(!showRequired){
                label =label +" Document(s)"
             }else if(showRequired && this.checkFieldIsRequired({'key':item.fieldName,'section':this.tplsection, 'fieldsArray':this.fieldsArray, 'required':item.required })){
                label = label+"<em>*</em>";
            }
        }
           
            return label;
        }

        }
    }
};
</script>
