<template>
    <div>

      <div class="accordian-table">
        <div class="form-container">
                  <div class="vx-row">                  
                    <div class="vx-col md:w-1/2 w-full" > 
                      <div class="form_group">
                          <vs-input autocomplete="off" autocorrect="off" :disabled="true"  name="Email" v-model="updateCompanyData.email" class="w-full"
                            data-vv-as="Email" label="Email"  />
                          <span class="text-danger text-sm"
                            v-show="errors.has('Email')">{{ errors.first("Email") }}</span>
                      </div>
                    </div>
                    <div class="vx-col md:w-1/2 w-full" > 
                      <div class="form_group">
                          <vs-input  autocomplete="off" autocorrect="off"  :disabled="true"  name="Name" v-model="updateCompanyData.name" class="w-full"
                            data-vv-as="Name" label="Name" />
                          <span class="text-danger text-sm"
                            v-show="errors.has('Name')">{{ errors.first("Name") }}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div class="vx-row">
                    <div class="vx-col md:w-1/2 w-full" > 
                      <div class="form_group ph_number">
                        <div class="vs-component">
                            <label for="" class="vs-input--label">Phone Number</label>
                            <VuePhoneNumberInput
                              icon-pack="feather"
                              class="w-full no-icon-border"
                              :no-example="false"
                               key="phone"
                               data-vv-as="Phone Number"
                              v-bind="vuePhone.props"
                              name="Companyphone"
                              :default-country-code="checkProperty(updateCompanyData['phoneCountryCode'] ,'countryCode')"
                              :no-country-selector="false"
                            v-model="updateCompanyData.phone" 
                              @update="updateCompanyPhone"
                              :preferred-countries="['US', 'IN']" /> 
                          <span class="text-danger text-sm" v-show="errors.has('Companyphone')">{{ errors.first("Companyphone") }}</span>
                        </div>
                      </div> 
                    </div>
                    <div class="vx-col md:w-1/2 w-full" > 
                      <div class="form_group">
                        <div class="vs-component">
                            <label for="" class="vs-input--label">Fax Number</label>
                            <VuePhoneNumberInput
                                icon-pack="feather"
                                class="w-full no-icon-border"
                                :no-example="false"
                                key="phone"
                                data-vv-as="Fax Number"
                                v-bind="vuePhone1.props"
                                name="companyfaxphone"
                                :default-country-code="checkProperty(updateCompanyData['faxCountryCode'] ,'countryCode')"
                                placeholder="Company Fax Number"
                                :no-country-selector="false"
                              v-model="updateCompanyData.fax" 
                                @update="updateCompanyFax" 
                                :preferred-countries="['US', 'IN']"/> 
                            <span class="text-danger text-sm" v-show="errors.has('companyfaxphone')">{{ errors.first("companyfaxphone") }}</span>
                        </div>
                      </div>
                    </div>
                      

                        
                   
                    <div class="vx-col md:w-1/2 w-full" v-if="getTenantTypeId !=2" > 
                      <div class="form_group">
                        <vs-input  autocomplete="off" autocorrect="off"   name="irstaxId" v-model="updateCompanyData.irstaxId" class="w-full"
                          oninput="this.value = this.value.replace(/[^a-z A-Z 0-9]/g, '').replace(/(\..*)\./g, '$1'); this.value = this.value.replace(/ /g,'');"
                       
                          data-vv-as="IRS Trancation Id" label="IRS Trancation Id" v-validate="'required|max:10'" />
                        <span class="text-danger text-sm"
                          v-show="errors.has('irstaxId')">{{ errors.first("irstaxId") }}</span>
                      </div>
                    </div>
                    <div class="vx-col md:w-1/2 w-full" > 
                      <div class="form_group">
                        <vs-input  autocomplete="off" autocorrect="off"   name="naicsCode" v-model="updateCompanyData.naicsCode" class="w-full"
                         oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1'); this.value = this.value.replace(/ /g,'');"
                       
                          data-vv-as="N Code" label="Naics Code" v-validate="'required|max:6'" />
                        <span class="text-danger text-sm"
                          v-show="errors.has('naicsCode')">{{ errors.first("naicsCode") }}</span>
                      </div>
                    </div>
                    
                  </div>


                  <h3 class="small-header"> Authorized Signatory </h3>
                 
                  <div class="vx-row">
                    <div class="vx-col md:w-1/3 w-full" > 
                    <div class="form_group">
                        <vs-input   autocomplete="off" autocorrect="off"  name="title" v-model="updateCompanyData.authorizedSignatory.title" class="w-full"
                          data-vv-as="Title" label="Title" v-validate="'required'" />
                        <span class="text-danger text-sm"
                          v-show="errors.has('title')">{{ errors.first("title") }}</span>
                    </div>
                    </div>
                    
                    
                    <div class="vx-col md:w-1/3 w-full" > 
                      <div class="form_group">
                        <vs-input  autocomplete="off" autocorrect="off"   name="FirstName" v-model="updateCompanyData.authorizedSignatory.firstName" class="w-full"
                          data-vv-as="First Name" label="First Name" v-validate="'required'" />
                        <span class="text-danger text-sm"
                          v-show="errors.has('FirstName')">{{ errors.first("FirstName") }}</span>
                      </div>
                    </div>
                    <!-- <div class="vx-col md:w-1/3 w-full" > 
                        <vs-input  autocomplete="off" autocorrect="off"   name="middleName" v-model="updateCompanyData.authorizedSignatory.middleName" class="w-full"
                          data-vv-as="Middle Name" label="Middle Name" v-validate="'required'" />
                        <span class="text-danger text-sm"
                          v-show="errors.has('middleName')">{{ errors.first("middleName") }}</span>
                    </div> -->
                    <div class="vx-col md:w-1/3 w-full" > 
                      <div class="form_group">
                          <vs-input  autocomplete="off" autocorrect="off"   name="lastName" v-model="updateCompanyData.authorizedSignatory.lastName" class="w-full"
                            data-vv-as="Last Name" label="Last Name" v-validate="'required'" />
                          <span class="text-danger text-sm"
                            v-show="errors.has('lastName')">{{ errors.first("lastName") }}</span>
                      </div>
                    </div>     
                    <div class="vx-col md:w-1/2 w-full" > 
                      <div class="form_group">
                          <vs-input  autocomplete="off" autocorrect="off"   name="fromEmail" v-model="updateCompanyData.authorizedSignatory.email" class="w-full"
                            data-vv-as="From Email" label="Email" v-validate="'required|email'" />
                          <span class="text-danger text-sm"
                            v-show="errors.has('fromEmail')">{{ errors.first("fromEmail") }}</span>
                      </div>
                    </div>     
                    
                    <div class="vx-col md:w-1/2 w-full" > 
                    <div class="form_group ph_number">
                      <div class="vs-component">
                    <label for="" class="vs-input--label">Phone Number</label>

                       

                        <VuePhoneNumberInput
                                                    icon-pack="feather"
                                                    class="w-full no-icon-border"
                                                    :no-example="false"
                                                    v-bind="vuePhone.props"
                                                     key="phone"
                                                      data-vv-as="Phone Number"
                                                    name="authorizedSignatoryphone"
                                                    :default-country-code="checkProperty(updateCompanyData['authorizedSignatory']['phoneCountryCode'] ,'countryCode')"
                                                    placeholder="Company Fax Number"
                                                    :no-country-selector="false"
                                                   v-model="updateCompanyData.authorizedSignatory.phone" 
                                                    @update="updateAuthorizedSignatoryPhone"
                                                    :preferred-countries="['US', 'IN']"
                                                    /> 
                        <span class="text-danger text-sm" v-show="errors.has('authorizedSignatoryphone')">{{ errors.first("authorizedSignatoryphone") }}</span>
                      </div>
                    </div>
                    </div>
                  
                  
                  </div>
              
                  <h3 class="small-header"> Address</h3>
                  <div class="vx-row">

                    <div class="vx-col md:w-1/2 w-full" > 
                    <div class="form_group">
                      <vs-input  autocomplete="off" autocorrect="off"   name="address1" v-model="updateCompanyData.address.line1" class="w-full"
                        data-vv-as="Street Address" v-validate="'required'" label="Street Address" />
                      <span class="text-danger text-sm"
                        v-show="errors.has('address1')">{{ errors.first("address1") }}</span>
                    </div>
                    </div>

                    <div class="vx-col md:w-1/2 w-full" > 
                    <div class="form_group">
                      <vs-input   name="address2" v-model="updateCompanyData.address.line2" class="w-full"
                        data-vv-as="Apt, Suite" label="Apt, Suite" v-validate="'required'" />
                      <span class="text-danger text-sm"
                        v-show="errors.has('address2')">{{ errors.first("address2") }}</span>
                    </div>
                    </div>

                    <div class="vx-col md:w-1/2 w-full"   >
                    <div class="form_group">
                      <div class="con-select w-full select-large">
                        <label for class="vs-select--label">Country</label>
                      
                        <multiselect name="spouseaddresscountry"   v-model="updateCompanyData.address.selectedCountry"
                          @input="changedCountry" :show-labels="false" track-by="id" label="name"
                          data-vv-as="Country" placeholder="Select Country" :options="countries" :searchable="true"
                          :allow-empty="false"  v-validate="'required'"  ></multiselect>
                      </div>


                      <span class="text-danger text-sm"
                        v-show="errors.has('spouseaddresscountry')">{{ errors.first("spouseaddresscountry") }}</span>
                    </div>
                    </div>
                    <div class="vx-col md:w-1/2 w-full">
                    <div class="form_group">
                      <div class="con-select w-full select-large">
                        <label for class="vs-select--label">State</label>
                        <multiselect name="State"   v-model="updateCompanyData.address.selectedState"
                          @input="changedState" :show-labels="false" track-by="id" label="name" data-vv-as="State"
                          placeholder="Select State" :options="states" :searchable="true" :allow-empty="false" v-validate="'required'" >
                        </multiselect>
                      </div>

                      <span class="text-danger text-sm" v-show="errors.has('State')">{{ errors.first("State") }}</span>
                    </div>
                    </div>
                    <div class="vx-col md:w-1/2 w-full"  >
                      <div class="form_group">
                        <div class="con-select w-full select-large">
                          <label for class="vs-select--label">City</label>
                          <multiselect name="city"   v-model="updateCompanyData.address.selectedCity"
                          @input="changedCity"
                          v-validate="'required'"
                          :show-labels="false" track-by="id" label="name" data-vv-as="City"
                            placeholder="Select City" :options="locations" :searchable="true" :allow-empty="false">
                          </multiselect>
                        </div>
                        <span class="text-danger text-sm" v-show="errors.has('city')">{{ errors.first("city") }}</span>
                      </div>
                    </div>
                    <div class="vx-col md:w-1/2 w-full" >
                    <div class="form_group">
                      <vs-input name="zipcode" v-model="updateCompanyData.address.zipcode"
                        v-validate="'numeric|required|min:5|max:6'" class="w-full" data-vv-as="Zip Code"

                        oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1'); this.value = this.value.replace(/ /g,'');"
                        label="Zip Code" />
                        <span class="text-danger text-sm" v-show="errors.has('zipcode')">{{ errors.first("zipcode") }}</span>
                      </div>
                    </div>


                  </div>

                  <h3 class="small-header"> Business Information</h3>
                  <div class="vx-row">
                                       
                    <div class="vx-col md:w-1/2 w-full" > 
                      <div class="form_group">
                        
                          <vs-input  autocomplete="off" autocorrect="off"   name="natureOfBusiness" v-model="updateCompanyData.natureOfBusiness" class="w-full"
                            data-vv-as="Nature Of Business" label="Nature Of Business" v-validate="'required'" />
                          <span class="text-danger text-sm"
                            v-show="errors.has('natureOfBusiness')">{{ errors.first("natureOfBusiness") }}</span>
                         
                      </div>
                    </div>
                    <div class="vx-col md:w-1/2 w-full" > 
                      <div class="form_group">
                        <div class="vs-component">
                         <label class="vs-input--label">Date</label>
                          <datepicker  :typeable="true" name="businessEstdDate" 
                          v-validate="'required'" 
                           data-vv-as="Business start Date"
                           v-model="updateCompanyData.businessEstdDate"  placeholder="MM/DD/YYYY">
                          </datepicker>
                        <span class="text-danger text-sm"
                          v-show="errors.has('businessEstdDate')">{{ errors.first("businessEstdDate") }}</span>
                      </div>
                      </div>
                    </div>

                    <div class="vx-col md:w-1/2 w-full" > 
                        <div class="form_group">
                        <vs-input  autocomplete="off" autocorrect="off"   name="totalFullTimeEmployees" v-model="updateCompanyData.totalFullTimeEmployees" class="w-full"
                          data-vv-as="Total FullTime Employees" label="Total Full Time Employees" v-validate="'required'"
                           oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1'); this.value = this.value.replace(/ /g,'');"
                        />
                        <span class="text-danger text-sm" v-show="errors.has('totalFullTimeEmployees')">{{ errors.first("totalFullTimeEmployees") }}</span>
                        </div>
                    </div>
                    <div class="vx-col md:w-1/2 w-full" > 
                    <div class="form_group">
                        <vs-input  autocomplete="off" autocorrect="off"   name="estimatedNetAnualIncome" v-model="updateCompanyData.estimatedNetAnualIncome" class="w-full"
                          data-vv-as="Estimated Net Anual Income" label="Estimated Net Anual Income" v-validate="'required'"
                           oninput="this.value = this.value.replace(/[^0-9 .]/g, '').replace(/(\..*)\./g, '$1'); this.value = this.value.replace(/ /g,'');"
                        
                           />
                        <span class="text-danger text-sm"
                          v-show="errors.has('estimatedNetAnualIncome')">{{ errors.first("estimatedNetAnualIncome") }}</span>
                    </div>
                    </div>
                    <div class="vx-col md:w-1/2 w-full" > 
                      <div class="form_group">
                        <vs-input  autocomplete="off" autocorrect="off"   name="estimatedGrossAnualIncome" v-model="updateCompanyData.estimatedGrossAnualIncome" class="w-full"
                          data-vv-as="Estimated Gross Anual Income" label="Estimated Gross Anual Income" v-validate="'required'"
                          oninput="this.value = this.value.replace(/[^0-9 .]/g, '').replace(/(\..*)\./g, '$1'); this.value = this.value.replace(/ /g,'');"
                        
                           />
                        <span class="text-danger text-sm"
                          v-show="errors.has('estimatedGrossAnualIncome')">{{ errors.first("estimatedGrossAnualIncome") }}</span>
                      </div>
                    </div>
                    
                  
                    <div class="vx-col   w-full" >  
                    <vs-checkbox  id="are50orMoreEmployeesInUS" name="are50orMoreEmployeesInUS"  v-model="updateCompanyData.are50orMoreEmployeesInUS"   class="w-full"
                         >Are 50 or More Employees In US</vs-checkbox>
                       
                        <!-- <span class="text-danger text-sm"  v-show="errors.has('are50orMoreEmployeesInUS')">{{ errors.first("are50orMoreEmployeesInUS") }}</span> -->
                    </div>
                    <div class="vx-col   w-full" >  
                         <vs-checkbox  id="areAbove50PercentH1BL1ALABStatus" name="areAbove50PercentH1BL1ALABStatus"  v-model="updateCompanyData.areAbove50PercentH1BL1ALABStatus"   class="w-full"
                         >Are Above 50 Percent H1B L1 AL AB Status</vs-checkbox>
                       
                        <!-- <span class="text-danger text-sm"  v-show="errors.has('areAbove50PercentH1BL1ALABStatus')">{{ errors.first("areAbove50PercentH1BL1ALABStatus") }}</span> -->
                   
                    </div>
                    <div class="vx-col w-full">  
                        <vs-checkbox  id="finalDeterminationFromDOL" name="finalDeterminationFromDOL"  v-model="updateCompanyData.finalDeterminationFromDOL"   class="w-full"
                         >Final Determination From DOL</vs-checkbox>
                       
                        <!-- <span class="text-danger text-sm"  v-show="errors.has('finalDeterminationFromDOL')">{{ errors.first("finalDeterminationFromDOL") }}</span> -->
                   
                    </div>


                     <div class="vx-col md:w-1/2 w-full" @click="documents=[]">
                <div class="form_group">
              
                <label class="vs-input--label">Logo</label>
                <div class="vs-component">
                <file-upload v-model="documents" class="file-upload-input"
                    name="logo" data-vv-as="Logo" :multiple="false"
                    :accept="imageDocEntity"
                      @input="upload(documents ,'logo')">
                      <img class="file-icon" src="@/assets/images/main/file-upload.svg"> Upload Logo
                    </file-upload>
                </div>
                  <img   class="file-icon upload-logo"  v-if="checkProperty(updateCompanyData ,'logo')" :src="updateCompanyData.logo"  @click="remove('logo')">
                    <span class="text-danger text-sm" v-show="errors.has('logo')">{{ errors.first("logo") }}</span>

              
                </div>  
                 </div>
                  </div>


        </div>
         
        <div class="popup-footer">
          <button v-if="checkProperty(companyDetails ,'registrationCompleted')"  @click="completeTenantprofile=false"  class="cancel">Cancel</button>
          <button class="save" :disabled="formSubmited"   @click="updateCompanyDetails()"> Update</button>
        </div>

      </div>
    </div>  

</template>


<script>
import VxAutoSuggest from "@/components/vx-auto-suggest/VxAutoSuggest.vue";
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import draggable from "vuedraggable";
import DateRangePicker from "vue2-daterange-picker";
import moment from "moment";
import Datepicker from "vuejs-datepicker-inv";
import VuePhoneNumberInput from 'vue-phone-number-input';
import 'vue-phone-number-input/dist/vue-phone-number-input.css';  
import FileUpload from "vue-upload-component/src";
import * as _ from "lodash";

export default {
  name: "the-navbar",
  props: {
    navbarColor: {
      type: String,
      default: "#fff",
    },
  },
  data() {
    return {
      formSubmited:false,
      showIncompleteCheckListTxt:true,
      isloading:false,
      documents:[],
     countries:[],
     states:[],
     locations:[],
     formerrors: {
        msg: ""
      },
      vuePhone:{
        props:{
          translations:{
            phoneNumberLabel:"Phone Number"
          }
        }

      },
      vuePhone1:{
        props:{
          translations:{
            phoneNumberLabel:"Fax Number"
          }
        }

      },
      tenantDetails:null,
      updateTenantData:{
      "profComplted":"no",
		  "tenantId": "",
    	"name": "",
      "adminEmail":'',
		  "adminFirstName":"",
		  "adminLastName":"",
		  "phone": "",
		  "phoneCountryCode": {countryCode:'',countryCallingCode:''},
		  "logo": "",
		 "favicon": "",
		 "fromEmail": "",
		 "contactEmail": "",
     "idPrefix": "",
		 "slug": "",
		 "assetPath": "",
		"address": {
        "line1" : "",
        "line2" : "",
        "countryId" : '',
        "stateId" : '',
        "locationId" : '',
        "zipcode" : ""
		}
	    },
      completeTenantprofile:false,
      disabledDates: {
        to: new Date(),
      },
      navbarSearchAndPinList: this.$store.state.navbarSearchAndPinList,
      searchQuery: "",
      showFullSearch: false,
      pageTitle: "",
      unreadNotifications: [],
      settings: {
        maxScrollbarLength: 60,
        wheelSpeed: 0.6,
      },
      autoFocusSearch: false,
      showBookmarkPagesDropdown: false,
      SubmtRminder: false,
      reminder: {
        name: "",
        description: "",
        dueDate: new Date(),
      },
      autoApply: "",
      reminderCount: 0,
      disable_reminder_btn: false,
      delNotification:{"notifyId": '' , 'removeAll':false},
      deleteAllConform:false,
      notification_popuptitle:'Delete',
      companyDetails:null,
      updateCompanyData: {
        "companyId":"",
        "email":'',
        "name": "",
        "phone":"",
        "phoneCountryCode":{countryCode:'',countryCallingCode:''},
        "fax":"",
        "faxCountryCode":{countryCode:'',countryCallingCode:''},
        "irstaxId":"",
        "naicsCode":"",
        "address": {
          "line1": "",
          "line2": "",
          "locationId":0 ,
          "stateId":0 ,
          "countryId":0 ,
          "zipcode": ""
        },
        "authorizedSignatory": { 
          "name":'',
          "firstName": "",
          "lastName": "",
          "title": "",
          "email": "",
          "phone": "",
          "phoneCountryCode":{countryCode:'',countryCallingCode:''}
        },
        "natureOfBusiness":"",
        "businessEstdDate":"",
        "totalFullTimeEmployees":"",
        "are50orMoreEmployeesInUS":"no",
        "areAbove50PercentH1BL1ALABStatus":"no",
        "finalDeterminationFromDOL":"no",
        "estimatedNetAnualIncome":2342.55,
        "estimatedGrossAnualIncome":2342.55,
        "logo": "https://innvectra.rmtportal.com/logo.png",
        //"completeRegistration": true // it should be true only if it is petitioner
	    }
    };
  },
  watch: {
    $route() {
      this.pageTitle = this.$route.meta.title;
      this.isTenantProfileCompleted;
      this.getPetitionerProfileCompaltion;
      this.formSubmited =false;

      if (this.showBookmarkPagesDropdown)
        this.showBookmarkPagesDropdown = false;
      
    },
  },
  mounted() {
    this.masterData("countries");
   
    if(this.getUserRoleId ==12 && _.has(this.getUserData , 'companyId')){
      this.updateCompanyData = Object.assign(this.updateCompanyData ,{"companyId":this.getUserData['companyId']})
      
        this.getCompanyDetails();
        
    }
    
    //this.$modal.show('updateTenantProfile-modal');
    
     
  },
  computed: {
    
    getPetitionerProfileCompaltion(){
       
      
      if(this.getUserRoleId==12){
        
        if( this.$store.getters['getPetitionerProfileCompaltion']){
          
           return false;
        }else{
         
         return true
        }
      }else{
        return false;
      }
    },
    
    
    
    
  },
  methods: {
    editMyDetails(){
      if(this.getUserRoleId ==3){
      this.$store.dispatch("editTenantDetails")
      .then((res)=>{
        
        this.isTenantProfileCompleted;
       });
      }

    },
    editCompanyDetails(){
      this.$store.dispatch("editCompanyDetails")
      .then((res)=>{
        
        this.getPetitionerProfileCompaltion();

      });

    },
    updateCompanyPhone(item) {
         
       
      if (item.isValid) {
        
       this.updateCompanyData.phoneCountryCode = {countryCode:item.countryCode,countryCallingCode:item.countryCallingCode};
       this.updateCompanyData.phone = item.nationalNumber;
       
      }
     },
     updateCompanyFax(item) {
      if (item.isValid) {
          this.updateCompanyData.faxCountryCode =  {countryCode:item.countryCode,countryCallingCode:item.countryCallingCode};
          this.updateCompanyData.fax = item.nationalNumber;
      }
     },
     updateAuthorizedSignatoryPhone(item) {
      if (item.isValid) {
          this.updateCompanyData['authorizedSignatory'].phoneCountryCode = {countryCode:item.countryCode,countryCallingCode:item.countryCallingCode};
          this.updateCompanyData['authorizedSignatory'].phone = item.nationalNumber;
      }
     },
    getCompanyDetails(){
      let postData = {"companyId":this.getUserData['companyId']};
      this.$store.dispatch("getCompanyDetails",postData)
      .then(response => {
        let companyData = response;
        this.companyDetails = response;
        this.getPetitionerProfileCompaltion;
        //now update updateCompanyData verable for update company data.
        _.forEach(companyData ,(value ,key)=>{
         // alert("key=="+key +"   VALUE=="+value);
          if(key=='address'){
            let address = {line1:"" , line2:"",countryId:'' ,selectedCountry:null ,stateId:'',selectedState:null,locationId:'',selectedCity:null ,zipcode:''};
            
            _.forEach(companyData['address'] , (adval ,adkey)=>{
              if(_.has(address ,adkey)){
                address[adkey] = adval;
              }

            })

          
            this.updateCompanyData['address'] = address;
            this.updateCompanyData = _.cloneDeep( this.updateCompanyData);

              if(_.has(this.updateCompanyData['address'] ,"countryId")){

                if(this.countries.length>=0){
                  this.updateCompanyData['address']['selectedCountry'] = _.find(this.countries,{"id":this.updateCompanyData['address']["countryId"]})
                  this.updateCompanyData = _.cloneDeep( this.updateCompanyData);
                  this.changedCountry();
                }
              }

            

          }else if(key=='authorizedSignatory'){

            
            
            _.forEach(companyData['authorizedSignatory'] , (authval ,authkey)=>{

              if(_.has(this.updateCompanyData['authorizedSignatory'] ,authkey)){
                this.updateCompanyData.authorizedSignatory[authkey] = authval;
                //alert(this.updateCompanyData['authorizedSignatory'][authkey]);
              }

            })
            

          }else if(_.has(this.updateCompanyData ,key) ){
            this.updateCompanyData[key] =value;
            if(key=="are50orMoreEmployeesInUS" ){
              if(value.toLowerCase()=="yes"){
                this.updateCompanyData['are50orMoreEmployeesInUS'] =true;
              }else{
                this.updateCompanyData['are50orMoreEmployeesInUS'] =false;
              }
              
            }
            if(key=="finalDeterminationFromDOL" ){
              if(value.toLowerCase()=="yes"){
                this.updateCompanyData['finalDeterminationFromDOL'] =true;
              }else{
                this.updateCompanyData['finalDeterminationFromDOL'] =false;
              }
              
            }
            if(key=="areAbove50PercentH1BL1ALABStatus"){
              if(value.toLowerCase()=="yes"){
                this.updateCompanyData['areAbove50PercentH1BL1ALABStatus'] =true;
              }else{
                this.updateCompanyData['areAbove50PercentH1BL1ALABStatus'] =false;
              }
              
            }
            
          }
          let tempupdateCompanyData = _.cloneDeep( this.updateCompanyData);
          this.updateCompanyData = tempupdateCompanyData;
          

        })
        this.$validator.reset();
        
      })
      .catch(error => {
        
        
      })

      
    },
    updateCompanyDetails(){
       //alert(JSON.stringify(this.updateTenantData))
       this.$validator.validateAll().then(result => {
         if(result){
          let postData = _.cloneDeep(this.updateCompanyData);
          
          postData = Object.assign(postData,{completeRegistration:true})
         
           if(this.updateCompanyData.are50orMoreEmployeesInUS){
              postData = Object.assign(postData ,{"are50orMoreEmployeesInUS":'Yes'})
           }else{
              postData = Object.assign(postData ,{"are50orMoreEmployeesInUS":'No'})
           }

           if(this.updateCompanyData.areAbove50PercentH1BL1ALABStatus){
            postData = Object.assign(postData ,{"areAbove50PercentH1BL1ALABStatus":'Yes'})
           }else{
            postData = Object.assign(postData ,{"areAbove50PercentH1BL1ALABStatus":'No'})

           }
           if(this.updateCompanyData.finalDeterminationFromDOL){
              postData = Object.assign(postData ,{"finalDeterminationFromDOL":'Yes'})
           }else{
             postData = Object.assign(postData ,{"finalDeterminationFromDOL":'No'})
           }
             this.formSubmited =true;
              this.$store.dispatch("commonAction", {"data":postData ,"path":"/company/update"})
              .then(response => {
                
                
                 this.showToster({message:response.message,isError:false });
                
              this.completeTenantprofile =false;
              this.getCompanyDetails();
              
                this.getPetitionerProfileCompaltion;
                 this.formSubmited =false;
           })
           .catch(error =>{
             this.formSubmited =false;
              this.showToster({message:error,isError:true });
           })
         }
       });
    },

    removeText(){
      this.$store.dispatch("removeText");

    },
    getTenantDetails(){
      let postData = {
          tenantId : this.getUserData['tenantDetails']['_id']
        }
        this.$store.dispatch("get_tenant_details", postData)
              .then(response => {
                this.tenantDetails= response;
                this.initTenantProfileData();
                this.isTenantProfileCompleted;
    
               
              })
               .catch(error => {
                  this.showToster({message:error,isError:true });
              })

    },
    updatePhone(item) {
         
       
      if (item.isValid) {
        
       this.updateTenantData.phoneCountryCode = {countryCode:item.countryCode,countryCallingCode:item.countryCallingCode};
       this.updateTenantData.phone = item.nationalNumber;
       
      }
     },
    initTenantProfileData(){
      if(this.getUserRoleId ==3 && _.has(this.getUserData , 'tenantDetails')){
      let tempupdateTenantData = this.updateTenantData;
      let tenantDetails = this.getUserData['tenantDetails'];

     let address = {line1:"" , line2:"",countryId:'' ,selectedCountry:null ,stateId:'',selectedState:null,locationId:'',selectedCity:null ,zipcode:''};
      
      //	"name": "",
     // "adminEmail":'',

     if( (_.has(this.tenantDetails ,'name')) && tenantDetails.name.trim()){
          tempupdateTenantData['name'] = this.tenantDetails.name.trim()

      }
      if( (_.has(this.tenantDetails ,'adminEmail')) && tenantDetails.adminEmail.trim()){
          tempupdateTenantData['adminEmail'] = this.tenantDetails.adminEmail.trim()

      }
      if( (_.has(this.tenantDetails ,'adminFirstName')) && tenantDetails.adminFirstName.trim()){
          tempupdateTenantData['adminFirstName'] = this.tenantDetails.adminFirstName.trim()

      }
       if( (_.has(this.tenantDetails ,'adminLastName')) && tenantDetails.adminLastName.trim()){
          tempupdateTenantData['adminLastName'] = this.tenantDetails.adminLastName.trim()

      }
       if( (_.has(this.tenantDetails ,'phone')) && tenantDetails.phone){
          tempupdateTenantData['phone'] = this.tenantDetails.phone;

      }
       if( (_.has(this.tenantDetails ,'phoneCountryCode')) && tenantDetails.phoneCountryCode){
          tempupdateTenantData['phoneCountryCode'] = this.tenantDetails.phoneCountryCode;

      }
      
      if( (_.has(this.tenantDetails ,'logo')) && tenantDetails.phone){
          tempupdateTenantData['logo'] = this.tenantDetails.logo;

      }
      if( (_.has(this.tenantDetails ,'favicon')) && tenantDetails.favicon){
          tempupdateTenantData['favicon'] = this.tenantDetails.favicon;

      }
      if( (_.has(this.tenantDetails ,'fromEmail')) && tenantDetails.fromEmail){
          tempupdateTenantData['fromEmail'] = this.tenantDetails.fromEmail;

      }
      if( (_.has(this.tenantDetails ,'contactEmail')) && tenantDetails.contactEmail){
          tempupdateTenantData['contactEmail'] = this.tenantDetails.contactEmail;

      }
      if( (_.has(this.tenantDetails ,'contactEmail')) && tenantDetails.contactEmail){
          tempupdateTenantData['contactEmail'] = this.tenantDetails.contactEmail;

      }
      if( (_.has(this.tenantDetails ,'slug')) && tenantDetails.slug){
          tempupdateTenantData['slug'] = this.tenantDetails.slug;

      }
      if( (_.has(this.tenantDetails ,'idPrefix')) && tenantDetails.idPrefix){
          tempupdateTenantData['idPrefix'] = this.tenantDetails.idPrefix;

      }
      if( (_.has(this.tenantDetails ,'idPrefix')) && tenantDetails.idPrefix){
          tempupdateTenantData['idPrefix'] = this.tenantDetails.idPrefix;

      }
      
      
      if(_.has(this.tenantDetails ,'address' )){


         tempupdateTenantData['address']= address;
        if(_.has(this.tenantDetails['address'] ,"line1")){
          tempupdateTenantData['address']["line1"] = tenantDetails['address']['line1'];
        }
        if(_.has(this.tenantDetails['address'] ,"line2")){
          tempupdateTenantData['address']["line2"] = tenantDetails['address']['line2'];
        }
        if(_.has(this.tenantDetails['address'] ,"countryId")){
          tempupdateTenantData['address']["countryId"] = tenantDetails['address']['countryId'];
          if(this.countries.length>=0){
            tempupdateTenantData['address']['selectedCountry'] = _.find(this.countries,{"id":tempupdateTenantData['address']["countryId"]})
            this.changedCountry();
          }
        }
        if(_.has(this.tenantDetails['address'] ,"stateId")){
          tempupdateTenantData['address']["stateId"] = tenantDetails['address']['stateId'];
        }
        if(_.has(this.tenantDetails['address'] ,"locationId")){
          tempupdateTenantData['address']["locationId"] = tenantDetails['address']['locationId'];
        }
        if(_.has(this.tenantDetails['address'] ,"zipcode")){
          tempupdateTenantData['address']["zipcode"] = tenantDetails['address']['zipcode'];
        }

      }else{
        tempupdateTenantData['address'] = address;
      }

      
      if( (_.has(this.tenantDetails ,'_id')) && tenantDetails._id){
          tempupdateTenantData['tenantId'] = this.tenantDetails._id;

      }

      tempupdateTenantData =Object.assign(tempupdateTenantData ,{'profComplted':'no'})
      if(_.has(this.tenantDetails ,'profComplted')){
        tempupdateTenantData['profComplted'] = tenantDetails['profComplted'];

      }

      this.updateTenantData = tempupdateTenantData;

        

      if(
    
      /*
       ( !(_.has(this.updateTenantData ,'adminFirstName')) || !this.updateTenantData.adminFirstName.trim())
       || ( !(_.has(this.updateTenantData ,'adminLastName')) || !this.updateTenantData.adminLastName.trim())
       ||  ( !(_.has(this.updateTenantData ,'phone')) || !this.updateTenantData.phone)
       ||  ( !(_.has(this.updateTenantData ,'logo')) || !this.updateTenantData.logo.trim())
       ||  ( !(_.has(this.updateTenantData ,'favicon')) || !this.updateTenantData.favicon.trim())
       ||  ( !(_.has(this.updateTenantData ,'fromEmail')) || !this.updateTenantData.fromEmail.trim())
       ||  ( !(_.has(this.updateTenantData ,'contactEmail')) || !this.updateTenantData.contactEmail.trim())
       ||
       */
       ( !(_.has(this.tenantDetails ,'profComplted')) || !tenantDetails.profComplted.trim() ||  tenantDetails.profComplted.toLowerCase() !="yes")
       //||  ( !(_.has(this.updateTenantData ,'slug')) || !this.updateTenantData.slug.trim())
       //||  ( !(_.has(this.updateTenantData ,'idPrefix')) || !this.updateTenantData.idPrefix.trim())
       /*
       ||  ( !(_.has(this.updateTenantData ,'address')) || !this.updateTenantData.address)
       ||  ( !(_.has(this.updateTenantData['address'] ,'line1')) || !this.updateTenantData['address'].line1)
       ||  ( !(_.has(this.updateTenantData['address'] ,'line2')) || !this.updateTenantData['address'].line2)
       ||  ( !(_.has(this.updateTenantData['address'] ,'countryId')) || !this.updateTenantData['address'].countryId)
       ||  ( !(_.has(this.updateTenantData['address'] ,'stateId')) || !this.updateTenantData['address'].stateId)
       ||  ( !(_.has(this.updateTenantData['address'] ,'locationId')) || !this.updateTenantData['address'].locationId)
       ||  ( !(_.has(this.updateTenantData['address'] ,'zipcode')) || !this.updateTenantData['address'].zipcode)
       */

      ){
         this.completeTenantprofile =true;
      }

      

    }
    this.$validator.reset();
    },
    updateTenantProfile(){
       //alert(JSON.stringify(this.updateTenantData))
       this.$validator.validateAll().then(result => {
         if(result){
          let postData = _.cloneDeep(this.updateTenantData);
         
           if(this.updateTenantData.profComplted !='Yes'){
            // this.updateTenantData.profComplted ="Yes";
             postData = Object.assign(postData ,{"assetPath":postData['slug'].trim() ,"profComplted":'Yes',"profCompleted":"Yes"})

           }
           this.formSubmited =true;
           //alert();
           //return false;
           this.$store.dispatch("updateTenantProfile" ,postData)
           .then(response => {
              this.showToster({message:response.message,isError:false });
              this.completeTenantprofile =false;
              this.getTenantDetails();
               this.isTenantProfileCompleted;
               this.formSubmited =false;
           })
           .catch(error =>{
             this.formSubmited =false;
              this.showToster({message:error,isError:true });
           })
         }
       });
    },
     upload(files , type="logo") {
        let model = _.cloneDeep(files);
        this.documents =[];  
        this.loading = true;
        let formData = new FormData();
        let temp_count = 0;
        let mapper = model.map(
              item =>
              (item = {
                  name: item.name,
                  file: item.file ? item.file : null,
                  path: item.url ? item.url : "",
                  url:item.url ? item.url : "",
                  extn: item.name.split('.').pop(),
                  mimetype: item.type ? item.type : item.mimetype,
                  
              })
          );
         
        if (mapper.length > 0) {
            this.isloading = true;
            
            mapper.forEach((doc, index) => {
                formData.append('files', doc.file);
                formData.append('secureType', 'public');
                this.$store.dispatch("uploadS3File", formData).then(response => {
                    temp_count++;
                   // alert(type) updateCompanyData
                    response.data.result.forEach(urlGenerated => {
                      
                        
                        if(this.getUserRoleId ==12){
                            if(type=="logo"){
                          this.updateCompanyData = Object.assign(this.updateCompanyData,{"logo":urlGenerated})
                        }else{
                         // alert(type+" ----- ")
                          this.updateCompanyData = Object.assign(this.updateCompanyData,{"favicon":urlGenerated})
                        }

                        }else{

                          if(type=="logo"){
                          this.updateTenantData = Object.assign(this.updateTenantData,{"logo":urlGenerated})
                        }else{
                         // alert(type+" ----- ")
                          this.updateTenantData = Object.assign(this.updateTenantData,{"favicon":urlGenerated})
                        }

                        }
                      
                           
                            
                          if(temp_count >= mapper.length){
                              this.documents=[];

                          }
                          doc.url = urlGenerated;
                          delete doc.file;
                          mapper[index] = doc;
                       
                    })
                });
            });
             model.splice(0, mapper.length, ...mapper);
        }
    },
      remove(item) {
       
         if(this.getUserRoleId ==12){
                            
            this.updateCompanyData[item] =''
         }else{
            this.updateTenantData[item] = '';
         }
        
      },
     changedCountry(){
         this.states =[];
        this.locations =[];
        let dataKey ="updateTenantData";
        if(this.getUserRoleId ==12){
          dataKey="updateCompanyData";
        }
        if( _.has(this[dataKey].address.selectedCountry , "id")){
            this[dataKey].address.countryId = this[dataKey].address.selectedCountry['id'];
           
            this.masterData('states');
        }
        
    },
    changedState(){
        let dataKey ="updateTenantData";
        if(this.getUserRoleId ==12){
          dataKey="updateCompanyData";
        }
       
         this.locations =[];
         if( _.has(this[dataKey].address.selectedState , "id")){
            this[dataKey].address.stateId = this[dataKey].address.selectedState['id'];
           this.masterData('locations');
        }
    },
    //locationId
    changedCity(){
      let dataKey ="updateTenantData";
        if(this.getUserRoleId ==12){
          dataKey="updateCompanyData";
        }
     
      if( _.has(this[dataKey].address.selectedCity , "id")){
            this[dataKey].address.locationId = this[dataKey].address.selectedCity['id'];
           this.masterData('locations');
        }

    },
    masterData(category="countries"){

         /*
        countries:[]
        states:[],
        locations:[],
         */
        let matcher ={};
         let postData = {
        matcher: matcher,
        page:1,
        perpage: 1000,
        category: category,
       
      };

      let dataKey ="updateTenantData";
       let detailsDataKey ="tenantDetails"; 
            
        if(this.getUserRoleId ==12){
          dataKey="updateCompanyData";
          detailsDataKey= "companyDetails";
        }

      if(category =="states"){

          matcher = { "countryId": this[dataKey].address.selectedCountry['id']}
      }
       if(category =="locations"){

          matcher = { "stateId": this[dataKey].address.selectedState['id']  }
      }
       postData['matcher'] = matcher;

         this.$store.dispatch("getMasterData" , postData)
         .then((res)=>{
             //countries
            
             
             if(category == "countries"){

                 this.countries = res['list'];
                 
                 //alert(JSON.stringify(this.countries))
             }
             if(category =="states"){


                  this.states= res['list'];
                  if(_.has(this[detailsDataKey]['address'] ,"stateId")){
                  this[dataKey]['address'].selectedState = _.find(this.states ,{"id":this[detailsDataKey]['address']['stateId']});
                  this.changedState();
                  }
                  
                  
             }
            if(category =="locations"){
              
                this.locations= res['list'];
                if(_.has(this[detailsDataKey]['address'] ,"locationId")){
                  this[dataKey]['address'].selectedCity = _.find(this.locations ,{"id":this[detailsDataKey]['address']['locationId']}) ;
                  }
                
            }
         })
         .catch((err)=>{
             
             this[category] =[];

         })

    },
    
    
  },
  directives: {
  },
  components: {
    VuePhoneNumberInput,
    FileUpload,
    VxAutoSuggest,
    VuePerfectScrollbar,
    draggable,
    DateRangePicker,
    moment,
    Datepicker,
  },
};
</script>