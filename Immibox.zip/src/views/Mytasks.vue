<template>
  <div>
    <div class="dashboard-wrapper">
      <!-- dashboard html start here-->
      <div class="dashboard-content">
        <h1>My Tasks </h1>
        <p class="login-name">Welcome {{username}}, your tasks in a brief!</p>
        <!-- no activities content here-->
        <div class="no-activities" style="display: none;">
          <figure>
            <img src="@/assets/images/main/no-activity-img.png">
          </figure>
          <h3>You don't have Activities</h3>
          <p>
            Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when
          </p>
        </div>
        <!-- dashboard content here-->
        <div class="dashboard-cards">

            <!--My Tasks-->
          <div class="vx-row">

            <!-- CARD 1: My Tasks -->
            <div class="vx-col w-full"  v-if="my_tasks.length>0">
              <vx-card class="normal-card my-task-card">
                <div class="mytask-listheader">
                  <h2>My Tasks</h2>
                <!--  <a href="" class="viewall">View All <i class="material-icons">
                    arrow_forward
                  </i></a>-->
                </div>

                <ul v-if="my_tasks.length>0"  >
                  <li v-bind:key="my_task" v-for="my_task in my_tasks">
                    <div class="my-task-card-content">
                      <div class="my-task-card-content-right">
                        <div class="my-task-id">
                          {{my_task.data.description}}
                          
                          <span>   
                              <div class="date">{{my_task.createdOn | formatDateTime}}</div>
                          </span>
                        </div>
                        
                          <a v-if="my_task.data.navigationKey=='TENANT_DETAILS'" href.prevent   @click="$router.push('/customers')" >
                           <button class="btn go-btn">Go</button>
                          </a>
                          <a  v-if="(my_task.data.navigationKey=='COMPANY_DETAILS' || my_task.data.navigationKey=='USER_DETAILS')" 
                          href.prevent   @click="$router.push((my_task.data.navigationKey=='COMPANY_DETAILS' || my_task.data.navigationKey=='USER_DETAILS')?'/petitioner-details/'+my_task.data.companyId:'/petition-details/'+my_task.data.petitionId)"
                          
                            >
                           <button class="btn go-btn">Go</button>
                          </a>
                      </div>
                    </div>
                  </li>
                  <!--<li>
                     <div class="my-task-card-content">
                        <div class="my-task-card-content-left">
                           <button class="btn upload">Upload</button>
                           <div class="date">21/08/2019 06:48 PM</div>
                        </div>
                        <div class="my-task-card-content-right">
                           <div class="my-task-id">0508201900256 <span>By Paralegal</span></div>
                           <button class="btn go-btn">Go</button>
                        </div>
                     </div>
                  </li>
                  <li>
                     <div class="my-task-card-content">
                        <div class="my-task-card-content-left">
                           <button class="btn upload">Upload</button>
                           <div class="date">21/08/2019 06:48 PM</div>
                        </div>
                        <div class="my-task-card-content-right">
                           <div class="my-task-id">0508201900256 <span>By Petitioner</span></div>
                           <button class="btn go-btn">Go</button>
                        </div>
                     </div>
                  </li>-->

                </ul>
              </vx-card>
            </div>
          </div>


        </div>
      </div>
      <!-- recent-activities html start here-->
      <div class="recent-activities">
        <div class="recent-activities-header">
          <h2>Recent Activities</h2>
          <vs-button v-on:click="refresh" radius color="success" icon-pack="feather" icon="icon-rotate-cw"></vs-button>
        </div>
        <div class="recent-activities-content">
          <ul>
          <template  v-if="recent_activitys.length>0">
            <li v-for="(recent_activity , indx) in recent_activitys" :key="indx">
              <h4>{{recent_activity.title}}</h4>
              <p>{{recent_activity.description}}</p>
              <span>{{recent_activity.createdOn | timeago }} </span>
            </li>
            </template>
            <!------
              <li>
                <h4>Request for LCA</h4>
                <p>Petitions no : HAR000001</p>
                <span>4 minutes ago</span>
             </li>
             <li>
                <h4>Documents required</h4>
                <p>Missing documents required for petitions no :HAR000001</p>
                <span>07/26/2019, 06:48 AM</span>
             </li>
             <li>
                <h4>New Petitions Added</h4>
                <p>Petitions no : HAR000001</p>
                <span>4 minutes ago</span>
             </li>
             <li>
                <h4>Invoice for HAR000001</h4>
                <p>You have pending activity, Please update the invoice</p>
                <span>07/26/2019, 06:48 AM</span>
             </li>-->
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
  import VueApexCharts from 'vue-apexcharts'
  import Vue from 'vue'

  Vue.use(VueApexCharts)

  Vue.component('apexchart', VueApexCharts)


  export default {
    data: function() {
      return {
        username:'',
        activities:[],
        options: {},
        series: [50, 102, 155, 141, 117],
        dashboard_data:{},
        lca_requests:[],
        new_petitioners:[],
        new_petitions:[],
        petitionersCount:{},
        beneficiaryStats :{ },

        petitionsCount:{},
        rfe_petitions:[],

        //recent activity data
        recent_activitys:[],
        my_tasks:[],



      }
    },
    mounted() {
      this.username = this.$store.state.user.name;
      this.roleId = this.$store.state.user['roleId'][0];
      //alert(this.roleId)
      
      this.petitionsCount ={petitionCount: 0,rfeCount: 0,totalCount: 0};
      this.petitionersCount = { approvedCount: 0,pendingCount: 0,totalCount: 0 };
      this.beneficiaryStats ={ "total": 0,"active": 0,"inactive": 0};

      this.get_dashboardData();
      this.get_recentActivitys();
      this.get_mytasks();
      this.getactivities();


    },
    methods:{
      get_dashboardData:function(){
        this.$store.dispatch("get_dashboard_data", {}).then(response => {
          this.dashboard_data = response;
          this.lca_requests = this.dashboard_data['lca_requests']?this.dashboard_data['lca_requests']:[];

          this.petitionsCount = this.dashboard_data['petitionsCount']?this.dashboard_data['petitionsCount']:{petitionCount: 0,rfeCount: 0,totalCount: 0};
          this.petitionersCount = this.dashboard_data['petitionersCount']?this.dashboard_data['petitionersCount']:{ approvedCount: 0,pendingCount: 0,totalCount: 0 };
          this.beneficiaryStats = this.dashboard_data['beneficiaryStats']?this.dashboard_data['beneficiaryStats']:{ "total": 0,"active": 0,"inactive": 0};


          this.new_petitioners = this.dashboard_data['new_petitioners']?this.dashboard_data['new_petitioners']:[];
          this.new_petitions = this.dashboard_data['new_petitions']?this.dashboard_data['new_petitions']:[];
          this.rfe_petitions = this.dashboard_data['rfe_petitions']?this.dashboard_data['rfe_petitions']:[];
        });
      },
      get_recentActivitys:function(){
        this.$store.dispatch("get_recent_activitys", {}).then(response => {
          this.recent_activitys = response.list;
          
        });
      },
      getactivities:function(){
        this.$store.dispatch("getactivities").then(response => {
          this.activities = response;
        });
      },
      get_mytasks:function(){
        this.$store.dispatch("get_my_tasks", {}).then(response => {
          this.my_tasks = response.list;

        });
      },
      refresh:function(){
        this.get_recentActivitys();
      },
    }
  };
</script>



<!-- <script>
   import VueApexCharts from 'vue-apexcharts'
   import Vue from 'vue'

   Vue.use(VueApexCharts)

   Vue.component('apexchart', VueApexCharts)


   export default {
       data: function() {
         return {
         series: [50, 102, 155, 141, 117],
         options: {
             labels: ['Petitions Filed', 'Documents Missing', 'Additional Documents Required', 'Certified LCA', 'USCIS Approved'],
                 legend: {
                   position: 'bottom'
                 }
         },
         options2: {
             labels: ['RFE Recieved', 'Documents Missing', 'Additional Documents Required', 'Certified LCA', 'USCIS Approved'],
                 legend: {
                   position: 'bottom'
                 }
         }

         }
       },
   };
   </script> -->
