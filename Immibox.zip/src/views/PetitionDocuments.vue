<template>
        <div>
<div class="tab-inner-content">
                        <div class="tabs-content-panel no-border-radius">
                           <vs-row>
                              <vs-col class="w-full p-0">
                                 
                           

                              </vs-col>
                              <vs-col>
                                 <div class="card-panels">
                                    <vs-card v-if=" petition['documents']['resume'].length>0" >
                                       <div slot="header">
                                          <h3>
                                             Resume
                                          </h3>
                                       </div>
                                       <div>
                                          <vs-list>
                                             <vs-list-item v-for=" resume in  petition['documents']['resume']" v-bind:title="resume.name"
                                               v-if="resume.status" v-bind:subtitle="resume.uploadedOn | formatDateTime">
                                                <template slot="avatar">
                                                   <img src="@/assets/images/main/icon-pdf.svg">
                                                </template>
                                                <div class="vertical-menu">
                                                   <vs-dropdown vs-custom-content vs-trigger-click >
                                                      <i class="material-icons">more_vert</i>
                                                      <vs-dropdown-menu class="actions-dropdown">
                                                         <vs-dropdown-item @click="fetchSignedUrl(resume)">View</vs-dropdown-item>
                                                      </vs-dropdown-menu>
                                                   </vs-dropdown>
                                                </div>
                                             </vs-list-item>
                                          </vs-list>
                                       </div>
                                    </vs-card>
                                   <vs-card v-if=" petition['documents']['education'].length>0" >
                                     <div slot="header">
                                       <h3>
                                         Education (Under Gaduate / Graduate Degree(s) along with Transcripts, as
                                         well as any Diploma(s), and Certificates, including Certificates for
                                         Pre-College Education)
                                       </h3>
                                     </div>
                                     <div>
                                       <vs-list>
                                         <vs-list-item v-for=" resume in  petition['documents']['education']" v-bind:title="resume.name"
                                                       v-if="resume.status"      v-bind:subtitle="resume.uploadedOn | formatDateTime" >
                                           <template slot="avatar">
                                             <img src="@/assets/images/main/icon-pdf.svg">
                                           </template>
                                          <div class="vertical-menu">
                                             <vs-dropdown vs-custom-content vs-trigger-click >
                                                <i class="material-icons">more_vert</i>
                                                <vs-dropdown-menu class="actions-dropdown">
                                                   <vs-dropdown-item @click="fetchSignedUrl(resume)">View</vs-dropdown-item>
                                                </vs-dropdown-menu>
                                             </vs-dropdown>
                                          </div>
                                         </vs-list-item>
                                       </vs-list>
                                     </div>
                                   </vs-card>
                                    <vs-card v-if=" petition['documents']['expLetters'].length>0" >
                                       <div slot="header">
                                          <h3>
                                             Experience Letters
                                          </h3>
                                       </div>
                                       <div>
                                          <vs-list >
                                             <vs-list-item  v-for=" edu in  petition['documents']['expLetters']" v-bind:title="edu.name"
                                                            v-if="edu.status"  v-bind:subtitle="edu.uploadedOn | formatDateTime">
                                                <template slot="avatar">
                                                   <img src="@/assets/images/main/icon-pdf.svg">
                                                </template>
                                                <div class="vertical-menu">
                                                   <vs-dropdown vs-custom-content vs-trigger-click >
                                                      <i class="material-icons">more_vert</i>
                                                      <vs-dropdown-menu class="actions-dropdown">
                                                         <vs-dropdown-item @click="fetchSignedUrl(edu)">View</vs-dropdown-item>
                                                      </vs-dropdown-menu>
                                                   </vs-dropdown>
                                                </div>
                                             </vs-list-item>

                                          </vs-list>
                                       </div>
                                    </vs-card>
                                   <vs-card  v-if=" petition['documents']['INSNotices'].length>0" >
                                       <div slot="header">
                                          <h3>
                                             Prior notice(s) of approval issued by INS
                                          </h3>
                                       </div>
                                       <div>
                                          <vs-list >
                                             <vs-list-item v-for=" item in  petition['documents']['INSNotices']" v-bind:title="item.name"
                                              v-if="item.status"  v-bind:subtitle="item.uploadedOn | formatDateTime">
                                                <template slot="avatar">
                                                   <img src="@/assets/images/main/icon-pdf.svg">
                                                </template>
                                                <div class="vertical-menu">
                                                   <vs-dropdown vs-custom-content vs-trigger-click >
                                                      <i class="material-icons">more_vert</i>
                                                      <vs-dropdown-menu class="actions-dropdown">
                                                         <vs-dropdown-item @click="fetchSignedUrl(item)">View</vs-dropdown-item>
                                                      </vs-dropdown-menu>
                                                   </vs-dropdown>
                                                </div>
                                             </vs-list-item>
                                          </vs-list>
                                       </div>
                                    </vs-card>
                                   <vs-card  v-if=" petition['documents']['passportVisaI94'].length>0" >
                                     <div slot="header">
                                       <h3>
                                         Passport, along with Visa and Form I-94
                                       </h3>
                                     </div>
                                     <div>
                                       <vs-list >
                                         <vs-list-item v-for=" item in  petition['documents']['passportVisaI94']" v-bind:title="item.name"
                                              v-if="item.status"        v-bind:subtitle="item.uploadedOn | formatDateTime">
                                           <template slot="avatar">
                                             <img src="@/assets/images/main/icon-pdf.svg">
                                           </template>
                                          <div class="vertical-menu">
                                             <vs-dropdown vs-custom-content vs-trigger-click >
                                                <i class="material-icons">more_vert</i>
                                                <vs-dropdown-menu class="actions-dropdown">
                                                   <vs-dropdown-item @click="fetchSignedUrl(item)">View</vs-dropdown-item>
                                                </vs-dropdown-menu>
                                             </vs-dropdown>
                                          </div>
                                         </vs-list-item>
                                       </vs-list>
                                     </div>
                                   </vs-card>
                                    <vs-card  v-if=" petition['documents']['formI20'].length>0">
                                       <div slot="header">
                                          <h3>
                                             Three Recent Pay Stubs
                                          </h3>
                                       </div>
                                       <div>
                                          <vs-list>
                                             <vs-list-item v-for=" item in  petition['documents']['formI20']" v-bind:title="item.name"
                                               v-if="item.status" v-bind:subtitle="item.uploadedOn | formatDateTime">
                                                <template slot="avatar">
                                                   <img src="@/assets/images/main/icon-pdf.svg">
                                                </template>
                                                <div class="vertical-menu">
                                                   <vs-dropdown vs-custom-content vs-trigger-click >
                                                      <i class="material-icons">more_vert</i>
                                                      <vs-dropdown-menu class="actions-dropdown">
                                                         <vs-dropdown-item @click="fetchSignedUrl(item)">View</vs-dropdown-item>
                                                      </vs-dropdown-menu>
                                                   </vs-dropdown>
                                                </div>
                                             </vs-list-item>
                                          </vs-list>
                                       </div>
                                    </vs-card>
                                   <vs-card v-if=" petition['documents']['socialSecurityCardAndProfLicense'].length>0" >
                                     <div slot="header">
                                       <h3>
                                         Social Security Card
                                       </h3>
                                     </div>
                                     <div>
                                       <vs-list>
                                         <vs-list-item v-for=" resume in  petition['documents']['socialSecurityCardAndProfLicense']" v-bind:title="resume.name"
                                                 v-if="resume.status"      v-bind:subtitle="resume.uploadedOn | formatDateTime">
                                           <template slot="avatar">
                                             <img src="@/assets/images/main/icon-pdf.svg">
                                           </template>
                                             <div class="vertical-menu">
                                                <vs-dropdown vs-custom-content vs-trigger-click >
                                                   <i class="material-icons">more_vert</i>
                                                   <vs-dropdown-menu class="actions-dropdown">
                                                      <vs-dropdown-item @click="fetchSignedUrl(item)">View</vs-dropdown-item>
                                                   </vs-dropdown-menu>
                                                </vs-dropdown>
                                             </div>
                                         </vs-list-item>
                                       </vs-list>
                                     </div>
                                   </vs-card>
                                 </div>
                              </vs-col>
                           </vs-row>
                        </div>
                     </div>
        </div>
</template>

<script>
export default {
	props: {
		petition: {
			type: Object,
			default: null
      }
   },
   methods: {
      fetchSignedUrl(value) {
         
         value.document = value.url.replace(this.$globalgonfig._S3URL,"")
         let postdata = {
         keyName: value.document
         };
         

         this.$store
         .dispatch("getSignedUrl", postdata)
         .then(response => {
            window.open(response.data.result.data, '_blank');
         });
      },
         downloaddocument() {
         
         value.document = value.url.replace(this.$globalgonfig._S3URL,"")
         let postdata = {
           petitionId :this.petition._id,"categories": ["petition-documents"]
         };
         

         this.$store
         .dispatch("downloaddetailsaspdf", postdata)
         .then(response => {
            window.open(response.data.result.data, '_blank');
         });
      }
   },
   mounted(){
      
   }
}
</script>
