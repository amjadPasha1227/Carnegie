<template>
  <div class="settings_right">
    <div class="content-header">
      <div class="content-header-left">
        <div class="search">
          <vs-input icon-pack="feather" icon="icon-search" v-model="searchtxt" placeholder="Search by Name"
            class="is-label-placeholder" />
        </div>
      </div>
      <div class="content-header-right">
        <!--filter dropdown-->
        <vs-dropdown  vs-custom-content vs-trigger-click>
          <vs-button
            color="primary"
            class="filter-btn"
            type="border"
            icon-pack="feather"
            icon="icon-chevron-down"
            icon-after
          >
            <img src="@/assets/images/main/icon-filter.svg" /> Filters
          </vs-button>
          <vs-dropdown-menu ref="filter_menu" class="filters-content settings_filters">

            <div class="filters-form-fileds">
              <div class="form-container">
                <div class="vx-row">

                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Select Types</label>
                    
                    <multiselect v-model="selected_typeids" :options="all_formTypes" :multiple="true" :hideSelected="true"
                      :close-on-select="false" :clear-on-select="false" :select-label="''" :preserve-search="true"
                      placeholder="Select Types" label="name" track-by="name" :preselect-first="false">
                      <!-- <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">{{ values.length }}
                          options selected</span>
                      </template> -->
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} options selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template> 
                    </multiselect>
                  </div>

                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Select Document Types</label>
                    
                    <multiselect v-model="formsAndLettersTypeFIlter" :options="forms_and_letters_type" :multiple="true" :hideSelected="true"
                      :close-on-select="false" :clear-on-select="false" :select-label="''" :preserve-search="true"
                      placeholder="Select Types" label="name" track-by="name" :preselect-first="false">
                     
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} options selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template> 
                    </multiselect>
                  </div>




                
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Select Status</label>
                    
                    <multiselect v-model="selected_statusids" :options="all_statusids" :multiple="true" :hideSelected="true"
                      :close-on-select="false" :clear-on-select="false" :select-label="''" :preserve-search="true"
                      placeholder="Select Status" label="name" track-by="name" :preselect-first="false">
                      <!-- <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">{{ values.length }}
                          options selected</span>
                      </template> -->
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} options selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template> 
                    </multiselect>
                  </div>

                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Created Date</label>
                    <date-range-picker
                       :maxDate="new Date()"
                      :autoApply="autoApply"
                      :ranges="false"
                      v-model="selected_createdDateRange"
                    ></date-range-picker>
                  </div>

                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Select Customer</label>
                    
                    <multiselect v-model="tenantListFilter" :options="tenantsList" :multiple="true" :hideSelected="true"
                      :close-on-select="false" :clear-on-select="false" :select-label="''" :preserve-search="true"
                      placeholder="Select Types" label="name" track-by="name" :preselect-first="false">
                     
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} Customer(s) Selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template> 
                    </multiselect>
                  </div>
                 </div>
                   
                   
     
              </div>
            </div>
            <div class="filters-status">
              <div class="left-buttons">

              </div>
              <div class="right-buttons">
                <vs-button color="success" class="save" type="filled" v-on:click="set_filter()">Apply</vs-button>
                <vs-button color="dark" class="cancel" type="filled" v-on:click="clear_filter($event)">Clear
                </vs-button>
              </div>
            </div>
          </vs-dropdown-menu>
        </vs-dropdown>
        <!-- end -->
        <vs-button type="border" class="light-blue-btn" @click="createNew(true)">Add Form/Letter<span>
          <img class="add-user-icon ml-2" src="@/assets/images/main/add-user.svg">
        </span>
        </vs-button>

        
      </div>
    </div>
    <NoDataFound ref="NoDataFoundRef"  v-if="list.length == 0 && !callFromSerch" content="You haven't  created any Forms and Letters yet. Create a Forms and Letters to start using the ImmiBox" heading="No Forms and Letters Found" type='Forms and Letters' />
    <NoDataFound ref="NoDataFoundRef"  v-if="list.length == 0 && callFromSerch" content="" heading="No Results Found" type='Forms and Letters' />

    <div class="accordian-table" v-if="list.length > 0">
      <vs-table :data="list" :no-data-text="'No data found..!'">
        <template slot="thead" v-if="list.length>0">
          <vs-th>
          <a @click="sortMe('name')"  v-bind:class="{'sort_ascending':sortKeys['name']==1, 'sort_descending':sortKeys['name']!=1}" >
             Name
              </a>
          </vs-th>
          

          <vs-th> <a @click="sortMe('typeName')"  v-bind:class="{'sort_ascending':sortKeys['typeName']==1, 'sort_descending':sortKeys['typeName']!=1}" >
             Type
              </a>
          </vs-th>

          <vs-th v-if="[1].indexOf(getUserRoleId)>-1 && tenantListFilter.length>0 ">
            <a @click="sortMe('tenantName')"  v-bind:class="{'sort_ascending':sortKeys['tenantName']==1, 'sort_descending':sortKeys['tenantName']!=1}" >
             Customer
            </a>
          </vs-th>
          
          <vs-th> <a @click="sortMe('docTypeName')"  v-bind:class="{'sort_ascending':sortKeys['docTypeName']==1, 'sort_descending':sortKeys['docTypeName']!=1}" >
              Document Type
              </a>
          </vs-th>

          <vs-th>File</vs-th>
          <vs-th>

          <a @click="sortMe('createdOn')"  v-bind:class="{'sort_ascending':sortKeys['createdOn']==1, 'sort_descending':sortKeys['createdOn']!=1}" >
             Created On
              </a>
          
          </vs-th>
           <vs-th>

          <a @click="sortMe('updatedOn')"  v-bind:class="{'sort_ascending':sortKeys['updatedOn']==1, 'sort_descending':sortKeys['updatedOn']!=1}" >
             Updated On
              </a>
          
          </vs-th>
          
          <vs-th> 
          <a @click="sortMe('statusName')"  v-bind:class="{'sort_ascending':sortKeys['statusName']==1, 'sort_descending':sortKeys['statusName']!=1}" >
          Status
          </a>
          </vs-th>
          <vs-th class="actions">Actions</vs-th>

        </template>

        <template slot-scope="{data}">
          <vs-tr  :data="tr" :key="indextr" v-for="(tr, indextr) in data">
            <vs-td :data="tr.username" class="td_label">
            <!--
              <img class="user-image" src="@/assets/images/main/avatar2.svg" />
              -->
              
              {{tr.name }}
              <small v-if="!checkProperty(tr , 'tenantId')">(Global)</small>
            </vs-td>
             <vs-td>  {{ checkProperty( tr,'type')}}  </vs-td>
             <vs-td v-if="[1].indexOf(getUserRoleId)>-1 && tenantListFilter.length>0">{{checkProperty(tr ,'tenantDetails' ,'name')}}</vs-td>
             <vs-td>  {{ checkProperty( tr,'docTypeDetails' ,'name')}}  </vs-td>
            <vs-td>
             {{checkProperty( tr,'document' , 'name')}}
            
            </vs-td>
            <vs-td>
             {{tr.createdOn | formatDate}}
            </vs-td>
            
            <vs-td>
             {{tr.updatedOn | formatDate}}
            </vs-td>

           
           <vs-td >
              <span class="statusspan " :class="{'status_pending':tr.statusId==1,'status_active':tr.statusId==2,'status_rejected':tr.statusId==3,'status_rejected':tr.statusId==4}" >
          
             <template v-if="checkProperty(tr ,'statusId') ==1">Pending</template>
            <template v-if="checkProperty(tr ,'statusId') ==2">Active</template>
            <template v-if="checkProperty(tr ,'statusId') ==3">Inactive</template>
            <template v-if="checkProperty(tr ,'statusId') ==4">Deleted</template>

              </span>
            </vs-td>

            <vs-td :data="tr.statusId">
              
             
              <vs-dropdown class="msg_dropdown_icon" :vs-trigger-click="true">
                  <a class="a-icon" href.prevent><more-vertical-icon size="1.5x" class="custom-class"></more-vertical-icon></a>
                 <vs-dropdown-menu class="loginx msg_dropdown">
                  <vs-dropdown-item>
                     <a @click="downloadFile(tr['document'])"  href.prevent><p style="cursor:pionter"  >Download</p></a>
                   </vs-dropdown-item>
                   <vs-dropdown-item v-if="tr.statusId !=4">
                     <a  href.prevent><p style="cursor:pionter" @click="editMe(tr ,false)" >Edit </p></a>
                   </vs-dropdown-item>
                   <vs-dropdown-item v-if="tr.statusId !=4 && checkUpdateRevision(tr)" >
                     <a  href.prevent><p style="cursor:pionter" @click="editMe(tr ,true)" >Upload New Version</p></a>
                   </vs-dropdown-item>
                   <vs-dropdown-item v-if="tr.statusId !=4" >
                     <a  href.prevent><p style="cursor:pionter" @click="deleteConform(tr)" >Delete</p></a>
                   </vs-dropdown-item>
                   

                   <vs-dropdown-item v-if=" checkProperty(tr ,'docChangeLogs' ,'length')>0" >
                     <a  href.prevent><p style="cursor:pionter" @click="showVersionDocuments(tr)" >Show Versions</p></a>
                   </vs-dropdown-item>
                    
                      <!-- 
                     <vs-dropdown-item>
                     <a  href.prevent><p style="cursor:pionter" @click="getDetails(tr._id)" >Details</p></a>
                   </vs-dropdown-item>
                    
                  
                      
                     -->
                    
                      
                   </vs-dropdown-menu>
                  
                </vs-dropdown>
              
            </vs-td>


          </vs-tr>
        </template>
      </vs-table>
      <paginate  v-if="list.length>0"  v-model="page" :page-count="totalpages" :page-range="3" :margin-pages="2" :click-handler="pageNate"
        prev-class="vs-pagination--buttons btn-prev-pagination vs-pagination--button-prev"
        next-class="vs-pagination--buttons btn-next-pagination vs-pagination--button-next" :prev-text="'<i></i>'"
        :next-text="'<i></i>'" :container-class="'pagination vs-pagination--nav'" :page-class="'page-item'"></paginate>
    </div>

<!---
    <vs-popup class="holamundo main-popup" :title="edit?'Edit Form/Letter':'Form/Letter'" v-if="addPopup" :active.sync="addPopup">
     
    </vs-popup>
    -->

     <vs-popup class="holamundo main-popup" :title="'Details'"  :active.sync="detailsView">
      <form>
     
        <div class="form-details">
          <div class="vx-row--">
            <div  class="main-list-wrap"> 
             <div class="vx-row m-0 main-list-panel"> 
              <div class="vx-col md:w-1/2 w-full p-0">
                <div class="main-list">
                  <p>Name
                    <span>{{checkProperty(details ,"name" )}}</span>
                  </p>     
                </div>
              </div>
              <div class="vx-col md:w-1/2 w-full p-0"> 
                <div class="main-list">
                        
                        <p>
                                
                              Type

                                <span>{{checkProperty(details ,"type" )}}</span>
                            </p>
                              
                                
                </div>
             </div>
             </div>

                        

            </div>
            <div class="vx-col w-full"  >
              <ul class="uploaded-list">

              <vs-chip >
                {{ checkProperty(details,'document' ,'name')}}
              </vs-chip>

              </ul>

          </div>
          </div>


          
        </div>
        <div class="popup-footer">
          <vs-button color="dark" @click="edit=false;createNew(false)" class="cancel" type="filled">Cancel</vs-button>
        </div>
      </form>
    </vs-popup>


    <vs-popup class="holamundo main-popup" title="Delete Forms/Letters" :active.sync="approveConformpopUp">
      <div class="form-container">
        
        <div class="vx-row">
          <div class="vx-col w-full">
          <p>{{actionText}}</p>
            
          </div>
          
        </div>
       
      </div>
      <div class="popup-footer">
        <vs-button color="dark" class="cancel" type="filled" @click="approveConformpopUp=false">Cancel</vs-button>
        <vs-button color="success" class="save" type="filled" @click="deleteformandLetter()">Delete</vs-button>
      </div>
    </vs-popup>



    <modal
      name="formsAndLatterModel"
      classes="v-modal-sec"
      :min-width="200"
      :min-height="200"
      :scrollable="true"
      :reset="true"
      width="500px"
      height="auto"
    >
     <div class="v-modal" >
        <div class="popup-header fromDetailsPage">
          <h2 class="popup-title">
             {{popUpTitle}}
          </h2>
          <span @click="hidewModal()">
            <em class="material-icons">close</em>
          </span>
        </div>
         <form @submit.prevent >
        <div class="form-container pb-2">
          <div class="vx-row">
            <div class="vx-col mb-6 mt-1"  v-if=" [1].indexOf(getUserRoleId)>-1">
              <div class="custom-radio custom-radio_btns" >  
                <vs-radio v-if=" !edit || (edit && !checkProperty(selectedItem ,'tenantId'))" class="mr-6"  v-model="wiseSelection" vs-value="true" @change="updateSelection()">Global</vs-radio>
                <vs-radio v-if=" !edit || (edit && checkProperty(selectedItem ,'tenantId'))" v-model="wiseSelection" vs-value="false"  @change="updateSelection()">Customer</vs-radio>
              </div> 
            </div>
            
          <template v-if="!isRvisionUpload">
            <div class="vx-col w-full">
              <div class="form_group  d-block">
                <label class="form_label">Name<em>*</em></label>
                <vs-input @keyup="formerrors.msg=''" v-model="newform.name" name="name" v-validate="'required'" class="w-full"
                   data-vv-as="Name"    />
                <span class="text-danger text-sm"
                  v-show="errors.has('name')">{{ errors.first("name") }}</span>
              </div>
            </div>

              <div class="vx-col w-full" v-if=" wiseSelection !='true' && (!edit || (edit && checkProperty(selectedItem ,'tenantId')) )"  >
               <div class="form_group  d-block">      
                 <div class="con-select w-full"> 
                    <label for class="form_label">Customer</label>
                    <multiselect class="w-full" v-model="newform.tenantId" :options="tenantsList" :multiple="false" name="Customer"
                      :close-on-select="true" :clear-on-select="false" :select-label="''" :preserve-search="true" :disabled="edit"
                       data-vv-as="Customer"   
                       placeholder="Select Customer" label="name" track-by="_id" :preselect-first="false">
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">{{ values.length }}
                          options selected</span>
                      </template>
                    </multiselect>
                    <!-- <span class="text-danger text-sm" v-show="errors.has('form type')">{{ errors.first("form type") }}</span> -->
                 </div>
                 </div>
              </div>

             <div class="vx-col w-full">
               <div class="form_group  d-block">      
                 <div class="con-select w-full"> 
                    <label for class="form_label">Type<em>*</em></label>
                    <multiselect class="w-full"  v-model="newform.type" :options="all_formTypes" :multiple="false" name="form type"
                      :close-on-select="true" :clear-on-select="false" :select-label="''" :preserve-search="true"
                      @input="changedformLatter()"
                      v-validate="'required'"
                      :disabled="edit"
                       data-vv-as="Type"   
                      placeholder="Select Type" label="name" track-by="name" :preselect-first="false">
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">{{ values.length }}
                          options selected</span>
                      </template>
                    </multiselect>
                    <span class="text-danger text-sm" v-show="errors.has('form type')">{{ errors.first("form type") }}</span>
                 </div>
                 </div>
              </div>

            

            <div class="vx-col w-full">
               <div class="form_group  d-block">      
                 <div class="con-select w-full"> 
             
                    <label for class="form_label">Document Type<em>*</em></label>
                    
                    <multiselect class="w-full" v-model="newform.docTypeDetails" 
                    :options="forms_and_letters_type" :multiple="false" 
                    name="doc type"
                      :close-on-select="true" :clear-on-select="false" 
                      :select-label="''" 
                      :preserve-search="true"
                      @input="changedDocType()"
                      v-validate="'required'"
                       data-vv-as="Document Type"   
                      placeholder="Select Document Type" label="name" track-by="name" :preselect-first="false">
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">{{ values.length }}
                          options selected</span>
                      </template>
                    </multiselect>
                    <span class="text-danger text-sm" v-show="errors.has('doc type')">{{ errors.first("doc type") }}</span>
                 </div>
                 </div>
              </div>
              <div class="vx-col w-full" v-if="checkProperty(newform, 'type') && checkProperty(newform, 'type', 'id') == 'Form'">
               <div class="form_group  d-block">      
                 <div class="con-select w-full"> 
             
                    <label for class="form_label">Edition<em>*</em></label>
                    <vs-input class="w-full"   :name="'editionedition'"  v-model="newform.edition"
                   v-validate="'required'"    :data-vv-as="'Edition'"  />
                   
                    <span class="text-danger text-sm" v-show="errors.has('editionedition')">{{ errors.first("editionedition") }}</span>
                 </div>
                 </div>
              </div>
              
              <!-- <immiInput :display="true" :fieldsArray="[]" :cid="'edition'"
                v-model="newform.edition" 
                 :required="true" :fieldName="'edition'" label="First Name" placeHolder="First Name" /> -->
              
            </template>

            

             <div class="vx-col w-full" @click="value =[] ;uploading=false" v-if="newform.type" >
                <div class="form_group file_group  d-block">
                  <label class="form_label">File<em>*</em></label>
                  <div class="vs-component relative">     
                    <file-upload v-model="value" class="file-upload-input upload_file justify-center" :accept="acceptedFiles" :name="'Documents'" :multiple="false" 
                    @input="upload(value)"
                     v-validate="{'required':newform.attachments.length<=0}"
                       data-vv-as="File"   
                    >
                        <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                        Upload
                        
                    </file-upload>
                     <span class="text-danger text-sm" v-show="errors.has('Documents')">{{ errors.first("Documents") }}</span>
                     <span v-if="uploading" class="loader"><img src="@/assets/images/main/loader.gif"></span>   
                  </div>
                 
                  <ul class="uploaded-list">
                      <template v-for="(item, index) in newform.attachments">
                          <vs-chip @click="remove(item, newform.attachments ,index)" :key="index" closable v-if="item.status !== false  && item.name !== null  && item.url !== null  && item.url !== ''">
                              {{ item.name }}
                          </vs-chip>
                      </template>
                  </ul>
                </div>
             </div>
              <div class="vx-col w-full" v-if="isRvisionUpload">
               <div class="form_group  d-block">      
                 <div class="con-select w-full"> 
             
                    <label for class="form_label">Effective Date<em>*</em></label>
                   
                     <datepicker   :typeable="true"
                                :format="customFormatter"
                                v-model="effectiveDate"
                                 v-validate="'required'" 
                                data-vv-as="Effective Date"
                                :disabled-dates="{ to: getPreviousDay }"
                                placeholder="MM/DD/YYYY"
                                name="formeffectiveDate"
                              ></datepicker>
                    
                    
                    <span class="text-danger text-sm" v-show="errors.has('formeffectiveDate')">{{ errors.first("formeffectiveDate") }}</span>
                 </div>
                 </div>
              </div>
            <div class="vx-col w-full">
              <div class="form_group  d-block">
                <label class="form_label">Description<em>*</em></label>
                
                <!-- <vs-textarea
                  data-vv-as="Description"
                  v-model="newform.description"
                  name="Description"
                  v-validate="'required'" 
                  class="w-full"
                 
                /> -->
                <ckeditor   data-vv-as="Description"
                  v-model="newform.description"
                  name="Description"
                  v-validate="'required'" 
                  class="w-full" :editor="editor" :config="editorConfig"></ckeditor>
                 <span class="text-danger text-sm" v-show="errors.has('Description')">{{ errors.first("Description") }}</span>
              </div>
            </div>

                   
            
          </div>


          <div class="text-danger text-sm formerrors" v-show="formerrors.msg" @click="formerrors.msg=''">
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
              icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
          </div>
        </div>
        <div class="popup-footer">
        <!--  validateForm ---->
          <vs-button color="dark" @click="edit=false;createNew(false)" class="cancel" type="filled">Cancel</vs-button>
          <vs-button color="success"  :disabled=" validateForm || formSubmited" class="save" v-if="edit" @click="updateformandLetter()" type="filled">Update</vs-button>
          <vs-button color="success" :disabled="formSubmited" class="save" v-else @click="createformandLetter()" type="filled">Save</vs-button>
        </div>
      </form>

        </div>
        </modal>

        <modal
      name="versionDocumentsModel"
      classes="v-modal-sec"
      :min-width="200"
      :min-height="200"
      :scrollable="true"
      :reset="true"
      width="500px"
      height="auto"
     
    >
     <div class="v-modal version-documents-arrow" >
        <div class="popup-header fromDetailsPage">
          <h2 class="popup-title">
             Version Documents
          </h2>
          <span @click="$modal.hide('versionDocumentsModel')">
            <em class="material-icons">close</em>
          </span>
        </div>
          
             <div class="form-container "  v-if="checkProperty(selectedItem ,'docChangeLogs')">
               <div class="vx-row">
                <vs-collapse accordion >
                  <vs-collapse-item class="closeDropdown"  v-for="( doc, ind) in selectedItem['docChangeLogs']" :key="ind" >
                    <div slot="header" class="ss">
                      <vs-list-item class="documents_accordian"  >
                        <div class="documents_accordian_tile">
                        <docType :item="doc['newDocument']" />

                        <span>{{ checkProperty(doc ,'newDocument' ,'name')}}<br/><small>Effective Date: {{ checkProperty(doc ,'effectiveDate' ) | formatDate}}</small></span>

                        </div>
                         <div class="vertical-menu">
                              <span class="menu-icon">  <i class="material-icons">more_vert</i>  </span>
                          
                              <ul>
                                 <li> <a @click="downloadFile(doc['newDocument'])"  href.prevent><p style="cursor:pionter"  >Download</p></a></li>
                              </ul>
                         </div>
                      </vs-list-item>
                                       
                    </div>
                    <vs-list-item class="documents_accordian"   >
                          <div class="documents_accordian_tile">
                          <docType :item="doc['oldDocument']" />
                            <span>{{ checkProperty(doc ,'oldDocument' ,'name')}}<br/><small></small></span>
                          </div>
                          <div class="vertical-menu">
                              <span class="menu-icon">  <i class="material-icons">more_vert</i>  </span>
                          
                              <ul>
                                 <li> <a @click="downloadFile(doc['oldDocument'])"  href.prevent><p style="cursor:pionter"  >Download</p></a></li>
                              </ul>
                         </div>
                      </vs-list-item>
                 </vs-collapse-item>
                </vs-collapse>


               </div>
             </div>  
          
     </div>
     </modal>
  </div>
</template>

<script>
import immiInput from "@/views/forms/fields/simpleinput.vue";
import DateRangePicker from "vue2-daterange-picker";
  import Datepicker from "vuejs-datepicker-inv";
  import Paginate from "vuejs-paginate";
  import NoDataFound from "@/views/common/noData.vue";
  import docType from "@/views/common/docType.vue";
  
import "vue2-daterange-picker/dist/vue2-daterange-picker.css";

  import _ from "lodash";
  import { FormWizard, TabContent } from "vue-form-wizard";
  import "vue-form-wizard/dist/vue-form-wizard.min.css";
   import moment from 'moment'
  import PhoneMaskInput from "vue-phone-mask-input";
  import JQuery from 'jquery'
  import { TheMask } from 'vue-the-mask'
  
import FileUpload from "vue-upload-component/src";
import VuePhoneNumberInput from 'vue-phone-number-input';
import 'vue-phone-number-input/dist/vue-phone-number-input.css';
import { MoreVerticalIcon } from 'vue-feather-icons';
import Vue from 'vue';
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';

  export default {
    provide() {
      return {
        parentValidator: this.$validator,
      };
    },
    computed:{
      getPreviousDay() {
        let date = new Date()
  const previous = new Date(date.getTime());
  previous.setDate(date.getDate() - 1);

  return previous;
},
      validateForm(){
        if(
          (this.newform.name && this.newform.name.trim() !='' ) 
          && ( _.has(this.newform['type'] ,"name")  )
          && ( _.has(this.newform ,"document") && this.newform.document && (Object.keys(this.newform.document).length>0 ) )
        
        ){

          return false;
        }else{
          return true;
        }

      },
      acceptedFiles(){
      let returnValue ='*';
      if(_.has(this.newform['type'] ,"name")){
        
        if(this.newform['type']['name'] =="Form" ){
          returnValue ='application/pdf';
        }else if(this.newform['type']['name'] =="Letter" || this.newform['type']['id'] =='audit_response' ){
          returnValue ='application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document';
        }

      }
      return returnValue;
      //image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document
    }
    },
    components: {
      immiInput,
      docType,
      NoDataFound,
      DateRangePicker,
      VuePhoneNumberInput,
      Datepicker,
      Paginate,
      FileUpload,
      FormWizard,
      TabContent,
      PhoneMaskInput,
      TheMask,
      MoreVerticalIcon
    },

    data: () => ({
      editor: ClassicEditor,
      editorConfig: {
       toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
      },
      wiseSelection:'true',
      isGlobal:true,
      tenantsList:[],
      tenantListFilter:[],
      popUpTitle:'Form/Letter',
      effectiveDate:'',
      isRvisionUpload:false,
      forms_and_letters_type:[],
      formsAndLettersTypeFIlter:[],
      callFromSerch:false,
      formSubmited:false, 
      uploading:false,
      detailsView:false,
      details:null,
    selected_createdDateRange: ["", ""],
    autoApply: "",
        value:[],
        all_formTypes:[{"name":"Form" ,"id":"Form"},{"name":"Letter" ,"id":"Letter"},{"name":"Audit Response" ,"id":"audit_response"} ],
        
      selectedItem:null,
      selectedStatus:2,
      actionText:"Do you want to Delete?",
      formerrors: {
        msg: ""
      },
      date: null,
      approveConformpopUp: false,
     
     newform: {name:'' ,type:'', tenantId:'',docTypeDetails:"",docTypeId:"", description:'',"document":null , attachments:[],"today":moment().format("YYYY-MM-DD"),edition:''},
      list: [],
      addPopup: false,
      NewPetition: false,
      
     
      searchtxt: "",
      query: [],
      country_code: 231,
      all_statusids: [],
      selected_statusids: [],
      final_selected_statusids: [],
      filter_roleIds: [],
      final_filter_roleIds: [1,2,3,4,5,8,9,10,11,12],

      
      seleted_states: [],
      final_selected_states: [],
      locations: [],
      // locationIds
      final_selected_typesids:[],
      selected_typeids:[],
      
      
      
      date_range: [],
      page: 1,
      perpage: 25,
      totalpages: 0,
      

     
      switch2:true,
      users_status:{},
      edit:false,
      sortKeys:{},
      sortKey:{},
      details:null
    }),
    watch: {
      searchtxt: function (value) {
        this.getList(true);
      }

    },
    
    methods: {
      updateSelection(){
        if(!this.edit){
          this.newform.tenantId='';
        }
        
      if(this.wiseSelection=='true'){
        this.isGlobal = true;

      }else{
        this.isGlobal = false;
      }
     
     //this.resetForm();
    },
      getenants() {
        let matcher = {};
        let query = {};
        query['page'] = 1;
        query['perpage'] = 10000;
         query['getMasterData'] = true;
        query['filters'] = matcher;
              

        this.$store
          .dispatch("getList",{data:query ,path:'/tenant/list'} )
          .then(response => {
            this.tenantsList = response.list;

          });
      },
      showVersionDocuments(item){
          this.selectedItem = item;
          this.$modal.show('versionDocumentsModel')

      },
      checkUpdateRevision(item){
        //effectiveDate
        if(this.checkProperty(item ,'effectiveDate')){
          let effectiveDate = moment(item['effectiveDate']);
          let today = moment();
          if(today.isAfter(effectiveDate ,"day")){
            return true
          }else{
            return false

          }


        }else{
          return true

        }
      },

      showModal(){
            
            this.$modal.show('formsAndLatterModel');

      },
      hidewModal(){
          this.$modal.hide('formsAndLatterModel');
      },
      downloadFile(document){
        
         window.open(this.$globalgonfig._APIURL+"/common/viewfile?path="+document.path, "_blank");
      },
      getDetails(id){

        let postData = {'formAndLetterId':id};
        this.$store.dispatch("commonAction" ,{data:postData,"path":'/form-letter/details'})
        .then((response) => {
         
          this.details = response;
          this.detailsView =true;

        })
        .catch((error)=>{
            this.detailsView =false;

        })

      },
      formandLetterDetails(){
        let query = {"formAndLetterId":this.selectedItem['_id']};
        this.$store
          .dispatch("formandLetterDetails", query)
          .then(response => {
             //alert(JSON.stringify(response));
             //this.details
          });

      },
      changedDocType(){
        
         this.newform.docTypeId = null;
        if(this.checkProperty(this.newform  ,'docTypeDetails' ,'id')  ){
            this.newform.docTypeId =this.checkProperty(this.newform  ,'docTypeDetails' ,'id')
          
         }

      },
      changedformLatter(){
         this.newform.attachments =[];
         this.newform.document = null;
         this.newform.docTypeDetails =null;
         this.newform.edition = '';
         this.changedDocType();

         if(this.edit  ){
            this.newform.attachments =[this.selectedItem.document];
            this.newform.document = this.selectedItem.document;
         }

      },
       sortMe(sort_key=''){

      
      if(sort_key !=''){
          this.sortKeys[sort_key] = this.sortKeys[sort_key]==1?-1:1
          // this.sortKey[sort_key] = this.sortKeys[sort_key]
          this.sortKey = {"path":sort_key ,"order":this.sortKeys[sort_key]};

          localStorage.setItem('formandLetter_sort_key', sort_key);
          localStorage.setItem('formandLetter_sort_value', this.sortKey[sort_key]);
          this.getList();
      }
          
      

      },
      editMe(item ,isRvisionUpload =false){
        this.wiseSelection ="true";
        if(this.checkProperty(item,'tenantId')){
          this.wiseSelection ="false";
        }

      
         this.formerrors.msg='';
        this.edit =true;
        this.selectedItem = item;
        this.newform = {name:this.selectedItem.name ,type:'',tenantId:'',"document":null ,'docTypeId':null ,docTypeDetails:null,"attachments":[],"today":moment().format("YYYY-MM-DD") ,"description":'',edition:''};
    
         this.newform =Object.assign(this.newform , { "docTypeId": this.selectedItem['docTypeId'] , "docTypeDetails":this.selectedItem['docTypeDetails'] })

        this.newform['document'] = this.checkProperty(this.selectedItem ,"document");
        this.newform['attachments'] = this.newform['document']?[this.newform['document']]:[];
        this.newform['description'] =this.checkProperty(this.selectedItem ,"description");
        this.newform['edition'] =this.checkProperty(this.selectedItem ,"edition");
        if(this.checkProperty(this.selectedItem ,"tenantDetails")){
          this.newform['tenantId'] = this.selectedItem['tenantDetails']
        }
        if( this.checkProperty(this.selectedItem ,"type")){
          //all_formTypes:[{"name":"Form" ,"id":"Form"},{"name":"Letter" ,"id":"Letter"} ],
          if(this.checkProperty(this.selectedItem ,"type") =="Form"){

             this.newform['type'] ={"name":"Form" ,"id":"Form"};

          }
          if(this.checkProperty(this.selectedItem ,"type") =="Letter"){

             this.newform['type'] ={"name":"Letter" ,"id":"Letter"};

          }

          if(this.checkProperty(this.selectedItem ,"type") =="audit_response"){

            this.newform['type'] ={"name":"Audit Response" ,"id":"audit_response"};

          }
         

        }
        this.addPopup=true;
         this.formSubmited =false;
          this.isRvisionUpload = isRvisionUpload;

           this.popUpTitle = "Edit Form/Letter"
           if(this.isRvisionUpload){
             
               this.newform.attachments =[];
               this.popUpTitle = "Upload  Form/Letter Version"

           }
          this.$validator.reset();
          this.showModal()

      },
     
     createNew(action =true){
      this.wiseSelection ="true";
      this.selectedItem =null;
       this.edit =false;
       this.isRvisionUpload =false;
       this.effectiveDate ='';
       this.newform = {name:'' ,type:'',tenantId:'', docTypeDetails:"",docTypeId:"","document":null ,"attachments":[],"today":moment().format("YYYY-MM-DD") ,"description":'',edition:''};
      this.addPopup=action;
      this.formerrors.msg='';
       this.formSubmited =false;
        this.$validator.reset();
       if(this.addPopup){
         this.showModal()
       }else{
         this.hidewModal()
       }
       this.popUpTitle = "Add Form/Letter"
       this.$vs.loading.close();
       this.$validator.reset();

      
     },
      
      deleteConform(item ){
        this.selectedItem = item;
        this.approveConformpopUp =true;
        this.edit= false;

      },
  
      getList(callFrom=false) {
       this.callFromSerch =callFrom;
        let matcher = {
          title: this.searchtxt,
          statusIds: this.final_selected_statusids,
          typeIds:this.final_selected_typesids,
          createdDateRange:[],
          "docTypeIds":[]
          
        };
        if (
        this.selected_createdDateRange["startDate"] &&
        this.selected_createdDateRange["startDate"] != "" &&
        this.selected_createdDateRange["endDate"] != "" &&
        this.selected_createdDateRange["endDate"]
      ) {
        matcher["createdDateRange"] = [
          this.selected_createdDateRange["startDate"],
          this.selected_createdDateRange["endDate"]
        ];
      }
      if(this.checkProperty(this.formsAndLettersTypeFIlter ,'length') >0){
        matcher['docTypeIds'] = this.formsAndLettersTypeFIlter.map((item)=>item.id)
      }
      if(this.checkProperty(this.tenantListFilter,'length') > 0){
        matcher['tenantIds'] = this.tenantListFilter.map((item)=>item._id)
      }

        let query = {};
        query['page'] = this.page;
        query['perpage'] = this.perpage;
        query['filters'] = matcher;
        query['sorting'] = this.sortKey;

        this.updateLoading(true);
        
        this.$store
          .dispatch("getList",{data:query ,path:'/form-letter/list'} )
          .then(response => {
             
            this.list = response.list;

            this.totalpages = Math.ceil(response.totalCount / this.perpage);
            setTimeout( ()=> {
            this.updateLoading(false);
            })
            //alert(this.perpage);
          }).catch(()=>{
             this.updateLoading(false);
          })
      },
      updateformandLetter(){
        this.$validator.validateAll().then(result => {
          
          if (result) {
             this.formSubmited =true;
            let postData ={
              "name":this.newform.name ,type:this.newform.type.id, document:this.newform.document ,'description':this.newform['description'] ,"docTypeId":this.newform.docTypeId ,'edition':this.newform.edition,
               today: moment().format("YYYY-MM-DD")
              }
          postData['name']  =this.newform['name'].trim(); 
         postData = Object.assign(postData ,{"formAndLetterId":this.selectedItem['_id']})
         if(this.isRvisionUpload && this.effectiveDate){
           let effectiveDate  = moment(_.cloneDeep(this.effectiveDate)).format("YYYY-MM-DD")
             
               postData = Object.assign(postData ,{"effectiveDate":effectiveDate})
             
             }
        this.$store.dispatch("updateformandLetter", postData)
          .then(response => {
           
            this.formSubmited =false;
            this.showToster({message:response.message,isError:false});
            this.getList();
            this.addPopup =false;
            this.hidewModal();
            this.edit =false;
             this.$vs.loading.close()


          }).catch((er)=>{

             this.formSubmited =false;
              this.$vs.loading.close()
                  Object.assign(this.formerrors, {
                    msg:er
                  });
            //this.showToster({message:"Somthin went wrong..!",isError:true});
          
        });
         }
        });

      },
      createformandLetter() {

        
        this.$validator.validateAll().then(result => {
          if (result) {
            this.formSubmited =true; 

            let postData ={"name":this.newform.name ,type:this.newform.type.id, document:this.newform.document ,"description":this.newform['description'] ,"docTypeId":this.newform.docTypeId,'edition':this.newform.edition}
            postData['name']  =this.newform['name'].trim();
            if(this.newform.tenantId){
              postData['tenantId'] = this.checkProperty(this.newform,'tenantId','_id')
            }
           this.$store
              .dispatch("createformandLetter", postData)
              .then(response => {
                this.formSubmited =false;
                this.$vs.loading.close()
                 this.showToster({message:response.message,isError:false });
                 this.getList();
                 this.addPopup =false;
                  this.hidewModal();
                
              })
              .catch((error)=>{
                this.formSubmited =false;
                 this.$vs.loading.close()
                Object.assign(this.formerrors, {
                    msg:error
                  });
              })
          }
        });
      },
      upload(files ,type="") {
        let model = _.cloneDeep(files);
        this.value = [];
        let fileType = "Form";
       
        if(_.has(this.newform['type'] ,"name")){
        
        if(this.newform['type']['name'] =="Form" ){
             fileType = "Form";
        }else if(this.newform['type']['name'] =="Letter" ){
           fileType = "Letter";
        }else if(this.newform['type']['id'] =="audit_response"){
          fileType = "audit_response";
        }

      }
      this.newform['document'] =null;
       this.newform['attachments'] = [];

            var _current = this;
           // this.$vs.loading();
            let formData = new FormData();
           
            let tempFiles =[]
            if (model.length > 0) {
                this.uploading =true;
                model.forEach((doc, index) => {
                   
                    if((fileType == "Form" && doc.type=='application/pdf' ) || ((fileType == "Letter" || fileType == "audit_response") && (doc.type=='application/msword' || doc.type=='application/vnd.openxmlformats-officedocument.wordprocessingml.document') ) ){

                    
                    formData.append("files", doc.file);
                    formData.append("secureType", "private");
                    formData.append("getDetails", true);
                                        
                    this.$store.dispatch("uploadLocal", formData).then((response) => {
                        response.data.result.forEach((urlGenerated) => {
                            doc.url = urlGenerated;
                            delete doc.file;
                             let temp_file = urlGenerated;
                             
                           
                          tempFiles.push(temp_file);
                          let fl = { "name":temp_file['name'] ,"url":temp_file['path'] , "mimetype":temp_file['mimetype']} ;
                          this.newform.document =  urlGenerated ;
                          this.newform.attachments.push(fl);
                        
                         this.uploading =false;
                         this.$vs.loading.close();
                         if (tempFiles.length >= model.length) {
                              _current.$vs.loading.close();
                          }   
                       
                       });
                    
                    });

                  }else{
                     this.uploading =false;
                     _current.$vs.loading.close();
                  }
               });
                
               
            }     
              //  model.splice(0, mapper.length, ...mapper);
            
    },
     remove(item, data ,filindex) {
            data.splice(filindex, 1);
            this.newform.document =null;
    
    },  
      
      get_statusids() {
        
        let item ={
          page:1,
          perpage: 10000,
          category: "form_letter_status",
          
        };

        this.$store.dispatch("getMasterData", item).then(response => {
         
             this.all_statusids = [
            /*  {
              "id": 1,
              "name": "Pending"
              },
              */
              {
              "id": 2,
              "name": "Active"
              },
              /*{
              "id": 3,
              "name": "Inactive"
              },
              */
              {
              "id": 4,
              "name": "Deleted"
              }
              ]
         // alert(JSON.stringify(response.list))
        });
      },
      
      set_filter: function () {
        
        this.$refs["filter_menu"].dropdownVisible = false;
       
        this.final_selected_statusids = [];
        if (this.selected_statusids.length > 0) {
          this.final_selected_statusids = [];
          for (let ind = 0; ind < this.selected_statusids.length; ind++) {
            let current_index = this.selected_statusids[ind];
            this.final_selected_statusids.push(current_index["id"]);
          }
        }

        this.final_selected_typesids = [];
        if (this.selected_typeids.length > 0) {
          this.final_selected_typesids = [];
          for (let ind = 0; ind < this.selected_typeids.length; ind++) {
            let current_index = this.selected_typeids[ind];
            this.final_selected_typesids.push(current_index["id"]);
          }
        }

        
// alert(this.final_selected_typesids)
       

       

        this.getList(true);
      },
      clear_filter: function () {
        this.formsAndLettersTypeFIlter = []
        this.tenantListFilter = []
        this.searchtxt ='';
        this.callFromSerch =false;
        this.$refs["filter_menu"].dropdownVisible = false;
        
        this.selected_statusids = [];
        this.final_selected_statusids = [];
        this.final_selected_typesids = [];
        this.selected_typeids = [];
      
        this.date = "";
        this.date_range = [];
         this.selected_createdDateRange["startDate"] = "";
         this.selected_createdDateRange["endDate"] = "";
        this.getList();
      },
      pageNate(pageNum) {
        this.page = pageNum;
        this.getList();
      },
      
      deleteformandLetter( ){
        let post_data = {"formAndLetterId":this.selectedItem['_id'] }
        this.$store.dispatch("deleteformandLetter", post_data)
          .then(response => {
           
           this.approveConformpopUp = false;
            this.showToster({message:response.message,isError:false});
            this.getList();
            this.edit =false;


          }).catch((er)=>{
            this.showToster({message:er,isError:true});
          
        });
      },

    },
    mounted() {

      //this.$store.dispatch("updateSidebarWidth", "extended");
      
      this.selected_statusids = [];
      this.final_selected_statusids = [];
      this.seleted_states = [];
      this.final_selected_states = [];
      this.sortKeys = {
            'name':1,
            'typeName':1,
            'statusName':1,
            "createdOn":-1,
            "updatedOn":1,
            docTypeName:1
     
    },

    this.sortKey = {"path":"createdOn" ,"order":-1};

    if(localStorage.getItem('formandLetter_sort_key') && localStorage.getItem('userrole_sort_value')  && localStorage.getItem('userrole_sort_value') >=-1 ){
        this.sortKeys[localStorage.getItem('formandLetter_sort_key')] = parseInt(localStorage.getItem('userrole_sort_value'));
        this.sortKey = {"path":localStorage.getItem('formandLetter_sort_key') ,"order":parseInt(localStorage.getItem('userrole_sort_value'))};
        

    }

    //forms_and_letters_type

    let postData = {
          page:1,
          perpage: 10000,
          category: "forms_and_letters_type",
         // tenantId: "5db7d79d6032453bd060ed9c",
        }

    this.$store.dispatch("getMasterData", postData).then(response => {
        
        this.forms_and_letters_type = response.list;

        })

   
     
      this.get_statusids();
      this.getList();
      this.getenants();
     

    }
  };
</script>
