<template>
  <div>
    <div class="details_list_sec">
    <span class="back_btn" v-if="!isLoadedFromUrl" @click="$store.dispatch('common/activateSettingTab' ,'branchList')"><img src="@/assets/images/main/return_arrow.png">Go to Branch List</span>
      <div class="details_list_cnt padb10 mb-5 relative">
          <h3 class="small-header mart20">General Information</h3>
        
          <div v-if="branchDetails" class="branch_status" :class="{'status_active': checkProperty(branchDetails ,'active' ), 'status_inactive': !checkProperty(branchDetails ,'active' )}">
            <template v-if="checkProperty(branchDetails ,'active' )"> Active</template>
            <template v-else> In-active</template>
          </div>
          <div  class="main-list-wrap"> 
              <div class="vx-row m-0 main-list-panel">  
                  <div class="vx-col md:w-1/3 w-full p-0">
                      <div class="main-list">
                      
                      <p>
                              
                            Branch Name

                              <span>{{
                                checkProperty(branchDetails ,"name" )?checkProperty(branchDetails ,"name" ):'--'
                                
                                }}</span>
                              
                          </p>
                            
                              
                      </div>
                  </div>
                  <div class="vx-col md:w-1/3 w-full p-0">
                      <div class="main-list">
                      <p>
                              
                          Phone Number

                              <span>
                              <template v-if="checkProperty(branchDetails ,'phone' )">
                              {{checkProperty( branchDetails,"phoneCountryCode" ,'countryCallingCode', "--")?checkProperty( branchDetails,"phoneCountryCode" ,'countryCallingCode')+'&nbsp;':''}}
                              {{checkProperty(branchDetails ,"phone" )?checkProperty(branchDetails ,"phone" ):'--'}}
                              </template>
                              <template v-else>--</template>
                              </span>
                          </p>
                            
                              
                      </div>
                  </div>
                  <div class="vx-col md:w-1/3 w-full p-0">
                      <div class="main-list">
                      <p>
                              
                        Mobile Telephone Number

                              <span>
                              <template v-if="checkProperty(branchDetails ,'homePhone' )">
                              {{checkProperty( branchDetails,"homePhoneCountryCode" ,'countryCallingCode', "--")?checkProperty( branchDetails,"homePhoneCountryCode" ,'countryCallingCode')+'&nbsp;':''}}
                              {{checkProperty(branchDetails ,"homePhone" )?checkProperty(branchDetails ,"homePhone" ):'--'}}
                              </template>
                              <template v-else>--</template>
                              </span>
                          </p>
                            
                              
                      </div>
                  </div>
                   <div class="vx-col md:w-1/3 w-full p-0">
                      <div class="main-list">
                      <p>
                              
                          Fax Number

                              <span>
                               <template v-if="checkProperty(branchDetails ,'fax' )">
                                  {{checkProperty( branchDetails,"faxCountryCode" ,'countryCallingCode')?checkProperty( branchDetails,"faxCountryCode" ,'countryCallingCode')+'&nbsp;':''}}
                                  {{checkProperty(branchDetails ,"fax" )?checkProperty(branchDetails ,"fax" ):'--'}}
                               </template>
                              <template v-else>--</template>
                              </span>
                          </p>
                            
                              
                      </div>
                  </div>

                  <div class="vx-col md:w-1/3 w-full p-0">
                      <div class="main-list">
                      <p>
                              
                         Branch Manager

                              <span>
                               <template v-if="checkProperty(branchDetails ,'userDetails' ,'name' )">
                                  {{checkProperty( branchDetails,"userDetails" ,'name')?checkProperty( branchDetails,"userDetails" ,'name'):'--'}}
                                 <br>
                                  {{checkProperty( branchDetails,"userDetails" ,'email')?checkProperty( branchDetails,"userDetails" ,'email'):''}}
                                 
                               </template>
                              <template v-else>--</template>
                              </span>
                          </p>
                            
                              
                      </div>
                  </div>
              </div>
          </div>            

          <h3 class="small-header">Contact Person </h3>
          <div  class="main-list-wrap"> 
              <div class="vx-row m-0 main-list-panel">  
            
                  <div class="vx-col md:w-1/3 w-full p-0">

                      <div class="main-list">
                      <p>
                              
                              First Name

                              <span>
                              
                               {{checkProperty(branchDetails ,"contact"  ,'firstName')?checkProperty(branchDetails ,"contact"  ,'firstName'):'--'}}
                              </span>
                             
                          </p>
                            
                              
                      </div>
                  </div>
                  <div class="vx-col md:w-1/3 w-full p-0" >
                      <div class="main-list">
                      <p>
                              
                              Middle Name

                              <span>
                             
                              {{checkProperty(branchDetails ,"contact"  ,'middleName')?checkProperty(branchDetails ,"contact"  ,'middleName'):'--'}}
                              </span>
                             
                          </p>
                            
                              
                      </div>
                  </div>

                  <div class="vx-col md:w-1/3 w-full p-0">
                      <div class="main-list">
                      <p>
                              
                              Last Name

                              <span>
                           
                               {{checkProperty(branchDetails ,"contact"  ,'lastName')?checkProperty(branchDetails ,"contact"  ,'lastName'):'--'}}
                              </span>
                             
                          </p>
                            
                              
                      </div>
                  </div>
                    <div class="vx-col md:w-1/3 w-full p-0">
                  
                      <div class="main-list">
                      <p>
                              
                              Email
                               
                              <span>
                              
                              {{checkProperty(branchDetails ,"contact"  ,'email')?checkProperty(branchDetails ,"contact"  ,'email'):'--'}}
                              </span>
                              
                          </p>
                            
                              
                      </div>
                  </div>
                  <div class="vx-col md:w-1/3 w-full p-0">
                      <div class="main-list">
                      <p>
                              
                              Phone Number

                              <span>

                              {{checkProperty( branchDetails.contact,"phoneCountryCode" ,'countryCallingCode', "--")?checkProperty( branchDetails.contact,"phoneCountryCode" ,'countryCallingCode')+'&nbsp;':''}}
                              {{checkProperty(branchDetails ,"contact"  ,'phone')?checkProperty(branchDetails ,"contact"  ,'phone'):'--'}}
                              </span>
                          </p>
                            
                              
                      </div>
                  </div>
                  
              </div>
          </div> 
          
          <h3 class="small-header">Address</h3>
          <div class="main-list-wrap" v-if="checkProperty(branchDetails,'address')">
              <div class="vx-row m-0 main-list-panel">
                                                          
                  <div class="vx-col w-full p-0" >
                      <div class="main-list auto_h">
<p>
                <span v-html="$options.filters.addressformat(branchDetails.address)"></span>

</p>
                      </div>
                  </div>
                
                          
              </div>
        </div>  


             <h3 class="small-header" v-if="checkProperty(branchDetails,'mailingaddress','line1')!=''">Mailing Address</h3>
          <div class="main-list-wrap" v-if="checkProperty(branchDetails,'mailingaddress','line1')!=''">
              <div class="vx-row m-0 main-list-panel">
                                                          
                  <div class="vx-col w-full p-0" >
                      <div class="main-list auto_h">
<p>
                <span v-html="$options.filters.addressformat(branchDetails.mailingaddress)"></span>

</p>
                      </div>
                  </div>
                
                          
              </div>
        </div>    
        
      
        
      </div>
    </div>
      <vs-popup class="holamundo main-popup" :title="(checkProperty(selectedItem,'active')?'Inactivate ':' Activate')+' Branch'" v-if="activatePopUp"   :active.sync="activatePopUp" >
      <div class="form-container">
        
        <div class="vx-row">
          <div class="vx-col w-full">
          <p>Are you sure of {{checkProperty(selectedItem, 'active')?'In':''}}activating this Branch?</p>
            
          </div>
          
        </div>
       
      </div>
      <div class="popup-footer">
        <vs-button color="dark" class="cancel" type="filled" @click="activatePopUp=false">Cancel</vs-button>
        <vs-button color="success" class="save" type="filled"  v-on:click="activateBranch()">{{checkProperty(selectedItem,'active')?'Inactivate ':' Activate'}}</vs-button>
      </div>
    </vs-popup>
    <!-- {{getBranchdetails()}} -->
    <!-- <div class="divider"></div> -->
    <template v-if="(branchId != null)">
      <defaultUserAssignment :branchId="branchId" :branchDetailss="branchDetails" />
    </template>
  
  </div>
</template>

<script>
import defaultUserAssignment from '@/views/defaultUserAssignment.vue'
  export default {
    props: {
       isLoadedFromUrl:{ type: Boolean, default: true},
       selectedBranch:null
     },
    components: {
      defaultUserAssignment,
    },

    data: () => ({ 
     edit:false,
     branchId:null,
     branchDetails: '',  
     selectedItem: null,
     activatePopUp:false,
     all_status:[{"name":"Active" ,"id":true} ,{"name":"Inactive" ,"id":false}],
     all_active_status:[{"name":"Active" ,"id":true} ,{"name":"Inactive" ,"id":false}],
    
     formerrors: {
        msg: ""
      },
  }),
    watch: {
      searchtxt: function () {
        this.getList();
      }

    },
    methods: {
       openactivepopup(item){
         this.selectedItem = item;
        this.activatePopUp =true;
        this.edit= false;
      },
         activateBranch(){
         let action =true;
        //  alert(this.selectedItem['active'])
         if(this.selectedItem['active'] ){
           action = false;
         }else{
           action =true;
         }
        let postData = {branchId:this.selectedItem['_id'] ,"active":action};
        this.$store.dispatch("commonAction" ,{"data":postData , "path":"/branch/manage-active-status"})
        .then((res)=>{
          this.activatePopUp = false;
          this.showToster({message:res.message ,isError:false});
          this.getBranchdetails();

        })
        .catch((err)=>{

           this.showToster({message:err ,isError:true});
        })
      },

      getBranchdetails(){
        let postData = {
          branchId : this.branchId
        }
       
        this.$store.dispatch("commonAction", {"data":postData ,"path":"/branch/details"})
              .then(response => {
                //alert(JSON.stringify(response))
                this.branchDetails= response
                
              })
               .catch(error => {
                  this.showToster({message:error,isError:true });
              })
      },
             
   
    
    },
    mounted() {
    
      if(this.checkProperty(this.$route.params, 'itemId') &&  this.isLoadedFromUrl){
         this.branchId = this.$route.params.itemId;
         this.getBranchdetails();
         
        
      }else if(!this.isLoadedFromUrl && this.checkProperty(this.selectedBranch, '_id')){
       this.branchId = this.selectedBranch['_id'];
         this.getBranchdetails();
      }
    
    }
  };
</script>
