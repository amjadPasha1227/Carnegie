<template>
  <div class="tab-inner-content">
    <div class="tabs-content-panel tab-pad-wrap">
      <div class="card-panels prev-versions">
        <vs-row vs-justify="center">
          <vs-col class="p-0" type="flex" vs-justify="center" vs-align="center" vs-w="12">
            <!-- Education card html-->
          
            <template v-if="formsAndLettersList.length <=0">
              <div  class="forms_letters dd forms_letters-v2" >
                  <vs-card class="no-card FL-height">               
                      <template v-if="(checkProperty(petition,'intStatusDetails','id')==1 ) && (checkActionButton ||  checkUserAccessBtn || IsAdminUser) && checkNoNotifyUserIds">
                          <template
                            v-if="
                              ([3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13].indexOf(getUserRoleId) >
                                -1 ) ||
                              ([3, 4, 5, 6, 7, 8, 9, 10, 11, 12 ,13].indexOf(getUserRoleId) >
                                -1 )
                            "
                          >
                            <div class="pd_upload_actions">

                              <template
                                v-if="
                                  [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13].indexOf(
                                    getUserRoleId
                                  ) > -1 &&  (checkIsActiveUser || IsAdminUser) &&
                                  checkProperty(getPetitionDetails, 'status') != false
                                "
                              >
                                <div class="generate_sec ml-auto">
                                
                                  <span
                                    class="generate-btn"
                                    @click="openGenerateFormsLattersPopup()"
                                  >
                                    <figure
                                      v-if="generatingFiles || loadingFormLatters"
                                      class="loader loader2"
                                    >
                                      <img src="@/assets/images/main/loader.gif" />
                                    </figure>
                                    Generate
                                  </span>
                                </div>
                              </template>
                            </div>
                          </template>
                      </template>
                      
                        <NoDataFound
                            ref="NoDataFoundReff"
                            
                            heading="No Documents Found."
                            type="documents"
                            :loading:="false"
                          />
                  </vs-card>
              </div>
            </template>
            <template v-else-if="checkProperty(petition, 'subTypeDetails', 'id') != 15 && formsAndLettersList.length >0">
               <!-----docUserType'] =='Beneficiary' Beneficiary Forms and Documents-->
              <div  class="forms_letters dd forms_letters-v2" @click="docUserType='Beneficiary' ;setdocUserType('Beneficiary')">
                
                  <template >
                    <div :label="'Forms'" >
                      <vs-card class="no-card FL-height">
                        <template v-if="(checkProperty(petition,'intStatusDetails','id')==1 ) && (checkActionButton ||  checkUserAccessBtn || IsAdminUser) && checkNoNotifyUserIds">
                        <template
                          v-if="
                            ([3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13].indexOf(getUserRoleId) >
                              -1 ) ||
                            ([3, 4, 5, 6, 7, 8, 9, 10, 11, 12 ,13].indexOf(getUserRoleId) >
                              -1 )
                          "
                        >
                          <div class="pd_upload_actions">
                            
                            <template
                              v-if="
                                [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13].indexOf(
                                  getUserRoleId
                                ) > -1 &&  (checkIsActiveUser || IsAdminUser) &&
                                checkProperty(getPetitionDetails, 'status') != false
                              "
                            >
                              <div class="generate_sec ml-auto">
                              
                                <span
                                  class="generate-btn"
                                  @click="openGenerateFormsLattersPopup()"
                                >
                                  <figure
                                    v-if="generatingFiles || loadingFormLatters"
                                    class="loader loader2"
                                  >
                                    <img src="@/assets/images/main/loader.gif" />
                                  </figure>
                                  Generate
                                </span>
                              </div>
                            </template>
                          </div>
                        </template>
                      </template>

                      <template v-if="checkProperty(petitionhistory, 'comment')">
                        <div
                            v-if="checkProperty(petitionhistory, 'comment') && checkProperty(petitionhistory, 'comment') != ''"
                            class="title_des alert_title_des"
                          >
                          
                          <p><span class="notes_head">Notes from Law Office:</span> {{ returnCommentText(checkProperty(petitionhistory, 'comment')) | commentSubStr }}</p>
                          <span v-if="checkCommentLength(checkProperty(petitionhistory, 'comment'))" class="view_more" @click="showHistoryComment(petitionhistory)"> View More</span>
                        </div>
                      </template>
                        <div
                          v-if="formsAndLettersList.length > 0  && (getUserRoleId !=51 || (getUserRoleId ==51 && checkProperty(petition, 'completedActivities', 'length')>0 &&  petition['completedActivities'].indexOf('REQUEST_BENEFICIARY_SIGN')>-1))  "
                          class="forms_accordian forms_accordian-v2 hidedropdown marb10"
                        >
                          <!--download bar 9,10-->
                          <!-- v-if="
                              [3, 4, 9, 10].indexOf(getUserRoleId) > -1 && !checkActiveList
                            "-->
                          
                          <div
                            v-if="
                            ( (([3, 4].indexOf(getUserRoleId) > -1 || checkDocM) && checkActiveList) 
                            ||
                            (!([3, 4].indexOf(getUserRoleId) > -1 || checkDocM) && checkActiveList))
                            "
                          >
                            <vs-list-item class="cards-list-heading">
                              <h2>
                              
                                Beneficiary Forms and Letters
                              
                              </h2>
                              <div class="d-flex">
                                <span
                                v-if="
                                checkProperty(getPetitionDetails, 'status') != false &&
                                [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13].indexOf(
                                  getUserRoleId
                                ) > -1 &&
                                (checkIsActiveUser || IsAdminUser)
                              "
                                 class="download-all mr-3" 
                                 @click="
                                 depType ='beneficiary';depLabel = 'beneficiary';docUserType ='Beneficiary';
                                 showDocType=true;
                                fuploder = false;
                                parentId = '';
                                entityIdDetails =null;entityId=''
                                fileuploadPopup = true;
                                (formerrors.msg = ''),
                                  (uploadMainDocuments = []),
                                  (uploadFinalMainDocuments = []);
                                  resetForms()
                              "
                                 >
                                  Upload
                                  <img src="@/assets/images/main/upload.svg" />
                              </span>
                              

                              <span v-if="checkFormsAndLetters('beneficiary')" class="download-all" @click=" depType ='beneficiary';depLabel = 'beneficiary';docUserType ='Beneficiary';openDownloadPopup(true)">
                                Download
                                <img src="@/assets/images/main/download.svg" />
                              </span>
                              </div>
                            </vs-list-item>
                          </div>
                          <vs-collapse accordion class="forms-letters-accordian" v-if="checkFormsAndLetters('beneficiary')">
                            <template v-for="(forms, index) in formsAndLettersList">
                            <template v-if="forms['docUserType'] =='Beneficiary'">
                              <!-- v-if="(currentRole ==12 && forms.selectedForSigning ) || currentRole !=12 "-->
                              <div  class="no-accordian" @click="changeTab(forms['type'] ,forms ,'Beneficiary')"
                                v-if="(([3, 4, 9, 10].indexOf(getUserRoleId) > -1) || ( [3, 4, 9, 10].indexOf(getUserRoleId) <= -1 &&  forms.statusId == 2 || forms.statusId == '2'))"
                                :key="index"
                              >
                                <vs-collapse-item
                              
                                  :class="{
                                    closeDropdown: currentRole == 50,
                                    'no-list':
                                      checkProperty(forms, 'reverse_document_versions') &&
                                      forms['reverse_document_versions'].length == 0,
                                  }"
                                  :not-arrow="
                                    !(
                                      checkProperty(forms, 'reverse_document_versions') &&
                                      forms['reverse_document_versions'].length >= 0
                                    )
                                  "
                                >
                                  <div slot="header" class="ss">
                                    <vs-list-item class="documents_accordian">
                                    </vs-list-item>
                                  </div>

                                  <template
                                    v-if="
                                      checkProperty(forms, 'name') ||
                                      (checkProperty(forms, 'reverse_document_versions') &&
                                        [50, 51].indexOf(getUserRoleId) <= -1)
                                    "
                                  >
                                    <div class="list_title">
                                      <div class="documents_accordian_tile">
                                        <docType :item="forms" />
                                        <span
                                          @click="
                                            $store.commit('selectedForEditDocument', null);
                                            fetchSignedUrl(forms);
                                          "
                                          ><em class="fl_scanned_docs" :title="forms.name"  :generated="checkProperty(forms,'generated')?checkProperty(forms,'generated'):'false'"  :id="checkProperty(forms,'_id')" :parent="checkProperty(forms,'parentId')" >{{ forms.name }}
                                            <small class="support_letter_text" v-if="false  && forms['docUserType'] =='Beneficiary'">(Beneficiary)</small>
                                            <small class="support_letter_text" v-if="false  && forms['docUserType'] =='Dependent'">(Dependent)</small>
                                            <template v-if="forms['type']=='Letter' && forms['entityId'] ">
                                                <small class="support_letter_text" v-if="forms['type']=='Letter' && forms['entityId'] =='support_letter'">(Support Letter)</small>
                                                <small  class="support_letter_text" v-else>(Cover Letter)</small>
                                            </template>
                                            
                                            </em>
                                            <small>{{
                                            getformated(forms)
                                          }}</small></span
                                        >
                                      </div>
                                      <div class="d-flex align-center">
                                        <template
                                          v-if="
                                            (checkIsloginUserDoce ||
                                              checkIsloginUserDocm ||
                                              [3, 4].indexOf(getUserRoleId) > -1) &&
                                            checkProperty(getPetitionDetails, 'status') !=
                                              false
                                          "
                                        >
                                          <span
                                            style="margin-right: 30px"
                                            :class="{
                                              status_pending: forms.statusId == 1,
                                              status_active: forms.statusId == 2,
                                              status_rejected: forms.statusId == 3,
                                            }"
                                          >
                                            <template
                                              v-if="checkProperty(forms, 'statusId') == 1"
                                              >Pending</template
                                            >
                                            <template
                                              v-if="checkProperty(forms, 'statusId') == 2"
                                              >Approved</template
                                            >
                                            <template
                                              v-if="checkProperty(forms, 'statusId') == 3"
                                              >Rejected</template
                                            >
                                          </span>
                                        </template>
                                        <div class="vertical-menu">
                                          <span class="menu-icon">
                                            <i class="material-icons">more_vert</i>
                                          </span>
                                          <ul>
                                            <li
                                              v-if="
                                                [50, 51].indexOf(currentRole) < 0 &&
                                                !checkSubmitToUscisCompleted &&
                                                checkProperty(
                                                  getPetitionDetails,
                                                  'status'
                                                ) != false
                                              "
                                              @click="$store.commit('selectedForEditDocument', null);selDoc(forms.mainParentId, forms)"
                                            >
                                              Upload
                                            </li>
                                            <li @click="$store.commit('selectedForEditDocument', null); fetchSignedUrl(forms, false, true)">
                                              View
                                            </li>
                                            <li
                                              v-if="
                                              
                                              checkProperty(forms, 'statusId') == 2 &&
                                                [50, 51].indexOf(currentRole) < 0 &&
                                                !isSubmitUscisCompleted &&
                                                checkProperty(
                                                  getPetitionDetails,
                                                  'status'
                                                ) != false
                                              "
                                              @click=" $store.commit('selectedForEditDocument', forms); editDocument(forms)"
                                            >
                                              Edit
                                            </li>
                                            <!-- <li @click="fetchSignedUrl(forms, true)">
                                              Download
                                            </li> -->
                                            <li @click="$store.commit('selectedForEditDocument', null); download_or_view(forms)">
                                              Download
                                            </li>
                                            <template v-if="isEnableApproveRejMenu">
                                            <li
                                              v-if="
                                                forms.statusId == 1 &&
                                                (checkDocM ||
                                                  [3, 4].indexOf(getUserRoleId) > -1)
                                              "
                                              @click="
                                              $store.commit('selectedForEditDocument', null);
                                                openApproveOrRejectDocs(
                                                  'APPROVED_BY_DOC_MANAGER'
                                                )
                                              "
                                            >
                                              Approve
                                            </li>
                                            <li
                                              v-if="
                                                forms.statusId == 1 &&
                                                (checkDocM ||
                                                  [3, 4].indexOf(getUserRoleId) > -1)
                                              "
                                              @click="
                                                openApproveOrRejectDocs(
                                                  'REJECT_BY_DOC_MANAGER'
                                                )
                                              "
                                            >
                                              Reject
                                            </li>
                                          </template>
                                            <li
                                              v-if="
                                                 [50,51].indexOf(getUserRoleId)<=-1 &&
                                                checkProperty(
                                                  getPetitionDetails,
                                                  'status'
                                                ) != false
                                              "
                                              @click="openConformPopUp(forms)"
                                            >
                                              Delete
                                            </li>
                                          </ul>
                                        </div>
                                      </div>
                                    </div>
                                  </template>
                                </vs-collapse-item>
                              </div> 
                              </template>  
                            </template>
                          </vs-collapse>
                          <template v-if="!checkFormsAndLetters('beneficiary')">
                          <NoDataFound  ref="NoDataFoundReff" :content="getContent()"  heading="No Documents Found." type="documents" :loading:="false" />
                          </template>
                        </div>
                      

                      </vs-card>
                    </div>
                  
                    
                  </template>
                  
                
              </div>
              <!-----Dependent Document checkFormsAndLetters('spouse')--->
              <template v-if=" checkProperty(petition, 'beneficiaryInfo', 'maritalStatus') !=1 ">
                <div v-if="checkProperty(petition, 'dependentsInfo', 'spouse') && checkProperty(petition['dependentsInfo'], 'spouse' ,'h4Required')" class="forms_letters forms_letters-v2 " @click="docUserType='Dependent';setdocUserType('Dependent')">
                  
                  <template >
                    <div :label="'Forms'" >
                      <vs-card class="no-card FL-height">
                      
                        <div
                          v-if="formsAndLettersList.length > 0"
                          class="forms_accordian forms_accordian-v2 hidedropdown marb10"
                        >
                          <!--download bar 9,10-->
                          <!-- v-if="
                              [3, 4, 9, 10].indexOf(getUserRoleId) > -1 && !checkActiveList
                            "-->
                          
                          <div
                            v-if="
                            ( (([3, 4].indexOf(getUserRoleId) > -1 || checkDocM) && checkActiveList) 
                            ||
                            (!([3, 4].indexOf(getUserRoleId) > -1 || checkDocM) && checkActiveList))
                            "
                          >
                            <vs-list-item class="cards-list-heading">
                              <h2>
                              
                                Spouse Forms and Letters 
                              
                              </h2>
                              <div class="d-flex">
                                  <span
                                  v-if="
                                  checkProperty(getPetitionDetails, 'status') != false &&
                                  [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13].indexOf(
                                    getUserRoleId
                                  ) > -1 &&
                                  (checkIsActiveUser || IsAdminUser)
                                "
                                  class="download-all mr-3" 
                                  @click="
                                  depType ='spouse';depLabel = 'spouse';docUserType ='Dependent';
                                  showDocType=true;
                                  fuploder = false;
                                  parentId = '';
                                  entityIdDetails =null;entityId=''
                                  fileuploadPopup = true;
                                  (formerrors.msg = ''),
                                    (uploadMainDocuments = []),
                                    (uploadFinalMainDocuments = []);
                                    resetForms()
                                "
                                  >
                                    Upload
                                    <img src="@/assets/images/main/upload.svg" />
                                </span>
                            

                              <span v-if="checkFormsAndLetters('spouse')" class="download-all" @click=" depType ='spouse';depLabel = 'spouse';docUserType ='Dependent';openDownloadPopup(true)">
                                Download
                                <img src="@/assets/images/main/download.svg" />
                              </span>
                            </div>
                            </vs-list-item>
                          </div>
                          <vs-collapse accordion class="forms-letters-accordian" v-if="checkFormsAndLetters('spouse')">
                            <template v-for="(forms, index) in formsAndLettersList">
                            <template v-if="forms['docUserType'] =='Dependent' && forms['depType']=='spouse'">
                              <!-- v-if="(currentRole ==12 && forms.selectedForSigning ) || currentRole !=12 "-->
                              <div  class="no-accordian" @click="changeTab(forms['type'] ,forms ,'Dependent')"
                                v-if="(([3, 4, 9, 10].indexOf(getUserRoleId) > -1) || ( [3, 4, 9, 10].indexOf(getUserRoleId) <= -1 &&  forms.statusId == 2 || forms.statusId == '2'))"
                                :key="index"
                              >
                                <vs-collapse-item
                              
                                  :class="{
                                    closeDropdown: currentRole == 50,
                                    'no-list':
                                      checkProperty(forms, 'reverse_document_versions') &&
                                      forms['reverse_document_versions'].length == 0,
                                  }"
                                  :not-arrow="
                                    !(
                                      checkProperty(forms, 'reverse_document_versions') &&
                                      forms['reverse_document_versions'].length >= 0
                                    )
                                  "
                                >
                                  <div slot="header" class="ss">
                                    <vs-list-item class="documents_accordian">
                                    </vs-list-item>
                                  </div>

                                  <template
                                    v-if="
                                      checkProperty(forms, 'name') ||
                                      (checkProperty(forms, 'reverse_document_versions') &&
                                        [50, 51].indexOf(getUserRoleId) <= -1)
                                    "
                                  >
                                    <div class="list_title">
                                      <div class="documents_accordian_tile">
                                        <docType :item="forms" />
                                        <span
                                          @click="
                                            $store.commit('selectedForEditDocument', forms);
                                            fetchSignedUrl(forms);
                                          "
                                          ><em class="fl_scanned_docs" :title="forms.name">{{ forms.name }}
                                            <small class="support_letter_text"   v-if="false &&  forms['docUserType'] =='Beneficiary'">(Beneficiary)</small>
                                            <small class="support_letter_text"  v-if="false &&  forms['docUserType'] =='Dependent'">(Dependent)</small>
                                            <template v-if="forms['type']=='Letter' && forms['entityId'] ">
                                                <small class="support_letter_text" v-if="forms['type']=='Letter' && forms['entityId'] =='support_letter'">(Support Letter)</small>
                                                <small  class="support_letter_text" v-else>(Cover Letter)</small>
                                            </template>
                                            </em>
                                            <small>{{
                                            getformated(forms)
                                          }}</small></span
                                        >
                                      </div>
                                      <div class="d-flex align-center">
                                        <template
                                          v-if="
                                            (checkIsloginUserDoce ||
                                              checkIsloginUserDocm ||
                                              [3, 4].indexOf(getUserRoleId) > -1) &&
                                            checkProperty(getPetitionDetails, 'status') !=
                                              false
                                          "
                                        >
                                          <span
                                            style="margin-right: 30px"
                                            :class="{
                                              status_pending: forms.statusId == 1,
                                              status_active: forms.statusId == 2,
                                              status_rejected: forms.statusId == 3,
                                            }"
                                          >
                                            <template
                                              v-if="checkProperty(forms, 'statusId') == 1"
                                              >Pending</template
                                            >
                                            <template
                                              v-if="checkProperty(forms, 'statusId') == 2"
                                              >Approved</template
                                            >
                                            <template
                                              v-if="checkProperty(forms, 'statusId') == 3"
                                              >Rejected</template
                                            >
                                          </span>
                                        </template>
                                        <div class="vertical-menu">
                                          <span class="menu-icon">
                                            <i class="material-icons">more_vert</i>
                                          </span>
                                          <ul>
                                            <li
                                              v-if="
                                                [50, 51].indexOf(currentRole) < 0 &&
                                                !checkSubmitToUscisCompleted &&
                                                checkProperty(
                                                  getPetitionDetails,
                                                  'status'
                                                ) != false
                                              "
                                              @click="selDoc(forms.mainParentId, forms)"
                                            >
                                              Upload
                                            </li>
                                            <li @click="fetchSignedUrl(forms, false, true)">
                                              View
                                            </li>
                                            <li
                                              v-if="
                                              
                                              checkProperty(forms, 'statusId') == 2 &&
                                                [50, 51].indexOf(currentRole) < 0 &&
                                                !isSubmitUscisCompleted &&
                                                checkProperty(
                                                  getPetitionDetails,
                                                  'status'
                                                ) != false
                                              "
                                              @click="editDocument(forms)"
                                            >
                                              Edit
                                            </li>
                                            <!-- <li @click="fetchSignedUrl(forms, true)">
                                              Download
                                            </li> -->
                                            <li @click="download_or_view(forms)">
                                              Download
                                            </li>
                                            <template v-if="isEnableApproveRejMenu">
                                            <li
                                              v-if="
                                                forms.statusId == 1 &&
                                                (checkDocM ||
                                                  [3, 4].indexOf(getUserRoleId) > -1)
                                              "
                                              @click="
                                                openApproveOrRejectDocs(
                                                  'APPROVED_BY_DOC_MANAGER'
                                                )
                                              "
                                            >
                                              Approve
                                            </li>
                                            <li
                                              v-if="
                                                forms.statusId == 1 &&
                                                (checkDocM ||
                                                  [3, 4].indexOf(getUserRoleId) > -1)
                                              "
                                              @click="
                                                openApproveOrRejectDocs(
                                                  'REJECT_BY_DOC_MANAGER'
                                                )
                                              "
                                            >
                                              Reject
                                            </li>
                                          </template>
                                            <li
                                              v-if="
                                                [50,51].indexOf(getUserRoleId)<=-1 &&
                                                checkProperty(
                                                  getPetitionDetails,
                                                  'status'
                                                ) != false
                                              "
                                              @click="openConformPopUp(forms)"
                                            >
                                              Delete
                                            </li>
                                          </ul>
                                        </div>
                                      </div>
                                    </div>
                                  </template>
                                </vs-collapse-item>
                              </div> 
                              </template>  
                            </template>
                          </vs-collapse>
                          <template v-else>
                            
                            <NoDataFound  ref="NoDataFoundReff" :content="getContent()"  heading="No Documents Found." type="documents" :loading:="false" />
                            </template>
                        </div>

                                            
                        

                      </vs-card>
                    </div>
                  
                    
                  </template>
                  
                
                </div>
                <template v-if="Object.entries(childrenFormsAndLetters).length>0">
                  <template v-for="( child ,ind) in Object.entries(childrenFormsAndLetters)">
                    
                    <template v-if="child && child.length>1">
                      <template v-if="child[1].length>0">
                        <div  class="forms_letters dd forms_letters-v2" @click="docUserType='Dependent';setdocUserType('Dependent')">
                    
                    <template >
                      <div :label="'Forms'" >
                        <vs-card class="no-card FL-height">
                        
                          <div
                            v-if="formsAndLettersList.length > 0"
                            class="forms_accordian forms_accordian-v2 hidedropdown marb10"
                          >
                            <!--download bar 9,10-->
                            <!-- v-if="
                                [3, 4, 9, 10].indexOf(getUserRoleId) > -1 && !checkActiveList
                              "-->
                            
                            <div
                              v-if="
                              ( (([3, 4].indexOf(getUserRoleId) > -1 || checkDocM) && checkActiveList) 
                              ||
                              (!([3, 4].indexOf(getUserRoleId) > -1 || checkDocM) && checkActiveList))
                              "
                            >
                              <vs-list-item class="cards-list-heading">
                                <h2>
                                <template v-if="Object.entries(childrenFormsAndLetters).length>1" >{{'Child '+(ind+1)+' Forms and Letters'}}</template>
                                <template v-else>Child Forms and Letters</template>
                                
                                
                                </h2>
                                <div class="d-flex">
                                    <span
                                    v-if="  
                                    checkProperty(getPetitionDetails, 'status') != false &&
                                    [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13].indexOf(
                                      getUserRoleId
                                    ) > -1 &&
                                    (checkIsActiveUser || IsAdminUser)
                                  "
                                    class="download-all mr-3" 
                                    @click="
                                    depType ='child';depLabel=checkProperty(child[1][0] ,'depLabel');docUserType ='Dependent';
                                    showDocType=true;
                                    fuploder = false;
                                    parentId = '';
                                    entityIdDetails =null;entityId=''
                                    fileuploadPopup = true;
                                    (formerrors.msg = ''),
                                      (uploadMainDocuments = []),
                                      (uploadFinalMainDocuments = []);
                                      resetForms()
                                  "
                                    >
                                      Upload
                                      <img src="@/assets/images/main/upload.svg" />
                                  </span>
                              

                                <span class="download-all" @click=" depType ='child';depLabel=checkProperty(child[1][0] ,'depLabel');docUserType ='Dependent';openDownloadPopup(true)">
                                  Download
                                  <img src="@/assets/images/main/download.svg" />
                                </span>
                              </div>
                              </vs-list-item>
                            </div>
                            <vs-collapse accordion class="forms-letters-accordian">
                              <template v-for="(forms, index) in child[1]">
                              <template >
                              
                                <div  class="no-accordian" @click="changeTab(forms['type'] ,forms ,'Dependent')"
                                  v-if="(([3, 4, 9, 10].indexOf(getUserRoleId) > -1) || ( [3, 4, 9, 10].indexOf(getUserRoleId) <= -1 &&  forms.statusId == 2 || forms.statusId == '2'))"
                                  :key="index"
                                >
                                  <vs-collapse-item
                                
                                    :class="{
                                      closeDropdown: currentRole == 50,
                                      'no-list':
                                        checkProperty(forms, 'reverse_document_versions') &&
                                        forms['reverse_document_versions'].length == 0,
                                    }"
                                    :not-arrow="
                                      !(
                                        checkProperty(forms, 'reverse_document_versions') &&
                                        forms['reverse_document_versions'].length >= 0
                                      )
                                    "
                                  >
                                    <div slot="header" class="ss">
                                      <vs-list-item class="documents_accordian">
                                      </vs-list-item>
                                    </div>

                                    <template
                                      v-if="
                                        checkProperty(forms, 'name') ||
                                        (checkProperty(forms, 'reverse_document_versions') &&
                                          [50, 51].indexOf(getUserRoleId) <= -1)
                                      "
                                    >
                                      <div class="list_title">
                                        <div class="documents_accordian_tile">
                                          <docType :item="forms" />
                                          <span
                                            @click="
                                              $store.commit('selectedForEditDocument', forms);
                                              fetchSignedUrl(forms);
                                            "
                                            ><em class="fl_scanned_docs" :title="forms.name">{{ forms.name }}
                                              <small class="support_letter_text"   v-if="false &&  forms['docUserType'] =='Beneficiary'">(Beneficiary)</small>
                                              <small class="support_letter_text"   v-if="false && forms['docUserType'] =='Dependent'">(Dependent)</small>
                                              <template v-if="forms['type']=='Letter' && forms['entityId'] ">
                                                <small class="support_letter_text" v-if="forms['type']=='Letter' && forms['entityId'] =='support_letter'">(Support Letter)</small>
                                                <small  class="support_letter_text" v-else>(Cover Letter)</small>
                                            </template>
                                              </em>
                                              <small>{{
                                              getformated(forms)
                                            }}</small></span
                                          >
                                        </div>
                                        <div class="d-flex align-center">
                                          <template
                                            v-if="
                                              (checkIsloginUserDoce ||
                                                checkIsloginUserDocm ||
                                                [3, 4].indexOf(getUserRoleId) > -1) &&
                                              checkProperty(getPetitionDetails, 'status') !=
                                                false
                                            "
                                          >
                                            <span
                                              style="margin-right: 30px"
                                              :class="{
                                                status_pending: forms.statusId == 1,
                                                status_active: forms.statusId == 2,
                                                status_rejected: forms.statusId == 3,
                                              }"
                                            >
                                              <template
                                                v-if="checkProperty(forms, 'statusId') == 1"
                                                >Pending</template
                                              >
                                              <template
                                                v-if="checkProperty(forms, 'statusId') == 2"
                                                >Approved</template
                                              >
                                              <template
                                                v-if="checkProperty(forms, 'statusId') == 3"
                                                >Rejected</template
                                              >
                                            </span>
                                          </template>
                                          <div class="vertical-menu">
                                            <span class="menu-icon">
                                              <i class="material-icons">more_vert</i>
                                            </span>
                                            <ul>
                                              <li
                                                v-if="
                                                  [50, 51].indexOf(currentRole) < 0 &&
                                                  !checkSubmitToUscisCompleted &&
                                                  checkProperty(
                                                    getPetitionDetails,
                                                    'status'
                                                  ) != false
                                                "
                                                @click="selDoc(forms.mainParentId, forms)"
                                              >
                                                Upload
                                              </li>
                                              <li @click="fetchSignedUrl(forms, false, true)">
                                                View
                                              </li>
                                              <li
                                                v-if="
                                                
                                                checkProperty(forms, 'statusId') == 2 &&
                                                  [50, 51].indexOf(currentRole) < 0 &&
                                                  !isSubmitUscisCompleted &&
                                                  checkProperty(
                                                    getPetitionDetails,
                                                    'status'
                                                  ) != false
                                                "
                                                @click="editDocument(forms)"
                                              >
                                                Edit
                                              </li>
                                              <!-- <li @click="fetchSignedUrl(forms, true)">
                                                Download
                                              </li> -->
                                              <li @click="download_or_view(forms)">
                                                Download
                                              </li>
                                              <template v-if="isEnableApproveRejMenu">
                                              <li
                                                v-if="
                                                  forms.statusId == 1 &&
                                                  (checkDocM ||
                                                    [3, 4].indexOf(getUserRoleId) > -1)
                                                "
                                                @click="
                                                  openApproveOrRejectDocs(
                                                    'APPROVED_BY_DOC_MANAGER'
                                                  )
                                                "
                                              >
                                                Approve
                                              </li>
                                              <li
                                                v-if="
                                                  forms.statusId == 1 &&
                                                  (checkDocM ||
                                                    [3, 4].indexOf(getUserRoleId) > -1)
                                                "
                                                @click="
                                                  openApproveOrRejectDocs(
                                                    'REJECT_BY_DOC_MANAGER'
                                                  )
                                                "
                                              >
                                                Reject
                                              </li>
                                            </template>
                                              <li
                                                v-if="
                                                   [50,51].indexOf(getUserRoleId)<=-1 &&
                                                  checkProperty(
                                                    getPetitionDetails,
                                                    'status'
                                                  ) != false
                                                "
                                                @click="openConformPopUp(forms)"
                                              >
                                                Delete
                                              </li>
                                            </ul>
                                          </div>
                                        </div>
                                      </div>
                                    </template>
                                  </vs-collapse-item>
                                </div> 
                                </template>  
                              </template>
                            </vs-collapse>
                          </div>
                        

                        </vs-card>
                      </div>
                    
                      
                    </template>
                    
                  
                  </div>
                      </template>

                    
                    </template>

                  </template>
                

                </template>
              </template>

               <!----PreviousVersions Section---->

              <div
                v-if="previousVersionList.length > 0 && checkRevisionDocuments('')"
                class="forms_accordian forms_accordian-v2" :class="{'show':showPreviousVersions ,'hide':!showPreviousVersions}"
              >

              <h2 class="pervious-versions-title 1" :class="{'show':showPreviousVersions ,'hide':!showPreviousVersions}" @click="togglePreviousVersions()"
                  
              >
              <span> Previous Versions</span>
              <img src="@/assets/images/icons/black_arrow.svg">
                <!--{{formLetterType+'s'}}-->
              </h2>
              <vs-collapse accordion class="forms-letters-accordian prev-no-accordian" >
                  <template v-for="(forms, index) in previousVersionList">
                    
                    <template class="no-accordian"
                      v-if="
                      
                        checkProperty(
                          forms,
                          'reverse_document_versions',
                          'length'
                        ) > 0
                      "
                    >
                      <vs-collapse-item
                        :class="{
                          closeDropdown: currentRole == 50,
                          'no-list':
                            checkProperty(forms, 'reverse_document_versions') &&
                            forms['reverse_document_versions'].length <= 1,
                        }"
                        :not-arrow="
                          !(
                            checkProperty(forms, 'reverse_document_versions') &&
                            forms['reverse_document_versions'].length >= 0
                          )
                        "
                        :key="index"
                      >
                        <div slot="header" class="ss">
                          <vs-list-item class="documents_accordian">
                          </vs-list-item>
                        </div>

                        <template
                          v-if="checkProperty(forms, 'reverse_document_versions')"
                        >
                          <div class="list_title">
                            <div class="documents_accordian_tile">
                              <docType
                                :item="forms['reverse_document_versions'][0]"
                              />
                              <span
                                @click="
                                  fetchSignedUrl(
                                    forms['reverse_document_versions'][0]
                                  )
                                "
                              >
                              <em class="fl_scanned_docs" :title='checkProperty(forms["reverse_document_versions"][0],"name")'>{{
                                  checkProperty(
                                    forms["reverse_document_versions"][0],
                                    "name"
                                  )
                                }}<small class="support_letter_text" 
                                      v-if=" forms['docUserType'] =='Beneficiary'">(Beneficiary)</small>
                                
                                  <small class="support_letter_text" 
                                      v-if=" forms['docUserType'] =='Dependent'">(Dependent)</small>
                                </em>
                                <small>{{
                                  getformated(
                                    forms["reverse_document_versions"][0]
                                  )
                                }}</small></span
                              >
                            </div>
                            <div class="d-flex align-center">
                            
                              <div class="vertical-menu">
                                <span class="menu-icon">
                                  <i class="material-icons">more_vert</i>
                                </span>
                                <ul>
                                  <li
                                    v-if="
                                      [50, 51].indexOf(currentRole) < 0 &&
                                      !checkSubmitToUscisCompleted &&
                                      checkProperty(
                                        getPetitionDetails,
                                        'status'
                                      ) != false
                                    "
                                    @click="
                                      selectedDocument = forms;
                                      restoreDocument(
                                        forms.mainParentId,
                                        forms['reverse_document_versions'][0]
                                      );
                                    "
                                  >
                                    Restore
                                  </li>
                                  <li
                                    @click="
                                      fetchSignedUrl(
                                        forms['reverse_document_versions'][0],
                                        false,
                                        true
                                      )
                                    "
                                  >
                                    View
                                  </li>
                              
                                </ul>
                              </div>
                            </div>
                          </div>
 
                          <template
                            v-for="(reveforms, inde) in forms[
                              'reverse_document_versions'
                            ]"
                          >
                            <template v-if="inde > 0">
                              <vs-list-item
                                class="documents_accordian"
                                v-if="currentRole != 50"
                                :key="inde"
                              >
                                <div class="documents_accordian_tile">
                                  <docType :item="reveforms" />
                                  <span @click="fetchSignedUrl(reveforms)"
                                    >
                                    <em class="fl_scanned_docs" :title="reveforms.name">{{ reveforms.name }}</em>
                                    <!-- {{ reveforms.name }}<br /> -->
                                    <small>{{
                                      getformated(reveforms)
                                    }}</small></span
                                  >
                                </div>
                                <template
                                  v-if="
                                    (checkIsloginUserDoce ||
                                      checkIsloginUserDocm) &&
                                    checkProperty(getPetitionDetails, 'status') !=
                                      false
                                  "
                                >
                                
                                </template>
                                <div class="vertical-menu">
                                  <span class="menu-icon">
                                    <i class="material-icons">more_vert</i>
                                  </span>
                                  <ul>
                                    <li
                                      v-if="
                                        [50, 51].indexOf(currentRole) < 0 &&
                                        !checkSubmitToUscisCompleted &&
                                        checkProperty(
                                          getPetitionDetails,
                                          'status'
                                        ) != false
                                      "
                                      @click="
                                        selectedDocument = forms;
                                        restoreDocument(
                                          forms.mainParentId,
                                          reveforms
                                        );
                                      "
                                    >
                                      Restore
                                    </li>
                                    <li
                                      @click="
                                        fetchSignedUrl(reveforms, false, true)
                                      "
                                    >
                                      View
                                    </li>
                                    <!--<li @click="fetchSignedUrl(forms,true)">Download</li>-->
                                    <li
                                      v-if="
                                         [50,51].indexOf(getUserRoleId)<=-1 &&
                                        checkProperty(
                                          getPetitionDetails,
                                          'status'
                                        ) != false
                                      "
                                      @click="openConformPopUp(reveforms)"
                                    >
                                      Delete
                                    </li>
                                  </ul>
                                </div>

                                <!-- <span class="view_doc" @click="fetchSignedUrl(reveforms)">View</span>
                                                        <span class="view_doc"   v-if="reveforms['createdBy'] ==currentUser "  @click="openConformPopUp(reveforms)">Delete</span> -->
                              </vs-list-item>
                            </template>
                          </template>
                        </template>
                      </vs-collapse-item>
                    </template>
                  </template>
                </vs-collapse>
              </div>
            
           </template>
           <template v-else-if=" checkProperty(petition, 'subTypeDetails', 'id') == 15 && formsAndLettersList.length >0">
           
            <div class="forms_letters dd forms_letters-v2" @click="docUserType='Beneficiary'">
              
            
              <div   
                label="Audit Response"
                
              >
                <vs-card class="no-card FL-height">
                  <template
                    v-if="
                      ([3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13].indexOf(getUserRoleId) >
                        -1 &&
                        !checkrequestSigninActivityCompleted) ||
                      ([3, 4, 5, 6, 7, 8, 9, 10, 11, 12].indexOf(getUserRoleId) > -1 &&
                        !checkrequestSigninActivityCompleted)
                    "
                  >
                    <div class="pd_upload_actions">
                      <template v-if="(checkProperty(petition,'intStatusDetails','id')==1 ) && (checkActionButton ||  checkUserAccessBtn || IsAdminUser) && checkNoNotifyUserIds">
                     
                      
                      <template
                        v-if="
                          [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13].indexOf(getUserRoleId) >
                            -1 &&
                          !checkrequestSigninActivityCompleted &&
                          checkProperty(getPetitionDetails, 'status') != false
                        "
                      >
                        <div class="generate_sec ml-auto">


                          <span
                            class="generate-btn"
                            @click="
                              openGenerateFormsLattersPopup();
                              copyingData();
                            "
                            v-if="
                              [
                                'DOL_SUPERVISORY_AUDIT',
                                'SUBMIT_TO_DOL',
                                'DOL_APPROVED',
                                'DOL_RECEIVED_RFE',
                                'DOL_DENIED',
                                'DOL_WITHDRAWN',
                              ].indexOf(petition.curWorkflowActivity) <= -1
                            "
                          >
                            <figure
                              v-if="generatingFiles || loadingFormLatters"
                              class="loader loader2"
                            >
                              <img src="@/assets/images/main/loader.gif" />
                            </figure>
                            Generate
                          </span>
                        </div>
                      </template>
                    </template>
                    </div>
                  </template>

                  <div
                    v-if="formsAndLettersList.length > 0"
                    class="forms_accordian forms_accordian-v2 hidedropdown marb10"
                  >
                    <vs-list-item class="cards-list-heading">
                      <h2>
                        <template
                          v-if="
                            checkProperty(petition, 'typeDetails', 'id') == 3 &&
                            checkProperty(petition, 'subTypeDetails', 'id') == 15
                          "
                        >
                          Audit Response
                        </template>
                        <template v-else> 
                          Beneficiary Forms and Letters
                        </template>
                      </h2>
                      
                        <div class="d-flex">
                          <template v-if="(checkProperty(petition,'intStatusDetails','id')==1 ) && (checkActionButton ||  checkUserAccessBtn || IsAdminUser) && checkNoNotifyUserIds">
                    
                                <span
                                v-if="
                          [
                            'DOL_SUPERVISORY_AUDIT',
                            'SUBMIT_TO_DOL',
                            'DOL_APPROVED',
                            'DOL_RECEIVED_RFE',
                            'DOL_DENIED',
                            'DOL_WITHDRAWN',
                          ].indexOf(petition.curWorkflowActivity) <= -1 &&
                          checkProperty(getPetitionDetails, 'status') != false &&
                          [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13].indexOf(getUserRoleId) >
                            -1 &&
                          !checkrequestSigninActivityCompleted
                        "
                                 class="download-all mr-3" 
                                 @click="
                                 showDocType=true;
                          fuploder = false;
                          parentId = '';
                          entityIdDetails =null;entityId='';
                          fileuploadPopup = true;

                          (formerrors.msg = ''),
                            (uploadMainDocuments = []),
                            (uploadFinalMainDocuments = []);
                            resetForms()
                        "
                                 >
                                  Upload
                                  <img src="@/assets/images/main/upload.svg" />
                              </span>
                        
                          </template>


                      <span class="download-all" @click="openDownloadPopup(true)">
                        Download
                        <img src="@/assets/images/main/download.svg" />
                      </span>
                    </div>
                    </vs-list-item>

                    <vs-collapse accordion class="forms-letters-accordian">
                      <template v-for="(forms, index) in formsAndLettersList">
                        <!-- v-if="(currentRole ==12 && forms.selectedForSigning ) || currentRole !=12 "-->
                        <vs-collapse-item
                       
                          :class="{
                            closeDropdown: currentRole == 50,
                            'no-list':
                              checkProperty(forms, 'reverse_document_versions') &&
                              forms['reverse_document_versions'].length == 0,
                          }"
                          :not-arrow="
                            !(
                              checkProperty(forms, 'reverse_document_versions') &&
                              forms['reverse_document_versions'].length >= 0
                            )
                          "
                          :key="index"
                        >
                          <div slot="header" class="ss">
                            <vs-list-item class="documents_accordian"> </vs-list-item>
                          </div>

                          <template
                            v-if="
                              checkProperty(forms, 'name') ||
                              (checkProperty(forms, 'reverse_document_versions') &&
                                [50, 51].indexOf(getUserRoleId) <= -1)
                            "
                          >
                            <div class="list_title" @click="changeTab('Audit Response' ,forms ,'Beneficiary')">
                              <div class="documents_accordian_tile">
                                <docType :item="forms" />
                                <span @click="fetchSignedUrl(forms)"
                                  >
                                  <em class="fl_scanned_docs" :title="forms.name">{{ forms.name }}<small class="support_letter_text" 
                                              v-if="forms['type']=='Audit Response' && forms['docUserType'] =='Beneficiary'">(Beneficiary)</small><small class="support_letter_text" 
                                              v-if="forms['type']=='Audit Response' && forms['docUserType'] =='Dependent'">(Dependent)</small>
                                  </em>
                                  <!-- {{ forms.name }}<br /> -->
                                  <small>{{
                                    getformated(forms)
                                  }}</small></span
                                >
                              </div>
                              <div class="d-flex align-center">
                                <template
                                  v-if="
                                    (checkIsloginUserDoce || checkIsloginUserDocm) &&
                                    checkProperty(getPetitionDetails, 'status') != false
                                  "
                                >
                                  <span
                                    style="margin-right: 30px"
                                    :class="{
                                      status_pending: forms.statusId == 1,
                                      status_active: forms.statusId == 2,
                                      status_rejected: forms.statusId == 3,
                                    }"
                                  >
                                    <template
                                      v-if="checkProperty(forms, 'statusId') == 1"
                                      >Pending</template
                                    >
                                    <template
                                      v-if="checkProperty(forms, 'statusId') == 2"
                                      >Approved</template
                                    >
                                    <template
                                      v-if="checkProperty(forms, 'statusId') == 3"
                                      >Rejected</template
                                    >
                                  </span>
                                </template>
                                <div class="vertical-menu">
                                  <span class="menu-icon">
                                    <i class="material-icons">more_vert</i>
                                  </span>
                                  <ul>
                                    <li
                                      v-if="
                                        [
                                          'DOL_SUPERVISORY_AUDIT',
                                          'SUBMIT_TO_DOL',
                                          'DOL_APPROVED',
                                          'DOL_RECEIVED_RFE',
                                          'DOL_DENIED',
                                          'DOL_WITHDRAWN',
                                        ].indexOf(petition.curWorkflowActivity) <= -1 &&
                                        [50, 51].indexOf(currentRole) < 0 &&
                                        !checkrequestSigninActivityCompleted &&
                                        checkProperty(getPetitionDetails, 'status') !=
                                          false
                                      "
                                      @click="selDoc(forms.mainParentId, forms)"
                                    >
                                      Upload
                                    </li>

                                    <li @click="fetchSignedUrl(forms, false, true)">
                                      View
                                    </li>
                                    <li
                                      v-if="
                                      checkProperty(forms, 'statusId') == 2 &&
                                        [
                                          'DOL_SUPERVISORY_AUDIT',
                                          'SUBMIT_TO_DOL',
                                          'DOL_APPROVED',
                                          'DOL_RECEIVED_RFE',
                                          'DOL_DENIED',
                                          'DOL_WITHDRAWN',
                                        ].indexOf(petition.curWorkflowActivity) <= -1 &&
                                        [50, 51].indexOf(currentRole) < 0 &&
                                        !isSubmitUscisCompleted &&
                                        checkProperty(getPetitionDetails, 'status') !=
                                          false
                                          "
                                          @click="editDocument(forms)"
                                    >
                                      Edit
                                    </li>
                                    <li  @click="downloads3file(forms)">
                                      Download
                                    </li>
                                    <li
                                      v-if="
                                        [
                                          'DOL_SUPERVISORY_AUDIT',
                                          'SUBMIT_TO_DOL',
                                          'DOL_APPROVED',
                                          'DOL_RECEIVED_RFE',
                                          'DOL_DENIED',
                                          'DOL_WITHDRAWN',
                                        ].indexOf(petition.curWorkflowActivity) <= -1 &&
                                        forms['createdBy'] == currentUser &&
                                        checkProperty(getPetitionDetails, 'status') !=
                                          false
                                      "
                                      @click="openConformPopUp(forms)"
                                    >
                                      Delete
                                    </li>
                                  </ul>
                                </div>
                              </div>
                            </div>
                          </template>
                        </vs-collapse-item>
                      </template>
                    </vs-collapse>
                  </div>

                  <!----PreviousVersions Section---->

                  <div
                    v-if="previousVersionList.length > 0 && checkRevisionDocuments('')"
                    class="forms_accordian forms_accordian-v2" :class="{'show':showPreviousVersions ,'hide':!showPreviousVersions}"
                  >
                  <h2 class="pervious-versions-title 2" :class="{'show':showPreviousVersions ,'hide':!showPreviousVersions}"  @click="togglePreviousVersions()"
                        
                  >
                   <span> Previous Versions</span>
                   <img src="@/assets/images/icons/black_arrow.svg">
                     <!--{{formLetterType+'s'}}-->
                  </h2>

                    <vs-collapse accordion class="forms-letters-accordian prev-no-accordian" v-if="showPreviousVersions" >
                      <template v-for="(forms, index) in previousVersionList">
                        <template
                          v-if="
                            checkProperty(
                              forms,
                              'reverse_document_versions',
                              'length'
                            ) > 0
                          "
                        >
                          <vs-collapse-item
                            :class="{
                              closeDropdown: currentRole == 50,
                              'no-list':
                                checkProperty(forms, 'reverse_document_versions') &&
                                forms['reverse_document_versions'].length <= 1,
                            }"
                            :not-arrow="
                              !(
                                checkProperty(forms, 'reverse_document_versions') &&
                                forms['reverse_document_versions'].length >= 0
                              )
                            "
                            :key="index"
                          >
                            <div slot="header" class="ss">
                              <vs-list-item class="documents_accordian"> </vs-list-item>
                            </div>

                            <template
                              v-if="checkProperty(forms, 'reverse_document_versions')"
                            >
                              <div class="list_title">
                                <div class="documents_accordian_tile">
                                  <docType
                                    :item="forms['reverse_document_versions'][0]"
                                  />
                                  <span
                                    @click="
                                      fetchSignedUrl(
                                        forms['reverse_document_versions'][0]
                                      )
                                    "
                                  >
                                  <em class="fl_scanned_docs" :title='checkProperty(forms["reverse_document_versions"][0],"name")'>
                                    {{
                                      checkProperty(
                                        forms["reverse_document_versions"][0],
                                        "name"
                                      )
                                    }}<small class="support_letter_text" 
                                              v-if=" forms['docUserType'] =='Beneficiary'">(Beneficiary)</small><small class="support_letter_text" 
                                              v-if=" forms['docUserType'] =='Dependent'">(Dependent)</small>
                                  </em>
                                    <!-- {{
                                      checkProperty(
                                        forms["reverse_document_versions"][0],
                                        "name"
                                      )
                                    }}<br /> -->
                                    <small>{{
                                      getformated(forms["reverse_document_versions"][0])
                                    }}</small></span
                                  >
                                </div>
                                <div class="d-flex align-center">
                                  <!---
                                                      <template v-if="(checkIsloginUserDoce || checkIsloginUserDocm ) && checkProperty(getPetitionDetails ,'status' )!=false">
                                                          <span  style="margin-right:30px"  :class="{'status_pending':forms.statusId==1,'status_active':forms.statusId==2,'status_rejected':forms.statusId==3}" >
                                                              <template v-if="checkProperty(forms ,'statusId') ==1">Pending</template>
                                                              <template v-if="checkProperty(forms ,'statusId') ==2">Approved</template>
                                                              <template v-if="checkProperty(forms ,'statusId') ==3">Rejected</template>
                                                          </span>
                                                      </template>
                                                      -->
                                  <div class="vertical-menu">
                                    <span class="menu-icon">
                                      <i class="material-icons">more_vert</i>
                                    </span>
                                    <ul>
                                      <li
                                        v-if="
                                          [50, 51].indexOf(currentRole) < 0 &&
                                          !checkrequestSigninActivityCompleted &&
                                          checkProperty(getPetitionDetails, 'status') !=
                                            false
                                        "
                                        @click="
                                          selectedDocument = forms;
                                          restoreDocument(
                                            forms.mainParentId,
                                            forms['reverse_document_versions'][0]
                                          );
                                        "
                                      >
                                        Restore
                                      </li>
                                      <li
                                        @click="
                                          fetchSignedUrl(
                                            forms['reverse_document_versions'][0],
                                            false,
                                            true
                                          )
                                        "
                                      >
                                        View
                                      </li>
                                      <!----
                                                              <li v-if="[50,51].indexOf(currentRole) < 0 && !checkrequestSigninActivityCompleted && checkProperty(getPetitionDetails ,'status' )!=false" @click="editDocument(forms)">Edit </li>
                                                              <li @click="fetchSignedUrl(forms,true)">Download</li> 
                                                              <li v-if="forms['createdBy'] ==currentUser && checkProperty(getPetitionDetails ,'status' )!=false "  @click="openConformPopUp(forms)">Delete</li>
                                                              -->
                                    </ul>
                                  </div>
                                </div>
                              </div>

                              <template
                                v-for="(reveforms, inde) in forms[
                                  'reverse_document_versions'
                                ]"
                              >
                                <template v-if="inde > 0">
                                  <vs-list-item
                                    class="documents_accordian"
                                    v-if="currentRole != 50"
                                    :key="inde"
                                  >
                                    <div class="documents_accordian_tile">
                                      <docType :item="reveforms" />
                                      <span @click="fetchSignedUrl(reveforms)"
                                        >
                                        <em class="fl_scanned_docs" :title="reveforms.name">{{ reveforms.name }}</em>
                                        <!-- {{ reveforms.name }}<br /> -->
                                        <small>{{
                                          getformated(reveforms)
                                        }}</small></span
                                      >
                                    </div>
                                    <template
                                      v-if="
                                        (checkIsloginUserDoce ||
                                          checkIsloginUserDocm) &&
                                        checkProperty(getPetitionDetails, 'status') !=
                                          false
                                      "
                                    >
                                      <!-- <span  style="margin-right:30px"  :class="{'status_pending':reveforms.statusId==1,'status_active':reveforms.statusId==2,'status_rejected':reveforms.statusId==3}" >
                                                          <template v-if="checkProperty(reveforms ,'statusId') ==1">Pending</template>
                                                          <template v-if="checkProperty(reveforms ,'statusId') ==2">Approved</template>
                                                          <template v-if="checkProperty(reveforms ,'statusId') ==3">Rejected</template>
                                                      </span> -->
                                    </template>
                                    <div class="vertical-menu">
                                      <span class="menu-icon">
                                        <i class="material-icons">more_vert</i>
                                      </span>
                                      <ul>
                                        <li
                                          v-if="
                                            [50, 51].indexOf(currentRole) < 0 &&
                                            !checkrequestSigninActivityCompleted &&
                                            checkProperty(
                                              getPetitionDetails,
                                              'status'
                                            ) != false
                                          "
                                          @click="
                                            selectedDocument = forms;
                                            restoreDocument(
                                              forms.mainParentId,
                                              reveforms
                                            );
                                          "
                                        >
                                          Restore
                                        </li>
                                        <li
                                          @click="
                                            fetchSignedUrl(reveforms, false, true)
                                          "
                                        >
                                          View
                                        </li>
                                        <!--<li @click="fetchSignedUrl(forms,true)">Download</li>-->
                                        <li
                                          v-if="
                                            reveforms['createdBy'] == currentUser &&
                                            checkProperty(
                                              getPetitionDetails,
                                              'status'
                                            ) != false
                                          "
                                          @click="openConformPopUp(reveforms)"
                                        >
                                          Delete
                                        </li>
                                      </ul>
                                    </div>

                                    <!-- <span class="view_doc" @click="fetchSignedUrl(reveforms)">View</span>
                                                      <span class="view_doc"   v-if="reveforms['createdBy'] ==currentUser "  @click="openConformPopUp(reveforms)">Delete</span> -->
                                  </vs-list-item>
                                </template>
                              </template>
                            </template>
                          </vs-collapse-item>
                        </template>
                      </template>
                    </vs-collapse>
                  </div>
                  <!--
                              <paginate  v-if="formsAndLettersList.length>0"  v-model="page" :page-count="totalpages" :page-range="3" :margin-pages="2" :click-handler="pageNate"
                              prev-class="vs-pagination--buttons btn-prev-pagination vs-pagination--button-prev"
                              next-class="vs-pagination--buttons btn-next-pagination vs-pagination--button-next" :prev-text="'<i></i>'"
                              :next-text="'<i></i>'" :container-class="'pagination vs-pagination--nav'" :page-class="'page-item'"></paginate>
                              -->
                  
                </vs-card>
              </div>
            
          </div>

           </template>
           <template v-if="(formsAndLettersList.length >0 && (  checkProperty(petition, 'subTypeDetails', 'id') != 15 && !checkFormsAndLetters('spouse') && !checkFormsAndLetters('child') && !checkFormsAndLetters('beneficiary') ))">
          
           <NoDataFound
                          ref="NoDataFoundReff"
                          :content="getContent()"
                          heading="No Documents Found."
                          type="documents"
                          :loading:="false"
                        />
            </template>

          </vs-col>
        </vs-row>
      </div>
    </div>

    <vs-popup
      class="Change_petition_wrap"
      title="Download Forms"
      :active.sync="downloadSamplespopup"
    >
      <div class="Change_petition">
        <div class="vx-col w-full marb10">
          <ul class="downloads_list">
            <li v-for="(typ, index) in types" :key="index">
              <p>{{ typ.name }}</p>
              <span>Download</span>
            </li>
          </ul>
        </div>
      </div>
      <div class="actions_footer">
        <button @click="downloadSamplespopup = false" class="btn cancel">Cancel</button>
      </div>
    </vs-popup>
    <!----formLetterType:'Letter', //'Form', --->
    <vs-popup
      class="Change_petition_wrap"
      :title="
        checkProperty(petition, 'subTypeDetails', 'id') == 15
          ? 'Upload Audit Response'
          : 'Upload Forms and Letters'
      "
      :active.sync="fileuploadPopup"
    >
      <div class="Change_petition upload_letter_others" >
      
        <div class="vx-col w-full">
         
          <!----- // this.formLetterType = "Form"; //this.formLetterType = "Letter";-->
          <div class="vx-row form-container pad0"   v-if="showDocType">
            <div class="custom-radio_wrap wf_radio">
              <label class="form_label pb-1 pl-4">Document Type<em >*</em></label>
              
              <ul class="custom-radio mb-1" >
               
                 <li> 
                  <vs-radio @input="formerrors.msg = ''"  name="documentType"  vs-value="Form" v-model="formLetterType" class="w-full" >Forms</vs-radio>
                 </li>
                  <li>
                     <vs-radio @input="formerrors.msg = ''"  name="documentType"   vs-value="Letter"  v-model="formLetterType" class="w-full" >Letters</vs-radio>
                   </li>
             </ul>
            </div>
            <span  class="text-danger text-sm"  v-show="showTypeIdError">Document Type is required</span>
          </div>
          <div class="vx-row form-container pad0"  @click="showTypeIdError=false" v-if="checkProperty(petition, 'subTypeDetails', 'id') == 15 && checkProperty(petitionDetails,'beneficiaryInfo','maritalStatus' ) !=1 &&   checkProperty(petitionDetails['dependentsInfo'] ,'spouse', 'h4Required')==true">
            <div class="custom-radio_wrap wf_radio">
              <label class="form_label pb-1 pl-4">Upload For<em >*</em></label>
              
              <ul class="custom-radio mb-1" >
               
                 <li> 
                  <vs-radio  name="docUserType" @change="changedBeneficiarycheck" vs-value="Beneficiary" v-model="docUserType" class="w-full" >Beneficiary</vs-radio>
                 </li>
                  <li>
                     <vs-radio  name="docUserType" @change="changedBeneficiarycheck"  vs-value="Dependent"  v-model="docUserType" class="w-full" >Dependent</vs-radio>
                   </li>
             </ul>
            </div>
            <span  class="text-danger text-sm"  v-show="showTypeIdError">Document Type is required</span>
          </div>
          <div class="vx-row form-container pad0 mt-3"  v-if="formLetterType=='Letter'">
              <div class="custom-radio_wrap wf_radio" @click="showentityIdError=''">
              <label class="form_label pb-1 pl-4">Letter Type<em >*</em></label>
              <!----entityIds:[{"id":"'cover_letter'" ,"name":"Cover Letter"},{"id":'support_letter' ,"name":'Support Letter'}],
   -->
              <ul class="custom-radio mb-3">
                
                 <li> 
                  <vs-radio   name="entity_id" @input="changedBeneficiarycheck" vs-value="cover_letter" v-model="entityId" class="w-full" >Cover Letter</vs-radio>
                 </li>
                  <li>
                     <vs-radio  name="entity_id" @input="changedBeneficiarycheck" vs-value="support_letter"  v-model="entityId" class="w-full" >Support Letter</vs-radio>
                   </li>
             </ul>
             <span  class="text-danger text-sm ml-3"  v-show="showentityIdError"  >Letter Type is required</span>
            </div>
          </div>

          <div class="vx-row form-container pad0"  v-if="false &&formLetterType=='Letter'" @click="showTypeIdError=false">
            <div class="custom-radio_wrap wf_radio">
              <label class="form_label pb-3 pl-4">Letter Type<em >*</em></label>
              <!----- entityIds:[{"id":"'cover_letter'" ,"name":"Cover Letter"},{"id":'support_letter' ,"name":'Support Letter'}],-->
              <ul class="custom-radio mb-1">
                 <li> 
                  <vs-radio  name="docUserType" @change="changedBeneficiarycheck" vs-value="cover_letter" v-model="entityId" class="w-full" >Cover Letter</vs-radio>
                 </li>
                  <li>
                     <vs-radio  name="docUserType" @change="changedBeneficiarycheck"  vs-value="support_letter"  v-model="entityId" class="w-full" >Support Letter</vs-radio>
                   </li>
             </ul>
            </div>
            <span  class="text-danger text-sm"  v-show="showentityIdError">Letter Type is required</span>
          </div>
          <div class="vx-row">
            <div class="vx-col w-full">
              <vx-input-group class="form-input-group select-upload-group">
                <div class="uploadsec_wrap">
                  <div class="w-full">
                    <div @click="uploadMainDocuments = []">
                      <file-upload
                        v-model="uploadMainDocuments"
                        :accept="acceptedFiles"
                        class="file-upload-input mb-0"
                        style="height: 50px; padding: 0px"
                        :name="'pdocuments'"
                        :multiple="true"
                        :hideSelected="true"
                        v-validate="'required'"
                        label="Forms and Letters"
                        data-vv-as="Forms and Letters"
                        @input="uploadToS3MainDocuments(uploadMainDocuments)"
                      >
                        <img
                          class="file-icon"
                          src="@/assets/images/main/file-upload.svg"
                        />
                        Upload
                      </file-upload>
                      <span class="file-type mb-0" v-if="formLetterType == 'Form'"
                        >(File Type: PDF, Max file size: 1MB)</span
                      >
                      <span class="file-type mb-0" v-else-if="formLetterType == 'Letter'"
                        >(File Type: DOC, Max file size: 1MB)</span
                      >
                      <span class="file-type mb-0" v-else
                        >(File Type: DOC Max file size: 1MB)</span
                      >
                      <span
                        class="text-danger text-sm"
                        v-show="errors.has('pdocuments')"
                        >{{ errors.first("documents" + index) }}</span
                      >
                    </div>

                    <VuePerfectScrollbar class="scrollbardoc">
                      <div
                        class="uploded-files_wrap mt-3"
                        v-if="
                          uploadFinalMainDocuments && uploadFinalMainDocuments.length > 0
                        "
                      >
                        <div
                          class="w-full"
                          v-for="(fil, fileindex) in uploadFinalMainDocuments"
                          :key="fileindex"
                        >
                          <div class="uploded-files">
                            <vx-input-group class="form-input-group">
                              <vs-input
                                v-on:keyup="chengefileName(index, fileindex)"
                                v-validate="'required'"
                                class="w-full"
                                :name="'fName' + fileindex"
                                v-model="fil['name']"
                                data-vv-as="File Name"
                              />
                              <span
                                class="text-danger text-sm"
                                v-show="errors.has('fName' + fileindex)"
                                >{{ errors.first("fName" + fileindex) }}</span
                              >

                              <div
                                class="delete"
                                style="z-index: 999"
                                @click="remove(fil, uploadFinalMainDocuments, fileindex)"
                              >
                                <img src="@/assets/images/main/cross.svg" />
                              </div>
                            </vx-input-group>
                          </div>
                        </div>
                      </div>
                    </VuePerfectScrollbar>
                  </div>
                </div>
              </vx-input-group>
            </div>
          </div>
          
        </div>
      </div>
      <!-----v-if="fuploder"-->
      <div
        class="text-danger text-sm formerrors"
        v-show="formerrors.msg"
        @click="formerrors.msg = ''"
      >
        <vs-alert
          color="warning"
          class="warning-alert reg-warning-alert no-border-radius"
          icon-pack="IntakePortal"
          icon="IP-information-button"
          active="true"
          >{{ formerrors.msg }}</vs-alert
        >
      </div>
      <div class="popup-footer relative">
        <button
          @click="
            fileuploadPopup = false;
            cancelpopups();
            fuploder = false;
          "
          class="btn cancel"
        >
          Cancel
        </button>
        <button
          class="btn save"
          :disabled="disable_uploadBtn || uploadFinalMainDocuments.length <= 0"
          @click="updateFormsAndDocuments()"
        >
          <figure v-if="fuploder" class="loader">
            <img src="@/assets/images/main/loader.gif" />
          </figure>
          Upload
        </button>
      </div>
    </vs-popup>

    
    <vs-popup
      class="holamundo main-popup"
      title="Generate Forms and Letters"
      v-if="generatePopup"
      :active.sync="generatePopup"
    >
      <form @submit.prevent>
        <div class="form-container" @click="formerrors.msg = ''">
          <div class="vx-row">
            <div class="vx-col w-full" @click="value = []">
              <file-upload
                v-model="value"
                class="file-upload-input"
                :accept="acceptedFiles"
                :name="'Documents'"
                :multiple="false"
                @input="uploadNewFormsandLatters(value)"
              >
                <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                Upload
              </file-upload>
              <ul class="uploaded-list">
                <template v-for="(item, index) in newFormsAndLetters">
                  <vs-chip
                    @click="remove(item, newFormsAndLetters, index)"
                    :key="index"
                    closable
                    v-if="
                      item.status !== false &&
                      item.name !== null &&
                      item.url !== null &&
                      item.url !== ''
                    "
                  >
                    {{ item.name }}
                  </vs-chip>
                </template>
              </ul>
            </div>
          </div>

          <div
            class="text-danger text-sm formerrors"
            v-show="formerrors.msg"
            @click="formerrors.msg = ''"
          >
            <vs-alert
              color="warning"
              class="warning-alert reg-warning-alert no-border-radius"
              icon-pack="IntakePortal"
              icon="IP-information-button"
              active="true"
              >{{ formerrors.msg }}</vs-alert
            >
          </div>
        </div>
        <div class="popup-footer relative">
          <vs-button
            color="dark"
            @click="
              generatePopup = false;
              newFormsAndLetters = [];
            "
            class="btn cancel"
            type="filled"
            >Cancel</vs-button
          >
          <figure v-if="generatingFiles" class="loader loader2">
            <img src="@/assets/images/main/loader.gif" />
          </figure>
          <vs-button
            color="success"
            class="btn save"
            @click="openGenerateFormsLattersPopup()"
            type="filled"
            >Generate
          </vs-button>
        </div>
      </form>
    </vs-popup>

    <vs-popup
      class="holamundo main-popup"
      :title="'Delete ' + formLetterType"
      :active.sync="approveConformpopUp"
    >
      <div class="form-container">
        <div class="vx-row">
          <div class="vx-col w-full">
            <p>Do you want to Delete?</p>
          </div>
        </div>
      </div>
      <div
        class="text-danger text-sm formerrors"
        v-show="formerrors.msg"
        @click="formerrors.msg = ''"
      >
        <vs-alert
          color="warning"
          class="warning-alert reg-warning-alert no-border-radius"
          icon-pack="IntakePortal"
          icon="IP-information-button"
          active="true"
          >{{ formerrors.msg }}</vs-alert
        >
      </div>
      <div class="popup-footer relative">
        <vs-button
          color="dark"
          class="btn cancel"
          type="filled"
          @click="approveConformpopUp = false"
          >Cancel</vs-button
        >
        <vs-button
          color="success"
          class="btn save"
          type="filled"
          @click="deleteDocument()"
          >Delete</vs-button
        >
      </div>
    </vs-popup>

    <modal
      name="download_files_model"
      classes="v-modal-sec"
      :min-width="200"
      :min-height="200"
      :scrollable="true"
      :reset="true"
      width="600px"
      height="auto"
    >
      <!-- formsAndLettersList  <span class="im_overlay" @click="$modal.hide('petition-workflow-configuration'); configPopup=false;"></span> -->
      <div class="v-modal">
        <div class="popup-header">
          <h2 class="popup-title">Download Files</h2>
          <span @click="hideModel('download_files_model', false)">
            <em class="material-icons">close</em>
          </span>
        </div>
        <div class="form-container">
          <div v-if="formsAndLettersList.length > 0" class="forms_accordian popup_no_accordian">
            <vs-collapse accordion>
              <template v-for="(forms, index) in formsAndLettersList">
                <template v-if="(forms.depType == depType && forms.depLabel ==depLabel && forms.docUserType == docUserType && checkProperty( petition ,'subTypeDetails' ,'id') !=15) || checkProperty( petition ,'subTypeDetails' ,'id') ==15 ">
                <vs-collapse-item
                  v-if="forms.statusId != 1"
                  :open="openItem"
                  :class="{
                    closeDropdown: currentRole == 50,
                    'no-list':
                      checkProperty(forms, 'reverse_document_versions') &&
                      forms['reverse_document_versions'].length == 0,
                  }"
                  :not-arrow="
                    !(
                      checkProperty(forms, 'reverse_document_versions') &&
                      forms['reverse_document_versions'].length >= 0
                    )
                  "
                  :key="index"
                >
                  <div slot="header" class="ss">
                    <vs-list-item :title="forms.name" :subtitle="getformated(forms)">
                      <docType :item="forms" />

                      <ul class="download_checkbox">
                        <li>
                          <vs-checkbox
                            :disabled="[50, 51].indexOf(getUserRoleId) > -1"
                            :name="'selectedForSigning_' + index + '_'"
                            v-model="forms.selectedForDownload"
                            class=""
                          ></vs-checkbox>
                        </li>
                      </ul>
                    </vs-list-item>
                  </div>
                </vs-collapse-item>
                </template>
              </template>
            </vs-collapse>
          </div>
          <div
            class="text-danger text-sm formerrors"
            v-show="formerrors.msg"
            @click="formerrors.msg = ''"
          >
            <vs-alert
              color="warning"
              class="warning-alert reg-warning-alert no-border-radius"
              icon-pack="IntakePortal"
              icon="IP-information-button"
              active="true"
              >{{ formerrors.msg }}</vs-alert
            >
          </div>
        </div>
        <div class="popup-footer relative">
          <button
            :disabled="downloading"
            @click="
              downloadFiles = false;
              openDownloadPopup(false);
              formerrors.msg = '';
            "
            class="btn cancel"
          >
            Cancel
          </button>
          <button
            :disabled="downloading"
            class="btn save w-auto pl-3 pr-3"
            @click="downloadFormslatters(true)"
          >
            <figure v-if="downloading" class="loader">
              <img src="@/assets/images/main/loader.gif" />
            </figure>
            Download Zip File
          </button>
          <button
            :disabled="downloading"
            class="btn save w-auto pl-3 pr-3"
            @click="downloadFormslatters(false)"
          >
            <figure v-if="downloading" class="loader">
              <img src="@/assets/images/main/loader.gif" />
            </figure>
            Download Pdf File
          </button>
        </div>
      </div>
    </modal>

    <modal
      name="pdfEditorPopup"
      classes="v-modal-sec"
      :min-width="200"
      :min-height="200"
      :scrollable="true"
      :reset="true"
      width="1000px"
      height="auto"
    >
      <div class="v-modal">
        <div class="popup-header fromDetailsPage">
          <h2 class="popup-title">Edit PDF</h2>
          <span @click="$modal.hide('pdfEditorPopup')">
            <em class="material-icons">close</em>
          </span>
        </div>

        <!---pdfUrl-->
        <template>
          <!-- <pdf v-for="page in numPdfPages"  :key="page" :src="pdfUrl"   ref="myPdfComponent" ></pdf>-->
        </template>
      </div>
    </modal>

    <modal
      name="generateFormsLattersPopup"
      classes="v-modal-sec"
      :min-width="200"
      :min-height="200"
      :scrollable="true"
      :reset="true"
      width="500px"
      height="auto"
    >
      <div class="v-modal generate-forms-Latters">
        <div class="popup-header fromDetailsPage">
          <h2 class="popup-title">Generate Forms and Letters</h2>
          <span @click="$modal.hide('generateFormsLattersPopup')">
            <em class="material-icons">close</em>
          </span>
        </div>
        <div class="form-container pb-0" @click="formerrors.msg = ''">
          <div class="row mt-0">
            <div class="vx-col w-full">
              <div class="form_group">
                <label class="form_label">Service Center<em>*</em></label>
                <div class="con-select" style="width: 100%">
                  <multiselect
                    data-vv-as="Service Center"
                    v-model="selectedOffice"
                    :allow-empty="false"
                    @input="changedOffice(false)"
                    :options="officeList"
                    :multiple="false"
                    :close-on-select="true"
                    :clear-on-select="false"
                    :preserve-search="true"
                    placeholder="Service Center"
                    label="name"
                    track-by="name"
                    :preselect-first="false"
                    name="service_center"
                    v-validate="'required'"
                  >
                    <template slot="selection" slot-scope="{ values, isOpen }">
                      <span
                        class="multiselect__single"
                        v-if="values.length &amp;&amp; !isOpen"
                        >{{ values.length }} options selected</span
                      >
                    </template>
                  </multiselect>

                  <span class="text-danger text-sm" v-if="errors.has('service_center')">{{
                    errors.first("service_center")
                  }}</span>
                </div>
              </div>
            </div>
          </div>

          <div>
            <!------beneficiary Documents-->
            <template
              v-if="checkProperty(masterFormsAndLatters, 'beneficiary', 'length') > 0"
            >
              <div class="spouse-documents mb-6">
                <span class="beneficiary-documents">Beneficiary Documents</span>
                <template
                  v-for="(documentItem, index) in masterFormsAndLatters['beneficiary']"
                >
                  <div class="row" :key="index">
                    <!----'isSelectedNewVersion':false ,"isSelectedCurrentVersion" availableNewVersion masterFormsAndLatters --->
                    <!--  effectiveDate == {{ checkProperty(documentItem,'effectiveDate') }}   priorFormsInformation==  {{documentItem.priorFormsInformation}}
                -->
                    <template v-if="checkProperty(documentItem, 'availableNewVersion')">
                      <div class="availableNewVersion">
                        <div class="documents_accordian_tile d-flex align-center">
                          <vs-checkbox
                            :name="'beneficiary_currentversion' + index"
                            @input="
                              selectDocument(documentItem, 'isSelectedCurrentVersion')
                            "
                            v-model="documentItem.isSelectedCurrentVersion"
                            class=""
                          >
                            <span
                              :availableNewVersion="
                                checkProperty(documentItem, 'availableNewVersion')
                              "
                              >{{ checkProperty(documentItem, "documentRef", "name")
                              }}<small
                                >{{ checkProperty(documentItem, "documentRef", "type") }}
                              </small></span
                            >
                          </vs-checkbox>
                          <h6 class="form-edited" v-if="documentItem.isedited">Edited</h6>
                        </div>
                        <div class="newVersionDocument">
                          <div class="documents_accordian_tile d-flex align-center">
                            <vs-checkbox
                              :name="'beneficiary_newversion' + index"
                              @input="
                                selectDocument(documentItem, 'isSelectedNewVersion')
                              "
                              v-model="documentItem.isSelectedNewVersion"
                              class=""
                            >
                              <span>Available New Version Document </span>
                            </vs-checkbox>
                          </div>
                        </div>
                      </div>
                    </template>
                    <template v-else>
                      <div class="documents_accordian_tile d-flex align-center">
                        <vs-checkbox
                          :name="'selectedForgenerate_' + index"
                          v-model="documentItem.isSelectedCurrentVersion"
                          class=""
                        >
                          <span
                            :availableNewVersion="
                              checkProperty(documentItem, 'availableNewVersion')
                            "
                            >{{ documentItem.name
                            }}<small
                              >{{ checkProperty(documentItem, "type") }}
                            </small></span
                          >
                        </vs-checkbox>
                        <h6 v-if="documentItem.isedited" class="form-edited">Edited</h6>
                      </div>
                    </template>
                  </div>
                </template>
              </div>
            </template>
            <!------Spouse Documents-->
            <template v-if="checkProperty(masterFormsAndLatters, 'spouse', 'length') > 0">
              <div class="spouse-documents mb-6">
                <span>Spouse Documents</span>
                <template
                  v-for="(documentItem, index) in masterFormsAndLatters['spouse']"
                >
                  <div class="row" :key="index">
                    <template v-if="checkProperty(documentItem, 'availableNewVersion')">
                      <div class="availableNewVersion">
                        <div class="documents_accordian_tile d-flex align-center">
                          <vs-checkbox
                            :name="'spouse_currentversion' + index"
                            @input="
                              selectDocument(documentItem, 'isSelectedCurrentVersion')
                            "
                            v-model="documentItem.isSelectedCurrentVersion"
                            class=""
                          >
                            <span
                              :availableNewVersion="
                                checkProperty(documentItem, 'availableNewVersion')
                              "
                              >{{ documentItem.name
                              }}<small
                                >{{ checkProperty(documentItem, "type") }}
                              </small></span
                            >
                          </vs-checkbox>
                          <h6 class="form-edited" v-if="documentItem.isedited">Edited</h6>
                        </div>
                        <div class="newVersionDocument">
                          <div class="documents_accordian_tile d-flex align-center">
                            <vs-checkbox
                              :name="'spouse_newversion' + index"
                              @input="
                                selectDocument(documentItem, 'isSelectedNewVersion')
                              "
                              v-model="documentItem.isSelectedNewVersion"
                              class=""
                            >
                              <span>Available New Version Document </span>
                            </vs-checkbox>
                          </div>
                        </div>
                      </div>
                    </template>
                    <template v-else>
                      <div class="documents_accordian_tile d-flex align-center">
                        <vs-checkbox
                          :name="'spouse_' + index"
                          v-model="documentItem.isSelectedCurrentVersion"
                          class=""
                        >
                          <span
                            :availableNewVersion="
                              checkProperty(documentItem, 'availableNewVersion')
                            "
                            >{{ documentItem.name
                            }}<small
                              >{{ checkProperty(documentItem, "type") }}
                            </small></span
                          >
                        </vs-checkbox>
                        <h6 class="form-edited" v-if="documentItem.isedited">Edited</h6>
                      </div>
                    </template>
                  </div>
                </template>
              </div>
            </template>

            <template
              v-if="
                checkProperty(Object.entries(masterFormsAndLatters['child']), 'length') >
                0
              "
            >
              <div class="spouse-documents mb-6">
                <template
                  v-for="(val, key) in Object.entries(masterFormsAndLatters['child'])"
                >
                  <div :key="'child_' + key" v-if="checkProperty(val, 'length') >= 2">
                    <template v-if="checkProperty(val[1], 'length') > 0">
                      <span>Child {{ val[1][0]["userName"] }} </span>
                      <template v-for="(documentItem, index) in val[1]">
                        <div class="row" :key="index">
                          <template
                            v-if="checkProperty(documentItem, 'availableNewVersion')"
                          >
                            <div class="availableNewVersion">
                              <div class="documents_accordian_tile d-flex align-center">
                                <vs-checkbox
                                  :name="'spouse_currentversion' + index"
                                  @input="
                                    selectDocument(
                                      documentItem,
                                      'isSelectedCurrentVersion'
                                    )
                                  "
                                  v-model="documentItem.isSelectedCurrentVersion"
                                  class=""
                                >
                                  <span
                                    :availableNewVersion="
                                      checkProperty(documentItem, 'availableNewVersion')
                                    "
                                    >{{ documentItem.name
                                    }}<small>{{
                                      checkProperty(documentItem, "type")
                                    }}</small></span
                                  >
                                </vs-checkbox>
                                <h6 class="form-edited" v-if="documentItem.isedited">
                                  Edited
                                </h6>
                              </div>
                              <div class="newVersionDocument">
                                <div class="documents_accordian_tile d-flex align-center">
                                  <vs-checkbox
                                    :name="'spouse_newversion' + index"
                                    @input="
                                      selectDocument(documentItem, 'isSelectedNewVersion')
                                    "
                                    v-model="documentItem.isSelectedNewVersion"
                                    class=""
                                  >
                                    <span>Available New Version Document </span>
                                  </vs-checkbox>
                                </div>
                              </div>
                            </div>
                            <span class="devider"></span>
                          </template>
                          <template v-else>
                            <div class="documents_accordian_tile d-flex align-center">
                              <vs-checkbox
                                :name="'spouse_' + index"
                                v-model="documentItem.isSelectedCurrentVersion"
                                class=""
                              >
                                <span
                                  :availableNewVersion="
                                    checkProperty(documentItem, 'availableNewVersion')
                                  "
                                  >{{ documentItem.name
                                  }}<small
                                    >{{ checkProperty(documentItem, "type") }}
                                  </small></span
                                >
                              </vs-checkbox>
                              <h6 class="form-edited" v-if="documentItem.isedited">
                                Edited
                              </h6>
                            </div>
                          </template>
                        </div>
                      </template>
                    </template>
                  </div>
                </template>
              </div>
            </template>
          </div>
        </div>
        <div
          class="text-danger text-sm formerrors"
          v-show="formerrors.msg"
          @click="formerrors.msg = ''"
        >
          <vs-alert
            color="warning"
            class="warning-alert reg-warning-alert no-border-radius"
            icon-pack="IntakePortal"
            icon="IP-information-button"
            active="true"
            >{{ formerrors.msg }}</vs-alert
          >
        </div>

        <div class="popup-footer relative">
          <button
            @click="
              $modal.hide('generateFormsLattersPopup');
              formerrors.msg = '';
            "
            class="btn cancel"
          >
            Cancel
          </button>
          <button class="btn save" @click="generateFormsAndLatters()">
            <figure v-if="generatingFiles" class="loader">
              <img src="@/assets/images/main/loader.gif" />
            </figure>
            Generate
          </button>
        </div>
      </div>
    </modal>

    <vs-popup
      style="z-index:999999; !important"
      class="holamundo main-popup"
      title="Regenerate Forms and Letters"
      :active.sync="regeneratingFormAndLetter"
    >
      <div class="form-container">
        <div class="vx-row">
          <div class="vx-col w-full">
            <p>
              Please note that changes made will be lost if the Forms/Letters are
              regenerated again
            </p>
            <p>Are you sure to proceed?</p>
          </div>
        </div>

        <div v-show="formerrors.msg">
          <vs-alert
            color="warning"
            class="warning-alert reg-warning-alert no-border-radius"
            icon-pack="IntakePortal"
            icon="IP-information-button"
            active="true"
            >{{ formerrors.msg }}</vs-alert
          >
        </div>
      </div>
      <div class="popup-footer relative">
        <figure v-if="generatingFiles" class="loader">
          <img src="@/assets/images/main/loader.gif" />
        </figure>
        <vs-button
          color="dark"
          class="cancel"
          type="filled"
          @click="regeneratingFormAndLetter = false"
          >Cancel
        </vs-button>
        <vs-button
          color="success"
          :disabled="formSubmited"
          class="save w-auto"
          type="filled"
          @click="generateFormsAndLatters()"
          >Yes</vs-button
        >
      </div>
    </vs-popup>
    <!--Approve or reject documents-->
    <vs-popup
      class="holamundo main-popup"
      :title="approveOrRejectDocsTitle"
      :active.sync="approveOrRejectDocs"
    >
      <form data-vv-scope="approveOrRejectDocsForm">
        <div class="form-container">
          <div class="vx-row">
            <div class="vx-col w-full">
              <div class="form_group">
                <label class="form_label">Comments</label>
                <!-- <vs-textarea
                  data-vv-as="Comments"
                  v-validate="'required'"
                  v-model="comments"
                  name="comments"
                  class="w-full"
                /> -->
                <ckeditor   data-vv-as="Comments"
                  v-validate="'required'"
                  v-model="comments"
                  name="comments"
                  class="w-full" :editor="editor" :config="editorConfig"></ckeditor>


                <span
                  class="text-danger text-sm"
                  v-show="errors.has('approveOrRejectDocsForm.comments')"
                  >{{ errors.first("approveOrRejectDocsForm.comments") }}</span
                >
              </div>
            </div>
          </div>
          <div class="text-danger text-sm formerrors" v-show="formErrors">
            <vs-alert
              color="warning"
              class="warning-alert reg-warning-alert no-border-radius"
              icon-pack="IntakePortal"
              icon="IP-information-button"
              active="true"
              >{{ formErrors }}</vs-alert
            >
          </div>
        </div>
        <div class="popup-footer">
          <!-- <span class="loader"><img src="@/assets/images/main/loader.gif" /></span> -->
          <vs-button
            color="dark"
            @click="approveOrRejectDocs = false"
            class="btn cancel"
            type="filled"
            >Cancel
          </vs-button>

          <vs-button
            v-if="selectedAction == 'REJECT_BY_DOC_MANAGER'"
            color="success"
            @click="approveOrRejectDocsAction('REJECT_BY_DOC_MANAGER')"
            class="save"
            type="filled"
            >Reject</vs-button
          >
          <vs-button
            v-if="selectedAction == 'APPROVED_BY_DOC_MANAGER'"
            color="success"
            @click="approveOrRejectDocsAction('APPROVED_BY_DOC_MANAGER')"
            class="save"
            type="filled"
            >Approve</vs-button
          >
        </div>
      </form>
    </vs-popup>

    <div
      class="workflow_view_wrap generate_formsandletters"
      :class="{ listopen: generateFormsLattersPopup }"
    >
      <div class="workflow_overlay"></div>
      <div class="workflow_view_cnt questionary_cnt">
        <div class="workflow_view_title pr-0 common_title">
          <label
            v-if="
              this.checkProperty(this.petition, 'typeDetails', 'id') == 3 &&
              this.checkProperty(this.petition, 'subTypeDetails', 'id') == 15
            "
            >Generate Audit Response</label
          >
          <label v-else> Generate Forms and Letters</label>
          <span class="close" @click="generateFormsLattersPopup = false;checkReloadPetition()">
            <x-icon size="1.5x" class="custom-class"></x-icon
          ></span>
        </div>
        <div class="audit-response">
          <div class="doc_modal">
         
            <VuePerfectScrollbar class="scrollbardoc pt-4">
              <vs-row vs-w="12">
                <div class="form-container pad30 pt-0 pb-0" @click="formerrors.msg = ''">
                 
                  <div class="vx-col w-full" v-if="showCourier">
                    <div class="form_group custom-radio_wrap mb-4">
                      <label for class="form_label">Courier<em>*</em></label>
                        <ul class="custom-radio" vs-type="flex" vs-align="center">
                         
                          
                        <li v-for="(courier , index) in courierListTemp">
                       
                            
                        <vs-radio name="courier"  :vs-value="courier.id"  v-model="selectedCourier"  class="w-full">
                          <span :id="'courier_'+courier.code">
                            {{ courier.name }}
                          </span>
                        </vs-radio > 

                        
                        </li>
                               
                            
                        </ul>
                   </div>
               </div>

                  <div
                    class="row mt-0"
                    v-if="
                      (!loadingFormLatters &&
                        checkProperty(masterFormsAndLatters, 'beneficiary', 'length') >
                          0) ||
                      checkProperty(masterFormsAndLatters, 'spouse', 'length') > 0 ||
                      checkProperty(
                        Object.entries(masterFormsAndLatters['child']),
                        'length'
                      ) > 0 ||
                      checkProperty(masterFormsAndLatters, 'audit_response', 'length') > 0
                    "
                  >
                    <div class="vx-col w-auto inline-block">
                      <div class="form_group">
                       
                        <div class="con-select service_center" style="width: 100%; margin-bottom: 10px !important;">
                          <label class="form_label">Service Center <em>*</em></label>
                          <multiselect
                            data-vv-as="Service Center"
                            v-model="selectedOffice"
                            :allow-empty="false"
                            @input="changedOffice(false)"
                            :options="officeList"
                            :multiple="false"
                            :close-on-select="true"
                            :clear-on-select="false"
                            :preserve-search="true"
                            placeholder="Service Center"
                            label="name"
                            track-by="name"
                            :preselect-first="false"
                            name="serviceCenter"
                            v-validate="'required'"
                          >
                            <template slot="selection" slot-scope="{ values, isOpen }">
                              <span
                                class="multiselect__single"
                                v-if="values.length &amp;&amp; !isOpen"
                                >{{ values.length }} options selected</span
                              >
                            </template>
                          </multiselect>

                          <span
                            class="text-danger text-sm"
                            v-if="errors.has('serviceCenter')"
                            >{{ errors.first("serviceCenter") }}</span
                          >
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="row mt-0 mb-0" v-if="courierAddress !=''">
                  <vs-alert  color="warning"  class="warning-alert top-warning-alert service_center_info" icon-pack="IntakePortal" icon="IP-information-button"
                    active="true"  v-html="courierAddress" >{{courierAddress }}</vs-alert>
                </div>

                  <div
                    v-if="
                      (!loadingFormLatters &&
                        checkProperty(masterFormsAndLatters, 'beneficiary', 'length') >
                          0) ||
                      checkProperty(masterFormsAndLatters, 'spouse', 'length') > 0 ||
                      checkProperty(
                        Object.entries(masterFormsAndLatters['child']),
                        'length'
                      ) > 0 ||
                      checkProperty(masterFormsAndLatters, 'audit_response', 'length') > 0
                    "
                  >
                  <div class="row mt-6 mb-0" >
                    
                    <vs-checkbox v-model="selectAll" @click="selct_all(true)" class="m-0">
                      <template v-if="selectAll">Unselect All</template>
                      <template v-else>Select All</template>
                      
                    </vs-checkbox>
                  </div>
                    <!------AUDIT RESPONSE -->
                    <template
                      v-if="
                        checkProperty(masterFormsAndLatters, 'audit_response', 'length') >
                        0
                      "
                    >
                      <div class="spouse-documents mb-6">
                        <span class="beneficiary-documents">
                          <template>Audit Response Documents</template>
                        </span>
                        <template
                          v-for="(documentItem, index) in masterFormsAndLatters[
                            'audit_response'
                          ]"
                        >
                          <div class="row" :key="index">
                            <!----'isSelectedNewVersion':false ,"isSelectedCurrentVersion" availableNewVersion masterFormsAndLatters --->
                            <!--  effectiveDate == {{ checkProperty(documentItem,'effectiveDate') }}   priorFormsInformation==  {{documentItem.priorFormsInformation}}
            -->
                            <template
                              v-if="checkProperty(documentItem, 'availableNewVersion')"
                            >
                              <div class="availableNewVersion">
                                <div class="documents_accordian_tile d-flex align-center">
                                  <vs-checkbox
                                  @click="selct_all(false)"
                                    :name="'beneficiary_currentversion' + index"
                                    
                                    @input="
                                      selectDocument(
                                        documentItem,
                                        'isSelectedCurrentVersion'
                                      )
                                    "
                                    v-model="documentItem.isSelectedCurrentVersion"
                                    class=""
                                  >
                                    <span
                                    
                                      :availableNewVersion="
                                        checkProperty(documentItem, 'availableNewVersion')
                                      "
                                      >{{
                                        checkProperty(
                                          documentItem,
                                          "documentRef",
                                          "name"
                                        )
                                      }}<small
                                        >{{
                                          checkProperty(
                                            documentItem,
                                            "documentRef",
                                            "type"
                                          )
                                        }}
                                      </small></span
                                    >
                                  </vs-checkbox>
                                  <h6 class="form-edited" v-if="documentItem.isedited">
                                    Edited
                                  </h6>
                                </div>
                                <div class="newVersionDocument">
                                  <div
                                    class="documents_accordian_tile d-flex align-center"
                                  >
                                    <vs-checkbox
                                      :name="'beneficiary_newversion' + index"
                                      @input="
                                        selectDocument(
                                          documentItem,
                                          'isSelectedNewVersion'
                                        )
                                      "
                                      v-model="documentItem.isSelectedNewVersion"
                                      class=""
                                    >
                                      <span>Available New Version Document </span>
                                    </vs-checkbox>
                                  </div>
                                </div>
                              </div>
                            </template>
                            <template v-else>
                              <div class="documents_accordian_tile d-flex align-center">
                                <vs-checkbox
                                  @click="selct_all(false)"
                                  :name="'selectedForgenerate_' + index"
                                  v-model="documentItem.isSelectedCurrentVersion"
                                  class=""
                                >
                                  <span
                                  
                                    :availableNewVersion="
                                      checkProperty(documentItem, 'availableNewVersion')
                                    "
                                    >{{ documentItem.name
                                    }}<small
                                      >{{ checkProperty(documentItem, "type") }}
                                    </small></span
                                  >
                                </vs-checkbox>
                                <h6 v-if="documentItem.isedited" class="form-edited">
                                  Edited
                                </h6>
                              </div>
                            </template>
                          </div>
                        </template>

                        <template
                          v-if="
                            checkProperty(petitionDetails, 'recruitmentInfo') &&
                            checkProperty(petitionDetails['recruitmentInfo'], 'documents')
                          "
                        >
                          <template
                            v-for="(itemmm, indexx) in Object.entries(
                              petitionDetails['recruitmentInfo']['documents']
                            )"
                          >
                            <div class="vx-col w-full upload-docs">
                              <div class="form_group">
                                <label class="form_label">{{
                                  checkDocsLabel({ field: itemmm[0], category: "label" })
                                }}</label>
                                <file-upload
                                  :ref="itemmm[0] + indexx"
                                  :hideSelected="true"
                                  v-model="fvalue"
                                  class="file-upload-input file-upload-input-cs"
                                  :name="itemmm[0] + indexx"
                                  :multiple="true"
                                  :accept="allDocEntity"
                                  @input="uploadAdv(fvalue, itemmm[0])"
                                >
                                  <img
                                    class="file-icon"
                                    src="@/assets/images/main/file-upload.svg"
                                  />
                                  Upload
                                  <span
                                    class="loader"
                                    v-if="
                                      checkDocsLabel({
                                        field: itemmm[0],
                                        category: 'loading',
                                      })
                                    "
                                    ><img src="@/assets/images/main/loader.gif"
                                  /></span>
                                </file-upload>

                                <ul class="uploaded-list">
                                  <template
                                    v-for="(item, index) in petitionDetails[
                                      'recruitmentInfo'
                                    ]['documents'][itemmm[0]]"
                                  >
                                    <vs-chip
                                      :key="index"
                                      @click="
                                        remove(
                                          item,
                                          petitionDetails['recruitmentInfo']['documents'][
                                            itemmm[0]
                                          ],
                                          index
                                        )
                                      "
                                      closable
                                    >
                                      {{ item.name }}
                                    </vs-chip>
                                  </template>
                                </ul>
                              </div>
                            </div>
                          </template>
                        </template>
                      </div>
                    </template>
                    <!------beneficiary Documents-->
                    <template
                      v-if="
                        checkProperty(masterFormsAndLatters, 'beneficiary', 'length') > 0
                      "
                    >
                      <div class="spouse-documents mb-6">
                        <span class="beneficiary-documents">
                          <template
                            v-if="
                              checkProperty(
                                masterFormsAndLatters['beneficiary'][0],
                                'userName'
                              )
                            "
                            >{{ masterFormsAndLatters["beneficiary"][0]["userName"] }}
                            (Beneficiary)
                          </template>
                          <template v-else>Beneficiary Documents </template>
                        </span>
                        <template
                          v-for="(documentItem, index) in masterFormsAndLatters[
                            'beneficiary'
                          ]"
                        >
                       
                          <div class="row" :key="index">
                            <!----'isSelectedNewVersion':false ,"isSelectedCurrentVersion" availableNewVersion masterFormsAndLatters --->
                            <!--  effectiveDate == {{ checkProperty(documentItem,'effectiveDate') }}   priorFormsInformation==  {{documentItem.priorFormsInformation}}
                            -->
                            
                            <template  v-if="checkProperty(documentItem, 'availableNewVersion')"
                            >
                              <div class="availableNewVersion">
                                <div class="documents_accordian_tile d-flex align-center">
                                  <vs-checkbox
                                    @click="selct_all(false)"
                                    :name="'beneficiary_currentversion' + index"
                                    
                                    @input="
                                      selectDocument(
                                        documentItem,
                                        'isSelectedCurrentVersion'
                                      );
                                    "
                                    v-model="documentItem.isSelectedCurrentVersion"
                                    class=""
                                  >
                                    <span
                                      
                                      :availableNewVersion="
                                        checkProperty(documentItem, 'availableNewVersion')
                                      "
                                      >  {{
                                        checkProperty(
                                          documentItem,
                                          "documentRef",
                                          "name"
                                        )
                                      }}<small
                                        >{{
                                          checkProperty(
                                            documentItem,
                                            "documentRef",
                                            "type"
                                          )
                                        }}
                                      </small></span
                                    >
                                  </vs-checkbox>
                                  <h6 class="form-edited" v-if="documentItem.isedited">
                                    Edited
                                  </h6>
                                </div>
                                <div class="newVersionDocument">
                                  <div
                                    class="documents_accordian_tile d-flex align-center"
                                  >
                                    <vs-checkbox
                                      :name="'beneficiary_newversion' + index"
                                      @input="
                                        selectDocument(
                                          documentItem,
                                          'isSelectedNewVersion'
                                        )
                                      "
                                      v-model="documentItem.isSelectedNewVersion"
                                      class=""
                                    >
                                      <span>Available New Version Document </span>
                                    </vs-checkbox>
                                  </div>
                                </div>
                              </div>
                            </template>
                            <template v-else>
                              <div class="documents_accordian_tile d-flex align-center"  >
                                <vs-checkbox
                                  @click="selct_all(false)"
                                  :name="'selectedForgenerate_' + index"
                                  v-model="documentItem.isSelectedCurrentVersion"
                                  class=""
                                >
                                  <span
                                 
                                    :availableNewVersion="
                                      checkProperty(documentItem, 'availableNewVersion')
                                    "
                                    >{{ documentItem.name
                                    }}<small
                                      >{{ checkProperty(documentItem, "type") }}
                                    </small></span
                                  >
                                </vs-checkbox>
                                <h6 v-if="documentItem.isedited" class="form-edited">
                                  Edited
                                </h6>
                              </div>
                            </template>
                          </div>
                          
                            <!-- <div class="accordian_item" :key="index">
                              <div class="accordian_header">
                                header 
                                <img src="@/assets/images/icons/black_arrow.svg" />
                              </div>
                              <div class="accordian_body">
                                <vs-checkbox
                                    @click="selct_all(false)"
                                    :name="'beneficiary_currentversion' + index"
                                    
                                    @input="
                                      selectDocument(
                                        documentItem,
                                        'isSelectedCurrentVersion'
                                      );
                                    "
                                    v-model="documentItem.isSelectedCurrentVersion"
                                    class=""
                                  >
                                    <span
                                      
                                      :availableNewVersion="
                                        checkProperty(documentItem, 'availableNewVersion')
                                      "
                                      >  {{
                                        checkProperty(
                                          documentItem,
                                          "documentRef",
                                          "name"
                                        )
                                      }}<small
                                        >{{
                                          checkProperty(
                                            documentItem,
                                            "documentRef",
                                            "type"
                                          )
                                        }}
                                      </small></span
                                    >
                                  </vs-checkbox>
                              </div>
                            </div> -->
                        </template>
                        <div class="accordian_sec_new" v-if="false">
                            <div class="accordian_item" :class="{open : toggleAccord}" @click="toggleAccord = !toggleAccord">
                              <div class="accordian_header">
                                header 
                                <img src="@/assets/images/icons/black_arrow.svg" />
                              </div>
                              <div class="accordian_body">
                                <vs-checkbox><span>I-539 <small>Form</small></span></vs-checkbox>
                                <vs-checkbox><span>H4 Cover Letter <small>Letter</small></span></vs-checkbox>
                                <vs-checkbox><span>G-28 <small>Form</small></span></vs-checkbox>
                              </div>
                            </div>
                            <div class="accordian_item" :class="{open : toggleAccord}" @click="toggleAccord = !toggleAccord">
                              <div class="accordian_header">
                                header 
                                <img src="@/assets/images/icons/black_arrow.svg" />
                              </div>
                              <div class="accordian_body">
                                <vs-checkbox><span>I-539 <small>Form</small></span></vs-checkbox>
                                <vs-checkbox><span>H4 Cover Letter <small>Letter</small></span></vs-checkbox>
                                <vs-checkbox><span>G-28 <small>Form</small></span></vs-checkbox>
                              </div>
                            </div>
                            <div class="accordian_item" :class="{open : toggleAccord}" @click="toggleAccord = !toggleAccord">
                              <div class="accordian_header">
                                header 
                                <img src="@/assets/images/icons/black_arrow.svg" />
                              </div>
                              <div class="accordian_body">
                                <vs-checkbox><span>I-539 <small>Form</small></span></vs-checkbox>
                                <vs-checkbox><span>H4 Cover Letter <small>Letter</small></span></vs-checkbox>
                                <vs-checkbox><span>G-28 <small>Form</small></span></vs-checkbox>
                              </div>
                            </div>
                          </div>
                      </div>
                    </template>
                    <!------Spouse Documents-->
                    <template
                      v-if="checkProperty(masterFormsAndLatters, 'spouse', 'length') > 0"
                    >
                      <div class="spouse-documents mb-6">
                        <span>
                          <template
                            v-if="
                              checkProperty(
                                masterFormsAndLatters['spouse'][0],
                                'userName'
                              )
                            "
                            >{{ masterFormsAndLatters["spouse"][0]["userName"] }} (Spouse)
                          </template>
                          <template v-else>Spouse Documents</template>
                        </span>
                        <template
                          v-for="(documentItem, index) in masterFormsAndLatters['spouse']"
                        >
                          <div class="row" :key="index">
                            <template
                              v-if="checkProperty(documentItem, 'availableNewVersion')"
                            >
                              <div class="availableNewVersion">
                                <div class="documents_accordian_tile d-flex align-center">
                                  <vs-checkbox
                                  @click="selct_all(false)"
                                    :name="'spouse_currentversion' + index"
                                    @input="
                                      selectDocument(
                                        documentItem,
                                        'isSelectedCurrentVersion'
                                      )
                                    "
                                    v-model="documentItem.isSelectedCurrentVersion"
                                    class=""
                                  >
                                    <span
                                    
                                      :availableNewVersion="
                                        checkProperty(documentItem, 'availableNewVersion')
                                      "
                                      >{{ documentItem.name
                                      }}<small
                                        >{{ checkProperty(documentItem, "type") }}
                                      </small></span
                                    >
                                  </vs-checkbox>
                                  <h6 class="form-edited" v-if="documentItem.isedited">
                                    Edited
                                  </h6>
                                </div>
                                <div class="newVersionDocument">
                                  <div
                                    class="documents_accordian_tile d-flex align-center"
                                  >
                                    <vs-checkbox
                                    
                                      :name="'spouse_newversion' + index"
                                      @input="
                                        selectDocument(
                                          documentItem,
                                          'isSelectedNewVersion'
                                        )
                                      "
                                      v-model="documentItem.isSelectedNewVersion"
                                      class=""
                                    >
                                      <span  >Available New Version Document </span>
                                    </vs-checkbox>
                                  </div>
                                </div>
                              </div>
                            </template>
                            <template v-else>
                              <div class="documents_accordian_tile d-flex align-center">
                                <vs-checkbox
                                @click="selct_all(false)"
                                  :name="'spouse_' + index"
                                  v-model="documentItem.isSelectedCurrentVersion"
                                  class=""
                                >
                                  <span 
                                    :availableNewVersion="
                                      checkProperty(documentItem, 'availableNewVersion')
                                    "
                                    >{{ documentItem.name
                                    }}<small 
                                      >{{ checkProperty(documentItem, "type") }}
                                    </small></span
                                  >
                                </vs-checkbox>
                                <h6 class="form-edited" v-if="documentItem.isedited">
                                  Edited
                                </h6>
                              </div>
                            </template>
                          </div>
                        </template>
                      </div>
                    </template>

                    <template
                      v-if="
                        checkProperty(
                          Object.entries(masterFormsAndLatters['child']),
                          'length'
                        ) > 0
                      "
                    >
                      <div class="spouse-documents mb-6">
                        <template
                          v-for="(val, key) in Object.entries(
                            masterFormsAndLatters['child']
                          )"
                        >
                          <div
                            :key="'child_' + key"
                            v-if="checkProperty(val, 'length') >= 2"
                          >
                            <template v-if="checkProperty(val[1], 'length') > 0">
                              <span> {{ val[1][0]["userName"] }} (Child) </span>
                              <template v-for="(documentItem, index) in val[1]">
                                <div class="row" :key="index">
                                  <template
                                    v-if="
                                      checkProperty(documentItem, 'availableNewVersion')
                                    "
                                  >
                                    <div class="availableNewVersion">
                                      <div
                                        class="documents_accordian_tile d-flex align-center"
                                      >
                                        <vs-checkbox
                                        @click="selct_all(false)"
                                          :name="'spouse_currentversion' + index"
                                          @input="
                                            selectDocument(
                                              documentItem,
                                              'isSelectedCurrentVersion'
                                            )
                                          "
                                          v-model="documentItem.isSelectedCurrentVersion"
                                          class=""
                                        >
                                          <span
                                          
                                            :availableNewVersion="
                                              checkProperty(
                                                documentItem,
                                                'availableNewVersion'
                                              )
                                            "
                                            >{{ documentItem.name
                                            }}<small>{{
                                              checkProperty(documentItem, "type")
                                            }}</small></span
                                          >
                                        </vs-checkbox>
                                        <h6
                                          class="form-edited"
                                          v-if="documentItem.isedited"
                                        >
                                          Edited
                                        </h6>
                                      </div>
                                      <div class="newVersionDocument">
                                        <div
                                          class="documents_accordian_tile d-flex align-center"
                                        >
                                          <vs-checkbox
                                            :name="'spouse_newversion' + index"
                                            @input="
                                              selectDocument(
                                                documentItem,
                                                'isSelectedNewVersion'
                                              )
                                            "
                                            v-model="documentItem.isSelectedNewVersion"
                                            class=""
                                          >
                                            <span  >Available New Version Document </span>
                                          </vs-checkbox>
                                        </div>
                                      </div>
                                    </div>
                                    <span class="devider"></span>
                                  </template>
                                  <template v-else>
                                    <div
                                      class="documents_accordian_tile d-flex align-center"
                                    >
                                      <vs-checkbox
                                      @click="selct_all(false)"
                                        :name="'spouse_' + index"
                                        v-model="documentItem.isSelectedCurrentVersion"
                                        class=""
                                      >
                                        <span  
                                          :availableNewVersion="
                                            checkProperty(
                                              documentItem,
                                              'availableNewVersion'
                                            )
                                          "
                                          >{{ documentItem.name
                                          }}<small
                                            >{{ checkProperty(documentItem, "type") }}
                                          </small></span
                                        >
                                      </vs-checkbox>
                                      <h6
                                        class="form-edited"
                                        v-if="documentItem.isedited"
                                      >
                                        Edited
                                      </h6>
                                    </div>
                                  </template>
                                </div>
                              </template>
                            </template>
                          </div>
                        </template>
                      </div>
                    </template>
                  </div>
                  <div v-else>
                    <template v-if="loadingFormLatters">
                      <span class="loader" v-if="loadingFormLatters"
                        ><img src="@/assets/images/main/loader.gif"
                      /></span>
                    </template>
                    <template v-else>
                      <NoDataFound
                        ref="NoDataFoundRef"
                        :checkLocading="false"
                        content=""
                        heading="No Documents Found."
                        type="documents"
                      />
                    </template>
                  </div>
                </div>
              </vs-row>
            </VuePerfectScrollbar>
            <div
              class="text-danger text-sm formerrors"
              v-show="formerrors.msg"
              @click="formerrors.msg = ''"
            >
              <vs-alert
                color="warning"
                class="warning-alert reg-warning-alert no-border-radius"
                icon-pack="IntakePortal"
                icon="IP-information-button"
                active="true"
                >{{ formerrors.msg }}</vs-alert
              >
            </div>
          </div>
          <div class="popup-footer relative">
            
            <button
              @click="generateFormsLattersPopup = false;checkReloadPetition()"
              class="cancel"
              type="filled"
              color="dark"
            >
              Cancel
            </button>
            <vs-button
             
              color="success"
              @click="generateFormsAndLatters()"
              class="marl15 save"
              type="filled"
              >Generate</vs-button
            >
          </div>
        </div>
        <div></div>
        <figure v-if="generatingFiles" class="loader">
          <img src="@/assets/images/main/loader.gif" />
        </figure>
      </div>
    </div>

    
    <vs-popup
      class="Change_petition_wrap"
      v-if="reversion_fileuploadPopup"
      :title="
        checkProperty(petition, 'subTypeDetails', 'id') == 15
          ? 'Upload Audit Response'
          : 'Upload Revision ' + formLetterType + 's'
      "
      :active.sync="reversion_fileuploadPopup"
    >
    
      <div class="Change_petition upload_letter_others">
        <div class="vx-col w-full">
          <div class="vx-row form-container pad0"   @click="showTypeIdError=false" v-if="checkProperty(petition, 'subTypeDetails', 'id') == 15 && checkProperty(petitionDetails,'beneficiaryInfo','maritalStatus' ) !=1 && checkProperty(petitionDetails['dependentsInfo'] ,'spouse', 'h4Required')==true">
            <div class="custom-radio_wrap wf_radio">
              <label class="form_label pb-1 pl-4">Upload For<em >*</em></label>
              <ul class="custom-radio mb-1">
                 <li> 
                  <vs-radio   name="docusertype" @input="changedBeneficiarycheck" vs-value="Beneficiary" v-model="docUserType" class="w-full" >Beneficiary</vs-radio>
                 </li>
                  <li>
                     <vs-radio  name="docusertype" @input="changedBeneficiarycheck" vs-value="Dependent"  v-model="docUserType" class="w-full" >Dependent</vs-radio>
                   </li>
             </ul>
            </div>
            <span  class="text-danger text-sm ml-3"  v-show="showTypeIdError">Document Type is required</span>
          </div>
          <div class="vx-row form-container pad0 mt-3"  v-if="formLetterType=='Letter'  && false">
              <div class="custom-radio_wrap wf_radio">
              <label class="form_label pb-1 pl-4">Letter Type<em >*</em></label>
              <!----entityIds:[{"id":"'cover_letter'" ,"name":"Cover Letter"},{"id":'support_letter' ,"name":'Support Letter'}],
   -->
   
              <ul class="custom-radio mb-3">
                 <li> 
                  <vs-radio   name="entityId" @input="changedBeneficiarycheck" vs-value="cover_letter" v-model="entityId" class="w-full" >Cover Letter</vs-radio>
                 </li>
                  <li>
                     <vs-radio  name="entityId" @input="changedBeneficiarycheck" vs-value="support_letter"  v-model="entityId" class="w-full" >Support Letter</vs-radio>
                   </li>
             </ul>
             <span  class="text-danger text-sm ml-3"  v-show="showentityIdError"  >Letter Type is required</span>
            </div>
          </div>
          
         <div class="vx-row">
          <div class="vx-col w-full">
            <div v-for="(docData, index) in documentData" :key="index">
            <div class="vx-row">
              <div class="vx-col w-full">
                <vx-input-group class="form-input-group select-upload-group">
                  <div class="uploadsec_wrap">
                    <div class="w-full">
                      <file-upload
                        :accept="acceptedFiles"
                        v-model="version_documentUploaded"
                        class="file-upload-input mb-0"
                        style="height: 50px"
                        :name="'version_documents' + index"
                        :multiple="false"
                        v-validate="'required'"
                        label="Forms and Letters"
                        data-vv-as="Forms and Letters"
                        @input="doUpload(selectedDoc, version_documentUploaded)"
                      >
                        <img
                          class="file-icon"
                          src="@/assets/images/main/file-upload.svg"
                        />

                        Upload
                      </file-upload>

                      <span v-if="formLetterType == 'Form'" class="file-type"
                        >(File Type: PDF, Max file size: 1MB)</span
                      >
                      <span v-else class="file-type mb-0"
                        >(File Type: DOC, Max file size: 1MB)</span
                      >

                      <VuePerfectScrollbar class="scrollbardoc">
                        <div
                          class="uploded-files_wrap"
                          v-if="version_documentUploaded.length > 0"
                        >
                          <div
                            class="w-full"
                            v-for="(fil, fileindex) in version_documentUploaded"
                            :key="fileindex" 
                          >
                           <template v-if="checkProperty(fil, 'path') || checkProperty(fil, 'url')">
                            <div class="uploded-files">
                              <vx-input-group class="form-input-group">
                                <vs-input
                                  v-on:keyup="reversion_fileNameChenged(fileindex)"
                                  required
                                  class="w-full"
                                  :name="'fName' + index"
                                  v-model="version_documentUploaded[fileindex]['name']"
                                  data-vv-as="File Name"
                                />
                                <span
                                  class="text-danger text-sm"
                                  v-show="!version_documentUploaded[fileindex]['name']"
                                  >Please Enter file name</span
                                >
                                <span
                                  class="text-danger text-sm"
                                  v-show="errors.has('fName' + index)"
                                  >{{ errors.first("fName" + index) }}</span
                                >

                                <div
                                  class="delete"
                                  style="z-index: 999"
                                  @click="remove_reversion_file()"
                                >
                                  <img src="@/assets/images/main/cross.svg" />
                                </div>
                              </vx-input-group>
                            </div>
                           </template>
                          </div>
                        </div>
                      </VuePerfectScrollbar>
                    </div>
                  </div>
                </vx-input-group>
              </div>
            </div>
          </div>
          </div>
         </div>
        

         
        </div>
      </div>
      <div
        class="text-danger text-sm formerrors"
        v-show="formerrors.msg"
        @click="formerrors.msg = ''"
      >
        <vs-alert
          color="warning"
          class="warning-alert reg-warning-alert no-border-radius"
          icon-pack="IntakePortal"
          icon="IP-information-button"
          active="true"
          >{{ formerrors.msg }}</vs-alert
        >
      </div>

      <div class="popup-footer relative">
        <button
          @click="
            reversion_fileuploadPopup = false;
            formerrors.msg = '';
            selectedDocument = null;
          "
          class="btn cancel"
        >
          Cancel
        </button>
        <!-- v-bind:disble="disable_reversion_uploadBtn" -->
        <button
          class="btn save"
          v-bind:disabled="disable_reversion_uploadBtn"
          @click="updateDocument_Version()"
        >
          <figure v-if="fuploder" class="loader loader2">
            <img src="@/assets/images/main/loader.gif" />
          </figure>
          Upload
        </button>
      </div>
    </vs-popup>

     <modal
      name="showI140PopUp"
      classes="v-modal-sec"
      :min-width="200"
      :min-height="200"
      :scrollable="true"
      :reset="true"
      width="750px"
      height="auto"
    >
      <div class="v-modal applicable_boxes_modal-v2 checkbox_to_radio_change" >
      <div class="popup-header fromDetailsPage">
        <h2 class="popup-title" >I-140 Additional Questionnaire</h2>
        <span @click="showPopup=false;$modal.hide('showI140PopUp');updateReload=false"> 
          <em class="material-icons">close</em>
        </span>
      </div>        
      <form  @submit.prevent data-vv-scope="newI140Form" class="trackingform">
          <div class="form-container pb-0">
            <div class="vx-row" >
              <div class="vx-col w-full">
                <h6 class="title-header mb-2">This petition is being filed for<span class="info"> (Select only one option)</span></h6>
                <ul class="custom-radio mb-1" >
         
                  <li> 
                    <vs-radio  :name="'petitionFieldFor'"  :vs-value="'a'" v-model="i140AdditionalInfo.petitionBeingFieldFor" class="w-full" >
                      An alien of extraordinary ability. 
                    </vs-radio>
                  </li>
                  <li>
                    <vs-radio  :name="'petitionFieldFor'"   :vs-value="'b'"  v-model="i140AdditionalInfo.petitionBeingFieldFor" class="w-full" >
                      An outstanding professor or researcher.
                    </vs-radio>
                  </li>
                  <li>
                    <vs-radio  name="petitionFieldFor"   vs-value="c"  v-model="i140AdditionalInfo.petitionBeingFieldFor" class="w-full" >
                      A multinational executive or manager. A member of the professions holding an advanced degree
                       or an alien of exceptional ability (who is NOT seeking a National Interest Waiver (NIW)). 
                    </vs-radio>
                  </li>
                  <li>
                    <vs-radio  name="petitionFieldFor"   vs-value="d"  v-model="i140AdditionalInfo.petitionBeingFieldFor" class="w-full" >
                      Any other worker (requiring less than two years of training or experience). 
                    </vs-radio>
                  </li>
                  <li>
                    <vs-radio  name="petitionFieldFor"   vs-value="e"  v-model="i140AdditionalInfo.petitionBeingFieldFor" class="w-full" >
                      A professional (at a minimum, possessing a bachelor's degree or a foreign degree equivalent to a U.S. bachelor's degree). 
                    </vs-radio>
                  </li>
                  <li>
                    <vs-radio  name="petitionFieldFor"   vs-value="f"  v-model="i140AdditionalInfo.petitionBeingFieldFor" class="w-full" >
                      A skilled worker (requiring at least two years of specialized training or experience).
                    </vs-radio>
                  </li>
                  <li>
                    <vs-radio  name="petitionFieldFor"   vs-value="g"  v-model="i140AdditionalInfo.petitionBeingFieldFor" class="w-full" >
                      Any other worker (requiring less than two years of training or experience).
                    </vs-radio>
                  </li>
                  <li>
                    <vs-radio  name="petitionFieldFor"   vs-value="h"  v-model="i140AdditionalInfo.petitionBeingFieldFor" class="w-full" >
                      An alien applying for an NIW (who IS a member of the professions holding an advanced degree or an alien of exceptional ability).
                    </vs-radio>
                  </li>
                </ul>
                <input type="hidden" :name="'petitionFieldFr'" v-validate="'required'"  data-vv-as="petition is being filed for"  v-model="i140AdditionalInfo.petitionBeingFieldFor">
                <span class="text-danger text-sm" v-show="errors.has('newI140Form.petitionFieldFr')">*Petition type is required</span>
              </div>
              <div class="vx-col w-full mt-6 mb-4">
                <h6 class="title-header mb-2">This petition is being filed<span class="info"> (Select only one option)</span></h6>
                <ul class="custom-radio mb-1 d-flex" >
                  <li class="w-50"> 
                    <vs-radio  name="petitionBeing"  vs-value="aa" v-model="i140AdditionalInfo.petitionBeingField" class="w-full" >
                      To amend a previously filed petition. Previous Petition Receipt Number 
                    </vs-radio>
                  </li>
                  <li class="w-50">
                    <vs-radio  name="petitionBeing"   vs-value="bb"  v-model="i140AdditionalInfo.petitionBeingField" class="w-full" >
                      For the Schedule A, Group I or II designation. 
                    </vs-radio>
                  </li>
                </ul>
                <template v-if="i140AdditionalInfo.petitionBeingField == 'aa'">
                  <immiInput :display="true"  cid="prevPetiReceiptNumber" :formscope="'newI140Form'" v-model="i140AdditionalInfo.prevPetiReceiptNumber" 
                  :fieldName="'prevPetiReceiptNumber'"  :required="true" :maxCharacters="13"  label="Previous Petition Receipt Number" placeHolder="Previous Petition Receipt Number" />
                </template>
                <input type="hidden" :name="'petitionBeiField'" v-validate="'required'"  data-vv-as="petition is being filed for"  v-model="i140AdditionalInfo.petitionBeingField">
                <span class="text-danger text-sm" v-show="errors.has('newI140Form.petitionBeiField')">*Petition type is required</span>
              </div>
              <div class="vx-col w-full">
                <redioButtons :defaultError="true" :wrapclass="'md:w-full'" :required="true"   :cid="'anyOtherPetiOrApplications'"
                :formscope="'newI140Form'"  v-model="i140AdditionalInfo.anyOtherPetiOrApplications"
                fieldName="Field"  label="Are you filing any other petitions or applications with this Form I-140?"
                placeHolder="" />
                <template v-if="checkProperty(i140AdditionalInfo,'anyOtherPetiOrApplications') == 'Yes'">
                  <div class="form_group">
                    <label class="form_label">Select all applicable boxes</label>
                  <div class="con-select w-full">
                    
                  <multiselect v-model="i140AdditionalInfo.petiOrApplicAllApplicableBoxes" :options="filingFormsList" :multiple="true"
                  :hideSelected="false" :close-on-select="false" :clear-on-select="false" :preserve-search="true"
                  :select-label="'Select all applicable boxes'" placeholder="Select all applicable boxes" label="name" track-by="id" 
                  :preselect-first="false" :searchable="true"  >
                  <template slot="selection" slot-scope="{ values, isOpen }">
                    <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }} applicable box(s)
                      selected</span>
                    <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                  </template>
                </multiselect>
                </div>
                </div>
                </template>
                <template v-if="checkAdditionalInfo && checkProperty(i140AdditionalInfo,'anyOtherPetiOrApplications') == 'Yes'">
                  <immiInput :wrapclass="'md:w-full'" :display="true"  cid="petiOrApplicAllApplicableBoxOther" :formscope="'newI140Form'" v-model="i140AdditionalInfo.petiOrApplicAllApplicableBoxOther" 
                  :fieldName="'petiOrApplicAllApplicableBoxOther'"  :required="true"  label="Provide an explanation in Part 11. Additional Information." placeHolder="Provide an explanation in Part 11. Additional Information." />
                </template>
                <redioButtons :defaultError="true" :wrapclass="'md:w-full'" :required="true"   :cid="'removalProceedings'"
                :formscope="'newI140Form'"  v-model="i140AdditionalInfo.removalProceedings"
                fieldName="removalProceedings"  label="Is the person for whom you are filing in removal proceedings?"
                placeHolder="" />
                <redioButtons :defaultError="true" :wrapclass="'md:w-full'" :required="true"   :cid="'immiVisaPetitionOrPerson'"
                :formscope="'newI140Form'"  v-model="i140AdditionalInfo.immiVisaPetitionOrPerson"
                fieldName="immiVisaPetitionOrPerson"  label="Has any immigrant visa petition ever been filed by or on behalf of this person?"
                placeHolder="" />
                <redioButtons :defaultError="true" :wrapclass="'md:w-full'" :required="true"   :cid="'supportOfAnotherFormi140'"
                :formscope="'newI140Form'"  v-model="i140AdditionalInfo.supportOfAnotherFormi140"
                fieldName="supportOfAnotherFormi140"  label="Are you filing this petition without an original labor certification because the original
                 labor certification was previously submitted in support of another Form I-140? "
                placeHolder="" />
                <redioButtons :defaultError="true" :wrapclass="'md:w-full'" :required="true"   :cid="'departmentOfLabor'"
                :formscope="'newI140Form'"  v-model="i140AdditionalInfo.departmentOfLabor"
                fieldName="departmentOfLabor"  label="If you are filing this petition without an original labor certification, are you requesting that U.S.
                 Citizenship and Immigration Services (USCIS) request a duplicate labor certification from the Department of Labor (DOL)?"
                placeHolder="" />
                <!-- <redioButtons :defaultError="true" :wrapclass="'md:w-full'" :required="true"   :cid="'updatePreEmployDetails'"
                :formscope="'newI140Form'"  v-model="updatePreEmployDetails" helpText="If selects 'No', Need to update previous employment details in the questionnaire"
                fieldName="updatePreEmployDetails"  label="Is beneficiary previous employment is matching with PERM job details?"
                placeHolder="" /> -->
                <div class="form_group custom-radio_wrap filing_fee_type d-block">
                  <label class="mb-2 d-block" style="font-size: 14px;">To fill Letters, consider beneficiary employment details from *</label>
                  <ul class="custom-radio" vs-type="flex" vs-align="center">
                    <li style="margin-bottom: -15px;"> 
                      <vs-radio    name="manual_entry"  vs-value="perm" v-model="i140AdditionalInfo.considerBnfEmpInfoForLetters" class="w-full"
                        ><span ref="manual_entry">PERM</span>
                      </vs-radio> 
                    </li>
                    <li style="margin-bottom: -15px;">
                      <vs-radio   ref="pre_defined"  name="manual_entry"  vs-value="questionnaire"   v-model="i140AdditionalInfo.considerBnfEmpInfoForLetters" class="w-full"
                      > <span ref="pre_defined">Questionnaire</span></vs-radio > 
                    </li>
                  </ul>
                  <input type="hidden" :name="'considerBnfEmpInfoForLettes'" v-validate="'required'"  data-vv-as="petition is being filed for"  v-model="i140AdditionalInfo.considerBnfEmpInfoForLetters">
                <span class="text-danger text-sm" v-show="errors.has('newI140Form.considerBnfEmpInfoForLettes')">*Field is required</span>
                </div>
              </div>
            </div>
          </div>
          <div @click="formerrors.msg=''" class="text-danger text-sm formerrors" v-if="formerrors.msg!=''">
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal" icon="IP-information-button"
             active="true">{{ formerrors.msg }}</vs-alert>
          </div>
          <div class="popup-footer relative">
          <span class="loader" v-if="loadingI140"><img src="@/assets/images/main/loader.gif"></span>
            <vs-button color="dark" class="cancel" type="filled" @click="$modal.hide('showI140PopUp');updateReload=false">Cancel</vs-button>
            <template v-if="updatePreEmployDetails == 'No'">
              <vs-button color="success" 
              @click="redirectQuestionnaire()" class="save" type="filled">Update Employment Details</vs-button>
            </template>
            <template v-else>
              <vs-button color="success" v-if="checkProperty(petition, 'i140AdditionalInfo') && checkProperty(petition, 'i140AdditionalInfo','petitionBeingFieldFor')"
                :disabled="loadingI140" @click="submiti140Form(false);updateReload=false"  class="save" type="filled">Generate</vs-button>
              <vs-button color="success" :disabled="loadingI140" @click="submiti140Form(true)"  class="save" type="filled">
                <template v-if="checkProperty(petition, 'i140AdditionalInfo') && checkProperty(petition, 'i140AdditionalInfo','petitionBeingFieldFor')">
                Update and Generate
                </template>
                <template v-else>Submit</template>
              </vs-button>
          </template>
          </div>
      </form>
      </div>
    </modal>  
  </div>
</template>

<script>
import selectField from "@/views/forms/fields/simpleselect.vue";
 import immiInput from "@/views/forms/fields/simpleinput.vue";
import redioButtons from "@/views/forms/fields/redioButtons.vue";
import JQuery from "jquery";
import immiuploader from "@/views/forms/fields/fileupload.vue";
const formatter = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  minimumFractionDigits: 2,
});
import casedocumentslist from "@/views/common/casedocuments.vue";
import FileUpload from "vue-upload-component/src";
import moment from "moment";
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import Paginate from "vuejs-paginate";
import NoDataFound from "@/views/common/noData.vue";
import docType from "@/views/common/docType.vue";
import { XIcon } from "vue-feather-icons";
import Vue from 'vue';
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import * as _ from "lodash";

export default {
  provide() {
    return {
      parentValidator: this.$validator,
    };
  },
  props: {
    // currentCaseDetails: {
    // type: Array,
    // default: new Array(),
    //},
    workFlowDetails: {
      type: Object,
      default: null,
    },
    lcaDetails: {
      type: Object,
      default: null,
    },
    configDetails: null,
    currentRole: null,
    currentUser: null,
    petition: {
            type: Object,
            default: null,
        },

  },
  components: {
    immiInput,
    redioButtons,
    selectField,
    casedocumentslist,
    immiuploader,
    NoDataFound,
    Paginate,
    FileUpload,
    VuePerfectScrollbar,
    docType,
    XIcon,
  },
  methods: {
    showHistoryComment(item){
      this.$emit('showHistoryComment', item)
    },
    getcaseHistory() {
      if (this.checkProperty(this.petition, '_id') && this.checkProperty(this.petition, 'completedActivities') && this.checkProperty(this.petition, 'completedActivities', 'length')>0 && 
      this.petition['completedActivities'].indexOf('REQUEST_PETITIONER_SIGN')>-1) {
        this.$store.dispatch("petitionhistory", this.checkProperty(this.petition, '_id')).then((response) => {
          if(response && this.checkProperty(response, 'result') && this.checkProperty(response, 'result', 'list') && this.checkProperty(response['result'], 'list', 'length')>0){
            let list = response.result.list;
            let templist = _.filter(list,(item)=>{
              if(_.has(item, 'action') && item['action'] == 'REQUEST_PETITIONER_SIGN'){
                return item;
              }
            });
            if(templist && this.checkProperty(templist, 'length')>0){
              templist.sort((a, b) => b.createdOn - a.createdOn);
              this.petitionhistory = templist[0];
            }
            
            //this.petitionhistory = response.result.list;
          }
        });
      }
    },
    selct_all(callFromSellectAll=false){
      
      setTimeout(()=>{ 
      
      let self =this;
      let totalCount =0;
      let selectedCount =0;
      let unSelectedCount =0;
     
     if (
      self.checkProperty(self.masterFormsAndLatters, "audit_response", "length") > 0 &&
      self.checkProperty(self.petition, "typeDetails", "id") == 3 &&
      self.checkProperty(self.petition, "subTypeDetails", "id") == 15
      ) {
        _.map(self.masterFormsAndLatters["audit_response"], (obj) => {
          totalCount =totalCount+1;
          if(callFromSellectAll){

            if(self.selectAll){
             obj['isSelectedCurrentVersion'] = true;
             
            }else{
              obj['isSelectedCurrentVersion'] = false;
              
            }

          }else{

            if(self.checkProperty(obj,'isSelectedCurrentVersion')){
              selectedCount = selectedCount+1;
            }else{
              unSelectedCount =unSelectedCount+1
            }
          }
        });
      }else{
        if (self.checkProperty(self.masterFormsAndLatters, "beneficiary", "length") > 0) {
          _.map(self.masterFormsAndLatters["beneficiary"], (obj) => {
            totalCount =totalCount+1;
            if(callFromSellectAll){

                if(self.selectAll){
                obj['isSelectedCurrentVersion'] = true;
                
                }else{
                  obj['isSelectedCurrentVersion'] = false;
                  
                }

              }else{

                if(self.checkProperty(obj,'isSelectedCurrentVersion')){
                  selectedCount = selectedCount+1;
                }else{
                  unSelectedCount =unSelectedCount+1
                }
            }
          });
        }
        if (self.checkProperty(self.masterFormsAndLatters, "spouse", "length") > 0) {
          _.map(self.masterFormsAndLatters["spouse"], (obj) => {
            totalCount =totalCount+1;
            if(callFromSellectAll){

              if(self.selectAll){
                  obj['isSelectedCurrentVersion'] = true;

              }else{
                obj['isSelectedCurrentVersion'] = false;
                
              }

              }else{

                if(self.checkProperty(obj,'isSelectedCurrentVersion')){
                  selectedCount = selectedCount+1;
                }else{
                  unSelectedCount =unSelectedCount+1
                }
            }
          });
        }

        if (
          self.checkProperty(    Object.entries(self.masterFormsAndLatters["child"]),  "length"   ) > 0
        ) {
          _.map(Object.entries(self.masterFormsAndLatters["child"]), (val, key) => {
            if (
              self.checkProperty(val, "length") > 1 &&
              self.checkProperty(val[1], "length") > 0
            ) {
              _.map(val[1], (obj) => {
                totalCount =totalCount+1;
                 if(callFromSellectAll){

                    if(self.selectAll){
                        obj['isSelectedCurrentVersion'] = true;

                    }else{
                      obj['isSelectedCurrentVersion'] = false;
                      
                    }

                  }else{

                    if(self.checkProperty(obj,'isSelectedCurrentVersion')){
                      selectedCount = selectedCount+1;
                    }else{
                      unSelectedCount =unSelectedCount+1
                    }
                }
              });
            }
          });
        }
      }
      if(!callFromSellectAll){
        if(selectedCount>0 &&  unSelectedCount== 0 &&  selectedCount ==totalCount ){
          self.selectAll =true;
        }else{
          self.selectAll =false;
        }

      }

  
    },100);
  
            },
    redirectQuestionnaire(){
      let obj= {
        currentTab : 'employment'
      }
      const string = JSON.stringify(obj) // convert Object to a String
      this.encodedString = btoa(string) // Base64 encode the String
      let routedId = this.checkProperty(this.petition, '_id')
      this.$router.push({ path: `/questionnaire/${routedId}` ,query: {'filter':this.encodedString} }).catch(err => {});
    },
    checkReloadPetition(callFromErr=false){
      if(this.checkProperty(this.petition, "typeDetails", "id") == 3 && this.checkProperty(this.petition, "subTypeDetails", "id") == 16 && 
      (this.updateReload || callFromErr ) ){
        this.$emit("updatepetition", "Forms and Letters");
      }
    },
    submiti140Form(updateCall = true){
        this.$validator.validateAll('newI140Form').then((result) => {
          if(result){
            if(updateCall){
              let payload={
                petitionId: this.checkProperty(this.petition, '_id'),
                i140AdditionalInfo:{
                  petitionBeingFieldFor: "",
                  petitionBeingField: "", 
                  prevPetiReceiptNumber: "",
                  anyOtherPetiOrApplications: "",
                  petiOrApplicAllApplicableBoxes: [],
                  petiOrApplicAllApplicableBoxOther: "",
                  removalProceedings: "",
                  immiVisaPetitionOrPerson: "",
                  supportOfAnotherFormi140: "",
                  departmentOfLabor: "",
                  considerBnfEmpInfoForLetters:''
                },
              }
              if(this.checkProperty(this.i140AdditionalInfo,'anyOtherPetiOrApplications') != 'Yes'){
                this.i140AdditionalInfo.petiOrApplicAllApplicableBoxes = [];
                this.i140AdditionalInfo.petiOrApplicAllApplicableBoxOther = '';
              }
              if(this.checkAdditionalInfo == false){
                this.i140AdditionalInfo.petiOrApplicAllApplicableBoxOther = '';
              }
              if(this.i140AdditionalInfo.petitionBeingField != 'aa'){
                this.i140AdditionalInfo.prevPetiReceiptNumber = ''
              };
              this.loadingI140= true;
              this.updateReload = false;
              payload['i140AdditionalInfo'] = _.cloneDeep(this.i140AdditionalInfo);;
              if(this.checkProperty(this.i140AdditionalInfo,'petiOrApplicAllApplicableBoxes') && this.checkProperty(this.i140AdditionalInfo,'petiOrApplicAllApplicableBoxes','length')>0){
                payload['i140AdditionalInfo']['petiOrApplicAllApplicableBoxes'] =  this.i140AdditionalInfo['petiOrApplicAllApplicableBoxes'].map(item =>item.id);
              }
              let path = '/petition/update-questionnaire-form-i140-form'
              this.$store.dispatch('commonAction',{data:payload,'path':path}).then((response)=>{
                this.showToster({message:response.message,isError:false });
                this.updateReload = true;
                this.getMasetFormsAndLatters(true);
                this.$modal.hide('showI140PopUp');
                this.loadingI140= false;
                setTimeout(()=>{
                  this.loadingI140= false;
                })
              }).catch((err)=>{
                this.loadingI140= false;
                this.formerrors.msg = err;
              })
            }else{
              this.updateReload = false;
              this.$modal.hide('showI140PopUp');
              this.getMasetFormsAndLatters(true);
            }
          }
        })
    },
    openI140Form(){
      if(_.has(this.petition,'i140AdditionalInfo') && this.checkProperty(this.petition, 'i140AdditionalInfo') 
      && this.checkProperty(this.petition, 'i140AdditionalInfo','petitionBeingFieldFor')){
        this.i140AdditionalInfo = _.cloneDeep(this.petition['i140AdditionalInfo'])
        if(this.i140AdditionalInfo && this.checkProperty(this.i140AdditionalInfo,'petiOrApplicAllApplicableBoxes') 
        && this.checkProperty(this.i140AdditionalInfo,'petiOrApplicAllApplicableBoxes','length')>0){
          let list = [];
           _.forEach(this.i140AdditionalInfo['petiOrApplicAllApplicableBoxes'],(item)=>{
            let findObj = _.find(this.filingFormsList,({'id':item}));
            if(findObj){
              list.push(findObj)
            }
          })
          this.i140AdditionalInfo['petiOrApplicAllApplicableBoxes'] = list;
        }
      }else{
        this.i140AdditionalInfo={
          petitionBeingFieldFor: "",
          petitionBeingField: "", 
          prevPetiReceiptNumber: "",
          anyOtherPetiOrApplications: "",
          petiOrApplicAllApplicableBoxes: [],
          petiOrApplicAllApplicableBoxOther: "",
          removalProceedings: "",
          immiVisaPetitionOrPerson: "",
          supportOfAnotherFormi140: "",
          departmentOfLabor: "",
          considerBnfEmpInfoForLetters:''
        }
      }
      this.updatePreEmployDetails = '';
      this.updateReload = false;
      this.loadingI140= false;
      this.formerrors.msg = '';
      this.$modal.show('showI140PopUp')
    },
    setdocUserType(docUserType = 'Beneficiary'){
      setTimeout(()=>{
        this.docUserType = docUserType;

      },300);
    },
    
    splitChildrensFormsAndLetters(){
      this.childrenFormsAndLetters ={};
     // depType //child
     let allChildList  =_.filter(this.formsAndLettersList, { "depType":'child',"docUserType":'Dependent' } );
     if(allChildList && allChildList.length>0){
      this.childrenFormsAndLetters = _.groupBy(allChildList ,'depLabel');
     }
      

    },
    getContent(){
      let self = this
      setTimeout(() => {
        try{
        if(self.$refs['NoDataFoundReff']){

          self.$refs['NoDataFoundReff'].updateLoading(false);

        }


      }catch(err){
        
        
        
      }
      }, 100);
      return '';
    },
    // this.formLetterType = "Form";
    //this.formLetterType = "Letter";
    changeTab(tab ,document ,docUserType='Beneficiary') {
      this.resetForms();
     // this.showPreviousVersions =false;
      this.fileuploadPopup =false;
   //   this.reversion_fileuploadPopup =false;
      this.selectedDocument = document;
      this.$store.commit("selectedForEditDocument", document);
      this.generatingFiles = false;
      Object.assign(this.formerrors, { msg: "" });
      //'Letter' 'Audit Response'
      if (tab == "Form") {
        this.formLetterType = "Form";
        
        this.acceptedFiles = "application/pdf";
      } else if (tab == "Letter") {
        this.formLetterType = "Letter";
        this.acceptedFiles =
          "application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document";
      } else if (this.checkProperty(this.petition, "subTypeDetails", "id") == 15) {
        this.acceptedFiles =
          "application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document";
      } else {
        this.formLetterType = "Audit Response";
        this.acceptedFiles =
          "application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document";
      }
      this.togleFileUpload = true;

   //   this.parentId = "";
      this.formerrors.msg = "";
      this.documentData = [{ type: "Forms, Letters and Others", documentUploaded: [] }];
     // this.getFormsAndLetters();
      this.docUserType = docUserType //'Beneficiary'
      this.entityId ='cover_letter';
    },
    changedOffice(callFromMounted=false) {
      
     
     // this.selectedOffice
     this.courierAddress ='';
     this.isValiedCourierAddress = false;
    
     if(this.selectedCourier && this.selectedOffice  && this.checkProperty(this.selectedOffice ,'addressConfig' )){
      let selectedCourierCenter = _.find(  this.masterCourierList ,{"id":this.selectedCourier});
      let msg ="Service Center Address is not available.";
      if(selectedCourierCenter && this.checkProperty(selectedCourierCenter ,"name")){
        msg ="Service Center Address is not available for "+selectedCourierCenter['name'];
      }

     
      let addressConfig = this.checkProperty(this.selectedOffice ,'addressConfig');
      if(addressConfig && this.checkProperty(addressConfig ,'length')>0 ){
        let matchedCourier = _.find(addressConfig ,{"courierId":this.selectedCourier});
       // alert(JSON.stringify(matchedCourier))
        if(matchedCourier && _.has(matchedCourier ,'address')){
          this.courierAddress = matchedCourier['address'];
          this.isValiedCourierAddress =true;
         

        }else{
          if(!callFromMounted){
             this.showToster({message:msg,isError:true });
          }
        }

      }else{
      
       if(!callFromMounted){
        this.showToster({message:msg,isError:true });
       }

        
       
      }

     }else{

      if(!callFromMounted){
        let msg = 'Service Center is required'
        if(!this.selectedCourier){
          msg = 'Courier Center is required'
        }
           //  this.$validator.validateAll();
             this.showToster({message:msg,isError:true });
          }


     }



    },
    getMasetFormsAndLatters(generateAction = false) {
      ///petition-config/details
          this.selectedCourier ='';
          this.courierAddress='';
          this.isValiedCourierAddress = false;

      if (generateAction) {
        this.loadingFormLatters = true;
        this.getCourierList();
      }

      let postData = { petitionId: "" };
      postData["petitionId"] = this.checkProperty(this.petition, "_id");

      let path = "/petition/get-forms-and-letters-to-generate";
      if (
        this.checkProperty(this.petition, "typeDetails", "id") == 3 &&
        this.checkProperty(this.petition, "subTypeDetails", "id") == 15
      ) {
        path = "/perm/get-forms-and-letters-to-generate";
        postData["docTypeIds"] = ["audit_response"];
      }

      this.$store
        .dispatch("commonAction", { data: postData, path: path })
        .then((response) => {
          this.masterFormsAndLatters = {
            beneficiary: [],
            spouse: [],
            child: {},
            audit_response: [],
          };

          let childCouments = [];
          if (this.checkProperty(response, "length") > 0) {
            _.forEach(response, (item) => {
              item = Object.assign(item, {
                isSelectedNewVersion: false,
                isSelectedCurrentVersion: true,
                availableNewVersion: false,
                priorFormsInformation: null,
                isedited: false,
              });
              //this.formsAndLettersList
              let priorFormsEffectiveDays = 7;
              if (this.checkProperty(this.configDetails, "priorFormsEffectiveDays") > 0) {
                priorFormsEffectiveDays = this.configDetails["priorFormsEffectiveDays"];
              }
              //check document is edited
              if (this.checkProperty(item, "entityId")) {
                let generatedEditedItem = _.find(this.formsAndLettersList, {
                  editedDocument: true,
                  entityId: item["entityId"],
                });
                if (generatedEditedItem) {
                  item["isedited"] = true;
                }
              }

              if (
                _.has(item, "effectiveDate") &&
                this.checkProperty(item, "effectiveDate") &&
                this.checkProperty(item, "documentRef", "name")
              ) {
                let today = moment();
                let effectiveDate = moment(item["effectiveDate"]);
                let priorFormsInformation = moment().subtract(
                  priorFormsEffectiveDays,
                  "days"
                );
                if (effectiveDate.isAfter(today, "day")) {
                  if (today.isSameOrAfter(priorFormsInformation, "day")) {
                    item["availableNewVersion"] = true;
                    item["priorFormsInformation"] = priorFormsInformation;
                  } else {
                    _.forEach(item["documentRef"], (val, key) => {
                      item[key] = val;
                    });
                  }
                }
              }

              //beneficiary Doduments

              if (this.checkProperty(item, "type") == "audit_response") {
                this.masterFormsAndLatters["audit_response"].push(item);
              }
              if (this.checkProperty(item, "depType") == "beneficiary") {
                this.masterFormsAndLatters["beneficiary"].push(item);
              } else if (this.checkProperty(item, "depType") == "spouse") {
                this.masterFormsAndLatters["spouse"].push(item);
              } else if (this.checkProperty(item, "depType") == "child") {
                if (_.has(this.masterFormsAndLatters["child"], item["depLabel"])) {
                  this.masterFormsAndLatters["child"][item["depLabel"]].push(item);
                } else {
                  this.masterFormsAndLatters["child"][item["depLabel"]] = [];
                  this.masterFormsAndLatters["child"][item["depLabel"]].push(item);
                }
              }
            });

            this.masterFormsAndLatters = _.cloneDeep(this.masterFormsAndLatters);
          } else {
            this.masterFormsAndLatters = _.cloneDeep(this.masterFormsAndLatters);
          }

          
         
          
          
          this.loadingFormLatters = false;
          this.generateFormsLattersPopup = generateAction;
          this.selectAll = generateAction;
         
          
          
          this.updateLoading(false);
          setTimeout(()=>{ this.updateLoading(false); setTimeout(()=>{ this.updateLoading(false);  },10);
          
        
          

        },10);
        })
        .catch((err) => {
          if (generateAction) {
            this.showToster({ message: err, isError: true });
          }
          this.checkReloadPetition(true)

          this.generateFormsLattersPopup = false;
          this.masterFormsAndLatters = {
            beneficiary: [],
            spouse: [],
            child: {},
            audit_response: [],
          };

          this.masterFormsAndLatters = _.cloneDeep(this.masterFormsAndLatters);

          this.loadingFormLatters = false;
          this.updateLoading(false);
          setTimeout(()=>{
            this.updateLoading(false);
          },10);
        });
    },
    getCourierList(){

let postdata = {};
this.$store
        .dispatch("getList", { data: postdata, path: "/tracking/courierlist" }).then((response) => {
            if (this.checkProperty(response, "list")) {
                 this.masterCourierList = response['list'];
                 this.courierListTemp = response['list'];
            }

 
 
  if(this.checkProperty(this.petitionDetails, "defaultCourierIds" ,"length")>0){
    this.courierListTemp = _.filter( this.masterCourierList,(itm)=>{
      return this.petitionDetails['defaultCourierIds'].indexOf(itm.id)>-1
    });
  }
  if(this.courierListTemp.length==1){
    this.selectedCourier = this.courierListTemp[0]['id'];
   
    this.showCourier =false;
  }else if(this.courierListTemp.length>1){


   
            let fedexItem = _.find(this.courierListTemp ,{ "id":2});
            if(_.has(fedexItem ,'code')){
              const $ = JQuery;
              
              $("#courier_"+fedexItem['code']).trigger('click');
              this.selectedCourier = fedexItem['id']

            }else{
              this.selectedCourier = this.courierListTemp[0]['id'];
            }
           
            this.showCourier =true;
            

          

  }
  this.changedOffice(true);
  

});

},
    changedBeneficiarycheck(){
    
      //bendocUserType
    },
    resetForms(){
      this.showentityIdError=false;
      this.showTypeIdError =false;
      this.entityId='cover_letter';  
      
      this.fuploder = false;
     // this.docUserType ='Beneficiary';
      this.$validator.reset();
     
        //let _self =this;
         
      // setTimeout(()=>{
      //     try{
      //       _self.$refs['bendocUserType'].click();
      //     }catch(err){
      //     alert(err)
      //     }
      // },100);
      
    },
    togglePreviousVersions(category=''){
     // alert()
      if( this.showPreviousVersions){
        this.showPreviousVersions =false;
      }else{
        this.showPreviousVersions = true;
      }  
      if(category){
        if(this.showPreviousVersionsList.indexOf(category) >-1){
          this.showPreviousVersionsList = _.filter(this.showPreviousVersionsList ,(item)=>{
            return category !=item
          })
        }else{
          this.showPreviousVersionsList.push(category);
        }
       

      }    

    },
    copyingData() {
      var data = _.merge(this.petitionDetails, this.petition);
      this.petitionDetails = _.cloneDeep(data);
    },
    uploadAdv(fils, category) {
      let model = _.clone(fils);
      this.fvalue = [];
      let mapper = model.map(
        (item) =>
          (item = {
            name: item.name,
            file: item.file ? item.file : null,
            url: item.url ? item.url : "",
            path: item.path ? item.path : "",
            isNew: item.isNew ? item.isNew : false,
            status: item.status === false || item.status === true ? item.status : true,
            mimetype: item.type ? item.type : item.mimetype,
          })
      );
      if (mapper.length > 0) {
        this.filesUploading = true;
        _.map(this.docsLists, (obj) => {
          if (obj.key == category) {
            obj["loading"] = true;
          }
        });
        let count = 0;
        mapper.forEach((doc, index) => {
          if (doc.file) {
            let formData = new FormData();
            formData.append("files", doc.file);
            formData.append("secureType", "private");
            formData.append("getDetails", true);
            this.$store.dispatch("uploadS3File", formData).then((response) => {
              response.data.result.forEach((urlGenerated) => {

                if(_.has(urlGenerated ,'size' )){
                  doc['size'] = urlGenerated['size'];
                }
                doc.isNew = true;
                doc.url = urlGenerated['path'];
                doc.path = urlGenerated['path'];
                delete doc.file;
                mapper[index] = doc;
              });
              this.petitionDetails.recruitmentInfo.documents[category].push(doc);

              count = count + 1;
              if (mapper.length >= count) {
                this.filesUploading = false;
                _.map(this.docsLists, (obj) => {
                  if (obj.key == category) {
                    obj["loading"] = false;
                  }
                });
              }
            });
          }
        });
        model.splice(0, mapper.length, ...mapper);
      }
    },

    //Approve - reject Documents
    openApproveOrRejectDocs(action = "") {
      this.formErrors = "";
      this.comments = "";
      //this.loading = false;
      this.approveOrRejectDocs = true;
      this.approveOrRejectDocsTitle = "Approve Documents";
      this.selectedAction = action;

      if(this.selectedAction == 'REJECT_BY_DOC_MANAGER'){
        this.approveOrRejectDocsTitle = "Reject Documents";
      }
      if(this.selectedAction == 'APPROVED_BY_DOC_MANAGER'){
        this.approveOrRejectDocsTitle = "Approve Documents";
      }
      this.$validator.reset();
    },
    approveOrRejectDocsAction(action = "") {
      this.approveOrRejectDocs = true;
     this.selectedAction = action;
      this.formErrors = "";

      this.$validator.validateAll("approveOrRejectDocsForm").then((result) => {
        if (
          result &&
          ["APPROVED_BY_DOC_MANAGER", "REJECT_BY_DOC_MANAGER"].lastIndexOf(
            this.selectedAction
          ) > -1
        ) {
          var postData = {
            petitionId: this.checkProperty(this.petition, "_id"),
            typeName: this.checkProperty(this.petition, "typeDetails", "name"),
            subTypeName: this.checkProperty(this.petition, "subTypeDetails", "name"),
            comment: this.comments, // Required on APPROVED_BY_DOC_MANAGER and REJECT_BY_DOC_MANAGER
            action: this.selectedAction, //"UPLOAD_BY_DOC_EXECUTIVE",//APPROVED_BY_DOC_MANAGER, REJECT_BY_DOC_MANAGER
            today: moment().format("YYYY-MM-DD"),
          };
          //this.loading = true;
          this.$store
            .dispatch("commonAction", {
              data: postData,
              path: "/petition/manage-offshore-document-upload",
            })
            .then((response) => {
              this.approveOrRejectDocs = false;
              this.showToster({ message: response.message, isError: false });
              this.reloadWallList();
            })
            .catch((error) => {
              this.formErrors = error;
              // this.loading = false;
            });
        }
      });
    },
    reloadWallList() {
      setTimeout(() => {
        //this.loading = false;
        this.$emit("rloadActionWidjet");
      }, 100);
    },
    restoreDocument(parentId, document) {
      // this.parentId = parentId;

      this.disable_uploadBtn = false;
      this.uploadFinalMainDocuments = [];

      this.disable_reversion_uploadBtn = false;
      this.rfuploder = false;
      this.version_documentUploaded = [];
      this.version_documentUploaded.push(document);
      this.documentId = parentId;
      this.parentId =parentId;
      this.updateDocument_Version(true);
    },

    //<!----'isSelectedNewVersion':false ,"isSelectedCurrentVersion" selectDocument--->
    selectDocument(document, type = "") {
      let self =this;
      setTimeout(() => {
        if (
          this.checkProperty(document, "isSelectedNewVersion") &&
          type == "isSelectedNewVersion"
        ) {
          document["isSelectedCurrentVersion"] = false;
        } else if (
          this.checkProperty(document, "isSelectedCurrentVersion") &&
          type == "isSelectedCurrentVersion"
        ) {
          document["isSelectedNewVersion"] = false;
        }
       
        
      }, 1);
     
      //this.masterFormsAndLatters  =_.cloneDeep(this.masterFormsAndLatters);
    },
   
    openGenerateFormsLattersPopup() {
      if (
        this.petition["permId"] == null &&
        this.checkProperty(this.petition, "typeDetails", "id") == 3 &&
        this.checkProperty(this.petition, "subTypeDetails", "id") == 16
      ) {
        if (!this.checkProperty(this.petition, "jobDetails", "jobTitle")) {
          this.$store.dispatch("setPetitionTab", "PERM-INFO");
          this.showToster({ message: "Job Details are required", isError: true });
          // this.$emit("updatepetition" ,'PERM-INFO');
          return false;
        }
      }

      this.generatingFiles = false;
      Object.assign(this.formerrors, { msg: "" });

      this.regeneratingFormAndLetter = false;
      if(this.checkProperty(this.petition, "typeDetails", "id") == 3 &&
        this.checkProperty(this.petition, "subTypeDetails", "id") == 16){
          this.openI140Form();
      }else{
        this.getMasetFormsAndLatters(true);
      }
      //alert(" shfs sdf ");
      
    },
    generateFormsAndLatters() {
    //  this.changedOffice(false);
      if(this.isValiedCourierAddress==false){
       
        this.changedOffice(false);
        return false;
      }
      let self = this;
     let  hasG28Form =false
      Object.assign(this.formerrors, { msg: "" });

      let selectedItems = [];
      // _.filter(this.masterFormsAndLatters ,{isSelectedNewVersion:true});
      //'isSelectedNewVersion':false ,"isSelectedCurrentVersion" availableNewVersion masterFormsAndLatters
      //get selected beneficiary documents
      let findSelectedItems = (item) => {

        if(self.checkProperty(item,'path') && self.checkProperty(item,'docTypeId')=='g-28' ){
          hasG28Form = true;
        }
        if (
          this.checkProperty(this.petition, "typeDetails", "id") == 3 &&
          this.checkProperty(this.petition, "subTypeDetails", "id") == 15
        ) {
          item["docTypeId"] = "audit_report";
          item["type"] = "Audit Response";
        }

        if (
          this.checkProperty(item, "isSelectedNewVersion") ||
          this.checkProperty(item, "isSelectedCurrentVersion")
        ) {
          if (this.checkProperty(item, "availableNewVersion")) {
            if (item["isSelectedCurrentVersion"] && !item["isSelectedNewVersion"]) {
              //get path from doc ref
              _.forEach(item["documentRef"], (val, key) => {
                item[key] = val;
              });
              selectedItems.push(item);
            } else if (
              !item["isSelectedCurrentVersion"] &&
              item["isSelectedNewVersion"]
            ) {
              selectedItems.push(item);
            }
          } else {
            selectedItems.push(item);
          }
        }
      };

      if (
        this.checkProperty(this.masterFormsAndLatters, "audit_response", "length") > 0 &&
        this.checkProperty(this.petition, "typeDetails", "id") == 3 &&
        this.checkProperty(this.petition, "subTypeDetails", "id") == 15
      ) {
        _.forEach(this.masterFormsAndLatters["audit_response"], (obj) => {
          findSelectedItems(obj);
        });
      }
      if (this.checkProperty(this.petition, "subTypeDetails", "id") != 15) {
        if (this.checkProperty(this.masterFormsAndLatters, "beneficiary", "length") > 0) {
          _.forEach(this.masterFormsAndLatters["beneficiary"], (obj) => {
            findSelectedItems(obj);
          });
        }
        if (this.checkProperty(this.masterFormsAndLatters, "spouse", "length") > 0) {
          _.forEach(this.masterFormsAndLatters["spouse"], (obj) => {
            findSelectedItems(obj);
          });
        }

        if (
          this.checkProperty(
            Object.entries(this.masterFormsAndLatters["child"]),
            "length"
          ) > 0
        ) {
          _.forEach(Object.entries(this.masterFormsAndLatters["child"]), (val, key) => {
            if (
              this.checkProperty(val, "length") > 1 &&
              this.checkProperty(val[1], "length") > 0
            ) {
              _.forEach(val[1], (doc) => {
                findSelectedItems(doc);
              });
            }
          });
        }
      }

      if (!this.checkProperty(this.selectedOffice, "id")) {
        Object.assign(this.formerrors, { msg: "Select Sevice Center" });

         this.showToster({ message: "Select Sevice Center", isError: true });
        return false;
      }

      if (selectedItems.length <= 0) {
        Object.assign(this.formerrors, {
          msg: "Select atleast one document to generate.",
        });
        this.showToster({ message: "Select atleast one document to generate.", isError: true });
        return false;
      }
      let postData = {
        petitionId: self.petition._id,
        today: moment().format("YYYY-MM-DD"),
        uploadedformsAndLetters: self.newFormsAndLetters,
        serviceCenter: self.selectedOffice,
        serviceCenterId: self.selectedOffice["id"],
        selectedFormsAndLetters: selectedItems,
        hasG28Form:hasG28Form
      };
      if (this.checkIsloginUserDoce) {
        postData = Object.assign(postData, { uploadByExecutive: true });
      }
      
      if(this.selectedCourier){
        postData = Object.assign(postData, { "finalCourierId": this.selectedCourier });
      }
      this.generatingFiles = true;
      let path = "/petition/generate-forms-and-letters";
      if (
        this.checkProperty(this.petition, "typeDetails", "id") == 3 &&
        this.checkProperty(this.petition, "subTypeDetails", "id") == 15
      ) {
        path = "/perm/generate-forms-and-letters";
        postData["auditAdvDocuments"] = this.checkProperty(
          this.petitionDetails["recruitmentInfo"],
          "documents"
        );
      }
      this.$store
        .dispatch("commonAction", { data: postData, path: path })
        .then((response) => {
          // self.selectedOffice = null;
          self.getFormsAndLetters();
          self.showToster({ message: response.message, isError: false });
          self.generatePopup = false;
          self.generatingFiles = false;
          self.regeneratingFormAndLetter = false;
          
        //  this.$route['params']['tabname'] ="Forms and Letters";
        //  this.$emit("updatepetition", "Forms and Letters");

          setTimeout(() => {

           

            self.getFormsAndLetters();
            self.reloadPetition();
            self.generateFormsLattersPopup = false;
            self.$modal.hide("generateFormsLattersPopup");
            this.$route['params']['tabname'] ="Forms and Letters";
            this.$emit("updatepetition", "Forms and Letters");
          }, 10);
        })
        .catch((error) => {
          this.generatingFiles = false;
          this.regeneratingFormAndLetter = false;
          this.showToster({ message: error, isError: true });
          Object.assign(this.formerrors, {
            msg: error,
          });
        });
    },
    editDocument(selectedForm = null) {
      let self = this;
      let item = _.cloneDeep(selectedForm)
      if(item !=null){
        item = Object.assign(item ,{ "viewmode":false})
        item['viewmode'] = false;
        item = Object.assign(item ,{ "savedDocumentId":null});
        item['savedDocumentId'] = null;
      }
      this.$store.commit("selectedForEditDocument", item);
      this.fetchSignedUrl(item);
      if( _.has(item,'type') && self.checkProperty(item, 'type') == 'Letter' && _.has(item,'generated') &&
       (self.checkProperty(item, 'generated') == true || self.checkProperty(item, 'generated') == 'true') && !item['parentId']){
        let  tempObj = _.cloneDeep(item);
        if(_.has(tempObj, '_id')){
          delete tempObj._id
        }
        this.selDoc(null, tempObj, true);
      }
    },
    uploadEditedDocs(doc){
      //alert(doc['type'])  this.selDoc(self.checkProperty(item, 'mainParentId'), item, true);
    },

    pdfEdit(pdfDoc) {
      let postdata = { keyName: pdfDoc.path };
      this.gettingUrl = true;
      this.$store
        .dispatch("getSignedUrl", postdata)
        .then((response) => {
          //alert(JSON.stringify(response.data.result.data));
          this.pdfUrl = response.data.result.data;

          var loadingTask = pdf.createLoadingTask(this.pdfUrl);

          loadingTask.promise.then((pdf) => {
            this.numPdfPages = pdf.numPages;
            this.$modal.show("pdfEditorPopup");
            this.gettingUrl = false;
          });
        })
        .catch(() => {
          this.gettingUrl = false;
        });
    },

    resetOffice() {
      // this.selectedOffice =null
    },
   
    hideModel(modelItem = "download_files_model", isShow = false) {
      if (isShow) {
        this.$modal.show(modelItem);
      } else {
        this.$modal.hide(modelItem);
      }
    },
   
    openConformPopUp(item) {
      this.selectedItem = item;
      this.approveConformpopUp = true;
      Object.assign(this.formerrors, { msg: "" });
    },
    //selectedForDownload
    openDownloadPopup(action = false) {
      _.forEach(this.formsAndLettersList, (item) => {
        item["selectedForDownload"] = true;
        if (
          this.checkProperty(item, "reverse_document_versions") &&
          item["reverse_document_versions"].length > 0
        ) {
          _.forEach(item["reverse_document_versions"], (vItem) => {
            vItem.selectedForDownload = false;
          });
        }
      });
      this.downloadFiles = action;
      this.downloading = false;
      Object.assign(this.formerrors, { msg: "" });
      this.openItem = true;
      this.hideModel("download_files_model", action);
    },

    uploadNewFormsandLatters(files, type = "") {
      let model = _.cloneDeep(files);
      this.value = [];

      this.newFormsAndLetters = [];

      var _current = this;
      this.$vs.loading();
      let formData = new FormData();

      let tempFiles = [];
      if (model.length > 0) {
        model.forEach((doc, index) => {
          if (
            (this.formLetterType == "Form" &&
              (doc.mimetype == "application/pdf" || doc.type == "application/pdf")) ||
            (this.formLetterType == "Letter" &&
              (doc.mimetype == "application/msword" ||
                doc.type == "application/msword" ||
                doc.mimetype ==
                  "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||
                doc.type ==
                  "application/vnd.openxmlformats-officedocument.wordprocessingml.document"))
          ) {
            formData.append("files", doc.file);
            formData.append("secureType", "private");
            formData.append("getDetails", true);

            this.$store.dispatch("uploadS3File", formData).then((response) => {
              response.data.result.forEach((urlGenerated) => {
                if(_.has( urlGenerated ,'size')){
                  doc["size"] = urlGenerated['size'];
                }
                doc.url = urlGenerated;
                doc["path"] = urlGenerated;
                delete doc.file;
                let temp_file = urlGenerated;

                tempFiles.push(temp_file);
                let fl = {
                  name: temp_file["name"],
                  url: temp_file["path"],
                  mimetype: temp_file["mimetype"],
                  size:0
                };
                if(_.has( urlGenerated ,'size')){
                  fl["size"] = urlGenerated['size'];
                }
                this.newFormsAndLetters.push(urlGenerated);

                if (tempFiles.length >= model.length) {
                  _current.$vs.loading.close();
                }
              });
            });
          } else {
            _current.$vs.loading.close();
          }
        });
      }
      //  model.splice(0, mapper.length, ...mapper);
    },

    selDoc(mainParentId, doc = null,callfromEdit=false) {
     this.formLetterType = this.checkProperty(doc ,'type');
      Object.assign(this.formerrors, { msg: "" });
      this.parentId = mainParentId;
      this.selectedDoc = doc;
      if(!callfromEdit){
        this.reversion_fileuploadPopup = true;
      }
      //this.resetForms();
      this.version_documentUploaded = [];
      this.disable_reversion_uploadBtn = false;
      this.selectedDocument = doc;
      this.docUserType ='Beneficiary'
      this.entityId ='cover_letter';
      this.showentityIdError=false;
      this.showTypeIdError =false;
      this.entityId='cover_letter';  
      this.fuploder = false;
      
    if(this.checkProperty(doc,'entityId' )){
        //support_letter cover_letter
     
    
      if(this.checkProperty(doc,'entityId' ) =='support_letter' && this.checkProperty(doc ,'type') =='Letter'){
        this.entityId ='support_letter';  
        setTimeout(()=>{
          this.entityId ='support_letter';  
        },100);
      }
    
     
    }
    if(!callfromEdit){
      this.reversion_fileuploadPopup = true;
    }
    if(callfromEdit){
      this.version_documentUploaded.push(this.selectedDoc);
      this.updateDocument_Version(false, false);
    }
      this.$validator.reset();
     
    },
    reversion_fileNameChenged(fileindex) {
      let fname = this.version_documentUploaded[fileindex]["name"];
      fname = fname.trim();
      this.disable_reversion_uploadBtn = false;
      if (!fname) {
        this.disable_reversion_uploadBtn = true;
      }
    },
    remove_reversion_file() {
      this.version_documentUploaded = [];
    },

    chengefileName(index, fileindex){
        this.disable_uploadBtn = false;
      _.forEach(this.uploadFinalMainDocuments, (doc, value) => {
            let fname = doc.name
            fname = fname.trim();

            if (!fname) {
              this.disable_uploadBtn = true;
            }

      })
      
    },  

    fileNameChenged(index, fileindex) {
      this.disable_uploadBtn = false;

      _.forEach(this.documentData, (doc, value) => {
        if (doc.documentUploaded.length > 0) {
          _.forEach(doc.documentUploaded, (fl, value) => {
            //let fname = fl.name;
            let fname = fl.document.name;
            fname = fname.trim();

            if (!fname) {
              this.disable_uploadBtn = true;
            }
          });
        }
      });
    },
    //Download 1
    fetchSignedUrl(value, download = false, viewmode = true) {
     
      value.download = download;
      
      if( !_.has(value ,'viewmode')){
        value.viewmode = viewmode;
      }
      this.$emit("download_or_view", value);
      // window.open(this.$globalgonfig._APIURL+"/common/viewfile?path="+value.path, "_blank");
    },
    download_or_view(value) {
        
        if (_.has(value, "path")) {
            value['url'] = value['path'];
            value['document'] = value['path'];
        }

        if (_.has(value, "url")) {
            value['path'] = value['url'];
            value['document'] = value['url'];
        }

        if (_.has(value, "document")) {
            value['path'] = value['document'];
            value['url'] = value['document'];
        }
        

        this.selectedFile = value;
        this.docValue = '';
        this.docPrivew = false;
        this.docType = false;
        this.docType = this.findmsDoctype(value);

        if (false && (this.docType == "office" || this.docType == "image")) {

            value.url = value.url.replace(this.$globalgonfig._S3URL, "");
            value.url = value.url.replace(this.$globalgonfig._S3URLAWS, "");
            let postdata = {
                keyName: value.url
            };
            this.$store.dispatch("getSignedUrl", postdata).then((response) => {
                this.docValue = response.data.result.data;

                if (this.docType == "office") {
                    this.docValue = encodeURIComponent(response.data.result.data);
                }
                this.docPrivew = true;
            });

        } else {

            this.downloads3file(value);
        }

    },
    remove(item, type) {
      type.splice(type.indexOf(item), 1);
      return false;
    },

    getformated(item) {
      //YYYY-MM-DD  HH:mm:ss
      if(this.checkProperty(item,'generated') == true || this.checkProperty(item,'generated') == 'true' ){
        if (item.createdOn) {
        return (
          "Generated On  " +
          moment(item.createdOn).format("MMM DD, YYYY hh:mm:ss a") +
          " - Generated By " +
          item.createdByName
        );
      } else if (item.uploadedOn) {
        return (
          "Generated On  " +
          moment(item.uploadedOn).format("MMM DD, YYYY hh:mm:ss a") +
          " - Generated By " +
          item.createdByName
        );
      } else {
        return "Generated By " + item.createdByName;
      }
      }else{
        if (item.updatedOn) {
          let txt = "Updated On  " + moment(item.updatedOn).format("MMM DD, YYYY hh:mm:ss a");
          if(item.updatedByName){
            txt =txt+" - Updated By " + item.updatedByName
          }else if(item.createdByName){
            txt =txt+" - Uploaded By " + item.createdByName
          }
        return txt;
      } else if (item.createdOn) {
        return (
          "Uploaded On  " +
          moment(item.createdOn).format("MMM DD, YYYY hh:mm:ss a") +
          " - Uploaded By " +
          item.createdByName
          // +" "+item.parentId +" id="+item._id
        );
      } else {
        return "Uploaded By " + item.createdByName;
      }
      }
      
    },
    deleteDocument() {
      let postdata = {
        documentId: this.selectedItem._id,
      };
      this.$store
        .dispatch("deleteFormAndLetter", postdata)
        .then((response) => {
          this.showToster({ message: response.message, isError: false });
          this.selectedItem = null;
          this.approveConformpopUp = false;
          this.getFormsAndLetters();
          setTimeout(() => {
            //this.$emit("updatepetition" ,'Forms and Letters');
          }, 100);
        })
        .catch((error) => {
          Object.assign(this.formerrors, { msg: error });
          //this.showToster({ message: error, isError: true });
          this.approveConformpopUp = true;
        });
    },
    fetchFormsMasterData() {
      this.$store.dispatch("getmasterdata", "forms_and_letter").then((response) => {
        this.types = [];
        this.types.push({
          name: "Selecte form",
          id: "",
        });
        //  this.types = response;

        _.forEach(response, (item) => {
          this.types.push(item);
        });
        // alert(JSON.stringify(this.types));
      });
    },
    //uploadMainDocuments
    uploadToS3MainDocuments(docs) {
      docs = docs.map(
        (item) =>{
          item = {
            name: item.name,
            size:item.size ? item.size : null,
            file: item.file,
            document: "",
            path: "",
            mimetype: item.type,
          }
          const newName = item.name.replace(/[^\w.]/g, '');
                item.name = newName;
                return item;
        }
      );
      this.formerrors.msg = "";

      if (docs.length > 0) {
        let filIndex = 0;

        docs.forEach((doc) => {
          
          if (
            (this.formLetterType == "Form" &&
              (doc.mimetype == "application/pdf" || doc.type == "application/pdf")) ||
            ((this.formLetterType == "Letter" ||
              this.checkProperty(this.petition, "subTypeDetails", "id") == 15) &&
              (doc.mimetype == "application/msword" ||
                doc.type == "application/msword" ||
                doc.mimetype ==
                  "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||
                doc.type ==
                  "application/vnd.openxmlformats-officedocument.wordprocessingml.document"))
          ) {
            this.disable_uploadBtn = true;
            this.fuploder = true;
            let formData = new FormData();
            formData.append("files", doc.file);
            formData.append("secureType", "private");
            formData.append("getDetails", true);

            this.$store.dispatch("uploadS3File", formData).then((response) => {
              filIndex++;
              if (filIndex >= this.uploadMainDocuments.length) {
                this.fuploder = false;
                this.disable_uploadBtn = false;
              }

              response.data.result.forEach((urlGenerated) => {
                doc.document = urlGenerated;
                doc.path = urlGenerated["path"];
                if(_.has(urlGenerated ,'size' )){
                  doc['size'] = urlGenerated['size'];
                }
                //this.uploadMainDocuments.push(doc);
                this.uploadFinalMainDocuments.push(doc);
              });
            });
          } else {
            this.disable_uploadBtn = false;
            this.fuploder = false;
            if (this.formLetterType == "Form") {
              this.formerrors.msg = " Froms Accept only pdf Documents";
            } else if (this.formLetterType == "Letter") {
              this.formerrors.msg = " Letters Accept only MS documents";
            } else if (this.checkProperty(this.petition, "subTypeDetails", "id") == 15) {
              this.formerrors.msg = " Audit Resopnse Accept only MS documents";
            } else {
              this.formerrors.msg = "";
            }
          }
        });
      }
    },
    selectedDocuments(index, docs) {
      docs = docs.map(
        (item) =>
          (item = {
            size:item.size?item.size:0,
            name: item.name,
            file: item.file,
            document: "",
            path: "",
            mimetype: item.type,
          })
      );
      this.documentData[index].documentUploaded = [];
      this.documentData[index].documentUploaded = docs;
      this.fuploder = false;
      this.disable_uploadBtn = false;
      if (docs.length > 0) {
        let filIndex = 0;
        this.fuploder = true;
        this.disable_uploadBtn = true;
        this.documentData[index].documentUploaded.forEach((doc) => {
          
          if (
            (this.formLetterType == "Form" &&
              (doc.mimetype == "application/pdf" || doc.type == "application/pdf")) ||
            (this.formLetterType == "Letter" &&
              (doc.mimetype == "application/msword" ||
                doc.type == "application/msword" ||
                doc.mimetype ==
                  "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||
                doc.type ==
                  "application/vnd.openxmlformats-officedocument.wordprocessingml.document"))
          ) {
            let formData = new FormData();
            formData.append("files", doc.file);
            formData.append("secureType", "private");
            formData.append("getDetails", true);

            this.$store.dispatch("uploadS3File", formData).then((response) => {
              filIndex++;
              if (filIndex >= this.documentData[index].documentUploaded.length) {
                this.fuploder = false;
                this.disable_uploadBtn = false;
              }

              response.data.result.forEach((urlGenerated) => {
                //alert(JSON.stringify(urlGenerated));
                doc.document = urlGenerated;
                doc.path = urlGenerated;
                
                if (this.documentData[index].documentUploaded[filIndex]) {
                  this.documentData[index].documentUploaded[filIndex][
                    "document"
                  ] = urlGenerated;
                  this.documentData[index].documentUploaded[filIndex][
                    "path"
                  ] = urlGenerated;
                }
              });

              
            });
          }
        });
      }
      this.docUserType ='Beneficiary'
      this.entityId ='cover_letter';
      this.fileuploadPopup = true;
    },

    remove_uploadedfile(index, fileindex) {
      this.documentData[index].documentUploaded.splice(fileindex, 1);
    },
   
    updateFormsAndDocuments() {
      let self =this;
      this.showTypeIdError =false;
      this.showentityIdError =false;
     if(this.formLetterType =='Letter' && !this.entityId ){
      this.showentityIdError =true;
      
     }
  
       if(!this.docUserType){
      //  this.showTypeIdError=true;
       }
        if(!this.showentityIdError || this.formLetterType !='Letter'){

       
      Object.assign(this.formerrors, { msg: "" });
      if (this.disable_uploadBtn) {
        return false;
      }
      // this.fileuploadPopup = false;
      let postData = {
        petitionId: this.petition._id,
        formLetterType: this.formLetterType,
        documents: [],

      };
      
      if (this.parentId) {
        postData = Object.assign(postData, { parentId: this.parentId });
      }
      if(this.petitionDetails.beneficiaryInfo.maritalStatus ==1 ){
          
          postData['docUserType'] = 'Beneficiary'
      }else if( this.docUserType){
        postData['docUserType'] = this.docUserType
        }
        

        // {{ "depType ==="+ depType +"; depLabel ="+depLabel + ' ;docUserType ==='+docUserType }}
       if(this.depType && this.depLabel &&  this.checkProperty(this.petition, "subTypeDetails", "id") != 15){
        postData['depType'] = this.depType;
        postData['depLabel'] = this.depLabel;

       }
       
        if(this.formLetterType =='Letter' && this.entityId){
           postData =Object.assign(postData, { 'entityId': this.entityId });
       }
      
      

      if (this.uploadFinalMainDocuments.length > 0) {
        this.uploadFinalMainDocuments.forEach((doc) => {
          let document = doc.document;
          document = Object.assign(document, { name: doc.name });

          document['uploadedBy'] =self.checkProperty(self.getUserData,'userId')!=''?self.checkProperty(self.getUserData,'userId'):null,
          document['uploadedByName'] =self.checkProperty(self.getUserData,'name')!=''?self.checkProperty(self.getUserData,'name'):'',
          document['uploadedByRoleId'] = self.getUserRoleId?self.getUserRoleId:null,
          document['uploadedByRoleName'] =self.checkProperty(self.getUserData,'loginRoleName'),

          postData["documents"].push(document);
        });
      }
      this.fuploder = true;
      this.disable_uploadBtn = true;
      let count = 0;
      // alert(JSON.stringify(postData))
      if (this.checkIsloginUserDoce) {
        postData = Object.assign(postData, { uploadByExecutive: true });
      }
      let dispatch = "uploadFormsAndLetters";
      if (
        this.checkProperty(this.petition, "typeDetails", "id") == 3 &&
        this.checkProperty(this.petition, "subTypeDetails", "id") == 15
      ) {
        dispatch = "uploadPermFormsAndLetters";
      }
     
    
      this.$store
        .dispatch(dispatch, postData)
        .then((response) => {
          this.depType ='';
          this.depLabel ='';
          this.showToster({ message: response.message, isError: false });
          this.fileuploadPopup = false;
          self.fileuploadPopup = false;
          this.fuploder = false;
          this.disable_uploadBtn = false;
          this.fileuploadPopup = false;
          self.fileuploadPopup = false;
          self.getFormsAndLetters();
          setTimeout(() => {
            self.$emit("updatepetition", "Forms and Letters");
          }, 100);
        })
        .catch((error) => {
          Object.assign(this.formerrors, { msg: error });
          //this.showToster({ message: error, isError: true });
          this.fuploder = false;
          this.disable_uploadBtn = false;
        });
      }
      
    },

    doUpload(id, documents, typeId = "") {
      this.documentId = id;

      let formData = new FormData();
      documents = documents.map(
        (item) =>
          (item = {
            typeId: typeId,
            name: item.name,
            file: item.file,
            path: "",
            size: item.size?item.size:0,

            mimetype: item.type,
          })
      );
      this.disable_reversion_uploadBtn = false;
      this.rfuploder = false;
      if (documents.length > 0) {
        this.rfuploder = true;
        this.disable_reversion_uploadBtn = true;
        let findx = 0;

        this.version_documentUploaded.forEach((doc) => {
          //:title="(checkProperty(petition ,'subTypeDetails' ,'id') ==15)?'Upload Audit Response': 'Upload '+formLetterType+'s and Others'"

          if (
            (this.formLetterType == "Form" &&
              (doc.mimetype == "application/pdf" || doc.type == "application/pdf")) ||
            ((this.formLetterType == "Letter" ||
              this.checkProperty(this.petition, "subTypeDetails", "id") == 15) &&
              (doc.mimetype == "application/msword" ||
                doc.type == "application/msword" ||
                doc.mimetype ==
                  "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||
                doc.type ==
                  "application/vnd.openxmlformats-officedocument.wordprocessingml.document"))
          ) {
            formData.append("files", doc.file);
            formData.append("secureType", "private");
            formData.append("getDetails", true);
            this.$store.dispatch("uploadS3File", formData).then((response) => {
              response.data.result.forEach((urlGenerated) => {
                if(_.has(urlGenerated ,'size' )){
                  doc['size'] = urlGenerated['size'];
                }
                doc.path = urlGenerated['path'];
                this.reversionFile = doc;
                this.disable_reversion_uploadBtn = false;
                this.rfuploder = false;
              });
            });
            findx++;
          }
        });
        if (findx == 0) {
          this.disable_reversion_uploadBtn = false;
          this.rfuploder = false;
          this.version_documentUploaded = [];
        }
      }
    },
    updateDocument_Version(fromRestore = false, showresponse = true) {
      let self =this;
      this.showentityIdError =false;
      this.showTypeIdError =false;
      if(!this.docUserType){
       // this.showTypeIdError=true;
        
       }
      if(!fromRestore){
        //formerrors.msg
        if (this.version_documentUploaded.length <= 0){
     
          Object.assign(this.formerrors, { msg: "" });
          Object.assign(this.formerrors, { msg: "Upload Revision Document" });
          return false;
        }
       
        if (this.formLetterType =='Letter' && this.checkProperty(this.selectedDocument, "entityId")=='support_letter'){
          this.entityId ='support_letter'; 
        }

        if(this.formLetterType =='Letter' && !this.entityId ){
           this.showentityIdError =true;
           return false;
       }
       
      }
      Object.assign(this.formerrors, { msg: "" });
      if (this.version_documentUploaded.length > 0 && !this.disable_reversion_uploadBtn) {
        this.disable_reversion_uploadBtn = true;
        this.rfuploder = false;

        let postData = {
          petitionId: this.petition._id,
          formLetterType: this.formLetterType,
          documents: [],
          restore: false,
        };

        if(this.formLetterType =='Letter' && this.entityId){
           postData =Object.assign(postData, { 'entityId': this.entityId });
       }

      if(this.checkProperty(this.selectedDocument, "entityId") ){
        postData =Object.assign(postData, { 'entityId':  this.checkProperty(this.selectedDocument, "entityId") });
      }
       
      
        
        if(this.petitionDetails.beneficiaryInfo.maritalStatus ==1 ){
          postData['docUserType'] = 'Beneficiary'
        }else if(this.docUserType){
        postData['docUserType'] = this.docUserType
        }  
     //  alert(postData['entityId']);
        if (fromRestore) {
          postData.restore = true;
        }
        this.version_documentUploaded.forEach((doc) => {
         // console.log(doc)
          //alert()
          let docum = doc;

          if (_.has(docum, "type") && !_.has(docum, 'mimetype')) {
            docum = Object.assign(docum, { mimetype: docum['type'] });
          }

          
          if (_.has(docum, "name") && !_.has(docum, 'extn')) {
            let docName = docum["name"];
            
            let nameArray = docName.split(".");
            if (nameArray.length > 1) {
              let length = nameArray.length;
              let ext = nameArray[length - 1];

              if (ext) {
                docum = Object.assign(docum, { extn: ext });
              }
            }
        
          }

        
          docum['uploadedBy'] =self.checkProperty(self.getUserData,'userId')!=''?self.checkProperty(self.getUserData,'userId'):null,
          docum['uploadedByName'] =self.checkProperty(self.getUserData,'name')!=''?self.checkProperty(self.getUserData,'name'):'',
          docum['uploadedByRoleId'] = self.getUserRoleId?self.getUserRoleId:null,
          docum['uploadedByRoleName'] =self.checkProperty(self.getUserData,'loginRoleName'),

          postData["documents"].push(docum);
        });
        
       
        if (this.parentId) {
          postData = Object.assign(postData, { parentId: this.parentId });
        }
        if (this.checkIsloginUserDoce) {
          postData = Object.assign(postData, { uploadByExecutive: true });
        }

        //    "depType": "beneficiary",// spouse, child, other
        //"depLabel": "beneficiary", // spouse, child_1, child_2, other
        if (
          this.checkProperty(this.selectedDocument, "depType") &&
          this.checkProperty(this.selectedDocument, "depLabel")
          &&  this.checkProperty(this.petition, "subTypeDetails", "id") != 15
        ) {
          postData["depType"] = this.checkProperty(this.selectedDocument, "depType");
          postData["depLabel"] = this.checkProperty(this.selectedDocument, "depLabel");
        }
        if(this.checkProperty(this.selectedDocument, "docUserType")){
          postData["docUserType"] = this.checkProperty(this.selectedDocument, "docUserType");
        }
         
        
        let dispatch = "uploadFormsAndLetters";
        if (
          this.checkProperty(this.petition, "typeDetails", "id") == 3 &&
          this.checkProperty(this.petition, "subTypeDetails", "id") == 15
        ) {
          dispatch = "uploadPermFormsAndLetters";
        }



        this.$store
          .dispatch(dispatch, postData)
          .then((response) => {
            this.getFormsAndLetters();
            if(showresponse == false && _.has(response, '_id')){
              if(this.checkProperty( this.$store.state ,'selectedForEditDocument') ){
                let ite = this.checkProperty( this.$store.state ,'selectedForEditDocument');
                ite['savedDocumentId'] = response['_id'];
                this.$store.commit("selectedForEditDocument", ite);
              }
             
            }
            this.selectedDocument = null;
            this.reversion_fileuploadPopup = false;
            this.version_documentUploaded = [];
            this.disable_reversion_uploadBtn = true;
            //this.getFormsAndLetters();
            this.parentId ='';
            if(showresponse){
              this.showToster({ message: response.message, isError: false });
            }
            this.getFormsAndLetters();
            setTimeout(() => {
              //  this.$emit("updatepetition" ,'Forms and Letters');
            }, 100);
          })
          .catch((error) => {
            if (fromRestore) {
              this.selectedDocument = null;
            }
           

            Object.assign(this.formerrors, { msg: error });
            this.showToster({ message: error, isError: true });
          });
      }
    },
    updateFilingFee() {
      this.$emit("showfilingFeesPopup");
    },
    cancelpopups() {
      this.documentData = [
        {
          type: "Forms, Letters and Others",
          documentUploaded: [],
        },
      ];
    },
    downloadFormslatters(downLoadZip = true) {
      let postdata = {
        petitionId: this.petition._id,
        documentIds: [],
        downloadType: "zip",
        entityType: "case",
      };
      if (!downLoadZip) {
        postdata["downloadType"] = "pdf";
      }
      
      //petition/download-forms-letters,
      //  if([3,4,5,6,7,8,9,10,11].indexOf(this.getUserRoleId)>-1){
      Object.assign(this.formerrors, { msg: "" });

      _.forEach(this.formsAndLettersList, (item) => {
        if (
          item["selectedForDownload"] &&
          postdata["documentIds"].indexOf(item._id) <= -1
        ) {
          postdata["documentIds"].push(item._id);
        }
        if (
          this.checkProperty(item, "reverse_document_versions") &&
          item["reverse_document_versions"].length > 0
        ) {
          _.forEach(item["reverse_document_versions"], (vItem) => {
            if (
              vItem["selectedForDownload"] &&
              postdata["documentIds"].indexOf(vItem._id) <= -1
            ) {
              postdata["documentIds"].push(vItem._id);
            }
          });
        }
      });

      //  }

      if (postdata["documentIds"].length > 0) {
        if (
          [3].indexOf(this.checkProperty(this.petition, "typeDetails", "id")) > -1 &&
          [15].indexOf(this.checkProperty(this.petition, "subTypeDetails", "id")) > -1
        ) {
          postdata["entityType"] = "perm";
        }

        this.downloading = true;
        this.$store
          .dispatch("downloadFormslatters", postdata)
          .then((response) => {
            this.downloading = false;
            this.openDownloadPopup(false);
            window.open(
              this.$globalgonfig._APIURL + "/common/viewfile?path=" + response.path,
              "_blank"
            );
            // window.open(response.data.result.data, '_blank');
          })
          .catch((error) => {
            this.downloading = false;
            Object.assign(this.formerrors, { msg: error });
            //this.showToster({ message: error, isError: true });
          });
      } else {
        Object.assign(this.formerrors, { msg: "Atleast one document is required." });
      }
    },
    reloadPetition() {
      let self = this;
      setTimeout(() => {

       
        self.$route['params']['tabname'] ="Forms and Letters"; 
        self.$route['params']['tabname'] ="Forms and Letters"; 
        self.$emit("updatepetition", "Forms and Letters");
      }, 100);
    },
    getFormsAndLetters() {
      this.fileuploadPopup = false;
      this.reversion_fileuploadPopup = false;
      this.formsAndLettersList = [];
      let finalList = [];
      this.previousVersionList = [];
      this.previousExisted = false;
      let postData = {
        petitionId: this.petition._id,
        matcher: { typeIds: ["Form" ,'Letter'] },
        page: 1,
        perpage: 100000,
      };
    //  postData["matcher"]["typeIds"] = [this.formLetterType];

      if (
        this.checkProperty(this.petition, "typeDetails", "id") == 3 &&
        this.checkProperty(this.petition, "subTypeDetails", "id") == 15
      ) {
        postData["matcher"]["typeIds"] = ["Audit Response"];
        this.formLetterType = "Audit Response";
        //audit_response
      }
      this.updateLoading(true ,'NoDataFoundReff');
      this.$store
        .dispatch("getList", {
          data: postData,
          // path:"/petition/filled-forms-and-letters-list"
          path: "/filled-forms-and-letters/list",
        })
        .then((response) => {
          let lst = [];
 let subList = [];
          let mainList =[];
          _.forEach(response.list, (mainItem) => {
            mainItem = Object.assign(mainItem, {
              reverse_document_versions: [],
              mainParentId: "",
              showMe: true,
              selectedForDownload: false,
              "viewmode":true,
            });
            if (mainItem.parentId) {
              mainItem["mainParentId"] = mainItem["parentId"];
            } else {
              mainItem["mainParentId"] = mainItem["_id"];
            }

            lst.push(mainItem);
          });
          // if(response){
          //    this.ActiveList = _.filter(response.list, (item) => {
          //     return item.statusId != 1
          //    });
          // }
          
         
          //reverse_document_versions
          _.forEach(lst, (mainItem) => {
            if (this.checkProperty(mainItem, "depType") != "child") {
              _.forEach(lst, (subItem) => {
                if (
                  mainItem.parentId &&
                  (mainItem.parentId == subItem["parentId"] ||
                    mainItem.parentId == subItem["_id"]) &&
                  mainItem["_id"] != subItem["_id"]
                ) {
                  subItem["showMe"] = false;
                  if (subList.indexOf(subItem["_id"]) <= -1) {
                    mainItem["reverse_document_versions"].push(subItem);
                    this.previousExisted = true;
                    subList.push(subItem["_id"]);
                    
                  }

                  // mainItem['showMe'] =true;
                }
              });
              
              
              if (mainItem.showMe && mainList.indexOf(mainItem['_id'])<= -1) {
                mainList.push(mainItem['_id'])
                finalList.push(_.cloneDeep(mainItem));
              }
            } else {
             
              _.forEach(lst, (subItem) => {
                if (
                  this.checkProperty(mainItem, "depType") ==
                    this.checkProperty(subItem, "depType") &&
                  this.checkProperty(mainItem, "depLabel") ==
                    this.checkProperty(subItem, "depLabel") &&
                  mainItem.parentId &&
                  (mainItem.parentId == subItem["parentId"] ||
                    mainItem.parentId == subItem["_id"]) &&
                  mainItem["_id"] != subItem["_id"]
                ) {
                  subItem["showMe"] = false;
                  if (subList.indexOf(subItem["_id"]) <= -1) {
                    mainItem["reverse_document_versions"].push(subItem);
                    this.previousExisted = true;
                    subList.push(subItem["_id"]);
                   
                  } 

                  // mainItem['showMe'] =true;
                }
              });

              if (mainItem.showMe && mainList.indexOf(mainItem['_id'])<= -1) {
                mainList.push(mainItem['_id'])
                finalList.push(_.cloneDeep(mainItem));
              }
            }
          });
          // if(this.checkProperty(finalList, 'length')>0){
          //   let sel = this
          //   _.forEach(finalList, (item)=>{
          //     if(_.has(item, 'reverse_document_versions') && sel.checkProperty(item, 'reverse_document_versions', 'length')>0){
          //       item  = _.orderBy(item, ["reverse_document_versions",'updatedOn' ] ,["desc",'desc'] );
          //     }
          //   })
          // }

          this.previousVersionList = _.cloneDeep(finalList)
          this.totalpages = Math.ceil(response.totalCount / this.perpage);
          //this.formsAndLettersList = _.cloneDeep(finalList); // JSON.parse(JSON.stringify(finalList));
         let tempList = _.filter(finalList,(ite)=>{
          let findObj =  _.find(finalList,{'parentId':ite['_id']});
            if(!findObj){
              return true
            }else{
              return false
            }
          })
          this.formsAndLettersList = _.cloneDeep(tempList);
          this.splitChildrensFormsAndLetters();
         // this.getMasetFormsAndLatters(false);
          this.updateLoading(false, 'NoDataFoundReff');
          setTimeout(() => {
            this.updateLoading(false, 'NoDataFoundReff');
            this.updateLoading(false, 'NoDataFoundReff');
            this.updateLoading(false, 'NoDataFoundReff');
               setTimeout(() => { 
                this.updateLoading(false ,'NoDataFoundReff'); 
                setTimeout(() => { this.updateLoading(false, 'NoDataFoundReff');  }, 100);
               }, 10);
          }, 10);
        })
        .catch((err) => {
          this.updateLoading(false);
          this.formsAndLettersList = [];
          setTimeout(() => {
            this.updateLoading(false);
          }, 10);
        });
    },
    pageNate(pageNum) {
      this.page = pageNum;
      this.getFormsAndLetters();
    },
    openGeneratePopup() {
      this.formerrors.msg = "";
      this.newFormsAndLetters = []
      this.generatePopup = true;
    },
  },

  data: () => ({
    toggleAccord:false,
    petitionhistory:null,
    previousVersionList:[],
    selectAll:false,
    encodedString:'',
    updatePreEmployDetails:'',
    updateReload:false,
    loadingI140:false,
    filingFormsList:[{'id':'i485',name:'Form I-485'},
    {'id':'i131',name:'Form I-131 '},{'id':'i765',name:'Form I-765'},{'id':'other',name:'Other'}],
    i140AdditionalInfo:{
      petitionBeingFieldFor: "",
      petitionBeingField: "", 
      prevPetiReceiptNumber: "",
      anyOtherPetiOrApplications: "",
      petiOrApplicAllApplicableBoxes: [],
      petiOrApplicAllApplicableBoxOther: "",
      removalProceedings: "",
      immiVisaPetitionOrPerson: "",
      supportOfAnotherFormi140: "",
      departmentOfLabor: "",
      considerBnfEmpInfoForLetters:''
    },
    depType:'',
    depLabel:'',
    docUserType:'Beneficiary',
    showPreviousVersionsList:[],
    childrenFormsAndLetters:{},
    showDocType:false,
    isValiedCourierAddress:false,
    courierAddress:'',
    showCourier:true,
    selectedCourier:null,
    masterCourierList:[],
    courierListTemp:[],
    
    showentityIdError:false,
    showTypeIdError:false,
    entityId:'cover_letter',
    
    entityIdDetails:null,
    entityIds:[{"id":"'cover_letter'" ,"name":"Cover Letter"},{"id":'support_letter' ,"name":'Support Letter'}],
   // DocTypeIds:[{"id":"'Beneficiary'","name":"Beneficiary"},{"id":"'Dependent'","name":"Dependent"}],
    editor: ClassicEditor,
 editorConfig: {
     toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
 },
    filesUploading: false,
    fvalue: [],

    docsLists: [
      {
        key: "sunday",
        fieldName: "sunday",
        required: false,
        label: "Copy of Sunday edition of the newspaper",
        display: true,
        loading: false,
      },
      {
        key: "jobFair",
        fieldName: "jobFair",
        required: false,
        label: "Copy of advertised at job fair",
        display: true,
        loading: false,
      },
      {
        key: "campusRecruitment",
        fieldName: "campusRecruitment",
        required: false,
        label: "Copy of advertised at on-campus recruiting",
        display: true,
        loading: false,
      },
      {
        key: "empWebsite",
        fieldName: "empWebsite",
        required: false,
        label: "Copy of advertised at on employer website",
        display: true,
        loading: false,
      },
      {
        key: "profOrgOrTrade",
        fieldName: "profOrgOrTrade",
        required: false,
        label: "Copy of advertised with trade or professional organization",
        display: true,
        loading: false,
      },
      {
        key: "pvtEmpmtFirm",
        fieldName: "pvtEmpmtFirm",
        required: false,
        label: "Copy of advertised at employment firm",
        display: true,
        loading: false,
      },
      {
        key: "jobSearchWebsite",
        fieldName: "jobSearchWebsite",
        required: false,
        label: "Copy of advertised at job search website",
        display: true,
        loading: false,
      },
      {
        key: "empRefProgram",
        fieldName: "empRefProgram",
        required: false,
        label: "Copy of advertised at employee referral program",
        display: true,
        loading: false,
      },
      {
        key: "campusPlacement",
        fieldName: "campusPlacement",
        required: false,
        label: "Copy of advertised at campus placement office ",
        display: true,
        loading: false,
      },
      {
        key: "localNewsPaper",
        fieldName: "localNewsPaper",
        required: false,
        label: "Copy of advertised at local or ethnic newspaper",
        display: true,
        loading: false,
      },
      {
        key: "tvAds",
        fieldName: "tvAds",
        required: false,
        label: "Copy of advertised at radio or TV ads",
        display: true,
        loading: false,
      },
      {
        key: "intrOfcMemomandum",
        fieldName: "intrOfcMemomandum",
        required: false,
        label: "Copy of Signed documents",
        display: true,
        loading: false,
      },
      {
        key: "recruReportSummary",
        fieldName: "recruReportSummary",
        required: false,
        label:
          "Copy of Recruitment Report and Summary describing the recruitment efforts and results",
        display: true,
        loading: false,
      },
      {
        key: "busNecLetterByEplr",
        fieldName: "busNecLetterByEplr",
        required: false,
        label: "Copy of Business Necessity Letter Provided by Employer",
        display: true,
        loading: false,
      },
    ],
    selectedAction: "",
    index: "",
    approveOrRejectDocs: false,
    approveOrRejectDocsTitle:"Approve Documents",
    formErrors: "",
    comments: "",
    //loading: false,
    selectedDocument: null,
    loadingFormLatters: false,
    previousExisted: false,
    showPreviousVersions:false,
    formSubmited: false,
    regeneratingFormAndLetter: false,
    generateFormsLattersPopup: false,
    masterFormsAndLatters: {
      beneficiary: [],
      spouse: [],
      child: {},
    },
    gettingUrl: false,
    numPdfPages: 1,
    pdfPage: 1,
    pdfUrl: "",
    selectedOffice: null,
    officeList: [],
    togleFileUpload: true,
    acceptedFiles: "application/pdf",
    approveConformpopUp: false,
    selectedItem: null,
    generatingFiles: false,
    openItem: true,
    formLetterType: "Form", //'Letter',
    downloading: false,
    downloadFiles: false,
    parentId: "",
    uploading: false,
    value: [],
    formerrors: {
      msg: "",
    },
    newFormsAndLetters: [],
    all_formTypes: [
      { name: "Form", id: "Form" },
      { name: "Letter", id: "Letter" },
    ],
    generatePopup: false,
    totalpages: 0,
    page: 1,
    perpage: 25,
    formsAndLettersList: [],
    types: [],
    typeSelected: "",
    documents: [],
    documentData: [
      {
        type: "Forms, Letters and Others",
        documentUploaded: [],
      },
    ],
    formsData: [],
    formsAndLetterSignedUrls: [],
    downloadSamplespopup: false,
    documentId: "",
    version_documentUploaded: [],
    fileuploadPopup: false,
    disable_uploadBtn: false,
    selectedDoc: "",
    reversion_fileuploadPopup: false,
    disable_reversion_uploadBtn: false,
    reversionFile: null,
    fuploder: false,
    rfuploder: false,
    uploadMainDocuments: [],
    uploadFinalMainDocuments: [],
    adminsList: [],
    ManagerList: [],
    petitionDetails: {},
    adminsList:[],
  }),
  mounted() {
    this.getCourierList();
    this.getcaseHistory();
   // this.docUserType = 'Beneficiary';
    setTimeout(() => {



      var data = _.merge(this.petitionDetails, this.petition);
      this.petitionDetails = _.cloneDeep(data);
      setTimeout(() => {
        var data = _.merge(this.petitionDetails, this.petition);
        this.petitionDetails = _.cloneDeep(data);

        
      }, 100);

      

    }, 10);
    // let adminsactiVityList =[];
    if (_.has(this.workFlowDetails, "config")) {
      
      let adminsactiVityList = _.find(this.workFlowDetails.config, {
       code: "MANAGER_LIST",
     });
    if (adminsactiVityList && adminsactiVityList.editors) {
     this.adminsList = _.map(adminsactiVityList.editors, "roleId");
     }
     
    }
    // let docsManagerList = _.find(this.workFlowDetails.config, {
    // code: "DOCUMENTATION_MANAGER_LIST",
    // });
    // if (docsManagerList && docsManagerList.editors) {
    //   this.ManagerList = _.map(docsManagerList.editors, "roleId");
    // }

    this.$store.commit("selectedForEditDocument", null);

    //  md_service_centerlet
    // this.checkProperty(this.petition,'typeDetails','id')
    let postData = { page: 1, perpage: 1000,
      filters: {
        typeIds: [],
        }, 
      };
      if(this.checkProperty(this.petition,'typeDetails','id')){
        postData['filters']['typeIds'].push(this.checkProperty(this.petition,'typeDetails','id'))
      }
    this.$store
      .dispatch("commonAction", { data: postData, path: "/service-centers/list" })
      .then((res) => {
        this.officeList = res["list"];
        if (this.checkProperty(this.getPetitionDetails, "serviceCenter", "id")) {
          this.selectedOffice = this.checkProperty(
            this.getPetitionDetails,
            "serviceCenter"
          );
        } else if (this.checkProperty(this.officeList, "length") > 0) {
         // this.selectedOffice = this.officeList[0];
        }
      });

    this.fetchFormsMasterData();
    if(this.$route.params && this.$route.params.openGeneratePopup && this.$route.params.openGeneratePopup=='openGeneratePopup' ){
      
      //this.$route['params']['openGeneratePopup'] ='';
     // this.$route['query']['openGenForms'] ='';
     // this.getMasetFormsAndLatters(true);
    }
    this.getFormsAndLetters(false);
    this.getFormsAndLetters();

   
    if (this.checkProperty(this.petition, "subTypeDetails", "id") == 15) {
      this.acceptedFiles =
        "application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document";
    }
  },
  computed: {
    checkCommentLength(){
      return (comment='')=>{
        let textcomment = comment;
        let self = this;
        let returnVal = false;
        if(textcomment){
          var plainText = textcomment.replace(/<[^>]*>/g, '');
          let plainext = plainText.replace(/&nbsp;|&nbsp/g, ' ');
          if(plainext){
            var htmlString = plainext.trim();
            if(htmlString && self.checkProperty(htmlString, 'length') >200 ){
              returnVal = true
            }
          }
        }
        return returnVal
      }
    },
    returnCommentText(){
      return (comment='')=>{
        let returnVal = '';
        if(comment){
          var plainText = comment.replace(/<[^>]*>/g, ' ');
          let plainext = plainText.replace(/&nbsp;|&nbsp/g, ' ');
          if(plainext){
            returnVal = plainext.trim();
            
          }
        }
        return returnVal
      }
    },
    checkAdditionalInfo(){
      let returnVal = false;
      if(this.checkProperty(this.i140AdditionalInfo, 'petiOrApplicAllApplicableBoxes') && this.checkProperty(this.i140AdditionalInfo, 'petiOrApplicAllApplicableBoxes','length')>0){
        const index = this.i140AdditionalInfo['petiOrApplicAllApplicableBoxes'].findIndex(item => item.name === 'Other');
        if(index>=0){
          returnVal = true;
        }
      }
      return returnVal
    },
    //reverse_document_versions
    checkRevisionDocuments(){
      return (category)=>{
        // formsAndLettersList.length > 0 forms['docUserType'] !='Beneficiary'"
        if(!category){
          let revisionDocuments =_.filter(this.formsAndLettersList ,(item)=>{
                  return this.checkProperty(item ,'reverse_document_versions' ,'length')>0?true:false
                });
                if(revisionDocuments && revisionDocuments.length>0){
                  return true
                }else{
                  return false
                }


        }else{
          let categoryList  =_.filter(this.formsAndLettersList, { "depLabel":category } );
             //alert(JSON.stringify(categoryList))
              if(categoryList.length > 0){

                let revisionDocuments =_.filter(categoryList ,(item)=>{
                  return this.checkProperty(item ,'reverse_document_versions' ,'length')>0?true:false
                });
                if(revisionDocuments && revisionDocuments.length>0){
                  return true
                }else{
                  return false
                }

                
              }else{
                return false
              }

        }
        

      }
    },

    checkFormsAndLetters(){
      return (category)=>{
        // formsAndLettersList.length > 0 forms['docUserType'] !='Beneficiary'"
        if(!category){
          if(this.formsAndLettersList.length > 0){
            return true
          }else{
            return false

          }


        }else{
          let categoryList  =_.filter(this.formsAndLettersList, { "depType":category } );
             //alert(JSON.stringify(categoryList))
              if(categoryList.length > 0){
                return true
              }else{
                return false
              }

        }
        

      }
    },

    checkNoNotifyUserIds(){
      let returnValue =true;
      if(_.has(this.petition, 'noNotifyUserIds')  ){
        if(this.petition['noNotifyUserIds'].length>0){
          if(this.petition['noNotifyUserIds'].indexOf(this.getUserData['userId']) >-1){
            returnValue = false;
          }

        }

      }
      return returnValue;
    },
    checkUserAccessBtn(){
      let returnVal = false;
      let accessRoleIds = this.checkProperty( this.petition ,'accessRoleIds')
      let accessUserIds = this.checkProperty( this.petition ,'accessUserIds' )
      let loginUserId = this.checkProperty(this.getUserData,'userId')
      // accessRoleIds.indexOf(this.getUserRoleId)>-1 || 
      if(accessUserIds.indexOf(loginUserId)>-1 ){
        returnVal = true
      }
      return returnVal
    },
    checkActionButton(){
      let returnVal = true
      if(this.checkProperty( this.petition ,'assignRoleLogs' ,'length')>0){
        let assignRoleLogs = this.checkProperty( this.petition ,'assignRoleLogs')
        let loginUserId = this.checkProperty(this.getUserData,'userId')
        let UserDetails = _.find(assignRoleLogs , {"userId":loginUserId})
        if(UserDetails ){
          let users = _.filter(assignRoleLogs , {"userId":loginUserId ,'hide':false})
          if(users && users.length>0){
            returnVal =true;
          }else{
            returnVal = false
          }
          
        }
        
      }
      return returnVal
    },
    checkIsActiveUser(){
      let returnVal = false
      if(this.checkProperty( this.petition ,'assignRoleLogs' ,'length')>0){
        let assignRoleLogs = this.checkProperty( this.petition ,'assignRoleLogs')
        let loginUserId = this.checkProperty(this.getUserData,'userId')
        let UserDetails = _.find(assignRoleLogs , {"userId":loginUserId})     
        if(UserDetails){
          let users = _.filter(assignRoleLogs , {"userId":loginUserId ,'hide':false})
          if(users && users.length>0){
            returnVal =true;
          }
        }
        else{
            returnVal = true
        }
        
      }
      return returnVal
    },
    checkSubmitToUscisCompleted(){
      let returnVal =false;
      if(this.petition && this.checkProperty(this.petition ,'completedActivities' ,'length' )>-1&& this.petition.completedActivities.indexOf('SUBMIT_TO_USCIS') >-1){
        returnVal =true;
      }
      return  returnVal;

    },
    isEnableApproveRejMenu(){
      return false;
    },
    isSubmitUscisCompleted(){
       if(
     
      
         ( _.has(this.petition ,'completedActivities')
         
           &&  this.petition.completedActivities.indexOf('SUBMIT_TO_USCIS') >-1
          
         )
  
      ){
       return true;
  
      }else{
        return false
      }
    },
    checkDocsLabel() {
      let self = this;
      return (data) => {
        if (_.has(data, "field")) {
          let filedKey = data["field"];
          let selectedKey = _.find(self.docsLists, { key: filedKey });
          if (_.has(data, "category") && data["category"] == "label") {
            let returnVal = null
            if(this.checkProperty(selectedKey,'label')){
              returnVal = this.checkProperty(selectedKey,'label')
            }
            return returnVal
            //return selectedKey['label'];
          }
          if (_.has(data, "category") && data["category"] == "loading") {
            let returnVal = false
            if(this.checkProperty(selectedKey,'loading')){
              returnVal = this.checkProperty(selectedKey,'loading')
            }
            return returnVal
            //return selectedKey['loading'];
          }
        } else {
          return null;
        }
      };
    },
    checkDocM() {
      let returnVal = false;
      let docsManagerList = null;
      if(this.workFlowDetails && this.workFlowDetails.config){
        docsManagerList = _.find(this.workFlowDetails.config, {
          code: "DOCUMENTATION_MANAGER_LIST",
        });
      }
      
      if (docsManagerList && docsManagerList.editors) {
        this.ManagerList = _.map(docsManagerList.editors, "roleId");
      }
      if (this.ManagerList && this.ManagerList.indexOf( this.getUserRoleId)>-1) {
        returnVal = true;
      }
      let adminsactiVityList = null;
      if(this.workFlowDetails && this.workFlowDetails.config){
        adminsactiVityList = _.find(this.workFlowDetails.config, {
        code: "MANAGER_LIST",
      });
      }
      
      let adminsList =[];
      if (adminsactiVityList && adminsactiVityList.editors) {
        adminsList = _.map(adminsactiVityList.editors, "roleId");
      }
      if (adminsList && adminsList.indexOf( this.getUserRoleId)>-1) {
        returnVal = true;
      }
      
      return returnVal;
    },
    IsAdminUser(){
      let returnVal = false
      if(this.adminsList && this.adminsList.indexOf(this.getUserRoleId)>-1){
          returnVal = true;
        }
        return returnVal
    },
    checkPendingDocs() {
      let returnVal = false;
      if ([3, 4, 9, 10].indexOf(this.getUserRoleId) <= -1) {
        if (
          this.formsAndLettersList &&
          this.checkProperty(this.formsAndLettersList, "length") > 0
        ) {
          let falseStautsListPen = _.filter(this.formsAndLettersList, (item) => {
            return this.checkProperty(item, "statusId") == 1;
          });
          let falseStautsListRej = _.filter(this.formsAndLettersList, (item) => {
            return this.checkProperty(item, "statusId") == 3;
          });
          if (
            (falseStautsListPen &&
              this.checkProperty(falseStautsListPen, "length") > 0) ||
            (falseStautsListRej && this.checkProperty(falseStautsListRej, "length") > 0)
          ) {
            if (
              this.checkProperty(falseStautsListPen, "length") ==
              this.checkProperty(this.formsAndLettersList, "length")
            ) {
              returnVal = true;
            }
          }
        }
      }
      return returnVal;
    },
    checkActiveList() {
      let returnVal = false;
      let activeItems = _.filter(this.formsAndLettersList, (item) => {
        return this.checkProperty(item, "statusId") == 2;
      });
      if (activeItems && this.checkProperty(activeItems, "length") > 0) {
        returnVal = true;
      }
      return returnVal;
    },
  },

  watch: {
    '$store.state.reloadPetitionHistory'(val){ 
      if(val){
        this.getcaseHistory();
      }
    },
   
            reversion_fileuploadPopup:function(value){
              if(!value){
                this.parentId ='';
                this.selectedDocument = null;
                

              }
            },

formLetterType:function(value){
    if(this.fileuploadPopup){
        this.uploadMainDocuments =[];
        this.uploadFinalMainDocuments =[];
        // :accept="acceptedFiles"
        if (value == "Form") {
    
            this.acceptedFiles = "application/pdf";
        } else if (value == "Letter") {
            this.acceptedFiles = "application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document";
        } 
      }

},
    fileuploadPopup:function(value){
     if(!value){
      this.showDocType =false;
     }
      
    
   },
    
    selectedCourier:function(value){
     
      setTimeout(()=>{
        this.changedOffice(true);
      } ,10);
     
    }
   // changedOffice selectedCourier
    // downloadFiles:function(value){
    //     if(value){
    //          // alert(value)
    //           //this.$modal.show('download_files_model');
    //           this.hideModel('download_files_model' ,true);
    //     }else{
    //         this.hideModel('download_files_model' ,false);
    //     }
    // }
  },
};
</script>
