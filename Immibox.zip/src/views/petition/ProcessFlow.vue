<template>
  <div class="tabs-layout-header-items padr0" v-if="petition">
    <div class="items-left">
      <ul class="items-list" v-if="checkProperty(petition ,'typeDetails')">
        <li>
          <span>{{checkProperty(petition,"typeDetails","name")}} <br/>
            <small><template v-if="[2,10].indexOf(checkProperty(petition,'typeDetails','id'))>-1">&nbsp</template>
              <template v-else>{{checkProperty(petition ,"subTypeDetails","name")}}</template>
              
            </small>
          </span>
        </li>
        <li  v-if="[51].indexOf(getUserRoleId)<=-1" class="tabwidth">
          Beneficiary
          <span style="font-size:12px">{{ checkProperty(petition,"beneficiaryDetails","name") }}</span>
        </li>
        <li v-if="checkProperty(petition,'petitionerId') && checkProperty(petition,'petitionerDetails','name') && getTenantTypeId !=2 && [51].indexOf(getUserRoleId)<=-1" class="tabwidth">
          Petitioner
          <span style="font-size:12px">{{ checkProperty(petition,"petitionerDetails","name") }}</span>
        </li>
        <li v-if="checkProperty(petition,'classification')" class="tabwidth">
          Classification
          <span style="font-size:12px">{{ checkProperty(petition,'classification') }}</span>
        </li>
        <li v-if="checkProperty(petition,'categoryDetails','name')" class="tabwidth">
          Category
          <span style="font-size:12px">{{ checkProperty(petition,'categoryDetails','name') }}</span>
        </li>
        <li v-if="false && checkProperty(petition,'uscisReceiptNumber') && [9].indexOf(checkProperty(petition,'typeDetails', 'id')) >-1" class="tabwidth">
          USCIS Receipt Number
          <span style="font-size:12px">{{ checkProperty(petition,'uscisReceiptNumber') }}</span>
        </li>
      </ul>
      <ul class="peoples_list" v-if="[51].indexOf(getUserRoleId)<=-1">

    <template v-if="checkProperty(petition ,'assignRoleLogs') && checkProperty(petition ,'assignRoleLogs','length')>0 && checkUserRoleAssignee && checkProperty(checkUserRoleAssignee ,'length')>0" >
         <!--    <template v-for="( assignedUser ,asindx) in petition['assignRoleLogs']">
            <li :key="asindx" v-if="asindx<=1" >
              <figure>
              
                <img class="user-image" :src="getUserPrfoilePic(assignedUser.userId)" />
              </figure>
              <div class="peoples-dropdown">
              
                <h6 v-if="assignedUser.name">
                
                  {{checkProperty(assignedUser ,"name")}}
                  <span v-if="assignedUser.roleName"> {{checkProperty(assignedUser ,"roleName")}}</span>
                </h6>
                <p v-if="assignedUser.email">
                  <a :href="'mailto:'+assignedUser.email">{{checkProperty(assignedUser ,"email")}}</a>
                  <span v-if="assignedUser.phoneCountryCode">
                  <template v-if="checkProperty(assignedUser ,'phoneCountryCode' ,'countryCallingCode')">{{checkProperty(assignedUser ,'phoneCountryCode' ,'countryCallingCode')+"&nbsp;"}}</template>
                  {{checkProperty(assignedUser ,"phone")}}
                  
                  </span>
                </p>
                
              </div>
            </li>
          
          </template> -->

            <li v-if="checkCurrentUrl && checkProperty(petition ,'assignRoleLogs') && checkProperty(petition ,'assignRoleLogs','length')>0 && checkUserRoleAssignee && checkProperty(checkUserRoleAssignee ,'length')>0 && checkActiveUsers">
            <figure class="moreinfo"><img src="@/assets/images/main/avatar3.svg"/> </figure>
            <div class="peoples-dropdown morepeople">
              <div class="morepeople_cnt">
              <VuePerfectScrollbar 
              ref="mainSidebarPs"
              class="scroll-area--nofications-dropdown p-0"
                :settings="peoplelist"
              >
              <ul>
              <template v-for="( assignedUser ,asindx) in checkUserRoleAssignee">
                
                  <li :key='asindx' v-if="checkProperty( assignedUser ,'hide') !=true">
                  <figure>
                     <img class="user-image" :src="getUserPrfoilePic(assignedUser.userId)" />
                     </figure>
                     <div>
                     <h5>{{checkProperty(assignedUser ,"name")}}<span v-if="checkProperty(assignedUser ,'autoAssign')==true || checkProperty(assignedUser ,'autoAssign')=='true'">Default</span>
                     </h5>
                     
                     <h6 v-if="assignedUser.roleName">{{checkProperty(assignedUser ,"roleName")}}</h6>
                     </div>
                        <span v-if="checkReplaceBtn && checkReplaceBtnSubmition && !isSubmitUscisCompleted"  @click="userReplacement(assignedUser);$modal.show('showReplacementPopup')" class="replace_btn"> Replace</span>
                      
                  </li>
                
              </template>
                  
              </ul>
              </VuePerfectScrollbar>
              </div>
            </div>
            </li>
      </template>

      
        
      </ul>
    </div>
   
   
    <div class="items-right" v-if="checkCurrentUrl && !loadedFromPreview" > 
      
      <ul>
        
        <li v-if="[2,3,4].indexOf(checkProperty(petition,'intStatusDetails','id'))>-1" class="petitioner_HAD_status">
          <template v-if="[2].indexOf(checkProperty(petition,'intStatusDetails','id'))>-1"><em>On Hold</em><template v-if="getTenantTypeId!=2"> <span v-if="checkProperty(petition ,'holdedByName')">by {{checkProperty(petition ,'holdedByName')}} <template v-if="checkProperty(petition ,'holdedByRoleName')"> ({{checkProperty(petition ,'holdedByRoleName')}})</template> </span></template></template>
          <template v-if="[3].indexOf(checkProperty(petition,'intStatusDetails','id'))>-1"><em>Abandoned</em><template v-if="getTenantTypeId!=2"> <span v-if="checkProperty(petition ,'abandonedByName')">by {{checkProperty(petition ,'abandonedByName')}}<template v-if="checkProperty(petition ,'abandonedByRoleName')"> ({{checkProperty(petition ,'abandonedByRoleName')}})</template></span></template></template>
          <template v-if="[4].indexOf(checkProperty(petition,'intStatusDetails','id'))>-1"><em>Deleted</em><template v-if="getTenantTypeId!=2"> <span v-if="checkProperty(petition ,'deletedByName')">by {{checkProperty(petition ,'deletedByName')}} <template v-if="checkProperty(petition ,'deletedByRoleName')"> ({{checkProperty(petition ,'deletedByRoleName')}})</template></span></template></template>
          
        </li>
        <li class="filed-date" v-if="[51].indexOf(this.getUserRoleId)<=-1 && checkProperty(petition ,'permFileDeadlineDate') && checkProperty(petition ,'subTypeDetails','id') ==15 " >
          
          PERM File Deadline Date
          <span>{{ checkProperty(petition ,'permFileDeadlineDate')| formatDate }}</span>
        </li>
         <li class="filed-date" v-if="[51].indexOf(this.getUserRoleId)<=-1 && checkProperty(petition ,'priorityDate') && checkProperty(petition ,'subTypeDetails','id') ==15 " >
          
          Priority Date
          <span>{{ checkProperty(petition ,'priorityDate')| formatDate }}</span>
        </li>
        <li v-if="checkH4Label && checkProperty(petition ,'subTypeDetails','id') !=15 && checkProperty(petition, 'questionnaireFilled')  ">
          <div class="dropdown-button-container status-btn_v2">
            <vs-button class="borderRadius20 ">
              <span class="statusspan">
                {{checkH4Label}}
              </span>
            </vs-button>
          </div>
        </li>
     
        <li  v-if="checkProperty( getPetitionDetails, 'premiumProcessing')">
          <div class="IB_tooltip premium_tooltip eee">
            <div class="premium_tooltip_icon">
              <span>P</span>
              <!-- <img v-if="checkProperty( getPetitionDetails,'premiumProcessingDocuments' ,'length')>0" src="@/assets/images/main/doc.svg"/> -->
            </div>
            <div class="tooltip_cnt" v-if="!checkProperty( getPetitionDetails,'premiumProcessingDocuments' ,'length')>0" >
              <p>Premium Processing</p>
            </div>
            <div class="premium_documents" v-if="checkProperty( getPetitionDetails,'premiumProcessingDocuments' ,'length')>0">
              <div class="premium_documents_cnt">
                <h5>Premium Processing</h5>
                <div class="premium_documents_list" @click="download_or_view(getPetitionDetails['premiumProcessingDocuments'][0])" >                
                  <docType  :item="getPetitionDetails['premiumProcessingDocuments'][0]" />
                  <figcaption>{{getPetitionDetails['premiumProcessingDocuments'][0]['name']}}</figcaption>
                </div>
              </div>              
            </div>
          </div> 
        </li>
        <li  v-if="[51].indexOf(getUserRoleId)<=-1 && !isCaseApproved && checkProperty(getPetitionDetails ,'status' )!=false
         && checkSharing && checkProperty(petition, 'intStatusDetails','id')==1 && [9].indexOf(checkProperty(petition, 'typeDetails','id'))<=-1"  >
          <div class="Generate_buttons">
            
            <button class="Generate_link" @click="genarateLink()"  v-if=" (checkProperty( petition ,'token') =='' || checkProperty( petition ,'token') ==null || checkProperty( petition ,'token') ==undefined )&& (anonymousAccesLink =='' || this.anonymousAccesLink ==null || this.anonymousAccesLink==undefined )" >
              <img src="@/assets/images/main/link.svg"/>      
              <small>Generate Link</small>    
            </button>
            <button class="copy_link" v-else @click="genarateLink()" >
              <img src="@/assets/images/main/link.svg"/>
              <small>Share Link </small>    
            </button>
          </div>
        </li> 
        <li  v-if="(checkProperty( petition, 'h1bCaseId') || checkProperty( petition, 'rfeCaseId')) &&
         [9,1,2,10].indexOf(checkProperty(petition, 'typeDetails','id'))>-1">
           <div class="dropdown-button-container status-btn_v2 cursor-pointer" @click="redirectToDetails()">
            <vs-button class="borderRadius20 cursor-pointer">
              <span class="statusspan" v-if="checkProperty( petition, 'h1bCaseId') && viewCaseName">{{ viewCaseName }}</span>
              <span class="statusspan" v-if="checkProperty( petition, 'rfeCaseId')">View RFE Case</span>
            </vs-button>
          </div>
        </li>
        <li   v-if="[51].indexOf(getUserRoleId)>-1 && checkProperty( petition ,'statusDetails', 'name') ">
          <!-- <div class="case-destiles-filter">
             <p><span>Status</span>{{ checkProperty( petition ,'statusDetails', 'name') }}</p>  View H-1B Case             
          </div> -->
          <div class="dropdown-button-container mr-4">
            <vs-button class="borderRadius20 status-btn">
              <span class="statusspan " v-bind:class="{

                  [getCaseColors(checkProperty(petition ,'statusDetails','id'))]:true  }">{{checkProperty(petition,'statusDetails','name') }}</span>
              <!-- <span class="status_inProcess">{{ checkProperty( petition ,'statusDetails', 'name') }}</span> -->
            </vs-button>
          </div>
        </li>
        <li class="flowdropdown menu_dropdown actions_dropdown" v-if="petition && (( ( checkProperty(petition ,'type') !=9 &&  checkProperty(petition ,'subTypeDetails' ,'id')!=15 &&  (petition.statusId < 25 || checkRFECase)) || ( checkProperty(petition ,'type')==9 && [32,33].indexOf(petition.statusId)>-1 || petition.statusId < 25 )  ) || ( checkProperty(petition ,'subTypeDetails' ,'id')==15 && petition.statusId < 30 )  ) && checkProperty(petition ,'status') !=false">
                 <div class="d-flex"> 
            <actionsMenu
              v-if="workFlowDetails"
               ref="actionsMenu"
               :isLcaRequiredForPetition="isLcaRequiredForPetition"
               @updatepetition="updatepetition"
              :hideMe="false"
              :formsAndLetters="lettersAndForms"
              :lcaDetails="lcaDetails"
              :workFlowDetails="workFlowDetails"
              :petitionDetails="getPetitionDetails"
              @openFilingFee="openFilingFee"
              @opengenFormsAndLatters="opengenFormsAndLatters"
            />
          </div>
        </li>
        
        <li v-if="false && checkProperty(getPetitionDetails, 'deadlineDate') && (petition.deadlineDate && [1, 2, 50, 51].indexOf(getUserRoleId) < 0)">
            <div class="case-destiles-filter">
             <p><span>Deadline</span>{{ getPetitionDetails['deadlineDate'] | formatDate}}</p>
             <figure class="filter"><img src="/img/WorkflowIcon_active.bbd03c17.svg"></figure>
             </div>
        </li>
        <!-- <li class="ptstatusBar "  v-if="[51].indexOf(getUserRoleId)<0">
          <div class="status_activities" :class="{'status_activities_full':[50,51].indexOf(getUserRoleId)>-1}">
            <label :class="{ 'active':getCaseStatusTab =='showCaseStatus' || ([50,51].indexOf(getUserRoleId)>-1 && getCaseStatusTab !='showCaseStatus')}" @click="reloadCaseHistory('showCaseStatus'); $store.commit('toggleCaseStatusTab','showCaseStatus')"  >Status</label>
            <label v-if="[50,51 ].indexOf(getUserRoleId)<=-1" :class="{ 'active':getCaseStatusTab !='showCaseStatus'}"  @click="reloadCaseHistory('showActivities');$store.commit('toggleCaseStatusTab','showActivities')" >Activities </label>
          </div>
        </li> -->
        
        <li style="display:none">
          <template lang="html">
            <div id="parentx">
              <img
                @click.stop="active=true"
                class="cursor-pointer"
                src="@/assets/images/main/settings.svg"
              />
              <vs-sidebar
                position-right
                parent="body"
                default-index="1"
                class="sidebarx history-sidebar 4"
                spacer
                v-model="active"
              >
                <div class="header-sidebar" slot="header">
                  <h4>Petition History</h4>
                  <figure>
                    <img
                      @click="active=false;gethistory()"
                      src="@/assets/images/main/icon-remove.svg"
                    />
                  </figure>
                </div>
                <VuePerfectScrollbar class="scroll-area">
                  <div class="timeline-sidebar">
                    <ul>
                      <li v-for="(history, index) in petitionhistory" :key="index">
                        <div class="timeline-icon">
                          <i class="icon IP-tick-sign"></i>
                        </div>
                        <div class="timeline-info">
                          <button class="btn active-green ml-0">{{history.createdByRoleName}}</button>
                          <ul>
                            <li>
                              <h3>{{history.title}}</h3>
                              <span>{{history.description}}</span>

                              <span>{{history.createdOn | formatDateTime}}</span>
                            </li>
                          </ul>
                        </div>
                      </li>
                    </ul>
                  </div>
                </VuePerfectScrollbar>
              </vs-sidebar>
            </div>
          </template>
        </li>
        
      </ul> 

   
   
    </div>

		               
 <modal
      name="genaratModal"
      classes="v-modal-sec"
      :min-width="200"
      :min-height="200"
      :scrollable="true"
      :reset="true"
      width="500px"
      height="auto"
    >
      <div class="v-modal">         
          <!---------Contanexdv--------->
          <div class="genarate_body">
            <span @click="$modal.hide('genaratModal')" class="closemodal">
              <em class="material-icons">close</em>
            </span>
            <h4 v-if="!checkProperty( getPetitionDetails ,'token' ) && false" >Your link has been<br/> generated Successfully</h4>
            <h3>Questionnaire</h3>
            <h6>Copy link.</h6>
            <div class="copysec" @click="copyLink('case')">
              <p>{{anonymousAccesLink}}</p>
              <img src="@/assets/images/main/copy.svg">
              <small>Copy</small>
            </div> 
            <div class="orshare"><span>OR</span></div>
            <h6>Share link.</h6>   
               
             <div class="copysec">
               <vs-input placeholder="Enter comma separated emails " class="form-control" v-model="linkShareToemailsText" @keyup="formatEmail('case')" />
               <vs-button @click="shareLink('case')" :disabled="sharing || linkShareToEmailList.length<=0" class="primary-btn" type="filled">Share</vs-button>
             </div>
             <template v-if="checkProperty(petition,'subTypeDetails','id') != 15 && ( checkPetitionLcaRequired && checkLcaRequestLink) ">
              <h3 class="lca_heading">LCA</h3>
             <h6>Copy LCA link.</h6>
            <div class="copysec" @click="copyLink('lca')">
              <p>{{anonymousLcaAccesLink}}</p>
              <img src="@/assets/images/main/copy.svg">
              <small>Copy</small>
            </div> 
            <div class="orshare"><span>OR</span></div>
            <h6>Share LCA link.</h6>   
               
             <div class="copysec">
               <vs-input placeholder="Enter comma separated emails " class="form-control" v-model="lcaLinkShareToemailText" @keyup="formatEmail('lca')" />
               <vs-button @click="shareLink('lca')" :disabled="sharing || lcaLinkShareToemailList.length<=0" class="primary-btn" type="filled">Share</vs-button>
             </div>
            </template>
          </div>
        </div>
        </modal>
        <modal
          name="showReplacementPopup"
          classes="v-modal-sec"
          :min-width="200"
          :min-height="200"
          :scrollable="true"
          :reset="true"
          width="650px"
          height="auto"
        >
        <div class="v-modal profile_details_modal error-modal-space" >
          <div class="popup-header fromDetailsPage">
            <h2 class="popup-title">
              Replace User
            </h2>
            <span @click="$modal.hide('showReplacementPopup');formerrors.msg = ''">
              <em class="material-icons">close</em>
            </span>
          </div>
          <form data-vv-scope="addPaymentForm" class="relative" @submit.prevent @keydown.enter.prevent>
        <div
          class="popup_info"
         
          @click="formErrors = ''"
        >
         
          
        </div>
        <div class="form-container">
          <div class="vx-row" >
            <selectField :wrapclass="'md:full'" :required="true" :vvas="'User'" :optionslist="replacementUsersList" v-model="replaceuserDetails"   :formscope="'addPaymentForm'"  fieldName="replaceuserDetails" label="User" placeHolder="Select"   />    
            <span class="loader loader-v2"  v-if="listLoading"
            ><img src="@/assets/images/main/loader.gif"
          /></span>
          </div>
          <div class="vx-row" >
            <div class="vx-col w-full">
              <div class="form_group">
                <label class="form_label">Comments<em>*</em></label>
                <!-- <vs-textarea
                  data-vv-as="Comments"
                  v-validate="'required'"
                  v-model="replaceUserData.comment"
                  name="comments"
                  class="w-full mb-5"
                /> -->
                <ckeditor data-vv-as="Comments"
                  v-validate="'required'"
                  v-model="replaceUserData.comment"
                  name="comments"
                  class="w-full mb-5"  :editor="editor" :config="editorConfig"></ckeditor>
 
                <span
                  class="text-danger text-sm"
                  v-show="errors.has('addPaymentForm.comments')"
                  >* Comments are required</span
                >
              </div>
            </div>           
          </div>
  
          <div class="text-danger text-sm formerrors padding" v-show="formerrors['msg']" @click="formerrors.msg = ''">
            <vs-alert
              color="warning"
              class="warning-alert reg-warning-alert no-border-radius"
              icon-pack="IntakePortal"
              icon="IP-information-button"
              active="true"
              >{{ formerrors['msg'] }}</vs-alert
            >
          </div>
          <div class="text-danger text-sm formerrors padding" v-show="PaidAmountErrorMsg">
            <vs-alert
              color="warning"
              class="warning-alert reg-warning-alert no-border-radius"
              icon-pack="IntakePortal"
              icon="IP-information-button"
              active="true"
              >{{ PaidAmountErrorMsg }}</vs-alert
            >
          </div>
        </div>
  
        <div class="popup-footer relative">
          <span class="loader"  v-if="loading"
            ><img src="@/assets/images/main/loader.gif"
          /></span>
          <vs-button
            color="dark"
            @click="hideError()"
            class="cancel"
            type="filled"
            >Cancel</vs-button>
          <vs-button
            :disabled="loading"
            color="success"
            @click="updateUserReplacement()"
            class="save"
            type="filled"
            >Replace 
          </vs-button>
        </div>
      </form>
          </div>
        </modal>  
    
 
  </div>
  
</template>
<script>
import { EyeIcon } from 'vue-feather-icons'
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import Vue from "vue";
import FileUpload from "vue-upload-component/src";
import Datepicker from "vuejs-datepicker-inv";
import moment from "moment";
import * as _ from "lodash";
import commonImage from "@/assets/images/main/avatar3.svg"
import docType from "@/views/common/docType.vue"
import actionsMenu from "@/views/common/actionsMenu.vue";
import selectField from "@/views/forms/fields/simpleselect.vue";
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';


export default {
  provide() {
    return {
      parentValidator: this.$validator,
    };
  },
  components: {
    selectField,
    docType,
    EyeIcon,
    FileUpload,
    VuePerfectScrollbar,
    Datepicker,
   actionsMenu
    

  },
  props: {
    loadedFromPreview:false,
    caseUsers:{
       type: [Array],
      default: [],
    },
    lettersAndForms:{
       type: [Array],
      default: [],
    },
    petition: {
      type: [Object ,Array],
      default: null,
    },
    currentRole: {
      type: Number,
      default: null,
    },
    lcaDetails: {
      type: Object,
      default: null,
    },
    workFlowDetails:{
       type: Object,
      default: null,

    },
     configDetails:{
       type: Object,
      default: null,

    },
    isLcaRequiredForPetition:{
      type:Boolean,
      default:false,
    }
  },
  computed: {
    checkRFECase(){
      let returnVal = false;
      if(this.checkProperty(this.petition ,'type')==1 && !this.checkProperty(this.petition,'rfeCaseId') &&  this.checkCaseCreatePermisions  &&
       this.petition.completedActivities.indexOf('USCIS_RECEIVED_RFE') >-1){
        returnVal = true;
      }
      return returnVal;
    },
    checkH4Label(){
      let returnVal = '';
      if(this.checkProperty(this.petition,'dependentsInfo') && (_.has(this.petition['dependentsInfo'],'spouse') || _.has(this.petition['dependentsInfo'],'childrens'))){
        if(this.checkProperty(this.petition,'dependentsInfo','spouse')){
          if(this.checkProperty(this.petition['dependentsInfo'],'spouse','h4Required') && this.checkProperty(this.petition['dependentsInfo'],'spouse','h4EADRequired')){
            returnVal = 'H4/H4 EAD';
            return returnVal;
          }else if(this.checkProperty(this.petition,'dependentsInfo','childrens') && this.checkProperty(this.petition['dependentsInfo'],'childrens','length')>0 ){
            let findObj = _.find(this.petition['dependentsInfo']['childrens'],{'h4Required':true,'h4EADRequired':true});
            if(findObj){
              returnVal = 'H4/H4 EAD';
              return returnVal;
            }
          }else if(this.checkProperty(this.petition['dependentsInfo'],'spouse','h4Required')){
            returnVal = 'H4';
            return returnVal;
          }else if(this.checkProperty(this.petition['dependentsInfo'],'spouse','h4EADRequired')){
            returnVal = 'H4 EAD';
            return returnVal;
          }else{
            if(this.checkProperty(this.petition,'dependentsInfo','childrens') && this.checkProperty(this.petition['dependentsInfo'],'childrens','length')>0 ){
              _.forEach(this.petition['dependentsInfo']['childrens'],(item)=>{
                if(_.has(item,'h4Required') && this.checkProperty(item,'h4Required') && _.has(item,'h4EADRequired') && this.checkProperty(item,'h4EADRequired') ){
                  returnVal = 'H4/H4 EAD';
                  return returnVal;
                }else if (this.checkProperty(item,'h4Required')){
                  returnVal = 'H4';
                  return returnVal;
                }else if (this.checkProperty(item,'h4EADRequired')){
                  returnVal = 'H4 EAD';
                  return returnVal;
                }
              })
            }
          }
        }else{
            if(this.checkProperty(this.petition,'dependentsInfo','childrens') && this.checkProperty(this.petition['dependentsInfo'],'childrens','length')>0 ){
              _.forEach(this.petition['dependentsInfo']['childrens'],(item)=>{
                if(_.has(item,'h4Required') && this.checkProperty(item,'h4Required') && _.has(item,'h4EADRequired') && this.checkProperty(item,'h4EADRequired') ){
                  returnVal = 'H4/H4-EAD';
                  return returnVal;
                }else if (this.checkProperty(item,'h4Required')){
                  returnVal = 'H4';
                  return returnVal;
                }else if (this.checkProperty(item,'h4EADRequired')){
                  returnVal = 'H4EAD';
                  return returnVal;
                }
              })
            }
        }
        return returnVal;
      }
    },
    isSubmitUscisCompleted(){
     
      if(
     
       ( this.petition )
        && 
         ( _.has(this.petition ,'completedActivities')
         
           &&  this.petition.completedActivities.indexOf('SUBMIT_TO_USCIS') >-1
          
         )
  
      ){
       return true;
  
      }else{
        return false
      }
    },
    checkLcaRequestLink(){
      let returnVal =false;
      let wf = _.cloneDeep(this.workFlowDetails);
      if(wf && _.has(wf ,'config')){
        let adminsactiVityList = _.find(wf.config , {"code":'MANAGER_LIST'});
        let adminsList=[]
        if(adminsactiVityList && adminsactiVityList.editors){
          adminsList = _.map(adminsactiVityList.editors, 'roleId');
        }
        let lcaSubmit = _.find( wf.config ,{"code":"LCA_SUBMIT"});
        let lcaList=[]
        if(lcaSubmit && lcaSubmit.editors){
          lcaList = _.map(lcaSubmit.editors, 'roleId');
        }
        // if([3,4].indexOf(this.getUserRoleId) > -1 || adminsList.indexOf(this.getUserRoleId) > -1 || _.find(lcaSubmit['editors'] ,{"roleId":this.getUserRoleId})){
        //   returnVal =true;
        // }
         if([3,4].indexOf(this.getUserRoleId) > -1 || adminsList.indexOf(this.getUserRoleId) > -1 || lcaList.indexOf(this.getUserRoleId) > -1){
          returnVal =true;
        }
        if([14].indexOf(this.getUserRoleId)>-1 && this.petition.completedActivities.indexOf('ASSIGN_LCA_EXECUTIVE')>-1 )
        {returnVal =true;}
     }
      return returnVal; 
    },
    checkReplaceBtnSubmition(){
      let returnVal =false;
      if(_.has(this.workFlowDetails ,'config')){
        let adminsactiVityList = _.find(this.workFlowDetails.config , {"code":'MANAGER_LIST'});
        let adminsList=[]
        if(adminsactiVityList && adminsactiVityList.editors){
          adminsList = _.map(adminsactiVityList.editors, 'roleId');
        }
        if(adminsList.indexOf(this.getUserRoleId) > -1 || [3,4].indexOf(this.getUserRoleId) > -1  ){
          returnVal =true;
        }
      }
      return returnVal; 
    },
    checkReplaceBtn(){
      
    if(this.petition && _.has( this.petition , 'completedActivities')){
      let responseList = ['PREPARE_PERM_APPLICATION','USCIS_RECEIVED_RFE','USCIS_DENIED','USCIS_WITHDRAWN','USCIS_APPROVED','DOL_APPROVED','DOL_DENIED','DOL_AUDIT','DOL_RECEIVED_RFE' ,'DOL_WITHDRAWN']
      return !(responseList.some((item)=>{ return this.petition.completedActivities.indexOf(item)>-1}));
      

    }else{
      return false;
    }
      
      
    },
    isAdmin(){
      if(this.workFlowDetails && _.has(this.workFlowDetails ,'config' ) &&  this.workFlowDetails['config']){
        let adminsactiVityList = _.find(this.workFlowDetails.config , {"code":'MANAGER_LIST'});
        if(adminsactiVityList && adminsactiVityList.editors){
          let adminsList = _.map(adminsactiVityList.editors, 'roleId');
          return adminsList.indexOf(this.getUserRoleId)>-1;
        }else{
          return false;
        }
    
      }else{
        return false;
      }
    },

    checkSharing(){
      let returnVal = true;
      if(_.has( this.petition,'curWorkflowActivity')){
        if([

                'USCIS_APPROVED',
                'USCIS_RECEIVED_RFE',
                'USCIS_DENIED',
                'USCIS_WITHDRAWN',
          
        'DOL_APPROVED' ,'DOL_RECEIVED_RFE' ,'DOL_DENIED' ,'DOL_WITHDRAWN'
      
      ].indexOf(this.petition['curWorkflowActivity']) >-1){
           returnVal =false
        }

      }
     return returnVal;
    },
    //petition['assignRoleLogs'].length>0 && 
    checkActiveUsers(){
      if(this.checkProperty( this.petition ,'assignRoleLogs' ,'length')>0){
        let activeUsers = _.filter(this.petition['assignRoleLogs'] ,(user)=>{
          return this.checkProperty(user, 'hide') !=true;
        });
        if(activeUsers && activeUsers.length>0 ){
          return true
        }else{
          return false;

        }


      }else{
        return false;
      }

    },
    
    checkAccessTokenExists(){
      if(this.checkProperty(this.getPetitionDetails ,"token")){
        return true;

      }else{
        return false;

      }

    },
   

      checkReassignmentPermission(){
      let self = this;
         let petitionDetails = this.getPetitionDetails;
         let workFlowDetails =  this.getWorkFlowDetails;
         let roleaArray =[];
          let returnValue =false;
         if(self.checkProperty( petitionDetails, 'reassignLogs' ,"length")>0){
            roleaArray = petitionDetails['reassignLogs'];
            let currentUser = _.cloneDeep(roleaArray[0]);
             if(self.checkProperty( currentUser,'userId')==self.checkProperty(self.getUserData ,"_id") ){
               returnValue = true;
             }


         }else{
           //check current activity editors roles

         }
       
       
         return returnValue
    },

    
    getPetitionTab(){
            return this.$store.state.selectedPetitionTab
        },
   

    

     findSkipedActivityList(){
       let skipedactivityList =[];
      let returnVal =false;
      let getWorkFlowDetails =  this.getWorkFlowDetails;
    if(this.getPetitionDetails && this.checkProperty(this.getPetitionDetails , 'nextWorkflowActivity') && _.has(getWorkFlowDetails ,"config")){
        
         let config  = getWorkFlowDetails['config'];
       let petitionCurrentActivityIndex = _.findIndex(config ,{"code": this.getPetitionDetails['nextWorkflowActivity'] });
       let completedActivityList = this.getPetitionDetails['completedActivities'];
       
       if(petitionCurrentActivityIndex>-1 && completedActivityList.length>0 && (completedActivityList.indexOf("SUBMIT_TO_USCIS")<=-1 )){
        _.forEach(config ,(activityItem ,index)=>{
          if(index<petitionCurrentActivityIndex){

            if(completedActivityList.indexOf(activityItem['code'])<=-1   && _.has(this.assignMentUsersList ,activityItem['code'])){

              if(completedActivityList.indexOf("CASE_APPROVED") >-1){

                if([ 'ASSIGN_DOCUMENTATION_MANAGER','ASSIGN_DOCUMENTATION_EXECUTIVE'].indexOf(activityItem['code']) >-1){

                    skipedactivityList.push(activityItem['code']);

                }

              }else{
                skipedactivityList.push(activityItem['code']);


              }
             

            }

          }


        })
       }
            
    }
    if(
      (this.isCaseApproved && (skipedactivityList.indexOf('ASSIGN_DOCUMENTATION_EXECUTIVE')>-1 || skipedactivityList.indexOf('ASSIGN_DOCUMENTATION_MANAGER')>-1  ) )
     || (!this.isCaseApproved && skipedactivityList.length>-1)
     ){
      returnVal =true;
    }
   return returnVal;

    },

    //uploadScanedFilsList
    checkuploadScnnedFiles(){
       let val = false;
       if(this.uploadScanedFilsList.length > 0){
         _.forEach(this.uploadScanedFilsList,(item)=>{
           if(!(_.has(item ,"name")) || item['name'] =='' || item['name'].trim()==''  ){
             val =true
           }
         })

       }else{
         val = true;
       }
       return val;
    },
   
    checkPaymentIntigration(){
      
      let petitionDetails = this.$store.state.petitionDetails;
      let workFlowDetails = this.$store.state.workFlowDetails;
      let returnVal =false;
      let code = "PAYMENT_INTEGRATION";
      if(workFlowDetails && _.has( workFlowDetails,'config') ){
        
        let requestPetitionerSign = _.find(workFlowDetails.config ,{'code':code});
        if(
         // (_.has(requestPetitionerSign ,"editors") &&  _.find(requestPetitionerSign.editors ,{"roleId":this.getUserRoleId})) &&
           this.checkProperty(requestPetitionerSign ,'actionRequired') =="Yes"
        ){
          returnVal =true;

        }
        

      }
      return returnVal;

    },
    
   
    
   
    getPetitionActionStatus(){
      return this.$store.state.showPetitionActionBtn
    },
    checkSubmitToLawFirm(){
     let returnValue =false;
     let processActivityList= [ "SUBMIT_TO_LAW_FIRM", "CASE_APPROVED", "LCA_SUBMIT","LCA_CERTIFIED_FOR_PETITION" , "SUBMIT_TO_USCIS", "USCIS_APPROVED" , "USCIS_RECEIVED_RFE" , "USCIS_DENIED" ];
      if(_.has(this.getPetitionDetails ,'curWorkflowActivity') && _.has(this.getPetitionDetails , 'nextWorkflowActivity')){
        let  curWorkflowActivity = _.cloneDeep(this.getPetitionDetails['curWorkflowActivity']);
        let  nextWorkflowActivity = _.cloneDeep(this.getPetitionDetails['nextWorkflowActivity']);
     
      
        if(
          // curWorkflowActivity == "SUBMIT_BY_BENEFICIARY" && nextWorkflowActivity == "SUBMIT_TO_LAW_FIRM"   //check lCA HERE
          (processActivityList.indexOf(nextWorkflowActivity) >-1)
           ){
              
          
          returnValue =true

        }

      }
      return  returnValue;

    },
    checkAssignmentActivity(){
      let returnValue =false;
      if(this.checkProperty(this.getPetitionDetails ,'curWorkflowActivity') && this.checkProperty(this.getPetitionDetails , 'nextWorkflowActivity')){
        let  curWorkflowActivity = _.cloneDeep(this.checkProperty(this.getPetitionDetails ,'curWorkflowActivity'));
        let  nextWorkflowActivity = _.cloneDeep(this.checkProperty(this.getPetitionDetails ,'nextWorkflowActivity'));
       
        if(nextWorkflowActivity.includes('ASSIGN_') || nextWorkflowActivity =="CASE_APPROVED" ){
          
          returnValue =true

        }

      }
      return returnValue;

    },
    checkActionconditions() {
      if(this.getPetitionDetails && this.getWorkFlowDetails && this.getUserRoleId !=13){
        return true;
      }else{
        return false;
      }
      

     

    },
    checkUserRoleAssignee(){
      let returnVal = [];
      if(this.checkProperty(this.petition, 'assignRoleLogs') && this.checkProperty(this.petition, 'assignRoleLogs', 'length')>0 ){
        let assignRoleList = this.checkProperty(this.petition, 'assignRoleLogs')
        _.forEach(assignRoleList,(item)=>{
          if(!(_.has(item,'autoAssign'))){
            item =Object.assign(item,{ 'autoAssign':false});
          }
        })
        assignRoleList.sort(function(a,b){return b['autoAssign']-a['autoAssign']});
        returnVal = _.cloneDeep(assignRoleList)
        return returnVal
      }
      else{
        return returnVal
      }
    }
  },
 
  data: () => ({
    viewCaseName:'',
    editor: ClassicEditor,
    editorConfig: {
        toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
    },
    listLoading:false,
    selectedUser:null,
    replaceUserData: {
      "petitionIds": [],
      "toUserId": "",
      "fromUserId": "",
      "comment":""
	  },
    loading:false,
    replaceuserDetails:null,
    replacementUsersList:[],
    PaidAmountErrorMsg:'',
    caseStatusTab:"Status",
   uploadMainDocuments:[],
    updateTrackingFormData:{
      "petitionId": "",
      "action": "COURIER_TRACKING", // "UPDATE_USCIS_RECEIPT_NUMBER",
       "items": [{
         "trackingId": "",
         "trackingUrl": "",
         "courier": "",
         "courierCode": "",

       }

       ],

    },

    notifyPetitioner:true,
    emailDocsForSign:false,
    selectedNewCaseType:null,
    selectedNewCaseSubType:null,
    assignedUserList:[],
    selectedAssignedUsers:[],
    caseTypeCahnging:false,
    visatypes:[],
    visasubtypes:[],
                



    ///documentTypes:[{"_id":"Original" ,"name":"Original"} ,{"_id":"Electronic" ,"name":"Electronic"} ],
    documentTypes:["Original" ,"Electronic" ],

    premiumProcessingFormErrors:'',
    premiumProcessingComment:'',
    premiumProcessing:false,
    updatingPremiumProcessing:false,
    premiumProcessingFiles:[],
    premiumProcessingFilesUploading:false,

    deadLineformErrors:'',
    settingDeadLine:false,
    deadlineDate:null,
    masterSocList:[],
    settingCaseNumber:false,
     setCode:false,
      newCaseCode:'',
      confCaseCode:'',

  showDataPicker:true,
    lcaLinkShareToemailText:'',
    linkShareToemailsText:'',
    linkShareToEmailList:[],
    lcaLinkShareToemailList:[],
    sharing:false,
    showToolTip:false,
    anonymousAccesLink:'',
    anonymousLcaAccesLink:'',
    payFrequencyList:[  "Monthly","Yearly" ],
    submittitle:"Re-Assign",
    submitToLawFirmActionPopup:false,
    selectedAssignToReviewer:null,
    assignToReviewerPopUp:false,
    assignToReviewerMsg:'',
    assignToReviewerComment:'',
    submiTingAssignment:false,
    peoplelist: { 
        wheelSpeed: 0.6,
      },
    isEnableSendforReview:true,
     assignMentUsersList: {
      "ASSIGN_SUPERVISOR":"SUPERVISOR_LIST",
      "ASSIGN_PARALEGAL":"PARALEGAL_LIST",
      "ASSIGN_DOCUMENTATION_MANAGER":"DOCUMENTATION_MANAGER_LIST",
      "ASSIGN_DOCUMENTATION_EXECUTIVE":"DOCUMENTATION_EXECUTIVE_LIST",
      "ASSIGN_ATTORNEY":"ATTORNEY_LIST",
      },
    fileModel:[],
    uploadScanedFilsList:[],
    updateTrackingLoading:false,
    trackingErrors:'',
    filesAreuploading:false,
    editFilngFee:false,
    uploading:false,
    validateLcaFiles:true,
    filedDate:null,
    certifiedDate:null,
    lcastatuses:[],
    lcaDocuments:[],
    filingFeeformerrors:'',
     active: false,
     petitionhistory: [],
     filingFeeComment:'',
     emailInvoice:true,
     filingFeesPopup:false,
     submitingFilingFee:false,
      
   

 disable_uploadBtn: false,
        fuploder: false,
    
    filingFeeData: [
      {
        amount: null,
        invoice: false,
        description: "",
      },
    ],
    tracking: {documents:[],receiptNumber:null,receiptName:null},
    uscisstatuslist: [
      {
        value: "USCIS_APPROVED",
        text: "Case Approved",
      },
      {
        value: "USCIS_RECEIVED_RFE",
        text: "RFE Received",
      },
      {
        value: "USCIS_DENIED",
        text: "Case Denied",
      },
      {
        value: "USCIS_WITHDRAWN",
        text: "Case Withdrawn",
      },
    ],
    
    casestatus: null,
    uscisdocument: [],
    dueDate:null,
    usciscomments: "",
    requestsignPopup: false,

    assigntoRoletitle: "",
    requestsignformcomments: "",
    assigntoroletxt: "",

    
checkFormsandLatters:false,
 lcaUpdateForm: false,
 lcastatusSelected:null,
 documents:[],
 actioncomment:'',
paralegalformerrors:'',
disabled_btn:false,
                    
                    




    filingFeeData: [
      {
        amount: null,
        invoice: false,
        description: "",
      },
    ],
    tracking: {documents:[],receiptNumber:null,receiptName:null},
    uscisstatuslist: [
      {
        value: "USCIS_APPROVED",
        text: "Case Approved",
      },
      {
        value: "USCIS_RECEIVED_RFE",
        text: "RFE Received",
      },
      {
        value: "USCIS_DENIED",
        text: "Case Denied",
      },
      {
        value: "USCIS_WITHDRAWN",
        text: "Case Withdrawn",
      },
    ],
    trackingdoc: [],
    issuedDate: null,
    receivedDate: null,
    dueDate: null,
    openDate: new Date().setFullYear(new Date().getFullYear()),
    startEligibleDate: new Date().setFullYear(new Date().getFullYear()),
    updateTrackingPopup: false,
    updateUSCISstatusPopup: false,
    usciscUpdateStatusError:'',
    usciscUpdating:false,
    
    
    casestatus: null,
    uscisdocument: [],
    usciscomments: "",
   
    assigntoRoletitle: "",
    requestsignformcomments: "",
    requestsignCommentError:false,
    requestsigning:false,
    assigntoroletxt: "",
    chooseassigntorole: "",
    assignedRoleId: null,
    assigntoRolePopup: false,
    approvalstatus: false,
    approveaction: false,
    rolesubmitaction: "",
    replaceParalegaltitle: "Replace Paralegal",
    paralegalformerrors: "",
    supervisorcomments: "",
    assignedrolecomments: "",
    paralegalcomments: "",
    petitionhistory: [],
    SubmitParalegal: false,
    SuccessQuestionnaire: false,
    AssignParalegal: false,
    paralegalModel: [],
    assigntoroleModel: [],
    supervisorMode: [],
    paralegallist: [],
    supervisorlist: [],
    selectedroleslist: [],
    disabledSelectedroleslist:false,
   

    replaceParalegal: false,
    approveParalegalform: false,
    active: false,
    approveRejectPop: false,
    approveRejectTitle: "Approve Questionnire",
    approveRejecInstructions: "",
    actionType: "approved",
    pactiontype: "ASSIGN_PARALEGAL",
    is_change_paralegal: false,
    is_change_superwiser: false,
    uploadSignedPopup: false,
    documents: [],
    documentData: [
      {
        type: "Forms, Letters and Others",
        documentUploaded: [],
      },
    ],
    formsData: [],
    courierList: [],
    formsAndLettersList:[],
    scannedCopiesList:[],
    approveOrRejectDocs:false,
    signerList:[],
    selectedSigner:null,
    linkGenareating:false,
    copyingLink:false,
    webBaseUrl:'',
    updatingLca:false,
    formerrors:{
      msg:''
    },
    isCaseNumberEdit:false,
    documentType:null,
    isInvaliedFileName:false,
   number:'',
   sortKey: {},
   lcaToken:'',
   caseToken:'',
   encodedString:'',
   casePermissionDetail:null,
    
  }),
  methods: {
    getPetitionDetailsForPermisson(){
      if(this.checkProperty(this.petition,'rfeCaseId') || this.checkProperty(this.petition,'h1bCaseId')){
        let payLoad ={
          petitionId:''
        };
        if(this.checkProperty(this.petition,'h1bCaseId')){
          payLoad['petitionId'] = this.checkProperty(this.petition,'h1bCaseId');
        }
        if(this.checkProperty(this.petition,'rfeCaseId')){
          payLoad['petitionId'] = this.checkProperty(this.petition,'rfeCaseId');
        }
        this.$store.dispatch("commonAction",{data:payLoad ,path:'/users/list'}).then((response)=>{
          this.casePermissionDetail = response;
        }).catch((err)=>{

        })
      }
    },
    redirectToDetails(){
      if(this.checkProperty(this.petition, 'h1bCaseId')){
        let routedId = this.checkProperty(this.petition, 'h1bCaseId');
        this.$router.push({ path: `/petition-details/${routedId}` ,query: {'filter':this.encodedString} }).catch(err => {})
      }
      if(this.checkProperty(this.petition, 'rfeCaseId')){
        let routedId = this.checkProperty(this.petition, 'rfeCaseId');
        this.$router.push({ path: `/petition-details/${routedId}` ,query: {'filter':this.encodedString} }).catch(err => {})
      }
    },
    opengenFormsAndLatters(){
      this.$emit('opengenFormsAndLatters');
    },
    hideError(){
      this.$modal.hide('showReplacementPopup');
       this.formerrors.msg = '';
    },
    updateUserReplacement(){
      this.$validator.validateAll('addPaymentForm').then(result => {
        if (result) {
          let Payload = {
            "petitionIds": [],
            "toUserId": "",
            "fromUserId": "",
            "comment":""
          }
          Payload['toUserId'] = this.checkProperty(this.replaceuserDetails,'_id')
          Payload['fromUserId'] = this.checkProperty(this.selectedUser,'userId');
          Payload['comment'] = this.replaceUserData.comment
          let obj= {
            petitionId:this.checkProperty(this.petition,'_id'),
            entityType:'case'
          }
          let path = '/petition-common/replace-user'
          if(this.checkProperty(this.petition,'subTypeDetails','id') ==15){
            obj['entityType'] = 'perm'
           // path = '/perm-common/replace-user'
          }

          Payload['petitionIds'].push(obj);

          this.loading = true
          this.$store.dispatch("commonAction" ,{data:Payload,'path':path}).then((response) =>{
            this.loading = false
            this.$modal.hide('showReplacementPopup')
            this.showToster({message:response.message,isError:false });
            this.updatepetition('');
          })
          .catch((err) =>{
            this.loading = false
            this.formerrors['msg'] = err
            this.showToster({message:err,isError:true });
          })
        }
      })  
    },
    userReplacement(item) {
      this.replacementUsersList =[]
      this.PaidAmountErrorMsg=''
      this.replaceuserDetails = null
      this.replaceUserData = {
        "petitionIds": [],
        "toUserId": "",
        "fromUserId": "",
        "comment":""
	    };
      this.selectedUser = item
      let selectUserId = null
      let matcher = {
        roleIds:[],
        title: '',
        searchString: '',
        statusIds: [],
        stateIds: [],
        locationIds: [],
        createdDateRange: [],
        page: this.page,
        perpage: 10000000,
        branchIds: [],
        subTypeIds:[],
        "fromUserId":''
      };
      if(this.checkProperty(this.petition, 'subTypeDetails', 'id')){
        matcher["subTypeIds"].push(this.checkProperty(this.petition, 'subTypeDetails', 'id'))
      }
      if(this.checkProperty(this.selectedUser,'roleId')){
        matcher['roleIds'].push(this.checkProperty(this.selectedUser,'roleId'))
      }
      if(this.checkProperty(this.selectedUser,'userId')){
        selectUserId = this.checkProperty(this.selectedUser,'userId')
        this.replaceUserData['fromUserId'] =selectUserId; 
        matcher['fromUserId'] = selectUserId;
      }

      let query = {};
      query['branchId'] = this.checkProperty(this.petition,'branchId')
      query['page'] = 1;
      query['perpage'] = 10000000;
      query['matcher'] = matcher;
      query['sorting'] = this.sortKey;
      query['getMasterData'] = true;
     this.listLoading = true
      this.$store
      .dispatch("getList",{data:query ,path:'/users/list'} )
      .then(response => {
        let list = response.list;
        this.listLoading = false
        if(list){
          list =_.filter(list ,(item)=>{
            return selectUserId !=item._id
          })
          if(list && list.length>0){
            _.forEach(list,(item)=>{
              item['id'] = item['_id'];
                if(_.has(item ,'name' ) && _.has(item ,'email' )){
                  item['name'] = item['name']+" ("+item['email']+")";
                }
              })
              this.replacementUsersList = _.cloneDeep(list) 
          }
          else{
            this.PaidAmountErrorMsg=`${this.selectedUser.roleName}(s) are not found.`
          }
        } 
        else{
          this.PaidAmountErrorMsg=`${this.selectedUser.roleName}(s) are not found.`
        }
        }).catch((err)=>{
          this.listLoading = false
         
        
        })
    },
    openFilingFee(){
      
      this.$emit('openFilingFee');
    },
    reloadCaseHistory(data){
       this.$emit("reloadCaseHistory" ,data);
    },
   updatepetition(tabname){
    if(tabname){
        this.$emit("updatepetition", tabname);

    }else{
        this.$emit("updatepetition", "Case Details");

    }

    },
    filameChenged(fileindex ,documents) {
            this.disable_uploadBtn = false;

            
                if (documents.length > 0) {
                    _.forEach(documents, (fl, value) => {
                        //let fname = fl.name;
                        let fname = fl.document.name;
                        fname = fname.trim();
                        

                        if (!fname) {
                            this.disable_uploadBtn = true;
                        }
                    });
                }
         

        },

   uploadToS3MainDocuments( docs  , item){
             docs = docs.map(
                item =>
                (item = {
                    status:true,
                    name: item.name,
                    file: item.file,
                    document: "",
                    path:'',
                    mimetype: item.type
                })
            );


            if (docs.length > 0) {
                let filIndex = 0;
                this.filesAreuploading = true;
                this.disable_uploadBtn = true;
                item['filesAreuploading'] =true;
                docs.forEach(doc => {
                     
                     
                         
                    let formData = new FormData();
                    formData.append("files", doc.file);
                    formData.append("secureType", "private");
                     formData.append("getDetails", true);
                    
                       
                    this.$store.dispatch("uploadS3File", formData).then(response => {
                         filIndex++;
                         if (filIndex >= this.uploadMainDocuments.length) {
                                this.filesAreuploading = false;
                                this.disable_uploadBtn = false;
                                item['filesAreuploading'] =false;
                            }
                        

                        response.data.result.forEach(urlGenerated => {
                            //alert(JSON.stringify(urlGenerated));
                            doc.document = urlGenerated;
                            doc.path = urlGenerated;
                           //this.uploadMainDocuments.push(doc);
                            urlGenerated.status =true;
                           item['documents'].push( urlGenerated);
                        });

                        
                      
                    });
                
                    
                });
            }

        },

     openTrackingDetailsForm() {
         
            this.uploadMainDocuments = [];
            let actionType ="UPDATE_USCIS_RECEIPT_NUMBER";// "COURIER_TRACKING";  ;
             this.trackingErrors ='';
            this.filesAreuploading =false;
            this.updateTrackingLoading =false;
          
           

            this.updateTrackingFormData ={
              "petitionId": "",
              "action": "COURIER_TRACKING", // "UPDATE_USCIS_RECEIPT_NUMBER",
              "items": [
                {
                  "trackingId": "",
                  "trackingUrl": "",
                  "courier": "",
                  "courierCode": "",
                  "courierDetails":null,
                }

              ],

            } ;
             this.updateTrackingFormData['petitionId'] = this.checkProperty(this.petition ,'_id');
            if(actionType =='UPDATE_USCIS_RECEIPT_NUMBER' ){
               this.updateTrackingFormData ={
                "petitionId": "",
                "action": "UPDATE_USCIS_RECEIPT_NUMBER", // "COURIER_TRACKING",
                "items":[],
               }

                 let benItem= {

                    "receiptName": "",
                    "receiptNumber": "",
                     "documents": [],
                     "userType": "Beneficiary",
                     "userName": "Bnf Name",
                     'filesAreuploading':false

                  };
                  benItem['userName'] = this.checkProperty( this.petition,'beneficiaryInfo' ,'name');

                   this.updateTrackingFormData['items'].push(benItem);


            }     

           
            
            if( this.updateTrackingFormData['action'] =="UPDATE_USCIS_RECEIPT_NUMBER"){
              //Spouse info
              if(this.checkProperty( this.petition,'dependentsInfo' ,'spouse')){
                if(this.checkProperty( this.petition['dependentsInfo']['spouse'] ,'h4Required')){

                  let spouseItem = {

                    "receiptName": "",
                    "receiptNumber": "",
                     "documents": [],
                     "userType": "Spouse",
                     "userName": "Bnf Name",
                      'filesAreuploading':false

                  }
                  spouseItem['userName'] = this.checkProperty( this.petition['dependentsInfo']['spouse'] ,'name');
                  this.updateTrackingFormData['items'].push(spouseItem );

                }
              }


                //child 
            if(this.checkProperty( this.petition,'dependentsInfo','childrens')){
              if(this.checkProperty( this.petition['dependentsInfo'],'childrens' ,'length')>0){
                _.forEach(this.petition['dependentsInfo']['childrens'] ,(child)=>{

                  if(this.checkProperty(child , 'h4Required')){

                    let childItem = {

                    "receiptName": "",
                    "receiptNumber": "",
                     "documents": [],
                     "userType": "Children",
                     "userName": "Bnf Name",
                    'filesAreuploading':false,
                    "childrenId":''

                  }
                  childItem['childrenId'] = this.checkProperty(child , '_id');
                  childItem['userName'] = this.checkProperty(child , 'name');
                   this.updateTrackingFormData['items'].push(childItem );

                  }

                })

              }

            }

            }
          this.updateTrackingFormData['petitionId'] = this.checkProperty(this.petition ,'_id');
             this.$validator.reset();
            this.$modal.show('trackingDetailsForm');
            
             
        }, 
      changedCourierInfo(item) {
      
        if(item){

          item['courier'] = '';
          item['courierCode'] ='';
          item['trackingUrl'] ='';

          item['courier'] = this.checkProperty(item ,'courierDetails','name');
          item['courierCode'] =this.checkProperty(item ,'courierDetails','code');
          item['trackingUrl'] =this.checkProperty(item ,'courierDetails','track_url');



      
      }


      
             
           // this.tracking.trackingUrl = this.tracking["courier"]["code"];
           // this.tracking.courierCode = this.tracking["courier"]["code"];
        },

    updateTrackingInfo(){
        this.trackingErrors ='';
            this.$validator.validateAll("trackingform").then((result) => {
             
              if(result){
                let path ="/petition/manage-tracking-details";
                this.updateTrackingLoading =true;
                this.updateTrackingFormData['petitionId'] = this.checkProperty(this.petition ,'_id');
                let postData = _.cloneDeep(this.updateTrackingFormData);

                this.$store.dispatch("commonAction" ,{data:postData,'path':path}).then((rx) =>{
                  this.trackingErrors ='';
                  this.filesAreuploading =false;
                  this.updateTrackingLoading =false;
                  this.showToster({message:rx.message,isError:false });
                  this.$modal.hide('trackingDetailsForm');
                  })
                  .catch((err) =>{
                      this.trackingErrors =err;
                      this.filesAreuploading =false;
                      this.updateTrackingLoading =false;
                      //this.showToster({message:err,isError:true }); 
                  
                  })
              }
            })


    },
    //notifyPetitioner==  {{notifyPetitioner}} --  emailDocsForSign == {{ emailDocsForSign}} 
    checkSendAttachments(action=''){
      setTimeout(() =>{
            if(this.notifyPetitioner && action=='notifyPetitioner'){
          //  this.emailDocsForSign =true;
         
            }
            
            if(this.emailDocsForSign && action=='emailDocsForSign'){
              this.notifyPetitioner =true;
            }

      } ,10)
      
    },
     getvisatypes(){
      this.$store.dispatch("getvisatypes").then(response => {
        this.visatypes = response;
      });
    },
    getvisasubtypes(vsType){
      
     Object.assign(this.formerrors , {msg:''});
    
    if(this.selectedNewCaseType && _.has(this.selectedNewCaseType ,"id")){
       this.visasubtypes =[];
      this.selectedNewCaseSubType = null;
     
    
        let item ={
          matcher:{
             // "searchString":this.searchtxt,
             "petitionType":parseInt(this.selectedNewCaseType['id'])

          },   
          page:this.page,
          perpage: this.perpage,
          category: "petition_sub_types",
          
        };

        this.$store.dispatch("getMasterData",item ).then(response => {
           this.visasubtypes = response.list;
           this.visasubtypes = _.filter(response.list ,(item)=>{
             return  this.checkProperty(this.getPetitionDetails ,'subTypeDetails','id') !=item['id'];
           })
          
           });
        this.$validator.reset();
        }
    },
    changeCaseTypeAction(){
        this.$validator.validateAll('changeCaseTypeForm').then((result) => {
          this.caseTypeCahnging= false;
          if(result){

            if(this.checkProperty(this.getPetitionDetails ,'subTypeDetails','id') ==this.checkProperty(this.selectedNewCaseSubType ,'id')){
              
              Object.assign(this.formerrors ,{msg:'Selected case subtype same as current case sub type.'});
              return false
            }
            Object.assign(this.formerrors ,{msg:''});
            let postData = {
                "petitionId": "",
                "subType": '',
                "typeName": "",
                "subTypeName": "",
                "oldSubTypeName": "",
                "notifyUserIds": []

            }
             postData['petitionId'] = this.checkProperty( this.getPetitionDetails ,'_id')
             postData['subType'] = this.checkProperty(this.selectedNewCaseSubType ,'id'),
             postData['typeName'] = this.checkProperty(this.getPetitionDetails ,'typeDetails','name'),
             postData['subTypeName'] = this.checkProperty(this.selectedNewCaseSubType ,'name'),
             postData['oldSubTypeName'] = this.checkProperty(this.getPetitionDetails ,'subTypeDetails','name'),
             postData['notifyUserIds'] =  this.selectedAssignedUsers.map((item)=>item._id)
              
           this.caseTypeCahnging= true;
             this.$store
              .dispatch("commonAction", {"data":postData ,"path":"/petition/change-subtype"})
              .then(response => {

                this.showToster({message:response.message,isError:false });
                 this.openchangeCaseTypePopup(false);
                   this.caseTypeCahnging= false;
                setTimeout(()=>{
                   
                   //  let tabName= this.getPetitionTab;
                     this.$emit("updatepetition" ,'Case Details');
                   
                   })
               
               
                                               
                                
              })
              .catch((error)=>{
                  this.caseTypeCahnging= false;
                 Object.assign(this.formerrors ,{msg:error})
              })

          }

        })

    },
    openchangeCaseTypePopup(action=false){
       this.selectedNewCaseType=null;
       this.selectedNewCaseSubType =null;
       this.selectedAssignedUsers =[];
       this.caseTypeCahnging= false;
       this.$validator.reset();
       this.assignedUserList = [];
      Object.assign(this.formerrors ,{msg:''})
     this.selectedNewCaseType = this.checkProperty(this.getPetitionDetails ,'typeDetails');
     this.getvisasubtypes();
       if(action){

         let postData ={
            "petitionId": '',
            "page": 1,
            "perpage":1000

         }
        
        postData['petitionId'] = this.checkProperty( this.getPetitionDetails ,'_id')
         

          this.$store
              .dispatch("commonAction", {"data":postData ,"path":"petition/assigned-user-list"})
              .then(response => {
               
                if(this.checkProperty(response , 'list' ,'length') >0){
                    this.assignedUserList = response['list']
                }
                                               
                                
              })
              .catch((error)=>{
                
              })

            this.$modal.show('changeCaseTypeModal')
          
       }else{
           this.$modal.hide('changeCaseTypeModal')
       }
     

    },
    fileNameChenged(fl) {
            let fname = fl["name"];
            fname = fname.trim();
            this.isInvaliedFileName = false;
            if (!fname) {
                this.isInvaliedFileName = true;
            }
        },
    download_or_view(item){
     
      this.$emit('download_or_view' ,item)
    },
    removePremiumProcessingFiles(index){
      this.premiumProcessingFiles.splice(index ,1)
    },

    uploadPremiumProcessingDocuments(model) {

            let temp_count = 0;
            
          
            this.disabled_btn = true;
            let mapper = model.map(
                item =>
                (item = {
                    name: item.name,
                    file: item.file ? item.file : null,
                    path: item.path ? item.path : "",
                    status: item.status?true:false,
                    mimetype: item.type ? item.type : item.mimetype,
                    //comment:this.actioncomment?this.actioncomment:''
                })
            );
             //this.$vs.loading();
             this.premiumProcessingFilesUploading =true;
             if (mapper.length > 0) {
              
                mapper.forEach((doc, index) => {
                    let formData = new FormData();
                    formData.append("files", doc.file);
                    formData.append("secureType", "private");
                    this.$store.dispatch("uploadS3File", formData).then(response => {
                        temp_count++;
                        response.data.result.forEach(urlGenerated => {

                            
                            doc.status = true;
                            doc.path = urlGenerated;
                            delete doc.file;
                             this.premiumProcessingFiles =[];
                            this.premiumProcessingFiles.push(doc);
                            mapper[index] = doc;
                            if (temp_count >= mapper.length) {
                                this.disabled_btn = false;
                               // this.$vs.loading.close();
                                this.documents =[];
                                  this.premiumProcessingFilesUploading =false;
                            }
                            

                        });
                    });

                });
                model.splice(0, mapper.length, ...mapper);
            }
    },

    openProcessingModel(){

         this.updatingPremiumProcessing =false;
         this.premiumProcessingFormErrors ='';
         this.premiumProcessingComment ='';
         this.$validator.reset();
         //this.premiumProcessing =false;
         this.premiumProcessingFiles = [];
        this. premiumProcessingFilesUploading=false;
         if(this.checkProperty( this.getPetitionDetails,'premiumProcessing')){
           //this.premiumProcessing = this.checkProperty( this.getPetitionDetails,'premiumProcessing');
          this.premiumProcessing=false
         }
         else{
          this.premiumProcessing=true
         }
         
         this.$modal.show('updatePremiumProcessingPopupModal');
    },


     updatePremiumProcess(){
       this.$validator.validateAll('premiumprocessingForm').then((result) => {
         
       
         let self =this;
            if (result) {
              let postData ={
                petitionId :self.checkProperty(self.getPetitionDetails ,'_id'),
                documents:self.premiumProcessingFiles,
                today: moment().format("YYYY-MM-DD"),
                comments:self.premiumProcessingComment,
                typeName:self.checkProperty(self.petition ,'typeDetails','name'),
                subTypeName:self.checkProperty(self.petition ,'subTypeDetails','name'),
                premiumProcessing: self.premiumProcessing
                
              }
              this.updatingPremiumProcessing =true;
              
               this.$store
              .dispatch("commonAction", {"data":postData ,"path":"/petition/manage-premium-process"})
              .then(response => {
               
                this.updatingPremiumProcessings =false;
                this.$modal.hide('updatePremiumProcessingPopupModal');
                this.showToster({message:response.message,isError:false });
                setTimeout(()=>{
                     let tabName= this.getPetitionTab;
                     this.$emit("updatepetition" ,tabName);
                   })
                                
                                
              })
              .catch((error)=>{
                this.premiumProcessingFormErrors =error;
                this.updatingPremiumProcessing =false;
              })
       
       

              
            }
          });

    },



    openSetDeadLinePopup(){
      let self =this;
      this.deadLineformErrors ='';
       this.deadlineDate =null;
       this.settingDeadLine =false;
       this.$validator.reset();
       
       if(self.checkProperty(self.petition ,'deadlineDate')){
          this.deadlineDate = moment(self.checkProperty(self.petition ,'deadlineDate')).format("YYYY-MM-DD")
       }


       this.$modal.show('setDeadlinePopupModal');
        
        
      


    },
    setCaseDeadLine(){
       this.$validator.validateAll('deadlineForm').then((result) => {
         
       
         let self =this;
            if (result) {
              let postData ={

                "petitionId": self.checkProperty(self.petition ,'_id'),
                today: moment().format("YYYY-MM-DD"),
                typeName:self.checkProperty(self.petition ,'typeDetails','name'),
                subTypeName:self.checkProperty(self.petition ,'subTypeDetails','name'),
                "deadlineDate":moment(self.deadlineDate).format("YYYY-MM-DD"),
              }
              this.settingDeadLine =true;
              
               this.$store
              .dispatch("commonAction", {"data":postData ,"path":"/petition/update-deadline"})
              .then(response => {
               
                this.settingDeadLine =false;
                this.$modal.hide('setDeadlinePopupModal');
                this.showToster({message:response.message,isError:false });
                setTimeout(()=>{
                     let tabName= this.getPetitionTab;
                     this.$emit("updatepetition" ,tabName);
                   })
                                
                                
              })
              .catch((error)=>{
                this.deadLineformErrors =error;
              })
       
       

              
            }
          });

    },

   
    getMasterSocList(){

          let query = {};
            query["page"] = 1;
            query["perpage"] = 10000;
            query["matcher"] = {
              // "getInactiveListAlso": true
              };
            query["category"] = "soc_codes";
            query["sorting"] = this.sortKey;

      this.$store
        .dispatch("getMasterData", query)
        .then((response) => {
          this.masterSocList = response.list;

        
         // alert(this.masterSocList);
        })
        .catch(() => {
          this.masterSocList = [];
         
        });

      },

      openSetCaseCodePopup(isEdit=false){
       
         this.isCaseNumberEdit = isEdit
         this.formerrors.msg = null;
         this.newCaseCode = '';//this.checkProperty( this.getPetitionDetails ,'caseNo');
         this.confCaseCode ='';
         this.settingCaseNumber =false
                  this.newCaseCode = this.checkProperty( this.getPetitionDetails ,'caseNo');

         this.$validator.reset('newCaseNumberForm')
         this.setCode = true;
      },
       SetCaseCodeAction() {
       
      this.$validator.validateAll('newCaseNumberForm').then((result) => {
        
        if (result) {
           
           let self =this;
          let postData = {
            caseNo: self.newCaseCode.trim(),
            //currentPassword: self.confCaseCode,
            petitionId: self.getPetitionDetails['_id'],
             subTypeName:self.checkProperty(self.getPetitionDetails,'subTypeDetails','name'),
             typeName:self.checkProperty(self.getPetitionDetails,'typeDetails','name'),
         
          };
          let path = "/petition/assign-custom-caseno";
          if(self.checkProperty(self.petitionDetails,'subTypeDetails','id') ==15){
            path = "/perm/assign-custom-caseno";
          }
           this.settingCaseNumber =true
            this.$store.dispatch("commonAction", {"data":postData ,"path":path})
              .then(response => {
                   this.showToster({message:response.message,isError:false });
                   this.newCaseCode ='';
                  this.confCaseCode ='';
                  this.$validator.reset('newCaseNumberForm');
                  this.setCode = false;
                   this.settingCaseNumber =false
                   setTimeout(()=>{
                     let tabName= this.getPetitionTab;
                     this.$emit("updatepetition" ,tabName);
                   })
              }).catch((err)=>{
                 this.settingCaseNumber =false
                this.sharing =false;
                this.showToster({message:err,isError:true });
              });
        }
      });
     },
    getBaseUrl(){

      this.webBaseUrl = window.location.origin;

      //  if (process.env.NODE_ENV == 'production') {

      //    if(this.checkProperty(window ,"location" ,'protocol') && this.checkProperty(window ,"location" ,'hostname')){

                   
      //     this.webBaseUrl = window.location.protocol+"//"+this.checkProperty(window ,"location" ,'hostname')
      //   }else{
      //      this.webBaseUrl = window.location.origin;
      //   }

      //  }else if(this.checkProperty(this.getPetitionDetails ,"tenantDetails" ,'slug')){

                   
      //     this.webBaseUrl = "https://"+(this.checkProperty(this.petition ,"tenantDetails" ,'slug'))+".immibox.com"
      //   }else{
      //      this.webBaseUrl = window.location.origin;
      //   }

        
      //window.location.protocol+window.location.hostname


    },
    shareLink( category=''){
      //anonymousAccesLink
      //anonymousLcaAccesLink
      let self =this;
      let postData  = {
        "petitionId":self.getPetitionDetails['_id'],
        "caseNo":self.getPetitionDetails['caseNo'],
        "link":self.anonymousAccesLink,
        "email":self.linkShareToEmailList.join(),
        entityType:'case'

      }
      if(category == 'lca'){
        postData['link'] = self.anonymousLcaAccesLink;
        postData['email'] = self.lcaLinkShareToemailText;
        postData['entityType'] = 'lca';
      }
      this.sharing =true;
       this.$store.dispatch("commonAction", {"data":postData ,"path":"/petition/share-link"})
              .then(response => {
                this.sharing =false;

                  this.showToster({message:response.message,isError:false });
                  this.$modal.hide('genaratModal');
                  this.linkShareToEmailList =[];
                  this.linkShareToemailsText ='';
                  this.lcaLinkShareToemailText ='';
                  this.lcaLinkShareToemailList = [];

              }).catch((err)=>{
                this.sharing =false;
                this.showToster({message:err,isError:true });
              });

    },
    removeEmail(i){
     
      this.linkShareToEmailList.splice(i ,1);
      //this.lcaLinkShareToemailList.splice(i , 1)
      this.linkShareToemailsText =  this.linkShareToEmailList.join(',');
      this.formatEmail();
    },

    formatEmail(category = ''){
      let emailList = null
      if(category == 'case'){
        emailList= this.linkShareToemailsText.split(',');
      }
      if(category == 'lca'){
        emailList= this.lcaLinkShareToemailText.split(',');
      }
      // this.linkShareToEmailList =[];
      // this.lcaLinkShareToemailList =[];
      let tempEmailList =[];
      if(this.checkProperty( emailList ,'length' )>0){
            const validateEmail = (email) => {
            return String(email)
            .toLowerCase()
            .match(
            /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
            );
            };
          if(category == 'case'){
            this.linkShareToEmailList = _.filter(emailList , (email)=>{
              if(validateEmail(email)){
                return true;
              }else{
                return false;
              }
            })
          }
          if(category == 'lca'){
            this.lcaLinkShareToemailList = _.filter(emailList , (email)=>{
              if(validateEmail(email)){
                return true;
              }else{
                return false;
              }
            })
        }    
      }

    },

    genarateLink(){
      this.webBaseUrl = window.location.origin;
      this.linkShareToEmailList =[];
      this.lcaLinkShareToemailList =[];
      this.linkShareToemailsText ='';
      this.lcaLinkShareToemailText ='';
      this.sharing =false;
      let petitionDetails = this.petition;
     // lcaToken:'',
     // caseToken:'',
      if( (this.checkProperty( petitionDetails ,'token') =='' && (this.caseToken =='' || this.caseToken ==null || this.caseToken==undefined ))||
      (this.checkProperty( petitionDetails ,'subTypeDetails' ,'id') !=15 && this.checkProperty( petitionDetails ,'lcaToken') =='' && (this.lcaToken =='' || this.lcaToken ==null || this.lcaToken==undefined ))
      ){
      let postData = {
        "petitionId":''
      };
      let path = "/petition/generate-link"
      postData['categories']= ["case", "lca"]
      if(this.checkProperty(petitionDetails, 'type')==3 && this.checkProperty(petitionDetails, 'subType')==15 ){
        path = "perm/generate-link"
        postData['categories']= ["case"]
      }
      if(!this.checkPetitionLcaRequired){
        postData['categories']= ["case"]
      }
      postData['petitionId'] = petitionDetails['_id'];

      this.anonymousAccesLink ='';
      this.anonymousLcaAccesLink ='';
      this.linkGenareating = true;
        this.$store.dispatch("commonAction" ,{"data":postData , "path":path})
        .then((res)=>{
          this.linkGenareating = false;
          this.petition['token'] = this.checkProperty(res ,'token','case');
          this.caseToken = this.checkProperty(res ,'token','case');
          if(this.checkProperty(res ,'token','lca')){
            this.petition['lcaToken'] = this.checkProperty(res ,'token','lca')
            this.lcaToken = this.checkProperty(res ,'token','lca');
          }
          this.anonymousLcaAccesLink = this.webBaseUrl+"/fill-lca-anonymous-user/"+petitionDetails['_id']+"?token="+this.checkProperty(res ,'token','lca');
          this.anonymousAccesLink = this.webBaseUrl+"/fill-questionnaire/"+petitionDetails['_id']+"?token="+this.checkProperty(res ,'token','case');
          if(this.checkProperty(petitionDetails, 'type')==3 && this.checkProperty(petitionDetails, 'subType')==15){
            this.anonymousAccesLink =this.webBaseUrl+"/fill-perm-questionnaire/"+petitionDetails['_id']+"?token="+this.checkProperty(res ,'token','case');
          }
          this.$modal.show('genaratModal');
        })
        .catch((err)=>{
            this.linkGenareating = false;
            this.showToster({message:err ,isError:true});
        })
      }else{
    
      if(this.checkProperty(petitionDetails, 'questionnaireFilled')){
          if(this.checkProperty(petitionDetails, 'type')==3 && this.checkProperty(petitionDetails, 'subType')==15){
            this.anonymousAccesLink =this.webBaseUrl+"/filled-perm-case-details/"+petitionDetails['_id']+"?token="+this.checkProperty(petitionDetails ,'token');
          }else{
            this.anonymousLcaAccesLink = this.webBaseUrl+"/fill-lca-anonymous-user/"+petitionDetails['_id']+"?token="+this.checkProperty(petitionDetails,'lcaToken');
            this.anonymousAccesLink =this.webBaseUrl+"/filled-case-details/"+petitionDetails['_id']+"?token="+this.checkProperty(petitionDetails ,'token');
          }
        }else{
          this.anonymousLcaAccesLink = this.webBaseUrl+"/fill-lca-anonymous-user/"+petitionDetails['_id']+"?token="+this.checkProperty(petitionDetails,'lcaToken');
          this.anonymousAccesLink = this.webBaseUrl+"/fill-questionnaire/"+petitionDetails['_id']+"?token="+this.checkProperty(petitionDetails ,'token')

          if(this.checkProperty(petitionDetails, 'type')==3 && this.checkProperty(petitionDetails, 'subType')==15){
            this.anonymousAccesLink =this.webBaseUrl+"/fill-perm-questionnaire/"+petitionDetails['_id']+"?token="+this.checkProperty(petitionDetails ,'token');
          }
        }
       this.$modal.show('genaratModal');
      

    }

    },
    async  copyLink(category =''){
     let self =this;
      this.copyingLink =true;
       let petitionDetails = this.petition;
      if((this.checkProperty( petitionDetails ,"token" ) || this.anonymousAccesLink !='') || (this.checkProperty( petitionDetails ,"lcaToken" ) || this.anonymousLcaAccesLink !='') ){
        try {
          if(category == 'case'){
            await navigator.clipboard.writeText(this.anonymousAccesLink);
          }
          if(category == 'lca'){
            await navigator.clipboard.writeText(this.anonymousLcaAccesLink);
          }
          this.showToster({  message: "Copied successfully ", isError: false, });
          this.showToolTip =true;
          this.copyingLink =false;
          setTimeout(() => {
            this.showToolTip =false;
            this.$modal.hide('genaratModal');
          } ,10)       
        } catch ($e) {
           this.copyingLink =false
           //  filderPath = "";
           this.showToster({  message: "Can't Copied folder path! ", isError: true,   });
        }
      }
    
    },

    openSubmitLawForm(){
          this.submittitle = "Submit Case";
          this.selectedAssignToReviewer =null;
          this.assignToReviewerMsg ='';
          this.assignToReviewerComment = '';
          this.assignToReviewerPopUp = true;
          this.submiTingAssignment =false;

             if([50].indexOf(this.getUserRoleId)>-1){
this.assignToReviewerComment ="Case is being submitted to "+this.petition.tenantDetails.name+" for further actions."

             }else{

this.assignToReviewerComment ="Case "+this.petition.typeDetails.name+", "+this.petition.subTypeDetails.name+" is being assigned for further actions"

             }

          

          this.selectedAssignToReviewer = {'_id':''};
          this.selectedAssignToReviewer['_id'] = this.checkProperty(this.getPetitionDetails ,'ptnrReassignRefUserId')
          
          
           this.$validator.reset();

    },

     submitToLawFirmAction(){
        this.assignToReviewerMsg ='';
         let postData = {
             petitionId: this.getPetitionDetails['_id'],
            comment: this.assignToReviewerComment,
            action:'SUBMIT_TO_LAW_FIRM', // "SUBMIT_TO_LAW_FIRM", // "CASE_APPROVED" / "LCA_CERTIFIED_FOR_PETITION" / "SUBMIT_TO_USCIS" / "USCIS_APPROVED" / "USCIS_RECEIVED_RFE" / "USCIS_DENIED" 
            today: moment().format('YYYY-MM-DD'), // Required on Status changes to "Received RFE"
           subTypeName:this.checkProperty(this.getPetitionDetails,'subTypeDetails','name'),
           typeName:this.checkProperty(this.getPetitionDetails,'typeDetails','name'),

         };
      
        this.assignToReviewerMsg ='';
        this.submiTingAssignment =true;
         this.$validator.validateAll("activityfoform").then((result) => {
            if (result) {
               this.loading =true;
               this.$store
              .dispatch("commonAction", {"data":postData ,"path":"/petition/manage-approval-process"})
              .then(response => {
                
                 this.showToster({message:response.message,isError:false });
                
                 setTimeout(() =>{
                    let tab = this.getPetitionTab;
                     this.submitToLawFirmActionPopup = false;
                     this.submiTingAssignment =false;
                   
                    this.$emit("updatepetition" ,tab);
                 });
                
                
                                
              })
              .catch((error)=>{
                this.submiTingAssignment =false;
                this.assignToReviewerMsg =error;

              })
       
       

              
            }
          });
           

       

    },

  editQuestionnaire(){
     let petitionDetails = this.getPetitionDetails;
     let petitionId = this.checkProperty( petitionDetails ,"_id");
     this.$router.push("/questionnaire/"+petitionId+"?fromedit=true");
  },


openReAssignToReviewerPopUp(){
  this.selectedAssignToReviewer =null;
  this.assignToReviewerMsg ='';
  this.assignToReviewerComment = '';
  this.submittitle = "Re-Assign";
   this.assignToReviewerPopUp = true;
   this.submiTingAssignment =false;
   this.assignToReviewerComment ="Case "+this.petition.typeDetails.name+", "+this.petition.subTypeDetails.name+" is being re-assigned for corrections/changes/updates."


   if([50].indexOf(this.getUserRoleId)>-1){
     this.selectedAssignToReviewer = _.find(this.caseUsers ,{'roleId':51});
   }
    if([51].indexOf(this.getUserRoleId)>-1){
     this.selectedAssignToReviewer = _.find(this.caseUsers ,{'roleId':50});
   }


   this.$validator.reset();

},
    submitreAssignAction(){
       let self =this;
        let petitionDetails = this.getPetitionDetails;
      this.$validator.validateAll().then((result) => {
   
        if(result){
           
            let postData ={
                "petitionId": "",
                "userId": "",
             //   "userName": "",
                //"roleId": '',
                "typeName": "",
                "subTypeName": "",
                "comment": ""
            };
          postData['petitionId'] = self.checkProperty(petitionDetails ,'_id'); 
          postData['userId'] = self.checkProperty(self.selectedAssignToReviewer ,'_id'); 
         // postData['userName'] = self.checkProperty(self.selectedAssignToReviewer ,'roleName'); 
       //   postData['roleId'] = self.checkProperty(self.selectedAssignToReviewer ,'roleId'); 
          postData['typeName'] = self.checkProperty(petitionDetails,'typeDetails','name'); 
          postData['subTypeName'] = self.checkProperty(petitionDetails,'subTypeDetails','name');
          postData['comment'] = self.assignToReviewerComment; 
        this.submiTingAssignment =true;
    this.$store.dispatch("commonAction" ,{data:postData,path:"/petition/reassign"})
        .then(response => {
     this.showToster({message:response.message,isError:false });
      
         this.assignToReviewerPopUp = false;
            setTimeout(() =>{
                  let tab = self.getPetitionTab;
                    this.$emit("updatepetition" ,tab);
                     this.submiTingAssignment =false;
                    
                 },10);

            
        }).catch((err)=>{
            this.submiTingAssignment =false;
            this.assignToReviewerMsg =err;
             this.showToster({message:err,isError:true });
          
        })
        }

      })


    },

    getSignerList(){
      this.selectedSigner =null
      // {{workFlowDetails}}
      if(this.workFlowDetails && _.has(this.workFlowDetails ,"config")){
        let DOC_SIGNER_LIST = _.find(this.workFlowDetails['config'] ,{"code":'DOC_SIGNER_LIST'})
        if(DOC_SIGNER_LIST && _.has(DOC_SIGNER_LIST ,"editors")){

           let companyIdRoles =[50,51];
           let branchIdRoles =[4, 5, 6, 7, 8, 9, 10, 11 ,12];
            let postData ={
              "matcher":{ "roleIds": [], "branchId":"",},              
              "page": 1,	
              "perpage":100000000,
              
            };
             _.forEach(DOC_SIGNER_LIST['editors'] ,(item)=>{
              
              
              postData.matcher.roleIds.push(item.roleId);
               if(companyIdRoles.indexOf(item.roleId)>-1 && this.checkProperty(this.getPetitionDetails ,'companyDetails' ,'_id')){
                postData = Object.assign(postData ,{"companyId":this.checkProperty(this.getPetitionDetails ,'companyDetails' ,'_id') })
              }

            if(branchIdRoles.indexOf(item.roleId)>-1 && this.checkProperty(this.getPetitionDetails ,'branchId')){
                postData['matcher']['branchId'] = this.checkProperty(this.getPetitionDetails ,'branchId');
              }
              

            });
            this.$store.dispatch("getList",{data:postData ,path:'/petition/assign-user-list'} ).then(response => {
             //alert(JSON.stringify(response.list));
             let lst = []
            
            _.forEach(response.list ,(item)=>{
              if(_.has(item ,'name') && _.has(item ,'roleName') && ( item._id !=this.getUserData['userId'])){
                  item.name = item.name+" ("+item.roleName+")";
                  lst.push(item);
              }
            


            });
            this.signerList = lst;


            })



        }
      }

    },

     checkMyPendingformsandLatters(){
       // this.lettersAndForms is from prpps
       //this.formsAndLettersList  is from loacaveriable
      
      this.isEnableSendforReview = false;
      let loginUserId = this.getUserData['_id'];
      _.forEach(this.formsAndLettersList ,(item)=>{
        
        
         if(item["statusId"] ==1 && item["createdBy"]== loginUserId){
           this.isEnableSendforReview = true;
            
         }

      })

     
     

      //  if(this.formsAndLettersList.length > 0){
      //    let loginUserId = this.getUserData['_id'];
      //    let myDocements = _.filter(this.formsAndLettersList ,(item)=>{
      //         return item["statusId"] ==1 && item["createdBy"]== loginUserId
           
      //      });

      
      //    alert(myDocements)
         
         
      //    if(myDocements && myDocements.length>0){
      //      this.isEnableSendforReview= true;
      //    }



      //  }

     }, 
    openApproveOrRejectDocs(){
    this.actioncomment = '';
    this.paralegalformerrors = '';
    this.disabled_btn = false;
    this.approveOrRejectDocs = true;
     this.$validator.reset();
  },
  approveOrRejectDocsAction(action="UPLOAD_BY_DOC_EXECUTIVE"){
    this.paralegalformerrors ="";
     this.$validator.validateAll("approveOrRejectDocsForm").then(result => {
      if(result || action=="UPLOAD_BY_DOC_EXECUTIVE"){
        var postData = {
              petitionId:this.checkProperty(this.getPetitionDetails,'_id'),
              typeName:this.checkProperty(this.getPetitionDetails,'typeDetails','name'),
              subTypeName:this.checkProperty(this.getPetitionDetails,'subTypeDetails','name'),
              comment:this.actioncomment, // Required on APPROVED_BY_DOC_MANAGER and REJECT_BY_DOC_MANAGER
              action: action,//"UPLOAD_BY_DOC_EXECUTIVE",//APPROVED_BY_DOC_MANAGER, REJECT_BY_DOC_MANAGER
              today: moment().format("YYYY-MM-DD")
        }

        this.disabled_btn =true;
        
        this.$store.dispatch("commonAction", {"data":postData ,"path":"/petition/manage-offshore-document-upload"})
              .then((response) => {
              
             
              this.approveOrRejectDocs = false;
              this.showToster({message:response.message,isError:false })
              setTimeout( ()=>{
                  this.disabled_btn =false;

                  this.$store.dispatch("setPetitionTab" , 'Forms and Letters').then(()=>{
                      this.$emit("updatepetition" ,"Forms and Letters")
                  }).catch(()=>{
                        this.$emit("updatepetition" ,"Forms and Letters")
                  })

              },10)
              
              
              
              })
              .catch((error) => {
                if(action=="UPLOAD_BY_DOC_EXECUTIVE"){
                    this.showToster({message:error,isError:true });
                    setTimeout( ()=>{
                      this.disabled_btn =false;
                      

                        this.$store.dispatch("setPetitionTab" , 'Forms and Letters').then(()=>{
                                      this.$emit("updatepetition" ,"Forms and Letters")
                                  }).catch(()=>{
                                        this.$emit("updatepetition" ,"Forms and Letters")
                                  })

                    },100)
                   
                }
                this.paralegalformerrors = error;
                this.disabled_btn = false;
                
              
              })
       }
            
         
     })
   
  },
    checkDocuments(){
     
      let documents = _.filter( this.lcaDocuments , { 'status':true });
      if(documents && documents.length>0){

        this.validateLcaFiles = false;
      }else{
         this.validateLcaFiles = true;
      }
      
    },
    uploadLcaDocuments(model) {

            let temp_count = 0;
          
            this.disabled_btn = true;
            let mapper = model.map(
                item =>
                (item = {
                    name: item.name,
                    file: item.file ? item.file : null,
                    path: item.path ? item.path : "",
                    status: item.status === false || item.status === true ?
                        item.status : true,
                    statusId: this.lcastatusSelected['id'] ? this.lcastatusSelected['id'] : '',
                    certified: this.lcastatusSelected.id == 3 ? true : false,
                    mimetype: item.type ? item.type : item.mimetype,
                    comment:this.actioncomment?this.actioncomment:''
                })
            );
             //this.$vs.loading();
             this.uploading =true;
             if (mapper.length > 0) {
                mapper.forEach((doc, index) => {
                    let formData = new FormData();
                    formData.append("files", doc.file);
                    formData.append("secureType", "private");
                    this.$store.dispatch("uploadS3File", formData).then(response => {
                        temp_count++;
                        response.data.result.forEach(urlGenerated => {

                            
                            doc.status = true;
                            doc.path = urlGenerated;
                            delete doc.file;
                            this.lcaDocuments.push(doc);
                            mapper[index] = doc;
                            if (temp_count >= mapper.length) {
                                this.disabled_btn = false;
                               // this.$vs.loading.close();
                                this.documents =[];
                                  this.uploading =false;
                            }
                            this.checkDocuments();

                        });
                    });

                });
                model.splice(0, mapper.length, ...mapper);
            }
    },

    removeLcaDocument(index, type){
      let selectedItemPath = this.lcaDocuments[index]['path'];
      let dbDocuments =[];
     if(this.lcaDetails.statusId == 2){
         dbDocuments =  _.cloneDeep(this.lcaDetails['documents']['filed']);
       }else if( this.checkProperty(this.lcaDetails ,'statusId') == 3){
          dbDocuments =  _.cloneDeep(this.lcaDetails['documents']['certified']);
       }

       if(dbDocuments.length>0 && _.find(dbDocuments , {"path":selectedItemPath  }) ){

          //this.lcaDocuments[index]['status'] =false;
          Object.assign(this.lcaDocuments[index] ,{ "status":false})

       }else{
         type.splice(type.indexOf(index), 1);
        
       }
       
    
      this.checkDocuments();
        return true;
    },

     selectLcaStatus(item){
        this.showDataPicker =false;
        this.lcastatusSelected = item;
        this.lcaDocuments =[];
         if(item.id == 2){
         this.lcaDocuments = _.cloneDeep(this.lcaDetails['documents']['filed']);
       }else if(item.id == 3){
          this.lcaDocuments =  _.cloneDeep(this.lcaDetails['documents']['certified']);
       }
       
      
       
       this.checkDocuments();
       setTimeout(()=>{
         this.showDataPicker  =true;
         this.$validator.reset();
         
       },1);
      
        
    },
    openLcaUpdatePopup(){
      //lcastatuses
      // filed:[],
      //certified:[]
      this.actioncomment = '';
      this.filedDate ='';
      this.certifiedDate = '' ; 
     this.paralegalformerrors ='';
     this.updatingLca =false,
     this.disabled_btn =false;
     
      this.documents = [];
    
      if(this.lcaDetails){
        
        this.lcastatusSelected = _.find(this.lcastatuses ,{ "id": this.lcaDetails.statusId });
        if(this.lcastatusSelected){
           this.selectLcaStatus( this.lcastatusSelected);
        } 
       this.number ='';
        if(_.has(this.lcaDetails ,'number')){
          this.number = this.lcaDetails.number;
        }

        //let  filedDate =  moment(this.filedDate).format("YYYY-MM-DD");  //filedDate certifiedDate this.lcastatusSelected.id ==
        if(this.checkProperty(this.lcaDetails ,"filedDate")){
          this.filedDate = moment(this.lcaDetails['filedDate']).format("YYYY-MM-DD");

        }

        if(this.checkProperty(this.lcaDetails ,"certifiedDate")){
          this.certifiedDate = moment(this.lcaDetails['certifiedDate']).format("YYYY-MM-DD");

        }
        
        this.lcaUpdateForm =true;
        this.$modal.show('updateLcaModal');
      }
       //this.$validator.reset("approveparalegalfoform");
       this.$validator.reset();
       

    },
    updateLca() {
             this.paralegalformerrors ='';
            this.$validator.validateAll("approveparalegalfoform").then(result => {
              this.lcastatusSelected.lcaId  =this.lcaDetails['_id'];
              let self = this;
              
                if (result) {
                  this.updatingLca=true
                        let updatedValue = {
                            lcaId: this.lcaDetails._id,
                            number: this.number,
                            caseNo: this.lcaDetails.petitionDetails.caseNo,
                            action: "LCA_SUBMIT",
                            actionTitle:"Basic information updated",
                            innerAction:'UPDATE_DETAILS_AND_DOCUMENTS',
                            updateType: "details-and-documents",
                            statusName: this.lcastatusSelected.name,
                            statusId: this.lcastatusSelected.id,
                            comment: this.actioncomment,
                            actionDescription:this.actioncomment,
                            documents: this.lcaDetails['documents'],
                            today: moment().format("YYYY-MM-DD"),
                          //  payFrequency: self.checkProperty(self.lcaDetails ,'payFrequency' )
                          desiredSOCCode:self.checkProperty(self.lcaDetails ,'socDetails' , 'id'),
                          clientName:self.checkProperty(self.lcaDetails ,'clientName')


                        };
                        //filedDate certifiedDate this.lcastatusSelected.id ==
                          if(updatedValue.statusId == 2){

                            updatedValue['documents']['filed']= this.lcaDocuments;
                                                    

                        }else if(updatedValue.statusId == 3){

                            updatedValue['documents']['certified']= this.lcaDocuments;
                            
                          
                        }
                        if(this.filedDate && this.lcastatusSelected.id == 2){
                            let  filedDate =  moment(this.filedDate).format("YYYY-MM-DD");  //filedDate certifiedDate this.lcastatusSelected.id ==
                             Object.assign(updatedValue ,{ "filedDate": filedDate });
                        }
                        if(this.certifiedDate && this.lcastatusSelected.id == 3){
                          let  certifiedDate =  moment(this.certifiedDate).format("YYYY-MM-DD");
                            Object.assign(updatedValue ,{ "certifiedDate":certifiedDate  });

                        }

                        this.updatingLca=true
                        this.$store.dispatch("updateLcaDetails", updatedValue).then(response => {
                          this.lcaUpdateForm = false;
                         this.updatingLca=false
                           this.$modal.hide('updateLcaModal');
                          this.showToster({message:this.checkProperty(response , 'data' ,'message'),isError:false })
                          setTimeout( ()=>{
                             this.disabled_btn =false;
                                  this.$store.dispatch("setPetitionTab" , 'LCA').then(()=>{
                                      this.$emit("updatepetition" ,"LCA")
                                  }).catch(()=>{
                                        this.$emit("updatepetition" ,"LCA")
                                  })
                          },100)
                         

                        })
                        .catch(error => {
                           this.updatingLca=false
                           this.disabled_btn =false;
                          this.paralegalformerrors =error;
                        })
                    

                    
                }
            })

        },

    enableActionBtn(){
     // alert("enableActionBtn");
       this.updatePetiotionActionBtn(true);
       return true;
    },
     getFormsAndLetters(callForSignin =false){
            if(callForSignin){
              this.getSignerList();

            }
          
          if([3].indexOf(this.checkProperty(this.petition ,'typeDetails' ,'id'))<=-1 && this.checkProperty(this.petition  ,'_id')){
            this.formsAndLettersList = [];
            let finalList =[];
             let postData ={petitionId:this.petition._id ,'page':1 ,'perpage':10000 };
            this.$store.dispatch("getList" ,
            {
              data:postData,
             // path:"/petition/filled-forms-and-letters-list"
              path:"/filled-forms-and-letters/list"
            })
            .then(response => {
          //  this.formsAndLettersList = response.list;
          
            
             let lst = [];
           
            _.forEach(response.list ,(mainItem)=>{
                mainItem = Object.assign(mainItem,{"reverse_document_versions":[] ,"mainParentId":'',showMe:true ,"selectedForSigning":false});
               if(mainItem.parentId){
                   mainItem['mainParentId'] = mainItem['parentId']
               }else{
                    mainItem['mainParentId'] = mainItem['_id']
               }

                lst.push(mainItem);
                 

            });

            let subList=[];
           
            //reverse_document_versions
            _.forEach(lst ,(mainItem)=>{

                                
               
               _.forEach(lst ,(subItem)=>{
                    if( mainItem.parentId && (mainItem.parentId == subItem['parentId'] ||  mainItem.parentId == subItem['_id']   ) &&  mainItem['_id'] != subItem['_id']){
                             
                             subItem['showMe'] =false;
                             if(subList.indexOf(subItem['_id']<=-1)){
                                  mainItem['reverse_document_versions'].push(subItem);
                                  subList.push(subItem['_id']);

                             }
                            
                            // mainItem['showMe'] =true;
                    }

                })
                
            if(mainItem.showMe){
                 finalList.push(mainItem);
            }
           
      
             
              

            })
           

            this.totalpages = Math.ceil(response.totalCount / this.perpage);
            this.formsAndLettersList =  finalList;
            //alert(JSON.stringify(this.formsAndLettersList));
            this.checkMyPendingformsandLatters()
            if(callForSignin){
              this.showPetitionersign();
            }
            
            })

          }

         },

    
    selectFormsandLatters(index ,forms){
      /*
      
      if( !this.petition.formsAndLetters[index]['selectedForSigning'] ){
        this.petition.formsAndLetters[index]['selectedForSigning'] = true
      }else{
        this.petition.formsAndLetters[index]['selectedForSigning'] = false;
      }
      */
      if(this.formsAndLettersList[index]){

          if(  !this.formsAndLettersList[index]['selectedForSigning'] ){
        
        forms['selectedForSigning'] =true;
        this.formsAndLettersList[index]['selectedForSigning'] = true
      }else{
         forms['selectedForSigning'] =false;
        this.formsAndLetters[index]['selectedForSigning'] = false;
      }
      }
    

      

     // alert(this.petition.formsAndLetters[index]['selectedForSigning']);
      
    },

    submitFilingFees() {
      this.filingFeeformerrors ='';
      this.$validator.validateAll("filingFeesform").then((result) => {
        if (result) {
          var totala = 0;
          this.filingFeeData.forEach((i) => {
            totala = totala + parseInt(i.amount);
          });
          
          var postData = {
             subTypeName:this.checkProperty(this.getPetitionDetails,'subTypeDetails','name'),
            typeName:this.checkProperty(this.getPetitionDetails,'typeDetails','name'),
            petitionId:this.checkProperty(this.getPetitionDetails,'_id'),
            filingFeeData: this.filingFeeData,
            today: moment().format("YYYY-MM-DD"),
            
            /*
            companyName: this.petition.petitionerDetails.name,
            beneficiaryName: this.petition.beneficiaryDetails.name,
            beneficiaryCustomId: this.petition.beneficiaryDetails.customId,
            petitionType: this.petition.typeDetails.name,
            companyId: this.petition.petitionerDetails._id,
             petitionId: this.petition._id,
           
            amount: totala,
            customer: {
              Id: this.petition.companyDetails.qbCustomerId,
              displayName: this.petition.companyDetails.name,
              email: this.petition.companyDetails.authorizedSignatory.email,
            },
            invoiceTerms: {
              days: 30,
            },
             comment:this.filingFeeComment,
            emailInvoice:this.emailInvoice
            */
          };
             this.submitingFilingFee =true;
             this.$store.dispatch("commonAction", {"data":postData ,"path":"/petition/save-filing-fees"})
            .then((response) => {
            
              //
            

                  this.createOrupdateInvoice('save-filing-fees');

             
            
             
            })
            .catch((error) => {
               this.submitingFilingFee =false;
              this.filingFeeformerrors =error;
            })
         
    
        }
      });
    },
    createOrupdateInvoice(callFrom='') {
      this.filingFeeformerrors ='';
      this.$validator.validateAll("filingFeesform").then((result) => {
        if (result) {
          var totala = 0;
         this.filingFeeData.forEach((i) => {
            totala = totala + parseInt(i.amount);
          });
           let filingFeeData = _.cloneDeep(this.filingFeeData);
          if(callFrom=='save-filing-fees'){

             //filingFeeData  = _.filter(filingFeeData , {'invoice':false});

          }
         
         
         
          var postdata = {
            companyName: this.petition.petitionerDetails.name,
            beneficiaryName: this.petition.beneficiaryDetails.name,
            beneficiaryCustomId: this.petition.beneficiaryDetails.customId,
            petitionType: this.petition.typeDetails.name,
            companyId: this.petition.petitionerDetails._id,
            petitionId: this.petition._id,
            feeDetails: filingFeeData,
            amount: totala,
            today: moment().format("YYYY-MM-DD"),
            customer: {
              Id: this.petition.companyDetails.qbCustomerId,
              displayName: this.petition.companyDetails.name,
              email: this.petition.companyDetails.authorizedSignatory.email,
            },
            invoiceTerms: {
              days: 30,
            },
            comment:this.filingFeeComment,
            emailInvoice:  this.checkPaymentIntigration//this.emailInvoice
          };
          this.submitingFilingFee =true;
          if(this.petition.invoiceId!=null){
            postdata.invoiceId = this.petition.invoiceId;
            postdata.statusId = 2;
            postdata.statusName = "Sent";
            this.$store.dispatch("updateFilingFees", postdata)
            .then((response) => {
                 this.filingFeesPopup = false;
                 this.$modal.hide('FilingFeesModal');
                  this.editFilngFee =false;
                 this.submitingFilingFee =false;
                 this.showToster({ message:response.message ,isError:false})
                 setTimeout(() => {
                    this.$store.dispatch("setPetitionTab" , 'Fees/Invoices').then(()=>{
                      this.$emit("updatepetition" ,"Fees/Invoices")
                    }).catch(()=>{
                      this.$emit("updatepetition" ,"Fees/Invoices")
                    })
                 } ,100)
                
           
            })
            .catch((error) => {

                  if(callFrom=="save-filing-fees"){

                      this.filingFeesPopup = false;
                       this.$modal.hide('FilingFeesModal');
                       this.editFilngFee =false;
                      this.submitingFilingFee =false;
                    this.showToster({ message:error ,isError:true})
                    setTimeout(() => {
                          
                        this.$store.dispatch("setPetitionTab" , 'Fees/Invoices').then(()=>{
                          this.$emit("updatepetition" ,"Fees/Invoices")
                        }).catch(()=>{
                          this.$emit("updatepetition" ,"Fees/Invoices")
                        })

                        } ,100);
                        
                    }else{
                        this.filingFeeformerrors =error;

                    }
                  })
          }else{

            this.$store.dispatch("submitFilingFees", postdata).then((response) => {
               this.filingFeesPopup = false;
                this.$modal.hide('FilingFeesModal');
               this.submitingFilingFee =false;
              this.showToster({ message:response.message ,isError:false})
                 setTimeout(() => {

                   this.$store.dispatch("setPetitionTab" , 'Fees/Invoices').then(()=>{
                      this.$emit("updatepetition" ,"Fees/Invoices")
                    }).catch(()=>{
                      this.$emit("updatepetition" ,"Fees/Invoices")
                    })

                 } ,100)
             
            })
            .catch((error) => {
                if(callFrom=="save-filing-fees"){

                this.filingFeesPopup = false;
                 this.$modal.hide('FilingFeesModal');
                this.submitingFilingFee =false;
                this.showToster({ message:error ,isError:true})
                setTimeout(() => {
                      this.$store.dispatch("setPetitionTab" , 'Fees/Invoices').then(()=>{
                        this.$emit("updatepetition" ,"Fees/Invoices")
                      }).catch(()=>{
                        this.$emit("updatepetition" ,"Fees/Invoices")
                      })
                  } ,100);

                }else{
                  this.filingFeeformerrors =error;

                }
              
             
             
            })

          }
    
        }
      });
    },
    addfilingfee: function () {
      // this.$validator.validateAll("filingFeesform").then((result) => {
                 
        // if(result){
            this.filingFeeData.push({
            amount: null,
            description: "",
            });

        // } });
    },
    removefilingfee: function (index) {
      Vue.delete(this.filingFeeData, index);
    },
    showfilingFeesPopup(editFilngFee=false) {
      this.editFilngFee = editFilngFee;
      this.filingFeeData = [
      {
        amount: null,
        invoice: false,
        description: "",
      },
    ];
      if (
        this.petition.filingFeeDetails &&
        this.petition.filingFeeDetails.amount > 0
      ){
      this.filingFeeData= [];
        this.filingFeeData = this.petition.filingFeeDetails.feeDetails;
      }

      this.filingFeesPopup = true;
      this.filingFeeformerrors ='';
      this.submitingFilingFee =false;
      this.filingFeeComment ='',
      this.emailInvoice =true;
      this.$emit('showfilingFeesPopup' ,editFilngFee);
      //this.$modal.show('FilingFeesModal');
    },
    gethistory() {

      
     if(this.checkProperty(this.petition, '_id' )){
      let postData ={"petitionId":'' ,"page": 1, "perpage": 500};
            postData['petitionId'] =  this.petition['_id'];
         let path ="/petition/activity-list";

        if([3].indexOf(this.checkProperty(this.petition,'typeDetails', 'id' )) >-1 &&  [15].indexOf(this.checkProperty(this.petition,'subTypeDetails', 'id' )) >-1){
          path ="/perm/activity-list";
        }
        this.$store
        .dispatch("getList", {
          data: postData,
          path:path,
        }).then((response) => {
        
          this.petitionhistory = response['list'];
        });
      }

     
    },
    reloadPetition() {
      this.$emit("updatepetition");
      this.$store
        .dispatch("getpetition", this.petition._id)
        .then((response) => {
          this.petition = response.data.result;
          if (this.petition.lcaId != null && false) {
            this.$store
              .dispatch("fetchLcaDetails", this.petition.lcaId)
              .then((response) => {
                //this.lcaDetails = response.data.result;
                this.$store.dispatch('setPetitionData' ,{petitionDetails:this.petition ,lcaDetails:response.data.result,workFlowDetails:null});

                  this.lcaDetails['status_documents'] = [];
                    let stsid = this.lcaDetails['statusId']
                    let status_documents = {}
                    let statusLogs = this.lcaDetails['statusLogs'];
                    _.forEach(statusLogs, (object) => {

                        let comment = object['comment'];
                        let statusId = object['statusId'];
                        _.forEach(this.lcaDetails['documents'].lca, (document, indx) => {
                            this.lcaDetails['documents'].lca[indx]['is_new'] = false

                            let doc = _.cloneDeep(document)
                            doc['comment'] = comment;

                            if (doc['statusId'] && doc['statusId'] == statusId && doc['comment'] && doc['comment'] != '') {
                                if (_.has(status_documents, statusId)) {

                                    status_documents[statusId].push(doc);
                                } else {
                                    status_documents[statusId] = []
                                    status_documents[statusId].push(doc);

                                }
                                document["is_status_document"] = true;
                            } else {
                                if (!document["is_status_document"])
                                    document["is_status_document"] = false;
                            }

                        });

                    });

                    _.forEach(status_documents, (docs) => {

                        if (docs.length > 0) {
                            this.lcaDetails['status_documents'].push(docs);
                        }
                    });
              });
          }

          let postDt = {userId:'' ,isRfeCase:false}
            if(_.has(this.petition ,"rfeCase" )){
            postDt['isRfeCase'] = this.petition['rfeCase']
            }
            postDt['userId'] = this.petition['userId'];

          this.$store
            .dispatch("getpetitionsdropdown", postDt)
            .then((response) => {
              this.petitions = response;
            });
        });
      this.$store.dispatch("petitionhistory", this.petition._id).then((response) => {
        this.petitionhistory = response.result.list;
      });
    },
    showMessages(message) {
      this.$vs.notify({
        title: "Success", 
        position: "top-right",
        color: "primary",
        iconPack: "feather",
        icon: "icon-check",
        text: message,
        
      });
    },

   actiVateTabe(tabName="LCA"){
    
     this.$emit('passparent',tabName);
   },
    getCourierList() {
      let postdata = {};

      this.$store.dispatch("getCourierList", postdata).then((response) => {
       // alert(JSON.stringify(response))
        
        //this.courierList = response;
      });
      //tracking/list
       this.$store.dispatch("getList",{data:postdata ,path:'/tracking/courierlist'} ).then(response => {
        if(this.checkProperty(response , "list")){
          this.courierList = response.list;
        }
        
        
      });

    },
    fetchSignedUrl(value) {
      
      value.document = value.document.replace(this.$globalgonfig._S3URL,"");
      value.document = value.document.replace(this.$globalgonfig._S3URLAWS,"");
      let postdata = {
        keyName: value.document,
      };
      this.$store.dispatch("getSignedUrl", postdata).then((response) => {
        window.open(response.data.result.data, "_blank");
      });
    },
    remove(item, type) {
        type.splice(type.indexOf(item), 1);
        return false;
    },
    
    uploadFiles() {
      this.paralegalformerrors = "";
      this.$validator.validateAll().then((result) => {
        if(!this.checkuploadScnnedFiles){
           

       
         let uploadPayload = {
          documents: this.uploadScanedFilsList,
          petitionId: this.petition._id,
          today: moment().format('YYYY-MM-DD')
        };
        
        this.$store.dispatch("uploadScannedCopies", uploadPayload).then((response) => {
            
             this.showToster({ message: response.message, isError: false });
             this.uploadSignedPopup =false;
             this.checkuploadScnnedFiles =[];
               this.uploadSignedPopup = false;
                setTimeout( ()=> {
                //self.showMessages(response.message);
              
               
                   this.$emit("updatepetition");

             
                
                
                });
          })
          .catch((error) => {
            this.paralegalformerrors = error;
               //this.showToster({ message: error, isError: true });
          });


        }else{
           this.paralegalformerrors = "Documents are required";
        }
      });
      
      

      
    },

    submitSignedDocuments() {
     // this.uscisdocument =[];
     this.uploadScanedFilsList =[];
     this.filesAreuploading =false;
     this.fileModel =[];
      this.documentData= [
      {
        type: "Forms, Letters and Others",
        documentUploaded: [],
      },
    ],
      this.uploadSignedPopup = true;
      this.paralegalformerrors = "";
    },
    showPetitionersign() {
      this.notifyPetitioner =true;
      this.emailDocsForSign =false;
       this.requestsignformcomments = "";
          this.requestsignCommentError = false;
          this.requestsigning =false;
          this.$validator.reset();
      
     
      let formsAndLettersActiveList = _.filter(this.formsAndLettersList ,{ "statusId":2})
      if(this.formsAndLettersList.length>0 && formsAndLettersActiveList.length>0){
         this.requestsignPopup = true;
         this.$modal.show('requestsignPopupModal');
         this.trackingErrors ='';
        

      }else{
        this.showToster({ message: "Required at least one forms and letters documents to send for signature.", isError: true });

        this.$store.dispatch("setPetitionTab" , 'Forms and Letters').then(()=>{
          this.$emit("updatepetition" , "Forms and Letters")
        }).catch(()=>{
          this.$emit("updatepetition" , "Forms and Letters")

        })
        
        
      }
           
        },
     updateUSCISstatus() {

       this.casestatus =null;
       this.uscisdocument =[];
      this.dueDate =null;
      this.receivedDate =null;
	    this.issuedDate =null;

       this.filesAreuploading =false;
            
            this.usciscomments='';
            this.usciscUpdateStatusError='';
            this.usciscUpdating =false;
            this.updateUSCISstatusPopup = true;
            this.documentType =null;

        },
      updateTrackingDetails() {
            this.updateTrackingPopup = true;
            this.trackingErrors ='';
            this.filesAreuploading =false;
            this.updateTrackingLoading =false;
            this.tracking = _.cloneDeep(this.tracking);
          //  this.tracking.trackingId ='';
          //  this.tracking.documents = [];
            this.tracking = Object.assign(this.tracking, {"trackingId":'' ,"documents":[] ,"courier":null})
           // this.petition.nextWorkflowActivity=='COURIER_TRACKING' 
             this.tracking = _.cloneDeep(this.tracking);
            this.uscisdocument = [];
            this.trackingdoc = [];
            
             if(!(_.has(this.petition , 'courierTrackingCategory')) || (  _.has(this.petition , 'courierTrackingCategory') && !this.petition['courierTrackingCategory'] )){
              //petition.courierTrackingCategory
              //this.tracking['courier'] =null;
             // this.tracking['trackingId'] ='';
            }
           
            
             
        }, 
    changedCourier() {
      if(_.has(this.tracking ,'courier') && (_.has(this.tracking['courier'] ,'code')) ){

        this.tracking = Object.assign(this.tracking ,{'courierCode':this.tracking["courier"]["code"] });

      }
      if(_.has(this.tracking ,'courier') && (_.has(this.tracking['courier'] ,'track_url')) ){

        this.tracking = Object.assign(this.tracking ,{"trackingUrl":this.tracking["courier"]["track_url"]  });

      }
      
             
           // this.tracking.trackingUrl = this.tracking["courier"]["code"];
           // this.tracking.courierCode = this.tracking["courier"]["code"];
        },
   updateTracking() {
     
     //this.petition.nextWorkflowActivity
             this.trackingErrors ='';
            this.$validator.validateAll("trackingform").then((result) => {
                if (result) {
                    this.tracking.petitionId = this.petition._id;
                    this.tracking.action =
                        this.petition.courierTrackingCategory != "UPDATE_TRACKING_NUMBER" ?
                        "UPDATE_TRACKING_NUMBER" :
                        "UPDATE_USCIS_RECEIPT_NUMBER";
                   
                   this.tracking.action =this.petition.nextWorkflowActivity;
                    this.updateTrackingLoading =true;
                    if(this.trackingdoc && this.trackingdoc.length>0){
                       this.tracking = Object.assign(this.tracking,{"documents":this.trackingdoc});
                    }
                    

                     let tracking = _.cloneDeep(this.tracking);
                    if(_.has(tracking , "courier")){

                       let courier = _.cloneDeep(tracking['courier'] );
                       if((_.has(courier  , "name"))){
                         tracking = Object.assign( tracking , { 'courier':courier['name'] });
                       }
                       if((_.has(courier  , "code"))){
                         tracking = Object.assign( tracking , { 'courierCode':courier['code'] });
                       }
                    }
                  
                    this.$store
                        .dispatch("updateTrackingDetails", tracking)
                        .then((response) => {
                           
                             this.trackingErrors ='';
                            this.showToster({ message: response.message, isError: false });
                             this.updateTrackingLoading =false;
                            this.updateTrackingPopup = false;
                            setTimeout(() => {
                              
                               this.$emit("updatepetition" ,'Petition Updates');
                              // this.$emit("loadstatus");

                            } ,10)
                            
                        })
                        .catch((error)=>{
                           this.trackingErrors =error;
                          this.updateTrackingLoading =false;
                          //this.showToster({ message: error, isError: true });

                        });

                }

            })

        },
   submitpetitionrequest() {
     this.trackingErrors ='';
     this.requestsignCommentError =false;
        if(this.requestsignformcomments =='' || this.requestsignformcomments.trim() =='' ){
           this.requestsignCommentError =true;
           return true;
          
        }
        let selectedDocuments = _.filter(this.formsAndLettersList,{selectedForSigning:true} );
        if(!selectedDocuments || this.checkProperty( selectedDocuments,"length") <=0){
           this.trackingErrors = "Atleast select one document is required."
            result =false;

        }
       
         
          let self =this;
            var postdata = {
                petitionId: this.petition._id,
                comment: this.requestsignformcomments,
                subTypeName:this.checkProperty(this.getPetitionDetails,'subTypeDetails','name'),
                typeName:this.checkProperty(this.getPetitionDetails,'typeDetails','name'),
                "formsAndLetters":[],
                "notifyPetitioner":false,
                "emailDocsForSign":false,

            };
            _.forEach(this.formsAndLettersList ,(item)=>{
              if(item['selectedForSigning']){
                postdata['formsAndLetters'].push(item['_id']);
              }

            })

            postdata['notifyPetitioner'] = this.notifyPetitioner
             postdata['emailDocsForSign'] = this.emailDocsForSign


          
            if(postdata['formsAndLetters'].length >0) {
              this.requestsigning =true;
              if(this.getTenantTypeId==2 && _.has(this.selectedSigner ,"_id")){
                postdata =Object.assign(postdata ,{"userId":self.selectedSigner['_id'] })

              }

              this.$store.dispatch("requestforsign", postdata).then((response) => {
               
                this.requestsignCommentError =false;
                 this.showToster({ message: response.message, isError: false });
                this.requestsignPopup = false;
                this.$modal.hide('requestsignPopupModal');
                 this.$store.dispatch("setPetitionTab" , 'Forms and Letters').then(()=>{
                   this.$emit("updatepetition" ,'Forms and Letters');
                   this.requestsigning =false;

                 }).catch(()=>{
                   this.$emit("updatepetition" ,'Forms and Letters');
                   this.requestsigning =false;

                 });
                
               
              }) .catch((error) => {
                 this.trackingErrors =error;
                  //Object.assign(this.formerrors ,{'msg':error});
                  //this.showToster({ message: error, isError: true });
                  this.requestsignCommentError =false;
                  this.requestsigning =false;
              });

            }else{
              this.trackingErrors="Select atleast one document!";
                this.requestsigning =false;
              this.checkFormsandLatters=true;
            }
            
       
            
        }, 
        
         submitassignrole() {
            this.$validator.validateAll("assignroleform").then((result) => {
                if (result) {
                    var postdata = {
                        petitionId: this.petition._id,
                        userId: this.assigntoroleModel._id,
                        userName: this.assigntoroleModel.name,
                        roleId: this.assignedRoleId,
                        typeName: this.petition.typeDetails.name,
                        subTypeName: this.petition.subTypeDetails.name,
                        comment: this.assignedrolecomments,
                        action: this.rolesubmitaction,
                        submitted: true,
                    };

                    this.$store.dispatch("gcpassigntoarole", postdata).then((response) => {
                        this.$emit("updatepetition");
                        this.showMessages(response.message);
                        this.assigntoRolePopup = false;
                    });
                }
            });
        },
        change_superwiser() {
            if (this.currentRole == 5) {
                this.SubmitParalegal = true;
                this.is_change_superwiser = true;
            }
        },
        change_paralegal() {
            if (this.currentRole == 5 || this.currentRole == 3) {
                this.replaceParalegaltitle = "Replace Paralegal";
                this.replaceParalegal = true;
                this.approveParalegalform = false;
                this.is_change_paralegal = true;
            }

            //alert("change_paralegal");
        },

        replaceparalegal() {
            this.replaceParalegaltitle = "Replace Paralegal";
            this.replaceParalegal = true;
            this.approveParalegalform = false;
            this.is_change_paralegal = false;
            this.pactiontype = "ASSIGN_PARALEGAL";
        },
        approveparalegal() {
            this.replaceParalegaltitle = "Approve Paralegal";
            this.replaceParalegal = true;
            this.approveParalegalform = true;
            this.pactiontype = "APPROVE_PARALEGAL";
        },
        submitapproveparalegal() {
            this.$validator.validateAll("approveparalegalfoform").then((result) => {
                if (result) {
                    var paralegalid = this.petition.paralegalDetails._id;
                    var userName = this.petition.paralegalDetails.name;
                    if (
                        this.paralegalModel != null &&
                        this.approveParalegalform == false
                    ) {
                        paralegalid = this.paralegalModel._id;
                        userName = this.paralegalModel.name;
                    }
                    var postdata = {
                        petitionId: this.petition._id,
                        userId: this.petition.paralegalDetails._id,
                        userName: this.petition.paralegalDetails.name,
                        roleId: 4,
                        typeName: this.petition.typeDetails.name,
                        subTypeName: this.petition.subTypeDetails.name,
                        comment: this.supervisorcomments,
                        action: this.pactiontype,
                        submitted: true,
                    };

                    if (this.is_change_paralegal) {
                        //alert("ACTION");
                        
                        postdata["userId"] = this.paralegalModel._id;
                        postdata["userName"] = this.paralegalModel.name;
                        postdata["typeName"] = this.paralegalModel.roleDetails[0]["name"];
                        postdata["action"] = "REPLACE_PARALEGAL";
                        postdata["lastUserName"] = this.petition.paralegalDetails.name;
                        //return false;
                    }
                    //petition/assign-a-role

                    this.$store.dispatch("assigntoarole", postdata).then((response) => {
                        this.$emit("updatepetition");
                        this.showMessages(response.message);
                        this.replaceParalegal = false;
                    });
                }
            });
        },
        assignparalegalform() {
            this.$validator.validateAll("paralegalfoform").then((result) => {
                if (result) {
                    // this.showMessages(JSON.stringify(this.petition.typeDetails));
                    
                    var postdata = {
                        petitionId: this.petition._id,
                        userId: this.paralegalModel._id,
                        userName: this.paralegalModel.name,
                        roleId: 4,
                        //    typeName: this.petition.typeDetails.name,
                        //  subTypeName: this.petition.subTypeDetails.name,
                        comment: this.supervisorcomments,
                        action: "ASSIGN_PARALEGAL",
                    };

                    // alert(JSON.stringify(postdata));

                    this.$store.dispatch("gcpassigntoarole", postdata).then((response) => {
                        this.$emit("updatepetition");
                        this.showMessages(response.message);
                        this.AssignParalegal = false;
                    });
                }
            });
        },
        checker(value) {
            this.documentlockformcomments = "";

            this.lockDocumentsPopup = true;
            this.lockDocumentsPopupTitle = "Lock Application Editing";
            if (!value) this.lockDocumentsPopupTitle = "Unlock Application Editing";
            this.documentsUpload = value;
        },
        submitdocumentslock() {
            this.$validator.validateAll("documentlockform").then((result) => {
                if (result) {
                    var postdata = {
                        petitionId: this.petition._id,
                        today: moment().format("YYYY-MM-DD"),
                        comment: this.documentlockformcomments,
                        action: this.documentsUpload ?
                            "DISABLE_EDIT_OPTION" :
                            "ENABLE_EDIT_OPTION",
                    };

                    this.$store
                        .dispatch("managegcediting", postdata)
                        .then((response) => {
                            this.showMessages(response.message);
                            this.lockDocumentsPopup = false;
                            this.documentlockformcomments = "";
                            this.petition.documentsUploadEnabled = this.documentsUpload;
                            this.$emit("updatepetition");
                        });
                }
            });
        },

        assignsupervisorform() {
            this.$validator.validateAll("supervisorform").then((result) => {
                if (result) {
                    var postdata = {
                        petitionId: this.petition._id,
                        userId: this.supervisorMode._id,
                        userName: this.supervisorMode.name,
                        roleId: 3,
                        typeName: this.petition.typeDetails.name,
                        subTypeName: this.petition.subTypeDetails.name,
                        comment: this.paralegalcomments,
                        action: "ASSIGN_SUPERVISOR",
                        submitted: true,
                    };

                    this.$store.dispatch("assigntoarole", postdata).then((response) => {
                        this.$emit("updatepetition");
                        this.showMessages(response.message);
                        this.SubmitParalegal = false;
                    });
                }
            });
        },
        approveOrreject(action_type = 1) {
            this.approveRejectTitle = "Approve Questionnaire";
            this.actionType = "approved";
            this.approveRejecInstructions = "";

            this.actionType = 1;
            if (action_type == "approved") {
                this.actionType = "approved";
                this.approveRejectTitle = "Approve Questionnaire";
                this.approveaction = true;
                this.$emit("passparent", 3);
            }
            if (action_type == "rejected") {
                this.actionType = "rejected";
                this.approveRejectTitle = "Reject Questionnaire";
                this.approveaction = false;
                this.approveRejectPop = true;
            }
        },
        saveApproveOrreject() {
            //alert(this.approveRejecInstructions);

            this.$validator.validateAll("approverejectquestion").then((result) => {
                if (result) {
                    // this.approveRejec_Instructions="* Instructions is required"

                    let payload_data = {
                        petitionId: this.petition._id,
                        comment: this.approveRejecInstructions,
                    };
                    // "action": "QUESTIONNIRE_APPROVED" // "QUESTIONNIRE_REJECTED" / "CASE_APPROVED" / "LCA_CERTIFIED_FOR_PETITION" / "READY_FOR_FILING" / "USCIS_APPROVED" / "USCIS_RECEIVED_RFE" / "USCIS_DENIED"

                    if (this.actionType == "approved") {
                        payload_data["action"] = "QUESTIONNIRE_APPROVED";
                    } else {
                        payload_data["action"] = "QUESTIONNIRE_REJECTED";
                    }
                    this.$store
                        .dispatch("manageApproval_process", payload_data)
                        .then((response) => {
                            this.$emit("updatepetition");


                            
                            this.showMessages(response.message);
                            this.approveRejectPop = false;
                        })
                        .catch((error) => {
                            alert(error)
                        });
                }
            });
        },
        petitionApproval() {
            //alert(this.approveRejecInstructions);
            this.usciscUpdateStatusError='';
            let self =this;
            this.$validator.validateAll("uscisstatus").then((result) => {
                if (result) {
                  
	                
                    // this.approveRejec_Instructions="* Instructions is required"

                    let payload_data = {
                        petitionId: this.petition._id,
                        comment: this.usciscomments,
                        action: this.casestatus.value,
                         "today": moment().format("YYYY-MM-DD"),
                         "typeName":this.petition.typeDetails.name,
                         "subTypeName":this.petition.subTypeDetails.name
                    };

                    let rfepayload = {
                        petitionId: this.petition._id,
                        comment: this.usciscomments,
                        description: this.usciscomments,
                        action: this.casestatus.value, //'UPDATE_USCIS_RESPONSE'
                         "today": moment().format("YYYY-MM-DD"),
                          "typeName":this.petition.typeDetails.name,
                         "subTypeName":this.petition.subTypeDetails.name
                    };
                    // "action": "QUESTIONNIRE_APPROVED" // "QUESTIONNIRE_REJECTED" / "CASE_APPROVED" / "LCA_CERTIFIED_FOR_PETITION" / "READY_FOR_FILING" / "USCIS_APPROVED" / "USCIS_RECEIVED_RFE" / "USCIS_DENIED"

                    if (this.casestatus.value == "USCIS_RECEIVED_RFE") {
                        payload_data["today"] = moment().format("YYYY-MM-DD");
                        payload_data["typeName"] = this.petition.typeDetails.name;
                        payload_data["subTypeName"] = this.petition.subTypeDetails.name;

                        rfepayload["today"] = moment().format("YYYY-MM-DD");
                        rfepayload["typeName"] = this.petition.typeDetails.name;
                        rfepayload["subTypeName"] = this.petition.subTypeDetails.name;

                        rfepayload["issuedDate"] = moment(this.issuedDate).format(
                            "YYYY-MM-DD"
                        );
                        rfepayload["receivedDate"] = moment(this.receivedDate).format(
                            "YYYY-MM-DD"
                        );
                        rfepayload["dueDate"] = moment(this.dueDate).format("YYYY-MM-DD");
                       
                    }
                  
                    rfepayload["documents"] = this.uscisdocument;
                    
                    
                    this.usciscUpdating =true;
                    this.filesAreuploading =false;
                    rfepayload["today"] = moment().format("YYYY-MM-DD");
                    //alert(JSON.stringify(rfepayload)); 
                    this.$store
                        .dispatch("manageApproval_process", rfepayload)
                        .then((response) => {
                            if (self.casestatus.value == "USCIS_RECEIVED_RFE") {
                                self.$store.dispatch("fileRFE", rfepayload).then((response) => {
                                   
                                    //this.showMessages(response.message);
                                    self.showToster({ message:response.message , isError: false})
                                    self.updateUSCISstatusPopup = false;

                                     setTimeout(() => {
                                    self.$emit("updatepetition");
                                
                                    } ,100)
                                });
                            } else {
                             
                               
                               // this.showMessages(response.message);
                                  self.showToster({ message:response.message , isError: false})
                                self.updateUSCISstatusPopup = false;
                                 setTimeout(() => {
                                    self.$emit("updatepetition");
                                
                                 } ,100)
                            }
                              this.usciscUpdating =false;
                        })
                        .catch((error) => {
                           this.usciscUpdating =false;
                           this.filesAreuploading =false;
                           this.usciscUpdateStatusError =error;
                          //this.showToster({ message: error, isError: true });
                        });
                }else{
                 // this.showToster({ message:"Invalid data" , isError: true});
                }
            });
        },
        
        
        
        selectedDocuments(index, fls) {

          let docs =_.cloneDeep(fls)
            let formData = new FormData();
            docs = docs.map(
                (item) =>
                (item = {
                    name: item.name,
                    file: item.file,
                    url: "",
                    path: "",
                    mimetype: item.type,
                    documentType:item.documentType?item.documentType:null,
                })
            );
           
            if (docs.length > 0) {
                var self = this;
                this.filesAreuploading = true;
                let count =0;
                docs.forEach(function (doc) {
                    formData.append("files", doc.file);
                    formData.append("secureType", "private");
                    self.$store.dispatch("uploadS3File", formData).then((response) => {
                      count = count+1;
                        if (response.data && response.data.result) {
                            response.data.result.forEach((urlGenerated) => {
                                doc.url = urlGenerated;
                                 doc.path = urlGenerated;
                                delete doc.file;
                                self.tracking.documents = docs;
                                self.uscisdocument = docs;
                                self.trackingdoc = docs;
                                self.documentData.documentUploaded = docs;
                                
                                    
                                 if(parseInt(count)>=docs.length){
                                   self.filesAreuploading = false;
                                  

                                }
                            });
                            if(count>=docs.length){
                              self.filesAreuploading = false;

                            }
                            
                        }
                       
                    });
                });
            }
        },
    fileNameChenged(index, fileindex) {
            this.disable_uploadBtn = false;

            _.forEach(this.documentData, (doc, value) => {
                if (doc.documentUploaded.length > 0) {
                    _.forEach(doc.documentUploaded, (fl, value) => {
                        let fname = fl.name;
                        fname = fname.trim();

                        if (!fname) {
                            this.disable_uploadBtn = true;
                        }
                    });
                }
            });

        },

   fileNameChengedScannedFiles( fileindex) {
            this.disable_uploadBtn = false;

           
                if (this.uploadScanedFilsList.length > 0) {
                    _.forEach(this.uploadScanedFilsList, (fl, value) => {
                        let fname = fl.name;
                        fname = fname.trim();

                        if (!fname) {
                            this.disable_uploadBtn = true;
                        }
                    });
                }
          

        },
        upload( docs) {
            
            
           
            if (docs.length > 0) {
                var self = this;
                self.filesAreuploading = true;
                let count =0;
                docs.forEach(function (doc) {
                  let formData = new FormData();
                    formData.append("files", doc.file);
                    formData.append("secureType", "private");
                     formData.append("getDetails",true);
                    
                    self.$store.dispatch("uploadS3File", formData).then((response) => {
                      count = count+1;
                        if (response.data && response.data.result) {
                            response.data.result.forEach((urlGenerated) => {
                              let tempUrl = urlGenerated
                              tempUrl = Object.assign(tempUrl, { uploadedBy: this.checkProperty(this.getUserData, 'userId'), uploadedByName: this.checkProperty(this.getUserData, 'name'), uploadedByRoleId: this.getUserRoleId, uploadedByRoleName: this.checkProperty(this.getUserData, 'loginRoleName') });
  
                                self.uploadScanedFilsList.push(tempUrl) ;
                                  
                                self.uploadScanedFilsList = _.cloneDeep(self.uploadScanedFilsList);
                                 if(parseInt(count)>=docs.length){
                                   self.filesAreuploading = false;
                                  

                                }
                            });
                            if(count>=docs.length){
                              self.filesAreuploading = false;

                            }
                            
                        }
                       
                    });
                });
            }
        },
        
   getscannedCopiesList(){
    this.formsAndLettersList =[];
          if( [3].indexOf(this.checkProperty(this.petition ,'typeDetails' ,'id'))>-1 ){
            return false;
          }
             
               let finalList =[];
           if(this.checkProperty(this.petition ,'_id' )){    
             let postData ={petitionId:this.petition._id ,'page':1 ,'perpage':100000};
            this.$store.dispatch("getList" ,{data:postData,path:"/petition/scanned-copies-list"})
            .then(response => {
               
            if(_.has(response , 'list')){
              this.scannedCopiesList = response['list'];
                 

            }

           
            
            })
          }
         }, 
         
         
         processInit(){
           this.getSignerList();
             this.getCourierList(); 
           this.assignMentUsersList = {
      "ASSIGN_SUPERVISOR":"SUPERVISOR_LIST",
      "ASSIGN_PARALEGAL":"PARALEGAL_LIST",
      "ASSIGN_DOCUMENTATION_MANAGER":"DOCUMENTATION_MANAGER_LIST",
      "ASSIGN_DOCUMENTATION_EXECUTIVE":"DOCUMENTATION_EXECUTIVE_LIST",
      "ASSIGN_ATTORNEY":"ATTORNEY_LIST",
      };

    this.$store
      .dispatch("getmasterdata", "lca_inventory_status")
      .then(response => {
        this.lcastatuses = _.filter(response, function(item) {
          return item.id == 2 || item.id == 3;
        });
      });
    
    
    this.gethistory();
   this.getFormsAndLetters(); 
   //this.formsAndLettersList = this.lettersAndForms;
    this.getscannedCopiesList();
    

         },

         getUserPrfoilePic(userId){
              let myDocements = _.find(this.petition.assignLogUserDetails ,{'_id':userId});

           if(myDocements && myDocements.profilePicture!=''){

             return myDocements.profilePicture
           }else{

             return commonImage;
           }

         },
   
  },
  mounted() {    
    if([50,51].indexOf(this.getUserRoleId)>-1 ){
    this.$store.commit('toggleCaseStatusTab','showActivities')
    }else{
    this.$store.commit('toggleCaseStatusTab','showCaseStatus')
      
    }

    if(this.checkProperty( this.petition, 'h1bCaseId')){
      let referncePetition = null;
      this.$store.dispatch("getpetition", this.petition['h1bCaseId']).then((response) => {
        referncePetition = response.data.result;
        if(_.has(referncePetition, 'typeDetails') && this.checkProperty(referncePetition, 'typeDetails', 'name')){
          this.viewCaseName = 'View '+this.checkProperty(referncePetition, 'typeDetails', 'name')+' Case'
        }else{
          this.viewCaseName = 'View H-1B Case'
        }
      })
    }    
    this.caseToken = this.checkProperty( this.petition ,'token'); 
    this.lcaToken = this.checkProperty( this.petition ,'lcaToken');
    setTimeout(()=>{
      this.caseToken = this.checkProperty( this.petition ,'token'); 
      this.lcaToken = this.checkProperty( this.petition ,'lcaToken');
      
    },1000);
    this.processInit();
    this.getBaseUrl();
    this.getMasterSocList();
    this.getvisatypes();
  
  

    
     
    
    
  },
 //lettersAndForms
};
</script>