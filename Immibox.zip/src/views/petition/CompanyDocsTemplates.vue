<template>
     
<div class="tab-inner-content">
    <div class="tabs-content-panel pad20">
        <div class="card-panels pt-0">

            <vs-row vs-justify="center">
                <vs-col class="p-0" type="flex" vs-justify="center" vs-align="center" vs-w="12">
                    <!-- Education card html v-if="[3].indexOf(currentRole)>-1"-->
                  
                    
                    <div class="pd_upload_actions pd_upload_actions_v2" @click="cancelpopups();parentId ='';formerrors.msg='';fuploder =false;parentId ='';fileuploadPopup=true;formerrors.msg='' , uploadMainDocuments=[] ,uploadFinalMainDocuments=[]" v-if="[3].indexOf(currentRole)>-1 && uploadCompanyDocs"  >
                        <span class="upload-btn">
                            <img src="@/assets/images/main/upload.svg" />Upload 
                        </span>                     
                    </div>

                    
                   
                   
                    <!--- petition.formsAndLetters---->
                    
                    
                   
                    <vs-card class="no-card">
                        <div v-if="formsAndLettersList.length>0" class="forms_accordian">
                            
                            
                            <vs-collapse accordion >
                                <template v-for="(forms, index) in formsAndLettersList" >
                              <!-- v-if="(currentRole ==12 && forms.selectedForSigning ) || currentRole !=12 "-->
                                <vs-collapse-item     :class="{ 'closeDropdown':currentRole ==50 , 'no-list': (checkProperty(forms ,'reverse_document_versions' ) && forms['reverse_document_versions'].length == 0)}" :not-arrow="!(checkProperty(forms ,'reverse_document_versions' ) && forms['reverse_document_versions'].length >= 0)"  :key="index">
                                    <div slot="header" class="ss">
                                       
                                        <vs-list-item :title="forms.name" :subtitle="getformated(forms)">
                                       
                                            <template slot="avatar">
                                                 <img v-if="checkFileFormat(forms['mimetype']) =='pdf'" src="@/assets/images/main/pdf.svg" /> 
                                                <img v-else-if="checkFileFormat(forms['mimetype']) =='video_mime_types'" src="@/assets/images/main/film.png" />
                                                <img v-else-if="checkFileFormat(forms['mimetype']) =='msDoc'" src="@/assets/images/main/doc.svg" />
                                                <img v-else-if="checkFileFormat(forms['mimetype']) =='zip'" src="@/assets/images/main/zip-file-format.png" />
                                                <img v-else-if="checkFileFormat(forms['mimetype']) =='msPpt'" src="@/assets/images/main/ppt.svg" />
                                                <img v-else-if="checkFileFormat(forms['mimetype']) =='msXl'" src="@/assets/images/main/xls.svg" /> 
                                                <img v-else-if="checkFileFormat(forms['mimetype']) =='image'" src="@/assets/images/main/image.svg" />
                                                <img v-else src="@/assets/images/main/icon-img.svg" />
                                            </template>
                                            <div class="vertical-menu">
                                                <span class="menu-icon">
                                                    <i class="material-icons">more_vert</i>
                                                </span>
                                              
                                                <ul>
                                                <!--
                                                    <li v-if="[50].indexOf(currentRole) >-1 " @click="selDoc(forms.mainParentId)">Upload</li>
                                                    -->
                                                    <li @click="fetchSignedUrl(forms,false,true)">View</li>
                                                    <li v-if="forms['createdBy'] ==currentUser"  @click="openConformPopUp(forms)">Delete</li>
                                                </ul>
                                            </div>
                                        </vs-list-item>
                                    </div>
                                    
                                    <template  v-if="false && (checkProperty(forms , 'reverse_document_versions') && ( [51].indexOf(getUserRoleId)<=-1 ))">
                                      
                                        <template  v-for="(reveforms, inde) in forms['reverse_document_versions']" >
                                            <vs-list-item   v-if="currentRole ==50"  :key="inde" :title="reveforms.name" :subtitle="getformated(reveforms)">
                                            
                                                <template slot="avatar">
                                                     <img v-if="checkFileFormat(reveforms['mimetype']) =='pdf'" src="@/assets/images/main/pdf.svg" /> 
                                                    <img v-else-if="checkFileFormat(reveforms['mimetype']) =='video_mime_types'" src="@/assets/images/main/film.png" />
                                                    <img v-else-if="checkFileFormat(reveforms['mimetype']) =='msDoc'" src="@/assets/images/main/doc.svg" />
                                                    <img v-else-if="checkFileFormat(reveforms['mimetype']) =='zip'" src="@/assets/images/main/zip-file-format.png" />
                                                    <img v-else-if="checkFileFormat(reveforms['mimetype']) =='msPpt'" src="@/assets/images/main/ppt.svg" />
                                                    <img v-else-if="checkFileFormat(reveforms['mimetype']) =='msXl'" src="@/assets/images/main/xls.svg" /> 
                                                    <img v-else-if="checkFileFormat(reveforms['mimetype']) =='image'" src="@/assets/images/main/image.svg" />
                                                    <img v-else src="@/assets/images/main/icon-img.svg" />
                                                </template>
                                              
                                                 
                                                <span class="view_doc" @click="fetchSignedUrl(reveforms,false,true)">View</span>
                                                <span class="view_doc"   v-if="reveforms['createdBy'] ==currentUser "  @click="openConformPopUp(reveforms)">Delete</span>
                                            </vs-list-item>
                                        </template>
                                    </template>     
                                </vs-collapse-item>
                               </template>  
                            </vs-collapse>
                        </div>
                        <!--
                        <paginate  v-if="formsAndLettersList.length>0"  v-model="page" :page-count="totalpages" :page-range="3" :margin-pages="2" :click-handler="pageNate"
                        prev-class="vs-pagination--buttons btn-prev-pagination vs-pagination--button-prev"
                        next-class="vs-pagination--buttons btn-next-pagination vs-pagination--button-next" :prev-text="'<i></i>'"
                        :next-text="'<i></i>'" :container-class="'pagination vs-pagination--nav'" :page-class="'page-item'"></paginate>
                        -->

                         <NoDataFound ref="NoDataFoundRef" v-if="formsAndLettersList.length<=0"  content="" heading="No Documents Found" type='documents' />
    
                    </vs-card>
                </vs-col>
            </vs-row>

           
        </div>
    </div>

    

    <vs-popup class="Change_petition_wrap" title="Download Forms" :active.sync="downloadSamplespopup">
        <div class="Change_petition">
            <div class="vx-col w-full marb10">
                <ul class="downloads_list">
                    <li v-for="(typ, index) in types" :key="index">
                        <p>{{typ.name}}</p>
                        <span>Download</span>
                    </li>
                </ul>
            </div>
        </div>
        <div class="actions_footer">
            <button @click="downloadSamplespopup=false" class="btn cancel">Cancel</button>
        </div>
    </vs-popup>

    

    <vs-popup class="Change_petition_wrap" v-if="reversion_fileuploadPopup" title="Upload" :active.sync="reversion_fileuploadPopup">
        <div class="Change_petition">
            <div class="vx-col w-full marb10">
                <div v-for="(docData, index) in documentData" :key="index">
                    <div class="vx-row">
                        <div class="vx-col w-full">
                            <vx-input-group class="form-input-group select-upload-group">
                                <div class="uploadsec_wrap">
                                    <div class="w-full">
                                        <file-upload v-model="version_documentUploaded" class="file-upload-input mb-0" style="height:50px;" :name="'version_documents'+index" :multiple="false" v-validate="'required'" label="Forms and Letters" data-vv-as="Forms and Letters" :accept="allDocEntity"
                                         @input="doUpload(selectedDoc ,version_documentUploaded)">
                                            <img class="file-icon" src="@/assets/images/main/file-upload.svg" />

                                            Upload
                                        </file-upload>

                                        <span class="file-type">(File Type: PDF, DOC, JPEG, PNG. Max file size: 1MB)</span>

                                        <VuePerfectScrollbar class="scrollbardoc">
                                            <div class="uploded-files_wrap" v-if="version_documentUploaded.length >0 ">
                                                <div class="w-full" v-for="(fil, fileindex) in version_documentUploaded" :key="fileindex">
                                                    <div class="uploded-files">
                                                        <vx-input-group class="form-input-group">
                                                            <vs-input v-on:keyup="reversion_fileNameChenged(fileindex)" required class="w-full" :name="'fName'+index" v-model="version_documentUploaded[fileindex]['name']" data-vv-as="File Name" />
                                                            <span class="text-danger text-sm" v-show="!version_documentUploaded[fileindex]['name']">Please Enter file name</span>
                                                            <span class="text-danger text-sm" v-show="errors.has('fName'+index)">{{ errors.first('fName'+index) }}</span>

                                                            <div class="delete" style="z-index:999" @click="remove_reversion_file()">
                                                                <img src="@/assets/images/main/cross.svg" />
                                                            </div>
                                                        </vx-input-group>
                                                    </div>
                                                </div>
                                            </div>
                                        </VuePerfectScrollbar>
                                    </div>
                                </div>
                            </vx-input-group>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="text-danger text-sm formerrors" v-show="formerrors.msg" @click="formerrors.msg=''">
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
              icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
          </div>
        <div class="actions_footer relative">
            <button @click="reversion_fileuploadPopup=false ;formerrors.msg =''" class="btn cancel">Cancel</button>
            <button class="btn" v-bind:disble="disable_reversion_uploadBtn" @click="updateDocument_Version()">
               <figure v-if="fuploder" class="loader loader2"><img src="@/assets/images/main/loader.gif" /></figure>
                Upload 
            </button>
        </div>
    </vs-popup>
   
   <vs-popup class="Change_petition_wrap" v-if="downloadFiles" title="Download Files" :active.sync="downloadFiles">
        <div v-if="formsAndLettersList.length>0" class="forms_accordian">
       
                            
                            
                            <vs-collapse accordion   >
                                <template v-for="(forms, index) in formsAndLettersList" >
                                <vs-collapse-item  :open="openItem"  :class="{ 'closeDropdown':currentRole ==50 , 'no-list': (checkProperty(forms ,'reverse_document_versions' ) && forms['reverse_document_versions'].length == 0)}" :not-arrow="!(checkProperty(forms ,'reverse_document_versions' ) && forms['reverse_document_versions'].length >= 0)"  :key="index">
                                    <div slot="header" class="ss">
                                    
                                        <vs-list-item    :title="forms.name" :subtitle="getformated(forms)">
                                            <template slot="avatar">
                                                    <img v-if="checkFileFormat(forms['mimetype']) =='pdf'" src="@/assets/images/main/pdf.svg" /> 
                                                    <img v-else-if="checkFileFormat(forms['mimetype']) =='video_mime_types'" src="@/assets/images/main/film.png" />
                                                    <img v-else-if="checkFileFormat(forms['mimetype']) =='msDoc'" src="@/assets/images/main/doc.svg" />
                                                    <img v-else-if="checkFileFormat(forms['mimetype']) =='zip'" src="@/assets/images/main/zip-file-format.png" />
                                                    <img v-else-if="checkFileFormat(forms['mimetype']) =='msPpt'" src="@/assets/images/main/ppt.svg" />
                                                    <img v-else-if="checkFileFormat(forms['mimetype']) =='msXl'" src="@/assets/images/main/xls.svg" /> 
                                                    <img v-else-if="checkFileFormat(forms['mimetype']) =='image'" src="@/assets/images/main/image.svg" />
                                                    <img v-else src="@/assets/images/main/icon-img.svg" />
                                            </template>
                                            
                                                
                                                
                                                <ul>
                                                    <li >
                                                    <vs-checkbox :disabled="( [50,51].indexOf(getUserRoleId)>-1 )"  :name="'selectedForSigning_'+index+'_'+inde"  v-model="forms.selectedForDownload" class=""></vs-checkbox>
                                               
                                                    </li>
                                                   
                                                </ul>
                                            
                                        </vs-list-item>
                                    </div>
                                    
                                    <template  v-if="checkProperty(forms , 'reverse_document_versions') && ( [50,51].indexOf(getUserRoleId)<=-1 )">
                                      
                                        <template  v-for="(reveforms, inde) in forms['reverse_document_versions']" >
                                            <vs-list-item   :key="inde" :title="reveforms.name" :subtitle="getformated(reveforms)">
                                                <template slot="avatar">
                                                    <img v-if="checkFileFormat(reveforms['mimetype']) =='pdf'" src="@/assets/images/main/pdf.svg" /> 
                                                    <img v-else-if="checkFileFormat(reveforms['mimetype']) =='video_mime_types'" src="@/assets/images/main/film.png" />
                                                    <img v-else-if="checkFileFormat(reveforms['mimetype']) =='msDoc'" src="@/assets/images/main/doc.svg" />
                                                    <img v-else-if="checkFileFormat(reveforms['mimetype']) =='zip'" src="@/assets/images/main/zip-file-format.png" />
                                                    <img v-else-if="checkFileFormat(reveforms['mimetype']) =='msPpt'" src="@/assets/images/main/ppt.svg" />
                                                    <img v-else-if="checkFileFormat(reveforms['mimetype']) =='msXl'" src="@/assets/images/main/xls.svg" /> 
                                                    <img v-else-if="checkFileFormat(reveforms['mimetype']) =='image'" src="@/assets/images/main/image.svg" />
                                                    <img v-else src="@/assets/images/main/icon-img.svg" />
                                                </template>
                                              
                                                  <vs-checkbox  :name="'selectedForSigning_'+index+'_'+inde"  v-model="reveforms.selectedForDownload" class=""></vs-checkbox>
                                               
                                            </vs-list-item>
                                        </template>
                                    </template>     
                                </vs-collapse-item>
                               </template>  
                            </vs-collapse>
        </div>
        <div class="text-danger text-sm formerrors" v-show="formerrors.msg" @click="formerrors.msg=''">
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
              icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
          </div>
        <div class="actions_footer relative">
            <button @click="downloadFiles=false ;formerrors.msg =''" class="btn cancel">Cancel</button>
            <button class="btn" @click="downloadFormslatters()">
               <figure v-if="downloading" class="loader loader2"><img src="@/assets/images/main/loader.gif" /></figure>
                Download 
            </button>
        </div>
    </vs-popup>

    <vs-popup class="holamundo main-popup" title="Delete Document" :active.sync="approveConformpopUp">
      <div class="form-container">
        
        <div class="vx-row">
          <div class="vx-col w-full">
          <p>Do you want to Delete?</p>
            
          </div>
          
        </div>
       
      </div>
      <div class="text-danger text-sm formerrors" v-show="formerrors.msg" @click="formerrors.msg=''">
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
              icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
          </div>
      <div class="popup-footer">
        <vs-button color="dark" class="cancel" type="filled" @click="approveConformpopUp=false">Cancel</vs-button>
        <vs-button color="success" class="save" type="filled" @click="deleteDocument()">Delete</vs-button>
      </div>
    </vs-popup>

    <vs-popup class="Change_petition_wrap" :title="'Upload Documents'" :active.sync="fileuploadPopup">
        <div class="Change_petition" @click="formerrors.msg=''">
            <div class="vx-col w-full">
            
                
                    <div class="vx-row">
                        <div class="vx-col w-full">
                            <vx-input-group class="form-input-group select-upload-group">
                                <div class="uploadsec_wrap">
                                    <div class="w-full">
                                     <!-- :accept="acceptedFiles"  -->

                                        <div  @click="uploadMainDocuments=[]">
                                            <div class="relative">
                                                <file-upload v-model="uploadMainDocuments"                                           
                                                class="file-upload-input mb-0" style="height:50px; padding:0px;" :name="'pdocuments'" :multiple="true" :hideSelected="true" v-validate="'required'" label="Forms and Letters" data-vv-as="Forms and Letters"  @input="uploadToS3MainDocuments(index, uploadMainDocuments)">
                                                    <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                                                    Upload
                                                </file-upload>
                                                <span v-if="fileUploading" class="loader"><img src="@/assets/images/main/loader.gif"></span>   
                                            </div>
                                            <span class="file-type mb-0">(File Type: PDF, DOC, JPEG, PNG. Max file size: 1MB)</span>
                                            <span class="text-danger text-sm" v-show="errors.has('pdocuments')">{{ errors.first('documents'+index) }}</span>
                                        </div>

                                        <VuePerfectScrollbar class="scrollbardoc">
                                            <div class="uploded-files_wrap mt-3" v-if="uploadFinalMainDocuments && uploadFinalMainDocuments.length >0 ">
                                                <div class="w-full" v-for="(fil, fileindex) in uploadFinalMainDocuments" :key="fileindex">                                                   
                                                    <div class="uploded-files">
                                                        <vx-input-group class="form-input-group">
                                                            <vs-input v-on:keyup="filameChenged(fileindex)"  v-validate="'required'" class="w-full" :name="'fName'+fileindex" v-model="fil['name']" data-vv-as="File Name" />
                                                            <span class="text-danger text-sm" v-show="errors.has('fName'+fileindex)">{{ errors.first('fName'+fileindex) }}</span>

                                                            <div class="delete" style="z-index:999" @click="remove(fil, uploadFinalMainDocuments ,fileindex)">
                                                                <img src="@/assets/images/main/cross.svg" />
                                                            </div>
                                                        </vx-input-group>
                                                    </div>
                                                </div>
                                            </div>
                                        </VuePerfectScrollbar>
                                    </div>
                                </div>
                            </vx-input-group>
                        </div>
                    </div>
                
            </div>
             <div class="text-danger text-sm formerrors" v-show="formerrors.msg" @click="formerrors.msg=''">
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius mb-0 mt-3" icon-pack="IntakePortal"
              icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
          </div>
        </div>
        <!-----v-if="fuploder"-->
        
        <div class="popup-footer relative">
            <button @click="fileuploadPopup=false;cancelpopups() ; fuploder=false" class="btn cancel">Cancel</button>
            <button class="btn save" v-bind:disble="disable_uploadBtn || uploadFinalMainDocuments.length <=0 || fileUploading" @click="updateFormsAndDocuments()">
                <figure v-if="fuploder"  class="loader"><img src="@/assets/images/main/loader.gif" /></figure> 
                Upload
            </button>
        </div>
    </vs-popup>


</div>
</template>

<script>
const formatter = new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 2
});

import FileUpload from "vue-upload-component/src";
import moment from "moment";
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import Paginate from "vuejs-paginate";
import NoDataFound from "@/views/common/noData.vue";

  

export default {
    props: {
        uploadCompanyDocs:{
            type:Boolean,
            default:true
        },
        currentRole: null,
        currentUser: null,
        petition: {
            type: Object,
            default: null
        },
        companyId:{
            type: String,
            default: ''
        },
    },
    components: {
        NoDataFound,
        Paginate,
        FileUpload,
        VuePerfectScrollbar
    },
    methods: {

         filameChenged(fileindex) {
            this.disable_uploadBtn = false;

            
                if (this.uploadFinalMainDocuments.length > 0) {
                    _.forEach(this.uploadFinalMainDocuments, (fl, value) => {
                        //let fname = fl.name;
                        let fname = fl.document.name;
                        fname = fname.trim();
                        

                        if (!fname) {
                            this.disable_uploadBtn = true;
                        }
                    });
                }
         

        },
         //uploadMainDocuments
        uploadToS3MainDocuments(index, docs){
             docs = docs.map(
                item =>
                (item = {
                    name: item.name,
                    file: item.file,
                    document: "",
                    path:'',
                    mimetype: item.type
                })
            );


            if (docs.length > 0) {
                let filIndex = 0;
                this.fileUploading = true;
                this.disable_uploadBtn = true;
                docs.forEach(doc => {
                     
                     
              //  if((this.formLetterType == "Form" && (doc.mimetype=='application/pdf' || doc.type=='application/pdf') ) || (this.formLetterType == "Letter" && (doc.mimetype=='application/msword' || doc.type=='application/msword'  || doc.mimetype=='application/vnd.openxmlformats-officedocument.wordprocessingml.document' || doc.type=='application/vnd.openxmlformats-officedocument.wordprocessingml.document') ) ){
                         
                    let formData = new FormData();
                    formData.append("files", doc.file);
                    formData.append("secureType", "private");
                     formData.append("getDetails", true);
                    
                       
                    this.$store.dispatch("uploadS3File", formData).then(response => {
                         filIndex++;
                         if (filIndex >= this.uploadMainDocuments.length) {
                                this.fileUploading = false;
                                this.disable_uploadBtn = false;
                            }
                        

                        response.data.result.forEach(urlGenerated => {
                            //alert(JSON.stringify(urlGenerated));
                            doc.document = urlGenerated;
                            doc.path = urlGenerated;
                           //this.uploadMainDocuments.push(doc);
                           this.uploadFinalMainDocuments.push(doc);
                        });

                        
                      
                    });
              //  }
                    
                });
            }

        },


        openConformPopUp(item){
            this.selectedItem = item;
            this.approveConformpopUp = true;
            Object.assign(this.formerrors ,{msg:''});
        },
         //selectedForDownload
        openDownloadPopup(action=true){
            
            _.forEach(this.formsAndLettersList,(item)=>{
                item['selectedForDownload'] =true;
                if(this.checkProperty(item , 'reverse_document_versions') && item['reverse_document_versions'].length>0 ){
                     _.forEach(item['reverse_document_versions'],(vItem)=>{
                         vItem.selectedForDownload =false;

                     });



                }

            })
            this.downloadFiles=action;
            this.downloading =false;
            Object.assign(this.formerrors ,{ msg:''})
            this.openItem =true

        },
        
        uploadNewFormsandLatters(files ,type="") {
        let model = _.cloneDeep(files);
        this.value = [];
     
     
      this.newFormsAndLetters= [];

            var _current = this;
            this.$vs.loading();
            let formData = new FormData();
           
            let tempFiles =[]
            if (model.length > 0) {
                
                model.forEach((doc, index) => {
                   
                    if(( doc.type=='application/pdf' ) || ( doc.type=='application/msword' ) ){

                    
                    formData.append("files", doc.file);
                    formData.append("secureType", "private");
                    formData.append("getDetails", true);
                                        
                    this.$store.dispatch("uploadLocal", formData).then((response) => {
                        response.data.result.forEach((urlGenerated) => {
                            doc.url = urlGenerated;
                            delete doc.file;
                             let temp_file = urlGenerated;
                             
                           
                          tempFiles.push(temp_file);
                          let fl = { "name":temp_file['name'] ,"url":temp_file['path'] , "mimetype":temp_file['mimetype']} ;
                           this.newFormsAndLetters.push(fl);
                        
                         
                         if (tempFiles.length >= model.length) {
                              _current.$vs.loading.close();
                          }   
                       
                       });
                    
                    });

                  }else{
                     _current.$vs.loading.close();
                  }
               });
                
               
            }     
              //  model.splice(0, mapper.length, ...mapper);
            
        },
        
        selDoc(seldoc) {
            Object.assign(this.formerrors ,{msg:''});
            this.parentId = seldoc;
            this.selectedDoc = seldoc;
            this.reversion_fileuploadPopup = true;
            this.version_documentUploaded = [];
            this.disable_reversion_uploadBtn = true;
        },
        reversion_fileNameChenged(fileindex) {
            let fname = this.version_documentUploaded[fileindex]["name"];
            fname = fname.trim();
            this.disable_reversion_uploadBtn = false;
            if (!fname) {
                this.disable_reversion_uploadBtn = true;
            }
        },
        remove_reversion_file() {
            this.version_documentUploaded = [];
        },

        fileNameChenged(index, fileindex) {
            this.disable_uploadBtn = false;

            _.forEach(this.documentData, (doc, value) => {
                if (doc.documentUploaded.length > 0) {
                    _.forEach(doc.documentUploaded, (fl, value) => {
                        //let fname = fl.name;
                        let fname = fl.document.name;
                        fname = fname.trim();

                        if (!fname) {
                            this.disable_uploadBtn = true;
                        }
                    });
                }
            });

        },
        fetchSignedUrl(value, download = false, viewmode = false) {
            value.download = download;
            value.viewmode = viewmode;
        
         this.$emit('download_or_view' ,value);
        // window.open(this.$globalgonfig._APIURL+"/common/viewfile?path="+value.path, "_blank");
            
            
        },
        remove(item, type) {
            type.splice(type.indexOf(item), 1);
            return false;
        },
        
        getformated(item) {
            //YYYY-MM-DD  HH:mm:ss
            if(item.createdOn){
                return (
                "Uploaded On  " +
                moment(item.createdOn).format("MMM DD, YYYY hh:mm:ss a") +
                " - Uploaded by " + item.createdByName
               // +" "+item.parentId +" id="+item._id
            );

            }else if(item.uploadedOn){
                return (
                "Uploaded On  " +
                moment(item.uploadedOn).format("MMM DD, YYYY hh:mm:ss a") +
                " - Uploaded by " + item.createdByName
               // +" "+item.parentId +" id="+item._id
            );

            }else{
                return 'Uploaded by '+ item.createdByName
            }
            
        },
        deleteDocument() {
            
            let postdata = {
                documentId: this.selectedItem._id
            };
            this.$store.dispatch("deleteCompanyDoc", postdata).then(response => {
               
                this.showToster({ message: response.message, isError: false });
                this.selectedItem =null;
                this.approveConformpopUp =false;
                this.getFormsAndLetters();
               

            })
            .catch((error) => {
                Object.assign(this.formerrors ,{'msg':error})
                //this.showToster({ message: error, isError: true });
                this.approveConformpopUp = true;
            });
        },
        fetchFormsMasterData() {
            this.$store
                .dispatch("getmasterdata", "forms_and_letter")
                .then(response => {
                    this.types = [];
                    this.types.push({
                        name: "Selecte form",
                        id: ""
                    });
                    //  this.types = response;
                      
                    _.forEach(response, item => {
                       
                        this.types.push(item);
                    });
                     // alert(JSON.stringify(this.types));
                });
        },
        selectedDocuments(index, docs) {
           
            docs = docs.map(
                item =>
                (item = {
                    name: item.name,
                    file: item.file,
                    document: "",
                    path:'',
                    mimetype: item.type
                })
            );
            this.documentData[index].documentUploaded = [];
            this.documentData[index].documentUploaded = docs;
            this.fuploder = false;
            this.disable_uploadBtn = false;
            if (docs.length > 0) {
                let filIndex = 0;
                this.fuploder = true;
                this.disable_uploadBtn = true;
                this.documentData[index].documentUploaded.forEach(doc => {
                    let formData = new FormData();
                    formData.append("files", doc.file);
                    formData.append("secureType", "private");
                     formData.append("getDetails", true);
                    //uploadS3File 
                       
                    this.$store.dispatch("uploadS3File", formData).then(response => {
                         filIndex++;
                         if (filIndex >= this.documentData[index].documentUploaded.length) {
                                this.fuploder = false;
                                this.disable_uploadBtn = false;
                            }
                        

                        response.data.result.forEach(urlGenerated => {
                            //alert(JSON.stringify(urlGenerated));
                            doc.document = urlGenerated;
                            doc.path = urlGenerated;
                            if(this.documentData[index].documentUploaded[filIndex] ){
                            this.documentData[index].documentUploaded[filIndex]["document"] = urlGenerated;
                            this.documentData[index].documentUploaded[filIndex]["path"] = urlGenerated;


                           
                                

                            }
                        });

                        
                      
                    });
                    
                });
            }
            this.fileuploadPopup = true
            this.fileUploading =false;
        },
        
        remove_uploadedfile(index, fileindex) {
            this.documentData[index].documentUploaded.splice(fileindex, 1);
        },
        
        updateFormsAndDocuments() {
             
             Object.assign( this.formerrors ,{ msg:''})
            if (this.disable_uploadBtn) {
                return false;
            }
           // this.fileuploadPopup = false;
            let postData = {
                  companyId: this.companyId,
                  formLetterType: this.formLetterType,
                  documents:[],
                

            };
            if(this.parentId){
                postData = Object.assign(postData ,{"parentId":this.parentId})
            }
            if(this.uploadFinalMainDocuments.length>0){

                    this.uploadFinalMainDocuments.forEach((doc)=>{
                       
                        let document = doc.document
                        document = Object.assign(document ,{ name:doc.name})
                         postData['documents'].push(document);
                    })
                   

                
            this.fuploder = true;
            this.disable_uploadBtn = true;
            let count = 0;
            // alert(JSON.stringify(postData))

             this.$store
                    .dispatch("uploadCompanyDocuments", postData)
                    .then(response => {
                        
                         this.fileuploadPopup = false;
                         this.showToster({message:response.message ,isError:false })
                         this.fuploder = false;
                         this.disable_uploadBtn = false;
                         this.fileuploadPopup = false;
                         this.fileUploading =false;
                         this.getFormsAndLetters();

                   
                    })
                    .catch((error) => {
                        Object.assign(this.formerrors ,{'msg':error})
                        //this.showToster({ message: error, isError: true });
                        this.fuploder = false;
                        this.disable_uploadBtn = false;
                    });
             
       }else{
            Object.assign( this.formerrors ,{ msg:'Upload atleast one document'})

      }
    
         
       
       },

        doUpload(id, documents, typeId = "") {
            this.documentId = id;

            let formData = new FormData();
            documents = documents.map(
                item =>
                (item = {
                    typeId: typeId,
                    name: item.name,
                    file: item.file,
                    path: "",
                   
                    mimetype: item.type
                })
            );
            this.disable_reversion_uploadBtn = false;
            this.rfuploder = false;
            if (documents.length > 0) {
                this.rfuploder = true;
                this.disable_reversion_uploadBtn = true;
                let findx = 0;
                this.version_documentUploaded.forEach(doc => {
                    formData.append("files", doc.file);
                    formData.append("secureType", "private");
                    this.$store.dispatch("uploadS3File", formData).then(response => {
                        response.data.result.forEach(urlGenerated => {
                            doc.path = urlGenerated;
                            this.reversionFile = doc;
                            this.disable_reversion_uploadBtn = false;
                            this.rfuploder = false;
                        });
                    });
                    findx++;
                });
            }
        },
        updateDocument_Version() {
            Object.assign(this.formerrors ,{'msg':''})
            if (
                this.version_documentUploaded.length > 0 &&
                !this.disable_reversion_uploadBtn
            ) {
                this.disable_reversion_uploadBtn = true;
               this.rfuploder = false;
                
                  let postData = {
                  companyId: this.companyId,
                  formLetterType:this.formLetterType,
                  documents:[],
                

            };
                this.version_documentUploaded.forEach(doc => {
                   postData['documents'].push(doc);
                   
                    });
                    if(this.documentId){
                     postData = Object.assign(postData ,{"parentId":this.documentId})
                  }

                  
                    this.$store
                        .dispatch("uploadCompanyDocuments", postData)
                        .then(response => {
                           
                            this.reversion_fileuploadPopup = false;
                             this.version_documentUploaded = [];
                             this.disable_reversion_uploadBtn = true;
                            //this.getFormsAndLetters();
                             this.showToster({message:response.message ,isError:false })
                              this.getFormsAndLetters();
                        })
                        .catch((error) => {
                             Object.assign(this.formerrors ,{'msg':error})
                        this.showToster({ message: error, isError: true });
                    });

               
            }
        },
        updateFilingFee() {
            this.$emit("showfilingFeesPopup");
        },
        cancelpopups() {
            this.documentData = [{
                type: "Forms, Letters and Others",
                documentUploaded: []
            }]
        },
        downloadFormslatters() {
             let postdata = {
           companyId :this.companyId,
           "documentIds": []
         };
         
         //petition/download-forms-letters,
         if([3,4,5,6,7,8,9,10,11 ,12].indexOf(this.getUserRoleId)>-1){

          _.forEach(this.formsAndLettersList,(item)=>{
               
                if( item['selectedForDownload'] && postdata['documentIds'].indexOf(item._id) <=-1 ){
                    postdata['documentIds'].push(item._id)
                }
                if(this.checkProperty(item , 'reverse_document_versions') && item['reverse_document_versions'].length>0 ){
                     _.forEach(item['reverse_document_versions'],(vItem)=>{
                         if( vItem['selectedForDownload'] && postdata['documentIds'].indexOf(vItem._id) <=-1 ){
                                 postdata['documentIds'].push(vItem._id)
                         }

                     });



                }

            })
        }
            if(([3,4,5,6,7,8,9,10,11,12].indexOf(this.getUserRoleId)>-1 && postdata['documentIds'].length>0) || ( [50,51].indexOf(this.getUserRoleId)>-1 ) ){
                this.downloading=true;
                this.$store
                .dispatch("downloadScannedCopies", postdata)
                .then(response => {
                    this.downloading=false;
                    this.openDownloadPopup(false);
                    window.open(this.$globalgonfig._APIURL+"/common/viewfile?path="+response.path, "_blank");
                // window.open(response.data.result.data, '_blank');
                })
                .catch((error)=>{
                    this.downloading=false;
                    Object.assign(this.formerrors ,{ msg:error})
                    // this.showToster({ message: error, isError: true });

                });
            }

        },
         reloadPetition() {
            setTimeout(()=>{
                this.$emit("updatepetition" ,'Scanned Documents');
            } ,100);
         },
         getFormsAndLetters(){
               this.updateLoading(true);
              this.formsAndLettersList =[];
               let finalList =[];
             let postData ={companyId:this.companyId ,'page':1 ,'perpage':100000};
            this.$store.dispatch("getList" ,{data:postData,path:"/company/documents-list"})
            .then(response => {
                 this.updateLoading(false);
               
            let lst = [];
           
            _.forEach(response.list ,(mainItem)=>{
                mainItem = Object.assign(mainItem,{"reverse_document_versions":[] ,"mainParentId":'',showMe:true ,selectedForDownload:false});
               if(mainItem.parentId){
                   mainItem['mainParentId'] = mainItem['parentId']
               }else{
                    mainItem['mainParentId'] = mainItem['_id']
               }

                lst.push(mainItem);
                 

            });

            let subList=[];
           
            //reverse_document_versions
            _.forEach(lst ,(mainItem)=>{

                                
               
               _.forEach(lst ,(subItem)=>{
                    if( mainItem.parentId && (mainItem.parentId == subItem['parentId'] ||  mainItem.parentId == subItem['_id']   ) &&  mainItem['_id'] != subItem['_id']){
                             
                             subItem['showMe'] =false;
                             if(subList.indexOf(subItem['_id']<=-1)){
                                  mainItem['reverse_document_versions'].push(subItem);
                                  subList.push(subItem['_id']);

                             }
                            
                            // mainItem['showMe'] =true;
                    }

                })
                
            if(mainItem.showMe){
                 finalList.push(mainItem);
            }
           
      
             
              

            })
           

            this.totalpages = Math.ceil(response.totalCount / this.perpage);
            this.formsAndLettersList =  finalList;
            
            }).catch((err)=>{
                this.formsAndLettersList = [];
                 this.updateLoading(false);
               
            })

           
            

         },
        pageNate(pageNum) {
             this.page = pageNum;
            this.getFormsAndLetters();
      },
      openGeneratePopup(){
          this.formerrors.msg='';
          this.newFormsAndLetters =[],
          this.generatePopup =true;
      }
    },
    data: () => ({
        approveConformpopUp:false,
        selectedItem:null,
        generatingFiles:false,
        openItem:true,
        formLetterType:'Form',
        downloading:false, 
        downloadFiles:false,
        parentId:'',
        uploading:false,
         value:[],
        formerrors: {
        msg: ""
      },
         newFormsAndLetters:[],
        all_formTypes:[{"name":"Form" ,"id":"Form"},{"name":"Letter" ,"id":"Letter"} ],
        generatePopup:false,
        totalpages:0,
        page:1,
        perpage:25,
        formsAndLettersList:[],
        types: [],
        typeSelected: "",
        documents: [],
        documentData: [{
            type: "Forms, Letters and Others",
            documentUploaded: []
        }],
        formsData: [],
        formsAndLetterSignedUrls: [],
        downloadSamplespopup: false,
        documentId: "",
        version_documentUploaded: [],
        fileuploadPopup: false,
        disable_uploadBtn: false,
        fileUploading:false,
        selectedDoc: "",
        reversion_fileuploadPopup: false,
        disable_reversion_uploadBtn: false,
        reversionFile: null,
        fuploder: false,
        rfuploder: false,
         uploadMainDocuments:[],
        uploadFinalMainDocuments:[],
    }),
    mounted() {
       
        this.fetchFormsMasterData();
        this.getFormsAndLetters();
      
    },
    computed:{
        acceptedFiles(){
      let returnValue ='application/pdf , application/msword';
      /*
      if(_.has(this.newform['type'] ,"name")){
        
        if(this.newform['type']['name'] =="Form" ){
          returnValue ='application/pdf';
        }else if(this.newform['type']['name'] =="Letter" ){
          returnValue ='application/msword';
        }
       

      }
       */
      return returnValue;
      //image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document
    }
    }
};
</script>
