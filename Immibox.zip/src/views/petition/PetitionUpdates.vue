<template>
   <div class="main-list-wrap" >
      <div>
         <template v-if="checkActivityCompleted('USCIS_RECEIVED_RFE')  && checkProperty(workFlowDetails,'manageRfeCase') =='with_in_case'">
            <refCaseUpdates :caseCurrentDetails="caseCurrentDetails" :petition="petition"
            :visastatuses="visastatuses" :workFlowDetails="workFlowDetails" @download_or_view="downloadfile" />
         </template>
        
         <section  class="petition_updates_wrap d-block w-full" v-if="checkProperty(petition ,'beneficiaryInfo' ,'maritalStatus') !=1 && checkProperty(petition ,'courierTrackingDetails' ,'length')>0">
           
            <template v-if="checkProperty(benficiaryFinalLog ,'endedOn') || checkProperty(h4UscisLogs ,'length') >0 || checkProperty(h4EadLogs ,'length') >0">
               <template v-if="checkProperty(benficiaryFinalLog ,'endedOn')">
               <div class="case_updates_sec case_updates_sec-v2">
                  <h3 class="d-flex align-center">{{checkProperty(benficiaryFinalLog, "data", 'title')}}
                     <button class="cursor primary-btn Update_USCIS_btn" @click="openUscisStatusPopup()" v-if="petition && ( ( checkCanSubmitResponse) && petition.completedActivities.indexOf('UPDATE_USCIS_RECEIPT_NUMBER') >= 0 && checkProperty(petition ,'uploadUscisDocs')==false && checkProperty(petition ,'autoUscisStatusUpdate') ==true )" >
                     <span class="viewdetails" target="_blank" >
                        <template v-if="checkProperty(petition ,'uploadUscisDocs')!=true && checkProperty(petition ,'autoUscisStatusUpdate') ==true">Upload USCIS Documents</template>
                        <template v-else>Update USCIS Status</template>
                     </span>
                  </button>
                  <button  @click="createRFE()" v-if=" petition && checkProperty(workFlowDetails ,'manageRfeCase') !='with_in_case' && [1,2,10].indexOf(checkProperty(petition ,'type')) >-1 && ( !checkProperty(petition,'rfeCaseId') &&  checkCaseCreatePermisions  && petition.completedActivities.indexOf('USCIS_RECEIVED_RFE') >-1) " class="cursor primary-btn Update_USCIS_btn">Create RFE Case</button>
                  </h3>   



               <div class="case_updates_wrap">
               <div class="case_updates_list">
                  <ul>
                  <template  >
                     <li class="cursor-pointer12" :class="{'current12':selecetedTab == trindex}"  @click="selecetedTab = trindex" :key="trindex"  >
                     <div class="case_update">
                        
                        <a class="status_btn" :class="{'btn_denied': (checkProperty(benficiaryFinalLog['data'],'rfeNotice', 'action' )=='USCIS_DENIED') ||   (benficiaryFinalLog['data']['action'] =='USCIS_RECEIVED_RFE') }" >
                           {{ checkProperty(benficiaryFinalLog, 'data', 'title' )  }} 
                        </a>

                        <h4>{{ checkProperty(benficiaryFinalLog, 'data', 'beneficiaryName') }}
                           <span style="text-transform: capitalize;">Beneficiary</span>
                        
                        </h4> 
                        <template v-if="checkProperty(benficiaryFinalLog ,'data' ,'rfeNotice' )">
                        <template v-for="( doc ,docind) in benficiaryFinalLog['data']['rfeNotice']['documents']">
                           <template v-if="docind ==0">
                              <a :title="checkProperty(benficiaryFinalLog['data'] ,'rfeNotice' ,'documentType')" class="action_btn file_btn"  :key="docind" @click="downloadfile(doc)">Copy received</a>
                           </template>
                        </template>
                        </template>

                        <!---- <a class="action_btn">{{checkProperty(petition ,'rfeNotice' ,"documentType")}} copy recieved</a>-->
                        <div class="case-date-info">
                           <label  v-if="checkProperty(benficiaryFinalLog['data'], 'rfeNotice','receivedDate' )" >Received Date <strong>{{checkProperty(benficiaryFinalLog['data'], 'rfeNotice', 'receivedDate' ) | formatDate}}</strong></label>  
                              <label v-if="checkProperty(benficiaryFinalLog['data'] ,'rfeNotice' ,'issuedDate')">Issued Date <strong>{{checkProperty(benficiaryFinalLog['data'] ,'rfeNotice' ,'issuedDate') | formatDate}}</strong></label>  
                              <label v-if="checkProperty(benficiaryFinalLog['data'] ,'rfeNotice' ,'dueDate')">Due Date <strong>{{checkProperty(benficiaryFinalLog['data'] ,'rfeNotice' ,'dueDate') | formatDate}}</strong></label>  
                              <label v-if="checkProperty(benficiaryFinalLog ,'endedOn')">Updated On <strong>{{checkProperty(benficiaryFinalLog ,'endedOn' ) | formatDate}}</strong></label>  
                             <!-- <label  v-if="checkProperty(benficiaryFinalLog['data'] ,'rfeNotice' ,'documentType')">
                              Document Type<strong> {{checkProperty(benficiaryFinalLog['data'] ,'rfeNotice' ,'documentType') }} copy received</strong>
                              </label> -->
                        </div>
                        
                        </div> 
                     </li>
                     </template>
                     
                  </ul>
               </div>

               </div>
               </div>

               </template>

                <!--- Spouse and children  H4 logs---->
               <template v-if="checkProperty(h4UscisLogs ,'length') >0">
                  <div class="case_updates_sec case_updates_sec-v2">
                     <h3 class="d-flex align-center">H4 USCIS Status </h3>   
                  
                  
                  
                  <div class="case_updates_wrap">
                  <div class="case_updates_list">
                     <ul>
                     <template v-for="(tracking , trindex) in h4UscisLogs" >
                        <li class="cursor-pointer12" :class="{'current12':selecetedTab == trindex}"  @click="selecetedTab = trindex" :key="trindex"  >
                        <div class="case_update">
                           
                           <a class="status_btn" :class="{'btn_denied': checkProperty(tracking['data'],'rfeNotice', 'action' )=='USCIS_DENIED' || checkProperty(tracking['data'],'rfeNotice', 'action' ) =='USCIS_RECEIVED_RFE'}" >
                              {{ checkProperty(tracking, 'data', 'title' )  }}
                           </a>

                           <h4 v-if="checkProperty(tracking ,'data' ,'rfeNotice' )">
                           <template v-if="checkProperty(tracking['data'], 'rfeNotice','userType') =='spouse'">
                              Spouse
                                                         
                           </template>
                           <template v-else-if="checkProperty(tracking['data'], 'rfeNotice','userType') =='children'">Children</template>
                           <template v-else>{{ checkProperty(tracking, 'data', 'beneficiaryName') }}
                              <span style="text-transform: capitalize;">Beneficiary</span>
                           </template>
                           
                           
                           </h4> 
                           <template v-if="checkProperty(tracking ,'data' ,'rfeNotice' )">
                           <template v-for="( doc ,docind) in tracking['data']['rfeNotice']['documents']">
                              <template v-if="docind ==0">
                                 <a :title="checkProperty(tracking['data'] ,'rfeNotice' ,'documentType')"  class="action_btn file_btn"  :key="docind" @click="downloadfile(doc)">Copy received</a>
                              </template>
                           </template>
                           </template>

                           <!---- <a class="action_btn">{{checkProperty(petition ,'rfeNotice' ,"documentType")}} copy recieved</a>-->
                           <div class="case-date-info">
                              <label  v-if="checkProperty(tracking['data'], 'rfeNotice','receivedDate' )" >Received Date <strong>{{checkProperty(tracking['data'], 'rfeNotice', 'receivedDate' ) | formatDate}}</strong></label>  
                              <label v-if="checkProperty(tracking['data'] ,'rfeNotice' ,'issuedDate')">Issued Date <strong>{{checkProperty(tracking['data'] ,'rfeNotice' ,'issuedDate') | formatDate}}</strong></label>  
                              <label v-if="checkProperty(tracking['data'] ,'rfeNotice' ,'dueDate')">Due Date <strong>{{checkProperty(tracking['data'] ,'rfeNotice' ,'dueDate') | formatDate}}</strong></label>  
                              <label v-if="checkProperty(tracking ,'endedOn')">Updated On <strong>{{checkProperty(tracking ,'endedOn' ) | formatDate}}</strong></label>  
                              <!-- <label  v-if="checkProperty(tracking['data'] ,'rfeNotice' ,'documentType')">
                                 Document Type <strong> {{checkProperty(tracking['data'] ,'rfeNotice' ,'documentType') }} copy received</strong>
                              </label> -->
                              
                           </div>
                           
                           </div> 
                        </li>
                        </template>
                        
                     </ul>
                  </div>
                 
                  </div>
               </div>
               
               </template>
               <template v-if="checkProperty(h4EadLogs ,'length') >0">
                  <div class="case_updates_sec case_updates_sec-v2">
                     <h3 class="d-flex align-center">H4 EAD Status </h3>   
                  
                              
                  

                  
                  <div class="case_updates_wrap">
                  <div class="case_updates_list">
                     <ul>
                     <template v-for="(tracking , trindex) in h4EadLogs" >
                        <li class="cursor-pointer12" :class="{'current12':selecetedTab == trindex}"  @click="selecetedTab = trindex" :key="trindex"  >
                        <div class="case_update">

                        
                           <a class="status_btn" :class="{'btn_denied': checkProperty(tracking['data'],'rfeNotice', 'action' )=='USCIS_DENIED' || checkProperty(tracking['data'],'rfeNotice', 'action' ) =='USCIS_RECEIVED_RFE'}" >
                              {{ checkProperty(tracking, 'data', 'title' )  }} 
                           </a>
                           <h4 v-if="checkProperty(tracking ,'data' ,'rfeNotice' )">
                           <template v-if="checkProperty(tracking['data'], 'rfeNotice','userType') =='spouse'">
                              {{checkProperty(petition['dependentsInfo'],'spouse' ,'name')}} 
                              <span style="text-transform: capitalize;">Spouse</span>
                           
                           </template>
                           <template v-else-if="checkProperty(tracking['data'], 'rfeNotice','userType') =='children'">Children</template>
                           <template v-else>{{ checkProperty(tracking, 'data', 'beneficiaryName') }}
                              <span style="text-transform: capitalize;">Beneficiary</span>
                           </template>
                           
                           
                           </h4> 
                           <template v-if="checkProperty(tracking ,'data' ,'rfeNotice' )">
                           <template v-for="( doc ,docind) in tracking['data']['rfeNotice']['documents']">
                              <template v-if="docind ==0">
                                 <a :title="checkProperty(tracking['data'] ,'rfeNotice' ,'documentType')" class="action_btn file_btn"  :key="docind" @click="downloadfile(doc)">Copy received</a>
                              </template>
                           </template>
                           </template>

                           <!---- <a class="action_btn">{{checkProperty(petition ,'rfeNotice' ,"documentType")}} copy recieved</a>-->
                           <div class="case-date-info">
                              <label  v-if="checkProperty(tracking['data'], 'rfeNotice','receivedDate' )" >Received Date <strong>{{checkProperty(tracking['data'], 'rfeNotice', 'receivedDate' ) | formatDate}}</strong></label>  
                              <label v-if="checkProperty(tracking['data'] ,'rfeNotice' ,'issuedDate')">Issued Date <strong>{{checkProperty(tracking['data'] ,'rfeNotice' ,'issuedDate') | formatDate}}</strong></label>  
                              <label v-if="checkProperty(tracking['data'] ,'rfeNotice' ,'dueDate')">Due Date <strong>{{checkProperty(tracking['data'] ,'rfeNotice' ,'dueDate') | formatDate}}</strong></label>  
                              <label v-if="checkProperty(tracking ,'endedOn')">Updated On <strong>{{checkProperty(tracking ,'endedOn' ) | formatDate}}</strong></label>  
                             <!-- <label  v-if="checkProperty(tracking['data'] ,'rfeNotice' ,'documentType')">
                                 Document Type <strong> {{checkProperty(tracking['data'] ,'rfeNotice' ,'documentType') }} copy received</strong>
                              </label> -->
                           </div>
                           
                           </div> 
                        </li>
                        </template>
                        
                     </ul>
                  </div>
                  
                  </div>
                 </div>
               
               </template>
           </template>
           <template v-else>
            
            <template v-if="checkProperty(petition ,'rfeNotice' ,'documents')">
               
               <div class="case_updates_sec case_updates_sec-v2"  v-if="checkProperty(petition['rfeNotice'] ,'documents' ,'length')>0" >
                <h3 class="case-heading d-flex align-center">{{checkProperty(petition ,'statusDetails' ,'name')}}        
                  <button class="cursor primary-btn Update_USCIS_btn" @click="openUscisStatusPopup()" v-if="petition && ( ( checkCanSubmitResponse) && petition.completedActivities.indexOf('UPDATE_USCIS_RECEIPT_NUMBER') >= 0  && checkProperty(petition ,'uploadUscisDocs')==false && checkProperty(petition ,'autoUscisStatusUpdate') ==true )" >
                     <span class="viewdetails" target="_blank" >
                        <template v-if="checkProperty(petition ,'uploadUscisDocs')!=true && checkProperty(petition ,'autoUscisStatusUpdate') ==true">Upload USCIS Documents</template>
                        <template v-else>Update USCIS Status</template>
                     </span>
                  </button>
                  <button  @click="createRFE()" v-if="petition && checkProperty(workFlowDetails ,'manageRfeCase') !='with_in_case' &&  [1,2,10].indexOf(checkProperty(petition ,'type')) >-1 && ( !checkProperty(petition,'rfeCaseId') &&  checkCaseCreatePermisions  && petition.completedActivities.indexOf('USCIS_RECEIVED_RFE') >-1) " class="cursor primary-btn Update_USCIS_btn">Create RFE Case</button>
                 
               </h3>
               <div class="case_updates_wrap">
                  <div class="case_updates_list">
                  <ul>
                  <template v-for="( statusItem , isndex) in petition['rfeNotice']['documents']">
                     <li :key="isndex"  class="cursor-pointer12" :class="{'current12':statusTab == isndex}"  @click="statusTab = isndex" >
                        <div class="case_update">
                       
                        <div class="case_action_btns">
                           <a :class="{'status_btn ':checkProperty(petition,'statusDetails','id')==22,'status_btn btn_denied ':checkProperty(petition,'statusDetails','id')!=22}">{{checkProperty(petition ,'statusDetails' ,'name')}}</a>
                           <a class="action_btn"  @click="downloadfile(statusItem)" v-tooltip.top-center="checkProperty(petition ,'rfeNotice' ,'documentType') + ' copy'">{{checkProperty(petition ,'rfeNotice' ,'documentType')}} copy</a>
                        </div>
                        <h4>
                           
                        {{checkProperty(statusItem,'userName')}}
                        
                       
                        <span style="text-transform: capitalize;" v-if="checkProperty(statusItem,'userType')">{{checkProperty(statusItem,'userType')}} </span>
                        
                        
                         </h4> 
                        
                        <div class="case-date-info">
                           <label v-if="checkProperty(petition ,'rfeNotice' ,'receivedDate')">Received Date <strong>{{checkProperty(petition ,'rfeNotice' ,'receivedDate') | formatDate}}</strong></label>  
                           <label v-if="checkProperty(petition ,'rfeNotice' ,'issuedDate')">Issued Date <strong>{{checkProperty(petition ,'rfeNotice' ,'issuedDate') | formatDate}}</strong></label>  
                           <label v-if="checkProperty(petition ,'rfeNotice' ,'dueDate')">Due Date <strong>{{checkProperty(petition ,'rfeNotice' ,'dueDate') | formatDate}}</strong></label>  
                        </div>
                          
                     </div> 
                     </li>
                     </template>
                     <!-- <li v-if="checkProperty(petition ,'rfeNotice' ,'issuedDate')">
                        <p>Issued Date<br/><a >{{checkProperty(petition ,'rfeNotice' ,'issuedDate') | formatDate}}</a></p>
                     </li>
                     <li v-if="checkProperty(petition ,'rfeNotice' ,'dueDate')">
                        <p>Due Date<br/><a >{{checkProperty(petition ,'rfeNotice' ,'dueDate') | formatDate}}</a></p>
                     </li> -->
                     
                  </ul>
                  </div>
                  <div class="case_updates_details">
                    
                     <template v-for="( statusItem , isndex) in petition['rfeNotice']['documents']">
                     <div class="case-updates-list" :key="isndex" v-if="statusTab ==isndex"  >
                        <div class="left">  
                           <ul>
                              <li class="d-flex align-items-center">  
                                                       
                                 <a class="status_btn" :class="{'status_btn ':checkProperty(petition,'statusDetails','id')==22,'status_btn btn_denied ':checkProperty(petition,'statusDetails','id')!=22}">{{checkProperty(petition ,'statusDetails' ,'name')}}</a>      
                                                    
                              </li> 
                              
                              <li v-if="checkProperty(petition ,'rfeNotice' ,'issuedDate')">
                                 <p>Issued Date<br/><a >{{checkProperty(petition ,'rfeNotice' ,'issuedDate') | formatDate}}</a></p>
                              </li>
                              <li v-if="checkProperty(petition ,'rfeNotice' ,'dueDate')">
                                 <p>Due Date<br/><a >{{checkProperty(petition ,'rfeNotice' ,'dueDate') | formatDate}}</a></p>
                              </li>
                           </ul>
                        </div>
                        <div class="right">
                           <ul>
                              
                                    <li   @click="downloadfile(statusItem)">
                                    <a href="#"><figure><img src="@/assets/images/download-white.svg"></figure></a>
                                    </li>
                           </ul>
                        </div>
                     </div>
                     </template>
                     
                  </div>
               </div>
               </div>
            </template>
            <template  v-else-if="checkProperty(petition ,'uploadUscisDocs')!=true && checkProperty(petition ,'autoUscisStatusUpdate') ==true">
               <div class="case_updates_sec case_updates_sec-v2"  >
                <h3 class="case-heading d-flex align-center">{{checkProperty(petition ,'statusDetails' ,'name')}}           
                  <button class="cursor primary-btn Update_USCIS_btn" @click="openUscisStatusPopup()" v-if="petition && ( ( checkCanSubmitResponse) && petition.completedActivities.indexOf('UPDATE_USCIS_RECEIPT_NUMBER') >= 0  && checkProperty(petition ,'uploadUscisDocs')==false && checkProperty(petition ,'autoUscisStatusUpdate') ==true )" >
                     <span class="viewdetails" target="_blank" >
                        <template v-if="checkProperty(petition ,'uploadUscisDocs')!=true && checkProperty(petition ,'autoUscisStatusUpdate') ==true">Upload USCIS Documents</template>
                        <template v-else>Update USCIS Status</template>
                     </span>
                  </button>
               </h3>
               <div class="case_updates_wrap">
                 <div class="case_updates_list">
                   <ul>
                   <template  >
                     <li class="cursor-pointer12"  >
                       <div class="case_update">
                        <a class="status_btn">{{checkProperty(petition ,'statusDetails' ,'name')}}  </a>
                         <div class="case-date-info">
                            <label  v-if="checkProperty(petition ,'rfeNotice' ,'receivedDate' )" >Received Date <strong>{{checkProperty(petition ,'rfeNotice','receivedDate' ) | formatDate}}</strong></label>  
                         </div>
                         
                        </div> 
                     </li>
                     </template>
                     
                   </ul>
                 </div>
                 <div class="case_updates_details">
                     <template v-for="(tracking , trindex) in petition['courierTrackingDetails']" >
                    
                     <div  class="case-updates-list" :key="trindex" v-if="selecetedTab==trindex && checkProperty(tracking ,'category')!='COURIER_TRACKING'">
                      
                         <div class="left">
                           <ul>
                               <li class="d-flex align-items-center">                          
                                 <a class="status_btn">Receipt Received</a>    
                                   
                                                     
                               </li> 
                               <li v-if="checkProperty(tracking ,'receiptNumber')">
                               
                                 <p>Receipt <span> {{ checkProperty(tracking ,'receiptNumber')}}</span></p>
                               </li>
                               <li v-if="checkProperty(tracking ,'receiptName')" >
                                 <p>USCIS Receipt<span> {{ checkProperty(tracking ,'receiptName')}}</span></p>
                                 
                               </li>
                           </ul>
                         </div>
                         <div class="right">
                           
                           <ul >

                              
                      
                             <template v-if="checkProperty(tracking ,'documents' ,'length')>0"> 
                                 <template v-for="( doc ,docind) in tracking['documents']">
                                 <template v-if="docind ==0">
                                    <!-- <li :key="docind"><a  target="_blank" :href="getTrackingUrl" class="viewdetails"> View Details</a></li>-->
                                       <li :key="docind"  @click="downloadfile(doc)">
                                       <a href="#"><figure><img src="@/assets/images/download-white.svg"></figure></a>
                                       </li>
                                 </template>
                                 </template>
                             </template>
                        </ul>
                         </div>
                     </div>
                     </template>
                     
                 </div>
               </div>
            </div>

            </template>
         </template>

            
            <div class="case_updates_sec case_updates_sec-v2" v-if=" petition.completedActivities.indexOf('UPDATE_USCIS_RECEIPT_NUMBER')>-1 && checkProperty(petition ,'courierTrackingDetails' ,'length')>0 ">
               <h3 class="d-flex align-center">Receipt Received        
                  <button class="cursor primary-btn Update_USCIS_btn" @click="openUscisStatusPopup()" v-if="false&&petition && ( ( checkCanSubmitResponse) && petition.completedActivities.indexOf('UPDATE_USCIS_RECEIPT_NUMBER') >= 0 && checkProperty(petition ,'uploadUscisDocs')==false && checkProperty(petition ,'autoUscisStatusUpdate') ==true)" >
                     <span class="viewdetails" target="_blank" >
                        <template v-if="checkProperty(petition ,'uploadUscisDocs')!=true && checkProperty(petition ,'autoUscisStatusUpdate') ==true">Upload USCIS Documents</template>
                        <template v-else>Update USCIS Status</template>
                     </span>
                  </button>
               </h3>   
                
                           
               

               
               <div class="case_updates_wrap">
                 <div class="case_updates_list">
                   <ul>
                  <template v-for="(tracking , trindex) in petition['courierTrackingDetails']" >
                     <template v-if="['UPDATE_USCIS_RECEIPT_NUMBER'].indexOf(checkProperty(tracking ,'category'))>-1">
                        <li class="cursor-pointer12" :class="{'current12':selecetedTab == trindex}"  @click="selecetedTab = trindex" :key="trindex" v-if="checkProperty(tracking ,'category')!='COURIER_TRACKING'" >
                        <div class="case_update">
                           <a class="status_btn">Receipt Received </a>
                           <h4>
                           <template v-if="checkProperty(tracking ,'userName' )">{{checkProperty(tracking ,'userName' )}}</template>
                           <!-- <template v-else-if="checkProperty(tracking ,'userType' )">{{checkProperty(tracking ,'userType' )}}</template>  -->
                           <template><span style="text-transform: capitalize;">{{checkProperty(tracking ,'userType' )}}</span></template> 
                           </h4> 
                           <template v-for="( doc ,docind) in tracking['documents']">
                              <template v-if="docind ==0">
                                 <a class="action_btn file_btn"  :key="docind" @click="downloadfile(doc)">Copy received</a>
                              </template>
                           </template>

                           <!---- <a class="action_btn">{{checkProperty(petition ,'rfeNotice' ,"documentType")}} copy recieved</a>-->
                           <div class="case-date-info">
                              <label  v-if="checkProperty(tracking ,'receivedDate' )" >Received Date <strong>{{checkProperty(tracking ,'receivedDate' ) | formatDate}}</strong></label>  
                              <label class="cursor" :title="checkProperty(tracking ,'receiptName' )" v-if="checkProperty(tracking ,'receiptName' )" >USCIS Receipt<strong>{{checkProperty(tracking ,'receiptName' ) }}</strong></label>  
                              <label class="cursor" :title="checkProperty(tracking ,'receiptNumber' )" v-if="checkProperty(tracking ,'receiptNumber' )" >Receipt  <strong>{{checkProperty(tracking ,'receiptNumber' ) }}</strong></label>  
                           </div>
                           
                           </div> 
                        </li>
                     </template>
                  </template>
                     
                   </ul>
                 </div>
                 <div class="case_updates_details">
                     <template v-for="(tracking , trindex) in petition['courierTrackingDetails']" >
                    
                     <div  class="case-updates-list" :key="trindex" v-if="selecetedTab==trindex && checkProperty(tracking ,'category')!='COURIER_TRACKING'">
                      
                         <div class="left">
                           <ul>
                               <li class="d-flex align-items-center">                          
                                 <a class="status_btn">Receipt Received </a>    
                                   
                                                     
                               </li> 
                               <li v-if="checkProperty(tracking ,'receiptNumber')">
                               
                                 <p>Receipt <span> {{ checkProperty(tracking ,'receiptNumber')}}</span></p>
                               </li>
                               <li v-if="checkProperty(tracking ,'receiptName')" >
                                 <p>USCIS Receipt<span> {{ checkProperty(tracking ,'receiptName')}}</span></p>
                                 
                               </li>
                           </ul>
                         </div>
                         <div class="right">
                           
                           <ul >

                              
                      
                             <template v-if="checkProperty(tracking ,'documents' ,'length')>0"> 
                                 <template v-for="( doc ,docind) in tracking['documents']">
                                 <template v-if="docind ==0">
                                    <!-- <li :key="docind"><a  target="_blank" :href="getTrackingUrl" class="viewdetails"> View Details</a></li>-->
                                       <li :key="docind"  @click="downloadfile(doc)">
                                       <a href="#"><figure><img src="@/assets/images/download-white.svg"></figure></a>
                                       </li>
                                 </template>
                                 </template>
                             </template>
                        </ul>
                         </div>
                     </div>
                     </template>
                     
                 </div>
               </div>
             </div>
         </section>

          <section >
          <template v-if="checkProperty(petition ,'beneficiaryInfo' ,'maritalStatus') ==1">
            
            <div class="case-approved-detailes case-approved-detailes-v2"  v-if="checkProperty(petition ,'statusDetails') && petition.statusDetails.id > 13" >
               <!----<h2 class="case-heading">{{checkProperty(petition ,'statusDetails' ,'name')}}</h2>-->

               <h3 class="case-heading d-flex align-center">{{checkProperty(petition ,'statusDetails' ,'name')}}      
                  <button class="cursor primary-btn Update_USCIS_btn" @click="openUscisStatusPopup()" v-if="petition && ( ( checkCanSubmitResponse) && petition.completedActivities.indexOf('UPDATE_USCIS_RECEIPT_NUMBER') >= 0 && checkProperty(petition ,'uploadUscisDocs')==false && checkProperty(petition ,'autoUscisStatusUpdate') ==true )" >
                     <span class="viewdetails" target="_blank" >
                        <template v-if="checkProperty(petition ,'uploadUscisDocs')!=true && checkProperty(petition ,'autoUscisStatusUpdate') ==true">Upload USCIS Documents</template>
                        <template v-else>Update USCIS Status</template>
                     </span>
                  </button>
                  <button  @click="createRFE()" v-if="petition && checkProperty(workFlowDetails ,'manageRfeCase') !='with_in_case' && [1,2,10].indexOf(checkProperty(petition ,'type')) >-1 && ( !checkProperty(petition,'rfeCaseId') &&  checkCaseCreatePermisions  && petition.completedActivities.indexOf('USCIS_RECEIVED_RFE') >-1) " class="cursor primary-btn Update_USCIS_btn">Create RFE Case</button>
                 
               </h3>
               <div class="case-approved-body">
                  <div class="left">
                    
                     <ul class="">
                        <li class="success" :class="{'success ':checkProperty(petition,'statusDetails','id')==22,'case-status-error':checkProperty(petition,'statusDetails','id')!=22}">{{checkProperty(petition ,'statusDetails' ,'name')}}</li>
                        <li>
                           <p>Updated Date <span> {{petition.updatedOn | formatDateTime}}</span></p>
                        </li>
                        <li v-if="checkProperty(petition ,'rfeNotice' ,'receivedDate')">
                           <p>Received Date <span> {{checkProperty(petition ,'rfeNotice' ,'receivedDate') | formatDate}}</span></p>
                        </li>
                        <li  v-if="checkProperty(petition ,'rfeNotice' ,'issuedDate')">
                           <p>Issued Date <span> {{checkProperty(petition ,'rfeNotice' ,'issuedDate') | formatDate}}</span></p>
                        </li>
                        <li  v-if="checkProperty(petition ,'rfeNotice' ,'dueDate')">
                           <p>Due Date <span> {{checkProperty(petition ,'rfeNotice' ,'dueDate') | formatDate}}</span></p>
                        </li>
                        <li  v-if="checkProperty(petition ,'rfeNotice' ,'documentType')">
                           <p>Document Type <span> {{checkProperty(petition ,'rfeNotice' ,'documentType') }} copy received</span></p>
                        </li>
                        
                     
                     </ul>
                  </div>
                  <div class="right">
                     <ul v-if="checkProperty(petition ,'rfeNotice' ,'documents')">
                       <!-- <li><a href="#" @click="downloadfile(petition.rfeNotice.documents[0])"> View Details</a></li>-->
                        <li @click="downloadfile(petition.rfeNotice.documents[0])">
                           <figure class="view-detailes_cnt"><img src="@/assets/images/download-white.svg"></figure>
                        </li>
                     </ul>
                  </div>
               </div>
        
            </div>
            <div class="case-approved-detailes case-approved-detailes-v2"  v-if="checkProperty(petition ,'courierTrackingDetails' ,'length') > 0 && petition.completedActivities.indexOf('UPDATE_USCIS_RECEIPT_NUMBER')>-1">
               <h3 class="d-flex align-center">Receipt Received              
                  <button class="cursor primary-btn Update_USCIS_btn" @click="openUscisStatusPopup()" v-if=" false && petition && ( ( checkCanSubmitResponse) && petition.completedActivities.indexOf('UPDATE_USCIS_RECEIPT_NUMBER') >= 0 && checkProperty(petition ,'uploadUscisDocs')==false && checkProperty(petition ,'autoUscisStatusUpdate') ==true)" >
                     <span class="viewdetails" target="_blank" >
                        <template v-if="checkProperty(petition ,'uploadUscisDocs')!=true && checkProperty(petition ,'autoUscisStatusUpdate') ==true">Upload USCIS Documents</template>
                        <template v-else>Update USCIS Status</template>
                     </span>
                  </button>
               </h3> 

                            <template  v-for="(tracking ,ind ) in petition.courierTrackingDetails" >

               <div class="case-approved-body" :key="ind" v-if="tracking.category == 'UPDATE_USCIS_RECEIPT_NUMBER'">
                  <div class="left">
                     <ul>
                        <li class="success">Received</li>
                        <li>
                           <p>Updated Date <span> {{tracking.createdOn | formatDateTime}}</span></p>
                        </li>
                        <li v-if="checkProperty(tracking ,'receivedDate')">
                           <p>Received Date <span> {{tracking.receivedDate | formatDate}}</span></p>
                        </li>

                        
                        <li v-if="checkProperty(tracking ,'receiptName')" >
                           <p>USCIS Receipt<span> {{ checkProperty(tracking ,'receiptName')}}</span></p>
                           
                        </li>
                        <li v-if="checkProperty(tracking ,'receiptNumber')">
                           
                           <p>Receipt <span> {{ checkProperty(tracking ,'receiptNumber')}}</span></p>
                        </li>
                        
                       
                       
                     </ul>
                  </div>
                  <div class="right">
                   
                     <ul >

                        

                        <template v-if="checkProperty(tracking ,'documents','length')>0">
                        <li v-if="false"><a href="#" @click="downloadfile(tracking.documents[0])" class="viewdetails"> View Details</a></li>
                        <li>
                           <figure class="view-detailes_cnt" @click="downloadfile(tracking.documents[0])"><img src="@/assets/images/download-white.svg"></figure>
                        </li>
                     </template>
                     </ul>
                  </div>
               </div>

                            </template>
            
            </div>
          </template>
       

             <div class="case-approved-detailes case-approved-detailes-v2" v-if="checkProperty(petition ,'courierTrackingDetails') && checkProperty(petition ,'courierTrackingDetails' ,'length')>0 && checkSubmitToUSCIS">
               <h2 class="case-heading">Docket Submitted to USCIS</h2>
             <template  v-for="(tracking ,ind ) in petition.courierTrackingDetails" >

                <div  :key="ind" v-if="tracking.category == 'COURIER_TRACKING' && checkProperty(tracking,'trackingDataLogs' ,'length' )> 0 && checkProperty(tracking.trackingDataLogs[0] ,'data') && checkProperty(tracking.trackingDataLogs[0] ,'data' ,'origin_info') " >

                  <div class="case-approved-body" :key="aind" v-for="(atracking ,aind ) in tracking.trackingDataLogs[0].data.origin_info.trackinfo">
                  <div class="left">
                     <ul>
                        <li  class="primary" v-if="atracking.StatusDescription"> {{atracking.StatusDescription}}</li>
                        <li v-if="atracking.Details && atracking.Date">
                           <p>{{atracking.Details}} <span> {{atracking.Date | formatDateTime }}</span></p>
                        </li>
                          <li  class="primary" v-if="atracking.tracking_detail"> {{atracking.tracking_detail}}</li>
                        <li v-if="atracking.location && atracking.checkpoint_date">
                           <p>{{atracking.location}} <span> {{atracking.checkpoint_date | formatDateTime }}</span></p>
                        </li>
                     </ul>
                  </div>
                  <div class="right">
                     <ul>
                        <li ><a class="viewdetails" target="_blank" :href="checkProperty(tracking ,'trackingUrl' )"> View Details</a></li>
                      
                     </ul>
                  </div>
                   </div>
               </div>

               <div class="case-approved-body" :key="ind" v-if="tracking.category == 'COURIER_TRACKING'" >
                  <div class="left">
                     <ul>
                        <li  class="primary">Submitted</li>
                        <li>
                           <p>Created date
                              
                           <span> {{tracking.createdOn | formatDateTime }}</span></p>
                        </li>
                        <li v-if="checkProperty(tracking ,'sentDate')">
                           <p>Sent Date
                              <span>{{checkProperty(tracking ,'sentDate') | formatDate}}</span></p>
                        </li>
                        
                        <li>
                           <p>Tracking Number
                              <a target="_blank" :href="checkProperty(tracking ,'trackingUrl' )" > <span>{{checkProperty(tracking ,'trackingId')}}</span></a> 
                           </p>

                        </li>
                     </ul>
                  </div>
                  <div class="right">
                     <ul>
                        <li ><a class="viewdetails" target="_blank" :href="checkProperty(tracking ,'trackingUrl' )"> View Details</a></li>
                      
                     </ul>
                  </div>
               </div>

             </template>


            </div>
         </section>
        

   


      </div>
      <actionsPopup v-if="petition" @updatepetition="updatePet" :workFlowDetails="workFlowDetails" ref="actionAllPopups" :petitionDetails="petition" />
   
   </div>
</template>
<script>
import refCaseUpdates from "@/views/petition/rfePetitionUpdatesForm.vue";
import actionsPopup from "@/views/common/actionsPopup.vue";
/*this.$refs["actionsPopup"].openuscisresponse(); */

import moment from "moment";
import * as _ from "lodash";
   export default {
    computed:{
      checkActivityCompleted(){
      return (code='')=>{
       
        if( _.has(this.petition ,"completedActivities") && this.petition['completedActivities'].indexOf(code) >-1){
          return true;
        }else{
          return false;
        }
        

      }
    },
      checkCanSubmitResponse(){
            let submitUSCISResponseList = [];
            let adminsList =[];
            if(this.workFlowDetails && _.has(this.workFlowDetails ,'config')){

            
            let submitUSCISResponseactiVityList = _.find(this.workFlowDetails.config , {"code":'UPDATE_USCIS_RESPONSE'});
            if(submitUSCISResponseactiVityList && submitUSCISResponseactiVityList.editors){
             submitUSCISResponseList = _.map(submitUSCISResponseactiVityList.editors, 'roleId');
            }

            let adminsactiVityList = _.find(this.workFlowDetails.config , {"code":'MANAGER_LIST'});
            if(adminsactiVityList && adminsactiVityList.editors){
               adminsList = _.map(adminsactiVityList.editors, 'roleId');
            }
         }

         return submitUSCISResponseList.indexOf(this.getUserRoleId) > -1 || adminsList.indexOf(this.getUserRoleId) > -1;


      },
      getTrackingNumber(){
         let courierTracking = _.find(this.petition['courierTrackingDetails'] ,{"category":'COURIER_TRACKING'});
         if(courierTracking){
          return this.checkProperty(courierTracking ,'trackingId' );

         }else{
          return ''
         } 
       
      },
      checkSubmitToUSCIS(){
         let returVal =false;
         let isSUbmitToDol = _.find(this.petition['courierTrackingDetails'] ,{"category":'COURIER_TRACKING'});
         if(isSUbmitToDol){
          return true;
         }
        return returVal;
      },
       getTrackingUrl(){
        let courierTracking = _.find(this.petition['courierTrackingDetails'] ,{"category":'COURIER_TRACKING'});
         if(courierTracking){
          return this.checkProperty(courierTracking ,'trackingUrl' );

         }else{
          return ''
         }
      },
    },
     data: () => ({
      benficiaryFinalLog:null,
      h4UscisLogs:[],
      h4EadLogs:[],
      selecetedTab:1,
      statusTab:0,
      petitionhistory: [],
   
    }),
     props: {
      caseCurrentDetails:{
         type: Array,
          default: []

      },
       petition: {
        // type: Object,
         default: null
       },
       visastatuses: {
         type: Array,
         default: null
       },
       workFlowDetails:{
          type: Object,
          default: null
        }
     },
     components: {
      refCaseUpdates,
      actionsPopup
        
     },
     methods: { 
      createRFE(){
        
         this.$emit('createRFE');
      },
      getRFEAggingLogs(){
         let self =this;
         let rfeCaseAodes = [
            'RFE_PREPARE_RESPONSE_DOCS','RFE_REVIEW_RESPONSE_DOCS',
            'REF_CASE_APPROVED','RFE_REQUEST_PETITIONER_SIGN',
            'RFE_SUBMIT_TO_USCIS','RFE_UPDATE_USCIS_RESPONSE'
         ];
         let tempRfeCaseAggingList = [];
         this.rfeCaseAggingList = [];
         if(this.caseCurrentDetails){
            _.forEach(this.caseCurrentDetails,(item)=>{
               if(rfeCaseAodes.indexOf(item['action']) >-1){
                  if(_.has(item ,'endedOn') && item['endedOn'] && !this.checkProperty(item ,'ignore')){
                     if(_.has(item ,'endedOn') && item['endedOn']){
                        item['endedOn'] = moment(item['endedOn'])
                     }
                     if(_.has(item ,'startedOn') && item['startedOn']){
                        item['startedOn'] = moment(item['startedOn'])
                     }
                     tempRfeCaseAggingList.push(item)
                  }
               }
            })
            if(tempRfeCaseAggingList && self.checkProperty(tempRfeCaseAggingList, 'length')>0){
               tempRfeCaseAggingList  = _.orderBy(tempRfeCaseAggingList ,['endedOn'] ,['desc'] );
               this.rfeCaseAggingList = tempRfeCaseAggingList;
            }
         }
      },
     
      getupdateUscisAggingLogs(userCategory='h4'){
         let self =this;
         if(userCategory =='h4'){
            self.h4UscisLogs =[];
         }else if(userCategory =='h4ead'){
            self.h4EadLogs =[];
         }
        
         this.benficiaryFinalLog =null;
         let tempBenficiaryFinalLog = [];
        
         _.forEach(this.caseCurrentDetails,(item)=>{
               if(['UPDATE_USCIS_RESPONSE' ].indexOf(item['action']) >-1){
//beneficairy h4_children , h4_spouse



                  if(_.has(item ,'endedOn') && item['endedOn'] && !this.checkProperty(item ,'ignore')){


                     
                   
                     if(_.has(item ,'endedOn') && item['endedOn']){
                        item['endedOn'] = moment(item['endedOn'])
   
                     }
                     if(_.has(item ,'startedOn') && item['startedOn']){
                        item['startedOn'] = moment(item['startedOn'])
   

                     }
                     if(self.checkProperty( item,'data' ,'rfeNotice')){
                        if(userCategory== 'h4'){
                        
                        if(self.checkProperty( item['data'],'uscisUpdateCategory') =='h4'){
                           // "userCatergoryCode": "h4_children",
                           let ischildrenExists = _.find(self.h4UscisLogs, (obj)=>{ return self.checkProperty(obj,'data', "userCatergoryCode" ) =="h4_children" });
                           let h4RFEchildDocs = null;
                           let h4RFEspouseDocs = null;
                        
                           if(self.petition && self.checkProperty(self.petition,'h4RfeNotices') && self.checkProperty(self.petition,'h4RfeNotices', 'length')>0){
                              h4RFEchildDocs = _.find(self.petition['h4RfeNotices'], (obj)=>{ return self.checkProperty(obj,'userType') =="children" });
                              h4RFEspouseDocs =  _.find(self.petition['h4RfeNotices'], (obj)=>{ return self.checkProperty(obj,'userType') =="spouse" });
                           }
                           if(self.checkProperty(item,'data', "userCatergoryCode" ) =="h4_children"){
                              if( !ischildrenExists){
                                 if(_.has(item,'data') && _.has(item['data'],'rfeNotice') && _.has(item['data']['rfeNotice'],'documents')
                                 && this.checkProperty(item['data']['rfeNotice'],'documents') && this.checkProperty(item['data']['rfeNotice'],'documents', 'length')>0){
                                    self.h4UscisLogs.push(item);
                                 }else if(false && h4RFEchildDocs && self.checkProperty(h4RFEchildDocs,'documents') && self.checkProperty(h4RFEchildDocs,'documents', 'length')>0){
                                    item['data']['rfeNotice']['documents'] = h4RFEchildDocs['documents'];
                                    self.h4UscisLogs.push(item);
                                 }else{
                                    self.h4UscisLogs.push(item);
                                 }
                              }
                           }else{
                              if(_.has(item,'data') && _.has(item['data'],'rfeNotice') && _.has(item['data']['rfeNotice'],'documents')
                              && this.checkProperty(item['data']['rfeNotice'],'documents') && this.checkProperty(item['data']['rfeNotice'],'documents', 'length')>0){
                                 self.h4UscisLogs.push(item);
                              }else if(false && h4RFEspouseDocs && self.checkProperty(h4RFEspouseDocs,'documents') && self.checkProperty(h4RFEspouseDocs,'documents', 'length')>0){
                                 item['data']['rfeNotice']['documents'] = h4RFEspouseDocs['documents'];
                                 self.h4UscisLogs.push(item);
                              }else{
                                 self.h4UscisLogs.push(item);
                              }
                              //self.h4UscisLogs.push(item);
                           } 
                        }
                     }else if(userCategory== 'h4ead'){
                        let h4EADRFEspouseDocs = null;
                        if(self.petition && self.checkProperty(self.petition,'h4EadRfeNotices') && self.checkProperty(self.petition,'h4EadRfeNotices', 'length')>0){
                              h4EADRFEspouseDocs =  _.find(self.petition['h4EadRfeNotices'], (obj)=>{ return self.checkProperty(obj,'userType') =="spouse" });
                           }
                        if(self.checkProperty( item['data'],'uscisUpdateCategory') =='h4ead'){
                           if(_.has(item,'data') && _.has(item['data'],'rfeNotice') && _.has(item['data']['rfeNotice'],'documents')
                           && this.checkProperty(item['data']['rfeNotice'],'documents') && this.checkProperty(item['data']['rfeNotice'],'documents', 'length')>0){
                              self.h4EadLogs.push(item);
                           }else if(false && h4EADRFEspouseDocs && self.checkProperty(h4EADRFEspouseDocs,'documents') && self.checkProperty(h4EADRFEspouseDocs,'documents', 'length')>0){
                              item['data']['rfeNotice']['documents'] = h4EADRFEspouseDocs['documents'];
                              self.h4EadLogs.push(item);
                           }else{
                              self.h4EadLogs.push(item);
                           }
                        //self.h4EadLogs.push(item);
                        }
                     }
                     //tempBenficiaryFinalLog   
                     if( self.checkProperty(item, 'data','userCatergoryCode') =='beneficairy'){
                        let tempRfeDocs = null;
                        if(self.petition && self.checkProperty(self.petition,'rfeNotice') && self.checkProperty(self.petition['rfeNotice'], 'documents') && self.checkProperty(self.petition['rfeNotice'], 'documents', 'length')>0){
                           tempRfeDocs =  self.checkProperty(self.petition['rfeNotice'], 'documents')
                        }
                        if(_.has(item,'data') && _.has(item['data'],'rfeNotice') && _.has(item['data']['rfeNotice'],'documents')
                        && this.checkProperty(item['data']['rfeNotice'],'documents') && this.checkProperty(item['data']['rfeNotice'],'documents', 'length')>0){
                           tempBenficiaryFinalLog.push(item);
                        }else if(tempRfeDocs  && self.checkProperty(tempRfeDocs, 'length')>0 && false){
                           item['data']['rfeNotice']['documents'] = tempRfeDocs;
                           tempBenficiaryFinalLog.push(item);
                        }else{
                           tempBenficiaryFinalLog.push(item);
                        }
                        //tempBenficiaryFinalLog.push(item);
                     }
                     }


                    
                     
                    
                     //self.h4UscisLogs  = _.orderBy(self.h4UscisLogs ,['endedOn'] ,['desc'] );
                  }
                  
                  
               }
          } );
         // checkProperty(tracking['data'], 'rfeNotice','userType')
          self.h4UscisLogs  = _.orderBy(self.h4UscisLogs ,["data.rfeNotice.userType",'endedOn' ] ,["desc",'desc'] );
          self.h4EadLogs  = _.orderBy(self.h4EadLogs, ["data.rfeNotice.userType",'endedOn' ] ,["desc",'desc'] );
          if(tempBenficiaryFinalLog.length>0){
            tempBenficiaryFinalLog  = _.orderBy(tempBenficiaryFinalLog ,['endedOn'] ,['desc'] );
            self.benficiaryFinalLog = tempBenficiaryFinalLog[0];
          }
          

      },
      updatePet(){
            this.$emit("updatepetition", "Case Details");
         },
         openUscisStatusPopup(){
            this.$refs["actionAllPopups"].openuscisresponse();
         },
         downloadfile(value) {
           this.$emit('download_or_view' ,value);
         // value.url = value.url.replace(this.$globalgonfig._S3URL,"");
         // value.url = value.url.replace(this.$globalgonfig._S3URLAWS,"");
         // let postdata = { keyName: value.url };
         // this.$store.dispatch("getSignedUrl", postdata).then(response => {
         //   window.open(response.data.result.data, "_blank");
         // });
       }
     },
     mounted() { 
      this.statusTab =0;
      
         this.getupdateUscisAggingLogs('h4ead');
         this.getupdateUscisAggingLogs('h4');
       setTimeout(()=>{
         this.getupdateUscisAggingLogs('h4ead');
         this.getupdateUscisAggingLogs('h4');
       },200)
     }
   };
</script>