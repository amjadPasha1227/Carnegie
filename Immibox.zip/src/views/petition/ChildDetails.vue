<template>
  <div>
   
    <div v-for="(child, index) in petition.dependentsInfo.childrens" :key="index">
      <div class="main-list-wrap" v-if="checkProperty(child ,'firstName') || checkProperty(child ,'name')" >
        <div class="vx-row m-0 main-list-panel" 
         v-if="checkProperty(child ,'name') || checkProperty(child ,'dateOfBirth')"
        >
          <div class="vx-col md:w-1/3 w-full p-0" >
            <div class="main-list">
              <p>
                Name of Child
                <span v-if="checkProperty(child ,'name')">{{checkProperty(child ,'name')}}</span>
                <span v-else>{{checkProperty(child ,'firstName')}} {{checkProperty(child ,'middleName')}} {{checkProperty(child ,'lastName')}}</span>
               
              </p>
            </div>
          </div>
          <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(child ,'email')">
            <div class="main-list">
              <p>
                Email
                <span>{{child.email}}</span>
              </p>
            </div>
          </div>
          <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(child ,'gender')"   >
            <div class="main-list">
              <p>
                Gender
                <span>{{checkProperty(child ,'gender')}}</span>
              </p>
            </div>
          </div>
          <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(child ,'maidenName')"   >
            <div class="main-list">
              <p>
                Maiden Name
                <span>{{checkProperty(child ,'maidenName')}}</span>
              </p>
            </div>
          </div>
          
          <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(child ,'phoneNumber')"   >
        <div class="main-list">
          <p>
            Phone Number
            <span>
            <template v-if="checkProperty(child ,'phoneCountryCode' ,'countryCallingCode')">{{checkProperty(child ,'phoneCountryCode' ,'countryCallingCode')+"&nbsp;"}}</template>
            {{child.phoneNumber}}</span>
          </p>
        </div>
      </div>
          <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(child ,'dateOfBirth')">
            <div class="main-list">
              <p>
                Date of Birth
                <span>{{child.dateOfBirth | formatDate}}</span>
              </p>
            </div>
          </div>
          <div class="vx-col md:w-1/3 w-full p-0" 
                      v-if="checkProperty(child ,'countryOfBirthDetails' ,'name')" >
            <div class="main-list">
              <p>
                Country of Birth
                <span> {{checkProperty(child ,'countryOfBirthDetails' ,'name')}} </span>
              </p>
            </div>
          </div>
          <div class="vx-col md:w-1/3 w-full p-0" 
                      v-if="checkProperty(child ,'provinceOfBirthDetails' ,'name')" >
            <div class="main-list">
              <p>
                Province of Birth
                <span> {{checkProperty(child ,'provinceOfBirthDetails' ,'name')}} </span>
              </p>
            </div>
          </div>
          <div class="vx-col md:w-1/3 w-full p-0" 
                      v-if="checkProperty(child ,'locationOfBirth')" >
            <div class="main-list">
              <p>
                Location of Birth
                <span> {{checkProperty(child ,'locationOfBirth')}} </span>
              </p>
            </div>
          </div>
          
              <div class="vx-col md:w-1/3 w-full p-0"  v-if="checkProperty(child ,'countryOfCitizenshipDetails' ,'name')"
                       >
            <div class="main-list">
              <p>
               
                Country of Citizenship
                <span> {{
                  checkProperty(child ,'countryOfCitizenshipDetails' ,'name')
                 }} </span>
              </p>
            </div>
          </div>
          <div class="vx-col md:w-1/3 w-full p-0"  v-if="checkProperty(child ,'otherCountriesOfCitizenshipDetails' ) && checkProperty(child ,'otherCountriesOfCitizenshipDetails', 'length' )>0 && 
           formatCountriesName(checkProperty(child ,'otherCountriesOfCitizenshipDetails' )) !='' "
                       >
            <div class="main-list">
              <p>
               
                Any other country(ies) of Citizenship
                <span> {{
                 formatCountriesName(checkProperty(child ,'otherCountriesOfCitizenshipDetails' ))
                 }} </span>
              </p>
            </div>
          </div>
          <div class="vx-col md:w-1/3 w-full p-0" v-if="canRenderField('hasChildren', questionnaireDetails ,false,'dependentsInfo.childrens')">
            <div class="main-list">
              <p>
               Do you have children
                <span v-if="checkProperty(child,'hasChildren')" > Yes </span>
                <span v-else> No </span>
              </p>
            </div>
          </div>
           <div class="vx-col md:w-1/3 w-full p-0" v-if="canRenderField('h4Required', questionnaireDetails ,false,'dependentsInfo.childrens')">
            <div class="main-list">
              <p>
               H4 required for children
                <span v-if="checkProperty(child,'h4Required')" > Yes </span>
                <span v-else> No </span>
              </p>
            </div>
          </div>
          <div class="vx-col md:w-1/3 w-full p-0" v-if="canRenderField('h4EADRequired', questionnaireDetails ,false,'dependentsInfo.childrens')">
            <div class="main-list">
              <p>
                H4 EAD required for children
                <span v-if="checkProperty(child,'h4EADRequired')" > Yes </span>
                <span v-else> No </span>
              </p>
            </div>
          </div>
          <div class="vx-col md:w-1/3 w-full p-0" v-if="canRenderField('doYouAlreadyH4EAD', questionnaireDetails ,false,'dependentsInfo.childrens')" >
            <div class="main-list">
              <p>
                Do you already have H4 EAD?
                <span v-if="checkProperty(child,'doYouAlreadyH4EAD')" > Yes </span>
                <span v-else> No </span>
              </p>
            </div>
          </div>
          <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(child,'relationship')" >
            <div class="main-list">
              <p>
                Relationship with the dependent
                <span >{{ checkProperty(child,'relationship') }}</span>
                
              </p>
            </div>
          </div>
        </div>
        <template v-if="checkProperty(child,'hasOtherNames') && checkProperty(child ,'otherNames') && checkProperty(child,'otherNames' ,'length') >0">
            <div class="vx-row m-0 main-list-panel">
                <h5 class="names_title">Used other names previously</h5>
                <template v-for="(item , ind)  in child['otherNames']">
    
                    <div :key="ind" class="vx-col md:w-1/3 w-full p-0">
                        <div class="main-list">
                            <p>First Name<span v-if="item.firstName">{{item.firstName}}</span>
                              <span v-else>N/A</span>
                            </p>
                        </div>
                    </div>
                    <div :key="ind" class="vx-col md:w-1/3 w-full p-0">
                        <div class="main-list">
                            <p> Middle Name <span v-if="item.middleName">{{item.middleName}}</span>
                              <span v-else>N/A</span>
                            </p>
                        </div>
                    </div>
    
                    <div :key="ind" class="vx-col md:w-1/3 w-full p-0">
                        <div class="main-list">
                            <p> Last Name <span v-if="item.lastName">{{item.lastName}}</span>
                              <span v-else>N/A</span>
                            </p>
                        </div>
                    </div>
    
                </template>
    
            </div>
    
        </template>
        <div class="vx-row m-0 main-list-panel"
        v-if="checkProperty(child ,'passportNumber') || checkProperty(child ,'passportExpiryDate')|| checkProperty(child ,'I94')
        || checkProperty(child ,'eadNumber')|| checkProperty(child ,'sevisNumber') 
        || checkProperty(child ,'currentStatus') 
          || checkProperty(child ,'isDSExpiryDate') 
          
          || checkProperty(child ,'statusExpiryDate') "
        
        >
          <div class="vx-col md:w-1/3 w-full p-0" v-if="child.passportNumber">
            <div class="main-list">
              <p>
                Passport Number
                <span>{{child.passportNumber}}</span>
              </p>
            </div>
          </div>
          <div class="vx-col md:w-1/3 w-full p-0" v-if="child.passportIssuedDate">
            <div class="main-list">
              <p>
                Passport Issued Date
                <span>{{child.passportIssuedDate | formatDate}}</span>
              </p>
            </div>
          </div>
          <div class="vx-col md:w-1/3 w-full p-0" v-if="child.passportExpiryDate">
            <div class="main-list">
              <p>
                Passport Expiry Date
                <span>{{child.passportExpiryDate | formatDate}}</span>
              </p>
            </div>
          </div>
          <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(child ,'passportIssuedCountryDetails','name')">
            <div class="main-list">
                <p>
                  Country of Passport Issued 
                    <span>{{ checkProperty(child ,'passportIssuedCountryDetails','name') }}</span>
                </p>
            </div>
        </div>
        <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(child,'stateDetailsOfLastEntryInUS') && checkProperty(child,'stateDetailsOfLastEntryInUS','name')  ">
            <div class="main-list">
                <p>
                  State of recent entry into the USA
                    <span>{{checkProperty(child,'stateDetailsOfLastEntryInUS','name')}}</span>
                </p>
            </div>
        </div>
        <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(child,'placeOfLastEntryInUS')">
            <div class="main-list">
                <p>
                  Place of recent entry into the USA
                    <span>{{checkProperty(child,'placeOfLastEntryInUS')}}</span>
                </p>
            </div>
        </div>
        
        <div class="vx-col md:w-1/3 w-full p-0" v-if="child.lastArrivalDate">
          <div class="main-list">
            <p>
              Date of most recent entry into the USA
              <span>{{child.lastArrivalDate | formatDate}}</span>
            </p>
          </div>
        </div>
          <div class="vx-col md:w-1/3 w-full p-0" v-if="child.I94">
            <div class="main-list">
              <p>
                I-94 Number
                <span>{{child.I94}}</span>
              </p>
            </div>
          </div>
          <div class="vx-col md:w-1/3 w-full p-0" v-if="child.I94 || child.isI94DSExpiryDate">
            <div class="main-list">
              <p>
                I-94 Expiry Date 
                <span v-if="checkProperty(child ,'isI94DSExpiryDate')">D/S</span>
                <span v-else>{{child.I94ExpiryDate | formatDate}}</span>
              </p>
            </div>
          </div>
          <div class="vx-col md:w-1/3 w-full p-0" v-if="child.currentStatus ">
            <div class="main-list">
              <p>
                Current Nonimmigrant Status 
               
                <span > {{child.currentStatus   | formatML(visastatuses)}}</span>
              </p>
            </div>
          </div>
          <div class="vx-col md:w-1/3 w-full p-0" v-if="child.statusExpiryDate || checkProperty(child ,'isDSExpiryDate') ">
            <div class="main-list">
              <p>
                Current Status Expiry Date
                <span v-if="checkProperty(child ,'isDSExpiryDate')">D/S</span>
                <span v-else>{{child.statusExpiryDate | formatDate}}</span>
              </p>
            </div>
          </div>
          
          <div class="vx-col md:w-1/3 w-full p-0" v-if="child.eadNumber">
            <div class="main-list">
              <p>
                EAD Number
                <span>{{child.eadNumber}}</span>
              </p>
            </div>
          </div>
          <div class="vx-col md:w-1/3 w-full p-0" v-if="child.sevisNumber">
            <div class="main-list">
              <p>
                SEVIS Number
                <span>{{child.sevisNumber}}</span>
              </p>
            </div>
          </div>
          <div class="vx-col md:w-1/3 w-full p-0" v-if="child.applyingWithYou">
            <div class="main-list">
              <p>
                Applying with you
                <span>{{child.applyingWithYou | booleanFormat}}</span>
              </p>
            </div>
          </div>
          <div class="vx-col md:w-1/3  w-full p-0" v-if="canRenderField('haveYouEverTravelledToUS', questionnaireDetails ,false,'dependentsInfo.childrens')" >
          <div class="main-list">
              <p>
                  Have you ever travelled to the United States?
                  <span v-if="checkProperty(child,'haveYouEverTravelledToUS')"> Yes</span>
                  <span v-else> No</span>
              </p>
          </div>
        </div>
          <div class="vx-col md:w-1/3 w-full p-0" v-if="canRenderField('haveYouEverTravelledToUS', questionnaireDetails ,false,'dependentsInfo.childrens') &&
          checkProperty(child ,'haveYouEverTravelledToUS') && checkProperty(child ,'immigStatusLastArrival') " >
            <div class="main-list">
              <p>
                Immigration Status at Your Last Arrival
                <span>{{child.immigStatusLastArrival}}</span>
              </p>
            </div>
          </div>
        </div>
        <div class="vx-row m-0 main-list-panel"
          v-if="checkProperty(child ,'SSN') || checkProperty(child ,'alienNumber') || canRenderField('doYouHaveSSN', questionnaireDetails ,false,'dependentsInfo.childrens')
          || checkProperty(child, 'currentlyInUS')
          || checkProperty(child ,'visaIssuedDate')">
           <div class="vx-col md:w-1/3 w-full p-0" v-if="canRenderField('doYouHaveSSN', questionnaireDetails ,false,'dependentsInfo.childrens')" >
            <div class="main-list">
              <p>
                Do you have SSN?
                <span>{{checkProperty(child, 'doYouHaveSSN') | booleanFormat}}</span>
              </p>
            </div>
          </div>
          <div class="vx-col md:w-1/3 w-full p-0" v-if="child.SSN">
            <div class="main-list">
              <p>
                Social Security Number
                <span>{{child.SSN}}</span>
              </p>
            </div>
          </div>
          <div class="vx-col md:w-1/3 w-full p-0" v-if="canRenderField('doYouHaveSSN', questionnaireDetails ,false,'dependentsInfo.childrens') &&
          !checkProperty(child, 'doYouHaveSSN') && canRenderField('doYouWantTheSsaToIssueYouSS', questionnaireDetails ,false,'dependentsInfo.childrens') " >
            <div class="main-list">
              <p>
                Do you want the SSA to issue you a Social Security card?
                <span>{{checkProperty(child, 'doYouWantTheSsaToIssueYouSS') | booleanFormat}}</span>
              </p>
            </div>
          </div>
          <template v-if="canRenderField('doYouHaveSSN', questionnaireDetails ,false,'dependentsInfo.childrens') &&
          !checkProperty(child, 'doYouHaveSSN') && canRenderField('doYouWantTheSsaToIssueYouSS', questionnaireDetails ,false,'dependentsInfo.childrens') && checkProperty(child, 'doYouWantTheSsaToIssueYouSS') " >
          <template v-if="checkProperty(child, 'ssnFather') && ( checkProperty(child, 'ssnFather', 'familyName') || checkProperty(child, 'ssnFather', 'givenName') )">
            <h5 class="names_title">Father Name</h5>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(child, 'ssnFather', 'familyName')">
            <div class="main-list">
              <p>
                Family Name
                <span>{{checkProperty(child, 'ssnFather', 'familyName')}}</span>
              </p>
            </div>
          </div>
          <div class="vx-col md:w-1/3 w-full p-0" v-if=" checkProperty(child, 'ssnFather', 'givenName')">
            <div class="main-list">
              <p>
                Given Name
                <span>{{ checkProperty(child, 'ssnFather', 'givenName')}}</span>
              </p>
            </div>
          </div>
          </template>
          <template v-if="checkProperty(child, 'ssnMother') && ( checkProperty(child, 'ssnMother', 'familyName') || checkProperty(child, 'ssnMother', 'givenName') )">
            <h5 class="names_title">Mother Name</h5>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(child, 'ssnMother', 'familyName')">
            <div class="main-list">
              <p>
                Family Name
                <span>{{checkProperty(child, 'ssnMother', 'familyName')}}</span>
              </p>
            </div>
          </div>
          <div class="vx-col md:w-1/3 w-full p-0" v-if=" checkProperty(child, 'ssnMother', 'givenName')">
            <div class="main-list">
              <p>
                Given Name
                <span>{{ checkProperty(child, 'ssnMother', 'givenName')}}</span>
              </p>
            </div>
          </div>
          </template>
          </template>
          <div class="vx-col md:w-1/3 w-full p-0" v-if="child.alienNumber">
            <div class="main-list">
              <p>
                Alien Number
                <span>{{child.alienNumber}}</span>
              </p>
            </div>
          </div>
          <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(child, 'currentlyInUS')">
            <div class="main-list">
              <p>
                Currently in USA
                <span>{{checkProperty(child, 'currentlyInUS') | booleanFormat}}</span>
              </p>
            </div>
          </div>
          <div class="vx-col md:w-1/3 w-full p-0" v-if="child.visaIssuedDate">
            <div class="main-list">
              <p>
                Case Issued Date
                <span>{{child.visaIssuedDate | formatDate}}</span>
              </p>
            </div>
          </div>
          <template v-if="child && canRenderField('anyOtherPersonEmployedInUS', questionnaireDetails ,false,'dependentsInfo.childrens') && ((checkProperty(child,'prevEmploymentInfo') && checkProperty(child,'prevEmploymentInfo','length')>0 && !checkProperty(child['prevEmploymentInfo'][0],'employerName'))
          || !checkProperty(child,'prevEmploymentInfo') || !checkProperty(child,'prevEmploymentInfo','length')>0 )" >
            <div class="vx-col md:w-1/3 w-full p-0" v-if="canRenderField('anyOtherPersonEmployedInUS', questionnaireDetails ,false,'dependentsInfo.childrens')">
            <div class="main-list">
              <p>
                Have you been employed in the United States since last admitted or granted an extension or change of status?
                <span>{{checkProperty(child, 'anyOtherPersonEmployedInUS') | booleanFormat}}</span>
              </p>
            </div>
          </div>
          </template>
        </div>
        <template v-if="checkProperty(petition, 'subTypeDetails','id') == 16" >
          <div class="vx-row m-0 main-list-panel" >
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(child,'adjustmentOfI485Status') == true || checkProperty(child,'adjustmentOfI485Status') == false " >
              <div class="main-list">
                <p>
                  Adjustment of Status (I-485) 
                  <span>{{checkProperty(child,'adjustmentOfI485Status') | booleanFormat }}</span>
                </p>
              </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(child,'consularProcessing') == true || checkProperty(child,'consularProcessing') == false ">
              <div class="main-list">
                <p>
                  Consular Processing
                  <span>{{checkProperty(child,'consularProcessing') | booleanFormat }}</span>
                </p>
              </div>
            </div>
        </div>
        </template>     

   
        <div class="vx-row m-0 main-list-panel" v-if="checkProperty(child,'currentAddress','line1') ">
          <div class="vx-col w-full p-0" v-if="checkProperty(child,'currentAddress')">
            <div class="main-list">
              <p>
               Current Address
                <span>{{checkProperty(child,'currentAddress') | addressformat}}</span>
              </p>
            </div>
          </div>
        </div>
        <div class="vx-row m-0 main-list-panel" v-if="checkProperty(child,'physicalAddress','line1') ">
          <div class="vx-col w-full p-0" v-if="checkProperty(child,'physicalAddress')">
            <div class="main-list">
              <p>
               Mailing Address
                <span>{{checkProperty(child,'physicalAddress') | addressformat}}</span>
              </p>
            </div>
          </div>
        </div>
        <div class="vx-row m-0 main-list-panel" v-if="checkProperty(child,'addressOutsideUS','line1')">
          <div class="vx-col w-full p-0" v-if="checkProperty(child,'addressOutsideUS')">
            <div class="main-list">
              <p>
                <template v-if="callFromPerm">Foreign Address</template>
                <template v-else>Address Outside the U.S</template>
                <span>{{checkProperty(child,'addressOutsideUS') | addressformat}}</span>
              </p>
            </div>
          </div>
        </div>
        
        <!-- <div class="vx-row m-0 main-list-panel" v-if="checkProperty(child ,'anyOtherPersonEmployedInUS' )">
            <div class="vx-col w-full p-0">
                <div class="main-list">
                    <p>
                      Have you ever been employed?
                        <span>{{child.anyOtherPersonEmployedInUS | booleanFormat}}</span>
                    </p>
                </div>
            </div>
        </div> -->
        <!-- <div class="vx-row m-0 main-list-panel" v-if="checkProperty(child ,'haveYouEverEmployed' )">
            <div class="vx-col w-full p-0">
                <div class="main-list">
                    <p>
                        Have you ever been employed Outside US?
                        <span>{{child.haveYouEverEmployed | booleanFormat}}</span>
                    </p>
                </div>
            </div>
        </div> -->
        <template v-if="child && checkProperty(child,'prevEmploymentInfo') && checkProperty(child,'prevEmploymentInfo','length')>0 && checkProperty(child['prevEmploymentInfo'][0],'employerName')" >
          <h3 class="small-header mart25"  > Employment</h3>
        
          <div class="child_info_employment">
            <employementInfo :callPrevious="true" :datatype ="'CHILD_EMPLOYEMENT'" :tplSection="'dependentsInfo.childrens'" :questionnaireDetails="questionnaireDetails" :employmentList="child.prevEmploymentInfo" :anyOtherPersonEmployedInUS="child.anyOtherPersonEmployedInUS"  :visastatuses="visastatuses" :callFromDependent="true" :petition="petition"></employementInfo>
          </div>
        </template>
        
        <template v-if="child && checkProperty(child,'priorPeriodOfStayInUS') &&  checkProperty(child,'priorPeriodOfStayInUS','length')>0 && checkProperty(child['priorPeriodOfStayInUS'][0],'visaStatus')">
          <h3 class="small-header mart25"> Dates of Stay in USA</h3>
          <div class="child_info_employment main-list-wrap petition_details_wrap mb-6">
          <periodofStayInUSA :callFrom="'SPOUSE'" :visastatuses="visastatuses" :petition="petition" :dataList="checkProperty(child,'priorPeriodOfStayInUS')" />
        </div>
        </template>
     
        <template v-if="!callFromPerm">
          <Documents :loadedFromPreview="loadedFromPreview" :petitionId="checkProperty(petition,'_id')" :callFrom="'Child'" v-bind:petition="child"  @download_or_view="downloadfile" :allbtn="false" />
        </template>
      </div>
    </div>
  </div>
</template>

<script>
import Documents from "./Documents";
import periodofStayInUSA from "@/views/petition/subtabs/periodofStayInUSA.vue";

import employementInfo from "@/views/petition/subtabs/employement.vue";
export default {
  data: ()=>({
    visastatuses:[],
  }),
  components: {
    Documents,
    employementInfo,
    periodofStayInUSA
  },
  props: {
    callFromPerm:{
      type: Boolean,
      default: false
    },
    loadedFromPreview:false,
    petition: {
      type: Object,
      default: null
    },
    questionnaireDetails:{
        type: Array,
        default: null
    }
    //  visastatuses: {
    //         type: Array,
    //         default: null
    //     }
  },
  methods:{
    getVisastatues(){
      this.$store.dispatch("getmasterdata", "visa_status").then((response) => {
        this.visastatuses = response;
      });
    },
     downloadfile(value) {
      
      this.$emit('download_or_view' ,value);
      // value.url = value.url.replace(this.$globalgonfig._S3URL,"");
      // value.url = value.url.replace(this.$globalgonfig._S3URLAWS,"");
      // let postdata = { keyName: value.url };
      // this.$store.dispatch("getSignedUrl", postdata).then((response) => {
      //   window.open(response.data.result.data, "_blank");
      // });
    },
  },
  mounted() {
    
    this.getVisastatues()
    this.$store.dispatch("setPetitionTab" , 'Children Info')

  },
  computed:{
    formatCountriesName(){
      return (data)=>{
        let returnVal = ''
        if(this.checkProperty(data, 'length')>0){
          _.forEach(data, (itm)=>{
            if(_.has(itm, 'name') && itm['name']){
              if(returnVal != ''){
                returnVal = returnVal + ', '+ itm['name']
              }else{
                returnVal = itm['name']
              }
            }
          })
        }
        return returnVal;
      }
    },
  }
  
};
</script>