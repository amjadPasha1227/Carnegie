<template>
  <ul>
    <li class="completed">
    
      <em></em>
      <div class="status_list_cnt">
        <div class="status_title">
          <label>Started </label>
        </div>
        <span v-if="checkProperty(getPetitionDetails ,'createdOn')">{{getPetitionDetails.createdOn | formatDateTime}}</span>
      </div>
    </li>

    <li v-if="checkProperty(workFlowDetails ,'config' ) && checkLcaRequired"  :class="{ 
      'lca-lnitiated':checkProperty(getLcaStatus ,'statusId')==1,
      'lca-filed':checkProperty(getLcaStatus ,'statusId')==2,
      'completed':checkProperty(getLcaStatus ,'statusId')==3,
      'lca-denied':checkProperty(getLcaStatus ,'statusId')==4,
      'lca-request-for-withdrawal':checkProperty(getLcaStatus ,'statusId')==5,
      'lca-withdrawn':checkProperty(getLcaStatus ,'statusId')==6,
      'lca-expired':checkProperty(getLcaStatus ,'statusId')==7,
      'lca-received-rfe':checkProperty(getLcaStatus ,'statusId')==8,
      'lca-draft':checkProperty(getLcaStatus ,'statusId')==99,
      'current': !getLcaStatus 
      }">
      <!---['LCA_REQUEST' ,'LCA_SUBMIT',"PROCESS_LCA_BY_MANAGER"]
      
       { "id": 1,  "name": "Initiated", "sortName": "initiated" },
       {"id": 2,"name": "Filed", },
       { "id": 3,  "name": "Certified"},
       {"id": 4, "name": "Denied",},
       {"id": 5,  "name": "Request for Withdrawal", },
       {  "id": 6, "name": "Withdrawn" },
       {"id": 7, "name": "Expired",},
       { "id": 8,"name": "Received RFE" },
       { "id": 99, "name": "Draft" }
      
      -->
      <em></em>
      <div class="status_list_cnt">
        <div class="status_title">
          <label>

            <template v-if="checkProperty(getLcaStatus ,'statusId') !=99 && checkProperty(getLcaStatus ,'statusDetails','name')">LCA {{ checkProperty(getLcaStatus ,'statusDetails','name') }}</template>
            <template v-else-if="checkProperty(getLcaStatus ,'statusId') !=99 && checkProperty(getLcaStatus ,'statusName')">LCA {{ checkProperty(getLcaStatus ,'statusName') }}</template>
            <template v-else>LCA Pending</template>
            
          </label>
        </div> 
        
        <span v-if="checkProperty(getLcaStatus ,'statusId') !=99 && checkProperty(getLcaStatus ,'createdOn')">{{checkProperty(getLcaStatus ,'createdOn') | formatDateTime}}</span>
      </div>   
      
      
    </li>


    <li v-if="getTenantTypeId ==2" :class="{completed: isActivyCompleted('Questionnaire Submitted'),current: isActivyActive('Questionnaire Submitted')}">
      <em></em>
      <div class="status_list_cnt">
        <div class="status_title">
          <label>Questionnaire Submitted</label>
          <template
            v-if="!checkProperty(petition, 'questionnaireFilled') || getCompletedActivities.indexOf('SUBMIT_TO_LAW_FIRM') <= -1" >
            <div
              class="info"
              v-if="findUsers && [50, 51].indexOf(getUserRoleId) <= -1"
            >
              <img src="@/assets/images/main/information.svg" />
              <div class="info_cnt">
                <p>Pending with {{ findUsers }}</p>
              </div>
            </div>
          </template>
        </div>
        <span
          v-if="
            checkProperty(getPetitionDetails, 'questionnaireFilled') &&
            getActionComplatedDate('SUBMIT_BY_BENEFICIARY')
          "
          >{{
            getActionComplatedDate("SUBMIT_BY_BENEFICIARY") | formatDateTime
          }}</span
        >
      </div>
    </li>
  <template v-if="getTenantTypeId !=2">

    <li :class="{completed: isActivyCompleted('Questionnaire Submitted'),current: isActivyActive('Questionnaire Submitted')}">
      <em></em>
      <div class="status_list_cnt">
        <div class="status_title">
          <label>Questionnaire Submitted</label>
          <template
            v-if="!checkProperty(petition, 'questionnaireFilled') || getCompletedActivities.indexOf('SUBMIT_TO_LAW_FIRM') <= -1" >
            <div
              class="info"
              v-if="findUsers && [50, 51].indexOf(getUserRoleId) <= -1"
            >
              <img src="@/assets/images/main/information.svg" />
              <div class="info_cnt">
                <p>Pending with {{ findUsers }}</p>
              </div>
            </div>
          </template>
        </div>
        <span
          v-if="
            checkProperty(getPetitionDetails, 'questionnaireFilled') &&
            getActionComplatedDate('SUBMIT_BY_BENEFICIARY')
          "
          >{{
            getActionComplatedDate("SUBMIT_BY_BENEFICIARY") | formatDateTime
          }}</span
        >
      </div>
    </li>

    <li  v-if="([2,10].indexOf(checkProperty(petition, 'type'))>-1 && checkProperty(petition,'petitionerId') ) ||([2,10].indexOf(checkProperty(petition, 'type'))<=-1)" :class="{completed: getCompletedActivities.indexOf('SUBMIT_TO_LAW_FIRM') >-1,current: checkProperty(getPetitionDetails, 'questionnaireFilled') &&getCompletedActivities.indexOf('SUBMIT_TO_LAW_FIRM') <=-1 }">
      <em></em>
      <div class="status_list_cnt">
        <div class="status_title">
          <label>Petitioner Reviewed</label>
          <template
            v-if=" checkProperty(getPetitionDetails, 'questionnaireFilled') && getCompletedActivities.indexOf('SUBMIT_TO_LAW_FIRM') <= -1" >
            <div
              class="info"
              v-if="findUsers && [50, 51].indexOf(getUserRoleId) <= -1"
            >
              <img src="@/assets/images/main/information.svg" />
              <div class="info_cnt">
                <p>Pending with {{ findUsers }}</p>
              </div>
            </div>
          </template>
        </div>
        <span
          v-if=" checkProperty(getPetitionDetails, 'questionnaireFilled') &&  getActionComplatedDate('SUBMIT_TO_LAW_FIRM')  "
          >{{
            getActionComplatedDate("SUBMIT_TO_LAW_FIRM") | formatDateTime
          }}</span
        >
      </div>
    </li>
  </template>

    
    <li 
       v-if="checkIsthisI140"
      :class="{completed: (checkActivityCompleted('GENERATED_FORMS_AND_LETTERS')||getCompletedActivities.indexOf('CASE_APPROVED') > -1), 
      current: isActivyCompleted('Questionnaire Submitted')&& getCompletedActivities.indexOf('SUBMIT_TO_LAW_FIRM')> -1 && !checkActivityCompleted('GENERATED_FORMS_AND_LETTERS') && getCompletedActivities.indexOf('CASE_APPROVED')<= -1,
      }"
    >
      <em></em>
      <div class="status_list_cnt">
        <div class="status_title">
          <label>Forms & Letters Generated</label>
           </div>
           
        <span v-if="getActionComplatedDate('GENERATED_FORMS_AND_LETTERS')">{{
         getActionComplatedDate("GENERATED_FORMS_AND_LETTERS") | formatDateTime
        }}
        </span>
        
      </div>
    </li>
    <li 
       v-if="checkIsthisI140"
      :class="{     
      completed: getCompletedActivities.indexOf('CASE_APPROVED') > -1,
      current: petition && checkProperty(petition, 'nextWorkflowActivity') && petition['nextWorkflowActivity'].indexOf('CASE_APPROVED')>-1,
      
      
      }"
     
    >
      <em></em>
      <div class="status_list_cnt">
        <div class="status_title">
          <label>Paralegal Review</label>
          

          <template
            v-if="
              checkProperty(getPetitionDetails, 'questionnaireFilled') &&
              getCompletedActivities.indexOf('CASE_APPROVED') <= -1
            "
          >
            <div
              class="info"
              v-if="findUsers && [50, 51].indexOf(getUserRoleId) <= -1"
            >
              <img src="@/assets/images/main/information.svg" />
              <div class="info_cnt">
                <p>Pending with <a href="#"></a> {{ findUsers }}</p>
              </div>
            </div>
          </template>
           </div>
           
        <span v-if="getActionComplatedDate('CASE_APPROVED')">{{
         getActionComplatedDate("CASE_APPROVED") | formatDateTime
        }}
        </span>
        
      </div>
    </li>

    

    <li 
       v-if="!checkIsthisI140 && checkAssignmentsExists"
      :class="{
        completed: isActivyCompleted('In Process'),
        current: isActivyActive('In Process') && !isActivyCompleted('In Process'),
      }"
    >
      <em></em>
      <div class="status_list_cnt">
        <div class="status_title">
          <label>In Process</label>
          <template
            v-if="
              checkProperty(getPetitionDetails, 'questionnaireFilled') &&
              getCompletedActivities.indexOf('SUBMIT_TO_LAW_FIRM') > -1 &&
              getCompletedActivities.indexOf('CASE_APPROVED') <= -1
            "
          >
            <div
              class="info"
              v-if="findUsers && [50, 51].indexOf(getUserRoleId) <= -1"
            >
              <img src="@/assets/images/main/information.svg" />
              <div class="info_cnt">
                <p>Pending with <a href="#"></a> {{ findUsers }}</p>
              </div>
            </div>
          </template>
        </div>
        <span v-if="getActionComplatedDate('CASE_APPROVED')">{{
          getActionComplatedDate("CASE_APPROVED") | formatDateTime
        }}</span>
      </div>
    </li>

    <li

    
      :class="{
        completed:isActivyCompleted('Petitioner Signature'),
        current:isActivyActive('Petitioner Signature') && !isActivyCompleted('Petitioner Signature') //checkProperty(getPetitionDetails, 'statusId') ==  9  && !( isActivyCompleted('Submitted to USCIS') || getPetitionDetails.completedActivities.indexOf('UPLOAD_BENEFICIARY_SCANNED_COPY')>-1|| getPetitionDetails.completedActivities.indexOf('UPLOAD_SCANNED_COPY')>-1)//|| isActivyActive('Petitioner Signature') && (!scannedDocumentsList || (scannedDocumentsList && checkProperty(scannedDocumentsList ,'length')<=0)),
      }"
    >
      <em></em>
      <div class="status_list_cnt">
        <div class="status_title">
          <label>
            <template v-if="[2,10].indexOf(checkProperty(petition, 'type' ))>-1 && !checkProperty(petition,'petitionerId')"> Sent for Signatures</template>
            <template v-else> Sent for Signatures</template>          
          </label>
          <template
            v-if="
              checkProperty(getPetitionDetails, 'nextWorkflowActivity') ==
                'REQUEST_PETITIONER_SIGN' &&
              getCompletedActivities.indexOf('SUBMIT_TO_USCIS') <= -1
            "
          >
            <div
              class="info"
              v-if="findUsers && [50, 51].indexOf(getUserRoleId) <= -1 && isActivyActive('Petitioner Signature') && !isActivyCompleted('Petitioner Signature')"
            >
              <img src="@/assets/images/main/information.svg" />
              <div class="info_cnt">
                <p>Pending with <a href="#"></a> {{ findUsers }}</p>
              </div>
            </div>
          </template>
        </div>
        <!---
                <span v-if="getActionComplatedDate('REQUEST_PETITIONER_SIGN')">{{getActionComplatedDate('REQUEST_PETITIONER_SIGN') | formatDateTime}}</span>
                -->
                
                <span v-if="getActionComplatedDate('REQUEST_PETITIONER_SIGN')">{{
          getActionComplatedDate("REQUEST_PETITIONER_SIGN") | formatDateTime
        }}</span>
        <span v-else-if="getActionComplatedDate('REQUEST_BENEFICIARY_SIGN')">{{
          getActionComplatedDate("REQUEST_BENEFICIARY_SIGN") | formatDateTime
        }}</span>
        
        
      </div>
    </li>

    <li

v-if="!checkIsthisI140"
  

:class="{
        completed:isActivyCompleted('Received Signed Forms') || (isActivyActive('Submitted to USCIS') && !isActivyCompleted('Submitted to USCIS')) ,
        current:isActivyActive('Received Signed Forms') && !( isActivyCompleted('Received Signed Forms') || (isActivyActive('Submitted to USCIS') && !isActivyCompleted('Submitted to USCIS'))) //checkProperty(getPetitionDetails, 'statusId') ==  9  && !( isActivyCompleted('Submitted to USCIS') || getPetitionDetails.completedActivities.indexOf('UPLOAD_BENEFICIARY_SCANNED_COPY')>-1|| getPetitionDetails.completedActivities.indexOf('UPLOAD_SCANNED_COPY')>-1)//|| isActivyActive('Petitioner Signature') && (!scannedDocumentsList || (scannedDocumentsList && checkProperty(scannedDocumentsList ,'length')<=0)),
      }"
>
  <em></em>
  <div class="status_list_cnt">
    <div class="status_title">
      <label>
      <template>Received Signed Forms </template>
      
      </label>
      <template
        v-if="
          checkProperty(getPetitionDetails, 'nextWorkflowActivity') ==
            'REQUEST_PETITIONER_SIGN' &&
          getCompletedActivities.indexOf('SUBMIT_TO_USCIS') <= -1
        "
      >
        <div
          class="info"
          v-if="findUsers && [50, 51].indexOf(getUserRoleId) <= -1"
        >
          <img src="@/assets/images/main/information.svg" />
          <div class="info_cnt">
            <p>Pending with <a href="#"></a> {{ findUsers }}</p>
          </div>
        </div>
      </template>
    </div>
    <!---
            <span v-if="getActionComplatedDate('REQUEST_PETITIONER_SIGN')">{{getActionComplatedDate('REQUEST_PETITIONER_SIGN') | formatDateTime}}</span>
            -->
    <!------<span v-if="scannedDocumentsList && scannedDocumentsList.length > 0">{{
      scannedDocumentsList[0]["createdOn"] | formatDateTime
    }}</span>--->

    <span v-if="getActionComplatedDate('UPLOAD_SCANNED_COPY')">{{
          getActionComplatedDate("UPLOAD_SCANNED_COPY") | formatDateTime
        }}</span>
        <span v-else-if="getActionComplatedDate('UPLOAD_BENEFICIARY_SCANNED_COPY')">{{
          getActionComplatedDate("UPLOAD_BENEFICIARY_SCANNED_COPY") | formatDateTime
        }}</span>
     
  </div>
    </li>

    <!----I-140-->
    <template  v-if="checkIsthisI140">
      <li

    
        :class="{
          completed: getCompletedActivities.indexOf('REQUEST_PETITIONER_SIGN') > -1 || getCompletedActivities.indexOf('GENERATED_SIGNED_DOCS') > -1,
           current: (getCompletedActivities.indexOf('GENERATED_SIGNED_DOCS') <= -1 && ((petition && checkProperty(petition, 'nextWorkflowActivity') && petition['nextWorkflowActivity'].indexOf('REQUEST_PETITIONER_SIGN')>-1) || (petition && checkProperty(petition, 'nextWorkflowActivity') && petition['nextWorkflowActivity'].indexOf('SUPERVISOR_FORMS_REVIEW')>-1 && getActionComplatedDate('UPLOAD_SCANNED_COPY') && getCompletedActivities.indexOf('REQUEST_PETITIONER_SIGN')<=-1 ))),
        }"
      >
        <em></em>
        <div class="status_list_cnt">
          <div class="status_title">
            <label>
            <template>Forms Sent for Signatures  </template>
            
            
            </label>
            <template
              v-if="
                checkProperty(getPetitionDetails, 'nextWorkflowActivity') ==
                  'REQUEST_PETITIONER_SIGN' &&
                getCompletedActivities.indexOf('SUBMIT_TO_USCIS') <= -1
              "
            >
              <div
                class="info"
                v-if="findUsers && [50, 51].indexOf(getUserRoleId) <= -1"
              >
                <img src="@/assets/images/main/information.svg" />
                <div class="info_cnt">
                  <p>Pending with <a href="#"></a> {{ findUsers }}</p>
                </div>
              </div>
            </template>
          </div>
          <span v-if="getActionComplatedDate('REQUEST_PETITIONER_SIGN')">{{
          getActionComplatedDate("REQUEST_PETITIONER_SIGN") | formatDateTime
        }}</span>
         <span v-else-if="getActionComplatedDate('REQUEST_BENEFICIARY_SIGN')">{{
          getActionComplatedDate("REQUEST_BENEFICIARY_SIGN") | formatDateTime
        }}</span>    

          <!---<span v-if="scannedDocumentsList && scannedDocumentsList.length > 0">{{
            scannedDocumentsList[0]["createdOn"] | formatDateTime
          }}</span>-->
        </div>
      </li>
      <li


      :class="{
      completed: ( (getCompletedActivities.indexOf('GENERATED_SIGNED_DOCS') || getCompletedActivities.indexOf('REQUEST_PETITIONER_SIGN') > -1 )&& (getCompletedActivities.indexOf('UPLOAD_SCANNED_COPY') > -1 || getActionComplatedDate('UPLOAD_SCANNED_COPY')) ||  ( petition && checkProperty(petition, 'completedActivities') && (petition['completedActivities'].indexOf('SUBMIT_TO_USCIS') > -1 || petition['completedActivities'].indexOf('SUPERVISOR_FORMS_REVIEW') > -1 ))),
      current: petition && checkProperty(petition, 'nextWorkflowActivity') && (petition['nextWorkflowActivity'].indexOf('UPLOAD_SCANNED_COPY')>-1 || (petition['currentActivity']=='REQUEST_PETITIONER_SIGN' && petition['nextWorkflowActivity'].indexOf('SUPERVISOR_FORMS_REVIEW')>-1 && !getActionComplatedDate('UPLOAD_SCANNED_COPY') ) ),
       
      }"
      >
      <em></em>
      <div class="status_list_cnt">
      <div class="status_title">
      <label>
      <template>Received Signed Forms</template>
      

      </label>
      <template
      v-if="
        checkProperty(getPetitionDetails, 'nextWorkflowActivity') ==
          'REQUEST_PETITIONER_SIGN' &&
        getCompletedActivities.indexOf('SUBMIT_TO_USCIS') <= -1
      "
      >
      <div
        class="info"
        v-if="findUsers && [50, 51].indexOf(getUserRoleId) <= -1"
      >
        <img src="@/assets/images/main/information.svg" />
        <div class="info_cnt">
          <p>Pending with <a href="#"></a> {{ findUsers }}</p>
        </div>
      </div>
      </template>
      </div>
      
      <span v-if="getActionComplatedDate('UPLOAD_SCANNED_COPY')">{{
          getActionComplatedDate("UPLOAD_SCANNED_COPY") | formatDateTime
        }}</span>  

      <!-----<span v-if="scannedDocumentsList && scannedDocumentsList.length > 0">{{
      scannedDocumentsList[0]["createdOn"] | formatDateTime
      }}</span>-->
      </div>
      </li>
      <!----Supervisor Review -->
      <li


      :class="{
      completed:( (getCompletedActivities.indexOf('GENERATED_SIGNED_DOCS') || getCompletedActivities.indexOf('REQUEST_PETITIONER_SIGN') > -1) && (petition && checkProperty(petition, 'completedActivities') && petition['completedActivities'].indexOf('SUPERVISOR_FORMS_REVIEW') > -1) ||  ( petition && checkProperty(petition, 'completedActivities') && petition['completedActivities'].indexOf('SUBMIT_TO_USCIS') > -1)),
      current: (getCompletedActivities.indexOf('GENERATED_SIGNED_DOCS') || getCompletedActivities.indexOf('REQUEST_PETITIONER_SIGN')>-1)&&(petition && checkProperty(petition, 'nextWorkflowActivity') && petition['nextWorkflowActivity'].indexOf('SUPERVISOR_FORMS_REVIEW')>-1 && getActionComplatedDate('UPLOAD_SCANNED_COPY')),
      }"
      >
      <em></em>
      <div class="status_list_cnt">
      <div class="status_title">
      <label>
      <template>Supervisor Review</template>

      </label>
      <template
      v-if="
        checkProperty(getPetitionDetails, 'nextWorkflowActivity') ==
          'SUPERVISOR_FORMS_REVIEW' &&
        getCompletedActivities.indexOf('SUPERVISOR_FORMS_REVIEW') <= -1
      "
      >
      <div
        class="info"
        v-if="findUsers && [50, 51].indexOf(getUserRoleId) <= -1"
      >
        <img src="@/assets/images/main/information.svg" />
        <div class="info_cnt">
          <p>Pending with <a href="#"></a> {{ findUsers }}</p>
        </div>
      </div>
      </template>
      </div>
      
          <span v-if="getActionComplatedDate('SUPERVISOR_FORMS_REVIEW')">{{getActionComplatedDate('SUPERVISOR_FORMS_REVIEW') | formatDateTime}}</span>
        
      </div>
      </li>
  </template>


    <li
      :class="{
        completed: isActivyCompleted('Submitted to USCIS'),
        current: isActivyActive('Submitted to USCIS')  ,
      }"
    >
      <em></em>
      <div class="status_list_cnt">
        <div class="status_title">
          <label> Submitted to USCIS </label>
          <template
            v-if="
              getCompletedActivities.indexOf('SUBMIT_TO_USCIS') <= -1 &&
              getCompletedActivities.indexOf('REQUEST_PETITIONER_SIGN') > -1 &&
              getCompletedActivities.indexOf('COURIER_TRACKING') <= -1 &&
              checkProperty(getPetitionDetails, 'questionnaireFilled')
            "
          >
            <div
              class="info"
              v-if="findUsers && [50, 51].indexOf(getUserRoleId) <= -1"
            >
              <img src="@/assets/images/main/information.svg" />
              <div class="info_cnt">
                <p>Pending with <a href="#"></a> {{ findUsers }}</p>
              </div>
            </div>
          </template>
        </div>
          <span v-if="getActionComplatedDate('SUBMIT_TO_USCIS')">{{
          getActionComplatedDate("SUBMIT_TO_USCIS") | formatDateTime
        }}</span>
      </div>
    </li>

    <li
      :class="{
        completed: isActivyCompleted('Receipt Received'),
        current: isActivyActive('Receipt Received'),
      }"
    >
      <em></em>
      <div class="status_list_cnt">
        <div class="status_title">
          <label> Receipt Received</label>
          <template
            v-if="
              getCompletedActivities.indexOf('SUBMIT_TO_USCIS') > -1 &&
              getCompletedActivities.indexOf('REQUEST_PETITIONER_SIGN') > -1 &&
              getCompletedActivities.indexOf('COURIER_TRACKING') > -1 &&
              getCompletedActivities.indexOf('UPDATE_USCIS_RECEIPT_NUMBER') <=
                -1
            "
          >
            <div
              class="info"
              v-if="findUsers && [50, 51].indexOf(getUserRoleId) <= -1"
            >
              <img src="@/assets/images/main/information.svg" />
              <div class="info_cnt">
                <p>Pending with <a href="#"></a> {{ findUsers }}</p>
              </div>
            </div>
          </template>
        </div>
        <span v-if="getActionComplatedDate('UPDATE_USCIS_RECEIPT_NUMBER')">{{
          getActionComplatedDate("UPDATE_USCIS_RECEIPT_NUMBER") | formatDateTime
        }}</span>
      </div>
    </li>

    <li
      :class="{  completed: isActivyCompleted('USCIS Response'), current: isActivyActive('USCIS Response'), }"
    >
      <em></em>
      <div class="status_list_cnt" v-if="checkProperty(getupdatebenficiaryLog ,'data' ,'rfeNotice')">
        <div class="status_title">
          <template
            v-if="
              [
                'USCIS_APPROVED',
                'USCIS_RECEIVED_RFE',
                'USCIS_DENIED',
                'USCIS_WITHDRAWN',
              ].indexOf(checkProperty(getupdatebenficiaryLog['data'],'rfeNotice' ,'action')) > -1
            "
          >
            <label v-if="  checkProperty(getupdatebenficiaryLog['data'],'rfeNotice' ,'action') ==  'USCIS_APPROVED' "> Approved </label>
            <label v-if=" checkProperty(getupdatebenficiaryLog['data'],'rfeNotice' ,'action') == 'USCIS_RECEIVED_RFE'  "  > RFE Received</label>
            <label v-if=" checkProperty(getupdatebenficiaryLog['data'],'rfeNotice' ,'action') =='USCIS_DENIED'"> Denied</label>
            <label v-if="  checkProperty(getupdatebenficiaryLog['data'],'rfeNotice' ,'action') == 'USCIS_WITHDRAWN' " >  Withdrawn</label>
          </template>
          <template v-else><label>USCIS Response</label></template>
          <div class="info" v-if="isActivyActive('USCIS Response') && findUsers && [50, 51].indexOf(getUserRoleId) <= -1">
              <img src="@/assets/images/main/information.svg" />
              <div class="info_cnt">
                <p>Pending with <a href="#"></a> {{ findUsers }}</p>
              </div>
            </div>
        </div>
      
        <span v-if="checkProperty(getupdatebenficiaryLog,'endedOn' )">{{checkProperty(getupdatebenficiaryLog,'endedOn' ) | formatDateTime}}</span>
          
      </div>
      <div class="status_list_cnt" v-else>
        
        <div class="status_title">
          <template
            v-if="
              [
                'USCIS_APPROVED',
                'USCIS_RECEIVED_RFE',
                'USCIS_DENIED',
                'USCIS_WITHDRAWN',
              ].indexOf(petition.curWorkflowActivity) > -1
            "
          >
            <label v-if="  checkProperty(petition, 'curWorkflowActivity') ==  'USCIS_APPROVED' "> Approved </label>
            <label v-if=" checkProperty(petition, 'curWorkflowActivity') == 'USCIS_RECEIVED_RFE'  "  > RFE Received</label>
            <label v-if=" checkProperty(petition, 'curWorkflowActivity') =='USCIS_DENIED'"> Denied</label>
            <label v-if="  checkProperty(petition, 'curWorkflowActivity') == 'USCIS_WITHDRAWN' " >  Withdrawn</label>
          </template>
          <template v-else><label>USCIS Response</label></template>
          <div class="info" v-if="isActivyActive('USCIS Response') && findUsers && [50, 51].indexOf(getUserRoleId) <= -1">
              <img src="@/assets/images/main/information.svg" />
              <div class="info_cnt">
                <p>Pending with <a href="#"></a> {{ findUsers }}</p>
              </div>
            </div>
        </div>

        <span v-if="getActionComplatedDate('UPDATE_USCIS_RESPONSE')">{{getActionComplatedDate("UPDATE_USCIS_RESPONSE") | formatDateTime}}</span>
          
      </div>
      
    </li>
    <!----- RFE Case with in case-->
    <template v-if="checkActivityCompleted('USCIS_RECEIVED_RFE')">
    <template v-if=" ([1].indexOf(checkProperty(petition ,'type')) >-1 && checkProperty(workFlowDetails ,'manageRfeCase') =='with_in_case') " >

      <li class="completed" v-if="false">
        <em></em>
        <div class="status_list_cnt">
          <div class="status_title">
            <label>Case Created</label>
            <template v-if="false">
            <div class="info">
              <img src="@/assets/images/main/information.svg" />
              <div class="info_cnt">
                <p>Pending with {{ findUsers }}</p>
              </div>
            </div>
          </template>
          </div>
          <span v-if="checkProperty( petition, 'createdOn')">{{ petition['createdOn'] | formatDateTime }}</span>
        </div>
      </li>
      <!----current-->
      <li
          :class="{'completed':checkActivityCompleted('RFE_PREPARE_RESPONSE_DOCS'),'current':isCurrentActive('RFE_PREPARE_RESPONSE_DOCS') || !checkActivityCompleted('RFE_PREPARE_RESPONSE_DOCS') }"  >
        <em></em>
        <div class="status_list_cnt">
          <div class="status_title">
            <label>RFE Response Docs Prepared</label>
            <template v-if="findUsers">
              <div class="info">
                <img src="@/assets/images/main/information.svg" />
                <div class="info_cnt">
                  <p>Pending with {{findUsers}}</p>
                </div>
              </div>
            </template>
          </div>
          <span v-if="getActionComplatedDate('RFE_PREPARE_RESPONSE_DOCS')">{{ getActionComplatedDate("RFE_PREPARE_RESPONSE_DOCS") | formatDateTime }}</span>
        </div>
      </li>
      <li :class="{'completed':checkActivityCompleted('RFE_CASE_APPROVED'),'current':isCurrentActive('RFE_CASE_APPROVED') }"  >
        <em></em>
        <div class="status_list_cnt">
          <div class="status_title">
            <label>RFE Response Docs Approved</label>
            <template v-if="findUsers">
              <div class="info">
                <img src="@/assets/images/main/information.svg" />
                <div class="info_cnt">
                  <p>Pending with {{findUsers}}</p>
                </div>
              </div>
            </template>
          </div>
          <span v-if="getActionComplatedDate('RFE_CASE_APPROVED')">{{ getActionComplatedDate("RFE_CASE_APPROVED") | formatDateTime }}</span>
        </div>
      </li>
      <li :class="{'completed':checkActivityCompleted('RFE_REQUEST_PETITIONER_SIGN'),'current':isCurrentActive('RFE_REQUEST_PETITIONER_SIGN') }" 
      >
        <em></em>
        <div class="status_list_cnt">
          <div class="status_title">
           
            <label v-if="getTenantTypeId !=2">RFE Sent for Petitioner Signature</label>
            <label v-else>RFE Sent for Signatures</label>
            <template v-if="findUsers">
              <div class="info">
                <img src="@/assets/images/main/information.svg" />
                <div class="info_cnt">
                  <p>Pending with {{findUsers}}</p>
                </div>
              </div>
            </template>
          </div>
          <span v-if="getActionComplatedDate('RFE_REQUEST_PETITIONER_SIGN')">{{ getActionComplatedDate("RFE_REQUEST_PETITIONER_SIGN") | formatDateTime }}</span>
        </div>
      </li>
      <li :class="{'completed':checkActivityCompleted('RFE_SUBMIT_TO_USCIS')&& (!checkIworkFlowActivityRequired('RFE_COURIER_TRACKING') || (checkIworkFlowActivityRequired('RFE_COURIER_TRACKING') && checkActivityCompleted('RFE_COURIER_TRACKING') ) ),'current':isCurrentActive('RFE_SUBMIT_TO_USCIS')|| (checkActivityCompleted('RFE_COURIER_TRACKING') && isCurrentActive('RFE_COURIER_TRACKING')) }" >
        <em></em>
        <div class="status_list_cnt">
          <div class="status_title">
            <label>RFE Filed with USCIS</label>
            <template v-if="findUsers">
              <div class="info">
                <img src="@/assets/images/main/information.svg" />
                <div class="info_cnt">
                  <p>Pending with {{findUsers}}</p>
                </div>
              </div>
            </template>
          </div>
          <span v-if="getActionComplatedDate('RFE_COURIER_TRACKING')">{{ getActionComplatedDate("RFE_COURIER_TRACKING") | formatDateTime }}</span>
          <span v-else-if="getActionComplatedDate('RFE_SUBMIT_TO_USCIS')">{{ getActionComplatedDate("RFE_SUBMIT_TO_USCIS") | formatDateTime }}</span>
        </div>
      </li>
      <li v-if="checkActivityCompleted('RFE_UPDATE_USCIS_RECEIPT_NUMBER')" :class="{'completed':checkActivityCompleted('RFE_UPDATE_USCIS_RECEIPT_NUMBER'),'current':isCurrentActive('RFE_UPDATE_USCIS_RECEIPT_NUMBER') }" >
        <em></em>
        <div class="status_list_cnt">
          <div class="status_title">
            <label>RFE Receipt Received</label>
            <template v-if="findUsers">
              <div class="info">
                <img src="@/assets/images/main/information.svg" />
                <div class="info_cnt">
                  <p>Pending with {{findUsers}}</p>
                </div>
              </div>
            </template>
          </div>
          <span v-if="getActionComplatedDate('RFE_UPDATE_USCIS_RECEIPT_NUMBER')">{{ getActionComplatedDate("RFE_UPDATE_USCIS_RECEIPT_NUMBER") | formatDateTime }}</span>
        </div>
      </li>

      <li :class="{'completed':  checkActivityCompleted('RFE_USCIS_APPROVED') || checkActivityCompleted('RFE_USCIS_RECEIVED_RFE')|| checkActivityCompleted('RFE_USCIS_DENIED')
      || checkActivityCompleted('RFE_USCIS_WITHDRAWN')
      ,
      'current':isCurrentActive('FINAL_USCIS_STATUS') }" >
        <em></em>
        
        <div class="status_list_cnt">
          <div class="status_title">

          <label v-if="checkActivityCompleted('RFE_USCIS_APPROVED')">Approved </label>
          <label v-else-if="checkActivityCompleted('RFE_USCIS_RECEIVED_RFE') "  >RFE Received</label>
          <label v-else-if="checkActivityCompleted('RFE_USCIS_DENIED')">Denied</label>
          <label v-else-if="checkActivityCompleted('RFE_USCIS_WITHDRAWN')" >Withdrawn</label>
          <label v-else > RFE USCIS Response</label>
         
            
          <template v-if="findUsers">
              <div class="info">
                <img src="@/assets/images/main/information.svg" />
                <div class="info_cnt">
                  <p>Pending with {{findUsers}}</p>
                </div>
              </div>
            </template>
          </div>
          <span v-if="getActionComplatedDate('RFE_USCIS_APPROVED')">{{ getActionComplatedDate("RFE_USCIS_APPROVED") | formatDateTime }}</span>
          <span v-else-if="getActionComplatedDate('RFE_USCIS_RECEIVED_RFE')">{{ getActionComplatedDate("RFE_USCIS_RECEIVED_RFE") | formatDateTime }}</span>
          <span v-else-if="getActionComplatedDate('RFE_USCIS_DENIED')">{{ getActionComplatedDate("RFE_USCIS_DENIED") | formatDateTime }}</span>
          <span v-else-if="getActionComplatedDate('RFE_USCIS_WITHDRAWN')">{{ getActionComplatedDate("RFE_USCIS_WITHDRAWN") | formatDateTime }}</span>
          <span v-else-if="getActionComplatedDate('RFE_UPDATE_USCIS_RESPONSE')">{{ getActionComplatedDate("RFE_UPDATE_USCIS_RESPONSE") | formatDateTime }}</span>
          
        </div>

       
      </li>
      
    </template>
   </template>
  </ul>
</template>

<script>

import moment from "moment";
import _ from "lodash";
export default {
  name: "caseStatusList",
  data: function () {
    return {
      
    }
   
  },

  methods: {
    getActionStartdDate(code = "") {
      let returnValue = "";
      if (code) {
        let item = _.find(this.currentCaseDetails, { action: code });
        if (item && this.checkProperty(item, "startedOn")) {
          returnValue = item["startedOn"];
        }
      }
      return returnValue;
    },
    getActionComplatedDate(code = "") {
      let returnValue = "";
      if (code) {
        let item = _.find(this.currentCaseDetails, (log)=>{
          return this.checkProperty(log, "action") ==code && this.checkProperty(log, "endedOn")
          });
        if (item && this.checkProperty(item, "endedOn")) {
          returnValue = item["endedOn"];
        }
      }
      return returnValue;
    },
  },
  mounted() {
  
  },
  props: {
    workFlowDetails: {
      type: Object,
      default: null,
    },
    petition: {
      type: Object,
      default: null,
    },
    currentCaseDetails: {
      type: Array,
      default: [],
    },
    scannedDocumentsList: {
      type: Array,
      default: [],
    },
  },
  computed: {
    checkIworkFlowActivityRequired(){
      return (code)=>{

        if(this.checkProperty(this.workFlowDetails,'config','length')>0 ){

          let actiVity = _.find(this.workFlowDetails.config , {"code":code,"actionRequired":'Yes'});
          if(actiVity){
            return true;
          }else{
            return false;

          }
   

        }
        

      }
    },
    isCurrentActive() {
        var _self = this;
        return (item = "") => {
          switch (item) {
            case "RFE_PREPARE_RESPONSE_DOCS":
              var _ca = ["RFE_PREPARE_RESPONSE_DOCS" ];
              return (_self.petition["nextWorkflowActivity"] && _self.petition["nextWorkflowActivity"].some((r) => _ca.indexOf(r) >= 0 )) 
            case "RFE_CASE_APPROVED":
              var _ca = ["RFE_CASE_APPROVED","RFE_REVIEW_RESPONSE_DOCS" ];
              return (_self.petition["nextWorkflowActivity"] && _self.petition["nextWorkflowActivity"].some((r) => _ca.indexOf(r) >= 0 )) 
            case "RFE_REQUEST_PETITIONER_SIGN":
              var _ca = ["RFE_REQUEST_PETITIONER_SIGN" ];
              return (_self.petition["nextWorkflowActivity"] && _self.petition["nextWorkflowActivity"].some((r) => _ca.indexOf(r) >= 0 )) 
            case "RFE_SUBMIT_TO_USCIS":
              var _ca = ["RFE_SUBMIT_TO_USCIS" ];
              return (_self.petition["nextWorkflowActivity"] && _self.petition["nextWorkflowActivity"].some((r) => _ca.indexOf(r) >= 0 )) 
            case "RFE_COURIER_TRACKING":
              var _ca = ["RFE_COURIER_TRACKING" ];
              return (_self.petition["nextWorkflowActivity"] && _self.petition["nextWorkflowActivity"].some((r) => _ca.indexOf(r) >= 0 )) 
            case "RFE_UPDATE_USCIS_RECEIPT_NUMBER":
              var _ca = ["RFE_UPDATE_USCIS_RECEIPT_NUMBER" ];
              return (_self.petition["nextWorkflowActivity"] && _self.petition["nextWorkflowActivity"].some((r) => _ca.indexOf(r) >= 0 )) 
            
            case "FINAL_USCIS_STATUS":
              var _ca = ["RFE_UPDATE_USCIS_RESPONSE"];
              return (_self.petition["nextWorkflowActivity"] && _self.petition["nextWorkflowActivity"].some((r) => _ca.indexOf(r) >= 0 )) 
            
              default:
              return false;
          }
  
          return false;
        };
      },
    checkLcaRequired(){
      let returnValue =false;
      if(this.workFlowDetails && _.has(this.workFlowDetails ,'config' )){
        let lcaRequest = _.find(this.workFlowDetails.config , {"code":'LCA_REQUEST' ,"actionRequired":'Yes'});
        if(lcaRequest){
          returnValue = true
        }

      }
      return returnValue;

    },
    getLcaStatus(){
      let lcaItems = [];
     let self =this;
      let filterItems = null;

      if(this.checkProperty(this.petition,"lcaDetails","statusLogs")){
        lcaItems = this.petition['lcaDetails']['statusLogs'];
      }
      if(this.checkProperty(lcaItems, "length") >-1){
       let items= _.orderBy(lcaItems, 'createdOn' ,'desc');
        filterItems = items[0];
      }

      if(self.checkProperty(self.petition,"lcaDetails","statusDetails") ){
        if(filterItems){
          filterItems = Object.assign(filterItems,{'statusDetails':self.petition['lcaDetails']['statusDetails']});
          if(!_.has(filterItems ,"statusId")){
          filterItems = Object.assign( filterItems , { "statusId":self.petition['lcaDetails']['statusId'] } )

        }
        if( !_.has(filterItems , 'statusName')){
          filterItems = Object.assign( filterItems , { "statusName":self.petition['lcaDetails']['statusDetails']['name'] } )
        }
        }else{
          filterItems = { "statusDetails":self.petition['lcaDetails']['statusDetails'] }
          if(!_.has(filterItems ,"statusId")){
          filterItems = Object.assign( filterItems , { "statusId":self.petition['lcaDetails']['statusId'] } )

        }
        if( !_.has(filterItems , 'statusName')){
          filterItems = Object.assign( filterItems , { "statusName":self.petition['lcaDetails']['statusDetails']['name'] } )
        }
        }
      
       
      }

      

      return filterItems;
    },
    checkAssignmentsExists(){
      let isAssignmentsExists =false
      if(this.workFlowDetails && _.has(this.workFlowDetails ,'config' )){
          let assignSuperVisorActiVity = _.find(this.workFlowDetails.config , {"code":'ASSIGN_SUPERVISOR' ,"include":'Yes'});
          let paralegalactiVity = _.find(this.workFlowDetails.config , {"code":'ASSIGN_PARALEGAL',"include":'Yes'});
          let attorneyactiVity = _.find(this.workFlowDetails.config , {"code":'ASSIGN_ATTORNEY',"include":'Yes'});
          let docm = _.find(this.workFlowDetails.config , {"code":'ASSIGN_DOCUMENTATION_MANAGER',"include":'Yes'});
          let doce = _.find(this.workFlowDetails.config , {"code":'ASSIGN_DOCUMENTATION_EXECUTIVE',"include":'Yes'});
          let caseApproved = _.find(this.workFlowDetails.config , {"code":'CASE_APPROVED',"include":'Yes'});
          
            if( assignSuperVisorActiVity  || paralegalactiVity || attorneyactiVity || docm  || caseApproved){
              isAssignmentsExists =true;
            }          
                    

            }
      return  isAssignmentsExists;

    },

    //currentCaseDetails
    checkActivityCompleted(){
      return (code='')=>{
       
        if( _.has(this.petition ,"completedActivities") && this.petition['completedActivities'].indexOf(code) >-1){
          return true;
        }else{
          return false;
        }
        

      }
    },
    checkIsthisI140(){
      if(this.checkProperty(this.petition ,'typeDetails','id' )==3 && [16 ,17].indexOf(this.checkProperty(this.petition ,'subTypeDetails','id' ))>-1){
        return true;
      }else{
        return false;
      }

    },
    isActivyCompleted() {
      var _self = this;
      return (item = "") => {
        switch (item) {
          case "Questionnaire Submitted":
            var _ca = [
              "SUBMIT_TO_LAW_FIRM" ,"SUBMIT_BY_BENEFICIARY"
            ];
            return _.has(_self.petition,'completedActivities')&& _self.petition["completedActivities"] && _self.petition["completedActivities"].some(
              (r) => _ca.indexOf(r) >= 0
            );
            break;
          case "In Process":
            var _ca = [
              "CASE_APPROVED",
              "COURIER_TRACKING",
              "UPDATE_USCIS_RECEIPT_NUMBER",
              "UPDATE_USCIS_RESPONSE",
              "SUBMIT_TO_USCIS",
              "COURIER_TRACKING",
              "UPDATE_USCIS_RECEIPT_NUMBER",
              "UPDATE_USCIS_RESPONSE",
              "USCIS_APPROVED",
              "USCIS_RECEIVED_RFE",
              "USCIS_DENIED",
              "USCIS_WITHDRAWN",
              
             // "REQUEST_PETITIONER_SIGN",
            //  "REQUEST_BENEFICIARY_SIGN",
            //  "UPLOAD_SCANNED_COPY",
           //   "UPLOAD_BENEFICIARY_SCANNED_COPY"
              
            ];
              if(_self.getUserRoleId ==51){ 
              _ca.push('REQUEST_BENEFICIARY_SIGN');
              _ca.push('UPLOAD_BENEFICIARY_SCANNED_COPY');
            }else{
              _ca.push('REQUEST_PETITIONER_SIGN');
              _ca.push('UPLOAD_SCANNED_COPY');
            }

            let nextWorkflowList =[];
            var isAssignmentsExists =false;
            if(this.workFlowDetails && _.has(this.workFlowDetails ,'config' )){
          let assignSuperVisorActiVity = _.find(this.workFlowDetails.config , {"code":'ASSIGN_SUPERVISOR' ,"include":'Yes'});
          let paralegalactiVity = _.find(this.workFlowDetails.config , {"code":'ASSIGN_PARALEGAL',"include":'Yes'});
          let attorneyactiVity = _.find(this.workFlowDetails.config , {"code":'ASSIGN_ATTORNEY',"include":'Yes'});
          let docm = _.find(this.workFlowDetails.config , {"code":'ASSIGN_DOCUMENTATION_MANAGER',"include":'Yes'});
          let doce = _.find(this.workFlowDetails.config , {"code":'ASSIGN_DOCUMENTATION_EXECUTIVE',"include":'Yes'});
          let caseApproved = _.find(this.workFlowDetails.config , {"code":'CASE_APPROVED',"include":'Yes'});
          let assignCaseApprover = _.find(this.workFlowDetails.config , {"code":'ASSIGN_CASE_APPROVER',"include":'Yes'});
          
            if( assignSuperVisorActiVity  || paralegalactiVity || attorneyactiVity || docm  || doce || caseApproved || assignCaseApprover){
              isAssignmentsExists =true;
            
              nextWorkflowList =[];
            
            }else{
              nextWorkflowList =['REQUEST_PETITIONER_SIGN' ,'REQUEST_BENEFICIARY_SIGN']

            }
          
                    

            }

            return (_.has(_self.petition,'completedActivities')&& _self.petition["completedActivities"] && _self.petition["completedActivities"].some(
              (r) => _ca.indexOf(r) >= 0) ) 
              || ( isAssignmentsExists ==false && _self.petition["nextWorkflowActivity"].some((r) => nextWorkflowList.indexOf(r) >= 0) )  ;
          case "Petitioner Signature":
            var _ca = [
              "COURIER_TRACKING",
              "SUBMIT_TO_USCIS",
              "UPDATE_USCIS_RECEIPT_NUMBER",
              "UPDATE_USCIS_RESPONSE",
              "USCIS_APPROVED",
              "USCIS_RECEIVED_RFE",
              "USCIS_DENIED",
              "USCIS_WITHDRAWN",
              "GENERATED_SIGNED_DOCS",
              
            //  "REQUEST_PETITIONER_SIGN",
          //    "REQUEST_BENEFICIARY_SIGN",
          //    "UPLOAD_SCANNED_COPY",
         //     "UPLOAD_BENEFICIARY_SCANNED_COPY"
            ];
            
           //   _ca.push('REQUEST_BENEFICIARY_SIGN');
         //     _ca.push('UPLOAD_BENEFICIARY_SCANNED_COPY');
            
             // _ca.push('UPLOAD_SCANNED_COPY');
             
             if([2,10].indexOf(this.checkProperty(this.petition, 'type' ))>-1 && !this.checkProperty(this.petition,'petitionerId') ){

              _ca.push('REQUEST_BENEFICIARY_SIGN');
              if(_self.petition['completedActivities'].indexOf('REQUEST_BENEFICIARY_SIGN') >-1){
                _ca.push('UPLOAD_BENEFICIARY_SCANNED_COPY');
             }

             }else{
              _ca.push('REQUEST_PETITIONER_SIGN');
              if(_self.petition['completedActivities'].indexOf('REQUEST_PETITIONER_SIGN') >-1){
                _ca.push('UPLOAD_SCANNED_COPY');
             }
              

             }
             
           
            return (
              _.has(_self.petition ,"completedActivities") && _self.petition["completedActivities"] && _self.petition["completedActivities"].some(
                (r) => _ca.indexOf(r) >= 0
              ) 
            );
          case "Received Signed Forms":
            var _ca = [
              "COURIER_TRACKING",
              "SUBMIT_TO_USCIS",
              "UPDATE_USCIS_RECEIPT_NUMBER",
              "UPDATE_USCIS_RESPONSE",
              "USCIS_APPROVED",
              "USCIS_RECEIVED_RFE",
              "USCIS_DENIED",
              "USCIS_WITHDRAWN",
              //"UPLOAD_SCANNED_COPY",
             // "UPLOAD_BENEFICIARY_SCANNED_COPY"
            ];
            if([2,10].indexOf(this.checkProperty(this.petition, 'type' ))>-1 && !this.checkProperty(this.petition,'petitionerId') ){
              if(_self.petition['completedActivities'].indexOf('REQUEST_BENEFICIARY_SIGN') >-1){
                _ca.push('UPLOAD_BENEFICIARY_SCANNED_COPY');
             }
            }
            if(_self.getUserRoleId ==51){ 
             // _ca.push('REQUEST_BENEFICIARY_SIGN');
             if(_self.petition['completedActivities'].indexOf('REQUEST_BENEFICIARY_SIGN') >-1){
                _ca.push('UPLOAD_BENEFICIARY_SCANNED_COPY');
             }
              
            }else{
           //   _ca.push('REQUEST_PETITIONER_SIGN');
             // _ca.push('UPLOAD_BENEFICIARY_SCANNED_COPY');
             if(_self.petition['completedActivities'].indexOf('REQUEST_PETITIONER_SIGN') >-1){
                _ca.push('UPLOAD_SCANNED_COPY');
             }

             // _ca.push('UPLOAD_SCANNED_COPY');
            }
            return (
              _.has(_self.petition ,"completedActivities") && _self.petition["completedActivities"] && _self.petition["completedActivities"].some(
                (r) => _ca.indexOf(r) >= 0
              ) 
              //|| (_self.scannedDocumentsList && _self.scannedDocumentsList.length > 0)
            );
          case "Submitted to USCIS":
            var _ca = [
              "SUBMIT_TO_USCIS",
              "COURIER_TRACKING",
              "UPDATE_USCIS_RECEIPT_NUMBER",
              "UPDATE_USCIS_RESPONSE",
              "USCIS_APPROVED",
              "USCIS_RECEIVED_RFE",
              "USCIS_DENIED",
              "USCIS_WITHDRAWN",
              //"UPLOAD_SCANNED_COPY"
            ];
            return _.has(_self.petition ,"completedActivities") && _self.petition["completedActivities"] && _self.petition["completedActivities"].some(
              (r) => _ca.indexOf(r) >= 0
            );
          case "Receipt Received":
            var _ca = [
              "UPDATE_USCIS_RECEIPT_NUMBER",
              "USCIS_APPROVED",
              "USCIS_RECEIVED_RFE",
              "USCIS_DENIED",
              "USCIS_WITHDRAWN",
            ];
            return _.has(_self.petition ,"completedActivities") && _self.petition["completedActivities"] && _self.petition["completedActivities"].some(
              (r) => _ca.indexOf(r) >= 0
            );
          case "USCIS Response":
            var _ca = [
              "USCIS_APPROVED",
              "USCIS_RECEIVED_RFE",
              "USCIS_DENIED",
              "USCIS_WITHDRAWN",
            ];
            return _.has(_self.petition ,"completedActivities") && _self.petition["completedActivities"] &&  _self.petition["completedActivities"].some(
              (r) => _ca.indexOf(r) >= 0
            );
          default:
            return false;
        }

        return false;
      };
    },
    isActivyActive() {
      var _self = this;
      return (item = "") => {
        switch (item) {
          case "Questionnaire Submitted":
            var _ca = ["SUBMIT_TO_LAW_FIRM" ,"SUBMIT_BY_BENEFICIARY"];
            return  _.has(_self.petition ,"completedActivities") && _self.petition["completedActivities"].indexOf("SUBMIT_TO_LAW_FIRM") <= -1 && _self.petition["nextWorkflowActivity"] && _self.petition["nextWorkflowActivity"].some((r) => _ca.indexOf(r) >= 0);
            break;
          case "In Process":
            var _ca = [
             // "ASSIGN_SUPERVISOR",
            //   "ASSIGN_PARALEGAL",
            //  "ASSIGN_DOCUMENTATION_MANAGER",
            //  "ASSIGN_DOCUMENTATION_EXECUTIVE",
            //  "ASSIGN_ATTORNEY",
            //  "ASSIGN_CASE_APPROVER",
            //  "CASE_APPROVED",
              "REQUEST_PETITIONER_SIGN"
            ];
            if([2,10].indexOf(this.checkProperty(this.petition, 'type' ))>-1 && !this.checkProperty(this.petition,'petitionerId') ){
              var _ca = [];
              _ca.push('REQUEST_BENEFICIARY_SIGN');
             //_ca.push('UPLOAD_BENEFICIARY_SCANNED_COPY');
            }

            var isAssignmentsExists =false;
            if(this.workFlowDetails && _.has(this.workFlowDetails ,'config' )){
          let assignSuperVisorActiVity = _.find(this.workFlowDetails.config , {"code":'ASSIGN_SUPERVISOR' ,"include":'Yes'});
          let paralegalactiVity = _.find(this.workFlowDetails.config , {"code":'ASSIGN_PARALEGAL',"include":'Yes'});
          let attorneyactiVity = _.find(this.workFlowDetails.config , {"code":'ASSIGN_ATTORNEY',"include":'Yes'});
          let docm = _.find(this.workFlowDetails.config , {"code":'ASSIGN_DOCUMENTATION_MANAGER',"include":'Yes'});
          let doce = _.find(this.workFlowDetails.config , {"code":'ASSIGN_DOCUMENTATION_EXECUTIVE',"include":'Yes'});
          let assignCaseApprover = _.find(this.workFlowDetails.config , {"code":'ASSIGN_CASE_APPROVER',"include":'Yes'});
          let caseApproved = _.find(this.workFlowDetails.config , {"code":'CASE_APPROVED',"include":'Yes'});
          
          if(assignSuperVisorActiVity ){
            isAssignmentsExists =true;
            _ca.push('ASSIGN_SUPERVISOR');
          }
          if(paralegalactiVity  ){
            isAssignmentsExists =true;
            _ca.push('ASSIGN_PARALEGAL');
          }
          if(attorneyactiVity   ){
            isAssignmentsExists =true;
            _ca.push('ASSIGN_ATTORNEY');
          }

          if(docm  ){
            isAssignmentsExists =true;
            _ca.push('ASSIGN_DOCUMENTATION_MANAGER');
          }
          if(doce  ){
            isAssignmentsExists =true;
            _ca.push('ASSIGN_DOCUMENTATION_EXECUTIVE');
          }
          if(caseApproved){
            isAssignmentsExists =true;
            _ca.push('CASE_APPROVED');
          }
          if(assignCaseApprover){
            _ca.push('ASSIGN_CASE_APPROVER');
          }


          

            }
          return  _.has(_self.petition ,"completedActivities") && _self.petition["completedActivities"].indexOf("SUBMIT_TO_LAW_FIRM") > -1 && _self.petition["nextWorkflowActivity"] && _self.petition["nextWorkflowActivity"].some((r) => _ca.indexOf(r) >= 0 && isAssignmentsExists);
          case "Petitioner Signature":
            var _ca = [];
            if(_self.getUserRoleId ==51){ 
              _ca.push('REQUEST_BENEFICIARY_SIGN');
             // _ca.push('UPLOAD_BENEFICIARY_SCANNED_COPY');
            }else{
              _ca.push('REQUEST_PETITIONER_SIGN');
             // _ca.push('UPLOAD_SCANNED_COPY');
            }

            if([2,10].indexOf(this.checkProperty(this.petition, 'type' ))>-1 && !this.checkProperty(this.petition,'petitionerId') ){
              var _ca = [];
              _ca.push('REQUEST_BENEFICIARY_SIGN');
             //_ca.push('UPLOAD_BENEFICIARY_SCANNED_COPY');
            }
            return _self.petition["nextWorkflowActivity"] && _self.petition["nextWorkflowActivity"].some(
                (r) => _ca.indexOf(r) >= 0
              );
          case "Received Signed Forms":
            var _ca = [];
            let activityCode ="REQUEST_PETITIONER_SIGN";

            if([2,10].indexOf(this.checkProperty(this.petition, 'type' ))>-1 && !this.checkProperty(this.petition,'petitionerId') ){
              activityCode ="REQUEST_BENEFICIARY_SIGN";
            }
            
            //return _self.petition["nextWorkflowActivity"] && _self.petition["nextWorkflowActivity"].some( (r) => _ca.indexOf(r) >= 0);
            return _self.petition["completedActivities"].indexOf(activityCode)>-1 && (_self.petition["completedActivities"].indexOf('UPLOAD_SCANNED_COPY') <=-1)
          case "Submitted to USCIS":
           
            var _ca = ['COURIER_TRACKING' ,'SUBMIT_TO_USCIS'];
            let checkUploads =false;
            if( _self.petition["completedActivities"].indexOf('UPLOAD_SCANNED_COPY')>-1){
              checkUploads =true;
            }else if([2,10].indexOf(_self.petition["type"])>-1 && _self.petition["completedActivities"].indexOf('UPLOAD_BENEFICIARY_SCANNED_COPY')>-1 ){
              checkUploads =true;
            }
           
            
           return (_self.petition["nextWorkflowActivity"] && _self.petition["nextWorkflowActivity"].some((r) => _ca.indexOf(r) >= 0 ) && checkUploads && _self.petition["completedActivities"].indexOf('SUBMIT_TO_USCIS')<=-1 
               // || (_self.petition["nextWorkflowActivity"].indexOf('REQUEST_PETITIONER_SIGN')>-1 && _self.petition["completedActivities"].indexOf('REQUEST_BENEFICIARY_SIGN') >-1 )|| ( _self.petition["nextWorkflowActivity"].indexOf('REQUEST_BENEFICIARY_SIGN')>-1 && _self.petition["completedActivities"].indexOf('REQUEST_PETITIONER_SIGN') >-1  )
             // || this.scannedDocumentsList && this.scannedDocumentsList.length > 0
          ) 
            
          case "Receipt Received":
            var _ca = ["UPDATE_USCIS_RECEIPT_NUMBER" ,'COURIER_TRACKING'];
            return (_self.petition["nextWorkflowActivity"] && _self.petition["nextWorkflowActivity"].some((r) => _ca.indexOf(r) >= 0 )) 
          case "USCIS Response":
            var _ca = ["UPDATE_USCIS_RECEIPT_NUMBER"];
            return _ca.indexOf(_self.petition["currentActivity"]) >= 0;
          default:
            return false;
        }

        return false;
      };
    },

    findUsers() {
      let self = this;
      let returnVal = "";
      let allUsers = [];
      let selectedUsers = [];
      let filterItems = _.filter(this.currentCaseDetails, (item) => {
        return (
          !_.has(item, "endedOn") || item.endedOn == null || item.endedOn == ""
        );
      });
      if (self.checkProperty(filterItems, "length") > 0) {
        _.forEach(filterItems, (obj) => {
          if (self.checkProperty(obj, "users", "length") > 0) {
            let users = obj["users"];
            _.forEach(users, (user, ind) => {
              let userName = user["name"] + " (" + user["roleName"] + ")";
              if (selectedUsers.indexOf(user["_id"]) <= -1) {
                allUsers.push(_.cloneDeep(userName));
              }
              selectedUsers.push(user["_id"]);
            });
          }
        });
      }
      if (allUsers.length > 0) {
        returnVal = allUsers.join(", ");
      }
      return returnVal;
    },

    getupdatebenficiaryLog(){
         let self =this;
         
        
         let benficiaryFinalLog =null;
         let tempBenficiaryFinalLog = [];
        
         _.forEach(this.currentCaseDetails,(item)=>{
               if(['UPDATE_USCIS_RESPONSE'].indexOf(item['action']) >-1){


                  if(_.has(item ,'endedOn') && item['endedOn'] && !this.checkProperty(item ,'ignore')){


                     
                   
                     if(_.has(item ,'endedOn') && item['endedOn']){
                        item['endedOn'] = moment(item['endedOn'])
   
                     }
                     if(_.has(item ,'startedOn') && item['startedOn']){
                        item['startedOn'] = moment(item['startedOn'])
   

                     }
                     if(self.checkProperty( item,'data' ,'rfeNotice')){
                     


                     //tempBenficiaryFinalLog
                     if( self.checkProperty(item, 'data','userCatergoryCode') =='beneficairy'){
                        tempBenficiaryFinalLog.push(item);
                     }
                  }


                    
                     
                    
                     //self.h4UscisLogs  = _.orderBy(self.h4UscisLogs ,['endedOn'] ,['desc'] );
                  }
                  
                  
               }
          } );
       
          if(tempBenficiaryFinalLog.length>0){
            tempBenficiaryFinalLog  = _.orderBy(tempBenficiaryFinalLog ,['endedOn'] ,['desc'] );
            benficiaryFinalLog = tempBenficiaryFinalLog[0];

          }
          return benficiaryFinalLog;
          

      },

  },
};
</script>