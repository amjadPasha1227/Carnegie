<template>
    <div class="row" style="padding: 5px;">dgfdg
        <div class="col-md-12">
            <div class="container-fluid">
                <span>
                    <strong>{{mention.name}} </strong> - {{mention.roleName}}</span>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        props:{
            mention: {
                type: Object,
                required: true
            }
        }
    }
</script>

<style scoped>
</style>