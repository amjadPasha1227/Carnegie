<template>
   
      <div class="card-panels pt-0">
        
     
        <div class="main-list-wrap forms_title mb-0 fees_actions">
      
          <div >
          <ul class="items-list" v-if="checkProperty(petition ,'filingFeeDetails') && checkProperty(petition,'filingFeeDetails','amount') > 0 ">
           
            <!-- <li>Status<span>Raised</span></li>
            <li>Last Updated <span>{{petition.filingFeeDetails.createdOn | formatDate}}</span></li> -->
            <li>Total Amount<span>{{formatprice(totalInvoiceAmountPaid)}}</span></li>
            <li>Paid Amount<span>{{formatprice(partlyPaidAmountt)}}</span></li>
            <li>Due Amount<span>{{formatprice(totalDueAmount)}}</span></li>
            <li v-if="checkProperty(petition['filingFeeDetails'],'statusDetails','name')">
              <span :class="{'status_invite':checkProperty(petition['filingFeeDetails'],'statusDetails','id')==1 ,'status_fullypaid':checkProperty(petition['filingFeeDetails'],'statusDetails','id')==6, 'status_partiallypaid':checkProperty(petition['filingFeeDetails'],'statusDetails','id')==5 }"
              
              class="ml-0 status-btn2 status_sent">{{checkProperty(petition['filingFeeDetails'],'statusDetails','name')}}</span></li>
          

          </ul>
          </div>
          
          <!-- canPreParePermApplication || -->
          <div class="actions-btn-list" v-if="checkProperty(petition, 'completedActivities', 'length')>0 && (petition.completedActivities.indexOf('SUBMIT_TO_LAW_FIRM') >-1 || [9].indexOf(checkProperty(petition,'typeDetails', 'id')) >-1)"> 
            <ul>
             
              <li v-if="checkFIlingFeeEditPermession && checkProperty(getPetitionDetails ,'status' )!=false && checkCreateButton  "> 
                <span v-if="checkProperty(petition ,'invoiceId') "  class="items_edit" @click="updateFilingFee(true) ">
                  <img src="@/assets/images/main/icon-edit.svg" />Edit
                </span>
                <span  v-else class="items_edit" @click="updateFilingFee(false)">
                  <img src="@/assets/images/main/icon-edit.svg" />Enter Filing Fees
                </span>
              </li>

              <li v-if="checkCompletePaymentBtn">
                <vs-button class="light-blue-btn btn_primary ml-2 payment_action"   @click="opencreatePopup()">
                  Complete Payment
                </vs-button>
              </li>

            </ul>
          </div>
        </div>

        <div class="text-danger text-sm formerrors" v-if=" (newlyAddInvoiceItems.length>0 || removedInvoiceItems.length>0 ) && ( checkFIlingFeeEditPermession && checkProperty(getPetitionDetails ,'status' )!=false && checkCreateButton )">
          <vs-alert color="warning"  class="warning-alert reg-warning-alert no-border-radius"  icon-pack="IntakePortal"  icon="IP-information-button"
            active="true"   >
            <template >
            We have observed that, There is a change in the case details and it will required to update the invoice. <span class="buttonlink" @click="updateFilingFee(true)">Click here</span> to update the Invoice.
            </template>
            
          </vs-alert>
          
          </div>
          
        <div >
          <div class="accordian-table filingdata_table pad0">
            <template v-if="checkProperty(petition ,'filingFeeDetails','feeDetails') && (petition.filingFeeDetails.feeDetails.length>0)">
            <template v-if="checkProperty(petition ,'filingFeeDetails','feeDetails') && (petition.filingFeeDetails.feeDetails.length>0) && checkProperty(petition,'filingFeeCategoryType')=='pre_defined'" >
                <vs-table :data="petition.filingFeeDetails.feeDetails" class="fees_table pt-5"> 
                  <template slot="thead">
                    <vs-th>
                      Fee Type   
                    </vs-th>
                    <vs-th>
                      Amount
                    </vs-th>
                    <vs-th >
                      Exclude from invoice
                    </vs-th> 
                  </template>

                  <template slot-scope="{data}">
                    <vs-tr>
                        <vs-td colspan="3"> 
                            <h3 class="small-header pt-0 pb-0 mb-0">USCIS Fees</h3>
                        </vs-td>
                    </vs-tr>
                    <vs-tr v-for="filingfee in data" :key="filingfee" v-if="filingfee.descriptionType=='USCIS'">
                      
                      <vs-td v-html="filingfee.description">
                        
                      </vs-td>

                      <vs-td>
                        {{formatprice(filingfee.amount)}}
                      </vs-td>

                      <vs-td>
                        <template v-if="filingfee.invoice">
                          <img   src="@/assets/images/main/checkmark.svg">
                      </template>
                      <template v-else>N/A</template>
                        

                      </vs-td>
                    </vs-tr>
                    <vs-tr>
                        <vs-td colspan="3"> 
                            <h3 class="small-header pt-0 pb-0 mb-0">Attorney Fees</h3>
                        </vs-td>
                    </vs-tr>
                    <vs-tr v-for="filingfee in data" :key="filingfee" v-if="filingfee.descriptionType=='Internal'"> 
                      <vs-td v-html="filingfee.description">  
                      </vs-td>
                      <vs-td>
                        {{formatprice(filingfee.amount)}}
                      </vs-td>
                      <vs-td>
                        <template v-if="filingfee.invoice">
                          <img   src="@/assets/images/main/checkmark.svg">
                        </template>
                        <template v-else>N/A</template>
                      </vs-td>
                    </vs-tr>
                  </template>
                </vs-table>
              </template>
              <template v-else>
                <vs-table :data="petition.filingFeeDetails.feeDetails" class="fees_table pt-5"> 
                  <template slot="thead">
                    <vs-th>
                      Fee Type   
                    </vs-th>
                    <vs-th>
                      Amount
                    </vs-th>
                    <vs-th >
                      Exclude from invoice
                    </vs-th> 
                  </template>

                  <template slot-scope="{data}">
                      <vs-tr v-for="filingfee in data" :key="filingfee" >
                        <vs-td v-html="filingfee.description">
                          
                        </vs-td>

                        <vs-td>
                          {{formatprice(filingfee.amount)}}
                        </vs-td>

                        <vs-td>
                          <template v-if="filingfee.invoice">
                             <img   src="@/assets/images/main/checkmark.svg">
                        </template>
                        <template v-else>N/A</template>
                          

                        </vs-td>
                      </vs-tr>
                    </template>
                </vs-table>
              </template>
            </template>
              <template v-if="!(checkProperty(petition ,'filingFeeDetails','feeDetails') && (petition.filingFeeDetails.feeDetails.length>0))"> 
             
                <NoDataFound ref="NoDataFoundRef" :loading="false" content="" heading="No Fees/Invoices Found" type='Fees/Invoices' />
              </template>
           
            
          </div>

          
 
        </div>
        <template v-if="checkProperty(petition ,'filingFeeDetails','partlyPaidLogs') && (petition.filingFeeDetails.partlyPaidLogs.length>0)" >
          <paymentList :petition="petition" />
        </template>
       
        <template v-if="(checkProperty(petition,'filingFeeDocs') && checkProperty(petition ,'filingFeeDocs', 'cheques') && checkProperty(petition['filingFeeDocs'],'cheques','length')>0)">
         <div class="px-6">
          <documentsView @download_or_view="download_or_view" :type="'Cheques'" :label="'Cheques'"  :documentsList="petition['filingFeeDocs']['cheques']" :petitionDetails="petition" />
         </div>
        </template>
        <addPayment
      @updatepetition="updatepetition"
      :petitionDetails="petition"
      :ACTIVITYCODE="ACTIVITYCODE"
      @hideMe="addPaymentPopup = false ;"
      v-if="addPaymentPopup"
    />
       
      </div>
     



   
</template>

<script>
import documentsView from "@/views/common/documentsView.vue";
const formatter = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  minimumFractionDigits: 2
});

import addPayment from "@/views/actionpopups/perm/addPayment.vue"; 
import paymentList from "@/views/petition/paymentList.vue"
import FileUpload from "vue-upload-component/src";
import moment from "moment";
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import NoDataFound from "@/views/common/noData.vue";
import _ from "lodash";

export default {
  computed:{
    checkCompletePaymentBtn(){
       let returnVal =false;
      if(this.workFlowDetails && _.has(this.workFlowDetails ,'config') ){
       
        let enableFilingFee = false;
        let filingEditors =[];
        let isAdmin =false;
        let adminsList =[];
          let adminsactiVityList = _.find(this.workFlowDetails.config , {"code":'MANAGER_LIST'});
        if(adminsactiVityList && adminsactiVityList.editors){
        
           adminsList = _.map(adminsactiVityList.editors, 'roleId');
        }
       
        let filingFeeActivity = _.find(this.workFlowDetails.config , {"code":'FILING_FEE'});
        if(filingFeeActivity && filingFeeActivity.actionRequired == "Yes"){
        
          enableFilingFee = true;
         filingEditors =_.map(filingFeeActivity.editors, 'roleId');
        }

          
          isAdmin = adminsList.indexOf(this.getUserRoleId) > -1
     
          if((  isAdmin || filingEditors.indexOf(this.getUserRoleId) > -1) && this.checkProperty(this.petition ,'invoiceId') && enableFilingFee && this.checkProperty( this.petition ,'invoiceDetails' ,'statusId') < 6  ){
            returnVal =true;
          }
        }
        return returnVal

      
    },
    checkCreateButton(){
      let returnValue =true;
      if(this.loadedFromPreview==true || (this.checkProperty(this.petition ,'intStatusId')) !=1){
        returnValue =false;
      }

      return returnValue;


    },
    checkInvoiceExists(){
      if(_.get( this.petition ,'filingFeeDetails.feeDetails')){

        let invoiceItems =_.filter(this.petition.filingFeeDetails.feeDetails ,{ "invoice":true});
      if(invoiceItems && invoiceItems.length>0){
        return true;
      }else{
        return false;
      }

      }else{
        return false
      }
      

    },
  },
  props: {
    loadedFromPreview:false,
     currentRole:null,
     currentUser:null,
    petition: {
      type: Object,
      default: null
    },
    workFlowDetails: {
      type: Object,
      default: null,
    },
  },
  components: {
    documentsView,
    addPayment,
    paymentList,
    FileUpload,
    VuePerfectScrollbar,
    NoDataFound
  },
  
  watch: {
    'petition'(val) {
     
      this.checkPaidAmount()

    }
  },
  methods: {
    getListcat(){
      this.invoiceNotification ='';
      this.removedInvoiceItems =[];
      this.newlyAddInvoiceItems =[];
      let self = this;
      let payload={  petitionId:'' }
    
      payload['petitionId'] = this.petition['_id']
      self.$store.dispatch("getList",{data:payload ,path:'/invoices/get-filing-fee-categories'} )
      .then((response) => {
        self.invoicecategoryList = response;


        if(this.checkProperty(this.petition ,'invoiceId')  && this.checkProperty(this.petition ,'filingFeeCategoryType') =="pre_defined" && this.invoicecategoryList.length>0){
         let filingFeeData = _.cloneDeep(this.petition.filingFeeDetails.feeDetails);
         //descriptionId
         let finalItems =[];
         _.forEach(filingFeeData ,(dbInvoice)=>{
            let isExistsInML = _.find(this.invoicecategoryList ,{ "id": dbInvoice['descriptionId']});
            if(isExistsInML){
              finalItems.push(dbInvoice);
            }else{
              this.removedInvoiceItems.push(dbInvoice);
            }

         })
         _.forEach(this.invoicecategoryList ,(invCat)=>{
            let isExistsInML = _.find(filingFeeData ,{ "descriptionId": invCat['id']});
            let isAlreadyExists  = _.find(finalItems ,{ "descriptionId": invCat['id']});

            if(!isExistsInML && !isAlreadyExists){

            let item = {  amount: null, description: "",  invoice: false,"descriptionId":''  };

            item['description'] = this.checkProperty(invCat ,"name");
            item['amount'] = this.checkProperty(invCat ,"amount");
            item['descriptionId'] = this.checkProperty(invCat ,"id");
            item['descriptionType'] = this.checkProperty(invCat,"type");
            item['newly_add'] = true;
            finalItems.push(item);
            }

         })
         /*
         this.totalInvoiceAmountPaid
         this.partlyPaidAmountt
         this.totalDueAmount
         */


        
      //this.totalPaidAmount;
      let newlyAddedfeeItems = _.filter(finalItems,{'newly_add':true} );
     
     if(newlyAddedfeeItems && this.checkProperty(newlyAddedfeeItems ,'length' )>0 ){
      this.newlyAddInvoiceItems = _.cloneDeep(newlyAddedfeeItems);
      let allItemsDescription = [];
    _.forEach(newlyAddedfeeItems ,(item)=>{
      if(self.checkProperty(item ,'description' )){
            allItemsDescription.push(item.description)
          }
          if(allItemsDescription.length>0){
            self.invoiceNotification =allItemsDescription.join();
          }
        });

        let totalInvoiceAmount = 0
      
        finalItems.forEach(item => {
          if(!item.invoice){
            totalInvoiceAmount += parseInt(item.amount);

          }
          
        });
       // alert("totalInvoiceAmount ="+totalInvoiceAmount +" old totalInvoiceAmount ="+self.partlyPaidAmountt);
        if(totalInvoiceAmount> self.totalInvoiceAmountPaid){
          
        }


      }
     
         

        }

          
              
      }).catch((err)=>{
        
      });
    
    },
    download_or_view(item){
     // alert();
      this.$emit('download_or_view',item);
    },
    updatepetition(){
     
      this.$route['params']['tabname']= 'Fees/Invoices';
      this.$emit("updatepetition" ,'Fees/Invoices');
     
          

    },
    opencreatePopup(){
      //this.$refs["actionsPopup"].openaddPaymentPopup('ADD_PAYMENT');
      this.ACTIVITYCODE = 'ADD_PAYMENT';
     this.addPaymentPopup =true;
    },
    commonMethod(){
      if(this.workFlowDetails && _.has(this.workFlowDetails ,'config') ){
          let adminsactiVityList = _.find(this.workFlowDetails.config , {"code":'MANAGER_LIST'});
        if(adminsactiVityList && adminsactiVityList.editors){
        
           this.adminsList = _.map(adminsactiVityList.editors, 'roleId');
        }
        this.enableFilingFee = false;
        this.filingEditors =[];
        let filingFeeActivity = _.find(this.workFlowDetails.config , {"code":'FILING_FEE'});
        if(filingFeeActivity && filingFeeActivity.actionRequired == "Yes"){
        
          this.enableFilingFee = true;
          //alert(this.enableFilingFee)
          this.filingEditors =_.map(filingFeeActivity.editors, 'roleId');
        }

          this.canPreParePermApplication = this.preparePermActivity.indexOf(this.getUserRoleId) > -1; 
          this.isAdmin = this.adminsList.indexOf(this.getUserRoleId) > -1
     }
      // alert(this.canPreParePermApplication)
      // alert(this.isAdmin)
    },
    checkPaidAmount(){
      let totalInvoiceAmount = 0
      let totalPaidAmount = 0
      if(this.checkProperty(this.petition,'filingFeeDetails','feeDetails') && this.checkProperty(this.petition['filingFeeDetails'],'feeDetails','length')>0 ){
        let filingfeeList = _.cloneDeep(this.checkProperty(this.petition,'filingFeeDetails','feeDetails'))
        filingfeeList.forEach(item => {
          if(!item.invoice){
            totalInvoiceAmount += item.amount;
          }
        });
      }
      //alert(totalInvoiceAmount)
      if(totalInvoiceAmount != 0){
        this.totalInvoiceAmountPaid = totalInvoiceAmount
        
      }
      if(this.checkProperty(this.petition,'filingFeeDetails','partlyPaidLogs') && this.checkProperty(this.petition['filingFeeDetails'],'partlyPaidLogs','length')>0 ){
        let filingfeeList = _.cloneDeep(this.checkProperty(this.petition,'filingFeeDetails','partlyPaidLogs'))
        filingfeeList.forEach(item => {
          totalPaidAmount += item.amount;
        });
      }
      if(totalPaidAmount != 0){
        this.partlyPaidAmountt= totalPaidAmount
        //alert(this.partlyPaidAmountt)
      }
      if(this.partlyPaidAmountt == 0 && this.totalInvoiceAmountPaid ){
        this.totalDueAmount = this.totalInvoiceAmountPaid 
        //alert( this.totalDueAmount)
      }
      if(this.partlyPaidAmountt && this.totalInvoiceAmountPaid ){
        this.totalDueAmount = this.totalInvoiceAmountPaid - this.partlyPaidAmountt
      }
      this.getListcat();
      this.isCompleted = true
      
  },
      formatprice(amount) {
      return formatter.format(amount);
    },
    updateFilingFee(action=true) {
      this.$emit("showfilingFeesPopup" ,action);
      
    },
    init(){
      
      this.checkPaidAmount()
    this.commonMethod();
    setTimeout(() => {
      this.commonMethod();
      this.checkPaidAmount()
    }, 100);
    
    
   

    this.updateLoading(false);
    // if(this.checkProperty(this.petition,'filingFeeDetails','feeDetails') && this.checkProperty(this.petition['filingFeeDetails'],'feeDetails','length')>0 ){
    //   this.checkPaidAmount()
    // }
   
   
    }
  },
  data: () => ({
    invoiceNotification:'',
    removedInvoiceItems:[],
    newlyAddInvoiceItems:[],
    invoicecategoryList:[],
    preparePermActivity:[],
    addPaymentPopup:false,
    ACTIVITYCODE:null,
    filingEditors:[],
    enableFilingFee:false,
    adminsList:[3,4],
    isAdmin:false,
    canPreParePermApplication:null,
    isCompleted:false,
    partlyPaidAmountt:0,
  totalInvoiceAmountPaid:0,
  totalDueAmount:0,
  }),
  mounted() {
    this.init();   
    
    
   
  }
};
</script>