<template>

  <!----
    Initiated
Questionnaire Submitted
Job Description
PWD Filed
PWD Response
Advertisements
PERM Draft Created
PERM Draft Approved
PERM Filed
DOL Response
    
  -->

    <ul>
    

          <li class="completed">
         
            <em></em>
            <div class="status_list_cnt">
              <div class="status_title">
                <label>Initiated </label>   
              </div>
              
             <!--- {{checkProperty(getPetitionDetails ,'curWorkflowActivity')}}-->
             
           
              <span v-if="this.checkProperty(getPetitionDetails ,'createdOn')">{{(this.checkProperty(getPetitionDetails ,'createdOn')) | formatDateTime}}</span>
            </div>             
          </li>

         

          <li :class="{
            'completed':checkCaseStatusCompleted('Questionnaire Submitted'),
            'current':checkIsCurrentActivity('Questionnaire Submitted')}">
            <em></em>
            <div class="status_list_cnt">
              <div class="status_title">
                <label>Questionnaire Submitted</label>
                <template v-if="(!checkProperty(getPetitionDetails, 'questionnaireFilled') || getCompletedActivities.indexOf('SUBMIT_TO_LAW_FIRM')<=-1)" >
                <div class="info" v-if="checkIsCurrentActivity('Questionnaire Submitted') && findUsers('SUBMIT_BY_BENEFICIARY') && [50,51].indexOf(getUserRoleId) <= -1" >
                    <img  src="@/assets/images/main/information.svg" />
                    <div class="info_cnt">
                      <!-----findUsers('SUBMIT_TO_LAW_FIRM')-->
                     <p>Pending with  {{findUsers('SUBMIT_BY_BENEFICIARY')}}</p>
                    </div>
                </div>
                </template>
              </div>     
              <span v-if="checkProperty(getPetitionDetails, 'questionnaireFilled') && getActionComplatedDate('SUBMIT_BY_BENEFICIARY')">{{getActionComplatedDate('SUBMIT_BY_BENEFICIARY') | formatDateTime}}</span>
            </div>
                        
          </li>

          <li :class="{
            'completed':checkCaseStatusCompleted('Job Description') ||( ['Filed','Certified'].indexOf(checkProperty(petition, 'pwdStatus'))>-1  || getCompletedActivities.indexOf('EFILE_PWD')>-1 || getCompletedActivities.indexOf('PWD_CERTIFID')>-1 ||  getCompletedActivities.indexOf('COLLECT_ADV_EVIDENCE')>-1),
            'current':checkIsCurrentActivity('Job Description') && getCompletedActivities.indexOf('SUBMIT_TO_LAW_FIRM')>-1 && !checkProperty(petition ,'hasJobDetails') && !(getCompletedActivities.indexOf('EFILE_PWD')>-1 || getCompletedActivities.indexOf('PWD_CERTIFID')>-1) }"  >
            <em></em>
            <div class="status_list_cnt">
              <div class="status_title">
                <label>Job Description </label>
                <template v-if="(checkProperty(getPetitionDetails, 'questionnaireFilled') && getCompletedActivities.indexOf('FINALIZE_JOB_DESC')<=-1)">
                <div class="info" v-if=" (checkIsCurrentActivity('Job Description') && (findUsers('CREATE_JOB_DESC') || findUsers('REQUEST_JOB_DESC_REVIEW') || findUsers('JOB_DESC_SUGGESSION') ||
                 findUsers('APPROVE_JOB_DESC') || findUsers('FINALIZE_JOB_DESC') ) && [50,51].indexOf(getUserRoleId) <= -1 && getCompletedActivities.indexOf('SUBMIT_BY_BENEFICIARY')>-1 && getCompletedActivities.indexOf('SUBMIT_TO_LAW_FIRM')>-1) || ( findUsers('INTERNAL_APPROVE_JOB_DESC') || findUsers('INTERNAL_REQUEST_JOB_DESC_REVIEW'))" >
                    <img  src="@/assets/images/main/information.svg" />
                    <div class="info_cnt">
                     <p>Pending with  <a href="#"></a> 
                      <template v-if="findUsers('CREATE_JOB_DESC')">  {{findUsers('CREATE_JOB_DESC')}}  </template>
                      <template v-else-if="findUsers('REQUEST_JOB_DESC_REVIEW')">  {{findUsers('REQUEST_JOB_DESC_REVIEW')}}  </template>
                      <template v-else-if="findUsers('INTERNAL_APPROVE_JOB_DESC')">  {{findUsers('INTERNAL_APPROVE_JOB_DESC')}}  </template>
                      <template v-else-if="findUsers('INTERNAL_REQUEST_JOB_DESC_REVIEW')">  {{findUsers('INTERNAL_REQUEST_JOB_DESC_REVIEW')}}  </template>
                      <template v-else-if="findUsers('JOB_DESC_SUGGESSION')">  {{findUsers('JOB_DESC_SUGGESSION')}}  </template>
                      <template v-else-if="findUsers('APPROVE_JOB_DESC')">  {{findUsers('APPROVE_JOB_DESC')}}  </template>
                      <template v-else-if="findUsers('FINALIZE_JOB_DESC')">  {{findUsers('FINALIZE_JOB_DESC')}} </template>
                    </p>
                    </div>
                </div>
                </template>
              </div>
              <span v-if="checkProperty(petition, 'pwdLinkedOn')">{{checkProperty(petition, 'pwdLinkedOn') | formatDateTime}}</span>
              <span v-else-if="getActionComplatedDate('FINALIZE_JOB_DESC')">{{getActionComplatedDate('FINALIZE_JOB_DESC') | formatDateTime}}</span>
              <span v-else-if="checkProperty(petition ,'filedPwdUpdatedOn')">{{ checkProperty(petition ,'filedPwdUpdatedOn') | formatDateTime}}</span>
              <span v-else-if="checkProperty(petition ,'certifiedPwdUpdatedOn')">{{ checkProperty(petition ,'certifiedPwdUpdatedOn') | formatDateTime}}</span>
              
            </div>
          </li>

          <li 
          v-if="( 
            ( getCompletedActivities.indexOf('PWD_CERTIFID') >-1 &&( ['Filed'].indexOf(checkProperty(petition, 'pwdStatus'))>-1 || getCompletedActivities.indexOf('EFILE_PWD') >-1  )  )
           || (getCompletedActivities.indexOf('PWD_CERTIFID') <=-1)
           )" 
            :class="{
            'completed':checkCaseStatusCompleted('PWD Filed') ||( ['Filed','Certified'].indexOf(checkProperty(petition, 'pwdStatus'))>-1 || getCompletedActivities.indexOf('PWD_CERTIFID')>-1),
            'current':checkIsCurrentActivity('PWD Filed') && !( getCompletedActivities.indexOf('EFILE_PWD')>-1 || getCompletedActivities.indexOf('PWD_CERTIFID')>-1 || ['Filed','Certified'].indexOf(checkProperty(petition, 'pwdStatus'))>-1)}">
            <em></em>
            <div class="status_list_cnt">
              <div class="status_title">
                <label>PWD Filed <!---( In Process / Pending Determination )--></label>
                <template  v-if="checkIsCurrentActivity('PWD Filed') && ( getCompletedActivities.indexOf('UPDATE_DOL_RESPONSE')<=-1)">
                  <div class="info" v-if="checkIsCurrentActivity('PWD Filed') && findUsers('EFILE_PWD') && [50,51].indexOf(getUserRoleId) <= -1" >
                    <img src="@/assets/images/main/information.svg" />
                    <div class="info_cnt">
                     <p>Pending with <a href="#"></a> {{findUsers('EFILE_PWD')}}</p>
                    </div>
                </div>
                </template>
               
              </div>
                <span v-if="checkProperty(petition, 'pwdLinkedOn')">{{checkProperty(petition, 'pwdLinkedOn') | formatDateTime}}</span>
                <span v-else-if="getActionComplatedDate('EFILE_PWD')">{{getActionComplatedDate('EFILE_PWD') | formatDateTime}}</span>
                <span v-else-if="getActionComplatedDate('PWD_CERTIFID')">{{getActionComplatedDate('PWD_CERTIFID') | formatDateTime}}</span>
                <span v-else-if="getActionComplatedDate('UPDATE_PWD_RESPONSE')">{{getActionComplatedDate('UPDATE_PWD_RESPONSE') | formatDateTime}}</span>
                <span v-else-if="checkProperty(petition ,'filedPwdUpdatedOn')">{{ checkProperty(petition ,'filedPwdUpdatedOn') | formatDateTime}}</span>
                <span v-else-if="checkProperty(petition ,'certifiedPwdUpdatedOn')">{{ checkProperty(petition ,'certifiedPwdUpdatedOn') | formatDateTime}}</span>
                
            <!------  
              <span v-if="scannedDocumentsList.length>0">{{scannedDocumentsList[0]['createdOn'] | formatDateTime}}</span>
            -->
   
            </div>
          </li>

          <li :class="{
            'completed':checkCaseStatusCompleted('PWD Response') || (['Certified'].indexOf(checkProperty(petition, 'pwdStatus'))>-1 ) ,
            'current':checkIsCurrentActivity('PWD Response') && ['Certified'].indexOf(checkProperty(petition, 'pwdStatus'))<=-1 || (  getCompletedActivities.indexOf('COLLECT_ADV_EVIDENCE')>-1 &&  getCompletedActivities.indexOf('PREPARE_PERM_APPLICATION')>-1 && getCompletedActivities.indexOf('PWD_CERTIFID')<=-1 ) }">
            <em></em>
            <div class="status_list_cnt">
              <div class="status_title">
                <label> PWD Certified</label>
                <template  v-if="( checkIsCurrentActivity('PWD Response') && getCompletedActivities.indexOf('UPDATE_PWD_RESPONSE')<=-1 && getCompletedActivities.indexOf('FINALIZE_JOB_DESC')>-1 )" >
                 <div class="info" v-if="findUsers('UPDATE_PWD_RESPONSE') && [50,51].indexOf(getUserRoleId) <= -1" >
                    <img src="@/assets/images/main/information.svg" />
                    <div class="info_cnt">
                     <p>Pending with <a href="#"></a> {{findUsers('UPDATE_PWD_RESPONSE')}}</p>
                    </div>
                </div>
                </template>
              </div>
              <span v-if="checkProperty(petition, 'pwdLinkedOn')">{{checkProperty(petition, 'pwdLinkedOn') | formatDateTime}}</span>
              <span v-else-if="getActionComplatedDate('PWD_CERTIFID')">{{getActionComplatedDate('PWD_CERTIFID') | formatDateTime}}</span>
              <span v-else-if="getActionComplatedDate('UPDATE_PWD_RESPONSE')">{{getActionComplatedDate('UPDATE_PWD_RESPONSE') | formatDateTime}}</span>
              <span v-else-if="checkProperty(petition ,'certifiedPwdUpdatedOn')">{{ checkProperty(petition ,'certifiedPwdUpdatedOn') | formatDateTime}}</span>
              
              
              
            </div>
            
          </li>

          <li
          :class="{
          'completed':checkCaseStatusCompleted('Advertisements') && (getCompletedActivities.indexOf('PWD_CERTIFID')>-1 || checkCaseStatusCompleted('Finalized PERM Questionnaire')),
          'current':(checkIsCurrentActivity('Advertisements') && !checkProperty( petition,'isPwdFiled')) || ( checkProperty( petition,'isPwdFiled') && getCompletedActivities.indexOf('COLLECT_ADV_EVIDENCE')<=-1 && checkProperty( petition ,'pwdStatus') =='Certified' && getCompletedActivities.indexOf('SUBMIT_TO_LAW_FIRM')>-1  ) }"
          >
            <em></em>
            <div class="status_list_cnt">
              <div class="status_title">
                <label> Advertisements</label>
                <template v-if="( getCompletedActivities.indexOf('FINALIZE_JOB_DESC')>-1 && getCompletedActivities.indexOf('COLLECT_ADV_EVIDENCE')<=-1  ) || ( checkProperty( petition,'isPwdFiled') && getCompletedActivities.indexOf('COLLECT_ADV_EVIDENCE')<=-1 && checkProperty( petition ,'pwdStatus') =='Certified' && getCompletedActivities.indexOf('SUBMIT_TO_LAW_FIRM')>-1  )">
                
                <div class="info" v-if="findUsers('COLLECT_ADV_EVIDENCE') && checkIsCurrentActivity('Advertisements') && [50,51].indexOf(getUserRoleId) <= -1" >
                    <img src="@/assets/images/main/information.svg" />
                    <div class="info_cnt">
                     <p>Pending with <a href="#"></a> {{findUsers('COLLECT_ADV_EVIDENCE')}}</p>
                    </div>
                </div>
                </template>
              </div>
              <span v-if="getActionComplatedDate('COLLECT_ADV_EVIDENCE')">{{getActionComplatedDate('COLLECT_ADV_EVIDENCE') | formatDateTime}}</span>
              <span v-else-if="checkProperty(petition, 'pwdLinkedOn')">{{checkProperty(petition, 'pwdLinkedOn') | formatDateTime}}</span>
            </div>
          </li>

          
          
          <li
          :class="{
          'completed':checkCaseStatusCompleted('Finalized PERM Questionnaire') ,
          'current':!checkCaseStatusCompleted('Finalized PERM Questionnaire') && checkIsCurrentActivity('Finalized PERM Questionnaire') && getCompletedActivities.indexOf('COLLECT_ADV_EVIDENCE')>-1}"
          >
            <em></em>
            <div class="status_list_cnt">
              <div class="status_title">
                <label> Finalized PERM Questionnaire</label>
                <template v-if="( (getCompletedActivities.indexOf('UPDATE_PWD_RESPONSE')>-1 || ['Filed','Certified'].indexOf(checkProperty(petition, 'pwdStatus'))>-1) && getCompletedActivities.indexOf('PREPARE_PERM_APPLICATION')<=-1  )">
                
                <div class="info" v-if="findUsers('PREPARE_PERM_APPLICATION') && [50,51].indexOf(getUserRoleId) <= -1" >
                    <img src="@/assets/images/main/information.svg" />
                    <div class="info_cnt">
                     <p>Pending with <a href="#"></a> {{findUsers('PREPARE_PERM_APPLICATION')}}</p>
                    </div>
                </div>
                </template>
              </div>
              <span v-if="getActionComplatedDate('PREPARE_PERM_APPLICATION')">{{getActionComplatedDate('PREPARE_PERM_APPLICATION') | formatDateTime}}</span>
            </div>
          </li>
          <li
          :class="{
          'completed':checkCaseStatusCompleted('PERM Draft Created') ,
          'current':checkIsCurrentActivity('PERM Draft Created')}"
          >
            <em></em>
            <div class="status_list_cnt">
              <div class="status_title">
                <label>PERM Draft Created</label>
                <template v-if="( getCompletedActivities.indexOf('EFILE_PREM_APPLICATION')>-1  )">
                
                <div class="info" v-if="findUsers('EFILE_PREM_APPLICATION') && [50,51].indexOf(getUserRoleId) <= -1" >
                    <img src="@/assets/images/main/information.svg" />
                    <div class="info_cnt">
                     <p>Pending with <a href="#"></a> {{findUsers('EFILE_PREM_APPLICATION')}}</p>
                    </div>
                </div>
                </template>
              </div>
              <span v-if="getActionComplatedDate('EFILE_PREM_APPLICATION')">{{getActionComplatedDate('EFILE_PREM_APPLICATION') | formatDateTime}}</span>
            </div>
          </li>
          
          <li
          :class="{
          'completed':checkCaseStatusCompleted('PERM Draft Approved') ,
          'current':checkIsCurrentActivity('PERM Draft Approved') && !checkDolResponse}"
          >
            <em></em>
            <div class="status_list_cnt">
              <div class="status_title">
                <label> PERM Draft Approved</label>
                <template v-if="( getCompletedActivities.indexOf('PREPARE_PERM_APPLICATION')>-1  )">
                
                <div class="info" v-if="checkIsCurrentActivity('PERM Draft Approved') && !checkDolResponse && (  findUsers( 'REQUEST_PERM_DRAFT_REVIEW') || findUsers('APPROVE_PERM_APPLICATION') || findUsers('PERM_DRAFT_SUGGESSION') ) && [50,51].indexOf(getUserRoleId) <= -1" >
                    <img src="@/assets/images/main/information.svg" />
                    <div class="info_cnt">
                     <p>Pending with <a href="#"></a>
                      <template v-if="findUsers('APPROVE_PERM_APPLICATION')">
                          {{findUsers('APPROVE_PERM_APPLICATION')}}
                       </template>
                       <template v-else-if="findUsers('REQUEST_PERM_DRAFT_REVIEW')">
                          {{findUsers('REQUEST_PERM_DRAFT_REVIEW')}}
                       </template>
                       <template v-else-if="findUsers('PERM_DRAFT_SUGGESSION')">
                          {{findUsers('PERM_DRAFT_SUGGESSION')}}
                       </template>
                       
                      </p>
                    </div>
                </div>
                </template>
              </div>
              <span v-if="getActionComplatedDate('APPROVE_PERM_APPLICATION')">{{getActionComplatedDate('APPROVE_PERM_APPLICATION') | formatDateTime}}</span>
            </div>
          </li>

<!------"name":"PERM Acknowledgement Uploaded",
          "currentActivity":['UPLOAD_PERM_ACK' ],
          "completed":['UPLOAD_PERM_ACK']-->

          <li
          class="h-auto"
          :class="{
          'completed':checkCaseStatusCompleted('PERM Acknowledgement Uploaded') ,
          'current':checkIsCurrentActivity('PERM Acknowledgement Uploaded') && !checkDolResponse}"
          >
          <div class="status-list-extended">
              <div class="d-flex">
                <em></em>
                <div class="status_list_cnt">
                  <div class="status_title">
                    <label> <!---PERM Acknowledgement Uploaded--->
                      PERM Submitted to DOL

                    </label>
                    <template v-if="( getCompletedActivities.indexOf('APPROVE_PERM_APPLICATION')>-1  )">
                    
                    <div class="info" v-if="checkIsCurrentActivity('PERM Acknowledgement Uploaded') && !checkDolResponse && (  findUsers( 'REQUEST_PERM_DRAFT_REVIEW') || findUsers('APPROVE_PERM_APPLICATION') || findUsers('PERM_DRAFT_SUGGESSION') ) && [50,51].indexOf(getUserRoleId) <= -1" >
                        <img src="@/assets/images/main/information.svg" />
                        <div class="info_cnt">
                        <p>Pending with <a href="#"></a>
                          <template v-if="findUsers('UPLOAD_PERM_ACK')">
                              {{findUsers('UPLOAD_PERM_ACK')}}
                          </template>
                          
                          
                          </p>
                        </div>
                    </div>
                    </template>
                  </div>
                  <span v-if=" getActionComplatedDate('UPLOAD_PERM_ACK')">{{getActionComplatedDate('UPLOAD_PERM_ACK') | formatDateTime}} </span>
                </div>
              </div> 
              
              <ul v-if="showDolLogs && checkProperty(dolLogs, 'length')>0">
                  <li v-for="( dollog ,index) in dolLogs" :key="index">
                  <template v-if="checkProperty(dollog ,'action') =='DOL_AUDIT'"> DOL Audit</template>
                  <template v-else-if="checkProperty(dollog ,'action') =='SUBMIT_TO_DOL'">DOL Submit</template>
                  <template v-else-if="checkProperty(dollog ,'action') =='DOL_SUPERVISORY_AUDIT'"> Supervisory Audit</template>
                  <template v-else-if="checkProperty(dollog ,'action') =='PREPARE_AUDIT_RESPONSE'"> DOL Audit Response</template>
                  
                  <template v-if="dollog['startedOn']"> <span>{{ dollog['startedOn'] | formatDateTime}}</span></template>
        
                </li>
                
              </ul>
            </div>
          </li>

         
         
         
          <li
          :class="{
          'completed': checkDolResponse ,
          'current':checkIsCurrentActivity('DOL Response') || ['DOL_AUDIT' ,'PREPARE_AUDIT_RESPONSE','SUBMIT_TO_DOL'].indexOf(petition.curWorkflowActivity)>-1 }"
          
          >
            <em></em>
            <div class="status_list_cnt">
              <div class="status_title">
                  <template  v-if=" checkDolResponse" >
                  
                      <label v-if="petition.completedActivities.indexOf('DOL_APPROVED')>-1   " > Certified  </label>
                      <label  v-if="petition.completedActivities.indexOf('DOL_RECEIVED_RFE')>-1"  > RFE Received</label>
                      <label  v-if="petition.completedActivities.indexOf('DOL_DENIED')>-1" > Denied </label>
                      <label  v-if="petition.completedActivities.indexOf('DOL_WITHDRAWN')>-1"  > Withdrawn </label>
                      <label  v-if="petition.completedActivities.indexOf('DOL_SUPERVISORY_AUDIT')>-1"  >Supervisory Audit</label>
                  </template>
                  <template v-else><label >DOL Response</label></template>
                  <div class="info" v-if=" checkIsCurrentActivity('DOL Response') && findUsers('UPDATE_DOL_RESPONSE') && [50,51].indexOf(getUserRoleId) <= -1" >
                    <img src="@/assets/images/main/information.svg" />
                    <div class="info_cnt">
                     <p>Pending with <a href="#"></a> {{findUsers('UPDATE_DOL_RESPONSE')}}</p>
                    </div>
                </div>
                
              </div>
            <template v-if="getDolSuperVisoryAudit !='' || (
                  petition.completedActivities.indexOf('DOL_APPROVED')>-1 
              ||  petition.completedActivities.indexOf('DOL_RECEIVED_RFE')>-1
              || petition.completedActivities.indexOf('DOL_DENIED')>-1
              || petition.completedActivities.indexOf('DOL_WITHDRAWN')>-1
              || petition.completedActivities.indexOf('DOL_SUPERVISORY_AUDIT')>-1
            )">  
              <span v-if="getDolSuperVisoryAudit !=''">{{getDolSuperVisoryAudit | formatDateTime}} </span>
              <span v-else-if="getDolLogsDate('DOL_APPROVED') !=''">{{getDolLogsDate('DOL_APPROVED') | formatDateTime}} </span>
              <span v-else-if="getDolLogsDate('DOL_RECEIVED_RFE') !=''">{{getDolLogsDate('DOL_RECEIVED_RFE') | formatDateTime}} </span>
              <span v-else-if="getDolLogsDate('DOL_DENIED') !=''">{{getDolLogsDate('DOL_DENIED') | formatDateTime}} </span>
              <span v-else-if="getDolLogsDate('DOL_WITHDRAWN') !=''">{{getDolLogsDate('DOL_WITHDRAWN') | formatDateTime}} </span>
              <span v-else-if="getDolLogsDate('DOL_SUPERVISORY_AUDIT') !=''">{{getDolLogsDate('DOL_SUPERVISORY_AUDIT') | formatDateTime}} </span>
              <span v-else-if="getActionComplatedDate('UPDATE_DOL_RESPONSE')">{{getActionComplatedDate('UPDATE_DOL_RESPONSE') | formatDateTime}}</span>
            </template>
              

                                  
            </div>
            
            
          </li> 


    </ul>
</template>

<script>
 import _ from "lodash";
 import moment from 'moment'
export default {

  /*
    Initiated
Questionnaire Submitted
Job Description
PWD Filed
PWD Response
Advertisements
PERM Draft Created
PERM Draft Approved
PERM Filed
DOL Response
    
 */
     name: "caseStatusList",
     data: () => ({
      showDolLogs:false,
      dolLogs:[],
      inProgressActivityes:['SUBMIT_TO_LAW_FIRM','ASSIGN_SUPERVISOR','ASSIGN_PARALEGAL','ASSIGN_DOCUMENTATION_MANAGER' ,'ASSIGN_DOCUMENTATION_EXECUTIVE','ASSIGN_ATTORNEY','CASE_APPROVED'],
       statusActivityList:[
        {
          "name":"Questionnaire Submitted",
          "currentActivity":['SUBMIT_BY_BENEFICIARY','SUBMIT_TO_LAW_FIRM' ], //check with case currentActivity
          "completed":['SUBMIT_BY_BENEFICIARY','SUBMIT_TO_LAW_FIRM'] // check in completed Activityes
      
        },
        {
          "name":"Job Description",
          "currentActivity":['CREATE_JOB_DESC' ,'REQUEST_JOB_DESC_REVIEW','JOB_DESC_SUGGESSION' ,'APPROVE_JOB_DESC' ,'FINALIZE_JOB_DESC',,"INTERNAL_APPROVE_JOB_DESC", "INTERNAL_REQUEST_JOB_DESC_REVIEW"],
          "completed":['APPROVE_JOB_DESC','FINALIZE_JOB_DESC']
      
        },
        {
          "name":"PWD Filed",
          "currentActivity":['EFILE_PWD'],
          "completed":['EFILE_PWD' ]
      
        },
        {
          "name":"PWD Response",
          "currentActivity":['UPDATE_PWD_RESPONSE'],
          "completed":['PWD_CERTIFID' ]
      
        },
        {
          "name":"Advertisements",
          "currentActivity":['COLLECT_ADV_EVIDENCE'],
          "completed":['COLLECT_ADV_EVIDENCE' ]
      
        },
        {
          "name":"Finalized PERM Questionnaire",
          "currentActivity":['PREPARE_PERM_APPLICATION'],
          "completed":['PREPARE_PERM_APPLICATION']
      
        },
        {
          "name":"PERM Draft Approved",
          "currentActivity":['APPROVE_PERM_APPLICATION' ,'REQUEST_PERM_DRAFT_REVIEW'],
          "completed":['APPROVE_PERM_APPLICATION']
      
        },
        {
          "name":"PERM Acknowledgement Uploaded",
          "currentActivity":['UPLOAD_PERM_ACK' ],
          "completed":['UPLOAD_PERM_ACK']
      
        },
        {
          "name":"PERM Draft Created",
          "currentActivity":['EFILE_PREM_APPLICATION'],
          "completed":['EFILE_PREM_APPLICATION']
      
        },
        
       
        {
          "name":"DOL Response",
          "currentActivity":['UPDATE_DOL_RESPONSE' ,'DOL_AUDIT' ,'DOL_SUPERVISORY_AUDIT','PREPARE_AUDIT_RESPONSE','SUBMIT_TO_DOL'],
          "completed":['DOL_APPROVED' ,'DOL_RECEIVED_RFE' ,'DOL_DENIED','DOL_WITHDRAWN']
      
        }

       ]

     }),
     methods:{
      processDolLogs(){
        this.dolLogs = [];
        this.showDolLogs =false;
        let tempList =[]
        if(this.petition && this.petition['dolLogs']){
      _.forEach(this.petition['dolLogs'],(log)=>{
        if(['DOL_AUDIT', 'SUBMIT_TO_DOL', 'DOL_SUPERVISORY_AUDIT'].indexOf(log['action'])>-1){
          if(log['startedOn']){
            log['startedOn'] = moment(log['startedOn']).format('MMM DD, YYYY hh:mm A')
          }
          
          tempList.push(log);
          this.showDolLogs =true;
        }
        
      });
      this.dolLogs  = _.orderBy( tempList ,['startedOn'] ,['asc'] );
     

    } 
      },

      getActionStartDate(code=''){
             let returnValue="";
             if(code){
                 let item = _.find( this.currentCaseDetails , {"action":code});
               if(item && this.checkProperty( item, 'startedOn')){

                  returnValue = item['startedOn']

               }
             }
             return returnValue;

         },

      checkCaseStatusCompleted_backup(category=''){
          let allCompletedActivityes =[];
            if(this.checkProperty(this.petition ,'completedActivities' ,'length')>0){
              allCompletedActivityes= this.petition['completedActivities']; 
            }
        

          //Receipt Received Submitted to USCIS Petitioner Signature In Process Questionnaire Submitted
          statusActivityList = _.find(this.statusActivityList ,{'name':category});
          switch (category) {
            case 'Questionnaire Submitted':
              if((this.checkProperty(this.petition, 'questionnaireFilled') && allCompletedActivityes.indexOf('SUBMIT_TO_LAW_FIRM')>-1 ))
                return true
              else
                return false
              break;
            case 'In Process':
              let inProcessActivityes =[ 'SUBMIT_TO_LAW_FIRM' ,"CASE_APPROVED"];
                let completedCount =0
              _.forEach(inProcessActivityes ,(item)=>{
                if(allCompletedActivityes.indexOf(item)>-1){
                  completedCount =completedCount+1;
                }

              });

              if(completedCount ==inProcessActivityes.length){
                return true;
              }else{
                return false;
              }

              break;
            case 'Petitioner Signature':
             
              if((allCompletedActivityes.indexOf('REQUEST_PETITIONER_SIGN')>-1 ))
                return true
              else
                return false
              break;
            case 'Submitted to USCIS':
           
              if((allCompletedActivityes.indexOf('SUBMIT_TO_USCIS')>-1 ) && (allCompletedActivityes.indexOf('COURIER_TRACKING')>-1 ) )
                return true 
              else
                return false
              break;
            case 'Receipt Received':
              if( (allCompletedActivityes.indexOf('UPDATE_USCIS_RECEIPT_NUMBER')>-1 ) )
                return true
              else
                return false
              break;
              
            case 'USCIS Response':
              let finalStatus =['USCIS_APPROVED' ,'USCIS_RECEIVED_RFE' ,'USCIS_DENIED','USCIS_WITHDRAWN']
              let count =0
              _.forEach(finalStatus ,(item)=>{
                if(allCompletedActivityes.indexOf(item)>-1){
                  count =count+1;
                }

              });

              if(count>0){
                return true;
              }else{
                return false;
              }
              break;
            default: 
              return false     


          }
        },
         
        
         getActionComplatedDate(code=''){
             let returnValue="";
             if(code=='UPDATE_DOL_RESPONSE'){
              let items = _.filter( this.currentCaseDetails , {"action":code});
              if(items  && items.length>0){

                let tempList =[];
                _.forEach(items ,(log)=>{
                  if(_.has(log ,'startedOn')){
                    log['startedOn'] = moment(log['startedOn']).format('MMM DD, YYYY hh:mm A')
                  }
                  tempList.push(log);
                  

                })
                let logs  = _.orderBy( tempList ,['startedOn'] ,['desc'] );
                if(logs.length>0){
                  returnValue =logs[0]['startedOn'];
                }


              }
              
           

             }else if(code){
                 let item = _.find( this.currentCaseDetails , {"action":code});
                 if(item && this.checkProperty( item, 'endedOn')){

                     returnValue = item['endedOn']

                 }


             }
             return returnValue;

         },
      getPendingWithUsers(activityCode=''){
       // this.currentCaseDetails
       //this.workFlowDetails
        let self =this;
        let returnVal='';
        let allUsers =[];
        let selectedUsers =[];
        if(_.has(this.workFlowDetails ,'config' ) && activityCode !='' && (self.checkProperty(this.currentCaseDetails ,"length")>0)){
        let selectedActivity = _.find(this.workFlowDetails['config'] ,{'code':activityCode});
        if(selectedActivity && _.has(selectedActivity , 'editors') && selectedActivity['editors'].length>0 ){

          let activityEditors = selectedActivity['editors'].map((editor)=>editor.roleId);
          //  let filterItems = _.filter(this.currentCaseDetails ,(item)=>{
          //    return (!(_.has(item ,'endedOn')) || (item.endedOn ==null) || (item.endedOn ==''))

          //  });

          _.forEach(this.currentCaseDetails , (obj)=>{
            if(self.checkProperty(obj, 'users','length' )>0){

              let users = obj['users'];
              _.forEach(users ,(user ,ind)=>{

                let userName = user['name']+" ("+ user['roleName']+")"
                if(activityEditors.indexOf(user['roleId'])>-1 && selectedUsers.indexOf(user['_id'])<=-1){
                  allUsers.push(_.cloneDeep(userName))
                
                }
                selectedUsers.push(user['_id'])
                


              })



            }

          })


        if(allUsers.length >0){

          returnVal = allUsers.join(', ');

        }
        return returnVal

        }

        }

      }, 

     },
     mounted(){
      //statusActivityList  inProgressActivityes
      setTimeout(() =>{

       
      if(this.checkProperty(this.workFlowDetails , 'config')){
        let workFlowConfig = this.workFlowDetails['config'];
        // _.forEach(this.statusActivityList ,(item)=>{

        //   if(this.checkProperty(item ,'name' ) =="In Process"){
        //     item['completed'] =[];
        //     item['currentActivity'] =[]
        //     _.forEach(this.inProgressActivityes,  (n)=> {
        //            let actionRequired= _.find(workFlowConfig, {"code": n ,"actionRequired":'Yes'});
        //            if(actionRequired){
        //             item['completed'].push(n);
        //             item['currentActivity'].push(n);
        //            }
        //     });


        //   }

        // })
    }

    //dolLogs
    
    
    
   
  } ,100);
  this.processDolLogs();
     
  
         

      

     },
     props:{
            workFlowDetails:{
            type: Object,
            default: null,

          },
          petition: {
             type: Object,
             default: null
         },
         currentCaseDetails:{
              type: Array,
              default:new Array(),
         },
         scannedDocumentsList:{
              type: Array,
              default:new Array(),
         },
     },
     computed:{
      getDolLogsDate(){
        let returnVal ='';
        return (code='')=>{

        if(this.checkProperty(this.petition, 'dolLogs' ,'length')>0){
          let activityList = _.filter(this.petition['dolLogs'] ,{"action":code});
                if(activityList  && activityList.length>0){

                  let tempList =[];
                  _.forEach(activityList ,(log)=>{
                      if(_.has(log ,'startedOn')){
                      log['startedOn'] = moment(log['startedOn']).format('MMM DD, YYYY hh:mm A')
                      }
                      tempList.push(log);

  
                    })
                  let logs  = _.orderBy( tempList ,['startedOn'] ,['desc'] );
                  if(logs.length>0){
                    returnVal =logs[0]['startedOn'];
                  }


                }


          }
        return returnVal;
      }
      },
       getDolSuperVisoryAudit(){
        //dolLogs DOL_SUPERVISORY_AUDIT
        let returnValue ='';
        if(this.dolLogs && this.dolLogs.length>0 && this.petition && _.has(this.petition ,'completedActivities') && this.petition.completedActivities.indexOf('DOL_SUPERVISORY_AUDIT')>-1){

          let dolSuperVisoryAudit = _.find( this.dolLogs ,{'action':'DOL_SUPERVISORY_AUDIT'});
          if(dolSuperVisoryAudit && _.has(dolSuperVisoryAudit,'startedOn')){
            returnValue = dolSuperVisoryAudit['startedOn'];
          }


        }
        return returnValue;
       },
      checkDolResponse(){
        let dolResopnseCompleted =false;
        let dolResponseList =['DOL_APPROVED' ,'DOL_RECEIVED_RFE' ,'DOL_DENIED','DOL_WITHDRAWN' ,'DOL_SUPERVISORY_AUDIT'];
        _.forEach(this.petition.completedActivities ,(item)=>{
          if(dolResponseList.indexOf(item) >-1){
            dolResopnseCompleted =true;
          }

        });
        return dolResopnseCompleted
      },

      checkCaseStatusCompleted(){
        let _self =this;
       return (category='')=>{
       
          let allCompletedActivityes =[];
            if(_self.checkProperty(_self.petition ,'completedActivities' ,'length')>0){
              allCompletedActivityes= _self.petition['completedActivities']; 
            }
          let statusActivity = _.find(_self.statusActivityList ,{'name':category});
          if(statusActivity && statusActivity['completed'].length>0){
            let count =0;
            _.forEach(statusActivity['completed'] ,(item)=>{
              if(allCompletedActivityes.indexOf(item)>-1){
                count =count+1;
              }

            });
          
            if( category=='DOL Response' ){
              return true;
            }
            if(category !='DOL Response' && statusActivity['completed'].length==count){

              return true;
            }else{
              return false;
            }


          }else{
            return false;
          }

        }
         

      },
      checkIsCurrentActivity(){
      
        let _self =this;
       return (category='')=>{
      
          let nextWorkflowActivity ='';
            if(_self.checkProperty(_self.petition ,'nextWorkflowActivity' )){
              nextWorkflowActivity= _self.petition['nextWorkflowActivity']; 
            }
          let statusActivity = _.find(_self.statusActivityList ,{'name':category});
          if(statusActivity && nextWorkflowActivity){
               let count =0
            _.forEach(statusActivity['currentActivity'] , (code)=>{
              if(nextWorkflowActivity.indexOf(code) >-1){
                count =count+1
              }

            });
            
            if(count>0){
              return true;
            }else{
               return false;
            }
           
            // if(statusActivity['currentActivity'].indexOf(curWorkflowActivity)>-1){
             
            //   return true;
            // }else{
            //   return false;
            // }


          }else{
            return false;
          }

        }
         

      },
      
       findUsers(){
         let self =this;
         let returnVal='';
         let allUsers =[];
         let selectedUsers =[];
         return (activityCode='')=>{
          if(activityCode !='' && (self.checkProperty(this.currentCaseDetails ,"length")>0)){
         
                  let filterItems = _.filter(this.currentCaseDetails ,(item)=>{
                    return (!(_.has(item ,'endedOn')) || (item.endedOn ==null) || (item.endedOn =='')) && item['action'] ==activityCode;

                  });
                  
                  if(self.checkProperty(filterItems ,"length")>0){
                    selectedUsers =[];
                    allUsers =[];
                    _.forEach(filterItems , (obj)=>{
                      if(self.checkProperty(obj, 'users','length' )>0){

                        let users = obj['users'];
                        _.forEach(users ,(user ,ind)=>{

                          let userName = user['name']+" ("+ user['roleName']+")"
                          if(selectedUsers.indexOf(user['_id'])<=-1){
                            allUsers.push(_.cloneDeep(userName))
                            
                          }
                            selectedUsers.push(user['_id'])
                          


                        })



                      }

                    })

                  }
                  if(allUsers.length >0){

                    returnVal = allUsers.join(', ');

                  }
            }

         return returnVal;
        }

       }
     }

}
</script>