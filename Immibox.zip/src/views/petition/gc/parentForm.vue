<template>
     
    <div class="vs-col m-auto float-none vs-xs- vs-sm-12 vs-lg-10 pt-10" vs-type="flex" vs-justify="center" vs-align="center">
        <h3 class="small-header">{{parentType}}</h3>
        
            <div class="form-container">
                <div class="vx-row">
               
                  <div class="vx-col w-full">
                         <vx-input-group class="form-input-group FML">
                            <immiInput :notRequired="notRequired" :display="false" :fieldsArray="fieldsArray" :tplkey="'firstName'" :required="true" :fieldName="'firstName'+fieldName" :cid="'firstName'+cid" :formscope="formscope" :tplsection="tplsection" v-model=value.firstName  label="First Name" placeHolder="First Name" />
                            <immiInput :notRequired="notRequired" :display="false"  :fieldsArray="fieldsArray" :tplkey="'middleName'"  :required="true" :cid="'middleName'+cid" :formscope="formscope" v-model="value.middleName"  :tplsection="tplsection" :fieldName="'middleName'+fieldName" label="Middle Name" placeHolder="Middle Name" />
                            <immiInput :notRequired="notRequired" :display="false"  :fieldsArray="fieldsArray" :tplkey="'lastName'" :required="true" :cid="'lastName'+cid" :formscope="formscope" v-model="value.lastName" :tplsection="tplsection" :fieldName="'lastName'+fieldName" label="Last Name" placeHolder="Last Name" />
                        </vx-input-group> 
                    </div>
                    
                    <immiyesorno  :required="checkFieldIsRequired({'key':'otherNames','section':tplsection, 'fieldsArray':fieldsArray, 'required':true,'notRequired':notRequired })"  wrapclass=" "    :display="false" :fieldsArray="questionnaireDetails" formscope="casedetailsform" :cid="'nameDifotherNamesfFromBirthCert'+parentType" :tplkey="'otherNames'"   v-model="value.hasOtherNames" :tplsection="tplsection"  :fieldName="'otherNames'+parentType" :wrapclass="'formgroup-mb0 h4_ead_label'"  label="Have you ever used any other names previously?"></immiyesorno>
                    <!-- <div class="vx-col w-full mb-5 yesno-v2" v-if="canRenderField('otherNames',fieldsArray, false, tplsection)">
                        <div class="d-block align-center">
                            <a class="switch-label">Have you ever used any other names previously?
                            </a><em v-if="checkFieldIsRequired({'key':'otherNames','section':tplsection, 'fieldsArray':fieldsArray, 'required':true })" >*</em>
                            <ul class="custom-radio custom-radio_v2">
                                <li>
                                    <vs-radio ref="yes" v-model="value.hasOtherNames" vs-name="parent.hasOtherNames" :vs-value="true"  @input="resetOtherNames(value.hasOtherNames)">Yes</vs-radio>
                                </li>
                                <li>
                                    <vs-radio ref="no" v-model="value.hasOtherNames" vs-name="parent.hasOtherNames" :vs-value="false"  @input="resetOtherNames(value.hasOtherNames)" >No</vs-radio>
                                </li> 
                            </ul>
                            <div class="form_group" v-if="checkFieldIsRequired({'key':'otherNames','section':tplsection, 'fieldsArray':fieldsArray, 'required':true })">
                                <input type="hidden" :name="'otherNames_parentInfo'+parentType" v-validate="'required'"  data-vv-as="Field"  v-model="value.hasOtherNames">
                                <span v-show="errors.has( formscope+'.otherNames_parentInfo'+parentType)" class="text-danger text-sm" style="">*Field is required</span>
                            </div>
                        </div>
                    </div> -->
                <!-- <immiswitchyesno wrapclass=" "  :fieldsArray="fieldsArray"  :tplsection="tplsection"  :display="false" :tplkey="'hasOtherNames'"  :cid="'hasOtherNames'+cid"  :formscope="formscope" v-model="value.hasOtherNames" :fieldName="'hasOtherNames'+fieldName" label="Have you ever used any other names previously?ave you used any other names previously?" placeHolder="" />  -->
                <template v-if="value.hasOtherNames && canRenderField('hasOtherNames', fieldsArray ,false,tplsection)">
                    <div class="vx-col w-full" v-for="(item, ind) in value['otherNames']" :key="ind">
                        <vx-input-group class="form-input-group delete-rows-cst FML">
                            <immiInput :notRequired="notRequired" :display="false" :tplkey="'firstName'" :tplsection="tplsection" :formscope="formscope" :cid="'benf'+ind" v-model="item.firstName" :required="false" fieldName="spouse_last_name" label="First Name" placeHolder="First Name" />
                            <immiInput :notRequired="notRequired" :display="false" :tplkey="'middleName'" :tplsection="tplsection" :formscope="formscope" :cid="'benm'+ind" v-model="item.middleName" :required="false" fieldName="spouse_middle_name" label="Middle Name" placeHolder="Middle Name" />
                            <immiInput :notRequired="notRequired" :display="false" :allowUpperCase="petition.tenantDetails && checkProperty(petition,'tenantDetails','slug') &&  checkProperty(petition,'tenantDetails','slug') == 'slg'"  :tplkey="'lastName'" :tplsection="tplsection" :formscope="formscope" :cid="'benl'+ind" v-model="item.lastName" :required="false" fieldName="olastName" label="Last Name" placeHolder="Last Name" />

                            <div class="delete" v-if="ind > 0" @click="removeOtherName(ind)">
                                <a>
                                    <img src="@/assets/images/main/delete-row-img.svg" />
                                </a>
                            </div>
                        </vx-input-group>
                        <a class="add-more add-more-names mb-10" v-if="value['otherNames'].length - 1 ==ind" @click="addOtherNames()"><span>+</span>Add</a>
                </div> 
                <!-- <div class="vx-col w-full">
                    
                     <a class="add-more add-more-names" @click="addOtherNames()"><span>+</span>Add</a>  
                </div> -->
                </template>
                 
                         <div class="vx-col w-full">
                         
                           <h3 class="small-header">Name at Birth</h3>
                            <vx-input-group class="form-input-group FML">
                                <immiInput :notRequired="notRequired" :display="false" :fieldsArray="fieldsArray" :tplkey="'firstName'" :cid="'atfirstName'+cid" :formscope="formscope" v-model=value.nameAtBirth.firstName :required="true" :tplsection="tplsection" :fieldName="'firstName'+fieldName" label="First Name" placeHolder="First Name" />
                                <immiInput :notRequired="notRequired" :display="false"  :fieldsArray="fieldsArray"  :tplkey="'middleName'" :cid="'atmiddleName'+cid" :formscope="formscope" v-model="value.nameAtBirth.middleName" :required="true" :tplsection="tplsection" :fieldName="'middleName'+fieldName" label="Middle Name" placeHolder="Middle Name" />
                                <immiInput :notRequired="notRequired" :display="false"  :fieldsArray="fieldsArray" :tplkey="'lastName'" :cid="'atlastName'+cid" :formscope="formscope" v-model="value.nameAtBirth.lastName" :required="true" :fieldName="'lastName'+fieldName" :tplsection="tplsection" label="Last Name" placeHolder="Last Name" />
                            </vx-input-group>
                        </div> 
                 
                   
                    <selectField :notRequired="notRequired" :display="false"  :fieldsArray="fieldsArray" :formscope="formscope" wrapclass="md:w-1/2"  @input="changeBfProvince" :required="true" :optionslist="countriesWithoutUS" :tplsection="tplsection"  v-model="value.countryOfBirthDetails"  :tplkey="'countryOfBirth'" :fieldName="'countryOfBirth'+fieldName" :cid="'countryOfBirth'+cid" label="Country of Birth" vvas="Country of Birth" placeHolder="Country of Birth" /> 
                    <selectField :notRequired="notRequired" :display="false" :cid="'provinceOfBirth'+cid"  :fieldsArray="fieldsArray" :formscope="formscope" :tplkey="'provinceOfBirth'" wrapclass="md:w-1/2" :tplsection="tplsection" @input="value.provinceOfBirth = value.provinceOfBirthDetails.id" :required="true" :optionslist="bfeprovinceStates" v-model="value.provinceOfBirthDetails"  :fieldName="'provinceOfBirth'+fieldName" label="Province of Birth" vvas="Province of Birth" placeHolder="Province of Birth" /> 

                    <immiInput :notRequired="notRequired" :display="false"  :fieldsArray="fieldsArray"  :formscope="formscope" wrapclass="md:w-1/2" :cid="'locationOfBirth'+cid"  :tplkey="'locationOfBirth'"  v-model="value.locationOfBirth" :tplsection="tplsection" :required="true" :fieldName="'locationOfBirth'+fieldName" label="Location of Birth" placeHolder="Location of Birth" />
                    <datepickerField :notRequired="notRequired" :display="false"  :fieldsArray="fieldsArray"  :dateEnableTo="startEligibleDate" :cid="'dateOfBirth'+cid" :tplkey="'dateOfBirth'"  :validationRequired="true" v-model="value.dateOfBirth" :tplsection="tplsection" :formscope="formscope" :fieldName="'dateOfBirth'+fieldName" label="Date of Birth" />
                     
                  
                    <datepickerField  :notRequired="notRequired"  :display="false" :fieldsArray="fieldsArray" :dateEnableTo="new Date()" :validationRequired="true" :tplkey="'deceasedDate'"  v-model="value.deceasedDate" :formscope="formscope" :tplsection="tplsection" :cid="'deceasedDate'+cid" :fieldName="'deceasedDate'+fieldName" label="Deceased Date" />
                    <selectField :notRequired="notRequired" :display="false" wrapclass="md:w-1/2" :fieldsArray="fieldsArray"  :required="true" :optionslist="usastates" :tplkey="'deceasedCity'"  v-model="value.deceasedCityDetails" :tplsection="tplsection" @input="value.deceasedCity = value.deceasedCityDetails.id" :cid="'deceasedCity'+cid"  :fieldName="'deceasedCity'+fieldName"  :formscope="formscope"  label="Deceased City" placeHolder="Deceased City" />
                    <immiswitchyesno :notRequired="notRequired" v-if="parentType=='Father Information'" wrapclass=" " :display="false" :fieldsArray="fieldsArray" :formscope="formscope" :tplkey="'isUSCitizen'"  v-model="value.isUSCitizen" :tplsection="tplsection" :fieldName="'isUSCitizen'+fieldName" :cid="'isUSCitizenn'+cid" label="Is your Father now or was he ever a U.S Citizen?" placeHolder="" />
                    <immiswitchyesno :notRequired="notRequired" v-if="parentType=='Mother Information'" wrapclass=" " :display="false" :fieldsArray="fieldsArray"  :formscope="formscope" :tplkey="'isUSCitizen'"  v-model="value.isUSCitizen" :tplsection="tplsection" :fieldName="'isUSCitizen'+fieldName" :cid="'isUSCitizen'+cid" label="Is your Mother now or was she ever a U.S Citizen?" placeHolder="" />
                    <datepickerField :notRequired="notRequired" v-if="value.isUSCitizen"  :display="false" :fieldsArray="fieldsArray" :dateEnableTo="new Date()" :validationRequired="true" :tplkey="'dateFromUSCitizen'" :tplsection="tplsection"  v-model="value.dateFromUSCitizen" :formscope="formscope"  :cid="'dateFromUSCitizen'+cid" :fieldName="'dateFromUSCitizen'+fieldName" label='Date Since U.S Citizen'/>
                     
                <div class="vx-col w-full">
                    <div>
                        <h3 class="small-header">Current Address</h3>
                        <addressField  :fieldsArray="fieldsArray" :tplkey="'currentAddress'" :disableCountry="false" :formscope="formscope"   :showaptType="true" :addFormContainerCls="false" :tplsection="tplsection" :validationRequired="true && !notRequired" :countries="countries" :fieldName="'currentAddress'+fieldName" v-model="value.currentAddress" :cid="'currentAddress'+cid" />
                    </div>                 
                </div>
                                                           

            </div>
            </div>
        
    </div>        
</template>
<script>
    import immiyesorno from "@/views/forms/fields/yesorno.vue";
import DateRangePicker from "vue2-daterange-picker";
 import "vue2-daterange-picker/dist/vue2-daterange-picker.css";
import datepickerField from "@/views/forms/fields/datepicker.vue";
import selectField from "@/views/forms/fields/simpleselect.vue";
import immiInput from "@/views/forms/fields/simpleinput.vue";
import redioButtons from "@/views/forms/fields/redioButtons.vue";
import addressField from "@/views/forms/fields/address.vue";
import Datepicker from "vuejs-datepicker-inv";
import immiswitchyesno from "@/views/forms/fields/switchyesno.vue";
import _ from "lodash";
export default {
    // pass v-model as petition['fatherInfo']
    inject: ["parentValidator"],
    created() {
            this.$validator = this.parentValidator;
        },
        props: {
            countriesWithoutUS:{
                type:Array,
                default:[]
            },
            notRequired:{
                type: Boolean,
                default: false,
            },
            tplsection:{
                type: String,
                default: null,
            },
            value: Object,
            // petitionDetails: {
            //     type: Object,
            //     default: null
            // },
            petition:{
                type:Object,
                default:null
            },
            formscope: {
                type: String,
                default: ''
            },
           
            datatype: {
                type: String,
                default: ""
            },
            vvas: {
                type: String,
                default: ""
            },
            required: {
                type: Boolean,
                default: false,
            },
            parentType:{
                type:String,
                default:'Father Information'
            },
            countries:{
                type:Array,
                default:null
            },
            cid: String,
            fieldName: String,
            fieldsArray:{
                type:Array,
                default:null
            },
        },
        data() {
            return {
                bfeprovinceStates:[],
                wrapclass:" ",
                questionnaireDetails:null,
                startEligibleDate: new Date().setFullYear(new Date().getFullYear() - 18),
                autoApply: "",
                usastates:[],
            };
        },
       
//           provide() {
//       return {
//          parentValidator: this.$validator,
//       };
//   },
        computed: {
        },
        mounted() {
            if (_.has(this.value,'countryOfBirthDetails') && this.value.countryOfBirthDetails && this.value.countryOfBirth != null) {

                this.loadStatesByCountry('bfeprovinceStates', this.value.countryOfBirth)

                }
           
        },
        methods: {
            changeBfProvince(value) {
            this.value.countryOfBirth = this.value.countryOfBirthDetails.id;
            this.bfeprovinceStates = [];
            this.value.provinceOfBirth = null;
            this.value.provinceOfBirthDetails = null;
            this.loadStatesByCountry('bfeprovinceStates', value.id)
        },
        loadStatesByCountry(model, countryId) {

            this.$store.dispatch("getstates", countryId).then((response) => {
                switch (model) {
                    case "bfeprovinceStates":
                        this.bfeprovinceStates = response;
                        break;
                }

            });
            this.$store.dispatch("getstates", 231).then((response) => {
                this.usastates = response;
             });

            },
            removeOtherName(index) {
                this.value['otherNames'].splice(index, 1);
            },
            addOtherNames() {
                let item = {
                    firstName:"",
                    middleName:"",
                    lastName:""
                };
                this.value['otherNames'].push(item);
            },
        },
        components: {
            immiyesorno,
            DateRangePicker,
            datepickerField,
            selectField,
            immiInput,
            immiswitchyesno,
            addressField,
            redioButtons,
            Datepicker
        }
    };
</script>