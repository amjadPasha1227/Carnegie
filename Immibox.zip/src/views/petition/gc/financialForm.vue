<template>
    <div>
    <div class="vs-col m-auto float-none vs-xs- vs-sm-12 vs-lg-10" vs-type="flex" vs-justify="center" vs-align="center">
        <h3 class="small-header pt-10">Financial </h3>
            <div class="form-container"> 
              <div class="vx-row">
                <div class="vx-col w-full">
                  <div class="vx-row" >
                  <immiInput :display="true" :onlyNumbers="true" :fieldsArray="fieldsArray" :allowFloatingPoint="true"  wrapclass="md:w-1/2" :cid="'deppositsInUSBanks'" :formscope="formscope" v-model="value.deppositsInUSBanks" :required="true" :fieldName="'deppositsInUSBanks'" label="Deposits in Bank in the USA" placeHolder="Deposits in Bank in the USA" />
                  <immiInput :display="true" :onlyNumbers="true" :fieldsArray="fieldsArray" :allowFloatingPoint="true"  wrapclass="md:w-1/2" :cid="'valueOfRealEstate' " :formscope="formscope" v-model="value.valueOfRealEstate" :required="false" :fieldName="'valueOfRealEstate' " label="Value of Real Estate, If Owned" placeHolder="Value of Real Estate, If Owned" />
                  <immiInput :display="true" :onlyNumbers="true" :fieldsArray="fieldsArray" :allowFloatingPoint="true"  wrapclass="md:w-1/2" :cid="'caseSurrenderOfLifeInsurance' " :formscope="formscope" v-model="value.caseSurrenderOfLifeInsurance" :required="true" :fieldName="'caseSurrenderOfLifeInsurance' " label="Cash Surrender Value of Life Insurance" placeHolder="Cash Surrender Value of Life Insurance" />
                  <immiInput :display="true" :onlyNumbers="true" :fieldsArray="fieldsArray" :allowFloatingPoint="true" wrapclass="md:w-1/2" :cid="'reasonalValOfPersonalProp' " :formscope="formscope" v-model="value.reasonalValOfPersonalProp" :required="true" :fieldName="'reasonalValOfPersonalProp'" label="Reasonable Value of Personal Property" placeHolder="Reasonable Value of Personal Property" />
                  <immiInput :display="true" :onlyNumbers="true"  :fieldsArray="fieldsArray" :allowFloatingPoint="true"  wrapclass="md:w-1/2" :cid="'marketValOfStoks' " :formscope="formscope" v-model="value.marketValOfStoks" :required="true" :fieldName="'marketValOfStoks' " label="Market Value of Stocks and Bonds" placeHolder="Market Value of Stocks and Bonds" />
                  <immiInput :display="true" :onlyNumbers="true" :fieldsArray="fieldsArray" :allowFloatingPoint="true" wrapclass="md:w-1/2" :cid="'sumOfLifeInsurence' " :formscope="formscope" v-model="value.sumOfLifeInsurence" :required="true" :fieldName="'sumOfLifeInsurence' " label="Sum of Life Insurance" placeHolder="Sum of Life Insurance" />
                  <immiInput :display="true" :onlyNumbers="true"  :fieldsArray="fieldsArray" wrapclass="md:w-1/2" :cid="'healthInsurancePremium' " :formscope="formscope" v-model="value.healthInsurancePremium" :required="true" :fieldName="'healthInsurancePremium' " label="Health Insurance Premium" placeHolder="Health Insurance Premium" />
                  <datepickerField :display="true" :fieldsArray="fieldsArray" :dateEnableTo="startEligibleDate" :validationRequired="true" v-model="value.HealthInsuranceRenewalDate" :formscope="formscope" :fieldName="'HealthInsuranceRenewalDate'" label="Health Insurance Renewal Date" />
                  <immiInput :display="true" :onlyNumbers="true" :fieldsArray="fieldsArray" :allowFloatingPoint="true"  wrapclass="md:w-1/2" :cid="'creditScore' " :formscope="formscope" v-model="value.creditScore" :required="true" :fieldName="'creditScore' " label="Credit Score" placeHolder="Credit Score" />
                  <immiInput :display="true" :onlyNumbers="true"  :fieldsArray="fieldsArray":allowFloatingPoint="true" wrapclass="md:w-1/2" :cid="'amtOfMortgageOnProperty' " :formscope="formscope" v-model="value.amtOfMortgageOnProperty" :required="true" :fieldName="'amtOfMortgageOnProperty' " label="Amount of Mortgage on the Property" placeHolder="Amount of Mortgage on the Property" />
                </div>
                </div>  
              </div>
            </div>
      </div>
    </div>  
</template>
<script>
import immiInput from "@/views/forms/fields/simpleinput.vue";
import datepickerField from "@/views/forms/fields/datepicker.vue";
import Datepicker from "vuejs-datepicker-inv";
//pass v- model as petition['benificiaryInfo']['financials']
  
  import _ from "lodash";
    export default {
        inject: ["parentValidator"],
       props: {
            formscope:'',
            value: Object,
           
            petition:{
                type:Object,
                default: null
            },
            countries:{
                type:Array,
                default: []
            },
            fieldsArray:{
                type:Array,
                default: []
            }
        },
        data() {
            return {
              setPasswordErrorMsg:'',
      
               startEligibleDate: new Date().setFullYear(new Date().getFullYear() - 18),

               
            };
        },
        created() {
            this.$validator = this.parentValidator;
        },
        computed: {
        },
        mounted() {
            
        },
        methods: {
            removepriorstay: function () {
                Vue.delete(this.value);
            },
            getStates(){
                let countryId = '231'
                this.$store.dispatch("getstates", countryId).then((response) => {
                    this.states_list = response
                })
            },
           
        },
        components: {
        Datepicker, 
        immiInput, 
        datepickerField
        }
    };
</script>