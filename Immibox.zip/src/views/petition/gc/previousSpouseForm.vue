<template>
    <div class="vx-col w-full">
    <div >
        <h3 class="small-header">Previous Spouse</h3>
            <div class="form-container"> 
              <div class="vx-row">
                <div class="vx-col w-full">
                  <div class="vx-row" >
             
                  <immiInput :notRequired="notRequired" :display="false" :tplsection="tplsection" :fieldsArray="fieldsArray"   wrapclass="md:w-1/2" :cid="'firstName'+cid" :formscope="formscope" v-model="value.firstName" :required="true" :fieldName="'firstName'+fieldName" label="First Name" placeHolder="First Name" :tplkey="'firstName'"/>
                  <immiInput :notRequired="notRequired" :display="false" :tplsection="tplsection" :fieldsArray="fieldsArray"   wrapclass="md:w-1/2" :cid="'middleName'+cid " :formscope="formscope" v-model="value.middleName" :required="true" :fieldName="'middleName'+fieldName " label="Middle Name" placeHolder="Middle Name" :tplkey="'middleName'"/>
                  <immiInput :notRequired="notRequired" :display="false" :tplsection="tplsection" :fieldsArray="fieldsArray"   wrapclass="md:w-1/2" :cid="'lastName'+cid " :formscope="formscope" v-model="value.lastName" :required="true" :fieldName="'lastName' +fieldName" label="Last Name" placeHolder="Last Name" :tplkey="'lastName'"/>
                  <immiInput :notRequired="notRequired" :display="false"  :tplsection="tplsection"  :fieldsArray="fieldsArray"   wrapclass="md:w-1/2" :cid="'maidenName'+cid " :formscope="formscope" v-model="value.maidenName" :required="true" :fieldName="'maidenName'+fieldName " label="Maiden Name" placeHolder="Maiden Name" :tplkey="'maidenName'"/>

                  <datepickerField :notRequired="notRequired" :display="false" :tplsection="tplsection"  :cid="'dateOfBirth'+cid" :fieldsArray="fieldsArray" :required="true" :dateEnableTo="startEligibleDate" :validationRequired="true" v-model="value.dateOfBirth" :formscope="formscope" :fieldName="'dateOfBirth'+fieldName" label="Date of Birth" :tplkey="'dateOfBirth'"/>
                  <datepickerField :notRequired="notRequired" :display="false" :tplsection="tplsection"  :cid="'dateOfMarriage'+cid" :fieldsArray="fieldsArray" :required="true"  :validationRequired="true" v-model="value.dateOfMarriage" :formscope="formscope" :fieldName="'dateOfMarriage'+fieldName" :dateEnableTo="new Date()" label="Date of Marriage" :tplkey="'dateOfMarriage'"/>
                  <datepickerField :notRequired="notRequired" :display="false" :tplsection="tplsection"  :cid="'dateOfMarriageEnd'+cid"  :fieldsArray="fieldsArray" :required="true" :dateEnableFrom="value.dateOfMarriage" :validationRequired="true" v-model="value.dateOfMarriageEnd" :formscope="formscope" :dateEnableTo="new Date()" :fieldName="'dateOfMarriageEnd'+fieldName" label="Date of Marriage Ended" :tplkey="'dateOfMarriageEnd'"/>
                  <selectField :notRequired="notRequired" :display="false" :tplsection="tplsection"  :fieldsArray="fieldsArray" :cid="'countryOfMarriage'+cid"  @input="getMarriageStates" :required="true" :optionslist="countries"  v-model="value.countryOfMarriageDetails" :formscope="formscope" :fieldName="'countryOfMarriage'+fieldName " label="Country of Marriage" vvas="Country of Marriage" placeHolder="Country of Marriage" :tplkey="'countryOfMarriage'"/> 
                  <selectField :notRequired="notRequired" :display="false" :tplsection="tplsection"  :fieldsArray="fieldsArray" :cid="'provinceOfMarriage'+cid"  @input="value.provinceOfMarriage = value.provinceOfMarriageDetails.id" :required="true" :optionslist="marriedStates" v-model="value.provinceOfMarriageDetails" :formscope="formscope" :fieldName="'provinceOfMarriage'+fieldName" label="Province of Marriage" vvas="Province of Marriage" placeHolder="Province of Marriage" :tplkey="'provinceOfMarriage'"/> 
                  <immiInput :notRequired="notRequired" :display="false" :tplsection="tplsection"  :fieldsArray="fieldsArray"  wrapclass="md:w-1/2" :cid="'locationOfMarriage' +cid" :formscope="formscope" v-model="value.locationOfMarriage" :required="true" :fieldName="'locationOfMarriage'+fieldName" label="Location of Marriage" placeHolder="Location of Marriage" :tplkey="'locationOfMarriage'"/>
                  <selectField :notRequired="notRequired" :display="false" :tplsection="tplsection"  :fieldsArray="fieldsArray" :cid="'countryOfMarriageTermination'+cid"  @input="getTerminatedStates" :required="true" :optionslist="countries" v-model="value.countryOfMarriageTerminationDetails" :formscope="formscope" :fieldName="'countryOfMarriageTermination'+fieldName " label="Country of Termination" vvas="Country of Termination" placeHolder="Country of Termination" :tplkey="'countryOfMarriageTermination'"/> 
                  <selectField :notRequired="notRequired" :display="false" :tplsection="tplsection"  :fieldsArray="fieldsArray" :cid="'provinceOfMarriageTermination'+cid"  @input="value.provinceOfMarriageTermination = value.provinceOfMarriageTerminationDetails.id" :required="true" :optionslist="terminatedStates" v-model="value.provinceOfMarriageTerminationDetails" :formscope="formscope" :fieldName="'provinceOfMarriageTermination'+fieldName" label="Province of Termination" vvas="Province of Termination" placeHolder="Province of Termination" :tplkey="'provinceOfMarriageTermination'" /> 
                  <immiInput :notRequired="notRequired" :display="false" :tplsection="tplsection"  :fieldsArray="fieldsArray"  wrapclass="md:w-1/2" :cid="'locationOfMarriageTermination' +cid" :formscope="formscope" v-model="value.locationOfMarriageTermination" :required="true" :fieldName="'locationOfMarriageTermination'+fieldName" label="Location of Termination" placeHolder="Location of Termination" :tplkey="'locationOfMarriageTermination'"/>
                  <!-- <immiswitchyesno :notRequired="notRequired" :required="checkFieldIsRequired({'key':'obtainPermResidenceThroughSpouse','section':tplsection, 'fieldsArray':fieldsArray, 'required':true,'notRequired':notRequired })"  wrapclass=" "  :tplsection="tplsection" :display="false" :formscope="formscope" :fieldsArray="fieldsArray" v-model="value.obtainPermResidenceThroughSpouse" :fieldName="'obtainPermResidenceThroughSpouse'+fieldName" label="Did you obtain U.S Permanent Residence through Spouse?" :tplkey="'obtainPermResidenceThroughSpouse'"></immiswitchyesno> -->
                  <immiyesorno :notRequired="notRequired" wrapclass=" " :required="checkFieldIsRequired({'key':'obtainPermResidenceThroughSpouse','section':tplsection, 'fieldsArray':fieldsArray, 'required':true,'notRequired':notRequired })" :tplkey="'obtainPermResidenceThroughSpouse'"  :display="false" :fieldsArray="fieldsArray" :formscope="formscope" cid="obtainPermResidenceThroughSpouse"  v-model="value.obtainPermResidenceThroughSpouse" :tplsection="tplsection"  :fieldName="'obtainPermResidenceThroughSpouse'+fieldName"  label="Did you obtain U.S Permanent Residence through Spouse?"></immiyesorno>
                  <selectField :notRequired="notRequired"  :listContainsId="false"  :tplsection="tplsection"  :display="false" :cid="'marriageEndedDueTo'+cid" :fieldsArray="fieldsArray"  :required="true" :optionslist="marriageEndedDueToList" v-model="value.marriageEndedDueTo"   :fieldName="'marriageEndedDueTo'+fieldName"  :formscope="formscope"  label="Marriage Ended Due To" placeHolder="Marriage Ended Due To" :tplkey="'marriageEndedDueTo'"/>                                            
                  <immiInput :notRequired="notRequired"  :tplsection="tplsection" :cid="'marriageEndedDueTo'+cid"  :display="false" v-if="checkProperty(value ,'marriageEndedDueTo')== 'Other'" :fieldsArray="fieldsArray"  wrapclass="md:w-1/2"  :formscope="formscope" v-model="value.marriageEndedOtherInfo" :required="true" :fieldName="'marriageEndedOtherInfo'+fieldName" label="If Marriage Ended" placeHolder="If Marriage Ended" :tplkey="'marriageEndedOtherInfo'"/>

                </div>
                </div>  
              </div>
            </div>
      </div>
    </div>  
</template>
<script>
import immiyesorno from "@/views/forms/fields/yesorno.vue";
import selectField from "@/views/forms/fields/simpleselect.vue";
import immiInput from "@/views/forms/fields/simpleinput.vue";
import datepickerField from "@/views/forms/fields/datepicker.vue";
import Datepicker from "vuejs-datepicker-inv";
import immiswitchyesno from "@/views/forms/fields/switchyesno.vue";
//pass v- model as petition['benificiaryInfo']['financials']
  export default {
    inject: ["parentValidator"],
    created() {
        this.$validator = this.parentValidator;
    },
  //   provide() {
  //     return {
  //        parentValidator: this.$validator,
  //     };
  // },
    components: { 
      immiyesorno,
      immiswitchyesno,
      selectField,
      Datepicker, 
      immiInput, 
      datepickerField
    },

    data: () => ({
     marriedStates:[],
     terminatedStates:[],
      startEligibleDate: new Date().setFullYear(new Date().getFullYear() - 18),
       marriageEndedDueToList:["Divorce","Death","Other"],
    }),
    props:{
      notRequired:{
        type: Boolean,
        default: false,
      },
      tplsection:{
            type: String,
            default: null,
        },
      fieldName: String,
      formscope: {
            type: String,
            default: ''
        },
        cid: String,
      value: Object,
      petition:{
        type:Object,
        default:null
      },
      fieldsArray:{
        type:Array,
        default:[]
      },
      countries:{
        type:Array,
        default:[]
      },
      
      
    },
    mounted(){
      
    },
    methods:{
      
      getMarriageStates(value){
        this.value.countryOfMarriage = this.value.countryOfMarriageDetails.id;
        this.value.provinceOfMarriage = null;
        this.value.provinceOfMarriageDetails = null;
        this.marriedStates=[];
        let countryId = this.value.countryOfMarriageDetails.id
        this.$store.dispatch("getstates", countryId).then((response) => {
          this.marriedStates = response
        })
      },
      getTerminatedStates(){
        this.value.countryOfMarriageTermination = this.value.countryOfMarriageTerminationDetails.id;
        this.terminatedStates = []
        this.value.provinceOfMarriageTermination = null;
        this.value.provinceOfMarriageTerminationDetails = null;
        let countryId = this.value.countryOfMarriageTerminationDetails.id
        this.$store.dispatch("getstates", countryId).then((response) => {
          this.terminatedStates = response
        })
      }
    }
  };
</script>