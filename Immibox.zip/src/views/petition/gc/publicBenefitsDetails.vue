<template>
    <div class="pad20">
        <div class="vx-row m-0 main-list-panel">
            <div class="vx-col md:w-1/3 w-full p-0">
                <div class="main-list">
                    <p>
                        check Federal, State, local or tribal case assistant for income maintenance
                        <span>{{petition.beneficiaryInfo.name}}</span>
                    </p>
                </div>
                <div class="main-list">
                    <p>
                        check Supplemental Security Income (SSI)
                        <span>{{petition.beneficiaryInfo.name}}</span>
                    </p>
                </div>
                <div class="main-list">
                    <p>
                        check Temporary Assistance for Needy Families (TANF)
                        <span>{{petition.beneficiaryInfo.name}}</span>
                    </p>
                </div>
                <div class="main-list">
                    <p>
                        check General Assistance (GA)
                        <span>{{petition.beneficiaryInfo.name}}</span>
                    </p>
                </div>
                <div class="main-list">
                    <p>
                        check Supplemental Nutrition Assistance Program (SNAP, formally called “Food Stamp”)
                        <span>{{petition.beneficiaryInfo.name}}</span>
                    </p>
                </div>
                <div class="main-list">
                    <p>
                        check Section 8 Housing Assistance under the Housing Choice Voucher Program
                        <span>{{petition.beneficiaryInfo.name}}</span>
                    </p>
                </div>
                <div class="main-list">
                    <p>
                        check Section 8 Project Based Rental Assistance (including Moderate rehabilitation)
                        <span>{{petition.beneficiaryInfo.name}}</span>
                    </p>
                </div>
                <div class="main-list">
                    <p>
                        check Public Housing under the Housing Act
                        <span>{{petition.beneficiaryInfo.name}}</span>
                    </p>
                </div>
                <div class="main-list">
                    <p>
                        check Federal Funded Medicaid
                        <span>{{petition.beneficiaryInfo.name}}</span>
                    </p>
                </div>
            
            </div>
        </div>
    </div>
</template>
    
    <script>
    export default {
        data(){
            return{
            petition:{
                beneficiaryInfo:{
                    name:'pk'
                }
            }
        }
        },
        // props: {
        //     petition: {
        //         type: Object,
        //         default: null
        //     },
        //     visastatuses: {
        //         type: Array,
        //         default: null
        //     }
        // },
        computed: {
            
        }
    };
    </script>