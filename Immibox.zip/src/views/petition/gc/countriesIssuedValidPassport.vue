<template>
    <div class="vx-col  w-full" >    
        <div class="form-container">
            <div class="vx-row">
    
                <div class="vx-col w-full prior-stay-list periods-nowrap">
                    <div class="vx-row delete-row"  v-for="(item, index) in value" :key="index" >
                        <selectField :display="true"  :fieldsArray="fieldsArray" @input="item.countryId = item.countryDetails.id" :required="true" :optionslist="countries" v-model="item.countryDetails" :formscope="formscope" :fieldName="'country' + index" label="Country" vvas="Country" placeHolder="Country" />
                        
                        <immiInput :display="true"  :fieldsArray="fieldsArray" wrapclass="md:w-1/2" :cid="'number' + index" :formscope="formscope" v-model="item.number" :required="true" :fieldName="'number' +index" label="Passport Number" placeHolder="Passport Number" />
                        
                         <datepickerField :display="true" :fieldsArray="fieldsArray" :dateEnableTo="startEligibleDate" :validationRequired="true" v-model="item.issuedDate" :formscope="formscope" :fieldName="'issuedDate'+index" label="Issued Date" />
                  
                         <datepickerField :display="true" :fieldsArray="fieldsArray" :dateEnableFrom="item.issuedDate" :validationRequired="true" v-model="item.expiryDate" :formscope="formscope" :fieldName="'expiryDate'+index" label="Expiration Date" />
                 
    
                        <div class="delete" v-if="value.length > 1" @click="removeAddress(index)">
                            <a>
                                <img src="@/assets/images/main/delete-row-img.svg" /> 
                            </a>
                        </div>
                    </div>
                </div>
               
            </div>
        </div>
        <div class="vx-row mar0" >
            <span @click="addAddress()" class="add-more">+ More</span>
        </div>
    </div>
    </template>
    
    <script>
    import Datepicker from "vuejs-datepicker-inv";
    import datepickerField from "@/views/forms/fields/datepicker.vue";
    import selectField from "@/views/forms/fields/simpleselect.vue";
    import immiInput from "@/views/forms/fields/simpleinput.vue";
    
    import Vue from "vue";
    import moment from 'moment'
    
    import _ from "lodash";
    export default {
         
        inject: ["parentValidator"],
    
        props: {
            value: Array,
           
            petition:{
                type:Object,
                default: null
            },
            countries:{
                type:Array,
                default: []
            },
            fieldsArray:{
                type:Array,
                default: []
            },
            formscope:'',
        },
        data() {
            return {
              
                startEligibleDate: new Date().setFullYear(new Date().getFullYear() - 18),
            };
        },
        created() {
            this.$validator = this.parentValidator;
        },
        computed: {
        },
        mounted() {
    
        },
        methods: {
            removepriorstay: function () {
                Vue.delete(this.value);
            },
            removeAddress(index){
              this.value.splice(index ,1);
            },
            addAddress(){
                let newAddress = {
                    countryId: '',
                    countryDetails: null,
                    number: '',
                    issuedDate: null,
                    expiryDate: null 
                }
                this.value.push(newAddress);
                this.$validator.reset();
         
            }
        },
        components: {
            selectField,
            Datepicker,
            immiInput,
            datepickerField
        }
    };
    </script>
    