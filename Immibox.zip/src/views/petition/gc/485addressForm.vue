<template>
    <div class="vs-col m-auto float-none vs-xs- vs-sm-12 vs-lg-10" vs-type="flex" vs-justify="center" vs-align="center" :class="wrapclass" > 
        <div class="form-container">
            <div class="vx-row">                                
                <div >
                    <h3 class="small-header pt-10">Address</h3>
                    <addressField :fieldsArray="questionnaireDetails" :disableCountry="value.currentlyInUS" :formscope="formscope" :showaptType="true" :addFormContainerCls="false" :validationRequired="true" :countries="countries" v-model="value.address" :cid="'beneficiaryInfoaddress'" />
                </div>
                <div >                                                                   
                    <div class="vx-col w-full d-flex">
                        <h3 class="small-header m-0" style="margin: 0 !important;margin-bottom:1rem !important; margin-top:1.5rem !important;">Current Mailing Address</h3>
                        <vs-checkbox @click="setSameaddress()"  v-model="value.mailingAddressIsSameAsAddress"
                        >Same as Address </vs-checkbox
                        >
                    </div>
                    <template v-if="value.mailingAddressIsSameAsAddress!=true && countries.length>0">                                                 
                    <addressField   :display="true" :fieldsArray="questionnaireDetails"  :formscope="formscope" :showaptType="true" :addFormContainerCls="false" :validationRequired="true" :countries="countries" v-model="value.currentAddress" :cid="'beneficiarymailInfoaddress'" />
                    </template>
                </div>
                <div class="divider full-divider mb-5"></div>
                <div>
                    <h3 class="small-header">Last Address outside Of the United States for more than one year</h3>
                    <addressField :fieldsArray="questionnaireDetails" :disableCountry="false" :formscope="formscope" :showaptType="true" :addFormContainerCls="false" :validationRequired="true" :countries="countries" v-model="value.addressOutsideUSMoreThanYear" :cid="'beneficiaryInfoaddress'" />
                    <div class="vx-row">
                        <datepickerField wrapclass="md:w-1/2" :display="true" :fieldsArray="fieldsArray" :dateEnableTo="startEligibleDate" :validationRequired="true" v-model="value.startDate" :formscope="formscope" :fieldName="'startDate'" label="From Date" />
                        <datepickerField wrapclass="md:w-1/2" :display="true" :fieldsArray="fieldsArray" :dateEnableTo="startEligibleDate" :validationRequired="true" v-model="value.endDate" :formscope="formscope" :fieldName="'endDate'" label="To Date" />
                    </div>
                    </div>
                <div class="divider full-divider mb-5"></div>
                <div>
                    <h3 class="small-header">Your Residence starting with most current for the Past Five Years in the U.S and Aboard</h3>
                    <template v-for="(item, index) in value.addressOfLastNYears">
                    <div class="delete-row">
                        <addressField :fieldsArray="questionnaireDetails" :disableCountry="false" :formscope="formscope" :showaptType="true" :addFormContainerCls="false" :validationRequired="true" :countries="countries" v-model="value.addressOfLastNYears[index]" :cid="'beneficiaryInfoaddress'" />
                        <div class="vx-row">
                            <datepickerField wrapclass="md:w-1/2" :display="true" :fieldsArray="fieldsArray" :dateEnableTo="startEligibleDate" :validationRequired="true" v-model="item.startDate" :formscope="formscope" :fieldName="'startDate'" label="From Date" />
                            <datepickerField wrapclass="md:w-1/2" v-if="index != 0" :display="true" :fieldsArray="fieldsArray" :dateEnableTo="startEligibleDate" :validationRequired="true" v-model="item.endDate" :formscope="formscope" :fieldName="'endDate'" label="To Date" />
                        </div>
                            <div class="delete" v-if="value['addressOfLastNYears'].length > 1" @click="removeAddress(index)">
                                <a>
                                    <img src="@/assets/images/main/delete-row-img.svg" />
                                </a>
                            </div>
                        </div>
                    </template>
                    
                    <div class="vx-row mar0">
                        <span @click="addAddress()" class="add-more ml-0">+ More</span>
                    </div>
                    
                </div>
            </div>
        </div>
       
    </div>
    </template>
    
    <script>
    import datepickerField from "@/views/forms/fields/datepicker.vue";
    //import datepickerField from "@/views/forms/fields/datepicker.vue";
    import selectField from "@/views/forms/fields/simpleselect.vue";
    import immiInput from "@/views/forms/fields/simpleinput.vue";
    import addressField from "@/views/forms/fields/address.vue";
    import Vue from "vue";
    import moment from 'moment'
    
    import _ from "lodash";
    export default {
        //pass props as petition['beneficiaryInfo'['assets'], assestsList
        inject: ["parentValidator"],
    
        props: {
            formscope:'',
            value: Object,
            petition:{
                type:Object,
                default:null
            },
            countries:{
                type:Array,
                default:[]
            },
            fieldsArray:{
                type:Array,
                default:[]
            },
        },
        data() {
            return {
                startEligibleDate: new Date().setFullYear(new Date().getFullYear() - 18),
            };
        },
        created() {
            this.$validator = this.parentValidator;
        },
        computed: {
        },
        mounted() {
    
        },
        methods: {
            setSameaddress(){
            setTimeout(()=>{
                if( this.value.mailingAddressIsSameAsAddress){
                    this.value['currentAddress'] = _.cloneDeep(this.value['address']);
                }else{
                    this.value['currentAddress'] =  {
                            line1: null,
                        line2: null,
                        aptType: null,
                        locationId: null,
                        locationDetails: null,
                        stateId: null,
                        stateDetails: null,
                        countryId: null,
                        countryDetails: null,
                        zipcode: null
                    }
                }
           });
        },
            
            removeAddress(index){
              this.value['addressOfLastNYears'].splice(index ,1);
            },
            addAddress(){
                let newData = {
                        line1: null,
                        line2: null,
                        aptType: null,
                        locationId: null,
                        locationDetails: null,
                        stateId: null,
                        stateDetails: null,
                        countryId: null,
                        countryDetails: null,
                        zipcode: null,
                        startDate: null,
                        endDate: null
                    }
                this.value['addressOfLastNYears'].push(newData);
                this.$validator.reset();
         
            }
        },
        components: {
            selectField,
            immiInput,
            addressField,
            datepickerField
        }
    };
    </script>
    