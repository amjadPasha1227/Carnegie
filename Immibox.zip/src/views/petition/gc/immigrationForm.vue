<template>
     
    <div class="vs-col m-auto float-none vs-xs- vs-sm-12 vs-lg-10" vs-type="flex" vs-justify="center" vs-align="center" >
    
        <div class="form-container">
            <h3 class="small-header pt-10">Immigration</h3>
            <div class="vx-row">
                <div class="vx-col w-full">
                    <div class="vx-row" >
                        <selectField :display="true"  :fieldsArray="fieldsArray"   @input="value.curNonImmigrantVisaStatus = value.curNonImmigrantVisaStatusDetails.id" :required="true" :optionslist="checkProperty(petition ,'visaStatusList' ,'length')>0?petition['visaStatusList']:[]" v-model="value.curNonImmigrantVisaStatusDetails" :formscope="formscope" fieldName="currentStatus" label="Current Status" placeHolder="Current Status" />
                        <datepickerField :display="true" :fieldsArray="fieldsArray" :dateEnableTo="startEligibleDate" :validationRequired="true" v-model="value.statusExpiryDate" :formscope="formscope" fieldName="statusExpiryDate" label="Status Expiry Date" />
                        <selectField :display="true" :fieldsArray="fieldsArray"   @input="value.stateOfLastEntryInUS = value.stateDetailsOfLastEntryInUS.id" :required="true" :optionslist="states_list" v-model="value.stateDetailsOfLastEntryInUS" :formscope="formscope" fieldName="stateOfLastEntryInUS" label="Place of Last Entry into the USA" placeHolder="Place of Last Entry into the USA" />
                        <immiInput :display="true"  :fieldsArray="fieldsArray"  wrapclass="md:w-1/2" cid="placeOfLastEntryInUS" :formscope="formscope" v-model="value.placeOfLastEntryInUS" :required="true" fieldName="placeOfLastEntryInUS" label="Place of Last Entry into the USA" placeHolder="Place of Last Entry into the USA" />
                    </div>
                    <div class="vx-row delete-row" >
                        <h3 class="small-header pl-5">All Countries that have Issued you a currently valid passport </h3>
                        <countriesIssued :fieldsArray="fieldsArray"   :display="true" :formscope="formscope"  :petition="petition"  :addFormContainerCls="false" :countries="countries" v-model="value.allIssuedPassportData" :validationRequired="true" :cid="'PlaceofLastEntryintotheUSA'" />
                    </div> 
                    <div class="divider full-divider mt-10 mb-10"></div>
                    <div class="vx-row">
                        <datepickerField :display="true" :fieldsArray="fieldsArray" :dateEnableTo="startEligibleDate" :validationRequired="true" v-model="value.caseIssuedDate" :formscope="formscope" fieldName="caseIssuedDate" label="Case Issued Date" />
                        <datepickerField :display="true" :fieldsArray="fieldsArray" :dateEnableTo="startEligibleDate" :validationRequired="true" v-model="value.caseExpiryDate" :formscope="formscope" fieldName="caseExpiryDate" label="Case Expiry Date" />
                       
                        <immiInput :display="true"  cid="placeOfCaseIssued" :fieldsArray="fieldsArray"  :formscope="formscope" v-model="value.placeOfCaseIssued" :required="true" fieldName="placeOfCaseIssued" label="Case Issued At" placeHolder="Case Issued At" />
                        
                        <datepickerField :display="true" :fieldsArray="fieldsArray" :dateEnableTo="startEligibleDate" :validationRequired="true" v-model="value.lastArrivalDate" :formscope="formscope" fieldName="lastArrivalDate" label="Most Recent Entry into the USA" />
                        <immiInput :display="true" :fieldsArray="fieldsArray"   wrapclass="md:w-1/2" cid="mannerOfLastArrival" :formscope="formscope" v-model="value.mannerOfLastArrival" :required="true" fieldName="mannerOfLastArrival" label="Manner of Most last entry into the USA" placeHolder="Manner of Most last entry into the USA" />
                        
                        <datepickerField :display="true" :fieldsArray="fieldsArray" :dateEnableTo="startEligibleDate" :validationRequired="true" v-model="value.firstArrivalDate" :formscope="formscope" fieldName="firstArrivalDate" label="Initial (First) Entry into the USA" />
                        
                        <immiInput :display="true" :fieldsArray="fieldsArray"   wrapclass="md:w-1/2" cid="reasonOfLastArrival" :formscope="formscope" v-model="value.reasonOfLastArrival" :required="true" fieldName="reasonOfLastArrival" label="Manner of Most recent entry into the USA" placeHolder="Manner of Most recent entry into the USA" />
                        
                        <datepickerField :display="true" :fieldsArray="fieldsArray" :dateEnableTo="startEligibleDate" :validationRequired="true" v-model="value.I94ExpiryDate" :formscope="formscope" fieldName="I94ExpiryDate" label="Expiration Date on Form I-94" />
                        
                        <datepickerField :display="true" :fieldsArray="fieldsArray" :dateEnableTo="startEligibleDate" :validationRequired="true" v-model="value.i140PriorityDate" :formscope="formscope" fieldName="i140PriorityDate" label="Priority Date of I-140" />
                        
                        <immiInput :display="true"  wrapclass="md:w-1/2" :fieldsArray="fieldsArray"  cid="I94" :formscope="formscope" v-model="value.I94" :required="true" fieldName="reasonOfLastArrival" label="Most Recent Form I-94 Card Number" placeHolder="Most Recent Form I-94 Card Number" />
                        
                        <datepickerField :display="true" :fieldsArray="fieldsArray" :dateEnableTo="startEligibleDate" :validationRequired="true" v-model="value.dateFromWhichResideInUs" :formscope="formscope" fieldName="dateFromWhichResideInUs" label="Date From which you have reside in the USA" />
                        
                        <immiInput :display="true"  :fieldsArray="fieldsArray"   wrapclass="md:w-1/2" cid="currentNonImmigrantCaseNumber" :formscope="formscope" v-model="value.currentNonImmigrantCaseNumber" :required="true" fieldName="currentNonImmigrantCaseNumber" label="Current Non Immigrant Case Number" placeHolder="Current Non Immigrant Case Number" />
                        <selectField :display="true"  :fieldsArray="fieldsArray"   :required="true" :optionslist="categoryList" v-model="value.classification" :formscope="formscope" fieldName="classification" label="Classification" placeHolder="Classification" />   
                        <immiswitchyesno wrapclass=" " :display="true" :fieldsArray="fieldsArray" :cid="'inspectedByAnyImmOfficer'"  :formscope="formscope" v-model="value.inspectedByAnyImmOfficer" fieldName="inspectedByAnyImmOfficer" label="Were you inspected by any Immigration Officer?" placeHolder="" />
                        <immiswitchyesno wrapclass=" " :display="true" :fieldsArray="fieldsArray" :cid="'issuedAnyEADFromUSCIS'"  :formscope="formscope" v-model="value.issuedAnyEADFromUSCIS" fieldName="issuedAnyEADFromUSCIS" label="Have you ever Been Issued an Employment Authorization document (EAD) from the USCIS?" placeHolder="" />
                        <immiswitchyesno wrapclass=" " :display="true" :fieldsArray="fieldsArray" :cid="'enterInUSUnderCaseWaiverProgram'"  :formscope="formscope" v-model="value.enterInUSUnderCaseWaiverProgram" fieldName="enterInUSUnderCaseWaiverProgram" label="Did You Enter in US Under Case Waiver Program" placeHolder="" />                        
                        <immiswitchyesno wrapclass=" " :display="true" :fieldsArray="fieldsArray" :cid="'hasPermResidencyInOtherCountry'"  :formscope="formscope" v-model="value.hasPermResidencyInOtherCountry" fieldName="hasPermResidencyInOtherCountry" label="Do you hold Permanent Residence in other country?" placeHolder="" />
                        <selectField  :display="true" v-if="value.hasPermResidencyInOtherCountry"  :fieldsArray="fieldsArray"  @input="value.permResidencyCountryId = value.permResidencyCountryDetails.id" :required="true" :optionslist="countries" v-model="value.permResidencyCountryDetails" :formscope="formscope" fieldName="Country" label="Country" placeHolder="Country" />
                        <immiswitchyesno wrapclass=" " :display="true" :fieldsArray="fieldsArray" :cid="'everAppliedAOSInUS'"  :formscope="formscope" v-model="value.everAppliedAOSInUS" fieldName="everAppliedAOSInUS" label="Have you ever applied for AOS in the U.S. or an Immigrant Case at an U.S. Embassy/Consulate to obtain permanent resident status before?" placeHolder="" />
                        
                    </div>
                </div>
            </div>
        </div>
    
    </div>
    </template>
    
    <script>
    import addressField from "@/views/forms/fields/address.vue";
    import countriesIssued from "@/views/petition/gc/countriesIssuedValidPassport.vue";
    import redioButtons from "@/views/forms/fields/redioButtons.vue";
    import datepickerField from "@/views/forms/fields/datepicker.vue";
    import selectField from "@/views/forms/fields/simpleselect.vue";
    import immiInput from "@/views/forms/fields/simpleinput.vue";
    import Datepicker from "vuejs-datepicker-inv";
    import immiswitchyesno from "@/views/forms/fields/switchyesno.vue";
    
    import Vue from "vue";
    import moment from 'moment'
    
    import _ from "lodash";
    export default {
        inject: ["parentValidator"],
       props: {
            formscope:'',
            value: Object,
           
            petition:{
                type:Object,
                default: null
            },
            countries:{
                type:Array,
                default: []
            },
            fieldsArray:{
                type:Array,
                default: []
            }
        },
        data() {
            return {
                openDate: new Date().setFullYear(new Date().getFullYear()),
                startEligibleDate: new Date().setFullYear(new Date().getFullYear() - 18),
                states_list:[],
                categoryList:['EB-1','EB-2','EB-3'],
               
            };
        },
        created() {
            this.$validator = this.parentValidator;
        },
        computed: {
        },
        mounted() {
            this. getStates()
        },
        methods: {
            removepriorstay: function () {
                Vue.delete(this.value);
            },
            getStates(){
                let countryId = '231'
                this.$store.dispatch("getstates", countryId).then((response) => {
                    this.states_list = response
                })
            },
           
        },
        components: {
            datepickerField,
            selectField,
            Datepicker,
            redioButtons,
            addressField,
            countriesIssued,
            immiInput,
            immiswitchyesno
        }
    };
    </script>
    