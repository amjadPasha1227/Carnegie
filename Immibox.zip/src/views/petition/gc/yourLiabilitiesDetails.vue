<template>
    <div class="pad20">
        <div class="vx-row m-0 main-list-panel" v-for="(item,index) in petition['liabilities']">
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(item,'accountType' )">
                <div class="main-list">
                    <p>
                       Account
                        <span>{{checkProperty(item,'accountType' )}}</span>
                    </p>
                </div>
            </div> 
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(item,'amount' )">
                <div class="main-list">
                    <p>
                       Amount
                        <span>{{checkProperty(item,'amount' ) | formatprice}}</span>
                    </p>
                </div>
            </div>
        </div>
    </div>
</template> 
<script>
export default {
    props: {
        petition: {
            type: Object,
            default: null
        }
    },
}
</script>    