<template>
    <div class="pad20">
        <div class="vx-row m-0 main-list-panel">
            <div class="vx-col md:w-1/3 w-full p-0">
                <div class="main-list">
                    <p>
                        Deposits in Bank in the USA
                        <span>{{petition.beneficiaryInfo.name}}</span>
                    </p>
                </div>
                <div class="main-list">
                    <p>
                        Value of Real Estate, If Owned
                        <span>{{petition.beneficiaryInfo.name}}</span>
                    </p>
                </div>
                <div class="main-list">
                    <p>
                        Cash Surrender Value of Life Insurance
                        <span>{{petition.beneficiaryInfo.name}}</span>
                    </p>
                </div>
                <div class="main-list">
                    <p>
                        Reasonable Value of Personal Property
                        <span>{{petition.beneficiaryInfo.name}}</span>
                    </p>
                </div>
                <div class="main-list">
                    <p>
                        Market Value of Stocks and Bons
                        <span>{{petition.beneficiaryInfo.name}}</span>
                    </p>
                </div>
                <div class="main-list">
                    <p>
                        Health Insurance Renewal Date
                        <span>{{petition.beneficiaryInfo.name}}</span>
                    </p>
                </div>
                <div class="main-list">
                    <p>
                        Credit Score
                        <span>{{petition.beneficiaryInfo.name}}</span>
                    </p>
                </div>
                <div class="main-list">
                    <p>
                        Amount of Mortgage on the Property
                        <span>{{petition.beneficiaryInfo.name}}</span>
                    </p>
                </div>
                
            
            </div>
        </div>
    </div>
</template>
    
    <script>
    export default {
        data(){
            return{
            petition:{
                beneficiaryInfo:{
                    name:'pk'
                }
            }
        }
        },
        // props: {
        //     petition: {
        //         type: Object,
        //         default: null
        //     },
        //     visastatuses: {
        //         type: Array,
        //         default: null
        //     }
        // },
        computed: {
            
        }
    };
    </script>