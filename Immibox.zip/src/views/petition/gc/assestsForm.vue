<template>
    <div class="vs-col m-auto float-none vs-xs- vs-sm-12 vs-lg-10" vs-type="flex" vs-justify="center" vs-align="center" :class="wrapclass" > 
        <h3 class="small-header pt-10">Assets</h3>   
        <div class="form-container">
            <div class="vx-row">
                <div class="vx-col w-full prior-stay-list periods-nowrap">
                    <div class="vx-row delete-row" v-for="(item, index) in value" :key="index" >
                        <selectField :display="true"  @input="item.typeId = item.typeDetails.id" :required="true" :optionslist="assestsList" v-model="item.typeDetails" :formscope="formscope" :fieldName="'typeDetails' + index" label="Type" vvas="Type" placeHolder="Type" /> 
                        <immiInput :display="true"  wrapclass="md:w-1/2" :cid="'nameOfHolder' + index" :formscope="formscope" v-model="item.nameOfHolder" :required="true" :fieldName="'nameOfHolder' +index" label="Name of the Holder" placeHolder="Name of the Holder" />
                        <immiInput :display="true"  wrapclass="md:w-1/2" :cid="'amount' + index" :formscope="formscope" v-model="item.amount" :required="true" :fieldName="'amount' +index" label="Amount" placeHolder="Amount" />
                        <div class="delete" v-if="value.length > 1" @click="removeAddress(index)">
                            <a>
                                <img src="@/assets/images/main/delete-row-img.svg" />
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="vx-row mar0" >
            <span @click="addAddress()" class="add-more">+ More</span>
        </div>
    </div>
    </template>
    
    <script>
    //import datepickerField from "@/views/forms/fields/datepicker.vue";
    import selectField from "@/views/forms/fields/simpleselect.vue";
    import immiInput from "@/views/forms/fields/simpleinput.vue";
    
    import Vue from "vue";
    import moment from 'moment'
    
    import _ from "lodash";
    export default {
        //pass props as petition['beneficiaryInfo'['assets'], assestsList
        inject: ["parentValidator"],
    
        props: {
            formscope:'',
            value: Array,
           
            assestsList:{
                type:Array,
                default:null
            },
            petition:{
                type:Object,
                default:null
            }
        },
        data() {
            return {

            };
        },
        created() {
            this.$validator = this.parentValidator;
        },
        computed: {
        },
        mounted() {
    
        },
        methods: {
            
            removeAddress(index){
              this.value.splice(index ,1);
            },
            addAddress(){
                let newData = {
                    typeId: '', 
                    typeDetails: null, 
                    nameOfHolder: '', 
                    amount: '' 
                }
                this.value.push(newData);
                this.$validator.reset();
         
            }
        },
        components: {
            selectField,
            immiInput
        }
    };
    </script>
    