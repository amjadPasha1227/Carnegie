<template>
    <div class="vs-col m-auto float-none vs-xs- vs-sm-12 vs-lg-10" vs-type="flex" vs-justify="center" vs-align="center">
        <h3 class="small-header pt-10"> Public Benefits</h3>
        <form>
            <div class="form-container">
                <template v-for="(item,index) in publicBenefitsList">
                    <div class="vx-col w-full "> 
                        <vs-checkbox v-model="item.isSelected" @change="getPublicBenefits">
                        {{item.name}}
                        </vs-checkbox>
                    </div>
                </template>
            </div>
        </form>
    </div>
</template>
<script>

  export default {
    created() {
        this.$validator = this.parentValidator;
    },
    provide() {
      return {
         parentValidator: this.$validator,
      };
    },
    components: {
        
    },
    props:{
        fieldsArray:{
                type:Array,
                default:[]
            },
        petition:{
                type:Object,
                default:null
            },
        formscope:'',
        value: null,
    },
    data: () => ({
        publicBenefits:[],
        publicBenefitDetail:[],
        publicBenefitsList:[]
    }),
    methods:{

        

        prePopLatePublicBenefits(){
            //publicBenefits
           // petition['beneficiaryInfo']['publicBenefits']
            if(this.checkProperty(this.publicBenefitsList ,'length' )>=0 && this.checkProperty( this.value ,'publicBenefits') &&this.checkProperty( this.value ,'publicBenefits' ,'length')>0  ){
             
                _.map(this.publicBenefitsList ,(item)=>{
                    item['isSelected'] =false;
                    if(this.value['publicBenefits'].indexOf(item.id) >=0){
                        item['isSelected'] =true;
                    }

                })
                

            }

        },
        getPublicBenefits(e){
            this.value['publicBenefits'] =[];
            this.publicBenefitDetail =[];
            _.forEach(this.publicBenefitsList, (item)=>{
                if(item.isSelected){
                    //this.publicBenefits.push(item.id)
                    this.publicBenefitDetail.push(item)
                    this.value.publicBenefits.push(item.id)
                }
            });
            this.prePopLatePublicBenefits();
        }
    },
    mounted() {
    
        this.$store.dispatch("getmasterdata", "public_benefits").then((response) => {
                let list = response;
                _.forEach( list,(item) => {
                   item =Object.assign(item,{ 'isSelected':false});
                });
                this.publicBenefitsList = _.cloneDeep(list);
                
            });
    }
  };
</script>