<template>
  <div class="main-list-wrap">
    <div class="communication_list_wrap pad20 pb-0">
        <div  v-if="commenterror" class="eroormessage">{{commenterror}}</div>
        <div class="communication_input message_input" v-if="this.checkProperty(getPetitionDetails ,'status')!=false">
           <!----New Design-->
          <div v-if="true" class="message-textarea">
            <quillTextEditor @input="manageDraft" :wrapclass="'md:w-1/1 mb-0'" v-model="comment" :label="'Message'"
              :fieldName="'message'" :required="true" :cid="'message'" :placeHolder="'Message'" :customValidNotRequire="true" />
                        
            <!-- <immitextfield @input="manageDraft" wrapclass="md:w-1/1"  :formscope="''"  v-model="comment" :required="true" fieldName="message"
             label="Message" placeHolder="Message"></immitextfield> -->
            <multiselect
             v-if="[51].indexOf(getUserRoleId) <=-1"
              v-model="selecteduser"
              :options="userslist"
              :multiple="true"
              :hideSelected="true" 
              :close-on-select="false"
              :clear-on-select="false" 
              :preserve-search="true"
              :select-label="'Select User'" 
              placeholder="Select Users"
              label="name"
              track-by="name"
              :preselect-first="false"
              :searchable="true"
              class="text-area-multiselect"
              @input="setLawFirm"
              >
              <template slot="selection" slot-scope="{ values, isOpen }">
                <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }} User(s)
                  selected</span>
                <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
              </template>
            </multiselect> 
            <div class="btn-check">
            <ul v-if="true" class="demo-alignment custom-radio"  vs-type="flex"   vs-align="center" >
              <li>
                <vs-checkbox vs-name="notifyNow" v-model="notifyNow" class="message-check">
                  Notify Immediately
                </vs-checkbox>
              </li>
            </ul>
            <div class="d-flex align-center">
              <template  v-if="communicationlist && communicationlist.length>0 ">
                <!-- <button class="export_btn"  @click="printPage()"><img class="user-image" src="@/assets/images/icons/share.png" />Print</button> -->
                <button class="export_btn" v-if="[50,51].indexOf(getUserRoleId) <=-1" @click="exportPage(selectedMessageId)"><img class="user-image" src="@/assets/images/icons/share.png" />Export</button>
              </template>
              <button :disabled="comment==null || comment=='<div><br></div>' || comment=='' || submitingComment || comment.trim() ==''"  @click="submitComment()" class="submit mart10">Submit</button>
            </div>
            
          </div>
          </div>
      

            
          <Mentionable
          v-if="false"
      :keys="['@']"
      :items="userslist"
      offset="6"  @open="getusers()"
      @onselect="selectedUsercallback"
    >
      <textarea  @input="manageDraft"  placeholder="@ Send Message" v-model="comment"/>
        
        <template #no-result>
            <div class="no_list">
                No Results found
            </div>
        </template>
        <template  #item-@="{ item }">        
            <div class="mentionList">
              <figure><img class="user-image" src="@/assets/images/main/avatar3.svg"></figure>
              <p>{{ item.name }}<span>{{ item.roleName }} </span></p>
            </div>         
        </template>
        


              <button :disabled="comment==null || comment=='' || submitingComment || comment.trim() ==''"  @click="submitComment()" class="submit">Submit</button>



    </Mentionable>
    
  

      
        </div>
        <div class="communication_list_cnt communication_list_cnt_v2" :id="'printMessageId'">
          <!-- <div class="inbox_sent_wrapper">
          <button type="border" class="inbox_btn " :class="{'active':selectedMsgType == 'inbox'}" @click="selectedMsgType = 'inbox';getmessages()" >Inbox</button>
          <button type="border" class="sent_btn" :class="{'active':selectedMsgType == 'sent'}"  @click="selectedMsgType = 'sent';getmessages()">Sent</button> 
        </div>-->
        <template v-if="communicationlist && communicationlist.length>0 ">
          <!-- selectedMessageId -->
          <!-- <button class="export_btn" v-if="[50,51].indexOf(getUserRoleId) <=-1" @click="exportPage(selectedMessageId)"><img class="user-image" src="@/assets/images/icons/share.png" />Export</button> -->
        <VuePerfectScrollbar
            ref="mainSidebarPs"
            class="scroll-area--main-sidebar"
            :settings="settings"
            @ps-scroll-y="scroll"
          >
          <template v-for="(item ,itemIndex) in communicationlist">
            <div class="communication_list" :key="itemIndex" :class="{'unread':checkProperty(item,'read') == false}" >
              <!-- <div class="message_actions">
                  <span class="mark_as_read" v-if="checkProperty(item,'read')" @click="markAsRead(item,false)">
                    Mark as Unread
                  </span>
                  <span class="mark_as_unread" v-else @click="markAsRead(item,true)">
                    Mark as Read
                  </span>
              </div> -->
              <figure>
                <img class="user-image" src="@/assets/images/main/avatar2.svg" />
              </figure>
              <div class="communication_details communication_details-v2 2"> 
                <div class="message_body_wrap padr20">
                  <div class="message_actions">
                    <span class="mark_as_read" v-if="checkProperty(item,'read')" @click="markAsRead(item,false)">
                      Mark as Unread
                    </span>
                    <span class="mark_as_unread" v-else @click="markAsRead(item,true)">
                      Mark as Read
                    </span>
                  </div>
                  <p class="message-body" v-html="checkProperty(item ,'message')"> 
                
                  </p>
                </div>
                
              
                <label class="sent-by">Sent By <b>{{checkProperty(item,'fromUserName')+' ('+checkProperty(item,'fromUserRoleName') +')'}}</b> On <b>{{item.createdOn  | formatDateTime }}</b></label>
                <label class="sent-by" v-if="getAssigneeName({'msgItem':item}) != ''">Assigned To
                <b>{{getAssigneeName({'msgItem':item})}}</b> </label>
                <!-- <div class="assined_removed_labels" v-if="checkProperty(item,'labels') && checkProperty(item,'labels','length')>0 && checkProperty(item,  'completed' )" >
                  <span>Assigned Label(s) 
                    <div class="message_sec">
                      <div class="message_lables">
                        <ul class="label_list" >
                          <template v-for="(labe,inde) in item['labels'] ">
                            <li :style="{'background-color':labe['color']}">
                              {{ checkProperty(labe,'name')  }}
                            </li>
                          </template>
                        </ul> 
                      </div>
                    </div>
                  </span>
                </div> -->
                
              <template v-if="checkProperty(item,'fromUserId') == checkProperty(getUserData, 'userId') && false">
                <div v-if=" checkProperty(item ,'toUserIds') && checkProperty(item ,'toUserIds' ,'length')>0 ">
                  <label class="sent-to" @click="showTaggedDetails(true, item)">Tagged to 
                    
                    <b> {{ checkProperty(item ,'toUserIds' ,'length') }}  Members</b><img src="@/assets/images/main/eye.png" width="15px"/>
                    <!-- <ul class="recipients-list">
                        <li v-for="(item,index) in item.toUserList" :key="index" >{{item.name}}</li>
                    </ul> -->
                  </label>
                </div>
                <!-- <span class="sent-to" @click="openAssignPopup(item)">Assign</span>
                <span class="sent-to" @click="makeAsCompleted(item)" >Make as Complete</span> -->
              </template>
              <template v-if="[50,51].indexOf(getUserRoleId) <=-1">
                <div class="new_msg_wrap">
                  <!-- <span class="msg_completed" v-if="checkProperty(item,  'completed' )"><em></em>Completed</span> -->
                  <div class="msg_actions"  >
                    <template v-if="
                    !item['completed'] &&
                    [50,51].indexOf(getUserRoleId) <=-1 &&
                    (
                      (checkProperty(item,  'actionUserIds' ,'length')==0 && checkProperty(item,  'toUserIds' ,'length')==0 ) 
                      || (checkProperty(item,  'toUserIds' ,'length')>0 && checkProperty(item,  'showMakeAsComplete' ) ) 
                      || ( checkCaseAdmin || checkProperty(item,  'createdByMe' ))
                      
                      ) && false"  >
                      <button @click="makeAsCompleted(item)" class="mark_as_complete_btn"><em></em>Mark as Complete
                        <span class="loader" v-if="loadingMessage"
                          ><img src="@/assets/images/main/loader.gif"
                        /></span>
                      </button>
                    </template>
                      
                      <messageLabel  :petition="petition" :callFromDetails="true" @updateLabels="updateLabels" @updateUserIds="updateUserIds" @openCreateLabel="openCreateLabel" :labelsList="labelsList" :message="item" />
                      <!-- <button @click="openAssignPopup(item)" class="msg_assign_btn">Assign</button> -->
                  </div>
                  <div class="msg_description_newv2" v-if="checkProperty(item,  'activityLogs' ,'length')>0">
                    <ul>
                      <li v-for="( aLog ,indx) in item['activityLogs']">
                        <span class="msg_desc" v-html=" aLog.comment "></span>
                        <span class="msg_date">On {{ aLog.createdOn | formatDateTime }}</span>
                      </li>
                    </ul>
                  </div>
                </div> 
              </template>
              </div>
            </div>
          </template>
          </VuePerfectScrollbar>
        </template>
        <template v-if="communicationlist && communicationlist.length>0 && false" >
          <div class="msg_actions_details">
            <messageLabel  :petition="petition" :callFromDetails="true" @updateLabels="updateLabels" @updateUserIds="updateUserIds" @openCreateLabel="openCreateLabel" :labelsList="labelsList" :message="selectedMessageId" />
            <div class="message_actions">
                  <button class="export_btn" @click="exportPage(selectedMessageId)"><img class="user-image" src="@/assets/images/icons/share.png" />Export</button>
                  <span class="mark_as_read" v-if="checkProperty(selectedMessageId,'read')" @click="markAsRead(selectedMessageId,false)">
                    Mark as Unread
                  </span>
                  <span class="mark_as_unread" v-else @click="markAsRead(selectedMessageId,true)">
                    Mark as Read
                  </span>
            </div>
          </div>
          
          <!-- selectedMessageId -->
          <VuePerfectScrollbar
            ref="mainSidebarPs"
            class="scroll-area--main-sidebar message_scrool"
            :settings="settings"
            @ps-scroll-y="scroll"
          >
          <div class="communication_list" :key="itemIndex"  v-for="(item ,itemIndex) in communicationlist"  >

            <figure>
              <img class="user-image" src="@/assets/images/main/avatar2.svg" />
            </figure>
            <div class="communication_details communication_details-v2 1"> 
              <template v-if="[50,51].indexOf(getUserRoleId) <=-1">
                <div class="new_msg_wrap" v-if="checkProperty(item,  'activityLogs' ,'length')>0">
                  <div class="msg_description_newv2" v-if="checkProperty(item,  'activityLogs' ,'length')>0">
                    <ul>
                      <li v-for="( aLog ,indx) in item['activityLogs']">
                        <span class="msg_desc" v-html=" aLog.comment "></span>
                        <span class="msg_date">On {{ aLog.createdOn | formatDateTime }}</span>
                      </li>
                    </ul>
                  </div>
                </div> 
              </template>
              <p class="message-body" v-html="checkProperty(item ,'message')"></p>
              <label class="sent-by">Sent By <b>{{checkProperty(item,'fromUserName')+' ('+checkProperty(item,'fromUserRoleName') +')'}}</b> On <b>{{item.createdOn  | formatDateTime }}</b></label>
              <!-- <label class="sent-by" v-if="getAssigneeName({'msgItem':item}) != ''">Assigned To
              <b>{{getAssigneeName({'msgItem':item})}}</b> </label> -->
            </div>
          </div>
          </VuePerfectScrollbar>
        </template>  
        <template >  
              <NoDataFound v-if="communicationlist.length<=0" ref="NoDataFoundRef"  content="" heading="No Messages Found" type='Communication' />
        </template>
        </div>
    </div>
    <!-- <vs-popup class="holamundo main-popup" :title="'Assign Message'" :active.sync="showAssignPopUpModal">
        <form @submit.prevent data-vv-scope="assignMessagepopupform">
          <div class="popup-accounts-content" v-if="showAssignPopUpModal">
            <div class="form-container padb20" @click="assignErrorMsg=''">
             
            </div>
            <div class="popup-footer">
              <div class="d-flex">
                <vs-button color="dark" class="cancel" type="filled" @click="showAssignPopUpModal =false">Cancel
                </vs-button>
                <vs-button color=" success" class="save" type="filled" @click="assignMessage();"
                  :disabled="loadingMessage">
                  Assign
                </vs-button>
              </div>
            </div>
          </div>
  
        </form>
      </vs-popup> -->
      <modal
          name="showAssignPopUpModal"
          classes="v-modal-sec"
          :min-width="200"
          :min-height="200"
          :scrollable="true"
          :reset="true"
          width="650px"
          height="auto"
        >
        <div class="v-modal profile_details_modal error-modal-space" >
          <div class="popup-header fromDetailsPage">
            <h2 class="popup-title">
              Assign 
            </h2>
            <span @click="$modal.hide('showAssignPopUpModal');assignErrorMsg=''">
              <em class="material-icons">close</em>
            </span>
          </div>
          <form data-vv-scope="assignMessagepopupform" class="relative" @submit.prevent @keydown.enter.prevent>
        <div
          class="popup_info"
         
          @click="assignErrorMsg = ''"
        >
         
          
        </div>
        <div class="form-container">
          <div class="form_group">
              <div class="vx-row">
                <selectField :placeHolder="'Select User'"  :display="true" :wrapclass="'md:w-full'"  :fieldsArray="[]" :required="true" :optionslist="assignUserList" v-model="message.assignedTo"   :fieldName="'assignedTo'"  formscope="assignMessagepopupform"  label="User" vvas="User" placeholder="User" />
                
                </div>
              </div>
              <div v-if="assignErrorMsg ">
                <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius"
                  icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ assignErrorMsg}}
                </vs-alert>
              </div>
        </div>
  
        <div class="popup-footer relative">
          <span class="loader" v-if="loadingMessage"
            ><img src="@/assets/images/main/loader.gif"
          /></span>
          <vs-button
            color="dark"
            @click="$modal.hide('showAssignPopUpModal')"
            class="cancel"
            type="filled"
            >Cancel</vs-button>
          <vs-button
            :disabled="loadingMessage"
            color="success"
            @click="assignMessage()"
            class="save"
            type="filled"
            >Assign 
          </vs-button>
        </div>
      </form>
          </div>
    </modal> 
    <vs-popup
      class="holamundo main-popup taggedlistmodal"
      :title="'Tagged '"
      v-if="taggedModal"
      :active.sync="taggedModal"
    >
      <div class="taggedlist">
      
        <ul>
          <template v-for="(member, index) in userDetails">
            <li :key="index">
              <figure>
                <img :src="checkProperty(member ,'profilePicture')"  @error="setDefaultPhoto($event)" />
              </figure>
              <figcaption>
                {{ checkProperty(member, "name")
                }}<span>{{ checkProperty(member, "roleName") }}</span>
              </figcaption>
             
            </li>
          </template>
        </ul>
        
      </div>
    </vs-popup>
    <modal
          name="showtaggedModal"
          classes="v-modal-sec"
          :min-width="200"
          :min-height="200"
          :scrollable="true"
          :reset="true"
          width="480px"
          height="auto"
        >
        <div class="v-modal profile_details_modal error-modal-space" >
          <div class="popup-header fromDetailsPage">
            <h2 class="popup-title">
            Tagged Members 
            </h2>
            <span @click="$modal.hide('showtaggedModal')">
              <em class="material-icons">close</em>
            </span>
          </div>
          <div class="taggedlist">
            <ul>
              <template v-for="(member, index) in userDetails">
                <li :key="index">
                  <figure>
                    <img :src="checkProperty(member ,'profilePicture')"  @error="setDefaultPhoto($event)" />
                  </figure>
                  <figcaption>
                    {{ checkProperty(member, "name")
                    }}<span>{{ checkProperty(member, "roleName") }}</span>
                  </figcaption>
                
                </li>
              </template>
            </ul>
          </div>
          
          </div>
    </modal> 
    <messageCreateLabel v-if="showCreate" :message="selectedMessage" @hideMe="hideMe" />
  </div>
</template>

 
<script>
import quillTextEditor from "@/views/forms/fields/quillTextEditor.vue";
import messageCreateLabel from "@/views/messages/messageCreateLabel.vue";
import messageLabel from "@/views/messages/messagesLabels.vue";
import immitextfield from "@/views/forms/fields/simpleTextField.vue";
import selectField from "@/views/forms/fields/simpleselect.vue";    
import Mentionable from "../../components/Mentionable";
import NoDataFound from "@/views/common/noData.vue";
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import * as _ from "lodash";
export default {
  provide() {
            return {
                parentValidator: this.$validator,
            };
        },
      components: {
        quillTextEditor,
        messageCreateLabel,
        messageLabel,
        VuePerfectScrollbar,
        immitextfield,
        selectField,
    Mentionable,
    NoDataFound
  },
      data() {
    return {
      selectedMsgType:'inbox',
      selectedMessage:null,
      showCreate:false,
      labelsList:[],
      message:{
        assignedTo:null,
        notifyNow:false,
      },
      assignErrorMsg:'',
      loadingMessage:false,
      showAssignPopUpModal:false,
      selectedItem:null,
      notifyNow:true,
      submitingComment:false,
        communicationlist:[],
        selectedMessageId:null,
      comment:"",
      userDetails:null,
        taggedModal:false,
        assignUserList:[],
      selecteduser:[],
        userslist:[],
        commenterror:'',
        perPage:25000,
        page:1,
        countTotalPages:1,
        settings: { 
        swipeEasing: false,
        
        markLoading:false,
        
      },
    }},
  props: {
    allbtn: false,
    userId:null,
    petition: {
      type: Object,
      default: null
    },
    workFlowDetails:{
      type: Object,
      default: null
    }
  },
  watch: {
    $route() {
      this.communicationlist = []
           this.getmessages();

    },
  },
  mounted() {
    this.getmessages();
    this.getusers();
    this.setDraftedMsg();
    this.getLabelsList();
    this.showCreate = false;
  },
  methods: {
    exportPage(obj){
      let Payload= {
                  "filters": {
                    getPtnrAndOtherInfo:true,
                      "entityType": this.checkProperty(obj,'entityType'),
                      "petitionIds": [this.checkProperty(obj,'petitionId')],
                      forCaseDetails: true
                  },
                  "page": 1,
                  "perpage": 100
              }
              let path = '/petition/export-messages'; 
              this.$store.dispatch("commonAction", {'data':Payload,'path':path}).then(response => {
                
                let fileObj ={
                  name: this.checkProperty(response,'fileName'),
                  path:this.checkProperty(response,'s3UrlPath'),
                  status: true,
                }
                this.downloads3file(fileObj);
              })
              .catch(error => {
                this.showToster({ message: error, isError: true });
              })
    },
    printPage(){
      const printableContent = document.getElementById('printMessageId');
      const printWindow = window.open('', '_blank');
        //printWindow.document.write('<html><head><title>Print</title></head><body>');printWindow.document.write('</body></html>')
        printWindow.document.write(printableContent.innerHTML);
        
        printWindow.document.close();
        printWindow.print();
      //alert('printMessageId')
    },
    markAsRead(val,action){
      let item = val
        let Payload ={
          messageId:this.checkProperty(item,'_id'),
          read:action
        };
        let path = 'communication/manage-read'
        this.$store.dispatch("commonAction", { "data": Payload, "path": path }).then((response)=>{
          this.showToster({message:response.message ,isError:false});
          this.getmessages()
        }).catch((err)=>{

        })
    },
    hideMe(){
      this.selectedMessage = null;
      this.showCreate = false;
      this.getmessages();
      this.getLabelsList();
    },
    updateUserIds(){
      this.getmessages();
    },
    updateLabels(){
      this.getmessages();
    },
    openCreateLabel(val){
      this.selectedMessage = val;
      this.showCreate = true;
    },
    getLabelsList(){
      let payLoad={
        matcher:{
          statusList:[],
          searchString:''
        },
        page:1,
        perpage:10000
      };
      let path='/message-label/list'
      this.$store.dispatch("getList", { "data": payLoad, "path": path }).then((response)=>{
        if(response.list){
          let list = response.list;
          let tempList = []
          _.forEach(list,(item)=>{
            if(!_.has(item,'id')){
              item['id'] = item['_id'];
              tempList.push(item)
            }
          })
          if(this.checkProperty(tempList,'length')>0){
            this.labelsList = tempList
          }
        }
      }).catch((err)=>{

      })
    },
    setLawFirm(){
      if(this.checkProperty(this.selecteduser,'length')>0 && this.checkProperty(this.petition,'typeDetails','id')){
        let findLawFirm = _.find(this.selecteduser,{'userId':'Law_Firm'})
        if(findLawFirm){
          this.selecteduser = [];
          this.selecteduser.push(findLawFirm)
        }
      }
     
    },
    setDraftedMsg(){
      let self =this;
      let messageDraftList =[];
      if(localStorage.getItem('messageDraftList')){
        messageDraftList = JSON.parse(localStorage.getItem('messageDraftList'));
      }


   

      let messageDraft =_.find(messageDraftList ,(data)=>{
        return data['userId'] == self.checkProperty(self.getUserData ,'userId') && data['petitionId'] ==self.petition._id
      });
     
      if(messageDraft && _.has(messageDraft ,'message')){
       
        self.comment = messageDraft['message'];
       
      }
     

      


    },
    manageDraft(){
     
      let self =this;
      let messageDraftList =[];
      if(localStorage.getItem('messageDraftList')){
        messageDraftList = JSON.parse(localStorage.getItem('messageDraftList'));
      }


      let postdata = {
        petitionId: self.petition._id,
        message:self.comment,
        userId:self.checkProperty(self.getUserData ,'userId'),
       
      };

      messageDraftList =_.filter(messageDraftList ,(data)=>{
        return data['userId'] != self.checkProperty(self.getUserData ,'userId') && data['petitionId'] !=self.petition._id
      });
      messageDraftList.push(postdata);
      localStorage.setItem('messageDraftList', JSON.stringify(messageDraftList));


      


    },
    makeAsCompleted(item){
      let markedItem = item
      let payload ={
        messageId:this.checkProperty(markedItem,'_id'),
      } 
      this.markLoading = true;
      this.$store.dispatch("commonCaseAction", {"data":payload ,"path":"/communication/mark-as-complete"})
      .then(response => {
        this.getmessages();
        this.markLoading = false;
        this.showToster({message:response.message ,isError:false});
      })
      .catch(err=>{
        this.markLoading = false;
        this.showToster({message:err.message ,isError:true});
      })
    },
    openAssignPopup(selectItem){
      this.message={
        assignedTo:null,
        notifyNow:false,
      },
      this.assignUserList = [];
      this.selectedItem = selectItem
      if(this.userslist && this.checkProperty(this.userslist,'length')>0){
        //actionUserIds toUserList 
        if(
           (this.selectedItem && this.checkProperty(this.selectedItem,'actionUserIds') && this.checkProperty(this.selectedItem,'actionUserIds','length')>0 )
          ){
          _.forEach(this.userslist,(uitem)=>{
            let item = _.cloneDeep(uitem);
            let isExists = this.selectedItem['actionUserIds'].indexOf(item['_id'])>-1?true:false
            let toUser = _.find(this.checkProperty(this.selectedItem,'toUserList'),{_id:item['_id']})
            

            if(!isExists && item['_id'] != this.checkProperty(this.getUserData ,'userId') ){
              Object.assign(item,{'id':item['_id']})
              if([50,51].indexOf(item['roleId'])<=-1){
               
                if(_.has(item ,'tempName')){
                  item['name'] =item['tempName'];
                }
                
                this.assignUserList.push(item)
              }
              
            }
          })
          if(this.assignUserList && this.checkProperty(this.assignUserList,'length')>0){
            this.$modal.show('showAssignPopUpModal')
          }
        }
        else{
          this.assignUserList = [];
          _.forEach(this.userslist,(item)=>{
            Object.assign(item,{'id':item['_id']})
            if([50,51].indexOf(item['roleId'])<=-1){
                this.assignUserList.push(item)
            }
          })
          this.$modal.show('showAssignPopUpModal')
        }
      }
      
    },
    assignMessage(){
      let payload ={
        messageId:'',
        userIds:[],
        notifyNow:true,
      }
      this.$validator.validateAll('assignMessagepopupform').then(result => {
        if(result){
          if(this.checkProperty(this.message,'assignedTo') && this.checkProperty(this.message,'assignedTo','_id') ){
            payload['userIds'].push(this.checkProperty(this.message,'assignedTo','_id'))
          }
          
          if(this.checkProperty(this.selectedItem,'_id')){
            payload['messageId'] = this.checkProperty(this.selectedItem,'_id')
          }
          this.$store.dispatch("commonCaseAction", {"data":payload ,"path":"/communication/assign-to-user"})
          .then(response => {
            this.getmessages();
            this.selectedItem = null;
            this.showToster({message:response.message ,isError:false});
            this.$modal.hide('showAssignPopUpModal')
          })
          .catch(err=>{
            this.assignErrorMsg =  err.message
          })
        }
      })
    },
    scroll(e) {
      const { target } = e;
    
      if (
       
        Math.ceil(target.scrollTop) >=
        target.scrollHeight - target.offsetHeight
      ) {
        //this code will run when the user scrolls to the bottom of this div so
        //you could do an api call here to implement lazy loading
        //this.countTotalPages

        if (this.page < this.countTotalPages) {
         this.page = this.page + 1;
          
          this.getmessages(true);
         
        }
      }
    },
    makeAsReads(){
      
          let postData = {"messageIds":[]};
     let messages =  _.filter(this.communicationlist ,(item)=>{
             return ( this.checkProperty(item ,'fromUserId') != this.checkProperty(this.getUserData ,'userId')) && this.checkProperty(item,'read') !=true;
       })

         postData['messageIds'] =messages.map((item)=>item['_id']);
 
       if(this.checkProperty(postData['messageIds'] ,'length') >0){
        
      
         this.$store.dispatch("commonAction", {"data":postData ,"path":"/communication/mark-as-read"}).then((response) => {
           
        })

       }
       
    },
selectedUsercallback(item){
  let isExistUser = _.find(this.selecteduser ,{"_id":item['_id']})
  if(isExistUser){
    this.selecteduser  = _.filter(this.selecteduser ,(user)=>{
      return user['_id'] !=item['_id'];

    })

  }else{
     this.selecteduser.push(item);

  }
 
               this.commenterror = null;

},
 submitComment(){
  
   this.commenterror = '';
      let postdata = {
        petitionId: this.petition._id,
        petitionCaseNo:this.petition.caseNo,
        message:this.comment,
        toUserIds:[],
        "entityType":'case',
      };

      if([15].indexOf(this.checkProperty(this.petition,'subTypeDetails', 'id' )) >-1){
        postdata['entityType'] ='perm';
        }
        let findLawFirm =  null;
        if(this.selecteduser && this.checkProperty(this.selecteduser,'length')>0){
          findLawFirm = _.find(this.selecteduser,{'userId':'Law_Firm'})
        }
        
        if(findLawFirm){
          postdata['toUserIds'] = [];
        }else{
          postdata['toUserIds'] =  this.selecteduser.map(user =>user._id)
        }
    
      // if(!this.selecteduser){
      //   this.commenterror  = 'Please Mention a User using @';
      // }
       if(!this.comment){
        this.commenterror  = 'Please enter your message';
      }
      if(this.commenterror!='') return false;
      this.submitingComment =true;
      postdata['notifyNow'] = this.notifyNow;
      this.$store.dispatch("submitcomment", postdata).then(response => {
        this.submitingComment =false;
           this.notifyNow = true;
           this.notifyNow = true;
            this.page = 1;
            this.countTotalPages = 1;
            this.getmessages();
             this.commenterror = null;
             this.comment=null;
             this.comment ='';
             this.selecteduser=[];
             this.$validator.reset();
             this.$validator.reset();
             this.manageDraft();
      })
      .catch(error => {
        this.submitingComment =false;
        this.showToster({ message: error, isError: true });

      })

 },
    getusers() {
      let postdata = {
        petitionId: this.petition._id,
        petitionType:"NORMAL"  //"GC" // 'RFE', 'NORMAL' ,'PERM'
      };

      if(( [3].indexOf(this.checkProperty(this.petition ,'typeDetails' ,'id'))>-1 && [15].indexOf(this.checkProperty(this.petition ,'subTypeDetails' ,'id'))>-1)){
        postdata['petitionType'] = 'PERM'
      }

      this.$store.dispatch("getcommunicationuserslist", postdata).then(response => {
         let ignoreUsers =[]
         if([3,4,5,6,7,8,9,10,11,12,13,14].indexOf(this.getUserRoleId) >-1){
           ignoreUsers =[3,4,5,6,7,8,9,10,11,12,13,14];
         }else if([50].indexOf(this.getUserRoleId) >-1){
           ignoreUsers =[];
         }else if([51].indexOf(this.getUserRoleId) >-1){
           ignoreUsers =[3,4,5,6,7,8,9,10,11,12,13,14];
         }
         if(ignoreUsers.length>0 && response.length>0){
          response  = _.filter(response , (usr)=>{
            return ignoreUsers.indexOf(usr['roleId'])<=-1
          })
         }
         let tempList  = response
        //  _.forEach(response ,(obj)=>{

        //   if(_.has(obj ,'roleName')){
        //     obj['tempName'] = obj['name']+" ("+obj['roleName']+")"
        //   }
        //   tempList.push(obj);
        //  })
         let modifiedList = [];
         if(this.checkProperty(this.petition,'typeDetails','id')){
          if([50,51].indexOf(this.getUserRoleId) <=-1){
            let lawOffice = {
              _id: "625806e7621cbad27e27766c",
              roleId: 65,
              branchId: "Law_Firm",
              userId: "Law_Firm",
              name: "Law Firm",
              value: "Law Firm",
              roleName: "Law Firm",
              tempName: "Law Firm"
            };
            modifiedList.push(lawOffice);
            let removedList = [];
            let petitionerObj = _.find(tempList,{'roleId':50});
            if(petitionerObj){
              petitionerObj['name'] = 'Petitioner';
              petitionerObj['tempName'] = 'Petitioner';
              removedList =  _.filter(tempList,(item)=>{
                return [50].indexOf(item['roleId'])<=-1
              });
              modifiedList.push(petitionerObj);
            }
            if((this.checkCHildH4 || this.checkSPouseH4) || [2,10].indexOf(this.checkProperty(this.petition, 'typeDetails', 'id'))>-1){
                let benObj = _.find(tempList,{'roleId':51});
                if(benObj && _.has(benObj,'name')){
                  benObj['name'] = 'Beneficiary';
                  benObj['tempName'] = 'Beneficiary';
                  removedList =  _.filter(removedList,(item)=>{
                    return item['roleId'] != 51
                  });
                  modifiedList.push(benObj);
                }
            }
            else{
              if(removedList && this.checkProperty(removedList,'length')>0){
                removedList =  _.filter(removedList,(item)=>{
                  return item['roleId'] != 51
                });
                //console.log(JSON.stringify(removedList))
              }else{
                removedList =  _.filter(tempList,(item)=>{
                  return [50,51].indexOf(item['roleId'])<=-1
                });
              }
              
            }
            tempList = _.cloneDeep(removedList)
          }
          if([50].indexOf(this.getUserRoleId) >-1){
            let lawOffice = {
              _id: "Law Firm",
              roleId: 65,
              branchId: "Law_Firm",
              userId: "Law_Firm",
              name: "Law Firm",
              value: "Law Firm",
              roleName: "Law Firm",
              tempName: "Law Firm"
            };
            modifiedList.push(lawOffice);
            let removedList = [];
            if((this.checkCHildH4 || this.checkSPouseH4) || [2,10].indexOf(this.checkProperty(this.petition, 'typeDetails', 'id'))>-1){
                let benObj = _.find(tempList,{'roleId':51});
                if(benObj && _.has(benObj,'name')){
                  benObj['name'] = 'Beneficiary';
                  benObj['tempName'] = 'Beneficiary';
                  removedList =  _.filter(tempList,(item)=>{
                    return item['roleId'] != 51
                  });
                  modifiedList.push(benObj);
                }
            }else{
              if(removedList && this.checkProperty(removedList,'length')>0){
                removedList =  _.filter(removedList,(item)=>{
                  return item['roleId'] != 51
                });
              }else{
                removedList =  _.filter(tempList,(item)=>{
                  return [50,51].indexOf(item['roleId'])<=-1
                });
              }
              
            }
            tempList = _.cloneDeep(removedList)
            // if(removedList && this.checkProperty(removedList,'length')>0){
            //   tempList = _.cloneDeep(removedList)
            // }
          }
        }
        if([50].indexOf(this.getUserRoleId) <=-1){
          _.forEach(tempList,(item)=>{
            modifiedList.push(item);
         })
        }
        
            this.userslist = modifiedList;
      });
    },
    getmessages(callFromScrolle=false) {

      if(!callFromScrolle){
        this.page =1;
        this.countTotalPages =1;

      }
      let postdata = {
     
        filters:{
          entityType:'case',
          petitionIds:[],
          forCaseDetails: true
          // msgListType:this.selectedMsgType,
        },
      //  petitionId: this.petition._id,
        page:this.page,
        perpage:this.perPage
      };
      if([15].indexOf(this.checkProperty(this.petition,'subTypeDetails', 'id' )) >-1){
        postdata['filters']['entityType'] ='perm';
        }
      let petitionId = this.$route.params.itemId;
      if(!petitionId && this.checkProperty(this.getPetitionDetails ,"_id")){
        petitionId = this.checkProperty(this.getPetitionDetails ,"_id");

      }
      postdata['filters']['petitionIds'] = [petitionId];
      this.communicationlist =[];
       this.updateLoading(true);
      this.$store.dispatch("getcommunicationbypetition", postdata).then(response => {
        let self = this
       let allList =[]
       let toUsersList = [];
          if(response['toUserList'] && self.checkProperty(response, 'toUserList', 'length')>0){
            toUsersList = response['toUserList'];
          }
        _.forEach(response['list'] ,(msg)=>{

                msg['showMakeAsComplete'] =false;
                msg['createdByMe'] =false;
                //actionUserIds
                //toUserList
                if(_.has(msg, 'toUserIds') &&  self.checkProperty(msg,'toUserIds', 'length')>0 && toUsersList && self.checkProperty(toUsersList, 'length')>0){
                  msg['toUserList'] = [];
                  _.forEach(msg['toUserIds'],(itd)=>{
                    let findOb = _.find(toUsersList,{'_id':itd});
                    if(findOb){
                      msg['toUserList'].push(findOb)
                    }
                  })
                }else{
                  if(!_.has(msg, 'toUserList')){
                    msg['toUserList'] = [];
                  }
                  
                }
                if(this.checkProperty( msg ,"actionUserIds" ,'length')>0){
                  let isExists = msg['actionUserIds'].indexOf(this.checkProperty(this.getUserData ,'userId'))>-1?true:false
                 if(isExists){
                  msg['showMakeAsComplete'] =true;
                  }
                }
                 if( this.checkProperty(msg , 'fromUserId') && this.checkProperty(msg , 'fromUserId')==this.checkProperty(this.getUserData ,'userId')){
                  msg['createdByMe'] =true;
                 }
                allList.push(msg)
             
              })
           
           
           if(callFromScrolle){
             _.forEach( allList ,(item)=>{
                 this.communicationlist.push(item);
             })
             this.countTotalPages = response.totalCount / this.perPage;
              
           }else{
              this.communicationlist = allList;
              this.countTotalPages = response.totalCount / this.perPage;
           }
           if(this.communicationlist && this.checkProperty(this.communicationlist,'length')>0){
            this.selectedMessageId = this.communicationlist[0]
           }
            setTimeout(()=>{
              //this.makeAsReads();
            },300)
             this.updateLoading(false);
      }).catch((err)=>{
        //alert(err)
                   this.updateLoading(false);
                   this.communicationlist =[];
                   this.countTotalPages =1;
                   this.page =1;
                   
            })
    },
    showTaggedDetails(action = false, item) {
      this.userDetails = null;
      let selectedItemm = item
      
      let Payload= {
        "matcher": {
        "title": "",
        "searchString": "",
        "userIds": [],
        "statusIds": [],
        "petitionSubTypeIds": [],
        "petitionSearchString": "",
        "createdDateRange": []
      },
      "sorting": {
        "path": "createdOn",
        "order": 1
      },
      "page": 1,
      "perpage": 100,
      //"getBeneficiaryList": true,
      "getMasterData": true
      }
      if(this.checkProperty(selectedItemm,'toUserIds')){
        Payload['matcher']['userIds'] = this.checkProperty(selectedItemm,'toUserIds')
      }

      this.$store.dispatch("commonAction", {"data":Payload ,"path":"/users/list"})
      .then(response => {
        this.userDetails = response.list
        if(this.userDetails){
          this.$modal.show('showtaggedModal')
          //this.taggedModal = action;
        }
      })
    },
    downloadfile(value) {
      value.url = value.url.replace(this.$globalgonfig._S3URL,"");
       value.url = value.url.replace(this.$globalgonfig._S3URLAWS,"");
       
      let postdata = { keyName: value.url };
      this.$store.dispatch("getSignedUrl", postdata).then(response => {
        window.open(response.data.result.data, "_blank");
      });
    }
  },
  computed:{
    getAssigneeName(){
        let self = this;
        return (data)=>{
          let returnVal = '';
          if(_.has( data ,'msgItem') && _.has( data['msgItem'],'toUserList') && self.checkProperty(data['msgItem'],'toUserList','length')>0  ){
            _.forEach(data['msgItem']['toUserList'],(dtItm)=>{
              if(_.has(dtItm,'name') && this.checkProperty(dtItm,'name')){
                if(this.checkProperty(dtItm,'roleId') == 50 && [50,51].indexOf(this.getUserRoleId) <=-1){
                  dtItm['name'] = 'Petitioner'
                }
                if(returnVal == ''){
                  returnVal = dtItm['name']
                }else{
                  returnVal = returnVal+', '+ dtItm['name']
                }
                
              }
            })
          }
          return returnVal
        }
        
        
      },
    checkCHildH4(){
      let returnVal = false;
      if(this.checkProperty(this.petition,'dependentsInfo','childrens') && this.checkProperty(this.petition['dependentsInfo'],'childrens','length')>0 ){
        _.forEach(this.petition['dependentsInfo']['childrens'],(item)=>{
          if(_.has(item,'h4Required') && this.checkProperty(item,'h4Required') && _.has(item,'h4EADRequired') && this.checkProperty(item,'h4EADRequired') ){
            returnVal = true;
            return returnVal;
          }else if (this.checkProperty(item,'h4Required')){
            returnVal = true;
            return returnVal;
          }else if (this.checkProperty(item,'h4EADRequired')){
            returnVal = true;
            return returnVal;
          }
        })
      }
      return returnVal;
    },
    checkSPouseH4(){
      let returnVal = false;
      if(this.checkProperty(this.petition,'dependentsInfo','spouse')){
        if(this.checkProperty(this.petition['dependentsInfo'],'spouse','h4Required') && this.checkProperty(this.petition['dependentsInfo'],'spouse','h4EADRequired')){
          returnVal = true;
          return returnVal;
        }else if(this.checkProperty(this.petition['dependentsInfo'],'spouse','h4Required')){
          returnVal = true;
          return returnVal;
        }else if(this.checkProperty(this.petition['dependentsInfo'],'spouse','h4EADRequired')){
          returnVal = true;
          return returnVal;
        }
      }
      return returnVal;
    },

    checkCaseAdmin(){

      //{{ workFlowDetails MANAGER_LIST  config }}
      let returnValue =false;
      let managerList =[];
      let userId=  this.checkProperty(this.getUserData ,'userId');
      if(this.workFlowDetails && this.checkProperty(this.workFlowDetails ,'config' ,'length') >0){
        let config = this.workFlowDetails['config'];
        let managerActivity = _.find(config ,{"code":'MANAGER_LIST'});
        if(managerActivity && this.checkProperty(managerActivity ,'editors' ,'length') >0 ){
          let editors = managerActivity['editors'];
          managerList = editors.map((editor)=>editor.roleId)
          if(managerList.indexOf(this.getUserRoleId) >-1){
      
                returnValue =true;
           }

        }
        
      }
   
      
      return returnValue;
    }
  }
};
</script>