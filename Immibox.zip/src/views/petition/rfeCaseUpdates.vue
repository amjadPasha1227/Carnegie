<template>
    <div class="main-list-wrap">
       <div class="">
           <section>
            <div class="case-approved-detailes gc-case perm-caseupdates" v-if="false">
                <div class="case-approved-body">
                   <div class="left">
                    <h5 class="primary ">RFE Received</h5>
                    <ul>
                        <li v-if="getActionCompletedDate('EFILE_PREM_APPLICATION')">
                            <p>Updated Date <span> {{getActionCompletedDate('EFILE_PREM_APPLICATION') | formatDateTime}}</span></p>
                        </li>
                        <li v-if=" checkProperty(petition ,'priorityDate')">
                            <p>Filed Date <span> {{checkProperty(petition ,'priorityDate') | formatDate}}</span></p>
                        </li>
                        <li v-if="getActivityByCode('EFILE_PREM_APPLICATION') && checkProperty(getActivityByCode('EFILE_PREM_APPLICATION') ,'data' ,'permApplicationNo' ) || checkProperty(petition ,'permApplicationNo') ">
                            <p v-if="getActivityByCode('EFILE_PREM_APPLICATION') && checkProperty(getActivityByCode('EFILE_PREM_APPLICATION') ,'data' ,'permApplicationNo' ) ">PERM Application No <span >
                                {{checkProperty(getActivityByCode('EFILE_PREM_APPLICATION') ,'data' ,'permApplicationNo' ) }}
                                </span>
                            </p>
                            <p v-else-if="checkProperty(petition ,'permApplicationNo') ">PERM Application No <span >
                                {{checkProperty(petition ,'permApplicationNo') }}
                                </span>
                            </p>
                        </li>
                    </ul>
                   </div>
                   <div class="right">
                      <ul v-if="checkProperty(petition ,'permDraftLogs' ,'length')>0 ">
                        <template v-if="checkProperty(petition['permDraftLogs'][0] ,'documents' ,'length')>0 " >
                         <li @click="downloadfile(petition.permDraftLogs[0].documents[0])">
                            <figure class="view-detailes_cnt"><img src="@/assets/images/download-white.svg"></figure>
                         </li>
                         </template>
                      </ul>
                   </div>
                </div>
            </div>
           
            <div class="case-approved-detailes gc-case perm-caseupdates">
                <div class="case-approved-body" v-if="checkProperty(petition ,'completedActivities') &&
                    (petition['completedActivities'].indexOf('USCIS_APPROVED')>-1
                    ||  petition['completedActivities'].indexOf('USCIS_RECEIVED_RFE')>-1
                    ||  petition['completedActivities'].indexOf('USCIS_DENIED')>-1
                    ||  petition['completedActivities'].indexOf('USCIS_WITHDRAWN')>-1
                    ||  petition['completedActivities'].indexOf('UPDATE_USCIS_RESPONSE')>-1
                    )">
                   <div class="left" :class="{
                     'success':petition['completedActivities'].indexOf('USCIS_APPROVED')>-1,
                     'error':petition['completedActivities'].indexOf('USCIS_RECEIVED_RFE')>-1
                       || petition['completedActivities'].indexOf('USCIS_DENIED')>-1 
                       || petition['completedActivities'].indexOf('USCIS_WITHDRAWN')>-1


                   }"
                   >
                    <h5 class="success">
                        <template v-if="petition['completedActivities'].indexOf('USCIS_APPROVED')>-1">   Approved</template>
                        <template v-else-if="petition['completedActivities'].indexOf('USCIS_RECEIVED_RFE')>-1">   RFE Received </template>
                        <template v-else-if="petition['completedActivities'].indexOf('USCIS_DENIED')>-1">   Denied </template>
                        <template v-else-if="petition['completedActivities'].indexOf('USCIS_WITHDRAWN')>-1">   Withdrawn </template>
                       <template v-else>  USCIS Response</template>
                    </h5>
                    <ul v-if="checkProperty(benficiaryFinalLog, 'data') && checkProperty(benficiaryFinalLog ,'data' ,'rfeNotice' ) && checkProperty(benficiaryFinalLog['data'] ,'rfeNotice','documents' ) 
                    && checkProperty(benficiaryFinalLog['data']['rfeNotice'],'documents', 'length')>0">
                        <li>
                            <vs-col class="padl0 padr0" >
                                <documentsView :showTitle="false" @download_or_view="downloadfile"  :documentsList="checkProperty(benficiaryFinalLog['data'] ,'rfeNotice','documents' )" :petitionDetails="petition" />
                            </vs-col>
                        </li>
                    </ul>
                    <ul>
                        <li v-if="checkProperty(benficiaryFinalLog, 'data') && checkProperty(benficiaryFinalLog['data'], 'rfeNotice', 'receivedDate' )">
                             <p>Received Date <span> {{checkProperty(benficiaryFinalLog['data'], 'rfeNotice', 'receivedDate' ) | formatDate}} </span></p>
                        </li>
                        <li v-if="checkProperty(benficiaryFinalLog, 'data') && checkProperty(benficiaryFinalLog['data'], 'rfeNotice', 'issuedDate' )">
                             <p>Issued Date <span> {{checkProperty(benficiaryFinalLog['data'], 'rfeNotice', 'issuedDate' ) | formatDate}} </span></p>
                         </li>
                        <li v-if="checkProperty(benficiaryFinalLog, 'data') && checkProperty(benficiaryFinalLog['data'], 'rfeNotice', 'dueDate' )">
                             <p>Due Date <span> {{checkProperty(benficiaryFinalLog['data'], 'rfeNotice', 'dueDate' ) | formatDate}} </span></p>
                         </li>
                        <li v-if="checkProperty(benficiaryFinalLog ,'endedOn' )">
                             <p>Updated On  <span> {{checkProperty(benficiaryFinalLog ,'endedOn' ) | formatDate}} </span></p> 
                        </li>
                    </ul>
                   </div>
                   <div class="right" v-if="false">
                    <ul v-if="checkProperty(benficiaryFinalLog, 'data') && checkProperty(benficiaryFinalLog ,'data' ,'rfeNotice' ) && checkProperty(benficiaryFinalLog['data'] ,'rfeNotice','documents' ) 
                    && checkProperty(benficiaryFinalLog['data']['rfeNotice'],'documents', 'length')>0">
                        <li @click="downloadfile(benficiaryFinalLog['data']['rfeNotice']['documents'][0])">
                            <figure class="view-detailes_cnt"><img src="@/assets/images/download-white.svg"></figure>
                        </li>
                    </ul>
                   </div>
                </div>
                <div class="case-approved-detailes case-approved-detailes-v2 docket_submitted_USCIS" v-if="checkProperty(petition ,'courierTrackingDetails') && checkProperty(petition ,'courierTrackingDetails' ,'length')>0 && checkSubmitToUSCIS">
                    <h2 class="case-heading"> Docket Submitted to USCIS</h2>
                    <template  v-for="(tracking ,ind ) in petition.courierTrackingDetails" >

                        <div  :key="ind" v-if="tracking.category == 'COURIER_TRACKING' && checkProperty(tracking,'trackingDataLogs' ,'length' )> 0 && checkProperty(tracking.trackingDataLogs[0] ,'data') && checkProperty(tracking.trackingDataLogs[0] ,'data' ,'origin_info') " >

                        <div class="case-approved-body" :key="aind" v-for="(atracking ,aind ) in tracking.trackingDataLogs[0].data.origin_info.trackinfo">
                        <div class="left">
                            <ul>
                                <li  class="primary" v-if="atracking.StatusDescription"> {{atracking.StatusDescription}}</li>
                                <li v-if="atracking.Details && atracking.Date">
                                <p>{{atracking.Details}} <span> {{atracking.Date | formatDateTime }}</span></p>
                                </li>
                                <li  class="primary" v-if="atracking.tracking_detail"> {{atracking.tracking_detail}}</li>
                                <li v-if="atracking.location && atracking.checkpoint_date">
                                <p>{{atracking.location}} <span> {{atracking.checkpoint_date | formatDateTime }}</span></p>
                                </li>
                            </ul>
                        </div>
                        <div class="right">
                            <ul>
                                    
                                    
                                     <li ><a class="viewdetails" target="_blank" :href="checkProperty(tracking ,'trackingUrl' )"> View Details</a></li>
                            
                            </ul>
                        </div>
                        </div>
                    </div>

                    <div class="case-approved-body" :key="ind" v-if="tracking.category == 'COURIER_TRACKING'" >
                        <div class="left">
                            <ul>
                                <li  class="primary">Submitted</li>
                                <li>
                                <p>Created date
                                    
                                <span> {{tracking.createdOn | formatDateTime }}</span></p>
                                </li>
                                <li v-if="checkProperty(tracking ,'sentDate')">
                                <p>Sent Date
                                    <span>{{checkProperty(tracking ,'sentDate') | formatDate}}</span></p>
                                </li>
                                
                                <li>
                                <p>Tracking Number
                                    <a target="_blank" :href="checkProperty(tracking ,'trackingUrl' )" > <span>{{checkProperty(tracking ,'trackingId')}}</span></a> 
                                </p>

                                </li>
                            </ul>
                        </div>
                        <div class="right">
                            <ul>
                                <li ><a class="viewdetails" target="_blank" :href="checkProperty(tracking ,'trackingUrl' )"> View Details</a></li>
                            
                            </ul>
                        </div>
                    </div>
                    </template>
                </div>
                <div class="case-approved-body" v-if="checkProperty(petition ,'completedActivities') && petition['completedActivities'].indexOf('SUBMIT_TO_USCIS')>-1">
                   <div class="left">
                    <h5 class="primary "> Filed with USCIS</h5>
                    <ul>
                        <li class="w-full" v-if="getActionCompletedDate('SUBMIT_TO_USCIS') != null && checkProperty(getActionCompletedDate('SUBMIT_TO_USCIS'),'data', 'comment')">
                            <p class="comment-sec">Comments  <span class="wrapall" v-html="checkProperty(getActionCompletedDate('SUBMIT_TO_USCIS'),'data', 'comment')"></span></p>
                        </li>
                        <li v-if="getActionCompletedDate('SUBMIT_TO_USCIS') != null">
                             <p>Updated Date <span> {{checkProperty(getActionCompletedDate('SUBMIT_TO_USCIS'), 'endedOn') | formatDateTime}} </span></p>
                        </li>
                    </ul>
                   </div>
                   <div class="right">
                    <ul>
                        
                    </ul>
                   </div>
                </div>
                <div class="case-approved-body" v-if=" checkWorkActivityisRequires('REQUEST_PETITIONER_SIGN') && checkProperty(petition ,'completedActivities') && (petition['completedActivities'].indexOf('UPLOAD_SIGNED_DOCUMENTS')>-1  || petition['completedActivities'].indexOf('UPLOAD_SCANNED_COPY')>-1 ) ">
                   <div class="left">
                    <h5 class="primary "> Uploaded signed copies </h5>
                    <ul>
                       
                        <li v-if="getActionCompletedDate('UPLOAD_SCANNED_COPY') != null">
                             <p>Uploaded On <span> {{checkProperty(getActionCompletedDate('UPLOAD_SCANNED_COPY'), 'endedOn') | formatDateTime}} </span></p>
                        </li> 
                        <li v-else-if="getActionCompletedDate('UPLOAD_SIGNED_DOCUMENTS') != null">
                             <p>Uploaded On <span> {{checkProperty(getActionCompletedDate('UPLOAD_SIGNED_DOCUMENTS'), 'endedOn') | formatDateTime}} </span></p>
                        </li>
                       
                        
                       
                    </ul>
                   </div>
                   <div class="right">
                    
                   </div>
                </div>

                <div class="case-approved-body" v-if=" checkWorkActivityisRequires('REQUEST_PETITIONER_SIGN') && checkProperty(petition ,'completedActivities') && petition['completedActivities'].indexOf('REQUEST_PETITIONER_SIGN')>-1 ">
                   <div class="left">
                    <h5 class="primary ">  Sent For Petitioner Signature</h5>
                    <ul v-if="getActionCompletedDate('REQUEST_PETITIONER_SIGN') != null && checkProperty(getActionCompletedDate('REQUEST_PETITIONER_SIGN'), 'data')
                      && checkProperty(getActionCompletedDate('REQUEST_PETITIONER_SIGN'), 'data','documents') && checkProperty(getActionCompletedDate('REQUEST_PETITIONER_SIGN').data,'documents','length')>0 " >
                        <li>
                            <vs-col class="padl0 padr0" >
                                <documentsView :showTitle="false" @download_or_view="downloadfile"  :documentsList="checkProperty(getActionCompletedDate('REQUEST_PETITIONER_SIGN'), 'data','documents')" :petitionDetails="petition" />
                            </vs-col>
                        </li>
                    </ul>
                    <ul>
                        <li class="w-full" v-if="getActionCompletedDate('REQUEST_PETITIONER_SIGN') != null && checkProperty(getActionCompletedDate('REQUEST_PETITIONER_SIGN'),'data', 'comment')">
                            <p class="comment-sec">Comments  <span class="wrapall" v-html="checkProperty(getActionCompletedDate('REQUEST_PETITIONER_SIGN'),'data', 'comment')"></span></p>
                        </li>
                        <li v-if="getActionCompletedDate('REQUEST_PETITIONER_SIGN') != null">
                             <p>Updated Date <span> {{checkProperty(getActionCompletedDate('REQUEST_PETITIONER_SIGN'), 'endedOn') | formatDateTime}} </span></p>
                        </li> 
                       
                        
                       
                    </ul>
                   </div>
                   <div class="right">
                    
                   </div>
                </div>
                <div class="case-approved-body" v-if="checkProperty(petition ,'completedActivities') && petition['completedActivities'].indexOf('CASE_APPROVED')>-1">
                   <div class="left ">
                    <h5 class="primary "> Response Documents Approved</h5>
                    <ul>
                        <li class="w-full" v-if="getActionCompletedDate('CASE_APPROVED') != null && checkProperty(getActionCompletedDate('CASE_APPROVED'),'data', 'comment')">
                            <p class="comment-sec">Comments  <span class="wrapall" v-html="checkProperty(getActionCompletedDate('CASE_APPROVED'),'data', 'comment')"></span></p>
                        </li>
                        <li v-if="getActionCompletedDate('CASE_APPROVED') != null">
                             <p>Updated Date <span> {{checkProperty(getActionCompletedDate('CASE_APPROVED'), 'endedOn') | formatDateTime}} </span></p>
                        </li>
                    </ul>
                   </div>
                   <div class="right" >
                   
                   </div>
                </div>
                <div class="case-approved-body" v-if="checkProperty(petition ,'completedActivities') && petition['completedActivities'].indexOf('RFE_REVIEW_RESPONSE_DOCS')>-1">
                   <div class="left ">
                    <h5 class="primary "> Response Documents Sent For Approval</h5>
                    <ul v-if="getActionCompletedDate('RFE_REVIEW_RESPONSE_DOCS') != null && checkProperty(getActionCompletedDate('RFE_REVIEW_RESPONSE_DOCS'), 'data')
                      && checkProperty(getActionCompletedDate('RFE_REVIEW_RESPONSE_DOCS'), 'data','rfeResDocs') && checkProperty(getActionCompletedDate('RFE_REVIEW_RESPONSE_DOCS').data,'rfeResDocs','length')>0 && false" >
                        <li>
                            <vs-col class="padl0 padr0" >
                                <documentsView :showTitle="false" @download_or_view="downloadfile"  :documentsList="checkProperty(getActionCompletedDate('RFE_REVIEW_RESPONSE_DOCS'), 'data','rfeResDocs')" :petitionDetails="petition" />
                            </vs-col>
                        </li>
                    </ul>
                    <ul>
                        <li class="w-full" v-if="getActionCompletedDate('RFE_REVIEW_RESPONSE_DOCS') != null && checkProperty(getActionCompletedDate('RFE_REVIEW_RESPONSE_DOCS'),'data', 'comment')">
                            <p class="comment-sec">Comments  <span class="wrapall" v-html="checkProperty(getActionCompletedDate('RFE_REVIEW_RESPONSE_DOCS'),'data', 'comment')"></span></p>
                        </li>
                        <li v-if="getActionCompletedDate('RFE_REVIEW_RESPONSE_DOCS') != null">
                            <p>Updated Date <span> {{checkProperty(getActionCompletedDate('RFE_REVIEW_RESPONSE_DOCS'), 'endedOn') | formatDateTime}} </span></p>
                        </li>
                    </ul>
                   </div>
                   <div class="right">
                    <ul v-if="!(checkProperty(petition ,'completedActivities') && petition['completedActivities'].indexOf('CASE_APPROVED')>-1)">
                        <li v-if="enableActionBtns('Response Documents Sent For Approval') && checkActionsBtnPermissionss('CASE_APPROVED')" @click="$refs['actionsPopups'].openassignActivityPopup([],'Approve Response Docs','Approve Response Docs','CASE_APPROVED')">
                            <div class="relative">
                                <vs-button   class="light-blue-btn">Approve Response Docs</vs-button>
                            </div>
                        </li>
                       
                       
                    </ul>
                   </div>
                </div>
                <div class="case-approved-body" v-if="checkProperty(petition ,'completedActivities') && petition['completedActivities'].indexOf('RFE_PREPARE_RESPONSE_DOCS')>-1 ">
                   <div class="left ">
                    <h5 class="primary ">Response Documents Prepared</h5>
                    <ul v-if="getActionCompletedDate('RFE_PREPARE_RESPONSE_DOCS') != null && checkProperty(getActionCompletedDate('RFE_PREPARE_RESPONSE_DOCS'), 'data')
                      && checkProperty(getActionCompletedDate('RFE_PREPARE_RESPONSE_DOCS'), 'data','rfeResDocs') && checkProperty(getActionCompletedDate('RFE_PREPARE_RESPONSE_DOCS').data,'rfeResDocs','length')>0 " >
                        <li>
                            <vs-col class="padl0 padr0" >
                                <documentsView :showTitle="false" @download_or_view="downloadfile"  :documentsList="checkProperty(getActionCompletedDate('RFE_PREPARE_RESPONSE_DOCS'), 'data','rfeResDocs')" :petitionDetails="petition" />
                            </vs-col>
                        </li>
                    </ul>
                    <ul>
                        <li v-if="getActionCompletedDate('RFE_PREPARE_RESPONSE_DOCS') != null"> 
                             <p>Updated Date <span>{{checkProperty(getActionCompletedDate('RFE_PREPARE_RESPONSE_DOCS'), 'endedOn') | formatDateTime}} </span></p> 
                        </li>
                    </ul>
                   </div>
                   <div class="right" >
                      <ul v-if="!(checkProperty(petition ,'completedActivities') && petition['completedActivities'].indexOf('RFE_REVIEW_RESPONSE_DOCS')>-1)">
                        <li  v-if="enableActionBtns('Response Docs Prepared') && checkActionsBtnPermissionss('RFE_REVIEW_RESPONSE_DOCS')" @click="$refs['actionsPopups'].openRefePrepareResDocsPopUp('RFE_REVIEW_RESPONSE_DOCS')">
                            <div class="relative">
                                <vs-button   class="light-blue-btn">Send Response Docs For Approval</vs-button>
                            </div>
                        </li>
                       
                    </ul>
                   </div>
                </div>
                <div class="case-approved-body" v-if="checkProperty(petition ,'completedActivities') && petition['completedActivities'].indexOf('CREATE_PETITION')>-1 ">
                   <div class="left">
                    <h5 class="primary ">Case Created</h5>
                    <ul>
                        <li v-if="checkProperty(petition, 'createdOn')"> 
                            <p>Created Date <span> {{checkProperty(petition, 'createdOn') | formatDateTime}}</span></p>
                         </li>
                         <li v-if="checkProperty(petition, 'rfeIssuedDate')"> 
                            <p> Issued Date <span> {{checkProperty(petition, 'rfeIssuedDate') | formatDate}}</span></p>
                         </li>
                         <li v-if="checkProperty(petition, 'rfeReceivedDate')"> 
                            <p> Received Date <span> {{checkProperty(petition, 'rfeReceivedDate') | formatDate}}</span></p>
                         </li>
                         <li v-if="checkProperty(petition, 'rfeDueDate')"> 
                            <p> Due Date <span> {{checkProperty(petition, 'rfeDueDate') | formatDate}}</span></p>
                         </li>
                         <li v-if="checkProperty(petition, 'uscisReceiptNumber')"> 
                            <p>USCIS Receipt Number <span> {{checkProperty(petition, 'uscisReceiptNumber')}}</span></p>
                         </li>
                    </ul>
                   </div>
                   <div class="right" >
                      <ul>
                        
                        <li v-if=" enableActionBtns('Case Created') && checkActionsBtnPermissionss('RFE_PREPARE_RESPONSE_DOCS')" @click="$refs['actionsPopups'].openRefePrepareResDocsPopUp('RFE_PREPARE_RESPONSE_DOCS')">
                            <div class="relative">
                                <vs-button   class="light-blue-btn">Prepare RFE Response Documents</vs-button>
                            </div>
                        </li>
                    </ul>
                   </div>
                </div>  
            </div>
           </section>
        </div>
        <actionsPopup v-if="petition" @updatepetition="updatePet" :workFlowDetails="workFlowDetails" ref="actionsPopups" :petitionDetails="petition" />
    </div>
</template>
<script>
import actionsPopup from "@/views/common/actionsPopup.vue";
import documentsView from "@/views/common/documentsView.vue";
import moment from "moment";
import * as _ from "lodash";
export default {
    data: ()=>({
        tempDoc:{
				"status": true,
				"accepted": false,
				"name": "TVA11_G-28.pdf",
				"path": "https://s3.us-west-1.amazonaws.com/immiboxbucket/thomasvallen/private/9/e/f/9ef21b90fe0211ed94146dd81a5c101c.pdf",
				"mimetype": "application/pdf",
				"uploadedBy": "6257ebae1b1a45cb4490ec66",
				"uploadedByName": "Thomas V Allen",
				"uploadedByRoleId": 3,
				"uploadedByRoleName": "Admin",
				"uploadedOn": "2023-05-29T09:24:46.019Z"
			},
        benficiaryFinalLog:null,
    }),
    methods:{
        updatePet(){
            this.$emit("updatepetition", "Petition Updates");
         },
        downloadfile(value) {
            this.$emit('download_or_view' ,value);
        },
        getActionCompletedDate(code=''){
            let returnValue=null;
            if(code){
                let item = _.find( this.caseCurrentDetails , {"action":code});
                if(item && this.checkProperty( item, 'endedOn')){
                    returnValue = item
                }
            }
            return returnValue;

        },
        getActivityByCode(code=''){
            if(code){
               let activity = _.find(this.caseCurrentDetails ,{'action':code});
               if(activity ){
                return activity
               }
            }
            return null;
        },
        getupdateUscisAggingLogs(){
         let self =this;
         this.benficiaryFinalLog =null;
         let tempBenficiaryFinalLog = [];
         _.forEach(this.caseCurrentDetails,(item)=>{
               if(['UPDATE_USCIS_RESPONSE' ].indexOf(item['action']) >-1){
                  if(_.has(item ,'endedOn') && item['endedOn'] && !this.checkProperty(item ,'ignore')){
                     if(_.has(item ,'endedOn') && item['endedOn']){
                        item['endedOn'] = moment(item['endedOn'])
                     }
                     if(_.has(item ,'startedOn') && item['startedOn']){
                        item['startedOn'] = moment(item['startedOn'])
                     }
                     if(self.checkProperty( item,'data' ,'rfeNotice')){
                        tempBenficiaryFinalLog.push(item);
                  }
                  }
               }
        });
        if(tempBenficiaryFinalLog.length>0){
            tempBenficiaryFinalLog  = _.orderBy(tempBenficiaryFinalLog ,['endedOn'] ,['desc'] );
            self.benficiaryFinalLog = tempBenficiaryFinalLog[0];
        }
      },
    },
    props:{
        workFlowDetails: {
            type: Object,
            default: null,
        },
        caseCurrentDetails:{
            type: Array,
            default: []
        },
        petition:{
            type:Object,
            default:null
        }
    },
    computed:{
        checkDocM() {
      let returnVal = false;
      let docmManagerList =[];
      let adminsList =[];
      if(_.has( this.workFlowDetails ,'config')){
        let docManagerActivity = _.find(this.workFlowDetails.config, {
          code: "DOCUMENTATION_MANAGER_LIST",
        });
        if (docManagerActivity && docManagerActivity.editors) {
          docmManagerList = _.map(docManagerActivity.editors, "roleId");
        }
        if (docmManagerList && docmManagerList.indexOf(this.getUserRoleId)>-1) {
          returnVal = true;
        }
        let adminsactiVityList = _.find(this.workFlowDetails.config, {
          code: "MANAGER_LIST",
        });
        
        if (adminsactiVityList && adminsactiVityList.editors) {
          adminsList = _.map(adminsactiVityList.editors, "roleId");
        }
        
        if (adminsList && adminsList.indexOf(this.getUserRoleId) >-1) {
          returnVal = true;
        }
    }
     
      return returnVal;
    },

       enableActionBtns(){
        return (status='')=>{
            let returnValue =false;
            if(this.checkProperty(this.petition ,'completedActivities') &&
                    (this.petition['completedActivities'].indexOf('USCIS_APPROVED')>-1
                    ||  this.petition['completedActivities'].indexOf('USCIS_RECEIVED_RFE')>-1
                    ||  this.petition['completedActivities'].indexOf('USCIS_DENIED')>-1
                    ||  this.petition['completedActivities'].indexOf('USCIS_WITHDRAWN')>-1
                    ||  this.petition['completedActivities'].indexOf('UPDATE_USCIS_RESPONSE')>-1
                    )){
                        return false

             }else{
                if(status=='Docket Submitted to USCIS'  && (this.checkProperty(this.petition ,'courierTrackingDetails') && this.checkProperty(this.petition ,'courierTrackingDetails' ,'length')>0 && this.checkSubmitToUSCIS)){
                      returnValue =true
                    

                }else if(status=='Filed with USCIS' && (this.checkProperty(this.petition ,'completedActivities') && this.petition['completedActivities'].indexOf('SUBMIT_TO_USCIS')>-1)){
                    
                        returnValue =true
                    

                }else if(status =='Sent For Petitioner Signature' && (this.checkWorkActivityisRequires('REQUEST_PETITIONER_SIGN') && this.checkProperty(this.petition ,'completedActivities') && this.petition['completedActivities'].indexOf('REQUEST_PETITIONER_SIGN')>-1 )){
                    
                        returnValue =true;
                    

                }else if(status=='Response Docs Approved' && (this.checkProperty(this.petition ,'completedActivities') && this.petition['completedActivities'].indexOf('CASE_APPROVED')>-1)){
                    
                        returnValue =true;
                    
                    
                }else if(status=='Response Documents Sent For Approval' && (this.checkProperty(this.petition ,'completedActivities') && this.petition['completedActivities'].indexOf('RFE_REVIEW_RESPONSE_DOCS')>-1)){
                    
                    returnValue =true;
                    
                }else if(status=='Response Docs Prepared' && (this.checkProperty(this.petition ,'completedActivities') && this.petition['completedActivities'].indexOf('RFE_PREPARE_RESPONSE_DOCS')>-1 )){
                    
                        returnValue =true;
                    
                    
                }else if(status == "Case Created" && this.petition['completedActivities'].indexOf('RFE_PREPARE_RESPONSE_DOCS')<=-1){
                    returnValue =true;

                }
            }

        return returnValue
        }
       },
        checkActionsBtnPermissionss(){
            let returnVal =false;
            return (code='')=>{
                if( _.has(this.workFlowDetails ,"config") && this.checkProperty(this.workFlowDetails ,'config', 'length') ){
                    let nextWorkflowActivityList =[];
                    

                    if(this.checkProperty(this.petition,'nextWorkflowActivity', 'length')){
                        nextWorkflowActivityList = this.petition['nextWorkflowActivity'];
                    }
                    let isAdmin =false;
                    let canAssignAttorneyorDocManager =false;
                    let canAssignDocm = false;
                    let adminsList =[]
                    let attorneymanagerList = [];
                    let docmList =[]

                    let adminsactiVityList = _.find(this.workFlowDetails.config , {"code":'MANAGER_LIST'});
                    if(adminsactiVityList && adminsactiVityList.editors){
                     adminsList = _.map(adminsactiVityList.editors, 'roleId');
                     isAdmin = adminsList.indexOf(this.getUserRoleId) > -1;
                    }


                    let attorneyactiVityList = _.find(this.workFlowDetails.config , {"code":'ASSIGN_ATTORNEY' ,"actionRequired":'Yes'});
                    if(attorneyactiVityList && attorneyactiVityList.editors){
                    attorneymanagerList = _.map(attorneyactiVityList.editors, 'roleId');
                    canAssignAttorneyorDocManager = attorneymanagerList.indexOf(this.getUserRoleId) > -1;
                    }

                    
                     

                        let docmListActivity = _.find(this.workFlowDetails.config , {"code":'ASSIGN_DOCUMENTATION_MANAGER'});
                        if(docmListActivity && docmListActivity.editors){
                           docmList = _.map(docmListActivity.editors, 'roleId');
                           canAssignDocm = docmList.indexOf(this.getUserRoleId) > -1;
                        }

                        let canCaseApprove =  false;
                        let caseApprovalactiVityList = _.find(this.workFlowDetails.config , {"code":'CASE_APPROVED'});
                        if(caseApprovalactiVityList && caseApprovalactiVityList.editors){
                        let caseApprovalList = _.map(caseApprovalactiVityList.editors, 'roleId');
                            caseApprovalList.indexOf(this.getUserRoleId) > -1;
                        }

                    


                    //let canAssignAttorneyorDocManager =false;
                   
                  
                    if(code=="RFE_REVIEW_RESPONSE_DOCS"){

                        if(
                           ! ( (isAdmin || canCaseApprove) && this.petition.completedActivities.indexOf('RFE_REVIEW_RESPONSE_DOCS') >-1 && this.petition.completedActivities.indexOf('RFE_PREPARE_RESPONSE_DOCS') >-1 && this.petition.completedActivities.indexOf('CASE_APPROVED') <=-1) 
                            &&  (( nextWorkflowActivityList.indexOf('RFE_REVIEW_RESPONSE_DOCS')>-1 && ( isAdmin || this.checkDocM) ) && this.petition.completedActivities.indexOf('RFE_REVIEW_RESPONSE_DOCS')<=-1 && this.petition.completedActivities.indexOf('RFE_PREPARE_RESPONSE_DOCS')>-1 )
                             ){
                            
                            returnVal = true;
                            return returnVal
                        }

                    }else if(code =="RFE_PREPARE_RESPONSE_DOCS"){
                        if( 
                             ! ( (isAdmin || canCaseApprove) && this.petition.completedActivities.indexOf('RFE_REVIEW_RESPONSE_DOCS') >-1 && this.petition.completedActivities.indexOf('RFE_PREPARE_RESPONSE_DOCS') >-1 && this.petition.completedActivities.indexOf('CASE_APPROVED') <=-1) 
                             && (( nextWorkflowActivityList.indexOf('RFE_PREPARE_RESPONSE_DOCS')>-1 && ( isAdmin || this.checkDocM) ) && nextWorkflowActivityList.indexOf('RFE_PREPARE_RESPONSE_DOCS')>-1 && this.petition.completedActivities.indexOf('RFE_PREPARE_RESPONSE_DOCS') <=-1)){
                            returnVal = true;
                            return returnVal
                        }

                    } else if( code=='CASE_APPROVED'){
                        if( (isAdmin || canCaseApprove) && this.petition.completedActivities.indexOf('RFE_REVIEW_RESPONSE_DOCS') >-1 && this.petition.completedActivities.indexOf('RFE_PREPARE_RESPONSE_DOCS') >-1 && this.petition.completedActivities.indexOf('CASE_APPROVED') <=-1){
                            returnVal =  true;
                            return returnVal
                       }


                    }
                
                }
                return returnVal;
          
        }


        },
        checkWorkActivityisRequires(){
        return (code='')=>{
          if( _.has(this.workFlowDetails ,"config") && this.checkProperty(this.workFlowDetails ,'config', 'length') ){
            let config = this.workFlowDetails['config'];
            let ilteredItem = _.find(config, {"code":code,"actionRequired":'Yes'});
            if(ilteredItem){
              return true;
            }
            return false;
          }else{
            return false;
          }
          
        }
        },
        checkSubmitToUSCIS(){
            let returVal =false;
            let isSUbmitToDol = _.find(this.petition['courierTrackingDetails'] ,{"category":'COURIER_TRACKING'});
            if(isSUbmitToDol){
            return true;
            }
            return returVal;
        },
    },
    mounted(){
        this.getupdateUscisAggingLogs();
        setTimeout(()=>{
            this.getupdateUscisAggingLogs();
        })
    },
    components:{
        documentsView,
        actionsPopup,
    }
}
</script>