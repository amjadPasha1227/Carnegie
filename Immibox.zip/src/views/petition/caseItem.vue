<template>

    <tr @click="gototpage(petition)"  style="cursor:pointer">
        <td>{{checkProperty(petition ,'caseNo')}}  <br/>{{checkProperty(petition ,'typeDetails','name')}} <!---- {{checkProperty(petition ,'subTypeDetails','name')}}--> </td>
        <td>{{checkProperty(petition ,'beneficiaryDetails','name')}} </td>
        <td><p>
        <!---
        <img class="user-image" src="@/assets/images/main/check3.svg" />
        --->


        <span class="statusspan"
                 
                  v-bind:class="{
                    'status_created': checkProperty(petition ,'statusDetails','id') == 1,
                    'status_submited': checkProperty(petition ,'statusDetails','id') == 2,
                    'status_inProcess': checkProperty(petition ,'statusDetails','id') == 3,
                    'status_waiting': checkProperty(petition ,'statusDetails','id') == 4,
                    'status_ready_for_filing': checkProperty(petition ,'statusDetails','id') == 5,
                    'status_sent_for_signatures': checkProperty(petition ,'statusDetails','id') == 6,
                    'staus_filed_with_USCIS': checkProperty(petition ,'statusDetails','id') == 7,
                    'Status_received_by_USCIS': checkProperty(petition ,'statusDetails','id') == 8,
                    'status_approved': checkProperty(petition ,'statusDetails','id') == 9,
                    'status_denied': checkProperty(petition ,'statusDetails','id') == 10,
                    'RFE_Received': ['11',11].indexOf(checkProperty(petition ,'statusDetails','id')) >-1,
                    'response_to_RFE_Filed': checkProperty(petition ,'statusDetails','id') == 12,
                    'response_to_RFE_Received': checkProperty(petition ,'statusDetails','id') == 13,
                    'status_withdrawn': checkProperty(petition ,'statusDetails','id') == 14,
                    ' ': checkProperty(petition ,'statusDetails','id') == 15
                  }"
                > {{checkProperty(petition ,'statusDetails','name')}}</span>
        
       
        </p></td> 
        <td class="arrow">
        <template v-if=" [51].indexOf(getUserRoleId)>-1 && !checkProperty(petition ,'questionnaireFilled')" >

                <a><img class="user-image" src="@/assets/images/main/rightarrow1.svg" /></a>
        
        
        </template>
        <template v-else>
                <a><img class="user-image" src="@/assets/images/main/rightarrow1.svg" /></a>
        
        </template>
        
        
        </td> 
        </tr>
             

</template>
<script>
export default {
methods:{
gototpage(tr){

          this.$router.push({ path: `/petition-details/${tr._id}` }).catch(err => {})

}

},
props: {
    caseListType:{
       type: String,
      default:'',
    },
    
    petition: {
      type: [Object ,Array],
      default: null,
    },
    
  }
  }

</script>
