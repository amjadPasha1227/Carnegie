<template>
    
    <div class="submit-ToLaw-Firm" >
    <!---From submitToLawFirm--->
   
   
    <div  class="menu_item submitToLawFirm"  v-if="checkProperty(getPetitionDetails ,'curWorkflowActivity') && checkProperty(getPetitionDetails , 'nextWorkflowActivity') && showMeAction " @click="openPopup()" >
    
    
    <a :enableActionBtn="enableActionBtn()"   href="javascript:;"  > {{getlableName(nextWorkWorkFlow ,'actionLable')}}</a>
     
    </div>
      <vs-popup
     
        class="holamundo main-popup"
        :title="getlableName(nextWorkWorkFlow ,'actionLable')"
        :active.sync="showPopup"
      >
      
        <form data-vv-scope="activityfoform">
      
          <div class="form-container" >
            <div class="vx-row">
             
              <div class="vx-col w-full">
              <div class="form_group">
                <label class="form_label">Comments</label>
                <vs-textarea
                  data-vv-as="Comments"
                  v-validate="'required'"
                  v-model="comments"
                  name="comments"
               
                  class="w-full"
                />

                <span
                  class="text-danger text-sm"
                  v-show="errors.has('activityfoform.comments')"
                >{{ errors.first("activityfoform.comments") }}</span>
              </div>
              </div>
            </div>
            <div class="text-danger text-sm formerrors" v-show="formErrors">
              <vs-alert
                color="warning"
                class="warning-alert reg-warning-alert no-border-radius"
                icon-pack="IntakePortal"
                icon="IP-information-button"
                active="true"
              >{{ formErrors }}</vs-alert>
            </div>
          </div>
          <div class="popup-footer">
           <span class="loader" v-if="loading" ><img src="@/assets/images/main/loader.gif"></span>
           <vs-button color="dark" @click="showPopup =false" class="cancel" type="filled">Cancel</vs-button>
            <vs-button
               :disabled="comments =='' || comments.trim() =='' || loading" 
              color="success"
              @click="submitAction()"
              class="save"
              type="filled"
            >Submit</vs-button>
          </div>
        </form>
             
      </vs-popup>
    </div>
    

    

</template>

<script>

import * as _ from "lodash";
import moment from 'moment'

export default {
  components: {

  },
  props: {
    scannedCopiesList:{
      type:Array,
      default:[]
    }
  },
  computed: {

    checkScannedFilesActivity(){
      //nextWorkWorkFlow
      let  scannedFileRequiredActivityList =[ 'REQUEST_PETITIONER_SIGN','SUBMIT_TO_USCIS'];
      let returnVal =false;
      
      if(
        (this.checkProperty(this.nextWorkWorkFlow ,"code" ) !='') &&
       (this.checkProperty( this.getPetitionDetails ,"petitionerSignRequested") ==true ) && 
        (this.scannedCopies && this.scannedCopies.length >0   )
        // && (scannedFileRequiredActivityList.indexOf(this.nextWorkWorkFlow['code'])>-1)
        ){
          returnVal =true;


      }else{

        returnVal = false;

      }
       return  returnVal
    },
      getPetitionTab(){
            return this.$store.state.selectedPetitionTab
        },
   
   
   
  },
 
  data: () => ({
    currentWorkFlow:null,
    nextWorkWorkFlow:null,
    showMeAction:false,
    showPopup:false,
    formErrors: "",
    comments:'',
    lableData:[],
    loading:false,
    scannedCopies:[],

    
    
  }),
  methods: {
    getscannedCopiesList(){
      
              
              this.scannedCopies =[];
               let finalList =[];
             let postData ={petitionId:this.getPetitionDetails['_id'] ,'page':1 ,'perpage':100000};
            this.$store.dispatch("getList" ,{data:postData,path:"/petition/scanned-copies-list"})
            .then(response => {
               
            let lst = [];
           
            _.forEach(response.list ,(mainItem)=>{
                mainItem = Object.assign(mainItem,{"reverse_document_versions":[] ,"mainParentId":'',showMe:true ,selectedForDownload:false});
               if(mainItem.parentId){
                   mainItem['mainParentId'] = mainItem['parentId']
               }else{
                    mainItem['mainParentId'] = mainItem['_id']
               }

                lst.push(mainItem);
                 

            });

            let subList=[];
           
            //reverse_document_versions
            _.forEach(lst ,(mainItem)=>{

                                
               
               _.forEach(lst ,(subItem)=>{
                    if( mainItem.parentId && (mainItem.parentId == subItem['parentId'] ||  mainItem.parentId == subItem['_id']   ) &&  mainItem['_id'] != subItem['_id']){
                             
                             subItem['showMe'] =false;
                             if(subList.indexOf(subItem['_id']<=-1)){
                                  mainItem['reverse_document_versions'].push(subItem);
                                  subList.push(subItem['_id']);

                             }
                            
                            // mainItem['showMe'] =true;
                    }

                })
                
            if(mainItem.showMe){
                 finalList.push(mainItem);
            }
           
      
             
              

            })
           

            
            this.scannedCopies =  finalList;
            if(this.scannedCopies.length > 0){
              this.showPopup = true;

            }else{
                this.showPopup = true;
            //   this.showToster({message:"Scanned Documents are not uploaded" ,isError:true});

            }
            this.actiVateTabe('Scanned Documents');
            
           
            }).catch((err)=>{
               this.showPopup = true; 
                 this.scannedCopies =[];
               // this.showToster({message:"Scanned Documents are not uploaded" ,isError:true});
                this.actiVateTabe('Scanned Documents');
            })

           
            

         },

     getlableName(activityObj ,msgType){
     let returnValue = this.checkProperty(activityObj ,"name");

     
      if(this.lableData.length>0 && activityObj && _.has(activityObj , 'code')){
      
        let msgObject = _.find(this.lableData , {"code":activityObj['code']});
        if( msgObject && _.has(msgObject , msgType) && this.checkProperty(msgObject ,msgType ) ){
            returnValue = msgObject[msgType];
        }

      }
      //alert(JSON.stringify(activityObj));

      return returnValue;

    },

 enableActionBtn(){
     // alert("enableActionBtn");
     this.loading =false;
       this.updatePetiotionActionBtn(true);
       return true;
    },
    init(){
        
      
     
      if( this.getWorkFlowDetails && this.checkProperty(this.getPetitionDetails ,'curWorkflowActivity') && this.checkProperty(this.getPetitionDetails , 'nextWorkflowActivity')){

        this.currentWorkFlow = _.find(this.getWorkFlowDetails.config ,{"code":this.getPetitionDetails.curWorkflowActivity});
        this.nextWorkWorkFlow = _.find(this.getWorkFlowDetails.config ,{"code":this.getPetitionDetails.nextWorkflowActivity});
       
        //check current login role present in currentWorkFlow editors list
        
       //this.getLcaDetails.statusId
       this.showMeAction =false;
    
         
        if((_.find(this.nextWorkWorkFlow.editors , {"roleId":this.getUserRoleId}) || this.checkAdminLoginroles ) && (this.checkProperty(this.nextWorkWorkFlow ,'actionRequired') =="Yes")){
              this.showMeAction =true;
             this.updatePetiotionActionBtn(true);
                  
        }  


      }
       

    },
    openPopup(){
      
       this.formErrors ='';
       this.comments ='';
        this.loading =false;
       //SUBMIT_TO_USCIS
      
    
     let getLcaDetails = _.cloneDeep(this.getLcaDetails);
      


       if([50].indexOf(this.getUserRoleId)>-1){
this.comments ="Case is being submitted to "+this.getPetitionDetails.tenantDetails.name+" for further actions."

             }else{

this.comments ="Case "+this.getPetitionDetails.typeDetails.name+", "+this.getPetitionDetails.subTypeDetails.name+" is being assigned for further actions"

             }
    
     if(this.nextWorkWorkFlow && this.nextWorkWorkFlow.code=="CASE_APPROVED" ){

        
            if((this.checkPetitionLcaRequired ) ){

            if( !(this.checkProperty(this.getPetitionDetails ,"lcaId") ) ||  ( _.has(getLcaDetails ,"statusId") && [2,3].indexOf(getLcaDetails['statusId'])<=-1) ){
                  this.showToster({message:"LCA should be either Request/Submit/Link in order to submit the case." ,isError: true});


                  this.$store.dispatch("setPetitionTab" , 'LCA')
                  .then(()=>{
                    this.$emit("updatepetition" ,'LCA');
                  })
                  .catch(()=>{
                    this.$emit("updatepetition" ,'LCA');

                  })
                  return false;
              }else{
                this.showPopup =true;
                 this.$validator.reset();
              }

          }else{
             this.showPopup =true;
                 this.$validator.reset();
          }
          


     }else  if((this.checkProperty(this.getPetitionDetails , 'nextWorkflowActivity') == 'SUBMIT_TO_USCIS' ) ){
    
       this.getscannedCopiesList();
       
      
    }else if((this.checkPetitionLcaRequired ) && !this.checkProperty(this.getPetitionDetails ,"lcaId") && this.getUserRoleId !=51){
        this.showToster({ message:"LCA should be either Request/Submit/Link in order to submit the case." ,isError: true})
        this.actiVateTabe('LCA');
      }else{
         this.showPopup =true;
         
      }
       this.$validator.reset();
      

    },
    submitAction(){
        this.formErrors ='';
         let postData = {
             petitionId: this.getPetitionDetails['_id'],
            comment: this.comments,
            action:this.nextWorkWorkFlow['code'], // "SUBMIT_TO_LAW_FIRM", // "CASE_APPROVED" / "LCA_CERTIFIED_FOR_PETITION" / "SUBMIT_TO_USCIS" / "USCIS_APPROVED" / "USCIS_RECEIVED_RFE" / "USCIS_DENIED" 
            today: moment().format('YYYY-MM-DD'), // Required on Status changes to "Received RFE"
           subTypeName:this.checkProperty(this.getPetitionDetails,'subTypeDetails','name'),
           typeName:this.checkProperty(this.getPetitionDetails,'typeDetails','name'),

         };
         
         this.$validator.validateAll("activityfoform").then((result) => {
            if (result) {
               this.loading =true;
               this.$store
              .dispatch("commonAction", {"data":postData ,"path":"/petition/manage-approval-process"})
              .then(response => {
                
                 this.showToster({message:response.message,isError:false });
                 this.showPopup =false;
                 setTimeout(() =>{
                    let tab = this.getPetitionTab;
                    this.loading =false;
                    this.$emit("updatepetition" ,tab);
                 });
                
                
                                
              })
              .catch((error)=>{
                 this.loading =false;
                this.formErrors =error;
              })
       
       

              
            }
          });
           

       

    },
    actiVateTabe(tabName='LCA'){

      this.$store.dispatch("setPetitionTab" , tabName)
      .then(()=>{
        this.$emit("actiVateTabe",tabName);
      })
      .catch(()=>{
        this.$emit("actiVateTabe",tabName);

      })

       
          
      
    },
     

  },
  mounted() {
      this.updatePetiotionActionBtn(false);
     
  
    ///messages/list
   
    this.$store.dispatch("getList" ,{data:{"category": "WORKFLOW"},path:"/messages/list"})
       .then(response => {
         //alert(JSON.stringify(response))
         this.lableData = response.messages.WORKFLOW;
          this.init();
       })
       .catch(error => {
          this.init();

       })

  },
 
};
</script>