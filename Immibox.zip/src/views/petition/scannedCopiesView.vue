<template>
    <div>
        <div class="forms_accordian forms_accordian-v2 hidedropdown marb10 mt-5" v-if="showRecent">
            <div>
                <vs-list-item class="cards-list-heading">
                <h2 v-if="docUserType == 'Beneficiary'">Beneficiary Documents</h2>
                <h2 v-if="docUserType == 'Petitioner'">Petitioner Documents</h2>
                <template v-if="docUserType == 'Internal'">
                    <h2 v-if="getTenantTypeId == 2" >Corporate Documents</h2>
                    <h2 v-else >Law Firm Documents</h2>
                </template>
                
                <div class="d-flex">
                    <label v-if="checkNoNotifyUserIds" class="download-all mr-3" @click="openUploadPopup();uploadMainDocuments=[];uploadOriginalDocument=[]">
                    Upload
                        <img src="@/assets/images/main/upload.svg" />
                    </label>

                    <label v-if="formsAndLettersList && checkProperty(formsAndLettersList,'length')>0" class="download-all" @click="openDownloadPopup(true)">
                        Download
                        <img src="@/assets/images/main/download.svg" />
                    </label>
                </div>
                </vs-list-item>
            </div>
            <vs-collapse accordion class="forms-letters-accordian">
                <template v-for="(forms, indexxx) in formsAndLettersList">
                    <div class="no-accordian" :key="indexxx">
                        <vs-collapse-item>
                            <div slot="header" class="ss">
                                <vs-list-item class="documents_accordian">
                                </vs-list-item>
                            </div>
                            <template>
                                <div class="list_title">
                                    <div class="documents_accordian_tile">
                                        <docType :item="forms" />
                                        <span
                                        @click="fetchSignedUrl(forms);"
                                        ><em class="fl_scanned_docs" :title="forms.name">{{ forms.name }}</em><small>{{getformated(forms)}}</small></span>
                                    </div>
                                    <div class="d-flex align-center">
                                        <div class="vertical-menu">
                                            <span class="menu-icon">
                                                <i class="material-icons">more_vert</i>
                                            </span>
                                            <ul>
                                                <li v-if="checkNoNotifyUserIds" @click="selDoc(forms.mainParentId, forms)">
                                                    Upload
                                                </li>
                                                <li @click="fetchSignedUrl(forms, false, true)">
                                                    View
                                                </li>
                                                <li @click="downloads3file(forms)">
                                                    Download
                                                </li>
                                                <li v-if="tabName == 'Scanned Documents' &&  [50,51].indexOf(getUserRoleId)<=-1" @click="confirmDocumentDelete(forms)">
                                                    Delete
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </template>
                        </vs-collapse-item>
                    </div>
                </template>
                <NoDataFound ref="NoDataFoundRef"  v-if="formsAndLettersList.length == 0" content="" heading="No Documents Found." type='documents' />
            </vs-collapse>
        </div>
          <!----PreviousVersions Section---->

          <div v-if="showPrevious" class="forms_accordian forms_accordian-v2 mt-5">
                    <h2 class="pervious-versions-title" v-if="docUserType == 'Beneficiary'"  ><span>Beneficiary Previous Versions</span></h2>
                    <h2 class="pervious-versions-title"  v-if="docUserType == 'Petitioner'"  ><span> Petitioner Previous Versions</span></h2>
                    <template v-if="docUserType == 'Internal'">
                        <h2 class="pervious-versions-title" v-if="getTenantTypeId == 2"   ><span> Corporate Previous Versions</span></h2>
                        <h2 class="pervious-versions-title" v-else  ><span> Law Firm Previous Versions</span></h2>
                    </template>
                      <vs-collapse accordion class="forms-letters-accordian prev-no-accordian"  >
                        <template v-for="(forms, index) in formsAndLettersList">
                          <template
                            v-if="checkProperty(forms,'reverse_document_versions','length') > 0">
                            <vs-collapse-item
                              :class="{closeDropdown: currentUser == 50,'no-list':checkProperty(forms, 'reverse_document_versions') && forms['reverse_document_versions'].length <= 1,}"
                              :not-arrow="!( checkProperty(forms, 'reverse_document_versions') && forms['reverse_document_versions'].length >= 0)" :key="index">
                              <div slot="header" class="ss">
                                <vs-list-item class="documents_accordian"> </vs-list-item>
                              </div>
                              <template
                                v-if="checkProperty(forms, 'reverse_document_versions')">
                                <div class="list_title">
                                  <div class="documents_accordian_tile">
                                    <docType
                                      :item="forms['reverse_document_versions'][0]"
                                    />
                                    <span
                                      @click="fetchSignedUrl(forms['reverse_document_versions'][0])">
                                    <em class="fl_scanned_docs" :title='checkProperty(forms["reverse_document_versions"][0],"name")'>{{checkProperty(forms["reverse_document_versions"][0],"name")}}
                                    </em>
                                      <small>{{getformated(forms["reverse_document_versions"][0])}}</small></span>
                                  </div>
                                  <div class="d-flex align-center">
                                    <div class="vertical-menu">
                                      <span class="menu-icon">
                                        <i class="material-icons">more_vert</i>
                                      </span>
                                      <ul>
                                        <li
                                          v-if="checkNoNotifyUserIds && [50, 51].indexOf(currentUser) < 0 && !checkrequestSigninActivityCompleted &&checkProperty(getPetitionDetails, 'status') !=false"
                                          @click="selectedDocument = forms;restoreDocument(forms.mainParentId,forms['reverse_document_versions'][0]);">
                                          Restore
                                        </li>
                                        <li @click="fetchSignedUrl(forms['reverse_document_versions'][0],false,true)">
                                          View
                                        </li>
                                      </ul>
                                    </div>
                                  </div>
                                </div>
                                <template
                                  v-for="(reveforms, inde) in forms['reverse_document_versions']">
                                  <template v-if="inde > 0">
                                    <vs-list-item
                                      class="documents_accordian"
                                      v-if="currentUser != 50"
                                      :key="inde"
                                    >
                                      <div class="documents_accordian_tile">
                                        <docType :item="reveforms" />
                                        <span @click="fetchSignedUrl(reveforms)"
                                          >
                                          <em class="fl_scanned_docs" :title="reveforms.name">{{ reveforms.name }}</em>
                                          <small>{{
                                            getformated(reveforms)
                                          }}</small></span
                                        >
                                      </div>
                                      <template
                                        v-if="(checkIsloginUserDoce ||checkIsloginUserDocm) &&checkProperty(getPetitionDetails, 'status') !=false">        
                                      </template>
                                      <div class="vertical-menu">
                                        <span class="menu-icon">
                                          <i class="material-icons">more_vert</i>
                                        </span>
                                        <ul>
                                         
                                          <li
                                            @click="fetchSignedUrl(reveforms, false, true)">View</li>
                                          
                                        </ul>
                                      </div>
                                    </vs-list-item>
                                  </template>
                                </template>
                              </template>
                            </vs-collapse-item>
                          </template>
                        </template>
                        <NoDataFound ref="NoDataFoundRef"  v-if="previousExisted == false" content="" heading="No Documents Found." type='documents' />
                      </vs-collapse>
            </div>
       
       
        <vs-popup class="Change_petition_wrap" v-if="reverseScan_fileuploadPopup" title="Upload Scanned Document" :active.sync="reverseScan_fileuploadPopup">
        <div class="Change_petition">
            <div class="vx-col w-full">
                <div v-for="(docData, index) in documentData" :key="index">
                    <div class="vx-row">
                        <div class="vx-col w-full">
                            <vx-input-group class="form-input-group select-upload-group">
                                <div class="uploadsec_wrap">
                                    <div class="w-full">
                                        <file-upload v-model="version_documentUploaded" class="file-upload-input mb-0" style="height:50px;" :name="'version_documents'+index" :multiple="false" v-validate="'required'" label="Scanned Documents" data-vv-as="Scanned Documents" :accept="allDocEntity"
                                         @input="doUpload(selectedDoc ,version_documentUploaded)">
                                            <img class="file-icon" src="@/assets/images/main/file-upload.svg" />

                                            Upload
                                        </file-upload>

                                        <span class="file-type mb-0">(File Type: PDF, DOC, JPEG, PNG. Max file size: 1MB)</span>

                                        <VuePerfectScrollbar class="scrollbardoc">
                                            <div class="uploded-files_wrap mt-3" v-if=" version_documentUploaded && version_documentUploaded.length >0 ">
                                                <div class="w-full" v-for="(fil, fileindex) in version_documentUploaded" :key="fileindex">
                                                    <div class="uploded-files">
                                                        <vx-input-group class="form-input-group">
                                                            <vs-input v-on:keyup="reversion_fileNameChenged(fileindex)" required class="w-full" :name="'fName'+index" v-model="version_documentUploaded[fileindex]['name']" data-vv-as="File Name" />
                                                            <span class="text-danger text-sm" v-show="!version_documentUploaded[fileindex]['name']">Please Enter file name</span>
                                                            <span class="text-danger text-sm" v-show="errors.has('fName'+index)">{{ errors.first('fName'+index) }}</span>

                                                            <div class="delete" style="z-index:999" @click="remove_reversion_file()">
                                                                <img src="@/assets/images/main/cross.svg" />
                                                            </div>
                                                        </vx-input-group>
                                                    </div>
                                                </div>
                                            </div>
                                        </VuePerfectScrollbar>
                                    </div>
                                </div>
                            </vx-input-group>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="text-danger text-sm formerrors" v-show="formerrors.msg" @click="formerrors.msg=''">
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
              icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
          </div>
        <div class="popup-footer relative">
            <button @click="reverseScan_fileuploadPopup=false ;formerrors.msg =''" class="btn cancel">Cancel</button>
            <button class="btn save " v-bind:disble="disable_reversion_uploadBtn" @click="updateDocument_Version()">
               <!-- <figure v-if="disable_version_update" class="loader loader2"><img src="@/assets/images/main/loader.gif" /></figure> -->
               <figure v-if="disable_version_update" class="loader "><img src="@/assets/images/main/loader.gif" /></figure>
               Submit
            </button>
        </div>
        </vs-popup>
        <template >
            <modal
            :name="'DownloadScannedModal'+docUserType"
            classes="v-modal-sec"
            :min-width="200"
            :min-height="200"
            :scrollable="true"
            :reset="true"
            width="600px"
            height="auto"
            >
            <div class="v-modal">
                <div class="popup-header fromDetailsPage">
                <h2 class="popup-title">Download Files</h2>
                <span @click="$modal.hide('DownloadScannedModal'+docUserType);downloadFiles=false">
                    <em class="material-icons">close</em>
                </span>
                </div>
                <form >
                <div class="form-container ">
                    <div v-if="formsAndLettersList.length>0" class="forms_accordian popup_no_accordian" @click="formerrors.msg=''">   
                        <vs-collapse accordion   >
                            <template v-for="(forms, index) in formsAndLettersList" >
                            <vs-collapse-item  :open="openItem"  :class="{ 'closeDropdown':currentUser ==50 , 'no-list': (checkProperty(forms ,'reverse_document_versions' ) && forms['reverse_document_versions'].length == 0)}" :not-arrow="!(checkProperty(forms ,'reverse_document_versions' ) && forms['reverse_document_versions'].length >= 0)"  :key="index">
                                <div slot="header">
                                    <vs-list-item    :title="forms.name" :subtitle="getformated(forms)">
                                        <docType :item="forms" />
                                        <ul class="download_checkbox">
                                            <li >
                                              
                                            <vs-checkbox   :name="'selectedForSigning_'+index"  v-model="forms.selectedForDownload" class=""></vs-checkbox>
                                        </li> 
                                        </ul>
                                    </vs-list-item>
                                </div>
                                <template  v-if="checkProperty(forms , 'reverse_document_versions') && ( [50,51].indexOf(currentUser)<=-1 )">
                                    <template  v-for="(reveforms, inde) in forms['reverse_document_versions']" >
                                        <vs-list-item   :key="inde" :title="reveforms.name" :subtitle="getformated(reveforms)">
                                            <template slot="avatar">
                                                <img v-if="checkFileFormat(reveforms['mimetype']) =='pdf'" src="@/assets/images/main/pdf.svg" /> 
                                                <img v-else-if="checkFileFormat(reveforms['mimetype']) =='video_mime_types'" src="@/assets/images/main/film.png" />
                                                <img v-else-if="checkFileFormat(reveforms['mimetype']) =='msDoc'" src="@/assets/images/main/doc.svg" />
                                                <img v-else-if="checkFileFormat(reveforms['mimetype']) =='zip'" src="@/assets/images/main/zip-file-format.png" />
                                                <img v-else-if="checkFileFormat(reveforms['mimetype']) =='msPpt'" src="@/assets/images/main/ppt.svg" />
                                                <img v-else-if="checkFileFormat(reveforms['mimetype']) =='msXl'" src="@/assets/images/main/xls.svg" /> 
                                                <img v-else-if="checkFileFormat(reveforms['mimetype']) =='image'" src="@/assets/images/main/image.svg" />
                                                <img v-else src="@/assets/images/main/icon-img.svg" />
                                            </template>
                                       
                                            <vs-checkbox  :name="'selectedForSigning_'+index+'_'+inde"  v-model="reveforms.selectedForDownload" class=""></vs-checkbox>
                                            
                                        </vs-list-item>
                                    </template>
                                </template>     
                            </vs-collapse-item>
                            </template>  
                        </vs-collapse>
                    </div>
                    <div class="text-danger text-sm formerrors" v-show="formerrors.msg" >
                        <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
                        icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
                    </div>
                </div>
                <div class="popup-footer relative">
                        <span @click="$modal.hide('DownloadScannedModal'+docUserType);downloadFiles=false ;formerrors.msg =''" class="btn cancel">Cancel</span>
                        <span class="btn save" @click="downloadFormslatters()">
                        <figure v-if="downloading" class="loader "><img src="@/assets/images/main/loader.gif" /></figure>
                            Download
                        </span>
                </div>
                </form>
                </div>
            </modal>
        </template>
        <modal
            :name="'fileuploadComPopup'+docUserType"
            classes="v-modal-sec"
            :min-width="200"
            :min-height="200"
            :scrollable="true"
            :reset="true"
            width="600px"
            height="auto"
            >
            <div class="v-modal">
                <div class="popup-header fromDetailsPage">
                <h2 class="popup-title">Upload Scanned Documents</h2>
                <span @click="$modal.hide('fileuploadComPopup'+docUserType)">
                    <em class="material-icons">close</em>
                </span>
                </div>
                <form  @submit.prevent >
                    
                    <div class="form-container">
                        <div class="vx-row">
                            <div class="vx-col w-full">
                                <div class="uploadsec_wrap ff">
                                        <div class="w-full">
                                            
                                            <!-- :accept="'application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document'"  -->
                                            <!-- 'application/pdf , application/msword' getWordDocEntity -->
                                            <div  @click="uploadMainDocuments=[]">
                                                <file-upload v-model="uploadMainDocuments" 
                                                :accept="allDocEntity"
                                                class="file-upload-input mb-0" style="height:50px; padding:0px;" :name="'documents'+docUserType" :multiple="true" :hideSelected="true" v-validate="'required'" label="Scanned Documents" data-vv-as="Scanned Documents"  @input="uploadToS3MainDocuments(0,uploadMainDocuments)">
                                                    <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                                                    Upload
                                                </file-upload>
                                                <span class="file-type mb-0">(File Type: PDF, DOC. Max file size: 1MB)</span>
                                                <!-- <span class="text-danger text-sm" v-show="errors.has('pdocuments')">{{ errors.first('documents'+index) }}</span> -->
                                            </div>
                                            <VuePerfectScrollbar class="scrollbardoc">
                                                <div class="uploded-files_wrap mt-3" >
                                                    <div class="w-full" v-for="(fil, fileindex) in uploadOriginalDocument" :key="fileindex">
                                                    
                                                        <div class="uploded-files">
                                                            <vx-input-group class="form-input-group">
                                                                <vs-input v-on:keyup="chengefileName(fileindex)"  v-validate="'required'" class="w-full" :name="'fName'+fileindex" v-model="fil['name']" data-vv-as="File Name" />
                                                                <span class="text-danger text-sm" v-show="errors.has('fName'+fileindex)">{{ errors.first('fName'+fileindex) }}</span>

                                                                <div class="delete" style="z-index:999" @click="remove(fil, uploadOriginalDocument ,fileindex)">
                                                                    <img src="@/assets/images/main/cross.svg" />
                                                                </div>
                                                            </vx-input-group>
                                                        </div>
                                                    </div>
                                                </div>
                                            </VuePerfectScrollbar>
                                        </div>
                                        
                                    </div>
                                <div class="text-danger text-sm formerrors mt-2" v-show="formerrors.msg" @click="formerrors.msg=''">
                                    <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius mb-0" icon-pack="IntakePortal"
                                    icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
                                </div>
                            </div>
                        </div>
                    </div>
                
            
                <div class="popup-footer relative">
                    <button @click="$modal.hide('fileuploadComPopup'+docUserType); fuploder=false" class="btn cancel">Cancel</button>
                    <button class="btn save" :disabled="disable_uploadBtn || uploadOriginalDocument.length <= 0"   @click="updateFormsAndDocuments()">
                        <figure v-if="fuploder" class="loader"><img src="@/assets/images/main/loader.gif" /></figure>
                        Submit
                    </button>
                </div>
                </form>
                </div>
    </modal>
    <vs-popup class="holamundo main-popup cls-btn" title="Delete Document" :active.sync="showDocumentDeletePopup">
            <div class="form-container">
                <div class="vx-row">
                    <div class="vx-col w-full">
                        <p style="line-height: 20px">
                            Do you want to Delete?
                        </p>
                    </div>
                </div>
            </div>
            <div class="popup-footer">
                <vs-button color="dark" class="cancel" type="filled" @click="showDocumentDeletePopup = false;selectedDocObj = null">Cancel</vs-button>
                <vs-button @click="documentDelete();" class="save questionnaire_btn" type="filled">Delete </vs-button>
            </div>
        </vs-popup>

    </div>
</template>
<script>
import NoDataFound from "@/views/common/noData.vue";
import moment from "moment";
import FileUpload from "vue-upload-component/src";
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import docType from "@/views/common/docType.vue";
export default {
    components:{
        FileUpload,
        docType,
        VuePerfectScrollbar,
        NoDataFound
    },
    data: () => ({
        showDocumentDeletePopup:false,
        selectedDocObj:null,
        disable_version_update:false,
        disable_reversion_uploadBtn:false,
        formsAndLettersList:[],
        totalpages:0,
        page:1,
        perpage:25,
        openItem:true,
        downloading:false,
        downloadFiles:false,
        version_documentUploaded: [],
        documentData: [{ type: "Forms, Letters and Others", documentUploaded: [] }],
        disable_revesion_uploadBtn:false,
        version_documrentUploaded:[],
        selectedDoc:null,
        reverseScan_fileuploadPopup:false,
        showPreviousVersions:false,
        previousExisted:false,
        disable_uploadBtn: false,
        fuploder: false,
        uploadOriginalDocument:[],
        uploadMainDocuments:[],
        formerrors:{
            msg:''
        },
        fileuploadComPopup: false,
        parentId:'',formLetterType:'Form',
        documentId: "",
        }),
    props:{
        tabName:{
            type:String,
            default:''
        },
        showPrevious:{
            type: Boolean,
            default: true,
        },
        showRecent:{
            type: Boolean,
            default: true,
        },
        currentUser:null,
        petition: {
            type: Object,
            default: null,
        },
        loadedFromPreview:{
            type: Boolean,
            default: false,
        },
        docUserType:{
            type: String,
            default: '',
        }
    },
    mounted(){
        this.getFormsAndLetters();
    },
    methods:{
        confirmDocumentDelete(doc){
            this.selectedDocObj = doc;
            this.showDocumentDeletePopup = true;
        },
        documentDelete(){
           let payLoad = {
            documentId:this.checkProperty(this.selectedDocObj,'_id')
           };
            let path = '/petition/delete-scanned-copy';
            this.$store.dispatch('commonAction',{data:payLoad,'path':path}).then((res)=>{
                this.showToster({message:res.message,isError:false });
                let filteredDocs = _.filter(this.formsAndLettersList,(docItem)=>{
                    return docItem['_id'] != this.checkProperty(this.selectedDocObj,'_id');
                })
                this.formsAndLettersList = [];
                this.formsAndLettersList = _.cloneDeep(filteredDocs);
                this.selectedDocObj =  null;
                this.showDocumentDeletePopup = false;
                if(this.checkProperty(this.formsAndLettersList,'length') == 0){
                    setTimeout(() => {
                    this.updateLoading(false);
                    setTimeout(() => { this.updateLoading(false);  }, 10);
                }, 10);
                }
            }).catch((err)=>{
                // this.selectedDocObj =  null;
                // this.showDocumentDeletePopup = false;
            })
            //this.$emit('dcoumentDelete',item,this.tabName)
        },
        chengefileName( fileindex){
        this.disable_uploadBtn = false;
       
      _.forEach(this.uploadOriginalDocument, (doc, value) => {
            let fname = doc.name
            fname = fname.trim();

            if (!fname) {
              this.disable_uploadBtn = true;
            }

      })
      
    },
        openUploadPopup(){
            this.$modal.show('fileuploadComPopup'+this.docUserType)
        },
        filameChenged(fileindex) {
            this.disable_uploadBtn = false;
                if (this.uploadOriginalDocument.length > 0) {
                    _.forEach(this.uploadOriginalDocument, (fl, value) => {                   
                        let fname = fl.document.name;
                        fname = fname.trim();
                        if (!fname) {
                            this.disable_uploadBtn = true;
                        }
                    });
                }
         

        },
        remove_reversion_file() {
            this.version_documentUploaded = [];
        },
        remove_uploadedfile(index, fileindex) {
            this.documentData[index].documentUploaded.splice(fileindex, 1);
        },
        remove(item, type) {
            type.splice(type.indexOf(item), 1);
            return false;
        },
        selDoc(seldoc) {
            Object.assign(this.formerrors ,{msg:''});
            this.parentId = seldoc;
            this.selectedDoc = seldoc;
            this.reverseScan_fileuploadPopup = true;
            this.version_documrentUploaded = [];
            this.disable_revesion_uploadBtn = true;
        },
        reversion_fileNameChenged(fileindex) {
            let fname = this.version_documentUploaded[fileindex]["name"];
            fname = fname.trim();
            this.disable_reversion_uploadBtn = false;
            if (!fname) {
                this.disable_reversion_uploadBtn = true;
            }
        },
        togglePreviousVersions(){
            if( this.showPreviousVersions){
                this.showPreviousVersions =false;
            }else{
                this.showPreviousVersions = true;
            }      
        },
        uploadToS3MainDocuments(index,docs){
            let self = this
             docs = docs.map(
                item =>{
                    item = {
                    name: item.name,
                    file: item.file,
                    document: "",
                    path:'',
                    size:item.size ? item.size : null,
                    mimetype: item.type
                }
                const newName = item.name.replace(/[^\w.]/g, '');
                item.name = newName;
                return item;
            }
            );
            if (docs.length > 0) {
                let filIndex = 0;
                docs.forEach(doc => {    
                
                  this.fuploder = true;
                this.disable_uploadBtn = true;
                    let formData = new FormData();
                    formData.append("files", doc.file);
                    formData.append("secureType", "private");
                     formData.append("getDetails", true);
                    // alert(1)
                    this.$store.dispatch("uploadS3File", formData).then(response => {
                         filIndex++;
                         if (filIndex >= self.uploadMainDocuments.length) {
                            self.fuploder = false;
                            self.disable_uploadBtn = false;
                        }
                        response.data.result.forEach(urlGenerated => {
                    
                            doc.document = urlGenerated;
                            doc.path = urlGenerated["path"];
                            if(_.has(urlGenerated ,'size' )){
                                doc['size'] = urlGenerated['size'];
                            }
                            //this.uploadMainDocuments.push(doc);
                            self.uploadOriginalDocument.push(doc);
                            
                            self.uploadOriginalDocument = _.cloneDeep(self.uploadOriginalDocument)
                            //alert(JSON.stringify(self.uploadOriginalDocument));
                        });
                       
                    });
                
                    
                });
            }

        },
        downloadFormslatters() {
             let postdata = {
           petitionId :this.petition._id,
           "documentIds": []
         };
         
         //petition/download-forms-letters,
         if([3,4,5,6,7,8,9,10,11,12,50].indexOf(this.getUserRoleId)>-1){

          _.forEach(this.formsAndLettersList,(item)=>{
               
                if( item['selectedForDownload'] && postdata['documentIds'].indexOf(item._id) <=-1 ){
                    postdata['documentIds'].push(item._id)
                }
                if(this.checkProperty(item , 'reverse_document_versions') && item['reverse_document_versions'].length>0 ){
                     _.forEach(item['reverse_document_versions'],(vItem)=>{
                         if( vItem['selectedForDownload'] && postdata['documentIds'].indexOf(vItem._id) <=-1 ){
                                 postdata['documentIds'].push(vItem._id)
                         }

                     });



                }

            })
        }
            if(([3,4,5,6,7,8,9,10,11,12,50].indexOf(this.getUserRoleId)>-1 && postdata['documentIds'].length>0) ){
                this.downloading=true;
                this.$store
                .dispatch("downloadScannedCopies", postdata)
                .then(response => {
                    this.downloading=false;
                    this.openDownloadPopup(false);
                    window.open(this.$globalgonfig._APIURL+"/common/viewfile?path="+response.path, "_blank");
                // window.open(response.data.result.data, '_blank');
                })
                .catch((error)=>{
                    this.downloading=false;
                    Object.assign(this.formerrors ,{ msg:error})
                });
            }else{
                if(this.checkProperty(postdata , 'documentIds' ,'length') <=0){
                    Object.assign(this.formerrors ,{ msg:"Select at least one document"})

                }
            }

        },
        updateFormsAndDocuments() {
             
             Object.assign( this.formerrors ,{ msg:''})
            if (this.disable_uploadBtn) {
                return false;
            }
            let postData = {
                petitionId: this.checkProperty(this.petition, '_id'),
                //formLetterType: this.formLetterType,
                docUserType:this.docUserType,
                documents:[],
            };
            if(this.parentId){
                postData = Object.assign(postData ,{"parentId":this.parentId})
            }
           if(this.uploadOriginalDocument.length>0){

                    this.uploadOriginalDocument.forEach((doc)=>{
                       
                        let document = doc.document
                        document = Object.assign(document ,{ name:doc.name})
                         postData['documents'].push(document);
                    })
                   

              
            this.fuploder = true;
            this.disable_uploadBtn = true;
            let count = 0;
             this.$store
                    .dispatch("uploadScannedCopies", postData)
                    .then(response => { //fileuploadComPopup
                         this.fileuploadComPopup = false;
                         this.$modal.hide('fileuploadComPopup'+this.docUserType)
                         this.showToster({message:response.message ,isError:false })
                         this.fuploder = false;
                         this.disable_uploadBtn = false;
                         this.fileuploadComPopup = false;
                         this.$modal.hide('fileuploadComPopup'+this.docUserType)
                          this.getFormsAndLetters();
                     
                       setTimeout(()=>{                           
                                this.$emit("updatepetition" ,'Scanned Documents');                            
                            } ,100);

                   
                    })
                    .catch((error) => {
                        Object.assign(this.formerrors ,{'msg':error})
                        this.fuploder = false;
                        this.disable_uploadBtn = false;
                    });
       
            }else{
                    Object.assign( this.formerrors ,{ msg:'Upload atleast one document'})

            }
        },
        updateDocument_Version() {
            Object.assign(this.formerrors ,{'msg':''})
            if (this.version_documentUploaded.length > 0 && !this.disable_reversion_uploadBtn) {
                this.disable_reversion_uploadBtn = true;
                this.rfuploder = false;
                let postData = {
                petitionId: this.petition._id,
                //formLetterType:this.formLetterType,
                documents:[],
                docUserType:this.docUserType
            };
            this.version_documentUploaded.forEach(doc => {
                let docum = doc;
                if(_.has(docum ,"name")){
                    let docName =docum['name']
                    let nameArray = docName.split(".");
                    if(nameArray.length>1){                         
                        let length = nameArray.length;
                        let ext = nameArray[length-1];                      
                        if(ext){                            
                            docum = Object.assign(docum ,{extn:ext})
                        }
                    }
                }
                postData['documents'].push(docum);
                
            });
            this.disable_version_update = true;
            if(this.documentId){
                postData = Object.assign(postData ,{"parentId":this.documentId})
            }  
                this.$store.dispatch("uploadScannedCopies", postData).then(response => {  
                    this.disable_version_update = false;                     
                    this.reverseScan_fileuploadPopup = false;
                    this.version_documentUploaded = [];
                    this.disable_reversion_uploadBtn = true;
                    this.getFormsAndLetters();
                    this.showToster({message:response.message ,isError:false })
                    setTimeout(()=>{
                        this.$emit("updatepetition" ,'Scanned Documents');
                    } ,100);
                    this.disable_version_update = false;
                })
                .catch((error) => {
                    Object.assign(this.formerrors ,{'msg':error})
                    this.showToster({ message: error, isError: true });
                    this.disable_version_update = false;
                });      
            }
        },
        doUpload(id, documents, typeId = "") {
            this.documentId = id;

            let formData = new FormData();
            documents = documents.map(
                item =>
                (item = {
                    typeId: typeId,
                    name: item.name,
                    file: item.file,
                    path: "",
                    size:item.size ? item.size : null,
                    mimetype: item.type
                })
            );
            this.disable_reversion_uploadBtn = false;
            this.rfuploder = false;
            if (documents.length > 0) {
                this.rfuploder = true;
                this.disable_reversion_uploadBtn = true;
                let findx = 0;
                this.version_documentUploaded.forEach(doc => {
                    formData.append("files", doc.file);
                    formData.append("secureType", "private");
                     formData.append("getDetails", true);
                    
                    this.$store.dispatch("uploadS3File", formData).then(response => {
                        response.data.result.forEach(urlGenerated => {
                            doc.path = urlGenerated['path'];
                            if(_.has(urlGenerated ,'size' )){
                                doc['size'] = urlGenerated['size'];
                            }
                            doc.mimetype =urlGenerated['mimetype'];
                            doc.extn =urlGenerated['extn'];
                            this.reversionFile = doc;
                            this.disable_reversion_uploadBtn = false;
                            this.rfuploder = false;
                        });
                    });
                    findx++;
                });
            }
        },
        fetchSignedUrl(value,download = false, viewmode = false) {
          value.download = download;
            value.viewmode = viewmode;
            this.$emit('download_or_view' ,value);
        },
        download_or_view(){},   
        getformated(item) {
            if(this.checkProperty(item,'generated') == true || this.checkProperty(item,'generated') == 'true' ){
                if (item.createdOn) {
                return (
                "Generated On  " +
                moment(item.createdOn).format("MMM DD, YYYY hh:mm:ss a") +
                " - Generated By " +
                item.createdByName
                );
            } else if (item.uploadedOn) {
                return (
                "Generated On  " +
                moment(item.uploadedOn).format("MMM DD, YYYY hh:mm:ss a") +
                " - Generated By " +
                item.createdByName
                );
            } else {
                return "Generated By " + item.createdByName;
            }
            }else{
                if (item.createdOn) {
                return (
                "Uploaded On  " +
                moment(item.createdOn).format("MMM DD, YYYY hh:mm:ss a") +
                " - Uploaded By " +
                item.createdByName
                // +" "+item.parentId +" id="+item._id
                );
            } else if (item.uploadedOn) {
                return (
                "Uploaded On  " +
                moment(item.uploadedOn).format("MMM DD, YYYY hh:mm:ss a") +
                " - Uploaded By " +
                item.createdByName
                // +" "+item.parentId +" id="+item._id
                );
            } else {
                return "Uploaded By " + item.createdByName;
            }
            }
        },
        openDownloadPopup(action=false){
            _.forEach(this.formsAndLettersList,(item)=>{
                item['selectedForDownload'] =true;
                if(this.checkProperty(item , 'reverse_document_versions') && item['reverse_document_versions'].length>0 ){
                    //item.selectedForDownload =false;
                    _.forEach(item['reverse_document_versions'],(vItem)=>{
                        vItem.selectedForDownload =false;
                    });
                }
            })
            this.downloadFiles=action;
            this.downloading =false;
            Object.assign(this.formerrors ,{ msg:''})
            this.openItem =true
            if(this.downloadFiles){
                this.$modal.show('DownloadScannedModal'+this.docUserType)
            }else{
                this.$modal.hide('DownloadScannedModal'+this.docUserType)
            }
            

        },
        getFormsAndLetters() {
            this.formsAndLettersList = [];
            let finalList = [];
            this.previousExisted = false;
            let postData ={
                petitionId:'',
                'page':1 ,
                'perpage':100000,
                matcher: { 
                    docUserTypeList: []
                }
            };
            postData['petitionId']= this.petition._id; 
            //postData['petitionId']= '63a55489e973d734f8d74387'; 
            if(this.docUserType){
                postData['matcher']['docUserTypeList'] = [this.docUserType]
            }
            this.updateLoading(true);
            this.$store
                .dispatch("getList", {
                data: postData,
                path: "/petition/scanned-copies-list",
                })
                .then((response) => {
                let lst = [];

                _.forEach(response.list, (mainItem) => {
                    mainItem = Object.assign(mainItem, {
                    reverse_document_versions: [],
                    mainParentId: "",
                    showMe: true,
                    selectedForDownload: false,
                    "viewmode":true,
                    });
                    if (mainItem.parentId) {
                    mainItem["mainParentId"] = mainItem["parentId"];
                    } else {
                    mainItem["mainParentId"] = mainItem["_id"];
                    }

                    lst.push(mainItem);
                });
                let subList = [];

                //reverse_document_versions
                _.forEach(lst, (mainItem) => {
                    if (this.checkProperty(mainItem, "depType") != "child") {
                    _.forEach(lst, (subItem) => {
                        if (
                        mainItem.parentId &&
                        (mainItem.parentId == subItem["parentId"] ||
                            mainItem.parentId == subItem["_id"]) &&
                        mainItem["_id"] != subItem["_id"]
                        ) {
                        subItem["showMe"] = false;
                        if (subList.indexOf(subItem["_id"]) <= -1) {
                            mainItem["reverse_document_versions"].push(subItem);
                            this.previousExisted = true;
                            subList.push(subItem["_id"]);
                            
                        }

                        // mainItem['showMe'] =true;
                        }
                    });

                    if (mainItem.showMe) {
                        finalList.push(_.cloneDeep(mainItem));
                    }
                    } else {
                    _.forEach(lst, (subItem) => {
                        if (
                        this.checkProperty(mainItem, "depType") ==
                            this.checkProperty(subItem, "depType") &&
                        this.checkProperty(mainItem, "depLabel") ==
                            this.checkProperty(subItem, "depLabel") &&
                        mainItem.parentId &&
                        (mainItem.parentId == subItem["parentId"] ||
                            mainItem.parentId == subItem["_id"]) &&
                        mainItem["_id"] != subItem["_id"]
                        ) {
                        subItem["showMe"] = false;
                        if (subList.indexOf(subItem["_id"]) <= -1) {
                            mainItem["reverse_document_versions"].push(subItem);
                            this.previousExisted = true;
                            subList.push(subItem["_id"]);
                            
                        }

                        // mainItem['showMe'] =true;
                        }
                    });

                    if (mainItem.showMe) {
                        finalList.push(_.cloneDeep(mainItem));
                    }
                    }
                });

                this.totalpages = Math.ceil(response.totalCount / this.perpage);
                this.formsAndLettersList = _.cloneDeep(finalList); // JSON.parse(JSON.stringify(finalList));

                // this.getMasetFormsAndLatters(false);
                this.updateLoading(false);
                setTimeout(() => {
                    this.updateLoading(false);
                    setTimeout(() => { this.updateLoading(false);  }, 10);
                }, 10);
                })
                .catch((err) => {
                this.updateLoading(false);
                this.formsAndLettersList = [];
                setTimeout(() => {
                    this.updateLoading(false);
                    }, 10);
                    });
        },
    },
    computed:{
        checkNoNotifyUserIds(){
      let returnValue =true;
      if(_.has(this.petition, 'noNotifyUserIds')  ){
        if(this.petition['noNotifyUserIds'].length>0){
          if(this.petition['noNotifyUserIds'].indexOf(this.getUserData['userId']) >-1){
            returnValue = false;
          }

        }

      }
      return returnValue;
    },

    }

}
</script>