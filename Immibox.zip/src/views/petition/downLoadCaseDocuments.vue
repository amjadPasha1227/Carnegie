<template>
    
                
                <div class="download_documents_list">
                    <vs-tabs >
                        <vs-tab label="Saved Documents" @click="changedDocumentsTab('savedDocuments')" >
                            <div class="con-tab-ejemplo" v-if="documentActiveTab=='savedDocuments'" >
                                <div class="doc_modal">
                                 
                                    <VuePerfectScrollbar class="scrollbardoc">
                                        <vs-row vs-w="12">
                                          
                                            <template v-if="checkActiveDocuments(beneficiaryDocumentsList)"  >
                                                <vs-col vs-lg="12" vs-sm="12" vs-xs="12">
                                                   <div class="list_elements drag-items">
                                                    <vs-collapse accordion>
                                                      <draggable :list="beneficiaryDocumentsList" group="people">
                                                        
                                                        <template v-for="(categoryDocs, index) in beneficiaryDocumentsList">
                                                         
                                                            <!-----{"category":category,"documents":categoryDocuments}-->
                                                          <vs-collapse-item v-if="checktSavedDocuments(categoryDocs['documents'])"  :key="index" >
                                                           
                                                            <div slot="header" class="d_header_title"  :id="'docTypeOrder_ben_'+categoryDocs['category']"  >
                                                             <!---- {{1+index}} - {{categoryDocs['category'] | formatdoctype}} --->
                                                             {{categoryDocs['category'] | formatdoctype}}
                                                              <span  @click="moveToTrash('beneficiaryDocumentsList' ,categoryDocs['category']);"  >
                                                                <img src="@/assets/images/main/delete-row-img.svg" />
                                                                <em>Remove from the list</em>
                                                              </span>
                                                            </div>
                                                            <div>
                                                              <div class="dragBox" v-if="categoryDocs['documents'] && categoryDocs['documents'].length > 0">
                                                                <div class="dragNested">
                                                                  <draggable >
                                                                  <template  v-for="(document,sindex) in  categoryDocs['documents']">
                                                                   
                                                                    <div
                                                                      :id="'order_ben_'+categoryDocs['category']+'_docPath_'+document['path']"
                                                                      :docPath="document['path']"
                                                                      
                                                                      v-bind:key="sindex"
                                                                      class="drab_sublist"
                                                                       v-if="!checkProperty( document,'isTrashDocument') && checkProperty(document,'path') && (checkProperty(document,'status')=='' || checkProperty(document,'status') )"
                                                                    >
                                                                      <div class="subdragHead" :documentssubcategory="categoryDocs['category']" :categoryOrder="index"  :documentPath="checkProperty(document ,'path')"   >{{document.name}}
                                                                      
                                                                      </div>
                                                                     
                                                                      <div class="downloadPopup-actions d-flex align-center">
                                                                          <span @click="downloadfile(document)" class="sub_delete" >
                                                                            <img width="14" src="@/assets/images/main/eye.png" />
                                                                            <em>View/Download</em>
                                                                          </span>
                                                                            <span  @click="document['isTrashDocument']=true ;savedDocumentsAction()"  class="sub_delete ml-4"   >
                                                                              <img src="@/assets/images/main/cross.svg" />
                                                                              <em>Remove from the list</em>
                                                                            </span>
                                                                        </div>
                                                                    </div>
                                                                    </template>
                                                                  </draggable>
                                                                </div>
                                                              </div>
                                                            </div>
                                                          </vs-collapse-item>
                                                        </template>
                                                      </draggable>
                                                    </vs-collapse>
                                                  </div>
                                                </vs-col>
                                            </template>
                                            <!-------Spouse Documents MM DD YYYY --> 
                                            <template v-if="checkProperty(petition ,'subTypeDetails' ,'id') !=16 && checkActiveDocuments(suposeDocumentsList)"  >
                                                <vs-col vs-lg="12" vs-sm="12" vs-xs="12">
                                                    <h2 class="small-header">Spouse Documents</h2>
                                                   <div class="list_elements drag-items">
                                                    <vs-collapse accordion>
                                                      <draggable :list="suposeDocumentsList" group="spouse">
                                                        <template v-for="(categoryDocs, index) in suposeDocumentsList">
                                                            <!-----{"category":category,"documents":categoryDocuments}-->
                                                          <vs-collapse-item v-if="checktSavedDocuments(categoryDocs['documents'])"  :key="index" >
                                                            <div slot="header" class="d_header_title" :id="'docTypeOrder_sup_'+categoryDocs['category']" >
                                                             <!--- {{1+index}} - {{categoryDocs['category'] | formatdoctype}} --->
                                                              {{categoryDocs['category'] | formatdoctype}}
                                                              <span  @click="moveToTrash('suposeDocumentsList',categoryDocs['category'])"  >
                                                                <img src="@/assets/images/main/delete-row-img.svg" />
                                                                <em>Remove from the list</em>
                                                              </span>
                                                            </div>
                                                            <div>
                                                              <div class="dragBox" v-if="categoryDocs['documents'] && categoryDocs['documents'].length > 0">
                                                                <div class="dragNested">
                                                                  <draggable >
                                                                  <template  v-for="(document,sindex) in  categoryDocs['documents']">
                                                                    <div
                                                                      :id="'order_sup_'+categoryDocs['category']+'_docPath_'+document['path']"
                                                                      :docPath="document['path']"
                                                                      
                                                                      v-bind:key="sindex"
                                                                      class="drab_sublist"
                                                                       v-if="!checkProperty( document,'isTrashDocument') && checkProperty(document,'path')  && (checkProperty(document,'status')=='' || checkProperty(document,'status') )"
                                                                    >
                                                                      <div class="subdragHead" :documentssubcategory="categoryDocs['category']" :categoryOrder="index"  :documentPath="checkProperty(document ,'path')"   >{{document.name}}</div>
                                                                     
                                                                      <div class="downloadPopup-actions d-flex align-center">
                                                                          <span @click="downloadfile(document)" class="sub_delete" >
                                                                            <img width="14" src="@/assets/images/main/eye.png" />
                                                                            <em>View/Download</em>
                                                                          </span>
                                                                            <span  @click="document['isTrashDocument']=true;savedDocumentsAction()"  class="sub_delete ml-4"   >
                                                                              <img src="@/assets/images/main/cross.svg" />
                                                                              <em>Remove from the list</em>
                                                                            </span>
                                                                        </div>
                                                                    </div>
                                                                    </template>
                                                                  </draggable>
                                                                </div>
                                                              </div>
                                                            </div>
                                                          </vs-collapse-item>
                                                        </template>
                                                      </draggable>
                                                    </vs-collapse>
                                                  </div>
                                                </vs-col>
                                            </template>

                                            <!-------------Child documents-->
                                            <template v-if="checkProperty(petition ,'subTypeDetails' ,'id') !=16 && checkProperty(childrenDocuments  ,'length')>0">
                                             
                                                <template v-for="(child , chind) in childrenDocuments" >
                                                 
                                                    <template v-if="checkActiveDocuments(child['documents'])"  >
                                                      <vs-col vs-lg="12" vs-sm="12" vs-xs="12" :key="chind">
                                                          <h2 class="small-header">Child {{child['name']}} Documents</h2>
                                                         <div class="list_elements drag-items">
                                                          <vs-collapse accordion>
                                                            <draggable :list="child['documents']" :group="'spouse_'+index">
                                                              <template v-for="(categoryDocs, index) in child['documents']">
                                                                  
                                                                <vs-collapse-item v-if="checktSavedDocuments(categoryDocs['documents'])"  :key="index" >
                                                                  <div slot="header" class="d_header_title" :id="'docTypeOrder_'+child['_id']+'_'+categoryDocs['category']"  >
                                                                    <!----{{1+index}} - {{categoryDocs['category'] | formatdoctype}}--->
                                                                    {{categoryDocs['category'] | formatdoctype}}
                                                                    <span  @click="moveToTrash('childrenDocuments',categoryDocs['category'] ,chind)"  >
                                                                      <img src="@/assets/images/main/delete-row-img.svg" />
                                                                      <em>Remove from the list</em>
                                                                    </span>
                                                                  </div>
                                                                  <div>
                                                                    <div class="dragBox" v-if="categoryDocs['documents'] && categoryDocs['documents'].length > 0">
                                                                      <div class="dragNested">
                                                                        <draggable >
                                                                        <template  v-for="(document,sindex) in  categoryDocs['documents']">
                                                                          <div
                                                                          :id="'order_chi_'+categoryDocs['category']+'_'+child['_id']+'_docPath_'+document['path']"
                                                                            :docPath="document['path']"
                                                                      
                                                                            v-bind:key="sindex"
                                                                            class="drab_sublist"
                                                                             v-if="!checkProperty( document,'isTrashDocument') && checkProperty(document,'path')  && (checkProperty(document,'status')=='' || checkProperty(document,'status') )"
                                                                          >
                                                                            <div class="subdragHead" :documentssubcategory="categoryDocs['category']" :categoryOrder="index"  :documentPath="checkProperty(document ,'path')"   >{{document.name}}</div>
                                                                           
                                                                            <div class="downloadPopup-actions d-flex align-center">
                                                                                <span @click="downloadfile(document)" class="sub_delete" >
                                                                                  <img width="14" src="@/assets/images/main/eye.png" />
                                                                                  <em>View/Download</em>
                                                                                </span>
                                                                                  <span  @click="document['isTrashDocument']=true;savedDocumentsAction()"  class="sub_delete ml-4"   >
                                                                                    <img src="@/assets/images/main/cross.svg" />
                                                                                    <em>Remove from the list</em>
                                                                                  </span>
                                                                              </div>
                                                                          </div>
                                                                          </template>
                                                                        </draggable>
                                                                      </div>
                                                                    </div>
                                                                  </div>
                                                                </vs-collapse-item>
                                                              </template>
                                                            </draggable>
                                                          </vs-collapse>
                                                        </div>
                                                      </vs-col>
                                                  </template>

                                                 

                                                </template>
                                            </template>
                                            <template v-if="!checkActiveDocuments(beneficiaryDocumentsList) && !checkActiveDocuments(suposeDocumentsList) && !checkChildActiveDocuments" >
                                              <div class="vs-col vs-xs-12 vs-sm-12 vs-lg-12">
                                                 <NoDataFound ref="NoDataFoundRef" :loading="false" :checkLocading="false"  content="" :heading="'No Documents Found'" type='Documents' />
                                              </div>  
                                            </template>
                                            

                                        </vs-row>
                                    </VuePerfectScrollbar>    
                                </div>
                            </div>

                        </vs-tab>
                        <vs-tab label="Trashed Documents" @click="changedDocumentsTab('trashedDocuments')" >
                            <div class="con-tab-ejemplo" v-if="documentActiveTab=='trashedDocuments'" >
                                <div class="doc_modal">
                                    
                                    <VuePerfectScrollbar class="scrollbardoc">
                                        <vs-row vs-w="12">
                                         
                                            <template  v-if="checkInActiveDocuments(beneficiaryDocumentsList)"  >
                                                <vs-col vs-lg="12" vs-sm="12" vs-xs="12">
                                                   <div class="list_elements drag-items">
                                                    
                                                    <vs-collapse accordion>
                                                      <draggable :list="beneficiaryDocumentsList" group="people">
                                                        <template v-for="(categoryDocs, index) in beneficiaryDocumentsList">
                                                            <!-----{"category":category,"documents":categoryDocuments}-->
                                                          <vs-collapse-item v-if="checktTrashedDocuments(categoryDocs['documents'])"  :key="index" >
                                                            <div slot="header" class="d_header_title">
                                                             <!----- {{1+index}} - {{categoryDocs["category"] | formatdoctype}}--->
                                                              {{categoryDocs["category"] | formatdoctype}}
                                                              <span  @click="moveToSave('beneficiaryDocumentsList', categoryDocs['category'])"  >
                                                                <img src="@/assets/images/main/delete-row-img.svg" />
                                                                <em>Remove from the list</em>
                                                              </span>
                                                            </div>
                                                            <div>
                                                              <div class="dragBox" v-if="categoryDocs['documents'] && categoryDocs['documents'].length > 0">
                                                                <div class="dragNested">
                                                                  <draggable >
                                                                  <template  v-for="(document,sindex) in  categoryDocs['documents']">
                                                                    <div
                                                                    
                                                                      v-bind:key="sindex"
                                                                      class="drab_sublist"
                                                                       v-if="checkProperty( document,'isTrashDocument')"
                                                                    >
                                                                      <div class="subdragHead"    >{{document.name}}</div>
                                                                     
                                                                      <div class="downloadPopup-actions d-flex align-center">
                                                                          <span @click="downloadfile(document)" class="sub_delete" >
                                                                            <img width="14" src="@/assets/images/main/eye.png" />
                                                                            <em>View/Download</em>
                                                                          </span>
                                                                            <span  @click="document['isTrashDocument']=false;savedDocumentsAction()"  class="sub_delete ml-4"   >
                                                                              <img src="@/assets/images/main/cross.svg" />
                                                                              <em>Remove from the list</em>
                                                                            </span>
                                                                        </div>
                                                                    </div>
                                                                    </template>
                                                                  </draggable>
                                                                </div>
                                                              </div>
                                                            </div>
                                                          </vs-collapse-item>
                                                        </template>
                                                      </draggable>
                                                    </vs-collapse>
                                                  </div>
                                                </vs-col>
                                            </template>
                                            <!-------Spouse Documents MM DD YYYY --> 
                                            <template v-if="checkInActiveDocuments(suposeDocumentsList)"  >
                                                <vs-col vs-lg="12" vs-sm="12" vs-xs="12">
                                                    <h2 class="small-header">Spouse Documents</h2>
                                                   
                                                   <div class="list_elements drag-items">
                                                    <vs-collapse accordion>
                                                      <draggable :list="suposeDocumentsList" group="Trashedspouse">
                                                        <template v-for="(categoryDocs, index) in suposeDocumentsList">
                                                            <!-----{"category":category,"documents":categoryDocuments}-->
                                                          <vs-collapse-item v-if="checktTrashedDocuments(categoryDocs['documents'])"  :key="index" >
                                                            <div slot="header" class="d_header_title">
                                                             <!------ {{1+index}} - {{categoryDocs['category'] | formatdoctype}}--->
                                                             {{categoryDocs['category'] | formatdoctype}}
                                                              <span  @click="moveToSave('suposeDocumentsList' ,categoryDocs['category'])"  >
                                                                <img src="@/assets/images/main/delete-row-img.svg" />
                                                                <em>Remove from the list</em>
                                                              </span>
                                                            </div>
                                                            <div>
                                                              <div class="dragBox" v-if="categoryDocs['documents'] && categoryDocs['documents'].length > 0">
                                                                <div class="dragNested">
                                                                  <draggable >
                                                                  <template  v-for="(document,sindex) in  categoryDocs['documents']">
                                                                    <div
                                                                    
                                                                      v-bind:key="sindex"
                                                                      class="drab_sublist"
                                                                       v-if="checkProperty( document,'isTrashDocument')"
                                                                    >
                                                                      <div class="subdragHead" :documentssubcategory="categoryDocs['category']" :categoryOrder="index"  :documentPath="checkProperty(document ,'path')"   >{{document.name}}</div>
                                                                     
                                                                      <div class="downloadPopup-actions d-flex align-center">
                                                                          <span @click="downloadfile(document)" class="sub_delete" >
                                                                            <img width="14" src="@/assets/images/main/eye.png" />
                                                                            <em>View/Download</em>
                                                                          </span>
                                                                            <span  @click="document['isTrashDocument']=false;savedDocumentsAction()"  class="sub_delete ml-4"   >
                                                                              <img src="@/assets/images/main/cross.svg" />
                                                                              <em>Remove from the list</em>
                                                                            </span>
                                                                        </div>
                                                                    </div>
                                                                    </template>
                                                                  </draggable>
                                                                </div>
                                                              </div>
                                                            </div>
                                                          </vs-collapse-item>
                                                        </template>
                                                      </draggable>
                                                    </vs-collapse>
                                                  </div>
                                                </vs-col>
                                            </template>
                                            <!-------------Child documents-->
                                            <template v-if="checkProperty(childrenDocuments  ,'length')>0">
                                             
                                              <template v-for="(child , chind) in childrenDocuments" >
                                                <template v-if="checkInActiveDocuments(child['documents'])"  >
                                                  <vs-col vs-lg="12" vs-sm="12" vs-xs="12" :key="chind">
                                                      <h2 class="small-header">Child {{child['name']}} Documents</h2>
                                                     <div class="list_elements drag-items">
                                                      <vs-collapse accordion>
                                                        <draggable :list="child['documents']" :group="'child_'+chind['_id']">
                                                          <template v-for="(categoryDocs, index) in child['documents']">
                                                              
                                                            <vs-collapse-item v-if="checktTrashedDocuments(categoryDocs['documents'])"  :key="index" >
                                                              <div slot="header" class="d_header_title">
                                                               <!---- {{1+index}} - {{categoryDocs['category'] | formatdoctype}}-->
                                                                  {{categoryDocs['category'] | formatdoctype}}
                                                                <span  @click="moveToSave( 'childrenDocuments' ,categoryDocs['category'] ,chind)"  >
                                                                  <img src="@/assets/images/main/delete-row-img.svg" />
                                                                  <em>Remove from the list</em>
                                                                </span>
                                                              </div>
                                                              <div>
                                                                <div class="dragBox" v-if="categoryDocs['documents'] && categoryDocs['documents'].length > 0">
                                                                  <div class="dragNested">
                                                                    <draggable >
                                                                    <template  v-for="(document,sindex) in  categoryDocs['documents']">
                                                                      <div
                                                                      
                                                                        v-bind:key="sindex"
                                                                        class="drab_sublist"
                                                                         v-if="checkProperty( document,'isTrashDocument')"
                                                                      >
                                                                        <div class="subdragHead" :documentssubcategory="categoryDocs['category']" :categoryOrder="index"  :documentPath="checkProperty(document ,'path')"   >{{document.name}}</div>
                                                                       
                                                                        <div class="downloadPopup-actions d-flex align-center">
                                                                            <span @click="downloadfile(document)" class="sub_delete" >
                                                                              <img width="14" src="@/assets/images/main/eye.png" />
                                                                              <em>View/Download</em>
                                                                            </span>
                                                                              <span  @click="document['isTrashDocument']=false;savedDocumentsAction()"  class="sub_delete ml-4"   >
                                                                                <img src="@/assets/images/main/cross.svg" />
                                                                                <em>Remove from the list</em>
                                                                              </span>
                                                                          </div>
                                                                      </div>
                                                                      </template>
                                                                    </draggable>
                                                                  </div>
                                                                </div>
                                                              </div>
                                                            </vs-collapse-item>
                                                          </template>
                                                        </draggable>
                                                      </vs-collapse>
                                                    </div>
                                                  </vs-col>
                                              </template>
                                                
                                                  
                                              </template>
                                            </template> 
                                           
                                            <template v-if="!checkInActiveDocuments(beneficiaryDocumentsList) && !checkInActiveDocuments(suposeDocumentsList) && !checkChildInActiveDocuments" >
                                              <div class="vs-col vs-xs-12 vs-sm-12 vs-lg-12">
                                                 <NoDataFound ref="NoDataFoundRef" :loading="false" :checkLocading="false"  content="" :heading="'No Documents Found'" type='Documents' />
                                              </div>  
                                            </template>

                                        </vs-row>
                                    </VuePerfectScrollbar>    
                                </div>
                            </div>

                        </vs-tab>
                    </vs-tabs>
                    <div class="popup-footer relative">
                      <button  @click="$emit('closeMe');downloadDocList = false" class="cancel" type="filled" color="dark">Cancel</button>
                      <vs-button
                      v-if="documentActiveTab=='savedDocuments'"
                    color="success"
                    :disabled="filesDownloading|| (!checkActiveDocuments(beneficiaryDocumentsList) && !checkActiveDocuments(suposeDocumentsList) && !checkChildActiveDocuments)"
                    @click="downloadcombine"
                    class="marl15 save"
                    type="filled"
                  >Download</vs-button>
                  <span v-if="filesDownloading" class="loader"><img src="@/assets/images/main/loader.gif"></span>
                  </div>
                  
                </div>
            
        
     

    
</template>
<script>
import JQuery from "jquery";
import draggable from "vuedraggable";
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import NoDataFound from "@/views/common/noData.vue";

  import { XIcon } from 'vue-feather-icons'
import * as _ from "lodash";
    export default {
        computed:{
            checktSavedDocuments(){
                let _self= this;
                return (docsList)=>{
                   
                    let savedDocs=_.filter(docsList ,{"isTrashDocument":false});
                    
                    if(savedDocs && _self.checkProperty(savedDocs ,'length')>0){
                        return true
                    }else{
                        return false;
                    }

                }
            },
            checktTrashedDocuments(){
                let _self= this;
                return (docsList)=>{
                   
                    let savedDocs=_.filter(docsList ,{"isTrashDocument":true});
                    
                    if(savedDocs &&savedDocs.length>0){
                        return true
                    }else{
                        return false;
                    }

                }
            },

            checkActiveDocuments(){
                let _self =this;
                return (allDocs)=>{
                    let count =0;
                    if(allDocs.length>0){
                     
                        _.forEach(allDocs ,(catDocs)=>{
                          
                           //alert(JSON.stringify(catDocs))
                            if(_.has(catDocs,'documents') && catDocs['documents'].length>0){
                              
                              let activDocs = _.filter(catDocs['documents'] ,{"isTrashDocument":false});
                              
                                    if(activDocs && activDocs.length>0){
                                        count =count+1;
                                    }

                                

                            }

                        });
                        if(count>0){
                           return true;
                        }else{
                            return false;
                        }
                        
                    }else{
                        return false;
                    }

                }
            },
            checkInActiveDocuments(){
                let _self =this;
                return (allDocs)=>{
                    let count =0;
                    if(allDocs.length>0){
                     
                        _.forEach(allDocs ,(catDocs)=>{
                          
                           //alert(JSON.stringify(catDocs))
                            if(_.has(catDocs,'documents') && catDocs['documents'].length>0){
                              
                              let activDocs = _.filter(catDocs['documents'] ,{"isTrashDocument":true});
                              
                                    if(activDocs && activDocs.length>0){
                                        count =count+1;
                                    }

                                

                            }

                        });
                        if(count>0){
                           return true;
                        }else{
                            return false;
                        }
                        
                    }else{
                        return false;
                    }

                }
            },
            checkChildActiveDocuments(){
             let count =0;
              this.childrenDocuments.map((child ,indx)=>{
              if(_.has( child ,'documents')){

                child['documents'].map((items)=>{
                if( _.has(items ,'documents') && items['documents'].length>0 ){
                 
                 let alctiveDocuments = _.filter(items['documents'] ,{"isTrashDocument":false})
                  if(alctiveDocuments && alctiveDocuments.length>0){
                    
                    count =count+1;
                  }
                }


              });

              }


            });
            if(count>0){
              return true
            }else{
              return false;
            }

            },
            checkChildInActiveDocuments(){
             let count =0;
              this.childrenDocuments.map((child ,indx)=>{
              if(_.has( child ,'documents')){

                child['documents'].map((items)=>{
                if( _.has(items ,'documents') && items['documents'].length>0 ){
                 
                 let alctiveDocuments = _.filter(items['documents'] ,{"isTrashDocument":true})
                  if(alctiveDocuments && alctiveDocuments.length>0){
                    
                    count =count+1;
                  }
                }


              });

              }


            });
            if(count>0){
              return true
            }else{
              return false;
            }

            },
           
           
        },
        data() {
         return {
          tempData:null,
          filesDownloading:false,
            beneficiaryDocuments:{},
            beneficiaryDocumentsList:[],

            suposeDocuments:{},
            suposeDocumentsList:[],
            childrenDocuments:[],
            savedDocumentsList:[],
           isDocumentsAreSaved:false,
           downloadDocList:true,
           documentActiveTab:'savedDocuments',


         }
       },
       methods: {
        closeMe(){
          this.$emit('closeMe')
        },
        savedDocumentsAction(callFromDownload=false){
          if(callFromDownload ==false){
            return ;
          }
          setTimeout(()=>{

           
            const $ = JQuery;
            let postData = { "petitionId":'', 'docList':[] ,"entityType": "case" ,"category": "other" };
            

            
           // alert(JSON.stringify(benCategoryOrders));

            postData = { "petitionId":'', 'docList':[] ,"entityType": "case" };
            let processDocuments =(documents ,category='benficiary' ,childrenId='' )=>{

              let benCategoryOrders ={};
              let benDocOrders ={};
              let supCategoryOrders ={};
              let chlCategoryOrders ={};
              if(category=='benficiary'){
                $("[id^='docTypeOrder_ben_']").each( (i, el)=> {
                
                  let category = el.id.substr(17);
                  benCategoryOrders[category] = i;
                
                });

                
      


              }
            
            if(category=='spouse'){
             $("[id^='docTypeOrder_sup_']").each( (i, el)=> {
              //   alert(el.id.substr(4))
              let category = el.id.substr(17);
              supCategoryOrders[category] = i;
              
              });
              
            }
        //  alert(category)
          if(category=='children'){ 
             $("[id^='docTypeOrder_"+childrenId+"_']").each( (i, el)=> {
              //   alert(el.id.substr(4))
              let id = el.id;
              let arr= id.split("_");
              if(arr.length>2){
                let category = arr[2];
               chlCategoryOrders[category] = i;
              }
              
              
              });
            //  alert(JSON.stringify(chlCategoryOrders));
            }
                  _.forEach(
                    documents,
                  (item ,index)=> {
                    
                      if( this.checkProperty(item  ,'category')){
                      if( this.checkProperty(item['documents'] ,'length')>0){
                        let documentCategory =item['category'];
                 
                          let activeRecords = [];
                          _.forEach(item['documents'] ,(doc)=>{
                               let order =1000000
                          if(category=='benficiary'){
                            $("[id^='order_ben_"+documentCategory+"']").each( (i, el)=> {
                             
                              if(el.id){
                                let id =el.id;
                                //_docPath_
                                let docPathArr = id.split("_docPath_");
                                if(docPathArr.length>1){
                                  let path =docPathArr[1];
                                  if(path==doc['path']){
                                    order =i;
                                  }
                                 
                                }
                              }
                              ;

                            })
                          }else if(category=='spouse'){
                            $("[id^='order_sup_"+documentCategory+"']").each( (i, el)=> {
                             
                              if(el.id){
                                let id =el.id;
                                //_docPath_
                                let docPathArr = id.split("_docPath_");
                                if(docPathArr.length>1){
                                  let path =docPathArr[1];
                                  if(path==doc['path']){
                                    order =i;
                                  }
                                 
                                }
                              }
                              

                            })
                          } else if(category=='children'){ 
                              $("[id^='order_chi_"+documentCategory+"_"+childrenId+"']").each( (i, el)=> {
                                if(el.id){
                                let id =el.id;
                                //_docPath_
                                let docPathArr = id.split("_docPath_");
                                if(docPathArr.length>1){
                                  let path =docPathArr[1];
                                  if(path==doc['path']){
                                    order =i;
                                  }
                                 
                                }
                              }
                                
                                
                                });
            
                          }
                            
                          let isAlreadyExista = _.find(postData['docList'] ,{'path':doc['path']});
                            if( !doc['isTrashDocument'] ){
                              
                              let docListItem ={
                                "path":doc['path'],
                                "order": order,
                                  "docType": documentCategory,
                                  "docTypeOrder": 10000,
                                  "category": category,
                                  "childrenId": childrenId,
                                  "documentCategory":documentCategory



                              }
                              if(_.has(benCategoryOrders ,documentCategory) && category=='benficiary'){
                                docListItem['docTypeOrder'] =benCategoryOrders[documentCategory];
                               // alert(JSON.stringify(docListItem));
                              }else if(_.has(supCategoryOrders ,documentCategory) && category=='spouse'){
                                docListItem['docTypeOrder'] =supCategoryOrders[documentCategory];
                               // alert(JSON.stringify(docListItem));
                              }else if(category==='children' && _.has(chlCategoryOrders ,documentCategory)  ){
                                
                                docListItem['docTypeOrder'] =chlCategoryOrders[documentCategory];
                                //alert(JSON.stringify(docListItem));
                              } 
                              
                              postData['docList'].push(docListItem);
                            }

                          })

                          

                        }
                  }
                        
                  });
            }
            //beneficiaryDocuments:{}, suposeDocuments:{},childrenDocuments:[],
           processDocuments(this.beneficiaryDocumentsList ,"benficiary");
            processDocuments(this.suposeDocumentsList ,"spouse");
            if(this.checkProperty(this.childrenDocuments ,'length')>0){
              _.forEach(this.childrenDocuments ,(child)=>{
                if(this.checkProperty(child ,'documents')){
                  processDocuments(child['documents'] ,"children" ,child['_id']);
                }

              });
            }
            let path ="/petition-common/save-docs-selected-config";
            let childrenDocs =_.filter(postData['docList'] ,{ 'category':'children'});
           // alert(JSON.stringify(childrenDocs));
            if(this.checkProperty(postData ,'docList','length') >0 && this.checkProperty(this.petition ,'_id')  ){
              postData['petitionId'] =this.petition._id;
             // path ="/petition/save-docs-selected-config";

              if(this.checkProperty(this.petition, 'type')==3 &&  [15].indexOf(this.checkProperty(this.petition,'subTypeDetails', 'id' )) >-1 ){
                //path ="/perm/save-docs-selected-config";
                postData['entityType'] ='perm'
            }

              
              
              this.$store.dispatch("commonAction" ,{data:postData,'path':path})
              .then((rx) =>{
              //  alert(JSON.stringify(rx));
             this.getSavedDocuments();
            

              }).catch((err)=>{
               //alert(err);
              })
            }

        },5);

        },
        downloadfile(item){
          
          let tempItem  =item
          tempItem = Object.assign( tempItem, {"viewmode":true});
          this.$emit('downloadfile' ,tempItem)
        },
        moveToTrash(type='beneficiaryDocumentsList',category='' ,childIndex=-1){
          if(type=='childrenDocuments' && childIndex>-1){
            let childrenDocuments =[];
            this.childrenDocuments.map((child ,indx)=>{
              if(indx ==childIndex){

                child['documents'].map((items)=>{
                if(_.has(items ,'category') && category==items['category'] && _.has(items ,'documents') && items['documents'].length>0 ){
                  items['documents'].map((item)=>{
                    item['isTrashDocument'] =true;
                  });
                }


              });

              }
              childrenDocuments.push(child);

            });
          
            this.childrenDocuments =[];
            this.childrenDocuments = _.cloneDeep(childrenDocuments);

          }else if(type=="beneficiaryDocumentsList"){
            this.beneficiaryDocumentsList.map((items)=>{
              if(_.has(items ,'category') && category==items['category'] && _.has(items ,'documents') && items['documents'].length>0 ){
                items['documents'].map((item)=>{
                   item['isTrashDocument'] =true;
                 });
              }


            });

          }else if(type=="suposeDocumentsList"){
            this.suposeDocumentsList.map((items)=>{
              if(_.has(items ,'category') && category==items['category'] && _.has(items ,'documents') && items['documents'].length>0 ){
                items['documents'].map((item)=>{
                   item['isTrashDocument'] =true;
                 });
              }


            });

          }
          
            setTimeout(()=>{
            // this.savedDocumentsAction(true);
            },100);
           
        },
        moveToSave(type='beneficiaryDocumentsList',category='' ,childIndex=-1){
          if(type=='childrenDocuments' && childIndex>-1){
            this.childrenDocuments.map((child ,indx)=>{
              if(indx ==childIndex){

                child['documents'].map((items)=>{
                if(_.has(items ,'category') && category==items['category'] && _.has(items ,'documents') && items['documents'].length>0 ){
                  items['documents'].map((item)=>{
                    item['isTrashDocument'] =false;
                  });
                }


              });

              }


            });
            let childrenDocuments = _.cloneDeep(this.childrenDocuments);
            this.childrenDocuments =[];
            this.childrenDocuments = _.cloneDeep(childrenDocuments);

          }else if(type=="beneficiaryDocumentsList"){
            this.beneficiaryDocumentsList.map((items)=>{
              if(_.has(items ,'category') && category==items['category'] && _.has(items ,'documents') && items['documents'].length>0 ){
                items['documents'].map((item)=>{
                   item['isTrashDocument'] =false;
                 });
              }


            });

          }else if(type=="suposeDocumentsList"){
            this.suposeDocumentsList.map((items)=>{
              if(_.has(items ,'category') && category==items['category'] && _.has(items ,'documents') && items['documents'].length>0 ){
                items['documents'].map((item)=>{
                   item['isTrashDocument'] =false;
                 });
              }


            });

          }
          
            setTimeout(()=>{
             // this.savedDocumentsAction(true);
            },100);
            
        },
       
        changedDocumentsTab(tabName='savedDocuments'){
            this.documentActiveTab = tabName;
              setTimeout(()=>{
                   this.updateLoading(false);
              } ,10);

        },
        getSavedDocuments(){
            
            let postData ={
            'petitionId':'',
            'entityType':'case',
            "category": "other"//"merge_all_docs" // other
            };
            postData['petitionId'] =this.petition._id;
            this.isDocumentsAreSaved =false;
            let path ="/petition/get-docs-selected-config";
                path ="/petition-common/get-docs-selected-config";
            if(this.checkProperty(this.petition, 'type')==3 &&  [15].indexOf(this.checkProperty(this.petition,'subTypeDetails', 'id' )) >-1 ){
              //  path ="/perm/get-docs-selected-config";
                postData['entityType'] ='perm'
            }
            this.$store.dispatch("commonAction" ,{data:postData,'path':path})
            .then((rx) =>{
            if(rx){
 
                if(this.checkProperty( rx,'docList')){
                 
                  
                this.isDocumentsAreSaved =true;
                this.savedDocumentsList =_.cloneDeep(rx['docList']);

                }else{

                    this.savedDocumentsList=[];
                   this.isDocumentsAreSaved =false;

                }
                

            }else{
                this.savedDocumentsList=[];
                this.isDocumentsAreSaved =false;

            }
           
            this.init();
            
            }).catch((e)=>{
           
            this.savedDocumentsList=[];
            this.isDocumentsAreSaved =false;
            this.init();
            });
        },
        init(){
            
            let _self =this;
            this.beneficiaryDocuments ={};
            this.beneficiaryDocumentsList =[];
            
            this.suposeDocuments ={};
            this.suposeDocumentsList =[];
            this.childrenDocuments =[];
            

           //benficiary documents
            let catDocuments =Object.entries(this.petition['documents']);
             let benFinalDocuments ={};
            _.forEach(catDocuments ,(item)=>{
                if(item.length>1){
                    let category =_.cloneDeep(item[0]);
                    let categoryOrders =null;
                    if(item[1].length>0){
                        let documents =_.cloneDeep(item[1]);
                        let categoryDocuments =[];
                        _.forEach(documents ,(document)=>{
                            if(_self.checkProperty(document ,'status') !=false){
                                document = Object.assign(document ,{ "isTrashDocument":false});
                                document['isTrashDocument'] =false;
                                document['order']=100000;
                                document['docTypeOrder']=100000;
                                
                                if(_self.isDocumentsAreSaved){
                                  let bencategoryDocs = _.filter(_self.savedDocumentsList ,{'category':'benficiary'});

                                 
                                 
                                  if(bencategoryDocs.length>0){
                                    
                                     categoryOrders = _.find(bencategoryDocs,{'docType':category ,'category':'benficiary'});
                                    
                                   
                                 
                                   let isSaveDoc = _.find(bencategoryDocs,{'path':document['path']});
                                   if(isSaveDoc && _.has(isSaveDoc ,'order')){
                                    document['order']= isSaveDoc['order'];

                                   }
                                   if(isSaveDoc && _.has(isSaveDoc ,'docTypeOrder')){
                                    document['docTypeOrder']= isSaveDoc['docTypeOrder'];

                                   }else  if(categoryOrders && _.has(categoryOrders ,'docTypeOrder')){
                                      document['docTypeOrder'] = categoryOrders['docTypeOrder'];
                                    }
                                  
                                    if(!isSaveDoc){
                                        document['isTrashDocument']=true;
                                    }
                                  }else{
                                    document['isTrashDocument']=true;
                                  }

                                }
                                categoryDocuments.push(_.cloneDeep(document));
                               

                            }

                        })
                        if(categoryDocuments.length>0){
                          categoryDocuments =_.orderBy(categoryDocuments, ['order'],  ['asc']);
                            benFinalDocuments[category] = categoryDocuments;
                            if(!_.find(this.beneficiaryDocumentsList ,{'category':category})){
                             let tempData = {"category":category,"documents":categoryDocuments ,'docTypeOrder':1000000};
                            if(categoryOrders && _.has(categoryOrders ,'docTypeOrder')){
                              tempData['docTypeOrder'] = categoryOrders['docTypeOrder'];
                              }
                            
                            this.beneficiaryDocumentsList.push(tempData);
                            //this.beneficiaryDocumentsList =
                            this.beneficiaryDocumentsList =_.orderBy(this.beneficiaryDocumentsList, ['docTypeOrder'],  ['asc']);

                            }
                          }

                    }

                }

            });
            this.beneficiaryDocuments  =_.cloneDeep(benFinalDocuments);


            //process spouse documents
            if(_self.checkProperty( _self.petition ,"dependentsInfo" ,'spouse')){
               
                if(_self.checkProperty(_self.petition['dependentsInfo']['spouse'] ,'documents'  )){
                    
                    let catDocuments =Object.entries(_self.petition['dependentsInfo']['spouse']['documents']);
                   let spoUseFinalDocuments ={};
                  
                   _.forEach(catDocuments ,(item)=>{
                        if(item.length>1){
                            let category =_.cloneDeep(item[0]);
                            let categoryOrders =null; 
                            
                            if(item[1].length>0){
                                let documents =_.cloneDeep(item[1]);
                                let spousecategoryDocuments =[];
                                _.forEach(documents ,(document)=>{
                                  document['order']= 10000;
                                  document['docTypeOrder'] =1000;
                                    if(_self.checkProperty(document ,'status') !=false){
                                       
                                        document = Object.assign(document ,{ "isTrashDocument":false});
                                        if(_self.isDocumentsAreSaved){
                                          let spousecategoryDocs = _.filter(_self.savedDocumentsList ,{'category':'spouse'});


                                          if(spousecategoryDocs.length>0){

                                            categoryOrders = _.find(spousecategoryDocs,{'docType':category ,'category':'spouse'});
                                         

                                            let isSaveDoc = _.find(spousecategoryDocs,{'path':document['path']});
                                            if(isSaveDoc && _.has(isSaveDoc ,'order')){
                                              document['order']= isSaveDoc['order'];

                                            }
                                            if(isSaveDoc && _.has(isSaveDoc ,'docTypeOrder')){
                                              document['docTypeOrder']= isSaveDoc['docTypeOrder'];

                                            }else  if(categoryOrders && _.has(categoryOrders ,'docTypeOrder')){
                                              document['docTypeOrder'] = categoryOrders['docTypeOrder'];
                                            }

                                            if(!isSaveDoc){
                                                document['isTrashDocument']=true;
                                            }
                                          }else{
                                            document['isTrashDocument']=true;
                                          }

                                        }
                                        spousecategoryDocuments.push(_.cloneDeep(document));
                                       

                                    }

                                })
                               
                                if(spousecategoryDocuments.length>0){
                                  spousecategoryDocuments =_.orderBy(spousecategoryDocuments, ['order'],  ['asc']);
                                    spoUseFinalDocuments[category] = _.cloneDeep(spousecategoryDocuments);
                                    if(!_.find(this.suposeDocumentsList ,{'category':category})){
                                      let tempData = {"category":category,"documents":spousecategoryDocuments ,'docTypeOrder':100000}
                                      if(categoryOrders && _.has(categoryOrders ,'docTypeOrder')){
                                         tempData['docTypeOrder'] = categoryOrders['docTypeOrder'];
                                      }
                                                               
                                     this.suposeDocumentsList.push(tempData);
                                     this.suposeDocumentsList =_.orderBy(this.suposeDocumentsList, ['docTypeOrder'],  ['asc']);

                                    }
                                    
                                    
                                }

                            }

                        }

                });
                   _self.suposeDocuments  =_.cloneDeep(spoUseFinalDocuments);
                  
                  

                }

            }

            //process childern Documents
            let finalChildrens =[];
            if(_self.checkProperty( _self.petition ,"dependentsInfo" ,'childrens')){
                if(_self.checkProperty( _self.petition["dependentsInfo"] ,'childrens' ,'length')>0){

                    _.forEach( _self.petition["dependentsInfo"]['childrens'] ,(child)=>{
                       
                        let childActiveDocuments =[];
                        if(_self.checkProperty(child ,'documents')){
                           
                            let catDocuments =Object.entries(child['documents']);
                           
                           
                            if(catDocuments.length>0){
                                let allCatDocuments =[];
                                let count =0;
                                _.forEach( catDocuments , (item)=>{
                                   
                                    if(item.length>1){
                                      
                                        if(item[1].length>0){
                                            let category = item[0];
                                            let categoryOrders =null; 
                                           let categoyDocuments =[];
                                            _.forEach(item[1] ,(doument)=>{
                                                if(  _self.checkProperty(doument ,'status') !=false){
                                                    doument = Object.assign(doument ,{ "isTrashDocument":false ,'order':100000 ,'docTypeOrder':10000});
                                                    if(_self.isDocumentsAreSaved){
                                                      let childrencategoryDocs = _.filter(_self.savedDocumentsList ,{'category':'children' ,'childrenId':child['_id']});
                                                      
                                                      if(childrencategoryDocs.length>0){
                                                        categoryOrders = _.find(childrencategoryDocs,{'docType':category ,'category':'children','childrenId':child['_id']});
  
                                                        let isSaveDoc = _.find(childrencategoryDocs,{'path':doument['path']});
                                                        if(isSaveDoc && _.has(isSaveDoc ,'order')){
                                                          doument['order']= isSaveDoc['order'];

                                                        }

                                                        if(isSaveDoc && _.has(isSaveDoc ,'docTypeOrder')){
                                                          doument['docTypeOrder']= isSaveDoc['docTypeOrder'];

                                                        }else  if(categoryOrders && _.has(categoryOrders ,'docTypeOrder')){
                                                          doument['docTypeOrder'] = categoryOrders['docTypeOrder'];
                                                        }
                                                       
                                                        if(!isSaveDoc){
                                                          doument['isTrashDocument']=true;
                                                        }
                                                      }else{
                                                        doument['isTrashDocument']=true;
                                                      }

                                                     }
                                                    categoyDocuments.push(doument);
                                                    count =count+1;

                                                }

                                            })
                                            
                                            if(categoyDocuments.length>0){
                                              categoyDocuments =_.orderBy(categoyDocuments, ['order'],  ['asc']);
                                                allCatDocuments[category]  =_.cloneDeep(categoyDocuments);
                                                if(!_.find(allCatDocuments ,{'category':category})){

                                                  let dc = {'category':category,'documents':categoyDocuments,'docTypeOrder':1000000};
                                                    if(categoryOrders && _.has(categoryOrders ,'docTypeOrder')){
                                                      dc['docTypeOrder'] = categoryOrders['docTypeOrder'];
                                                    }

                                                  allCatDocuments.push(dc);
                                                  allCatDocuments=_.orderBy(allCatDocuments, ['docTypeOrder'],  ['asc']);

                                                }
                                              
                                            }

                                        }


                                    }

                                })
                              
                              
                                if(count>0){
                                   
                                    let tempChildDocs ={
                                        "name":'',
                                        "_id":child['_id'],
                                        "documents":[]
                                   };
                                   if(_self.checkProperty(child ,'name')){
                                        tempChildDocs['name'] = child['name']
                                    }else{
                                        tempChildDocs['name'] = _self.checkProperty(child ,'firstName')+" "+_self.checkProperty(child ,'lastName')
                                    }
                                    tempChildDocs['documents'] = _.cloneDeep(allCatDocuments);
                                    finalChildrens.push(tempChildDocs);
                                    allCatDocuments =[];


                                }else{
                                     allCatDocuments =[];
                                }
                            
                            }
                           
                          

                        }

                    });

                    _self.childrenDocuments = _.cloneDeep(finalChildrens);
               }

            }


            
         setTimeout(()=>{
          this.updateLoading(false);
          setTimeout(()=>{
          this.updateLoading(false);
         } ,10);
         setTimeout(()=>{
          this.updateLoading(false);
         } ,10);
         } ,10);
            
       

        },

        downloadcombine() {
     let _APIURL = this.$globalgonfig._APIURL
      var self = this;
      var docs = [];

      
    let combailDocuments = (alDocs ,category='beneficiary' ,childrenId='')=>{
      //{"category":category,"documents":categoryDocuments}
      let allDocuments =[];
      let categoryOrders ={}
      let order =1000000


      if(category=='beneficiary'){
          $("[id^='docTypeOrder_ben_']").each( (i, el)=> {
          
            let category = el.id.substr(17);
            categoryOrders[category] = i;
          
          });


      }else if(category=='spouse'){
        $("[id^='docTypeOrder_sup_']").each( (i, el)=> {
        //   alert(el.id.substr(4))
        let category = el.id.substr(17);
        categoryOrders[category] = i;
        
        });
        
      }else if(category=='children'){ 
             $("[id^='docTypeOrder_"+childrenId+"_']").each( (i, el)=> {
              //   alert(el.id.substr(4))
              let id = el.id;
              let arr= id.split("_");
              if(arr.length>2){
                let category = arr[2];
                categoryOrders[category] = i;
              }
              
              
              });
            //  alert(JSON.stringify(chlCategoryOrders));
      }
      _.forEach(alDocs ,(tempList)=>{
        let documentCategory = tempList['category'];
       
        let trashedItems = _.filter(tempList['documents'] ,{isTrashDocument:false});
       // alert(JSON.stringify(docsList))
        if(trashedItems && trashedItems.length>0){
          let item =trashedItems[0];
          if(item && _.has(item,'docTypeOrder')){
            tempList['docTypeOrder'] = item['docTypeOrder'];
          }else{
            tempList['docTypeOrder'] =100000;
          }
          if(_.has(categoryOrders ,documentCategory)){
            tempList['docTypeOrder'] =categoryOrders[documentCategory];
          }
        
        let tempDocuments =[];
        _.forEach(trashedItems ,(docItem)=>{
             
                  if(category=='benficiary'){
                    $("[id^='order_ben_"+documentCategory+"']").each( (i, el)=> {
                      
                      if(el.id){
                        let id =el.id;
                        //_docPath_
                        let docPathArr = id.split("_docPath_");
                        if(docPathArr.length>1){
                          let path =docPathArr[1];
                          if(path==docItem['path']){
                            order =i;
                          }
                          
                        }
                      }
                      ;

                    })
                  }else if(category=='spouse'){
                    $("[id^='order_sup_"+documentCategory+"']").each( (i, el)=> {
                      
                      if(el.id){
                        let id =el.id;
                        //_docPath_
                        let docPathArr = id.split("_docPath_");
                        if(docPathArr.length>1){
                          let path =docPathArr[1];
                          if(path==docItem['path']){
                            order =i;
                          }
                          
                        }
                      }
                      

                    })
                  } else if(category=='children'){ 
                      $("[id^='order_chi_"+documentCategory+"_"+childrenId+"']").each( (i, el)=> {
                        if(el.id){
                        let id =el.id;
                        //_docPath_
                        let docPathArr = id.split("_docPath_");
                        if(docPathArr.length>1){
                          let path =docPathArr[1];
                          if(path==docItem['path']){
                            order =i;
                          }
                          
                        }
                      }
                        
                        
                        });

                  }
                  docItem['order'] = order;
                 tempDocuments.push(docItem);
                })

         tempDocuments =_.orderBy(tempDocuments, ['order'],  ['asc']);
         tempList['documents'] =tempDocuments;
         allDocuments.push(tempList);
         allDocuments =_.orderBy(allDocuments, ['docTypeOrder'],  ['asc']);
        }



      });
       
       
      _.forEach(allDocuments ,(doc ,index)=> {
        
        if(this.checkProperty(doc ,'documents','length') >0){
          // if(this.checkProperty(doc[1] ,'length') >0){
          //alert(JSON.stringify(doc))
          
          doc['documents'].forEach(i=> {
                if(i.path!=null && i.path !='' && !this.checkProperty(i ,'isTrashDocument')   ){ 
                  if(docs.indexOf(i.path)<=-1){
                    docs.push(i.path);
                  }
                  
                }else if(i.url!=null && i.url !='' && !this.checkProperty(i ,'isTrashDocument')  ){ 
                  if(docs.indexOf(i.path)<=-1){
                    docs.push(i.path);
                  }
                }
          })
        //}
        }
      })
    }
   // alert(JSON.stringify(this.beneficiaryDocuments));
    
    combailDocuments(this.beneficiaryDocumentsList ,'beneficiary' );
    combailDocuments(this.suposeDocumentsList ,'spouse' );
   
       
         
    if(this.checkProperty(this.childrenDocuments ,'length')>0){
              _.forEach(this.childrenDocuments ,(child)=>{
                if(this.checkProperty(child ,'documents')){
                 combailDocuments(child['documents'] ,'children' ,child['_id']);
                }

              });
    }
       

              let postdata = {
        petitionId: this.petition._id,
        documents: docs,
      };
     
     
      if(postdata['documents'].length>0){
          this.filesDownloading =true;
        let actionPath ="downloaddocsbyorder";
        if(this.checkProperty(this.petition, 'type')==3  && this.checkProperty(this.petition, 'subType')==15){
          actionPath ="downloaddocsbyorderPerm";
          }  
          
        this.$store
        .dispatch(actionPath, postdata)
        .then((response) => {
          this.savedDocumentsAction(true);
           this.filesDownloading =false;
       
          self.downloadDocumentPop = true;
         // alert( _APIURL+"/common/viewfile?path="+response.data.result.path);
          window.open(
            _APIURL+"/common/viewfile?path=" +
              response.data.result.path,
            "_blank"
          );
        }).catch((error)=>{
          this.filesDownloading =false;
          this.showToster({ message:error , isError: true})
         
        });
    
      } 
    },
        


       },
        props: {
            loadedFromPreview:{type: Boolean , default: false},
            petition: {
                type: Object,
                default: null,
              }
        },
        mounted(){
          this.filesDownloading =false;
            setTimeout(()=>{
                this.getSavedDocuments();
            },10);
           
        },
        components:{
            draggable,
            
            VuePerfectScrollbar,
            NoDataFound,
            XIcon
        }
        ,
        watch:{
          downloadDocList:(val)=>{
            if(!val){
              this.$emit('closeMe');
            }
          }
        }    
    }
</script>
