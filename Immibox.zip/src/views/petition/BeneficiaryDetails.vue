<template>
     
<div class="main-list-wrap petition_details_wrap">

       

    <template v-if="checkTabs">
       <div class="tab-inner-content tabs-nobg">
          <div class="tabs-content-panel tab-pad-wrap">
                <div class="card-panels">
        <vs-tabs>
            <vs-tab label="Personal">
                <personalInfo :visastatuses="visastatuses" :tplSection="'beneficiaryInfo'" :questionnaireDetails="questionnaireDetails" @download_or_view="download_or_view"  :petition="petition"></personalInfo>

            </vs-tab>
            <vs-tab v-if="petition.beneficiaryInfo.educations && petition.beneficiaryInfo.educations.length > 0 && petition.beneficiaryInfo.educations[0].name!=null && petition.beneficiaryInfo.educations[0].name!=''" label="Education">
                <educationInfo :visastatuses="visastatuses" :questionnaireDetails="questionnaireDetails" :petition="petition"></educationInfo>

            </vs-tab>
            <vs-tab v-if="(petition.beneficiaryInfo.prevEmploymentInfo && petition.beneficiaryInfo.prevEmploymentInfo.length > 0 && petition.beneficiaryInfo.prevEmploymentInfo[0].employerName!=null && petition.beneficiaryInfo.prevEmploymentInfo[0].employerName!='') || 
                (petition.beneficiaryInfo.prevEmploymentOutsideUS && petition.beneficiaryInfo.prevEmploymentOutsideUS.length > 0 && petition.beneficiaryInfo.prevEmploymentOutsideUS[0].employerName!=null && petition.beneficiaryInfo.prevEmploymentOutsideUS[0].employerName!='')" label="Employment">
                <employementInfo :visastatuses="visastatuses" :tplSection="'beneficiaryInfo'" :questionnaireDetails="questionnaireDetails" :anyOtherPersonEmployedInUS="petition.beneficiaryInfo.anyOtherPersonEmployedInUS" :datatype="'BENEFICIARY_EMPLOYEMENT'" :employmentList="petition.beneficiaryInfo.prevEmploymentInfo" :petition="petition"></employementInfo> 

            </vs-tab>
            <vs-tab label="Previous Spouse" v-if="checkProperty(petition,'beneficiaryInfo') && checkProperty(petition,'beneficiaryInfo','previousSpouse') && checkProperty(petition['beneficiaryInfo'],'previousSpouse','firstName')  ">
                <previousSpouseDetails :visastatuses="visastatuses" :callFrom="'BENEFICIARY'" :questionnaireDetails="questionnaireDetails" :petition="petition['beneficiaryInfo']['previousSpouse']"></previousSpouseDetails>
            </vs-tab>
            <vs-tab  v-if="petition.beneficiaryInfo.priorPeriodOfStayInUS && petition.beneficiaryInfo.priorPeriodOfStayInUS.length >0 && petition.beneficiaryInfo.priorPeriodOfStayInUS[0].visaStatus!=null"  label="Dates of Stay in USA">
                <periodofStayInUSA :callFrom="'BENEFICIARY'" :visastatuses="visastatuses" :petition="petition" :dataList="petition.beneficiaryInfo.priorPeriodOfStayInUS" />
            </vs-tab>
            <vs-tab  v-if="petition.beneficiaryInfo.nonImmPetitionsInfo && petition.beneficiaryInfo.nonImmPetitionsInfo.length >0 && petition.beneficiaryInfo.nonImmPetitionsInfo[0].visaStatus!=null"  label="Non Immigrant Petitions">
                <nonImmigrantPetitionInformation :questionnaireDetails="questionnaireDetails"  :visastatuses="visastatuses" :petition="petition"/>
            </vs-tab>
            <!-- //.immPetitionInfo.anyOtherAlienFiled -->
            <!-- petition.beneficiaryInfo.anyImmPetitionFiled && checkProperty(petition,'typeDetails','id') != 1 && (checkProperty(petition,'typeDetails','id') != 3 && checkProperty(petition,'subTypeDetails','id') != 16 ) -->
           <!-- v-if="petition.beneficiaryInfo.immPetitionInfo && petition.beneficiaryInfo.immPetitionInfo.anyOtherAlienFiled.length >0 && petition.beneficiaryInfo.immPetitionInfo.anyOtherAlienFiled[0].visaStatus!=null" -->
           
           <!-- removed one v-if="(petition.beneficiaryInfo.h1bImmPetitionsInfo.length>0 &&  petition.beneficiaryInfo.h1bImmPetitionsInfo[0].typetypeId!='') || (petition.beneficiaryInfo.immPetitionInfo)" -->
          
           
                <vs-tab v-if="checkImmpetitionTab"   label="Immigrant Petitions" >
                    <ImmigrantPetitionInformation  :visastatuses="visastatuses" :petition=" petition"/>
                </vs-tab>
                <!-- v-if="checkProperty(petition, "typeDetails", "id") == 3 && checkProperty(petition, "subTypeDetails", "id") == 16
                && checkProperty(petition,'i140AdditionalInfo') && checkProperty(petition,'i140AdditionalInfo' ,'petitionBeingFieldFor')" -->
                
                <vs-tab  v-if="checkAdditionalInfo"  label="Additional Information" >
                    <additionali140Info   :petition=" petition"/>
                </vs-tab>
        </vs-tabs>
        
        </div>
        </div>
        </div>
    </template>
    <template v-else>
      
        <div ><personalInfo :visastatuses="visastatuses" :questionnaireDetails="questionnaireDetails" @download_or_view="download_or_view" :petition="petition"></personalInfo></div>
    </template>

</div>
</template>

<script>
import previousSpouseDetails  from "@/views/petition/subtabs/previousSpouseDetails.vue"; 
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import personalInfo from "@/views/petition/subtabs/personalInfo.vue";
//import personalInfo from "@/views/petition/subtabs/personalInfoVer2.vue";
import employementInfo from "@/views/petition/subtabs/employement.vue";
import periodofStayInUSA from "@/views/petition/subtabs/periodofStayInUSA.vue";
import nonImmigrantPetitionInformation from "@/views/petition/subtabs/nonImmigrant.vue"; 
import ImmigrantPetitionInformation from "@/views/petition/subtabs/immigrantpetitions.vue"; 
import additionali140Info from "@/views/petition/subtabs/additionali140Info.vue"; 
import educationInfo from "@/views/petition/subtabs/education.vue";
import PeriodofStayInUSA from "./subtabs/periodofStayInUSA.vue";

export default {
    data: () => ({

        petitionhistory: [],

    }),
    computed: {
        checkAdditionalInfo(){
            let returnVal = false;
                if(this.checkProperty(this.petition, "typeDetails", "id") == 3 && this.checkProperty(this.petition, "subTypeDetails", "id") == 16
                && this.checkProperty(this.petition,'i140AdditionalInfo') && this.checkProperty(this.petition,'i140AdditionalInfo' ,'petitionBeingFieldFor')){
                    returnVal = true;
                }
                return returnVal 
        },
        checkImmpetitionTab(){
            let retrunVal = false
            if( (this.petition.beneficiaryInfo.h1bImmPetitionsInfo && this.petition.beneficiaryInfo.h1bImmPetitionsInfo.length>0 &&  this.petition.beneficiaryInfo.h1bImmPetitionsInfo[0].typetypeId)
            ||(this.petition.beneficiaryInfo.immPetitionInfo && this.petition.beneficiaryInfo.immPetitionInfo.anyOtherAlienFiled) ||(this.petition.beneficiaryInfo.immPetitionInfo && this.petition.beneficiaryInfo.immPetitionInfo.seekingFiledDateforETA750)
            ||(this.petition.beneficiaryInfo.immPetitionInfo && this.petition.beneficiaryInfo.immPetitionInfo.anyI140Filed) || (this.petition.beneficiaryInfo && this.petition.beneficiaryInfo.anyImmPetitionFiled) ){
                retrunVal = true
            }
            return retrunVal
        },
        checkTabs() {
          var petition = this.petition;
          if(  (petition.beneficiaryInfo.educations && petition.beneficiaryInfo.educations.length > 0 && petition.beneficiaryInfo.educations[0].name!=null && petition.beneficiaryInfo.educations[0].name!="")){

            return true
          }
            if(  (petition.beneficiaryInfo.prevEmploymentInfo && petition.beneficiaryInfo.prevEmploymentInfo.length > 0 && petition.beneficiaryInfo.prevEmploymentInfo[0].employerName && petition.beneficiaryInfo.prevEmploymentInfo[0].employerName!="")){

            return true
            }
            if(  (this.checkProperty(petition,'beneficiaryInfo' ,'nonImmPetitionsInfo')  && this.checkProperty(petition['beneficiaryInfo'] ,'nonImmPetitionsInfo' ,'length') > 0 && (this.checkProperty(petition.beneficiaryInfo.nonImmPetitionsInfo[0],'visastatuses') ||  this.checkProperty(petition.beneficiaryInfo.nonImmPetitionsInfo[0] ,'receiptNo')!="" || this.checkProperty(petition.beneficiaryInfo.nonImmPetitionsInfo[0] ,'petitionerName')!="" ))){

            return true
            }
            if(petition.beneficiaryInfo.priorPeriodOfStayInUS && petition.beneficiaryInfo.priorPeriodOfStayInUS.length >0 && petition.beneficiaryInfo.priorPeriodOfStayInUS[0].visaStatus!=null){
                return true
            }
            if(this.checkProperty(this.petition, "typeDetails", "id") == 3 && this.checkProperty(this.petition, "subTypeDetails", "id") == 16
                && this.checkProperty(this.petition,'i140AdditionalInfo') && this.checkProperty(this.petition,'i140AdditionalInfo' ,'petitionBeingFieldFor')){
                    return true
            }
          return false
        }

    },
    props: {
        questionnaireDetails:{
            type: Array,
            default: []
        },
        petition: {
            type: Object,
            default: null
        },
        visastatuses: {
            type: Array,
            default: null
        }
    },
    components: {
        additionali140Info,
    previousSpouseDetails,
    nonImmigrantPetitionInformation,
    educationInfo,
    employementInfo,
    VuePerfectScrollbar,
    personalInfo,
    ImmigrantPetitionInformation,
    periodofStayInUSA
},
    methods: {
        download_or_view(value) {
            this.$emit('download_or_view' ,value);
         },
        checPpriorPeriodOfStayInUS(data = []) {
            //enteredDate departedDate visaStatus

            if (data.length > 0) {
                if (data.length == 1) {

                    if ((data[0].enteredDate != null && data[0].departedDate != null) || (data[0].visaStatus != '' && data[0].visaStatus != null)) {

                        return true;
                    } else {
                        return false;
                    }

                } else {
                    return true;

                }

            } else {
                return false;
            }

        },
        gethistory() {
            if(this.checkProperty(this.petition ,'_id')){

            
            this.$store
                .dispatch("petitionhistory", this.petition._id)
                .then(response => {
                    this.petitionhistory = response.result.list;
                });
            }
        },
        reloadPetition() {
            this.$store.dispatch("getpetition", this.petition._id).then(response => {
                this.petition = response.data.result;
                if (this.petition.lcaId != null) {
                    this.$store
                        .dispatch("fetchLcaDetails", this.petition.lcaId)
                        .then(response => {
                            this.lcaDetails = response.data.result;
                        });
                }
                let postDt = {
                    userId: '',
                    isRfeCase: false
                }
                if (_.has(this.petition, "rfeCase")) {
                    postDt['isRfeCase'] = this.petition['rfeCase']
                }
                postDt['userId'] = this.petition['userId'];

                this.$store
                    .dispatch("getpetitionsdropdown", postDt)
                    .then(response => {
                        this.petitions = response;
                    });
            });
            this.$store.dispatch("petitionhistory", petitionId).then(response => {
                this.petitionhistory = response.result.list;
            });
        },
    },
    mounted() {
        this.gethistory();
    }
};
</script>
