<template>
    <div>
    
    <div class="menu_item assignment"  v-if="checkCaseApprove || openApproveCase"  @click="openapproveCasePopup() ;reviewrsRolesList=[]">
        <a :enableActionBtn="enableActionBtn()"    href="javascript:;"  >  Approve Case</a>
    </div>
   
  
      <div @click="openPopup() ;reviewrsRolesList=[]"  class="menu_item assignment"  v-if="currentWorkFlow && checkProperty(getPetitionDetails ,'curWorkflowActivity') && checkProperty(getPetitionDetails , 'nextWorkflowActivity') && showMeAction" >
  <!---From assignmentActivity--->
      <div  :enableActionBtn="enableActionBtn()">
      
      <a  href="javascript:;" >{{getlableName(currentWorkFlow ,'actionLable')}}</a> 
      
      </div>
    </div>

    

    <div class="menu_item 333 test"  @click="openAtnPopup( );reviewrsRolesList=[]" 
     v-if="(
       (openAssignAttorney && checkProperty(currentWorkFlow ,'code')!='ASSIGN_ATTORNEY')
        || ( checkAdminLoginroles && checkProperty(getPetitionDetails , 'nextWorkflowActivity') =='ASSIGN_ATTORNEY'  && checkProperty(currentWorkFlow ,'code')!='ASSIGN_ATTORNEY')
       
       ) && !isApproveCaseCompleted">
      <div   >
      <!---From assignmentActivity openAssignAttorney--->
      <a   :enableActionBtn="enableActionBtn()" href="javascript:;"  >Assign Attorney</a>
      
      </div>
    </div>
    
     
      <vs-popup
     
        class="holamundo main-popup"
        :title="getlableName(currentWorkFlow ,'popUpTitle')"
        :active.sync="showPopup"
      >
        <form data-vv-scope="assignmentForm" class="relative">
   
          <div class="popup_info" v-if="usersList.length>0"  @click="formErrors=''" >
            <span><eye-icon size="1.5x" class="custom-class"></eye-icon></span>
            <div class="info_list">
              <ul v-if="usersList.length>0">
              <template v-for="(usr ,usrIndx) in usersListReviewrsRolesList">
               <li :key="usrIndx">{{usr['roleName']}}</li>
              </template>
                
              </ul> 
            </div>
          </div>
          <div class="form-container">
            <div class="vx-row">
              <div class="vx-col w-full">
                <div class="form_group">
                  <label for class="form_label">Reviewer<em>*</em></label>
                  <div class="con-select w-full select-large">
                
                   <multiselect
                    name="users"
                    v-model="selectedUser"
                    :close-on-select="true"
                     v-validate="'required'"
                    :multiple="false"
                    :show-labels="false"
                    @input="selectUesr"
                    label="name"
                    data-vv-as="Reviewer"
                    placeholder="Select Reviewer"
                    :options="usersList"
                    :searchable="true"
                    :allow-empty="false"
                >
                 <template slot="selection" slot-scope="{ values, isOpen }">
                                                    <span
                                                    class="multiselect__selectcustom"
                                                    v-if="values.length && !isOpen"
                                                    >{{ values.length }} selected</span
                                                    >
                                                    <span
                                                    class="multiselect__selectcustom"
                                                    v-if="values.length && isOpen"
                                                    ></span>
                                                </template>
                </multiselect>
                </div>

                <span
                  class="text-danger text-sm"
                  v-show="errors.has('assignmentForm.users')"
                >{{ errors.first("assignmentForm.users") }}</span>
              </div>
              </div>
              
              <div class="vx-col w-full">
                <div class="form_group">
                <label class="form_label">Comments</label>
                <vs-textarea
                  data-vv-as="Comments"
                  v-validate="'required'"
                  v-model="comments"
                  name="comments" 
                  class="w-full"
                />

                <span
                  class="text-danger text-sm"
                  v-show="errors.has('assignmentForm.comments')"
                >{{ errors.first("assignmentForm.comments") }}</span>
              </div>
              </div>
            </div>

           
            <div class="text-danger text-sm formerrors" v-show="formErrors">
            
              <vs-alert
                color="warning"
                class="warning-alert reg-warning-alert no-border-radius"
                icon-pack="IntakePortal"
                icon="IP-information-button"
                active="true"
              >{{ formErrors }}</vs-alert>
              
            </div>
          </div>
         
          <div class="popup-footer relative">
           <span class="loader" v-if="loading" ><img src="@/assets/images/main/loader.gif"></span>
           <vs-button color="dark" @click="showPopup =false" class="cancel" type="filled">Cancel</vs-button>
            <vs-button
            :disabled="loading"
              color="success"
              @click="submitAction()"
              class="save"
              type="filled"
            >Assign </vs-button>
          </div>
        </form>
      </vs-popup>
 
    <vs-popup
        
          class="holamundo main-popup"
          :title="getlableName({'code':'ASSIGN_ATTORNEY'} ,'popUpTitle')?getlableName({'code':'ASSIGN_ATTORNEY'} ,'popUpTitle'):'Allocation to Attorney'"
          :active.sync="openAtornyPopup"
        >
          <form data-vv-scope="assignmentForm" class="relative">
          <div class="popup_info attorny"  v-if="attorneyList.length>0" @click="formErrors">
              <span><eye-icon size="1.5x" class="custom-class"></eye-icon></span>
              <div class="info_list">
                <ul >
                <template v-for="(attorney ,attorneyIndx) in addReviewrsRolesList">
                  <li  :key="attorneyIndx">{{attorney['roleName']}}</li>
                </template>
                  
                </ul> 
              </div>
            </div>
            <div class="form-container">
              <div class="vx-row">
                <div class="vx-col w-full">
                  <div class="form_group">
                  <div class="con-select w-full select-large">
                    <label for class="vs-select--label">Attorney<em>*</em></label>
                    
                  
                      <multiselect
                      name="users"
                      v-model="selectedUser"
                      :close-on-select="true"
                        v-validate="'required'"
                      :multiple="false"
                      :show-labels="false"
                      @input="selectUesr"
                      label="name"
                      data-vv-as="User"
                      placeholder="Select Attorney"
                      :options="attorneyList"
                      :searchable="true"
                      :allow-empty="true"
                  >
                    <template slot="selection" slot-scope="{ values, isOpen }">
                                                      <span
                                                      class="multiselect__selectcustom"
                                                      v-if="values.length && !isOpen"
                                                      >{{ values.length }} selected</span
                                                      >
                                                      <span
                                                      class="multiselect__selectcustom"
                                                      v-if="values.length && isOpen"
                                                      ></span>
                                                  </template>
                  </multiselect>
                  </div>

                  <span
                    class="text-danger text-sm"
                    v-show="errors.has('assignmentForm.users')"
                  >{{ errors.first("assignmentForm.users") }}</span>
                  </div>
                </div>
                
                <div class="vx-col w-full">
                <div class="form_group">
                  <label class="form_label">Comments</label>
                  <vs-textarea
                    data-vv-as="Comments"
                    v-validate="'required'"
                    v-model="comments"
                    name="comments"
                    
                    class="w-full"
                  />

                  <span
                    class="text-danger text-sm"
                    v-show="errors.has('assignmentForm.comments')"
                  >{{ errors.first("assignmentForm.comments") }}</span>
                </div>
                  </div>
              </div>
              <div class="text-danger text-sm formerrors" v-show="formErrors">
              
                <vs-alert
                  color="warning"
                  class="warning-alert reg-warning-alert no-border-radius"
                  icon-pack="IntakePortal"
                  icon="IP-information-button"
                  active="true"
                >{{ formErrors }}</vs-alert>
                
              </div>
            </div>
            
            <div class="popup-footer">
              <span class="loader" v-if="loading" ><img src="@/assets/images/main/loader.gif"></span>
              <vs-button color="dark" @click="openAtornyPopup =false" class="cancel" type="filled">Cancel</vs-button>
              <vs-button
                :disabled="loading"
                color="success"
                @click="submitAction('ASSIGN_ATTORNEY')"
                class="save"
                type="filled"
              >Assign </vs-button>
            </div>
          </form>
      </vs-popup>
      
    <vs-popup

      class="holamundo main-popup"
      :title="'Approve Case'" 
      :active.sync="approveCasePopup"
    >

      <form data-vv-scope="approvecase">

        <div class="form-container"  @click="formErrors=''">
          <div class="vx-row">
            
            <div class="vx-col w-full">
            <div class="form_group">
              <label class="form_label">Comments</label>
              <vs-textarea
                data-vv-as="Note"
                v-validate="'required'"
                v-model="comments"
                name="comments"
              
                class="w-full"
              />

              <span
                class="text-danger text-sm"
                v-show="errors.has('approvecase.comments')"
              >{{ errors.first("approvecase.comments") }}</span>
            </div>
            </div>
          </div>
          <div class="text-danger text-sm formerrors" v-show="formErrors">
            <vs-alert
              color="warning"
              class="warning-alert reg-warning-alert no-border-radius"
              icon-pack="IntakePortal"
              icon="IP-information-button"
              active="true"
            >{{ formErrors }}</vs-alert>
          </div>
        </div>
        <div class="popup-footer">
          <span class="loader" v-if="loading" ><img src="@/assets/images/main/loader.gif"></span>
          <vs-button
              :disabled="comments =='' || comments.trim() =='' || loading" 
            color="success"
            @click="caseApproveCaseAction()"
            class="save"
            type="filled"
          >Approve</vs-button>
        </div>
      </form>
            
    </vs-popup>




    </div>
    

    

</template>

<script>

import * as _ from "lodash";
import moment from 'moment'
import { EyeIcon } from 'vue-feather-icons'
export default {
  components: {
    EyeIcon
  },
  props: {
    scannedCopiesList:{
      type:Array,
      default:[]
    }
  },
  computed: {
    addReviewrsRolesList(){

      let reviewrsRolesList =[]
        
        let tempData = _.cloneDeep(this.attorneyList);
        let tempUnuqueItems =[]
        _.forEach(tempData ,(object)=>{
          if(tempUnuqueItems.indexOf(object['roleName']) <=-1){
             tempUnuqueItems.push(object['roleName']);
             reviewrsRolesList.push(object); 

          }

        })
        return reviewrsRolesList;
 
      
    },
    //usersList
    usersListReviewrsRolesList(){

      let reviewrsRolesList =[]
        
        let tempData = _.cloneDeep(this.usersList);
        let tempUnuqueItems =[]
        _.forEach(tempData ,(object)=>{
          if(tempUnuqueItems.indexOf(object['roleName']) <=-1){
             tempUnuqueItems.push(object['roleName']);
             reviewrsRolesList.push(object); 

          }

        })
        return reviewrsRolesList;
 
      
    },
   
   
  },
 
  data: () => ({
    reviewrsRolesList:[],
    openApproveCase:false,
    approveCasePopup:false,
    loading:false,
    lableData:[],
    attorneyList:[],
    openAssignAttorney:false,
    openAtornyPopup:false,
    currentWorkFlow:null,
    nextWorkWorkFlow:null,
    showMeAction:true,
    showPopup:false,
    selectedUser:null,
    usersList:[],
    formErrors: "",
    comments:'',
    skipedActivityList:[],
    assignMentUsersList :{
      "ASSIGN_SUPERVISOR":"SUPERVISOR_LIST",
      "ASSIGN_PARALEGAL":"PARALEGAL_LIST",
      "ASSIGN_DOCUMENTATION_MANAGER":"DOCUMENTATION_MANAGER_LIST",
      "ASSIGN_DOCUMENTATION_EXECUTIVE":"DOCUMENTATION_EXECUTIVE_LIST",
      "ASSIGN_ATTORNEY":"ATTORNEY_LIST",
      },
      skipedActivity:false,
    

    
    
  }),
  methods: {

    
    checkAssignmentWorkFlowPermessions(){
      
       let getWorkFlowDetails =  this.getWorkFlowDetails ;
       let getPetitionDetails = this.getPetitionDetails;
       if(getWorkFlowDetails && _.has( getWorkFlowDetails ,"config")){
         let configList = getWorkFlowDetails['config'];
         let postData = {
           branchId:''
         }
        
         postData['branchId'] = this.checkProperty(this.getPetitionDetails ,'branchId')
         this.$store.dispatch("getList",{data:postData ,path:'/users/get-count-by-role'} ).then(response => {
             let founActivity =false;
             
                let getUserspostData ={ "matcher":{"roleIds": [],"branchId":""}, "page": 1,	"perpage":100000000};

            let companyIdRoles =[50,51];
            let branchIdRoles =[4, 5, 6, 7, 8, 9, 10, 11 ,12];
              if(response){
                let assignMentUsersList = _.cloneDeep(this.assignMentUsersList);
                //assignMentUsersList =Object.assign(assignMentUsersList ,{"CASE_APPROVED":"CASE_APPROVED"})
                
                _.forEach(assignMentUsersList ,(usersListKey ,activityCode)=>{
                   let activity = _.find(configList ,{ "code":activityCode });
                   getUserspostData ={ "matcher":{"roleIds": [],"branchId":""}, "page": 1,	"perpage":100000000};
                  if(usersListKey=="CASE_APPROVED"){
                    if(_.find(activity['editors'] ,{"roleId":this.getUserRoleId})){
                      this.openApproveCase =true;
                       this.updatePetiotionActionBtn(true);

                    }else{
                      // this.updatePetiotionActionBtn(false);

                    }

                  }else{
                   
                    let activityUsersList = _.find(configList ,{ "code":usersListKey });
                   
                    if(!founActivity && activity.actionRequired =="Yes" &&  _.find(activity['editors'] ,{"roleId":this.getUserRoleId}) && getPetitionDetails['completedActivities'].indexOf(activityCode)<=-1  ){
                      
                         
                        _.forEach(activityUsersList['editors'] ,(item)=>{
                          getUserspostData.matcher.roleIds.push(item.roleId);

                          if(companyIdRoles.indexOf(item.roleId)>-1 && this.checkProperty(this.getPetitionDetails ,'companyDetails' ,'_id')){
                            getUserspostData = Object.assign(getUserspostData ,{"companyId":this.checkProperty(this.getPetitionDetails ,'companyDetails' ,'_id') })
                          }

                        if(branchIdRoles.indexOf(item.roleId)>-1 && this.checkProperty(this.getPetitionDetails ,'branchId')){
                            getUserspostData['matcher']['branchId'] = this.checkProperty(this.getPetitionDetails ,'branchId');
                          }
                           
                          let roleId = JSON.stringify(item.roleId);
                          if(_.has(response ,roleId) && response[roleId] && !founActivity  ){
                            if( (response[roleId]>1 && item.roleId ==this.getUserRoleId  ) || ( item.roleId !=this.getUserRoleId  )  ){
                               this.currentWorkFlow = activity;
                                this.showMeAction =true;
                                
                                founActivity =true
                                 this.usersList =[];
                                this.updatePetiotionActionBtn(true);
                                

                            }else{
                              this.showMeAction =false;
                             // this.updatePetiotionActionBtn(false);

                            }
                            
                          }
                                    

                        });

                        if(founActivity && getUserspostData.matcher.roleIds.length>0){

                          this.$store.dispatch("getList",{data:getUserspostData ,path:'/petition/assign-user-list'} ).then(response => {
                            //alert(JSON.stringify(response.list));
                            let lst = []
                            
                            _.forEach(response.list ,(item)=>{
                              if(_.has(item ,'name') && _.has(item ,'roleName') && ( item._id !=this.getUserData['userId'])){
                                  item.name = item.name+"("+item.roleName+")";
                                  lst.push(item);
                              }
                              
                            });
                            this.usersList = lst;
                          });

                        }
                    }
                  }
                  
                })
              }

          })
       
         

       }
        

    },
    openapproveCasePopup(){
      let getLcaDetails = _.cloneDeep(this.getLcaDetails);

      if( getLcaDetails && _.has(getLcaDetails ,"statusId") && [2,3].indexOf(getLcaDetails['statusId'])<=-1 ){
        this.showToster({message:"LCA should be either Filed or Certified in order to approve the case." ,isError: true});
        
        this.$store.dispatch("setPetitionTab" , 'LCA')
        .then(()=>{
          this.$emit("updatepetition" ,'LCA');
        })
        .catch(()=>{
           this.$emit("updatepetition" ,'LCA');

        })
       
        return false;
      }else{
          this.showPopup =false;
          this.formErrors = '';
          this.comments ='';
          this.loading =false,
          this.approveCasePopup =true;
          this.$validator.reset();

      }
       


    },
    caseApproveCaseAction(){
       this.formErrors ='';
         let postData = {
             petitionId: this.getPetitionDetails['_id'],
            comment: this.comments,
            action:'CASE_APPROVED', // "SUBMIT_TO_LAW_FIRM", // "CASE_APPROVED" / "LCA_CERTIFIED_FOR_PETITION" / "SUBMIT_TO_USCIS" / "USCIS_APPROVED" / "USCIS_RECEIVED_RFE" / "USCIS_DENIED" 
            today: moment().format('YYYY-MM-DD'), // Required on Status changes to "Received RFE"
           subTypeName:this.checkProperty(this.getPetitionDetails,'subTypeDetails','name'),
           typeName:this.checkProperty(this.getPetitionDetails,'typeDetails','name'),

         };
         
         this.$validator.validateAll("approvecase").then((result) => {
           
            if (result) {
               this.loading =true;
               this.$store
              .dispatch("commonAction", {"data":postData ,"path":"/petition/manage-approval-process"})
              .then(response => {
                
                 this.showToster({message:response.message,isError:false });
                 this.showPopup =false;
                 this.approveCasePopup =false;
                 setTimeout(() =>{
                    this.loading =false;
                    this.$emit("updatepetition");
                 });
                
                
                                
              })
              .catch((error)=>{
                 this.loading =false;
                this.formErrors =error;
              })
       
       

              
            }
          });
           

       
     

    },


    openAtnPopup(){
      

      if((this.checkPetitionLcaRequired  ) && !this.checkProperty(this.getPetitionDetails ,"lcaId") && this.getUserRoleId !=51){
        this.actiVateTabe('LCA');
      }else{
        this.selectedUser=null;
        this.comments ='';
        this.formErrors =''
        this.loading =false;
        this.$validator.reset();
        this.openAtornyPopup=true;
         this.comments = "Case "+this.getPetitionDetails.typeDetails.name+", "+this.getPetitionDetails.subTypeDetails.name+"  is being assigned for further actions";

      }
     this.getattorneyList()
     //this.findSkipedActivityList();
       
     
    },
   // {{lableData}} 
    getlableName(activityObj ,msgType){

       let returnValue = this.checkProperty(activityObj ,"name");
     if(this.checkProperty(activityObj ,'code')){
      let labels = [
        {"code":"ASSIGN_SUPERVISOR" ,"label":"Assign Supervisor"},
        {"code":"ASSIGN_PARALEGAL" ,"label":"Assign Paralegal"},
        {"code":"ASSIGN_DOCUMENTATION_MANAGER" ,"label":"Assign Document Manager"},
        {"code":"ASSIGN_DOCUMENTATION_EXECUTIVE" ,"label":"Assign Document Executive"},
       {"code":"ASSIGN_ATTORNEY" ,"label":"Assign Attorney"},
      ];

      let assignLabel = _.find(labels , {"code":activityObj['code']} );
     
      if(assignLabel && this.checkProperty(assignLabel ,'label' )){

        returnValue = assignLabel['label'];

      }  else if(this.lableData.length>0 && activityObj && _.has(activityObj , 'code')){
        let msgObject = _.find(this.lableData , {"code":activityObj['code']});
        if( msgObject && _.has(msgObject , msgType)){
            returnValue = msgObject[msgType];
        }

      }
    }

      return returnValue;

    },
    enableActionBtn(){
     // alert("enableActionBtn");
       this.loading =false;
       this.updatePetiotionActionBtn(true);
       return true;
    },
    init(){
      this.loading =false;
      this.showMeAction =false;
      this.skipedActivity =false;
     let getWorkFlowDetails =  this.getWorkFlowDetails ;
     let getPetitionDetails = this.getPetitionDetails
    
      
      if(this.getPetitionDetails && this.checkProperty(this.getPetitionDetails , 'nextWorkflowActivity') && _.has(getWorkFlowDetails ,'config') && this.getPetitionDetails['nextWorkflowActivity'] !="SUBMIT_TO_LAW_FIRM"){
        
        
       if((this.getPetitionDetails['nextWorkflowActivity'] == 'ASSIGN_DOCUMENTATION_MANAGER' || (this.getPetitionDetails['nextWorkflowActivity'] ==   'ASSIGN_DOCUMENTATION_EXECUTIVE' ) ) && this.getPetitionDetails['nextWorkflowActivity'] !="SUBMIT_TO_LAW_FIRM"){
          this.getattorneyList();
       }
       let config  = this.getWorkFlowDetails['config'];  
      let petitionCurrentActivityIndex = _.findIndex(config ,{"code": this.getPetitionDetails['nextWorkflowActivity'] }) 
     
      let usersListObject  =null
      let currentWorkFlow = null
        //find activity is required . if activity is not required then goto next activity
        _.forEach(this.assignMentUsersList ,(usersListKey ,activityCode)=>{
         
             
           currentWorkFlow = _.find(config ,{"code":activityCode});
           usersListObject = _.find(config ,{"code":usersListKey});
          let configIndex = _.findIndex(config ,{"code":activityCode});
          
          if(
            (_.find(currentWorkFlow['editors'] ,{"roleId":this.getUserRoleId}) || this.checkAdminLoginroles )
           && currentWorkFlow['actionRequired']=='Yes' && (usersListObject 
           &&  _.has(usersListObject ,'editors') 
           && usersListObject['editors'].length>0   )
           // && (configIndex>= petitionCurrentActivityIndex || this.skipedActivityList.indexOf(activityCode)>-1)
           ){
            if((configIndex>= petitionCurrentActivityIndex )){
               
                  this.skipedActivity =false;
                  this.showMeAction =true;
                 
                  this.updatePetiotionActionBtn(true);
                  
                  this.currentWorkFlow =currentWorkFlow;
                  return false;

            }else if(( this.skipedActivityList.indexOf(activityCode)>-1) ){
            
               this.skipedActivity =true;
              this.showMeAction =true;
             
              this.updatePetiotionActionBtn(true);
              this.currentWorkFlow =currentWorkFlow;
              return false;

            }  
           
            
          }
          
          
        });
       
        if(this.showMeAction){
           this.usersList =[];
          let postData ={
              "matcher":{
               
                "roleIds": [],
                "branchId":"",
              
              },
              
              "page": 1,	
              "perpage":100000000,
              
            };

            let companyIdRoles =[50,51];
            let branchIdRoles =[4, 5, 6, 7, 8, 9, 10, 11 ,12];
            _.forEach(usersListObject['editors'] ,(item)=>{
              
              
              postData.matcher.roleIds.push(item.roleId);
               if(companyIdRoles.indexOf(item.roleId)>-1 && this.checkProperty(this.getPetitionDetails ,'companyDetails' ,'_id')){
                postData = Object.assign(postData ,{"companyId":this.checkProperty(this.getPetitionDetails ,'companyDetails' ,'_id') })
              }

            if(branchIdRoles.indexOf(item.roleId)>-1 && this.checkProperty(this.getPetitionDetails ,'branchId')){
                postData['matcher']['branchId'] = this.checkProperty(this.getPetitionDetails ,'branchId');
              }
              

            });
             //alert(JSON.stringify(postData));

            this.$store.dispatch("getList",{data:postData ,path:'/petition/assign-user-list'} ).then(response => {
             //alert(JSON.stringify(response.list));
             let lst = []
            
            _.forEach(response.list ,(item)=>{
              if(_.has(item ,'name') && _.has(item ,'roleName') && ( item._id !=this.getUserData['userId'])){
                  item.name = item.name+" ("+item.roleName+")";
                  lst.push(item);
              }
            


            });
            this.usersList = lst;
            if([3,4 ,50,51].indexOf(this.getUserRoleId) <= -1 && !this.isCaseApproved){

               this.checkAssignmentWorkFlowPermessions();

            }
           

          });



        }

       
     


      }
     
       

    },
    openPopup(){
       this.approveCasePopup =false;
         this.formErrors = '';
        this.comments ='';
      if((this.checkPetitionLcaRequired  ) && !this.checkProperty(this.getPetitionDetails ,"lcaId") && this.getUserRoleId !=51){
        this.actiVateTabe('LCA');
      }else{

         this.formErrors ="";
          this.comments ='';
          this.showPopup =true;
          this.selectedUser =null;
          this.loading =false;


        if(this.usersList.length>0){
          this.formErrors ="";
          this.comments ='';
          this.showPopup =true;
          this.selectedUser =null;
          this.loading =false;

        }else{
          this.showToster({message:'Reviewers not found.',isError:true });
          this.checkAssignmentWorkFlowPermessions();
        }

      
         this.comments = "Case "+this.getPetitionDetails.typeDetails.name+", "+this.getPetitionDetails.subTypeDetails.name+"  is being assigned for further actions";


      }

       
      this.$validator.reset();
      
      
     

    },
    submitAction(action=''){
          this.$validator.validateAll("assignmentForm").then((result) => {
            if (result) {
              let postData = {
               petitionId: this.getPetitionDetails['_id'],
                comment: this.comments,
                  "userId": this.checkProperty(this.selectedUser ,"_id"),
                  "userName": this.checkProperty(this.selectedUser ,"name"),
                  "roleId":  this.checkProperty(this.selectedUser ,"roleId"),
                  "assignRoleName":  this.checkProperty(this.selectedUser ,"roleName"),
                  subTypeName:this.checkProperty(this.getPetitionDetails,'subTypeDetails','name'),
                  typeName:this.checkProperty(this.getPetitionDetails,'typeDetails','name'),
                   "action":this.currentWorkFlow['code'], //"ASSIGN_SUPERVISOR", // "ASSIGN_PARALEGAL" / "ASSIGN_DOCUMENTATION_MANAGER" / "ASSIGN_DOCUMENTATION_EXECUTIVE" / "ASSIGN_ATTORNEY"
                 // "lastUserName": "Paralegal", // is Required when replacing a paralegal(action == "REPLACE_PARALEGAL"),
                //  "submitted": true // Required only when submitting to any roleSupervisor
                 isSkippedAction:this.skipedActivity?true:false

              };
              

              if(action !=''){
                postData['action']  = 'ASSIGN_ATTORNEY';

              }

              
              //alert(JSON.stringify(postData))
               this.loading =true;
               this.$store
              .dispatch("commonAction", {"data":postData ,"path":"/petition/assign-a-role"})
              .then(response => {
                this.showPopup =false;
                this.openAtornyPopup =false;
                this.showToster({message:response.message,isError:false });
                this.skipedActivity =false;
                setTimeout(() => {
                   this.loading =false;
                   this.$emit("updatepetition" ,'');
                   //setTimeout(()=>{ this.init(); } ,100);
                } ,100)

                
                
                
                                
              })
              .catch((error)=>{
                
                this.formErrors =error;
                this.loading =false;
              })
              
       
       

              
            }
          });
      

    },
    selectUesr(item){
      this.selectedUser = item;
     
    },
    getattorneyList(){
      
      
      this.attorneyList =[];
      let config  = _.filter(this.getWorkFlowDetails.config ,(item)=>{
          return item['code']!= 'LCA_SUBMIT' && item['code'] != 'LCA_REQUEST';

        });
      let code = "ASSIGN_ATTORNEY";
      let assignAttorney = _.find(config ,{'code':code});
      let attorneyListObject = _.find(config ,{'code':'ATTORNEY_LIST'});
      if(
        ( (_.has(assignAttorney , 'editors') &&  _.find(assignAttorney.editors ,{"roleId":this.getUserRoleId}) ) || this.checkAdminLoginroles  )
      
      && _.has(attorneyListObject ,'editors') && attorneyListObject['editors'].length>0    ){
            this.openAssignAttorney = true;
            this.updatePetiotionActionBtn(true);
          //get Attorney roles
          let companyIdRoles =[50,51];
          let branchIdRoles =[4, 5, 6, 7, 8, 9, 10, 11,12 ,13];
          let postData ={
          "matcher":{
            
            "roleIds": [],
            "branchId":'',
          },
          
          "page": 1,	
          "perpage":100000000,
          
          };
          _.forEach(attorneyListObject['editors'] ,(item)=>{
              postData.matcher.roleIds.push(item.roleId);
                if(companyIdRoles.indexOf(item.roleId)>-1 && this.checkProperty(this.getPetitionDetails ,'companyDetails' ,'_id')){
                  postData = Object.assign(postData ,{"companyId":this.checkProperty(this.getPetitionDetails ,'companyDetails' ,'_id') })
                }
              if(branchIdRoles.indexOf(item.roleId)>-1 && this.checkProperty(this.getPetitionDetails ,'branchId')){
                  postData['matcher']['branchId'] = this.checkProperty(this.getPetitionDetails ,'branchId');
                  
              }
          });
          // alert(JSON.stringify(postData));
          this.$store
          .dispatch("getList",{data:postData ,path:'/petition/assign-user-list'} )
          .then(response => {
             this.attorneyList = response.list
             _.forEach(this.attorneyList ,(item)=>{
                item.name = item.name+" ("+item.roleName+")";
              });
          });

      }
    },
    findSkipedActivityList(){
      this.skipedActivityList =[];
      this.skipedActivity =false;
      let getWorkFlowDetails =  this.getWorkFlowDetails;
    if(this.getPetitionDetails && this.checkProperty(this.getPetitionDetails , 'nextWorkflowActivity') && _.has(getWorkFlowDetails ,"config")){
        
         let config  = getWorkFlowDetails['config'];
       let petitionCurrentActivityIndex = _.findIndex(config ,{"code": this.getPetitionDetails['nextWorkflowActivity'] });
       let completedActivityList = this.getPetitionDetails['completedActivities'];
       
       if(petitionCurrentActivityIndex>-1 && completedActivityList.length>0 && (completedActivityList.indexOf("SUBMIT_TO_USCIS")<=-1 )){
        _.forEach(config ,(activityItem ,index)=>{
          if(index<petitionCurrentActivityIndex){

            if(completedActivityList.indexOf(activityItem['code'])<=-1   && _.has(this.assignMentUsersList ,activityItem['code'])){
              //this.skipedActivityList.push(activityItem['code']);

              if(completedActivityList.indexOf("CASE_APPROVED") >-1){

                if([ 'ASSIGN_DOCUMENTATION_MANAGER','ASSIGN_DOCUMENTATION_EXECUTIVE'].indexOf(activityItem['code']) >-1){

                    this.skipedActivityList.push(activityItem['code']);

                }

              }else{
                 this.skipedActivityList.push(activityItem['code']);

              }
             
            }

          }


        })
       }
            
    }
    this.init();

    },
    actiVateTabe(tabName='LCA'){
     
       this.$store.dispatch("setPetitionTab" , tabName)
      .then(()=>{
        this.$emit("actiVateTabe",tabName);
      })
      .catch(()=>{
        this.$emit("actiVateTabe",tabName);

      })
          
      
    },

  },
  mounted() {
    
    this.updatePetiotionActionBtn(false);
    this.checkAssignmentWorkFlowPermessions();
  
   this.assignMentUsersList = {
      "ASSIGN_SUPERVISOR":"SUPERVISOR_LIST",
      "ASSIGN_PARALEGAL":"PARALEGAL_LIST",
      "ASSIGN_DOCUMENTATION_MANAGER":"DOCUMENTATION_MANAGER_LIST",
      "ASSIGN_DOCUMENTATION_EXECUTIVE":"DOCUMENTATION_EXECUTIVE_LIST",
      "ASSIGN_ATTORNEY":"ATTORNEY_LIST",
      };
  
    ///messages/list
     this.skipedActivityList =[];
     this.skipedActivity =false;
   
    this.$store.dispatch("getList" ,{data:{"category": "WORKFLOW"},path:"/messages/list"})
       .then(response => {
         //alert(JSON.stringify(response))
         this.lableData = response.messages.WORKFLOW;
         
          this.findSkipedActivityList();
       })
       .catch(error => {
          
          this.findSkipedActivityList();

       })
   
    

  },
 
};
</script>