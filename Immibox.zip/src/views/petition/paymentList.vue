<template>
    <div class="card-panels pt-0">
       
      <div >
        <div class="accordian-table filingdata_table pad0">
          <h3 class="small-header pad20 pt-0 pb-0 mb-0">Payment History</h3>
            <template v-if="checkProperty(petition ,'filingFeeDetails','partlyPaidLogs') && (petition.filingFeeDetails.partlyPaidLogs.length>0)" >
              <vs-table :data="petition.filingFeeDetails.partlyPaidLogs" class="fees_table pt-2"> 
                <template slot="thead">
                  <!-- <vs-th>
                    Payment Status
                  </vs-th> -->
                  <vs-th>
                    Mode of Payment
                  </vs-th>
                  <vs-th >
                    Reference Number
                  </vs-th> 
                  <vs-th >
                    Amount
                  </vs-th>
                  <vs-th >
                    Payment Date
                  </vs-th>
                </template>

                <template slot-scope="{data}">
                    <vs-tr v-for="filingfee in data" :key="filingfee" >
                      <!-- <vs-td>
                        {{checkProperty(filingfee,'statusDetails','name')}}
                      </vs-td> -->
                      <vs-td>
                        {{checkProperty(filingfee,'paymentMethodId') | formatML(modeofPaymentsList)}}
                      </vs-td>
                      <vs-td>
                        {{checkProperty(filingfee,'paymentRefNo')}}
                      </vs-td>

                      <vs-td>
                        {{formatprice(checkProperty(filingfee,'amount'))}}
                      </vs-td>
                      <vs-td>
                        {{checkProperty(filingfee,'paymentDate') | formatDate }}
                      </vs-td>
                    </vs-tr>
                  </template>
              </vs-table>
            </template>
            <!-- <template v-else> 
           
              <NoDataFound ref="NoDataFoundRef" :loading="false" content="" heading="No Fees/Invoices Found" type='Fees/Invoices' />
            </template> -->
          
        </div>

      </div>

     
    </div>
   



 
</template>

<script>
const formatter = new Intl.NumberFormat("en-US", {
style: "currency",
currency: "USD",
minimumFractionDigits: 2
});

import FileUpload from "vue-upload-component/src";
import moment from "moment";
import VuePerfectScrollbar from "vue-perfect-scrollbar";
//import NoDataFound from "@/views/common/noData.vue";
import _ from "lodash";

export default {
computed:{
  checkCreateButton(){
    let returnValue =true;
    if(this.loadedFromPreview==true || (this.checkProperty(this.petition ,'intStatusId')) !=1){
      returnValue =false;
    }

    return returnValue;


  },
  checkInvoiceExists(){
    if(_.get( this.petition ,'filingFeeDetails.feeDetails')){

      let invoiceItems =_.filter(this.petition.filingFeeDetails.feeDetails ,{ "invoice":true});
    if(invoiceItems && invoiceItems.length>0){
      return true;
    }else{
      return false;
    }

    }else{
      return false
    }
    

  },
},
props: {
  loadedFromPreview:false,
   currentRole:null,
   currentUser:null,
  petition: {
    type: Object,
    default: null
  }
},
components: {
  FileUpload,
  VuePerfectScrollbar,
  //NoDataFound
},
methods: {
  checkPaidAmount(){
      let totalInvoiceAmount = 0
      let totalPaidAmount = 0
      if(this.checkProperty(this.petition,'filingFeeDetails','feeDetails') && this.checkProperty(this.petition['filingFeeDetails'],'feeDetails','length')>0 ){
        let filingfeeList = _.cloneDeep(this.checkProperty(this.petition,'filingFeeDetails','feeDetails'))
        filingfeeList.forEach(item => {
          if(!item.invoice){
            totalInvoiceAmount += item.amount;
          }
        });
      }
      //alert(totalInvoiceAmount)
      if(totalInvoiceAmount != 0){
        this.totalInvoiceAmountPaid = totalInvoiceAmount
        
      }
      if(this.checkProperty(this.petition,'filingFeeDetails','partlyPaidLogs') && this.checkProperty(this.petition['filingFeeDetails'],'partlyPaidLogs','length')>0 ){
        let filingfeeList = _.cloneDeep(this.checkProperty(this.petition,'filingFeeDetails','partlyPaidLogs'))
        filingfeeList.forEach(item => {
          totalPaidAmount += item.amount;
        });
      }
      if(totalPaidAmount != 0){
        this.partlyPaidAmountt= totalPaidAmount
        //alert(this.partlyPaidAmountt)
      }
      if(this.partlyPaidAmountt && this.totalInvoiceAmountPaid ){
        this.totalDueAmount = this.totalInvoiceAmountPaid - this.partlyPaidAmountt
      }
      
  },
    formatprice(amount) {
    return formatter.format(amount);
  },
  updateFilingFee(action=true) {
    this.$emit("showfilingFeesPopup" ,action);
    
  },
  getmasterDataList(){
        this.$store.dispatch("getmasterdata", "invoice_status").then((response) => {
           this.PaymentsStatusList = response;
        });
        this.$store.dispatch("getmasterdata", "invoice_payment_methods").then((response) => {
           this.modeofPaymentsList = response;
        });
    },
},
data: () => ({
  partlyPaidAmountt:0,
  totalInvoiceAmountPaid:0,
  modeofPaymentsList:[],
  PaymentsStatusList:[],
  totalDueAmount:0,
}),
mounted() {
  this.updateLoading(false);
  this.getmasterDataList()
  this.checkPaidAmount()
  
 
}
};
</script>