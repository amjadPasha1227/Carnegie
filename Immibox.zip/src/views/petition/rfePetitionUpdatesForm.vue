<template>
   <div>
      <section  class="petition_updates_wrap d-block w-full" v-if="checkProperty(benficiaryFinalLog ,'endedOn') ||
        (checkProperty(petition ,'completedActivities') && petition.completedActivities.indexOf('RFE_UPDATE_USCIS_RECEIPT_NUMBER')>-1 && checkProperty(petition ,'courierTrackingDetails') &&  checkProperty(petition ,'courierTrackingDetails' ,'length')>0) " >
         <template v-if="checkProperty(benficiaryFinalLog ,'endedOn')">
            <template v-if="checkProperty(benficiaryFinalLog ,'endedOn')">
               <div class="case_updates_sec case_updates_sec-v2">
                  <h3 class="d-flex align-center">{{checkProperty(benficiaryFinalLog, "data", 'title')}}
                     <button class="cursor primary-btn Update_USCIS_btn" @click="openUscisStatusPopup()" v-if="petition && ( ( checkCanSubmitResponse) && petition.completedActivities.indexOf('UPDATE_USCIS_RECEIPT_NUMBER') >= 0 && checkProperty(petition ,'uploadUscisDocs')==false && checkProperty(petition ,'autoUscisStatusUpdate') ==true )" >
                        <span class="viewdetails" target="_blank" >
                           <template v-if="checkProperty(petition ,'uploadUscisDocs')!=true && checkProperty(petition ,'autoUscisStatusUpdate') ==true">Upload USCIS Documents</template>
                           <template v-else>Update USCIS Status</template>
                        </span>
                     </button>
                  </h3>   
               <div class="case_updates_wrap">
               <div class="case_updates_list">
                  <ul>
                  <template  >
                     <!-- :class="{'current12':selecetedTab == trindex}"  @click="selecetedTab = trindex" :key="trindex" -->
                     <li class="cursor-pointer12"   >
                     <div class="case_update">
                        
                        <a class="status_btn" :class="{'btn_denied': (checkProperty(benficiaryFinalLog['data'],'rfeNotice', 'action' )=='RFE_USCIS_DENIED') ||   (benficiaryFinalLog['data']['action'] =='RFE_USCIS_RECEIVED_RFE') }" >
                           {{ checkProperty(benficiaryFinalLog, 'data', 'title' )  }} 
                        </a>

                        <h4>{{ checkProperty(benficiaryFinalLog, 'data', 'beneficiaryName') }}
                           <span style="text-transform: capitalize;">Beneficiary</span>
                        
                        </h4> 
                        <template v-if="checkProperty(benficiaryFinalLog ,'data' ,'rfeNotice' )">
                        <template v-for="( doc ,docind) in benficiaryFinalLog['data']['rfeNotice']['documents']">
                           <template v-if="docind ==0">
                              <a :title="checkProperty(benficiaryFinalLog['data'] ,'rfeNotice' ,'documentType')" class="action_btn file_btn"  :key="docind" @click="downloadfile(doc)">Copy received</a>
                           </template>
                        </template>
                        </template>

                        <!---- <a class="action_btn">{{checkProperty(petition ,'rfeNotice' ,"documentType")}} copy recieved</a>-->
                        <div class="case-date-info">
                           <label  v-if="checkProperty(benficiaryFinalLog['data'], 'rfeNotice','receivedDate' )" >Received Date <strong>{{checkProperty(benficiaryFinalLog['data'], 'rfeNotice', 'receivedDate' ) | formatDate}}</strong></label>  
                              <label v-if="checkProperty(benficiaryFinalLog['data'] ,'rfeNotice' ,'issuedDate')">Issued Date <strong>{{checkProperty(benficiaryFinalLog['data'] ,'rfeNotice' ,'issuedDate') | formatDate}}</strong></label>  
                              <label v-if="checkProperty(benficiaryFinalLog['data'] ,'rfeNotice' ,'dueDate')">Due Date <strong>{{checkProperty(benficiaryFinalLog['data'] ,'rfeNotice' ,'dueDate') | formatDate}}</strong></label>  
                              <label v-if="checkProperty(benficiaryFinalLog ,'endedOn')">Updated On <strong>{{checkProperty(benficiaryFinalLog ,'endedOn' ) | formatDate}}</strong></label>  
                           <!-- <label  v-if="checkProperty(benficiaryFinalLog['data'] ,'rfeNotice' ,'documentType')">
                              Document Type<strong> {{checkProperty(benficiaryFinalLog['data'] ,'rfeNotice' ,'documentType') }} copy received</strong>
                              </label> -->
                        </div>
                        
                        </div> 
                     </li>
                     </template>
                     
                  </ul>
               </div>

               </div>
               </div>
            </template>
         </template>
         <div class="case_updates_sec case_updates_sec-v2" v-if=" checkProperty(petition ,'completedActivities') && petition.completedActivities.indexOf('RFE_UPDATE_USCIS_RECEIPT_NUMBER')>-1 && checkProperty(petition ,'courierTrackingDetails') &&  checkProperty(petition ,'courierTrackingDetails' ,'length')>0 ">
            <h3 class="d-flex align-center">RFE Receipt Received</h3>   
            <div class="case_updates_wrap">
               <div class="case_updates_list">
                  <ul>
                     <template v-for="(tracking , trindex) in petition['courierTrackingDetails']" >
                        <li class="cursor-pointer12" :class="{'current12':selecetedTab == trindex}"  @click="selecetedTab = trindex" :key="trindex" v-if="checkProperty(tracking ,'category')=='RFE_UPDATE_USCIS_RECEIPT_NUMBER'" >
                           <div class="case_update">
                              <a class="status_btn">Receipt Received</a>
                              <h4>
                              <template v-if="checkProperty(tracking ,'userName' )">{{checkProperty(tracking ,'userName' )}}</template>
                              <template><span style="text-transform: capitalize;">{{checkProperty(tracking ,'userType' )}}</span></template> 
                              </h4> 
                              <template v-for="( doc ,docind) in tracking['documents']">
                                 <template v-if="docind ==0">
                                    <a class="action_btn file_btn"  :key="docind" @click="downloadfile(doc)">Copy received</a>
                                 </template>
                              </template>
                              <div class="case-date-info">
                                 <label  v-if="checkProperty(tracking ,'receivedDate' )" >Received Date <strong>{{checkProperty(tracking ,'receivedDate' ) | formatDate}}</strong></label>  
                                 <label class="cursor" :title="checkProperty(tracking ,'receiptName' )" v-if="checkProperty(tracking ,'receiptName' )" >USCIS Receipt<strong>{{checkProperty(tracking ,'receiptName' ) }}</strong></label>  
                                 <label class="cursor" :title="checkProperty(tracking ,'receiptNumber' )" v-if="checkProperty(tracking ,'receiptNumber' )" >Receipt  <strong>{{checkProperty(tracking ,'receiptNumber' ) }}</strong></label>  
                              </div>
                           </div> 
                        </li>
                     </template>
                  </ul>
               </div>
            </div>
         </div>
      </section>
      <div class="case-approved-detailes gc-case perm-caseupdates newRFECaseUpdates_v2">
         <div class="case-approved-detailes case-approved-detailes-v2 docket_submitted_USCIS" v-if="checkProperty(petition ,'courierTrackingDetails') && checkProperty(petition ,'courierTrackingDetails' ,'length')>0 && checkSubmitToUSCIS && checkProperty(rfeCourierTracking, 'length')>0">
            <h2 class="case-heading">RFE Docket Submitted to USCIS</h2>
            <template  v-for="(tracking ,ind ) in rfeCourierTracking" >
               <div  :key="ind" v-if="tracking.category == 'RFE_COURIER_TRACKING' && checkProperty(tracking,'trackingDataLogs' ,'length' )> 0 && checkProperty(tracking.trackingDataLogs[0] ,'data') && checkProperty(tracking.trackingDataLogs[0] ,'data' ,'origin_info') " >

               <div class="case-approved-body" :key="aind" v-for="(atracking ,aind ) in tracking.trackingDataLogs[0].data.origin_info.trackinfo">
               <div class="left">
                     <ul>
                        <li  class="primary" v-if="atracking.StatusDescription"> {{atracking.StatusDescription}}</li>
                        <li v-if="atracking.Details && atracking.Date">
                        <p>{{atracking.Details}} <span> {{atracking.Date | formatDateTime }}</span></p>
                        </li>
                        <li  class="primary" v-if="atracking.tracking_detail"> {{atracking.tracking_detail}}</li>
                        <li v-if="atracking.location && atracking.checkpoint_date">
                        <p>{{atracking.location}} <span> {{atracking.checkpoint_date | formatDateTime }}</span></p>
                        </li>
                     </ul>
               </div>
               <div class="right">
                     <ul>
                           
                           
                              <li ><a class="viewdetails" target="_blank" :href="checkProperty(tracking ,'trackingUrl' )"> View Details</a></li>
                     
                     </ul>
               </div>
               </div>
            </div>
            <div class="case-approved-body" :key="ind" v-if="tracking.category == 'RFE_COURIER_TRACKING'" >
               <div class="left">
                  <ul>
                     <li  class="primary">Submitted</li>
                     <li>
                        <p>Created date
                        
                        <span> {{tracking.createdOn | formatDateTime }}</span></p>
                     </li>
                     <li v-if="checkProperty(tracking ,'sentDate')">
                        <p>Sent Date
                           <span>{{checkProperty(tracking ,'sentDate') | formatDate}}</span></p>
                     </li>
                     
                     <li>
                        <p>Tracking Number
                           <a target="_blank" :href="checkProperty(tracking ,'trackingUrl' )" > <span>{{checkProperty(tracking ,'trackingId')}}</span></a> 
                        </p>
                     </li>
                  </ul>
               </div>
               <div class="right">
                  <ul>
                     <li ><a class="viewdetails" target="_blank" :href="checkProperty(tracking ,'trackingUrl' )"> View Details</a></li>
                  
                  </ul>
               </div>
            </div>
            </template>
         </div>
         <div class="case-approved-body" v-if="checkProperty(petition ,'completedActivities') && petition['completedActivities'].indexOf('RFE_SUBMIT_TO_USCIS')>-1">
            <div class="left">
            <h5 class="primary ">RFE Filed with USCIS</h5>
            <ul>
               <li class="w-full" v-if="getActionCompletedDate('RFE_SUBMIT_TO_USCIS') != null && checkProperty(getActionCompletedDate('RFE_SUBMIT_TO_USCIS'),'data', 'comment')">
                     <p class="comment-sec">Comments  <span class="wrapall" v-html="checkProperty(getActionCompletedDate('RFE_SUBMIT_TO_USCIS'),'data', 'comment')"></span></p>
               </li>
               <li v-if="getActionCompletedDate('RFE_SUBMIT_TO_USCIS') != null">
                     <p>Updated Date <span> {{checkProperty(getActionCompletedDate('RFE_SUBMIT_TO_USCIS'), 'endedOn') | formatDateTime}} </span></p>
               </li>
            </ul>
            </div>
            <div class="right">
            <ul>
            </ul>
            </div>
         </div>
         <div class="case-approved-body" v-if="false && checkProperty(petition ,'completedActivities') && (petition['completedActivities'].indexOf('UPLOAD_SIGNED_DOCUMENTS')>-1  || petition['completedActivities'].indexOf('UPLOAD_SCANNED_COPY')>-1 ) ">
            <div class="left">
            <h5 class="primary ">RFE Uploaded signed copies </h5>
            <ul>
               
               <li v-if="getActionCompletedDate('UPLOAD_SCANNED_COPY') != null">
                     <p>Uploaded On <span> {{checkProperty(getActionCompletedDate('UPLOAD_SCANNED_COPY'), 'endedOn') | formatDateTime}} </span></p>
               </li> 
               <li v-else-if="getActionCompletedDate('UPLOAD_SIGNED_DOCUMENTS') != null">
                     <p>Uploaded On <span> {{checkProperty(getActionCompletedDate('UPLOAD_SIGNED_DOCUMENTS'), 'endedOn') | formatDateTime}} </span></p>
               </li>
               
               
               
            </ul>
            </div>
         </div>
         <div class="case-approved-body" v-if=" checkProperty(petition ,'completedActivities') && petition['completedActivities'].indexOf('RFE_REQUEST_PETITIONER_SIGN')>-1 ">
            <div class="left">
            <h5 class="primary ">RFE Sent For Petitioner Signature</h5>
            <ul v-if="getActionCompletedDate('RFE_REQUEST_PETITIONER_SIGN') != null && checkProperty(getActionCompletedDate('RFE_REQUEST_PETITIONER_SIGN'), 'data')
               && checkProperty(getActionCompletedDate('RFE_REQUEST_PETITIONER_SIGN'), 'data','documents') && checkProperty(getActionCompletedDate('RFE_REQUEST_PETITIONER_SIGN').data,'documents','length')>0 " >
               <li>
                     <vs-col class="padl0 padr0" >
                        <documentsView :showTitle="false" @download_or_view="downloadfile"  :documentsList="checkProperty(getActionCompletedDate('RFE_REQUEST_PETITIONER_SIGN'), 'data','documents')" :petitionDetails="petition" />
                     </vs-col>
               </li>
            </ul>
            <ul>
               <li class="w-full" v-if="getActionCompletedDate('RFE_REQUEST_PETITIONER_SIGN') != null && checkProperty(getActionCompletedDate('RFE_REQUEST_PETITIONER_SIGN'),'data', 'comment')">
                     <p class="comment-sec">Comments  <span class="wrapall" v-html="checkProperty(getActionCompletedDate('RFE_REQUEST_PETITIONER_SIGN'),'data', 'comment')"></span></p>
               </li>
               <li v-if="getActionCompletedDate('RFE_REQUEST_PETITIONER_SIGN') != null">
                     <p>Updated Date <span> {{checkProperty(getActionCompletedDate('RFE_REQUEST_PETITIONER_SIGN'), 'endedOn') | formatDateTime}} </span></p>
               </li> 
               
               
               
            </ul>
            </div>
            <div class="right">
            
            </div>
         </div>
         <div class="case-approved-body" v-if="checkProperty(petition ,'completedActivities') && petition['completedActivities'].indexOf('RFE_CASE_APPROVED')>-1">
            <div class="left ">
            <h5 class="primary ">RFE Response Documents Approved</h5>
            <ul>
               <li class="w-full" v-if="getActionCompletedDate('RFE_CASE_APPROVED') != null && checkProperty(getActionCompletedDate('RFE_CASE_APPROVED'),'data', 'comment')">
                     <p class="comment-sec">Comments  <span class="wrapall" v-html="checkProperty(getActionCompletedDate('RFE_CASE_APPROVED'),'data', 'comment')"></span></p>
               </li>
               <li v-if="getActionCompletedDate('RFE_CASE_APPROVED') != null">
                     <p>Updated Date <span> {{checkProperty(getActionCompletedDate('RFE_CASE_APPROVED'), 'endedOn') | formatDateTime}} </span></p>
               </li>
            </ul>
            </div>
            <div class="right" >
            
            </div>
         </div>
         <div class="case-approved-body" v-if="false && checkProperty(petition ,'completedActivities') && petition['completedActivities'].indexOf('RFE_REVIEW_RESPONSE_DOCS')>-1">
            <div class="left ">
            <h5 class="primary ">RFE Response Documents Sent For Approval</h5>
            <ul v-if="getActionCompletedDate('RFE_REVIEW_RESPONSE_DOCS') != null && checkProperty(getActionCompletedDate('RFE_REVIEW_RESPONSE_DOCS'), 'data')
               && checkProperty(getActionCompletedDate('RFE_REVIEW_RESPONSE_DOCS'), 'data','rfeResDocs') && checkProperty(getActionCompletedDate('RFE_REVIEW_RESPONSE_DOCS').data,'rfeResDocs','length')>0 " >
               <li>
                     <vs-col class="padl0 padr0" >
                        <documentsView :showTitle="false" @download_or_view="downloadfile"  :documentsList="checkProperty(getActionCompletedDate('RFE_REVIEW_RESPONSE_DOCS'), 'data','rfeResDocs')" :petitionDetails="petition" />
                     </vs-col>
               </li>
            </ul>
            <ul>
               <li class="w-full" v-if="getActionCompletedDate('RFE_REVIEW_RESPONSE_DOCS') != null && checkProperty(getActionCompletedDate('RFE_REVIEW_RESPONSE_DOCS'),'data', 'comment')">
                     <p class="comment-sec">Comments  <span class="wrapall" v-html="checkProperty(getActionCompletedDate('RFE_REVIEW_RESPONSE_DOCS'),'data', 'comment')"></span></p>
               </li>
               <li v-if="getActionCompletedDate('RFE_REVIEW_RESPONSE_DOCS') != null">
                     <p>Updated Date <span> {{checkProperty(getActionCompletedDate('RFE_REVIEW_RESPONSE_DOCS'), 'endedOn') | formatDateTime}} </span></p>
               </li>
            </ul>
            </div>
            <div class="right">
            <ul v-if="!(checkProperty(petition ,'completedActivities') && petition['completedActivities'].indexOf('CASE_APPROVED')>-1)">
               <li v-if="enableActionBtns('Response Documents Sent For Approval') && checkActionsBtnPermissionss('CASE_APPROVED')" @click="$refs['actionsPopups'].openassignActivityPopup([],'Approve Response Docs','Approve Response Docs','CASE_APPROVED')">
                     <div class="relative">
                        <vs-button   class="light-blue-btn">Approve Response Docs</vs-button>
                     </div>
               </li>
               
               
            </ul>
            </div>
         </div>
         <div class="case-approved-body" v-if="checkProperty(petition ,'completedActivities') && petition['completedActivities'].indexOf('RFE_PREPARE_RESPONSE_DOCS')>-1 ">
            <div class="left ">
            <h5 class="primary ">RFE Response Documents Prepared</h5>
            <ul v-if="getActionCompletedDate('RFE_PREPARE_RESPONSE_DOCS') != null && checkProperty(getActionCompletedDate('RFE_PREPARE_RESPONSE_DOCS'), 'data')
               && checkProperty(getActionCompletedDate('RFE_PREPARE_RESPONSE_DOCS'), 'data','rfeResDocs') && checkProperty(getActionCompletedDate('RFE_PREPARE_RESPONSE_DOCS').data,'rfeResDocs','length')>0 " >
               <li>
                     <vs-col class="padl0 padr0" >
                        <documentsView :showTitle="false" @download_or_view="downloadfile"  :documentsList="checkProperty(getActionCompletedDate('RFE_PREPARE_RESPONSE_DOCS'), 'data','rfeResDocs')" :petitionDetails="petition" />
                     </vs-col>
               </li>
            </ul>
            <ul>
               <li v-if="getActionCompletedDate('RFE_PREPARE_RESPONSE_DOCS') != null"> 
                     <p>Updated Date <span>{{checkProperty(getActionCompletedDate('RFE_PREPARE_RESPONSE_DOCS'), 'endedOn') | formatDateTime}} </span></p> 
               </li>
            </ul>
            </div>
            <div class="right" >
               <ul v-if="!(checkProperty(petition ,'completedActivities') && petition['completedActivities'].indexOf('RFE_REVIEW_RESPONSE_DOCS')>-1)">
               <li  v-if="enableActionBtns('Response Docs Prepared') && checkActionsBtnPermissionss('RFE_REVIEW_RESPONSE_DOCS')" @click="$refs['actionsPopups'].openRefePrepareResDocsPopUp('RFE_REVIEW_RESPONSE_DOCS')">
                     <div class="relative">
                        <vs-button   class="light-blue-btn">Send Response Docs For Approval</vs-button>
                     </div>
               </li>
               
            </ul>
            </div>
         </div>
      </div>
   </div>
</template>
<script>
import actionsPopup from "@/views/common/actionsPopup.vue";
import documentsView from "@/views/common/documentsView.vue";
import moment from "moment";
import * as _ from "lodash";
 export default {
   computed:{

   },
   data: () => ({
      rfeCourierTracking:[],
      rfeCaseAggingList:[],
      benficiaryFinalLog:null,
      h4UscisLogs:[],
      h4EadLogs:[],
      selecetedTab:1,
      statusTab:0,
      petitionhistory: [],
      checkCanSubmitResponse:false,
   }),
   props:{
      caseCurrentDetails:{
         type: Array,
         default: []
      },
      petition: {
         default: null
      },
      visastatuses: {
         type: Array,
         default: null
      },
      workFlowDetails:{
         type: Object,
         default: null
      }
   },
   components:{
      documentsView,
      actionsPopup,
   },
   computed:{
      checkDocM() {
      let returnVal = false;
      let docmManagerList =[];
      let adminsList =[];
      if(_.has( this.workFlowDetails ,'config')){
        let docManagerActivity = _.find(this.workFlowDetails.config, {
          code: "DOCUMENTATION_MANAGER_LIST",
        });
        if (docManagerActivity && docManagerActivity.editors) {
          docmManagerList = _.map(docManagerActivity.editors, "roleId");
        }
        if (docmManagerList && docmManagerList.indexOf(this.getUserRoleId)>-1) {
          returnVal = true;
        }
        let adminsactiVityList = _.find(this.workFlowDetails.config, {
          code: "MANAGER_LIST",
        });
        
        if (adminsactiVityList && adminsactiVityList.editors) {
          adminsList = _.map(adminsactiVityList.editors, "roleId");
        }
        
        if (adminsList && adminsList.indexOf(this.getUserRoleId) >-1) {
          returnVal = true;
        }
    }
     
      return returnVal;
      },

       enableActionBtns(){
        return (status='')=>{
            let returnValue =false;
            if(this.checkProperty(this.petition ,'completedActivities') &&
                    (this.petition['completedActivities'].indexOf('USCIS_APPROVED')>-1
                    ||  this.petition['completedActivities'].indexOf('USCIS_RECEIVED_RFE')>-1
                    ||  this.petition['completedActivities'].indexOf('USCIS_DENIED')>-1
                    ||  this.petition['completedActivities'].indexOf('USCIS_WITHDRAWN')>-1
                    ||  this.petition['completedActivities'].indexOf('UPDATE_USCIS_RESPONSE')>-1
                    )){
                        return false

             }else{
                if(status=='Docket Submitted to USCIS'  && (this.checkProperty(this.petition ,'courierTrackingDetails') && this.checkProperty(this.petition ,'courierTrackingDetails' ,'length')>0 && this.checkSubmitToUSCIS)){
                      returnValue =true
                    

                }else if(status=='Filed with USCIS' && (this.checkProperty(this.petition ,'completedActivities') && this.petition['completedActivities'].indexOf('SUBMIT_TO_USCIS')>-1)){
                    
                        returnValue =true
                    

                }else if(status =='Sent For Petitioner Signature' && (this.checkWorkActivityisRequires('REQUEST_PETITIONER_SIGN') && this.checkProperty(this.petition ,'completedActivities') && this.petition['completedActivities'].indexOf('REQUEST_PETITIONER_SIGN')>-1 )){
                    
                        returnValue =true;
                    

                }else if(status=='Response Docs Approved' && (this.checkProperty(this.petition ,'completedActivities') && this.petition['completedActivities'].indexOf('CASE_APPROVED')>-1)){
                    
                        returnValue =true;
                    
                    
                }else if(status=='Response Documents Sent For Approval' && (this.checkProperty(this.petition ,'completedActivities') && this.petition['completedActivities'].indexOf('RFE_REVIEW_RESPONSE_DOCS')>-1)){
                    
                    returnValue =true;
                    
                }else if(status=='Response Docs Prepared' && (this.checkProperty(this.petition ,'completedActivities') && this.petition['completedActivities'].indexOf('RFE_PREPARE_RESPONSE_DOCS')>-1 )){
                    
                        returnValue =true;
                    
                    
                }else if(status == "Case Created" && this.petition['completedActivities'].indexOf('RFE_PREPARE_RESPONSE_DOCS')<=-1){
                    returnValue =true;

                }
            }

        return returnValue
        }
       },
        checkActionsBtnPermissionss(){
            let returnVal =false;
            return (code='')=>{
                if( _.has(this.workFlowDetails ,"config") && this.checkProperty(this.workFlowDetails ,'config', 'length') ){
                    let nextWorkflowActivityList =[];
                    

                    if(this.checkProperty(this.petition,'nextWorkflowActivity', 'length')){
                        nextWorkflowActivityList = this.petition['nextWorkflowActivity'];
                    }
                    let isAdmin =false;
                    let canAssignAttorneyorDocManager =false;
                    let canAssignDocm = false;
                    let adminsList =[]
                    let attorneymanagerList = [];
                    let docmList =[]

                    let adminsactiVityList = _.find(this.workFlowDetails.config , {"code":'MANAGER_LIST'});
                    if(adminsactiVityList && adminsactiVityList.editors){
                     adminsList = _.map(adminsactiVityList.editors, 'roleId');
                     isAdmin = adminsList.indexOf(this.getUserRoleId) > -1;
                    }


                    let attorneyactiVityList = _.find(this.workFlowDetails.config , {"code":'ASSIGN_ATTORNEY' ,"actionRequired":'Yes'});
                    if(attorneyactiVityList && attorneyactiVityList.editors){
                    attorneymanagerList = _.map(attorneyactiVityList.editors, 'roleId');
                    canAssignAttorneyorDocManager = attorneymanagerList.indexOf(this.getUserRoleId) > -1;
                    }

                    
                     

                        let docmListActivity = _.find(this.workFlowDetails.config , {"code":'ASSIGN_DOCUMENTATION_MANAGER'});
                        if(docmListActivity && docmListActivity.editors){
                           docmList = _.map(docmListActivity.editors, 'roleId');
                           canAssignDocm = docmList.indexOf(this.getUserRoleId) > -1;
                        }

                        let canCaseApprove =  false;
                        let caseApprovalactiVityList = _.find(this.workFlowDetails.config , {"code":'CASE_APPROVED'});
                        if(caseApprovalactiVityList && caseApprovalactiVityList.editors){
                        let caseApprovalList = _.map(caseApprovalactiVityList.editors, 'roleId');
                            caseApprovalList.indexOf(this.getUserRoleId) > -1;
                        }

                    


                    //let canAssignAttorneyorDocManager =false;
                   
                  
                    if(code=="RFE_REVIEW_RESPONSE_DOCS"){

                        if(
                           ! ( (isAdmin || canCaseApprove) && this.petition.completedActivities.indexOf('RFE_REVIEW_RESPONSE_DOCS') >-1 && this.petition.completedActivities.indexOf('RFE_PREPARE_RESPONSE_DOCS') >-1 && this.petition.completedActivities.indexOf('CASE_APPROVED') <=-1) 
                            &&  (( nextWorkflowActivityList.indexOf('RFE_REVIEW_RESPONSE_DOCS')>-1 && ( isAdmin || this.checkDocM) ) && this.petition.completedActivities.indexOf('RFE_REVIEW_RESPONSE_DOCS')<=-1 && this.petition.completedActivities.indexOf('RFE_PREPARE_RESPONSE_DOCS')>-1 )
                             ){
                            
                            returnVal = true;
                            return returnVal
                        }

                    }else if(code =="RFE_PREPARE_RESPONSE_DOCS"){
                        if( 
                             ! ( (isAdmin || canCaseApprove) && this.petition.completedActivities.indexOf('RFE_REVIEW_RESPONSE_DOCS') >-1 && this.petition.completedActivities.indexOf('RFE_PREPARE_RESPONSE_DOCS') >-1 && this.petition.completedActivities.indexOf('CASE_APPROVED') <=-1) 
                             && (( nextWorkflowActivityList.indexOf('RFE_PREPARE_RESPONSE_DOCS')>-1 && ( isAdmin || this.checkDocM) ) && nextWorkflowActivityList.indexOf('RFE_PREPARE_RESPONSE_DOCS')>-1 && this.petition.completedActivities.indexOf('RFE_PREPARE_RESPONSE_DOCS') <=-1)){
                            returnVal = true;
                            return returnVal
                        }

                    } else if( code=='CASE_APPROVED'){
                        if( (isAdmin || canCaseApprove) && this.petition.completedActivities.indexOf('RFE_REVIEW_RESPONSE_DOCS') >-1 && this.petition.completedActivities.indexOf('RFE_PREPARE_RESPONSE_DOCS') >-1 && this.petition.completedActivities.indexOf('CASE_APPROVED') <=-1){
                            returnVal =  true;
                            return returnVal
                       }


                    }
                
                }
                return returnVal;
          
        }


        },
        checkWorkActivityisRequires(){
        return (code='')=>{
          if( _.has(this.workFlowDetails ,"config") && this.checkProperty(this.workFlowDetails ,'config', 'length') ){
            let config = this.workFlowDetails['config'];
            let ilteredItem = _.find(config, {"code":code,"actionRequired":'Yes'});
            if(ilteredItem){
              return true;
            }
            return false;
          }else{
            return false;
          }
          
        }
        },
        checkSubmitToUSCIS(){
            let returVal =false;
            let isSUbmitToDol = _.find(this.petition['courierTrackingDetails'] ,{"category":'RFE_COURIER_TRACKING'});
            if(isSUbmitToDol){
            return true;
            }
            return returVal;
        },
   },
   methods:{
      getrfeCourierTracking(){
         this.rfeCourierTracking = [];
         let self = this;
         if(this.checkProperty(this.petition, 'courierTrackingDetails') && this.checkProperty(this.petition, 'courierTrackingDetails', 'length')>0){
            this.rfeCourierTracking =  _.filter(this.petition['courierTrackingDetails'], (item)=>{
              if(_.has(item, 'category') && self.checkProperty(item, 'category') == 'RFE_COURIER_TRACKING'){
               return item;
              } 
            })
         }
      },
      downloadfile(value) {
         this.$emit('download_or_view' ,value);
      },
      getActionCompletedDate(code=''){
            let returnValue=null;
            if(code){
                let item = _.find( this.caseCurrentDetails , {"action":code});
                if(item && this.checkProperty( item, 'endedOn')){
                    returnValue = item
                }
            }
            return returnValue;

      },
      getActivityByCode(code=''){
         if(code){
            let activity = _.find(this.caseCurrentDetails ,{'action':code});
            if(activity ){
               return activity
            }
         }
         return null;
      },
      getupdateUscisAggingLogs(){
         let self =this;
         this.benficiaryFinalLog =null;
         let tempBenficiaryFinalLog = [];
         _.forEach(this.caseCurrentDetails,(item)=>{
            if(['RFE_UPDATE_USCIS_RESPONSE' ].indexOf(item['action']) >-1){   
               if(_.has(item ,'endedOn') && item['endedOn'] && !this.checkProperty(item ,'ignore')){
                  if(_.has(item ,'endedOn') && item['endedOn']){
                     item['endedOn'] = moment(item['endedOn'])
                  }
                  if(_.has(item ,'startedOn') && item['startedOn']){
                     item['startedOn'] = moment(item['startedOn'])
                  }
                  if(self.checkProperty( item, 'data', 'rfeNotice' )){
                     if( self.checkProperty(item, 'data','userCatergoryCode') =='beneficairy'){
                        let tempRfeDocs = null;
                        if(self.petition && self.checkProperty(self.petition,'rfeRfeNotice') && self.checkProperty(self.petition['rfeRfeNotice'], 'documents') && self.checkProperty(self.petition['rfeRfeNotice'], 'documents', 'length')>0){
                           tempRfeDocs =  self.checkProperty(self.petition['rfeRfeNotice'], 'documents')
                        }
                        if(_.has(item,'data') && _.has(item['data'],'rfeNotice') && _.has(item['data']['rfeNotice'],'documents')
                        && this.checkProperty(item['data']['rfeNotice'],'documents') && this.checkProperty(item['data']['rfeNotice'],'documents', 'length')>0){
                           tempBenficiaryFinalLog.push(item);
                        }else if( tempRfeDocs  && self.checkProperty(tempRfeDocs, 'length')>0){
                           item['data']['rfeNotice']['documents'] = tempRfeDocs;
                           tempBenficiaryFinalLog.push(item);
                        }else{
                           tempBenficiaryFinalLog.push(item);  
                        }
                     }
                  }
               }
            }
         });
         if(tempBenficiaryFinalLog.length>0){
            tempBenficiaryFinalLog  = _.orderBy(tempBenficiaryFinalLog ,['endedOn'] ,['desc'] );
            self.benficiaryFinalLog = tempBenficiaryFinalLog[0];
         }
      },
      getRFEAggingLogs(){
         let self =this;
         let rfeCaseCodesList = [
            {
               action:'RFE_PREPARE_RESPONSE_DOCS',
               title:'Response Documents Prepared'
            },
            {
               action:'RFE_REVIEW_RESPONSE_DOCS',
               title:'Response Documents Sent For Approval'
            },
            {
               action:'REF_CASE_APPROVED',
               title:'Response Documents Approved'
            },
            {
               action:'RFE_REQUEST_PETITIONER_SIGN',
               title:'Uploaded signed copies'
            },
            {
               action:'RFE_SUBMIT_TO_USCIS',
               title:'Filed with USCIS'
            },
            {
               action:'RFE_UPDATE_USCIS_RESPONSE',
               title:'Approved'
            },
         ];
         let tempRfeCaseAggingList = [];
         this.rfeCaseAggingList = [];
         if(this.caseCurrentDetails){
            _.forEach(this.caseCurrentDetails,(item)=>{
               let findObj = _.find(rfeCaseCodesList, {'action':item['action']})
               if(findObj){
                  if(_.has(item ,'endedOn') && item['endedOn'] && !this.checkProperty(item ,'ignore')){
                     if(_.has(item ,'endedOn') && item['endedOn']){
                        item['endedOn'] = moment(item['endedOn'])
                     }
                     if(_.has(item ,'startedOn') && item['startedOn']){
                        item['startedOn'] = moment(item['startedOn'])
                     }
                     item['title'] = findObj['title']
                     tempRfeCaseAggingList.push(item)
                  }
               }
            })
            if(tempRfeCaseAggingList && self.checkProperty(tempRfeCaseAggingList, 'length')>0){
               tempRfeCaseAggingList  = _.orderBy(tempRfeCaseAggingList ,['endedOn'] ,['desc'] );
               this.rfeCaseAggingList = tempRfeCaseAggingList;
            }
         }
      },
   },
   mounted(){
      this.getrfeCourierTracking();
      //this.getupdateUscisAggingLogs('h4ead');
      this.getupdateUscisAggingLogs();
   }
 }
</script>