<template>
    <div  :class="{'pad20':callPrevious}">
        <h5 class="names_title mt-6"  >Employment Outside US</h5>
        <div class="vx-row m-0 main-list-panel" >
        <div class="vx-col w-full p-0  edu-block" :key="index" v-for="(item,index) in petition">

            <div class="dependent-block_wrap">
                <div class="dependent-block pb-0">
                    <div class="dependent-title">
                        <h3>
                            {{item.employerName}}
                        </h3>

                    </div>
                    <div class="dependent_details">
                        
                        <ul>
                            <li v-if="item.businessType"> Business Type <span>{{item.businessType}}</span></li>
                            <li v-if="item.jobTitle"> Job Title <span>{{item.jobTitle}}</span></li>
                            <li v-if="item.salary"> Salary 
                                <span>
                                    <template v-if="checkProperty(item,'address','countryDetails') && checkProperty(item['address'],'countryDetails' ,'currencyCode')">
                                        {{item.salary | formatprice(checkProperty(item['address'],'countryDetails' ,'currencyCode'))}}
                                    </template>
                                    <template v-else>
                                        {{item.salary | formatprice}}
                                    </template>
                                    
                                </span>
                            </li>
                            <li v-if="item.payFrequency"> Pay Frequency <span>{{item.payFrequency }}</span></li>
                           </ul>
                            <ul>     
                                <li v-if="item.startDate"> Start Date <span>{{item.startDate | formatDate}}</span></li>
                            <li v-if="item.endDate">End Date <span>{{item.endDate | formatDate}}</span></li>
                            <li v-if="item.address && ( checkProperty(item,'address','line1') ||
                            checkProperty(item,'address','line2') || checkProperty(item,'address','aptType') ||
                            checkProperty(item,'address','locationId') || checkProperty(item,'address','stateId') ||
                            checkProperty(item,'address','countryId')|| checkProperty(item,'address','zipcode')
                            )">Work Address <span v-html="$options.filters.addressformat(item.address)"></span>
                            </li>
                        </ul>                        
                    </div>
                    <div class="editor_view_wrap" v-if="item.jobDuties">
                        <h3 class="sub-title">Job Duties</h3>
                        <div class="editor_view" v-html="item.jobDuties"></div>
                    </div>
                </div>
            </div>

        </div>
        </div>
    </div>
</template>

<script>
export default {
    props: {
        petition: {
            type: Object,
            default: null
        },
        visastatuses: {
            type: Array,
            default: null
        },
        callPrevious:{
            type:Boolean,
            default:false
        }
    },
    mounted() {
    },
    methods: {
     

    }
};
</script>