<template>
    <div class="main-list-wrap petition_details_wrap">
    <div class="pad20">  
        <div class="vx-row m-0 main-list-panel" >
            <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'i140AdditionalInfo' ,'petitionBeingFieldFor')">
                <div class="main-list">
                    <p>
                        This petition is being filed for
                        <span>{{petitionFieldFr(checkProperty(petition,'i140AdditionalInfo' ,'petitionBeingFieldFor'))}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'i140AdditionalInfo' ,'petitionBeingField')">
                <div class="main-list">
                    <p>
                        This petition is being filed
                        <span >{{petitionBeiField(checkProperty(petition,'i140AdditionalInfo' ,'petitionBeingField'))}}</span>
                    </p>
                </div>
            </div> 
    
            <div class="vx-col  md:w-1/2 w-full p-0" v-if="checkProperty(petition,'i140AdditionalInfo' ,'petitionBeingField') == 'aa'">
                <div class="main-list">
                    <p>
                        Previous Petition Receipt Number
                        <span>{{checkProperty(petition,'i140AdditionalInfo' ,'prevPetiReceiptNumber')}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'i140AdditionalInfo' ,'anyOtherPetiOrApplications')">
                <div class="main-list">
                    <p>
                        Are you filing any other petitions or applications with this Form I-140?
                        <span>{{checkProperty(petition,'i140AdditionalInfo' ,'anyOtherPetiOrApplications')}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'i140AdditionalInfo' ,'anyOtherPetiOrApplications') == 'Yes' &&
            checkProperty(petition,'i140AdditionalInfo' ,'petiOrApplicAllApplicableBoxes')
             &&  checkProperty(petition['i140AdditionalInfo'] ,'petiOrApplicAllApplicableBoxes','length')>0 ">
                <div class="main-list"> 
                    <p>
                        Applicable boxes
                        <span>
                            {{ applicableBoxesList }}
                        </span>
                       
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'i140AdditionalInfo' ,'anyOtherPetiOrApplications') == 'Yes' &&
            checkProperty(petition,'i140AdditionalInfo' ,'petiOrApplicAllApplicableBoxes')
             &&  checkProperty(petition['i140AdditionalInfo'] ,'petiOrApplicAllApplicableBoxes','length')>0 &&
              petition['i140AdditionalInfo']['petiOrApplicAllApplicableBoxes'].indexOf('other')>-1  ">
                <div class="main-list">
                    <p>
                        Additional Information
                        <span>{{checkProperty(petition,'i140AdditionalInfo' ,'petiOrApplicAllApplicableBoxOther')}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'i140AdditionalInfo' ,'removalProceedings')">
                <div class="main-list">
                    <p>
                        Is the person for whom you are filing in removal proceedings?
                        <span>{{checkProperty(petition,'i140AdditionalInfo' ,'removalProceedings')}}</span>
                    </p>
                </div>
            </div>  
            <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'i140AdditionalInfo' ,'immiVisaPetitionOrPerson')">
                <div class="main-list">
                    <p>
                        Has any immigrant visa petition ever been filed by or on behalf of this person?
                        <span>{{checkProperty(petition,'i140AdditionalInfo' ,'immiVisaPetitionOrPerson')}}</span>
                    </p>
                </div>
            </div>  
            <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'i140AdditionalInfo' ,'supportOfAnotherFormi140')">
                <div class="main-list">
                    <p>
                        Are you filing this petition without an original labor certification because the original
                 labor certification was previously submitted in support of another Form I-140?
                        <span>{{checkProperty(petition,'i140AdditionalInfo' ,'supportOfAnotherFormi140')}}</span>
                    </p>
                </div>
            </div>  
            <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'i140AdditionalInfo' ,'departmentOfLabor')">
                <div class="main-list">
                    <p>
                        If you are filing this petition without an original labor certification, are you requesting that U.S.
                        Citizenship and Immigration Services (USCIS) request a duplicate labor certification from the Department of Labor (DOL)?
                        <span>{{checkProperty(petition,'i140AdditionalInfo' ,'departmentOfLabor')}}</span>
                    </p>
                </div>
            </div>  
            <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'i140AdditionalInfo' ,'considerBnfEmpInfoForLetters')">
                <div class="main-list">
                    <p>
                        To fill Letters, consider beneficiary employment details from
                        <span v-if="checkProperty(petition,'i140AdditionalInfo' ,'considerBnfEmpInfoForLetters') == 'perm'">PERM</span>
                        <span v-if="checkProperty(petition,'i140AdditionalInfo' ,'considerBnfEmpInfoForLetters') == 'questionnaire'">Questionnaire</span>
                    </p>
                </div>
            </div>
        </div> 
    </div>
</div>
    </template>
    
    <script>
    import * as _ from "lodash";
    export default {
        components: {
        },
        props: {
            petition: {
                type: Object,
                default: null
            },
        },
        computed: {
            applicableBoxesList(){

                let returnval = '';
                if(this.checkProperty(this.petition,'i140AdditionalInfo' ,'anyOtherPetiOrApplications') == 'Yes' &&
                this.checkProperty(this.petition,'i140AdditionalInfo' ,'petiOrApplicAllApplicableBoxes')
                &&  this.checkProperty(this.petition['i140AdditionalInfo'] ,'petiOrApplicAllApplicableBoxes','length')>0 ){
                let list = [];
                _.forEach(this.petition.i140AdditionalInfo['petiOrApplicAllApplicableBoxes'],(item)=>{
                    let findObj = _.find(this.filingFormsList,({'id':item}));
                    if(findObj){
                        list.push(findObj)
                    }
                })
                    _.forEach(list,(it)=>{
                        if(_.has(it, 'name')){
                            if(returnval == ''){
                                returnval = it['name']
                            }else{
                                returnval = returnval+', '+it['name']
                            }
                        }
                    })
                return returnval
                }
            },

            showRouteName(){
                if(this.$route.name == 'questionnaire'){
                    return false
                }
                else{
                    return true
                }
            }
        },
        methods:{ 
            petitionBeiField(item){
                if(item){
                    var labelsType = [
                    {
                        'key':'aa',
                        'name':' To amend a previously filed petition. Previous Petition Receipt Number'
                    },
                    {
                        'key':'bb',
                        'name':'For the Schedule A, Group I or II designation'
			        }
                ]
                    var findval = _.find(labelsType, { 'key': item});
		            return findval?findval.name:"";
                }
            },
            petitionFieldFr(item){
                if(item){
                    var labelsType = [
                    {
                        'key':'a',
                        'name':' An alien of extraordinary ability'
                    },
                    {
                        'key':'b',
                        'name':'An outstanding professor or researcher'
			        },
                    {
                        'key':'c',
                        "name":" A multinational executive or manager A member of the professions holding an advanced degree or an alien of exceptional ability (who is NOT seeking a National Interest Waiver (NIW)) "
			        },
                    {
                        'key':'d',
                        'name':'Any other worker (requiring less than two years of training or experience).'
			        },
                    {
                        'key':'e',
                        'name':"A professional (at a minimum, possessing a bachelor's degree or a foreign degree equivalent to a U.S. bachelor's degree)."
			        },
                    {
                        'key':'f',
                        'name':'A skilled worker (requiring at least two years of specialized training or experience).'
			        },
                    {
                        'key':'g',
                        'name':' Any other worker (requiring less than two years of training or experience).'
			        },
                    {
                        'key':'h',
                        'name':'An alien applying for an NIW (who IS a member of the professions holding an advanced degree or an alien of exceptional ability).'
			        },
                ]
                    var findval = _.find(labelsType, { 'key': item});
		            return findval?findval.name:"";
                }
            },
     
        },
        data: () => ({
            filingFormsList:[
                {'id':'i485',name:'Form I-485'},
                {'id':'i131',name:'Form I-131 '},
                {'id':'i765',name:'Form I-765'},
                {'id':'other',name:'Other'}
            ],
        }),
        mounted() { 
          
        }
    };
    </script>
    