<template>
    
    <div class="main-list-wrap petition_details_wrap">
        <template >
       <div class="tab-inner-content tabs-nobg">
          <div class="tabs-content-panel tab-pad-wrap">
                <div class="card-panels">
        <vs-tabs>
            
            <vs-tab label="Father" v-if="checkProperty(petition,'fatherInfo') && checkProperty(petition,'fatherInfo','firstName') ">
                <parentsDetails :visastatuses="visastatuses" :petition="petition['fatherInfo']"></parentsDetails>
            </vs-tab>
            <vs-tab label="Mother" v-if="checkProperty(petition,'motherInfo')  && checkProperty(petition,'motherInfo','firstName')">
                <parentsDetails :visastatuses="visastatuses" :petition="petition['motherInfo']"></parentsDetails>
            </vs-tab>

           
            
        </vs-tabs>
        
        </div>
        </div>
        </div>
    </template>
  
    
    </div>
    </template>
    
    <script>
    import VuePerfectScrollbar from "vue-perfect-scrollbar";
    import parentsDetails  from "@/views/petition/subtabs/parentsDetails.vue"; 
   
    export default {
        data: () => ({
    
           
        }),
        computed: {
    
        },
        props: {
            petition: {
                type: Object,
                default: null
            },
            visastatuses: {
                type: Array,
                default: null
            }
        },
        components: {
            parentsDetails,
            VuePerfectScrollbar
    
        },
        methods: {

        },
        mounted() {

        }
    };
    </script>
    