<template>
  <div class="pad20">
      <!-- <h3 class="small-header" v-if="checkProperty(petition.beneficiaryInfo.educations,'length')>0" >Educational Information</h3> -->
    <template  v-for="(item,index) in petition.beneficiaryInfo.educations"> 
      <template v-if="checkProperty(item,'name')">
        <div class="vx-row m-0 main-list-panel bb-0" :key="index">
            <div class="vx-col w-full p-0  edu-block" >
              
                <div class="dependent-block_wrap">
                    <div class="dependent-block">
                        <div class="dependent-title">
                            <h3>
                                {{item.name}}
                            </h3>
    
                        </div>
                        <div class="dependent_details">
                              <ul class="toplist">
                                <li v-if="checkProperty(item,'name')">University/College/School Name <span>{{item.name}}</span></li>
                                <li v-if="checkProperty(item,'highestDegree')">Qualification <span>{{item.highestDegree | formatML(petition.highestDegreeList)}}</span></li>
                                <li v-if="item.majorFieldOfStudy">Major Field of Study <span>{{item.majorFieldOfStudy}}</span></li>
                            </ul>
                            <ul>
                                <li v-if="item.graduatedYear"> Year of Graduation <span>{{item.graduatedYear}}</span></li>
                                <li v-if="item.graduatedDate"> Date of Graduation <span>{{item.graduatedDate | formatDate}}</span></li>
                                <li v-if="item.attendedFrom">Course Started On <span>{{item.attendedFrom | formatMonthYear}}</span></li>
                                <li v-if="item.attendedTo">Course Completed On <span>{{item.attendedTo | formatMonthYear}}</span></li>
                                <li v-if="checkProperty(item['address'],'line1')"> Address <span v-html="$options.filters.addressformat(item.address)"></span>
                                </li>
                            </ul>
                            <ul class="toplist" v-if="checkProperty(item['address'],'countryId')==231">
                                <li>Was the University Accredited at the time of your graduation <span>{{item.isAccredited?'Yes':'No'}}</span></li>
                                <li>Is the University a for-profit Organization <span>{{item.isForProfit?'Yes':'No'}}</span></li>
                            </ul>
                            <!-- {{ item['documents'] }} -->
                        
                        </div>
                        <vs-col class="padl0 padr0" v-if="checkProperty(item,'documents') ">
                          <div class="divider"></div>
                            <h3 class="small-header mb-0 cap-info-header">Documents</h3>
                            <ul class="documents_new_list">
                              <li class="doc_list_item" v-if="checkProperty(item,'documents','passport') && checkProperty(item['documents'],'passport','length') > 0 ">
                                <documentsView @download_or_view="download_or_view" :type="'educationPassport'"  :documentsList="item['documents']['passport']" :petitionDetails="petition" />
                              </li>
                              <li class="doc_list_item" v-if="checkProperty(item,'documents','graduationCertificate') && checkProperty(item['documents'],'graduationCertificate','length') > 0 ">
                                  <documentsView @download_or_view="download_or_view" :type="'graduationCertificate'"  :documentsList="item['documents']['graduationCertificate']" :petitionDetails="petition" />
                              </li>
                              <li class="doc_list_item" v-if="checkProperty(item,'documents','transcripts') && checkProperty(item['documents'],'transcripts','length') > 0 ">
                                  <documentsView @download_or_view="download_or_view" :type="'transcripts'"  :documentsList="item['documents']['transcripts']" :petitionDetails="petition" />
                              </li>
                              <li class="doc_list_item" v-if="checkProperty(item,'documents','eduTranscripts') && checkProperty(item['documents'],'eduTranscripts','length') > 0 ">
                                  <documentsView @download_or_view="download_or_view" :type="'eduTranscripts'"  :documentsList="item['documents']['eduTranscripts']" :petitionDetails="petition" />
                              </li>
                            </ul>
  
                        </vs-col>
                    </div>
                </div>
            
            </div>
        </div>
      </template>
    </template>
      
      <template v-if="checkProperty(petition['beneficiaryInfo'],'vacationalOrTrainingInst') && checkProperty(petition['beneficiaryInfo'],'vacationalOrTrainingInst','length')>0  ">
      <h5 class="names_title mt-6" v-if="checkProperty(petition.beneficiaryInfo.vacationalOrTrainingInst,'length')>0" >Vocational or Training</h5>
      <div class="vx-row m-0 main-list-panel">
      <div class="vx-col w-full p-0  edu-block" :key="index" v-for="(item,index) in petition.beneficiaryInfo.vacationalOrTrainingInst">
        <template v-if="checkProperty(item,'name')">
          <div class="dependent-block_wrap">
              <div class="dependent-block">
                  <div class="dependent-title">
                      <h3>
                          {{item.name}}
                      </h3>

                  </div>
                  <div class="dependent_details">
                      <ul class="toplist">
                        <li v-if="checkProperty(item,'name')">University/College/School Name <span>{{item.name}}</span></li>
                          <li v-if="checkProperty(item,'highestDegree')">Qualification <span>{{item.highestDegree | formatML(petition.highestDegreeList)}}</span></li>
                          <li v-if="checkProperty(item,'majorFieldOfStudy')">Major Field of Study <span>{{item.majorFieldOfStudy}}</span></li>
                      </ul>
                      <ul>
                          <li v-if="item.graduatedYear"> Year of Graduation <span>{{item.graduatedYear}}</span></li>
                          <li v-if="item.graduatedDate"> Date of Graduation <span>{{item.graduatedDate | formatDate}}</span></li>
                          <li v-if="item.attendedFrom"> Course Started On <span>{{item.attendedFrom | formatMonthYear}}</span></li>
                          <li v-if="item.attendedTo"> Course Completed On <span>{{item.attendedTo | formatMonthYear}}</span></li>
                          <li v-if="checkProperty(item,'address')"> Address <span v-html="$options.filters.addressformat(item.address)"></span>
                          </li>

                      </ul>
                      <ul class="toplist" v-if="checkProperty(item['address'],'countryId')==231">
                          <li>Was the University Accredited at the time of your graduation <span>{{item.isAccredited?'Yes':'No'}}</span></li>
                          <li>Is the University a for-profit Organization <span>{{item.isForProfit?'Yes':'No'}}</span></li>
                      </ul>
                     
                  </div>
              </div>
          </div>
        </template>
      </div>
      </div>
      </template>
      <vs-popup
    class="document_modal document_modal-v2"
    :class="{ expand: expandModal }"
    :title="checkProperty(selectedFile, 'name')"
    :active.sync="docPrivew"
  >
  <div class="document_actions" @click="expandModal = !expandModal">
      <figure v-if="!expandModal" class="maximize-img"><img src="@/assets/images/maximize.png"  width="18" height="18"/></figure>
      <figure v-else class="minimize-img"><img src="@/assets/images/minimize.png"  width="20" height="20"/></figure>
    </div>
    <h2> <img 
        :class="{
          pdf_view_download: docType == 'pdf',
          office_view_download: docType == 'office',
          image_view_download: docType == 'image',
        }"
        class="download-button"
        @click="downloads3file(selectedFile)"
        src="@/assets/images/download.svg"
      /></h2>
     
    <div class="pdf_loader" >
   <figure v-if="formSubmited" class="loader loader2"><img src="@/assets/images/main/loader.gif" /></figure>
     
      <!-- <span :class="{'pdf_view_close':docType == 'pdf', 'office_view_close':docType == 'office'  , 'image_view_close 33':docType =='image'}" class="close close2" @click="docPrivew= false"></span> -->
      <template v-if="docType == 'office'">
                     <div   style="height:90vh">

           <div  id="placeholder" style="height:100%"></div>
       </div>
      </template>
      <template v-else-if="docType == 'image'">
        <img :src="docValue" />
      </template>
      <template v-else-if="docType == 'pdf'">
        <div class="pdf" style="height:90vh">
          
         <iframe v-if="docValue!=''" border="0" style="border:0px;" :src="docValue" height="100%" width="100%">

         </iframe>
        </div>
      </template>
    </div>
  </vs-popup>
  </div>
  </template>
  
  <script>
   import documentsView from "@/views/common/documentsView.vue";
  export default {
      props: {
          petition: {
              type: Object,
              default: null
          },
          visastatuses: {
              type: Array,
              default: null
          }
      },
      mounted() {


      },
      data: () => ({
        expandModal: false,
          selectedFile:'',
       docValue : "",
       docPrivew :false,
       docType : false,
       
         

      }),
      methods: {
          downloadfile(value) {
          this.$emit('download_or_view' ,value);
       },
       download_or_view(docItem) {
    
    
    let value = _.cloneDeep(docItem);
    this.expandModal= false;
   if( this.checkProperty(this.getPetitionDetails ,'caseNo') && this.checkProperty(value ,'name')){
     let docName = _.cloneDeep(value['name']);
     value['name'] = this.checkProperty(this.getPetitionDetails ,'caseNo')+"_"+docName;
   }
    
   
   var _self = this;
   this.formSubmited =false;
   if (_.has(value, "path")) {
     value["url"] = value["path"];
     value["document"] = value["path"];
   }

   if (_.has(value, "url")) {
     value["path"] = value["url"];
     value["document"] = value["url"];
   }

   if (_.has(value, "document")) {
     value["path"] = value["document"];
     value["url"] = value["document"];
   }
   value = Object.assign(value ,{ 'petitionId':this.petition['_id']})
   value = Object.assign(value ,{ 'subTypeDetails':this.petition['subTypeDetails']})


   this.selectedFile = value;
   this.docValue = "";
   this.docPrivew = false;
   this.docType = false;
   this.docType = this.findmsDoctype(value);
   
   if ( (this.docType == "office" || this.docType == "image" || this.docType == "pdf")  ) {
   //if ( (this.docType == "office" || this.docType == "image" || this.docType == "pdf") && value.download == false ) {
     value.url = value.url.replace(this.$globalgonfig._S3URL, "");
     value.url = value.url.replace(this.$globalgonfig._S3URLAWS, "");
     let postdata = {
       keyName: value.url,
       "petitionId":value['petitionId'],
       
       // entityType:value['petitionId']
      // "fileName":value.name?value.name:''
     };
     if(this.checkProperty(value,'subTypeDetails','id') == 15){
       postdata['entityType'] = 'perm'
     }else{
       postdata['entityType'] = 'case'
     }
     
    
     this.$store.dispatch("getSignedUrl", postdata).then((response) => {
       this.docValue = response.data.result.data;

       if (this.docType == "office") {
         document.getElementById("placeholder").innerHTML= "  <div  id='placeholder2' style='height:100%'></div>";
           let _editing= true;
         
           if([50,51].indexOf(this.getUserRoleId)>-1){
                 _editing= false;
           }

           if(value.viewmode){
             _editing= false;
           }
           var _ob  = {}
           if(value.editedDocument){
                  _ob ={
             
             petitionId:this.petition._id,
              name:value.name,
             _id:value._id,
               "extn": "docx",
             "formLetterType": "Letter",
               parentId:value.parentId
           }

           }else{

                  _ob ={
                    
                 name:value.name,
                      petitionId:this.petition._id,
             _id:value._id,
            "extn": "docx",
             "formLetterType": "Letter",
               parentId:value._id

           }

           }
       
           
           window.docEditor = new DocsAPI.DocEditor("placeholder2",
         {
             
             "document": {
                "c": "forcesave",
                 "fileType": "docx",
                 "key": value._id,
                  "userdata": JSON.stringify(_ob),
                 "title": value.name,
                 "url": response.data.result.data,
                  permissions: {
                 edit: _editing,
                 download: true,
                 reader:false,
                 review: false,
                 comment: false
                }
             },
           
             "documentType": "word",
             "height": "100%",
             "width": "100%",
            
            "editorConfig": {
                "userdata": JSON.stringify(_ob),
            "callbackUrl": "https://immibox.com/api/perm/post-edited-document?payload="+JSON.stringify(_ob)+"&token="+_self.$store.state.token+"&name="+value.name.replace('.docx',''),
     "customization": {
           "logo": {
             "image": "https://immibox.com/app/favicon.png",
             "imageDark": "https://immibox.com/app/favicon.png",
             "url": "https://immibox.com"
         },
       "anonymous": {
             "request": false,
             "label": "Guest"
         },
         "chat": false,
         "comments": false,
         "compactHeader": false,
         "compactToolbar": true,
         "compatibleFeatures": false,
         "feedback": {
             "visible": false
         },
         "forcesave": true,
         "help": false,
         "hideNotes": true,
         "hideRightMenu": true,
         "hideRulers": true,
           layout: { 
               toolbar: {
                  "collaboration": false,
               },
           },
         "macros": false,
         "macrosMode": "warn",
         "mentionShare": false,
         "plugins": false,
         "spellcheck": false,
         "toolbarHideFileName": true,
         "toolbarNoTabs": true,
         "uiTheme": "theme-light",
         "unit": "cm",
         "zoom": 100
     },
},          events: {
      onReady: function () {
    
         },
         onDocumentStateChange: function (event) {
           var url = event.data;
           

           if(!event.data){

             if(value.editedDocument){

              }

           }
         }

}
         });
         //this.docValue = encodeURIComponent(response.data.result.data);
       }

         if (this.docType == "pdf") {
           var _vid= value._id;
           if(value.parentId){
              _vid= value.parentId;
           }
           var  viewmode = 1; // Enable edit
                viewmode= 0; //Disabled Edit
           if(value.viewmode){
              viewmode= 0;
           }
         this.docValue = "https://immibox.com/viewer/pdfjs-dist/web/viewer.html?view="+viewmode+"+&file="+encodeURIComponent(response.data.result.data);
       }
       this.docPrivew = true;
     });
   } else {
    
    

     this.downloads3file(value);
   }
  
 },
      },
      components:{
          documentsView
      }
  };
  </script>
  