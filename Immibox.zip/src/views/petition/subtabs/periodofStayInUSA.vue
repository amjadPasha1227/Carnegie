<template>
    <div class="tabs-content-table mt-2 priorPeriodtable " v-if=" dataList && dataList.length > 0 && dataList[0].visaStatus!=null">
        <div class="pad20">
            <template>
                       <vs-table :data="dataList"> 
   
                           <template>
                               <template slot="thead">
                                   <vs-th>Case Status</vs-th>
                                   <vs-th>Date Entered</vs-th>
                                   <vs-th>Date Departed</vs-th>
                                   <vs-th v-if="checkNoofDays">No. of Days</vs-th>
                               </template>
                               <template>
                                   <vs-tr :key="sin" v-for="(stay ,sin) in dataList">
                                       <vs-td> {{ stay.visaStatus  | formatML(visastatusess)}}</vs-td>
                                       <vs-td>
                                        <template v-if="stay.enteredDate">{{stay.enteredDate | formatDate}}</template>
                                        <template v-else>N/A</template>
                                            
                                        </vs-td>
                                       <vs-td>
                                            <template v-if="stay.departedDate">{{stay.departedDate | formatDate}}</template>
                                            <template v-else>N/A</template>
                                        
                                        </vs-td>
                                        <!-- {{ visastatuses | visastatus(stay.visaStatus) }}-->
                                       
                                       <vs-td v-if="checkNoofDays">{{stay.noOfDays}}</vs-td>
                                   </vs-tr>
                               </template>
                           </template>
                       </vs-table>
                      
                        <template v-if="callFrom == 'BENEFICIARY'">
                                <template v-if="petition.beneficiaryInfo.noOfDaysStayInUS > 1095 && petition.beneficiaryInfo.confirmDaysStayInUS">

                                    Total No. of days in the US in H/L status - {{noOfDaysStayInUS}}
                                </template>
                                <template v-if="noOfDaysStayInUS > 2185">

                                    <label class="form_label pb-5 pt-5">Note: Please note that you are allowed a maximum period of 6 years on your H-1B. To receive H-1B approval past 6 years you need to either have an approved I-140 or PERM application pending for more than 364 days. Please confirm if you have the following:</label>

                                    Approved I-140 (from any employer that has not been revoked within 180 days of its approval) {{hasApprovedI140?'Yes':'No'}}
                                    PERM application pending for more than 365 days {{hasPermPendingForMorethan365Days?'Yes':'No'}}

                                </template>
                            </template>
                        </template>
                        <template v-if="callFrom == 'SPOUSE'">
                            <template v-if="petition.dependentsInfo.spouse.noOfDaysStayInUS > 1095 && petition.dependentsInfo.spouse.confirmDaysStayInUS">
                                Total No. of days in the US in H/L status - {{noOfDaysStayInUS}}
                            </template>
                            <template v-if="noOfDaysStayInUS > 2185">
                                <label class="form_label pb-5 pt-5">Note: Please note that you are allowed a maximum period of 6 years on your H-1B. To receive H-1B approval past 6 years you need to either have an approved I-140 or PERM application pending for more than 364 days. Please confirm if you have the following:</label>
                                Approved I-140 (from any employer that has not been revoked within 180 days of its approval) {{hasApprovedI140?'Yes':'No'}}
                                PERM application pending for more than 365 days {{hasPermPendingForMorethan365Days?'Yes':'No'}}
                            </template>
                        </template>
                        </div>
        
    
    </div>
    </template>
    
        
    <script>
    export default {
        props: {
            petition: {
                type: Object,
                default: null
            },
            visastatuses: {
                type: Array,
                default: null
            },
            dataList:{
                type: Array,
                default: []
            },
            callFrom:{
                type: String,
                default: ''
            }
        },
        mounted(){
            this.getVisastatues()
        },
        methods:{
            getVisastatues(){
                this.$store.dispatch("getmasterdata", "visa_status").then((response) => {
                    this.visastatusess = response;
                });
            }
        },
        data: ()=>({
          visastatusess:[],
        }),
        computed: {
            checkNoofDays(){
                let returnVal = true
                if( this.callFrom == 'BENEFICIARY'  && this.checkProperty(this.petition['beneficiaryInfo'] ,'priorPeriodOfStayInUS') && this.checkProperty(this.petition['beneficiaryInfo'] ,'priorPeriodOfStayInUS', 'length')>0 ){
                   let noOfDaysList =  _.filter(this.petition.beneficiaryInfo.priorPeriodOfStayInUS, (item)=>{
                        if(item && item['noOfDays']){
                           return item
                        }
                    })
                    if(noOfDaysList && this.checkProperty(noOfDaysList,'length')>0){
                        returnVal = true
                    }else{
                        returnVal = false
                    }
                }
                if(this.callFrom == 'SPOUSE' && this.checkProperty(this.petition['dependentsInfo']['spouse'],'priorPeriodOfStayInUS') && this.checkProperty(this.petition['dependentsInfo']['spouse'] ,'priorPeriodOfStayInUS', 'length')>0 ){
                    let noOfDaysList =  _.filter(this.petition.dependentsInfo.spouse.priorPeriodOfStayInUS, (item)=>{
                        if(item && item['noOfDays']){
                            return item
                        }
                    })
                    if(noOfDaysList && this.checkProperty(noOfDaysList,'length')>0){
                        returnVal = true
                    }else{
                        returnVal = false
                    }
                }
                return returnVal
            },
        }
        
        
    };
    </script>
    