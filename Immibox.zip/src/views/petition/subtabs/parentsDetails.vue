<template>
    <div class="pad20">
        <div class="vx-row m-0 main-list-panel">
            <div class="vx-col md:w-1/3 w-full p-0"
                v-if="checkProperty(petition,'name') || checkProperty(petition,'firstName') ||
                    checkProperty(petition,'middleName') || checkProperty(petition,'lastName')">
                <div class="main-list">
                    <p>
                        Full Name
                        <span>{{ formatFullname(petition) }}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition, 'locationOfBirth')">
                <div class="main-list">
                    <p>
                        Location of Birth
                        <span>{{ checkProperty(petition, 'locationOfBirth') }}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition, 'provinceOfBirthDetails') && checkProperty(petition, 'provinceOfBirthDetails','name')">
                <div class="main-list">
                    <p>
                        Province of Birth
                        <span>{{ checkProperty(petition, 'provinceOfBirthDetails','name') }}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition, 'countryOfBirthDetails') && checkProperty(petition, 'countryOfBirthDetails','name')">
                <div class="main-list">
                    <p>
                        Country of Birth
                        <span>{{ checkProperty(petition, 'countryOfBirthDetails','name') }}</span>
                    </p>
                </div> 
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'dateOfBirth')">
                <div class="main-list">
                    <p>
                        Date of Birth
                        <span>{{ checkProperty(petition, 'dateOfBirth') | formatDate }}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'isUSCitizen')">
                <div class="main-list">
                    <p>
                        Is US Citizen
                        <span>{{ checkProperty(petition, 'isUSCitizen') | booleanFormat }}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'dateFromUSCitizen')">
                <div class="main-list">
                    <p>
                        Date from US Citizen
                        <span>{{ checkProperty(petition, 'dateFromUSCitizen') | formatDate }}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition, 'deceasedCityDetails') && checkProperty(petition, 'deceasedCityDetails','name')">
                <div class="main-list">
                    <p>
                        Deceased City
                        <span>{{ checkProperty(petition, 'deceasedCityDetails','name') }}</span>
                    </p>
                </div> 
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'deceasedDate')">
                <div class="main-list">
                    <p>
                        Deceased Date
                        <span>{{ checkProperty(petition, 'deceasedDate') | formatDate }}</span>
                    </p>
                </div>
            </div>
            
        </div>
        <template v-if="checkProperty(petition,'hasOtherNames') && checkProperty(petition,'otherNames' ,'length') >0">
                <div class="vx-row m-0 main-list-panel">
                    <h5 class="names_title">Used other names previously</h5>
                    <template v-for="(item , ind)  in petition['otherNames']">

                        <div :key="ind" class="vx-col md:w-1/3 w-full p-0">
                            <div class="main-list">
                                <p>First Name<span  v-if="item.firstName">{{item.firstName}}</span>
                                    <span v-else>N/A</span> </p>
                            </div>
                           
                        </div>
                        <div :key="ind" class="vx-col md:w-1/3 w-full p-0">
                            <div class="main-list">
                                <p> Middle Name <span  v-if="item.middleName">{{item.middleName}}</span>
                                    <span v-else>N/A</span> </p>
                            </div>
                        </div>

                        <div :key="ind" class="vx-col md:w-1/3 w-full p-0">
                            <div class="main-list">
                                <p> Last Name <span v-if="item.lastName">{{item.lastName}}</span>
                                    <span v-else>N/A</span></p>
                            </div>
                        </div>

                    </template>
 
                </div>
            </template>
        <template v-if="checkProperty(petition,'nameAtBirth') && (checkProperty(petition,'nameAtBirth' ,'firstName') || checkProperty(petition,'nameAtBirth' ,'lastName') || checkProperty(petition,'nameAtBirth' ,'middleName') )">
                <div class="vx-row m-0 main-list-panel">
                    <h5 class="names_title">Names at Birth</h5>
                        <div  class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'nameAtBirth' ,'firstName')">
                            <div class="main-list">
                                <p>First Name<span>{{checkProperty(petition,'nameAtBirth' ,'firstName')}}</span> </p>
                            </div>
                        </div>
                        <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'nameAtBirth' ,'middleName')">
                            <div class="main-list">
                                <p> Middle Name <span>{{checkProperty(petition,'nameAtBirth' ,'middleName')}}</span> </p>
                            </div>
                        </div>
                        <div  class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'nameAtBirth' ,'lastName')">
                            <div class="main-list">
                                <p> Last Name <span>{{checkProperty(petition,'nameAtBirth' ,'lastName')}}</span> </p>
                            </div>
                        </div>
                </div>
            </template>
        <div class="vx-row m-0 main-list-panel" v-if=" checkProperty(petition  ,'currentAddress' )  && 
            (checkProperty(petition,'currentAddress' ,'line1' )
            || checkProperty(petition['currentAddress'] ,'locationDetails' ,'name' )
            || checkProperty(petition['currentAddress'] ,'stateDetails' ,'name' )
            || checkProperty(petition['currentAddress'] ,'countryDetails' ,'name' ))">
            <div class="vx-col w-full p-0" v-if=" checkProperty(petition ,'currentAddress' )  && 
                (checkProperty(petition ,'currentAddress' ,'line1' )
                || checkProperty(petition['currentAddress'] ,'locationDetails' ,'name' )
                || checkProperty(petition['currentAddress'] ,'stateDetails' ,'name' )
                || checkProperty(petition['currentAddress'] ,'countryDetails' ,'name' ))">
                <div class="main-list">
                    <p>
                    Current Address
                        <span v-html="$options.filters.addressformat(petition.currentAddress)"></span>

                    </p>
                </div>
            </div>
        </div>
</div>
</template>
    
<script>
import educationInfo from "@/views/petition/subtabs/educationsVersion2.vue";
import documentsView from "@/views/common/documentsView.vue";
import _ from "lodash";
export default {
    components: {
        educationInfo,
        documentsView,
    },
    data: () => ({
        visastatuses: [],
        docPrivew: false,
    }),
    props: {
        petition: {
            type: Object,
            default: null
        },

    },
    computed: {

    },
    methods: {
        formatFullname(item) {
            let returnVal = ''
            if (this.checkProperty(item, 'name')) {
                return returnVal = this.checkProperty(item, 'name')
            }
            else {
                if (this.checkProperty(item, 'firstName')) {
                    returnVal = this.checkProperty(item, 'firstName')
                }
                if (this.checkProperty(item, 'middleName')) {
                    returnVal = returnVal + ' ' + this.checkProperty(item, 'middleName')
                }
                if (this.checkProperty(item, 'lastName')) {
                    returnVal = returnVal + ' ' + this.checkProperty(item, 'lastName')
                }
                return returnVal
            }
        },downloadfile(value) {
            this.$emit('download_or_view' ,value);
         },
        download_or_view(value) {
            if (_.has(value, "path")) {
                value['url'] = value['path'];
                value['document'] = value['path'];
            }

            if (_.has(value, "url")) {
                value['path'] = value['url'];
                value['document'] = value['url'];
            }

            if (_.has(value, "document")) {
                value['path'] = value['document'];
                value['url'] = value['document'];
            }

            this.selectedFile = value;
            this.docValue = '';
            this.docPrivew = false;
            this.docType = false;
            this.docType = this.findmsDoctype(value);

            if (this.docType == "office" || this.docType == "image") {

                value.url = value.url.replace(this.$globalgonfig._S3URL, "");
                value.url = value.url.replace(this.$globalgonfig._S3URLAWS, "");
                let postdata = {
                    keyName: value.url
                };
                this.$store.dispatch("getSignedUrl", postdata).then((response) => {
                    this.docValue = response.data.result.data;

                    if (this.docType == "office") {
                        this.docValue = encodeURIComponent(response.data.result.data);
                    }
                    this.docPrivew = true;
                });

            } else {
                this.downloads3file(value);
            }

        },

    },
    mounted() {

    }
};
</script>
    