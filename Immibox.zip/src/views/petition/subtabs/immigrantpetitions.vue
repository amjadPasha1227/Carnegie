<template>
    <div>
        <div class="pad20 pb-0">
        <div class="vx-row m-0 main-list-panel"  style="margin-bottom: 0 !important;">
            <!-- {{ questionnaireDetails }}  v-if="canRenderField('hasAnyDependetsinUStoFileH4', questionnaireDetails ,false,'beneficiaryInfo')"-->
            <div class="vx-col w-full p-0" v-if="canRenderField('anyOtherAlienFiled', questionnaireDetails ,false,'beneficiaryInfo.immPetitionInfo')">
                <div class="main-list pb-0">
                    <p>
                        Has any other Alien Employment Certification, a.k.a Labor Certification been filed on your behalf?
                        <span>{{petition.beneficiaryInfo.immPetitionInfo.anyOtherAlienFiled?"Yes":"No"}}</span>
                    </p>
                </div>
            </div>
    
            <div class="vx-col md:w-1/3 w-full p-0" v-if="canRenderField('filedDate', questionnaireDetails ,false,'beneficiaryInfo.immPetitionInfo') && 
            checkProperty(petition.beneficiaryInfo,'immPetitionInfo', 'filedDate')">
                <div class="main-list pb-0">
                    <p  >
                         Filed Date
                        <span>{{petition.beneficiaryInfo.immPetitionInfo.filedDate | formatDate}}</span>
                    </p>
                </div>
            </div>
    
            
            <div class="vx-col md:w-1/3 w-full p-0" v-if="canRenderField('employerName', questionnaireDetails ,false,'beneficiaryInfo.immPetitionInfo') && 
            checkProperty(petition.beneficiaryInfo,'immPetitionInfo', 'employerName')">
                <div class="main-list pb-0">
                    <p>
                        Name of the Employer
                        <span>{{petition.beneficiaryInfo.immPetitionInfo.employerName}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="canRenderField('filedStateId', questionnaireDetails ,false,'beneficiaryInfo.immPetitionInfo') && 
            checkProperty(petition.beneficiaryInfo,'immPetitionInfo', 'filedStateDetails') && checkProperty(petition.beneficiaryInfo['immPetitionInfo'], 'filedStateDetails', 'name')">
                <div class="main-list pb-0">
                    <p>
                        State where it was filed
                        <span>{{petition.beneficiaryInfo.immPetitionInfo.filedStateDetails.name}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="canRenderField('applCurStatus', questionnaireDetails ,false,'beneficiaryInfo.immPetitionInfo') && 
            checkProperty(petition.beneficiaryInfo,'immPetitionInfo', 'applCurStatus')">
                <div class="main-list pb-0">
                    <p>
                        Current Status of the Application
                        <span>{{petition.beneficiaryInfo.immPetitionInfo.applCurStatus}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="canRenderField('rirOrRegularProcessing', questionnaireDetails ,false,'beneficiaryInfo.immPetitionInfo')" >
                <div class="main-list pb-0">
                    <p>
                        RIR or Regular Processing
                        <span>{{petition.beneficiaryInfo.immPetitionInfo.rirOrRegularProcessing?"Yes":"No"}}</span>
                    </p>
                </div>
            </div>
            
            <div class="vx-col w-full p-0" v-if="canRenderField('seekingFiledDateforETA750', questionnaireDetails ,false,'beneficiaryInfo.immPetitionInfo')">
                <div class="main-list pb-0">
                    <p>
                        Are you seeking to utilize the filing date from a previously submitted Application for Alien Employment Certification (ETA 750)?   
                        <span>{{petition.beneficiaryInfo.immPetitionInfo.seekingFiledDateforETA750?"Yes":"No"}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col w-full p-0" v-if="canRenderField('anyI140Filed', questionnaireDetails ,false,'beneficiaryInfo.immPetitionInfo')">
                <div class="main-list pb-0">
                    <p>
                        Has any I-140 Petition been filed on your behalf?
                        <span>{{petition.beneficiaryInfo.immPetitionInfo.anyI140Filed?"Yes":"No"}}</span>
                    </p>
                </div>
            </div>
            

            <template v-if="checkProperty(petition.beneficiaryInfo,'immPetitionInfo', 'i140Info')">
                <div class="vx-col md:w-1/3 w-full p-0" v-if="canRenderField('fieldDate', questionnaireDetails ,false,'beneficiaryInfo.immPetitionInfo.i140Info') && 
                checkProperty(petition.beneficiaryInfo['immPetitionInfo'], 'i140Info', 'fieldDate')">
                    <div class="main-list pb-0">
                        <p>
                            Date Filed
                            <span>{{petition.beneficiaryInfo.immPetitionInfo.i140Info.fieldDate | formatDate}}</span>
                        </p>
                    </div>
                </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="canRenderField('employerName', questionnaireDetails ,false,'beneficiaryInfo.immPetitionInfo.i140Info') &&
             checkProperty(petition.beneficiaryInfo['immPetitionInfo'], 'i140Info', 'employerName')">
                <div class="main-list pb-0">
                    <p>
                        Name of the Employer
                        <span>{{petition.beneficiaryInfo.immPetitionInfo.i140Info.employerName}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0"  v-if="canRenderField('priorityDate', questionnaireDetails ,false,'beneficiaryInfo.immPetitionInfo.i140Info') && 
            checkProperty(petition.beneficiaryInfo['immPetitionInfo'], 'i140Info', 'priorityDate')">
                <div class="main-list pb-0">
                    <p>
                        Priority Date
                        <span>{{petition.beneficiaryInfo.immPetitionInfo.i140Info.priorityDate | formatDate}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0"  v-if="canRenderField('eb2orEb3', questionnaireDetails ,false,'beneficiaryInfo.immPetitionInfo.i140Info') && 
            checkProperty(petition.beneficiaryInfo['immPetitionInfo'], 'i140Info', 'eb2orEb3')">
                <div class="main-list pb-0">
                    <p>
                        EB2/EB3:
                        <span>{{petition.beneficiaryInfo.immPetitionInfo.i140Info.eb2orEb3}}</span>
                    </p>
                </div>
            </div>
          
            <div class="vx-col md:w-1/3 w-full p-0"  v-if="canRenderField('currentStatus', questionnaireDetails ,false,'beneficiaryInfo.immPetitionInfo.i140Info') && 
            checkProperty(petition.beneficiaryInfo['immPetitionInfo'], 'i140Info', 'currentStatus')">
                <div class="main-list pb-0">
                    <p>
                        Current Status of the I-140
                        <span>{{petition.beneficiaryInfo.immPetitionInfo.i140Info.currentStatus}}</span>
                    </p>
                </div>
            </div>
        </template>

    
        </div>
    
        
    </div>
    <div class="tabs-content-table mt-2 priorPeriodtable " v-if="(checkProperty(petition.beneficiaryInfo, 'h1bImmPetitionsInfo') && petition.beneficiaryInfo.h1bImmPetitionsInfo.length>0 &&  petition.beneficiaryInfo.h1bImmPetitionsInfo[0].typetypeId!='')">
      
        <div class="pad20 pt-0">
            <vs-table :data="petition.beneficiaryInfo.h1bImmPetitionsInfo">
                <template >
                    <template slot="thead">
                        <vs-th>Petition Type</vs-th>
                        <vs-th>Receipt Number</vs-th>
                        <vs-th>Petitioner/Employer Name</vs-th>
                        <vs-th>Valid From</vs-th>
                        <vs-th>Valid To</vs-th>
                    </template>
                    <template>
                        <vs-tr :key="sin" v-for="(item ,sin) in petition.beneficiaryInfo.h1bImmPetitionsInfo">
                            <vs-td v-if="item.typeDetails">{{checkProperty(item,'typeDetails','name')}}</vs-td>
                            <vs-td>{{item.receiptNo}}</vs-td>
                            <vs-td> {{item.petitionerName}} <!-- {{ visastatuses | visastatus(stay.visaStatus) }}-->
                            </vs-td>
                            <vs-td v-if="item.validFrom">
                                <template v-if="item.validFrom"> {{item.validFrom | formatDate }}</template>
                                <template v-else>N/A</template>
                            </vs-td>
                            <vs-td >
                            <template v-if="item.validTo"> {{item.validTo | formatDate }}</template>
                            <template v-else>N/A</template>
                            </vs-td>
                        </vs-tr>
                    </template>
                </template>
            </vs-table>
        </div>
    </div>
    
    </div>
    </template>
    
    <script>
    export default {
        props: {
            petition: {
                type: Object,
                default: null
            },
            visastatuses: {
                type: Array,
                default: null
            },
            questionnaireDetails:{
                type: Array,
                default: null
            }
        },
        mounted(){
        this.getVisastatues()
    },
    methods:{
        getVisastatues(){
            this.$store.dispatch("getmasterdata", "visa_status").then((response) => {
                this.visastatusess = response;
            });
        }
    },
    data: ()=>({
      visastatusess:[],
    }),
    };
    </script>
    