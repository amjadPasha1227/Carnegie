<template>
     
<div class="pad20">

    <template v-if="checkProperty(petition,'typeDetails','id')==3 && datatype == 'BENEFICIARY_EMPLOYEMENT'">
        <div class="vx-row m-0 main-list-panel" v-if="false && checkProperty(petition,'subTypeDetails','id')==16 && !checkProperty(petition,'permId') && checkProperty(petition,'jobDetails')" >
            <div class="vx-col w-full p-0  edu-block">
                <div class="dependent-block_wrap">
                    <div class="dependent-block">
                        <div class="dependent-title">
                            <h3>
                                Job Details
                            </h3>
                        </div>
                        <div class="dependent_details"> 
                            <ul>
                                <li v-if="checkProperty(petition,'jobDetails','jobTitle')"> Job Title <span>{{checkProperty(petition,'jobDetails','jobTitle')}}</span></li>
                                <li v-if="checkProperty(petition,'jobDetails','fullTimePosition')">Full Time Position <span>{{checkProperty(petition,'jobDetails','fullTimePosition') | booleanFormat}}</span></li>
                                <li v-if="checkProperty(petition,'jobDetails','hoursPerWeek')"> Hours Work per Week <span>{{checkProperty(petition,'jobDetails','hoursPerWeek')}}</span></li>
                                <li v-if="checkProperty(petition,'jobDetails','wageRate')">Wage Rate <span>{{checkProperty(petition,'jobDetails','wageRate')}}</span></li>
                                <li v-if="checkProperty(petition,'jobDetails','payFrequency')">Pay Frequency <span>{{checkProperty(petition,'jobDetails','payFrequency')}}</span></li>
                                <li v-if="checkProperty(petition,'jobDetails','permanentPosition')"> Permanent Position<span>{{checkProperty(petition,'jobDetails','permanentPosition')| booleanFormat}} </span></li>
                                <li v-if="checkProperty(petition,'jobDetails','newPosition')"> New Position<span>{{checkProperty(petition,'jobDetails','newPosition')| booleanFormat}} </span></li>
                            </ul>
                            <ul v-for="(item,inder) in petition['jobDetails']['workAddresses']" :key="inder">
                                <li v-if="item">Work Address <span v-html="$options.filters.addressformat(item)"></span>
                                </li>
                            </ul>
                                                   
                        </div>
                        <div class="editor_view_wrap" v-if="checkProperty(petition,'jobDetails','description')">
                            <h3 class="sub-title">Job Description</h3>
                            <div class="editor_view" v-html="petition['jobDetails']['description']"></div>
                        </div>
                    </div>
                </div>
            </div>        
        </div>
    <div class="vx-row m-0 main-list-panel" >
            <div class="vx-col w-full p-0  edu-block" :key="index" v-for="(item,index) in petition.beneficiaryInfo.prevEmploymentInfo">
    
                <div class="dependent-block_wrap">
                    <div class="dependent-block">
                        <div class="dependent-title">
                            <h3>
                                {{item.employerName}}
                            </h3>
    
                        </div>
                        <div class="dependent_details">
                            <ul>
                                <li v-if="item.businessType"> Business Type <span>{{item.businessType}}</span></li>
                                <li v-if="item.jobTitle"> Job Title <span>{{item.jobTitle}}</span></li>
                                <li v-if="item.salary">Salary<span>{{item.salary | formatprice}}</span></li>
                                <li v-if="item.payFrequency">Pay Frequency <span>{{item.payFrequency}}</span></li>
                               </ul>
                               
                                <ul>     
                            <li v-if="item.startDate"> Start Date <span>{{item.startDate | formatDate}}</span></li>
                                <li v-if="item.endDate && (item.currentEmployer ==false || item.currentEmployer =='false' || item.currentEmployer =='No')"> End Date <span>{{item.endDate | formatDate}}</span></li>
                                <li v-if="item.hoursWorkedPerWeek"> Hours Worked per Week <span>{{item.hoursWorkedPerWeek}}</span></li>
                                <li v-if="item.currentEmployer ==true || item.currentEmployer =='true' || item.currentEmployer =='Yes'"> Current Employer<span>Yes </span></li>
                                <li v-if="item.workPhoneNumber" class="work_ph_number">  Work Phone Number
                                    <span>
                                            <template v-if="checkProperty(item ,'workPhoneCountryCode'  ,'countryCallingCode')">{{checkProperty(item ,'workPhoneCountryCode'  ,'countryCallingCode')|countryFormatter}}</template>
                                            {{item.workPhoneNumber | formatPhone}} 
                                    </span>
                                </li>
                                <li v-if="item.fax">  Fax Number
                                    <span>
                                            <template v-if="checkProperty(item ,'faxCountryCode'  ,'countryCallingCode')">{{checkProperty(item ,'faxCountryCode'  ,'countryCallingCode')|countryFormatter}}</template>
                                            {{item.fax | formatPhone}} 
                                    </span>
                                </li>
                                <li v-if="item.address"> Address <span v-html="$options.filters.addressformat(item.address)"></span>
                                </li>
                                <li  v-if="item.jobDuties" class="w-full"> Job Description 
                                    <div class="editor_view pb-2" v-html="item.jobDuties"></div>
                                </li>
                            </ul>
                            <div class="devider mb-6" v-if="checkProperty(item ,'supervisor'  ,'name')" ></div>
                           
                            <div class="dependent-title" v-if="checkProperty(item ,'supervisor'  ,'name')" >
                                <h3 v-if="checkProperty(item ,'supervisor'  ,'name')" class="">Supervisor Details</h3>
                            </div>
                            <ul>
                                
                                
                                <li v-if="checkProperty(item ,'supervisor'  ,'name')"> Name<span>{{checkProperty(item ,'supervisor'  ,'name')}}</span></li>
                                <!-- <li v-if="checkProperty(item ,'supervisor'  ,'phoneNumber')"> Phone Number<span>{{checkProperty(item ,'supervisor'  ,'phoneNumber')}}</span></li> -->
                                <li v-if="checkProperty(item ,'supervisor'  ,'phoneNumber')">Phone Number
                                    <span>
                                    <template v-if="checkProperty(item['supervisor'],'phoneCountryCode' ,'countryCallingCode')">{{checkProperty(item['supervisor'],'phoneCountryCode' ,'countryCallingCode')|countryFormatter}}</template>
                                    {{checkProperty(item ,'supervisor'  ,'phoneNumber') | formatPhone}}
                                </span>
                                </li>
                                <!-- <li v-if="item.jobDuties" class="w-full"> Job Description 
                                    <div class="editor_view pb-2" v-html="item.jobDuties"></div>
                                </li> -->
                            </ul>                        
                        </div>
                        <!-- <div class="editor_view_wrap" v-if="item.jobDuties">
                            <h3 class="sub-title">Job Description</h3>
                            <div class="editor_view pb-2" v-html="item.jobDuties"></div>
                            <h3 class="sub-title" v-if="item.jobDescription">Job Description</h3>
                            <div class="editor_view" v-html="item.jobDescription"></div>
                        </div> -->
                    </div>
                </div>
    
            </div>
    </div>  
    
    </template>
    <template v-else>
        <div class="vx-row m-0 main-list-panel"  >
            <div class="dependent-block_wrap" v-if="canRenderField('anyOtherPersonEmployedInUS', questionnaireDetails ,false,tplSection)">
            <div class="dependent-block dependent-block-transparent">
                <div class="vx-col md:w-1/3 w-full p-0">
                    <div class="dependent_details">
                        <ul class="toplist">
                            <li>
                                <template v-if="datatype == 'CHILD_EMPLOYEMENT'">Have you been employed in the United States since last admitted or granted an extension or change of status?</template>
                                <template v-else> Have you ever been employed?</template>
                               
                                <span>{{anyOtherPersonEmployedInUS | booleanFormat}}</span></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <template v-if="employmentList && checkProperty(employmentList,'length')>0 && checkProperty(employmentList[0],'employerName') ">
            <div class="vx-col w-full p-0  edu-block" :key="index" v-for="(item,index) in employmentList">
                <div class="dependent-block_wrap">
                    <div class="dependent-block pb-0">
                        <div class="dependent-title">
                            <h3>
                                {{item.employerName}}
                            </h3>

                        </div>
                        <div class="dependent_details">
                        
                        
                            <ul>
                                <li v-if="item.businessType"> Business Type <span>{{item.businessType}}</span></li>
                                <li v-if="item.jobTitle"> Job Title <span>{{item.jobTitle}}</span></li>
                                <li v-if="item.salary">
                                    Salary 
                                    <span>
                                    <template v-if="checkProperty(item,'address','countryDetails') && checkProperty(item['address'],'countryDetails' ,'currencyCode')">
                                    {{item.salary | formatprice(checkProperty(item['address'],'countryDetails' ,'currencyCode'))}}
                                </template>
                                    <template v-else>
                                        {{item.salary | formatprice}}
                                    </template>
                                    
                                </span>
                            </li>
                            <li v-if="item.payFrequency"> Pay Frequency <span>{{item.payFrequency }}</span></li>
                            </ul>
                        <ul >     <li v-if="item.startDate"> Start Date <span>{{item.startDate | formatDate}}</span></li>
                                <li v-if="item.endDate">End Date <span>{{item.endDate | formatDate}}</span></li>
                                <li v-if="item.address && ( checkProperty(item,'address','line1') ||
                                checkProperty(item,'address','line2') || checkProperty(item,'address','aptType') ||
                                checkProperty(item,'address','locationId') || checkProperty(item,'address','stateId') ||
                                checkProperty(item,'address','countryId')|| checkProperty(item,'address','zipcode')
                                )">Work Address <span v-html="$options.filters.addressformat(item.address)"></span>
                                </li>
                            </ul>                        
                        </div>
                        <div class="editor_view_wrap" v-if="item.jobDuties">
                            <h3 class="sub-title">Job Duties</h3>
                            <div class="editor_view" v-html="item.jobDuties"></div>
                        </div>
                    </div>
                </div>
            </div>
        </template>
        </div>
    
        
    </template>
    <template v-if="dataList && dataList.length>0">
        <previousEmploymentDetailsPage :visastatuses="visastatuses" :petition="dataList"></previousEmploymentDetailsPage>
    </template>
</div>
</template>

<script>
import previousEmploymentDetailsPage from "@/views/petition/previousEmploymentDetailsPage.vue";
export default {
    props: {
        anyOtherPersonEmployedInUS:{
            type: Boolean,
            default: false,
        },
        petition: {
            type: Object,
            default: null
        },
        visastatuses: {
            type: Array,
            default: null
        },
        datatype:{
            type:String,
            default:'BENEFICIARY_EMPLOYEMENT'
        },
        employmentList:{
            type: Array,
            default: []
        },
        tplSection:{
            type:String,
            default:''
        },
        questionnaireDetails:{
            type: Array,
            default: null
        }
    },
    mounted() {
        this.dataList = [];
        if(this.datatype == 'SPOUSE_EMPLOYEMENT'){
            if(this.checkProperty(this.petition['dependentsInfo'],'spouse') && this.checkProperty(this.petition['dependentsInfo'],'spouse','prevEmploymentOutsideUS') && this.checkProperty(this.petition['dependentsInfo']['spouse'],'prevEmploymentOutsideUS','length')>0 && this.checkProperty(this.petition['dependentsInfo']['spouse']['prevEmploymentOutsideUS'][0],'employerName')){
                this.dataList = this.checkProperty(this.petition['dependentsInfo'],'spouse','prevEmploymentOutsideUS')
            }
        }
        if(this.datatype == 'BENEFICIARY_EMPLOYEMENT'){
            if(this.checkProperty(this.petition,'beneficiaryInfo') && this.checkProperty(this.petition['beneficiaryInfo'],'prevEmploymentOutsideUS') && this.checkProperty(this.petition['beneficiaryInfo'],'prevEmploymentOutsideUS','length')>0 && this.checkProperty(this.petition['beneficiaryInfo']['prevEmploymentOutsideUS'][0],'employerName')){
                this.dataList = this.checkProperty(this.petition['beneficiaryInfo'],'prevEmploymentOutsideUS')
            }
        }
    },
    methods: {
     

    },
    data: () => ({
        dataList: [],
    }),
    components:{
        previousEmploymentDetailsPage
    }
};
</script>
