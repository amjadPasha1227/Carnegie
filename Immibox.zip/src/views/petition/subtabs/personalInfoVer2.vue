<template>
    <div class="pad20">
        <div class="vx-row m-0 main-list-panel" v-if="false" >
                <template v-for="( val, field) in petition.beneficiaryInfo">
                    <template v-if=" checkFieldType({'field':field , 'dataVar':beneficiaryInfo})['type']=='string' " >
                        <stringDetails :key="field" :value="val" 
                        :label="checkFieldType({'field':field , 'dataVar':beneficiaryInfo})['label']" 
                        v-if="val" :formater="checkFieldType({'field':field , 'dataVar':beneficiaryInfo})['formater']" :wrapclass="'md:w-1/2'"  />
                    </template>
                </template>
        </div>

        <div class="vx-row m-0 main-list-panel"> 
                <template v-for="( val, field) in beneficiaryInfo">
                    <template v-if="checkFieldType({'field':field , 'dataVar':petition.beneficiaryInfo}) && val['type'] == 'string'" >
                        <template v-if="checkAddressFormat({'values':checkFieldType({'field':field , 'dataVar':petition.beneficiaryInfo}),'formatter':val['formater']})">
                            <stringDetails :key="field" :fieldValue="checkFieldType({'field':field , 'dataVar':petition.beneficiaryInfo})" 
                            :label="val['label']" :visastatuses="visastatuses"
                            v-if="val" :formater="val['formater']" :wrapclass="'md:w-1/3'"  />
                        </template>
                    </template>
                    <template v-if=" checkFieldType({'field':field , 'dataVar':petition.beneficiaryInfo}) && checkProperty(checkFieldType({'field':field , 'dataVar':petition.beneficiaryInfo}), 'length') && val['section'] == 'stayInUs'" >
                        <template v-if="checkProperty(petition['beneficiaryInfo']['priorPeriodOfStayInUS'],'length')>0 && checkProperty(petition['beneficiaryInfo']['priorPeriodOfStayInUS'][0],'visaStatus')!=null">
                        <div class="divider"></div>
                        <periodOfStayInUsa  :visastatuses="visastatuses" :fieldValue="checkFieldType({'field':field , 'dataVar':petition.beneficiaryInfo})" 
                           />
                        </template>
                    </template>
                     <template v-if="checkFieldType({'field':field , 'dataVar':petition.beneficiaryInfo})&& ['fax','workPhoneNumber','homePhoneNumber','cellPhoneNumber'].indexOf(field)>-1" >
                        <phoneNumberDetails :key="field" :fieldValue="checkFieldType({'field':field , 'dataVar':petition.beneficiaryInfo})" 
                        :fieldStructure="val" :countryCodeValue="getCellPhoneCountryCode({'field':field })"
                        :label="val['label']"  :formater="val['formater']"  :wrapclass="'md:w-1/3'"/>
                    </template>
                </template>
        </div>
    </div>
</template>
    
<script>
    import _ from "lodash";
    import stringDetails from "@/views/detailsFields/stringDetails.vue";
    //import arrayDetails from "@/views/detailsFields/arrayDetails.vue";
    import phoneNumberDetails from "@/views/detailsFields/phoneNumberDetails.vue";
    import otherNamescomponent from "@/views/detailsFields/otherNamescomponent.vue";
    import periodOfStayInUsa from "@/views/detailsFields/periodOfStayInUsa.vue";
    export default {
        components:{
            stringDetails,
            //arrayDetails,
            otherNamescomponent,
            periodOfStayInUsa,
            phoneNumberDetails
        },
        data : ()=>({
            phoneObjects :{
                "fax":"faxCountryCode",
                "workPhoneNumber":"workPhoneCountryCode",
                "homePhoneNumber":"homePhoneCountryCode",
                "cellPhoneNumber":"cellPhoneCountryCode"
            },
            beneficiaryInfo: {
                name: { type:'string' ,"label":'Full Name' ,"formater":null},
                email: { type:'string' ,"label":'Email' ,"formater":null},
                gender: { type:'string' ,"label":'Gender' ,"formater":'capitalize'},
                dateOfBirth: { type:'string' ,"label":'Date of Birth' ,"formater":'formatDate'},
                countryOfBirthDetails:{
                    type:'string' ,
                    label:'Country of Birth' ,
                    formater:'getObjectName',
                },
                provinceOfBirthDetails:{
                     type:'string' ,
                     label:'Province of Birth' ,
                     formater:'getObjectName',
                },
                locationOfBirth: { type:'string' ,"label":'Location of Birth' ,"formater":null},
                countryOfCitizenshipDetails:{
                    type:'string',
                    label:'Country of Citizenship' ,
                    formater:'getObjectName',
                },
                passportNumber:{type:'string' ,"label":'Passport' ,"formater":null},
                passportIssuedDate:{type:'string' ,"label":'Passport Issue Date' ,"formater":'formatDate'},
                passportExpiryDate:{type:'string' ,"label":'Passport Expiry Date' ,"formater":'formatDate'},
                I94: { type:'string' ,"label":'I-94 Number' ,"formater":null},
                I94ExpiryDate: { type:'string' ,"label":'I-94 Expiry Date' ,"formater":'formatDate'},
                maritalStatusDetails: { type:'string' ,"label":'Marital Status' ,"formater":'getObjectName'},
                passportNumber: { type:'string' ,"label":'Passport Number' ,"formater":null},
                passportIssuedDate: { type:'string' ,"label":'Passport Issued Date' ,"formater":'formatDate'},
                curNonImmigrantVisaStatus: { type:'string' ,"label":'Current Nonimmigrant Status' ,"formater":'formatML'},
                curVisaExpiryDate: { type:'string' ,"label":'Current Status Expiry Date' ,"formater":'formatDate'},
                sevisNumber: { type:'string' ,"label":'SEVIS Number' ,"formater":null},
                eadNumber: { type:'string' ,"label":' EAD Number' ,"formater":null},
                SSN: { type:'string' ,"label":'Social Security Number' ,"formater":null},
                hasI140ImmPetitionFiled: { type:'string' ,"label":'Has an I-140 immigrant petition been filed on your behalf?' ,"formater":"booleanFormat"},
                homePhoneNumber: { "label":'Home Phone Number' ,"formater":'formatPhone'},
                cellPhoneNumber: { "label":'Phone Number' ,"formater":'formatPhone'},
                workPhoneNumber:{ "label":'Work Phone Number' ,"formater":'formatPhone'},
                fax: { "label":'Fax Number' ,"formater":null},
                currentAddress: { type:'string' , "label":'Current Address' ,"formater":'addressformat'}, 
                mailingAddress: { type:'string' , "label":'Mailing Address' ,"formater":'addressformat'},
                consulateNotifyAddress: { type:'string' ,"label":"Consulate to notify upon approval of your petition (if outside the USA)" ,"formater":null},
                I140ImmPetitionFiledDetails: { type:'string' ,"label":'Has an I-140 immigrant petition been filed on your behalf? Details' ,"formater":null},
                noOfDaysStayInUS: { type:'string' ,"label":'Total No. of days in the US in H/L status' ,"formater":null},
                firstEntryDateOrApprovalInUsWithH1B: { type:'string' ,"label":'First Entry Date Or Approval In Us With H1B' ,"formater":'formatDate'},
                dateFifthYearOfHExpire: { type:'string' ,"label":'Date Fifth Year of H1B Status Expires' ,"formater":'formatDate'},
                currentlyInUS: { type:'string' ,"label":'Currently In US' ,"formater":"booleanFormat"},
                haveOwnershipInterest: { type:'string' ,"label":'Having Ownership Interest' ,"formater":"booleanFormat"},
                ownershipInterestDesc: { type:'string' ,"label":'Currently In US' ,"formater":null},
                alienNumber: { type:'string' ,"label":'Alien Number' ,"formater":null},
                lastArrivalDate: { type:'number' ,"label":'Last Arrival Date' ,"formater":'formatDate'},
                placeOfLastEntryInUS: { type:'string' ,"label":'Places of Last Entry In US' ,"formater":null},
                passportExpiryDate:{ type:'string' ,"label":'Date of Passport Expiry' ,"formater":'formatDate'},
               // haveYouEverTravelledToUS: { type:'string' ,"label":'Ever travelled to US' ,"formater":"booleanFormat"},
                priorPeriodOfStayInUS: {
                    section:'stayInUs',
                    type:'array',
                    enteredDate: { type:'string' ,"label":'Date Entered U.S.' ,"formater":'formatDate'},
                    departedDate: { type:'string' ,"label":'Date Departed U.S.' ,"formater":'formatDate'},
                    visaStatus: { type:'string' ,"label":'Case Status' ,"formater":'formatML'},
                    noOfDays: { type:'string' ,"label":'No. of Days' ,"formater":null},
                },
            },
        }),
       
        computed: {
            getCellPhoneCountryCode(){
                let obj = null;
                return (data)=>{
                    if(_.has( data ,'field')){
                        obj = this.checkProperty(this.phoneObjects, data['field'])
                        if(obj){
                            return this.checkProperty(this.petition['beneficiaryInfo'],obj);
                        }
                    }
                }
            },
            checkFieldType(){
                let _self =this;
                return (data)=>{
                if(_.has( data ,'dataVar')){
                    if(_.has(data['dataVar'] ,data['field'])){
                        return data['dataVar'][data['field']];
                    }
                    else {
                        return false;
                    }
                }
                else {
                    return false;
                    }
                }
            },
            checkAddressFormat(){
                return (data)=>{
                if(_.has( data ,'formatter') && this.checkProperty(data, 'formatter') && this.checkProperty(data, 'formatter') == 'addressformat' ){
                    if(this.checkProperty(data, 'values')){
                        if(
                        this.checkProperty(data, 'values','line1') != null || 
                        this.checkProperty(data, 'values','line2') != null ||
                        this.checkProperty(data, 'values','aptType') != null || 
                        this.checkProperty(data, 'values','locationDetails') != null || 
                        this.checkProperty(data, 'values','stateDetails') != null || 
                        this.checkProperty(data, 'values','countryDetails') != null || 
                        this.checkProperty(data, 'values','zipcode') != null         
                        ){
                            return true;
                        }else{
                            return false;
                        }
                    }
                }
                else {
                    return true;
                    }
                }
            },
           
        },
        props: {
            petition: {
                type: Object, 
                default: null
            },
            visastatuses: {
                type: Array,
                default: null
            }
        },
    };
</script>
    