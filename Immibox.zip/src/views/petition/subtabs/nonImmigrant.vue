<template>
<div class="tabs-content-table mt-2 priorPeriodtable " v-if="petition.beneficiaryInfo.nonImmPetitionsInfo.length > 0 && petition.beneficiaryInfo.nonImmPetitionsInfo[0].visaStatus!=null">
    <div class="main-list-wrap pad20 pb-0">
        <div class="vx-row m-0 main-list-panel" style="margin-bottom: 0 !important;">
            <div class="vx-col md:w-1/3 w-full p-0" v-if="canRenderField('didThisPtnrFliedImmPetitionEarlier',questionnaireDetails,false ,'beneficiaryInfo')" >
                <div class="main-list pb-0">
                    <p>
                        Has this employer ever filed a Non-Immigrant H1B petition for you earlier?
                        <span>{{checkProperty(petition['beneficiaryInfo']  ,'didThisPtnrFliedImmPetitionEarlier') | booleanFormat}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="canRenderField('didThisPtnrFliedImmPetitionEarlier',questionnaireDetails,false ,'beneficiaryInfo')" >
                <div class="main-list">
                    <p>
                        This is a first extension with this employer
                        <span>{{checkProperty(petition['beneficiaryInfo']  ,'firstExtnWithPtnr') | booleanFormat}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="canRenderField('didThisPtnrFliedImmPetitionEarlier',questionnaireDetails,false ,'beneficiaryInfo')"  >
                <div class="main-list">
                    <p>
                        This is a second or subsequent extension with this employer
                        <span>{{checkProperty(petition['beneficiaryInfo']  ,'secOrSubSequentExtnWithPtnr') | booleanFormat}}</span>
                    </p>
                </div>
            </div>
        </div>
    </div>
    <div class="pad20">
        <vs-table :data="petition.beneficiaryInfo.nonImmPetitionsInfo">
            <template >
                <template slot="thead">
                    <vs-th>Visa Status</vs-th>
                    <vs-th>Receipt Number</vs-th>
                    <vs-th>Petitioner/Employer Name</vs-th>
                    <vs-th>Valid From</vs-th>
                    <vs-th>Valid To</vs-th>
                </template>
                <template>
                    <vs-tr :key="sin" v-for="(item ,sin) in petition.beneficiaryInfo.nonImmPetitionsInfo">
                        <vs-td>{{item.visaStatus | formatML(visastatusess)}}</vs-td>
                        <vs-td>{{item.receiptNo}}</vs-td>
                        <vs-td> {{item.petitionerName}} <!-- {{ visastatuses | visastatus(stay.visaStatus) }}-->
                        </vs-td>
                        <vs-td v-if="item.validFrom">
                            <template v-if="item.validFrom"> {{item.validFrom | formatDate }}</template>
                            <template v-else>N/A</template>
                        </vs-td>
                        <vs-td >
                           <template v-if="item.validTo"> {{item.validTo | formatDate }}</template>
                           <template v-else>N/A</template>
                        </vs-td>
                    </vs-tr>
                </template>
            </template>
        </vs-table>
    </div>  
</div>
</template>

    
<script>
export default {
    props: {
        petition: {
            type: Object,
            default: null
        },
        visastatuses: {
            type: Array,
            default: null
        },
        questionnaireDetails:{
            type: Array,
            default: null
        }
    },
    mounted(){
        this.getVisastatues()
    },
    methods:{
        getVisastatues(){
            this.$store.dispatch("getmasterdata", "visa_status").then((response) => {
                this.visastatusess = response;
            });
        }
    },
    data: ()=>({
      visastatusess:[],
    }),
    
    
};
</script>
