<template>
    <div class="pad20">
        <div class="vx-row m-0 main-list-panel">
            <div class="vx-col md:w-1/3 w-full p-0"
                v-if="checkProperty(petition,'name') || checkProperty(petition,'firstName') ||
                    checkProperty(petition,'middleName') || checkProperty(petition,'lastName')">
                <div class="main-list">
                    <p>
                        Full Name
                        <span>{{ formatFullname(petition) }}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0"
                v-if="checkProperty(petition,'maidenName') ">
                <div class="main-list">
                    <p>
                       Maiden Name
                        <span>{{ checkProperty(petition, 'maidenName')  }}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition, 'countryOfMarriageDetails') && checkProperty(petition, 'countryOfMarriageDetails','name')">
                <div class="main-list">
                    <p>
                      Country of Marriage
                        <span>{{ checkProperty(petition, 'countryOfMarriageDetails','name') }}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition, 'provinceOfMarriageDetails') && checkProperty(petition, 'provinceOfMarriageDetails','name')">
                <div class="main-list">
                    <p>
                        Province of Marriage
                        <span>{{ checkProperty(petition, 'provinceOfMarriageDetails','name') }}</span>
                    </p>
                </div> 
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition, 'countryOfMarriageTerminationDetails') && checkProperty(petition, 'countryOfMarriageTerminationDetails','name')">
                <div class="main-list">
                    <p>
                        Country of Marriage Termination
                        <span>{{ checkProperty(petition, 'countryOfMarriageTerminationDetails','name') }}</span>
                    </p>
                </div> 
            </div> 
             
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition, 'provinceOfMarriageTerminationDetails') && checkProperty(petition, 'provinceOfMarriageTerminationDetails','name')">
                <div class="main-list">
                    <p>
                        Province of Marriage Termination
                        <span>{{ checkProperty(petition, 'provinceOfMarriageTerminationDetails','name') }}</span>
                    </p>
                </div> 
            </div> 
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'dateOfBirth')">
                <div class="main-list">
                    <p>
                        Date of Birth
                        <span>{{ checkProperty(petition, 'dateOfBirth') | formatDate }}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'dateOfMarriage')">
                <div class="main-list">
                    <p>
                        Date of Marriage
                        <span>{{ checkProperty(petition, 'dateOfMarriage') | formatDate }}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'dateOfMarriage')">
                <div class="main-list">
                    <p>
                        Date of Marriage End
                        <span>{{ checkProperty(petition, 'dateOfMarriage') | formatDate }}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'locationOfMarriage')">
                <div class="main-list">
                    <p>
                       Location of Marriage
                        <span>{{ checkProperty(petition, 'locationOfMarriage') }}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'locationOfMarriageTermination')">
                <div class="main-list">
                    <p>
                        Location of Marriage Termination
                        <span>{{ checkProperty(petition, 'locationOfMarriageTermination') }}</span>
                    </p>
                </div>
            </div>  
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'marriageEndedDueTo')">
                <div class="main-list">
                    <p>
                        Marriage Ended Due TO
                        <span>{{ checkProperty(petition, 'marriageEndedDueTo')}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'marriageEndedOtherInfo')">
                <div class="main-list">
                    <p>
                        Marriage Ended Other Info
                        <span>{{ checkProperty(petition, 'marriageEndedOtherInfo')}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="canRenderField('everAppliedAOSInUS',questionnaireDetails, false, questionnaireSection )" >
                <div class="main-list">
                    <p>
                        Obtained PERM residence through Spouse
                        <span>{{ checkProperty(petition, 'obtainPermResidenceThroughSpouse')| booleanFormat}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="canRenderField('isUSCitizen',questionnaireDetails, false, questionnaireSection )">
                <div class="main-list">
                    <p>
                        Is US Citizen
                        <span>{{ checkProperty(petition, 'isUSCitizen') | booleanFormat }}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'dateFromUSCitizen')">
                <div class="main-list">
                    <p>
                        Date from US Citizen
                        <span>{{ checkProperty(petition, 'dateFromUSCitizen') | formatDate }}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition, 'deceasedCityDetails') && checkProperty(petition, 'deceasedCityDetails','name')">
                <div class="main-list">
                    <p>
                        Deceased City
                        <span>{{ checkProperty(petition, 'deceasedCityDetails','name') }}</span>
                    </p>
                </div> 
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'deceasedDate')">
                <div class="main-list">
                    <p>
                        Deceased Date
                        <span>{{ checkProperty(petition, 'deceasedDate') | formatDate }}</span>
                    </p>
                </div>
            </div>
            <template v-if="checkProperty(petition,'hasOtherNames') && checkProperty(petition,'otherNames' ,'length') >0">
                <div class="vx-row m-0 main-list-panel">
                    <h5 class="names_title">Used other names previously</h5>
                    <template v-for="(item , ind)  in petition['otherNames']">

                        <div :key="ind" class="vx-col md:w-1/3 w-full p-0">
                            <div class="main-list">
                                <p>First Name<span>{{item.firstName}}</span> </p>
                            </div>
                        </div>
                        <div :key="ind" class="vx-col md:w-1/3 w-full p-0">
                            <div class="main-list">
                                <p> Middle Name <span>{{item.middleName}}</span> </p>
                            </div>
                        </div>

                        <div :key="ind" class="vx-col md:w-1/3 w-full p-0">
                            <div class="main-list">
                                <p> Last Name <span>{{item.lastName}}</span> </p>
                            </div>
                        </div>

                    </template>

                </div>
            </template>
        </div>
        <template v-if="checkProperty(petition,'nameAtBirth') && (checkProperty(petition,'nameAtBirth' ,'firstName') || checkProperty(petition,'nameAtBirth' ,'lastName') || checkProperty(petition,'nameAtBirth' ,'middleName') )">
                <div class="vx-row m-0 main-list-panel">
                    <h5 class="names_title">Names at Birth</h5>
                        <div  class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'nameAtBirth' ,'firstName')">
                            <div class="main-list">
                                <p>First Name<span>{{checkProperty(petition,'nameAtBirth' ,'firstName')}}</span> </p>
                            </div>
                        </div>
                        <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'nameAtBirth' ,'middleName')">
                            <div class="main-list">
                                <p> Middle Name <span>{{checkProperty(petition,'nameAtBirth' ,'middleName')}}</span> </p>
                            </div>
                        </div>
                        <div  class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition,'nameAtBirth' ,'lastName')">
                            <div class="main-list">
                                <p> Last Name <span>{{checkProperty(petition,'nameAtBirth' ,'lastName')}}</span> </p>
                            </div>
                        </div>
                </div>
            </template>
        <div class="vx-row m-0 main-list-panel" v-if=" checkProperty(petition  ,'currentAddress' )  && 
            (checkProperty(petition,'currentAddress' ,'line1' )
            || checkProperty(petition['currentAddress'] ,'locationDetails' ,'name' )
            || checkProperty(petition['currentAddress'] ,'stateDetails' ,'name' )
            || checkProperty(petition['currentAddress'] ,'countryDetails' ,'name' ))">
            <div class="vx-col w-full p-0" v-if=" checkProperty(petition ,'currentAddress' )  && 
                (checkProperty(petition ,'currentAddress' ,'line1' )
                || checkProperty(petition['currentAddress'] ,'locationDetails' ,'name' )
                || checkProperty(petition['currentAddress'] ,'stateDetails' ,'name' )
                || checkProperty(petition['currentAddress'] ,'countryDetails' ,'name' ))">
                <div class="main-list">
                    <p>
                    Current Address
                        <span v-html="$options.filters.addressformat(petition.currentAddress)"></span>

                    </p>
                </div>
            </div>
        </div>
</div>
</template>
    
<script>
import educationInfo from "@/views/petition/subtabs/educationsVersion2.vue";
import documentsView from "@/views/common/documentsView.vue";
import _ from "lodash";
export default {
    components: {
        educationInfo,
        documentsView,
    },
    data: () => ({
        visastatuses: [],
        docPrivew: false,
        questionnaireSection:'',
    }),
    props: {
        petition: {
            type: Object,
            default: null
        },
        questionnaireDetails:{
            type: Array,
            default: []
        },
        callFrom: {
            type: String,
            default: ''
        },

    },
    computed: {

    },
    methods: {
        formatFullname(item) {
            let returnVal = ''
            if (this.checkProperty(item, 'name')) {
                return returnVal = this.checkProperty(item, 'name')
            }
            else {
                if (this.checkProperty(item, 'firstName')) {
                    returnVal = this.checkProperty(item, 'firstName')
                }
                if (this.checkProperty(item, 'middleName')) {
                    returnVal = returnVal + ' ' + this.checkProperty(item, 'middleName')
                }
                if (this.checkProperty(item, 'lastName')) {
                    returnVal = returnVal + ' ' + this.checkProperty(item, 'lastName')
                }
                return returnVal
            }
        },downloadfile(value) {
            this.$emit('download_or_view' ,value);
         },
        download_or_view(value) {
            if (_.has(value, "path")) {
                value['url'] = value['path'];
                value['document'] = value['path'];
            }

            if (_.has(value, "url")) {
                value['path'] = value['url'];
                value['document'] = value['url'];
            }

            if (_.has(value, "document")) {
                value['path'] = value['document'];
                value['url'] = value['document'];
            }

            this.selectedFile = value;
            this.docValue = '';
            this.docPrivew = false;
            this.docType = false;
            this.docType = this.findmsDoctype(value);

            if (this.docType == "office" || this.docType == "image") {

                value.url = value.url.replace(this.$globalgonfig._S3URL, "");
                value.url = value.url.replace(this.$globalgonfig._S3URLAWS, "");
                let postdata = {
                    keyName: value.url
                };
                this.$store.dispatch("getSignedUrl", postdata).then((response) => {
                    this.docValue = response.data.result.data;

                    if (this.docType == "office") {
                        this.docValue = encodeURIComponent(response.data.result.data);
                    }
                    this.docPrivew = true;
                });

            } else {
                this.downloads3file(value);
            }

        },

    },
    mounted() {
        if(this.callFrom == 'BENEFICIARY' ){
            this.questionnaireSection = 'beneficiaryInfo.previousSpouse'
        };
        if(this.callFrom == 'SPOUSE' ){
            this.questionnaireSection = 'dependentsInfo.spouse.previousSpouse'
        };
    }
};
</script>
    