<template>
    
<div class="pad20">
    <div class="dependent-block_wrap" v-if="canRenderField('hasMasterDegreeInUS', questionnaireDetails ,false,'beneficiaryInfo')">
        <div class="dependent-block dependent-block-transparent">
            <div class="vx-col w-full p-0">
                <div class="dependent_details">
                    <ul class="toplist">
                        <li>Do you have Masters degree in United States? <span>{{petition.beneficiaryInfo.hasMasterDegreeInUS | booleanFormat}}</span></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
                                          
    
    <div class="vx-row m-0 main-list-panel">
        <div class="vx-col  w-full p-0  edu-block" :key="index" v-for="(item,index) in petition.beneficiaryInfo.educations">

            <div class="dependent-block_wrap">
                <div class="dependent-block">
                    <div class="dependent-title">
                        <h3>
                            {{item.name}}
                        </h3>

                    </div>
                    <div class="dependent_details">
                          <ul class="toplist">
                            <li v-if="item.highestDegree">Highest Degree <span>{{item.highestDegree | formatML(highestDegreeList)}}</span></li>
                            <li v-if="item.majorFieldOfStudy">Major Field of Study <span>{{item.majorFieldOfStudy}}</span></li>
                            <li v-if="item.attendedFrom">Course Started On <span>{{item.attendedFrom | formatMonthYear}}</span></li>
                            <li v-if="item.attendedTo">Course Completed On <span>{{item.attendedTo | formatMonthYear}}</span></li>
                        </ul>
                        <ul>
                            <li v-if="item.graduatedYear"> Year of Graduation <span>{{item.graduatedYear}}</span></li>
                            <li v-if="item.graduatedDate"> Date of Graduation <span>{{item.graduatedDate | formatDate}}</span></li>
                            
                            <li v-if="item.address"> Address <span v-html="$options.filters.addressformat(item.address)"></span>
                            </li>
                        </ul>
                        <ul class="toplist" v-if="checkProperty(item['address'],'countryId')==231">
                            <li> Was the University Accredited at the time of your graduation <span>{{item.isAccredited?'Yes':'No'}}</span></li>
                            <li>Is the University a for-profit Organization <span>{{item.isForProfit?'Yes':'No'}}</span></li>
                        </ul>
                    </div>
                </div>
            </div>

        </div> 
    </div>
</div>
</template>

<script>
export default {
      data: ()=>({
        highestDegreeList:[],
  }),
    props: {
        petition: {
            type: Object,
            default: null
        },
        visastatuses: {
            type: Array,
            default: null
        },
        questionnaireDetails:{
            type: Array,
            default: null
        }
    },
    mounted() {
        this.getEducationTypes()
    },
    methods: {
        //this.petition.highestDegreeList = response;
        getEducationTypes(){
        this.$store.dispatch("getmasterdata", "education_types")
                    .then((response) => {
                        this.highestDegreeList = response;
                    });
                }

    }
};
</script>
