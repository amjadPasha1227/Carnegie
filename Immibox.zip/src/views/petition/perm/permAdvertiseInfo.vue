<template>
    <div class="main-list-wrap petition_details_wrap">
    <div class="pad20">
        <div class="relative d-flex justify-end" v-if="checkProperty(petition ,'completedActivities','length')>0 && petition.completedActivities.indexOf('COLLECT_ADV_EVIDENCE') >-1 
               && petition.completedActivities.indexOf('UPLOAD_PERM_ACK') <=-1 && checkAllCasesPermAcknowladge && checkAdverTiseMentPermissions " >
     
     <vs-button @click="$emit('openAdv' ,'COLLECT_ADV_EVIDENCE_EDIT')" class="light-blue-btn btn_primary ml-2">Update Evidence of Advertisements</vs-button>
   </div>
      <div class="vx-row m-0 main-list-panel"  v-if="
                        checkProperty(petition,'recruitmentInfo' ,'applForProfOcc')
                      || checkProperty(petition,'recruitmentInfo' ,'applForColOrUniTeacher')
                      || checkProperty(petition,'recruitmentInfo' ,'selCandiadateByCompRecru')
                      || checkProperty(petition,'recruitmentInfo' ,'useBasicRecruProcForProfOccu')
                     
                       ">   
       
            <h5 class="names_title">Occupation Type</h5>
            <div class="vx-col md:w-1/2 w-full p-0" v-if="checkIsTempAccount(checkProperty(petition,'recruitmentInfo' ,'applForProfOcc'))">
                 <div class="main-list">
                <p>
                   Application for a Professional Occupation
                    <span>{{petition.recruitmentInfo.applForProfOcc}}</span>
                </p>
            </div>
            </div>
            <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'applForColOrUniTeacher')">
            <div class="main-list">
                <p>
                    Application for a college or university teacher
                    <span>{{petition.recruitmentInfo.applForColOrUniTeacher}}</span>
                </p>
            </div>
        </div>
        <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'selCandiadateByCompRecru')">
            <div class="main-list">
                <p>
                    Did you select the candidate using a competitive recruitment and selection process
                    <span>{{petition.recruitmentInfo.selCandiadateByCompRecru}}</span>
                </p>
            </div>
        </div>
         <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'useBasicRecruProcForProfOccu')">
            <div class="main-list">
                <p>
                    Did you use the basic recruitment process for professional occupations
                    <span>{{petition.recruitmentInfo.useBasicRecruProcForProfOccu}}</span>
                </p>
            </div>
        </div>
        
      </div>
      <div class="vx-row m-0 main-list-panel"  v-if=" 
                       checkProperty(petition,'recruitmentInfo' ,'dateAlienSelected')
                      || checkProperty(petition,'recruitmentInfo' ,'nameOfNationalProfJourAdvPlaced')
                      || checkProperty(petition,'recruitmentInfo' ,'dateOfNationalProfJourAdvPlaced')
                      || checkProperty(petition,'recruitmentInfo' ,'addiRecruInfo')
                     
                       "> 
        <template v-if="checkProperty(petition,'recruitmentInfo' ,'applForColOrUniTeacher')">
        <h5 class="names_title">Special Recruitment and Documentation Procedures for College and University Teachers</h5>
        <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'dateAlienSelected')">
            <div class="main-list">
                <p>
                 Date of alien selected
                    <span>{{petition.recruitmentInfo.dateAlienSelected | formatDate}}</span>
                </p>
            </div>
        </div>
        <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'nameOfNationalProfJourAdvPlaced')">
            <div class="main-list">
                <p>
                 Name and date of national professional journal in which advertisement was placed
                    <span>{{petition.recruitmentInfo.nameOfNationalProfJourAdvPlaced}}</span>
                </p>
            </div>
        </div>
        <!-- <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'dateOfNationalProfJourAdvPlaced')">
            <div class="main-list">
                <p>
                 Date of national professional journal in which advertisement was placed
                    <span>{{petition.recruitmentInfo.dateOfNationalProfJourAdvPlaced | formatDate}}</span>
                </p>
            </div>
        </div> -->
        <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'addiRecruInfo')">
            <div class="main-list">
                <p>
                    Specify additional Recruitment Information
                    <span>{{petition.recruitmentInfo.addiRecruInfo}}</span> 
                </p>
            </div>
        </div>
       </template>
       
      </div>
      <div class="vx-row m-0 main-list-panel" v-if="checkProperty(petition,'recruitmentInfo','swaStartDate')
                       || checkProperty(petition,'recruitmentInfo','swaEndDate')
                        || checkProperty(petition,'recruitmentInfo','hasSundayEditionOfNewsPaper')
                         || checkProperty(petition,'recruitmentInfo','nameOfNewsPaperFirstAdvPlaced')
                          || checkProperty(petition,'recruitmentInfo','dateOfFirstAdvtIdentified')
                           || checkProperty(petition,'recruitmentInfo','nameOfNewsPaperOrJourSecondAdvPlaced')
                           || checkProperty(petition,'recruitmentInfo','isNewsPaperOrJournal')
                           || checkProperty(petition,'recruitmentInfo','dateOfSecondAdvIdentified')"> 
        
             <h5 class="names_title">Professional/Non-Professional Information</h5>
          <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'swaStartDate')">
            <div class="main-list">
                <p>
                 Start date for the SWA job order
                    <span>{{petition.recruitmentInfo.swaStartDate | formatDate}}</span>
                </p>
            </div>
        </div>
         <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'swaEndDate')">
            <div class="main-list">
                <p>
                 End date for the SWA job order
                    <span>{{petition.recruitmentInfo.swaEndDate | formatDate}}</span>
                </p>
            </div>
        </div>
          <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'hasSundayEditionOfNewsPaper')">
            <div class="main-list">
                <p>
                    Sunday edition of the newspaper in the area of intended employment
                    <span>{{petition.recruitmentInfo.hasSundayEditionOfNewsPaper}}</span>
                </p>
            </div>
        </div>
        <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'startDateOfSundayNewsPaper') && checkProperty(petition,'recruitmentInfo' ,'hasSundayEditionOfNewsPaper') =='Yes'">
            <div class="main-list">
                <p>
                    Start date of Sunday edition of the newspaper
                    <span>{{petition.recruitmentInfo.startDateOfSundayNewsPaper | formatDate}}</span>
                </p>
            </div>
        </div>
        <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'endDateOfSundayNewsPaper')  && checkProperty(petition,'recruitmentInfo' ,'hasSundayEditionOfNewsPaper') =='Yes'">
            <div class="main-list">
                <p>
                    End date of Sunday edition of the newspaper
                    <span>{{petition.recruitmentInfo.endDateOfSundayNewsPaper | formatDate}}</span>
                </p>
            </div>
        </div>
        <template v-if="checkProperty(petition['recruitmentInfo'],'documents','sunday') && checkProperty(petition,'recruitmentInfo' ,'hasSundayEditionOfNewsPaper') =='Yes'">
        <vs-col class="padl0 padr0" v-if="checkProperty(petition['recruitmentInfo']['documents'],'sunday','length')>0" >
          <documentsView @download_or_view="download_or_view" :type="'sunday'"  :documentsList="petition['recruitmentInfo']['documents']['sunday']" :petitionDetails="petition" />
        </vs-col>
        </template>
         <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'nameOfNewsPaperFirstAdvPlaced')">
            <div class="main-list">
                <p>
                Name of newspaper in which the first advertisement was placed
                    <span>{{petition.recruitmentInfo.nameOfNewsPaperFirstAdvPlaced}}</span>
                </p>
            </div>
        </div>
         <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'dateOfFirstAdvtIdentified')">
            <div class="main-list">
                <p>
                Date of first advertisement identified
                    <span>{{petition.recruitmentInfo.dateOfFirstAdvtIdentified | formatDate}}</span>
                </p>
            </div>
        </div>
         <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'nameOfNewsPaperOrJourSecondAdvPlaced')">
            <div class="main-list">
                <p>
                    Name of newspaper or professional journal in which second advertisement was placed
                    <span>{{petition.recruitmentInfo.nameOfNewsPaperOrJourSecondAdvPlaced}}</span>
                </p>
            </div>
        </div>
        <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'isNewsPaperOrJournal')">
            <div class="main-list">
                <p>
                    Newspaper/Journal
                    <span>{{petition.recruitmentInfo.isNewsPaperOrJournal}}</span>
                </p>
            </div>
        </div>
        <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'dateOfSecondAdvIdentified')">
            <div class="main-list">
                <p>
                    Date of second newspaper advertisement or date of publication of journal identified
                    <span>{{petition.recruitmentInfo.dateOfSecondAdvIdentified | formatDate}}</span>
                </p>
            </div>
        </div>
      </div>
      <div class="vx-row m-0 ml-0 mr-0 main-list-panel professional_recruitment-info" v-if="checkProperty(petition,'recruitmentInfo','dateOfAdvAtJobFair')
                       || checkProperty(petition,'recruitmentInfo','dateOfNonCampusRecru')
                        || checkProperty(petition,'recruitmentInfo','startDateOfEmplrWebsitePosted')
                         || checkProperty(petition,'recruitmentInfo','endDateOfEmplrWebsitePosted')
                         || checkProperty(petition,'recruitmentInfo','startDateOfAdvWithTradeOrProfOrg')
                         || checkProperty(petition,'recruitmentInfo','endDateOfAdvWithTradeOrProfOrg')
                         || checkProperty(petition,'recruitmentInfo','startDateOfListedInJobSite')
                         || checkProperty(petition,'recruitmentInfo','endDateOfListedInJobSite')
                         || checkProperty(petition,'recruitmentInfo','startDateOfListedInPrivateEmpFirm')
                         || checkProperty(petition,'recruitmentInfo','endDateOfListedInPrivateEmpFirm')
                         || checkProperty(petition,'recruitmentInfo','startDateOfAdvEmpRefProgram')
                         || checkProperty(petition,'recruitmentInfo','endDateOfAdvEmpRefProgram')
                         || checkProperty(petition,'recruitmentInfo','startDateOfAdvCampusPlacOfc')
                         || checkProperty(petition,'recruitmentInfo','endDateOfAdvCampusPlacOfc')
                         || checkProperty(petition,'recruitmentInfo','startDateOfAdvLocalNewsPaper')
                         || checkProperty(petition,'recruitmentInfo','endDateOfAdvLocalNewsPaper')
                         || checkProperty(petition,'recruitmentInfo','startDateOfAdvInTVOrRadio')
                         || checkProperty(petition,'recruitmentInfo','endDateOfAdvInTVOrRadio')   
                             "> 
       
            <h5 class="names_title">Professional Recruitment Information</h5>
        <div class="vx-row" v-if="(checkProperty(petition,'recruitmentInfo' ,'startDateOfAdvAtJobFair') || checkProperty(petition,'recruitmentInfo' ,'endDateOfAdvAtJobFair')) ||
        (checkProperty(petition['recruitmentInfo'],'documents','jobFair') && checkProperty(petition['recruitmentInfo']['documents'],'jobFair','length')>0)">
            <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'startDateOfAdvAtJobFair')">
                <div class="main-list">
                    <p>
                        Start date of advertised at job fair
                        <span>{{petition.recruitmentInfo.startDateOfAdvAtJobFair | formatDate}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'endDateOfAdvAtJobFair')">
                <div class="main-list">
                    <p>
                        End date of advertised at job fair
                        <span>{{petition.recruitmentInfo.endDateOfAdvAtJobFair | formatDate}}</span>
                    </p>
                </div>
            </div>
            <template v-if="checkProperty(petition['recruitmentInfo'],'documents','jobFair')">
            <vs-col class="padl0 padr0" v-if="checkProperty(petition['recruitmentInfo']['documents'],'jobFair','length')>0" >
            <documentsView @download_or_view="download_or_view" :type="'jobFair'"  :documentsList="petition['recruitmentInfo']['documents']['jobFair']" :petitionDetails="petition" />
            </vs-col>
            </template>
        </div>
        <div class="vx-row" v-if="(checkProperty(petition,'recruitmentInfo' ,'startDateOfNonCampusRecru') || checkProperty(petition,'recruitmentInfo' ,'endDateOfNonCampusRecru')) || 
        (checkProperty(petition['recruitmentInfo'],'documents','campusRecruitment') && checkProperty(petition['recruitmentInfo']['documents'],'campusRecruitment','length')>0)">
            <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'startDateOfNonCampusRecru')">
                <div class="main-list">
                    <p>
                        Start date of on-campus recruiting
                        <span>{{petition.recruitmentInfo.startDateOfNonCampusRecru | formatDate}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'endDateOfNonCampusRecru')">
                <div class="main-list">
                    <p>
                        End date of on-campus recruiting
                        <span>{{petition.recruitmentInfo.endDateOfNonCampusRecru | formatDate}}</span>
                    </p>
                </div>
            </div>
            <template v-if="checkProperty(petition['recruitmentInfo'],'documents','campusRecruitment')">
            <vs-col class="padl0 padr0" v-if="checkProperty(petition['recruitmentInfo']['documents'],'campusRecruitment','length')>0" >
            <documentsView @download_or_view="download_or_view" :type="'campusRecruitment'"  :documentsList="petition['recruitmentInfo']['documents']['campusRecruitment']" :petitionDetails="petition" />
            </vs-col>
            </template>
        </div>
        <div class="vx-row" v-if="(checkProperty(petition,'recruitmentInfo' ,'startDateOfEmplrWebsitePosted') || checkProperty(petition,'recruitmentInfo' ,'endDateOfEmplrWebsitePosted')) ||
         (checkProperty(petition['recruitmentInfo'],'documents','empWebsite') && checkProperty(petition['recruitmentInfo']['documents'],'empWebsite','length')>0) ">
            <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'startDateOfEmplrWebsitePosted')">
                <div class="main-list">
                    <p>
                        Start date posted on employer website
                        <span>{{petition.recruitmentInfo.startDateOfEmplrWebsitePosted | formatDate}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'endDateOfEmplrWebsitePosted')">
                <div class="main-list">
                    <p>
                        End date posted on employer website
                        <span>{{petition.recruitmentInfo.endDateOfEmplrWebsitePosted | formatDate}}</span>
                    </p>
                </div>
            </div>
            <template v-if="checkProperty(petition['recruitmentInfo'],'documents','empWebsite')">
            <vs-col class="padl0 padr0" v-if="checkProperty(petition['recruitmentInfo']['documents'],'empWebsite','length')>0" >
            <documentsView @download_or_view="download_or_view" :type="'empWebsite'"  :documentsList="petition['recruitmentInfo']['documents']['empWebsite']" :petitionDetails="petition" />
            </vs-col>
            </template>
        </div>
        <div class="vx-row" v-if="(checkProperty(petition,'recruitmentInfo' ,'startDateOfAdvWithTradeOrProfOrg') || checkProperty(petition,'recruitmentInfo' ,'endDateOfAdvWithTradeOrProfOrg')) ||
        (checkProperty(petition['recruitmentInfo'],'documents','profOrgOrTrade') && checkProperty(petition['recruitmentInfo']['documents'],'profOrgOrTrade','length')>0) ">
            <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'startDateOfAdvWithTradeOrProfOrg')">
                <div class="main-list">
                    <p>
                        Start date advertised with trade or professional organization
                        <span>{{petition.recruitmentInfo.startDateOfAdvWithTradeOrProfOrg | formatDate}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'endDateOfAdvWithTradeOrProfOrg')">
                <div class="main-list">
                    <p>
                        End date advertised with trade or professional organization
                        <span>{{petition.recruitmentInfo.endDateOfAdvWithTradeOrProfOrg | formatDate}}</span>
                    </p>
                </div>
            </div>
            <template v-if="checkProperty(petition['recruitmentInfo'],'documents','profOrgOrTrade')">
            <vs-col class="padl0 padr0" v-if="checkProperty(petition['recruitmentInfo']['documents'],'profOrgOrTrade','length')>0" >
            <documentsView @download_or_view="download_or_view" :type="'profOrgOrTrade'"  :documentsList="petition['recruitmentInfo']['documents']['profOrgOrTrade']" :petitionDetails="petition" />
            </vs-col>
            </template>
        </div>
        <div class="vx-row" v-if="(checkProperty(petition,'recruitmentInfo' ,'startDateOfListedInJobSite') || checkProperty(petition,'recruitmentInfo' ,'endDateOfListedInJobSite'))|| 
         (checkProperty(petition['recruitmentInfo'],'documents','jobSearchWebsite') && checkProperty(petition['recruitmentInfo']['documents'],'jobSearchWebsite','length')>0)">
            <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'startDateOfListedInJobSite')">
                <div class="main-list">
                    <p>
                        Start date listed with job search website
                        <span>{{petition.recruitmentInfo.startDateOfListedInJobSite | formatDate}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'endDateOfListedInJobSite')">
                <div class="main-list">
                    <p>
                        End date listed with job search website
                        <span>{{petition.recruitmentInfo.endDateOfListedInJobSite | formatDate}}</span>
                    </p>
                </div>
            </div>
            <template v-if="checkProperty(petition['recruitmentInfo'],'documents','jobSearchWebsite')">
                <vs-col class="padl0 padr0" v-if="checkProperty(petition['recruitmentInfo']['documents'],'jobSearchWebsite','length')>0" >
                <documentsView @download_or_view="download_or_view" :type="'jobSearchWebsite'"  :documentsList="petition['recruitmentInfo']['documents']['jobSearchWebsite']" :petitionDetails="petition" />
                </vs-col>
            </template>
        </div>
        <div class="vx-row" v-if="(checkProperty(petition,'recruitmentInfo' ,'startDateOfListedInPrivateEmpFirm') ||checkProperty(petition,'recruitmentInfo' ,'endDateOfListedInPrivateEmpFirm')) || 
         (checkProperty(petition['recruitmentInfo'],'documents','pvtEmpmtFirm') && checkProperty(petition['recruitmentInfo']['documents'],'pvtEmpmtFirm','length')>0) " >
            <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'startDateOfListedInPrivateEmpFirm')">
                <div class="main-list">
                    <p>
                        Start date listed with private employment firm
                        <span>{{petition.recruitmentInfo.startDateOfListedInPrivateEmpFirm | formatDate}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'endDateOfListedInPrivateEmpFirm')">
                <div class="main-list">
                    <p>
                        End date listed with private employment firm
                        <span>{{petition.recruitmentInfo.endDateOfListedInPrivateEmpFirm | formatDate}}</span>
                    </p>
                </div>
            </div>
            <template v-if="checkProperty(petition['recruitmentInfo'],'documents','pvtEmpmtFirm')">
            <vs-col class="padl0 padr0" v-if="checkProperty(petition['recruitmentInfo']['documents'],'pvtEmpmtFirm','length')>0" >
            <documentsView @download_or_view="download_or_view" :type="'pvtEmpmtFirm'"  :documentsList="petition['recruitmentInfo']['documents']['pvtEmpmtFirm']" :petitionDetails="petition" />
            </vs-col>
            </template>
        </div>
        <div class="vx-row" v-if="(checkProperty(petition,'recruitmentInfo' ,'startDateOfAdvEmpRefProgram') || checkProperty(petition,'recruitmentInfo' ,'endDateOfAdvEmpRefProgram')) || 
        (checkProperty(petition['recruitmentInfo'],'documents','empRefProgram') && checkProperty(petition['recruitmentInfo']['documents'],'empRefProgram','length')>0) ">
            <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'startDateOfAdvEmpRefProgram')">
                <div class="main-list">
                    <p>
                        Start date advertised with employee referral program
                        <span>{{petition.recruitmentInfo.startDateOfAdvEmpRefProgram | formatDate}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'endDateOfAdvEmpRefProgram')">
                <div class="main-list">
                    <p>
                        End date advertised with employee referral program
                        <span>{{petition.recruitmentInfo.endDateOfAdvEmpRefProgram | formatDate}}</span>
                    </p>
                </div>
            </div>
            <template v-if="checkProperty(petition['recruitmentInfo'],'documents','empRefProgram')">
            <vs-col class="padl0 padr0" v-if="checkProperty(petition['recruitmentInfo']['documents'],'empRefProgram','length')>0" >
            <documentsView @download_or_view="download_or_view" :type="'empRefProgram'"  :documentsList="petition['recruitmentInfo']['documents']['empRefProgram']" :petitionDetails="petition" />
            </vs-col>
            </template>
        </div>
        <div class="vx-row"  v-if="(checkProperty(petition,'recruitmentInfo' ,'startDateOfAdvCampusPlacOfc') || checkProperty(petition,'recruitmentInfo' ,'endDateOfAdvCampusPlacOfc'))||
        (checkProperty(petition['recruitmentInfo'],'documents','campusPlacement') && checkProperty(petition['recruitmentInfo']['documents'],'campusPlacement','length')>0)  " >
            <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'startDateOfAdvCampusPlacOfc')">
            <div class="main-list">
                <p>
                    Start date advertised with campus placement office
                    <span>{{petition.recruitmentInfo.startDateOfAdvCampusPlacOfc | formatDate}}</span>
                </p>
            </div>
            </div>
            <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'endDateOfAdvCampusPlacOfc')">
            <div class="main-list">
                <p>
                    End date advertised with campus placement office
                    <span>{{petition.recruitmentInfo.endDateOfAdvCampusPlacOfc | formatDate }}</span>
                </p>
            </div>
            </div>
            <template v-if="checkProperty(petition['recruitmentInfo'],'documents','campusPlacement')">
                <vs-col class="padl0 padr0" v-if="checkProperty(petition['recruitmentInfo']['documents'],'campusPlacement','length')>0" >
                <documentsView @download_or_view="download_or_view" :type="'campusPlacement'"  :documentsList="petition['recruitmentInfo']['documents']['campusPlacement']" :petitionDetails="petition" />
                </vs-col>
            </template>
        </div>
        <div class="vx-row"  v-if="(checkProperty(petition,'recruitmentInfo' ,'startDateOfAdvLocalNewsPaper') || checkProperty(petition,'recruitmentInfo' ,'endDateOfAdvLocalNewsPaper')) ||
         (checkProperty(petition['recruitmentInfo'],'documents','localNewsPaper') && checkProperty(petition['recruitmentInfo']['documents'],'localNewsPaper','length')>0)">
            <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'startDateOfAdvLocalNewsPaper')">
                <div class="main-list">
                    <p>
                        Start date advertised with local or ethnic newspaper
                        <span>{{petition.recruitmentInfo.startDateOfAdvLocalNewsPaper | formatDate}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'endDateOfAdvLocalNewsPaper')">
                <div class="main-list">
                    <p>
                        End date advertised with local or ethnic newspaper
                        <span>{{petition.recruitmentInfo.endDateOfAdvLocalNewsPaper | formatDate}}</span>
                    </p>
                </div>
            </div>
            <template v-if="checkProperty(petition['recruitmentInfo'],'documents','localNewsPaper')">
                <vs-col class="padl0 padr0" v-if="checkProperty(petition['recruitmentInfo']['documents'],'localNewsPaper','length')>0" >
                <documentsView @download_or_view="download_or_view" :type="'localNewsPaper'"  :documentsList="petition['recruitmentInfo']['documents']['localNewsPaper']" :petitionDetails="petition" />
                </vs-col>
            </template>
        </div>
        <div class="vx-row" v-if="(checkProperty(petition,'recruitmentInfo' ,'startDateOfAdvInTVOrRadio') ||checkProperty(petition,'recruitmentInfo' ,'endDateOfAdvInTVOrRadio'))||
         (checkProperty(petition['recruitmentInfo'],'documents','tvAds') && checkProperty(petition['recruitmentInfo']['documents'],'tvAds','length')>0) ">
            <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'startDateOfAdvInTVOrRadio')">
                <div class="main-list">
                    <p>
                        Start date advertised with radio or TV ads
                        <span>{{petition.recruitmentInfo.startDateOfAdvInTVOrRadio | formatDate}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'endDateOfAdvInTVOrRadio')">
                <div class="main-list">
                    <p>
                        End date advertised with radio or TV ads
                        <span>{{petition.recruitmentInfo.endDateOfAdvInTVOrRadio | formatDate}}</span>
                    </p>
                </div>
            </div>
            <template v-if="checkProperty(petition['recruitmentInfo'],'documents','tvAds')">
                <vs-col class="padl0 padr0" v-if="checkProperty(petition['recruitmentInfo']['documents'],'tvAds','length')>0" >
                <documentsView @download_or_view="download_or_view" :type="'jobSearchWebsite'"  :documentsList="petition['recruitmentInfo']['documents']['tvAds']" :petitionDetails="petition" />
                </vs-col>
            </template>
        </div>
        </div>
        <!-- <div class="vx-row m-0 main-list-panel" v-if="(checkProperty(petition['recruitmentInfo'],'documents','recruReportSummary')
        && checkProperty(petition['recruitmentInfo']['documents'],'recruReportSummary','length')>0)
        || (checkProperty(petition['recruitmentInfo'],'documents','busNecLetterByEplr')
            && checkProperty(petition['recruitmentInfo']['documents'],'busNecLetterByEplr','length')>0)
        "> 
        <h5 class="names_title">Additional Documents</h5>
        <template v-if="checkProperty(petition['recruitmentInfo'],'documents','recruReportSummary') ">
        <vs-col class="padl0 padr0" v-if="checkProperty(petition['recruitmentInfo']['documents'],'recruReportSummary','length')>0" >
          <documentsView @download_or_view="download_or_view" :type="'recruReportSummary'"  :documentsList="petition['recruitmentInfo']['documents']['recruReportSummary']" :petitionDetails="petition" />
        </vs-col>
        </template>
        <template v-if="checkProperty(petition['recruitmentInfo'],'documents','busNecLetterByEplr') ">
        <vs-col class="padl0 padr0" v-if="checkProperty(petition['recruitmentInfo']['documents'],'busNecLetterByEplr','length')>0" >
          <documentsView @download_or_view="download_or_view" :type="'busNecLetterByEplr'"  :documentsList="petition['recruitmentInfo']['documents']['busNecLetterByEplr']" :petitionDetails="petition" />
        </vs-col>
        </template>
      </div> -->
      <div class="vx-row m-0 main-list-panel" v-if="(checkProperty(petition['recruitmentInfo'],'documents','intrOfcMemomandum')
        && checkProperty(petition['recruitmentInfo']['documents'],'intrOfcMemomandum','length')>0)
        || checkProperty(petition,'recruitmentInfo','startDateOfPostedIntrOfcMemorandum  ') || checkProperty(petition,'recruitmentInfo','endDateOfPostedIntrOfcMemorandum')
        ">
        <h5 class="names_title">Inter Office Memorandum</h5>
        <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'startDateOfPostedIntrOfcMemorandum')">
                <div class="main-list">
                    <p>
                       Start date
                        <span>{{petition.recruitmentInfo.startDateOfPostedIntrOfcMemorandum | formatDate}}</span>
                    </p>
                </div>
        </div>
        <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'endDateOfPostedIntrOfcMemorandum')">
                <div class="main-list">
                    <p>
                        End date 
                        <span>{{petition.recruitmentInfo.endDateOfPostedIntrOfcMemorandum | formatDate}}</span>
                    </p>
                </div>
        </div>
        <template v-if="checkProperty(petition['recruitmentInfo'],'documents','intrOfcMemomandum') ">
        <vs-col class="padl0 padr0" v-if="checkProperty(petition['recruitmentInfo']['documents'],'intrOfcMemomandum','length')>0" >
          <documentsView @download_or_view="download_or_view" :type="'intrOfcMemomandum'"  :documentsList="petition['recruitmentInfo']['documents']['intrOfcMemomandum']" :petitionDetails="petition" />
        </vs-col>
        </template>
        </div>








        <div class="vx-row m-0 main-list-panel" v-if="checkProperty(petition,'recruitmentInfo' ,'hasEmplrRecPayForSubAppl')
                      || checkProperty(petition,'recruitmentInfo' ,'amountRecivedPurposeAndDateForSubAppl')
                      || checkProperty(petition,'recruitmentInfo' ,'hasBargainRepreForWorkerInOccu')
                      || checkProperty(petition,'recruitmentInfo' ,'noBargainRepreHasNotice')
                      || checkProperty(petition,'recruitmentInfo' ,'hasEmplrHadLayoffInArea')
                      || checkProperty(petition,'recruitmentInfo' ,'wereLaidOffUSWorker')
                       "> 
      
             <h5 class="names_title">General Information</h5>
          <div class="vx-col  w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'hasEmplrRecPayForSubAppl')">
            <div class="main-list">
                <p>
                    Has the employer received payment of any kind for the submission of this application
                    <span>{{petition.recruitmentInfo.hasEmplrRecPayForSubAppl}}</span>
                </p>
            </div>
        </div>
          <div class="vx-col  w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'hasEmplrRecPayForSubAppl')=='Yes' && checkProperty(petition,'recruitmentInfo' ,'amountRecivedPurposeAndDateForSubAppl')">
            <div class="main-list">
                <p>
                    Details of the payment including the amount, date and purpose of the payment
                    <span>{{petition.recruitmentInfo.amountRecivedPurposeAndDateForSubAppl}}</span>
                </p>
            </div>
        </div>
          <div class="vx-col  w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'hasBargainRepreForWorkerInOccu')">
            <div class="main-list">
                <p>
                    Has the bargaining representative for workers in the occupation in which the alien will be employed been provided with notice of this filing at least 30 days but not more than 180 days before the date the application is filed
                    <span>{{petition.recruitmentInfo.hasBargainRepreForWorkerInOccu}}</span>
                </p>
            </div>
        </div>
          <div class="vx-col w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'noBargainRepreHasNotice')">
            <div class="main-list">
                <p>
                    If there is no bargaining representative, has a notice of this filing been posted for 10 business days in a conspicuous location at the place of employment, ending at least 30 days before but not more than 180 days before the date the application is filed
                    <span>{{petition.recruitmentInfo.noBargainRepreHasNotice}}</span>
                </p>
            </div>
        </div>
           <div class="vx-col  w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'hasEmplrHadLayoffInArea')">
            <div class="main-list">
                <p>
                    Has the employer had a layoff in the area of intended employment in the occupation involved in this application or in a related occupation within the six months immediately preceding the filing of this application
                    <span>{{petition.recruitmentInfo.hasEmplrHadLayoffInArea}}</span>
                </p>
            </div>
        </div>
           <div class="vx-col  w-full p-0" v-if="checkProperty(petition,'recruitmentInfo' ,'wereLaidOffUSWorker')">
            <div class="main-list">
                <p>
                    The laid off U.S. workers notified and considered for the job opportunity for which certification is sought
                    <span>{{petition.recruitmentInfo.wereLaidOffUSWorker}}</span> 
                </p>
            </div>
        </div>
     
        <vs-col class="padl0 padr0" v-if="false" >
        <documentsListView @download_or_view="download_or_view" v-if="checkProperty(petition, 'recruitmentInfo','documents')" :documentsList="checkProperty(petition, 'recruitmentInfo','documents')" :petitionDetails="petition" />
       </vs-col>
        </div>
    </div>
    </div>
    </template>
    
    <script>
    import VueDocPreview from 'vue-doc-preview'
    import VuePerfectScrollbar from "vue-perfect-scrollbar";
    import documentsListView from "@/views/common/documentsListView.vue";
    import documentsView from "@/views/common/documentsView.vue";
    import _ from "lodash";
    export default {
        data: () => ({
            
            docPrivew: false,
            docValue: '',
            docType: "",
            selectedFile: null,
           

        }),
        computed: {
            checkAdverTiseMentPermissions(){
              let returnVal =false;
             
              let isAdmin =false;
             let canEditPermAdvertisement =false;
            let jobAdvertismentActivity =[];
            let adminsList =[3]
            let loginUserData =_.cloneDeep(this.getUserData)
            let workFlowDetails = this.checkProperty( this.petition ,'workFlowDetails' ,"config");

             if(workFlowDetails){


                let adminsactiVityList = _.find(workFlowDetails , {"code":'MANAGER_LIST'});
                if(adminsactiVityList && adminsactiVityList.editors){
                    adminsList = _.map(adminsactiVityList.editors, 'roleId');
                }
                

                let avertismentActivity = _.find(workFlowDetails , {"code":'COLLECT_ADV_EVIDENCE'});
                if(avertismentActivity && avertismentActivity.editors){
                    jobAdvertismentActivity = _.map(avertismentActivity.editors, 'roleId');
                }
                adminsList.push(3);
                isAdmin =adminsList.indexOf(this.getUserRoleId) > -1;
                canEditPermAdvertisement =jobAdvertismentActivity.indexOf(this.getUserRoleId) > -1 || isAdmin;
                    
                }else if( this.checkProperty( this.petition, "actionUserIds" ,'length') >-1&& this.loadedFromPwdLibrary  ){
                    adminsList.push(3);
                    isAdmin =adminsList.indexOf(this.getUserRoleId) > -1;
                    let actionUserIds = this.petition['actionUserIds'];
                    if(( this.petition['createdByRoleId'] != 3  )||  isAdmin ){
                        if(actionUserIds.indexOf(loginUserData['userId']) >-1 ||  isAdmin || this.petition['createdBy'] ==loginUserData['userId']){
                        
                            canEditPermAdvertisement =true;
                            
                        }
                        

                    }
                
                
                
                }


              if(canEditPermAdvertisement &&(
               this.getUserRoleId !=50 &&  
                (canEditPermAdvertisement || isAdmin)
                && this.petition.completedActivities.indexOf('COLLECT_ADV_EVIDENCE') >-1 
                
                
                )){
                    returnVal =true

              }

              return returnVal;


            },
            checkAllCasesPermAcknowladge(){
                let returnVal =true;
                
                if(this.loadedFromPwdLibrary && this.checkProperty(this.petition ,'petitionList' ,'length') >0){
                    let casList = _.filter(this.petition['petitionList'], (item)=>item.statusId>=21 );
                    if(casList && casList.length>0){
                        returnVal =false
                    }

                
                }
            return returnVal;

            },
           },
        props: {
            loadedFromPwdLibrary:{
                type: Boolean,
                default: false
            },
            petition: {
                type: Object,
                default: null
            },
            visastatuses: {
                type: Array,
                default: null
            }
        },
        components: {
            documentsListView,
            VuePerfectScrollbar,
            VueDocPreview,
            documentsView
        },
        methods: {
            download_or_view(value) {
            this.$emit('download_or_view' ,value);
         },
        //     download_or_view(value) {
        //     if (_.has(value, "path")) {
        //         value['url'] = value['path'];
        //         value['document'] = value['path'];
        //     }

        //     if (_.has(value, "url")) {
        //         value['path'] = value['url'];
        //         value['document'] = value['url'];
        //     }

        //     if (_.has(value, "document")) {
        //         value['path'] = value['document'];
        //         value['url'] = value['document'];
        //     }

        //     //   this.$emit('download_or_view',value);  
        //     if (this.docType == "office" || this.docType == "image") {
        //             value.url = value.url.replace(this.$globalgonfig._S3URL, "");
        //             value.url = value.url.replace(this.$globalgonfig._S3URLAWS, "");
        //             let postdata = {
        //                 keyName: value.url
        //             };
        //             this.$store.dispatch("getSignedUrl", postdata).then((response) => {
        //                 this.docValue = response.data.result.data;

        //                 if (this.docType == "office") {
        //                     this.docValue = encodeURIComponent(response.data.result.data);
        //                 }
        //                 this.docPrivew = true;
        //             });

        //     }else {
        //         this.downloads3file(value);
        //     }
        // },
        },
        mounted() {
           
        }
    };
    </script>
    