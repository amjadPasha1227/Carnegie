<template>
    <div class="pad20">
        <div class="opportunity_sec">
            <!-- <div class="opportunity-title">
                <h3>
                    Job Oppurtunity Information
                </h3>    
            </div> -->
        <div class="vx-row blockmargin main-list-panel" >
            <div class="vx-col md:w-1/2 w-full" v-if="checkProperty(petition,'jobOpportunityInfo' ,'jobTitle') && false">
                <div class="main-list">
                    <p>
                        Preferred Job Title
                        <span>{{checkProperty(petition,'jobOpportunityInfo' ,'jobTitle')}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full" v-if="checkProperty(petition,'jobOpportunityInfo' ,'preferredJobTitle') && false">
                <div class="main-list">
                    <p>
                        Job Title
                        <span>{{checkProperty(petition,'jobOpportunityInfo' ,'preferredJobTitle')}}</span>
                    </p>
                </div>
            </div>
    
            <!-- <template v-if="checkProperty(petition['jobOpportunityInfo'] ,'minDegreeDetails','name')">
                <div class="vx-col md:w-1/2 w-full" v-if="checkProperty(petition['jobOpportunityInfo'] ,'minDegreeDetails','name')">
                    <div class="main-list">
                        <p>
                            Education
                            <span>{{checkProperty(petition['jobOpportunityInfo'] ,'minDegreeDetails','name')}}</span>
                        </p>
                    </div>
                </div>
            </template> -->
            <div class="vx-col md:w-1/2 w-full" v-if="checkProperty(petition,'jobOpportunityInfo' ,'majorFieldsOfStudy') && false">
                <div class="main-list">
                    <p>
                       Major Field Of Study
                        <span >{{checkProperty(petition,'jobOpportunityInfo' ,'majorFieldsOfStudy')}}</span>
                    </p>
                </div>
            </div>
    
            <div class="vx-col  md:w-1/2 w-full" v-if="checkProperty(petition,'jobOpportunityInfo' ,'isTrainigRequired')">
                <div class="main-list">
                    <p>
                        Training required for the job opportunity
                        <span>{{checkProperty(petition,'jobOpportunityInfo' ,'isTrainigRequired')}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full" v-if="checkProperty(petition,'jobOpportunityInfo' ,'noOfTraningMonths') && checkProperty(petition,'jobOpportunityInfo' ,'isTrainigRequired')=='Yes'">
                <div class="main-list">
                    <p>
                        No of months of training required
                        <span>{{checkProperty(petition,'jobOpportunityInfo' ,'noOfTraningMonths')}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full" v-if="checkProperty(petition,'jobOpportunityInfo' ,'fieldOfTraining')">
                <div class="main-list">
                    <p>
                        Field of Training
                        <span>{{checkProperty(petition,'jobOpportunityInfo' ,'fieldOfTraining')}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full" v-if="checkProperty(petition,'jobOpportunityInfo' ,'isExpRequired')">
                <div class="main-list">
                    <p>
                        Experience in the job offered required for the job
                        <span>{{checkProperty(petition,'jobOpportunityInfo' ,'isExpRequired')}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full" v-if="checkProperty(petition,'jobOpportunityInfo' ,'noOfExpMonths') && checkProperty(petition,'jobOpportunityInfo' ,'isExpRequired') == 'Yes'">
                <div class="main-list">
                    <p>
                        No of months experience required
                        <span>{{checkProperty(petition,'jobOpportunityInfo' ,'noOfExpMonths')}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full" v-if="checkProperty(petition,'jobOpportunityInfo' ,'isAltFieldOfStudyAccept')">
                <div class="main-list">
                    <p>
                        Alternate field of study that is acceptable
                        <span>{{checkProperty(petition,'jobOpportunityInfo' ,'isAltFieldOfStudyAccept')}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full" v-if="checkProperty(petition,'jobOpportunityInfo' ,'altMajorFieldOfStudy')">
                <div class="main-list">
                    <p>
                        Alternate field of study 
                        <span>{{checkProperty(petition,'jobOpportunityInfo' ,'altMajorFieldOfStudy')}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full" v-if="checkProperty(petition,'jobOpportunityInfo' ,'isAltCombOfEduAndExpAccept')">
                <div class="main-list">
                    <p>
                        Alternate combination of education and experience that is acceptable
                        <span>{{checkProperty(petition,'jobOpportunityInfo' ,'isAltCombOfEduAndExpAccept')}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full" v-if="checkProperty(petition['jobOpportunityInfo'] ,'altLevelOfEduDetails','name')">
                <div class="main-list">
                    <p>
                        Alternate level of education required
                        <span>{{checkProperty(petition['jobOpportunityInfo'] ,'altLevelOfEduDetails','name')}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full" v-if="checkProperty(petition,'jobOpportunityInfo' ,'altAcceptExpInYears')">
                <div class="main-list">
                    <p>
                        No of years experience acceptable
                        <span>{{checkProperty(petition,'jobOpportunityInfo' ,'altAcceptExpInYears')}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full" v-if="checkProperty(petition,'jobOpportunityInfo' ,'foreignEduEqAccept')">
                <div class="main-list">
                    <p>
                        Foreign educational equivalent acceptable
                        <span>{{checkProperty(petition,'jobOpportunityInfo' ,'foreignEduEqAccept')}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full" v-if="checkProperty(petition,'jobOpportunityInfo' ,'isExpInAltOccuAccept')">
                <div class="main-list">
                    <p>
                        Experience in an alternate occupation acceptable
                        <span>{{checkProperty(petition,'jobOpportunityInfo' ,'isExpInAltOccuAccept')}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full" v-if="checkProperty(petition,'jobOpportunityInfo' ,'noOfExpMonthsInAltOccu')">
                <div class="main-list">
                    <p>
                        No of months experience in alternate occupation required
                        <span>{{checkProperty(petition,'jobOpportunityInfo' ,'noOfExpMonthsInAltOccu')}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full" v-if="checkProperty(petition,'jobOpportunityInfo' ,'jobTitleOfAcceptAltOccu')">
                <div class="main-list">
                    <p>
                        Job title of the acceptable alternate occupation
                        <span>{{checkProperty(petition,'jobOpportunityInfo' ,'jobTitleOfAcceptAltOccu')}}</span>
                    </p>
                </div>
            </div>
            <!-- <div class="vx-col md:w-1/2 w-full" v-if="checkProperty(petition,'jobOpportunityInfo' ,'jobDuties')">
                <div class="main-list">
                    <p>
                        Job Duties
                        <span>{{checkProperty(petition,'jobOpportunityInfo' ,'jobDuties')}}</span>
                    </p>
                </div>
            </div> -->
            <div class="vx-col md:w-1/2 w-full" v-if="checkProperty(petition,'jobOpportunityInfo' ,'jobOppoReqForNormalOccu')">
                <div class="main-list">
                    <p>
                        Job opportunity’s requirements normal for the occupation
                        <span>{{checkProperty(petition,'jobOpportunityInfo' ,'jobOppoReqForNormalOccu')}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full" v-if="checkProperty(petition,'jobOpportunityInfo' ,'isForiegnLangRequired')">
                <div class="main-list">
                    <p>
                        Knowledge of a foreign language required to perform the job duties
                        <span>{{checkProperty(petition,'jobOpportunityInfo' ,'isForiegnLangRequired')}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full" v-if="checkProperty(petition,'jobOpportunityInfo' ,'isApplInvolJobOppoInclCombOfOccu')" >
                <div class="main-list">
                    <p>
                        This application involve a job opportunity that includes a combination of occupations
                        <span>{{checkProperty(petition,'jobOpportunityInfo' ,'isApplInvolJobOppoInclCombOfOccu')}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full" v-if="checkProperty(petition,'jobOpportunityInfo' ,'positionOfferToAlien')">
                <div class="main-list">
                    <p>
                        The position identified in this application being offered to the alien identified 
                        <span>{{checkProperty(petition,'jobOpportunityInfo' ,'positionOfferToAlien')}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full" v-if="checkProperty(petition,'jobOpportunityInfo' ,'alienReqToLiveEmplrPrimisis')">
                <div class="main-list">
                    <p>
                        The job require the alien to live on the employer’s premises
                        <span>{{checkProperty(petition,'jobOpportunityInfo' ,'alienReqToLiveEmplrPrimisis')}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full" v-if="checkProperty(petition,'jobOpportunityInfo' ,'applLiveInHouseDomWorker')">
                <div class="main-list">
                    <p>
                        The application for a live-in household domestic service worker
                        <span>{{checkProperty(petition,'jobOpportunityInfo' ,'applLiveInHouseDomWorker')}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full" v-if="checkProperty(petition,'jobOpportunityInfo' ,'emplrProviedAlienCopyOfContract') && checkProperty(petition,'jobOpportunityInfo' ,'applLiveInHouseDomWorker')=='Yes'">
                <div class="main-list">
                    <p>
                        The employer and the alien executed the required employment contract and has the employer provided a copy of the contract to the alien
                        <span>{{checkProperty(petition,'jobOpportunityInfo' ,'emplrProviedAlienCopyOfContract')}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col w-full" v-if="checkProperty(petition,'jobOpportunityInfo' ,'jobDuties')">
                <div class="main-list d-block">
                    <p>
                        Job Duties
                        <span class="d-block" v-html="checkProperty(petition,'jobOpportunityInfo' ,'jobDuties')"></span>
                    </p>
                </div>
            </div>

            
            

            
        </div>
        
        <template v-if="checkProperty(petition,'jobOpportunityInfo' ,'workAddresses') && checkProperty(petition['jobOpportunityInfo'] ,'workAddresses' ,'length') >0 && false">
            <div class="devider w-full"></div>
            <div class="vx-row m-0 main-list-panel">
                <h5 class="names_title">Address</h5>
                <div class="dependent-block_wrap address_info_wrap">
                <div class="vx-col  w-full p-0" >
                    <div class="dependent-block" :key="index" v-for="(item,index) in petition.jobOpportunityInfo.workAddresses">
                        <div class="address_info">
                    <div class="dependent-title"><h3>{{checkProperty(item,'companyName')}}</h3></div>
                    <em v-if="checkProperty(item,'workLocation')">Work Location </em>
                    <span class="address" v-html="$options.filters.addressformat(item)"></span>
                  </div> 
                        <!-- <div class="dependent-block">
                            <div class="dependent-title" v-if="checkProperty(item,'companyName')" >
                                <h3>
                                    {{checkProperty(item,'companyName')}}
                                </h3>

                            </div>
                            <div class="dependent_details">
                                <ul>
                                    <li v-if="checkProperty(item,'workLocation')"> Work Location 
                                        <span v-if="checkProperty(item,'workLocation')">Yes</span>
                                        <span v-else>No</span>
                                    </li>
                                    <li v-if="checkProperty(item,'line1')"> Street Address<span>{{checkProperty(item,'line1')}}</span></li>
                                    <li v-if="checkProperty(item,'line2')"> Apt, Suite <span>{{checkProperty(item,'aptType')}}{{checkProperty(item,'line2')}}</span></li>
                                    <li v-if="checkProperty(item,'countryDetails','name')"> Country<span>{{checkProperty(item,'countryDetails','name')}}</span></li>
                                    <li v-if="checkProperty(item,'stateDetails','name')"> State<span>{{checkProperty(item,'stateDetails','name')}}</span></li>
                                    <li v-if="checkProperty(item,'locationDetails','name')"> Location <span>{{checkProperty(item,'locationDetails','name')}}</span></li>
                                </ul>
                            </div>
                        </div> -->
                    </div>
                </div>
              </div>
            </div>
        </template>

        <template v-if="checkProperty(petition,'jobOpportunityInfo' ,'skills') && checkProperty(petition['jobOpportunityInfo'] ,'skills' ,'length') >0 && false">
            <div class="vx-row m-0 main-list-panel">
                <h5 class="names_title">Skills</h5>
                <ul class="uploaded-list">
                <template v-for="(item , ind)  in petition['jobOpportunityInfo']['skills']">
                        <vs-chip
                            :key="ind"
                        >
                            {{ item}}
                        </vs-chip>
                    </template>
                </ul>

                

                

            </div>
        </template>
        </div>
    </div>
    </template>
    
    <script>
    export default {
        props: {
            petition: {
                type: Object,
                default: null
            },
            visastatuses: {
                type: Array,
                default: null
            }
        },
        computed: {
            showRouteName(){
                if(this.$route.name == 'questionnaire'){
                    return false
                }
                else{
                    return true
                }
            }
        }
    };
    </script>
    