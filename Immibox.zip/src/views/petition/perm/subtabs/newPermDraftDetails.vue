<template>
    <div class="main-list-wrap petition_details_wrap">
    <div class="pad20">  
<div class="relative d-flex justify-end" v-if="canPermDraftSuggession || canApprovePermApplication || canUpdatePermQuestionnaire  ">
     
    <vs-button v-if="canPermDraftSuggession"  :disabled="updating" @click="$refs['actioPopups'].openPermJobDescActionsModal('PERM_DRAFT_SUGGESSION')" class="light-blue-btn btn_primary ml-2">Suggest Changes / Approve PERM Draft</vs-button>
    <vs-button v-else-if="canApprovePermApplication" @click="$refs['actioPopups'].openPermJobDescActionsModal('APPROVE_PERM_APPLICATION')" class="light-blue-btn btn_primary ml-2">Approve PERM Application</vs-button>
    <vs-button   v-if="canUpdatePermQuestionnaire"  :disabled="updating" @click="editQuestionnaire('PERM_DRAFT_SUGGESSION')"  class="light-blue-btn btn_primary ml-2">Update PERM Questionnaire</vs-button>
     
</div>



        <div class="vx-row m-0 main-list-panel" >
            <h5 class="names_title">Alien Information</h5>
            <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'alienInfo' ,'isTrainigRequired')">
                <div class="main-list">
                    <p>
                        Training required for the job opportunity
                        <span>{{checkProperty(petition,'alienInfo' ,'isTrainigRequired')}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'alienInfo' ,'isExpRequired')">
                <div class="main-list">
                    <p>
                        Experience in the job offered required for the job
                        <span >{{checkProperty(petition,'alienInfo' ,'isExpRequired')}}</span>
                    </p>
                </div>
            </div>
    
            <div class="vx-col  md:w-1/2 w-full p-0" v-if="checkProperty(petition,'alienInfo' ,'isAltCombOfEduAndExpAccept')">
                <div class="main-list">
                    <p>
                        Alternate combination of education and experience that is acceptable
                        <span>{{checkProperty(petition,'alienInfo' ,'isAltCombOfEduAndExpAccept')}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'alienInfo' ,'isExpInAltOccuAccept')">
                <div class="main-list">
                    <p>
                        Experience in an alternate occupation acceptable
                        <span>{{checkProperty(petition,'alienInfo' ,'isExpInAltOccuAccept')}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'alienInfo' ,'hasGainAnyExpWithEmplr')">
                <div class="main-list">
                    <p>
                        The alien gain any of the qualifying experience with the employer in a position substantially comparable to the job opportunity requested
                        <span>{{checkProperty(petition,'alienInfo' ,'hasGainAnyExpWithEmplr')}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'alienInfo' ,'didEmplrPayForEdu')">
                <div class="main-list">
                    <p>
                        The employer pay for any of the alien’s education or training necessary to satisfy any of the employer’s job requirements for this position
                        <span>{{checkProperty(petition,'alienInfo' ,'didEmplrPayForEdu')}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'alienInfo' ,'isWorkingWithPetngEmplr')">
                <div class="main-list">
                    <p>
                        The alien currently employed by the petitioning employer
                        <span>{{checkProperty(petition,'alienInfo' ,'isWorkingWithPetngEmplr')}}</span>
                    </p>
                </div>
            </div>  
        </div> 

        <div class="vx-row m-0 main-list-panel" >
            <h5 class="names_title">Refilling Information</h5>
            <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'refilingInstructions' ,'useFilingDateFromPrevSubtn')">
                <div class="main-list">
                    <p>
                        Are you seeking to utilize the filing date from a previously submitted application for Alien Employement Certification (ETA 750)
                        <span>{{checkProperty(petition,'refilingInstructions' ,'useFilingDateFromPrevSubtn')}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full p-0" v-if="checkProperty(petition,'refilingInstructions' ,'prevFilingDate')">
                <div class="main-list">
                    <p>
                        Previous filing date 
                        <span >{{checkProperty(petition,'refilingInstructions' ,'prevFilingDate')|formatDate}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col  md:w-1/2 w-full p-0" v-if="checkProperty(petition,'refilingInstructions' ,'prevSWAOrLocalCaseNo')">
                <div class="main-list">
                    <p>
                        The previous SWA or local office case number OR if not available, specify state where case was originally filed 
                        <span>{{checkProperty(petition,'refilingInstructions' ,'prevSWAOrLocalCaseNo')}}</span>
                    </p>
                </div>
            </div>
        </div>
        <actionsPopup v-if="petition" @updatepetition="updatePet" :workFlowDetails="workFlowDetails" ref="actioPopups" :petitionDetails="petition" />
   

    </div>
</div>
    </template>
    
    <script>
import { formatDate } from 'tough-cookie';
import actionsPopup from "@/views/common/actionsPopup.vue";
    export default {
        components: {
      
         actionsPopup
         
      },
        props: {
            petition: {
                type: Object,
                default: null
            },
            workFlowDetails: {
                type: Object,
                default: null
            },
            visastatuses: {
                type: Array,
                default: null
            }
        },
        computed: {
            canUpdatePermQuestionnaire(){
         let canPreParePermApplication = this.preparePermActivity.indexOf(this.getUserRoleId) > -1; 
         if ( (canPreParePermApplication || this.isAdmin) 
          && (this.petition.nextWorkflowActivity.indexOf('REQUEST_PERM_DRAFT_REVIEW')>-1 || this.petition.nextWorkflowActivity.indexOf('APPROVE_PERM_APPLICATION')>-1 ) 
          && this.petition.completedActivities.indexOf('REQUEST_PERM_DRAFT_REVIEW')>-1 
          && this.petition.completedActivities.indexOf('APPROVE_PERM_APPLICATION')<=-1 
          && this.isActiveCode("PREPARE_PERM_APPLICATION") 
          && this.petition.completedActivities.indexOf('PREPARE_PERM_APPLICATION')>-1 ){
             return true
          }else{ 
            return false
         }

      },
            canPermDraftSuggession(){
         let canPreParePermApplicationSuggssion = this.permSuggssitionActivity.indexOf(this.getUserRoleId) > -1; 
         if (( this.petition.completedActivities.indexOf('APPROVE_PERM_APPLICATION')<=-1 
          &&  this.isActiveCode("APPROVE_PERM_APPLICATION") && (canPreParePermApplicationSuggssion ) 
          && this.petition.completedActivities.indexOf('PREPARE_PERM_APPLICATION')>=0 ) 
          && this.checkProperty(this.petition ,'curWorkflowActivity') !='PERM_DRAFT_SUGGESSION' ){
            return true;
          }else{
            return false;
          } 
      },
            canApprovePermApplication(){

                
         let canPreParePermApplicationSuggssion = this.permSuggssitionActivity.indexOf(this.getUserRoleId) > -1; 
         let canApprovePermApplication = this.approvePermApplication.indexOf(this.getUserRoleId) > -1; 

         if (
            (
              this.petition.completedActivities.indexOf('EFILE_PREM_APPLICATION')>-1  
                 && this.isActiveCode("APPROVE_PERM_APPLICATION") 
              && (canApprovePermApplication || this.isAdmin) 
              && this.petition.completedActivities.indexOf('PREPARE_PERM_APPLICATION')>0 
             && this.petition.completedActivities.indexOf('APPROVE_PERM_APPLICATION')<=-1
          )&& !(
                ( this.petition.completedActivities.indexOf('APPROVE_PERM_APPLICATION')<=-1 
                  &&  this.isActiveCode("APPROVE_PERM_APPLICATION") && (canPreParePermApplicationSuggssion ) 
                  && this.petition.completedActivities.indexOf('PREPARE_PERM_APPLICATION')>=0 
                ) 
               && this.checkProperty(this.petition ,'curWorkflowActivity') !='PERM_DRAFT_SUGGESSION'
             
             ) 
          
          ){

           return true
          }else{
            return false
          }
      },
            showRouteName(){
                if(this.$route.name == 'questionnaire'){
                    return false
                }
                else{
                    return true
                }
            }
        },
        methods:{

            editQuestionnaire(activityCode=''){
     
     if([3].indexOf(this.checkProperty(this.petition,'typeDetails', 'id' )) >-1 && [15].indexOf(this.checkProperty(this.petition,'subTypeDetails', 'id' )) >-1){
       
       if(activityCode =="PREPARE_PERM_APPLICATION"){
         this.$router.push("/permapplication-questionnaire/"+this.petition._id+"?fromedit=true");
       }else  if(activityCode =="PERM_DRAFT_SUGGESSION"){
         this.$router.push("/permapplicationSuggession-questionnaire/"+this.petition._id+"?fromedit=true");
        
       }else{
         this.$router.push("/perm-questionnaire/"+this.petition._id+"?fromedit=true");

       }
       
      
       //permapplication-questionnaire/
       //permapplicationSuggession-questionnaire
      
     }else{
       this.$router.push("/questionnaire/"+this.petition._id+"?fromedit=true");
     }
   
         },

            isActiveCode(listcode){
                if(this.workFlowDetails && this.checkProperty( this.workFlowDetails ,'config')){
                    let activytList =  _.find(this.workFlowDetails.config , {"code":listcode}); 
                if(activytList && activytList['include'] == 'Yes') return true;
                    return false;
                }
            },
            updatePet(){
            this.$emit("updatepetition", "Case Details");
            },
            init(){
                if(this.workFlowDetails && this.checkProperty(this.workFlowDetails ,'config' ,'length' )>0){
            let permSuggssitionActivity = _.find(this.workFlowDetails.config , {"code":'PERM_DRAFT_SUGGESSION'});
            permSuggssitionActivity = _.find(this.workFlowDetails.config , {"code":'APPROVE_JOB_DESC'});
            if(permSuggssitionActivity && permSuggssitionActivity.editors){
            this.permSuggssitionActivity = _.map(permSuggssitionActivity.editors, 'roleId');
            }


               let adminsactiVityList = _.find(this.workFlowDetails.config , {"code":'MANAGER_LIST'});
               if(adminsactiVityList && adminsactiVityList.editors){
               this.adminsList = _.map(adminsactiVityList.editors, 'roleId');
               }


            this.isAdmin = this.adminsList.indexOf(this.getUserRoleId) > -1

         let approvePermApplication = _.find(this.workFlowDetails.config , {"code":'APPROVE_PERM_APPLICATION'});
         if(approvePermApplication && approvePermApplication.editors){
            this.approvePermApplication = _.map(approvePermApplication.editors, 'roleId');
         }

            let preparePermActivity = _.find(this.workFlowDetails.config , {"code":'PREPARE_PERM_APPLICATION'});
            if(preparePermActivity && preparePermActivity.editors){
                this.preparePermActivity = _.map(preparePermActivity.editors, 'roleId');
            }

            let permDraftreview = _.find(this.workFlowDetails.config , {"code":'REQUEST_PERM_DRAFT_REVIEW'});
            if(permDraftreview && permDraftreview.editors){
               _.forEach(permDraftreview.editors ,(editor)=>{
                  this.preparePermActivity.push(editor['roleId'])
               });

            }

         let jobAdvertismentActivity = _.find(this.workFlowDetails.config , {"code":'COLLECT_ADV_EVIDENCE'});
         if(jobAdvertismentActivity && jobAdvertismentActivity.editors){
            this.approvedPwdReqForAdvEvidences = false;
         if(_.has(jobAdvertismentActivity ,'approvedPwdReqForAdvEvidences') && jobAdvertismentActivity['approvedPwdReqForAdvEvidences'] =='Yes'){
             this.approvedPwdReqForAdvEvidences = jobAdvertismentActivity['approvedPwdReqForAdvEvidences']==='Yes'?true:false;
         }
         this.jobAdvertismentActivity = _.map(jobAdvertismentActivity.editors, 'roleId');
         }
         }

            }
        },
        data: () => ({
        
         jobAdvertismentActivity:[],
         approvedPwdReqForAdvEvidences:false,
         preparePermActivity:[],
         approvePermApplication:[],
         openPermJobDescActions:false,
         permSuggssitionActivity:[],
         adminsList:[3,4],
         isAdmin:false,
       }),
       mounted() { 
        this.init();
        setTimeout(()=>{  this.init();  },100);
       }
    };
    </script>
    