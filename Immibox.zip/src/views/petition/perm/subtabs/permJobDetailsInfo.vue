<template>
    <div class="pad20" >
        <div class="relative d-flex justify-end mb-2"  >
            
                       
            
            <template v-if="canPermJobApprove && canSuggestJob">
               
                <vs-button style="height:28px" v-if="canPermJobApprove" @click="$emit('openActionMenu' ,'JOB_DESC_APPROVE_OR_SUGGESSION')"  class="light-blue-btn btn_primary ml-2">
                    Suggest Changes / Approve Job Description
               <!-----@click="$refs['actionsPopups'].openPermJobDescActionsModal('APPROVE_JOB_DESC')"-->
            </vs-button>

            </template>
            <template v-else-if="(canPermJobApprove || canSuggestJob )&& false">
                <vs-button v-if="canPermJobApprove" @click="$emit('openActionMenu' ,'APPROVE_JOB_DESC')"  class="light-blue-btn btn_primary ml-2">
                Approve Job Description sssss
               <!-----@click="$refs['actionsPopups'].openPermJobDescActionsModal('APPROVE_JOB_DESC')"-->
            </vs-button> 
            <vs-button v-if="canSuggestJob"    class="light-blue-btn btn_primary ml-2" @click="$emit('openActionMenu' ,'JOB_DESC_SUGGESSION')">
                Suggest changes to Job Description
               <!-----@click="$refs['actionsPopups'].openPermJobDescActionsModal('JOB_DESC_SUGGESSION')"-->
            </vs-button>
           </template>
           <template v-if="canFinailizeJobDesc || canEditJobDesc">
             <vs-button v-if="canFinailizeJobDesc"    @click="$emit('openActionMenu' ,'FINALIZE_JOB_DESC')"  class="light-blue-btn btn_primary ml-2">
                Finalize Job Description
               <!-----@click="$refs['actionsPopups'].openPermJobDescActionsModal('FINALIZE_JOB_DESC')"-->
            </vs-button>
            <vs-button v-else-if="canEditJobDesc"   @click="$emit('openActionMenu' ,'JOB_DESC_EDIT')" class="light-blue-btn btn_primary ml-2">
                Edit Job Description
               <!-----@click="$refs['actionsPopups'].openJobDescription('JOB_DESC_SUGGESSION')"-->
            </vs-button>
        </template>
            
            
            
         </div>
        <permJobDetailsInformation :visastatuses="visastatuses" :petition="petition"></permJobDetailsInformation>
        <template v-if="checkProperty(history,'length')>1">        
            <div class="vx-row m-0">
                <div class="divider w-full mt-1"></div>
                <div class="vx-col w-full p-0 edu-block" >
                    <div class="dependent-block_wrap">
                        <div class="dependent-block job_details_block">
                            <div class="dependent-title">
                            
                                <h3>
                                    Previous Versions
                                </h3>
                            </div>
                            <div class="accordian_block">
                                <vs-collapse accordion>
                                    <template  v-for="(item,index) in history" >

                                        <vs-collapse-item :key="index" v-if="index != removeIndexx && checkProperty(item ,'jobDetails','jobTitle') ">
                                        <template >

                                        <div slot="header" class="d_header_title">
                                            <h6>{{checkProperty(item ,'jobDetails','jobTitle')}}
                                            </h6>
                                            <small> <template v-if="checkProperty(item,'createdByName') "> Updated By<span> {{checkProperty(item,'createdByName')}} </span></template><template v-if="checkProperty(item,'createdByRoleName')"> <span>({{checkProperty(item,'createdByRoleName')}})</span></template><template v-if="checkProperty(item,'createdOn')"> On <span>{{item.createdOn | formatDateTime}}</span></template></small>
                                                
                                            
                                        </div>
                                        
                                        <permJobDetailsInformation :visastatuses="visastatuses" :petition="item"></permJobDetailsInformation>
                                        <!-- <permWageInfo :visastatuses="visastatuses" :petition="item"></permWageInfo>
                                        <permJobOppurtunity :visastatuses="visastatuses" :petition="item"></permJobOppurtunity> -->
                                        <label class="comment_label" v-if="checkProperty(item ,'comment')">Comments Suggested By Petitioner</label>
                                        <div class="comment-text" v-if="checkProperty(item ,'comment')">{{checkProperty(item ,'comment')?checkProperty(item ,'comment'):''}}</div>
                                    </template>
                                        <!------
                                        <div class="dependent_details">
                                                    <ul>
                                                        <li v-if="checkProperty(item ,'jobId')"> Job Id <span>{{checkProperty(item ,'jobId')}}</span></li>
                                                        <li v-if="checkProperty(item ,'noOfPositions')"> No Of Positions <span>{{checkProperty(item ,'noOfPositions')}}</span></li>
                                                        <li v-if="checkProperty(item ,'minDegreeDetails','name')"> Minimum Degree <span>{{checkProperty(item ,'minDegreeDetails','name')}}</span></li>
                                                        <li v-if="checkProperty(item ,'expInYears')"> Experience in years <span>{{checkProperty(item ,'expInYears')}}</span></li>
                                                        <li v-if="checkProperty(item ,'salary')"> Salary <span>{{checkProperty(item ,'salary')}}</span></li>
                                                        <li v-if="checkProperty(item ,'jobType')"> Job Type <span>{{checkProperty(item ,'jobType')}}</span></li>
                                                        <li v-if="checkProperty(item ,'jobShift')"> Job Shift <span>{{checkProperty(item ,'jobShift')}}</span></li>
                                                        <li v-if="checkProperty(item ,'hoursPerWeek')"> Hours Per Week <span>{{checkProperty(item ,'hoursPerWeek')}}</span></li>
                                                    </ul>
                                                    <h3 v-if="checkProperty(item ,'applicationInfo','jobStartsOn')" class="sub-title">Application Information</h3>
                                                    <ul>    
                                                            <li v-if="checkProperty(item ,'applicationInfo','applyByMail')"> Apply By Mail <span>{{checkProperty(item ,'applicationInfo','applyByMail')}}</span></li>
                                                            <li v-if="checkProperty(item ,'applicationInfo','jobStartsOn')"> Job Starts On<span>{{checkProperty(item ,'applicationInfo','jobStartsOn') | formatDate}}</span></li>
                                                            <li v-if="checkProperty(item ,'applicationInfo','jobEndOn')"> Job Starts On <span>{{checkProperty(item ,'applicationInfo','jobEndOn') | formatDate}}</span>
                                                            </li>
                                                        </ul>                        
                                        </div>
                                        <div class="editor_view_wrap" v-if="checkProperty(item ,'description','length')">
                                            <h3 class="sub-title">Job Description</h3>
                                            <div class="editor_view" v-html="checkProperty(item ,'description')"></div>
                                        </div>
                                        --->
                                    </vs-collapse-item>
                                    </template>
                            
                                    <!------
                                    
                                    <vs-collapse-item :key="index" v-for="(item,index) in history" >
                                        <div slot="header" class="d_header_title">
                                            <h6>Software
                                                <small>Sep 27, 2022</small>
                                            </h6>
                                                
                                            
                                        </div>
                                    
                                        
                                        <div class="comment-text">{{checkProperty(item ,'comment')?checkProperty(item ,'comment'):'Comment Text Here'}}</div>    
                                        
                                        <permWageInfo :visastatuses="visastatuses" :petition="item"></permWageInfo>
                                        <permJobOppurtunity :visastatuses="visastatuses" :petition="item"></permJobOppurtunity>
                                    
                                    </vs-collapse-item>
                                    <vs-collapse-item :key="index" v-for="(item,index) in history" >
                                        <div slot="header" class="d_header_title">
                                            <h6>Software
                                                <small>Sep 27, 2022</small>
                                            </h6>
                                                
                                            
                                        </div>
                                    
                                        
                                        <div class="comment-text">{{checkProperty(item ,'comment')?checkProperty(item ,'comment'):'Comment Text Here'}} </div>
                                    
                                        <permWageInfo :visastatuses="visastatuses" :petition="item"></permWageInfo>
                                        <permJobOppurtunity :visastatuses="visastatuses" :petition="item"></permJobOppurtunity>
                                        
                                    </vs-collapse-item>
                                -->
                                    
                                </vs-collapse>
                                <!-- <paginate  
                                v-model="page" :page-count="totalpages" :page-range="3"
                                :margin-pages="2" :click-handler="pageNate"
                                prev-class="vs-pagination--buttons btn-prev-pagination vs-pagination--button-prev"
                                next-class="vs-pagination--buttons btn-next-pagination vs-pagination--button-next" :prev-text="'<i></i>'"
                                :next-text="'<i></i>'" :container-class="'pagination vs-pagination--nav'" :page-class="'page-item'">
                                </paginate> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </template>
        
    </div>
    </template>
    
    <script>
        import Paginate from "vuejs-paginate";
        import permWageInfo from "@/views/petition/perm/subtabs/permWageInfo.vue";
        import permJobOppurtunity from "@/views/petition/perm/subtabs/permJobOppurtunity.vue";
        import permJobDetailsInformation from "@/views/petition/perm/subtabs/permJobDetailsInformation.vue";
    
    export default {

        computed:{
            checkAssignments(){
            let returnValue = true;
            if(this.workFlowDetails && _.has(this.workFlowDetails ,'config' )){
                let assignSuperVisorActiVity = _.find(this.workFlowDetails.config , {"code":'ASSIGN_SUPERVISOR' ,"include":'Yes'});
                let paralegalactiVity = _.find(this.workFlowDetails.config , {"code":'ASSIGN_PARALEGAL',"include":'Yes'});
                let attorneyactiVity = _.find(this.workFlowDetails.config , {"code":'ASSIGN_ATTORNEY',"include":'Yes'});
                let docm = _.find(this.workFlowDetails.config , {"code":'ASSIGN_DOCUMENTATION_MANAGER',"include":'Yes'});

            
                if(assignSuperVisorActiVity && this.checkProperty(assignSuperVisorActiVity, 'editors' ,'length')>0 && this.petition.completedActivities.indexOf('ASSIGN_SUPERVISOR') <= -1 ){
                returnValue =false;
                }
                if(paralegalactiVity && this.checkProperty(paralegalactiVity, 'editors' ,'length')>0 &&  this.petition.completedActivities.indexOf('ASSIGN_PARALEGAL') <= -1 ){
                returnValue =false;
                }
                if(attorneyactiVity && this.checkProperty(attorneyactiVity, 'editors' ,'length')>0 && this.petition.completedActivities.indexOf('ASSIGN_ATTORNEY') <= -1 ){
                returnValue =false;
                }

                if(docm && this.checkProperty(docm, 'editors' ,'length')>0 && this.petition.completedActivities.indexOf('ASSIGN_DOCUMENTATION_MANAGER') <= -1 ){
                returnValue =false;
                }
                if(!returnValue && this.checkProperty(this.workFlowDetails ,'workflowType') =="Free-Flow" ){
                    returnValue =true;
                }
                
            }


            return returnValue;

            },
            
            canFinailizeJobDesc(){
                let hasJobDetails =false;
            if(_.has(this.petition , 'hasJobDetails')){
                hasJobDetails = this.petition['hasJobDetails'];
            }
            let canFinnailizePermJob =this.finnailizePermJob.indexOf(this.getUserRoleId) > -1; 

                if (!hasJobDetails && this.checkAssignments && this.isActiveCode("FINALIZE_JOB_DESC") && (canFinnailizePermJob || this.isAdmin) && this.petition.completedActivities.indexOf('APPROVE_JOB_DESC') >-1 && this.petition.completedActivities.indexOf('FINALIZE_JOB_DESC') <=-1){
                    return true
                }else{
                    return false;
                }  


            },
            canEditJobDesc(){
                //APPROVE_JOB_DESC_EDIT
                let hasJobDetails =false;
            if(_.has(this.petition , 'hasJobDetails')){
                hasJobDetails = this.petition['hasJobDetails'];
            }
                
            let canPermJobApprove =this.permJobApprove.indexOf(this.getUserRoleId) > -1; 
            let canEditPermJobDesc =this.permJobDesEditorsList.indexOf(this.getUserRoleId) > -1;
                
                if ( !hasJobDetails && this.checkAssignments &&
                    ( this.jobdescriptionapprovallist.indexOf(this.getUserRoleId)<= -1 ) &&
                    (this.petition.nextWorkflowActivity.indexOf('REQUEST_JOB_DESC_REVIEW')<=-1 && this.isActiveCode("APPROVE_JOB_DESC") && (canPermJobApprove || this.isAdmin) && this.petition.completedActivities.indexOf('REQUEST_JOB_DESC_REVIEW') >-1 && this.petition.completedActivities.indexOf('APPROVE_JOB_DESC') <=-1 ) || (this.checkProperty(this.petition ,'curWorkflowActivity') =='JOB_DESC_SUGGESSION' ) && (canEditPermJobDesc || this.isAdmin)
                    || (this.checkProperty(this.petition ,'curWorkflowActivity') =='JOB_DESC_SUGGESSION' && (canEditPermJobDesc || this.isAdmin) )
                    ){

                    return true
                }else{ 

                    return false


                }
            },
            canReqJobDesReview(){
                let hasJobDetails =false;
                if(_.has(this.petition , 'hasJobDetails')){
                    hasJobDetails = this.petition['hasJobDetails'];
                }
                let canReqJobDesReview =this.reqJobDesReview.indexOf(this.getUserRoleId) > -1; 
                
                    if ( !hasJobDetails && this.checkAssignments &&  this.checkProperty(this.petition ,'curWorkflowActivity') !='REQUEST_JOB_DESC_REVIEW' &&  this.isActiveCode("REQUEST_JOB_DESC_REVIEW") && (canReqJobDesReview || this.isAdmin) && (this.petition.completedActivities.indexOf('CREATE_JOB_DESC') >-1 && this.petition.completedActivities.indexOf('APPROVE_JOB_DESC') <=-1) ){
                        return true;
                    }else{
                        return false;
                    } 


            },

            canSuggestJob(){
                if(this.checkProperty(this.petition ,'curWorkflowActivity') =='REQUEST_JOB_DESC_REVIEW' && this.jobdescriptionapprovallist.indexOf(this.getUserRoleId) > -1 ){

                    return true;
                }else{
                    return false;
                }
            },
            
            
            canPermJobApprove(){

                let hasJobDetails =false;
            if(_.has(this.petition , 'hasJobDetails')){
                hasJobDetails = this.petition['hasJobDetails'];
            }
            let canPermJobApprove =this.permJobApprove.indexOf(this.getUserRoleId) > -1; 

                if (!hasJobDetails && this.checkAssignments && this.isActiveCode("APPROVE_JOB_DESC") && (canPermJobApprove || this.isAdmin) && this.petition.completedActivities.indexOf('CREATE_JOB_DESC') >-1 && this.petition.completedActivities.indexOf('APPROVE_JOB_DESC') <=-1 ){
                    return true
                }else{
                    return false
                } 


            },
           

        },
        data: ()=>({
         permJobDesEditorsList:[],
         jobdescriptionapprovallist:[],
         reqJobDesReview:[],
         permJobApprove:[],
         finnailizePermJob:[],
         showPermApproveinfo:false,
         jobAdvertismentActivity:[],
         approvedPwdReqForAdvEvidences:false,
         preparePermActivity:[],
         approvePermApplication:[],
         openPermJobDescActions:false,
         permSuggssitionActivity:[],
         adminsList:[3,4],
         isAdmin:false,

            history:[],
            page:1,
            perPage:10000,
            petitionId:null,
            totalpages:0,
            removeIndexx:0,
        }),
        components: {
            Paginate,
            permWageInfo,
            permJobOppurtunity,
            permJobDetailsInformation
        },
        props: {
            workFlowDetails: {
                type: Object,
                default: null
            },
            petition: {
                type: Object,
                default: null
            },
            visastatuses: {
                type: Array,
                default: null
            }
        },
        methods: {
            isActiveCode(listcode){
                if(this.workFlowDetails && this.checkProperty( this.workFlowDetails ,'config')){
                    let activytList =  _.find(this.workFlowDetails.config , {"code":listcode}); 
                    if(activytList && activytList['include'] == 'Yes') return true;
                    return false;
                }
            },
            getJobHistory(){
                let Payload={
                    pwdId: '',
                    page: this.page,
                    perpage:this.perPage
                }
                if(this.checkProperty(this.petition,'pwdId')){
                    Payload['pwdId'] = this.checkProperty(this.petition,'pwdId')
                }else{
                    Payload['pwdId'] = this.checkProperty(this.petition,'_id')
                }
                let path= "/perm/job-desc-version-list";
                 path= "/pwd/job-desc-version-list";
                this.$store.dispatch("getList", {"data":Payload ,"path":path}).then(response => {
                    let list = response.list
                    _.forEach( list,(item) => {
                        item =Object.assign(item,{ 'show':false});
                    });
                    this.history = list;
                    if(this.history && this.checkProperty(this.history,'length')>1){
                        this.removeIndexx = parseInt(this.checkProperty(this.history,'length')) - 1
                    }
                    this.totalpages = Math.ceil(response.totalCount / this.perPage);
                })
            },
            pageNate(pageNum) {
                this.page = pageNum;
                this.getJobHistory();
            },
            init(){
                if(this.workFlowDetails && this.checkProperty(this.workFlowDetails ,'config' ,'length' )>0){

                    let permJobApprove = _.find(this.workFlowDetails.config , {"code":'APPROVE_JOB_DESC'});
                    if(permJobApprove && permJobApprove.editors){
                    this.permJobApprove = _.map(permJobApprove.editors, 'roleId');
                    }

                    let finnailizePermJob = _.find(this.workFlowDetails.config , {"code":'FINALIZE_JOB_DESC'});
                    if(finnailizePermJob && finnailizePermJob.editors){
                    this.finnailizePermJob = _.map(finnailizePermJob.editors, 'roleId');
                    }
                    let reqJobDesReview = _.find(this.workFlowDetails.config , {"code":'REQUEST_JOB_DESC_REVIEW'});
                    if(reqJobDesReview && reqJobDesReview.editors){
                        this.reqJobDesReview = _.map(reqJobDesReview.editors, 'roleId');
                    }

                    let jobdescriptionapprovallisteditors= _.find(this.workFlowDetails.config , {"code":'APPROVE_JOB_DESC'});

                    if(jobdescriptionapprovallisteditors && jobdescriptionapprovallisteditors.editors){
                       this.jobdescriptionapprovallist = _.map(jobdescriptionapprovallisteditors.editors, 'roleId');
                    }
            
                    let permJobDesEditorsList = _.find(this.workFlowDetails.config , {"code":'CREATE_JOB_DESC'});
                    if(permJobDesEditorsList && permJobDesEditorsList.editors){
                        this.permJobDesEditorsList = _.map(permJobDesEditorsList.editors, 'roleId');
                    }

                    let adminsactiVityList = _.find(this.workFlowDetails.config , {"code":'MANAGER_LIST'});
                    if(adminsactiVityList && adminsactiVityList.editors){
                    this.adminsList = _.map(adminsactiVityList.editors, 'roleId');
                    }
                    this.isAdmin = this.adminsList.indexOf(this.getUserRoleId) > -1


                }

            }
        },
        mounted(){
            if (this.petition && this.petition['_id']) {
                this.petitionId = this.petition['_id'];
                this.getJobHistory();
            } 
            this.init();
            setTimeout(()=>{
                this.init();
            });         
        }
    };
    </script>
    