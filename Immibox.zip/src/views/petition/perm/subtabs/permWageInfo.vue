<template>
    <div class="pad20" >
        <div class="vx-row m-0" v-if="checkProperty(petition,'wageInfo')" >
            <div class="vx-col w-full p-0  edu-block" >
                <div class="dependent-block_wrap">
                    <div class="dependent-block custom_list_block">
                        <div class="dependent-title">
                            <h3>
                                Wage Information
                            </h3>
                        </div>
                        <div class="dependent_details"> 
                            <ul>
                                <li v-if="checkProperty(petition['wageInfo'] ,'trackingNumber')"> Tracking No<span>{{checkProperty(petition['wageInfo'] ,'trackingNumber')}}</span></li>
                                <!-- <li v-if="checkProperty(petition['wageInfo'] ,'socDetails','name')">Preferred SOC Code <span>{{checkProperty(petition['wageInfo'] ,'socDetails','name')}}</span></li> -->
                                <li v-if="checkProperty(petition['wageInfo'] ,'preferredSocCodeDetails','name')">Preferred SOC Code <span class="d-flex">{{checkProperty(petition['wageInfo'] ,'preferredSocCodeDetails','name')}}<span v-if="checkProperty(petition['wageInfo'] ,'preferredSocCodeDetails','designation')">({{ checkProperty(petition['wageInfo'] ,'preferredSocCodeDetails','designation') }})</span></span></li>
                                <!-- <li v-if="checkProperty(petition['wageInfo'] ,'wageRate')">Preferred Wage Rate<span>{{checkProperty(petition['wageInfo'] ,'wageRate') | formatprice }}</span></li> -->
                                <li v-if="checkProperty(petition['wageInfo'] ,'preferredWageRate')">Preferred Wage Rate<span>{{checkProperty(petition['wageInfo'] ,'preferredWageRate') | formatprice }}</span></li>
                                <li v-if="checkProperty(petition['wageInfo'] ,'payFrequency')"> Pay Frequency<span>{{checkProperty(petition['wageInfo'] ,'payFrequency')}}</span></li>
                                <li v-if="checkProperty(petition['wageInfo'] ,'wageSource')">Source of Wage<span>{{checkProperty(petition['wageInfo'] ,'wageSource')}}</span></li>                     
                                <li v-if="checkProperty(petition['wageInfo'] ,'determinationDate')"> Wage Determination Date <span>{{checkProperty(petition['wageInfo'] ,'determinationDate') | formatDate}}</span></li>
                                <li v-if="checkProperty(petition['wageInfo'] ,'expirationDate')"> Expiry Date <span>{{checkProperty(petition['wageInfo'] ,'expirationDate') | formatDate}}</span></li>
                            </ul>  
                            <ul>
                                <li class="w-full" v-if="checkProperty(petition['wageInfo'] ,'wageSourceOtherDesc')"> Wage Source Description <span>{{checkProperty(petition['wageInfo'] ,'wageSourceOtherDesc')}}</span></li>
                            </ul>                   
                        </div>
                    </div>
                </div>
    
            </div>
        </div>
        <div class="vx-row m-0"  v-if="checkProperty(petition,'wageOfferInfo')">
            <div class="vx-col w-full p-0  edu-block" >
    
                <div class="dependent-block_wrap">
                    <div class="dependent-block custom_list_block">
                        <div class="dependent-title">
                            <h3>
                                Wage Offer Information
                            </h3>

                        </div>
                        
                        <div class="dependent_details">
                            <ul>
                                <li v-if="checkProperty(petition['wageOfferInfo'] ,'minWage')"> Minimum Wage<span>{{checkProperty(petition['wageOfferInfo'] ,'minWage') | formatprice }}</span></li>
                                <li v-if="checkProperty(petition['wageOfferInfo'] ,'maxWage')"> Maximum Wage <span>{{checkProperty(petition['wageOfferInfo'] ,'maxWage') | formatprice }}</span></li>
                                <li v-if="checkProperty(petition['wageOfferInfo'] ,'payFrequency')"> Pay Frequency<span>{{checkProperty(petition['wageOfferInfo'] ,'payFrequency')}}</span></li>
                            </ul>                     
                        </div>
                    </div>
                </div>
    
            </div>
        </div>
    </div>
    </template>
    
    <script>
    export default {
        props: {
            petition: {
                type: Object,
                default: null
            },
            visastatuses: {
                type: Array,
                default: null
            }
        },
        data: () => ({
            masterSocList: [],
            prefferedsocDetails:null,
        }),
        methods:{
            getMasterSocList(){
                let query = {};
                query["page"] = 1;
                query["perpage"] = 10000;
                query["matcher"] = { 
                    // "getInactiveListAlso": true
                    };
                query["category"] = "soc_codes";
                this.$store
                .dispatch("getMasterData", query)
                .then((response) => {
                    this.masterSocList = response.list;
                   
                    if(this.checkProperty(this.petition['wageInfo'] ,'preferredSocCode')){
                        this.prefferedsocDetails=_.find(this.masterSocList, {"id": this.petition['wageInfo']['preferredSocCode']});
                    }
                })
                .catch(() => {
                    this.masterSocList = [];
                });

            },
        },
        mounted(){
             this.getMasterSocList();
        }
    };
    </script>
    