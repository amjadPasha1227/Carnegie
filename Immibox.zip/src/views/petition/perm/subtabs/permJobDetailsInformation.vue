<template>
     <div class="vx-row m-0" v-if="checkProperty(petition,'jobDetails')">
            <div class="vx-col w-full p-0 edu-block">
                <div class="dependent-block_wrap">
                    <div class="dependent-block job_details_block">
                        <!-- <h5 class="names_title">
                            Job Information
                        </h5> -->
                        <div class="dependent_details">
                            <ul>
                                <!-- <li v-if="checkProperty(petition['jobDetails'] ,'jobId')"> Job ID <span>{{checkProperty(petition['jobDetails'] ,'jobId')}}</span></li>
                                <li v-if="checkProperty(petition['jobDetails'] ,'noOfPositions')"> No of Positions <span>{{checkProperty(petition['jobDetails'] ,'noOfPositions')}}</span></li>
                                
                                <li v-if="checkProperty(petition['jobDetails'] ,'minDegreeDetails','name')"> Minimum Education Level <span>{{checkProperty(petition['jobDetails'] ,'minDegreeDetails','name')}}</span></li>
                                <li v-else-if="getMinDegreeDetails"> Minimum Education Level <span>{{getMinDegreeDetails}}</span></li>

                                <li v-if="checkProperty(petition['jobDetails'] ,'expInYears')"> Experience in years <span>{{checkProperty(petition['jobDetails'] ,'expInYears')}}</span></li>
                                <li v-if="checkProperty(petition['jobDetails'] ,'salary')"> Salary <span>{{checkProperty(petition['jobDetails'] ,'salary') | formatprice}}</span></li> 
                                <li v-if="checkProperty(petition['jobDetails'] ,'jobType')"> Job Type <span>{{checkProperty(petition['jobDetails'] ,'jobType')}}</span></li>
                                <li v-if="checkProperty(petition['jobDetails'] ,'jobShift')"> Job Shift <span>{{checkProperty(petition['jobDetails'] ,'jobShift')}}</span></li>
                                <li v-if="checkProperty(petition['jobDetails'] ,'hoursPerWeek')"> Hours Per Week <span>{{checkProperty(petition['jobDetails'] ,'hoursPerWeek')}}</span></li>
                               </ul>
                               <ul >    
                                 <li v-if="checkProperty(petition['jobDetails'] ,'applicationInfo','applyByMail')"> Applied By Mail <span>{{checkProperty(petition['jobDetails'] ,'applicationInfo','applyByMail')}}</span></li>
                                <li v-if="checkProperty(petition['jobDetails'] ,'applicationInfo','jobStartsOn')"> Job Start Date<span>{{checkProperty(petition['jobDetails'] ,'applicationInfo','jobStartsOn') | formatDate}}</span></li>
                                <li v-if="checkProperty(petition['jobDetails'] ,'applicationInfo','jobEndOn')"> Job End Date <span>{{checkProperty(petition['jobDetails'] ,'applicationInfo','jobEndOn') | formatDate}}</span>
                                </li>  -->
                                <li v-if="checkProperty(petition['jobDetails'] ,'jobTitle')"> Job Title <span>{{checkProperty(petition['jobDetails'] ,'jobTitle')}}</span></li>
                                <li v-if="checkProperty(petition,'noOfPositions')"> Number of Positions <span>{{checkProperty(petition ,'noOfPositions')}}</span></li>
                                <li v-if="checkProperty(petition['jobDetails'] ,'wageRate')"> Prevailing Wage <span>{{checkProperty(petition['jobDetails'] ,'wageRate') | formatprice}}</span></li>
                                <li v-if="checkProperty(petition['jobDetails'] ,'socDetails','name')"> SOC Code  <span class="d-flex">{{checkProperty(petition['jobDetails'] ,'socDetails' ,'name')}}<span v-if="checkProperty(petition['jobDetails'] ,'socDetails','designation')">({{checkProperty(petition['jobDetails'] ,'socDetails','designation' )}})</span></span></li>
                                <li v-if="checkProperty(petition['jobDetails'] ,'socDetails','designation')"> SOC Occupation Title  <span>{{checkProperty(petition['jobDetails'] ,'socDetails','designation' )}}</span></li>
                                <li v-if="checkProperty(petition['jobDetails'] ,'preferredSocCodeDetails','name')"> Preferred SOC Code  <span class="d-flex">{{checkProperty(petition['jobDetails'] ,'preferredSocCodeDetails','name')}}<span v-if="checkProperty(petition['jobDetails'],'preferredSocCodeDetails','designation')">({{checkProperty(petition['jobDetails'],'preferredSocCodeDetails','designation')}})</span></span></li>
                                 <li v-if="checkProperty(petition['jobDetails'] ,'preferredSocCodeDetails','designation')"> Preferred SOC Occupation Title  <span>{{checkProperty(petition['jobDetails'],'preferredSocCodeDetails','designation')}}</span></li>
                                <li v-if="checkProperty(petition['jobDetails'] ,'classification')"> Classification <span>{{checkProperty(petition['jobDetails'] ,'classification')}}</span></li>
                              <li v-if="checkProperty(petition['jobDetails'] ,'minDegreeDetails' ,'name')">Minimum Education Details <span>{{checkProperty(petition['jobDetails'] ,'minDegreeDetails' , 'name')}}</span></li>
                                <li v-if="checkProperty(petition['jobDetails'] ,'majorFieldsOfStudy')"> Major Field of Study <span>{{checkProperty(petition['jobDetails'] ,'majorFieldsOfStudy')}}</span></li>
                                <li v-if="checkProperty(petition['jobDetails'] ,'expInYears')"> Experience in Months <span>{{checkProperty(petition['jobDetails'] ,'expInYears')}}</span></li>
                                <li v-if="checkProperty(petition,'pwdDocCaseNo')">PWD Number<span>{{ checkProperty(petition,'pwdDocCaseNo') }}</span></li>
                                </ul>
                               
                                <template >
                                    <ul style="padding-top:10px;margin-bottom:10px;border-top: 1px solid #CBD5E7;border-bottom: 1px solid #CBD5E7">
                                    <li v-if="checkProperty(petition['jobDetails'] ,'altJobRequirements','areAltSetsOfEducation')"> Are alternate sets of Education, Training, and/or Experience accepted <span>{{checkProperty(petition['jobDetails'],'altJobRequirements','areAltSetsOfEducation')}}</span></li>
                                    <template v-if="checkProperty(petition['jobDetails'],'altJobRequirements','areAltSetsOfEducation')=='Yes'">
                                        <li v-if="checkProperty(petition['jobDetails'] ,'altJobRequirements','altevelOfEducationDetails')">Alternate level of education<span>{{checkProperty(petition['jobDetails']['altJobRequirements'],'altevelOfEducationDetails','name')}}</span></li>
                                        <li v-if="checkProperty(petition['jobDetails'] ,'altJobRequirements','usDiplomaOrDegreeAccepted') && checkProperty(petition['jobDetails'] ,'altJobRequirements','altevelOfEducationDetails') ">Other Degree<span>{{checkProperty(petition['jobDetails']['altJobRequirements'],'usDiplomaOrDegreeAccepted')}}</span></li>
                                        <li v-if="checkProperty(petition['jobDetails'] ,'altJobRequirements','majorsOrFieldsOfStudyAccepted') && checkProperty(petition['jobDetails'] ,'altJobRequirements','altevelOfEducationDetails')">Majors Field of Other Degree<span>{{checkProperty(petition['jobDetails']['altJobRequirements'],'majorsOrFieldsOfStudyAccepted')}}</span></li>
                                     
                                    </template>
                                    <li v-if="checkProperty(petition['jobDetails'] ,'altJobRequirements','isAltTrainingForTheJobOpporAccepted')"> Alternate training for the job opportunity accepted <span>{{checkProperty(petition['jobDetails'],'altJobRequirements','isAltTrainingForTheJobOpporAccepted')}}</span></li>
                                    <template v-if="checkProperty(petition['jobDetails'],'altJobRequirements','isAltTrainingForTheJobOpporAccepted')=='Yes'">
                                        <li v-if="checkProperty(petition['jobDetails'] ,'altJobRequirements','noOfMonthsOfAltTrainingAccepted')">Alternative Training Experience in Months<span>{{checkProperty(petition['jobDetails'],'altJobRequirements','noOfMonthsOfAltTrainingAccepted')}}</span></li> 
                                        <li v-if="checkProperty(petition['jobDetails'] ,'altJobRequirements','filedsOrNamesOfTrainingAccepted')">Majors Field of Alternate Training Field<span>{{checkProperty(petition['jobDetails'],'altJobRequirements','filedsOrNamesOfTrainingAccepted')}}</span></li> 
                                    </template>

                                    
                                        <li v-if="checkProperty(petition['jobDetails'] ,'altJobRequirements','altEmpExpAccepted')">Alternate employment experience accepted<span>{{checkProperty(petition['jobDetails'],'altJobRequirements','altEmpExpAccepted')}}</span></li>
                                        <template v-if="checkProperty(petition['jobDetails'],'altJobRequirements','altEmpExpAccepted')=='Yes'">
                                            <li v-if="checkProperty(petition['jobDetails'] ,'altJobRequirements','noOfMonthsAltEmpExpAccepted')">Number of months of alternate experience<span>{{checkProperty(petition['jobDetails'],'altJobRequirements','noOfMonthsAltEmpExpAccepted')}}</span></li> 
                                        </template>
                                        <li v-if="checkProperty(petition['jobDetails'] ,'altJobRequirements','splSkillOrOtherRequi')">Does the employer require any specific or other requirements<span>{{checkProperty(petition['jobDetails'],'altJobRequirements','splSkillOrOtherRequi')}}</span> </li>
                                        <template v-if="checkProperty(petition['jobDetails'],'altJobRequirements','splSkillOrOtherRequi')=='Yes'">
                                            <li v-if="checkProperty(petition['jobDetails'] ,'altJobRequirements','ForeignLanguage')">Foreign language<span>{{checkProperty(petition['jobDetails'],'altJobRequirements','ForeignLanguage')}}</span></li>
                                            <li v-if="checkProperty(petition['jobDetails'] ,'altJobRequirements','LicenseCertification')">License/Certification<span>{{checkProperty(petition['jobDetails'],'altJobRequirements','LicenseCertification')}}</span></li>
                                            <li v-if="checkProperty(petition['jobDetails'] ,'altJobRequirements','residencyFellowship')">Residency/Fellowship<span>{{checkProperty(petition['jobDetails'],'altJobRequirements','residencyFellowship')}}</span></li>
                                            <li v-if="checkProperty(petition['jobDetails'] ,'altJobRequirements','otherSplSkillsOrRequi')">Other Special Skills or Requirements<span>{{checkProperty(petition['jobDetails'],'altJobRequirements','otherSplSkillsOrRequi')}}</span></li>
                                        </template>
                                </ul>
                                </template>
                            
                            <ul>
                                <li v-if="checkProperty(petition['jobDetails']['workAddresses'] ,'companyName')"> Company Name <span>{{checkProperty(petition['jobDetails']['workAddresses'] ,'companyName')}}</span></li>
                               
                                <li class="w-full" v-if="checkProperty(petition['jobDetails'] ,'skills' ,'length')>0">Skills
                                    <!-- <h3 class="small-header">Skills </h3> -->
                                    <ul class="default_list_items ddd" >
                                        <li v-for=" (skil ,ind) in petition['jobDetails']['skills']" :key="ind">
                                            <span>{{skil}}</span>,
                                        </li>
                                      <!-- <vs-chip v-for=" (skil ,ind) in petition['jobDetails']['skills']" :key="ind">{{skil}}</vs-chip> -->
                                    </ul>                                    
                                </li>
                                <li class="w-full" v-if="checkProperty(petition['jobDetails'] ,'description','length')">Job Description
                                    <div class="editor_view pb-0" v-html="checkProperty(petition['jobDetails'] ,'description')"></div>
                                </li>
                                
                                 <li class="w-full" v-if="checkProperty(petition['jobDetails']['workAddresses'][0],'line1')">Work Address 
                                    
                                    <!-- <h3 class="small-header">Work Address</h3> -->
                                        <ul class="w-full" v-for="(item,inder) in petition['jobDetails']['workAddresses']" :key="inder">
                                            <li class="w-full" v-if="item"><span v-html="$options.filters.addressformat(item)"></span>
                                            </li>
                                        </ul>
                              </li>
                                <!-- <li v-if="checkProperty(petition['jobDetails']['workAddresses'],'line1')"> line1 <span>{{checkProperty(petition['jobDetails']['workAddresses'] ,'line1')}}</span></li>
                                <li v-if="checkProperty(petition['jobDetails']['workAddresses'] ,'line2')"> line2 <span>{{checkProperty(petition['jobDetails']['workAddresses'] ,'line2')}}</span></li>
                                <li v-if="checkProperty(petition['jobDetails']['workAddresses'] ,'aptType')"> aptType <span>{{checkProperty(petition['jobDetails']['workAddresses'] ,'aptType')}}</span></li>
                                <li v-if="checkProperty(petition['jobDetails']['workAddresses'] ,'locationId')"> locationId <span>{{checkProperty(petition['jobDetails']['workAddresses'] ,'locationId')}}</span></li>
                                <li v-if="checkProperty(petition['jobDetails']['workAddresses'],'stateId')"> stateId <span>{{checkProperty(petition['jobDetails'] ,'stateId')}}</span></li>
                                <li v-if="checkProperty(petition['jobDetails']['workAddresses'] ,'countryId')"> countryId <span>{{checkProperty(petition['jobDetails']['workAddresses'] ,'countryId')}}</span></li>
                                <li v-if="checkProperty(petition['jobDetails']['workAddresses'] ,'zipcode')"> zipcode <span>{{checkProperty(petition['jobDetails']['workAddresses'] ,'zipcode')}}</span></li> -->
                              
                                <!-- <li v-if="checkProperty(petition['jobDetails']['workAddresses']['locationDetails'] ,'id')"> id <span>{{checkProperty(petition['jobDetails']['workAddresses']['locationDetails'] ,'id')}}</span></li>
                                <li v-if="checkProperty(petition['jobDetails']['workAddresses']['locationDetails'] ,'name')"> name <span>{{checkProperty(petition['jobDetails']['workAddresses']['locationDetails'] ,'name')}}</span></li>
                                <li v-if="checkProperty(petition['jobDetails']['workAddresses'] ['locationDetails'],'stateId')"> stateId <span>{{checkProperty(petition['jobDetails']['workAddresses']['locationDetails'] ,'stateId')}}</span></li>
                                <li v-if="checkProperty(petition['jobDetails']['workAddresses'] ['locationDetails'],'countryId')"> countryId <span>{{checkProperty(petition['jobDetails']['workAddresses']['locationDetails'] ,'countryId')}}</span></li> -->
                                
                            
                                <!-- <li v-if="checkProperty(petition['jobDetails']['workAddresses'] ['stateDetails'] ,'name')"> name <span>{{checkProperty(petition['jobDetails']['workAddresses']['stateDetails'] ,'name')}}</span></li>
                                <li v-if="checkProperty(petition['jobDetails'] ['workAddresses']['stateDetails'] ,'shortName')"> shortName <span>{{checkProperty(petition['jobDetails']['workAddresses']['stateDetails'] ,'shortName')}}</span></li>
                                <li v-if="checkProperty(petition['jobDetails']['workAddresses'] ['stateDetails'] ,'countryId')"> countryId <span>{{checkProperty(petition['jobDetails'] ['workAddresses']['stateDetails'],'countryId')}}</span></li> -->
                              
                           
                                <!-- <li v-if="checkProperty(petition['jobDetails']['workAddresses'] ['countryDetails'] ,'shortName')"> shortName <span>{{checkProperty(petition['jobDetails'] ['workAddresses']['countryDetails'] ,'shortName')}}</span></li>
                                <li v-if="checkProperty(petition['jobDetails'] ['workAddresses']['countryDetails'] ,'name')"> name <span>{{checkProperty(petition['jobDetails'] ['workAddresses']['countryDetails'] ,'name')}}</span></li>
                                <li v-if="checkProperty(petition['jobDetails']['workAddresses']['countryDetails'] ,'phoneCode')"> phoneCode <span>{{checkProperty(petition['jobDetails'] ['workAddresses']['countryDetails'] ,'phoneCode')}}</span></li>
                              
                                <li v-if="checkProperty(petition['jobDetails']['workAddresses']['countryDetails'] ,'currencySymbol')"> currencySymbol <span>{{checkProperty(petition['jobDetails'] ['workAddresses']['countryDetails'] ,'currencySymbol')}}</span></li>
                                <li v-if="checkProperty(petition['jobDetails'] ['workAddresses']['countryDetails'] ,'currencyCode')"> currencyCode <span>{{checkProperty(petition['jobDetails']  ['workAddresses']['countryDetails'],'currencyCode')}}</span></li>
                               -->
                               
                                <!-- <li v-if="checkProperty(petition['jobDetails'] ,'minDegreeDetails','name')"> Minimum Education Level <span>{{checkProperty(petition['jobDetails'] ,'minDegreeDetails','name')}}</span></li>
                                <li v-else-if="getMinDegreeDetails"> Minimum Education Level <span>{{getMinDegreeDetails}}</span></li> -->

                                <!-- <li class="w-full" v-if="checkProperty(petition['jobDetails'] ,'description','length')">Job Description
                                    <div class="editor_view" v-html="checkProperty(petition['jobDetails'] ,'description')"></div>
                                </li> -->

                            </ul>                        
                        </div>
                        <!-- <div class="editor_view_wrap" v-if="checkProperty(petition['jobDetails'] ,'description','length')">
                            <h3 class="sub-title">Job Description</h3>
                            <div class="editor_view" v-html="checkProperty(petition['jobDetails'] ,'description')"></div>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
</template>
<script>

import * as _ from "lodash";
    export default {
        props: {
            petition: {
                type: Object,
                default: null
            },
            visastatuses: {
                type: Array,
                default: null
            }
        },
        data: () => ({
            masterSocList: [],
            socDetails:null,
            prefferedsocDetails:null,
        }),
        computed:{
            getMinDegreeDetails(){
                //petition['jobDetails']['minDegree']
                 let returnVal ='';
                if( this.checkProperty(this.petition['jobDetails'] ,'minDegree') && !this.checkProperty(this.petition['jobDetails'] ,'minDegreeDetails','name') && this.checkProperty(this.petition,'highestDegreeList' ,'length')>0){
                    let eduDetails = _.find(this.petition['highestDegreeList'],{"id":this.petition['jobDetails']['minDegree']});
                    if(eduDetails && _.has(eduDetails ,'name')){
                        returnVal = eduDetails['name'];
                    }
                }
                return returnVal;
            }
        },
        methods:{
            getMasterSocList(){
                let query = {};
                query["page"] = 1;
                query["perpage"] = 10000;
                query["matcher"] = { 
                    // "getInactiveListAlso": true
                    };
                query["category"] = "soc_codes";
                this.$store
                .dispatch("getMasterData", query)
                .then((response) => {
                    this.masterSocList = response.list;
                    if(this.checkProperty(this.petition['jobDetails'] ,'socCode')){
                        this.socDetails = _.find(this.masterSocList, {"id": this.petition['jobDetails']['socCode']});
                    }
                    if(this.checkProperty(this.petition['jobDetails'] ,'preferredSocCode')){
                        this.prefferedsocDetails= _.find(this.masterSocList, {"id": this.petition['jobDetails']['preferredSocCode']});
                       
                    }
                })
                .catch(() => {
                    this.masterSocList = [];
                });

            },
        },
        mounted(){
             this.getMasterSocList();
        }
    }
</script>