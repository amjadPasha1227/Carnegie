<template>
    <div class="pad20">
        <div class="opportunity_sec">
            <!-- <div class="opportunity-title">
                <h3>
                    Job Oppurtunity Information
                </h3>    
            </div> -->
        <div class="vx-row blockmargin main-list-panel" >
            <div class="vx-col md:w-1/2 w-full" v-if="checkProperty(petition,'permEfileInfo' ,'classOfAdmission') ">
                <div class="main-list">
                    <p>
                        Class of Admission
                        <span>{{checkProperty(petition,'permEfileInfo' ,'classOfAdmission')}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full" v-if="checkProperty(petition,'permEfileInfo' ,'skillLevel') ">
                <div class="main-list">
                    <p>
                        Skills Level
                        <span>{{checkProperty(petition,'permEfileInfo' ,'skillLevel')}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full" v-if="checkProperty(petition,'permEfileInfo' ,'isEmployerInvolved')">
                <div class="main-list">
                    <p>
                        The employer a closely held corporation, partnership, or sole proprietorship in which the alien has an ownership interest, or is there a familial relationship between the owners, stockholders, partners, corporate officers, or incorporators, and the alien
                        <span>{{checkProperty(petition,'permEfileInfo' ,'isEmployerInvolved')}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/2 w-full" v-if="checkProperty(petition,'permEfileInfo' ,'supportOfAScheduleASheepherder')">
                <div class="main-list">
                    <p>
                        This application in support of a Schedule A or Sheepherder occupation
                        <span>{{checkProperty(petition,'permEfileInfo' ,'isEmployerInvolved')}}</span>
                    </p>
                </div>
            </div>
            
           
            
        </div>
        </div>
    </div>
    </template>
    
    <script>
    export default {
        props: {
            petition: {
                type: Object,
                default: null
            },
            visastatuses: {
                type: Array,
                default: null
            }
        },
        computed: {
            showRouteName(){
                if(this.$route.name == 'questionnaire'){
                    return false
                }
                else{
                    return true
                }
            }
        }
    };
    </script>
    