<template>
    <div class="pad20" >
        <div class="relative d-flex justify-end mb-2"  >
    <div class="vx-row m-0" v-if="checkProperty(petition,'jobDetails')">
           <div class="vx-col w-full p-0 edu-block">
               <div class="dependent-block_wrap">
                   <div class="dependent-block job_details_block">
                       <!-- <h5 class="names_title">
                           Job Information  
                       </h5> -->
                       <div class="dependent_details">
                           <ul v-if="false">
                               <li v-if="checkProperty(petition['jobDetails'] ,'jobTitle')"> Job Title <span>{{checkProperty(petition['jobDetails'] ,'jobTitle')}}</span></li>
                               <li v-if="checkProperty(petition['jobDetails'] ,'preferredSocCodeDetails')"> Preferred SOC Code  <span>{{checkProperty(petition['jobDetails'] ,'preferredSocCodeDetails' ,'name')}}</span></li>
                               <li v-if="checkProperty(petition['jobDetails'] ,'preferredSocOccuTitle')"> Preferred SOC Occupation Title  <span>{{checkProperty(petition['jobDetails'] ,'preferredSocOccuTitle')}}</span></li>
                               <li v-if="checkProperty(petition['jobDetails'] ,'socCodeDetails')"> SOC Code  <span>{{checkProperty(petition['jobDetails'] ,'socCodeDetails' ,'name')}}</span></li>
                               <li v-if="checkProperty(petition['jobDetails'] ,'socOccuTitle')"> SOC Title  <span>{{checkProperty(petition['jobDetails'] ,'socOccuTitle')}}</span></li>
                               <li v-if="checkProperty(petition['jobDetails'] ,'classification')"> Classification <span>{{checkProperty(petition['jobDetails'] ,'classification')}}</span></li>
                               <li v-if="checkProperty(petition['jobDetails'] ,'minDegreeDetails','name')"> Minimum Education Level <span>{{checkProperty(petition['jobDetails'] ,'minDegreeDetails','name')}}</span></li>
                               <li v-if="checkProperty(petition['jobDetails'] ,'majorFieldsOfStudy')"> Major Field of Study <span>{{checkProperty(petition['jobDetails'] ,'majorFieldsOfStudy')}}</span></li>
                               <li v-if="checkProperty(petition['jobDetails'] ,'expInYears')"> Experience in years <span>{{checkProperty(petition['jobDetails'] ,'expInYears')}}</span></li>
                               <li v-if="checkProperty(petition['jobDetails'] ,'wageRate')"> Preferred Wage Rate <span>{{checkProperty(petition['jobDetails'] ,'wageRate') | formatprice}}</span></li>
                               <li class="w-full" v-if="checkProperty(petition['jobDetails'] ,'skills' ,'length')>0">Skills
                                   <ul class="default_list_items ddd" >
                                       <li v-for=" (skil ,ind) in petition['jobDetails']['skills']" :key="ind">
                                           <span>{{skil}}</span>,
                                       </li>
                                   </ul>                                    
                               </li>
                               <li class="w-full" v-if="checkProperty(petition['jobDetails'] ,'description','length')">Job Description
                                   <div class="editor_view pb-0" v-html="checkProperty(petition['jobDetails'] ,'description')"></div>
                               </li>
                               
                               <li class="w-full" v-if="checkProperty(petition['jobDetails']['workAddresses'][0],'line1')">Work Address
                                    <ul class="w-full" v-for="(item,inder) in petition['jobDetails']['workAddresses']" :key="inder">
                                        <li class="w-full" v-if="item"><span v-html="$options.filters.addressformat(item)"></span></li>
                                    </ul>
                                </li>
                           </ul>
                           <ul>
                            <li v-if="checkProperty(petition['moreJobDetails'] ,'jobId')"> Job Id <span>{{checkProperty(petition['moreJobDetails'] ,'jobId')}}</span></li>
                            <li v-if="checkProperty(petition['moreJobDetails'] ,'noOfPositions')"> No of Positions <span>{{checkProperty(petition['moreJobDetails'] ,'noOfPositions')}}</span></li>
                            <li v-if="checkProperty(petition['moreJobDetails'] ,'salary')"> Salary <span>{{checkProperty(petition['moreJobDetails'] ,'salary') | formatprice}}</span></li> 
                            <li v-if="checkProperty(petition['moreJobDetails'] ,'jobType')"> Job Type <span>{{checkProperty(petition['moreJobDetails'] ,'jobType')}}</span></li>
                            <li v-if="checkProperty(petition['moreJobDetails'] ,'jobShift')"> Job Shift <span>{{checkProperty(petition['moreJobDetails'] ,'jobShift')}}</span></li>
                            <li v-if="checkProperty(petition['moreJobDetails'] ,'hoursPerWeek')"> Hours Per Week <span>{{checkProperty(petition['moreJobDetails'] ,'hoursPerWeek')}}</span></li>
                            <li v-if="checkProperty(petition['moreJobDetails'] ,'applicationInfo','applyByMail')"> Applied By Mail <span>{{checkProperty(petition['moreJobDetails'] ,'applicationInfo','applyByMail')}}</span></li>
                            <li v-if="checkProperty(petition['moreJobDetails'] ,'applicationInfo','jobStartsOn')"> Job Start Date<span>{{checkProperty(petition['moreJobDetails'] ,'applicationInfo','jobStartsOn') | formatDate}}</span></li>
                            <li v-if="checkProperty(petition['moreJobDetails'] ,'applicationInfo','jobEndOn')"> Job End Date <span>{{checkProperty(petition['moreJobDetails'] ,'applicationInfo','jobEndOn') | formatDate}}</span></li>
                           </ul>                        
                       </div>
                   </div>
               </div>
           </div>
       </div>
       </div>
       </div>
</template>
<script>

import * as _ from "lodash";
   export default {
       props: {
           petition: {
               type: Object,
               default: null
           },
           visastatuses: {
               type: Array,
               default: null
           }
       },
       computed:{
         
       },
       mounted(){
            
       }
   }
</script>