<template>
    <div class="main-list-wrap petition_details_wrap">
    
           
        
        <template >
           <div class="tab-inner-content tabs-nobg gc_emp_details_tab">
              <div class="tabs-content-panel tab-pad-wrap">
                    <div class="card-panels">
            <vs-tabs>
                <vs-tab  label="Alien Information"  >
                    <newPermDraftDetails :visastatuses="visastatuses" :petition="petition"></newPermDraftDetails>
                </vs-tab>

                <vs-tab  label="Job Oppurtunity Information"  >
                    <permJobOppurtunity :visastatuses="visastatuses" :petition="petition"></permJobOppurtunity>
                </vs-tab>
                <vs-tab  label="Other Information"  >
                    <permOtherJobDetails :visastatuses="visastatuses" :petition="petition"></permOtherJobDetails>
                </vs-tab>
            </vs-tabs>
          
            </div>
            </div>
            </div>
        </template>
    
    </div>
    </template>
    
    <script>
     import permOtherJobDetails from "@/views/petition/perm/subtabs/permOtherJobDetails.vue";
    import newPermDraftDetails from "@/views/petition/perm/subtabs/newPermDraftDetails.vue";
    import permJobOppurtunity from "@/views/petition/perm/subtabs/permJobOppurtunity.vue";
    
    
    export default {
        data: () => ({
    
            petitionhistory: [],
    
        }),
        computed: {
            checkTabs() {
              var petition = this.petition;
              if(  (petition.beneficiaryInfo.educations && petition.beneficiaryInfo.educations.length > 0 && petition.beneficiaryInfo.educations[0].name!=null && petition.beneficiaryInfo.educations[0].name!="")){
    
                return true
              }
                if(  (petition.beneficiaryInfo.prevEmploymentInfo && petition.beneficiaryInfo.prevEmploymentInfo.length > 0 && petition.beneficiaryInfo.prevEmploymentInfo[0].employerName && petition.beneficiaryInfo.prevEmploymentInfo[0].employerName!="")){
    
                return true
                }
                if(  (this.checkProperty(petition,'beneficiaryInfo' ,'nonImmPetitionsInfo')  && this.checkProperty(petition['beneficiaryInfo'] ,'nonImmPetitionsInfo' ,'length') > 0 && (this.checkProperty(petition.beneficiaryInfo.nonImmPetitionsInfo[0],'visastatuses') ||  this.checkProperty(petition.beneficiaryInfo.nonImmPetitionsInfo[0] ,'receiptNo')!="" || this.checkProperty(petition.beneficiaryInfo.nonImmPetitionsInfo[0] ,'petitionerName')!="" ))){
    
                return true
                }
              return false
            }
    
        },
        props: {
            workFlowDetails: {
                type: Object,
                default: null
            },
            petition: {
                type: Object,
                default: null
            },
            visastatuses: {
                type: Array,
                default: null
            }
        },
        components: {
            newPermDraftDetails,
            permJobOppurtunity,
            permOtherJobDetails
         
    
        },
        methods: {
            
        },
        mounted() {

        }
    };
    </script>
    