<template>
    <div class="main-list-wrap petition_details_wrap">
    
           
    
        <template v-if="checkTabs">
           <div class="tab-inner-content tabs-nobg gc_emp_details_tab">
              <div class="tabs-content-panel tab-pad-wrap">
                    <div class="card-panels">
            <vs-tabs>
                <vs-tab label="Personal">
                    <personalInfo :visastatuses="visastatuses" :petition="petition"></personalInfo>
    
                </vs-tab>
                <vs-tab label="Previous Spouse" v-if="checkProperty(petition,'beneficiaryInfo') && checkProperty(petition,'beneficiaryInfo','previousSpouse') && checkProperty(petition['beneficiaryInfo'],'previousSpouse','firstName')  ">
                    <previousSpouseDetails :visastatuses="visastatuses" :callFrom="'BENEFICIARY'" :questionnaireDetails="questionnaireDetails" :petition="petition['beneficiaryInfo']['previousSpouse']"></previousSpouseDetails>
                </vs-tab>
                <template v-if="(petition.beneficiaryInfo.educations && petition.beneficiaryInfo.educations.length > 0) ||(petition.beneficiaryInfo.vacationalOrTrainingInst && petition.beneficiaryInfo.vacationalOrTrainingInst.length > 0) ">
                   <vs-tab v-if=" (petition.beneficiaryInfo.educations && petition.beneficiaryInfo.educations.length > 0 && checkProperty(petition['beneficiaryInfo']['educations'][0], 'name')) || (petition.beneficiaryInfo.vacationalOrTrainingInst && petition.beneficiaryInfo.vacationalOrTrainingInst.length > 0 && checkProperty(petition['beneficiaryInfo']['vacationalOrTrainingInst'][0], 'name') )"  label="Education">
                    <educationInfo :visastatuses="visastatuses" :petition="petition"></educationInfo>
    
                </vs-tab>
            </template>
                <vs-tab v-if="petition.beneficiaryInfo.prevEmploymentInfo && petition.beneficiaryInfo.prevEmploymentInfo.length > 0 && petition.beneficiaryInfo.prevEmploymentInfo[0].employerName!=null && petition.beneficiaryInfo.prevEmploymentInfo[0].employerName!=''" label="Employment">
                    <employementInfo :visastatuses="visastatuses" :petition="petition"></employementInfo>
    
                </vs-tab>
    
                <vs-tab  v-if=" false && petition.beneficiaryInfo.nonImmPetitionsInfo && petition.beneficiaryInfo.nonImmPetitionsInfo.length >0 && petition.beneficiaryInfo.nonImmPetitionsInfo[0].petitionerName!=null "  label="Non Immigrant Petitions">
                    <nonImmigrantPetitionInformation  :visastatuses="visastatuses" :petition="petition"/>
                </vs-tab>
    
                <vs-tab  v-if="checkImmpetitionTab" label="Immigrant Petitions">
                    <ImmigrantPetitionInformation :questionnaireDetails="questionnaireDetails"  :visastatuses="visastatuses" :petition="petition"/>
                </vs-tab>
            </vs-tabs>  
    
            </div>
            </div>
            </div>
        </template>
        <template v-else>
          
            <div ><personalInfo :visastatuses="visastatuses" :petition="petition"></personalInfo></div>
        </template>
    
    </div>
    </template>
    
    <script>
    import previousSpouseDetails  from "@/views/petition/subtabs/previousSpouseDetails.vue"; 

    import VuePerfectScrollbar from "vue-perfect-scrollbar";
    //import personalInfo from "@/views/petition/subtabs/personalInfo.vue";
    import personalInfo from "@/views/petition/subtabs/personalInfoVer2.vue";
    import employementInfo from "@/views/petition/subtabs/employement.vue";
    import nonImmigrantPetitionInformation from "@/views/petition/subtabs/nonImmigrant.vue"; 
    import ImmigrantPetitionInformation from "@/views/petition/subtabs/immigrantpetitions.vue"; 
    
    import educationInfo from "@/views/petition/subtabs/educationsVersion2.vue";
    
    export default {
        data: () => ({
    
            petitionhistory: [],
    
        }),
        computed: {
            checkImmpetitionTab(){
                let retrunVal = false;
                var petition = this.petition;
                let self= this
                if(petition.beneficiaryInfo && petition.beneficiaryInfo.immPetitionInfo &&
                 (self.checkProperty(petition.beneficiaryInfo, 'immPetitionInfo', 'anyOtherAlienFiled') || self.checkProperty(petition.beneficiaryInfo, 'immPetitionInfo', 'employerName')||
                 self.checkProperty(petition.beneficiaryInfo, 'immPetitionInfo', 'filedDate') || self.checkProperty(petition.beneficiaryInfo, 'immPetitionInfo', 'rirOrRegularProcessing')||
                 self.checkProperty(petition.beneficiaryInfo, 'immPetitionInfo', 'rirOrRegularProcessing') || self.checkProperty(petition.beneficiaryInfo, 'immPetitionInfo', 'filedStateDetails')||
                 self.checkProperty(petition.beneficiaryInfo, 'immPetitionInfo', 'applCurStatus') || self.checkProperty(petition.beneficiaryInfo, 'immPetitionInfo', 'seekingFilednullforETA750'))){
                    retrunVal = true
                };
                return retrunVal
            },
            checkTabs() {
              var petition = this.petition;
              if(  (petition.beneficiaryInfo.educations && petition.beneficiaryInfo.educations.length > 0 && petition.beneficiaryInfo.educations[0].name!=null && petition.beneficiaryInfo.educations[0].name!="")){
    
                return true
              }
                if(  (petition.beneficiaryInfo.prevEmploymentInfo && petition.beneficiaryInfo.prevEmploymentInfo.length > 0 && petition.beneficiaryInfo.prevEmploymentInfo[0].employerName && petition.beneficiaryInfo.prevEmploymentInfo[0].employerName!="")){
    
                return true
                }
                if(  (this.checkProperty(petition,'beneficiaryInfo' ,'nonImmPetitionsInfo')  && this.checkProperty(petition['beneficiaryInfo'] ,'nonImmPetitionsInfo' ,'length') > 0 && (this.checkProperty(petition.beneficiaryInfo.nonImmPetitionsInfo[0],'visastatuses') ||  this.checkProperty(petition.beneficiaryInfo.nonImmPetitionsInfo[0] ,'receiptNo')!="" || this.checkProperty(petition.beneficiaryInfo.nonImmPetitionsInfo[0] ,'petitionerName')!="" ))){
    
                return true
                }
                if(this.checkImmpetitionTab){
                    return true
                }
              return false
            }
    
        },
        props: {
            petition: {
                type: Object,
                default: null
            },
            visastatuses: {
                type: Array,
                default: null
            },
            questionnaireDetails:{
                type: Array,
                default: null
            }
        },
        components: {
            previousSpouseDetails,
            nonImmigrantPetitionInformation,
            educationInfo,
            employementInfo,
            VuePerfectScrollbar,
            personalInfo,
            ImmigrantPetitionInformation
    
        },
        methods: {
            checPpriorPeriodOfStayInUS(data = []) {
                //enteredDate departedDate visaStatus
    
                if (data.length > 0) {
                    if (data.length == 1) {
    
                        if ((data[0].enteredDate != null && data[0].departedDate != null) || (data[0].visaStatus != '' && data[0].visaStatus != null)) {
    
                            return true;
                        } else {
                            return false;
                        }
    
                    } else {
                        return true;
    
                    }
    
                } else {
                    return false;
                }
    
            },
            gethistory() {
                this.$store
                    .dispatch("petitionhistory", this.petition._id)
                    .then(response => {
                        this.petitionhistory = response.result.list;
                    });
            },
            reloadPetition() {
                this.$store.dispatch("getpetition", this.petition._id).then(response => {
                    this.petition = response.data.result;
                    if (this.petition.lcaId != null) {
                        this.$store
                            .dispatch("fetchLcaDetails", this.petition.lcaId)
                            .then(response => {
                                this.lcaDetails = response.data.result;
                            });
                    }
                    let postDt = {
                        userId: '',
                        isRfeCase: false
                    }
                    if (_.has(this.petition, "rfeCase")) {
                        postDt['isRfeCase'] = this.petition['rfeCase']
                    }
                    postDt['userId'] = this.petition['userId'];
    
                    this.$store
                        .dispatch("getpetitionsdropdown", postDt)
                        .then(response => {
                            this.petitions = response;
                        });
                });
                this.$store.dispatch("petitionhistory", petitionId).then(response => {
                    this.petitionhistory = response.result.list;
                });
            },
        },
        mounted() {
            this.gethistory();
        }
    };
    </script>
    