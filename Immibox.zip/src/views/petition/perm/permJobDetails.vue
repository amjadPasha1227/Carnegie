<template>
    <div class="main-list-wrap petition_details_wrap">
    
           
        
        <template >
           <div class="tab-inner-content tabs-nobg gc_emp_details_tab">
              <div class="tabs-content-panel tab-pad-wrap">
                    <div class="card-panels">
            <vs-tabs>
                <!-- v-if="petition.jobDetails.length>0" --> 
                <vs-tab label="Job Description" >
                    <personalInfo @openActionMenu="openActionMenu" :workFlowDetails="workFlowDetails" :visastatuses="visastatuses" :petition="petition"></personalInfo>
    
                </vs-tab>
                <vs-tab label="Job Details" v-if="checkProperty(petition,'moreJobDetails') && checkProperty(petition['moreJobDetails'] ,'jobId')" >
                    <newPwdJobDetails :visastatuses="visastatuses" :petition="petition"></newPwdJobDetails>
    
                </vs-tab>
                <!-- v-if="petition.wageInfo && petition.wageOfferInfo.length > 0 " -->
                <vs-tab  label="Wage Information" v-if="checkProperty(petition['wageInfo'] ,'trackingNumber')"  >
                    <permWageInfo :visastatuses="visastatuses" :petition="petition"></permWageInfo>
                </vs-tab>
                <!-- v-if="petition.jobOpportunityInfo.length > 0 " -->
                <vs-tab  label="Job Oppurtunity Information" v-if="false" >
                    <permJobOppurtunity :visastatuses="visastatuses" :petition="petition"></permJobOppurtunity>
                </vs-tab>
            </vs-tabs>
          
            </div>
            </div>
            </div>
        </template>
    
    </div>
    </template>
    
    <script>
    import VuePerfectScrollbar from "vue-perfect-scrollbar";
    //import personalInfo from "@/views/petition/subtabs/personalInfo.vue";
    import personalInfo from "@/views/petition/perm/subtabs/permJobDetailsInfo.vue";
    import employementInfo from "@/views/petition/subtabs/employement.vue";
    import permJobOppurtunity from "@/views/petition/perm/subtabs/permJobOppurtunity.vue";
    import nonImmigrantPetitionInformation from "@/views/petition/subtabs/nonImmigrant.vue"; 
    import ImmigrantPetitionInformation from "@/views/petition/subtabs/immigrantpetitions.vue"; 
    import newPwdJobDetails from "@/views/petition/perm/subtabs/newPwdJobDetails.vue";
    import permWageInfo from "@/views/petition/perm/subtabs/permWageInfo.vue";
    
    export default {
        data: () => ({
    
            petitionhistory: [],
    
        }),
        computed: {
            checkTabs() {
              var petition = this.petition;
              if(  (petition.beneficiaryInfo.educations && petition.beneficiaryInfo.educations.length > 0 && petition.beneficiaryInfo.educations[0].name!=null && petition.beneficiaryInfo.educations[0].name!="")){
    
                return true
              }
                if(  (petition.beneficiaryInfo.prevEmploymentInfo && petition.beneficiaryInfo.prevEmploymentInfo.length > 0 && petition.beneficiaryInfo.prevEmploymentInfo[0].employerName && petition.beneficiaryInfo.prevEmploymentInfo[0].employerName!="")){
    
                return true
                }
                if(  (this.checkProperty(petition,'beneficiaryInfo' ,'nonImmPetitionsInfo')  && this.checkProperty(petition['beneficiaryInfo'] ,'nonImmPetitionsInfo' ,'length') > 0 && (this.checkProperty(petition.beneficiaryInfo.nonImmPetitionsInfo[0],'visastatuses') ||  this.checkProperty(petition.beneficiaryInfo.nonImmPetitionsInfo[0] ,'receiptNo')!="" || this.checkProperty(petition.beneficiaryInfo.nonImmPetitionsInfo[0] ,'petitionerName')!="" ))){
    
                return true
                }
              return false
            }
    
        },
        props: {
            workFlowDetails: {
                type: Object,
                default: null
            },
            petition: {
                type: Object,
                default: null
            },
            visastatuses: {
                type: Array,
                default: null
            }
        },
        components: {
            permJobOppurtunity,
            permWageInfo,
            nonImmigrantPetitionInformation,
            newPwdJobDetails,
            employementInfo,
            VuePerfectScrollbar,
            personalInfo,
            ImmigrantPetitionInformation
    
        },
        methods: {
            openActionMenu(code=''){
               
                if(code){
                    this.$emit('openActionMenu' ,code);

                }

            },
            checPpriorPeriodOfStayInUS(data = []) {
                //enteredDate departedDate visaStatus
    
                if (data.length > 0) {
                    if (data.length == 1) {
    
                        if ((data[0].enteredDate != null && data[0].departedDate != null) || (data[0].visaStatus != '' && data[0].visaStatus != null)) {
    
                            return true;
                        } else {
                            return false;
                        }
    
                    } else {
                        return true;
    
                    }
    
                } else {
                    return false;
                }
    
            },
            gethistory() {
                this.$store
                    .dispatch("petitionhistory", this.petition._id)
                    .then(response => {
                        this.petitionhistory = response.result.list;
                    });
            },
            reloadPetition() {
                this.$store.dispatch("getpetition", this.petition._id).then(response => {
                    this.petition = response.data.result;
                    if (this.petition.lcaId != null) {
                        this.$store
                            .dispatch("fetchLcaDetails", this.petition.lcaId)
                            .then(response => {
                                this.lcaDetails = response.data.result;
                            });
                    }
                    let postDt = {
                        userId: '',
                        isRfeCase: false
                    }
                    if (_.has(this.petition, "rfeCase")) {
                        postDt['isRfeCase'] = this.petition['rfeCase']
                    }
                    postDt['userId'] = this.petition['userId'];
    
                    this.$store
                        .dispatch("getpetitionsdropdown", postDt)
                        .then(response => {
                            this.petitions = response;
                        });
                });
                this.$store.dispatch("petitionhistory", petitionId).then(response => {
                    this.petitionhistory = response.result.list;
                });
            },
        },
        mounted() {
            this.gethistory();
        }
    };
    </script>
    