<template>
    <div class="main-list-wrap">
    
       <div class="">
      
           <section >
           <template >
            
             
             <div class="case-approved-detailes gc-case perm-caseupdates"   >
                <!-- <h2 class="case-heading">{{checkProperty(petition ,'statusDetails' ,'name')}} </h2> -->

                <span class="error_info" v-if="preparePermApplicationDateValidationError && petition['completedActivities'].indexOf('PREPARE_PERM_APPLICATION')<=-1">{{preparePermApplicationDateValidationError}}</span>

                <div class="case-approved-body" v-if="petition['completedActivities'].indexOf('DOL_APPROVED')>-1 &&  petition['i140Case'] && petition['i140Case']['_id']!=null" >
                  <!----APPROVE_PERM_APPLICATION-->
                   <div class="left success">
                     <h5 class="success">Immigrant Petition (I-140) Created</h5>
                      <ul >
                         
                         <li>
                            <p>Created Date <span> {{petition['i140Case']['createdOn'] | formatDateTime}}</span></p>
                         </li>
                      
                      </ul>
                   </div>
                   <div class="right">
                      <ul >
                         <li>
                           <router-link :to="{ name: 'petition-details', params: { 'itemId':petition['i140Case']['_id'] }}">
                              View 
                              </router-link>
                           </li>
               
                      </ul>
                   </div>
                </div>
                <div class="case-approved-body" v-if="petition['completedActivities'].indexOf('DOL_APPROVED')>-1 && !petition['createCase'] && petition['i140notCreateReason']" >
                  <!----APPROVE_PERM_APPLICATION-->
                   <div class="left error">
                     <h5 class="success">Immigrant Petition (I-140) Not Created</h5>
                      <ul >
                        <li class="w-full" v-if="checkProperty(petition ,'i140notCreateComment' )">
                              <p class="comment-sec">Comments <span class="wrapall" v-html="checkProperty(petition ,'i140notCreateComment' )"></span></p>
                           </li>
                         
                         <li v-if="checkProperty(petition ,'i140CreateConfirmedOn' )">
                            <p>Updated Date <span> {{petition['i140CreateConfirmedOn'] | formatDateTime}}</span></p>
                         </li>
                         <li v-if="checkProperty(petition ,'i140notCreateReasonDetails' ,'name' )">
                            <p>Reason <span> {{checkProperty(petition ,'i140notCreateReasonDetails' ,'name' )}}</span></p>
                         </li>
                      
                      </ul>
                   </div>
                   <div class="right" >
                      <ul v-if="false" >
                         <li>
                           <router-link :to="{ name: 'petition-details', params: { 'itemId':petition['i140Case']['_id'] }}">
                              View 
                              </router-link>
                           </li>
               
                      </ul>
                   </div>
                </div>

                <div class="case-approved-body" v-if=" false && checkProperty(petition ,'completedActivities') && 
                (petition['completedActivities'].indexOf('DOL_APPROVED')>-1

               ||  petition['completedActivities'].indexOf('DOL_RECEIVED_RFE')>-1
               ||  petition['completedActivities'].indexOf('DOL_DENIED')>-1
               ||  petition['completedActivities'].indexOf('DOL_WITHDRAWN')>-1
               ||  petition['completedActivities'].indexOf('UPDATE_DOL_RESPONSE')>-1
                )" >
                  <!----UPDATE_DOL_RESPONSE //"DOL_APPROVED" / "DOL_RECEIVED_RFE" / "DOL_DENIED" / "DOL_WITHDRAWN"-->
                   <div class="left  " :class="{
                     'success':petition['completedActivities'].indexOf('DOL_APPROVED')>-1,
                     'error':petition['completedActivities'].indexOf('DOL_RECEIVED_RFE')>-1
                       || petition['completedActivities'].indexOf('DOL_DENIED')>-1 
                       || petition['completedActivities'].indexOf('DOL_WITHDRAWN')>-1


                   }">
                     <h5  class="success">
                        <template v-if="petition['completedActivities'].indexOf('DOL_APPROVED')>-1">   Approved</template>
                        <template v-else-if="petition['completedActivities'].indexOf('DOL_RECEIVED_RFE')>-1">   RFE Received </template>
                        <template v-else-if="petition['completedActivities'].indexOf('DOL_DENIED')>-1">   Denied </template>
                        <template v-else-if="petition['completedActivities'].indexOf('DOL_WITHDRAWN')>-1">   Withdrawn </template>
                       <template v-else>  DOL Response</template>
                     </h5>
                      <ul> 
                        <li v-if="getActionCompletedDate('UPDATE_DOL_RESPONSE')">
                           <p>Updated Date <span> {{getActionCompletedDate('UPDATE_DOL_RESPONSE') | formatDateTime}}</span></p>
                        </li>
                        <li v-if="checkProperty(petition ,'dolResponse' ,'issuedDate')">
                           <p>Receipt Date<br/><a >{{checkProperty(petition ,'dolResponse' ,'issuedDate') | formatDate}}</a></p>
                        </li>
                        <li v-if="checkProperty(petition ,'dolResponse' ,'receivedDate')">
                           <p>Received Date<br/><a >{{checkProperty(petition ,'dolResponse' ,'receivedDate') | formatDate}}</a></p>
                        </li>
                        <li v-if="checkProperty(petition ,'dolResponse' ,'dueDate')">
                           <p>Expiration Date<br/><a >{{checkProperty(petition ,'dolResponse' ,'dueDate') | formatDate}}</a></p>
                        </li>
                        
                        
                      
                      </ul>
                   </div>
                   <div class="right">
                    
                      <ul v-if="checkProperty(petition ,'dolResponse' ,'documents') && checkProperty(petition['dolResponse'] ,'documents' ,'length')>0  ">
                         <li v-if="false" class="cursor"><a  @click="downloadfile(petition.dolResponse.documents[0])"> View Details</a></li>
                         <li @click="downloadfile(petition.dolResponse.documents[0])">
                            <figure class="view-detailes_cnt"><img src="@/assets/images/download-white.svg"></figure>
                         </li>
                      </ul>
                   </div>
                </div>
               <!----Audit Report information SUBMIT_TO_DOL---->    
               <template v-if="checkProperty(petition, 'dolLogs' ,'length')>0">
                
                 <template v-for="( dollog ,index) in petition['dolLogs']">

                  <div :key="index"  class="case-approved-body"  >
                  
                   <div class="left " 
                   
                   :class="{
                     'success':checkProperty(dollog ,'action') ==='DOL_APPROVED',
                     'error':checkProperty(dollog ,'action') !='DOL_APPROVED' 


                   }"
                   >
                     <h5 class="success" >
                        <template v-if="checkProperty(dollog ,'action') =='DOL_AUDIT'"> DOL Audit</template>
                        <template v-else-if="checkProperty(dollog ,'action') =='DOL_SUPERVISORY_AUDIT'"> Supervisory Audit</template>
                        <template v-else-if="checkProperty(dollog ,'action') =='PREPARE_AUDIT_RESPONSE'"> DOL Audit Response</template>
                        <template v-else-if="checkProperty(dollog ,'action') =='SUBMIT_TO_DOL'">DOL Submit</template>
                        <template v-else-if=" checkProperty(dollog ,'action') =='DOL_APPROVED' ">   Certified</template>
                        <template v-else-if=" checkProperty(dollog ,'action') =='DOL_RECEIVED_RFE'">   RFE Received </template>
                        <template v-else-if="  checkProperty(dollog ,'action') =='DOL_DENIED'">   Denied </template>
                        <template v-else-if="checkProperty(dollog ,'action') =='DOL_WITHDRAWN'">   Withdrawn </template>
                        
                    

                     </h5>
                    
                      <ul >
                        <li v-if="checkProperty(dollog ,'startedOn') ">
                           <p>Updated Date<span> {{ dollog['startedOn'] | formatDateTime}}</span></p>
                        </li>
                        <template v-if="checkProperty(dollog ,'data')">
                           <li v-if="checkProperty(dollog ,'data' ,'uploadedOn' )">
                              <p>Updated Date <span> {{ dollog['data']['uploadedOn'] | formatDate}}</span></p>
                           </li>
                         <li v-if="checkProperty(dollog ,'data' ,'issuedDate')">
                           <p>Receipt Date<br/><a >{{checkProperty(dollog ,'data' ,'issuedDate') | formatDate}}</a></p>
                        </li>
                       
                        <li v-if="checkProperty(dollog ,'data' ,'receivedDate')">
                           <p>Received Date<br/><a >{{checkProperty(dollog ,'data' ,'receivedDate') | formatDate}}</a></p>
                        </li>
                        <li v-if="checkProperty(dollog ,'data' ,'dueDate')">
                           <p>Expiration Date<br/><a >{{checkProperty(dollog ,'data' ,'dueDate') | formatDate}}</a></p>
                        </li>
                        
                     </template>
                    
                      
                      </ul>
                   </div>
                   <div class="right" >
                      <ul >
                        
                        <li v-if="['PREPARE_AUDIT_RESPONSE' ,'DOL_AUDIT'].indexOf(checkProperty(dollog ,'action'))>-1"><a href="#" @click="reloadPetitionMe('Forms and Letters')"> View </a></li>
                         <li v-if="checkProperty(dollog ,'data' ,'documents') && checkProperty(dollog['data'] ,'documents' ,'length')>0" @click="downloadfile(dollog.data.documents[0])">
                            <figure class="view-detailes_cnt"><img src="@/assets/images/download-white.svg"></figure>
                         </li>
                      </ul>
                   </div>
                  </div>

                 </template>
               </template>

               <!----UPLOAD_PERM_ACK -->
               <div class="case-approved-body" v-if="checkProperty(petition ,'completedActivities') && (petition['completedActivities'].indexOf('UPLOAD_PERM_ACK')>-1 )" >
                  <!----FINALIZE_JOB_DESC-->
                   <div class="left success">
                     <h5 class="success"
                        
                         >
                         <!----PERM Acknowledgement Uploaded --->
                         PERM Submitted to DOL
                        </h5>
                      <ul >

                        <li class="w-full" v-if="getActivityComments('UPLOAD_PERM_ACK')">
                                 <p class="comment-sec">Comments  <span class="wrapall" v-html="getActivityComments('UPLOAD_PERM_ACK')"></span></p>
                              </li>
                         
                         <li v-if="getActionCompletedDate('UPLOAD_PERM_ACK')">
                            <p>Updated Date <span> {{getActionCompletedDate('UPLOAD_PERM_ACK') | formatDateTime}}</span></p>
                         </li>

                         <li v-if="getActivityByCode('UPLOAD_PERM_ACK') && checkProperty(getActivityByCode('UPLOAD_PERM_ACK') ,'data' ,'permApplicationNo' ) || checkProperty(petition ,'permApplicationNo') ">
                            <p v-if="getActivityByCode('UPLOAD_PERM_ACK') && checkProperty(getActivityByCode('UPLOAD_PERM_ACK') ,'data' ,'permApplicationNo' ) ">PERM Application No <span >
                               {{checkProperty(getActivityByCode('UPLOAD_PERM_ACK') ,'data' ,'permApplicationNo' ) }}
                              </span>
                           </p>
                            <p v-else-if="checkProperty(petition ,'permApplicationNo') ">PERM Application No <span >
                               {{checkProperty(petition ,'permApplicationNo') }}
                              </span>
                            </p>
                           </li>
                         
                      
                      </ul>
                   </div>
                   <div class="right" >
                     
                      <ul v-if="getActivityByCode('UPLOAD_PERM_ACK') && checkProperty(getActivityByCode('UPLOAD_PERM_ACK') ,'data' ,'documents' )  && checkProperty(getActivityByCode('UPLOAD_PERM_ACK').data ,'documents' ,'length' )">
                       
                         <li @click="downloadfile(getActivityByCode('UPLOAD_PERM_ACK').data.documents[0])">
                            <figure class="view-detailes_cnt"><img src="@/assets/images/download-white.svg"></figure>
                         </li>
                      </ul>
                   </div>
                </div>
                



                <div class="case-approved-body" v-if=" checkProperty(petition ,'completedActivities') && petition['completedActivities'].indexOf('APPROVE_PERM_APPLICATION')>-1" >
                  <!----APPROVE_PERM_APPLICATION-->
                   <div class="left success">
                     <h5 class="success">PERM Draft Approved </h5>
                      <ul >
                         
                        <!----hasAnyRelationWithBeneficiary-->
                        <li class="w-full d-block text-left" v-if="getHasAnyRelationWithBeneficiary('APPROVE_PERM_APPLICATION')">
                              <em><div class="ben_btn"><p>Do you have any relationship with the Beneficiary?</p><span :class="{'rejected':getHasAnyRelationWithBeneficiary('APPROVE_PERM_APPLICATION')=='No' , 'completed':getHasAnyRelationWithBeneficiary('APPROVE_PERM_APPLICATION')=='Yes' }"><em></em>{{getHasAnyRelationWithBeneficiary('APPROVE_PERM_APPLICATION') }} by Petitioner</span></div>
                                 <div class="relative" v-if="canPermDraftReviewRequest && (getHasAnyRelationWithBeneficiary('APPROVE_PERM_APPLICATION') =='Yes' &&  (!checkProperty( petition ,'reviewedBnfRelationInfo') || !checkProperty( petition ,'reviewedBnfRelationInfo' ,'reviewed')) )">
                                    <vs-button :disabled="updating" @click="approveParalegal(true)" class="light-blue-btn">Review</vs-button>
                                     <!--<span v-if="updating"  class="loader"><img src="@/assets/images/main/loader.gif"></span>-->
                                 </div>
                              </em>
                              <p v-if="(getHasAnyRelationWithBeneficiary('APPROVE_PERM_APPLICATION') =='Yes' && checkProperty( petition ,'reviewedBnfRelationInfo' ,'reviewed'))">
                                 
                                 <template v-if="checkProperty( petition,'reviewedBnfRelationInfo' ,'createdByName' )">
                                    Reviewed by {{checkProperty( petition,'reviewedBnfRelationInfo' ,'createdByName' )}} ({{checkProperty( petition,'reviewedBnfRelationInfo' ,'createdByRoleName' )}}) on 
                                    <template v-if="getActionCompletedDate('APPROVE_PERM_APPLICATION')">{{getActionCompletedDate('APPROVE_PERM_APPLICATION') | formatDateTime}}</template>
                                 </template>
                                 <template v-else>Review comments by Paralegal </template>

                              <span>Relationship has been considered and taken appropriate action by speaking to Petitioner</span></p>
                           </li>
                           <li class="w-full"  v-if="checkProperty( petition,'reviewedBnfRelationInfo' ,'comment' ) && (checkProperty(agingLog ,'data' ,'hasAnyRelationWithBeneficiary') =='Yes' && checkProperty( petition ,'reviewedBnfRelationInfo' ,'reviewed'))">
                                 <p class="comment-sec">Review Comments <span v-html="checkProperty(petition ,'reviewedBnfRelationInfo' ,'comment')"></span></p>
                           </li>

                       
                         <li v-if="getActionCompletedDate('APPROVE_PERM_APPLICATION')">
                            <p>Updated Date <span> {{getActionCompletedDate('APPROVE_PERM_APPLICATION') | formatDateTime}}</span></p>
                         </li>
                         
                      
                      </ul>
                   </div>
                   <div class="right">
                      <ul v-if="checkProperty(petition ,'rfeNotice' ,'documents') && false">
                         <li><a href="#" @click="downloadfile(petition.rfeNotice.documents[0])"> View Details</a></li>
                         <li @click="downloadfile(petition.rfeNotice.documents[0])">
                            <figure class="view-detailes_cnt"><img src="@/assets/images/download-white.svg"></figure>
                         </li>
                      </ul>
                   </div>
                </div>
                <template v-if=" checkProperty(petition ,'sponsorshipQuestionnaireSubmittedOn') && checkProperty(petition ,'completedActivities') && petition['completedActivities'].indexOf('EFILE_PREM_APPLICATION')>-1 && checkProperty(petition ,'sponsorshipQuestionnaireSubmitted' )">
                  <div class="case-approved-body"  >
                  <!----PREPARE_PERM_APPLICATION-->
                   <div class="left">
                     <h5 class="primary">Petitioner Responded to Sponsorship Questionnaire</h5>
                      <ul >
                         
                         <li v-if="checkProperty(petition ,'sponsorshipQuestionnaireSubmittedOn')">
                            <p>Updated Date <span> {{checkProperty(petition ,'sponsorshipQuestionnaireSubmittedOn') | formatDateTime}}</span></p>
                         </li>
                      
                      </ul>
                   </div>
                   <div class="right">
                      <ul v-if="checkProperty(petition ,'rfeNotice' ,'documents') && false">
                         <li><a href="#" @click="downloadfile(petition.rfeNotice.documents[0])"> View Details</a></li>
                         <li @click="downloadfile(petition.rfeNotice.documents[0])">
                            <figure class="view-detailes_cnt"><img src="@/assets/images/download-white.svg"></figure>
                         </li>
                      </ul>
                   </div>
                </div>
               </template>
              <!----REVIEW_PREM_DRAFT_SUGGESSION -->
              <template v-if="getPerDraftmLogs && checkProperty(getPerDraftmLogs ,'length')>0">
               <template v-for="(agingLog ,index ) in getPerDraftmLogs" >
                 
                    <div :key="agingLog['nodeKey']" class="case-approved-body"  v-if=" checkProperty(agingLog ,'action') == 'REVIEW_PREM_DRAFT_SUGGESSION' || (checkProperty(agingLog ,'action') == 'REQUEST_PERM_DRAFT_REVIEW' && checkProperty(agingLog ,'endedOn') && agingLog['endedOn'] && !checkProperty(agingLog ,'ignore')   )"   >
                        
                        <div class="left"> 
                           <h5 class="primary" v-if="checkProperty(agingLog ,'action')=='REQUEST_PERM_DRAFT_REVIEW'"> 
                              <template v-if="getTenantTypeId!=2"> Sent For Petitioner Review </template>
                              <template v-else> Sent For Review</template>
                              </h5>
                           <h5 class="primary" v-else-if="checkProperty(agingLog ,'action')=='REVIEW_PREM_DRAFT_SUGGESSION'"> Suggestions by Petitioner</h5>
                           
                           
                           <ul >
                              
                              <li class="w-full" v-if="checkProperty(agingLog ,'data' ,'comment')">
                                 <p class="comment-sec">Comments <template v-if=" checkProperty(agingLog ,'action')=='REVIEW_PREM_DRAFT_SUGGESSION'">Suggested by Petitioner</template> <span class="wrapall" v-html="agingLog['data']['comment']"></span></p>
                              </li>




                              <li class="w-full d-block text-left " v-if="checkProperty(agingLog ,'data' ,'hasAnyRelationWithBeneficiary')">
                                 <em><div class="ben_btn"><p>Do you have any relationship with the Beneficiary?</p><span :class="{'rejected':checkProperty(agingLog ,'data' ,'hasAnyRelationWithBeneficiary')=='No' , 'completed':checkProperty(agingLog ,'data' ,'hasAnyRelationWithBeneficiary')=='Yes' }"> <em></em> {{checkProperty(agingLog ,'data' ,'hasAnyRelationWithBeneficiary') }} by Petitioner </span></div>
                                    <div class="relative" v-if="canPermDraftReviewRequest && (checkProperty(agingLog ,'data' ,'hasAnyRelationWithBeneficiary') =='Yes' && (!checkProperty( petition ,'reviewedBnfRelationInfo') || !checkProperty( petition ,'reviewedBnfRelationInfo' ,'reviewed')) )">
                                       <vs-button :disabled="updating" @click="approveParalegal(true)" class="light-blue-btn">Review</vs-button>
                                      <!--- <span v-if="updating"  class="loader"><img src="@/assets/images/main/loader.gif"></span>-->
                                    </div>
                                 </em>
                                 <p v-if="(checkProperty(agingLog ,'data' ,'hasAnyRelationWithBeneficiary') =='Yes' && checkProperty( petition ,'reviewedBnfRelationInfo' ,'reviewed'))">
                                    <template v-if="checkProperty( petition,'reviewedBnfRelationInfo' ,'createdByName' )">
                                        Reviewed by {{checkProperty( petition,'reviewedBnfRelationInfo' ,'createdByName' )}} ({{checkProperty( petition,'reviewedBnfRelationInfo' ,'createdByRoleName' )}})
                                          <template v-if="checkProperty(agingLog ,'endedOn')" >on {{agingLog['endedOn'] | formatDateTime}}</template>
                                          <template v-else-if="checkProperty(agingLog ,'startedOn')" >on {{agingLog['startedOn'] | formatDateTime}}</template>
                                          <template v-else-if="getActionCompletedDate( checkProperty(agingLog ,'action'))" >on {{getActionCompletedDate( checkProperty(agingLog ,'action')) | formatDateTime}}</template>
                                    
                                       </template>
                                     <template v-else>Reviewd by Paralegal </template>
                                  
                                 <span>Relationship has been considered and taken appropriate action by speaking to Petitioner</span></p>
                              </li>
                              <li class="w-full"  v-if="checkProperty( petition,'reviewedBnfRelationInfo' ,'comment' ) && (checkProperty(agingLog ,'data' ,'hasAnyRelationWithBeneficiary') =='Yes' && checkProperty( petition ,'reviewedBnfRelationInfo' ,'reviewed'))">
                                 <p class="comment-sec">Review Comments <span v-if="checkProperty(petition ,'reviewedBnfRelationInfo' ,'comment')"></span></p>
                              </li>

                              

                              <template v-if="!(checkProperty(agingLog ,'data' ,'hasAnyRelationWithBeneficiary') =='Yes' && checkProperty( petition ,'reviewedBnfRelationInfo' ,'reviewed'))">
                              <li v-if="checkProperty(agingLog ,'endedOn')">
                                 
                                 <p>Updated Date <span> {{agingLog['endedOn'] | formatDateTime}}</span></p>
                              </li>
                              <li v-else-if="checkProperty(agingLog ,'startedOn')">
                                 <p>Updated Date <span> {{agingLog['startedOn'] | formatDateTime}}</span></p>
                              </li>
                              <li v-else-if="getActionCompletedDate( checkProperty(agingLog ,'action'))">
                                 <p>Updated Date <span> {{getActionCompletedDate( checkProperty(agingLog ,'action')) | formatDateTime}}</span></p>
                              </li>
                              </template>
                        
            
                           
                           
                           </ul>
                        </div>
                        <div class="right">
                         
                           <ul  >
                              <template v-if="index<=0">
                                 
                                 <li :class="{'multibutton':canUpdatePermQuestionnaire && canApprovePermApplication}"  v-if=" (canPermDraftSuggession || canApprovePermApplication)">
                                    <div class="relative" v-if="canPermDraftSuggession">
                                          <vs-button   :disabled="updating" @click="$refs['actionsPopups'].openPermJobDescActionsModal('PERM_DRAFT_SUGGESSION')" class="light-blue-btn">Suggest Changes / Approve PERM Draft</vs-button>
                                          
                                       </div>
                                       <div v-else-if="canApprovePermApplication">
                                          <vs-button @click="$refs['actionsPopups'].openPermJobDescActionsModal('APPROVE_PERM_APPLICATION')" class="light-blue-btn">Approve PERM Application</vs-button>
                                       
                                       </div>
                                 </li>
                                 <li :class="{'multibutton':canUpdatePermQuestionnaire && canApprovePermApplication}"  v-if=" (canUpdatePermQuestionnaire) ">
                                 
                                    <div class="relative">
                                          
                                          <vs-button @click="editQuestionnaire('PERM_DRAFT_SUGGESSION')"  class="light-blue-btn">Update PERM Questionnaire</vs-button>
                                          
                                       </div>
                                 </li>
                              </template>
                              <li @click="reloadPetitionMe('Perm Draft')"><a href="#"  > View </a></li>
                              <li v-if="checkProperty(agingLog ,'data','documents') && checkProperty(agingLog['data'],'documents' ,'length')>0" @click="downloadfile(agingLog['data']['documents'][0])">
                                <figure class="view-detailes_cnt"><img src="@/assets/images/download-white.svg"></figure>
                            </li>
                              
                           </ul>
                        </div>
                     </div>
                  
               </template>
            </template>
              

                <div class="case-approved-body" v-if=" checkProperty(petition ,'completedActivities') && petition['completedActivities'].indexOf('EFILE_PREM_APPLICATION')>-1" >
                  <!----EFILE_PREM_APPLICATION-->
                   <div class="left">
                     <h5 class="primary ">PERM Draft Created</h5>
                      <ul >
                         
                         <li v-if="getActionCompletedDate('EFILE_PREM_APPLICATION')">
                            <p>Updated Date <span> {{getActionCompletedDate('EFILE_PREM_APPLICATION') | formatDateTime}}</span></p>
                         </li>
                         <li v-if=" checkProperty(petition ,'priorityDate')">
                            <p>Filed Date <span> {{checkProperty(petition ,'priorityDate') | formatDate}}</span></p>
                         </li>
                         <li v-if="getActivityByCode('EFILE_PREM_APPLICATION') && checkProperty(getActivityByCode('EFILE_PREM_APPLICATION') ,'data' ,'permApplicationNo' ) || checkProperty(petition ,'permApplicationNo') ">
                            <p v-if="getActivityByCode('EFILE_PREM_APPLICATION') && checkProperty(getActivityByCode('EFILE_PREM_APPLICATION') ,'data' ,'permApplicationNo' ) ">PERM Application No <span >
                               {{checkProperty(getActivityByCode('EFILE_PREM_APPLICATION') ,'data' ,'permApplicationNo' ) }}
                              </span>
                           </p>
                            <p v-else-if="checkProperty(petition ,'permApplicationNo') ">PERM Application No <span >
                               {{checkProperty(petition ,'permApplicationNo') }}
                              </span>
                            </p>
                           </li>
                         
                      
                      </ul>
                   </div>
                   <div class="right">
                      <ul v-if="checkProperty(petition ,'permDraftLogs' ,'length')>0 ">
                        <template v-if="checkProperty(petition['permDraftLogs'][0] ,'documents' ,'length')>0 " >
                         <!----<li ><a href="#" @click="downloadfile(petition.permDraftLogs[0].documents[0])"> View Details</a></li>-->
                         <li @click="downloadfile(petition.permDraftLogs[0].documents[0])">
                            <figure class="view-detailes_cnt"><img src="@/assets/images/download-white.svg"></figure>
                         </li>
                         </template>
                      </ul>
                   </div>
                </div>
                <template v-if="checkProperty(petition ,'accApprovalInfo' ,'requestedOn')">
                  <!----
                   accApprovalInfo: {
                     requestedOn: Date,
                     requestedBy: Schema.Types.ObjectId,
                     requestedByName: String,
                     requestedByRoleId: Number,
                     requestedByRoleName: String,
                     requestedComment: String,
                     approvedOn: Date,
                     approvedBy: Schema.Types.ObjectId,
                     approvedByName: String,
                     approvedByRoleId: Number,
                     approvedByRoleName: String,
                     approvedComment: String

               }   
                  --->
                  <div class="case-approved-body" v-if="checkProperty(petition ,'accApprovalInfo' ,'approvedOn')" >
                  
                  <div class="left success">
                    <h5 class="primary">Approved by Accounts</h5>
                     <ul >
                        <li class="w-full" v-if="checkProperty(petition ,'accApprovalInfo' ,'approvedComment')" >
                                 <p class="comment-sec">Comments <span v-html="checkProperty(petition ,'accApprovalInfo' ,'approvedComment')"></span></p>
                        </li>

                        <li v-if="checkProperty(petition ,'accApprovalInfo' ,'approvedByName')">
                            <p>Approved by <span> {{checkProperty(petition ,'accApprovalInfo' ,'approvedByName')}}</span></p>
                         </li>
                        
                        <li v-if="checkProperty(petition ,'accApprovalInfo' ,'approvedOn')">
                           <p>Updated Date <span> {{checkProperty(petition ,'accApprovalInfo' ,'approvedOn') | formatDateTime}}</span></p>
                        </li>
                     
                     </ul>
                  </div>
                  <div class="right" >
                     <ul v-if="false">
                       
                     </ul>
                  </div>
                  </div>
                <div class="case-approved-body" v-if="checkProperty(petition ,'accApprovalInfo' ,'requestedOn')" >
                  
                   <div class="left">
                     <h5 class="primary">Requested for Approval from Accounts</h5>
                      <ul >
                        <li class="w-full" v-if="checkProperty(petition ,'accApprovalInfo' ,'requestedComment')" >
                                 <p class="comment-sec">Comments <span v-html="checkProperty(petition ,'accApprovalInfo' ,'requestedComment')"></span></p>
                        </li>         
                        <li v-if="checkProperty(petition ,'accApprovalInfo' ,'requestedByName')">
                            <p>Requested by <span> {{checkProperty(petition ,'accApprovalInfo' ,'requestedByName')}}</span></p>
                         </li>
                         <li v-if="checkProperty(petition ,'accApprovalInfo' ,'requestedOn')">
                            <p>Requested On <span> {{checkProperty(petition ,'accApprovalInfo' ,'requestedOn') | formatDateTime}}</span></p>
                         </li>
                      
                      </ul>
                   </div>
                   <div class="right" >
                      <ul v-if="false">
                        
                      </ul>
                   </div>
                </div>
               </template>

                <div class="case-approved-body" v-if=" checkProperty(petition ,'completedActivities') &&  petition['completedActivities'].indexOf('PREPARE_PERM_APPLICATION')>-1" >
                  <!----PREPARE_PERM_APPLICATION-->
                   <div class="left">
                     <h5 class="primary">Finalized PERM Questionnaire</h5>
                      <ul >
                         
                         <li v-if="getActionCompletedDate('PREPARE_PERM_APPLICATION')">
                            <p>Updated Date <span> {{getActionCompletedDate('PREPARE_PERM_APPLICATION') | formatDateTime}}</span></p>
                         </li>
                      
                      </ul>
                   </div>
                   <div class="right">
                      <ul >
                        <li @click="reloadPetitionMe('Perm Draft')"><a href="#"  > View </a></li>
                         <li v-if="checkProperty(petition ,'rfeNotice' ,'documents') && checkProperty(petition['rfeNotice'] ,'documents' ,'length')>0 " @click="downloadfile(petition.rfeNotice.documents[0])">
                            <figure class="view-detailes_cnt"><img src="@/assets/images/download-white.svg"></figure>
                         </li>
                      </ul>
                   </div>
                </div>
                <div class="case-approved-body" v-if=" checkProperty(petition ,'completedActivities') && petition['completedActivities'].indexOf('COLLECT_ADV_EVIDENCE')>-1" >
                  <!----COLLECT_ADV_EVIDENCE-->
                   <div class="left">
                     <h5 class="primary"> Evidence of Advertisements Collected</h5>
                      <ul >
                         
                         <li v-if="getActionCompletedDate('COLLECT_ADV_EVIDENCE') ">
                            <p>Updated Date <span> {{getActionCompletedDate('COLLECT_ADV_EVIDENCE') | formatDateTime}}</span></p>
                         </li>
                      
                      </ul>
                   </div>
                   <div class="right">
                      <ul >

                        <li v-if="(checkCollectAdvertismentEdit)" >
                              
                              <div class="relative">
                                 
                                    <vs-button @click="showPermInfoPopup()"  class="light-blue-btn">Update Evidence of Advertisements</vs-button>
                                    
                                 </div>
                           </li>
                         <li><a href="#" @click="reloadPetitionMe('Advertise Info')"> View </a></li>
                         <li v-if="checkProperty(petition ,'rfeNotice' ,'documents') && checkProperty(petition['rfeNotice'] ,'documents' ,'length')>0"  @click="downloadfile(petition.rfeNotice.documents[0])">
                            <figure class="view-detailes_cnt"><img src="@/assets/images/download-white.svg"></figure>
                         </li>
                      </ul>
                   </div>
                </div>

         

                <template v-if="checkProperty(petition ,'pwdLogs') && checkProperty(petition ,'pwdLogs' ,'length')>0 " >
                  
                <template v-for="(pwdLog ,index ) in petition.pwdLogs" >
                  <template v-if="index>=0 && checkProperty(pwdLog ,'action') && (['PWD_RFI_RECEIVED' ,'SUBMIT_RFI_RESPONSE' ,'PWD_CERTIFID' ].indexOf( pwdLog['action'] )>-1 )">
                     <div :key="index" class="case-approved-body"    >
                       
                        <div class="left" :class="{'success':checkProperty(pwdLog ,'action')=='PWD_CERTIFID'}"> 
                           <h5 class="primary" >
                              <template v-if="checkProperty(pwdLog ,'action')=='PWD_RFI_RECEIVED'"> RFI Received</template>
                              <template v-if="checkProperty(pwdLog ,'action')=='SUBMIT_RFI_RESPONSE'"> RFI Response Submitted</template>
                              <template v-if="checkProperty(pwdLog ,'action')=='PWD_CERTIFID'">PWD Certified </template>
                           </h5>
                           
                        
                        <ul >
                              <template v-if="
                              ( checkProperty(pwdLog ,'data' ,'rfiDescription') && checkProperty(pwdLog ,'action')=='PWD_RFI_RECEIVED')
                              || ( checkProperty(pwdLog ,'data' ,'description') && checkProperty(pwdLog ,'action')=='SUBMIT_RFI_RESPONSE')
                              || ( checkProperty(pwdLog ,'data' ,'description') && checkProperty(pwdLog ,'action')=='PWD_CERTIFID')
                                 ">
                              <li class="w-full" >
                                 <p class="comment-sec">Comments
                                    <span class="wrapall"><template v-if="( checkProperty(pwdLog ,'data' ,'rfiDescription') && checkProperty(pwdLog ,'action')=='PWD_RFI_RECEIVED')"><span class="wrapall" v-html=" pwdLog['data']['rfiDescription']"></span> </template>
                                       <template v-else-if="( checkProperty(pwdLog ,'data' ,'description') && checkProperty(pwdLog ,'action')=='SUBMIT_RFI_RESPONSE')"><span v-html="pwdLog['data']['description']"></span> </template>
                                       <template v-else-if="( checkProperty(pwdLog ,'data' ,'description') && checkProperty(pwdLog ,'action')=='PWD_CERTIFID')"><span v-html="pwdLog['data']['description']"></span> </template>
                                    
                                    </span>
                                    
                                 </p>
                              </li>
                           </template>
   
                              <li v-if="checkProperty(petition, 'pwdLinkedOn')">
                                 <p>Updated Date <span> {{checkProperty(petition, 'pwdLinkedOn') | formatDateTime}}</span></p>
                              
                              </li>
                              <li v-else-if="checkProperty(pwdLog ,'endedOn')">
                                 <p>Updated Date <span> {{pwdLog['endedOn'] | formatDateTime}}</span></p>
                              </li>
                              <li v-else-if="checkProperty(pwdLog ,'startedOn')">
                                 <p>Updated Date <span> {{pwdLog['startedOn'] | formatDateTime}}</span></p>
                              </li>
                              <li v-if="checkProperty(pwdLog ,'data' ,'documentType') && checkProperty(pwdLog ,'action')=='PWD_CERTIFID'">
                                 <p>Document Type <span> {{pwdLog['data']['documentType']}}</span></p>
                              </li>

                              <template v-if="(['PWD_CERTIFID' ,'PWD_RFI_RECEIVED'].indexOf(checkProperty(pwdLog ,'action'))>-1)">

                                 <li v-if="checkProperty(pwdLog ,'data' ,'issuedDate')">
                                 <p>Receipt Date<br/><a >{{checkProperty(pwdLog ,'data' ,'issuedDate') | formatDate}}</a></p>
                                 </li>
                                 <li v-if="checkProperty(pwdLog ,'data' ,'receivedDate')">
                                 <p>Received Date<br/><a >{{checkProperty(pwdLog ,'data' ,'receivedDate') | formatDate}}</a></p>
                                 </li>
                                 <li v-if="checkProperty(pwdLog ,'data' ,'dueDate')">
                                 <p>Expiration Date<br/><a >{{checkProperty(pwdLog ,'data' ,'dueDate') | formatDate}}</a></p>
                                 </li>
                              </template>
                              <template v-if="(['PWD_RFI_RECEIVED'].indexOf(checkProperty(pwdLog ,'action'))>-1)">

                                 
                                 <li v-if="checkProperty(pwdLog ,'data' ,'rfiReceivedDate')">
                                 <p>Received Date<br/><a >{{checkProperty(pwdLog ,'data' ,'rfiReceivedDate') | formatDate}}</a></p>
                                 </li>
                                 <li v-if="checkProperty(pwdLog ,'data' ,'rfiDueDate')">
                                 <p>Expiration Date<br/><a >{{checkProperty(pwdLog ,'data' ,'rfiDueDate') | formatDate}}</a></p>
                                 </li>
                              </template>
                              
                              
                        
            
                           
                           
                           </ul>
                        </div>
                        <div class="right">
                           
                           
                           <ul >
                             
                              <li v-if="index<=0 && collectEvedenceBtn">
                                 <div class="relative">
                                     <vs-button @click="$refs['actionsPopups'].openPermAdvrtisementModal()"  class="light-blue-btn">Collect Evidence of Advertisements</vs-button>
                                 </div>
                              </li>

                             <li v-if="['PWD_RFI_RECEIVED'].indexOf(checkProperty(pwdLog ,'action'))>-1 && (checkProperty(pwdLog ,'data' ,'rfiDocuments') && checkProperty(pwdLog['data'] ,'rfiDocuments' ,'length')>0)" @click="downloadfile(pwdLog.data.rfiDocuments[0])">
                                <figure class="view-detailes_cnt"><img src="@/assets/images/download-white.svg"></figure>
                             </li>
                             <li v-else-if="(checkProperty(pwdLog ,'data' ,'documents') && checkProperty(pwdLog['data'] ,'documents' ,'length')>0)" @click="downloadfile(pwdLog.data.documents[0])">
                                 <figure class="view-detailes_cnt"><img src="@/assets/images/download-white.svg"></figure>
                              </li>
                           </ul>
                        </div>
                     </div>
                  </template> 
               </template>
               </template>
              
                
                <div class="case-approved-body" v-if=" checkProperty(petition ,'completedActivities') && (petition['completedActivities'].indexOf('EFILE_PWD')>-1 || ['Filed'].indexOf(checkProperty(petition ,'pwdStatus') ) >-1)" >
                  <!----EFILE_PWD-->
                   <div class="left">
                     <!-- E-Filed PWD (Filed/In-Process) -->
                     <h5 class="primary">PWD Filed (In Process / Pending Determination) </h5>
                      <ul>

                        
                        <li v-if="checkProperty(petition, 'pwdLinkedOn')">
                                 <p>Updated Date <span> {{checkProperty(petition, 'pwdLinkedOn') | formatDateTime}}</span></p>
                              
                        </li>
                         <li v-else-if="getActionCompletedDate('EFILE_PWD')">
                            <p>Updated Date <span> {{getActionCompletedDate('EFILE_PWD') | formatDateTime}}</span></p>
                         </li>
                         <li v-else-if="checkProperty(petition ,'filedPwdUpdatedOn')">
                            <p>Updated Date <span> {{checkProperty(petition ,'filedPwdUpdatedOn') | formatDateTime}}</span></p>
                         </li>
                         <li v-else-if="checkProperty(petition ,'certifiedPwdUpdatedOn')">
                            <p>Updated Date <span> {{checkProperty(petition ,'certifiedPwdUpdatedOn') | formatDateTime}}</span></p>
                         </li>
                         <li v-if="checkProperty(petition ,'jobDetails' ,'trackingNumber')">
                           <p>Tracking Number <span> {{ checkProperty(petition ,'jobDetails' ,'trackingNumber')}}</span></p>
                        </li>

                        <li  v-if="checkProperty(petition ,'pwdResponse' ,'filedDocumentType') && checkProperty(petition['pwdResponse'] ,'filedDocuments' ,'length')>0">
                           <p>Document Type <span> {{checkProperty(petition ,'pwdResponse' ,'filedDocumentType') }} copy</span></p>
                        </li>
                      </ul>
                   </div>
                   <div class="right">
                      <ul >
                        
                        
                        <li v-if="collectEvedenceBtn && checkProperty(petition ,'pwdLogs' ,'length')<=0 ">
                                 <div class="relative">
                                     <vs-button @click="$refs['actionsPopups'].openPermAdvrtisementModal()"  class="light-blue-btn">Collect Evidence of Advertisements</vs-button>
                                 </div>
                              </li>
                        <!---- <li><a href="#" @click="downloadfile(petition.pwdResponse.filedDocuments[0])"> View Details</a></li>-->
                         <li v-if="checkProperty(petition ,'pwdResponse' ,'filedDocuments') && checkProperty(petition['pwdResponse'] ,'filedDocuments' ,'length')>0" @click="downloadfile(petition.pwdResponse.filedDocuments[0])">
                            <figure class="view-detailes_cnt"><img src="@/assets/images/download-white.svg"></figure>
                         </li>
                      </ul>
                   </div>
                </div>
                <div class="case-approved-body" v-if="(getActionCompletedDate('FINALIZE_JOB_DESC') || checkProperty(petition ,'filedPwdUpdatedOn') || checkProperty(petition ,'certifiedPwdUpdatedOn') )&& checkProperty(petition ,'completedActivities') && (petition['completedActivities'].indexOf('FINALIZE_JOB_DESC')>-1 )" >
                  <!----FINALIZE_JOB_DESC-->
                   <div class="left success">
                     <h5 class="success"
                        
                         >Finalized Job Description</h5>
                      <ul >
                        <li v-if="checkProperty(petition, 'pwdLinkedOn')">
                              <p>Updated Date <span> {{checkProperty(petition, 'pwdLinkedOn') | formatDateTime}}</span></p>
                        </li>
                         <li v-else-if="getActionCompletedDate('FINALIZE_JOB_DESC')">
                            <p>Updated Date <span> {{getActionCompletedDate('FINALIZE_JOB_DESC') | formatDateTime}}</span></p>
                         </li>
                         <li v-else-if="checkProperty(petition ,'filedPwdUpdatedOn')">
                            <p>Updated Date <span> {{checkProperty(petition ,'filedPwdUpdatedOn') | formatDateTime}}</span></p>
                         </li>
                         <li v-else-if="checkProperty(petition ,'certifiedPwdUpdatedOn')">
                            <p>Updated Date <span> {{checkProperty(petition ,'certifiedPwdUpdatedOn') | formatDateTime}}</span></p>
                         </li>
                      
                      </ul>
                   </div>
                   <div class="right">
                     
                      <ul v-if="checkProperty(petition ,'rfeNotice' ,'documents') && false">
                         <li><a href="#" @click="downloadfile(petition.rfeNotice.documents[0])"> View Details</a></li>
                         <li @click="downloadfile(petition.rfeNotice.documents[0])">
                            <figure class="view-detailes_cnt"><img src="@/assets/images/download-white.svg"></figure>
                         </li>
                      </ul>
                   </div>
                </div>
                
                <div class="case-approved-body" v-if="(checkProperty(petition, 'pwdLinkedOn') || getActionCompletedDate('APPROVE_JOB_DESC') || checkProperty(petition ,'filedPwdUpdatedOn') || checkProperty(petition ,'certifiedPwdUpdatedOn') ) && checkProperty(petition ,'completedActivities') && ( petition['completedActivities'].indexOf('APPROVE_JOB_DESC')>-1 )" >
                  <!----APPROVE_JOB_DESC FINALIZE_JOB_DESC-->
                   <div class="left success">
                     <h5 class="success"
                        
                         > Job Description Approved</h5>
                      <ul >
                        <li v-if="checkProperty(petition, 'pwdLinkedOn')">
                              <p>Updated Date <span> {{checkProperty(petition, 'pwdLinkedOn') | formatDateTime}}</span></p>
                        </li>
                         <li v-else-if="getActionCompletedDate('APPROVE_JOB_DESC')">
                            <p>Updated Date <span> {{getActionCompletedDate('APPROVE_JOB_DESC') | formatDateTime}}</span></p>
                         </li>
                         <li v-else-if="checkProperty(petition ,'filedPwdUpdatedOn')">
                            <p>Updated Date <span> {{checkProperty(petition ,'filedPwdUpdatedOn') | formatDateTime}}</span></p>
                         </li>
                         <li v-else-if="checkProperty(petition ,'certifiedPwdUpdatedOn')">
                            <p>Updated Date <span> {{checkProperty(petition ,'certifiedPwdUpdatedOn') | formatDateTime}}</span></p>
                         </li>
                      
                      </ul>
                   </div>
                   <div class="right">
                      <ul >
                        <li v-if="canFinailizeJobDesc ">
                              
                              <div class="relative">
                                 
                                    <vs-button @click="$refs['actionsPopups'].openPermJobDescActionsModal('FINALIZE_JOB_DESC')"  class="light-blue-btn">Finalize Job Description</vs-button>
                                    
                                 </div>
                           </li>
                      </ul>
                   </div>
                </div>

               <!-----REVIEW_JOB_DESC_SUGGESSION 
                  v-if=" checkProperty(agingLog ,'action') == 'REVIEW_PREM_DRAFT_SUGGESSION' || (checkProperty(agingLog ,'action') == 'REQUEST_PERM_DRAFT_REVIEW' && checkProperty(agingLog ,'endedOn'))"
                  
                  ---->
               
              <template v-if="getjobDescriptionLogs && (checkProperty(petition ,'completedActivities') && petition['completedActivities'].indexOf('CREATE_JOB_DESC')>-1  && getjobDescriptionLogs && checkProperty(getjobDescriptionLogs ,'length')>0)">
                  <template v-for="(agingLog ,index ) in getjobDescriptionLogs" >

                    
                     <div :key="agingLog['nodeKey']" class="case-approved-body" v-if=" ( checkProperty(agingLog ,'endedOn') && agingLog['endedOn'] && !checkProperty(agingLog ,'ignore'))"
                        >
                        
                        <div class="left" :actionCode="checkProperty(agingLog ,'action')">
                           
                           <!----"INTERNAL_REQUEST_JOB_DESC_REVIEW","INTERNAL_JOB_DESC_SUGGESSION",'INTERNAL_APPROVE_JOB_DESC'-->
                           
                           
                           <h5 class="primary" v-if="checkProperty(agingLog ,'action')=='UPDATE_JOB_DESC'">Uploaded New Job Description <!-- Suggestions For Job Description.--></h5>
                           <h5 class="primary" v-else-if="checkProperty(agingLog ,'action')=='INTERNAL_REQUEST_JOB_DESC_REVIEW'">Sent for Internal Review <!-- Suggestions For Job Description.--></h5>
                           <h5 class="primary" v-else-if="checkProperty(agingLog ,'action')=='INTERNAL_JOB_DESC_SUGGESSION'">
                             <template v-if="checkProperty(agingLog ,'data' ,'jobDescSuggessionType') =='job_desc_update'"> Update Job Description</template>
                             <template v-else>Suggestions by Internal Team</template>
                              
                           </h5>
                           <h5 class="primary" v-else-if="checkProperty(agingLog ,'action')=='INTERNAL_APPROVE_JOB_DESC'">Approved by Internal Team <!-- Suggestions For Job Description.--></h5>
                        
                           <h5 class="primary" v-else-if="checkProperty(agingLog ,'action')=='REQUEST_JOB_DESC_REVIEW'">
                              <template v-if="getTenantTypeId!=2"> Sent For Petitioner Review</template>
                              <template v-else> Sent For Review</template>
                           </h5>
                           <h5 class="primary" v-if="checkProperty(agingLog ,'action')=='JOB_DESC_SUGGESSION'">Suggestions by Petitioner <!-- Suggestions For Job Description.--></h5>
                           <h5 class="primary" v-else-if="checkProperty(agingLog ,'action')=='REVIEW_JOB_DESC_SUGGESSION'">
                              
                              <template v-if="getTenantTypeId!=2"> Suggestions by Petitioner</template>
                              <template v-else> Suggestions For Job Description</template>
                              
                              <!-- Suggestions For Job Description.--></h5>
                        
                           <!-- <p v-if="checkProperty(agingLog ,'data' ,'comment')" >{{ agingLog['data']['comment']}}</p> -->
                           
                           <ul >
                              
                              <!-- <li v-if=" checkProperty(agingLog ,'action')=='REVIEW_JOB_DESC_SUGGESSION' && getActionCompletedDate('REVIEW_JOB_DESC_SUGGESSION')">
                                 <p>Updated Date <span> {{getActionCompletedDate('REVIEW_JOB_DESC_SUGGESSION') | formatDateTime}}</span></p>
                              </li> -->
                              <li class="w-full" v-if="checkProperty(agingLog ,'data' ,'comment')">
                                 <p class="comment-sec">Comments <template v-if=" checkProperty(agingLog ,'action')=='REVIEW_JOB_DESC_SUGGESSION'">Suggested by Petitioner</template>
                                 
                                    <span class="wrapall" v-html="agingLog['data']['comment']"></span>
                                 </p>
                              </li>
                              <li v-if="checkProperty(petition, 'pwdLinkedOn')">
                                 <p>Updated Date <span> {{checkProperty(petition, 'pwdLinkedOn') | formatDateTime}}</span></p>
                              
                              </li>
                              <li v-else-if="checkProperty(agingLog ,'endedOn')">
                                 <p>Updated Date <span> {{agingLog['endedOn'] | formatDateTime}}</span></p>
                              </li>
                              <li v-else-if="checkProperty(agingLog ,'startedOn')">
                                 <p>Updated Date <span> {{agingLog['startedOn'] | formatDateTime}}</span></p>
                              </li>
                              <li v-else-if="getActionCompletedDate( checkProperty(agingLog ,'action'))">
                                 <p>Updated Date <span> {{getActionCompletedDate( checkProperty(agingLog ,'action')) | formatDateTime}}</span></p>
                              </li>

                              
                           
                           </ul>
                        </div>
                        <div class="right">
                                                                               
                           <ul>
                              <!---v-if="(index<=0 && agingLog['action']=='REQUEST_JOB_DESC_REVIEW') || ( index-1==0 && agingLog['action']=='REVIEW_JOB_DESC_SUGGESSION')"---->
                              <template v-if="index<=0 && checkProperty(petition ,'pwdLogs' ,'length')<=0 && !(checkProperty(petition ,'completedActivities') && (petition['completedActivities'].indexOf('EFILE_PWD')>-1 || ['Certified' ,'Filed'].indexOf(checkProperty(petition ,'pwdStatus') ) >-1))" >
                              
                                  <!----"INTERNAL_REQUEST_JOB_DESC_REVIEW","INTERNAL_JOB_DESC_SUGGESSION",'INTERNAL_APPROVE_JOB_DESC'  -cansendIndernalReview cansendIndernalApprove -->
                                 
                                   
                                  <template v-if="cansendIndernalReview  || cansendIndernalApprove">
                                 
                                  <li>
                                   
                                    <div class="relative" v-if="(canEditJobDesc || isAdmin) &&  ['INTERNAL_JOB_DESC_SUGGESSION' ,'JOB_DESC_SUGGESSION'].indexOf(checkProperty(petition ,'curWorkflowActivity')) >-1">
                                    
                                    <vs-button @click="editJobDescription()"  class="light-blue-btn">Update Job Description</vs-button>
                                    
                                   </div>
                                  <div class="relative" v-else-if="cansendIndernalReview &&  !cansendIndernalApprove &&  !checkActivityCompleted('APPROVE_JOB_DESC')">
                              
                                     <vs-button @click="$refs['actionsPopups'].openPermJobDescActionsModal('INTERNAL_REQUEST_JOB_DESC_REVIEW');"  class="light-blue-btn">Request for review of Job Description - Internal</vs-button>
                                 </div>
                                  
                                    <div class="relative"  v-else-if="!cansendIndernalReview && cansendIndernalApprove && ['INTERNAL_REQUEST_JOB_DESC_REVIEW','INTERNAL_JOB_DESC_SUGGESSION','INTERNAL_APPROVE_JOB_DESC'].indexOf(agingLog['action'])>-1 && !checkActivityCompleted('INTERNAL_APPROVE_JOB_DESC') &&  !checkActivityCompleted('APPROVE_JOB_DESC')">
                                       
                                        <vs-button   @click="$refs['actionsPopups'].openPermJobDescActionsModal('INTERNAL_APPROVE_JOB_DESC');"  class="light-blue-btn">Suggest Changes/Approve Job Description - Internal</vs-button>
                                    </div>

                                                              
                                 
                                 
                                 </li> 
                              
                                 
                                 </template>
                                 <template v-else-if="canSendforPerReview">
                                    <li>

                                       <div class="relative" >

                                       <vs-button @click=" $refs['actionsPopups'].openPermJobDescActionsModal('REQUEST_JOB_DESC_REVIEW');"  class="light-blue-btn">Request Petitioner for Job Description Review</vs-button>

                                       </div>
                                    </li>
                                 
                                 </template>
                                 <template v-else>
                                    
                                    
                                    <li v-if="canApproveSujjestJobDes">
                                 
                                    <div class="relative">
                                 
                                    
                                       <vs-button @click="$refs['actionsPopups'].openPermJobDescActionsModal('JOB_DESC_APPROVE_OR_SUGGESSION')"  class="light-blue-btn">Suggest Changes / Approve Job Description</vs-button>
                                       
                                    </div>
                                   </li> 
                                   <li v-else-if="canSuggestJob && !canPermJobApprove && ['INTERNAL_REQUEST_JOB_DESC_REVIEW','INTERNAL_JOB_DESC_SUGGESSION','INTERNAL_APPROVE_JOB_DESC'].indexOf(agingLog['action'])<=-1" >
                                 
                                    <div class="relative">
                                    
                                       <vs-button @click="$refs['actionsPopups'].openPermJobDescActionsModal('JOB_DESC_SUGGESSION')"  class="light-blue-btn">Suggest changes to Job Description</vs-button>
                                       
                                    </div>
                                   </li>
                                   <li v-else-if="(canEditJobDesc || isAdmin) &&  ['INTERNAL_JOB_DESC_SUGGESSION' ,'JOB_DESC_SUGGESSION' ,'REQUEST_JOB_DESC_REVIEW'].indexOf(checkProperty(petition ,'curWorkflowActivity')) >-1" >
                                    
                                    <div class="relative" >
                                       
                                       <vs-button @click="editJobDescription()"  class="light-blue-btn">Update Job Description</vs-button>
                                       
                                    </div>
                                   </li>
                                   <li v-if="canPermJobApprove && !canSuggestJob && ( ( !isenJobDescriptionReviewRequired || ( isenJobDescriptionReviewRequired && this.petition.completedActivities.indexOf('REQUEST_JOB_DESC_REVIEW') >-1) )) &&(!checkInternalActivityRequires || ( checkInternalActivityRequires  && this.checkProperty(this.petition ,'curWorkflowActivity') !='INTERNAL_REQUEST_JOB_DESC_REVIEW' ) && (this.petition.completedActivities.indexOf('INTERNAL_JOB_DESC_SUGGESSION') >-1 || this.petition.completedActivities.indexOf('INTERNAL_APPROVE_JOB_DESC') >-1 ) )">
                                 
                                 <div class="relative">
                                 
                                    <vs-button @click="$refs['actionsPopups'].openPermJobDescActionsModal('APPROVE_JOB_DESC')"  class="light-blue-btn">Approve Job Description</vs-button>
                                    
                                 </div>
                                   </li>
                                 </template>
                           </template>
                              <li @click="reloadPetitionMe('Job Details')"><a href="#"  > View </a></li>
                              
                           </ul>
                        </div>
                     </div>
                  
               </template>
              </template>
                <div class="case-approved-body" v-if=" checkProperty(petition ,'completedActivities') && (petition['completedActivities'].indexOf('CREATE_JOB_DESC')>-1 ) || checkProperty(petition ,'jobDetails' ,'jobTitle')" >
                  <!----CREATE_JOB_DESC-->
                   <div class="left"> 
                     <h5 class="primary"
                         
                         > Job Description Created</h5>

                           
                      <ul >
                       

                        
                        <li v-if="checkProperty(petition, 'pwdLinkedOn')">
                           <p>Updated Date <span> {{checkProperty(petition, 'pwdLinkedOn') | formatDateTime}}</span></p>
                              
                        </li>
                         <li v-else-if="getActionCompletedDate('CREATE_JOB_DESC')">
                            <p>Updated Date <span> {{getActionCompletedDate('CREATE_JOB_DESC') | formatDateTime}}</span></p>
                         </li>
                         <li v-else-if="checkProperty(petition ,'filedPwdUpdatedOn')">
                            <p>Updated Date <span> {{checkProperty(petition ,'filedPwdUpdatedOn') | formatDateTime}}</span></p>
                         </li>
                         <li v-else-if="checkProperty(petition ,'certifiedPwdUpdatedOn')">
                            <p>Updated Date <span> {{checkProperty(petition ,'certifiedPwdUpdatedOn') | formatDateTime}}</span></p>
                         </li>
                      
                      </ul>
                   </div>
                   <div class="right">
                      <ul>
                        
                           <!-----['REVIEW_JOB_DESC_SUGGESSION' ,'REQUEST_JOB_DESC_REVIEW'] -->
                           
                           <li  v-if="cansendIndernalReview && checkProperty(getjobDescriptionLogs ,'length')<=0 && !checkActivityCompleted('APPROVE_JOB_DESC')">
                                 
                                 <div class="relative">
                              
                                     <vs-button @click="$refs['actionsPopups'].openPermJobDescActionsModal('INTERNAL_REQUEST_JOB_DESC_REVIEW');"  class="light-blue-btn">Request for review of Job Description - Internal</vs-button>
                                 </div>

                              </li>
                           <template v-else-if=" checkProperty(getjobDescriptionLogs ,'length')<=0 && !checkActivityInlogs('REQUEST_JOB_DESC_REVIEW') && !checkActivityInlogs('REVIEW_JOB_DESC_SUGGESSION') && petition['completedActivities'].indexOf('INTERNAL_REQUEST_JOB_DESC_REVIEW')<=-1">
                           <li v-if="canSuggestJob && canPermJobApprove">
                              
                              <div class="relative">
                                 
                                    <vs-button @click="$refs['actionsPopups'].openPermJobDescActionsModal('JOB_DESC_APPROVE_OR_SUGGESSION')"  class="light-blue-btn">Suggest Changes / Approve Job Description</vs-button>
                                    
                                 </div>
                           </li>
                           
                              <li v-if="canPermJobApprove && !canSuggestJob && ( ( !isenJobDescriptionReviewRequired || ( isenJobDescriptionReviewRequired && this.petition.completedActivities.indexOf('REQUEST_JOB_DESC_REVIEW') >-1) )) &&(!checkInternalActivityRequires || ( checkInternalActivityRequires  && this.checkProperty(this.petition ,'curWorkflowActivity') !='INTERNAL_REQUEST_JOB_DESC_REVIEW' ) && (this.petition.completedActivities.indexOf('INTERNAL_JOB_DESC_SUGGESSION') >-1 || this.petition.completedActivities.indexOf('INTERNAL_APPROVE_JOB_DESC') >-1 ) )" >
                              
                                 <div class="relative">
                                 
                                    <vs-button @click="$refs['actionsPopups'].openPermJobDescActionsModal('APPROVE_JOB_DESC')"  class="light-blue-btn">Approve Job Description</vs-button>
                                    
                                 </div>
                              </li>
                              <li v-if="canSuggestJob && !canPermJobApprove " >
                              
                                 <div class="relative">
                                 
                                    <vs-button @click="$refs['actionsPopups'].openPermJobDescActionsModal('JOB_DESC_SUGGESSION')"  class="light-blue-btn">Suggest changes to Job Description</vs-button>
                                    
                                 </div>
                              </li>

                           </template>
                           
                         <li  @click="reloadPetitionMe('Job Details')"><a href="#"  > View </a></li>
                         <!-- <li @click="downloadfile(petition.rfeNotice.documents[0])">
                            <figure class="view-detailes_cnt"><img src="@/assets/images/download-white.svg"></figure>
                         </li> -->
                      </ul>
                   </div>
                </div>
         
             </div>
             
           </template>
         
 
             
          </section>
         
 
    
 
       </div>


    <actionsPopup v-if="petition" @updatepetition="updatePet" :workFlowDetails="workFlowDetails" ref="actionsPopups" :petitionDetails="petition" />
    <vs-popup class="holamundo main-popup  confirm_modal"  title="Update Evidence of Advertisements" :active.sync="showPermApproveinfo">
      <div class="form-container">
        <div class="vx-row">
          <div class="vx-col w-full text-center">
          
          <vs-alert class="primary-alert mb-1" style="height: auto;">The changes you make will not apply to draft application in DOL website. Please make sure to apply these changes in DOL portal manually.</vs-alert>
          
            
          </div>
          
        </div>

              
       
      </div>
      <div class="popup-footer relative">
       
        <template >
               
          <vs-button  color="success" @click="showPermApproveinfo=false;showPermApproveinfo=false;showPermApproveinfo=false;$refs['actionsPopups'].openPermAdvrtisementModal()"  class="save"  type="filled"> Ok</vs-button>
        </template> 
        </div>
   </vs-popup>

   <!----approveParalegalPopup approveParalegalForm-->

   <vs-popup class="holamundo main-popup  confirm_modal"  title="Review" :active.sync="approveParalegalPopup">
      <form @submit.prevent data-vv-scope="approveParalegalForm" class="trackingform">
      <div class="form-container">
        <div class="vx-row">
         <div class="vx-col  w-full"  >
            <div class="form_group mb-4">
            <label class="form_label">Comments<em >*</em></label>
                     <!-- <vs-textarea name="Comments" v-model="approveParalegalComment" v-validate="'required'"  class="w-full" :data-vv-as="'Comments'" /> -->
                     <ckeditor name="Comments" v-model="approveParalegalComment" v-validate="'required'"  class="w-full" :data-vv-as="'Comments'"  :editor="editor" :config="editorConfig"></ckeditor>
                  <p v-show="errors.has('approveParalegalForm.Comments')" class="text-danger text-sm p-0"><em>*</em> Comments are required</p>
            </div>
         </div>
          
        </div>

              
       
      </div>
   
      <div class="popup-footer relative">
       
        <template >
         <span class="loader" v-if="updating"><img src="@/assets/images/main/loader.gif"></span>
         <vs-button color="dark" class="cancel" type="filled" @click="approveParalegalPopup=false;approveParalegalComment='' ">Cancel</vs-button>
          <vs-button  color="success" @click="approveParalegal(false)"  class="save"  type="filled"> Considered the Relationship</vs-button>
        </template> 
        </div>
      </form>

   </vs-popup>

    </div>
 </template>
 <script>

 import * as _ from "lodash";
 import permJobActionModal from "@/views/actionpopups/perm/permJobActionModal.vue"; 
 import actionsPopup from "@/views/common/actionsPopup.vue";
 import moment from "moment";
 import Vue from 'vue';
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';

    export default {
     computed:{
      checkActivityCompleted(){
         let returnValue =false;
         return (code)=>{
            if(this.checkProperty( this.petition ,'completedActivities' ,'length') >0){
               
               let completedActivities = this.petition['completedActivities'];
               returnValue =  completedActivities.indexOf(code)>-1;


            }
            return returnValue;

         }
      },
      collectEvedenceBtn(){
         let canEditPermAdvertisement =this.jobAdvertismentActivity.indexOf(this.getUserRoleId) > -1;
         let pwdStatus ='';
            if(_.has(this.petition , 'pwdStatus') && ['Filed' ,'Certified'].indexOf(this.petition['pwdStatus'])>-1 ){
            pwdStatus = this.petition['pwdStatus'];
            }
         if (
              this.checkAssignments &&
               this.isActiveCode("COLLECT_ADV_EVIDENCE") && (canEditPermAdvertisement || this.isAdmin) && this.petition.completedActivities.indexOf('COLLECT_ADV_EVIDENCE') <=-1
                &&(

                 (this.petition.completedActivities.indexOf('PWD_CERTIFID') >-1 )
                 || ( ( (['Filed'].indexOf(pwdStatus)>-1 || this.petition.completedActivities.indexOf('EFILE_PWD')>-1    ) && !this.approvedPwdReqForAdvEvidences)  || (['Certified'].indexOf(pwdStatus)>-1  ) )
                 

                 )
              
               ){
                return true
              }else{
                return false
              }
      },
      canApproveSujjestJobDes(){
         let hasJobDetails =false;
          let returnValue = false;

         if(_.has(this.petition , 'hasJobDetails')){
          hasJobDetails = this.petition['hasJobDetails'];
          
       }

       let canPermJobApprove =this.permJobApprove.indexOf(this.getUserRoleId) > -1; 
         if(
            (!hasJobDetails && this.checkAssignments && this.isActiveCode("APPROVE_JOB_DESC") && (canPermJobApprove || this.isAdmin) && this.petition.completedActivities.indexOf('CREATE_JOB_DESC') >-1 && this.petition.completedActivities.indexOf('APPROVE_JOB_DESC') <=-1 )
             && (this.checkProperty(this.petition ,'curWorkflowActivity') =='REQUEST_JOB_DESC_REVIEW' && this.jobdescriptionapprovallist.indexOf(this.getUserRoleId) > -1  )
            ){
            returnValue = true;

          }
          return returnValue
      },
      isenJobDescriptionReviewRequired(){

         let returnValue =false;
         if(this.checkProperty(this.workFlowDetails ,'config' ,'length') >0){
        if( _.find(this.workFlowDetails.config , {"code":'REQUEST_JOB_DESC_REVIEW' ,'actionRequired':'Yes'})){
         returnValue = true;
        }
      }
      return returnValue;

      },
      canSendforPerReview(){
         let hasJobDetails =false;
       if(_.has(this.petition , 'hasJobDetails')){
          hasJobDetails = this.petition['hasJobDetails'];
          
       }
         if ( 
           
            (!this.checkInternalActivityRequires || ( this.checkInternalActivityRequires  && this.checkProperty(this.petition ,'curWorkflowActivity') !='INTERNAL_REQUEST_JOB_DESC_REVIEW' ) && (this.petition.completedActivities.indexOf('INTERNAL_JOB_DESC_SUGGESSION') >-1 || this.petition.completedActivities.indexOf('INTERNAL_APPROVE_JOB_DESC') >-1 ) )
           &&  (!hasJobDetails && this.checkAssignments && ['REQUEST_JOB_DESC_REVIEW' ,'INTERNAL_REQUEST_JOB_DESC_REVIEW'].indexOf(this.checkProperty(this.petition ,'curWorkflowActivity')) <=-1  &&  this.isActiveCode("REQUEST_JOB_DESC_REVIEW")) 
          && (this.canReqJobDesReview || this.isAdmin) 
          && (this.petition.completedActivities.indexOf('CREATE_JOB_DESC') >-1 && this.petition.completedActivities.indexOf('APPROVE_JOB_DESC') <=-1)
           ) {
            return true
         }else{
            return false
         }
      },

      //(!checkInternalActivityRequires || ( checkInternalActivityRequires  && this.checkProperty(this.petition ,'curWorkflowActivity') !='INTERNAL_REQUEST_JOB_DESC_REVIEW' ) && (this.petition.completedActivities.indexOf('INTERNAL_JOB_DESC_SUGGESSION') >-1 || this.petition.completedActivities.indexOf('INTERNAL_APPROVE_JOB_DESC') >-1 ) )
      checkInternalActivityRequires(){
         let returnValue = false
      if(this.checkProperty(this.workFlowDetails ,'config' ,'length') >0){
      
       let internalApproveActiVity = _.find(this.workFlowDetails.config , {"code":'INTERNAL_APPROVE_JOB_DESC' ,"include":'Yes'});
         if(internalApproveActiVity){
            returnValue =true;
         }
      }
      return returnValue

      },
    //  REQUEST_JOB_DESC_REVIEW  cansendIndernalReview cansendIndernalApprove
    cansendIndernalReview(){
      let returnValue = false
      if(this.checkProperty(this.workFlowDetails ,'config' ,'length') >0){
       let createJd = _.find(this.workFlowDetails.config , {"code":'CREATE_JOB_DESC' ,"include":'Yes'});
       let internalApproveActiVity = _.find(this.workFlowDetails.config , {"code":'INTERNAL_APPROVE_JOB_DESC' ,"include":'Yes'});
      
       let createJdEditors = []; 
      
       if(createJd && createJd.editors){
         createJdEditors = _.map(createJd.editors, 'roleId');
       }

      
       
     // alert(JSON.stringify(this.checkAssignments))

       
        
      if(internalApproveActiVity && this.checkAssignments && (  this.petition.completedActivities.indexOf('REQUEST_JOB_DESC_REVIEW') <=-1 &&  this.petition.nextWorkflowActivity.indexOf('INTERNAL_REQUEST_JOB_DESC_REVIEW') >-1 &&  this.petition.completedActivities.indexOf('CREATE_JOB_DESC') >-1 )   ){

         if(this.isAdmin || createJdEditors.indexOf(this.getUserRoleId)>-1 ){
            returnValue = true;
         }
      }
   }

      return returnValue



    },
    cansendIndernalApprove(){
      let returnValue = false
      if(this.checkProperty(this.workFlowDetails ,'config' ,'length') >0){
       let createJd = _.find(this.workFlowDetails.config , {"code":'CREATE_JOB_DESC' ,"include":'Yes'});
       let internalApproveActiVity = _.find(this.workFlowDetails.config , {"code":'INTERNAL_APPROVE_JOB_DESC' });
      
       let createJdEditors = []; 
       let internalReqEditors =[];
       
       if(createJd && createJd.editors){
         createJdEditors = _.map(createJd.editors, 'roleId');
       }

       if(internalApproveActiVity && internalApproveActiVity.editors){
         internalReqEditors = _.map(internalApproveActiVity.editors, 'roleId');
       }
      
       if(
            this.petition.completedActivities.indexOf('REQUEST_JOB_DESC_REVIEW') <=-1 &&
            this.checkAssignments
            && this.petition.nextWorkflowActivity.indexOf('INTERNAL_APPROVE_JOB_DESC') >-1
             &&   this.petition.completedActivities.indexOf('CREATE_JOB_DESC') >-1 
            &&  this.petition.completedActivities.indexOf('APPROVE_JOB_DESC') <=-1 
            && (internalReqEditors.indexOf(this.getUserRoleId) >-1 )
            
            ){
               returnValue =true;
            }
     
         }
      return returnValue



    },
     
      checkActivityInlogs(){
         return (action='')=>{

         
         if(action){
           let log =  _.find(this.currentCaseDetails,{'action':action});
           if(log){
            return true;
           }else{
            return false;
           }

         }else{
            return false;
         }
      }

      },
      canFinailizeJobDesc(){
         let hasJobDetails =false;
       if(_.has(this.petition , 'hasJobDetails')){
          hasJobDetails = this.petition['hasJobDetails'];
       }
       if( this.checkProperty(this.finnailizePermJob ,'length') >0){
       let canFinnailizePermJob =this.finnailizePermJob.indexOf(this.getUserRoleId) > -1; 

         if (!hasJobDetails && this.checkAssignments && this.isActiveCode("FINALIZE_JOB_DESC") && (canFinnailizePermJob || this.isAdmin) && this.petition.completedActivities.indexOf('PWD_CERTIFID') <=-1  && this.petition.completedActivities.indexOf('EFILE_PWD') <=-1&&  this.petition.completedActivities.indexOf('APPROVE_JOB_DESC') >-1 && this.petition.completedActivities.indexOf('FINALIZE_JOB_DESC') <=-1){
              return true
         }else{
            return false;
         } 
      } 


      },
      canEditJobDesc(){
         //APPROVE_JOB_DESC_EDIT
         let hasJobDetails =false;
       if(_.has(this.petition , 'hasJobDetails')){
          hasJobDetails = this.petition['hasJobDetails'];
       }
         
       let canPermJobApprove =this.permJobApprove.indexOf(this.getUserRoleId) > -1; 
       let canEditPermJobDesc =this.permJobDesEditorsList.indexOf(this.getUserRoleId) > -1;
           
         if ( !hasJobDetails && this.checkAssignments &&
            ( this.jobdescriptionapprovallist.indexOf(this.getUserRoleId)<= -1 ) &&
            (this.petition.nextWorkflowActivity.indexOf('REQUEST_JOB_DESC_REVIEW')<=-1 && this.isActiveCode("APPROVE_JOB_DESC") && (canPermJobApprove || this.isAdmin) && this.petition.completedActivities.indexOf('REQUEST_JOB_DESC_REVIEW') >-1 && this.petition.completedActivities.indexOf('APPROVE_JOB_DESC') <=-1 ) || (this.checkProperty(this.petition ,'curWorkflowActivity') =='JOB_DESC_SUGGESSION' ) && (canEditPermJobDesc || this.isAdmin)
            || (this.checkProperty(this.petition ,'curWorkflowActivity') =='JOB_DESC_SUGGESSION' && (canEditPermJobDesc || this.isAdmin) )
            ){

            return true
         }else{ 

            return false


         }
      },
      canReqJobDesReview(){
         let hasJobDetails =false;
       if(_.has(this.petition , 'hasJobDetails')){
          hasJobDetails = this.petition['hasJobDetails'];
       }
       let canReqJobDesReview =this.reqJobDesReview.indexOf(this.getUserRoleId) > -1; 
       
         if ( this.checkInternalReviewCompleted && !hasJobDetails && this.checkAssignments &&  this.checkProperty(this.petition ,'curWorkflowActivity') !='REQUEST_JOB_DESC_REVIEW' &&  this.isActiveCode("REQUEST_JOB_DESC_REVIEW") && (canReqJobDesReview || this.isAdmin) && (this.petition.completedActivities.indexOf('CREATE_JOB_DESC') >-1 && this.petition.completedActivities.indexOf('APPROVE_JOB_DESC') <=-1) ){
              return true;
         }else{
            return false;
         } 


      },

      canSuggestJob(){
         if(this.checkProperty(this.petition ,'curWorkflowActivity') =='REQUEST_JOB_DESC_REVIEW' && this.jobdescriptionapprovallist.indexOf(this.getUserRoleId) > -1 ){

             return true;
         }else{
            return false;
         }
      },
      checkInternalReviewCompleted(){
         let returnValue = true
         if(this.checkProperty(this.workFlowDetails ,'config' ,'length') >0){

         
            //,"INTERNAL_REQUEST_JOB_DESC_REVIEW","INTERNAL_JOB_DESC_SUGGESSION",'INTERNAL_APPROVE_JOB_DESC'
         let internalApproveActiVity = _.find(this.workFlowDetails.config , {"code":'INTERNAL_REQUEST_JOB_DESC_REVIEW' ,"include":'Yes'});
         
         if(internalApproveActiVity){
            returnValue = false;
         let nextWorkflowActivity = [];
            if(this.checkProperty(this.petition ,'nextWorkflowActivity' ,'length') >0){
               nextWorkflowActivity = this.petition['nextWorkflowActivity'];
            }
            let internalActivityList =["INTERNAL_REQUEST_JOB_DESC_REVIEW","INTERNAL_JOB_DESC_SUGGESSION","INTERNAL_APPROVE_JOB_DESC"];
            if(nextWorkflowActivity.some(  (r) => internalActivityList.indexOf(r) >= 0 ) ){
               returnValue = false;
            }else{
               returnValue = true;
            }

         }

       return returnValue;
         
      }
      },
      
     
      canPermJobApprove(){

         //(
            // (!this.checkInternalActivityRequires || ( this.checkInternalActivityRequires  && this.checkProperty(this.petition ,'curWorkflowActivity') !='INTERNAL_REQUEST_JOB_DESC_REVIEW' ) && (this.petition.completedActivities.indexOf('INTERNAL_JOB_DESC_SUGGESSION') >-1 || this.petition.completedActivities.indexOf('INTERNAL_APPROVE_JOB_DESC') >-1 ) )
            // && (!hasJobDetails && this.checkAssignments && this.isActiveCode("APPROVE_JOB_DESC") && (canPermJobApprove || isAdmin) && this.petition.completedActivities.indexOf('CREATE_JOB_DESC') >-1 && this.petition.completedActivities.indexOf('APPROVE_JOB_DESC') <=-1 )
            // && !(this.checkProperty(this.petition ,'curWorkflowActivity') =='REQUEST_JOB_DESC_REVIEW' && this.jobdescriptionapprovallist.indexOf(this.getUserRoleId) > -1 )
            // )

         let hasJobDetails =false;
       if(_.has(this.petition , 'hasJobDetails')){
          hasJobDetails = this.petition['hasJobDetails'];
          
       }
      
       let canPermJobApprove =this.permJobApprove.indexOf(this.getUserRoleId) > -1; 

         if (
            (!this.checkInternalActivityRequires || ( this.checkInternalActivityRequires  && this.checkProperty(this.petition ,'curWorkflowActivity') !='INTERNAL_REQUEST_JOB_DESC_REVIEW' ) && (this.petition.completedActivities.indexOf('INTERNAL_JOB_DESC_SUGGESSION') >-1 || this.petition.completedActivities.indexOf('INTERNAL_APPROVE_JOB_DESC') >-1 ) )
            && (!hasJobDetails && this.checkAssignments && this.isActiveCode("APPROVE_JOB_DESC") && (canPermJobApprove || this.isAdmin) && this.petition.completedActivities.indexOf('CREATE_JOB_DESC') >-1 && this.petition.completedActivities.indexOf('APPROVE_JOB_DESC') <=-1 )
            && !(this.checkProperty(this.petition ,'curWorkflowActivity') =='REQUEST_JOB_DESC_REVIEW' && this.jobdescriptionapprovallist.indexOf(this.getUserRoleId) > -1 )
            ){
            return true
         }else{
            return false
         } 


      },
      checkAssignments(){
      let returnValue = true;
      if(this.workFlowDetails && _.has(this.workFlowDetails ,'config' )){
        let assignSuperVisorActiVity = _.find(this.workFlowDetails.config , {"code":'ASSIGN_SUPERVISOR' ,"include":'Yes'});
        let paralegalactiVity = _.find(this.workFlowDetails.config , {"code":'ASSIGN_PARALEGAL',"include":'Yes'});
        let attorneyactiVity = _.find(this.workFlowDetails.config , {"code":'ASSIGN_ATTORNEY',"include":'Yes'});
        let docm = _.find(this.workFlowDetails.config , {"code":'ASSIGN_DOCUMENTATION_MANAGER',"include":'Yes'});

      
        if(assignSuperVisorActiVity && this.checkProperty(assignSuperVisorActiVity, 'editors' ,'length')>0 && this.petition.completedActivities.indexOf('ASSIGN_SUPERVISOR') <= -1 ){
          returnValue =false;
        }
        if(paralegalactiVity && this.checkProperty(paralegalactiVity, 'editors' ,'length')>0 &&  this.petition.completedActivities.indexOf('ASSIGN_PARALEGAL') <= -1 ){
          returnValue =false;
        }
        if(attorneyactiVity && this.checkProperty(attorneyactiVity, 'editors' ,'length')>0 && this.petition.completedActivities.indexOf('ASSIGN_ATTORNEY') <= -1 ){
          returnValue =false;
        }

        if(docm && this.checkProperty(docm, 'editors' ,'length')>0 && this.petition.completedActivities.indexOf('ASSIGN_DOCUMENTATION_MANAGER') <= -1 ){
          returnValue =false;
        }
        if(!returnValue && this.checkProperty(this.workFlowDetails ,'workflowType') =="Free-Flow" ){
          returnValue =true;
        }
        if(!returnValue && this.checkProperty(this.workFlowDetails ,'workflowType') =="Free-Flow" ){
          returnValue =true;
        }
        
      }


      return returnValue;

     },
      checkCollectAdvertismentEdit(){
         let canEditPermAdvertisement =this.jobAdvertismentActivity.indexOf(this.getUserRoleId) > -1;
            let pwdStatus ='';
            if(_.has(this.petition , 'pwdStatus') && ['Filed' ,'Certified'].indexOf(this.petition['pwdStatus'])>-1 ){
            pwdStatus = this.petition['pwdStatus'];
            }
            if (
             // this.checkAssignments &&
              _.has(this.petition ,'completedActivities') && this.petition
              &&  this.isActiveCode("COLLECT_ADV_EVIDENCE") && (canEditPermAdvertisement || this.isAdmin) 
               && this.petition.completedActivities.indexOf('COLLECT_ADV_EVIDENCE') >-1 
               && this.petition.completedActivities.indexOf('UPLOAD_PERM_ACK') <=-1 
                &&(

                 (this.petition.completedActivities.indexOf('PWD_CERTIFID') >-1 )
                 || ( ( (['Filed'].indexOf(pwdStatus)>-1 || this.petition.completedActivities.indexOf('EFILE_PWD')>-1    ) && !this.approvedPwdReqForAdvEvidences)  || (['Certified'].indexOf(pwdStatus)>-1  ) )
                 

                 )
              
               ){
                return true
              }else{
                return false
              } 

      },
      checkCollectAdvertisment(){
         let canEditPermAdvertisement =this.jobAdvertismentActivity.indexOf(this.getUserRoleId) > -1;
            let pwdStatus ='';
            if(_.has(this.petition , 'pwdStatus') && ['Filed' ,'Certified'].indexOf(this.petition['pwdStatus'])>-1 ){
            pwdStatus = this.petition['pwdStatus'];
            }
         if (
              
               this.isActiveCode("COLLECT_ADV_EVIDENCE") && (canEditPermAdvertisement || this.isAdmin) 
               && this.petition.completedActivities.indexOf('COLLECT_ADV_EVIDENCE') <=-1 
              // && this.petition.completedActivities.indexOf('UPLOAD_PERM_ACK') <=-1 
                &&(

                 (this.petition.completedActivities.indexOf('PWD_CERTIFID') >-1 )
                 || ( ( (['Filed'].indexOf(pwdStatus)>-1 || this.petition.completedActivities.indexOf('EFILE_PWD')>-1    ) && !this.approvedPwdReqForAdvEvidences)  || (['Certified'].indexOf(pwdStatus)>-1  ) )
                 

                 )
              
               ){
                return true
              }else{
                return false
              } 

      },
      canUpdatePermQuestionnaire(){
         let canPreParePermApplication = this.preparePermActivity.indexOf(this.getUserRoleId) > -1; 
         if ( (canPreParePermApplication || this.isAdmin) 
          && (this.petition.nextWorkflowActivity.indexOf('REQUEST_PERM_DRAFT_REVIEW')>-1 || this.petition.nextWorkflowActivity.indexOf('APPROVE_PERM_APPLICATION')>-1 ) 
          && this.petition.completedActivities.indexOf('REQUEST_PERM_DRAFT_REVIEW')>-1 
          && this.petition.completedActivities.indexOf('APPROVE_PERM_APPLICATION')<=-1 
          && this.isActiveCode("PREPARE_PERM_APPLICATION") 
          && this.petition.completedActivities.indexOf('PREPARE_PERM_APPLICATION')>-1 ){
             return true
          }else{ 
            return false
         }

      },
      canApprovePermApplication(){
         let canPreParePermApplicationSuggssion = this.permSuggssitionActivity.indexOf(this.getUserRoleId) > -1; 
         let canApprovePermApplication = this.approvePermApplication.indexOf(this.getUserRoleId) > -1; 

         if (
            (
              this.petition.completedActivities.indexOf('EFILE_PREM_APPLICATION')>-1  
                 && this.isActiveCode("APPROVE_PERM_APPLICATION") 
              && (canApprovePermApplication || this.isAdmin) 
              && this.petition.completedActivities.indexOf('PREPARE_PERM_APPLICATION')>0 
             && this.petition.completedActivities.indexOf('APPROVE_PERM_APPLICATION')<=-1
          )&& !(
                ( this.petition.completedActivities.indexOf('APPROVE_PERM_APPLICATION')<=-1 
                  &&  this.isActiveCode("APPROVE_PERM_APPLICATION") && (canPreParePermApplicationSuggssion ) 
                  && this.petition.completedActivities.indexOf('PREPARE_PERM_APPLICATION')>=0 
                ) 
               && this.checkProperty(this.petition ,'curWorkflowActivity') !='PERM_DRAFT_SUGGESSION'
             
             ) 
          
          ){

           return true
          }else{
            return false
          }
      },
      getPermLogs(){
         //(['REVIEW_JOB_DESC_SUGGESSION' ,'REQUEST_JOB_DESC_REVIEW'].indexOf(
         let tempAgingLogs =[];
         
         let agingLogs = _.cloneDeep(this.currentCaseDetails);
         

         let tempActions ={};
         let actionCodes=[];
         if(this.checkProperty(this.currentCaseDetails ,'length')>0){
         
           
            _.forEach(agingLogs ,(log ,index)=>{
                let item =_.cloneDeep(log);
               actionCodes.push(item['action'])
              

               if(_.has(item ,'endedOn') && item['endedOn']){
                  item['endedOn'] = moment(item['endedOn'])

               }
               if(_.has(item ,'startedOn') && item['startedOn']){
                  item['startedOn'] = moment(item['startedOn'])

               }

               if(_.has(tempActions ,item['action'])){
                 
                     tempActions[item['action']]['actions'].push(item['action']); 
                    // tempActions[item['action']]['actionIndex'] = tempActions[item['action']]['actionIndex']+1;
                     let exists =_.filter(actionCodes ,(cod)=>cod==item['action'])
               
                     if(exists){
                        tempActions[item['action']]['actionIndex'] =exists.length;
                        
                     }
                 
                  
               }else{
                  tempActions[item['action']] = {'actionIndex':1 ,'actions':[]};
                  tempActions[item['action']]['actions'].push(item['action']); 
                  
                  
                  
                  
               }
              
               item[item['action']] = _.cloneDeep(tempActions[item['action']]);
               tempAgingLogs.push(item);

            })
            
            

            //asc ,desc
            tempAgingLogs  = _.orderBy( tempAgingLogs ,['endedOn'] ,['desc'] );
         
         }
        return tempAgingLogs;
        



      },
      
      getPerDraftmLogs(){
         //'REVIEW_PREM_DRAFT_SUGGESSION' ,'REQUEST_PERM_DRAFT_REVIEW'
         let tempAgingLogs =[];
         
         let agingLogs = _.cloneDeep(this.currentCaseDetails);
         

         let tempActions ={};
         let actionCodes=[];
         if(this.checkProperty(this.currentCaseDetails ,'length')>0){
         
           
            _.forEach(agingLogs ,(log ,index)=>{

               if(_.has(log ,'endedOn') && log['endedOn'] && !this.checkProperty(log ,'ignore')){
                     
                  let item =_.cloneDeep(log);
                  actionCodes.push(item['action'])
               

                  if(_.has(item ,'endedOn') && item['endedOn']){
                     item['endedOn'] = moment(item['endedOn'])

                  }
                  if(_.has(item ,'startedOn') && item['startedOn']){
                     item['startedOn'] = moment(item['startedOn'])

                  }

                  if(_.has(tempActions ,item['action'])){
                  
                        tempActions[item['action']]['actions'].push(item['action']); 
                     // tempActions[item['action']]['actionIndex'] = tempActions[item['action']]['actionIndex']+1;
                        let exists =_.filter(actionCodes ,(cod)=>cod==item['action'])
                  
                        if(exists){
                           tempActions[item['action']]['actionIndex'] =exists.length;
                           
                        }
                  
                     
                  }else{
                     tempActions[item['action']] = {'actionIndex':1 ,'actions':[]};
                     tempActions[item['action']]['actions'].push(item['action']); 
                     
                     
                     
                     
                  }
               
                  item[item['action']] = _.cloneDeep(tempActions[item['action']]);
                  if(['REVIEW_PREM_DRAFT_SUGGESSION' ,'REQUEST_PERM_DRAFT_REVIEW'].indexOf(item['action'])>-1){
                     tempAgingLogs.push(item);
                  }
               }

            })
            
            

            //asc ,desc
            tempAgingLogs  = _.orderBy( tempAgingLogs ,['endedOn'] ,['desc'] );
         
         }
        return tempAgingLogs;
        



      },

     
      getjobDescriptionLogs(){
         //(['REVIEW_JOB_DESC_SUGGESSION' ,'REQUEST_JOB_DESC_REVIEW'].indexOf(
         let tempAgingLogs =[];
         
         let agingLogs = _.cloneDeep(this.currentCaseDetails);
         

         let tempActions ={};
         let actionCodes=[];
         if(this.checkProperty(this.currentCaseDetails ,'length')>0){
         
           
            _.forEach(agingLogs ,(log ,index)=>{
               if(_.has( log,'endedOn') && log['endedOn']  && !this.checkProperty(log ,'ignore')){

               
                     let item =_.cloneDeep(log);
                     actionCodes.push(item['action'])
                  

                     if(_.has(item ,'endedOn') && item['endedOn']){
                        item['endedOn'] = moment(item['endedOn'])

                     }
                     if(_.has(item ,'startedOn') && item['startedOn']){
                        item['startedOn'] = moment(item['startedOn'])

                     }

                     if(_.has(tempActions ,item['action'])){
                     
                           tempActions[item['action']]['actions'].push(item['action']); 
                        // tempActions[item['action']]['actionIndex'] = tempActions[item['action']]['actionIndex']+1;
                           let exists =_.filter(actionCodes ,(cod)=>cod==item['action'])
                     
                           if(exists){
                              tempActions[item['action']]['actionIndex'] =exists.length;
                              
                           }
                     
                        
                     }else{
                        tempActions[item['action']] = {'actionIndex':1 ,'actions':[]};
                        tempActions[item['action']]['actions'].push(item['action']); 
                        
                        
                        
                        
                     }
                  
                     item[item['action']] = _.cloneDeep(tempActions[item['action']]);
                     
                     if( [ "JOB_DESC_SUGGESSION" ,"UPDATE_JOB_DESC",'REVIEW_JOB_DESC_SUGGESSION' ,'REQUEST_JOB_DESC_REVIEW' ,"INTERNAL_REQUEST_JOB_DESC_REVIEW","INTERNAL_JOB_DESC_SUGGESSION",'INTERNAL_APPROVE_JOB_DESC' ,].indexOf(item['action'])>-1){
                       if("JOB_DESC_SUGGESSION" ==item['action']){
                        if(this.checkProperty(item ,'data','jobDescSuggessionType' ) =="comments"){
                           tempAgingLogs.push(item);
                        }
                        
                       }else{
                        tempAgingLogs.push(item);
                       }
                       

                     }
               }
               

            })
            
            

            //asc ,desc
            tempAgingLogs  = _.orderBy( tempAgingLogs ,['endedOn'] ,['desc'] );
         
         }
        return tempAgingLogs;
        



      },
      canPermDraftSuggession(){
         let canPreParePermApplicationSuggssion = this.permSuggssitionActivity.indexOf(this.getUserRoleId) > -1; 
         if (( this.petition.completedActivities.indexOf('APPROVE_PERM_APPLICATION')<=-1 
          &&  this.isActiveCode("APPROVE_PERM_APPLICATION") && (canPreParePermApplicationSuggssion ) 
          && this.petition.completedActivities.indexOf('PREPARE_PERM_APPLICATION')>=0 ) 
          && this.checkProperty(this.petition ,'curWorkflowActivity') !='PERM_DRAFT_SUGGESSION' ){
            return true;
          }else{
            return false;
          } 
      },
      canPermDraftReviewRequest(){
         let canRequestPermDraftReview =false;
         if( this.workFlowDetails && this.checkProperty(this.workFlowDetails ,'config' ,'length')>0){
         let requestPermDraftReviewActivity = _.find(this.workFlowDetails.config , {"code":'REQUEST_PERM_DRAFT_REVIEW'});
            if(requestPermDraftReviewActivity && requestPermDraftReviewActivity.editors){
               let requestPermDraftReview = _.map(requestPermDraftReviewActivity.editors, 'roleId');
                canRequestPermDraftReview = requestPermDraftReview.indexOf(this.getUserRoleId) > -1 || this.isAdmin; 
               
            }
         }
            return canRequestPermDraftReview;
   
      },
       getTrackingNumber(){
          let courierTracking = _.find(this.petition['courierTrackingDetails'] ,{"category":'COURIER_TRACKING'});
          if(courierTracking){
           return this.checkProperty(courierTracking ,'trackingId' );
 
          }else{
           return ''
          } 
        
       },
        getTrackingUrl(){
         let courierTracking = _.find(this.petition['courierTrackingDetails'] ,{"category":'COURIER_TRACKING'});
          if(courierTracking){
           return this.checkProperty(courierTracking ,'trackingUrl' );
 
          }else{
           return ''
          }
       },
     },
      data: () => ({
         internalLogs:[],
         editor: ClassicEditor,
         editorConfig: {
            toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
         },
         approveParalegalComment:'',
         approveParalegalPopup:false,
         permJobDesEditorsList:[],
         jobdescriptionapprovallist:[],
         reqJobDesReview:[],
         permJobApprove:[],
         finnailizePermJob:[],
         showPermApproveinfo:false,
         jobAdvertismentActivity:[],
         approvedPwdReqForAdvEvidences:false,
         preparePermActivity:[],
         approvePermApplication:[],
         openPermJobDescActions:false,
         permSuggssitionActivity:[],
         adminsList:[3,4],
         isAdmin:false,
         updating:false,
         agingLogs:[],
         preparePermApplicationDateValidationError:'',
         avertisementList:[
        /* {
          startDateKey:'swaStartDate',
          endDateKey:'swaEndDate',
          documentKey:'jobFair'
        },
        */
        {
          startDateKey:'startDateOfSundayNewsPaper',
          endDateKey:'endDateOfSundayNewsPaper',
          documentKey:'sunday'
        },
        {
          startDateKey:'startDateOfAdvAtJobFair',
          endDateKey:'endDateOfAdvAtJobFair',
          documentKey:'jobFair'
        },
        {
          startDateKey:'startDateOfNonCampusRecru',
          endDateKey:'endDateOfNonCampusRecru',
          documentKey:'campusRecruitment'
        },
        {
          startDateKey:'startDateOfEmplrWebsitePosted',
          endDateKey:'endDateOfEmplrWebsitePosted',
          documentKey:'empWebsite'
        },
        {
          startDateKey:'startDateOfAdvWithTradeOrProfOrg',
          endDateKey:'startDateOfAdvWithTradeOrProfOrg',
          documentKey:'profOrgOrTrade'
        },
        {
          startDateKey:'startDateOfAdvEmpRefProgram',
          endDateKey:'endDateOfAdvEmpRefProgram',
          documentKey:'empRefProgram'
        },
        {
          startDateKey:'startDateOfListedInJobSite',
          endDateKey:'endDateOfListedInJobSite',
          documentKey:'jobSearchWebsite'
        },
        {
          startDateKey:'startDateOfListedInPrivateEmpFirm',
          endDateKey:'endDateOfListedInPrivateEmpFirm',
          documentKey:'pvtEmpmtFirm'
        },
        {
          startDateKey:'startDateOfAdvCampusPlacOfc',
          endDateKey:'endDateOfAdvCampusPlacOfc',
          documentKey:'campusPlacement'
        },
        {
          startDateKey:'startDateOfAdvLocalNewsPaper',
          endDateKey:'endDateOfAdvLocalNewsPaper',
          documentKey:'localNewsPaper'
        },
        {
          startDateKey:'startDateOfAdvInTVOrRadio',
          endDateKey:'endDateOfAdvInTVOrRadio',
          documentKey:'tvAds'
        },
      ],
       selecetedTab:1,
       statusTab:0,
       petitionhistory: [],
    
     }),
      props: {
         currentCaseDetails:{
              type: Array,
              default:new Array(),
         },
        petition: {
          type: Object,
          default: null
        }, 
        workFlowDetails:{
          type: Object,
          default: null
        }, 
        visastatuses: {
          type: Array,
          default: null
        }
      },
      components: {
         permJobActionModal,
         actionsPopup
         
      },
      methods: {
         init(){
           
            this.statusTab =0;
       setTimeout(()=>{
         
         this.efilePermApplicationRestriction();
         setTimeout(()=>{ 
            this.efilePermApplicationRestriction();
            this.init();
            this.processInternalLogs();
         } ,500);
         
         this.init();
         this.processInternalLogs();

       } ,500);
        

         }, 
         editJobDescription(){

            let activityCode =  "JOB_DESC_SUGGESSION";
            if(['JOB_DESC_SUGGESSION','INTERNAL_JOB_DESC_SUGGESSION'].indexOf(this.checkProperty(this.petition ,'curWorkflowActivity')) >-1){
              activityCode  =this.checkProperty(this.petition ,'curWorkflowActivity');
            }
          
            this.$refs['actionsPopups'].openUpdateJdModal(activityCode)
         },
         
         processInternalLogs(){
            this.internalLogs = [];
            let tempAgingLogs =[];
            let internalActivites = ["INTERNAL_REQUEST_JOB_DESC_REVIEW","INTERNAL_JOB_DESC_SUGGESSION","INTERNAL_APPROVE_JOB_DESC"];
            if(this.checkProperty(this.currentCaseDetails ,'length')>0){
            let agingLogs = _.cloneDeep(this.currentCaseDetails);
         
          
            _.forEach(agingLogs ,(item)=>{
               if(_.has(item ,'endedOn') && item['endedOn']){
                  item['endedOn'] = moment(item['endedOn'])

               }
               if(_.has(item ,'startedOn') && item['startedOn']){
                  item['startedOn'] = moment(item['startedOn'])

               }
               if(internalActivites.indexOf(item['action']) >-1){
                  tempAgingLogs.push(item);
               }
               

            })

            //asc ,desc
            this.internalLogs = _.orderBy( tempAgingLogs ,['endedOn'] ,['desc']);
           
         }

         },
         showPermInfoPopup(){
            this.showPermApproveinfo =false;
         if(this.petition && this.petition.completedActivities.indexOf('APPROVE_PERM_APPLICATION')>-1){
            
            this.showPermApproveinfo =true;
         }else{
            this.$refs["actionsPopups"].openPermAdvrtisementModal();
         }
      
    },
         editQuestionnaire(activityCode=''){
     
     if([3].indexOf(this.checkProperty(this.petition,'typeDetails', 'id' )) >-1 && [15].indexOf(this.checkProperty(this.petition,'subTypeDetails', 'id' )) >-1){
       
       if(activityCode =="PREPARE_PERM_APPLICATION"){
         this.$router.push("/permapplication-questionnaire/"+this.petition._id+"?fromedit=true");
       }else  if(activityCode =="PERM_DRAFT_SUGGESSION"){
         this.$router.push("/permapplicationSuggession-questionnaire/"+this.petition._id+"?fromedit=true");
        
       }else{
         this.$router.push("/perm-questionnaire/"+this.petition._id+"?fromedit=true");

       }
       
      
       //permapplication-questionnaire/
       //permapplicationSuggession-questionnaire
      
     }else{
       this.$router.push("/questionnaire/"+this.petition._id+"?fromedit=true");
     }
   
         },

         updatePet(){
            this.$emit("updatepetition", "Case Details");
         },
        
         isActiveCode(listcode){
          if(this.workFlowDetails && this.checkProperty( this.workFlowDetails ,'config')){
         let activytList =  _.find(this.workFlowDetails.config , {"code":listcode}); 
         if(activytList && activytList['include'] == 'Yes') return true;
         return false;
         }
         },

         approveParalegal(openpopUp=false){
            this.updating =false;
            if(!openpopUp){
               this.$validator.validateAll("approveParalegalForm").then((result) => {
                 
                  if(result){
                     
                     let data ={action:'' ,'petitionId':'' ,"typeName": "", 	"subTypeName": "", comment:'' };
                     data['comment'] = this.approveParalegalComment;

                     data['typeName'] = this.checkProperty( this.petition , 'typeDetails','name');
                     data['subTypeName'] = this.checkProperty( this.petition ,'subTypeDetails','name');
                     data['petitionId'] = this.checkProperty( this.petition ,'_id');
                     this.updating =true;
                     let path ="/perm/review-beneficiary-relation"
                     this.$store.dispatch('commonAction' ,{ "data":data ,'path':path})
                     .then((res)=>{
                       
                        this.approveParalegalPopup=false;
                        this.showToster({message:res['message'],isError:false });
                        this.updating =false;
                        setTimeout(() => {
                           this.$emit("updatepetition", "Case Details");
                        }, 0);
                       

                     })
                     .catch((error)=>{
                       
                        this.updating =false;
                        this.approveParalegalPopup=false;
                        this.showToster({message:error,isError:true });
                     })
                  }
            })
            }else{

               this.approveParalegalComment ='';
               this.approveParalegalPopup=true;
               this.$validator.reset();
            }

         },

         
         getHasAnyRelationWithBeneficiary(code=''){
            //UPLOAD_PERM_ACK
           
            let comments='';
            if(code){
               let activity = _.find(this.currentCaseDetails ,{'action':code});
              
               if(activity && this.checkProperty(activity ,'data' ,'hasAnyRelationWithBeneficiary')){

                  comments = activity['data']['hasAnyRelationWithBeneficiary']
               }

            }

            return comments;

            
         },
         getActivityComments(code=''){
            //UPLOAD_PERM_ACK
           
            let comments='';
            if(code){
               let activity = _.find(this.currentCaseDetails ,{'action':code});
              
               if(activity && this.checkProperty(activity ,'data' ,'comment')){

                  comments = activity['data']['comment']
               }

            }

            return comments;

            
         },
         getActivityByCode(code=''){
            //UPLOAD_PERM_ACK
           
           
            if(code){
               let activity = _.find(this.currentCaseDetails ,{'action':code});
              
               if(activity ){

                  return activity
               }

            }

            return null;

            
         },

         efilePermApplicationRestriction(){
     
               let pwdResponseDueDate=null;
               let today = moment().format("YYYY-MM-DD");
               try{
                  if(this.checkProperty(this.petition,'pwdResponse')){
                  pwdDetails = _.cloneDeep(this.petition.pwdResponse)
                  if(this.checkProperty(pwdDetails,'dueDate')){
                     startDate =pwdDetails['dueDate']
                     pwdResponseDueDate = moment(startDate).format("YYYY-MM-DD");
                  }
                  
                  }
               }catch(err){

                  pwdResponseDueDate=null;
               }
                  if(_.has(this.petition , 'completedActivities') && this.petition['completedActivities'].indexOf('PREPARE_PERM_APPLICATION')>-1){

                  let allAvertise =[];
                  
               //   let preparePermApplicationActivity = _.find(this.workFlowDetails.config , {"code":'PREPARE_PERM_APPLICATION'});
                     // startDateKey:'startDateOfAdvAtJobFair',
                     //endDateKey:'endDateOfAdvAtJobFair',
                  _.forEach(this.avertisementList ,(item)=>{
                  let tempItem = {
                     startDateVal:'',
                     endDateVal:''
                  }
                  
                  if(_.has(this.petition['recruitmentInfo'], item['startDateKey'] ) && this.checkProperty(this.petition['recruitmentInfo'] ,item['startDateKey'])  ){
                        try{
                        let startDateVal = this.petition['recruitmentInfo'][item['startDateKey']];
                        tempItem['startDateVal'] =moment(startDateVal).format("YYYY-MM-DD");
                        
                        }catch(err){
                        
                        

                        }
                  }
                  if(_.has(this.petition['recruitmentInfo'], item['endDateKey'] ) && this.checkProperty(this.petition['recruitmentInfo'], item['endDateKey'])  ){
                        try{
                        let endDateVal = this.petition['recruitmentInfo'][item['endDateKey']];
                        tempItem['endDateVal'] =moment(endDateVal).format("YYYY-MM-DD");

                        }catch(err){
                        

                        }
                  }
                  if(tempItem['startDateVal'] && tempItem['endDateVal'] ){
                     allAvertise.push(tempItem);
                  }

                  });
               
                  allAvertise = _.orderBy(allAvertise ,['startDateVal'] ,['asc']);
               if(this.checkProperty(allAvertise ,'length') >0){
                  let lastAdverStartDate = moment(allAvertise[0]['startDateVal']);
                  let dateDif = moment().diff(lastAdverStartDate, 'days') ;
                  

                  if(dateDif>179 || ( pwdResponseDueDate && pwdResponseDueDate !=null && ( today>pwdResponseDueDate)  )  ){  
                     
                     let msg ="PERM should be filed within 179 days from the date of first advertisement released";
                     if(( pwdResponseDueDate && pwdResponseDueDate !=null && ( today>pwdResponseDueDate)  )){
                        msg = "PERM should be filed prior to the date when PERM expires";
                     }

                     this.preparePermApplicationDateValidationError =msg;
                     //this.showToster({message:msg,isError:true });
                    // return false;
                  
                  }else{
                  //this.$refs["actionsPopup"].openPerDraftForm('EFILE_PREM_APPLICATION');
                  
                  }

               }else{
               // this.$refs["actionsPopup"].openPerDraftForm('EFILE_PREM_APPLICATION');
               }
               
               }else{
               // this.$refs["actionsPopup"].openPerDraftForm('EFILE_PREM_APPLICATION');
               }

     // 
         },
     
         checPreParePermApplicationRestriction(){

         let advCoolingPeriod =0;
         if(this.checkProperty(this.petition,'advCoolingPeriod') >0){
            advCoolingPeriod =parseInt(this.petition['advCoolingPeriod']);
         }
            this.preparePermApplicationDateValidationError ='';
           
            if(_.has(this.petition , 'completedActivities') && this.petition['completedActivities'].indexOf('PREPARE_PERM_APPLICATION')<=-1){

            
          
                   
                   
               let allAvertise =[];
               let today = moment().format("YYYY-MM-DD");
               let preparePermApplicationActivity = _.find(this.workFlowDetails.config , {"code":'PREPARE_PERM_APPLICATION'});
                   // startDateKey:'startDateOfAdvAtJobFair',
                   //endDateKey:'endDateOfAdvAtJobFair',
               _.forEach(this.avertisementList ,(item)=>{
               let tempItem = {
                   startDateVal:'',
                   endDateVal:''
               }
               
               if(_.has(this.petition['recruitmentInfo'], item['startDateKey'] ) && this.checkProperty(this.petition['recruitmentInfo'] ,item['startDateKey'])  ){
                   try{
                       let startDateVal = this.petition['recruitmentInfo'][item['startDateKey']];
                       tempItem['startDateVal'] =moment(startDateVal).format("YYYY-MM-DD");
                       
                   }catch(err){
                   
                       

                   }
               }
               if(_.has(this.petition['recruitmentInfo'], item['endDateKey'] ) && this.checkProperty(this.petition['recruitmentInfo'], item['endDateKey'])  ){
                   try{
                       let endDateVal = this.petition['recruitmentInfo'][item['endDateKey']];
                       tempItem['endDateVal'] =moment(endDateVal).format("YYYY-MM-DD");

                   }catch(err){
                       

                   }
               }
               if(tempItem['startDateVal'] && tempItem['endDateVal'] ){
                   allAvertise.push(tempItem);
               }

               });

               allAvertise = _.orderBy(allAvertise ,['startDateVal'] ,['desc']);
               if(this.checkProperty(allAvertise ,'length') >0){
               let lastAdverStartDate = moment(allAvertise[0]['startDateVal']);
               let dateDif = moment().diff(lastAdverStartDate, 'days') ;
               
               


               if(dateDif<advCoolingPeriod){  
                   let remainingDays = advCoolingPeriod-dateDif;

                   let msg ="It is recommended that a cooling period of "+advCoolingPeriod+" days must be maintained before the PERM Draft is created"
                   if(dateDif<0){         
                        if(lastAdverStartDate.isAfter(moment() ,'day')){

                        remainingDays = advCoolingPeriod+(lastAdverStartDate.diff(moment(), 'days'))

                        }  

                       msg ="It is recommended that a cooling period of "+remainingDays+" days must be maintained before the PERM Draft is created";
                    }else if(dateDif>0){
                       msg ="It has been "+dateDif+" since the last advertisement is placed. It is recommended that a cooling period of "+advCoolingPeriod+" days must be maintained before the PERM Draft is created"

                    }

               if(preparePermApplicationActivity && this.checkProperty(preparePermApplicationActivity ,'restrictPermDraftByAdvConfig') =="Yes"){
                  this.preparePermApplicationDateValidationError = msg
                  // this.showToster({message:"Prepare PERM only after 30 days of last advertisement",isError:true });
                 //  return false;
               }else{
                  this.preparePermApplicationDateValidationError = msg
                   //this.showToster({message:"Prepare PERM only after 30 days of last advertisement",isError:true });
                  // this.editQuestionnaire('PREPARE_PERM_APPLICATION');
               }
               }

               }
           

            }

    // 
         },
         reloadPetitionMe(tab='Job Details'){
            
            this.$emit('reloadPetitionMe' ,tab)

         },
        
         getActionCompletedDate(code=''){
             let returnValue=null;
             if(code){
                 let item = _.find( this.currentCaseDetails , {"action":code});
                 if(item && this.checkProperty( item, 'endedOn')){

                     returnValue = item['endedOn']

                 }


             }
             return returnValue;

         },
         getActionStartDate(code=''){
             let returnValue="";
             if(code){
                 let item = _.find( this.currentCaseDetails , {"action":code});
               if(item && this.checkProperty( item, 'startedOn')){

                  returnValue = item['startedOn']

               }
             }
             return returnValue;

         },
          downloadfile(value) {
            this.$emit('download_or_view' ,value);
          // value.url = value.url.replace(this.$globalgonfig._S3URL,"");
          // value.url = value.url.replace(this.$globalgonfig._S3URLAWS,"");
          // let postdata = { keyName: value.url };
          // this.$store.dispatch("getSignedUrl", postdata).then(response => {
          //   window.open(response.data.result.data, "_blank");
          // });
        },
        init(){

         if(this.checkProperty(this.currentCaseDetails ,'length')>0){
            let agingLogs = _.cloneDeep(this.currentCaseDetails);
            this.agingLogs = [];
            let tempAgingLogs =[];
            _.forEach(agingLogs ,(item)=>{
               if(_.has(item ,'endedOn') && item['endedOn']){
                  item['endedOn'] = moment(item['endedOn'])

               }
               if(_.has(item ,'startedOn') && item['startedOn']){
                  item['startedOn'] = moment(item['startedOn'])

               }
               
               tempAgingLogs.push(item);

            })

            //asc ,desc
            this.agingLogs = _.orderBy( tempAgingLogs ,['endedOn'] ,['desc'] );
           
         }

          if(this.workFlowDetails && this.checkProperty(this.workFlowDetails ,'config' ,'length' )>0){
            let permSuggssitionActivity = _.find(this.workFlowDetails.config , {"code":'PERM_DRAFT_SUGGESSION'});
            permSuggssitionActivity = _.find(this.workFlowDetails.config , {"code":'APPROVE_JOB_DESC'});
            if(permSuggssitionActivity && permSuggssitionActivity.editors){
            this.permSuggssitionActivity = _.map(permSuggssitionActivity.editors, 'roleId');
            }


               let adminsactiVityList = _.find(this.workFlowDetails.config , {"code":'MANAGER_LIST'});
               if(adminsactiVityList && adminsactiVityList.editors){
               this.adminsList = _.map(adminsactiVityList.editors, 'roleId');
               }


            this.isAdmin = this.adminsList.indexOf(this.getUserRoleId) > -1

         let approvePermApplication = _.find(this.workFlowDetails.config , {"code":'APPROVE_PERM_APPLICATION'});
         if(approvePermApplication && approvePermApplication.editors){
            this.approvePermApplication = _.map(approvePermApplication.editors, 'roleId');
         }

            let preparePermActivity = _.find(this.workFlowDetails.config , {"code":'PREPARE_PERM_APPLICATION'});
            if(preparePermActivity && preparePermActivity.editors){
                this.preparePermActivity = _.map(preparePermActivity.editors, 'roleId');
            }

            let permDraftreview = _.find(this.workFlowDetails.config , {"code":'REQUEST_PERM_DRAFT_REVIEW'});
            if(permDraftreview && permDraftreview.editors){
               _.forEach(permDraftreview.editors ,(editor)=>{
                  this.preparePermActivity.push(editor['roleId'])
               });

            }

               let jobAdvertismentActivity = _.find(this.workFlowDetails.config , {"code":'COLLECT_ADV_EVIDENCE'});
               if(jobAdvertismentActivity && jobAdvertismentActivity.editors){
                  this.approvedPwdReqForAdvEvidences = false;
               if(_.has(jobAdvertismentActivity ,'approvedPwdReqForAdvEvidences') && jobAdvertismentActivity['approvedPwdReqForAdvEvidences'] =='Yes'){
                  this.approvedPwdReqForAdvEvidences = jobAdvertismentActivity['approvedPwdReqForAdvEvidences']==='Yes'?true:false;
               }
               this.jobAdvertismentActivity = _.map(jobAdvertismentActivity.editors, 'roleId');
               }

               let permJobApprove = _.find(this.workFlowDetails.config , {"code":'APPROVE_JOB_DESC'});
               if(permJobApprove && permJobApprove.editors){
               this.permJobApprove = _.map(permJobApprove.editors, 'roleId');
               }

               let finnailizePermJob = _.find(this.workFlowDetails.config , {"code":'FINALIZE_JOB_DESC'});
               if(finnailizePermJob && finnailizePermJob.editors){
               this.finnailizePermJob = _.map(finnailizePermJob.editors, 'roleId');
               }
               let reqJobDesReview = _.find(this.workFlowDetails.config , {"code":'REQUEST_JOB_DESC_REVIEW'});
               if(reqJobDesReview && reqJobDesReview.editors){
                  this.reqJobDesReview = _.map(reqJobDesReview.editors, 'roleId');
               }

               let jobdescriptionapprovallisteditors= _.find(this.workFlowDetails.config , {"code":'APPROVE_JOB_DESC'});

               if(jobdescriptionapprovallisteditors && jobdescriptionapprovallisteditors.editors){
               this.jobdescriptionapprovallist = _.map(jobdescriptionapprovallisteditors.editors, 'roleId');
               }
            
               let permJobDesEditorsList = _.find(this.workFlowDetails.config , {"code":'CREATE_JOB_DESC'});
               if(permJobDesEditorsList && permJobDesEditorsList.editors){
                  this.permJobDesEditorsList = _.map(permJobDesEditorsList.editors, 'roleId');
               }
         }






        }
        
      },
      mounted() { 
      this.init();
      }
    };
 </script>