<template>
<div>
    <template v-if="openTabes && checkCurrentUrl">
        <div class="tab-inner-content">
          <div class="tabs-content-panel tab-pad-wrap">
                <div class="card-panels">
                
                 
                  <vs-row vs-justify="center" >
            
             
                      <vs-col class="p-0" type="flex" vs-justify="center" vs-align="center" vs-w="12">
                        <div class="forms_letters"> 
                          <vs-tabs>
                              <vs-tab label="Documents" @click="changeTab('documentsList')" >
                                <template v-if="!editDocuments">
                                  <!-- {{ petition.documents['slgOfferLetter'] }} -->
                                  <div class="form_section pad20 white_bg" v-if="(canRenderField('slgOfferLetter', fieldsArray, false, 'documents', 'slgOfferLetter') ||
                                    canRenderField('slgSignedOfferLetter', fieldsArray, false, 'documents', 'slgSignedOfferLetter')) && fieldsArray && checkProperty(fieldsArray,'length')>0 && !loadedFromPreview">
                                    <h3 class="title-header">
                                      Offer Letter
                                     </h3>
                                      <template v-if="currentRole !=51" >
                                        <div class="edit_comp_casedocs">
                                          <casedocumentslist :showTitle="false" :docslist="offerDocslist" :petition="petition" formscope="" :fieldsArray="fieldsArray" v-model="offerDocuments" :tplsection="'documents'"  :fieldName="''" ></casedocumentslist>
                                        </div>
                                      </template>
                                      <template v-else >
                                        <vs-row class="mt-4" v-if="checkProperty(petition['documents'],'slgOfferLetter') && checkProperty(petition['documents'],'slgOfferLetter','length')>0
                                        && canRenderField('slgOfferLetter', fieldsArray, false, 'documents', 'slgOfferLetter')  " >
                                          <vs-col class="padl0 padr0">
                                            <div class="card-panels pad0">
                                              <vs-card>
                                                <div slot="header" >
                                                  <h3>Unsigned Offer Letter</h3> 
                                                </div>
                                                <div>
                                                  <div>
                                                  <template v-for="(item ,ind ) in  checkProperty(petition['documents'],'slgOfferLetter')" >
                                                
                                                    <div class="documents__list" v-if="checkProperty( item,'status') !=false" v-bind:key="ind">
                                                      <div class="documents__title" @click="downloadfile(item)" >
                                                        <figure > 
                                                          <img v-if="checkFileFormat(item['mimetype']) =='pdf'" src="@/assets/images/main/pdf.svg" /> 
                                                          <img v-else-if="checkFileFormat(item['mimetype']) =='video_mime_types'" src="@/assets/images/main/film.png" />
                                                          <img v-else-if="checkFileFormat(item['mimetype']) =='msDoc'" src="@/assets/images/main/doc.svg" />
                                                          <img v-else-if="checkFileFormat(item['mimetype']) =='zip'" src="@/assets/images/main/zip-file-format.png" />
                                                          <img v-else-if="checkFileFormat(item['mimetype']) =='msPpt'" src="@/assets/images/main/ppt.svg" />
                                                          <img v-else-if="checkFileFormat(item['mimetype']) =='msXl'" src="@/assets/images/main/xls.svg" />
                                                          <img v-else-if="checkFileFormat(item['mimetype']) =='image'" src="@/assets/images/main/image.svg" />
                                                          <img v-else src="@/assets/images/main/icon-img.svg" />
                                                        </figure>
                                                    
                                                        <span >
                                                          
                                                          <em class="fl_scanned_docs" :title="item.name">{{item.name}}</em>
                                                          <small class="uploaded_doc_small" v-if="!loadedFromPreview"> 
                                                            <p><span v-if="getformated(item)"> {{ getformated(item) }}</span><span v-if="checkProperty(item,'uploadedByName')"> - Uploaded By {{ item['uploadedByName']}} <em v-if="checkProperty(item,'uploadedByRoleName')">({{ item['uploadedByRoleName'] }})</em></span></p>
                                                          </small>                                                                        
                                                        </span>
                                                      </div>
                                                      <div class="documents__actions">
                                                        <button  @click="downloads3file(item)" class="view-btn px-4 w-auto">Download</button>
                                                      </div>
                                                    </div>
                                                    </template>
                                                  </div>
                                                </div>
                                              </vs-card>
                                            </div>
                                          </vs-col>
                                        </vs-row>
                                        <div class="edit_comp_casedocs">
                                          <casedocumentslist :showTitle="false" :showToBeneficiary="true" :docslist="benOfferDocslist" :petition="petition" formscope="" :fieldsArray="fieldsArray" v-model="offerDocuments" :tplsection="'documents'"  :fieldName="''" ></casedocumentslist>
                                        </div>
                                      </template>
                                       
                                      <!-- <button @click="updateOfferDocs()" class="primary-btn update-btn">
                                      <span>Update</span></button>  slgSignedOfferLetter-->
                                      <div class="popup-footer mt-0 pt-4 pr-0 h-auto relative">
                                        <button :disabled="documensUpdating ||(([51].indexOf(getUserRoleId)>-1 && checkProperty(offerDocuments, 'slgSignedOfferLetter', 'length')<=0  ) || 
                                          ([51].indexOf(getUserRoleId)<=-1 && checkProperty(offerDocuments, 'slgOfferLetter', 'length')<=0 && checkProperty(offerDocuments, 'slgSignedOfferLetter', 'length')<=0) )"
                                         @click="updateOfferDocs()" class="btn save"><span>Update</span></button>
                                      </div>
                                       
                                  
                                  </div>
                                      <div class="main-list-wrap pad0">
                                        <div class="tab-inner-content">
                                          <div class="doc_top_bar" v-if="documentsUploadbtn && false">
                                          <p >(File Type: PDF, DOC, JPEG, PNG. Max file size: 1MB)</p>

                                                
                                          </div>
                                          <div >
                                            <div class="doc_header pt-0 d" >
                                              <h3 class="small-header mart25"  >
                                              <template >
                                              Documents
                                              </template>
                                              </h3>
                                              <div class="d-flex" v-if="!loadedFromPreview">   
                                            
                                                <button v-if="checkNoNotifyUserIds && editableDocs && questionnaireDetails" @click="openEditDocs(true)" class="edit-doc"> <img src="@/assets/images/main/icon-edit.svg" />Upload Documents</button>
                                                <button v-if="checkCurrentUrl && allbtn && (todalDocumentsCount>0 ||spouseDocumentCount>0 || totalChildDocumentCount>0 )" @click="downloadallfile()"  class="download_all">Download Documents</button>
                                                 <button v-if="is_enablesavebtn" @click="saveUploadedsFiles()" class="documents_save">Save</button>
                                              </div>
                                              
                                            </div>
                                            <template  v-if="todalDocumentsCount > 0">
                                    
                                              
                                                <div :key="docs" v-for="(type,docs) in  petitiondocuments" >
                                                  <!-- <div :key="index" v-for="(item,index) in  type" v-if="item.showMe==true"> -->
                                                      <vs-row v-if="['beneficiaryDocs','slgOfferLetter'].indexOf(docs)<=-1

                                                       && type && (type.length > 0 || ((currentRole ==50 || currentRole == 51) && petition.documentsUploadEnabled )) && checkDocumentsExists(type) " >
                                                        <vs-col class="padl0 padr0">
                                                          <div class="card-panels pad0">
                                                            <vs-card>
                                                              <div slot="header" >
                                                                <h3>{{docs | formatdoctype}}</h3> 
                                                                
                                                                <div
                                                                  class="doc_upload upload_documents"
                                                                  @click="selectDoctype(docs)"
                                                                  v-if="(currentRole ==50|| currentRole == 51) && petition.documentsUploadEnabled && checkProperty(getPetitionDetails ,'status' )!=false"
                                                                >

                                                                  <file-upload
                                                                    v-model="profilePicture"
                                                                    class="file-upload-input"
                                                                    v-bind:name="docs"
                                                                    v-bind:data-vv-as="docs"
                                                                    :multiple="false"
                                                                    :accept="allDocEntity"
                                                                    @input="upload(profilePicture ,docs)"
                                                                  >
                                                                    <img class="file-icon" src="@/assets/images/main/file-upload.svg" /> Upload 
                                                                  </file-upload>
                                                                </div>
                                                              </div>
                                                              <div>
                                                                <div>
                                                                <template v-for="(item ,ind ) in  type" >
                                                              
                                                                  <div class="documents__list" v-if="checkProperty( item,'status') !=false" v-bind:key="ind">
                                                                    <div class="documents__title" @click="downloadfile(item)" >
                                                                      <figure > 
                                                                        <img v-if="checkFileFormat(item['mimetype']) =='pdf'" src="@/assets/images/main/pdf.svg" /> 
                                                                        <img v-else-if="checkFileFormat(item['mimetype']) =='video_mime_types'" src="@/assets/images/main/film.png" />
                                                                        <img v-else-if="checkFileFormat(item['mimetype']) =='msDoc'" src="@/assets/images/main/doc.svg" />
                                                                        <img v-else-if="checkFileFormat(item['mimetype']) =='zip'" src="@/assets/images/main/zip-file-format.png" />
                                                                        <img v-else-if="checkFileFormat(item['mimetype']) =='msPpt'" src="@/assets/images/main/ppt.svg" />
                                                                        <img v-else-if="checkFileFormat(item['mimetype']) =='msXl'" src="@/assets/images/main/xls.svg" />
                                                                        <img v-else-if="checkFileFormat(item['mimetype']) =='image'" src="@/assets/images/main/image.svg" />
                                                                        <img v-else src="@/assets/images/main/icon-img.svg" />
                                                                      </figure>
                                                                  
                                                                      <span >
                                                                        
                                                                        <em class="fl_scanned_docs" :title="item.name">{{item.name}}</em>
                                                                        <small class="uploaded_doc_small" v-if="!loadedFromPreview"> 
                                                                          <p><span v-if="getformated(item)"> {{ getformated(item) }}</span><span v-if="checkProperty(item,'uploadedByName')"> - Uploaded By {{ item['uploadedByName']}} <em v-if="checkProperty(item,'uploadedByRoleName')">({{ item['uploadedByRoleName'] }})</em></span></p>
                                                                        </small>                                                                        
                                                                      </span>
                                                                    </div>
                                                                    <div class="documents__actions d-flex">
                                                                      <button @click="removethis(ind ,type)" v-if="checkProperty( item, 'tempDoc')==true" class="view-btn ml-2">Remove</button>
                                                                      <button v-else @click="downloadfile(item,false,true)" class="view-btn ml-2">View</button>
                                                                      <button v-if="!loadedFromPreview && [50,51].indexOf(getUserRoleId)<=-1"  @click="confirmDocumentDelete(item,docs,ind,'Beneficiary')" class="view-btn ml-2">Delete</button>
                                                                    </div>
                                                                  </div>
                                                                  </template>
                                                                </div>
                                                              </div>
                                                            </vs-card>
                                                          </div>
                                                        </vs-col>
                                                      </vs-row>
                                                  <!-- </div> -->
                                                </div> 
                                            </template>
                                          
                                            <!------------Spouse Documents-------->
                                          
                                          <template  v-if=" checkProperty(petition ,'subTypeDetails' ,'id')  && spouseDocumentCount>0&&(checkProperty( petition , 'dependentsInfo' ,'spouse'))" >

                                          
                                            <template v-if="checkProperty( petition['dependentsInfo'] ,'spouse','documents')" >
                                              <div class="doc_header pt-0 d" v-if="Object.entries(petitiondocumentr).length>0 || [10,2].indexOf(checkProperty(petition ,'typeDetails' ,'id'))>-1" >
                                                <h3 class="small-header mart25" >Spouse Documents</h3>
                                              </div>
                                              <div :key="docs" v-for="(type,docs) in  petitiondocumentr">
                                                <!-- <div :key="index" v-for="(item,index) in  type"> -->
                                                 
                                                  <vs-row v-if="docs !='beneficiaryDocs' && type && (type.length > 0 || ((currentRole ==50 || currentRole == 51) && petition.documentsUploadEnabled )) && checkDocumentsExists(type) " >
                                                    <vs-col class="padl0 padr0">
                                                      <div class="card-panels pad0">
                                                          <vs-card>
                                                          <div slot="header" >
                                                            <h3>{{docs | formatdoctype}}</h3> 
                                                            <div
                                                              class="doc_upload upload_documents"
                                                              @click="selectDoctype(docs)"
                                                              v-if="(currentRole ==50|| currentRole == 51) && petition.documentsUploadEnabled"
                                                            >

                                                              <file-upload
                                                                v-model="profilePicture"
                                                                class="file-upload-input"
                                                                v-bind:name="docs"
                                                                v-bind:data-vv-as="docs"
                                                                :multiple="false"
                                                                :accept="allDocEntity"
                                                                @input="upload(profilePicture ,docs)"
                                                              >
                                                                <img class="file-icon" src="@/assets/images/main/file-upload.svg" /> Upload 
                                                              </file-upload>
                                                            </div>
                                                          </div>
                                                          <div>
                                                            <div>
                                                            
                                                            <template v-for="(item ,ind ) in  type" >
                                                              
                                                              <div class="documents__list" v-if="checkProperty( item,'status') !=false" v-bind:key="ind">
                                                                <div class="documents__title" @click="downloadfile(item)" >
                                                                  <figure > 
                                                                    <img v-if="checkFileFormat(item['mimetype']) =='pdf'" src="@/assets/images/main/pdf.svg" /> 
                                                                    <img v-else-if="checkFileFormat(item['mimetype']) =='video_mime_types'" src="@/assets/images/main/film.png" />
                                                                    <img v-else-if="checkFileFormat(item['mimetype']) =='msDoc'" src="@/assets/images/main/doc.svg" />
                                                                    <img v-else-if="checkFileFormat(item['mimetype']) =='zip'" src="@/assets/images/main/zip-file-format.png" />
                                                                    <img v-else-if="checkFileFormat(item['mimetype']) =='msPpt'" src="@/assets/images/main/ppt.svg" />
                                                                    <img v-else-if="checkFileFormat(item['mimetype']) =='msXl'" src="@/assets/images/main/xls.svg" />
                                                                    <img v-else-if="checkFileFormat(item['mimetype']) =='image'" src="@/assets/images/main/image.svg" />
                                                                    <img v-else src="@/assets/images/main/icon-img.svg" />
                                                                  </figure> 
                                                                  <span >

                                                                    <em class="fl_scanned_docs" :title="item.name">{{item.name}}</em>
                                                                    <small class="uploaded_doc_small" v-if="!loadedFromPreview"> 
                                                                      <p><span v-if="getformated(item)"> {{ getformated(item) }}</span><span v-if="checkProperty(item,'uploadedByName')"> - Uploaded By {{ item['uploadedByName']}} <em v-if="checkProperty(item,'uploadedByRoleName')">({{ item['uploadedByRoleName'] }})</em></span></p>
                                                                    </small>
                                                                  
                                                                  </span>
                                                                </div>
                                                                <div class="documents__actions d-flex" >
                                                                  <button @click="removethis(ind ,type)" v-if="checkProperty( item, 'tempDoc')==true" class="view-btn ml-2">Remove</button>
                                                                  <button v-else @click="downloadfile(item,false,true)" class="view-btn ml-2">View</button>
                                                                  <button v-if="!loadedFromPreview && [50,51].indexOf(getUserRoleId)<=-1"  @click="confirmDocumentDelete(item,docs,ind,'Spouse')" class="view-btn ml-2">Delete</button>
                                                                </div>
                                                              </div>
                                                              </template>
                                                            </div>
                                                          </div>
                                                        </vs-card>
                                                      </div>
                                                    </vs-col>
                                                  </vs-row>
                                                <!-- </div> -->
                                              </div>
                                            
                                          </template>
                                            
                                          </template>
                                      
                                          <!-----------Children Documents---------->
                       
                                            <template  v-if="checkProperty(petition ,'subTypeDetails' ,'id') && allChildrens.length>0 && totalChildDocumentCount>0 && (checkProperty( petition , 'dependentsInfo' ,'childrens')) " >
                                              <template v-if="(checkProperty( petition['dependentsInfo'] ,'childrens' ,'length'))" >
                                              <!-------------LooEach Child--   -->
                                      
                                              <template v-for="( child ,cind ) in allChildrens" >
                                                  <template> 
                                                    <div  :key="cind">
                                                    <div class="doc_header pt-0 d" >
                                                      <h3 class="small-header mart25" v-if="checkProperty(child ,'name' )" >Child {{child.name }} Documents</h3>
                                                      <h3 class="small-header mart25" v-else >Child {{ cind+1 }} Documents</h3>
                                                    </div>
                                                    <div :key="docs" v-for="(type,docs) in  child['documents']">
                                                      <!-- <div :key="index" v-for="(item,index) in  type" > -->
                                                     
                                                    <vs-row v-if="docs !='beneficiaryDocs' && type && (type.length > 0 || ((currentRole ==50 || currentRole == 51) && petition.documentsUploadEnabled )) && checkDocumentsExists(type) " >
                                                      <vs-col class="padl0 padr0">
                                                        <div class="card-panels pad0">
                                                          <vs-card>
                                                            <div slot="header" >
                                                              <h3>{{docs | formatdoctype}}</h3> 
                                                              <div
                                                                class="doc_upload upload_documents"
                                                                @click="selectDoctype(docs)"
                                                                v-if="(currentRole ==50|| currentRole == 51) && petition.documentsUploadEnabled"
                                                              >

                                                                <file-upload
                                                                  v-model="profilePicture"
                                                                  class="file-upload-input"
                                                                  v-bind:name="docs"
                                                                  v-bind:data-vv-as="docs"
                                                                  :multiple="false"
                                                                  :accept="allDocEntity"
                                                                  @input="upload(profilePicture ,docs)"
                                                                >
                                                                  <img class="file-icon" src="@/assets/images/main/file-upload.svg" /> Upload 
                                                                </file-upload>
                                                              </div>
                                                            </div>
                                                            <div>
                                                              <div>
                                                              <template v-for="(item ,ind ) in  type" >
                                                                <div class="documents__list" v-if="checkProperty( item,'status') !=false" v-bind:key="ind">
                                                                  <div class="documents__title" @click="downloadfile(item)">
                                                                    <figure > 
                                                                      <img v-if="checkFileFormat(item['mimetype']) =='pdf'" src="@/assets/images/main/pdf.svg" /> 
                                                                      <img v-else-if="checkFileFormat(item['mimetype']) =='video_mime_types'" src="@/assets/images/main/film.png" />
                                                                      <img v-else-if="checkFileFormat(item['mimetype']) =='msDoc'" src="@/assets/images/main/doc.svg" />
                                                                      <img v-else-if="checkFileFormat(item['mimetype']) =='zip'" src="@/assets/images/main/zip-file-format.png" />
                                                                      <img v-else-if="checkFileFormat(item['mimetype']) =='msPpt'" src="@/assets/images/main/ppt.svg" />
                                                                      <img v-else-if="checkFileFormat(item['mimetype']) =='msXl'" src="@/assets/images/main/xls.svg" />
                                                                      <img v-else-if="checkFileFormat(item['mimetype']) =='image'" src="@/assets/images/main/image.svg" />
                                                                      <img v-else src="@/assets/images/main/icon-img.svg" />
                                                                      


                                                                    </figure>
                                                                    <span>
                                                                      <!-- {{item.name}} -->
                                                                      <em class="fl_scanned_docs" :title="item.name">{{item.name}}</em>
                                                                    <small class="uploaded_doc_small" v-if="!loadedFromPreview"> 
                                                                      <p><span v-if="getformated(item)"> {{ getformated(item) }}</span><span v-if="checkProperty(item,'uploadedByName')"> - Uploaded By {{ item['uploadedByName']}} <em v-if="checkProperty(item,'uploadedByRoleName')">({{ item['uploadedByRoleName'] }})</em></span></p>
                                                                    </small>
                                                                    </span>
                                                                  </div>
                                                                  <div class="documents__actions d-flex" >
                                                                    <button @click="removethis(ind ,type)" v-if="checkProperty( item, 'tempDoc')==true" class="view-btn ml-2">Remove</button>
                                                                    <button v-else @click="downloadfile(item,false,true)" class="view-btn ml-2">View</button>
                                                                    <button v-if="!loadedFromPreview && [50,51].indexOf(getUserRoleId)<=-1"  @click="confirmDocumentDelete(item,docs,child,'Child')" class="view-btn ml-2">Delete</button>
                                                                  </div>
                                                                </div>
                                                                </template>
                                                              </div>
                                                            </div>
                                                          </vs-card>
                                                        </div>
                                                      </vs-col>
                                                    </vs-row>
                                                  <!-- </div> -->
                                                  </div>
                                                    </div>
                                                  </template>
                                              </template>
                                              
                                              </template>
                                          </template>
                                            <NoDataFound :loading="false"   :update_loading="updateNodataLoading('NoDataFoundReff')"  ref="NoDataFoundReff"  content=""  heading="No Documents Found." type='documents'   v-if="spouseDocumentCount <= 0 && [10,2].indexOf(checkProperty(petition ,'typeDetails' ,'id'))>-1" />
                                            <NoDataFound :loading="false"   :update_loading="updateNodataLoading('NoDataFoundRefBen')"  ref="NoDataFoundRefBen"  content=""  heading="No Spouse Documents Found." type='documents'   v-if="(todalDocumentsCount<=0 && (spouseDocumentCount<=0 && checkProperty(petition ,'subTypeDetails' ,'id') !=16) && (totalChildDocumentCount<=0 && checkProperty(petition ,'subTypeDetails' ,'id') !=16) )" /> 
                                          </div>
                                        </div>
                                      </div>
                                 </template>
                                 <template v-else> 
                                  
                                  <template v-if="checkProperty(petition,'typeDetails','id') == 9 "> 
                                    <div class="main-list-wrap sdgf pad0 editCaseDocuments  doc__list rfe_petition_docs">
                                    <documentsUploadcomp v-if="editDocuments" :petition="petition" :fieldsArray="fieldsArray" :questionnaireDetails="questionnaireDetails"
                                     @reloadCaseDetails="reloadCaseDetails"  @openEditDocs="openEditDocs"  />
                                  </div>
                                </template>
                                <template v-if="checkProperty(petition,'typeDetails','id') == 2 "> 
                                    <div class="main-list-wrap sdgf pad0 editCaseDocuments  doc__list rfe_petition_docs">
                                    <documentsUploadcomp v-if="editDocuments" :petition="petition" :fieldsArray="fieldsArray" :questionnaireDetails="questionnaireDetails" :showSpouseDocs="true"
                                     @reloadCaseDetails="reloadCaseDetails"  @openEditDocs="openEditDocs" :benDocumentList="benh4DocumList" :spouseDocumentList="spouseH4DocumentList"  />
                                  </div>
                                </template>
                                  <template v-else>
                                   
                                  <div class="main-list-wrap sdgf pad0 editCaseDocuments pad20 doc__list">
                                    <caseQuestionnaireDocs :fieldsArray="fieldsArray" @downloadOrView="downloadfile" v-if="editDocuments" :petitionDetails="petition" :questionnaireDetails="questionnaireDetails"  @reloadCaseDetails="reloadCaseDetails" :tempDocuments="documents" :callFromEdit='true' @openEditDocs="openEditDocs" />
                                  </div>    
                                </template>
                              </template>
                              </vs-tab>
                              <vs-tab v-if="!loadedFromPreview" label="Additional Documents" @click="changeTab('UploadDocuments')" >
                                <div class="main-list-wrap pad0">
                                  <div class="tab-inner-content">
                                    <div class="doc_top_bar mb-3" v-if="documentsUploadbtn">
                                      <p>(File Type: PDF, DOC, JPEG, PNG. Max file size: 1MB)</p>
                                     
                                    </div>
                                
                                    <div class="">
                                    <div class="doc_header pb-3 pt-0" v-if="(isSelectedForApprove && [51].indexOf(getUserRoleId)<=-1) || ([50,51].indexOf(getUserRoleId)>-1) " >
                                      <h3 class="small-header mart25"  v-if="checkProperty(petition ,'documents','beneficiaryDocs') &&  (checkProperty(petition ,'documents','beneficiaryDocs')).length>0" ></h3>
                                      <div class="pd_upload_actions mb-0">          
                                        <div @click="documentUploaded=[]" v-if="[50,51].indexOf(getUserRoleId)>-1 && checkProperty(getPetitionDetails ,'status' )!=false" class="upload-btn" >
                                          <span @click="formerrors.msg='';fuploder =false;fileuploadPopup=true;formerrors.msg='' , uploadMainDocuments=[] ,uploadFinalMainDocuments=[]; errorMessage; $validator.reset()">
                                          
                                                <img src="@/assets/images/main/upload.svg" />Upload
                                            </span>
                                        </div>
                                        <div class="generate-btn ml-auto" v-if="isSelectedForApprove && [ 50,51].indexOf(getUserRoleId)<=-1 && !checkApproveDocuments"  @click="approveMe()">                            
                                            <span>Approve</span>
                                        </div>
                                      </div>
                                      
                                    </div>
                                    <div  v-if="checkProperty(petition ,'documents','beneficiaryDocs') &&  (checkProperty(petition ,'documents','beneficiaryDocs')).length>0" >
                                      <vs-row >
                                      
                                      
                                        <vs-col class="padl0 padr0">
                                          <div class="card-panels pad0 additional_documents documents-form-pdf">
                                            <vs-card>
                                              <div slot="header">
                                                <div class="d-flex">
                                                  <template v-if="checkProperty(acceptDocs ,'length')>0 && [50,51].indexOf(getUserRoleId)<=-1 && !checkApproveDocuments" >
                                                    <vs-checkbox v-model="selectAll" @click="selct_all()" class="padl6"></vs-checkbox> 
                                                  </template>
                                                <h3>Documents</h3>   
                                                   
                                                </div>                                  
                                              </div>
                                              <div>
                                             
                                                                                
                                                    <div class="documents__list" v-for="(item ,ind ) in acceptDocs" v-bind:key="ind">
                                                      <div class="documents__title">
                                                        <vs-checkbox  v-if="[50,51].indexOf(getUserRoleId)<=-1 && !checkApproveDocuments" v-model="item.accepted" @click="selectMe()" ></vs-checkbox>
                                                        
                                          <docType :item="item" />
                                                        <!-- <figure slot="avatar" > 
                                                          <img v-if="checkFileFormat(item['mimetype']) =='pdf'" src="@/assets/images/main/pdf.svg" /> 
                                                          <img v-else-if="checkFileFormat(item['mimetype']) =='video_mime_types'" src="@/assets/images/main/film.png" />
                                                          <img v-else-if="checkFileFormat(item['mimetype']) =='msDoc'" src="@/assets/images/main/doc.svg" />
                                                          <img v-else-if="checkFileFormat(item['mimetype']) =='zip'" src="@/assets/images/main/zip-file-format.png" />
                                                          <img v-else-if="checkFileFormat(item['mimetype']) =='msPpt'" src="@/assets/images/main/ppt.svg" />
                                                          <img v-else-if="checkFileFormat(item['mimetype']) =='msXl'" src="@/assets/images/main/xls.svg" />
                                                          <img v-else-if="checkFileFormat(item['mimetype']) =='image'" src="@/assets/images/main/image.svg" />
                                                          <img v-else src="@/assets/images/main/icon-img.svg" />
                                                        </figure> -->
                                                        
                                                          <!-- {{item.name}} -->
                                                        
                                                        <span @click="
                                            $store.commit('selectedForEditDocument', null);
                                            fetchSignedUrl(item);
                                          ">
                                                          <em class="fl_scanned_docs" :title="item.name">{{item.name}}</em>
                                                                <small class="uploaded_doc_small" v-if="!loadedFromPreview"> 
                                                                  <p><span v-if="getformated(item)"> {{ getformated(item) }}</span><span v-if="checkProperty(item,'uploadedByName')"> - Uploaded By {{ item['uploadedByName']}} <em v-if="checkProperty(item,'uploadedByRoleName')">({{ item['uploadedByRoleName'] }})</em></span></p>
                                                                </small></span>
                                                      </div>
                                                      <div class="documents__actions">
                                                        <button @click="removethis(ind ,type)" v-if="checkProperty( item, 'tempDoc')==true" class="view-btn">Remove</button>
                                                        <button v-else @click="downloadfile(item,false,true)" class="view-btn">View</button>
                                                      </div>
                                                    </div>
                                                  
                                                </div>

                                              

                                                <div class="accordian-table custom-table d-none">
                                                  <vs-table :data="petition.documents['beneficiaryDocs']" >
                                                  <template slot="thead">

                                                  <vs-th >
                                                  <template >
                                                    <vs-checkbox v-model="selectAll" @click="selct_all()" class="padl6"></vs-checkbox>
                                                    <a >Select All</a>
                                                  </template>
                                                  </vs-th>
                                                  <vs-th></vs-th>
                                                  
                                                  </template>

                                                  <template >
                                                    <vs-tr :data="item"  :key="ind" v-for="(item ,ind ) in   petition.documents['beneficiaryDocs']" class="vs-table--tr" >
                                                  
                                                      <vs-td>


                                                        
                                                        <div>
                                                        <vs-checkbox  v-if="[50,51].indexOf(getUserRoleId)<=-1" v-model="item.accepted" @click="selectMe()" ></vs-checkbox>
                                                        <template >
                                                        
                                                          <img v-if="checkFileFormat(item['mimetype']) =='pdf'" src="@/assets/images/main/pdf.svg" /> 
                                                          <img v-else-if="checkFileFormat(item['mimetype']) =='video_mime_types'" src="@/assets/images/main/film.png" />
                                                          <img v-else-if="checkFileFormat(item['mimetype']) =='msDoc'" src="@/assets/images/main/doc.svg" />
                                                          <img v-else-if="checkFileFormat(item['mimetype']) =='zip'" src="@/assets/images/main/zip-file-format.png" />
                                                          <img v-else-if="checkFileFormat(item['mimetype']) =='msPpt'" src="@/assets/images/main/ppt.svg" />
                                                          <img v-else-if="checkFileFormat(item['mimetype']) =='msXl'" src="@/assets/images/main/xls.svg" />
                                                          <img v-else-if="checkFileFormat(item['mimetype']) =='image'" src="@/assets/images/main/image.svg" />
                                                            <img v-else src="@/assets/images/main/icon-img.svg" />
                                                        </template>
                                                        {{item.name}}
                                                        </div>
                                                      </vs-td>
                                                      <vs-td>
                                                      <button  @click="downloadfile(item,false,true)" class="view-btn">View</button>
                                                      </vs-td>
                                                    </vs-tr>
                                                  </template>  

                                                  </vs-table>  
                                                
                                                </div>
                                              
                                            </vs-card>
                                          </div>
                                        </vs-col>
                                      </vs-row>
                                    </div>
                                  <!-----
                                    <div class="no-data" v-if="!(checkProperty(petition ,'documents','beneficiaryDocs') &&  (checkProperty(petition ,'documents','beneficiaryDocs')).length>0)" > 
                                    
                                    Documents Not Submitted
                                    </div>--->
                                    
                                      <NoDataFound :loading="false" ref="NoDataFoundRef" :update_loading="updateNodataLoading()"   content=""  heading="No Documents Found." type='documents'   v-if="!(checkProperty(petition ,'documents','beneficiaryDocs') &&  (checkProperty(petition ,'documents','beneficiaryDocs')).length>0)"/>
                                    
                                    </div>
                                  </div>
                                </div>
                              
                              </vs-tab>
                          </vs-tabs>   
                        
                        </div>

                      </vs-col>
                  </vs-row>

              </div>
          </div>
        </div>
      </template>
      <template v-else>
          <template v-if="!editDocuments">
            <div class="main-list-wrap" >
                  <div class="tab-inner-content pad0 pt-0 pb-2">
                    <div class="doc_top_bar" v-if="documentsUploadbtn && false">
                      <p>(File Type: PDF, DOC, JPEG, PNG. Max file size: 1MB)</p>

                          <template v-if="false&&[5,7,8,6].indexOf(currentRole) >- 1 && petition.statusId < 11" >
                      <div
                      
                        v-show="!petition.documentsUploadEnabled"
                        class="documents_toggle"
                        @click="checker(false)"
                      >
                        <label>Unlock Documents</label>
                        <figure>
                          <img src="@/assets/images/main/unlock.svg" />
                        </figure>
                      </div>

                      <div
                        v-show="petition.documentsUploadEnabled && petition.statusId < 11"
                        class="documents_toggle"
                        @click="checker(true)"
                      >
                        <label>Lock Documents</label>
                        <figure>
                          <img src="@/assets/images/main/lock.svg" />
                        </figure>
                      </div>
                          </template>
                    </div>              
                    <div :class="{'pad20':!checkCurrentUrl}" >
                      <div class="doc_header pt-0" >
                        <h3 class="small-header mart25"  >
                        <template  v-if="todalDocumentsCount>0">
                        Documents
                        </template>
                        </h3>
                        
                        <div class="d-flex">  
                           <button v-if=" ( !loadedFromPreview && checkCurrentUrl  ) && checkNoNotifyUserIds && editableDocs && questionnaireDetails" @click="openEditDocs(true)" class="edit-doc"> <img src="@/assets/images/main/icon-edit.svg" />Upload Documents</button>        
                          <button v-if="!callBenDetails && [50].indexOf(getUserRoleId)<=-1 && checkCurrentUrl && allbtn && (todalDocumentsCount>0 || spouseDocumentCount>0 || totalChildDocumentCount>0 )" @click="downloadallfile()" class="download_all">Download Documents </button>
                          <button v-if="is_enablesavebtn" @click="saveUploadedsFiles()" class="documents_save">Save</button>
                        </div>
                        
                      </div>
                        <template  v-if="todalDocumentsCount>0">
                      <div :key="docs" v-for="(type,docs) in  petitiondocuments">
                        
                        <vs-row v-if="docs !='beneficiaryDocs' && type && (type.length > 0 || ((currentRole ==50 || currentRole == 51) && petition.documentsUploadEnabled )) && checkDocumentsExists(type) " >
                          <vs-col class="padl0 padr0">
                            <div class="card-panels pad0">
                              <vs-card>
                                <div slot="header" >
                                  <h3>{{docs | formatdoctype}}</h3> 
                                  <div
                                    class="doc_upload upload_documents"
                                    @click="selectDoctype(docs)"
                                    v-if="(currentRole ==50|| currentRole == 51) && petition.documentsUploadEnabled && checkProperty(getPetitionDetails ,'status' )!=false"
                                  >

                                    <file-upload
                                      v-model="profilePicture"
                                      class="file-upload-input"
                                      v-bind:name="docs"
                                      v-bind:data-vv-as="docs"
                                      :multiple="false"
                                      :accept="allDocEntity"
                                      @input="upload(profilePicture ,docs)"
                                    >
                                      <img class="file-icon" src="@/assets/images/main/file-upload.svg" /> Upload 
                                    </file-upload>
                                  </div>
                                </div>
                                <div>
                                  <div>
                                    <template v-for="(item ,ind ) in  type">
                                
                                      <div class="documents__list" v-if="checkProperty( item,'status') !=false"  v-bind:key="ind">
                                        <div class="documents__title" @click="downloadfile(item)">
                                          <figure> 
                                            <img v-if="checkFileFormat(item['mimetype']) =='pdf'" src="@/assets/images/main/pdf.svg" /> 
                                            <img v-else-if="checkFileFormat(item['mimetype']) =='video_mime_types'" src="@/assets/images/main/film.png" />
                                            <img v-else-if="checkFileFormat(item['mimetype']) =='msDoc'" src="@/assets/images/main/doc.svg" />
                                            <img v-else-if="checkFileFormat(item['mimetype']) =='zip'" src="@/assets/images/main/zip-file-format.png" />
                                            <img v-else-if="checkFileFormat(item['mimetype']) =='msPpt'" src="@/assets/images/main/ppt.svg" />
                                            <img v-else-if="checkFileFormat(item['mimetype']) =='msXl'" src="@/assets/images/main/xls.svg" />
                                            <img v-else-if="checkFileFormat(item['mimetype']) =='image'" src="@/assets/images/main/image.svg" />
                                            <img v-else src="@/assets/images/main/icon-img.svg" />
                                          </figure>
                                          <span>
                                            <!-- {{item.name}} -->
                                            <em class="fl_scanned_docs" :title="item.name">{{item.name}}</em>
                                            <small class="uploaded_doc_small" v-if="!loadedFromPreview"> 
                                              <p><span v-if="getformated(item)"> {{ getformated(item) }}</span><span v-if="checkProperty(item,'uploadedByName')"> - Uploaded By {{ item['uploadedByName']}} <em v-if="checkProperty(item,'uploadedByRoleName')">({{ item['uploadedByRoleName'] }})</em></span></p>
                                            </small>
                                          
                                          </span>
                                        </div>
                                        <div class="documents__actions d-flex">
                                          <button @click="removethis(ind ,type)" v-if="checkProperty( item, 'tempDoc')==true" class="view-btn ml-2">Remove</button>
                                          <button v-else @click="downloadfile(item,false,true)" class="view-btn ml-2">View</button>
                                          <button v-if="!loadedFromPreview && ['Child','Spouse'].indexOf(callFrom)>-1 && [50,51].indexOf(getUserRoleId)<=-1" @click="confirmDocumentDelete(item,docs,ind,true)" class="view-btn ml-2">Delete</button>
                                        </div>
                                      </div>
                                    </template>
                                  </div>
                                </div>
                              </vs-card>
                            </div>
                          </vs-col>
                        </vs-row>
                      </div>
                        </template>
                      <!------------Spouse Documents spouseActiveDocs-------->

                      <template  v-if="spouseDocumentCount>0&&(checkProperty( petition , 'dependentsInfo' ,'spouse'))" >


                      <template  v-if="(checkProperty( petition['dependentsInfo'] ,'spouse','documents')) && Object.entries(petitiondocumentr).length>0" >
                        <div class="doc_header pt-0 d"  >
                          <h3 class="small-header mart25" >Spouse Documents</h3>
                        </div>
                        <div :key="docs" v-for="(type,docs) in  petitiondocumentr">
                        <vs-row v-if="docs !='beneficiaryDocs' && type && (type.length > 0 || ((currentRole ==50 || currentRole == 51) && petition.documentsUploadEnabled )) && checkDocumentsExists(type) " >
                          <vs-col class="padl0 padr0">
                            <div class="card-panels pad0">
                              <vs-card>
                                <div slot="header" >
                                  <h3>{{docs | formatdoctype}}</h3> 
                                  <div
                                    class="doc_upload upload_documents"
                                    @click="selectDoctype(docs)"
                                    v-if="(currentRole ==50|| currentRole == 51) && petition.documentsUploadEnabled && checkProperty(getPetitionDetails ,'status' )!=false"
                                  >

                                    <file-upload
                                      v-model="profilePicture"
                                      class="file-upload-input"
                                      v-bind:name="docs"
                                      v-bind:data-vv-as="docs"
                                      :multiple="false"
                                      :accept="allDocEntity"
                                      @input="upload(profilePicture ,docs)"
                                    >
                                      <img class="file-icon" src="@/assets/images/main/file-upload.svg" /> Upload 
                                    </file-upload>
                                  </div>
                                </div>
                                <div>
                                  
                                  <template v-for="(item ,ind ) in  type" >
                                    <div class="documents__list" v-if="checkProperty( item,'status') !=false" v-bind:key="ind">
                                      <div class="documents__title" @click="downloadfile(item)">
                                        <figure> 
                                          <img v-if="checkFileFormat(item['mimetype']) =='pdf'" src="@/assets/images/main/pdf.svg" /> 
                                          <img v-else-if="checkFileFormat(item['mimetype']) =='video_mime_types'" src="@/assets/images/main/film.png" />
                                          <img v-else-if="checkFileFormat(item['mimetype']) =='msDoc'" src="@/assets/images/main/doc.svg" />
                                          <img v-else-if="checkFileFormat(item['mimetype']) =='zip'" src="@/assets/images/main/zip-file-format.png" />
                                          <img v-else-if="checkFileFormat(item['mimetype']) =='msPpt'" src="@/assets/images/main/ppt.svg" />
                                          <img v-else-if="checkFileFormat(item['mimetype']) =='msXl'" src="@/assets/images/main/xls.svg" />
                                          <img v-else-if="checkFileFormat(item['mimetype']) =='image'" src="@/assets/images/main/image.svg" />
                                          <img v-else src="@/assets/images/main/icon-img.svg" />
                                        </figure>
                                        <span>
                                          <!-- {{item.name}} -->
                                          <em class="fl_scanned_docs" :title="item.name">{{item.name}}</em>
                                          <small class="uploaded_doc_small" v-if="!loadedFromPreview"> 
                                            <p><span v-if="getformated(item)"> {{ getformated(item) }}</span><span v-if="checkProperty(item,'uploadedByName')"> - Uploaded By {{ item['uploadedByName']}} <em v-if="checkProperty(item,'uploadedByRoleName')">({{ item['uploadedByRoleName'] }})</em></span></p>
                                          </small>
                                        </span>
                                      </div>
                                      <div class="documents__actions">
                                        <button @click="removethis(ind ,type)" v-if="checkProperty( item, 'tempDoc')==true" class="view-btn">Remove</button>
                                        <button v-else @click="downloadfile(item,false,true)" class="view-btn">View</button>
                                      </div>
                                    </div>
                                    </template> 
                                </div>
                              </vs-card>
                            </div>
                          </vs-col>
                        </vs-row>
                      </div>
                        
                      </template>
                        
                      </template>

                      <!-----------Children Documents---------->
                      <template  v-if="totalChildDocumentCount>0 && (checkProperty( petition , 'dependentsInfo' ,'childrens'))" >
                        <template v-if="(checkProperty( petition['dependentsInfo'] ,'childrens' ,'length'))" >
                        <!-------------LooEach Child-->
                        <template v-for="( child ,cind ) in petition['dependentsInfo']['childrens']"  >

                            <template > 
                              <div  :key="cind">
                              <div class="doc_header pt-0 d" >
                                <h3 class="small-header mart25" >Child {{cind+1| numToText }} Documents</h3>
                              </div>
                              <div :key="docs" v-for="(type,docs) in  child['documents']">
                              <vs-row v-if="docs !='beneficiaryDocs' && type && (type.length > 0 || ((currentRole ==50 || currentRole == 51) && petition.documentsUploadEnabled )) && checkDocumentsExists(type) " >
                                <vs-col class="padl0 padr0">
                                  <div class="card-panels pad0">
                                    <vs-card>
                                      <div slot="header" >
                                        <h3>{{docs | formatdoctype}}</h3> 
                                        <div
                                          class="doc_upload upload_documents"
                                          @click="selectDoctype(docs)"
                                          v-if="(currentRole ==50|| currentRole == 51) && petition.documentsUploadEnabled && checkProperty(getPetitionDetails ,'status' )!=false"
                                        >

                                          <file-upload
                                            v-model="profilePicture"
                                            class="file-upload-input"
                                            v-bind:name="docs"
                                            v-bind:data-vv-as="docs"
                                            :multiple="false"
                                            :accept="allDocEntity"
                                            @input="upload(profilePicture ,docs)"
                                          >
                                            <img class="file-icon" src="@/assets/images/main/file-upload.svg" /> Upload 
                                          </file-upload>
                                        </div>
                                      </div>
                                      <div>
                                        
                                        <template v-for="(item ,ind ) in  type" >
                                          <div class="documents__list" v-if="checkProperty( item,'status') !=false" v-bind:key="ind">
                                            <div class="documents__title" @click="downloadfile(item)">
                                              <figure> 
                                                <img v-if="checkFileFormat(item['mimetype']) =='pdf'" src="@/assets/images/main/pdf.svg" /> 
                                                <img v-else-if="checkFileFormat(item['mimetype']) =='video_mime_types'" src="@/assets/images/main/film.png" />
                                                <img v-else-if="checkFileFormat(item['mimetype']) =='msDoc'" src="@/assets/images/main/doc.svg" />
                                                <img v-else-if="checkFileFormat(item['mimetype']) =='zip'" src="@/assets/images/main/zip-file-format.png" />
                                                <img v-else-if="checkFileFormat(item['mimetype']) =='msPpt'" src="@/assets/images/main/ppt.svg" />
                                                <img v-else-if="checkFileFormat(item['mimetype']) =='msXl'" src="@/assets/images/main/xls.svg" />
                                                <img v-else-if="checkFileFormat(item['mimetype']) =='image'" src="@/assets/images/main/image.svg" />
                                                <img v-else src="@/assets/images/main/icon-img.svg" />
                                              </figure>
                                              <span>
                                                <!-- {{item.name}} -->
                                                <em class="fl_scanned_docs" :title="item.name">{{item.name}}</em>
                                                <small class="uploaded_doc_small" v-if="!loadedFromPreview"> 
                                                  <p><span v-if="getformated(item)"> {{ getformated(item) }}</span><span v-if="checkProperty(item,'uploadedByName')"> - Uploaded By {{ item['uploadedByName']}} <em v-if="checkProperty(item,'uploadedByRoleName')">({{ item['uploadedByRoleName'] }})</em></span></p>
                                                </small>
                                              </span>
                                            </div>
                                            <div class="documents__actions">
                                              <button @click="removethis(ind ,type)" v-if="checkProperty( item, 'tempDoc')==true" class="view-btn">Remove</button>
                                              <button v-else @click="downloadfile(item,false,true)" class="view-btn">View</button>
                                            </div>
                                          </div>
                                          </template> 
                                      </div>
                                    </vs-card>
                                  </div>
                                </vs-col>
                              </vs-row>
                            </div>
                              </div>
                            </template>
                        </template>
                        
                        </template>



                        
                      </template>
                      <NoDataFound :loading="false" ref="NoDataFoundRef"  :update_loading="updateNodataLoading()"   content=""  heading="No Documents Found." type='documents'   v-if="(todalDocumentsCount<=0 && spouseDocumentCount <=0 && totalChildDocumentCount<=0 )"/>
                    </div>
                  </div>
            </div>
          </template>
          <template v-else> 
            <template v-if="checkProperty(petition,'typeDetails','id') == 9 ">
              <documentsUploadcomp v-if="editDocuments" :petition="petition" :questionnaireDetails="questionnaireDetails" @reloadCaseDetails="reloadCaseDetails"  @openEditDocs="openEditDocs" />
            </template>
            <template v-else>
              <div class="main-list-wrap pad0 editCaseDocuments dd ">
                <caseQuestionnaireDocs @downloadOrView="downloadfile" v-if="editDocuments"  :petitionDetails="petition"  :questionnaireDetails="questionnaireDetails"  @reloadCaseDetails="reloadCaseDetails" :tempDocuments="documents" :callFromEdit='true' @openEditDocs="openEditDocs" />
              </div>   
            </template>
               
          </template>
      </template>
   
  
 
    <vs-popup
     v-if="lockDocumentsPopup"
      class="holamundo main-popup"
      :title="lockDocumentsPopupTitle"
      :active.sync="lockDocumentsPopup"
    >
      <form data-vv-scope="documentlockform">
        <div class="form-container">
          <div class="vx-row">
            <div class="vx-col w-full"  @click="lockUnlockformerrors=''"  @keyup="lockUnlockformerrors=''">
            <label class="form_label">Comments</label>
              <!-- <vs-textarea
                data-vv-as="Comments"
                v-validate="'required'"
                v-model="documentlockformcomments"
                name="documentlockformcomments"
               
                class="w-full"
              /> -->
              <ckeditor data-vv-as="Comments"
                v-validate="'required'"
                v-model="documentlockformcomments"
                name="documentlockformcomments"
               
                class="w-full"  :editor="editor" :config="editorConfig"></ckeditor>


              <span
                class="text-danger text-sm"
                v-show="errors.has('documentlockform.documentlockformcomments')"
              >{{ errors.first("documentlockform.documentlockformcomments") }}</span>
            </div>
          </div>
          <div class="text-danger text-sm formerrors" v-show="lockUnlockformerrors">
            <vs-alert
              color="warning"
              class="warning-alert reg-warning-alert no-border-radius"
              icon-pack="IntakePortal"
              icon="IP-information-button"
              active="true"
            >{{ lockUnlockformerrors }}</vs-alert>
          </div>
        </div>
        <div class="popup-footer">
        <vs-button color="dark" @click="lockDocumentsPopup=false ;" class="cancel" type="filled">Cancel</vs-button>
         
          <vs-button color="success" @click="submitdocumentslock" class="save" type="filled">Submit</vs-button>
        </div>
      </form>
    </vs-popup>


   <vs-popup class="Change_petition_wrap" :title="'Upload Documents'" :active.sync="fileuploadPopup">
        <div class="Change_petition" @click="formerrors.msg=''">
            <div class="vx-col w-full marb10">
            
                
                    <div class="vx-row">
                        <div class="vx-col w-full">
                            <vx-input-group class="form-input-group select-upload-group">
                                <div class="uploadsec_wrap">
                                    <div class="w-full">

                                        <div  @click="uploadMainDocuments=[]">
                                            <file-upload v-model="uploadMainDocuments"
                                            :accept="acceptedFiles" 
                                             class="file-upload-input mb-0" style="height:50px; padding:0px;" :name="'pdocuments'" :multiple="true" :hideSelected="true" v-validate="'required'" label="Forms and Letters" data-vv-as="Forms and Letters"  @input="uploadToS3MainDocuments( uploadMainDocuments)">
                                                <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                                                Upload
                                            </file-upload>
                                            <span class="file-type">(File Type: PDF, DOC, JPEG, PNG. Max file size: 1MB)</span>
                                            <span v-if="[50,51].indexOf(getUserRoleId)>-1" class="text-danger text-sm" v-show="errors.has('pdocuments')">*Documents are required</span>
                                            <span v-else class="text-danger text-sm" v-show="errors.has('pdocuments')">{{ errors.first('pdocuments') }}</span>
                                        </div>

                                        <VuePerfectScrollbar class="scrollbardoc">
                                            <div class="uploded-files_wrap" v-if="uploadFinalMainDocuments && uploadFinalMainDocuments.length >0 ">
                                                <div class="w-full" v-for="(fil, fileindex) in uploadFinalMainDocuments" :key="fileindex">
                                                   
                                                    <div class="uploded-files">
                                                        <vx-input-group class="form-input-group">
                                                            <vs-input v-on:keyup="filameChenged(fileindex)"  v-validate="'required'" class="w-full" :name="'fName'+fileindex" v-model="fil['name']" data-vv-as="File Name" />
                                                            <span class="text-danger text-sm" v-show="errors.has('fName'+fileindex)">{{ errors.first('fName'+fileindex) }}</span>

                                                            <div class="delete"  @click="remove(fil, uploadFinalMainDocuments ,fileindex)">
                                                                <img src="@/assets/images/main/cross.svg" />
                                                            </div>
                                                        </vx-input-group>
                                                    </div>
                                                </div>
                                            </div>
                                        </VuePerfectScrollbar>
                                    </div>
                                </div>
                            </vx-input-group>
                        </div>
                    </div>
                
            </div>
        </div>
        <!-----v-if="fuploder"-->
         <div class="text-danger text-sm formerrors" v-show="formerrors.msg" @click="formerrors.msg=''">
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
              icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
          </div>
        <div  class="popup-footer relative" >
            <button @click="fileuploadPopup=false; fuploder=false" class="btn cancel">Cancel</button>
            <button class="btn save" v-bind:disble="disable_uploadBtn || uploadFinalMainDocuments.length<=0" @click="uploadBenDocuments()">
                <figure v-if="fuploder" class="loader loader2"><img src="@/assets/images/main/loader.gif" /></figure>
                Upload
            </button>
        </div>
    </vs-popup>

    <div  class="custom_modal_sec documents__modal custom_modal-v2" :class="{ modalopen: downloadDocList }" >
        <div class="custom_modal_overlay"   ></div>
            <div class="custom_modal_cnt">
                <div class="modal_title">      
                    <h2> Download Documents </h2>                
                     <span class="close" @click="$emit('closeMe');downloadDocList = false"><x-icon size="1.5x"></x-icon></span>
                </div>


       <downLoadCaseDocuments @closeMe="downloadDocList=false" v-if="!loadedFromPreview && downloadDocList" @downloadfile="downloadfile" v-bind:petition="petition" v-bind:loadedFromPreview="loadedFromPreview" />
     </div>
    </div>
    <vs-popup class="holamundo main-popup cls-btn" title="Delete Document" :active.sync="showDocumentDeletePopup">
            <div class="form-container">
                <div class="vx-row">
                    <div class="vx-col w-full">
                        <p style="line-height: 20px">
                          Do you want to Delete?
                        </p>
                    </div>
                </div>
            </div>
            <div class="popup-footer">
                <vs-button color="dark" class="cancel" type="filled" @click="showDocumentDeletePopup = false;cancelDocumentDel()">Cancel</vs-button>
                <vs-button @click="documentDelete();" class="save questionnaire_btn" type="filled">Delete </vs-button>
            </div>
        </vs-popup>
</div>
</template>

<style >
.dragHead {
  background: #eceff3;
  border-radius: 4px 4px 0 0;
  padding: 6px 10px;
  color: #1d202c;
  font-size: 14px;
  font-family: "robotomedium";
  line-height: normal;
}

.subdragHead {
  padding: 6px 10px;
  color: #1d202c;
  font-size: 14px;
  font-family: "robotomedium";
  line-height: normal;
}
.dragNested {
  padding: 10px 20px;
}
.scrollbardoc {
  height: 400px;
}
</style>
<script>
import docType from "@/views/common/docType.vue";
import moment, { relativeTimeThreshold } from "moment";
import casedocumentslist from "@/views/common/casedocuments.vue";
import * as _ from "lodash";
import draggable from "vuedraggable";
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import NoDataFound from "@/views/common/noData.vue";
  import { XIcon } from 'vue-feather-icons'
import FileUpload from "vue-upload-component/src";
import documentsUploadcomp from "@/views/forms/documentsUpload.vue";
import caseQuestionnaireDocs from "@/views/forms/caseQuestionnaireDocs.vue";
import downLoadCaseDocuments from "@/views/petition/downLoadCaseDocuments.vue";
import Vue from 'vue';
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import JQuery from "jquery";
import { formatDate } from "tough-cookie";
export default {
   provide() {
        return {
            parentValidator: this.$validator,
        };
    },
  components: {
    documentsUploadcomp,
    downLoadCaseDocuments,
    caseQuestionnaireDocs,
    draggable,
    FileUpload,
    VuePerfectScrollbar,
    NoDataFound,
    casedocumentslist,
    XIcon,
    docType
  },
  data() {
    return {
      benh4DocumList:[
      {
          required: false,
          fileUploading:false,
          cid:"ben_proofOfCurrentStatus",
          key:'proofOfCurrentStatus',
          fieldName:"proofOfCurrentStatus",
          label:'Proof Of Current Status'
        },
        {
          required: false,
          fileUploading:false,
          cid:"ben_copyOfExistingVisa",
          key:'copyOfExistingVisa',
          fieldName:"copyOfExistingVisa",
          label:'Copy Of Existing visa'
        },
        {
          required: false,
          fileUploading:false,
          cid:"ben_approvalCopyOfi140",
          key:'approvalCopyOfi140',
          label:'Approval Copy Of I-140',
          fieldName:"approvalCopyOfi140",
        },
          {
            required: false,
            fileUploading:false,
            cid: 'ben_priorH4Approvals',
            key: 'priorH4Approvals',
            fieldName: 'priorH4Approvals',
            label: 'All prior H4 approvals, if any'
          }, 
          {
            required: false,
            fileUploading:false,
            key: 'passport',
            cid: 'ben_passport',
            fieldName: 'passport',
            label: 'Passport'
          },  
          {
            required: false,
            fileUploading:false,
            key: 'usVisa',
            fieldName: 'usVisa',
            cid: 'ben_usVisa',
            label: 'US Visa'
          },   
          {
            required: false,
            fileUploading:false,
            key: 'mostRecentI94',
            fieldName: 'mostRecentI94',
            cid: 'ben_mostRecentI94',
            label: 'Most recent I-94'
          },  
          {
            required: false,
            fileUploading:false,
            key: 'ssnCard',
            fieldName: 'ssnCard',
            cid: 'ben_ssnCard',
            label: 'SSN Card, if any'
          }, 
         
          {
            required: false,
            fileUploading:false,
            key: 'eadCard',
            cid: 'ben_eadCard',
            fieldName: 'eadCard',
            label: 'Prior EAD Cards, if any '
          }, 
          
          {
            required: false,
            fileUploading:false,
            key: 'marriageCertificate',
            cid: 'ben_marriageCertificate',
            fieldName: 'marriageCertificate',
            label: 'Marriage Certificate'
          },
          {
              required: false,
              key: 'other',
              cid: 'ben_other',
              fieldName: 'other',
              label: 'Others'
          }   
      ],
      spouseH4DocumentList:[
          {
            required: false,
            fileUploading:false,
            key: 'approvedI140',
            fieldName: 'approvedI140',
            cid: 'approvedI140',
            label: 'Approved I-140 or Pending Perm for more than 365 days'
          }, 
          {
            required: false,
            fileUploading:false,
            key: 'h1Bapprovals',
            fieldName: 'h1Bapprovals',
            cid: 'h1Bapprovals',
            label: 'All H-1B approvals, all the way to CAP '
          }, 
          {
            required: false,
            fileUploading:false,
            key: 'passport',
            fieldName: 'passport',
            cid: 'passport',
            label: 'Passport'
          }, 
          {
            required: false,
            fileUploading:false,
            key: 'usVisa',
            fieldName: 'usVisa',
            cid: 'usVisa',
            label: 'US Visa'
          },  
           
          {
            required: false,
            fileUploading:false,
            key: 'mostRecentI94',
            fieldName: 'mostRecentI94',
            cid: 'mostRecentI94',
            label: 'Most recent I-94'
          },  
          {
            required: false,
            fileUploading:false,
            key: 'travelHistory',
            fieldName: 'travelHistory',
            cid: 'travelHistory',
            label: 'Travel History'
          },  
          {
            required: false,
            fileUploading:false,
            key: 'mostRecentPayStubs',
            fieldName: 'mostRecentPayStubs',
            cid: 'travelHistory',
            label: '3 most recent pay stubs '
          },
          {
              required: false,
              key: 'other',
              fieldName: 'other',
              cid: 'other',
              label: 'Others'
          } 
        ],
      selectedDocObj:null,
      selectedDocCategory:'',
      selectedDocIndex:null,
      selectedPetitionCategory:'',
      showDocumentDeletePopup:false,
      acceptDocs:[],
      documensUpdating:false,
      offerDocuments:{
        slgOfferLetter:[],
        slgSignedOfferLetter:[],
      },
      benOfferDocslist:[
      {
          required: false,
          fieldName: 'slgSignedOfferLetter',
          key: "slgSignedOfferLetter",
          label: "Signed Offer Letter"
        },
      ],
      offerDocslist:[
        {
          required: false,
          fieldName: 'slgOfferLetter',
          key: "slgOfferLetter",
          label: "Unsigned Offer Letter"
        },
        {
          required: false,
          fieldName: 'slgSignedOfferLetter',
          key: "slgSignedOfferLetter",
          label: "Signed Offer Letter"
        },
      ],
      allChildrens:[],
      testVariable:[],
      childsObject:[],
      benChildsObject:[],
      showConetent1:false,
      showConetent2:false,
      showConetent3:false,
      editor: ClassicEditor,
      editorConfig: {
          toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
      },
      savedDocumentsList:[],
      isDocumentsAreSaved:false,
      documentActiveTab:'savedDocuments',
      editDocuments:false,
       documents: {
          //h4 documents
         
          priorH4Approvals: [],
         // passport:[],
          usVisa: [],
          mostRecentI94: [],
          ssnCard: [],
          eadCard: [],
          // marriageCertificate:[],
          
          // other:[],
          //h4 documents

        birthCertificate:[],
        passportVisaI94: [],
        passport: [],
        resume: [],
        education: [],
        expLetters: [],
        INSNotices: [],

        formI20: [],
        I797NoticeofApprovalforI140:[],
        socialSecurityCardAndProfLicense: [],
        I140ApprovalNotice: [],
        payStubs: [],
        offerLetter: [],

        clientLetter: [],
        vendorLetter: [],
        ead: [],
        msa: [],
        po: [],
        h1bRegSelectionNotice: [],
        employmentAgreement: [],
        primeVendor: [],
        formI94: [],
        priorFormI797: [],
        other: [],
      },
      documentTypes:{
        "beneficiary":{},
        "spouse":{},
        "child":{}
      },
      itemSlength:0,
       downloadDocList: false,
       acceptedFiles:'application/pdf',
      filesDownloading:false,
      lockUnlockformerrors:'',
      color: "#000",
      downloadDocumentPop: false,
      documentsUpload: true,
      lockDocumentsPopup: false,
      lockDocumentsPopupTitle: "",
      uploaddocType: "",
      profilePicture: [],
      petitiondocuments: {},
      
      petitiondocumentsl: [],
      petitiondocumentr: [],
      childernDocuments:[],
      is_enablesavebtn: false,

      errorMessage:'',
      fileuploadPopup:false,
      documentUploaded:[],
      activeTabName:'Documents',
      disable_uploadBtn:false,
      fuploder:false,
       formerrors: {
        msg: ""
      },
      selectedDocsForApprove:[],
      selectAll:false,
      uploadMainDocuments:[],
      uploadFinalMainDocuments:[],

      todalDocumentsCount:0,
      spouseDocumentCount:0,
      totalChildDocumentCount:0,
      spouseActiveDocs:[],
      questionnaireDetails:null,
      tempUpdateDocList:{
        "benficiaryCategoryOrders":[], //[{ category:'resumes' ,order:1}]
        "spouseCategoryOrders":[], //[{ category:'resumes' ,order:1}]
        "childCategoryOrders":[], //[{ category:'resumes' ,order:1 ,"childrenId":'' }]
         "documentsOrder":[ ] //[{'path':'http://s3.amozon.com' ,order:2}]
      },
      benficiaryTrashItems:[],
      trashedItems:[],
      processingDocuments:true

      

    };
  },
  watch: {
    documentsUpload: function (value) {},
  },
  props: {
    loadedFromPreview:{type: Boolean , default: false},
    editableDocs:{type: Boolean , default: false},
    openTabes:false,
    allbtn: false,
    documentsUploadbtn: false,
    currentRole: null,
    petition: {
      type: Object,
      default: null,
    },
    workFlowDetails: {
      type: Object,
      default: null,
    },
    fieldsArray:[],
    callBenDetails:{
      type:Boolean,
      default:false
    },
    callFrom:{
      type:String,
      default:''
    },
    petitionId:{
      type:String,
      default:''
    }
  },
  mounted() {
      

    if(this.checkProperty(this.petition,'documents') && this.checkProperty(this.petition,'documents','slgOfferLetter')
    && this.checkProperty(this.petition['documents'],'slgOfferLetter','length')>0 ){
      this.offerDocuments['slgOfferLetter'] = _.cloneDeep(this.checkProperty(this.petition,'documents','slgOfferLetter'))
    }
    if(this.checkProperty(this.petition,'documents') && this.checkProperty(this.petition,'documents','slgSignedOfferLetter')
    && this.checkProperty(this.petition['documents'],'slgSignedOfferLetter','length')>0 ){
      this.offerDocuments['slgSignedOfferLetter'] = _.cloneDeep(this.checkProperty(this.petition,'documents','slgSignedOfferLetter'))
    }
   
    this.getSavedDocuments();
    let self =this;
    
    setTimeout(()=>{
      if (_.has(this.petition, "questionnaireTplId")) {

     
      this.questionnaireTplId = this.getPetitionDetails["questionnaireTplId"];
      this.getquestionnaireDetails();
    }
    });
   
      if(this.checkProperty(this.petition['dependentsInfo'],'childrens')){
          this.allChildrens = [];
        _.forEach(this.petition['dependentsInfo']['childrens'] ,(child ,cindex)=>{
            if(self.checkProperty(child ,'documents' )){

              //child['documents'] =[]
              let childDocs= {};
              _.forEach(child['documents'] ,(documents ,category)=>{
                let filterDocs =[]
                  _.forEach(documents ,(document)=>{
                  if(!_.has(document ,'status') || ( _.has(document ,'status') && document['status'])){
                    if(self.getUserRoleId==51){
                      if(self.checkProperty(document,'uploadedByRoleId') && self.checkProperty(document,'uploadedByRoleId') == 51 ){
                          filterDocs.push(document);        
                      }
                    }else{
                      filterDocs.push(document);         
                    }
                  }
                });
                if(filterDocs && filterDocs.length>0){
                 
                  childDocs[category] = filterDocs;
                 // alert(JSON.stringify(childDocs[category]))
              }     
              })
              if(Object.entries(childDocs).length>0){
                child['documents'] =childDocs;
                this.allChildrens.push(child);
               
              }
            }    
        })
         //this.petition['dependentsInfo']['childrens'] = this.allChildrens;
      }
      
     
      this.initDocuments();
    
  },
  methods: {
    fetchSignedUrl(value, download = false, viewmode = true) {
     
     value.download = download;
     
     if( !_.has(value ,'viewmode')){
       value.viewmode = viewmode;
     }
     this.$emit("download_or_view", value);
     // window.open(this.$globalgonfig._APIURL+"/common/viewfile?path="+value.path, "_blank");
   },
   download_or_view(value) {
       
       if (_.has(value, "path")) {
           value['url'] = value['path'];
           value['document'] = value['path'];
       }

       if (_.has(value, "url")) {
           value['path'] = value['url'];
           value['document'] = value['url'];
       }

       if (_.has(value, "document")) {
           value['path'] = value['document'];
           value['url'] = value['document'];
       }
       

       this.selectedFile = value;
       this.docValue = '';
       this.docPrivew = false;
       this.docType = false;
       this.docType = this.findmsDoctype(value);

       if (false && (this.docType == "office" || this.docType == "image")) {

           value.url = value.url.replace(this.$globalgonfig._S3URL, "");
           value.url = value.url.replace(this.$globalgonfig._S3URLAWS, "");
           let postdata = {
               keyName: value.url
           };
           this.$store.dispatch("getSignedUrl", postdata).then((response) => {
               this.docValue = response.data.result.data;

               if (this.docType == "office") {
                   this.docValue = encodeURIComponent(response.data.result.data);
               }
               this.docPrivew = true;
           });

       } else {

           this.downloads3file(value);
       }

   },
    confirmDocumentDelete(document,docCategory,inde,category,childId){
      this.selectedDocObj = document;
      this.selectedDocCategory = docCategory;
      this.selectedDocIndex = inde;
      this.selectedPetitionCategory = category;
      this.showDocumentDeletePopup = true;
    },
    cancelDocumentDel(){
      this.selectedDocObj = null;
      this.selectedDocCategory = '';
      this.selectedDocIndex = null;
      this.selectedPetitionCategory = '';
      this.showDocumentDeletePopup = false;
    },
    documentDelete(){
      let selectedDocument = this.selectedDocObj;
      let selectedDocCategory = this.selectedDocCategory;
      let selectedChild = this.selectedDocIndex;
      let selectedPetitionCategory = this.selectedPetitionCategory;
      if(selectedDocument){
        selectedDocument = Object.assign(selectedDocument ,{ 'docTypeName':''})
      }
      let payLoad={
        petitionId: this.checkProperty(this.petition,'_id'),
        documents:null,
        deletedDocs:null,
        entityType:'case'
      };
      let tempDocs = null;
      if(this.checkProperty(this.petition,'subTypeDetails','id') == 15){
        payLoad['entityType'] = 'perm'
      };
      if(selectedPetitionCategory == 'Beneficiary' || selectedPetitionCategory == true ){
        selectedDocument['docTypeName'] = this.formatDocLabel(selectedDocCategory);
        payLoad['category'] = 'Beneficiary';
                               
        if(this.callFrom == 'Spouse'){
          let docLabel = 'Spouse '+this.formatDocLabel(selectedDocCategory)
          selectedDocument['docTypeName'] = docLabel;
          payLoad['petitionId'] = this.petitionId;
          payLoad['category'] = 'Spouse';
        }
        if(this.callFrom == 'Child'){
          let docLabel = 'Child ' +this.checkProperty(this.petition,'name')+' '+this.formatDocLabel(selectedDocCategory)
          selectedDocument['docTypeName'] = docLabel;
          payLoad['petitionId'] = this.petitionId;
          payLoad['category'] = 'Child';
          payLoad['childId'] = this.checkProperty(this.petition,'_id');
        }
        tempDocs = this.petition.documents;
        if(_.has(tempDocs, selectedDocCategory) && this.checkProperty(tempDocs,selectedDocCategory,'length')>0 && _.has(selectedDocument,'path')){
          let filteredDoc = _.filter(tempDocs[selectedDocCategory],(docItem)=>{
            return docItem['path'] != selectedDocument['path']
          })
          tempDocs[selectedDocCategory] = filteredDoc;
        }
        tempDocs = _.cloneDeep(tempDocs)
      };
      if(selectedPetitionCategory == 'Spouse' ){
        let docLabel = 'Spouse '+this.formatDocLabel(selectedDocCategory)
        selectedDocument['docTypeName'] = docLabel;
        payLoad['category'] = 'Spouse';
        tempDocs = this.checkProperty( this.petition['dependentsInfo'] ,'spouse','documents');
        if(_.has(tempDocs, selectedDocCategory) && this.checkProperty(tempDocs,selectedDocCategory,'length')>0 && _.has(selectedDocument,'path')){
          let filteredDoc = _.filter(tempDocs[selectedDocCategory],(docItem)=>{
            return docItem['path'] != selectedDocument['path']
          })
          tempDocs[selectedDocCategory] = filteredDoc;
        }
        tempDocs = _.cloneDeep(tempDocs)
      };
      if(selectedPetitionCategory == 'Child' ){
        let docLabel = 'Child ' +this.checkProperty(selectedChild,'name')+' '+this.formatDocLabel(selectedDocCategory)
        selectedDocument['docTypeName'] = docLabel;
        payLoad['category'] = 'Child';
        payLoad['childId'] = this.checkProperty(selectedChild,'_id');
        let childObj = _.find(this.checkProperty( this.petition['dependentsInfo'] ,'childrens'), { '_id': this.checkProperty(selectedChild,'_id') })
        if(childObj){
          tempDocs = this.checkProperty( childObj,'documents');
          if(_.has(tempDocs, selectedDocCategory) && this.checkProperty(tempDocs,selectedDocCategory,'length')>0 && _.has(selectedDocument,'path')){
            let filteredDoc = _.filter(tempDocs[selectedDocCategory],(docItem)=>{
              return docItem['path'] != selectedDocument['path']
            })
            tempDocs[selectedDocCategory] = filteredDoc;
          }
          tempDocs = _.cloneDeep(tempDocs);
        }
      };
      payLoad['documents'] = _.cloneDeep(tempDocs);
      payLoad['deletedDocs'] = _.cloneDeep(selectedDocument);
      let path = '/petition-common/delete-document';
      this.$store.dispatch('commonAction',{data:payLoad,'path':path}).then((res)=>{
        this.cancelDocumentDel();
        this.showToster({message:res.message,isError:false });
        this.init();
      }).catch((err)=>{

      })
    },
    initDocuments(){
      this.acceptDocs =[];
     _.filter(this.petition.documents['beneficiaryDocs'] ,(item)=>{
          item['accepted'] =false
          this.acceptDocs.push(item)
        
     })
    },
    updateOfferDocs() {

    Object.assign(this.formerrors, { msg: "" });
        // this.creatingNew = true;
        let postData = {
          "documents": {},
          "typeName": "",
          "subTypeName": "",
          "petitionId": '',
          "today": null,
          override:true

        }
        let documents = {}
        if(this.getUserRoleId == 51){
          documents['slgSignedOfferLetter'] =  this.offerDocuments['slgSignedOfferLetter']
        }else{
          documents = _.cloneDeep(this.offerDocuments)
        }
        postData['documents'] = _.cloneDeep(documents);
        postData['typeName'] = this.checkProperty(this.getPetitionDetails, "typeDetails", "name")
        postData['subTypeName'] = this.checkProperty(this.getPetitionDetails, "subTypeDetails", "name")
        postData['petitionId'] = this.checkProperty(this.getPetitionDetails, "_id");
        postData['today'] = moment().format("YYYY-MM-DD")
        this.documensUpdating = true;
        let path = "/petition/add-additional-documents";
        if (this.checkProperty(this.getPetitionDetails, 'type') == 3 && [15].indexOf(this.checkProperty(this.getPetitionDetails, 'subTypeDetails', 'id')) > -1) {
          path = "/perm/add-additional-documents";
        }
        this.$store.dispatch("commonAction", { "data": postData, "path": path })
          .then(response => {
            //lca_request_msg

            this.showToster({ message: response.message, isError: false });
            this.documensUpdating = false;
            this.reloadCaseDetails();
            // this.$emit('reloadCaseDetails')
          })
          .catch((error) => {
            Object.assign(this.formerrors, { msg: error });
            this.documensUpdating = false;
          })

    },
    getformated(item) {

       if(item.uploadedOn){
            return (
            "Uploaded On  " +
            moment(item.uploadedOn).format("MMM DD, YYYY hh:mm:ss a")
          );
        }
        else {
        if( item.createdOn){
              return (
              "Uploaded On  " +
              moment(item.createdOn).format("MMM DD, YYYY hh:mm:ss a")
          );

        }
      }
        },
    openEditDocs(action =false){

        this.documents={
          passportVisaI94: [],
          passport: [],
          resume: [],
          education: [],
          expLetters: [],
          INSNotices: [],

          formI20: [],
          I797NoticeofApprovalforI140:[],
          socialSecurityCardAndProfLicense: [],
          I140ApprovalNotice: [],
          payStubs: [],
          offerLetter: [],

          clientLetter: [],
          vendorLetter: [],
          ead: [],
          msa: [],
          po: [],
          h1bRegSelectionNotice: [],
          employmentAgreement: [],
          primeVendor: [],
          formI94: [],
          priorFormI797: [],
          other: [],
          bnfSpouseLatestI797:[],
          bnfSpousePassport:[],
          bnfSpouseRecentPayStubs:[],
          bnfSpouseFormAllI20:[],
          slgResume: [],
          slgEduCredentials:[],
          slgEvalOfEduCredentials:[],
          slgEvalOfEduExpCredentials:[],
          slgTransScripts:[],
          slgExpLetters:[],
          slgPassportAndVisa:[],
          slgCurPrevH1BH4ApprovalsByINS:[], 
          slgAdvancedDegrees:[]
        }
        

        // if(this.checkProperty(this.petition ,'typeDetails' ,'id') ==3){
        //   this.documents={
        //       }
        // }
        let documents = _.cloneDeep( this.documents);

        if(this.checkProperty(this.petition ,'documents')){
          // this.documents = this.checkProperty(this.getPetitionDetails ,'documents');
          _.forEach(Object.entries(this.petition['documents']) ,(val ,key)=>{
           
            
            if(this.checkProperty( val ,"length")>1){
             
              let docKey = val[0];
              
            let docs = val[1];
            _.forEach(docs  ,(dcoItem)=>{
              dcoItem['isNew'] =false

            })
              documents[docKey] = docs;


            }
          })
        }

        this.documents =null;
        this.documents = _.cloneDeep( documents);
        this.documents = _.cloneDeep(  this.documents);
        //alert(JSON.stringify(this.documents));
        if(action){
          setTimeout(()=>{
            this.editDocuments =true;
          });

        }else{
          this.editDocuments = false;
        }
      
        // window.scrollTo(0, -100);
    },
    toggleToTrash(path ,action=false ,docCatecory='', type='petitiondocuments' , childernId=''){
     
     
    if(type=='petitiondocuments'){
      _.forEach(
      Object.entries(this.petitiondocuments),
      (item ,index)=> {
        
          if( this.checkProperty(item  ,'length')>1){
          if( this.checkProperty(item[1] ,'length')>0){
             _.forEach(item[1] ,(doc)=>{
                if((doc['path'] ==path || path=='ALL' ) && item[0]==docCatecory){
                    doc['isTrashDocument'] =action;
                    
                }

              })

              

            }
      }
            
      });
    }else if(this.checkProperty( this.petition,'dependentsInfo' ,'spouse') && type=='petitiondocumentr'){

      if(this.checkProperty( this.petition['dependentsInfo'] ,'spouse','documents')){
       
        
         _.forEach(
          Object.entries(this.petition['dependentsInfo']['spouse']['documents']),
          (item ,index)=> {
            
              if( this.checkProperty(item  ,'length')>1){
              if( this.checkProperty(item[1] ,'length')>0){
                

               
                  _.forEach(item[1] ,(doc)=>{

                     if((doc['path'] ==path || path=='ALL' )&& item[0]==docCatecory){
                       doc['isTrashDocument'] =action;
                    }

                  })
                  
                 

                }
          }
                
          });
          
       
      
      }

    } else if(this.checkProperty( this.childernDocuments ,'length')>0){

      _.forEach(this.childernDocuments,(child)=>{
       

          _.forEach(child,(item)=>{
            if( this.checkProperty(item,"length")>1 ){
           

            
                  if(item[1] && item[1].length > 0){
                   
                   
                    _.forEach(item[1] ,(doc)=>{
                      if((doc['path'] ==path || path=='ALL' )&& item[0]==docCatecory && doc['childrenId'] ==childernId){
                       doc['isTrashDocument'] =action;
                      }

                  })
                
                  
                    

                    }
               
            
            
              
              
             
          }

          })

      })

        

    }

    


    
      this.petitiondocuments  =_.cloneDeep(this.petitiondocuments);
      this.petitiondocumentr = _.cloneDeep(this.petitiondocumentr);
      this.childernDocuments = _.cloneDeep(this.childernDocuments);
      this.trashDocument(); 

     
    },

    splitFiles(){

      this.processingDocuments =true;
      this.petitiondocuments ={};
      let self =this;
      let total = Object.entries(this.petition.documents).length;
      let half = Math.round(total/2);
       this.todalDocumentsCount = 0;
       this.spouseDocumentCount = 0;
       this.totalChildDocumentCount =0;
       this.petitiondocumentr ={};
       let tempDocs =  _.cloneDeep(this.petition.documents );
       if(_.has(tempDocs,'slgOfferLetter')){
        delete tempDocs["slgOfferLetter"]
       }
       if(_.has(tempDocs,'slgSignedOfferLetter')){
        delete tempDocs["slgSignedOfferLetter"]
       }
       
     let caseDocuments =_.cloneDeep(tempDocs );
          _.forEach(
          Object.entries(caseDocuments ),
          (item ,index)=> {
            
              if( this.checkProperty(item  ,'length')>1){
              if( this.checkProperty(item[1] ,'length')>0){
                let documentCategory =item[0];

                  let activeRecords = [];
                  _.forEach(item[1] ,(doc)=>{
                     Object.assign(doc ,{'isTrashDocument':false})  
                     if(this.getUserRoleId == 51){
                      if(this.checkProperty(doc,'uploadedByRoleId') && this.checkProperty(doc,'uploadedByRoleId') == 51 ){
                        Object.assign(doc ,{'showMe':true}) 
                      }else{
                        Object.assign(doc ,{'showMe':false}) 
                      }
                     } else{
                      Object.assign(doc ,{'showMe':true})  
                     }
                    doc['isTrashDocument'] =false;
                    if(this.isDocumentsAreSaved  ){
                        let isSavedDoc = _.find(this.savedDocumentsList ,{'path':doc['path']});
                        
                      if(!isSavedDoc){
                         
                          doc['isTrashDocument'] =true;
                          
                                                 

                      }

                    }
                    if(doc.status && ( this.checkProperty( doc ,'path') !='' || this.checkProperty( doc ,'url') !=''  )){
                      // if(this.checkProperty( doc ,'isTrashDocument')){
                      //   alert(doc['isTrashDocument'])
                      // }
                     
                      if(this.getUserRoleId == 51 ){
                        if(this.checkProperty(doc,'uploadedByRoleId') == 51 && doc.showMe==true){
                          //alert(doc.showMe)
                          activeRecords.push(doc)
                        }
                      }
                        else{
                        activeRecords.push( _.cloneDeep(doc));
                       
                      }
                     
                    
                    }

                  })
                  
                  if(activeRecords.length>0){
                    this.petitiondocuments[documentCategory] =[];
                    this.petitiondocuments[documentCategory] =_.cloneDeep(activeRecords);
                    this.todalDocumentsCount = this.todalDocumentsCount +(activeRecords.length);
                   
                  
                  }
                 
                 
                
          }
          }
                
          });
          if(this.petition.documents && this.checkProperty(this.petition.documents,'slgSignedOfferLetter') && this.checkProperty(this.petition.documents,'slgSignedOfferLetter','length')>0){
            this.petitiondocuments['slgSignedOfferLetter'] = this.checkProperty(this.petition.documents,'slgSignedOfferLetter')
          }
      


    if(this.checkProperty( this.petition,'dependentsInfo' ,'spouse')){

      if(this.checkProperty( this.petition['dependentsInfo'] ,'spouse','documents')){
         
         _.forEach(
          Object.entries(this.petition['dependentsInfo']['spouse']['documents']),
          (item ,index)=> {
            
              if( this.checkProperty(item  ,'length')>1){
              if( this.checkProperty(item[1] ,'length')>0){
                let documentCategory =item[0];

                  let activeRecords = [];
                  _.forEach(item[1] ,(doc)=>{
                    if(this.getUserRoleId == 51){
                      if(this.checkProperty(doc,'uploadedByRoleId') && this.checkProperty(doc,'uploadedByRoleId') == 51 ){
                        Object.assign(doc ,{'showMe':true}) 
                      }else{
                        Object.assign(doc ,{'showMe':false}) 
                      }
                     } else{
                      Object.assign(doc ,{'showMe':true})  
                     }
                    
                    doc['isTrashDocument'] =false;
                    if(this.isDocumentsAreSaved  ){
                        let isSavedDoc = _.find(this.savedDocumentsList ,{'path':doc['path']});
                      if(!isSavedDoc){
                          doc['isTrashDocument'] =true;

                      }

                    }
                    if(doc.status && ( this.checkProperty( doc ,'path') !='' || this.checkProperty( doc ,'url') !=''  )){
                      if(this.getUserRoleId == 51 ){
                        if(this.checkProperty(doc,'uploadedByRoleId') == 51 && doc.showMe==true){
                          activeRecords.push(doc)
                        }
                      }
                        else{
                        activeRecords.push( _.cloneDeep(doc));
                       }
                      
                    }
                  })
                  
                  if(activeRecords.length>0){
                    this.petitiondocumentr[documentCategory] =[];
                    this.petitiondocumentr[documentCategory] =activeRecords;
                   this.spouseDocumentCount = this.spouseDocumentCount +(activeRecords.length);
                  
                  }
                 

                }
          }
                
          });
          
       
      
      }

    }
   


  //childrens
  this.childernDocuments =[];
  if(this.checkProperty( this.petition,'dependentsInfo' ,'childrens')){
      if(this.checkProperty( this.petition['dependentsInfo'] ,'childrens' ,'length')>0){

        _.forEach(this.petition['dependentsInfo']['childrens'] ,(childernDocs)=>{
           



          if( this.checkProperty( childernDocs ,"documents") ){
          
            let childDocs = _.filter(
              Object.entries(childernDocs['documents']),
              (item)=> {
                if(item[1] && item[1].length > 0){

                  let activeRecords = [];
                  _.forEach(item[1] ,(doc)=>{
                    
                    doc['isTrashDocument'] =false;
                      if(this.isDocumentsAreSaved  ){
                          let isSavedDoc = _.find(this.savedDocumentsList ,{'path':doc['path']});
                        if(!isSavedDoc){
                            doc['isTrashDocument'] =true;

                        }

                      }
                    if(doc.status){
                        doc['childrenId'] =this.checkProperty(childernDocs ,'_id');
                        activeRecords.push(doc)
                        
                    }

                })
              
                
                  if(activeRecords.length>0 && this.allChildrens.length>0){

                    self.totalChildDocumentCount = self.totalChildDocumentCount+(activeRecords.length )
                    return true;
                  }else{
                  return false;
                  }

                  }else{
                    return false;
                  }
              }
            );
            
           self.childernDocuments.push(_.cloneDeep(childDocs))
          
            
            
        }

        })

      }

  }

  this.petitiondocuments  =_.cloneDeep(this.petitiondocuments);
  this.petitiondocumentr = _.cloneDeep(this.petitiondocumentr);
  this.childernDocuments = _.cloneDeep(this.childernDocuments);
 this.processingDocuments =false;

     
    },
    
    
    init(){
       this.documentTypes = {
      "beneficiary":{

      
            "passport":"docs_passport",
            "passportVisaI94":'docs_passport_visa_i94',
            "formI20":"docs_form_i20_ead",
            "priorFormI797":"docs_prior_form_i797",
            "education":"docs_education",
            "formI94":"docs_form_i94",
            "resume":"docs_resume",
            "expLetters":"docs_exp_letters",
            "offerLetter":'docs_offer_letters',
            "employmentAgreement":"docs_employment_agreement",
            "INSNotices":'docs_ins_notices',
            "payStubs":'docs_paystubs',
            "ead":"docs_ead",
            "I797NoticeofApprovalforI140":"docs_I797NoticeofApprovalforI140",
            "resume":"docs_resume",
            "socialSecurityCardAndProfLicense":"docs_ssc_licence",
            "clientLetter":"docs_client_letters",
            "vendorLetter":"docs_vendor_letters",
            "msa":'docs_msa',
            "po":'docs_po',
            "h1bRegSelectionNotice":'docs_h1b_reg_selection_notice',
            "primeVendor":'docs_prime_vendor',
            "other":"docs_other",
            "I140ApprovalNotice":"hasI140ImmPetitionFiled" 
      },
      "spouse":{
            "passport":"spouse_docs_passport",
            "formI797":"spouse_docs_form_i797",
            "marriageCertificate":'spouse_docs_mrg_certificate',
            "visa":'spouse_docs_visa',
            "noticeOfApprovalOfH1Status":"spouse_docs_form_i20",
            "payStubs":"spouse_docs_pay_stubs",
            "other":"spouse_docs_other"
      },
      "child":{
            "passport":"child_docs_passport",
            "visa":'child_docs_visa',
            "formI94":"child_docs_form_i94",
            "formI797":"child_docs_form_i797",
            "birthCertificate":"child_docs_birth_certificate",
            "approvalNotice":"child_docs_approval_notice",
            "other":'child_docs_other'
      }


    }
    
    this.documentsUpload = !this.petition.documentsUploadEnabled;
    
 
   
    if (_.has(this.petition, "questionnaireTplId")) {
      //alert(this.petition['questionnaireTplId']);
      this.questionnaireTplId = this.getPetitionDetails["questionnaireTplId"];
      this.getquestionnaireDetails();
    }
    this.splitFiles();
    },
    trashDocument(){
      setTimeout(()=>{
      const $ = JQuery;
     
     this.tempUpdateDocList=[];
     $("[id^='beneficiaryDocuments_']").each( (i, el)=> {
  //   alert(el.id.substr(4))
       let _id = el.id.substr(21);
      // documentssubcategory =
        

      // this.tempUpdateDocList.push(item);
    
     });

     let postData = { "petitionId":'', 'docList':[] };
     let processDocuments =(documents ,category='benficiary' )=>{

          _.forEach(
          Object.entries(documents),
          (item ,index)=> {
            
              if( this.checkProperty(item  ,'length')>1){
              if( this.checkProperty(item[1] ,'length')>0){
                let documentCategory =item[0];

                  let activeRecords = [];
                  _.forEach(item[1] ,(doc)=>{

                   let isAlreadyExista = _.find(postData['docList'] ,{'path':doc['path']});
                    if( !this.checkProperty( doc ,'isTrashDocument') && !isAlreadyExista){
                      
                      let docListItem ={
                        "path":doc['path'],
                         "order": 1,
                          "docType": documentCategory,
                          "docTypeOrder": 1,
                          "category": category,
                         // "childrenId": ""
                      }
                      postData['docList'].push(docListItem);
                    }

                  })

                  

                }
          }
                
          });
      }
      
      processDocuments(this.petitiondocuments ,"benficiary");
      processDocuments(this.petitiondocumentr ,"spouse");
     

     
      if(this.checkProperty(postData ,'docList','length') >0 && this.checkProperty(this.petition ,'_id')  ){
        postData['petitionId'] =this.petition._id;
        let path ="/petition/save-docs-selected-config";
        if(this.checkProperty(this.petition, 'type')==3 &&  [15].indexOf(this.checkProperty(this.petition,'subTypeDetails', 'id' )) >-1 ){
            path ="/perm/save-docs-selected-config";
        }
        this.$store.dispatch("commonAction" ,{data:postData,'path':path})
        .then((rx) =>{
        //  alert(JSON.stringify(rx));
           
       

        }).catch((err)=>{
         // alert(err);
        })
      }
      
      
    } ,10)
    },
    getSavedDocuments(){
     
      let postData ={
        'petitionId':''
      };
      postData['petitionId'] =this.petition._id;
      this.isDocumentsAreSaved =false;
      let path ="/petition/get-docs-selected-config";
      if([3].indexOf(this.checkProperty(this.petition,'typeDetails', 'id' )) >-1 &&  [15].indexOf(this.checkProperty(this.petition,'subTypeDetails', 'id' )) >-1){
        path = "/perm/get-docs-selected-config"; 
      }
      
       this.$store.dispatch("commonAction" ,{data:postData,'path':path})
       .then((rx) =>{
        if(rx){

          if(this.checkProperty( rx,'docList')){
            this.isDocumentsAreSaved =true;
            this.savedDocumentsList =rx['docList'];
          }else{

             this.savedDocumentsList=[];
            this.isDocumentsAreSaved =false;

          }
          

        }else{
          this.savedDocumentsList=[];
          this.isDocumentsAreSaved =false;

        }
        this.init();
        
       }).catch((e)=>{
       
        this.savedDocuments=[];
        this.isDocumentsAreSaved =false;
        this.init();
       });
    },

    changedDocumentsTab(activeTab='savedDocuments'){
     
      setTimeout(()=>{
        this.documentActiveTab=activeTab
      });
    },
     getquestionnaireDetails() {
      let postData = { questionnaireId: this.questionnaireTplId };
      this.$store
        .dispatch("commonAction", {
          data: postData,
          path: "/questionnaire/details",
        })
        .then((res) => {
          //alert(JSON.stringify(res.name));
          this.questionnaireDetails = res;
          
         
        });
    },
     reloadCaseDetails(){
          
        
             //this.$store.dispatch("setPetitionTab", 'Case Details').then((res) => {
                  this.openEditDocs(false);
                  this.$store.dispatch("setPetitionTab", 'Documents')
                   this.$emit("updatepetition" ,'Documents');
                     
                
            //  })
           
           
            
     },
  

   
    selectMe(){
      let self =this;
      self.selectAll =false
      if(self.checkProperty(self.acceptDocs ,'length') >0){

      setTimeout(()=>{

        let selectedItems = _.filter(self.acceptDocs,(item)=>{
          return item['accepted'] ==true;
        }) 
        
          
       
        let toTalItemsLength = self.checkProperty(self.petition['documents'],'beneficiaryDocs' ,'length')

       let selectedItemsLength= self.checkProperty(selectedItems ,'length');
      
      if(toTalItemsLength >0 && selectedItemsLength>0 &&  (toTalItemsLength ==selectedItemsLength)){
        self.selectAll =true;
       
      }
      if(toTalItemsLength >0 && selectedItemsLength>0){
      //  self.isSelectedForApprove()
      self.isSelectedForApprove=true;
      }


      } ,10)
    }
      
      // if( this.checkProperty(item ,'accepted')){
      //   item['accepted'] =false;
      // }else{
      //   item['accepted'] =true;

      // }

    },
 

    findLength(){
      //petitiondocumentsl
   //   petitiondocumentr
      // if(index<=0){
      //   this.itemSlength = (this.petitiondocumentsl.length)+(this.petitiondocumentr.length)+(child.length)

      // }else{
      //   this.itemSlength = this.itemSlength+(child.length);
      // }
      this.itemSlength++;
     return true;
    },
    
     checkDocumentsExists(docs){
    //  alert(JSON.stringify(docs))
       if( this.checkProperty( docs ,'length'>0)){

          let activeDocs = _.filter(docs,{"status":true});
         // alert(JSON.stringify(activeDocs))
         if(activeDocs){
           return true
         }else{
           return false
         }

       }else{
         return true;
       }
     },
    

 remove(item, type) {
            type.splice(type.indexOf(item), 1);
            return false;
        },
      filameChenged(fileindex) {
            this.disable_uploadBtn = false;

            
                if (this.uploadFinalMainDocuments.length > 0) {
                    _.forEach(this.uploadFinalMainDocuments, (fl, value) => {
                        //let fname = fl.name;
                        let fname = fl.document.name;
                        fname = fname.trim();
                        

                        if (!fname) {
                            this.disable_uploadBtn = true;
                        }
                    });
                }
         

        },
         //uploadMainDocuments
        uploadToS3MainDocuments( docs){
             docs = docs.map(
                item =>
                (item = {
                    name: item.name,
                    file: item.file,
                    document: "",
                    path:'',
                    mimetype: item.type
                })
            );


            if (docs.length > 0) {
                let filIndex = 0;
                this.fuploder = true;
                this.disable_uploadBtn = true;
                docs.forEach(doc => {
                     
                    
                        
                    let formData = new FormData();
                    formData.append("files", doc.file);
                    formData.append("secureType", "private");
                     formData.append("getDetails", true);
                    
                       
                    this.$store.dispatch("uploadS3File", formData).then(response => {
                         filIndex++;
                         if (filIndex >= this.uploadMainDocuments.length) {
                                this.fuploder = false;
                                this.disable_uploadBtn = false;
                            }
                        

                        response.data.result.forEach(urlGenerated => {
                            //alert(JSON.stringify(urlGenerated));
                            doc.document = urlGenerated;
                            doc.path = urlGenerated;
                           //this.uploadMainDocuments.push(doc);
                           this.uploadFinalMainDocuments.push(doc);
                        });

                        
                      
                    });
                
                    
                });
            }

        },

    updateNodataLoading(rel){
      setTimeout(()=>{
        this.updateLoading(false,rel);
        setTimeout(()=>{
        this.updateLoading(false,rel);
      } ,100)
      } ,100)
      return true;

    },
    selct_all(){ 
     //petition.documents['beneficiaryDocs']
     let _self = this;
     setTimeout(()=>{

    
        _self.acceptDocs.map((item)=>{
          item.accepted =false;
        
          if(_self.selectAll){
            item.accepted =true;

          }else{
             item.accepted =false;

          }

        })
      })

      

    },
        
    approveMe(){

      let postData = {
                  petitionId: '',
                  beneficiaryDocs:[],
                  typeName:'',
                  subTypeName:''

              
            };
            
            if(this.checkProperty( this.petition ,"typeDetails" ,"name")){
              postData['typeName'] = this.petition['typeDetails']['name'];
            }
            if(this.checkProperty( this.petition ,"subTypeDetails" ,"name")){
              postData['subTypeName'] = this.petition['subTypeDetails']['name'];
            }

            this.selectedDocsForApprove= _.filter(this.petition.documents['beneficiaryDocs'] ,{"accepted":true})
                
            if(this.selectedDocsForApprove && this.selectedDocsForApprove.length>0  && _.has( this.petition ,"_id")){

              postData['beneficiaryDocs'] = this.selectedDocsForApprove;
              postData = Object.assign(postData ,{"petitionId": this.petition._id}); 
              
              postData['beneficiaryDocs'] = this.selectedDocsForApprove.map((item)=>{
                item = Object.assign(item ,{"accepted": true });
                return item;
              })

              //approveBenDocuments

              this.fuploder = true;
              this.disable_uploadBtn = true;
              let path ="/petition/accept-beneficiary-docs"
              if(this.checkProperty(this.petition['subTypeDetails'],'id') == 15){
                path="/perm/accept-beneficiary-docs"
              }
              this.$store.dispatch('commonAction', {"data":postData ,path}).then(response => {
                    this.showToster({message:response.message ,isError:false })
                    this.fileuploadPopup = false;
                    this.fuploder = false;
                    this.disable_uploadBtn = false;
                    this.fileuploadPopup = false;
                 
                  setTimeout(()=>{  this.$emit("updatepetition" ,'Documents'); } ,100);

              
              })
              .catch((error) => {
                  Object.assign(this.formerrors ,{'msg':error})
                   this.showToster({message:error ,isError:true })
                  this.fuploder = false;
                  this.disable_uploadBtn = false;
              });


      }

    },

    uploadBenDocuments() {
           
             
             Object.assign( this.formerrors ,{ msg:''})
            if (this.disable_uploadBtn) {
                return false;
            }
           // this.fileuploadPopup = false; /petition/upload-beneficiary-docs,
            let postData = {
                  petitionId: '',
                  beneficiaryDocs:[],
                  typeName:'',
                  subTypeName:''

              
            };
            
            if(this.checkProperty( this.petition ,"typeDetails" ,"name")){
              postData['typeName'] = this.petition['typeDetails']['name'];
            }
            if(this.checkProperty( this.petition ,"subTypeDetails" ,"name")){
              postData['subTypeName'] = this.petition['subTypeDetails']['name'];
            }
                
            if(this.uploadFinalMainDocuments && this.uploadFinalMainDocuments.length>0  && _.has( this.petition ,"_id")){


               if(this.uploadFinalMainDocuments.length>0){

                    this.uploadFinalMainDocuments.forEach((doc)=>{
                       
                        let document = doc.document
                        document = Object.assign(document ,{ name:doc.name})
                         postData['beneficiaryDocs'].push(document);
                    })
                   

                

              postData['beneficiaryDocs'] = postData['beneficiaryDocs'].map((item)=>{
                item.accepted =false;
                return item;

              });
              //petition.documents['beneficiaryDocs']
              if(this.checkProperty( this.petition ,"documents" ,"beneficiaryDocs") && (this.petition.documents['beneficiaryDocs'].length>0 )){
                _.forEach( this.petition.documents['beneficiaryDocs'], (item)=>{
                  postData['beneficiaryDocs'].push(item);

                })

              }
              postData = Object.assign(postData ,{"petitionId": this.petition._id});  
              
              this.fuploder = true;
              this.disable_uploadBtn = true;
              let path ="/petition/upload-beneficiary-docs"
              if(this.checkProperty(this.petition['subTypeDetails'],'id') == 15){
                path="/perm/upload-beneficiary-docs"
              }
              //"uploadBenDocuments", postData
             
              this.$store.dispatch('commonAction', {"data":postData ,path}).then(response => {
                    this.showToster({message:response.message ,isError:false })
                    this.fileuploadPopup = false;
                    this.fuploder = false;
                    this.disable_uploadBtn = false;
                    this.fileuploadPopup = false;
                 
                  setTimeout(()=>{
                    this.$store.dispatch("setPetitionTab" , '').then(()=>{
                      this.$emit("updatepetition" ,'Documents');

                    }).catch(()=>{
                      this.$emit("updatepetition" ,'Documents');

                    })
                     
                     
                          
                          
                      } ,100);

              
              })
              .catch((error) => {
                  Object.assign(this.formerrors ,{'msg':error})
                  this.fuploder = false;
                  this.disable_uploadBtn = false;
              });
        
         }
          }else{
            Object.assign( this.formerrors ,{ msg:'Upload atleast one document'})

      }
    
         
       
    },

    selectedDocuments(docs) {
           
            docs = docs.map(
                item =>
                (item = {
                    name: item.name,
                    file: item.file,
                    extn: "",
                    path:'',
                    mimetype: item.type,
                    accepted:false,
                })
            );
            this.documentUploaded = [];
            this.documentUploaded = docs;
            this.fuploder = false;
            this.disable_uploadBtn = false;
            if (docs.length > 0) {
                let filIndex = 0;
                this.fuploder = true;
                this.disable_uploadBtn = true;
                this.documentUploaded.forEach(doc => {
                     
                     
                         
                    let formData = new FormData();
                    formData.append("files", doc.file);
                    formData.append("secureType", "private");
                     formData.append("getDetails", true);
                    
                       
                    this.$store.dispatch("uploadS3File", formData).then(response => {
                         filIndex++;
                         if (filIndex >= this.documentUploaded.length) {
                                this.fuploder = false;
                                this.disable_uploadBtn = false;
                            }
                      

                        response.data.result.forEach(urlGenerated => {
                            
                             doc.path = urlGenerated.path;
                             doc.extn = urlGenerated.extn;
                             delete doc.file
                        });

                        
                      
                    });
               
                    
                });
            }
            this.fileuploadPopup = true
        },
     remove_uploadedfile( fileindex) {
            
            this.documentUploaded.splice(fileindex, 1);

            if(this.documentUploaded.length ==0){
              this.fileuploadPopup =false;

            }
        },
     fileNameChenged( fileindex) {
            this.disable_uploadBtn = false;

            
                if (this.documentUploaded.length > 0) {
                    _.forEach(this.documentUploaded, (fl, index) => {
                      if(index ==fileindex){
                        //let fname = fl.name;
                        let fname = fl.name;
                        fname = fname.trim();

                        if (!fname) {
                            this.disable_uploadBtn = true;
                        }
                    }

                    });
                }
           

        },
    changeTab(tabName=''){

      this.selectAll =false;
      
      this.initDocuments();
      this.activeTabName = tabName;
      this.openEditDocs(false);
        setTimeout(()=>{

           this.updateNodataLoading()
           
          // this.selct_all();
        } , 100)
       


      


    },
    checkDocLen(documents){
     
      
        let return_value =false
        _.each(documents ,(val ,indx)=>{
         
          if(val.length>0 && indx !="beneficiaryDocs"){
            
         
            return_value = true;

            
          }
        });
        
        return return_value;
      

    },
    selectDoctype(type = "") {
      this.uploaddocType = type;
    },

    upload(model, uploaddocType) {
      this.is_enablesavebtn = false;
      
      let temp_count = 0;
      this.uploaddocType = uploaddocType;
      let formData = new FormData();
      if (model.length > 0) {
        this.$vs.loading();
        model.forEach((doc) => {
          formData.append("files", doc.file);
          formData.append("secureType", "public");
          this.$store.dispatch("uploadS3File", formData).then((response) => {
           temp_count++;
            let docmnt = {
              mimetype: model[0]["file"]["type"],
              name: model[0]["file"]["name"],
              status: true,
              uploadedOn: new Date(),
              url: response["data"]["result"][0],
              path: response["data"]["result"][0],
              tempDoc:true,
              uploadedBy:this.checkProperty(this.getUserData,'userId'),
              uploadedByName:this.checkProperty(this.getUserData,'name'),
              uploadedByRoleId:this.getUserRoleId,
              uploadedByRoleName:this.checkProperty(this.getUserData,'loginRoleName'),
            };

            this.petition["documents"][this.uploaddocType].push(docmnt);
            this.is_enablesavebtn = true;
            if (temp_count >= model.length) {
                 
                  this.$vs.loading.close();
              }
          });
        });
      }
    },

    saveUploadedsFiles() {
      var postpetition = {
        petitionId: this.$route.params.itemId,
        userName: this.$store.state.user.name,
        action: "UPLOAD_DOCUMENTS",
        documents: this.petition["documents"],
        typeName: this.petition["subTypeDetails"]["name"],
        subTypeName: this.petition["typeDetails"]["name"],
      };



      this.$store
        .dispatch("petitioner/petitionupdate", postpetition)

        .then((response) => {
          if (response.error) {
            Object.assign(this.formerrors, {
              msg: response.error.message,
            });
          } else {
            this.is_enablesavebtn = false;
            this.$emit("updatepetition" ,'Documents');
            this.$vs.notify({
              text: response.message,
              position: "top-right",
              color: "primary",
              
            });
          }
        });
    },
    removethis(index,parent) {
      
      parent.splice(index, 1);
      this.trashDocument()
      return false;
      
    },
    removethisalt(index,parent) {
      
      this.petitiondocumentr.splice(index, 1);
      return false;
    },
    removethissub(item,parent) {
   parent.splice(item.indexOf(parent), 1);
      return false;
    },
    checker(value) {
      this.documentlockformcomments = "";
      this.lockUnlockformerrors = '';
      this.lockDocumentsPopup = true;
      this.lockDocumentsPopupTitle = "Lock Documents";
      if (!value) this.lockDocumentsPopupTitle = "Unlock Documents";
      this.documentsUpload = value;

       this.$validator.reset();
    },
    submitdocumentslock() {
     this.lockUnlockformerrors ='';
      this.$validator.validateAll("documentlockform").then((result) => {
        if (result) {
          var postdata = {
            petitionId: this.petition._id,
            typeName: this.petition.typeDetails.name,
            subTypeName: this.petition.subTypeDetails.name,
            comment: this.documentlockformcomments,
            action: this.documentsUpload
              ? "DISABLE_DOCUMENT_UPLOAD"
              : "ENABLE_DOCUMENT_UPLOAD",
          };

          this.$store
            .dispatch("managedocumentupload", postdata)
            .then((response) => {
              this.lockDocumentsPopup = false;
              this.documentlockformcomments = "";
              this.petition.documentsUploadEnabled = this.documentsUpload;
              this.showMessages(response.message);
              window.location.reload();
              //this.$emit("updatepetition");
              
            })
            .catch((error)=>{
              this.lockUnlockformerrors = error;
              this.showToster({ message: error, isError: true });

            })
        }
      });
    },
    successUpload() {
      this.$vs.notify({
        color: "success",        
        position: "top-right",
        color: "primary",
        text: "Documents Sucessfully Uploded",
      });
    },
    showMessages(message) {
      this.$vs.notify({
        title: "Success",
        position: "top-right",
        color: "success",
        iconPack: "feather",
        icon: "icon-check",
        text: message,
      });
    },
    downloadallfile() {
        this.filesDownloading =false;
        //this.petitiondocuments =[];
         //this.petitiondocumentr =[];
       //  this.petitiondocuments = _.cloneDeep(this.petition.documents);
         this.downloadDocList = true;
        //this.splitFiles();
      
        this.downloadDocumentPop = true;
        setTimeout(()=>{
          this.changedDocumentsTab('savedDocuments');
        });
     
    },
    downloadcombine() {
     let _APIURL = this.$globalgonfig._APIURL
      var self = this;
      var docs = [];


    let combailDocuments = (documents)=>{
        _.forEach(documents ,(doc)=> {

          if(this.checkProperty(doc ,'length') >1){
            if(this.checkProperty(doc[1] ,'length') >0){
           
            doc[1].forEach(i=> {
                  if(i.path!=null && i.path !='' && !this.checkProperty(i ,'isTrashDocument')   ){ 
                    docs.push(i.path);
                  }else if(i.url!=null && i.url !='' && !this.checkProperty(i ,'isTrashDocument')  ){ 
                    docs.push(i.url);
                  }
            })
          }
          }
        })
    }
    combailDocuments(this.petitiondocuments );
    combailDocuments(this.petitiondocumentr );
       
         
        this.childernDocuments.forEach((child)=>{

           child.forEach(doc=> {
           doc[1].forEach(i=> {
                if(i.path !='' && i.path!=null && !this.checkProperty(i ,'isTrashDocument') ){ 
                  docs.push(i.path);
                }else if(i.url !='' && i.url!=null && !this.checkProperty(i ,'isTrashDocument') ){ 
                  docs.push(i.url);
                }
           })
        })


        })
       

              let postdata = {
        petitionId: this.petition._id,
        documents: docs,
      };
     
      
      if(postdata['documents'].length>0){
          this.filesDownloading =true;
        this.$store
        .dispatch("downloaddocsbyorder", postdata)
        .then((response) => {
           this.filesDownloading =false;
       
          self.downloadDocumentPop = true;
         // alert( _APIURL+"/common/viewfile?path="+response.data.result.path);
          window.open(
            _APIURL+"/common/viewfile?path=" +
              response.data.result.path,
            "_blank"
          );
        }).catch((error)=>{
          this.filesDownloading =false;
          this.showToster({ message:error , isError: true})
         
        });
    
      } 
    },
    downloadfile(value, download = false, viewmode = true) {
      value.download = download;
     // value.viewmode = viewmode;
      if(_.has(value ,"url" ) && !(_.has(value ,"path" ) )){
        value =Object.assign(value ,{ "path":value['url']})
      }else  if(_.has(value ,"path" ) && !(_.has(value ,"url" )) ){
        value =Object.assign(value ,{ "url":value['path']})
      }
      //alert(value.viewmode)
      this.$emit('download_or_view' ,value);
      // value.url = value.url.replace(this.$globalgonfig._S3URL,"");
      // value.url = value.url.replace(this.$globalgonfig._S3URLAWS,"");
      // let postdata = { keyName: value.url };
      // this.$store.dispatch("getSignedUrl", postdata).then((response) => {
      //   window.open(response.data.result.data, "_blank");
      // });  ({'field':field , 'dataVar':beneficiaryInfo})
    },
  },
  computed:{
   checkDocumentPath(){
    return (data)=>{

    }
   },
    checkNoNotifyUserIds(){
      let returnValue =true;
      if(_.has(this.petition, 'noNotifyUserIds')  ){
        if(this.petition['noNotifyUserIds'].length>0){
          if(this.petition['noNotifyUserIds'].indexOf(this.getUserData['userId']) >-1){
            returnValue = false;
          }

        }

      }
      return returnValue;
    },
    //5--front office user
    checkApproveDocuments(){
      let returnVal = false;
      
      let docSupList = _.find(this.workFlowDetails.config, {
        code: "SUPERVISOR_LIST",
      });
      if (docSupList && docSupList.editors) {
        this.finalList = _.map(docSupList.editors, "roleId");
      }
      if(this.finalList && this.finalList.indexOf( this.getUserRoleId)>-1 || [5].indexOf(this.getUserRoleId)>-1) {
        returnVal = true;
      }
      
      return returnVal;
    },

    
    getbenficiarySavedDocuments(){
     
      let returnSavedDocuments =[];
      _.forEach(Object.entries(this.petitiondocuments) , (category ,index)=>{
       
        if(this.checkProperty(category ,'length')>1){
          if(this.checkProperty(category[1] ,'length') >0){
            let trashedItems = _.filter(category[1] ,{'isTrashDocument':false});
           
            if(trashedItems && this.checkProperty(trashedItems ,'length')>0){
             
              returnSavedDocuments.push(category);
            }

          }
          //isTrashDocument
       

        }

      });
      return returnSavedDocuments
     
     
    },
    getbenficiaryTrashedDocuments(){
     
      let returnSavedDocuments =[];
      _.forEach(Object.entries(this.petitiondocuments) , (category ,index)=>{
       
        if(this.checkProperty(category ,'length')>1){
          if(this.checkProperty(category[1] ,'length') >0){
            let trashedItems = _.filter(category[1] ,{'isTrashDocument':true});
           
            if(trashedItems && this.checkProperty(trashedItems ,'length')>0){
             
              returnSavedDocuments.push(category);
            }

          }
          //isTrashDocument
       

        }

      });
     
      return returnSavedDocuments
     
     
    },

    
    getspouseSavedDocuments(){
      //this.petitiondocumentr
       let returnSavedDocuments =[];
      _.forEach(Object.entries(this.petitiondocumentr) , (category ,index)=>{
       
        if(this.checkProperty(category ,'length')>1){
          if(this.checkProperty(category[1] ,'length') >0){
            let trashedItems = _.filter(category[1] ,{'isTrashDocument':false});
           
            if( this.checkProperty(trashedItems ,'length')>0){
             
              returnSavedDocuments.push(category);
            }

          }
          //isTrashDocument
       

        }

      });
      return returnSavedDocuments
     

    },
    getspouseTrashedDocuments(){
      //this.petitiondocumentr
       let returnSavedDocuments =[];
      _.forEach(Object.entries(this.petitiondocumentr) , (category ,index)=>{
       
        if(this.checkProperty(category ,'length')>1){
          if(this.checkProperty(category[1] ,'length') >0){
            let trashedItems = _.filter(category[1] ,{'isTrashDocument':true});
           
            if(trashedItems && this.checkProperty(trashedItems ,'length')>0){
             
              returnSavedDocuments.push(category);
            }

          }
          //isTrashDocument
       

        }

      });
      return returnSavedDocuments
     

    },
    
    //childernDocuments
    getChildSavedDocuments(){

      
      //this.petitiondocumentr
        let finalArray =[];
       _.forEach(this.childernDocuments ,(child ,index)=>{
         
         let returnSavedDocuments =[];
      _.forEach(Object.entries(child) , (category ,index)=>{
       
        if(this.checkProperty(category ,'length')>1){
          if(this.checkProperty(category[1] ,'length') >0){
            let trashedItems = _.filter(category[1][1] ,{'isTrashDocument':false});
           
            if( this.checkProperty(trashedItems ,'length')>0){
             
              returnSavedDocuments.push(category[1]);
           }

          }
          //isTrashDocument
       

        }

      });
     

      if(this.checkProperty(returnSavedDocuments ,'length')>0){
        finalArray.push(returnSavedDocuments)
      }


    })
      return finalArray
     

    },
    getChildTrasheddDocuments(){

      

      
      //this.petitiondocumentr
        let finalArray =[];
       _.forEach(this.childernDocuments ,(child ,index)=>{
         
         let returnSavedDocuments =[];
      _.forEach(Object.entries(child) , (category ,index)=>{
       
        if(this.checkProperty(category ,'length')>1){
          if(this.checkProperty(category[1] ,'length') >0){
            let trashedItems = _.filter(category[1][1] ,{'isTrashDocument':true});
           
            if( this.checkProperty(trashedItems ,'length')>0){
             
              returnSavedDocuments.push(category[1]);
           }

          }
          //isTrashDocument
       

        }

      });
     

      if(this.checkProperty(returnSavedDocuments ,'length')>0){
        finalArray.push(returnSavedDocuments)
      }


    })
      return finalArray

    },
    
    isSelectedForApprove(){
     let selectedItems= _.filter(this.acceptDocs,{"accepted":true})
     if(selectedItems && selectedItems.length>0){
       return true;
     }else{
       return false;

     }
    }
   
  }
};
</script>
