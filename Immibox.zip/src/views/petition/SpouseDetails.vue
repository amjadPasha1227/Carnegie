<template>
  <div class="main-list-wrap pad20 petition_details_wrap">
    <div class="dependent-block_wrap" v-if="canRenderField('hasAnyDependetsinUStoFileH4', questionnaireDetails ,false,'beneficiaryInfo')">
        <div class="dependent-block dependent-block-transparent">
            <div class="vx-col  w-full p-0">
                <div class="dependent_details">
                    <ul class="toplist">
                        <li>Do you have any dependents currently in USA for whom you wish to file H4 Visa? <span>{{petition.beneficiaryInfo.hasAnyDependetsinUStoFileH4 | booleanFormat}}</span></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="vx-row m-0 main-list-panel">
  
      <div class="vx-col md:w-1/3 w-full p-0" >
        <div class="main-list">
          <p>
            Name of Spouse
            <span v-if="checkProperty(petition['dependentsInfo'],'spouse' ,'name')">{{checkProperty(petition['dependentsInfo'],'spouse' ,'name')}}</span>
            <span v-else>{{checkProperty(petition['dependentsInfo'],'spouse' ,'firstName')}} {{checkProperty(petition['dependentsInfo'],'spouse' ,'middleName')}} {{checkProperty(petition['dependentsInfo'],'spouse' ,'lastName')}}</span>
          </p>
        </div>
      </div>
         <div class="vx-col md:w-1/3 w-full p-0" v-if="petition.dependentsInfo.spouse.email" >
        <div class="main-list">
          <p>
            Email
            <span>{{petition.dependentsInfo.spouse.email}}</span>
          </p>
        </div>
      </div>
      <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition['dependentsInfo'],'spouse' ,'gender')">
        <div class="main-list">
          <p>
            Gender
            <span style="text-transform: capitalize;">{{checkProperty(petition['dependentsInfo'],'spouse' ,'gender')}}</span>
          </p>
        </div>
      </div>
      <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition['dependentsInfo'],'spouse' ,'maidenName')">
        <div class="main-list">
          <p>
            Maiden Name
            <span style="text-transform: capitalize;">{{checkProperty(petition['dependentsInfo'],'spouse' ,'maidenName')}}</span>
          </p>
        </div>
      </div>
       <div class="vx-col md:w-1/3 w-full p-0" v-if="petition.dependentsInfo.spouse.phoneNumber" >
        <div class="main-list">
          <p>
            Phone Number
            <span>
            <template v-if="checkProperty(petition.dependentsInfo.spouse ,'phoneCountryCode' ,'countryCallingCode')">{{checkProperty(petition.dependentsInfo.spouse ,'phoneCountryCode' ,'countryCallingCode')+"&nbsp;"}}</template>
            {{petition.dependentsInfo.spouse.phoneNumber}}</span>
          </p>
        </div>
      </div>
      <div class="vx-col md:w-1/3 w-full p-0" v-if="petition.dependentsInfo.spouse.dateOfBirth">
        <div class="main-list">
          <p>
            Date of Birth
            
            <span>{{checkProperty(petition.dependentsInfo ,'spouse' ,'dateOfBirth') | formatDate}}</span>
          </p>
        </div>
      </div>
      <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition.dependentsInfo['spouse'] ,'currentSpouseName' )">
        <div class="main-list">
          <p>
            Current Spouse Name
            <span>{{checkProperty(petition.dependentsInfo['spouse'] ,'currentSpouseName' )}}</span>
           
          </p>
        </div>
      </div>
      <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition.dependentsInfo['spouse'] ,'countryOfBirthDetails' ,'name')">
        <div class="main-list">
          <p>
            Country of Birth
            <span>{{checkProperty(petition.dependentsInfo['spouse'] ,'countryOfBirthDetails' ,'name') | empty}}</span>
           
          </p>
        </div>
      </div>
      <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition.dependentsInfo ,'spouse' ,'provinceOfBirthDetails')">
        <div class="main-list">
          <p>
            Province of Birth
            <span>{{checkProperty(petition.dependentsInfo['spouse'] ,'provinceOfBirthDetails' ,'name') | empty}}</span>
          </p>
        </div>
      </div>
       <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition.dependentsInfo ,'spouse' ,'locationOfBirth')">
        <div class="main-list">
          <p>
            Location of Birth
            <span>{{checkProperty(petition.dependentsInfo ,'spouse' ,'locationOfBirth' ) | empty}}</span>
          </p>
        </div>
      </div>
      <div class="vx-col md:w-1/3 w-full p-0" v-if="canRenderField('hasSpouse', questionnaireDetails ,false,'dependentsInfo.spouse')">
            <div class="main-list">
              <p>
               Fill Spouse information
                <span v-if="checkProperty(petition['dependentsInfo'],'spouse', 'hasSpouse')" > Yes </span>
                <span v-else> No </span>
              </p>
            </div>
          </div>
      <div class="vx-col md:w-1/3 w-full p-0" v-if="canRenderField('h4Required', questionnaireDetails ,false,'dependentsInfo.spouse')">
        <div class="main-list">
          <p>
            H4 required for spouse
            <span v-if="checkProperty(petition['dependentsInfo'] ,'spouse' ,'h4Required')">Yes</span>
            <span v-else>No</span>
          </p>
        </div>
      </div>

      <div class="vx-col md:w-1/3 w-full p-0" v-if="canRenderField('h4EADRequired', questionnaireDetails ,false,'dependentsInfo.spouse')" >
        <div class="main-list">
          <p>
           H4 EAD required for spouse
            <span v-if="checkProperty(petition['dependentsInfo'] ,'spouse' ,'h4EADRequired')">Yes</span>
            <span v-else>No</span>
          </p>
        </div>
      </div>
      <div class="vx-col md:w-1/3 w-full p-0" v-if="canRenderField('doYouAlreadyH4EAD', questionnaireDetails ,false,'dependentsInfo.spouse')" >
        <div class="main-list">
          <p>
            Do you already have H4 EAD?
            <span v-if="checkProperty(petition['dependentsInfo'] ,'spouse' ,'doYouAlreadyH4EAD')">Yes</span>
            <span v-else>No</span>
          </p>
        </div>
      </div>
      <div class="vx-col md:w-1/3 w-full p-0" v-if="canRenderField('adjustmentStatusToPermResidenceI485', questionnaireDetails ,false,'dependentsInfo.spouse')" >
        <div class="main-list">
          <p>
            Adjustment of status to Permanent Residency (Form I-485) required for spouse
            <span>{{checkProperty(petition['dependentsInfo']['spouse'] ,'adjustmentStatusToPermResidenceI485' ) | booleanFormat }}</span>
            
          </p>
        </div>
      </div>
      <template>
        <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition['dependentsInfo'] ,'spouse','dateOfMarriage')">
            <div class="main-list">
                <p>
                    Date of Marriage
                    <span>{{petition.dependentsInfo.spouse.dateOfMarriage | formatDate}}</span>
                </p>
            </div>
        </div>
        <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition['dependentsInfo'] ,'spouse','dateOfMarriageEnd')">
            <div class="main-list">
                <p>
                    Date of Marriage End
                    <span>{{petition.dependentsInfo.spouse.dateOfMarriageEnd | formatDate}}</span>
                </p>
            </div>
        </div>
        <div class="vx-col md:w-1/3 w-full p-0" v-if=" checkProperty(petition['dependentsInfo'] , 'spouse' ,'maritalStatusDetails') && checkProperty(petition['dependentsInfo']['spouse'] ,'maritalStatusDetails','name')" >
        <div class="main-list">
          <p>
            Marital Status
            <span>{{checkProperty(petition['dependentsInfo']['spouse'] ,'maritalStatusDetails' ,'name') }}</span>
          </p>
        </div>
       </div>
        <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition['dependentsInfo'] ,'spouse' ,'hairColor') && checkProperty(petition['dependentsInfo']['spouse'] ,'hairColor','id')">
            <div class="main-list">
                <p>
                    Hair color
                    <span>{{ checkProperty(petition['dependentsInfo']['spouse'] ,'hairColor','name')  }}</span>
                </p>
            </div>
        </div>
        <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition['dependentsInfo'] ,'spouse'  ,'race') && checkProperty(petition['dependentsInfo']['spouse'] ,'race','id')">
            <div class="main-list">
                <p>
                    Race
                    <span>{{ checkProperty(petition['dependentsInfo']['spouse'] ,'race','name')  }}</span>
                </p>
            </div>
        </div> 
        <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition['dependentsInfo'] ,'spouse'  ,'eyeColor') && checkProperty(petition['dependentsInfo']['spouse'] ,'eyeColor','id')">
            <div class="main-list">
                <p>
                    Eye Color
                    <span>{{ checkProperty(petition['dependentsInfo']['spouse'] ,'eyeColor','name')  }}</span>
                </p>
            </div>
        </div>
        <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition['dependentsInfo']['spouse'] ,'weight') ">
            <div class="main-list">
                <p>
                    Weight
                    <span>{{ checkProperty(petition['dependentsInfo']['spouse'] ,'weight')  }}</span>
                </p>
            </div>
        </div>
        <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition['dependentsInfo']['spouse'] ,'height') && (checkProperty(petition['dependentsInfo']['spouse'] ,'height','feet')||
        checkProperty(petition['dependentsInfo']['spouse'],'height','inches')) ">
            <div class="main-list">
                <p>
                    Height
                    <!-- <span>{{ checkProperty(petition['dependentsInfo']['spouse'] ,'height')  }}</span> -->
                    <span>{{ convertHeight(checkProperty(petition['dependentsInfo']['spouse'] ,'height')) }}</span>
                </p>
            </div>
        </div>
        <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition['dependentsInfo']['spouse'] ,'relationship') ">
            <div class="main-list">
                <p>
                    Relationship
                    <span>{{ checkProperty(petition['dependentsInfo']['spouse'] ,'relationship')  }}</span>
                </p>
            </div>
        </div>
    </template>
  

      <div class="vx-col md:w-1/3 w-full p-0" v-if="petition.dependentsInfo.spouse.passportNumber">
        <div class="main-list">
          <p>
            Passport Number
            <span>
            
            {{petition.dependentsInfo.spouse.passportNumber }}
            
            </span>
          </p>
        </div>
      </div>
      <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition['dependentsInfo']['spouse'] ,'passportIssuedCountryDetails','name')">
            <div class="main-list">
                <p>
                  Country of Passport Issued
                    <span>{{ checkProperty(petition['dependentsInfo']['spouse'] ,'passportIssuedCountryDetails','name') }}</span>
                </p>
            </div>
        </div>

      <div
        class="vx-col md:w-1/3 w-full p-0"
        v-if="petition.dependentsInfo.spouse.passportExpiryDate"
      >
        <div class="main-list">
          <p>
            Date of Passport Expiry
            <span>{{petition.dependentsInfo.spouse.passportExpiryDate | formatDate}}</span>
          </p>
        </div>
      </div>
      <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition['dependentsInfo'] ,'spouse' ,'I94')">
        <div class="main-list">
          <p>
            Spouse I-94
            <span>{{petition.dependentsInfo.spouse.I94}}</span>
          </p>
        </div>
      </div>
      
   <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition['dependentsInfo'] ,'spouse' ,'I94ExpiryDate') || checkProperty(petition['dependentsInfo'] ,'spouse'  ,'isI94DSExpiryDate')  ">
        <div class="main-list">
          <p>
             I-94 Expiry Date
            <span v-if="checkProperty(petition['dependentsInfo']['spouse'] ,'isI94DSExpiryDate')">D/S</span>
            <span v-else>{{petition.dependentsInfo.spouse.I94ExpiryDate | formatDate}}</span>
          </p>
        </div>
      </div>
      <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition['dependentsInfo'] ,'spouse' ,'eadNumber')">
        <div class="main-list">
          <p>
            EAD Number
            <span>{{petition.dependentsInfo.spouse.eadNumber}}</span>
          </p>
        </div>
      </div>
      <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition['dependentsInfo'] ,'spouse' ,'sevisNumber')">
        <div class="main-list">
          <p>
            SEVIS Number
            <span>{{petition.dependentsInfo.spouse.sevisNumber}}</span>
          </p>
        </div>
      </div>
       <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition['dependentsInfo'] , 'spouse' ,'countryOfCitizenshipDetails') && checkProperty(petition['dependentsInfo']['spouse'] ,'countryOfCitizenshipDetails' ,'name')" >
        <div class="main-list">
          <p>
             Country of Citizenship
            <span>{{checkProperty(petition['dependentsInfo']['spouse'] ,'countryOfCitizenshipDetails' ,'name') }}</span>
          </p>
        </div>
       </div>
       <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition['dependentsInfo'] , 'spouse' ,'otherCountriesOfCitizenshipDetails') && checkProperty(petition['dependentsInfo']['spouse'] ,'otherCountriesOfCitizenshipDetails' ,'length')>0 
       && formatCountriesName(checkProperty(petition['dependentsInfo']['spouse'] ,'otherCountriesOfCitizenshipDetails' )) !=''" >
        <div class="main-list">
          <p>
            Any other country(ies) of Citizenship
            <span>{{formatCountriesName(checkProperty(petition['dependentsInfo']['spouse'] ,'otherCountriesOfCitizenshipDetails' )) }}</span>
          </p>
        </div>
       </div>
       <template v-if="checkProperty(petition, 'subTypeDetails','id') == 16">
       <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition['dependentsInfo'] , 'spouse' ,'adjustmentOfI485Status')==false || checkProperty(petition['dependentsInfo'] , 'spouse' ,'adjustmentOfI485Status') == true" >
        <div class="main-list">
          <p>
            Adjustment of Status (I-485)
            <span>{{checkProperty(petition['dependentsInfo']['spouse'] ,'adjustmentOfI485Status' ) | booleanFormat }}</span>
          </p>
        </div>
       </div>
       <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition['dependentsInfo'] , 'spouse' ,'consularProcessing')== false || checkProperty(petition['dependentsInfo'] , 'spouse' ,'consularProcessing') == true" >
        <div class="main-list">
          <p>
            Consular Processing
            <span>{{checkProperty(petition['dependentsInfo']['spouse'] ,'consularProcessing' ) | booleanFormat }}</span>
          </p>
        </div>
       </div>
      </template>
      <div class="vx-col md:w-1/3 w-full p-0" v-if="petition.dependentsInfo.spouse.visaIssuedDate">
        <div class="main-list">
          <p>
            Date Case issued
            <span>{{petition.dependentsInfo.spouse.visaIssuedDate | formatDate}}</span>
          </p>
        </div>
      </div>

      <div class="vx-col md:w-1/3 w-full p-0" v-if="petition.dependentsInfo.spouse.currentStatus">
        <div class="main-list">
          <p>
            Current Nonimmigrant Status 
            <!-- <span>{{petition.dependentsInfo.spouse.currentStatusDetails.name | empty}}</span> -->
            <!-- <span>{{petition.dependentsInfo.spouse.currentStatus  | formatML(petition.visaStatusList)}}</span> -->
            <span>{{petition.dependentsInfo.spouse.currentStatus  | formatML(visastatuses)}}</span>
          </p>
        </div>
      </div>
      <div
        class="vx-col md:w-1/3 w-full p-0"
        v-if="petition.dependentsInfo.spouse.statusExpiryDate ||checkProperty(petition['dependentsInfo'],'spouse' ,'isDSExpiryDate')"
      >
        <div class="main-list">
          <p>
           Current Status Expiry Date
            <span v-if="checkProperty(petition['dependentsInfo'],'spouse' ,'isDSExpiryDate')">D/S</span>
            <span v-else>{{petition.dependentsInfo.spouse.statusExpiryDate | formatDate}}</span>
          </p>
        </div>
      </div>
      <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition['dependentsInfo'], 'spouse','curNonImmigrantVisaNumber')">
            <div class="main-list">
                <p>
                    Current nonimmigrant visa number
                    <span>{{ checkProperty(petition['dependentsInfo'], 'spouse','curNonImmigrantVisaNumber')}}</span>
                </p>
            </div>
        </div>
      <div class="vx-col md:w-1/3 w-full p-0" v-if="canRenderField('currentlyInUS', questionnaireDetails ,false,'dependentsInfo.spouse')">
        <div class="main-list">
          <p>
            Currently in USA
            <span>{{checkProperty(petition['dependentsInfo'], 'spouse', 'currentlyInUS') | booleanFormat}}</span>
          </p>
        </div>
      </div>
      <div class="vx-col md:w-1/3  w-full p-0" v-if="canRenderField('haveYouEverTravelledToUS', questionnaireDetails ,false,'dependentsInfo.spouse')" >
          <div class="main-list">
              <p>
                  Have you ever travelled to the United States?
                  <span v-if="checkProperty(petition['dependentsInfo'],'spouse' ,'haveYouEverTravelledToUS')"> Yes</span>
                  <span v-else> No</span>
              </p>
          </div>
      </div>
      <div class="vx-col md:w-1/3 w-full p-0" v-if=" canRenderField('haveYouEverTravelledToUS', questionnaireDetails ,false,'dependentsInfo.spouse') && checkProperty(petition['dependentsInfo'],'spouse' ,'haveYouEverTravelledToUS') && 
      checkProperty(petition['dependentsInfo'], 'spouse', 'immigStatusLastArrival')">
        <div class="main-list">
          <p>
            Immigration Status at Your Last Arrival
            <span>{{checkProperty(petition['dependentsInfo'], 'spouse', 'immigStatusLastArrival') }}</span>
          </p>
        </div>
      </div>
      <div class="vx-col md:w-1/3 w-full p-0" v-if="canRenderField('doYouHaveSSN', questionnaireDetails ,false,'dependentsInfo.spouse')">
        <div class="main-list">
          <p>
            Do you have SSN?
            <span>{{checkProperty(petition['dependentsInfo'], 'spouse', 'doYouHaveSSN') | booleanFormat}}</span>
          </p>
        </div>
      </div>
      <div class="vx-col md:w-1/3 w-full p-0" v-if="petition.dependentsInfo.spouse.SSN">
        <div class="main-list">
          <p>
            Social Security Number
            <span>{{petition.dependentsInfo.spouse.SSN}}</span>
          </p>
        </div>
      </div>
      <div class="vx-col md:w-1/3 w-full p-0" v-if=" canRenderField('doYouHaveSSN', questionnaireDetails ,false,'dependentsInfo.spouse') &&
      !checkProperty(petition['dependentsInfo'], 'spouse', 'doYouHaveSSN') &&
      canRenderField('doYouWantTheSsaToIssueYouSS', questionnaireDetails ,false,'dependentsInfo.spouse')">
        <div class="main-list">
          <p>
            Do you want the SSA to issue you a Social Security card?
            <span>{{checkProperty(petition['dependentsInfo'], 'spouse', 'doYouWantTheSsaToIssueYouSS') | booleanFormat}}</span>
          </p>
        </div>
      </div>
      <template v-if=" canRenderField('doYouHaveSSN', questionnaireDetails ,false,'dependentsInfo.spouse') &&
        !checkProperty(petition['dependentsInfo'], 'spouse', 'doYouHaveSSN') &&
        canRenderField('doYouWantTheSsaToIssueYouSS', questionnaireDetails ,false,'dependentsInfo.spouse') && checkProperty(petition['dependentsInfo'], 'spouse', 'doYouWantTheSsaToIssueYouSS') ">
        <template v-if="checkProperty(petition['dependentsInfo'], 'spouse','ssnFather') && 
        (checkProperty(petition['dependentsInfo']['spouse'],'ssnFather','familyName') || checkProperty(petition['dependentsInfo']['spouse'],'ssnFather', 'givenName'))" >
        <h5 class="names_title">Father Name</h5>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition['dependentsInfo']['spouse'],'ssnFather','familyName')">
              <div class="main-list">
                <p>
                  Family Name
                  <span>{{checkProperty(petition['dependentsInfo']['spouse'],'ssnFather','familyName')}}</span>
                </p>
              </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition['dependentsInfo']['spouse'],'ssnFather', 'givenName')">
              <div class="main-list">
                <p>
                  Given Name
                  <span>{{checkProperty(petition['dependentsInfo']['spouse'],'ssnFather', 'givenName')}}</span>
                </p>
              </div>
            </div>
        </template>
        <template v-if="checkProperty(petition['dependentsInfo'], 'spouse','ssnMother') && 
        (checkProperty(petition['dependentsInfo']['spouse'],'ssnMother','familyName') || checkProperty(petition['dependentsInfo']['spouse'],'ssnMother', 'givenName'))" >
          <h5 class="names_title">Mother Name</h5>
          <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition['dependentsInfo']['spouse'],'ssnMother','familyName')">
            <div class="main-list">
              <p>
                Family Name
                <span>{{checkProperty(petition['dependentsInfo']['spouse'],'ssnMother','familyName')}}</span>
              </p>
            </div>
          </div>
          <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition['dependentsInfo']['spouse'],'ssnMother', 'givenName')">
            <div class="main-list">
              <p>
                Given Name
                <span>{{checkProperty(petition['dependentsInfo']['spouse'],'ssnMother', 'givenName')}}</span>
              </p>
            </div>
          </div>
        </template>
      </template>
      <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition['dependentsInfo'],'spouse','alienNumber')">
            <div class="main-list">
                <p>
                    Alien Number
                    <span>{{checkProperty(petition['dependentsInfo'],'spouse','alienNumber')}}</span>
                </p>
            </div>
      </div>
        <template>
        <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition['dependentsInfo'],'spouse','placeOfLastEntryInUS')">
            <div class="main-list">
                <p>
                  Place of recent entry into the USA
                    <span>{{checkProperty(petition['dependentsInfo'],'spouse','placeOfLastEntryInUS')}}</span>
                </p>
            </div>
        </div>
        <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition['dependentsInfo'],'spouse','stateDetailsOfLastEntryInUS') && checkProperty(petition['dependentsInfo']['spouse'],'stateDetailsOfLastEntryInUS','name')  ">
            <div class="main-list">
                <p>
                  State of recent entry into the USA
                    <span>{{checkProperty(petition['dependentsInfo']['spouse'],'stateDetailsOfLastEntryInUS','name')}}</span>
                </p>
            </div>
        </div>
        <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty(petition['dependentsInfo'],'spouse','lastArrivalDate')">
          <div class="main-list">
            <p>
              Date of most recent entry into the USA
              <span>{{petition.dependentsInfo.spouse.lastArrivalDate | formatDate}}</span>
            </p>
          </div>
      </div> 
     
      <div class="vx-col md:w-1/3  w-full p-0" v-if="canRenderField('applyingWithYou', questionnaireDetails ,false,'dependentsInfo.spouse')" >
          <div class="main-list">
              <p>
                Applying with you
                <span>{{checkProperty(petition['dependentsInfo'],'spouse'  ,'applyingWithYou') | booleanFormat}}</span>
              </p>
          </div>
      </div>
        <div class="vx-col  md:w-1/3 w-full p-0" v-if="checkProperty(petition['dependentsInfo'],'spouse' ,'hasPermResidencyInOtherCountry') && checkProperty(petition['dependentsInfo'],'spouse' ,'permResidencyCountryDetails')  && checkProperty(petition['dependentsInfo']['spouse'] ,'permResidencyCountryDetails','name') " >
            <div class="main-list">
                <p>
                    Permanent Residency Country
                    <span>{{checkProperty(petition['dependentsInfo']['spouse'] ,'permResidencyCountryDetails','name')}}</span>
                </p>
            </div>
        </div>
        <template >
          <div class="vx-col  md:w-1/3 w-full p-0" v-if="canRenderField('enterInUSUnderCaseWaiverProgram',questionnaireDetails, false, 'dependentsInfo.spouse' )" >
              <div class="main-list">
                  <p>
                      Did you enter the U.S. under the Visa waiver program
                      <span>{{checkProperty(petition['dependentsInfo'],'spouse'  ,'enterInUSUnderCaseWaiverProgram') | booleanFormat}}</span>
                  </p>
              </div>
          </div>
          <div class="vx-col  md:w-1/3 w-full p-0" v-if="canRenderField('hasPermResidencyInOtherCountry',questionnaireDetails, false, 'dependentsInfo.spouse' )" >
              <div class="main-list">
                  <p>
                      Do you hold Permanent residence in any other country
                      <span>{{checkProperty(petition['dependentsInfo'],'spouse'  ,'hasPermResidencyInOtherCountry') | booleanFormat}}</span>
                  </p>
              </div>
          </div>
          
          <div class="vx-col  md:w-1/3 w-full p-0" v-if="canRenderField('have2AffidavitsOfBirthFamily',questionnaireDetails, false, 'dependentsInfo.spouse' )" >
              <div class="main-list">
                  <p>
                      Do you have Two (2) Affidavits of Birth from family members
                      <span>{{checkProperty(petition['dependentsInfo'],'spouse' ,'have2AffidavitsOfBirthFamily') | booleanFormat}}</span>
                  </p>
              </div>
          </div>
        
          <div class="vx-col  md:w-1/3 w-full p-0" v-if="canRenderField('haveYouArrestedBefore',questionnaireDetails, false, 'dependentsInfo.spouse' )" >
              <div class="main-list">
                  <p>
                      Have you ever been arrested,cited, charged or detained for any reason by an law enforcement official
                      <span>{{checkProperty(petition['dependentsInfo'],'spouse' ,'haveYouArrestedBefore') | booleanFormat}}</span>
                  </p>
              </div>
          </div>
          <template v-if="checkProperty(petition['dependentsInfo'],'spouse' ,'haveYouArrestedBeforeDocs') && checkProperty(petition['dependentsInfo']['spouse'] ,'haveYouArrestedBeforeDocs','length')>0 && checkProperty(petition['dependentsInfo'],'spouse' ,'haveYouArrestedBefore')">
              <vs-col class="padl0 padr0" v-if="checkProperty(petition['dependentsInfo']['spouse'] ,'haveYouArrestedBeforeDocs','length')>0" >
                  <documentsView @download_or_view="download_or_view" :type="'haveYouArrestedBeforeDocs'"  :documentsList="petition['dependentsInfo']['spouse']['haveYouArrestedBeforeDocs']" :petitionDetails="petition" />
              </vs-col>
          </template>
          <div class="vx-col  md:w-1/3 w-full p-0" v-if="canRenderField('haveYouEverReceivedPublicAssistendeInUS',questionnaireDetails, false, 'dependentsInfo.spouse' )" >
              <div class="main-list">
                  <p>
                      Have you ever received public assistence in the united states from any source, including the US government or any state,country,city or muncipality
                      <span>{{checkProperty(petition['dependentsInfo'],'spouse' ,'haveYouEverReceivedPublicAssistendeInUS') | booleanFormat}}</span>
                  </p>
              </div>
          </div>
          <div class="vx-col  md:w-1/3 w-full p-0" v-if="canRenderField('haveYouEverlikelyReceivePublicAssistendeInUS',questionnaireDetails, false, 'dependentsInfo.spouse' )" >
              <div class="main-list">
                  <p>
                      Have you ever likely to receive public assistence in the united states from any source, including the US government or any state,country,city or muncipality
                      <span>{{checkProperty(petition['dependentsInfo'],'spouse' ,'haveYouEverlikelyReceivePublicAssistendeInUS') | booleanFormat}}</span>
                  </p>
              </div>
          </div>
          <div class="vx-col  md:w-1/3 w-full p-0" v-if="canRenderField('haveYoueverPresntUnlawfully',questionnaireDetails, false, 'dependentsInfo.spouse' )" >
              <div class="main-list">
                  <p>
                      Have you ever been present in the united states unlawfully for more than 180 days
                      <span>{{checkProperty(petition['dependentsInfo'],'spouse' ,'haveYoueverPresntUnlawfully') | booleanFormat}}</span>
                  </p>
              </div>
          </div>
          <div class="vx-col  md:w-1/3 w-full p-0" v-if="checkProperty(petition['dependentsInfo'],'spouse' ,'presntUnlawfullyReason') && checkProperty(petition['dependentsInfo'],'spouse' ,'haveYoueverPresntUnlawfully') " >
              <div class="main-list">
                  <p>
                      Reason
                      <span>{{checkProperty(petition['dependentsInfo'],'spouse' ,'presntUnlawfullyReason')}}</span>
                  </p>
              </div>
          </div>
        </template>
    </template>
     
      
      <template  >
        <div class="vx-col  md:w-1/3 w-full p-0" v-if="canRenderField('everAppliedAOSInUS',questionnaireDetails, false, 'dependentsInfo.spouse' )" >
                <div class="main-list">
                    <p>
                     Have you ever applied AOS in the united states or an immigrant visa at the US Embassy/Consulate to obatain permanent resident status before
                        <span>{{checkProperty(petition['dependentsInfo'],'spouse'  ,'everAppliedAOSInUS') | booleanFormat}}</span>
                    </p>
                </div>
            </div>
            <template v-if="checkProperty(petition['dependentsInfo'],'spouse','appliedAOSInUSDocs') && checkProperty(petition['dependentsInfo']['spouse'],'appliedAOSInUSDocs','length')>0 && checkProperty(petition['dependentsInfo'],'spouse'  ,'everAppliedAOSInUS')">
                <vs-col class="padl0 padr0" v-if="checkProperty(petition['dependentsInfo']['spouse'],'appliedAOSInUSDocs','length')>0" >
                    <documentsView @download_or_view="download_or_view" :type="'appliedAOSInUSDocs'"  :documentsList="petition.dependentsInfo['spouse']['appliedAOSInUSDocs']" :petitionDetails="petition" />
                </vs-col>
            </template>
            <div class="vx-col  md:w-1/3 w-full p-0" v-if="canRenderField('birthCertHaveNamePobDob',questionnaireDetails, false, 'dependentsInfo.spouse' )" >
                <div class="main-list">
                    <p>
                        The birth certificate have your name, place of birth, date of birth, parents’ names mentioned, and the birth was registered around the time you were born
                        <span>{{checkProperty(petition['dependentsInfo'],'spouse'  ,'birthCertHaveNamePobDob') | booleanFormat}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col  md:w-1/3 w-full p-0" v-if="canRenderField('inspectedByAnyImmOfficer',questionnaireDetails, false, 'dependentsInfo.spouse' )" >
                <div class="main-list">
                    <p>
                        Were you inspected by an immigration officer
                        <span>{{checkProperty(petition['dependentsInfo'],'spouse'  ,'inspectedByAnyImmOfficer') | booleanFormat}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col  md:w-1/3 w-full p-0" v-if="canRenderField('isVisaDenieedTOUS',questionnaireDetails, false, 'dependentsInfo.spouse' )" >
                <div class="main-list">
                    <p>
                        Have you ever been denied a visa to the United States
                        <span>{{checkProperty(petition['dependentsInfo'],'spouse'  ,'isVisaDenieedTOUS') | booleanFormat}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col  md:w-1/3 w-full p-0" v-if="checkProperty(petition['dependentsInfo'],'spouse'  ,'visaDeniedReason')" >
                <div class="main-list">
                    <p>
                        Reason
                        <span>{{checkProperty(petition['dependentsInfo'],'spouse'  ,'visaDeniedReason') }}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col  md:w-1/3 w-full p-0" v-if="canRenderField('issuedAnyEADFromUSCIS',questionnaireDetails, false, 'dependentsInfo.spouse' )" >
                <div class="main-list">
                    <p>
                        Have you ever been issued an Employement Authorization Document(EAD) from the USCIS
                        <span>{{checkProperty(petition['dependentsInfo'],'spouse'  ,'issuedAnyEADFromUSCIS') | booleanFormat}}</span>
                    </p>
                </div>
            </div>
            <template v-if="checkProperty(petition['dependentsInfo']['spouse'],'documents','eadCard') && checkProperty(petition['dependentsInfo']['spouse']['documents'],'eadCard','length')>0 && checkProperty(petition['beneficiaryInfo']  ,'issuedAnyEADFromUSCIS')">
                <vs-col class="padl0 padr0" v-if="checkProperty(petition['dependentsInfo']['spouse']['documents'],'eadCard','length')>0" >
                    <documentsView @download_or_view="download_or_view" :type="'eadCard'"  :documentsList="petition.dependentsInfo.spouse.documents['eadCard']" :petitionDetails="petition" />
                </vs-col>
            </template>
            <div class="vx-col  md:w-1/3 w-full p-0" v-if="canRenderField('nameDiffFromBirthCert',questionnaireDetails, false, 'dependentsInfo.spouse' )" >
                <div class="main-list">
                    <p>
                        Your name is different from that stated on your birth certificate, have you had it legally changes
                        <span>{{checkProperty(petition['dependentsInfo'],'spouse'  ,'nameDiffFromBirthCert') | booleanFormat}}</span>
                    </p>
                </div>
            </div>
      </template>

    </div>
    <template v-if="checkProperty(petition['dependentsInfo'] ,'spouse' ,'hasOtherNames') && checkProperty(petition['dependentsInfo']['spouse'] ,'otherNames') && checkProperty(petition['dependentsInfo']['spouse'] ,'otherNames' ,'length') >0">
            <div class="vx-row m-0 main-list-panel">
                <h5 class="names_title">Used other names previously</h5>
                <template v-for="(item , ind)  in petition['dependentsInfo']['spouse']['otherNames']">
    
                    <div :key="ind" class="vx-col md:w-1/3 w-full p-0">
                        <div class="main-list">
                            <p>First Name<span v-if="item.firstName">{{item.firstName}}</span> 
                              <span v-else>N/A</span>
                            </p>
                        </div>
                    </div>
                    <div :key="ind" class="vx-col md:w-1/3 w-full p-0">
                        <div class="main-list">
                            <p> Middle Name <span v-if="item.middleName">{{item.middleName}}</span>
                              <span v-else>N/A</span>
                            </p>
                        </div>
                    </div>
    
                    <div :key="ind" class="vx-col md:w-1/3 w-full p-0">
                        <div class="main-list">
                            <p> Last Name <span v-if="item.lastName">{{item.lastName}}</span> 
                              <span v-else>N/A</span>
                            </p>
                        </div>
                    </div>
    
                </template>
    
            </div>
    
        </template>
    <template v-if="checkProperty(petition['dependentsInfo'] ,'spouse', 'associations') && checkProperty(petition['dependentsInfo']['spouse'], 'associations','length')>0 && checkProperty(petition['dependentsInfo']['spouse']['associations'][0],'name') " >
        <h5 class="names_title">Associations/Groups</h5>
        <template  v-for="(item , ind)  in petition['dependentsInfo']['spouse']['associations']">
            <div :key="ind" class="vx-row m-0 main-list-panel" v-if="checkProperty(petition['dependentsInfo'] ,'spouse', 'associations')">
                <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty( item,'name')">
                    <div class="main-list">
                        <p>
                            Name of the associations and groups
                            <span>{{checkProperty( item,'name')}}</span>
                        </p>
                    </div>
                </div>
                <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty( item,'natureofAssociations')">
                    <div class="main-list">
                        <p>
                            Nature of associations and groups
                            <span>{{checkProperty( item,'natureofAssociations')}}</span>
                        </p>
                    </div>
                </div>
                <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty( item,'startDate')">
                    <div class="main-list">
                        <p>
                            Start Date
                            <span>{{checkProperty( item,'startDate') | formatDate}}</span>
                        </p>
                    </div>
                </div>
                <div class="vx-col md:w-1/3 w-full p-0" v-if="checkProperty( item,'endDate')">
                    <div class="main-list">
                        <p>
                            End Date
                            <span>{{checkProperty( item,'endDate') | formatDate}}</span>
                        </p>
                    </div>
                </div>
            </div>
        </template>
    </template>
    <div class="vx-row m-0 main-list-panel" v-if="canRenderField('haveYouEverEmployed', questionnaireDetails ,false,'dependentsInfo.spouse') || canRenderField('anyOtherPersonEmployedInUS',questionnaireDetails, false, 'dependentsInfo.spouse' )">
            <div class="vx-col md:w-1/3 w-full p-0 " v-if="canRenderField('anyOtherPersonEmployedInUS',questionnaireDetails, false, 'dependentsInfo.spouse' )" >
                <div class="main-list">
                    <p>
                      Have you been employed in the United States since last admitted or granted an extension or change of status?
                        <span>{{checkProperty(petition['dependentsInfo'],'spouse','anyOtherPersonEmployedInUS') | booleanFormat}}</span>
                    </p>
                </div>
            </div>
            <div class="vx-col md:w-1/3 w-full p-0" v-if="canRenderField('haveYouEverEmployed',questionnaireDetails, false, 'dependentsInfo.spouse' )"  >
                <div class="main-list">
                    <p>
                      Have you ever been employed Outside US?
                        <span>{{checkProperty(petition['dependentsInfo'],'spouse','haveYouEverEmployed') | booleanFormat}}</span>
                    </p>
                </div>
            </div>
        </div>
        
    <div class="vx-row m-0 main-list-panel" v-if="petition.dependentsInfo.spouse.currentAddress && checkProperty(petition['dependentsInfo']['spouse'],'currentAddress','line1') " >
      <div
        class="vx-col md:w-full p-0"   >
        <div class="main-list">
          <p>
          Current Address


    <span v-html="$options.filters.addressformat(petition.dependentsInfo.spouse.currentAddress)"></span>

           
          </p>
        </div>
      </div>
     
    </div>
    <div class="vx-row m-0 main-list-panel" v-if="petition.dependentsInfo.spouse.physicalAddress && checkProperty(petition['dependentsInfo']['spouse'],'physicalAddress','line1') " >
      <div
        class="vx-col md:w-full p-0"   >
        <div class="main-list">
          <p>
          Mailing Address


    <span v-html="$options.filters.addressformat(petition.dependentsInfo.spouse.physicalAddress)"></span>

           
          </p>
        </div>
      </div>
     
    </div>
    <div class="vx-row m-0 main-list-panel" v-if="petition.dependentsInfo.spouse.addressOutsideUS && checkProperty(petition['dependentsInfo']['spouse'],'addressOutsideUS','line1')" >
      <div
        class="vx-col md:w-full p-0"   >
        <div class="main-list"> 
          <p>
            <template v-if="callFromPerm">Foreign Address</template>
            <template v-else>Address Outside the U.S</template>
          <span v-html="$options.filters.addressformat(petition.dependentsInfo.spouse.addressOutsideUS)"></span>
          </p>
        </div>
      </div>
     
    </div>
    
    <template v-if=" canRenderField('addressOfLastNYears', questionnaireDetails ,false,'dependentsInfo.spouse')&&
     checkProperty(petition['dependentsInfo'] ,'spouse' ,'addressOfLastNYears') &&  checkProperty(petition['dependentsInfo']['spouse']['addressOfLastNYears'],'length')>0 ">
        <div class="vx-row m-0 main-list-panel" v-if="checkProperty(petition['dependentsInfo'] ,'spouse' ,'addressOfLastNYears') && 
                    (
                        checkProperty(petition['dependentsInfo']['spouse']['addressOfLastNYears'][0] ,'line1' )

                    || checkProperty(petition['dependentsInfo']['spouse']['addressOfLastNYears'][0] ,'locationDetails' ,'name' )
                        || checkProperty(petition['dependentsInfo']['spouse']['addressOfLastNYears'][0] ,'stateDetails' ,'name' )
                        || checkProperty(petition['dependentsInfo']['spouse']['addressOfLastNYears'][0] ,'countryDetails' ,'name' )

                    )
                    ">

        <div class="vx-col w-full p-0">
        <div class="main-list p-0">
            <p>
                Residence starting with most current for the Past Five Years in the U.S and Abroad
                <template v-if="checkProperty(petition['dependentsInfo'],'spouse','addressOfLastNYears')">
                <div :key="ind" class="vx-row m-0 main-list-panel " >
                  <template v-for="(item , ind)  in petition['dependentsInfo']['spouse']['addressOfLastNYears']">
                        <div class="vx-col  w-full mt-3 map-pointer">
                            <span v-html="$options.filters.addressformat(item)"></span>
                        </div>
                        <div class="main-list md:w-1/3 p-0 mt-1" v-if="item.startDate && canRenderField('startDate', questionnaireDetails ,false,'dependentsInfo.spouse.addressOfLastNYears') ">
                           <p> Start Date<span>{{item.startDate | formatDate}}</span></p>
                        </div>
                        <div class="main-list md:w-1/3 p-0 mt-1" v-if="item.endDate && canRenderField('endDate', questionnaireDetails ,false,'dependentsInfo.spouse.addressOfLastNYears') ">
                            <p>End Date<span>{{item.endDate | formatDate}}</span></p>
                        </div>
                      </template>
                   </div>
            </template>
            </p>
        </div>
        
        </div>
       
        </div>
    </template>
    <template v-if=" canRenderField('addressOutsideUSMoreThanYear', questionnaireDetails ,false,'dependentsInfo.spouse')&&
    checkProperty(petition['dependentsInfo'] ,'spouse' ,'addressOutsideUSMoreThanYear' ) && checkProperty(petition['dependentsInfo']['spouse']['addressOutsideUSMoreThanYear'],'length' )>0 ">
    <div class="vx-row m-0 main-list-panel" v-if=" checkProperty(petition['dependentsInfo'] ,'spouse' ,'addressOutsideUSMoreThanYear' )  && 
                (
                    checkProperty(petition['dependentsInfo']['spouse']['addressOutsideUSMoreThanYear'][0] ,'line1' )

                   || checkProperty(petition['dependentsInfo']['spouse']['addressOutsideUSMoreThanYear'][0] ,'locationDetails' ,'name' )
                    || checkProperty(petition['dependentsInfo']['spouse']['addressOutsideUSMoreThanYear'][0] ,'stateDetails' ,'name' )
                     || checkProperty(petition['dependentsInfo']['spouse']['addressOutsideUSMoreThanYear'][0] ,'countryDetails' ,'name' )

                )
                 ">

    <div class="vx-col w-full p-0">
    <div class="main-list p-0">
        <p>

            Last Address outside Of the United States for more than one year
            <template v-if="checkProperty(petition['dependentsInfo'],'spouse','addressOutsideUSMoreThanYear')">
                <div :key="ind" class="vx-row m-0 main-list-panel " >
                  <template v-for="(item , ind)  in petition['dependentsInfo']['spouse']['addressOutsideUSMoreThanYear']">
                        <div class="vx-col  w-full p-0 mt-3">
                            <span v-html="$options.filters.addressformat(item)"></span>
                        </div>
                        <div class="main-list md:w-1/3 p-0 mt-1" v-if="item.startDate && canRenderField('startDate', questionnaireDetails ,false,'dependentsInfo.spouse.addressOutsideUSMoreThanYear') ">
                           <p> Start Date<span>{{item.startDate | formatDate}}</span></p>
                        </div>
                        <div class="main-list md:w-1/3 p-0 mt-1" v-if="item.endDate && canRenderField('endDate', questionnaireDetails ,false,'dependentsInfo.spouse.addressOutsideUSMoreThanYear') ">
                            <p>End Date<span>{{item.endDate | formatDate}}</span></p>
                        </div>
                      </template>
                   </div>
            </template>


        </p>
    </div>
    </div>
    

    </div>
    </template>
    
    <div class="vx-row m-0 main-list-panel" v-if="false && petition.dependentsInfo.spouse.priorPeriodOfStayInUS && petition.dependentsInfo.spouse.priorPeriodOfStayInUS.length > 0  && checkProperty(petition['dependentsInfo']['spouse']['priorPeriodOfStayInUS'][0],'visaStatus')!=null">
        <div class="vx-col w-full p-0">
            <div class="tabs-content-table mt-2 priorPeriodtable">
                <p>
                    All prior periods of stay in the U.S. over the last seven years</p>
                <template>
                   
                    <vs-table :data="petition.dependentsInfo.spouse.priorPeriodOfStayInUS"> 

                        <template>
                            <template slot="thead">
                                <vs-th>Case Status</vs-th>
                                <vs-th>Date Entered</vs-th>
                                <vs-th>Date Departed</vs-th>
                                <vs-th v-if="checkNoofDays">No. of Days</vs-th>
                            </template>
                            <template>
                                <vs-tr :key="sin" v-for="(stay ,sin) in petition.dependentsInfo.spouse.priorPeriodOfStayInUS">
                                    <vs-td> {{ stay.visaStatus  | formatML(visastatuses)}}</vs-td>
                                    <vs-td>{{stay.enteredDate | formatDate}}</vs-td>
                                    <vs-td>{{stay.departedDate | formatDate}}</vs-td>
                                     <!-- {{ visastatuses | visastatus(stay.visaStatus) }}-->
                                    
                                    <vs-td v-if="checkNoofDays">{{stay.noOfDays}}</vs-td>
                                </vs-tr>
                            </template>
                        </template>
                    </vs-table>

                    <template v-if="petition.dependentsInfo.spouse.noOfDaysStayInUS > 1095 && petition.dependentsInfo.spouse.confirmDaysStayInUS">

                        Total No. of days in the US in H/L status - {{noOfDaysStayInUS}}
                    </template>
                    <template v-if="noOfDaysStayInUS > 2185">

                        <label class="form_label pb-5 pt-5">Note: Please note that you are allowed a maximum period of 6 years on your H-1B. To receive H-1B approval past 6 years you need to either have an approved I-140 or PERM application pending for more than 364 days. Please confirm if you have the following:</label>

                        Approved I-140 (from any employer that has not been revoked within 180 days of its approval) {{hasApprovedI140?'Yes':'No'}}
                        PERM application pending for more than 365 days {{hasPermPendingForMorethan365Days?'Yes':'No'}}

                    </template>

                </template>
            </div>
        </div>
    </div>
    <template v-if="!callFromPerm">
      <Documents :loadedFromPreview="loadedFromPreview" :callFrom="'Spouse'" :petitionId="checkProperty(petition,'_id')"  v-bind:petition="petition.dependentsInfo.spouse" @download_or_view="downloadfile"   :allbtn="false" />
    </template>

  </div>
</template>

<script>
import Documents from "./Documents";
import documentsView from "@/views/common/documentsView.vue";
export default {
  data: ()=>({
    visastatuses:[],
  }),
    components:{
Documents,
documentsView
    },
  props: {
    callFromPerm:{
      type: Boolean,
      default: false
    },
    loadedFromPreview:false,
    petition: {
      type: Object,
      default: null
    },  
    questionnaireDetails:{
      type: Array,
       default: null
    },
    tplSection:{
        type:String,
        default:''
    },
    // visastatuses: {
    //   type: Array,
    //   default: null
    // }
  },
  computed: {
    formatCountriesName(){
      return (data)=>{
        let returnVal = ''
        if(this.checkProperty(data, 'length')>0){
          _.forEach(data, (itm)=>{
            if(_.has(itm, 'name') && itm['name']){
              if(returnVal != ''){
                returnVal = returnVal + ', '+ itm['name']
              }else{
                returnVal = itm['name']
              }
            }
          })
        }
        return returnVal;
      }
    },
        checkNoofDays(){
            let returnVal = true
            //petition.beneficiaryInfo.priorPeriodOfStayInUS
            if(this.checkProperty(this.petition['dependentsInfo']['spouse'],'priorPeriodOfStayInUS') && this.checkProperty(this.petition['dependentsInfo']['spouse'] ,'priorPeriodOfStayInUS', 'length')>0 ){
               let noOfDaysList =  _.filter(this.petition.dependentsInfo.spouse.priorPeriodOfStayInUS, (item)=>{
                    if(item && item['noOfDays']){
                       return item
                    }
                })
                if(noOfDaysList && this.checkProperty(noOfDaysList,'length')>0){
                    returnVal = true
                }else{
                    returnVal = false
                }
            }
            return returnVal
        },
      },
   mounted() {
   this.getVisastatues()

  },
  methods: {
    convertHeight(val){          
      if(val){
          let returnVal = null;
          let feet = ''
          let inches = ''
          if( _.has(val,'feet')){
              feet = val['feet']
          }
          if(_.has(val,'inches')){
              inches = val['inches']
          }
          if(feet){
              returnVal = feet+"'"+inches+"''"
          }
          return returnVal
      }
    },
    getVisastatues(){
      this.$store.dispatch("getmasterdata", "visa_status").then((response) => {
        this.visastatuses = response;
      });
    },
    download_or_view(value){
      this.$emit('download_or_view' ,value);
    },

    downloadfile(value) {
     
      this.$emit('download_or_view' ,value);
      // value.url = value.url.replace(this.$globalgonfig._S3URL,"");
      // value.url = value.url.replace(this.$globalgonfig._S3URLAWS,"");
      // let postdata = { keyName: value.url };
      // this.$store.dispatch("getSignedUrl", postdata).then((response) => {
      //   window.open(response.data.result.data, "_blank");
      // });
    },
  }
};
</script>