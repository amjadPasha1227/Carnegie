<template>
    <div class="case-actions" :class="{'hidden':!(getPetitionActionStatus && !isUpdatedUscisResponce && checkProperty(getPetitionDetails ,'status' )!=false)}">
     
      <div class="slider_navigation">
          <div class="swiper-button-prev tab_prev"><i class="vs-icon notranslate icon-scale material-icons null">keyboard_arrow_down</i></div>
          <div class="swiper-button-next tab_next"><i class="vs-icon notranslate icon-scale material-icons null">keyboard_arrow_down</i></div>
      </div>
   <swiper :allow-touch-move="false" :options="swiperOption"  >
    
    <swiper-slide   class="menu_item caseActions" ref="SUBMIT_TO_LAW_FIRM"  v-if="checkActionPermissions('SUBMIT_TO_LAW_FIRM')"  >
        <button :enableActionBtn="enableActionBtn()"    class="light-blue-btn" @click="submitTolawFirm('SUBMIT_TO_LAW_FIRM')" > Submit Case </button>
    </swiper-slide >

    <swiper-slide  ref="ASSIGN_SUPERVISOR" class="menu_item caseActions" v-if="checkActionPermissions('ASSIGN_SUPERVISOR')"   >
        <button :enableActionBtn="enableActionBtn()"    class="light-blue-btn" @click="getUsersList('ASSIGN_SUPERVISOR')" > {{getlableName('ASSIGN_SUPERVISOR' ,'actionLable')}}</button>
    </swiper-slide >

     <swiper-slide  ref="ASSIGN_PARALEGAL" class=" caseActions" v-if="checkActionPermissions('ASSIGN_PARALEGAL')"   >
        <button :enableActionBtn="enableActionBtn()"    class="light-blue-btn" @click="getUsersList('ASSIGN_PARALEGAL')" > {{getlableName('ASSIGN_PARALEGAL' ,'actionLable')}}</button>
    </swiper-slide >
     <swiper-slide  ref="ASSIGN_DOCUMENTATION_MANAGER" class=" caseActions" v-if="checkActionPermissions('ASSIGN_DOCUMENTATION_MANAGER')"  >
        <button :enableActionBtn="enableActionBtn()"    class="light-blue-btn"  @click="getUsersList('ASSIGN_DOCUMENTATION_MANAGER')"  > {{getlableName('ASSIGN_DOCUMENTATION_MANAGER' ,'actionLable')}}</button>
    </swiper-slide >
    <swiper-slide  ref="ASSIGN_DOCUMENTATION_EXECUTIVE" class=" caseActions" v-if="checkActionPermissions('ASSIGN_DOCUMENTATION_EXECUTIVE')"   >
        <button :enableActionBtn="enableActionBtn()"    class="light-blue-btn" @click="getUsersList('ASSIGN_DOCUMENTATION_EXECUTIVE')" >{{getlableName('ASSIGN_DOCUMENTATION_EXECUTIVE' ,'actionLable')}}</button>
    </swiper-slide >
    <swiper-slide  ref="ASSIGN_ATTORNEY" class=" caseActions" v-if="checkActionPermissions('ASSIGN_ATTORNEY')"   >
        <button :enableActionBtn="enableActionBtn()"    class="light-blue-btn"  @click="getUsersList('ASSIGN_ATTORNEY')" > {{getlableName('ASSIGN_ATTORNEY' ,'actionLable')}}
        
        </button>
    </swiper-slide >
    <!---- let processActivityList= [ "SUBMIT_TO_LAW_FIRM", "CASE_APPROVED",  "SUBMIT_TO_USCIS" ]; ASSIGN_DOCUMENTATION_MANAGER-->
     <swiper-slide   class=" caseActions" ref="CASE_APPROVED"  v-if="checkActionPermissions('CASE_APPROVED')"  >
        <button :enableActionBtn="enableActionBtn()"    class="light-blue-btn" @click="submitTolawFirm('CASE_APPROVED')" >    Approve Case</button>
    </swiper-slide >
     <swiper-slide   class=" caseActions" ref="SUBMIT_TO_USCIS"  v-if="checkActionPermissions('SUBMIT_TO_USCIS')" >
        <button :enableActionBtn="enableActionBtn()"    class="light-blue-btn"  @click="submitTolawFirm('SUBMIT_TO_USCIS')"  >   Submit to USCIS</button>
    </swiper-slide >

     <swiper-slide  class=" caseActions" v-if="checkAdminLoginroles && !isCaseApproved"  >
              <button class="light-blue-btn" @click="$emit('openchangeCaseTypePopup',true)" :enableActionBtn="enableActionBtn()" > Change Case Subtype </button>
      </swiper-slide>
       <swiper-slide class=" caseActions" v-if="!checkCaseCustomNumberAssigned && checkSubtoLawFirmActivityCompleted && checkAssignSupervisorPermessions"  >
                    <button class="light-blue-btn" :enableActionBtn="enableActionBtn()"   @click="$emit('openSetCaseCodePopup')" >Assign Case Number</button>
       </swiper-slide>

       

       <template v-if="!isCaseApproved">

       <swiper-slide class=" caseActions"   v-if="
      
                      ( checkProperty(getPetitionDetails, 'rfeCase') !=true) &&
                      (
                      
                      (
                        (
                          ( checkPetEditPermission ) 

                        || ([50].indexOf(getUserRoleId)>-1 && checkProperty( getPetitionDetails,'ptnrReassignRefUserId')) || ([51].indexOf(getUserRoleId)>-1 && checkProperty( getPetitionDetails,'benfReassignRefUserId')) 
                        
                        )
                      ) || [3,4,5,6,7,8,9,10,11,12,13,14].indexOf(getUserRoleId)>-1)">
                            <button @click="$emit('editQuestionnaire')"  :enableActionBtn="enableActionBtn()"  class="light-blue-btn" >Edit Questionnaire</button>
       </swiper-slide>

                  
                      
            <swiper-slide    v-if="[50].indexOf(getUserRoleId)>-1 &&  checkProperty(getPetitionDetails ,'ptnrReassignRefUserId')"  >
                  <button  @click="$emit('openSubmitLawForm')" :enableActionBtn="enableActionBtn()"  class="light-blue-btn" >Submit Case</button>
          </swiper-slide>

          <swiper-slide v-if="checkCaseCustomNumberAssigned && checkProperty(getPetitionDetails ,'questionnaireFilled')&&(([50].indexOf(getUserRoleId)>-1 && checkProperty(getPetitionDetails ,'ptnrReassignRefUserId') ) || [3,4,5,6,7,8,9,10,11,12,13,14].indexOf(getUserRoleId)>-1)" >
                  <button  @click="$emit('openReAssignToReviewerPopUp')"  :enableActionBtn="enableActionBtn()"  class="light-blue-btn" >
                  
                  Re-Assign <template v-if="[50].indexOf(getUserRoleId)>-1">to Beneficiary</template>
                  
                  </button>
          </swiper-slide>

                  
      </template>

      <swiper-slide v-if="[50,51].indexOf(getUserRoleId)<=-1&&checkSubtoLawFirmActivityCompleted && !checkSubmitUscisCompleted"    >
          <button  :enableActionBtn="enableActionBtn()" class="light-blue-btn"  @click="$emit('openSetDeadLinePopup')"  >Update Deadline</button>
      </swiper-slide>

        <swiper-slide v-if="[50,51].indexOf(getUserRoleId)<=-1 && !checkSubmitUscisCompleted"  >
          <button  @click="$emit('openProcessingModel')"  :enableActionBtn="enableActionBtn()"  class="light-blue-btn"  >
            <template v-if="checkProperty( getPetitionDetails, 'premiumProcessing')">Revert to Normal Processing</template>
            <template v-else>Upgrade to Premium Processing</template>
          </button>
        </swiper-slide>
        <swiper-slide   v-if=" (( checkProperty(getPetitionDetails, 'rfeCase') !=true) && (checkPetitionLcaRequired && getLcaDetails && checkLcaUpdate )) " >
          <button @click="$emit('openLcaUpdatePopup')"  :enableActionBtn="enableActionBtn()"  class="light-blue-btn" >Update LCA</button>
        </swiper-slide>


        <swiper-slide  v-if=" [50].indexOf(getUserRoleId)>-1 && checkrequestSigninActivityCompleted  && !checkSubmitUscisCompleted" >
          <button  :enableActionBtn="enableActionBtn()" @click="$emit('submitSignedDocuments')"  class="light-blue-btn" >Submit Signed Documents </button>
        </swiper-slide >

        <swiper-slide v-if="checkIsloginUserDocm && checkProperty(getPetitionDetails, 'docsUploadByDocExecutive') && checkDoceAssigned "   >
            <button @click="openApproveOrRejectDocs()" :enableActionBtn="enableActionBtn()"  class="light-blue-btn"  >Approve Documents</button> 
        </swiper-slide>

         <template v-if="checkIsloginUserDoce && checkDoceAssigned" >

          <swiper-slide     v-if="isEnableSendforReview && !checkProperty(getPetitionDetails, 'docsUploadByDocExecutive')"  >
              <buton  @click="$emit('approveOrRejectDocsAction','UPLOAD_BY_DOC_EXECUTIVE')"  :enableActionBtn="enableActionBtn()"  class="light-blue-btn"  >Send Documents For Review</buton>
          </swiper-slide >
          <swiper-slide v-else-if="!isEnableSendforReview && !checkrequestSigninActivityCompleted"    >
            <buton @click="$store.dispatch('setPetitionTab' , 'Forms and Letters')" :enableActionBtn="enableActionBtn()"   class="light-blue-btn"   >Upload Documents</buton>
          </swiper-slide>
        </template>

        <swiper-slide  v-if=" (!checkProperty(getPetitionDetails, 'petitionerSignRequested') && ( checkSendForSigning ) )" >
          <button class="light-blue-btn" @click="$emit('getFormsAndLetters',true)" :enableActionBtn="enableActionBtn()"   >Send for Signing</button>
        </swiper-slide>
          <swiper-slide  v-if="checkTrackingPermessions" >
          <!----SUBMIT_TO_USCIS--> 
              <button class="light-blue-btn"  @click="$emit('updateTrackingDetails')" :enableActionBtn="enableActionBtn()">{{caseFiledTxt}}</button>
          </swiper-slide>
        <swiper-slide    v-if="checkCourierTracking" >
            <button :enableActionBtn="enableActionBtn()" class="light-blue-btn" @click="$emit('updateTrackingDetails')">Update USCIS Receipt</button>
       </swiper-slide>
       <swiper-slide    v-if="checkUpdateUscisResponse"   >
          <!--- UPDATE_USCIS_RESPONSE---->
        <button :enableActionBtn="enableActionBtn()"   @click="$emit('updateUSCISstatus')" class="light-blue-btn"   >Update USCIS Status</button>
      </swiper-slide>  
  </swiper>
    


    <!-------Assignment Popup-->
     <vs-popup
     
        class="holamundo main-popup"
        :title="getlableName(checkProperty(nextWorkWorkFlowActivity ,'code') ,'popUpTitle')"
        :active.sync="showPopup"
      >
        <form @submit.prevent data-vv-scope="assignmentForm" class="relative">
   
   
          <div class="popup_info" v-if="usersList.length>0"  @click="formErrors=''" >
            <span><eye-icon size="1.5x" class="custom-class"></eye-icon></span>
            <div class="info_list">
              <ul v-if="usersList.length>0">
              <template v-for="(usr ,usrIndx) in usersList">
               <li :key="usrIndx">{{usr['roleName']}}</li>
              </template>
                
              </ul> 
            </div>
          </div>
          <div class="form-container">
            <div class="vx-row">
              <div class="vx-col w-full">
                <div class="form_group">
                  <label for class="form_label">Reviewer<em>*</em></label>
                  <div class="con-select w-full select-large">
                
                   <multiselect
                    name="users"
                    v-model="selectedUser"
                    :close-on-select="true"
                     v-validate="'required'"
                    :multiple="false"
                    :show-labels="false"
                    @input="selectUesr"
                    label="name"
                    data-vv-as="Reviewer"
                    placeholder="Select Reviewer"
                    :options="usersList"
                    :searchable="true"
                    :allow-empty="false"
                >
                 <template slot="selection" slot-scope="{ values, isOpen }">
                                                    <span
                                                    class="multiselect__selectcustom"
                                                    v-if="values.length && !isOpen"
                                                    >{{ values.length }} selected</span
                                                    >
                                                    <span
                                                    class="multiselect__selectcustom"
                                                    v-if="values.length && isOpen"
                                                    ></span>
                                                </template>
                </multiselect>
                </div>

                <span
                  class="text-danger text-sm"
                  v-show="errors.has('assignmentForm.users')"
                >{{ errors.first("assignmentForm.users") }}</span>
              </div>
              </div>
              
              <div class="vx-col w-full">
                <div class="form_group">
                <label class="form_label">Comments</label>
                <vs-textarea
                  data-vv-as="Comments"
                  v-validate="'required'"
                  v-model="comments"
                  name="comments" 
                  class="w-full"
                />

                <span
                  class="text-danger text-sm"
                  v-show="errors.has('assignmentForm.comments')"
                >{{ errors.first("assignmentForm.comments") }}</span>
              </div>
              </div>
            </div>

           
            <div class="text-danger text-sm formerrors" v-show="formErrors">
            
              <vs-alert
                color="warning"
                class="warning-alert reg-warning-alert no-border-radius"
                icon-pack="IntakePortal"
                icon="IP-information-button"
                active="true"
              >{{ formErrors }}</vs-alert>
              
            </div>
          </div>
         
          <div class="popup-footer relative">
           <span class="loader" v-if="loading" ><img src="@/assets/images/main/loader.gif"></span>
           <vs-button color="dark" @click="showPopup =false" class="cancel" type="filled">Cancel</vs-button>
            <vs-button
            :disabled="loading"
              color="success"
              @click="submitAssignmentAction()"
              class="save"
              type="filled"
            >Assign </vs-button>
          </div>
        </form>
      </vs-popup>
 

 <!-------Submit To Law firm Popup-->
      <vs-popup
     
        class="holamundo main-popup"
        :title="getlableName(checkProperty(nextWorkWorkFlowActivity ,'code') ,'actionLable')"
        :active.sync="submitTolawFirmPopup"
      >
      
        <form @submit.prevent data-vv-scope="submitTolawFirmform">
      
          <div class="form-container" >
            <div class="vx-row">
             
              <div class="vx-col w-full">
              <div class="form_group">
                <label class="form_label">Comments</label>
                <vs-textarea
                  data-vv-as="Comments"
                  v-validate="'required'"
                  v-model="comments"
                  name="comments"
               
                  class="w-full"
                />

                <span
                  class="text-danger text-sm"
                  v-show="errors.has('submitTolawFirmform.comments')"
                >{{ errors.first("submitTolawFirmform.comments") }}</span>
              </div>
              </div>
            </div>
            <div class="text-danger text-sm formerrors" v-show="formErrors">
              <vs-alert
                color="warning"
                class="warning-alert reg-warning-alert no-border-radius"
                icon-pack="IntakePortal"
                icon="IP-information-button"
                active="true"
              >{{ formErrors }}</vs-alert>
            </div>
          </div>
          <div class="popup-footer">
           <span class="loader" v-if="loading" ><img src="@/assets/images/main/loader.gif"></span>
           <vs-button color="dark" @click="submitTolawFirmPopup =false" class="cancel" type="filled">Cancel</vs-button>
            <vs-button
               :disabled="comments =='' || comments.trim() =='' || loading" 
              color="success"
              @click="submitToLawFirmAction()"
              class="save"
              type="filled"
            >Submit</vs-button>
          </div>
        </form>
             
      </vs-popup>
   


    </div>
    

    

</template>

<script>

import * as _ from "lodash";
import moment from 'moment'
import { EyeIcon } from 'vue-feather-icons'

import "swiper/dist/css/swiper.css"; 

import { swiper, swiperSlide } from "vue-awesome-swiper";

export default {
  components: {
    EyeIcon,
     swiper,
    swiperSlide
  },
  props: {
       scannedCopiesList:{
      type:Array,
      default:[]
    },
    isEnableSendforReview:{
      type:Boolean,
      default:true

    }
    
  },
  computed: {
   
   
   
  },
 
  data: () => ({
    swiperOption: {
    'allow-touch-move':"false",
	slidesPerView:"auto",
  allowTouchMove:"false",
	spaceBetween: 15,
	pagination: {
		el: '.swiper-pagination',
    clickable: true
	},
	navigation: {
		nextEl: '.tab_next',
		prevEl: '.tab_prev'
	},
},


     
     submitTolawFirmPopup:false,  
    scannedCopies:[],
    skipedActivityList:[],
    assignMentUsersList :{
      "ASSIGN_SUPERVISOR":"SUPERVISOR_LIST",
      "ASSIGN_PARALEGAL":"PARALEGAL_LIST",
      "ASSIGN_DOCUMENTATION_MANAGER":"DOCUMENTATION_MANAGER_LIST",
      "ASSIGN_DOCUMENTATION_EXECUTIVE":"DOCUMENTATION_EXECUTIVE_LIST",
      "ASSIGN_ATTORNEY":"ATTORNEY_LIST",
      },
      skipedActivity:false,
      usersList:[],
      formErrors: "",
      comments:'',
      showPopup:false,
      selectedUser:null,
      loading:false,
      nextWorkWorkFlowActivity:null,


    

    
    
  }),
  methods: {
     enableActionBtn(){
     
     // alert("enableActionBtn");
       this.updatePetiotionActionBtn(true);
       return true;
    },
      submitAssignmentAction(action=''){
          this.$validator.validateAll("assignmentForm").then((result) => {
            if (result) {
              let postData = {
                petitionId: this.getPetitionDetails['_id'],
                comment: this.comments,
                  "userId": this.checkProperty(this.selectedUser ,"_id"),
                  "userName": this.checkProperty(this.selectedUser ,"name"),
                  "roleId":  this.checkProperty(this.selectedUser ,"roleId"),
                  "assignRoleName":  this.checkProperty(this.selectedUser ,"roleName"),
                  subTypeName:this.checkProperty(this.getPetitionDetails,'subTypeDetails','name'),
                  typeName:this.checkProperty(this.getPetitionDetails,'typeDetails','name'),
                   "action":this.nextWorkWorkFlowActivity['code'], //"ASSIGN_SUPERVISOR", // "ASSIGN_PARALEGAL" / "ASSIGN_DOCUMENTATION_MANAGER" / "ASSIGN_DOCUMENTATION_EXECUTIVE" / "ASSIGN_ATTORNEY"
                 // "lastUserName": "Paralegal", // is Required when replacing a paralegal(action == "REPLACE_PARALEGAL"),
                //  "submitted": true // Required only when submitting to any roleSupervisor
                 isSkippedAction:false//this.skipedActivity?true:false

              };
              if(this.skipedActivityList.indexOf(this.nextWorkWorkFlowActivity['code'])>-1){
                postData['isSkippedAction'] =true;
              }
              

              if(action !=''){
                postData['action']  = 'ASSIGN_ATTORNEY';

              }

              
              //alert(JSON.stringify(postData))
               this.loading =true;
               this.$store
              .dispatch("commonAction", {"data":postData ,"path":"/petition/assign-a-role"})
              .then(response => {
                this.showPopup =false;
                this.openAtornyPopup =false;
                this.showToster({message:response.message,isError:false });
                this.skipedActivity =false;
               setTimeout(() =>{
                    let tab = this.getPetitionTab;
                    this.loading =false;
                    this.$emit("updatepetition" ,tab);
                 });

                
                
                
                                
              })
              .catch((error)=>{
                
                this.formErrors =error;
                this.loading =false;
              })
              
       
       

              
            }
          });
      

      },
    openAssignMentPopup(){

        this.formErrors = '';
    this.comments ='';
    if((this.checkPetitionLcaRequired  ) && !this.checkProperty(this.getPetitionDetails ,"lcaId") && this.getUserRoleId !=51){
    this.actiVateTabe('LCA');
    }else{

        this.formErrors ="";
        this.comments ='';
        this.showPopup =true;
        this.selectedUser =null;
        this.loading =false;


    if(this.usersList.length>0){
        this.formErrors ="";
        this.comments ='';
        this.showPopup =true;
        this.selectedUser =null;
        this.loading =false;

    }else{
        this.showToster({message:'Reviewers not found.',isError:true });
        
    }


    this.comments = "Case "+this.getPetitionDetails.typeDetails.name+", "+this.getPetitionDetails.subTypeDetails.name+"  is being assigned for further actions";


    }


    this.$validator.reset();




    },
      submitToLawFirmAction(){

          this.formErrors ='';
         let postData = {
             petitionId: this.getPetitionDetails['_id'],
            comment: this.comments,
            action:this.nextWorkWorkFlowActivity['code'], // "SUBMIT_TO_LAW_FIRM", // "CASE_APPROVED" / "LCA_CERTIFIED_FOR_PETITION" / "SUBMIT_TO_USCIS" / "USCIS_APPROVED" / "USCIS_RECEIVED_RFE" / "USCIS_DENIED" 
            today: moment().format('YYYY-MM-DD'), // Required on Status changes to "Received RFE"
             subTypeName:this.checkProperty(this.getPetitionDetails,'subTypeDetails','name'),
              typeName:this.checkProperty(this.getPetitionDetails,'typeDetails','name'),

         };
         
         this.$validator.validateAll("submitTolawFirmform").then((result) => {
            if (result) {
               this.loading =true;
               this.$store
              .dispatch("commonAction", {"data":postData ,"path":"/petition/manage-approval-process"})
              .then(response => {
                
                 this.showToster({message:response.message,isError:false });
                 this.submitTolawFirmPopup =false;
                 setTimeout(() =>{
                    let tab = this.getPetitionTab;
                    this.loading =false;
                    this.$emit("updatepetition" ,tab);
                 });
                
                
                                
              })
              .catch((error)=>{
                 this.loading =false;
                this.formErrors =error;
              })
       
       

              
            }
          });
           


      },
       getscannedCopiesList(){
              this.scannedCopies =[];
               let finalList =[];
             let postData ={petitionId:this.getPetitionDetails['_id'] ,'page':1 ,'perpage':100000};
            this.$store.dispatch("getList" ,{data:postData,path:"/petition/scanned-copies-list"})
            .then(response => {
               
            let lst = [];
           
            _.forEach(response.list ,(mainItem)=>{
                mainItem = Object.assign(mainItem,{"reverse_document_versions":[] ,"mainParentId":'',showMe:true ,selectedForDownload:false});
               if(mainItem.parentId){
                   mainItem['mainParentId'] = mainItem['parentId']
               }else{
                    mainItem['mainParentId'] = mainItem['_id']
               }

                lst.push(mainItem);
                 

            });

            let subList=[];
           
            //reverse_document_versions
            _.forEach(lst ,(mainItem)=>{

                                
               
               _.forEach(lst ,(subItem)=>{
                    if( mainItem.parentId && (mainItem.parentId == subItem['parentId'] ||  mainItem.parentId == subItem['_id']   ) &&  mainItem['_id'] != subItem['_id']){
                             
                             subItem['showMe'] =false;
                             if(subList.indexOf(subItem['_id']<=-1)){
                                  mainItem['reverse_document_versions'].push(subItem);
                                  subList.push(subItem['_id']);

                             }
                            
                            // mainItem['showMe'] =true;
                    }

                })
                
            if(mainItem.showMe){
                 finalList.push(mainItem);
            }
           
      
             
              

            })
           

            
            this.scannedCopies =  finalList;
            if(this.scannedCopies.length > 0){
              this.showPopup = false;
              this.submitTolawFirmPopup =true;

            }else{
               this.showPopup = false;
               this.submitTolawFirmPopup =false;
               this.showToster({message:"Scanned Documents are not uploaded" ,isError:true});

            }
            this.actiVateTabe('Scanned Documents');
            
           
            }).catch((err)=>{
               this.showPopup = false; 
                this.submitTolawFirmPopup =false;
                 this.scannedCopies =[];
                this.showToster({message:"Scanned Documents are not uploaded" ,isError:true});
                this.actiVateTabe('Scanned Documents');
            })

           
            

         },

      submitTolawFirm( activityCode=''){
            this.formErrors ='';
            this.comments ='';
            this.loading =false;
       //SUBMIT_TO_USCIS
       this.nextWorkWorkFlowActivity  = null;
        let config  = [];
        if(this.checkProperty(this.getWorkFlowDetails ,'config' ,'length')){
            config = this.getWorkFlowDetails['config'];
             this.nextWorkWorkFlowActivity = _.find(config ,{"code":activityCode })
        }

    
     let getLcaDetails = _.cloneDeep(this.getLcaDetails);
     


       if([50].indexOf(this.getUserRoleId)>-1){
            this.comments ="Case is being submitted to "+this.getPetitionDetails.tenantDetails.name+" for further actions."

        }else{

            this.comments ="Case "+this.getPetitionDetails.typeDetails.name+", "+this.getPetitionDetails.subTypeDetails.name+" is being assigned for further actions"

        }
    
     if(this.nextWorkWorkFlowActivity && this.nextWorkWorkFlowActivity.code=="CASE_APPROVED" ){

        
            if((this.checkPetitionLcaRequired ) ){

            if( !(this.checkProperty(this.getPetitionDetails ,"lcaId") ) ||  ( _.has(getLcaDetails ,"statusId") && [2,3].indexOf(getLcaDetails['statusId'])<=-1) ){
                  this.showToster({message:"LCA should be either Request/Submit/Link in order to submit the case." ,isError: true});


                  this.$store.dispatch("setPetitionTab" , 'LCA')
                  .then(()=>{
                    this.$emit("updatepetition" ,'LCA');
                  })
                  .catch(()=>{
                    this.$emit("updatepetition" ,'LCA');

                  })
                  return false;
              }else{
                this.submitTolawFirmPopup =true;
                 this.$validator.reset();
              }

          }else{
             this.submitTolawFirmPopup =true;
                 this.$validator.reset();
          }
          


     }else  if((this.checkProperty(this.getPetitionDetails , 'nextWorkflowActivity') == 'SUBMIT_TO_USCIS' ) ){
    
       this.getscannedCopiesList();
       
      
    }else if((this.checkPetitionLcaRequired ) && !this.checkProperty(this.getPetitionDetails ,"lcaId") && this.getUserRoleId !=51){
        this.showToster({ message:"LCA should be either Request/Submit/Link in order to submit the case." ,isError: true})
        this.actiVateTabe('LCA');
      }else{
         this.submitTolawFirmPopup =true;
         
      }
       this.$validator.reset();
      

      },
      selectUesr(item){
      this.selectedUser = item;
     
    },
   

      getUsersList(activityCode=''){
        this.findSkipedActivityList()
          this.nextWorkWorkFlowActivity =null;
          this.usersList =[];
          if(_.has(this.assignMentUsersList ,activityCode)){
             

            let usersListActivityCode =  this.assignMentUsersList[activityCode];
            let config  = [];
            if(this.checkProperty(this.getWorkFlowDetails ,'config' ,'length') >0 && usersListActivityCode){
                config = this.getWorkFlowDetails['config'];
                this.nextWorkWorkFlowActivity = _.find(config ,{'code':activityCode ,'actionRequired':'Yes' })
                
               
              let usersListActivity = _.find(config ,{ "code": usersListActivityCode });
               if(_.has(usersListActivity ,'editors')){
                   let postData ={
                        "matcher":{
                        
                            "roleIds": [],
                            "branchId":"",
                        
                        },
              
                        "page": 1,	
                        "perpage":100000000,
                        
                     };
                    let companyIdRoles =[50,51];
                   let branchIdRoles =[4, 5, 6, 7, 8, 9, 10, 11 ,12 ,13];
                    _.forEach(usersListActivity['editors'] ,(item)=>{
              
                        postData.matcher.roleIds.push(item.roleId);
                        if(companyIdRoles.indexOf(item.roleId)>-1 && this.checkProperty(this.getPetitionDetails ,'companyDetails' ,'_id')){
                            postData = Object.assign(postData ,{"companyId":this.checkProperty(this.getPetitionDetails ,'companyDetails' ,'_id') })
                        }

                        if(branchIdRoles.indexOf(item.roleId)>-1 && this.checkProperty(this.getPetitionDetails ,'branchId')){
                            postData['matcher']['branchId'] = this.checkProperty(this.getPetitionDetails ,'branchId');
                        }
                 
                   });
                   this.$store.dispatch("getList",{data:postData ,path:'/petition/assign-user-list'} ).then(response => {
                    //alert(JSON.stringify(response.list));
                    let lst = []
                    
                    _.forEach(response.list ,(item)=>{
                        if(_.has(item ,'name') && _.has(item ,'roleName') && ( item._id !=this.getUserData['userId'])){
                            item.name = item.name+" ("+item.roleName+")";
                            lst.push(item);
                        }
                    });
                   this.usersList = lst;
                 this.nextWorkWorkFlowActivity = _.find(config ,{'code':activityCode ,'actionRequired':'Yes' })
                    
                this.openAssignMentPopup();
            
           

                }); 


               }
            
            }
          }
      },


   checkActionPermissions(actionCode=''){
       let returnValue=false;
       let completedActivityList = [];
         
       if(this.checkProperty(this.getPetitionDetails ,'completedActivities' ,'length') >0){
            completedActivityList = this.getPetitionDetails['completedActivities'];
       }
         let config  = [];
        if(this.checkProperty(this.getWorkFlowDetails ,'config' ,'length') >0){
            config = this.getWorkFlowDetails['config'];
             
        }
        let isparallelActivity =false;
       
        switch (actionCode) {
            case 'SUBMIT_TO_LAW_FIRM':{
                returnValue=false;
                if( this.getWorkFlowDetails && this.checkProperty(this.getPetitionDetails ,'curWorkflowActivity') && this.checkProperty(this.getPetitionDetails , 'nextWorkflowActivity')=='SUBMIT_TO_LAW_FIRM'){

                       
                        let nextWorkWorkFlowActivity = _.find(this.getWorkFlowDetails.config ,{"code":this.getPetitionDetails.nextWorkflowActivity});
                                           
                        if((_.find(nextWorkWorkFlowActivity.editors , {"roleId":this.getUserRoleId}) || this.checkAdminLoginroles ) && (this.checkProperty(nextWorkWorkFlowActivity ,'actionRequired') =="Yes")){
                            returnValue =true;
                            
                            this.updatePetiotionActionBtn(true);
                                
                        }  


                }
                return returnValue;

            }
            case 'ASSIGN_SUPERVISOR':{
                returnValue=false;
                let activity =_.find(config ,{'code':'ASSIGN_SUPERVISOR' ,"actionRequired":'Yes'});
                let isImEditor  =false;
                if(_.has(activity ,'editors')){
                   isImEditor = _.find(activity['editors'] ,{'roleId':this.getUserRoleId})
                }
               
                if((completedActivityList.indexOf('ASSIGN_SUPERVISOR')<=-1  && activity &&this.checkSubtoLawFirmActivityCompleted && this.checkCaseCustomNumberAssigned)&& (isImEditor || this.checkAdminLoginroles)){
                    if(isparallelActivity){
                       returnValue=true;
                     }else{
                       if(this.checkProperty(this.getPetitionDetails , 'nextWorkflowActivity')=='ASSIGN_SUPERVISOR'){
                           returnValue=true;
                       }

                   }

                }
                return returnValue;
            }
            case 'ASSIGN_PARALEGAL':{
                returnValue=false;
                let activity =_.find(config ,{'code':'ASSIGN_PARALEGAL' ,"actionRequired":'Yes'});
                let isImEditor  =false;
                if(_.has(activity ,'editors') ){
                   isImEditor = _.find(activity['editors'] ,{'roleId':this.getUserRoleId})
                }
               
                if((completedActivityList.indexOf('ASSIGN_PARALEGAL')<=-1  && activity&&this.checkSubtoLawFirmActivityCompleted && this.checkCaseCustomNumberAssigned) && (isImEditor || this.checkAdminLoginroles)){
                    if(isparallelActivity){
                       returnValue=true;
                     }else{
                       if(this.checkProperty(this.getPetitionDetails , 'nextWorkflowActivity')=='ASSIGN_PARALEGAL'){
                           returnValue=true;
                       }

                   }

                }
                return returnValue;
            }    
            case 'ASSIGN_DOCUMENTATION_MANAGER':{
                returnValue=false;
                let activity =_.find(config ,{'code':'ASSIGN_DOCUMENTATION_MANAGER' ,"actionRequired":'Yes'});
                let isImEditor  =false;
                if(_.has(activity ,'editors') ){
                   isImEditor = _.find(activity['editors'] ,{'roleId':this.getUserRoleId})
                }
               
                if((completedActivityList.indexOf('ASSIGN_DOCUMENTATION_MANAGER')<=-1  && activity&&this.checkSubtoLawFirmActivityCompleted && this.checkCaseCustomNumberAssigned) && (isImEditor || this.checkAdminLoginroles)){
                   if(isparallelActivity){
                       returnValue=true;
                   }else{
                       //if(this.checkProperty(this.getPetitionDetails , 'nextWorkflowActivity')=='ASSIGN_DOCUMENTATION_MANAGER'){
                           returnValue=true;
                     //  }

                   }
                    

                }
                return returnValue;
            }
            case 'ASSIGN_DOCUMENTATION_EXECUTIVE':{
                returnValue=false;
                let activity =_.find(config ,{'code':'ASSIGN_DOCUMENTATION_EXECUTIVE' ,"actionRequired":'Yes'});
                let isImEditor  =false;
                if(_.has(activity ,'editors') ){
                   isImEditor = _.find(activity['editors'] ,{'roleId':this.getUserRoleId})
                }
              
                if(( completedActivityList.indexOf('ASSIGN_DOCUMENTATION_MANAGER')>-1 && completedActivityList.indexOf('ASSIGN_DOCUMENTATION_EXECUTIVE')<=-1  && activity &&this.checkSubtoLawFirmActivityCompleted &&this.checkCaseCustomNumberAssigned) && (isImEditor || this.checkAdminLoginroles)){
                     if(isparallelActivity){
                       returnValue=true;
                     }else{
                       // alert(this.checkProperty(this.getPetitionDetails , 'nextWorkflowActivity'))
                     //  if(this.checkProperty(this.getPetitionDetails , 'nextWorkflowActivity')=='ASSIGN_DOCUMENTATION_EXECUTIVE'){
                           returnValue=true;
                    //   }

                   }

                }
                return returnValue;
            }
            case 'ASSIGN_ATTORNEY':{
                returnValue=false;
                let activity =_.find(config ,{'code':'ASSIGN_DOCUMENTATION_EXECUTIVE' ,"actionRequired":'Yes'});
                let isImEditor  =false;
                if(_.has(activity ,'editors') ){
                   isImEditor = _.find(activity['editors'] ,{'roleId':this.getUserRoleId})
                }
               ////nextWorkflowActivity: "ASSIGN_DOCUMENTATION_MANAGER"


                if( ( completedActivityList.indexOf('ASSIGN_ATTORNEY')<=-1  && activity &&this.checkSubtoLawFirmActivityCompleted && this.checkCaseCustomNumberAssigned )&& (isImEditor || this.checkAdminLoginroles)){
                    if(isparallelActivity){
                       returnValue=true;
                     }else{
                       if((['ASSIGN_ATTORNEY' ,'ASSIGN_DOCUMENTATION_EXECUTIVE' ,'ASSIGN_DOCUMENTATION_MANAGER'].indexOf(this.checkProperty(this.getPetitionDetails , 'nextWorkflowActivity'))>-1)  ){
                           returnValue=true;
                       }

                   }

                }
                 return returnValue;
            }
            case 'CASE_APPROVED':{
                returnValue=false;
                if( this.getWorkFlowDetails && this.checkProperty(this.getPetitionDetails ,'curWorkflowActivity') && (this.checkProperty(this.getPetitionDetails , 'nextWorkflowActivity')=='CASE_APPROVED' || (this.checkProperty(this.getPetitionDetails , 'nextWorkflowActivity')=='ASSIGN_DOCUMENTATION_MANAGER') ) ){

                       
                        let nextWorkWorkFlowActivity = _.find(this.getWorkFlowDetails.config ,{"code":this.getPetitionDetails.nextWorkflowActivity});
                                           
                        if((_.find(nextWorkWorkFlowActivity.editors , {"roleId":this.getUserRoleId}) || this.checkAdminLoginroles ) && (this.checkProperty(nextWorkWorkFlowActivity ,'actionRequired') =="Yes")){
                            returnValue =true;
                            
                            this.updatePetiotionActionBtn(true);
                                
                        }  


                }
                return returnValue;

            }
            case 'SUBMIT_TO_USCIS':{
                returnValue=false;
                if( this.getWorkFlowDetails && this.checkProperty(this.getPetitionDetails ,'curWorkflowActivity') && this.checkProperty(this.getPetitionDetails , 'nextWorkflowActivity')=='SUBMIT_TO_USCIS'){

                       
                        let nextWorkWorkFlowActivity = _.find(this.getWorkFlowDetails.config ,{"code":this.getPetitionDetails.nextWorkflowActivity});
                                           
                        if((_.find(nextWorkWorkFlowActivity.editors , {"roleId":this.getUserRoleId}) || this.checkAdminLoginroles ) && (this.checkProperty(nextWorkWorkFlowActivity ,'actionRequired') =="Yes")){
                            returnValue =true;
                            
                            this.updatePetiotionActionBtn(true);
                                
                        }  


                }
                return returnValue;

            }
           
        
        }
        return returnValue;

   },
    
    
   // {{lableData}} 
    getlableName(activityObjCode ,msgType){

       let returnValue = '';
     if(activityObjCode){
      let labels = [
        {"code":"ASSIGN_SUPERVISOR" ,"label":"Assign Supervisor"},
        {"code":"ASSIGN_PARALEGAL" ,"label":"Assign Paralegal"},
        {"code":"ASSIGN_DOCUMENTATION_MANAGER" ,"label":"Assign Document Manager"},
        {"code":"ASSIGN_DOCUMENTATION_EXECUTIVE" ,"label":"Assign Document Executive"},
       {"code":"ASSIGN_ATTORNEY" ,"label":"Assign Attorney"},
      ];

      let assignLabel = _.find(labels , {"code":activityObjCode} );
     
      if(assignLabel && this.checkProperty(assignLabel ,'label' )){

        returnValue = assignLabel['label'];

      }  else if(this.checkProperty(this.lableData ,'length')>0 ){
        let msgObject = _.find(this.lableData , {"code":activityObjCode});
        if( msgObject && _.has(msgObject , msgType)){
            returnValue = msgObject[msgType];
        }

      }
    }

      return returnValue;

    },
    enableActionBtn(){
     // alert("enableActionBtn");
       this.loading =false;
       this.updatePetiotionActionBtn(true);
       return true;
    },
    
    findSkipedActivityList(){
      this.skipedActivityList =[];
      this.skipedActivity =false;
      let getWorkFlowDetails =  this.getWorkFlowDetails;
    if(this.getPetitionDetails && this.checkProperty(this.getPetitionDetails , 'nextWorkflowActivity') && _.has(getWorkFlowDetails ,"config")){
        
         let config  = getWorkFlowDetails['config'];
       let petitionCurrentActivityIndex = _.findIndex(config ,{"code": this.getPetitionDetails['nextWorkflowActivity'] });
       let completedActivityList = this.getPetitionDetails['completedActivities'];
       
       if(petitionCurrentActivityIndex>-1 && completedActivityList.length>0 && (completedActivityList.indexOf("SUBMIT_TO_USCIS")<=-1 )){
        _.forEach(config ,(activityItem ,index)=>{
          if(index<petitionCurrentActivityIndex){

            if(completedActivityList.indexOf(activityItem['code'])<=-1   && _.has(this.assignMentUsersList ,activityItem['code'])){
              //this.skipedActivityList.push(activityItem['code']);

              if(completedActivityList.indexOf("CASE_APPROVED") >-1){

                if([ 'ASSIGN_DOCUMENTATION_MANAGER','ASSIGN_DOCUMENTATION_EXECUTIVE'].indexOf(activityItem['code']) >-1){

                    this.skipedActivityList.push(activityItem['code']);

                }

              }else{
                 this.skipedActivityList.push(activityItem['code']);

              }
             
            }

          }


        })
       }
            
    }
    

    },
    actiVateTabe(tabName='LCA'){
     
       this.$store.dispatch("setPetitionTab" , tabName)
      .then(()=>{
        this.$emit("actiVateTabe",tabName);
      })
      .catch(()=>{
        this.$emit("actiVateTabe",tabName);

      })
          
      
    },
   
   

  },
  mounted() {

     
    this.findSkipedActivityList();
    this.updatePetiotionActionBtn(false);
    
  
   this.assignMentUsersList = {
      "ASSIGN_SUPERVISOR":"SUPERVISOR_LIST",
      "ASSIGN_PARALEGAL":"PARALEGAL_LIST",
      "ASSIGN_DOCUMENTATION_MANAGER":"DOCUMENTATION_MANAGER_LIST",
      "ASSIGN_DOCUMENTATION_EXECUTIVE":"DOCUMENTATION_EXECUTIVE_LIST",
      "ASSIGN_ATTORNEY":"ATTORNEY_LIST",
      };
  
    ///messages/list
     this.skipedActivityList =[];
     this.skipedActivity =false;
   
    this.$store.dispatch("getList" ,{data:{"category": "WORKFLOW"},path:"/messages/list"})
       .then(response => {
         //alert(JSON.stringify(response))
         this.lableData = response.messages.WORKFLOW;
         
         
       })
       .catch(error => {
          
         

       })
   
    

  },
 
};
</script>