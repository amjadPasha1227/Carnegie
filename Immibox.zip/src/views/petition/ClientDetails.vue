<template>
    <div class="main-list-wrap">
                    <div class="vx-row m-0 main-list-panel" >
                      <div class="vx-col md:w-1/2 w-full p-0">
                        <div class="main-list">
                          <p>
                            Name of the Client
                            <span>{{petition.clientInfo.name | empty}}</span>
                          </p>
                        </div>
                      </div>
                    </div>
                    <!-- <div class="vx-row m-0 main-list-panel">
                      <div class="vx-col md:w-1/2 w-full p-0" >
                        <div class="main-list">
                          <p>
                            Current Position
                            <span>{{petition.clientInfo.position | empty}}</span>
                          </p>
                        </div>
                      </div>
                      <div
                        class="vx-col md:w-1/2 w-full p-0"
                        v-if="petition.clientInfo.salaryOffered"
                      >
                        <div class="main-list" >
                          <p v-if="petition.clientInfo.salaryOffered" >
                            Salary Offered
                            <span>$ {{petition.clientInfo.salaryOffered }} {{petition.clientInfo.salaryFrequencyDetails?petition.clientInfo.salaryFrequencyDetails.name:" "}}</span>
                          </p>
                        </div>
                      </div>
                    </div> -->
                    <div class="vx-row m-0 main-list-panel">
                      <div class="vx-col md:w-1/2 w-full p-0">
                        <div class="main-list">
                          <p>
                            Client Address

                       <span v-html="$options.filters.addressformat(petition.clientInfo.address)"></span>

                          
                          </p>
                        </div>
                      </div>
                      <div class="vx-col md:w-1/2 w-full p-0"></div>
                    </div>
                  </div>
</template>
<script>
export default {
  props: {
    petition: {
      type: Object,
      default: null
    }
  },
  
   mounted() {
    

  }
};
</script>