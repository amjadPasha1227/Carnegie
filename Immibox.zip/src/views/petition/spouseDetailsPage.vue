<template>
     
    <div class="main-list-wrap petition_details_wrap">
    
           
    
        <template v-if="checkTabs">
           <div class="tab-inner-content tabs-nobg">
              <div class="tabs-content-panel tab-pad-wrap">
                    <div class="card-panels">
            <vs-tabs>
                <vs-tab label="Personal">
                    <SpouseDetails :callFromPerm="callFromPerm" :loadedFromPreview="loadedFromPreview" :tplSection="'dependentsInfo.spouse'" :questionnaireDetails="questionnaireDetails" :visastatuses="visastatuses" @download_or_view="download_or_view" :petition="petition"></SpouseDetails>
    
                </vs-tab>
                <!-- <vs-tab v-if="petition.dependentsInfo.spouse.educations && petition.dependentsInfo.spouse.educations.length > 0 && petition.dependentsInfo.spouse.educations[0].name!=null && petition.dependentsInfo.spouse.educations[0].name!=''" label="Education">
                    <educationInfo :visastatuses="visastatuses" :callFromDependent="true" :petition="petition"></educationInfo>
    
                </vs-tab> -->
                <vs-tab v-if="(checkProperty(petition['dependentsInfo'],'spouse') && checkProperty(petition['dependentsInfo'],'spouse','prevEmploymentInfo') && checkProperty(petition['dependentsInfo']['spouse'],'prevEmploymentInfo','length')>0 && checkProperty(petition['dependentsInfo']['spouse']['prevEmploymentInfo'][0],'employerName'))||
                    (checkProperty(petition['dependentsInfo'],'spouse') && checkProperty(petition['dependentsInfo'],'spouse','prevEmploymentOutsideUS') && checkProperty(petition['dependentsInfo']['spouse'],'prevEmploymentOutsideUS','length')>0 && checkProperty(petition['dependentsInfo']['spouse']['prevEmploymentOutsideUS'][0],'employerName'))" label="Employment">
                    <employementInfo :callPrevious="true" :tplSection="'dependentsInfo.spouse'" :questionnaireDetails="questionnaireDetails" :anyOtherPersonEmployedInUS="petition.dependentsInfo.spouse.anyOtherPersonEmployedInUS" :employmentList="petition.dependentsInfo.spouse.prevEmploymentInfo" :datatype="'SPOUSE_EMPLOYEMENT'" :visastatuses="visastatuses" :callFromDependent="true" :petition="petition"></employementInfo>
    
                </vs-tab>
                <vs-tab label="Previous Spouse" v-if="checkProperty(petition['dependentsInfo'],'spouse') && checkProperty(petition['dependentsInfo'],'spouse','previousSpouse') &&  checkProperty(petition['dependentsInfo']['spouse'],'previousSpouse','firstName')">
                    <previousSpouseDetails :visastatuses="visastatuses" :petition="petition['dependentsInfo']['spouse']['previousSpouse']"></previousSpouseDetails>
                </vs-tab>
                <vs-tab  v-if="checkProperty(petition['dependentsInfo'],'spouse','priorPeriodOfStayInUS') && checkProperty(petition['dependentsInfo']['spouse'],'priorPeriodOfStayInUS','length')>0 && checkProperty(petition['dependentsInfo']['spouse']['priorPeriodOfStayInUS'][0],'visaStatus')"  label="Dates of Stay in USA">
                    <periodofStayInUSA :callFrom="'SPOUSE'" :visastatuses="visastatuses" :petition="petition" :dataList="checkProperty(petition['dependentsInfo'],'spouse','priorPeriodOfStayInUS')" />
                </vs-tab>
                <vs-tab label="Father" v-if="checkProperty(petition['dependentsInfo'],'spouse') && checkProperty(petition['dependentsInfo'],'spouse','fatherInfo')  && checkProperty(petition['dependentsInfo']['spouse'],'fatherInfo','firstName') ">
                    <parentsDetails :visastatuses="visastatuses" :petition="petition['dependentsInfo']['spouse']['fatherInfo']"></parentsDetails>
                </vs-tab>
                <vs-tab label="Mother" v-if="checkProperty(petition['dependentsInfo'],'spouse') && checkProperty(petition['dependentsInfo'],'spouse','motherInfo')  && checkProperty(petition['dependentsInfo']['spouse'],'motherInfo','firstName') ">
                    <parentsDetails :visastatuses="visastatuses" :petition="petition['dependentsInfo']['spouse']['motherInfo']"></parentsDetails>
                </vs-tab>
            </vs-tabs>
            
            </div>
            </div>
            </div>
        </template>
        <template v-else>
          
            <div ><SpouseDetails :callFromPerm="callFromPerm" :loadedFromPreview="loadedFromPreview"  :visastatuses="visastatuses" :questionnaireDetails="questionnaireDetails" @download_or_view="download_or_view" :petition="petition"></SpouseDetails></div>
        </template>
    
    </div>
    </template>
    
    <script>
    import periodofStayInUSA from "@/views/petition/subtabs/periodofStayInUSA.vue";
    import parentsDetails  from "@/views/petition/subtabs/parentsDetails.vue"; 
    import SpouseDetails from "@/views/petition/SpouseDetails";
    import previousSpouseDetails  from "@/views/petition/subtabs/previousSpouseDetails.vue"; 
    import VuePerfectScrollbar from "vue-perfect-scrollbar";
    import personalInfo from "@/views/petition/subtabs/personalInfo.vue";
    //import personalInfo from "@/views/petition/subtabs/personalInfoVer2.vue";
    import employementInfo from "@/views/petition/subtabs/employement.vue";
    import nonImmigrantPetitionInformation from "@/views/petition/subtabs/nonImmigrant.vue"; 
    import ImmigrantPetitionInformation from "@/views/petition/subtabs/immigrantpetitions.vue"; 
    
    import educationInfo from "@/views/petition/subtabs/education.vue";
    
    export default {
        data: () => ({
    
            petitionhistory: [],
    
        }),
        computed: {
            checkTabs() {
              var petition = this.petition;
               
                if(this.checkProperty(petition['dependentsInfo'],'spouse') && this.checkProperty(petition['dependentsInfo'],'spouse','prevEmploymentInfo') && this.checkProperty(petition['dependentsInfo']['spouse'],'prevEmploymentInfo','length')>0 && this.checkProperty(petition['dependentsInfo']['spouse']['prevEmploymentInfo'][0],'employerName')){
                    return true
                }
                if(this.checkProperty(petition['dependentsInfo'],'spouse') && this.checkProperty(petition['dependentsInfo'],'spouse','motherInfo')  && this.checkProperty(petition['dependentsInfo']['spouse'],'motherInfo','firstName') ){
                    return true
                }
                if(this.checkProperty(petition['dependentsInfo'],'spouse') && this.checkProperty(petition['dependentsInfo'],'spouse','fatherInfo')  && this.checkProperty(petition['dependentsInfo']['spouse'],'fatherInfo','firstName') ){
                    return true
                }
                if(this.checkProperty(petition['dependentsInfo'],'spouse') && this.checkProperty(petition['dependentsInfo'],'spouse','previousSpouse')){
                    return true
                }
                if(this.checkProperty(petition['dependentsInfo'],'spouse') && this.checkProperty(petition['dependentsInfo'],'spouse','priorPeriodOfStayInUS') && this.checkProperty(petition['dependentsInfo']['spouse'],'priorPeriodOfStayInUS','length')>0 && this.checkProperty(petition['dependentsInfo']['spouse']['priorPeriodOfStayInUS'][0],'visaStatus')){
                    return true
                }
              return false
            }
    
        },
        props: {
            callFromPerm:{
                type: Boolean,
                default: false
            },
            loadedFromPreview:false,
            petition: {
                type: Object,
                default: null
            },
            visastatuses: {
                type: Array,
                default: null
            },
            questionnaireDetails:{
                type: Array,
                default: null
            }
        },
        components: {
            parentsDetails,
            SpouseDetails,
            previousSpouseDetails,
            nonImmigrantPetitionInformation,
            educationInfo,
            employementInfo,
            VuePerfectScrollbar,
            personalInfo,
            ImmigrantPetitionInformation,
            periodofStayInUSA
    
        },
        methods: {
            checPpriorPeriodOfStayInUS(data = []) {
                //enteredDate departedDate visaStatus
    
                if (data.length > 0) {
                    if (data.length == 1) {
    
                        if ((data[0].enteredDate != null && data[0].departedDate != null) || (data[0].visaStatus != '' && data[0].visaStatus != null)) {
    
                            return true;
                        } else {
                            return false;
                        }
    
                    } else {
                        return true;
    
                    }
    
                } else {
                    return false;
                }
    
            },
            gethistory() {
                if(this.checkProperty(this.petition ,'_id')){
                this.$store
                    .dispatch("petitionhistory", this.petition._id)
                    .then(response => {
                        this.petitionhistory = response.result.list;
                    });
                }
            },
            reloadPetition() {
                this.$store.dispatch("getpetition", this.petition._id).then(response => {
                    this.petition = response.data.result;
                    if (this.petition.lcaId != null) {
                        this.$store
                            .dispatch("fetchLcaDetails", this.petition.lcaId)
                            .then(response => {
                                this.lcaDetails = response.data.result;
                            });
                    }
                    let postDt = {
                        userId: '',
                        isRfeCase: false
                    }
                    if (_.has(this.petition, "rfeCase")) {
                        postDt['isRfeCase'] = this.petition['rfeCase']
                    }
                    postDt['userId'] = this.petition['userId'];
    
                    this.$store
                        .dispatch("getpetitionsdropdown", postDt)
                        .then(response => {
                            this.petitions = response;
                        });
                });
                this.$store.dispatch("petitionhistory", petitionId).then(response => {
                    this.petitionhistory = response.result.list;
                });
            },
            download_or_view(value){
                this.$emit('download_or_view' ,value);
            },
        },
        mounted() {
            this.gethistory();
        }
    };
    </script>
    