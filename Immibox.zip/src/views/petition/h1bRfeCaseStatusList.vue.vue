<template>
    <div>
        
   
      <li class="completed">
        <em></em>
        <div class="status_list_cnt">
          <div class="status_title">
            <label>Case Created</label>
            <template>
            <div class="info">
              <img src="@/assets/images/main/information.svg" />
              <div class="info_cnt">
                <p>Pending with #pk</p>
              </div>
            </div>
          </template>
          </div>
          <span v-if="checkProperty( petition, 'createdOn')">{{ petition['createdOn'] | formatDateTime }}</span>
        </div>
      </li>
      
    </ul>
    </div>
</template>
<script>

import moment from "moment";
import * as _ from "lodash";
export default {
    data: ()=>({
       
    }),
    methods:{
        
        getActionComplatedDate(code = "") {
      let returnValue = "";
      if (code) {
        let item = _.find(this.currentCaseDetails, (log)=>{
          return this.checkProperty(log, "action") ==code && this.checkProperty(log, "endedOn")
          });
        if (item && this.checkProperty(item, "endedOn")) {
          returnValue = item["endedOn"];
        }
      }
      return returnValue;
    }, 
    },
    props: {
    workFlowDetails: {
      type: Object,
      default: null,
    },
    petition: {
      type: Object,
      default: null,
    },
    currentCaseDetails: {
      type: Array,
      default: [],
    },
    scannedDocumentsList: {
      type: Array,
      default: [],
    },
  },
    computed:{
        isActivyCompleted() {
      var _self = this;
      return (item = "") => {
        switch (item) {
          case "Questionnaire Submitted":
            var _ca = [
              "SUBMIT_TO_LAW_FIRM" ,"SUBMIT_BY_BENEFICIARY"
            ];
            return _.has(_self.petition,'completedActivities')&& _self.petition["completedActivities"] && _self.petition["completedActivities"].some(
              (r) => _ca.indexOf(r) >= 0
            );
            break;
          case "In Process":
            var _ca = [
              "CASE_APPROVED",
              "COURIER_TRACKING",
              "UPDATE_USCIS_RECEIPT_NUMBER",
              "UPDATE_USCIS_RESPONSE",
              "SUBMIT_TO_USCIS",
              "COURIER_TRACKING",
              "UPDATE_USCIS_RECEIPT_NUMBER",
              "UPDATE_USCIS_RESPONSE",
              "USCIS_APPROVED",
              "USCIS_RECEIVED_RFE",
              "USCIS_DENIED",
              "USCIS_WITHDRAWN",
              
             // "REQUEST_PETITIONER_SIGN",
            //  "REQUEST_BENEFICIARY_SIGN",
            //  "UPLOAD_SCANNED_COPY",
           //   "UPLOAD_BENEFICIARY_SCANNED_COPY"
              
            ];
              if(_self.getUserRoleId ==51){ 
              _ca.push('REQUEST_BENEFICIARY_SIGN');
              _ca.push('UPLOAD_BENEFICIARY_SCANNED_COPY');
            }else{
              _ca.push('REQUEST_PETITIONER_SIGN');
              _ca.push('UPLOAD_SCANNED_COPY');
            }

            let nextWorkflowList =[];
            var isAssignmentsExists =false;
            if(this.workFlowDetails && _.has(this.workFlowDetails ,'config' )){
          let assignSuperVisorActiVity = _.find(this.workFlowDetails.config , {"code":'ASSIGN_SUPERVISOR' ,"include":'Yes'});
          let paralegalactiVity = _.find(this.workFlowDetails.config , {"code":'ASSIGN_PARALEGAL',"include":'Yes'});
          let attorneyactiVity = _.find(this.workFlowDetails.config , {"code":'ASSIGN_ATTORNEY',"include":'Yes'});
          let docm = _.find(this.workFlowDetails.config , {"code":'ASSIGN_DOCUMENTATION_MANAGER',"include":'Yes'});
          let doce = _.find(this.workFlowDetails.config , {"code":'ASSIGN_DOCUMENTATION_EXECUTIVE',"include":'Yes'});
          let caseApproved = _.find(this.workFlowDetails.config , {"code":'CASE_APPROVED',"include":'Yes'});
          let assignCaseApprover = _.find(this.workFlowDetails.config , {"code":'ASSIGN_CASE_APPROVER',"include":'Yes'});
          
            if( assignSuperVisorActiVity  || paralegalactiVity || attorneyactiVity || docm  || doce || caseApproved || assignCaseApprover){
              isAssignmentsExists =true;
            
              nextWorkflowList =[];
            
            }else{
              nextWorkflowList =['REQUEST_PETITIONER_SIGN' ,'REQUEST_BENEFICIARY_SIGN']

            }
          
                    

            }

            return (_.has(_self.petition,'completedActivities')&& _self.petition["completedActivities"] && _self.petition["completedActivities"].some(
              (r) => _ca.indexOf(r) >= 0) ) 
              || ( isAssignmentsExists ==false && _self.petition["nextWorkflowActivity"].some((r) => nextWorkflowList.indexOf(r) >= 0) )  ;
          case "Petitioner Signature":
            var _ca = [
              "COURIER_TRACKING",
              "SUBMIT_TO_USCIS",
              "UPDATE_USCIS_RECEIPT_NUMBER",
              "UPDATE_USCIS_RESPONSE",
              "USCIS_APPROVED",
              "USCIS_RECEIVED_RFE",
              "USCIS_DENIED",
              "USCIS_WITHDRAWN",
              "GENERATED_SIGNED_DOCS",
              
            //  "REQUEST_PETITIONER_SIGN",
          //    "REQUEST_BENEFICIARY_SIGN",
          //    "UPLOAD_SCANNED_COPY",
         //     "UPLOAD_BENEFICIARY_SCANNED_COPY"
            ];
            
           //   _ca.push('REQUEST_BENEFICIARY_SIGN');
         //     _ca.push('UPLOAD_BENEFICIARY_SCANNED_COPY');
            
             // _ca.push('UPLOAD_SCANNED_COPY');
             
             if([2,10].indexOf(this.checkProperty(this.petition, 'type' ))>-1 && !this.checkProperty(this.petition,'petitionerId') ){

              _ca.push('REQUEST_BENEFICIARY_SIGN');
              if(_self.petition['completedActivities'].indexOf('REQUEST_BENEFICIARY_SIGN') >-1){
                _ca.push('UPLOAD_BENEFICIARY_SCANNED_COPY');
             }

             }else{
              _ca.push('REQUEST_PETITIONER_SIGN');
              if(_self.petition['completedActivities'].indexOf('REQUEST_PETITIONER_SIGN') >-1){
                _ca.push('UPLOAD_SCANNED_COPY');
             }
              

             }
             
           
            return (
              _.has(_self.petition ,"completedActivities") && _self.petition["completedActivities"] && _self.petition["completedActivities"].some(
                (r) => _ca.indexOf(r) >= 0
              ) 
            );
          case "Received Signed Forms":
            var _ca = [
              "COURIER_TRACKING",
              "SUBMIT_TO_USCIS",
              "UPDATE_USCIS_RECEIPT_NUMBER",
              "UPDATE_USCIS_RESPONSE",
              "USCIS_APPROVED",
              "USCIS_RECEIVED_RFE",
              "USCIS_DENIED",
              "USCIS_WITHDRAWN",
              //"UPLOAD_SCANNED_COPY",
             // "UPLOAD_BENEFICIARY_SCANNED_COPY"
            ];
            if([2,10].indexOf(this.checkProperty(this.petition, 'type' ))>-1 && !this.checkProperty(this.petition,'petitionerId') ){
              if(_self.petition['completedActivities'].indexOf('REQUEST_BENEFICIARY_SIGN') >-1){
                _ca.push('UPLOAD_BENEFICIARY_SCANNED_COPY');
             }
            }
            if(_self.getUserRoleId ==51){ 
             // _ca.push('REQUEST_BENEFICIARY_SIGN');
             if(_self.petition['completedActivities'].indexOf('REQUEST_BENEFICIARY_SIGN') >-1){
                _ca.push('UPLOAD_BENEFICIARY_SCANNED_COPY');
             }
              
            }else{
           //   _ca.push('REQUEST_PETITIONER_SIGN');
             // _ca.push('UPLOAD_BENEFICIARY_SCANNED_COPY');
             if(_self.petition['completedActivities'].indexOf('REQUEST_PETITIONER_SIGN') >-1){
                _ca.push('UPLOAD_SCANNED_COPY');
             }

             // _ca.push('UPLOAD_SCANNED_COPY');
            }
            return (
              _.has(_self.petition ,"completedActivities") && _self.petition["completedActivities"] && _self.petition["completedActivities"].some(
                (r) => _ca.indexOf(r) >= 0
              ) 
              //|| (_self.scannedDocumentsList && _self.scannedDocumentsList.length > 0)
            );
          case "Submitted to USCIS":
            var _ca = [
              "SUBMIT_TO_USCIS",
              "COURIER_TRACKING",
              "UPDATE_USCIS_RECEIPT_NUMBER",
              "UPDATE_USCIS_RESPONSE",
              "USCIS_APPROVED",
              "USCIS_RECEIVED_RFE",
              "USCIS_DENIED",
              "USCIS_WITHDRAWN",
              //"UPLOAD_SCANNED_COPY"
            ];
            return _.has(_self.petition ,"completedActivities") && _self.petition["completedActivities"] && _self.petition["completedActivities"].some(
              (r) => _ca.indexOf(r) >= 0
            );
          case "Receipt Received":
            var _ca = [
              "UPDATE_USCIS_RECEIPT_NUMBER",
              "USCIS_APPROVED",
              "USCIS_RECEIVED_RFE",
              "USCIS_DENIED",
              "USCIS_WITHDRAWN",
            ];
            return _.has(_self.petition ,"completedActivities") && _self.petition["completedActivities"] && _self.petition["completedActivities"].some(
              (r) => _ca.indexOf(r) >= 0
            );
          case "USCIS Response":
            var _ca = [
              "USCIS_APPROVED",
              "USCIS_RECEIVED_RFE",
              "USCIS_DENIED",
              "USCIS_WITHDRAWN",
            ];
            return _.has(_self.petition ,"completedActivities") && _self.petition["completedActivities"] &&  _self.petition["completedActivities"].some(
              (r) => _ca.indexOf(r) >= 0
            );
          default:
            return false;
        }

        return false;
      };
    },
        isActivyActive() {
      var _self = this;
      return (item = "") => {
        switch (item) {
          case "Questionnaire Submitted":
            var _ca = ["SUBMIT_TO_LAW_FIRM" ,"SUBMIT_BY_BENEFICIARY"];
            return  _.has(_self.petition ,"completedActivities") && _self.petition["completedActivities"].indexOf("SUBMIT_TO_LAW_FIRM") <= -1 && _self.petition["nextWorkflowActivity"] && _self.petition["nextWorkflowActivity"].some((r) => _ca.indexOf(r) >= 0);
            break;
          case "In Process":
            var _ca = [
             // "ASSIGN_SUPERVISOR",
            //   "ASSIGN_PARALEGAL",
            //  "ASSIGN_DOCUMENTATION_MANAGER",
            //  "ASSIGN_DOCUMENTATION_EXECUTIVE",
            //  "ASSIGN_ATTORNEY",
            //  "ASSIGN_CASE_APPROVER",
            //  "CASE_APPROVED",
              "REQUEST_PETITIONER_SIGN"
            ];
            if([2,10].indexOf(this.checkProperty(this.petition, 'type' ))>-1 && !this.checkProperty(this.petition,'petitionerId') ){
              var _ca = [];
              _ca.push('REQUEST_BENEFICIARY_SIGN');
             //_ca.push('UPLOAD_BENEFICIARY_SCANNED_COPY');
            }

            var isAssignmentsExists =false;
            if(this.workFlowDetails && _.has(this.workFlowDetails ,'config' )){
          let assignSuperVisorActiVity = _.find(this.workFlowDetails.config , {"code":'ASSIGN_SUPERVISOR' ,"include":'Yes'});
          let paralegalactiVity = _.find(this.workFlowDetails.config , {"code":'ASSIGN_PARALEGAL',"include":'Yes'});
          let attorneyactiVity = _.find(this.workFlowDetails.config , {"code":'ASSIGN_ATTORNEY',"include":'Yes'});
          let docm = _.find(this.workFlowDetails.config , {"code":'ASSIGN_DOCUMENTATION_MANAGER',"include":'Yes'});
          let doce = _.find(this.workFlowDetails.config , {"code":'ASSIGN_DOCUMENTATION_EXECUTIVE',"include":'Yes'});
          let assignCaseApprover = _.find(this.workFlowDetails.config , {"code":'ASSIGN_CASE_APPROVER',"include":'Yes'});
          let caseApproved = _.find(this.workFlowDetails.config , {"code":'CASE_APPROVED',"include":'Yes'});
          
          if(assignSuperVisorActiVity ){
            isAssignmentsExists =true;
            _ca.push('ASSIGN_SUPERVISOR');
          }
          if(paralegalactiVity  ){
            isAssignmentsExists =true;
            _ca.push('ASSIGN_PARALEGAL');
          }
          if(attorneyactiVity   ){
            isAssignmentsExists =true;
            _ca.push('ASSIGN_ATTORNEY');
          }

          if(docm  ){
            isAssignmentsExists =true;
            _ca.push('ASSIGN_DOCUMENTATION_MANAGER');
          }
          if(doce  ){
            isAssignmentsExists =true;
            _ca.push('ASSIGN_DOCUMENTATION_EXECUTIVE');
          }
          if(caseApproved){
            isAssignmentsExists =true;
            _ca.push('CASE_APPROVED');
          }
          if(assignCaseApprover){
            _ca.push('ASSIGN_CASE_APPROVER');
          }


          

            }
          return  _.has(_self.petition ,"completedActivities") && _self.petition["completedActivities"].indexOf("SUBMIT_TO_LAW_FIRM") > -1 && _self.petition["nextWorkflowActivity"] && _self.petition["nextWorkflowActivity"].some((r) => _ca.indexOf(r) >= 0 && isAssignmentsExists);
          case "Petitioner Signature":
            var _ca = [];
            if(_self.getUserRoleId ==51){ 
              _ca.push('REQUEST_BENEFICIARY_SIGN');
             // _ca.push('UPLOAD_BENEFICIARY_SCANNED_COPY');
            }else{
              _ca.push('REQUEST_PETITIONER_SIGN');
             // _ca.push('UPLOAD_SCANNED_COPY');
            }

            if([2,10].indexOf(this.checkProperty(this.petition, 'type' ))>-1 && !this.checkProperty(this.petition,'petitionerId') ){
              var _ca = [];
              _ca.push('REQUEST_BENEFICIARY_SIGN');
             //_ca.push('UPLOAD_BENEFICIARY_SCANNED_COPY');
            }
            return _self.petition["nextWorkflowActivity"] && _self.petition["nextWorkflowActivity"].some(
                (r) => _ca.indexOf(r) >= 0
              );
          case "Received Signed Forms":
            var _ca = [];
            let activityCode ="REQUEST_PETITIONER_SIGN";

            if([2,10].indexOf(this.checkProperty(this.petition, 'type' ))>-1 && !this.checkProperty(this.petition,'petitionerId') ){
              activityCode ="REQUEST_BENEFICIARY_SIGN";
            }
            
            //return _self.petition["nextWorkflowActivity"] && _self.petition["nextWorkflowActivity"].some( (r) => _ca.indexOf(r) >= 0);
            return _self.petition["completedActivities"].indexOf(activityCode)>-1 && (_self.petition["completedActivities"].indexOf('UPLOAD_SCANNED_COPY') <=-1)
          case "Submitted to USCIS":
           
            var _ca = ['COURIER_TRACKING' ,'SUBMIT_TO_USCIS'];
            let checkUploads =false;
            if( _self.petition["completedActivities"].indexOf('UPLOAD_SCANNED_COPY')>-1){
              checkUploads =true;
            }else if([2,10].indexOf(_self.petition["type"])>-1 && _self.petition["completedActivities"].indexOf('UPLOAD_BENEFICIARY_SCANNED_COPY')>-1 ){
              checkUploads =true;
            }
           
            
           return (_self.petition["nextWorkflowActivity"] && _self.petition["nextWorkflowActivity"].some((r) => _ca.indexOf(r) >= 0 ) && checkUploads && _self.petition["completedActivities"].indexOf('SUBMIT_TO_USCIS')<=-1 
               // || (_self.petition["nextWorkflowActivity"].indexOf('REQUEST_PETITIONER_SIGN')>-1 && _self.petition["completedActivities"].indexOf('REQUEST_BENEFICIARY_SIGN') >-1 )|| ( _self.petition["nextWorkflowActivity"].indexOf('REQUEST_BENEFICIARY_SIGN')>-1 && _self.petition["completedActivities"].indexOf('REQUEST_PETITIONER_SIGN') >-1  )
             // || this.scannedDocumentsList && this.scannedDocumentsList.length > 0
          ) 
            
          case "Receipt Received":
            var _ca = ["UPDATE_USCIS_RECEIPT_NUMBER" ,'COURIER_TRACKING'];
            return (_self.petition["nextWorkflowActivity"] && _self.petition["nextWorkflowActivity"].some((r) => _ca.indexOf(r) >= 0 )) 
          case "USCIS Response":
            var _ca = ["UPDATE_USCIS_RECEIPT_NUMBER"];
            return _ca.indexOf(_self.petition["currentActivity"]) >= 0;
          default:
            return false;
        }

        return false;
      };
    },

    findUsers() {
      let self = this;
      let returnVal = "";
      let allUsers = [];
      let selectedUsers = [];
      let filterItems = _.filter(this.currentCaseDetails, (item) => {
        return (
          !_.has(item, "endedOn") || item.endedOn == null || item.endedOn == ""
        );
      });
      if (self.checkProperty(filterItems, "length") > 0) {
        _.forEach(filterItems, (obj) => {
          if (self.checkProperty(obj, "users", "length") > 0) {
            let users = obj["users"];
            _.forEach(users, (user, ind) => {
              let userName = user["name"] + " (" + user["roleName"] + ")";
              if (selectedUsers.indexOf(user["_id"]) <= -1) {
                allUsers.push(_.cloneDeep(userName));
              }
              selectedUsers.push(user["_id"]);
            });
          }
        });
      }
      if (allUsers.length > 0) {
        returnVal = allUsers.join(", ");
      }
      return returnVal;
    },
        checkActivityCompleted(){
      return (code='')=>{
       
        if( _.has(this.petition ,"completedActivities") && this.petition['completedActivities'].indexOf(code) >-1){
          return true;
        }else{
          return false;
        }
        

      }
    },
    },
    mounted(){
     
    },
    components:{
     
    }
}
</script>