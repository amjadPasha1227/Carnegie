<template>
   
  <div
    class="main-tabs-content tabs_mob petetion__details_page"
    :class="{
      petetion__details_full_width: !loadedFromPreview,
      anonymouslogin: !checkCurrentUrl,
    }"
  >
    <div class="tabs-layout-header" v-if="!loadedFromPreview">
      <div class="case-no-panel">
        <!-- <vs-dropdown>
          <a class="flex items-center">
            <div class="drop-down-content">
              Case No
              <span>{{ checkProperty(petition, "caseNo") }}</span>
            </div>
            <i class="material-icons" v-if="petition">arrow_drop_down</i>
          </a>
          
          <vs-dropdown-menu class="caseno-dropdown" v-if="petitions && checkCurrentUrl">
            <vs-dropdown-item
              @click="petetionChange(petition._id)"
              v-for="(petition, index) in petitions"
              :key="index"
              >{{ petition.caseNo }}</vs-dropdown-item
            >
          </vs-dropdown-menu>
          
        </vs-dropdown>  !loadedFromPreview, !checkCurrentUrl -->
        
        <div class="casenumber_sec">
          <div class="case_number">
            <div class="d-flex align-items-center">
              Case No
              <em
                class="edit_caseno"
                v-if="
                  !loadedFromPreview &&
                  [3, 4, 5].indexOf(getUserRoleId) > -1 &&
                  checkProperty(petition, '_id') ==
                    checkProperty(getPetitionDetails, '_id') &&
                  getPetitionDetails &&
                  getPetitionDetails.completedActivities &&
                  getPetitionDetails.completedActivities.indexOf(
                    'ASSIGN_CUSTOM_CASE_NO'
                  ) <= -1 &&
                  checkProperty(getPetitionDetails, 'status') != false
                "
                v-on:click.stop.prevent="editCaseNumber"
              >
                <img src="@/assets/images/main/edit_icon.svg" />
                <small>Edit Case No</small>
              </em>
            </div>
            <span>{{ checkProperty(petition, "caseNo") }} </span>
            <i
              class="material-icons"
              v-if="
                !loadedFromPreview &&
                checkCurrentUrl &&
                checkProperty(petitions, 'length') > 0
              "
              >arrow_drop_down</i
            >
          </div>
          <div
            class="case_number_list"
            v-if="
              !loadedFromPreview &&
              checkCurrentUrl &&
              checkProperty(petitions, 'length') > 0
            "
          >
            <VuePerfectScrollbar class="scroll-area">
              <ul v-if="petitions">
                <li
                  @click="petetionChange(petition._id)"
                  v-for="(petition, index) in petitions"
                  :key="index"
                >
                  {{ petition.caseNo }}

                  <!-- <span v-if="petition._id ==petitionId && getPetitionDetails && getPetitionDetails.completedActivities &&  getPetitionDetails.completedActivities.indexOf('ASSIGN_CUSTOM_CASE_NO')>-1" v-on:click.stop.prevent="editCaseNumber" > 
                  
                  <img src="@/assets/images/main/edit_icon.svg" />
 
              </span> -->
                </li>
              </ul>
            </VuePerfectScrollbar>
          </div>
        </div>
      </div>

      <ProcessFlow
        v-if="petition !=null"
        @reloadCaseHistory="reloadActivities"
        :caseUsers="caseUsers"
        ref="process_flow"
        :loadedFromPreview="loadedFromPreview"
        v-bind:lettersAndForms="formsAndLettersList"
        v-bind:workFlowDetails="workFlowDetails"
        v-bind:petition="petition"
        :isLcaRequiredForPetition="isLcaRequiredForPetition"
        v-bind:lcaDetails="lcaDetails"
        :configDetails="configDetails"
        @passparent="setActivetab"
        @updatepetition="reloadPetition"
        @opengenFormsAndLatters="opengenFormsAndLatters"
        v-bind:currentRole="currentRole"
        @loadstatus="setActivetabstatus"
        :enable_submit_to_offshore_manager="enable_submit_to_offshore_manager"
        @showfilingFeesPopup="showfilingFeesPopup"
        @download_or_view="download_or_view"
        @openFilingFee="openFilingFee()"
      />
      <div></div>
    </div>
    <!-- content section start here  {{petition.questionnaireFilled}}   -->

    <div
      class="tabs-content detail_page_sec petetion__details case-details-box-width"
      :class="{ petetion__details_full_width: !loadedFromPreview }"
    >
      <vs-row vs-w="12" class="bg_white" v-if="petition !=null">
        <vs-col
          vs-type="flex"
          style="padding: 0px; width: calc(100% - 300px)"
          class="mob-left"
          :class="{ 'w-full': !checkCurrentUrl || [51].indexOf(getUserRoleId) > -1 }"
        >
          <section class="petition__details_section">
            <div class="pd_left">
              <ul>
                <li
                  v-if="
                    checkProperty($route, 'name') != 'fill-lca-anonymous-user' &&
                    (checkProperty(petition, 'questionnaireFilled') || [9].indexOf(checkProperty(petition,'typeDetails', 'id')) >-1) &&
                    petition &&
                    petition.completedActivities &&
                    ((petition.completedActivities.indexOf('COURIER_TRACKING') > -1 || petition.completedActivities.indexOf('UPDATE_USCIS_RECEIPT_NUMBER')>-1) || [9].indexOf(checkProperty(petition,'typeDetails', 'id')) >-1)
                     && getUserRoleId != 51
                  "
                  :class="{
                    current_child: getPetitionTab == 'Petition Updates',
                  }"
                  @click="setActivetab('Petition Updates')"
                >
                  <a>Case Updates</a>
                </li>
                <li
                  v-if="checkProperty($route, 'name') != 'fill-lca-anonymous-user' && [9].indexOf(checkProperty(petition,'typeDetails', 'id')) <=-1"
                  :class="{
                    current_child:
                      getPetitionTab == 'Case Details' ||
                      (getPetitionTab == 'Petition Updates' && getUserRoleId == 51)
                     ||  (  getPetitionTab == 'Petition Updates' &&  petition.completedActivities && petition.completedActivities.indexOf('COURIER_TRACKING') <= -1  )
                    && !checkCourrerTrackingCompleted 
                  }"
                  @click="setActivetab('Case Details', true)"
                >
                  <a>Beneficiary Info </a>
                </li>
                <li
                v-if="
                    checkProperty($route, 'name') != 'fill-lca-anonymous-user' && 
                    (checkProperty(petition, 'questionnaireFilled') ||
                      loadedFromPreview) &&
                    ((checkProperty(petition,'fatherInfo') && checkProperty(petition,'fatherInfo','firstName')) || (checkProperty(petition,'motherInfo') && checkProperty(petition,'motherInfo','firstName')) )
                  "
                  :class="{ current_child: getPetitionTab == 'Parents Info' }"
                  @click="setActivetab('Parents Info', true)"
                >
                  <a>Parents Info </a>
                </li>
                <li
                  v-if="
                    (checkProperty($route, 'name') != 'fill-lca-anonymous-user' &&
                      checkProperty(petition, 'questionnaireFilled')) ||
                    loadedFromPreview || [9].indexOf(checkProperty(petition,'typeDetails', 'id')) >-1
                  "
                  :class="{ current_child: getPetitionTab == 'Documents' }"
                  @click="setActivetab('Documents', true)"
                >
                  <a>Petition Documents </a>
                </li>
                <li
                  v-if="
                    checkProperty($route, 'name') != 'fill-lca-anonymous-user' &&
                    (checkProperty(petition, 'questionnaireFilled') ||
                      loadedFromPreview) &&
                    [5, 8].indexOf(checkProperty(petition, 'subTypeDetails', 'id')) <=
                      -1 &&
                    checkProperty(petition, 'dependentsInfo', 'spouse') &&
                    ((petition.dependentsInfo.spouse.name != null &&
                      petition.dependentsInfo.spouse.name != '') ||
                      (petition.dependentsInfo.spouse.firstName != null &&
                        petition.dependentsInfo.spouse.firstName != '')) &&
                    checkProperty(
                      petition['beneficiaryInfo'],
                      'maritalStatusDetails',
                      'id'
                    ) != 1
                  "
                  :class="{
                    current_child: getPetitionTab == 'Dependents Info',
                  }"
                  @click="setActivetab('Dependents Info', true)"
                >
                  <a>Dependents Info</a>
                </li>
                <li
                  v-if="
                    checkProperty($route, 'name') != 'fill-lca-anonymous-user' &&
                    (checkProperty(petition, 'questionnaireFilled') ||
                      loadedFromPreview) &&
                    [5, 8].indexOf(checkProperty(petition, 'subTypeDetails', 'id')) <=
                      -1 &&
                    checkProperty(petition, 'dependentsInfo', 'childrens') &&
                    petition.dependentsInfo.childrens.length > 0 &&
                    petition.dependentsInfo.childrens[0].h4Required &&
                    (checkProperty(petition.dependentsInfo.childrens[0], 'name') ||
                      checkProperty(petition.dependentsInfo.childrens[0], 'firstName')) &&
                    checkProperty(
                      petition['beneficiaryInfo'],
                      'maritalStatusDetails',
                      'id'
                    ) != 1
                  "
                  :class="{ current_child: getPetitionTab == 'Children Info' }"
                  @click="setActivetab('Children Info', true)"
                >
                  <a>Children Info</a>
                </li>
                <li
                  v-if=" petition && workFlowDetails && 
                    (currentRole != 51 &&  !loadedFromPreview &&  
                      ((isLcaRequiredForPetition || checkProperty(petition ,'lcaId')) || (!checkProperty(petition ,'lcaId') && [50].indexOf(getUserRoleId)>-1 && isLcaRequiredForPetition) )&&
                      checkCurrentUrl) ||
                    (!checkCurrentUrl &&
                      checkProperty($route, 'name') === 'fill-lca-anonymous-user')
                  "
                  :class="{ current_child: getPetitionTab == 'LCA' }"
                  @click="setActivetab('LCA', true)"
                >
                  <a>LCA </a>
                </li>
                <template v-if="checkCurrentUrl">
                  <li
                    v-if="
                      checkProperty(petition, 'questionnaireFilled') &&
                      checkProperty(petition, 'clinetshowed')
                    "
                    :class="{ current_child: getPetitionTab == 'Client Info' }"
                    @click="setActivetab('Client Info', true)"
                  >
                    <a>Client Info</a>
                  </li>

                  <li
                    v-if="
                     (currentRole != 51 && !loadedFromPreview && checkFilingFeeRequired && (checkProperty(petition, 'questionnaireFilled') || [9].indexOf(checkProperty(petition,'typeDetails', 'id')) >-1) && checkProperty(petition, 'tenantDetails', 'typeId') != 2)
                     && ( (currentRole == 50 && checkProperty(petition, 'invoiceId') ) ||  currentRole !=50 )  
                      
                    "
                    :class="{ current_child: getPetitionTab == 'Fees/Invoices' }"
                    @click="setActivetab('Fees/Invoices', true)"
                  >
                    <a>Fees/Invoices </a>
                  </li>
                  
                  <li
                    v-if="
                    
                      checkProperty(petition, 'questionnaireFilled') && !loadedFromPreview && ( 
                      ([50,51].indexOf(getUserRoleId)<=-1 && checkActivityCompleted('SUBMIT_TO_LAW_FIRM')) 
                        || ( getUserRoleId ==50 && petition['completedActivities'].indexOf('REQUEST_PETITIONER_SIGN')>-1)
                        || ( getUserRoleId ==51 && petition['completedActivities'].indexOf('REQUEST_BENEFICIARY_SIGN')>-1)
                     )
                    "
                    :class="{
                      current_child: getPetitionTab == 'Forms and Letters',
                    }"
                    @click="setActivetab('Forms and Letters', true)"
                  >
                    <a>Forms and Letters</a>
                  </li>

                  <li
                    :class="{
                      current_child: getPetitionTab == 'Scanned Documents',
                    }"
                    @click="setActivetab('Scanned Documents', true)"
                    v-if="
                      ((checkProperty(petition, 'questionnaireFilled') &&  !loadedFromPreview ) ||
                      (checkProperty(petition,'type')==9 &&
                      petition['completedActivities'].indexOf('REQUEST_PETITIONER_SIGN')>-1)) && 
                      (
                        
                         ( 
                            [9].indexOf(checkProperty(petition,'typeDetails', 'id')) >=-1 &&
                            checkWorkActivityisRequires('REQUEST_PETITIONER_SIGN') && [51].indexOf(getUserRoleId)<=-1
                        ) || (  [9].indexOf(checkProperty(petition,'typeDetails', 'id')) <=-1 )
                        
                      ) && 
                      
                      (
                        (([50,51].indexOf(getUserRoleId)<=-1 && checkActivityCompleted('SUBMIT_TO_LAW_FIRM')) || (checkProperty(petition,'type')==9 &&
                      petition['completedActivities'].indexOf('REQUEST_PETITIONER_SIGN')>-1) )

                        || ( getUserRoleId ==50 && petition['completedActivities'].indexOf('REQUEST_PETITIONER_SIGN')>-1)
                        || ( getUserRoleId ==51 && petition['completedActivities'].indexOf('REQUEST_BENEFICIARY_SIGN')>-1)

                       
                      )                  
                     
                    "
                  >
                    <a>Scanned/Signed Documents</a>
                  </li>
                  <li
                    :class="{ current_child: getPetitionTab == 'Company Docs' }"
                    @click="setActivetab('Company Docs', true)"
                    v-if="
                    false &&
                      checkProperty(petition, 'questionnaireFilled') &&
                      !loadedFromPreview &&
                      [3, 4, 5, 6, 7, 8, 9, 10, 11, 12].indexOf(currentRole) > -1 &&
                      getTenantTypeId != 2
                    "
                  >
                    <a>Company Docs</a>
                  </li>
                  <li
                    v-if="
                    false &&
                      [50,51].indexOf(getUserRoleId)<=-1&& checkProperty(petition, 'questionnaireFilled') && !loadedFromPreview
                    "
                    :class="{
                      current_child: getPetitionTab == 'Recent Documents',
                    }"
                    @click="setActivetab('Recent Documents', true)"
                  >
                    <a>Recent Downloads</a>
                  </li>
                  <li
                    v-if="
                      [50,51].indexOf(getUserRoleId)<=-1 && (checkProperty(petition, 'questionnaireFilled') || [9].indexOf(checkProperty(petition,'typeDetails', 'id')) >-1) && !loadedFromPreview "
                    :class="{
                      current_child: getPetitionTab == 'All Documents',
                    }"
                    @click="setActivetab('All Documents', true)"
                  >
                    <a>All Documents</a>
                  </li> 
                  <li
                    :class="{ current_child: getPetitionTab == 'PERM-INFO' }"
                    @click="setActivetab('PERM-INFO', true)"
                    v-if="
                      checkProperty(petition, 'typeDetails', 'id') == 3 &&
                      !loadedFromPreview &&
                      checkProperty(petition, 'subTypeDetails', 'id') == 16
                    "
                  >
                    <a>PERM</a>
                  </li>
                  <li
                    :class="{ current_child: getPetitionTab == 'I140-INFO' }"
                    @click="setActivetab('I140-INFO', true)"
                    v-if="
                      checkProperty(petition, 'typeDetails', 'id') == 3 &&
                      !loadedFromPreview &&
                      checkProperty(petition, 'subTypeDetails', 'id') == 17
                    "
                  >
                    <a>I-140</a>
                  </li>
                  <li
                    v-if="!loadedFromPreview"
                    :class="{ current_child: getPetitionTab == 'Communication' }"
                    @click="setActivetab('Communication', true)"
                  >
                    <a>Messages</a>
                  </li>
                  <li
                    v-if="!loadedFromPreview"
                    :class="{ current_child: getPetitionTab == 'notes' }"
                    @click="setActivetab('notes', true)"
                  >
                    <a>Notes</a>
                  </li>
                </template>
              </ul>
            </div>

            <div class="pd_right petition__details_cnt">
              <div class="pd_right_cnt">
                <!-- <vs-alert color="warning" class="warning-alert top-warning-alert" icon-pack="IntakePortal" icon="IP-information-button" active="true">
                            Note: You can enter certain beneficiary information which is different from the profile information or new information in the case application.
                            However, you can decide at the time of application submission if you want those change information to be updated in the beneficiary profile.
                        </vs-alert> -->
                <div
                  class="pad20"
                  v-if="getPetitionTab == 'Petition Updates' && getUserRoleId != 51 && ((petition.completedActivities && 
                  (petition.completedActivities.indexOf('COURIER_TRACKING')>-1 || petition.completedActivities.indexOf('UPDATE_USCIS_RECEIPT_NUMBER')>-1 ))
                  || [9].indexOf(checkProperty(petition,'typeDetails', 'id')) >-1 )"
                >
                <template  v-if="[9].indexOf(checkProperty(petition,'typeDetails', 'id')) >-1">
                  <rfeCaseUpdates
                    :caseCurrentDetails="caseCurrentDetails"
                    v-bind:petition="petition"
                    @download_or_view="download_or_view"
                    v-bind:workFlowDetails="workFlowDetails"
                    @updatepetition="reloadPetition"
                   />
                </template>
                <template v-else>
                  <PetitionUpdates
                  @createRFE="createRFE"
                    :caseCurrentDetails="caseCurrentDetails"
                    v-bind:petition="petition"
                    @download_or_view="download_or_view"
                    v-bind:workFlowDetails="workFlowDetails"
                    @updatepetition="reloadPetition"
                  />
                </template>
                  
                  
                </div>
                <template
                  v-if="
                    getPetitionTab == 'Case Details' ||
                    (getPetitionTab == 'Petition Updates' && getUserRoleId == 51)
                    || (  getPetitionTab == 'Petition Updates' &&  !checkCourrerTrackingCompleted  )
                  "
                >
                  <div
                    v-if="
                      (loadedFromPreview &&
                        petition.beneficiaryInfo != null &&
                        petition.beneficiaryInfo.firstName != null) ||
                      checkProperty(petition, 'questionnaireFilled')
                      // checkProperty(petition, 'beneficiaryInfo') &&
                      // getPetitionTab == 'Case Details'
                    "
                  >
                    <BeneficiaryDetails
                      v-bind:petition="petition"
                      :visastatuses="visastatuses"
                      @download_or_view="download_or_view"
                      :questionnaireDetails = "questionnaireDetails"
                    />
                  </div>
                  <div v-else class="no-activities q_not_submitted">
                    <div class="q_not_submitted_cnt" v-if="[9].indexOf(checkProperty(petition,'typeDetails', 'id')) <=-1">
                      <figure>
                        <img src="@/assets/images/main/no-activity-img.png" />
                      </figure>
                      <h3 :removeAction="updatePetiotionActionBtn(false)">
                        <template v-if="checkCaseStatus == 1">
                          <template v-if="[3, 4, 5,6,8, 50, 51].indexOf(getUserRoleId) > -1">
                            <template v-if="!loadedFromPreview && checkCurrentUrl">
                              <a style="cursor:pointer;" @click="goToQuestionaireLink(petition._id)">
                                Fill Questionnaire.</a
                              >
                            </template>
                          </template>
                          <template v-else>Questionnaire Not Submitted Yet</template>
                        </template>

                        <template v-else> Questionnaire Not Submitted Yet </template>
                      </h3>
                    </div>
                  </div>
                </template>
                <div
                  v-if="
                    checkProperty(petition, 'dependentsInfo', 'spouse') &&
                    (checkProperty(petition['dependentsInfo'], 'spouse', 'firstName') ||
                      checkProperty(petition['dependentsInfo'], 'spouse', 'name')) &&
                    getPetitionTab == 'Dependents Info'
                  "
                >
                  <SpouseDetails
                    :loadedFromPreview="loadedFromPreview"
                    v-bind:petition="petition"
                    @download_or_view="download_or_view"
                    :questionnaireDetails = "questionnaireDetails"
                  />
                </div>       

                <div
                  class="pad20"
                  v-if="
                    checkProperty(petition, 'dependentsInfo', 'childrens') &&
                    petition.dependentsInfo.childrens.length > 0 &&
                    petition.dependentsInfo.childrens[0].h4Required &&
                    (checkProperty(petition.dependentsInfo.childrens[0], 'name') ||
                      checkProperty(petition.dependentsInfo.childrens[0], 'firstName')) &&
                    getPetitionTab == 'Children Info'
                  "
                >
                  <ChildDetails
                    :loadedFromPreview="loadedFromPreview"
                    v-bind:petition="petition"
                    @download_or_view="download_or_view"
                    :questionnaireDetails = "questionnaireDetails"
                  />
                </div>
                <!-- :visastatuses="visastatuses" -->

                <div
                  v-if="
                    checkProperty(petition, 'clinetshowed') &&
                    getPetitionTab == 'Client Info'
                  "
                >
                  <ClientDetails v-bind:petition="petition" />
                </div>
                <div
                  v-if="getPetitionTab == 'Parents Info'"
                >
                  <parentsInfoDetails
                    v-bind:petition="petition"
                    :visastatuses="visastatuses"
                  />
                </div>
                <div v-if="getPetitionTab == 'Fees/Invoices'">
                  <Fees
                   @download_or_view="download_or_view"
                    @updatepetition="reloadPetition"
                    @showfilingFeesPopup="showfilingFeesPopup"
                    v-bind:currentRole="currentRole"
                    v-bind:petition="petition"
                    v-bind:workFlowDetails="workFlowDetails"
                    ref="feeModule"
                  />
                </div>
                <!----LCA checkProperty($route ,'name')==='fill-lca-anonymous-user' )---->

                <div
                  v-if="
                  
                    (petition && workFlowDetails && getPetitionTab == 'LCA') ||
                    checkProperty($route, 'name') === 'fill-lca-anonymous-user'
                  "
                >

                <template v-if="checkProperty(lcaDetails,'statusId') == 99">
                  <template v-if="checkLca">
                    <RequestLCA 
                     ref="RequestLCARef"
                    v-if="
                      (!checkProperty(petition, 'lcaId') || petition.lcaId == null || (isEditLca && petition.lcaId)) && (checkPetitionLcaSubmit ||checkPetitionLcaRequired ||
                        checkProperty($route, 'name') === 'fill-lca-anonymous-user') || checkProperty(lcaDetails,'statusId') == 99
                    "
                    v-bind:petitionDetails="petition"
                    v-bind:workFlowDetails="workFlowDetails"
                    @updatepetition="reloadPetition"
                    @editLca="editLca"
                    @reloadLcaDetails="reloadLcaDetails"
                    :callFromDetails="true"
                  />
                  </template>
                  <template v-else>
                    <LCADetails
                    v-bind:workFlowDetails="workFlowDetails"
                      :showStatusButton="true"
                      v-if="lcaDetails != null && !isEditLca"
                      v-bind:currentRole="currentRole"
                      v-bind:lcaDetails="lcaDetails"
                      v-bind:petition="petition"
                      :showLcaActivity="false"
                      @download_or_view="download_or_view"
                      @updatepetition="reloadPetition"
                      @editLca="editLca"
                  />
                  </template>
                </template>
                <template v-else>
                  <RequestLCA 

                     ref="RequestLCARef"
                    v-if="
                      (!checkProperty(petition, 'lcaId') || petition.lcaId == null || (isEditLca && petition.lcaId)) && (checkPetitionLcaSubmit ||checkPetitionLcaRequired ||
                        checkProperty($route, 'name') === 'fill-lca-anonymous-user')
                    "
                    v-bind:petitionDetails="petition"
                    v-bind:workFlowDetails="workFlowDetails"
                    @updatepetition="reloadPetition"
                    @editLca="editLca"
                    @reloadLcaDetails="reloadLcaDetails"
                    :callFromDetails="true"
                  />
                <LCADetails
                    v-bind:workFlowDetails="workFlowDetails"
                      :showStatusButton="true"
                      v-if="lcaDetails != null && !isEditLca"
                      v-bind:currentRole="currentRole"
                      v-bind:lcaDetails="lcaDetails"
                      v-bind:petition="petition"
                      :showLcaActivity="false"
                      @download_or_view="download_or_view"
                      @updatepetition="reloadPetition"
                      @editLca="editLca"
                  />
                </template>
             
                 

                  
                </div>

                <div
                  v-if="
                    checkProperty(petition, 'documents') && getPetitionTab == 'Documents'
                  "
                >
                  <Documents
                    @updatepetition="reloadDocuments"
                    :openTabes="true"
                    @download_or_view="download_or_view"
                    :documentsUploadbtn="true"
                    :loadedFromPreview="loadedFromPreview"
                    :currentRole="currentRole"
                    :allbtn="true"
                    v-bind:petition="petition"
                    v-bind:workFlowDetails="workFlowDetails"
                    :editableDocs="true"
                    v-if="reRenderDocuments && questionnaireDetails"
                    :fieldsArray="questionnaireDetails"
                  />
                </div>
                <div v-if="getPetitionTab == 'Recent Documents'">
                  <recentDocuments
                    @download_or_view="download_or_view"
                    v-bind:petition="petition"
                  />
                </div>
                <div v-if="getPetitionTab == 'All Documents' ">
                  <allDocuments
                    @download_or_view="download_or_view"
                    v-bind:petition="petition"
                    @updatepetition="reloadPetition"
                    v-bind:lcaDetails="lcaDetails"
                    :loadedFromPreview="loadedFromPreview"
                    :fieldsArray = "questionnaireDetails"
                    :workFlowDetails="workFlowDetails"
                  />
                </div>
                <div v-if="getPetitionTab == 'PERM-INFO'">
                  <permInfo
                    @updatepetition="reloadPetition"
                    :currentRole="currentRole"
                    :loadedFromPreview="loadedFromPreview"
                    v-bind:currentRole="currentRole"
                    @download_or_view="download_or_view"
                    v-bind:petition="petition"
                    v-model="petition"
                  />
                </div>
                <div v-if="getPetitionTab == 'I140-INFO'">
                  <I140Info
                    @updatepetition="reloadPetition"
                    :currentRole="currentRole"
                    :loadedFromPreview="loadedFromPreview"
                    v-bind:currentRole="currentRole"
                    @download_or_view="download_or_view"
                    v-bind:petition="petition"
                    v-model="petition"
                  />
                </div>

                <!----Forms and Letters---->
                <div v-if="getPetitionTab == 'Forms and Letters'">
                  <FormsandLetters
                    v-bind:workFlowDetails="workFlowDetails"
                    v-bind:lcaDetails="lcaDetails"
                    :configDetails="configDetails"
                    :currentUser="currentUserId"
                    v-bind:currentRole="currentRole"
                    @download_or_view="download_or_view"
                    @showHistoryComment="showHistoryComment"
                    @updatepetition="reloadPetition"
                    @showfilingFeesPopup="showfilingFeesPopup"
                    v-bind:petition="petition"
                    @enableAction="enableAction"
                    ref="FormsAndLetters"
                  />
                </div>

                <div
                  v-if=" getPetitionTab == 'Scanned Documents'
                  "
                >
                  <ScannedCopies
                    :currentUser="currentUserId"
                    v-bind:currentRole="currentRole"
                    @download_or_view="download_or_view"
                    @updatepetition="reloadPetition"
                    @showfilingFeesPopup="showfilingFeesPopup"
                    v-bind:petition="petition"
                    @dcoumentDelete="confirmDocumentDelete"
                  />
                </div>

                <!----Company Docs--->
                <div
                  v-if="
                    [3, 4, 5, 6, 7, 8, 9, 10, 11, 12].indexOf(currentRole) > -1 &&
                    getPetitionTab == 'Company Docs'
                  "
                >
                  <CompanyDocsTemplates
                    :companyId="checkProperty(petition, 'companyDetails', '_id')"
                    :uploadCompanyDocs="
                      checkProperty(getPetitionDetails, 'status') != false
                    "
                    :currentUser="currentUserId"
                    v-bind:currentRole="currentRole"
                    @download_or_view="download_or_view"
                    @updatepetition="reloadPetition"
                    @showfilingFeesPopup="showfilingFeesPopup"
                    v-bind:petition="petition"
                    @enableAction="enableAction"
                  />
                </div>
                <div v-if="getPetitionTab == 'Communication'">
                  <Communication
                    v-bind:petition="petition"
                    v-bind:userId="currentUserId"
                    v-bind:workFlowDetails="workFlowDetails"
                  />
                </div>
                <div v-if="getPetitionTab === 'notes'">
                  <notes
                    @download_or_view="download_or_view"
                    @updatepetition="reloadPetition"
                    v-bind:petitionDetails="petition"
                    :loadedFromPreview="loadedFromPreview"
                    :loadedFromCaseDetails="true"
                  />
                </div>
              </div>
            </div>
          </section>

          <div
            v-if="
              isEveryThingLoaded &&
              petition &&
              checkProperty(petition, 'questionnaireFilled') == 'false---'
            "
            class="no-activities q_not_submitted"
          >
            <div class="q_not_submitted_cnt">
              <figure>
                <img src="@/assets/images/main/no-activity-img.png" />
              </figure>
              <h3 :removeAction="updatePetiotionActionBtn(false)">
                <template v-if="checkCaseStatus == 1">
                  <template v-if="[3, 4, 5,6,8, 50, 51].indexOf(getUserRoleId) > -1">
                    <router-link
                      :to="{ name: 'questionnaire', params: { id: petition._id } }"
                    >
                      Fill Questionnaire.
                    </router-link></template
                  >
                  <template v-else>Questionnaire Not Submitted Yet</template>
                </template>
                <template v-else> Questionnaire Not Submitted Yet </template>
                <!-- Questionnaire Not Submitted Yet -->
              </h3>
            </div>
          </div>
        </vs-col>

        <vs-col
          vs-type="flex"
          class="padr0 padl0 mob-right activies_list_wrap status_wrap"
          style="width: 300px; flex-direction: column"
          v-if="
            !loadedFromPreview && checkCurrentUrl && [51].indexOf(getUserRoleId) <= -1
          "
        >
          <!-- Newly Added -->
          <ul v-if="checkCurrentUrl && !loadedFromPreview">
            <li class="ptstatusBar" v-if="[51].indexOf(getUserRoleId) < 0">
              <div
                class="status_activities"
                :class="{ status_activities_full: [50, 51].indexOf(getUserRoleId) > -1 }"
              >
                <label
                  :class="{
                    active:
                      getCaseStatusTab == 'showCaseStatus' ||
                      ([50, 51].indexOf(getUserRoleId) > -1 &&
                        getCaseStatusTab != 'showCaseStatus'),
                  }"
                  @click="
                    reloadCaseHistory('showCaseStatus');
                    $store.commit('toggleCaseStatusTab', 'showCaseStatus');
                  "
                  >Status</label
                >
                <label
                  v-if="[50, 51].indexOf(getUserRoleId) <= -1"
                  :class="{ active: getCaseStatusTab != 'showCaseStatus' }"
                  @click="
                    reloadCaseHistory('showActivities');
                    $store.commit('toggleCaseStatusTab', 'showActivities');
                  "
                  >Activities
                </label>
              </div>
            </li>
          </ul>
          <div
            class="status_list gc_status"
            v-if="
              getCaseStatusTab == 'showCaseStatus' ||
              ([50, 51].indexOf(getUserRoleId) > -1 &&
                getCaseStatusTab != 'showCaseStatus')
            "
          >
            <VuePerfectScrollbar class="scroll-area">
              <template v-if="checkProperty( petition, 'type')==9">
                <rfeCaseStatusList
                v-bind:petition="petition"
                v-bind:workFlowDetails="workFlowDetails"
                :currentCaseDetails="caseCurrentDetails"
                :scannedDocumentsList="scannedDocumentsList"
              />
              </template>
              <template v-else>

                <caseStatusList
                v-bind:petition="petition"
                v-bind:workFlowDetails="workFlowDetails"
                :currentCaseDetails="caseCurrentDetails"
                :scannedDocumentsList="scannedDocumentsList"
              />
              </template>
              
             
            </VuePerfectScrollbar>
            <div
              class="deadline"
              v-if="
                checkProperty(petition, 'deadlineDate') &&
                [1, 2, 51].indexOf(getUserRoleId) < 0
              "
            >
            Deadline - {{ petition.deadlineDate | formatDate }}
            </div>
          </div>
          <div v-else class="history-sidebar petition_history activies_list">
            <div class="vs-sidebar">
              <div class="petition_updated" v-if="petitionhistory.length == 0">
                Last Updated -
                {{ checkProperty(petition, "updatedOn") | formatDateTime }}
              </div>
              <div class="petition_updated" v-if="petitionhistory.length > 0">
                Last Updated - {{ petitionhistory[0].createdOn | formatDateTime }}
              </div>

              <div class="vs-sidebar--items">
                <VuePerfectScrollbar class="scroll-area">
                  <div class="timeline-sidebar 2">
                    <ul>
                      <li v-for="(history, index) in petitionhistory" :key="index">
                        <div class="timeline-icon">
                          <i class="icon IP-tick-sign"></i>
                        </div>
                        <div class="timeline-info">
                          <button class="btn active-green ml-0">
                            {{
                              history.createdByRoleName
                                ? history.createdByRoleName
                                : "Anonymous User"
                            }}
                          </button>
                          <ul>
                            <li>
                              <h3>
                                <span>{{ history.title }}</span>
                                <div
                                  v-if="history.comment && history.comment != ''"
                                  class="title_des"
                                >
                                  <small></small>
                                  <div class="dec-content">
                                    <p> {{ returnCommentText(history.comment) | commentSubString }}</p>
                                    <span v-if="checkCommentLength(history['comment'])" class="view_more" @click="showHistoryComment(history)"> View More</span>
                                  </div>
                                </div>
                              </h3>
                              <!-- && checkProperty(history, 'comment', 'length') >45 -->

                              <span>{{ history.description }}</span>
                              <span>{{ history.createdOn | formatDateTime }}</span>
 <!---- (checkProperty(history, 'action') == 'MANAGE_PREMIUM_PROCESS' || checkProperty(history, 'action') == 'PETITION_DOC_DELETE')  && 
                                  <figcaption>{{checkProperty(history['documents'][0] ,'name')}}</figcaption>-->
                              <!-- <p
                                calss="cursor-pointer" 
                                style="margin-top: 5px; cursor: pointer"
                                v-if=" checkProperty(history, 'documents', 'length') > 0 "
                                @click="download_or_view(history['documents'][0])"
                              >
                                <docmentType
                                  :title="checkProperty(history['documents'][0], 'name')"
                                  :item="history['documents'][0]"
                                />
                               
                              </p> -->
                              <p class="m-0" v-if="checkProperty(history, 'documents') && checkProperty(history, 'documents', 'length') > 0" >
                                <ul class="activities_doc_list">
                                  <template v-for="(doc,indoc) in history['documents']" >
                                    <template v-if="checkProperty(doc, 'path')">
                                      <li class="cursor-pointer" @click="download_or_view(doc)" >
                                        <docmentType :title="checkProperty(doc, 'name')" :item="doc" />
                                      </li>
                                    </template>
                                  </template>
                                </ul>
                              </p>
                            </li>
                          </ul>
                        </div>
                      </li>
                    </ul>
                  </div>
                </VuePerfectScrollbar>
              </div>
            </div>
          </div>
        </vs-col>
      </vs-row>
      <!-- <div
        v-if="
          isEveryThingLoaded &&
          petition &&
          checkProperty(petition, 'questionnaireFilled') == false
        "
        class="no-activities q_not_submitted"
      >
        <figure>
          <img src="@/assets/images/main/no-activity-img.png" />
        </figure>
        <h3 :removeAction="updatePetiotionActionBtn(false)">
          Questionnaire Not Submitted Yet
        </h3>
      </div> -->
    </div>

    <vs-popup
      class="holamundo success-popups"
      title="Your registration is complete."
      :active.sync="SuccessQuestionnaire"
    >
      <figure>
        <img src="@/assets/images/main/icon-note.svg" alt="login" class="mx-auto" />
      </figure>
      <h2 class="title">
        USCIS receipt has been
        <br />sent to the Petitioner
      </h2>
    </vs-popup>

    <vs-popup
      class="document_modal document_modal-v2 "
      :class="{ 'expand': expandModal, 'custom_close_doc_modal':showCloseIcon }"
      :title="checkProperty(selectedFile, 'name')"
      :active.sync="docPrivew"
    >
    <div class="document_actions" @click="expandModal = !expandModal">
      <figure v-if="!expandModal" class="maximize-img"><img src="@/assets/images/maximize.png"  width="18" height="18"/></figure>
      <figure v-else class="minimize-img"><img src="@/assets/images/minimize.png"  width="20" height="20"/></figure>
    </div>
    <div class="custom_close" v-if="showCloseIcon">
      <figure class="close_icon" @click="showConfrmLetterPopup = true;updateletterLoading = false;errorMessage=''">
        <svg xmlns="http://www.w3.org/2000/svg" width="21" height="21" viewBox="0 0 20 20"><path class="a" d="M10,0A10,10,0,1,0,20,10,10,10,0,0,0,10,0Zm4.3,12.708L12.705,14.3A36.72,36.72,0,0,0,10,11.6a37.242,37.242,0,0,0-2.706,2.7L5.7,12.708A31.208,31.208,0,0,0,8.4,10,30.784,30.784,0,0,0,5.7,7.3L7.292,5.7s2.541,2.7,2.706,2.7,2.708-2.7,2.708-2.7L14.3,7.3A36.62,36.62,0,0,0,11.591,10C11.591,10.183,14.3,12.708,14.3,12.708Z"/></svg>
      </figure>
    </div>
      <h2>
        <img
          :class="{
            pdf_view_download: docType == 'pdf',
            office_view_download: docType == 'office',
            image_view_download: docType == 'image',
          }"
          class="download-button"
          @click="downloads3file(selectedFile)"
          src="@/assets/images/download.svg"
        />
      </h2>
      <div class="pdf_loader">
        <figure v-if="formSubmited && !saveEditedFile" class="loader loader2">
          <img src="@/assets/images/main/loader.gif" />
        </figure>

        <!-- <span :class="{'pdf_view_close':docType == 'pdf', 'office_view_close':docType == 'office'  , 'image_view_close 33':docType =='image'}" class="close close2" @click="docPrivew= false"></span> -->
        <template v-if="docType == 'office'">
          <div style="height: 90vh">
            <div id="placeholder" style="height: 100%"></div>
          </div>
        </template>
        <template v-else-if="docType == 'image'">
          <img :src="docValue" />
        </template>
        <template v-else-if="docType == 'pdf'">
          <div class="pdf" style="height: 90vh">
            <iframe
              v-if="docValue != ''"
              border="0"
              style="border: 0px"
              :src="docValue"
              height="100%"
              width="100%"
            >
            </iframe>
          </div>
        </template>
      </div>
    </vs-popup>

    <modal
      name="FilingFeesModal"
      classes="v-modal-sec"
      :min-width="200"
      :min-height="200"
      :scrollable="true"
      :reset="true"
      width="800px"
      height="auto"
    >
      <div class="v-modal">
        <div class="popup-header fromDetailsPage">
          <h2 class="popup-title">Filing Fees</h2>
          <span @click="$modal.hide('FilingFeesModal')">
            <em class="material-icons">close</em> 
          </span>
        </div>
        <form  data-vv-scope="filingFeesform" @submit.prevent>
          <div class="form-container filingFeesformcontainer editfeeform"  @click="filingFeeformerrors = ''" >
            <div class="filing_fields w-100">
              <template v-if="checkProperty(petition,'filingFeeCategoryType')=='pre_defined'">
                
                <div class="form-container ">
                <div class="vx-row" >
                  <div class="pre_defined_sec" >
                     <vs-table :data="filingFeeData">
                     
                      <template v-if="filingFeeData.length > 0" slot="thead">
                        <vs-th>Fee Type</vs-th>
                        <vs-th>Amount($)</vs-th>
                        <vs-th>Exclude from Invoice</vs-th>
                      </template>
                      <template slot-scope="{ data }">
                        <vs-tr>
                          <vs-td colspan="3"> 
                          <h3>USCIS Fees</h3>
                          </vs-td>
                        </vs-tr>
                        <vs-tr :data="filingFee" :key="index" v-for="(filingFee ,index) in filingFeeData" class="vs-table--tr" :class="{'new-invoice-item':checkProperty(filingFee ,'newly_add')}" v-if="filingFee.descriptionType=='USCIS'">
                          <vs-td><span>{{ filingFee.description  }}</span></vs-td>
                          <vs-td>
                           
                            <div class="comments_sec mb-0" >
                                  <vs-input
                                  data-vv-as="Amount"
                                  v-validate="'required'"
                                  v-model="filingFee.amount"
                                  :name="'amountUSCIS'+index"
                                  v-mask="'#####'"
                                  class="amount_input"
                                />
                                <span
                                  class="text-danger text-sm"
                                  v-show="errors.has('filingFeesform.amountUSCIS'+index)"
                                  >{{ errors.first("filingFeesform.amountUSCIS"+index) }}
                                </span>
                            </div>
                          </vs-td>
                          <vs-td>
                            <div class="form_group">
                                <div class="con-select w-full select-large">
                                  <vs-checkbox v-model="filingFee.invoice" :name="'amountUSCISinvoice'+index"
                                  ></vs-checkbox>
                                </div>
                            </div>
                          </vs-td>
                        </vs-tr>   
                        <vs-tr>
                          <vs-td colspan="3"> 
                            <h3>Attorney Fees</h3>
                          </vs-td>
                        </vs-tr>                     
                        <vs-tr :data="filingFee" :key="index" v-for="(filingFee ,index) in filingFeeData" class="vs-table--tr" :class="{'new-invoice-item':checkProperty(filingFee ,'newly_add')}" v-if="filingFee.descriptionType=='Internal'">
                          <vs-td>{{ filingFee.description  }}</vs-td>
                          <vs-td>
                            <div class="comments_sec mb-0" >
                                  <vs-input
                                  data-vv-as="Amount"
                                  v-validate="checkProperty(getUserData, 'tenantDetails', 'slug') == 'slg'?'':'required'"
                                  v-model="filingFee.amount"
                                  :name="'amountAttorney'+index"
                                  v-mask="'#####'"
                                  class="amount_input"
                                />
                                <span
                                  class="text-danger text-sm"
                                  v-show="errors.has('filingFeesform.amountAttorney' + index)"
                                  >{{ errors.first("filingFeesform.amountAttorney" + index) }}
                                </span>
                            </div>
                          </vs-td>
                          <vs-td>
                            <div class="form_group">
                                <div class="con-select w-full select-large">
                                  <vs-checkbox v-model="filingFee.invoice" :name="'invoiceAttorney' + index"
                                  ></vs-checkbox>
                                </div>
                            </div>
                          </vs-td>
                        </vs-tr>
                      </template>
                     </vs-table>
                  
              
                    </div>
                <div class="vx-col w-full" @click="value = [];uploading=false;DocErr=false">
                <div class="form_group file_group mb-0">
                  <div class="vs-component marb10">
                    <label class="form_label">Cheques<em>*</em></label>
                    <div class="relative">
                      <file-upload v-model="value" class="file-upload-input upload_file justify-center"
                        :accept="allDocEntity"
                        :name="'Documents'" :multiple="true" :hideSelected="true" @input="upload(value)"
                        >
                        <img class="file-icon" src="@/assets/images/main/file-upload.svg" />
                        Upload
                      </file-upload>
                      <span v-if="uploading" class="loader"><img src="@/assets/images/main/loader.gif" /></span>
                      <span class="text-danger text-sm" v-if="DocErr">*Documents are required</span>
                    </div>
                  </div>
                  <ul class="uploaded-list note_uploads mt-5">
                    <template v-for="(item, index) in filingFeeDocs">
                      <vs-chip @click="remove(item, filingFeeDocs, index)" :key="index" closable>
                        <img src="@/assets/images/main/down-arrow2.svg" @click="download_or_view(item)" />
                        {{ item.name }}
                      </vs-chip>
                    </template>
                  </ul>
                </div>
              </div>
                </div>
              </div>
              </template>
              <template v-else>
                <div class="filing_fees_v2">
                  <template vs-w="12" v-for="(filingFee, index) in filingFeeData" >
                    <div class="amount_sec" :key="index">
                      <vs-row>
                        <vs-col vs-xs="12">
                          <div class="form_group">
                            <label class="form_label">Fee Type<em>*</em></label>
                            <!-- <vs-textarea
                                data-vv-as="Description"
                                v-validate="'required'"
                                v-model="filingFee.description"
                                :name="'filingdescription' + index"
                                class="w-full"
                              /> -->
                              <ckeditor  data-vv-as="Description"
                                v-validate="'required'"
                                v-model="filingFee.description"
                                :name="'filingdescription' + index"
                                class="w-full" :editor="editor" :config="editorConfig"></ckeditor>
                              <span
                                class="text-danger text-sm"
                                v-show="
                                  errors.has('filingFeesform.filingdescription' + index)
                                "
                                >{{
                                  errors.first("filingFeesform.filingdescription" + index)
                                }}</span
                              >
                          </div>
                        </vs-col>
                        <vs-col vs-xs="12">
                          <vx-input-group>
                            <div class="form_group">
                              <label class="form_label">Amount($)<em>*</em></label>
                              <div class="comments_sec mb-0">
                                <vs-input
                                data-vv-as="Amount"
                                v-validate="'required'"
                                v-model="filingFee.amount"
                                :name="'amount' + index"
                                v-mask="'#####'"
                                class="amount_input"
                              />
                              <span
                                class="text-danger text-sm"
                                v-show="errors.has('filingFeesform.amount' + index)"
                                >{{ errors.first("filingFeesform.amount" + index) }}</span
                              >
                              
                              <div
                                class="delete"
                                v-if="filingFeeData.length > 1"
                                @click="removefilingfee(index)"
                              >
                                <a>
                                  <img src="@/assets/images/main/delete-row-img.svg" />
                                </a>
                              </div>
                              </div>
                              
                            </div>
                            <!-- <vs-checkbox
                                v-model="filingFee.invoice"
                                :name="'invoice'+index"
                                >Exclude from invoice</vs-checkbox> -->
                          </vx-input-group>
                        </vs-col>
                      </vs-row>
                      <vs-row class="border-0">
                        <vs-checkbox v-model="filingFee.invoice" :name="'invoice' + index"
                          >Exclude from invoice</vs-checkbox
                        >
                      </vs-row>
                    </div>
                  </template>
                </div>
                <vs-row class="more_btn_wrap">
                <vs-col
                  class="float-none pl-0 pt-3 pb-5 more_btn"
                  vs-type="flex"
                  vs-align="center"
                >
                  <a @click="addfilingfee" class="add-more ml-0 mt-5" type="filled">
                    <span>+</span> More
                  </a>
                </vs-col>
                </vs-row>
                <vs-row>
                  <vs-col vs-lg="12" vs-sm="12" vs-xs="12">
                    <div class="filing_comments p-0">
                      <div class="form_group">
                        <label class="form_label">Note<em>*</em></label>
                        <!-- <vs-textarea
                          data-vv-as="Note"
                          v-validate="'required'"
                          v-model="filingFeeComment"
                          :name="'filingFeeComment'"
                          class="w-full"
                        /> -->
                        <ckeditor  data-vv-as="Note"
                          v-validate="'required'"
                          v-model="filingFeeComment"
                          :name="'filingFeeComment'"
                          class="w-full" :editor="editor" :config="editorConfig"></ckeditor>

                        <span
                          v-if="validatefilingFeeDescrition"
                          class="text-danger text-sm"
                          v-show="errors.has('filingFeesform.filingFeeComment')"
                          >{{ errors.first("filingFeesform.filingFeeComment") }}</span
                        >
                      </div>
                    </div>
                    <!--
                    <vs-checkbox
                        v-model="emailInvoice"
                        :name="'invoice'+index"
                      >Email Invoice</vs-checkbox>
                      -->
                  </vs-col>
                </vs-row>
              </template>  
            </div>       
          </div>
          <div class="text-danger text-sm formerrors"  v-if="filingFeeformerrors!=''">
            <vs-alert
              color="warning"
              class="warning-alert reg-warning-alert no-border-radius"
              icon-pack="IntakePortal"
              icon="IP-information-button"
              active="true"
              >{{ filingFeeformerrors }}</vs-alert
            >
          </div>
          <div class="popup-footer relative">
            <span class="loader" v-if="submitingFilingFee"
              ><img src="@/assets/images/main/loader.gif"
            /></span>
            <vs-button
              color="dark"
              @click="$modal.hide('FilingFeesModal')"
              class="cancel"
              type="filled"
              >Cancel</vs-button
            >
            <!-----checkProperty(petition ,'filingFeeDetails') && checkProperty(petition,'filingFeeDetails','amount') > 0-->
            <vs-button
              color="success"
              v-if="editFilngFee"
              :disabled="submitingFilingFee"
              @click="createOrupdateInvoice"
              class="save"
              type="filled"
            >
              Update</vs-button
            >
            <vs-button
              color="success"
              v-else
              :disabled="submitingFilingFee"
              @click="submitFilingFees"
              class="save"
              type="filled"
              >Submit</vs-button
            >
          </div>
        </form>
      </div>
    </modal>
    <vs-popup
      style="z-index:99999999;"
      class="holamundo main-popup"
      title="Confirmation"
      :active.sync="showConfrmLetterPopup"
    >
      <div class="form-container" @click="errorMessage = ''">
        <div class="vx-row">
          <div class="vx-col w-full">
            <p>Do you want to save these changes as separate version?</p>
          </div>
        </div>

        <div v-show="errorMessage">
          <vs-alert
            color="warning"
            class="warning-alert reg-warning-alert no-border-radius"
            icon-pack="IntakePortal"
            icon="IP-information-button"
            active="true"
            >{{ errorMessage }}</vs-alert
          >
        </div>
      </div>
      <div class="popup-footer relative">
        <template>
          <figure v-if="updateletterLoading" class="loader loader2">
            <img src="@/assets/images/main/loader.gif" />
          </figure>
          <!-- v-if="!checkProperty(getDelectedForEditDocument, 'editedDocument')" -->
          <vs-button
            :disabled="updateletterLoading"
            class="btn cancel"
            type="filled"
            @click="deleteUpdatedDoc()"
            >No</vs-button
          >
          <vs-button
            color="success"
            :disabled="updateletterLoading"
            class="save"
            type="filled"
            @click="getDetailsDocument()"
            >Yes</vs-button 
          >
        </template>
      </div>
    </vs-popup>

    <vs-popup
      style="z-index:99999999;"
      class="holamundo main-popup"
      title="Save Document"
      :active.sync="saveEditedFile"
    >
      <div class="form-container" @click="errorMessage = ''">
        <div class="vx-row">
          <div class="vx-col w-full">
            <p>Changes made will be saved as new version.</p>
          </div>
        </div>

        <div v-show="errorMessage">
          <vs-alert
            color="warning"
            class="warning-alert reg-warning-alert no-border-radius"
            icon-pack="IntakePortal"
            icon="IP-information-button"
            active="true"
            >{{ errorMessage }}</vs-alert
          >
        </div>
      </div>
      <div class="popup-footer relative">
        <vs-button
          color="dark"
          class="cancel"
          type="filled"
          @click="saveEditedFile = false"
          >Cancel
        </vs-button>
        <template>
          <figure v-if="formSubmited" class="loader loader2">
            <img src="@/assets/images/main/loader.gif" />
          </figure>
          <vs-button
            color="success"
            v-if="!checkProperty(getDelectedForEditDocument, 'editedDocument')"
            :disabled="formSubmited"
            class="save"
            type="filled"
            @click="uploadSavedFileToS3()"
            >Ok</vs-button
          >
          <vs-button
            color="success"
            v-else
            :disabled="formSubmited"
            class="save"
            type="filled"
            @click="updateExistingDocument()"
            >Yes</vs-button
          >
        </template>
      </div>
    </vs-popup>
    <vs-popup class="holamundo main-popup cls-btn" title="Delete Document" :active.sync="showDocumentDeletePopup">
            <div class="form-container">
                <div class="vx-row">
                    <div class="vx-col w-full">
                        <p style="line-height: 20px">
                          Are you sure to continue?
                        </p>
                    </div>
                </div>
            </div>
            <div class="popup-footer">
                <vs-button color="dark" class="cancel" type="filled" @click="showDocumentDeletePopup = false;cancelDocumentDel()">Cancel</vs-button>
                <vs-button @click="documentDelete();" class="save questionnaire_btn" type="filled">Yes </vs-button>
            </div>
        </vs-popup>

        <modal
      name="historyComment"
      classes="v-modal-sec"
      :min-width="200"
      :min-height="200"
      :scrollable="true"
      :reset="true"
      width="800px"
      height="auto"
    >
      <div class="v-modal">
        <div class="popup-header fromDetailsPage">
          <h2 class="popup-title">Comment</h2>
          <span @click="$modal.hide('historyComment');selectedHistory=null">
            <em class="material-icons">close</em> 
          </span>
        </div>

        <div class="form-container">
                <div class="vx-row mb-2">
                    <div class="vx-col w-full comment_modal">
                        <p style="line-height: 20px" v-html="checkProperty(selectedHistory ,'comment')">
                         
                        </p>
                    </div>
                </div>
            </div>
            <div class="popup-footer">
                <vs-button color="dark" class="cancel" type="filled" @click="$modal.hide('historyComment');selectedHistory=null">Cancel</vs-button>
                
            </div>

       
        </div>
    </modal>    
  </div>
</template>

<script>
import parentsInfoDetails  from "@/views/petition/subtabs/parentsInfoDetails.vue"; 
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import FormsandLetters from "./petition/FormsLetters";
import CompanyDocsTemplates from "./petition/CompanyDocsTemplates";
import allDocuments from "./allDocuments.vue";
import ScannedCopies from "./ScannedCopies";
import permInfo from "./permInfo.vue";
import I140Info from "./I140Info.vue";
import ProcessFlow from "./petition/ProcessFlow";
import RequestLCA from "./RequestLCA";
import LCADetails from "./LCADetails";
import PetitionUpdates from "./petition/PetitionUpdates";
import rfeCaseUpdates from "./petition/rfeCaseUpdates";
import recentDocuments from "@/views/recentDocuments.vue";
import ClientDetails from "./petition/ClientDetails";
import ChildDetails from "./petition/ChildDetails";
import SpouseDetails from "./petition/spouseDetailsPage.vue";
import Documents from "./petition/Documents";
import BeneficiaryDetails from "./petition/BeneficiaryDetails";
import Communication from "./petition/Communication";
import Fees from "./petition/Fees";
import _ from "lodash";
import moment from "moment";
import JQuery from "jquery";
import VueDocPreview from "vue-doc-preview";
import docmentType from "@/views/common/docType.vue";
import caseStatusList from "./petition/caseStatusList.vue";
import rfeCaseStatusList from "@/views/rfeCaseStatusList.vue";
import pdfReader from "../views/common/pdfReader.vue";
import Vue from 'vue';
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import notes from "@/views/notes.vue";
import axios from "axios";
import FileUpload from "vue-upload-component/src";
var fe;
export default {
  components: {
    rfeCaseUpdates,
    FileUpload,
    allDocuments,
    parentsInfoDetails,
    recentDocuments,
    notes,
    docmentType,
    pdfReader,
    caseStatusList,
    rfeCaseStatusList,
    VueDocPreview,
    VuePerfectScrollbar,
    FormsandLetters,
    ScannedCopies,
    permInfo,
    I140Info,
    Documents,
    ProcessFlow,
    RequestLCA,
    LCADetails,
    ClientDetails,
    SpouseDetails,
    ChildDetails,
    BeneficiaryDetails,
    Communication,
    PetitionUpdates,
    Fees,
    CompanyDocsTemplates,
    uploading:false,
  },
  name: "app",
  data: () => ({
    updateletterLoading:false,
    selectedFileForEdit:false,
    selectedHistory:'',
    expandModal: false,
    selectedDocReloadTab:'',
    selectedDocument:null,
    showDocumentDeletePopup:false,
    forinedit:false,
    removedInvoiceItems:[],
    newlyAddInvoiceItems:[],
    questionnaireDetails:[],
    uploading:false,
    value:[],
    editor: ClassicEditor,
      editorConfig: {
          toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
      },
    reRenderDocuments: true,
    filingFeeDocs:[],
    DocErr:false,
    setTab: false,
    editedFile: null,
    saveEditedFile: false,
    errorMessage: "",
    formSubmited: false,

    isEditLca: false,
    currentRouteName: "",
    caseUsers: [],
    formsAndLettersList: [],
    feeInvoicesPermessions: false,
    isLcaRequiredForPetition: true,
    isEveryThingLoaded: false,
    showProcessFlow: false,
    docPrivew: false,
    showCloseIcon:false,
    showConfrmLetterPopup:false,
    docValue: "",
    docType: "",
    selectedFile: null,

    loaded: false,
    currentRole: null,
    currentUserId: null,
    SuccessQuestionnaire: false,
    petition: null,
    petitions: [],
    petitionhistory: [],
    supervisorlist: [],
    active_tab: 0,
    tabs: [
      {
        index: 0,
      },
      {
        index: 1,
      },
      {
        index: 2,
      },
      {
        index: 3,
      },
      {
        index: 4,
      },
      {
        index: 5,
      },
      {
        index: 6,
      },
    ],

    visa_status: {},
    visastatuses: [],
    spouse_currentStatusDetails: {},
    country_names: {},
    lcaDetails: null,
    workFlowId: null,
    workFlowDetails: null,
    //Filing Fee Veriables
    editFilngFee: false,
    filingFeeData: [
      {
        amount: null,
        invoice: false,
        description: "",
      },
    ],
    filingFeesPopup: false,
    filingFeeformerrors: "",
   
    submitingFilingFee: false,
    filingFeeComment: "",
    emailInvoice: false,
    validatefilingFeeDescrition: true,
    //Filing Fee Veriables End
    configDetails: null,
    filingFeeCategoryTypeGlobal:'',
    caseCurrentDetails: [],
    caseStatusList: [],
    foundDcurrentUsers: true,
    crruntUserList: [],
    scannedDocumentsList: [],
    invoicecategoryList:[],

  }),
  watch: {

    /*
    this.docPrivew = false;
                this.$refs["FormsAndLetters"].getFormsAndLetters();
    */
    docPrivew(value){
        var self = this;
        
      if(!value && self.selectedFileForEdit){
        try{
          self.selectedFileForEdit =false;
         
          self.$refs["FormsAndLetters"].getFormsAndLetters();
        }catch(e){
          self.selectedFileForEdit =false;
          console.log(e);
                   

        }

      }

    },
    active_tab(val) {
      var self = this;
      setTimeout(function () {
        JQuery(".vs-tabs--li:contains(Communication)").addClass("comm");
      }, 5);
    },
    $route: function () {
      if (this.$route.params && this.$route.params.itemId) {
        this.petitionId = this.$route.params.itemId;
        
         
          this.petition =null;
          this.petitions =  [];
          this.isEveryThingLoaded =false;
          this.workFlowDetails =null;
          this.lcaDetails =null;
          this.$store.dispatch("setPetitionData", {
                  petitionDetails: this.petition,
                  lcaDetails: this.lcaDetails,
                  workFlowDetails: this.workFlowDetails,
      }).then(()=>{
        this.mountFunction();
      }).catch(()=>{
        this.mountFunction();
      });
         

          
       
      }
    },
  },
  methods: {
    deleteUpdatedDoc(){
      let postdata = {
        documentId: '',
      };
      if(this.checkProperty( this.$store.state ,'selectedForEditDocument') ){
        let ite = this.checkProperty( this.$store.state ,'selectedForEditDocument');
        postdata['documentId'] = ite['savedDocumentId'];
      }
      this.updateletterLoading = true;
      this.$store
      .dispatch("deleteFormAndLetter", postdata)
      .then((response) => {
        this.showConfrmLetterPopup = false;
        this.updateletterLoading = false;
        this.docPrivew = false;
        this.errorMessage = '';
      })
      .catch((error) => {
        this.updateletterLoading = false;
        this.errorMessage = error;
       });
    },
    getDetailsDocument(){
      let payload = {
        formAndLetterId : ''
      };
      let selecteStoreDoc = '';
      if(this.checkProperty( this.$store.state ,'selectedForEditDocument') ){
        selecteStoreDoc = this.checkProperty( this.$store.state ,'selectedForEditDocument');
        payload['formAndLetterId'] = selecteStoreDoc['_id'];
      };
      let path = '/filled-forms-and-letters/details';
      this.updateletterLoading = true;
      this.$store.dispatch('commonAction', {"data":payload ,"path":path}).then((response)=>{
        this.errorMessage = '';
        if(_.has(response, 'path') && _.has(selecteStoreDoc, 'path') ){
          selecteStoreDoc['path'] = response['path'];
          selecteStoreDoc['parentId'] = selecteStoreDoc['savedDocumentId'];  
          selecteStoreDoc['generated'] = false;
          selecteStoreDoc['size'] = this.checkProperty(response, 'size');
          this.uploadEditedLetter(selecteStoreDoc)
        }else{
          this.updateletterLoading = false;
        }
      }).catch((err)=>{
        this.updateletterLoading = false;
        this.errorMessage = err;
      })
    },
    uploadEditedLetter(doc){
      let editedDoc = doc;
      let self = this;
      let temppay= _.cloneDeep(doc);      
      let payLoad = {
        petitionId: self.checkProperty(self.petition, '_id'),
        formLetterType: self.checkProperty(editedDoc, 'type'),
        restore:false,
        entityId:'cover_letter',
        parentId:self.checkProperty(editedDoc, 'parentId'),
        docUserType:self.checkProperty(editedDoc, 'docUserType'),
        depLabel:self.checkProperty(editedDoc, 'depLabel'),
        depType:self.checkProperty(editedDoc, 'depType'),
        formAndLetterId:self.checkProperty(editedDoc, '_id'),
        generated:false,
        documents:temppay
      }
      if(self.checkProperty(editedDoc,'entityId' ) && self.checkProperty(editedDoc ,'type') =='Letter'){
        if(self.checkProperty(editedDoc,'entityId' ) =='support_letter'){
          payLoad['entityId'] = 'support_letter';
        }
      }
      let path = "/filled-forms-and-letters/update";
      this.$store.dispatch('commonAction', {"data":payLoad ,"path":path}).then((response) => {
        this.showConfrmLetterPopup = false;
        this.updateletterLoading = false;
        this.docPrivew = false;
        this.updateletterLoading = false;
        this.errorMessage = '';
        this.$store.commit("selectedForEditDocument", null);
      }).catch((err)=>{
        this.updateletterLoading = false;
        this.errorMessage = err;
      })

    },
    createRFE() {
      
      try {
        this.$refs["process_flow"].$refs["actionsMenu"].triggerAction({"code":'CREATE_RFE_CASE'});
      } catch (e) {
        console.log(e);

      }
    },
    showHistoryComment(item=null){
      
      this.selectedHistory = item;
      if(this.checkProperty(this.selectedHistory ,'comment')){
        this.$modal.show('historyComment');
      }else{
        this.$modal.hide('historyComment');
      }

    },
    confirmDocumentDelete(val,tab){
      if(val){
        this.showDocumentDeletePopup = true;
        this.selectedDocument = val
      }
      if(tab){
        this.selectedDocReloadTab = val
      }
    },
    documentDelete(){
//alert()
    },
    cancelDocumentDel(){
      this.selectedDocReloadTab = '';
      this.showDocumentDeletePopup = false;
      this.selectedDocument = null;
    },
    upload(model, type = "") {
      
      var _current = this;
     
      let efiles = [];
      efiles = _.filter(model, (e) => {
        return e.url != null && e.url != "";
      });
      let nfiles = _.filter(model, (e) => {
        return e.url == null || e.url == undefined;
      });

      let mapper = nfiles.map(
        (item) =>
          (item = {
            name: item.name,
            file: item.file ? item.file : null,
            url: item.url ? item.url : "",
            path: item.path ? item.path : "",
            status:
              item.status === false || item.status === true
                ? item.status
                : true,
            mimetype: item.type ? item.type : item.mimetype,
          })
      );
     
      let tempFiles = [];
      if (mapper.length > 0) {
        this.uploading = true;
        let count = 0;
        mapper.forEach((doc, index) => {
          let formData = new FormData();
          formData.append("files", doc.file);
          formData.append("secureType", "private");
          formData.append("getDetails", true);
          count++;

          this.$store.dispatch("uploadS3File", formData).then((response) => {
            response.data.result.forEach((urlGenerated) => {

             // uploadedOn: moment().format("YYYY-MM-DD"),
             Object.assign(urlGenerated, {uploadedOn: moment().format("YYYY-MM-DD"), uploadedBy: _current.checkProperty(_current.getUserData, 'userId'), uploadedByName: _current.checkProperty(_current.getUserData, 'name'), uploadedByRoleId: _current.getUserRoleId, uploadedByRoleName: _current.checkProperty(_current.getUserData, 'loginRoleName') });
             
              if (
                _.has(urlGenerated, "name") &&
                tempFiles.indexOf(urlGenerated["name"]) <= -1
              ) {
                tempFiles.push(urlGenerated["name"]);
                this.filingFeeDocs.push(urlGenerated);
              }
              if(this.filingFeeDocs.length>0){
                this.DocErr=false;
              }
              doc.url = urlGenerated;
              doc.path = urlGenerated;
              doc["mimetype"] = urlGenerated["mimetype"];
              doc["type"] = urlGenerated["mimetype"];
              delete doc.file;
              mapper[index] = doc;
            });
            if (index >= mapper.length - 1) {
              this.uploading = false;
             
            }
          });
        });
        if (efiles.length > 0) efiles.push(...mapper);
       
      }
    },
    reloadLcaDetails(Val){
      if(Val){
        this.petition['lcaId'] = Val;
        this.$store.dispatch("fetchLcaDetails", this.petition.lcaId).then((response) => {
          this.lcaDetails = response.data.result;
          this.$store.dispatch("setPetitionData", {
            petitionDetails: this.petition,
            lcaDetails: this.lcaDetails,
            workFlowDetails: this.workFlowDetails,
          });
        })
      }

      setTimeout(()=>{
        this.$refs['RequestLCARef'].reload();
      });
      
    },
    remove(item, data, filindex) {
      data.splice(filindex, 1);
    },
    submitFilingFees() {
      this.validatefilingFeeDescrition = true;
      this.filingFeeformerrors = "";
      this.DocErr=false;
       if(this.checkProperty(this.petition,'filingFeeCategoryType')=='pre_defined' && this.checkProperty(this.filingFeeDocs,'length')<=0){
        this.DocErr=true;
       
       }
      
      this.$validator.validateAll("filingFeesform").then((result) => {
        
       
        if (result && this.DocErr==false) {
          this.DocErr=false;
          let includeInvoicesList = _.filter(this.filingFeeData ,{"invoice":false});
          if(includeInvoicesList && includeInvoicesList.length<=0){
            this.filingFeeformerrors = "Include at least one item into invoice";
            return false;
          }
     
          var totala = 0;
          this.filingFeeData.forEach((i) => {
            totala = totala + parseInt(i.amount);
          });
          var postData = {
            subTypeName: this.checkProperty(
              this.getPetitionDetails,
              "subTypeDetails",
              "name"
            ),
            typeName: this.checkProperty(this.getPetitionDetails, "typeDetails", "name"),
            petitionId: this.checkProperty(this.getPetitionDetails, "_id"),
            filingFeeData: this.filingFeeData,
            today: moment().format("YYYY-MM-DD"),
            comment:this.filingFeeComment,
            filingFeeDocs:{ "cheques":[]} //this.filingFeeDocs,
            /*
            companyName: this.petition.petitionerDetails.name,
            beneficiaryName: this.petition.beneficiaryDetails.name,
            beneficiaryCustomId: this.petition.beneficiaryDetails.customId,
            petitionType: this.petition.typeDetails.name,
            companyId: this.petition.petitionerDetails._id,
             petitionId: this.petition._id,
           
            amount: totala,
            customer: {
              Id: this.petition.companyDetails.qbCustomerId,
              displayName: this.petition.companyDetails.name,
              email: this.petition.companyDetails.authorizedSignatory.email,
            },
            invoiceTerms: {
              days: 30,
            },
             comment:this.filingFeeComment,
            emailInvoice:this.emailInvoice
            */
          };
          if(this.filingFeeDocs.length>0){
            postData['filingFeeDocs']['cheques'] = this.filingFeeDocs;
            // filingFeeDocs:{ "cheques":[]} //this.filingFeeDocs,
          }
         
          
          this.submitingFilingFee = true;
          this.$store
            .dispatch("commonAction", {
              data: postData,
              path: "/petition/save-filing-fees",
            })
            .then((response) => {
             
              this.createOrupdateInvoice("save-filing-fees");
            })
            .catch((error) => {
              this.submitingFilingFee = false;
              this.filingFeeformerrors = error;
            });
        }
      });
    },
    createOrupdateInvoice(callFrom = "") {
    
      let self = this;
      this.validatefilingFeeDescrition = true;
      this.filingFeeformerrors = "";
      this.DocErr=false;
       if(this.checkProperty(this.petition,'filingFeeCategoryType')=='pre_defined' && this.checkProperty(this.filingFeeDocs,'length')<=0){
        this.DocErr=true;
       }
     
      this.$validator.validateAll("filingFeesform").then((result) => {
       // alert(result)
        let includeInvoicesList = _.filter(this.filingFeeData ,{"invoice":false});
        if( includeInvoicesList && includeInvoicesList.length<=0){
            this.filingFeeformerrors = "Include at least one item into invoice";
            return false;
          }
        if (result && this.DocErr==false) {
          var totala = 0;
          this.filingFeeData.forEach((i) => {
            totala = totala + parseInt(i.amount);
          });
          let filingFeeData = _.cloneDeep(this.filingFeeData);
          if (callFrom == "save-filing-fees") {
            //filingFeeData  = _.filter(filingFeeData , {'invoice':false});
          }

          var postdata = {
            companyName: self.checkProperty(self.petition, "petitionerDetails", "name"),
            beneficiaryName: self.petition.beneficiaryDetails.name,
            beneficiaryCustomId: self.petition.beneficiaryDetails.customId,
            petitionType: self.petition.typeDetails.name,
            companyId: self.checkProperty(self.petition, "petitionerDetails", "_id"),
            petitionId: self.petition._id,
            feeDetails: filingFeeData,
            filingFeeDocs:{"cheques":[]},
            amount: totala?totala:0,
            today: moment().format("YYYY-MM-DD"),
            customer: {
              Id: self.checkProperty(self.petition, "companyDetails", "qbCustomerId"),
              displayName: "", //this.petition.companyDetails.name,
              email: "", //this.petition.companyDetails.authorizedSignatory.email,
            },
            invoiceTerms: {
              days: 30,
            },
            comment: this.filingFeeComment,
            emailInvoice: self.checkPaymentIntigration, //this.emailInvoice
          };

          if(this.filingFeeDocs.length>0){
            postdata['filingFeeDocs']['cheques'] = this.filingFeeDocs;
           
          }

          if (this.checkProperty(self.petition, "companyDetails")) {
            postdata["customer"]["Id"] = this.checkProperty(
              self.petition,
              "companyDetails",
              "qbCustomerId"
            );
            postdata["customer"]["displayName"] = this.checkProperty(
              self.petition,
              "authorizedSignatory",
              "name"
            );
            postdata["customer"]["email"] = this.checkProperty(
              self.petition,
              "authorizedSignatory",
              "email"
            );
          }

          let totalPaidAmount =0
            
            if(this.checkProperty(this.petition,'filingFeeDetails','partlyPaidLogs') && this.checkProperty(this.petition['filingFeeDetails'],'partlyPaidLogs','length')>0 ){
            let filingfeeList = _.cloneDeep(this.checkProperty(this.petition,'filingFeeDetails','partlyPaidLogs'))
              filingfeeList.forEach(item => { totalPaidAmount += parseInt(item.amount);  });
            }
            
          this.submitingFilingFee = true;
          if (
            this.checkProperty(self.petition, "invoiceId") &&
            this.petition.invoiceId != null
          ) {
            postdata.invoiceId = this.petition.invoiceId;
            postdata.statusId = 2;
            postdata.statusName = "Sent";

            
            let dueAmount = totala-totalPaidAmount
            
          if(dueAmount <=0){
            postdata.statusId = 6;
            postdata.statusName = "Fully Paid";
          }


            if(this.checkProperty(this.petition ,'filingFeeCategoryType') =="pre_defined" && this.invoicecategoryList.length>0){
               let dbFilingFeeData = _.cloneDeep(this.petition.filingFeeDetails.feeDetails);
               //this.removedInvoiceItems =[];
               //this.newlyAddInvoiceItems =[];
               if(this.removedInvoiceItems.length>0 || this.newlyAddInvoiceItems.length>0 ){

               let dbAmount =0
                dbFilingFeeData.forEach((i) => {
                  dbAmount = totala + parseInt(i.amount);
                 });


                   
                    if(totala >totalPaidAmount && totalPaidAmount>0){
                      postdata.statusId = 5;
                      postdata.statusName = "Partially Paid";

                    }else if(totala==totalPaidAmount){
                      postdata.statusId = 6;
                      postdata.statusName = "Fully Paid";

                    }else if(totalPaidAmount<totala && totalPaidAmount>0 ){
                      postdata.statusId = 5;
                      postdata.statusName = "Partially Paid";

                    }
                     if(dueAmount <=0){
                      postdata.statusId = 6;
                      postdata.statusName = "Fully Paid";
                    }

                  }
            }
            this.$store
              .dispatch("updateFilingFees", postdata)
              .then((response) => {
                this.submitingFilingFee = false;
                this.filingFeesPopup = false;
                this.$modal.hide("FilingFeesModal");
                this.editFilngFee = false;
                this.submitingFilingFee = false;
                
            
                this.showToster({ message: response.message, isError: false });
                setTimeout(() => {
                  this.reloadPetition("Fees/Invoices");
                }, 100);
              })
              .catch((error) => {
                this.submitingFilingFee = false;
                if (callFrom == "save-filing-fees") {
                  this.filingFeesPopup = false;
                  this.$modal.hide("FilingFeesModal");
                  this.editFilngFee = false;
                  
                  this.submitingFilingFee = false;
                  this.showToster({ message: error, isError: true });
                  setTimeout(() => {
                    this.reloadPetition("Fees/Invoices");
                  }, 100);
                } else {
                  this.filingFeeformerrors = error;
                 
                }
              });
          } else {
            this.$store
              .dispatch("submitFilingFees", postdata)
              .then((response) => {
                this.filingFeesPopup = false;
                this.$modal.hide("FilingFeesModal");
                this.submitingFilingFee = false;
               
                this.showToster({ message: response.message, isError: false });
                setTimeout(() => {
                  this.reloadPetition("Fees/Invoices");
                }, 100);
              })
              .catch((error) => {
                if (callFrom == "save-filing-fees") {
                  this.filingFeesPopup = false;
                  this.$modal.hide("FilingFeesModal");
                  this.submitingFilingFee = false;
                  
                  this.showToster({ message: error, isError: true });
                  setTimeout(() => {
                    this.reloadPetition("Fees/Invoices");
                  }, 100);
                } else {
                  this.submitingFilingFee = false;
                  this.filingFeeformerrors = error;
                }
              });
          }
        }
      });
    },
   async  showfilingFeesPopup(editFilngFee = false) {
    
    this.removedInvoiceItems =[];
    this.newlyAddInvoiceItems =[];
      await this.getListcat()
      this.editFilngFee = editFilngFee;
      this.DocErr=false;
      this.filingFeeData = [
        {
          amount: null,
          invoice: false,
          description: "",
        },
      ];
      if (
        this.editFilngFee &&
        this.checkProperty(this.petition ,'filingFeeDetails' ,'feeDetails') 
        //&& this.petition.filingFeeDetails.amount > 0
      ) {
        this.filingFeeData = [];
        //this.filingFeeDocs =[];
        if(this.checkProperty(this.petition ,'filingFeeCategoryType') =="pre_defined" && this.invoicecategoryList.length>0){
         let filingFeeData = _.cloneDeep(this.petition.filingFeeDetails.feeDetails);
         //descriptionId
         let finalItems =[];
         _.forEach(filingFeeData ,(dbInvoice)=>{
            let isExistsInML = _.find(this.invoicecategoryList ,{ "id": dbInvoice['descriptionId']});
            if(isExistsInML){
              finalItems.push(dbInvoice);
            }else{
              //removed Items
              this.removedInvoiceItems.push(dbInvoice);
            }

         })
         _.forEach(this.invoicecategoryList ,(invCat)=>{
            let isExistsInML = _.find(filingFeeData ,{ "descriptionId": invCat['id']});
            let isAlreadyExists  = _.find(finalItems ,{ "descriptionId": invCat['id']});

            if(!isExistsInML && !isAlreadyExists){

            let item = {  amount: null, description: "",  invoice: false,"descriptionId":''  };

            item['description'] = this.checkProperty(invCat ,"name");
            item['amount'] = this.checkProperty(invCat ,"amount");
            item['descriptionId'] = this.checkProperty(invCat ,"id");
            item['descriptionType'] = this.checkProperty(invCat,"type");
            item['newly_add'] = true;
            this.newlyAddInvoiceItems.push(item);
            finalItems.push(item);
            }

         })
         this.filingFeeData =finalItems;

        }else{
          this.filingFeeData = _.cloneDeep(this.petition.filingFeeDetails.feeDetails);
        }
        
        if(this.checkProperty(this.petition ,'filingFeeDocs', 'cheques')){
         
            this.filingFeeDocs = this.petition.filingFeeDocs['cheques'];
            this.DocErr =false;
        }
     
      }else{

        if(this.checkProperty(this.petition ,'filingFeeCategoryType') =="pre_defined" && this.invoicecategoryList.length>0){
          this.filingFeeData = [];
          this.filingFeeDocs =[];
          //this.DocErr=false
          _.forEach(this.invoicecategoryList ,(invCat)=>{
            let item = {  amount: null, description: "",  invoice: false,"descriptionId":''  };
            item['description'] = this.checkProperty(invCat ,"name");
            item['amount'] = this.checkProperty(invCat ,"amount");
            item['descriptionId'] = this.checkProperty(invCat ,"id");
            item['descriptionType'] = this.checkProperty(invCat,"type")
            
            this.filingFeeData.push(item);

          });
        }
      }
      
      this.filingFeesPopup = true;
      this.filingFeeformerrors = "";
      this.submitingFilingFee = false;
        this.filingFeeComment = this.checkProperty(
        this.petition,
        "filingFeeDetails",
        "comment"
      );
      if(!editFilngFee){
        this.filingFeeComment ='Thank you for the business. Please process this at the earliest possible.'
      }
      this.emailInvoice = true;
      this.$modal.show("FilingFeesModal");
      
      setTimeout(()=>{
        this.$validator.reset();
      } ,10);
      

      // this.$refs.ProcessFlow.showfilingFeesPopup(editFilngFee);
    },
    getListcat(){
      let self = this;
      let Payload={
       petitionId:this.$route.params.itemId
     }
      return new Promise((res ,rej)=>{
  
      self.$store.dispatch("getList",{data:Payload ,path:'/invoices/get-filing-fee-categories'} )
      .then((response) => {
        self.invoicecategoryList = response;
        res();      
              
      }).catch((err)=>{
        res();
      });
    });
  },
    mountFunction(){
      this.petition =null;
      if ([50, 51].indexOf(this.getUserRoleId) > -1) {
      this.$store.commit("toggleCaseStatusTab", "showActivities");
    } else {
      this.$store.commit("toggleCaseStatusTab", "showCaseStatus");
    }
    // this.$store.commit('toggleCaseStatusTab','showCaseStatus')

    let _self = this;
    this.setTab = false;
  
   
    if (this.$route.params && this.$route.params.itemId) {
      this.petitionId = this.$route.params.itemId;

      if (this.loadedFromPreview && this.previewData) {
        this.setActivetab("Case Details", true);
        this.petition = _.cloneDeep(this.previewData);
      } else {
        this.init();
      }
      if(this.loadedFromPreview && this.fieldsArrayDetails && this.checkProperty(this.fieldsArrayDetails,'length')>0){
        this.questionnaireDetails = _.cloneDeep(this.fieldsArrayDetails)
      }
      if (this.checkProperty(this.$route, "name") == "fill-lca-anonymous-user") {
        this.setActivetab("LCA", true);
      }
    }

    },
    opengenFormsAndLatters(){
      let _self= this;
      
    
      if(this.getPetitionTab == 'Forms and Letters'){
       
        try{
          this.$route['params']['openGeneratePopup'] ='';
          this.$route['query']['openGenForms'] ='';
          this.$refs["FormsAndLetters"].openGenerateFormsLattersPopup();
        }catch(err){
          this.$route['params']['openGeneratePopup'] ='';
          this.$route['query']['openGenForms'] =''
        }
        
      }
      
    },
    checkPaidAmount(){
      setTimeout(()=>{
        try{
        this.$refs['feeModule'].init();

      }catch(e){
         //alert(e);
      }

      },500);
      
    },
    openFilingFee() {
      if (this.checkProperty(this.petition, "invoiceId")) {
        this.showfilingFeesPopup(true);
       

      } else {
        this.filingFeeData = [
          {
            amount: null,
            invoice: false,
            description: "",
          },
        ];
        this.showfilingFeesPopup(false);
      }
    },
    updateUrl() {
      this.$route["params"]["itemId"] = _.cloneDeep(this.petitionId);
    },
    reloadCaseHistory(data) {
      this.reloadActivities(data);
     // this.$emit("reloadCaseHistory", data);
    },

    togleLoader(type = false) {
      if (type) {
        this.$vs.loading();
      } else {
        this.$vs.loading.close();
      }
    },
    reloadDocuments(tab = "Documents") {
      this.$store.dispatch("setPetitionTab", "Documents");
      this.loadPetetion(tab);
      // this.$store.dispatch("setPetitionTab", 'Case Details')
    },
    uploadSavedFileToS3() {
      //this.editedFile  =Object.assign( this.editedFile , {'extn': this.checkProperty(this.getDelectedForEditDocument ,'extn')})
      //  this.editedFile  =Object.assign( this.editedFile , {'mimetype': this.checkProperty(this.getDelectedForEditDocument ,'mimetype')})

      let formData = new FormData();
      formData.append("files", this.editedFile);
      formData.append("secureType", "private");
      formData.append("getDetails", true);
      this.formSubmited = true;

      this.$store
        .dispatch("uploadS3File", formData)
        .then((response) => {
          response.data.result.forEach((urlGenerated) => {
            let postData = {
              petitionId: this.petitionId,
              formLetterType: this.getDelectedForEditDocument["type"],
              documents: [],
              entityId: null,
            };
            if (this.checkProperty(this.getDelectedForEditDocument, "entityId")) {
              postData["entityId"] = this.getDelectedForEditDocument["entityId"];
            }
            if (!this.checkProperty(this.getDelectedForEditDocument, "editedDocument")) {
              postData = Object.assign(postData, {
                editedDocument: true,
                parentId: this.getDelectedForEditDocument["_id"],
              });
            }

            if (this.checkProperty(this.getDelectedForEditDocument, "parentId")) {
              postData = Object.assign(postData, {
                editedDocument: true,
                parentId: this.getDelectedForEditDocument["parentId"]
              });

            }else if (this.checkProperty(this.getDelectedForEditDocument, "_id")) {
              postData = Object.assign(postData, {
                editedDocument: true,
                parentId: this.getDelectedForEditDocument["_id"]
              });

            }

            if (this.checkProperty(this.getDelectedForEditDocument, "depLabel")) {
              postData = Object.assign(postData, { depLabel: "" });
              postData["depLabel"] = this.getDelectedForEditDocument["depLabel"];
            }
            if (this.checkProperty(this.getDelectedForEditDocument, "depType")) {
              postData = Object.assign(postData, { depType: "" });
              postData["depType"] = this.getDelectedForEditDocument["depType"];
            }
            if (this.checkProperty(this.getDelectedForEditDocument, "docUserType")) {
              postData = Object.assign(postData, { docUserType: "" });
              postData["docUserType"] = this.getDelectedForEditDocument["docUserType"];
            }

            if (this.checkProperty(this.getDelectedForEditDocument, "depLabel")) {
              urlGenerated = Object.assign(urlGenerated, { depLabel: "" });
              urlGenerated["depLabel"] = this.getDelectedForEditDocument["depLabel"];
            }
            if (this.checkProperty(this.getDelectedForEditDocument, "depType")) {
              urlGenerated = Object.assign(urlGenerated, { depType: "" });
              urlGenerated["depType"] = this.getDelectedForEditDocument["depType"];
            }
            if (this.checkProperty(this.getDelectedForEditDocument, "docUserType")) {
              urlGenerated = Object.assign(urlGenerated, { docUserType: "" });
              urlGenerated["docUserType"] = this.getDelectedForEditDocument["docUserType"];
            }
            postData.documents.push(urlGenerated);
            this.$store
              .dispatch("uploadFormsAndLetters", postData)
              .then((response) => {
                this.showToster({ message: response.message, isError: false });

                this.saveEditedFile = false;
                this.errorMessage = "";
                this.formSubmited = false;
                this.docPrivew = false;
               
                this.$refs["FormsAndLetters"].getFormsAndLetters();
                this.$store.commit("selectedForEditDocument", null);
              })
              .catch((error) => {
                this.errorMessage = error;
                this.formSubmited = false;
              });
          });
        })
        .catch((error) => {
          this.errorMessage = error;
          this.formSubmited = false;
        });
    },
    updateExistingDocument() {

           var _self = this;
      if(this.forinedit == false){
      this.forinedit = true;

       this.$vs.loading();
      let formData = new FormData();
      formData.append("files", this.editedFile);
      formData.append("secureType", "private");
      formData.append("getDetails", true);
      this.formSubmited = true;
      this.$store
        .dispatch("uploadS3File", formData)
        .then((response) => {
          response.data.result.forEach((urlGenerated) => {
            let postData = {
              petitionId: this.petitionId,
              formLetterType: this.getDelectedForEditDocument["type"],
              documents: null,
              document: null,
              formAndLetterId: null,
            };
            postData["formAndLetterId"] = this.getDelectedForEditDocument["_id"];

           
            if (this.checkProperty(this.getDelectedForEditDocument, "depLabel")) {
              postData = Object.assign(postData, { depLabel: "" });
              postData["depLabel"] = this.getDelectedForEditDocument["depLabel"];
            }
            if (this.checkProperty(this.getDelectedForEditDocument, "depType")) {
              postData = Object.assign(postData, { depType: "" });
              postData["depType"] = this.getDelectedForEditDocument["depType"];
            }
            if (this.checkProperty(this.getDelectedForEditDocument, "docUserType")) {
              postData = Object.assign(postData, { docUserType: "" });
              postData["docUserType"] = this.getDelectedForEditDocument["docUserType"];
            }

            if (this.checkProperty(this.getDelectedForEditDocument, "depLabel")) {
              urlGenerated = Object.assign(urlGenerated, { depLabel: "" });
              urlGenerated["depLabel"] = this.getDelectedForEditDocument["depLabel"];
            }
            if (this.checkProperty(this.getDelectedForEditDocument, "depType")) {
              urlGenerated = Object.assign(urlGenerated, { depType: "" });
              urlGenerated["depType"] = this.getDelectedForEditDocument["depType"];
            }
            if (this.checkProperty(this.getDelectedForEditDocument, "docUserType")) {
              urlGenerated = Object.assign(urlGenerated, { docUserType: "" });
              urlGenerated["docUserType"] = this.getDelectedForEditDocument["docUserType"];
            }

            postData.documents = urlGenerated;
            postData.document = urlGenerated;


            let path = "/petition/update-forms-and-letters";
            path = "/filled-forms-and-letters/update";
            this.$store
              .dispatch("commonAction", { data: postData, path: path })
              .then((response) => {
                this.showToster({ message: response.message, isError: false });
        
                this.saveEditedFile = false;
                this.errorMessage = "";
                this.formSubmited = false;
                this.docPrivew = false;
                this.$refs["FormsAndLetters"].getFormsAndLetters();
                this.$store.commit("selectedForEditDocument", null);
                this.$vs.loading.close();
                 _self.forinedit = false;
              })
              .catch((error) => {
                this.errorMessage = error;
                this.formSubmited = false;
                 _self.forinedit = false;
              });
          });
        })
        .catch((error) => {
          this.errorMessage = error;
          this.formSubmited = false;
           _self.forinedit = false;
        });

      }
    },
    editLca(action = false) {
      this.isEditLca = action;
    },

    getscannedDocumentsList() {
      if (this.petitionId) {
        this.scannedDocumentsList = [];
        let finalList = [];
        let postData = { petitionId: this.petitionId, page: 1, perpage: 10000 };
        this.$store
          .dispatch("getList", {
            data: postData,
            path: "/petition/scanned-copies-list",
          })
          .then((response) => {
            //  this.formsAndLettersList = response.list;

            let lst = [];

            _.forEach(response.list, (mainItem) => {
              mainItem = Object.assign(mainItem, {
                reverse_document_versions: [],
                mainParentId: "",
                showMe: true,
                selectedForSigning: false,
              });
              if (mainItem.parentId) {
                mainItem["mainParentId"] = mainItem["parentId"];
              } else {
                mainItem["mainParentId"] = mainItem["_id"];
              }

              lst.push(mainItem);
            });

            let subList = [];

            //reverse_document_versions
            _.forEach(lst, (mainItem) => {
              _.forEach(lst, (subItem) => {
                if (
                  mainItem.parentId &&
                  (mainItem.parentId == subItem["parentId"] ||
                    mainItem.parentId == subItem["_id"]) &&
                  mainItem["_id"] != subItem["_id"]
                ) {
                  subItem["showMe"] = false;
                  if (subList.indexOf(subItem["_id"] <= -1)) {
                    mainItem["reverse_document_versions"].push(subItem);
                    subList.push(subItem["_id"]);
                  }

                  // mainItem['showMe'] =true;
                }
              });

              if (mainItem.showMe) {
                finalList.push(mainItem);
              }
            });

            this.scannedDocumentsList = finalList;
          });
      }
    },
    goToQuestionaireLink(item) {
      this.$router.push({ name: "questionnaire", params: { itemId: item } });
    },
    getCaseCurrentDetails() {
      if (this.petitionId) {
        let self = this;
        let postData = {
          petitionId: self.petitionId,
        };
        this.caseCurrentDetails = [];
        this.$store
          .dispatch("commonAction", {
            data: postData,
            path: "petition/get-current-at-details",
          })
          .then((response) => {
            if (this.checkProperty(response, "agingLogs")) {
              this.caseCurrentDetails = response["agingLogs"];
            }
          });
      }
    },

    editCaseNumber() {
      try {
        this.$refs["process_flow"].$refs["actionsMenu"].$refs[
          "actionsPopup"
        ].assignCaseNumber(true);
      } catch (e) {}
    },
    getGlobalConfigDetails() {
      let postData = {};
      this.configDetails = null;
      this.$store
        .dispatch("commonAction", { data: postData, path: "global-config/details" })
        .then((response) => {
          if (this.checkProperty(response, "config")) {
            this.configDetails = response["config"];
            if(this.configDetails.filingFeeCategoryType){
              this.filingFeeCategoryTypeGlobal=this.configDetails.filingFeeCategoryType
            }
          }
        });
    },
    getCaseUsers() {
      let self = this;
      this.caseUsers = [];
      let postData = {
        petitionId: self.petitionId,
        page: 1,
        perpage: 2500,
      };
      this.$store
        .dispatch("getList", {
          data: postData,
          path: "/petition/assigned-user-list",
        })
        .then((response) => {
          if (self.checkProperty(response, "list")) {
            let list = response["list"];
            _.forEach(list, (user) => {
              user["tempName"] = user["name"];
              if (_.has(user, "roleName")) {
                user["tempName"] = user["tempName"] + " (" + user["roleName"] + ")";
              }
            });
            self.caseUsers = list;
          }
        });
    },

    reloadProcessFlow() {
      this.showProcessFlow = true;
    },
    getFormsAndLetters() {
      if (this.petitionId) {
        this.formsAndLettersList = [];
        let finalList = [];
        let postData = { petitionId: "", page: 1, perpage: 10000 };
        postData["petitionId"] = this.petitionId;
        this.$store
          .dispatch("getList", {
            data: postData,
            //path: "/petition/filled-forms-and-letters-list",
            path: "/filled-forms-and-letters/list",
          })
          .then((response) => {
            //  this.formsAndLettersList = response.list;

            let lst = [];

            _.forEach(response.list, (mainItem) => {
              mainItem = Object.assign(mainItem, {
                reverse_document_versions: [],
                mainParentId: "",
                showMe: true,
                selectedForSigning: false,
              });
              if (mainItem.parentId) {
                mainItem["mainParentId"] = mainItem["parentId"];
              } else {
                mainItem["mainParentId"] = mainItem["_id"];
              }

              lst.push(mainItem);
            });

            let subList = [];

            //reverse_document_versions
            _.forEach(lst, (mainItem) => {
              _.forEach(lst, (subItem) => {
                if (
                  mainItem.parentId &&
                  (mainItem.parentId == subItem["parentId"] ||
                    mainItem.parentId == subItem["_id"]) &&
                  mainItem["_id"] != subItem["_id"]
                ) {
                  subItem["showMe"] = false;
                  if (subList.indexOf(subItem["_id"] <= -1)) {
                    mainItem["reverse_document_versions"].push(subItem);
                    subList.push(subItem["_id"]);
                  }

                  // mainItem['showMe'] =true;
                }
              });

              if (mainItem.showMe) {
                finalList.push(mainItem);
              }
            });

            this.formsAndLettersList = finalList;
            this.reloadProcessFlow();
          });
      }
    },
   

    addfilingfee: function () {
      let isValied = true;
      this.validatefilingFeeDescrition = false;
      this.$validator.validateAll("filingFeesform").then((result) => {
        if (this.filingFeeData.length > 0) {
          _.forEach(this.filingFeeData, (item, index) => {
            if (
              this.errors.has("filingFeesform.amount" + index) ||
              this.errors.has("filingFeesform.filingdescription" + index)
            ) {
              isValied = false;
            }
          });
        }

        if (isValied) {
          this.filingFeeData.push({
            amount: null,
            description: "",
            invoice: false,
          });

          this.$validator.reset("filingFeesform.filingFeeComment");
        }
      });
    },
    removefilingfee: function (index) {
      this.filingFeeData.splice(index, 1);
      //Vue.delete(this.filingFeeData, index);
    },

   

    checkFeeInvoicesPermessions() {
      this.feeInvoicesPermessions = false;
      let wf = _.cloneDeep(this.getWorkFlowDetails);

      if (wf && _.has(wf, "config")) {
        let filingFeeRequired = _.find(wf["config"], { code: "FILING_FEE" });

        if (
          (filingFeeRequired &&
            _.has(filingFeeRequired, "editors") &&
            _.has(filingFeeRequired, "actionRequired") &&
            filingFeeRequired["editors"].length > 0 &&
            filingFeeRequired.actionRequired == "Yes" &&
            _.has(this.petition, "completedActivities") &&
            this.petition["completedActivities"].indexOf("CASE_APPROVED") > -1) ||
          (_.has(this.petition, "nextWorkflowActivity") &&
            this.petition["nextWorkflowActivity"] == "FILING_FEE")
        ) {
          this.feeInvoicesPermessions = true;
        } else {
          this.feeInvoicesPermessions = false;
        }
      } else {
        this.feeInvoicesPermessions = false;
      }
      // alert(this.feeInvoicesPermessions);
    },

    isLcaRequired() {
      this.isLcaRequiredForPetition = false;
      let wf = _.cloneDeep(this.getWorkFlowDetails);

      if (wf && _.has(wf, "config")) {
        let lcaRequired = _.find(wf["config"], { code: "LCA_REQUEST",'actionRequired':'Yes' });

        if (
          lcaRequired &&
          _.has(lcaRequired, "editors") &&
          _.has(lcaRequired, "actionRequired") &&
          lcaRequired["editors"].length > 0 &&
          lcaRequired.actionRequired == "Yes"
        ) {
          if (this.petition.lcaId) {
            this.isLcaRequiredForPetition = true;
          } else if (
            this.petition.lcaId == null &&
            (_.find(lcaRequired["editors"], { roleId: this.getUserRoleId }) ||
              this.checkAdminLoginroles)
          ) {
            this.isLcaRequiredForPetition = true;
          }
        } else {
          this.isLcaRequiredForPetition = false;
        }
      } else {
        this.isLcaRequiredForPetition = false;
      }


      if([14].indexOf(this.getUserRoleId)>-1 && this.petition && this.petition.completedActivities.indexOf('ASSIGN_LCA_EXECUTIVE')>-1 ){
        this.isLcaRequiredForPetition  =true;
      }

      this.isEveryThingLoaded = true;

      let tab = this.getPetitionTab;

      this.setActivetab(tab);
    },

    getWorkflowDetails(tab = "") {
      if (tab == "") {
        tab = this.getPetitionTab;
      }

      //alert(this.workFlowId)
      this.workFlowDetails = null;
      this.$store.dispatch("setPetitionData", {
        petitionDetails: this.petition,
        lcaDetails: this.lcaDetails,
        workFlowDetails: this.workFlowDetails,
      });

      if (this.workFlowId) {
        let payLoad = {
          path: "/workflow/details",
          data: { workflowId: this.workFlowId },
        };
        this.$store
          .dispatch("commonAction", payLoad)
          .then((res) => {
            this.workFlowDetails = res;
            this.$store.dispatch("setPetitionData", {
              petitionDetails: this.petition,
              lcaDetails: this.lcaDetails,
              workFlowDetails: this.workFlowDetails,
            });
            if (this.checkProperty(this.petition, "questionnaireFilled")) {
              this.showProcessFlow = true;
            }

            setTimeout(() => {
              this.isLcaRequired();
              this.checkFeeInvoicesPermessions();
            }, 100);
            this.getFormsAndLetters();
            setTimeout(() => {
              this.setActivetab(tab);
            }, 100);
            this.reloadProcessFlow();
          })
          .catch((error) => {
            this.reloadProcessFlow();
            this.workFlowDetails = null;
            this.$store.dispatch("setPetitionData", {
              petitionDetails: this.petition,
              lcaDetails: this.lcaDetails,
              workFlowDetails: this.workFlowDetails,
            });
            setTimeout(() => {
              this.setActivetab(tab);
            }, 100);
          });
      }
    },
    enable_submit_to_offshore_manager(data) {},

    download_or_view(docItem) {
      let value = _.cloneDeep(docItem);
      this.selectedFileForEdit =false;
      this.showCloseIcon = false;
      if ( _.has(value ,'viewmode') && this.checkProperty(value,'viewmode')==false ) {
          this.selectedFileForEdit =true;
      }

      this.expandModal= false;

      if (
        this.checkProperty(this.getPetitionDetails, "caseNo") &&
        this.checkProperty(value, "name")
      ) {
        let docName = _.cloneDeep(value["name"]);
        
        try{
          if(!docName.includes(this.checkProperty(this.getPetitionDetails, "caseNo"))){
            value["name"] = docName;
          }
        }catch(err){

        }

        
      }

      var _self = this;
      this.formSubmited = false;
      if (_.has(value, "path")) {
        value["url"] = value["path"];
        value["document"] = value["path"];
      }

      if (_.has(value, "url")) {
        value["path"] = value["url"];
        value["document"] = value["url"];
      }

      if (_.has(value, "document")) {
        value["path"] = value["document"];
        value["url"] = value["document"];
      }

      this.selectedFile = value;
      this.docValue = "";
      this.docPrivew = false;
      this.docType = false;
      this.docType = this.findmsDoctype(value);
      this.showCloseIcon = false;

      //if ( (this.docType == "office" || this.docType == "image" || this.docType == "pdf") && value.download == false ) {
      if (this.docType == "office" || this.docType == "image" || this.docType == "pdf") {
        value.url = value.url.replace(this.$globalgonfig._S3URL, "");
        value.url = value.url.replace(this.$globalgonfig._S3URLAWS, "");
        let postdata = {
          keyName: value.url,
          petitionId: value["petitionId"],
        };
        this.$store.dispatch("getSignedUrl", postdata).then((response) => {
          this.docValue = response.data.result.data;

          if (this.docType == "office") {
            document.getElementById("placeholder").innerHTML =
              "  <div  id='placeholder2' style='height:100%'></div>";
            let _editing = false;

            if ([50, 51].indexOf(this.getUserRoleId) > -1) {
              _editing = false;
            }
           
            let docViewUrl ='https://immibox.com/api/petition/post-edited-document';
            if(_.has(this.$globalgonfig, 'DOC_VIEW_URL')){
              docViewUrl = this.$globalgonfig['DOC_VIEW_URL'];
            }

            let entityId = 'cover_letter';
            if(this.checkProperty(value,'entityId')){
              entityId = value['entityId'];
            }
               
            if ( _.has(value ,'viewmode') && value.viewmode==false ) {
              _editing = true;
              if(_.has(value,'type') && _self.checkProperty(value, 'type') == 'Letter' && _.has(value,'generated') &&
              (_self.checkProperty(value, 'generated') == true || _self.checkProperty(value, 'generated') == 'true') && !value['parentId']
               ){
                this.showCloseIcon = true; 
                // && this.checkProperty( this.$store.state ,'selectedForEditDocument') && this.checkProperty( this.$store.state ,'selectedForEditDocument', 'savedDocumentId')
              } 
            }
            var _ob = {};
            if (value.editedDocument) {
              _ob = {
               // entityId:entityId,
                petitionId: this.petition._id,
                name: value.name,
                _id: value._id,
                extn: "docx",
                formLetterType: "Letter",
                parentId: value.parentId,
              };
            } else {
              _ob = {
               // entityId:entityId,
                name: value.name,
                petitionId: this.petition._id,
                _id: value._id,
                extn: "docx",
                formLetterType: "Letter",
                parentId: value._id,
              };
            }
            var nid = value._id +  Math.round(+new Date()/1000)
            window.docEditor = new DocsAPI.DocEditor("placeholder2", {
              document: {
                c: "forcesave",
                fileType: "docx",
                key: nid,
                userdata: JSON.stringify(_ob),
                title: value.name,
                url: response.data.result.data,
                permissions: {
                  edit: _editing,
                  download: true,
                  reader: false,
                  review: false,
                  comment: false,
                },
              },

              documentType: "word",
              height: "100%",
              width: "100%",

              editorConfig: {
                userdata: JSON.stringify(_ob),
                callbackUrl:
                docViewUrl+"?entityId="+entityId+"&payload=" +
                  JSON.stringify(_ob) +
                  "&token=" +
                  _self.$store.state.token +
                  "&name=" +
                  value.name.replace(".docx", ""),
                customization: {
                  logo: {
                    image: "https://immibox.com/app/favicon.png",
                    imageDark: "https://immibox.com/app/favicon.png",
                    url: "https://immibox.com",
                  },
                  anonymous: {
                    request: false,
                    label: "Guest",
                  },
                  chat: false,
                  comments: false,
                  compactHeader: false,
                  compactToolbar: true,
                  compatibleFeatures: false,
                  feedback: {
                    visible: false,
                  },
                  forcesave: true,
                  help: false,
                  hideNotes: true,
                  hideRightMenu: true,
                  hideRulers: true,
                  layout: {
                    toolbar: {
                      collaboration: false,
                    },
                  },
                  macros: false,
                  macrosMode: "warn",
                  mentionShare: false,
                  plugins: false,
                  spellcheck: false,
                  toolbarHideFileName: true,
                  toolbarNoTabs: true,
                  uiTheme: "theme-light",
                  unit: "cm",
                  zoom: 100,
                },
              },
              events: {
                onReady: function () {},
                onDocumentStateChange: function (event) {
                  var url = event.data;
                  if (!event.data) {
                    if (value.editedDocument) {
                    }
                  }
                },
              },
            });
            //this.docValue = encodeURIComponent(response.data.result.data);
          }

          if (this.docType == "pdf") {
            var formAndLetterId = value._id;
            let parentId = '';
            // if (this.checkProperty(value,'parentId')) {
            //   parentId = value.parentId;
            // }else{
            //   if (this.checkProperty(value,'generated')) {
            //     parentId = value._id;
            //   }
             
            // }
            //alert(parentId)
            var  viewmode = 0; //viewmode= 1 Enable edit AND viewmode= 0; //Disabled Edit
            let pdfViewUrl ='https://immibox.com/viewer/pdfjs-dist/web/viewerv2.html';
            
            if(_.has(this.$globalgonfig, 'PDF_VIEW_URL')){
              pdfViewUrl = this.$globalgonfig['PDF_VIEW_URL'];
            }
             

            if(_.has(value ,'viewmode')){
              if (value.viewmode) {
                viewmode = 0;
              }else{
                viewmode = 1;
                viewmode=viewmode+"&depLabel="+value.depLabel+"&depType="+value.depType+"&docUserType="+value.docUserType+"&generated="+value.generated+"&parentId="+parentId+"&formAndLetterId="+formAndLetterId+"&save=v2&docname="+value.name+"&posturl="+this.$globalgonfig._APIURL+"/&petitionId="+this.$route.params.itemId+"&entityId="+value.entityId+"&token="+this.$store.state.token
                if(_.has(this.$globalgonfig, 'PDF_EDIT_URL')){
                  pdfViewUrl = this.$globalgonfig['PDF_EDIT_URL'];
                  
                 }
              }

            }

           
            
           
            if(this.getPetitionTab != 'Forms and Letters'){
              viewmode= 0; //Disabled Edit
              if(_.has(this.$globalgonfig, 'PDF_VIEW_URL')){
                pdfViewUrl = this.$globalgonfig['PDF_VIEW_URL'];
              }
              
            }
           
            this.docValue =
            pdfViewUrl+"?view=" +
              viewmode +
              "+&file=" +
              encodeURIComponent(response.data.result.data);
          }
          this.docPrivew = true;
        });
      } else {
        this.downloads3file(value);
      }
    },

    enableAction() {
      this.loadPetetion();
    },
    
    reloadPetition(tab = "Case Details") {
      if(tab=="opengenFormsAndLatters"){
        this.getPetitionTab == 'Forms and Letters'
        this.$store.dispatch("setPetitionTab", 'Forms and Letters').then(()=>{
          setTimeout(()=>{
            this.opengenFormsAndLatters();
          },1)
          
          
        }).catch(()=>{
          setTimeout(()=>{
            this.opengenFormsAndLatters();
          },1)
         
        });

      }else  if (tab != "") {
       
        this.$store
          .dispatch("setPetitionTab", tab)
          .then(() => {
            this.init(tab);
          })
          .catch((err) => {
            this.init();
          });
      } else {
        this.$store.dispatch("setPetitionTab", "Case Details");
        this.init();
      }
    },
    setActivetab(stab = "Case Details", callFromClick = false) {
      //Communication Company Docs Case Details Dependents Info  , Children Info , Fees/Invoices
      // this.updatePetiotionActionBtn(false)
      this.editLca(false);
      if (!stab) {
        stab = "Case Details";
      }
      if( stab == "Case Details"){
        if(this.petition && this.checkProperty(this.petition, 'typeDetails') && this.checkProperty(this.petition, 'typeDetails', 'id') == 9 ){
          stab = 'Petition Updates'
        }else{
          stab = "Case Details"
        }
      }
      this.$store.dispatch("setPetitionTab", stab);
      if (stab == "Forms and Letters") {
        try {
          if (this.$refs["process_flow"]) {
            this.$refs["process_flow"].getFormsAndLetters();
          }
        } catch (err) {}
      }

      if (callFromClick) {
        //  this.loadPetetion();
      }
      $("html, body").animate({ scrollTop: 0 }, 100);
      $(".preview_content .ps-container").scrollTop(0);
    },
    setActivetabstatus() {
      var self = this;
      setTimeout(function () {
        self.active_tab = JQuery(".vs-tabs--li:contains(Tracking)").index();
      }, 100);
    },
    getQuestioinnairyDetails(){
      this.questionnaireDetails=null;
      this.$store.dispatch("commonAction", {
          data: {
              questionnaireId: this.petition.questionnaireTplId
          },
          path: "/questionnaire/details",
      })
      .then((res) => {
        this.questionnaireDetails = res.fields;
        
      })
    },
    setchromeStore(){
      var data ={'loginToken':'','caseId':'' ,'dolEfilePwdRefId':'' ,'dolEfilePermRefId':'' ,"lcaId":''};
      var loginToken = localStorage.getItem('loginToken');
      data['loginToken'] = loginToken;
      data['petitionId'] = this.petitionId;
      data['caseId'] = this.petitionId;
      if(this.checkProperty( this.petition,'lcaId')){
        data['lcaId'] = this.checkProperty(this.petition,'lcaId');
      }
     

      if(this.petition && this.petition['dolEfilePwdRefId']){
        data = Object.assign(data ,{'dolEfilePwdRefId':this.petition['dolEfilePwdRefId']});
      }
      if(this.petition && this.petition['dolEfilePermRefId']){
        data = Object.assign(data ,{'dolEfilePermRefId':this.petition['dolEfilePermRefId']})
      }
     // alert(chrome);
      
      localStorage.setItem("storeData", JSON.stringify(data))
    //  chrome.storage.local.set({'storeData': data}, () => { });




    },
    loadPetetion(tab = "") {
      this.setTab = false;
      this.editLca(false);
      this.updatePetiotionActionBtn(false);

      this.getscannedDocumentsList();

      // this.workFlowDetails =null;
      //this.petition =null;
      //  this.lcaDetails = null;
      // this.petition.filingFeeDetails = null;
      this.active_tab = 0;
      if (this.petition == null) {
        this.loaded = false;
        this.loaded = true;
        this.$vs.loading();
      }
      this.getGlobalConfigDetails();
      this.getCaseCurrentDetails();

      this.$store.dispatch("getpetition", this.petitionId).then((response) => {
        this.updatePetiotionActionBtn(false);

        this.getCaseUsers();
        this.$vs.loading.close();
        this.loaded = false;
        this.loaded = true;
        if (response && response.data && response.data.result ) {

          
          this.reRenderDocuments = false;
          this.petition = response.data.result;

          this.getQuestioinnairyDetails();

          if (
            ["set_Communication", "set_LCA", "set_notes"].indexOf(this.getPetitionTab) >
            -1
          ) {
            let tmp = this.getPetitionTab.split("set_");

            if (this.checkProperty(tmp, "length") >= 2) {
              this.$store.dispatch("setPetitionTab", tmp[1]);
              this.setTab = true;
            }
          }

          if (this.$route.params && this.$route.params.tabname) {
            this.$store.dispatch("setPetitionTab", this.$route.params.tabname);
            this.setTab = true;
          }
 
          if (!this.setTab && tab == "") {
            if([9].indexOf(this.checkProperty(this.petition, 'typeDetails', 'id'))>-1){
              if(this.currentRole == 51){
                this.$store.dispatch("setPetitionTab", 'Documents');
              }else{
                this.$store.dispatch("setPetitionTab", "Petition Updates");
              }
              
            }else{
              //alert()
              //this.$store.dispatch("setPetitionTab", "Case Details");
            }
          }

          if (
            !this.setTab &&
            ((this.petition && this.petition.statusId > 12) || (this.checkProperty(this.petition, 'completedActivities') && this.checkProperty(this.petition, 'completedActivities', 'length')>0 &&  this.petition.completedActivities.indexOf('COURIER_TRACKING') >=0)
               // ["COURIER_TRACKING"].indexOf(this.checkProperty("nextWorkflowActivity")) >
                )
          ) {
            this.$store.dispatch("setPetitionTab", "Petition Updates");

            this.setTab = true;
          }

          this.$store.dispatch("setPetitionData", {
            petitionDetails: this.petition,
            lcaDetails: this.lcaDetails,
            workFlowDetails: this.workFlowDetails,
          });
          this.setchromeStore();
        }else{
          this.showToster({message:"Case Details are not found",isError:true });
          setTimeout(() => {
            this.$router.push("/cases/");
         }, 10);

         return true;
        }
        setTimeout(() => {
          this.reRenderDocuments = true;
        }, 0);

        if (this.checkProperty(this.$route, "name") === "fill-lca-anonymous-user") {
          this.$store.dispatch("setPetitionTab", "LCA");
          this.setTab = true;
        }
        
        if (this.currentRole == 51 && !this.loadedFromPreview && !this.checkProperty(this.petition, "questionnaireFilled") && this.checkProperty(this.petition, 'typeDetails', 'id') !=9
        ) {
          let routeId = this.petitionId;

          this.$router.push("/questionnaire/" + routeId);
        }
        if (this.checkProperty(this.petition, "beneficiaryInfo", "dateOfBirth")) {
          let routeId = this.$route.params.itemId;
          //this.$router.push({ name: 'questionnaire', params: { routeId } })
        }

        if (this.checkProperty(this.petition, "workflowId")) {
          this.workFlowId = this.petition.workflowId;
          this.getWorkflowDetails();
        }
        //this.petition.filingFeeDetails = null;
        if (_.has(this.petition, "invoiceId")) {
          this.$store
            .dispatch("filingFeeDetails", {
              invoiceId: this.petition.invoiceId,
            })
            .then((response) => {
              this.loaded = true;
              this.petition.filingFeeDetails = response;
              this.checkPaidAmount();
            })
            .catch((response) => {
              this.loaded = true;
            });
        }

        if (this.checkProperty(this.petition, "lcaId")) {
          this.$store
            .dispatch("fetchLcaDetails", this.petition.lcaId)
            .then((response) => {
              this.lcaDetails = response.data.result;
              //alert(JSON.stringify( this.lcaDetails));
              // this.lcaDetails["status_documents"] = [];
              this.lcaDetails = Object.assign(this.lcaDetails, { status_documents: [] });

              let stsid = this.lcaDetails["statusId"];
              let status_documents = {};
              let statusLogs = this.lcaDetails["statusLogs"];
              _.forEach(statusLogs, (object) => {
                let comment = object["comment"];
                let statusId = object["statusId"];
                _.forEach(this.lcaDetails["documents"].lca, (document, indx) => {
                  this.lcaDetails["documents"].lca[indx]["is_new"] = false;

                  let doc = _.cloneDeep(document);
                  doc["comment"] = comment;

                  if (
                    doc["statusId"] &&
                    doc["statusId"] == statusId &&
                    doc["comment"] &&
                    doc["comment"] != ""
                  ) {
                    if (_.has(status_documents, statusId)) {
                      status_documents[statusId].push(doc);
                    } else {
                      status_documents[statusId] = [];
                      status_documents[statusId].push(doc);
                    }
                    document["is_status_document"] = true;
                  } else {
                    if (!document["is_status_document"])
                      document["is_status_document"] = false;
                  }
                });
              });

              _.forEach(status_documents, (docs) => {
                if (docs.length > 0) {
                  this.lcaDetails["status_documents"].push(docs);
                }
              });
              this.$store.dispatch("setPetitionData", {
                petitionDetails: this.petition,
                lcaDetails: this.lcaDetails,
                workFlowDetails: this.workFlowDetails,
              });
              setTimeout(() => {
                //this.setActivetab(tab);
              }, 100);
            });
        } else {
          setTimeout(() => {
            //this.setActivetab(tab);
          }, 100);
        }
        this.$store.dispatch("setPetitionData", {
          petitionDetails: this.petition,
          lcaDetails: this.lcaDetails,
          workFlowDetails: this.workFlowDetails,
        });

        if (this.checkProperty(this.petition, "userId")) {
          let postDt = { userId: "", isRfeCase: false };
          if (_.has(this.petition, "rfeCase")) {
            postDt["isRfeCase"] = this.petition["rfeCase"];
          }
          postDt["userId"] = this.petition["userId"];
          this.$store.dispatch("getpetitionsdropdown", postDt).then((response) => {
            this.petitions = response;
          });
        }
      });
      this.getcaseHistory();
    },
    reloadActivities(data) {
      //'showCaseStatus' showActivities
      if (data == "showActivities") {
        this.getcaseHistory();
      }
      if (data == "showCaseStatus") {
        this.getCaseCurrentDetails();
      }
    },
    getcaseHistory() {
      if (this.petitionId) {
        this.$store.dispatch("petitionhistory", this.petitionId).then((response) => {
          this.petitionhistory = response.result.list;
        });
      }
    },
    init(tab = "") {
      // this.$store.commit("TOGGLE_IS_SIDEBAR_ACTIVE", false);
      // this.$store.dispatch('updateSidebarWidth', 'reduced');
      //  this.$store.commit('UPDATE_SIDEBAR_ITEMS_MIN', true)

      this.updatePetiotionActionBtn(false);

      this.currentRole = this.$store.state.user.loginRoleId;
      this.currentUserId = this.$store.state.user._id;
      this.loadPetetion(tab);

      this.$store.dispatch("getmasterdata", "visa_status").then((response) => {
        this.visastatuses = response;
      });
      this.$store.dispatch("getusersByrole", 8).then((response) => {
        this.paralegallist = response.list;
      });
      this.$store.dispatch("getusersByrole", 7).then((response) => {
        this.supervisorlist = response.list;
      });
    },
    petetionChange(id) {
      this.getPetitionTab == 'Case Details';
      this.setActivetab("Case Details", true);
      /*
        if(this.petitions.length>1){
            this.petitionId = id;
            //this.$router.push("/petition-details/"+id);
                setTimeout( ()=>{this.init()},100);

        }else{
                this.petitionId = id;
                setTimeout( ()=>{this.init()},100);

        }
        */

      this.workFlowDetails = null;
      this.petition = null;
      this.lcaDetails = null;
      this.petitionId = id;

      // this.$store.commit('toggleCaseStatusTab','showCaseStatus')

      // this.$store.dispatch("setPetitionTab", "Case Details");
      this.$store
        .dispatch("setPetitionData", {
          petitionDetails: this.petition,
          lcaDetails: this.lcaDetails,
          workFlowDetails: this.workFlowDetails,
        })
        .then(() => {
          setTimeout(() => {
            this.init();
          }, 10);
        })
        .catch(() => {
          setTimeout(() => {
            this.init();
          }, 1);
        });
      this.updateUrl();
    },
    receiveMessage (event) {

       if(event.data && event.data.message == 'openLoader'){
       // this.togleLoader(true);
      }

      if(event.data && event.data.message == 'closePopup'){
                this.showToster({ message: event.data.cmessage.message, isError: false });
        
                this.saveEditedFile = false;
                this.errorMessage = "";
                this.formSubmited = false;
                this.docPrivew = false;
                this.$refs["FormsAndLetters"].getFormsAndLetters();
                this.$store.commit("selectedForEditDocument", null);
                this.$vs.loading.close();
                 this.forinedit = false;

      }
      
   }
  },
  beforeDestroy() {
    try {
       window.removeEventListener('message', this.receiveMessage)

    } catch (err) {
      
    }
  },
  mounted() {
    this.getListcat();
    this.mountFunction();
     window.addEventListener('message', this.receiveMessage)

  },
  computed: {
    checkCommentLength(){
      return (comment='')=>{
        let textcomment = comment;
        let self = this;
        let returnVal = false;
        if(textcomment){
          var plainText = textcomment.replace(/<[^>]*>/g, '');
          let plainext = plainText.replace(/&nbsp;|&nbsp/g, ' ');
          if(plainext){
            var htmlString = plainext.trim();
            if(htmlString && self.checkProperty(htmlString, 'length') > 100 ){
              returnVal = true
            }
          }
        }
        return returnVal
      }
    },
    returnCommentText(){
      return (comment='')=>{
        let returnVal = '';
        if(comment){
          var plainText = comment.replace(/<[^>]*>/g, ' ');
          let plainext = plainText.replace(/&nbsp;|&nbsp/g, ' ');
          if(plainext){
            returnVal = plainext.trim();
            
          }
        }
        return returnVal
      }
    },
    checkWorkActivityisRequires(){
        return (code='')=>{
          if( _.has(this.workFlowDetails ,"config") && this.checkProperty(this.workFlowDetails ,'config', 'length') ){
            let config = this.workFlowDetails['config'];
            let ilteredItem = _.find(config, {"code":code,"actionRequired":'Yes'});
            if(ilteredItem){
              return true;
            }
            return false;
          }else{
            return false;
          }
        }
    },
    checkLca(){
      let returnVal = true;
      if(this.checkProperty(this.lcaDetails ,'statusDetails') && this.checkProperty(this.lcaDetails ,'statusDetails','id') == 99){
        if(this.checkProperty(this.lcaDetails,'createdBy') == this.checkProperty( this.getUserData ,'userId')){
          returnVal = true;
        }else{
          returnVal = false;
        }
      }
      return returnVal;
    },
    checkCourrerTrackingCompleted(){
      let returVal =false;
      if(this.petition && _.has(this.petition ,"completedActivities") ){
          if(this.petition['completedActivities'].indexOf('COURIER_TRACKING')>-1 || this.petition['completedActivities'].indexOf('UPDATE_USCIS_RECEIPT_NUMBER')>-1){
            returVal =true;
          }
        }
        return returVal;
    },
    // checkSubmitToUSCIS(){
    //      let returVal =false;
    //     //  let isSUbmitToDol = _.find(this.petition['courierTrackingDetails'] ,{"category":'COURIER_TRACKING'});
    //      let uscisRecieptNumber = _.find(this.petition['courierTrackingDetails'] ,{"category":'UPDATE_USCIS_RECEIPT_NUMBER'});
    //      if( uscisRecieptNumber){
    //       return true;
    //      }
    //     return returVal;
    //   },
    checkActivityCompleted(){
      let returnVal =false;
      return (activityCode='')=>{

        if(this.petition && _.has(this.petition ,"completedActivities") ){
          if(this.petition['completedActivities'].indexOf(activityCode)>-1){
            returnVal =true;
          }
        }
      return returnVal;
      }
    },
    checkFilingFeeRequired(){
      let returnVal =false;
      if(this.workFlowDetails){
      let feeActiVity = _.find(this.workFlowDetails.config , {"code":'FILING_FEE'});
      if(feeActiVity && feeActiVity['actionRequired'] =="Yes"){
        returnVal = true;
      }
    }
    return returnVal;

    },
    checkCaseStatus() {
      if (this.checkProperty(this.petition, "intStatusDetails", "id") == 1) {
        return this.checkProperty(this.petition, "intStatusDetails", "id");
      } else {
        return 4;
      }
    },
    getDelectedForEditDocument() {
      if (this.checkProperty(this.$store.state, "selectedForEditDocument")) {
        return this.$store.state["selectedForEditDocument"];
      } else {
        return null;
      }
    },

    checkFormsAndLattersPermissions() {
      let returValue = true;
      if ([51].indexOf(this.getUserRoleId) > -1) {
        returValue = false;
      } else {
        if (
          [50].indexOf(this.getUserRoleId) > -1 &&
          this.checkProperty(this.getPetitionDetails, "completedActivities", "length") > 0
        ) {
          if (
            this.getPetitionDetails["completedActivities"].indexOf(
              "REQUEST_PETITIONER_SIGN"
            ) <= -1
          ) {
            returValue = false;
          }
        }
      }
      return returValue;
    },

    activateLcaTab() {
      if (
        this.checkPetitionLcaRequired &&
        !this.checkProperty(this.getPetitionDetails, "lcaId")
      ) {
        return true;
      } else {
        return false;
      }
    },
    getPetitionTab() {
      return this.$store.state.selectedPetitionTab;
    },
  },
  props: {
    fieldsArrayDetails:{
      type:Array,
      default:null
    },
    loadedFromPreview: false,
    previewData: null,
  },
};
</script>
