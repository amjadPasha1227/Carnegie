<template>
  <div>
    <div class="content-header">
      <div class="content-header-left">
        <div class="search petition-search">
          <vs-input icon-pack="feather" icon="icon-search" v-model="searchtxt"
            placeholder="Search by Name/Email/Cust ID" class="is-label-placeholder" />
        </div>
      </div>
      <div class="content-header-right">

        <vs-dropdown vs-custom-content vs-trigger-click>
          <vs-button color="primary" class="filter-btn" type="border" icon-pack="feather" icon="icon-chevron-down"
            icon-after>
            <img src="@/assets/images/main/icon-filter.svg" /> Filters
          </vs-button>
          <vs-dropdown-menu ref="filter_menu" class="filters-content">

            <div class="filters-form-fileds">
              <div class="form-container">
                <div class="vx-row">

                  <!---
            countries:[],
     states:[],
     locations:[],
     selectedCountry:null,
     selectedState:null,
     selectedCityes:[],
    -->
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Select Status</label>

                    <multiselect v-model="selected_statusids" :options="all_statusids" :multiple="true"
                      :hideSelected="true" :close-on-select="false" :clear-on-select="false" :select-label="''"
                      :preserve-search="true" placeholder="Select Status" label="name" track-by="name"
                      :preselect-first="false">

                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          option(s) selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>

                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Country</label>
                    <multiselect name="spouseaddresscountry" v-model="selectedCountry" @input="changedCountry"
                      :show-labels="false" track-by="id" label="name" data-vv-as="Country" placeholder="Select Country"
                      :options="countries" :searchable="true" :allow-empty="false">
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          options selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label for class="typo__label">State</label>
                    <multiselect name="State" v-model="selectedState" @input="changedState" :show-labels="false"
                      track-by="id" label="name" data-vv-as="State" :multiple="false" placeholder="Select State"
                      :options="states" :searchable="true" :allow-empty="true">
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          options selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label for class="typo__label">City</label>
                    <multiselect name="city" v-model="selectedCityes" @input="changedCity" :show-labels="false"
                      track-by="id" label="name" data-vv-as="City" placeholder="Select City" :options="locations"
                      :searchable="true" :allow-empty="true" :multiple="true" :hideSelected="true">
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          options selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>
                  <div class="vx-col md:w-1/3 w-full con-select" v-if="[3,4].indexOf(getUserRoleId)>-1">
                    <label class="typo__label">Deleted</label>
                    <multiselect v-model="selectedarchive"
                      :options="[{'name':'Yes' ,'_id':false} ,{'name':'No' ,'_id':true}]" :multiple="true"
                      :hideSelected="true" :close-on-select="false" :clear-on-select="false" :preserve-search="true"
                      placeholder="Select" label="name" track-by="name" :preselect-first="false">

                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          Selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>

                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Created Date</label>
                    <date-range-picker :maxDate="new Date()" :autoApply="autoApply" :ranges="false"
                      v-model="selected_createdDateRange"></date-range-picker>
                  </div>
                </div>



              </div>
            </div>
            <div class="filters-status">
              <div class="left-buttons">

              </div>
              <div class="right-buttons">
                <vs-button color="success" class="save" type="filled" v-on:click="set_filter()">Apply</vs-button>
                <vs-button color="dark" class="cancel" type="filled" v-on:click="clear_filter($event)">Clear
                </vs-button>
              </div>
            </div>
          </vs-dropdown-menu>
        </vs-dropdown>


        <vs-button type="border" v-if="checkPetInvitePermisions" class="light-blue-btn"
          @click="invitePetitionPopupshow(true)">Invite Customer<span>
            <img class="add-user-icon ml-2" src="@/assets/images/main/add-user.svg">
          </span>
        </vs-button>
        <!-- <vs-button
        :disabled="archiving"
          color="primary"
          type="border"
          class="light-blue-btn"
          @click="$modal.show('conformArchivemodal')"
          v-if="checkProperty(selectedForArchiveList ,'length')>0 &&[3,4].indexOf(getUserRoleId) > -1"
        >
        
        Delete <span>
          <img class="add-user-icon ml-2" src="@/assets/images/main/add-user.svg">
        </span></vs-button> -->
      </div>
    </div>

    <NoDataFound ref="NoDataFoundRef" v-if="users.length == 0"
      :content="callFromSerch?'No Results Found':'No Petitioners signed up yet. Invite Petitioners to start using ImmiBox'"
      heading="No Petitioners Found" type='petitioner' />
    <!---  "createdOn":-1, "invitedByName":1, "createdByName":1, "name":1, "email":1, "phone":1, 'statusName':1, 'updatedOn':1---->

    <div class="accordian-table relative" v-if="users.length > 0">
      <div class="table_actions">
        <vs-button :disabled="archiving" color="primary" type="border" class="primary_btn delete_btn"
          @click="$modal.show('conformArchivemodal')"
          v-if="checkProperty(selectedForArchiveList ,'length')>0 &&[3,4].indexOf(getUserRoleId) > -1">

          Delete </vs-button>
      </div>
      <vs-table :data="users" :no-data-text="'No data found...!'">
        <template slot="thead">


          <vs-th>
            <vs-checkbox :disabled="archiving" v-if="[3,4].indexOf(getUserRoleId) > -1 && checkEnableSelectAll"
              @change="selectAllforArchive()" :name="'selecteAll'" v-model="selectedAllForArchive" class="">
            </vs-checkbox>

            <a @click="sortMe('name')"
              v-bind:class="{'sort_ascending':sortKeys['name']==1, 'sort_descending':sortKeys['name']!=1}">
              Name
            </a>
          </vs-th>
          <vs-th>
            <a @click="sortMe('email')"
              v-bind:class="{'sort_ascending':sortKeys['email']==1, 'sort_descending':sortKeys['email']!=1}">

              Email
            </a>
          </vs-th>
          <vs-th>
            <a @click="sortMe('customIdSNo')"
              v-bind:class="{'sort_ascending':sortKeys['customIdSNo']==1, 'sort_descending':sortKeys['customIdSNo']!=1}">

              Cust ID
            </a>
          </vs-th>
          <vs-th>
            <a @click="sortMe('statusName')"
              v-bind:class="{'sort_ascending':sortKeys['statusName']==1, 'sort_descending':sortKeys['statusName']!=1}">

              Status
            </a>
          </vs-th>
          <vs-th>
            <a @click="sortMe('createdOn')"
              v-bind:class="{'sort_ascending':sortKeys['createdOn']==1, 'sort_descending':sortKeys['createdOn']!=1}">
              Created On
            </a>
          </vs-th>
          <vs-th class="actions">Actions
          </vs-th>
        </template>
        <template slot-scope="{data}">
          
          <vs-tr :data="tr" :key="indextr" v-for="(tr, indextr) in data">
            <vs-td :data="tr.name">
              <vs-checkbox v-if="[3,4].indexOf(getUserRoleId) > -1 && checkProperty(tr ,'status')!=false"
                @change="selectForArchive(tr)" :name="'selected_'+indextr" v-model="tr.selectedForArchive" class="">
              </vs-checkbox>



              <span class="cursor-pointer" @click="petitionlink(tr)">
                <avatar :size="36" :backgroundColor="'#0E1D48'" :initials="avtarName(tr, 'name')"></avatar>
                {{ tr.name }}
              </span>
            </vs-td>
            <vs-td>
              <span class="cursor-pointer" @click="petitionlink(tr)">{{ checkProperty( tr,'sortEmail' )}}</span>
            </vs-td>

            <vs-td :data="tr.customId"><span class="cursor-pointer" @click="petitionlink(tr)">{{tr.customId}} </span>
            </vs-td>
            <vs-td :data="tr.statusDetails">
              <div>
                <span @click="petitionlink(tr)" class="statusspan cursor-pointer"
                :class="
                {'status_pending':tr.statusDetails['id']==1,'status_active':tr.statusDetails['id']==2,'status_onHold':tr.statusDetails['id']==3,'status_rejected':tr.statusDetails['id']==4}">{{checkProperty(tr
                ,"statusDetails" ,'name')}}</span>
                <span class="user_role pl-6" v-if="tr.petitionerUserDetails.statusId ==4" >deleted</span>
                <span class="user_role" v-if="tr.registrationCompleted==true">(Profile Completed)</span>
              </div>
              
            </vs-td>
            <vs-td :data="tr.createdOn">
              <span class="cursor-pointer"  @click="petitionlink(tr)">{{ tr.createdOn | formatDate }}</span>
            </vs-td>
            <vs-td>
              <vs-dropdown class="msg_dropdown_icon" :vs-trigger-click="true">
                <a class="a-icon" href.prevent>
                  <more-vertical-icon size="1.5x" class="custom-class cursor"></more-vertical-icon>
                </a>
                <vs-dropdown-menu class="loginx msg_dropdown">
                  <!--
                 [ { "_id": "614474466228a1faac34a244", "id": 1, "name": "Registered" },
                  { "_id": "614474466228a1faac34a245", "id": 2, "name": "Approved" },
                   { "_id": "614474466228a1faac34a246", "id": 3, "name": "On Hold" },
                  { "_id": "614474466228a1faac34a247", "id": 4, "name": "Rejected" }, 
                  { "_id": "614474466228a1faac34a248", "id": 5, "name": "Closed" } ]
                  -->
                  <template v-if="tr.statusDetails['id']<=1 && checkProperty( tr ,'status') !=false">
                    <vs-dropdown-item>
                      <a href.prevent style="cursor:pionter;padding:3px 10px"
                        @click="openApprovepopup(tr ,2,'Approve')"><span>Approve</span></a>
                    </vs-dropdown-item>
                    <vs-dropdown-item>
                      <a href.prevent style="cursor:pionter;padding:3px 10px"
                        @click="openApprovepopup(tr ,3,'Hold')"><span>Hold</span></a>
                    </vs-dropdown-item>
                    <vs-dropdown-item>
                      <a href.prevent style="cursor:pionter;padding:3px 10px"
                        @click="openApprovepopup(tr ,4 ,'Reject')"><span>Reject</span></a>
                    </vs-dropdown-item>
                  </template>
                  <template v-if="tr.statusDetails['id']==2">
                    <!--
                      <vs-dropdown-item>
                        <a href.prevent style="cursor:pionter;padding:3px 10px" v-if="tr.statusDetails['id'] >=2"  @click="openApprovepopup(tr ,5 ,'Close')"><span>Close</span></a>
                      </vs-dropdown-item>
                      -->
                    <vs-dropdown-item v-if="checkProperty( tr ,'status') !=false">
                      <a href.prevent style="cursor:pionter;padding:3px 10px" v-if="[3,4,5,7].indexOf(getUserRoleId)>-1"
                        @click="showSetPassword( true,tr['petitionerUserDetails'])"><span>Set Password</span></a>
                    </vs-dropdown-item>


                    <vs-dropdown-item v-if="checkPetProfileEditPermisions && checkProperty( tr ,'status') !=false">
                      <router-link :to="'/petitioner-edit/'+tr._id">
                        <a href.prevent style="cursor:pionter;padding:3px 10px"
                          v-if="checkEditPermissions"><span>Edit</span></a>
                      </router-link>
                    </vs-dropdown-item>

                    <vs-dropdown-item>
                      <router-link :to="'/petitioner-details/'+tr._id">
                        <a href.prevent style="cursor:pionter;padding:3px 10px"
                          v-if="tr.statusDetails['id'] >=2"><span>Details</span></a>
                      </router-link>
                    </vs-dropdown-item>

                  </template>
                  <vs-dropdown-item
                    v-if="checkProperty(tr ,'petitionerUserDetails' ) &&  checkProperty(tr ,'petitionerUserDetails' ,'statusId')<=1 && checkProperty( tr ,'status') !=false">
                    <a href.prevent style="cursor:pionter;padding:3px 10px" @click="resend(tr)"><span>Resend Activation
                        Link</span></a>
                  </vs-dropdown-item>
                  <vs-dropdown-item
                    v-if="[3].indexOf(getUserRoleId)>-1">
                    <a href.prevent style="cursor:pionter;padding:3px 10px" @click="conformDeleteCorporate(tr);errorMsg='';"><span>Delete</span></a>
                  </vs-dropdown-item>

                </vs-dropdown-menu>
              </vs-dropdown>
            </vs-td>
          </vs-tr>
        </template>
      </vs-table>
      <div class="table_footer">
        <div class="vx-col  con-select pages_select"  v-if="users.length>0">
          <label class="typo__label">Per Page</label>
          <multiselect @input="changeperPage()" v-model="perpage" :options="perPeges" :multiple="false"
              :close-on-select="true" :clear-on-select="false" :preserve-search="true" placeholder="Per Page"
              :preselect-first="true">
            </multiselect>
            <span class="totla_list_count" v-if="totalCount"> Total <em>{{totalCount}}</em></span>
          </div>
      <paginate v-if="users.length>0" v-model="page" :page-count="totalpages" :page-range="3" :margin-pages="2"
        :click-handler="pageNate" prev-class="vs-pagination--buttons btn-prev-pagination vs-pagination--button-prev"
        next-class="vs-pagination--buttons btn-next-pagination vs-pagination--button-next" :prev-text="'<i></i>'"
        :next-text="'<i></i>'" :container-class="'pagination vs-pagination--nav'" :page-class="'page-item'"></paginate>
      </div>
    </div>
    <vs-popup class="holamundo main-popup" title="Invite Customer" v-if="invitepetitioner"
      :active.sync="invitepetitioner">
      <form>
        <div class="form-container">
          <div class="vx-row">
            <div class="vx-col w-full">
              <div class="form_group">
                <label class="form_label">Company Name<em>*</em></label>
                <vs-input @click="formerrors.msg=''" type="text" class="w-full no-icon-border" name="company name"
                  data-vv-as="Company Name" v-model="new_user.name" v-validate="'required'" />
                <span class="text-danger text-sm" v-show="errors.has('company name')">{{ errors.first("company name")
                  }}</span>
              </div>
            </div>

            <div class="vx-col w-1/2">
              <div class="form_group">
                <label class="form_label">First Name<em>*</em></label>
                <vs-input type="text" class="w-full no-icon-border" name="adminFirstName" data-vv-as="First Name"
                  v-model="new_user.adminFirstName" v-validate="'required'" />
                <span class="text-danger text-sm" v-show="errors.has('adminFirstName')">{{
                  errors.first("adminFirstName") }}</span>
              </div>
            </div>
            <div class="vx-col w-1/2">
              <div class="form_group">
                <label class="form_label"> Last Name<em>*</em></label>
                <vs-input type="text" class="w-full no-icon-border" name="adminLastName" data-vv-as="Last Name"
                  v-model="new_user.adminLastName" v-validate="'required'" />
                <span class="text-danger text-sm" v-show="errors.has('adminLastName')">{{ errors.first("adminLastName")
                  }}</span>
              </div>

            </div>

            <div class="vx-col w-1/2">
              <div class="form_group">
                <label class="form_label">Email ID<em>*</em></label>
                <vs-input v-model="new_user.email" class="w-full no-icon-border" key="email" name="email"
                  data-vv-as="Email" autocomplete="off" autocorrect="off" autocapitalize="none"
                  v-validate="'required|email'" />
                <span class="text-danger text-sm" v-show="errors.has('email')">{{ errors.first("email") }}</span>
              </div>
            </div>
            <div class="vx-col w-1/2" @click="formerrors.msg=''">
              <div class="form_group ph_number">
                <div class="vs-component">
                  <label for="" class="form_label">Phone Number<em>*</em></label>
                  <VuePhoneNumberInput autocomplete="off" autocorrect="off" icon-pack="feather"
                    class="w-full no-icon-border" :no-example="false" v-validate="'required'" data-vv-as="Phone Number"
                    name="phone" v-bind="vuePhone.props" default-country-code="US" placeholder="Number"
                    :no-country-selector="false" v-model="new_user.phone" @update="updatePhone" :preferred-countries="['US', 'IN']"/>
                  <span class="text-danger text-sm" v-show="!isPhoneValid && !errors.has('phone')">*Invalid phone number
                    - Please enter a valid one</span>
                  <span class="text-danger text-sm" v-show="errors.has('phone')">{{ errors.first("phone") }}</span>
                </div>
              </div>
            </div>

          </div>

          <div class="text-danger text-sm formerrors mt-1" v-show="formerrors.msg">
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
              icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
          </div>
        </div>
        <div class="popup-footer relative">
          <figure v-if="inviting" class="loader"><img src="@/assets/images/main/loader.gif" /></figure>
          <vs-button color="dark" @click="invitePetitionPopupshow(false)" class="cancel" type="filled">Cancel
          </vs-button>
          <vs-button :disabled="inviting" color="success" @click="petitionerInvite()" class="save" type="filled">Submit</vs-button>
        </div>
      </form>
    </vs-popup>



    <vs-popup class="holamundo main-popup" :title="popupbtnTxt+' Company'" :active.sync="approveConformpopUp">
      <div class="form-container">

        <div class="vx-row">
          <div class="vx-col w-full">
            <p>{{actionText}}</p>

          </div>

        </div>

      </div>
      <div class="popup-footer">
        <vs-button color="dark" class="cancel" type="filled" @click="approveConformpopUp=false">Cancel</vs-button>
        <vs-button color="success" class="save" type="filled" @click="changetPetitionerstatus()">{{popupbtnTxt}}
        </vs-button>
      </div>
    </vs-popup>

    <vs-popup class="holamundo main-popup" title="Set Password" :active.sync="setPassword">
      <form>
        <div class="popup-accounts-content edit_password" v-if="setPassword">
          <div class="text-danger text-sm formerrors"   @click="setPasswordErrorMsg=''">
       
          <div class="form-container">
            <div class="form_group">
              <!-- <i class="placeholder-icon IP-hide-1"></i> -->
              <label class="form_label">New Password<em>*</em></label>
              <vs-input type="password" v-validate="'required|min:6|max:15|strongpassword'" data-vv-as="New Password"
                name="currentPassword" v-model="newPassword" class="w-full no-icon-border" ref="password" />
              <span class="text-danger text-sm" v-show="errors.has('currentPassword')">{{
                errors.first("currentPassword") }}<br /></span>
            </div>
            <div class="form_group">
              <!-- <i class="placeholder-icon IP-hide-1"></i> -->
              <label class="form_label">Confirm Password<em>*</em></label>
              <vs-input type="password" v-validate="'required|confirmed:password'" data-vv-as="Confirm Password"
                v-model="confPassword" name="newPassword" class="w-full no-icon-border" />
              <span class="text-danger text-sm" v-show="errors.has('newPassword')">{{
                errors.first("newPassword")
                }}</span>
            </div>
            <div v-if="setPasswordErrorMsg ">
              <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius"
                icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ setPasswordErrorMsg}}</vs-alert>
            </div>
          </div>
          <div class="popup-footer justify-between relative">
            <div class="password-count">
              <i class="icon IP-lock"></i> Password must contain 6 to 15 characters
            </div>
            <div class="d-flex">
              <vs-button color="dark" @click="setPassword=false ;updatingPassword=false" class="cancel" type="filled">
                Cancel</vs-button>

              <vs-button class="save" type="filled" @click="changePassword" :disabled="updatingPassword">
                <figure v-if="updatingPassword" class="loader"><img src="@/assets/images/main/loader.gif" /></figure>
                Update
              </vs-button>
            </div>
          </div>
        </div>
        </div>
      </form>
    </vs-popup>
    <vs-popup class="holamundo main-popup" title="Delete" :active.sync="deleteCorporatePopup">
        <div class="form-container">
          <div class="vx-row"  >
            <div class="vx-col w-full">
              <p>Are you sure to continue?</p>
            </div>
                      
          </div>
          <div class="text-danger text-sm formerrors" v-show="errorMsg">
                <vs-alert
                  color="warning"
                  class="warning-alert reg-warning-alert no-border-radius"
                  icon-pack="IntakePortal"
                  icon="IP-information-button"
                  active="true"
                >{{ errorMsg }}</vs-alert>
          </div>
        </div>
        <div class="popup-footer relative">
           <span class="loader" v-if="loading" ><img src="@/assets/images/main/loader.gif"/></span>
          <vs-button color="dark" class="cancel" type="filled" v-on:click.stop.prevent="deleteCorporatePopup=false;">Cancel</vs-button>
          <vs-button color="success" class="save" :disabled="loading" type="filled" v-on:click.stop.prevent="deleteCorporate()">Delete</vs-button>
        </div>
    </vs-popup>
    <modal name="conformArchivemodal" classes="v-modal-sec" :min-width="200" :min-height="200" :scrollable="true"
      :reset="true" width="450px" height="auto">
      <div class="v-modal">
        <div class="popup-header fromDetailsPage">
          <h2 class="popup-title">
            Delete

          </h2>
          <span @click="$modal.hide('conformArchivemodal');">
            <em class="material-icons">close</em>
          </span>
        </div>

        <div class="form-container">

          <div class="vx-row">
            <div class="vx-col w-full">
              <p class="msg_text">Are you sure to continue?</p>

            </div>

          </div>

          <div v-show="formerrors.msg">
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
              icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
          </div>

        </div>
        <div class="popup-footer relative">
          <figure v-if="archiving" class="loader"><img src="@/assets/images/main/loader.gif" /></figure>
          <vs-button color="dark" class="cancel" type="filled" @click="$modal.hide('conformArchivemodal');">No
          </vs-button>
          <vs-button :disabled="archiving" color="success" class="save" type="filled" @click="archiveAction()">Yes
          </vs-button>
        </div>

      </div>
    </modal>


  </div>
</template>

<script>
  import Datepicker from "vuejs-datepicker-inv";
  import Paginate from "vuejs-paginate";
import DateRangePicker from "vue2-daterange-picker";
  import { FormWizard, TabContent } from "vue-form-wizard";
  import "vue-form-wizard/dist/vue-form-wizard.min.css";
   import moment from 'moment'
  import PhoneMaskInput from "vue-phone-mask-input";
  import JQuery from 'jquery'
  import { TheMask } from 'vue-the-mask'
  import { MoreVerticalIcon } from 'vue-feather-icons';
  import Avatar from 'vue-avatar'
  import NoDataFound from "@/views/common/noData.vue";

  import VuePhoneNumberInput from 'vue-phone-number-input';
 import 'vue-phone-number-input/dist/vue-phone-number-input.css';

  export default {
    components: {
      DateRangePicker,
      VuePhoneNumberInput,
      Datepicker,
      Paginate,
      MoreVerticalIcon,
      FormWizard,
      TabContent,
      PhoneMaskInput,
      TheMask,
      NoDataFound,
      Avatar
    },

    data: () => ({
      inviting:false,
      loading:false,
      setPasswordErrorMsg:'',
     setPassword:false,
   newPassword:'',
   confPassword:'',
   updatingPassword:false,
   selectedItem:null,


      isPhoneValid:true,
      callFromSerch:false,
      selected_createdDateRange: ["", ""],
    autoApply: "",
     countries:[],
     states:[],
     locations:[],
     selectedCountry:null,
     selectedState:null,
     selectedCityes:[],
     vuePhone:{
        props:{
          translations:{
            phoneNumberLabel:"Phone Number"
          }
        }

      },
      sortKeys:{},
    sortKey:{},
       petitioner: {
                name: "",
                adminFirstName:"",
                adminLastName:"",
                email: "",
                phoneCountryCode:{countryCode:'',countryCallingCode:''},
                roleId:"1",
                phone:"",
                password: "",
                confirm_password: "",
                invite:true
                
            },  
      selectedpetitioner:null,
      selectedStatus:2,
      actionText:"Do you want to approve?",
      formerrors: {
        msg: ""
      },
      date: null,
      visatype: {
        id: 1,
        name: "H1B"
      },
      visasubtype: null,
      visasubtype: null,
      selectedUser: null,
      selectedUsername: null,
      approveConformpopUp: false,
      selected_roleID:'1',
      new_user: {
        firstName: "",
        lastName:"",
        adminFirstName: "",
        adminLastName:"",
        roleId:12,
        email: "",
        phone:"",
        active:true,
        "accountType": "Corporate",
        address: {
          "line1": "",
          "line2": "",
          "locationId": "",
          "stateId": "",
          "countryId": 231,
          "zipcode": ""
        }

      },
      users: [],
      invitepetitioner: false,
      NewPetition: false,
      visatypes: [],
      visasubtypes: [],
      searchtxt: "",
      query: [],
      country_code: 231,
      all_statusids: [],
      selected_statusids: [],
      final_selected_statusids: [],
      filter_roleIds: [],
      final_filter_roleIds: [1,2,3,4,5,8,9,10,11 ,12],

      all_states: [],
      seleted_states: [],
      final_selected_states: [],
      locations: [],
      // locationIds
      all_locations: [],
      seleted_locations: [],
      final_selected_locations: [],
      date: "",
      date_range: [],
      page: 1,
      perPeges: [10,25,50,75,100],
      perpage: 25,
      totalCount:0,
      totalpages: 0,
      all_userroles: [],

      selected_userrole: '',
      switch2:true,
      users_status:{},
      popupbtnTxt:'',
      companyStatusList:[],

       selectedForArchiveList:[],
       archiving:false,
       selectedarchive:[],
       selectedAllForArchive:false,
       deleteCorporatePopup: false,
      selectedCorporateItem:null,
      errorMsg:'',
      encodedString:'',
    }),
    watch: {
      searchtxt: function (value) {
        this.getPetitioners(true);
      }

    },
    methods: {
      changeperPage(){
        this.page = 1;
        this.getPetitioners(true);
      },
      conformDeleteCorporate(item){
        this.loading =false;
        this.deleteCorporatePopup =true;
        this.selectedCorporateItem = item;
        this.errorMsg ='';
    },
    deleteCorporate(){
       let  postData = {};
       postData['companyIds'] = [this.selectedCorporateItem._id]
       let path ="/company/delete"
          this.loading =true;
          this.$store.dispatch("commonAction", {"data":postData ,"path":path})
        .then(response => {
          this.showToster({message:response.message,isError:false });
          this.loading =false;
          this.deleteCorporatePopup =false;
          this.selectedCorporateItem =null;
          this.getPetitioners(true);    
          this.errorMsg ='';                            
        }).catch((error)=>{
          //this.showToster({message:error,isError:true });
          this.loading =false;
          this.errorMsg =error;
        })
      },
       petitionlink(tr) {
      
        this.$router.push({ path: `/petitioner-details/${tr["_id"]}` ,query: {'filter':this.encodedString} }).catch(err => {})
        //this.$router.push('/petitioner-details/'+tr._id)
    },
      selectAllforArchive(){
               this.formerrors.msg ='';
          this.selectedForArchiveList =[];
        _.forEach(this.users ,(item)=>{
          item.selectedForArchive =false;
          if(this.selectedAllForArchive && this.checkProperty(item ,'status')!=false){
             item.selectedForArchive =true;
             this.selectedForArchiveList.push(item._id)

          }
         
        })

        if(this.users.length>0 && this.users.length != this.selectedForArchiveList.length ){
        this.selectedAllForArchive =false;
      }

      
     
      

    },

      archiveAction(){
         this.formerrors.msg =''
     let postData ={
       "companyIds":[]
     };
     postData['companyIds'] = this.selectedForArchiveList;
     this.archiving =true;
      this.$store
              .dispatch("commonAction", {"data":postData ,"path":"/company/delete"})
              .then(response => {
               
                this.archiving =false;
                this.selectedForArchiveList =[];
                this.showToster({message:response.message,isError:false });
                this.getPetitioners();
                this.$modal.hide('conformArchivemodal')
                                               
                                
              })
              .catch((error)=>{
                  this.formerrors.msg =error
                //this.showToster({message:error,isError:true });
                this.archiving =false;
              })

       },

    selectForArchive(caseItem){
              this.formerrors.msg ='';

        if(this.archiving ){
         return false
       }else{
         this.archiving =false
       if(this.checkProperty(caseItem ,'selectedForArchive') && this.checkProperty(caseItem ,'status')!=false){
         if(this.selectedForArchiveList.indexOf(caseItem['_id'])<=-1){
            this.selectedForArchiveList.push(caseItem['_id'])

         }

       }else{
          this.selectedForArchiveList = _.filter( this.selectedForArchiveList ,(item)=>{
           return item !=caseItem['_id']
          })
       }

    }
    this.selectedAllForArchive =false
    if(this.users.length==this.selectedForArchiveList.length && this.selectedForArchiveList.length>0){
      this.selectedAllForArchive =true
    }
       

     },
      showSetPassword(action =false ,selectedItem=null){

         this.newPassword ='';
        this.confPassword = '';
        this.$validator.reset();
        this.selectedItem = selectedItem;
        this.setPassword =action;
        this.setPasswordErrorMsg = "";
      },

       changePassword() {
      this.$validator.validateAll().then((result) => {
         this.setPasswordErrorMsg ='';
        if (result) {
           
           let self =this;
          let postData = {
            newPassword: self.newPassword,
            currentPassword: self.confPassword,
            userId: self.selectedItem['_id'],
            //email: this.getUserData.email,
           // roleId: this.getUserRoleId,
         
          };
          ///auth/change-password,
          this.updatingPassword =true;
          this.$store.dispatch("commonAction", {"data":postData ,"path":"/auth/change-password"}).then((response) => {
              this.showToster({message:response.message,isError:false });
           
              // this.$vs.notify({ text: response.data.message, });
              this.setPassword = false;
              this.formerrors.msg = null;
              this.updatingPassword =false;
            
          }).catch((error) => {
              this.setPasswordErrorMsg = error;
              Object.assign(this.formerrors, {
                msg: error.message,
              });
              this.updatingPassword =false;
          })
        }
      });
    },
      resend(item){
      
        let obj = { "email": item['sortEmail'] ,"tenantId":''};
        if(this.$store.getters['common/getTenantId']){
          obj['tenantId'] =this.$store.getters['common/getTenantId']
        }
        
        this.$store
              .dispatch("resend", obj)
              .then(response => {
                //alert(JSON.stringify(response.data.message))
                   if (response.error) {
                  
                     this.showToster({message:response.error.message ,isError:true})
                } else {
                  this.showToster({message:response.data.message ,isError:false})
                  
                }
                
              })
              .catch((err)=>{
                this.showToster({message:err ,isError:true});

              });

      },
      changedCountry(){
            /*
            countries:[],
     states:[],
     locations:[],
     selectedCountry:null,
     selectedState:null,
     selectedCityes:[],
    */
      if( this.selectedCountry && _.has(this.selectedCountry , "id")){
          this.masterData('states');
      }
      
      },
      changedState(){
        
          this.locations =[];
          if( _.has(this.selectedState , "id")){
            this.masterData('locations');
        }
      },
    //locationId
    changedCity(){

      if( _.has(this.selectedCity , "id")){
            //this.updateTenantData.address.locationId = this.updateTenantData.address.selectedCity['id'];
            this.masterData('locations');
        }

    },
    masterData(category="countries"){

        /*
      countries:[]
      states:[],
      locations:[],
        */
      let matcher ={};
        let postData = {
      matcher: matcher,
      page:1,
      perpage: 1000,
      category: category,
      
    };
    if(category =="states"){

        matcher = { "countryId": this.selectedCountry['id']}
    }
      if(category =="locations"){

        matcher = { "stateId": this.selectedState['id']  }
    }
      postData['matcher'] = matcher;

        this.$store.dispatch("getMasterData" , postData)
        .then((res)=>{
            //countries
            
            if(category == "countries"){

                this.countries = res['list'];
                
                //alert(JSON.stringify(this.countries))
            }
            if(category =="states"){


                this.states= res['list'];
               
                
                
            }
          if(category =="locations"){
            
              this.locations= res['list'];
             
              
          }
        })
        .catch((err)=>{
            this[category] =[];

        })

    },
      getCompanyStatusList(){
        this.all_statusids =[];
         let postdata ={
        page:1,
        perpage: 1000,
        category: "company_status",
       
      };
        this.$store.dispatch("getMasterData" ,postdata)
        .then((res)=>{
          this.all_statusids = res['list'];
          this.all_statusids = _.filter(this.all_statusids ,(item)=>{
            return [1,2,3,4].indexOf(item['id'])>-1;

           });

                if(this.checkProperty(this.$route ,'query' ,'filter')){
                try{
                  let filter =this.$route['query']['filter']; this.checkProperty(this.$route ,'query' ,'filter')
                  var actual = JSON.parse(atob(filter));
                  let keys = Object.keys(actual);
                  if(this.checkProperty(keys ,'length') >0){


                    if(actual && (Object.keys(actual)).length>0 ){
                    _.forEach(actual ,(item ,key) => {
                        if(key=='matcher' ){
                          
                          if((Object.keys(item)).length>0 ){

                            if(_.has(item ,'statusIds')){
                              
                              this.selected_statusids = _.filter(this.all_statusids ,(status)=>{
                                  return item['statusIds'].indexOf(status['id'])>-1;

                            })

                            }

                            
                            
                          }
                        
                        }
                      
                        
                    
                    })
                  }
                    
                    
                  }

                }catch(e){
                  

                }
                  
              }

        })
        .catch(()=>{

        })


      },
      sortMe(sort_key=''){

      //   this.sortKeys = {
      //   'caseNo':1,
      //   'beneficiaryDetails.name':1,
      //   "typeDetails.name":1,
      //   "petitionerDetails.name":1,
      //   "updatedOn":1,
      //   "communicationDetailslength":1

      // }

      if(sort_key !=''){
          this.sortKeys[sort_key] = this.sortKeys[sort_key]==1?-1:1
          this.sortKey ={};
          this.sortKey = {"path":sort_key,"order":this.sortKeys[sort_key]};

          localStorage.setItem('company_sort_key', sort_key);
          localStorage.setItem('company_sort_value', this.sortKey[sort_key]);
          this.getPetitioners();
      }
      },
     updatePhone(item) { 
        this.isPhoneValid=true  
      if (item.isValid) {
          
       this.new_user.phoneCountryCode = {countryCode:item.countryCode,countryCallingCode:item.countryCallingCode};
       this.new_user.phone = item.nationalNumber;
       
      }
      else{
        this.isPhoneValid=false;
      }
     },
     invitePetitionPopupshow(action =true){
      this.inviting =false;
       this.new_user =  {
                name: "",
                //firstName:"",
                //lastName:"",
                adminFirstName: "",
                adminLastName:"",
                email: "",
                phoneCountryCode:{countryCode:'',countryCallingCode:''},
                roleId:50,
                phone:"",
                invite:true,
                "accountType": "Corporate"
            }
      this.invitepetitioner=action;
      this.isPhoneValid=true;
      
     },
      
      openApprovepopup(item ,status=2 ,txt=''){
        this.actionText = "Do you want to "+txt+" ?",
        this.popupbtnTxt = txt;
        this.selectedpetitioner = item;
        this.selectedStatus = status;
        this.approveConformpopUp =true;

      },
  
      getPetitioners(callFromSerch=false) {
        this.selectedAllForArchive =false;
       this.selectedForArchiveList =[]; 
        this.callFromSerch = callFromSerch;

        let matcher = {
          searchString: this.searchtxt,
          statusIds: this.final_selected_statusids,
          "countryIds": [],
			    "stateIds": [],
			    "locationIds": [],
          createdDateRange:[],
          statusList:[]
        };

        if(this.selectedarchive.length>0){

               matcher["statusList"] = this.selectedarchive.map((item)=>item._id);

     }

        //filter Country and staet and locations
        
         if(this.selectedCountry && _.has(this.selectedCountry ,"id")){
           matcher['countryIds'] = [this.selectedCountry['id']]

         }
         if(this.selectedState && _.has(this.selectedState ,"id")){
           matcher['stateIds'] = [this.selectedState['id']]

         }

         if(this.selectedCityes &&this.selectedCityes.length>0 ){
           // _.has(this.selectedCountry ,"id")
           _.forEach(this.selectedCityes,(item)=>{

              if( _.has(item ,"id")){
                  matcher['locationIds'].push(item['id']);

              }


           })
          

         }

         if (
        this.selected_createdDateRange["startDate"] &&
        this.selected_createdDateRange["startDate"] != "" &&
        this.selected_createdDateRange["endDate"] != "" &&
        this.selected_createdDateRange["endDate"]
      ) {
        matcher["createdDateRange"] = [
          this.selected_createdDateRange["startDate"],
          this.selected_createdDateRange["endDate"]
        ];
      }

        let query = {};
        query['page'] = this.page;
        query['perpage'] = this.perpage;
        query['matcher'] = matcher;
        query['sorting'] = this.sortKey;
        if(this.callFromSerch){
         
          this.users =[];
        }

      //    if(this.checkProperty(this.$route ,'query' ,'filter')){
      //   try{
      //      let filter =this.$route['query']['filter']; this.checkProperty(this.$route ,'query' ,'filter')
      //     var actual = JSON.parse(atob(filter));
      //     let keys = Object.keys(actual);
      //     if(this.checkProperty(keys ,'length') >0){


      //       if(actual && (Object.keys(actual)).length>0 ){
      //       _.forEach(actual ,(item ,key) => {
      //           if(key=='matcher' ){
      //             if((Object.keys(item)).length>0 ){
      //               query['matcher'] = item
      //             }
                
      //           }
               
      //           if(callFromSerch){
      //           if(key =='page' && item >0){
      //             query['page'] = parseInt(item)
      //             this.page = parseInt(item)
      //           }
      //           if(key =='perpage' && item >0){
      //             query['perpage'] = parseInt(item)
                  
      //             this.perpage = parseInt(item)
      //           }
      //           if(key=='sorting' ){
      //             if((Object.keys(item)).length>0 ){
      //               query['sorting'] = item
      //             }
                
      //           }
      //         }
            
      //       })
      //     }
            
            
      //     }

      //   }catch(e){
           

      //   }
        
          
      // }
      let tempObj={
        selectedCityes:this.selectedCityes,
        selectedState:this.selectedState,
        selectedCountry:this.selectedCountry,
        selectedarchive:this.selectedarchive,
        selected_statusids:this.selected_statusids,
        searchtxt:this.searchtxt,
        page:this.page,
        perpage:this.perpage,
        sortKey:this.sortKey
      };
      if (
        this.selected_createdDateRange["startDate"] &&
        this.selected_createdDateRange["startDate"] != "" &&
        this.selected_createdDateRange["endDate"] != "" &&
        this.selected_createdDateRange["endDate"]
      ) { 
        tempObj["startDate"] = moment(this.selected_createdDateRange["startDate"]).format("YYYY-MM-DD");
        tempObj["endDate"] = moment(this.selected_createdDateRange["endDate"]).format("YYYY-MM-DD");
      }
      this.setQueryString(tempObj);

      //query['matcher']["accountTypeList"]= ["Corporate"],

       
        this.updateLoading(true);
        this.$store
          .dispatch("getList",{data:query ,path:'/company/list'} )
          .then(response => {
             this.updateLoading(false);
            

             let tempList =[];
         let list = response.list
         _.forEach( list,(item) => {
            item =Object.assign(item,{ 'selectedForArchive':false});
           if(this.selectedForArchiveList.indexOf(item['_id'])>-1){
              item =Object.assign(item,{ 'selectedForArchive':true});
           }
           tempList.push(item)
           
         });
          this.users =tempList;
          this.totalCount = this.checkProperty(response, 'totalCount');
          this.totalpages = Math.ceil(response.totalCount / this.perpage);
            //alert(this.perpage);
          }).catch((err)=>{
            this.users =[];
             this.updateLoading(false);
          })
      },
      filterQueryPreSelect(callFromMounted=false){
        if(this.checkProperty(this.$route ,'query' ,'filter')){
          try{
            let filter =this.$route['query']['filter']; this.checkProperty(this.$route ,'query' ,'filter')
            var actual = JSON.parse(atob(filter));
            let keys = Object.keys(actual);
            if(this.checkProperty(keys ,'length') >0 ){
              if(_.has(actual ,'page') && this.checkProperty(actual ,'page')){                                     
                this.page = this.checkProperty(actual ,'page');
              }
              if(_.has(actual ,'perpage') && this.checkProperty(actual ,'perpage')){                                     
                this.perpage = this.checkProperty(actual ,'perpage');
              }
              if(_.has(actual ,'sortKey') && this.checkProperty(actual ,'sortKey')){                                     
                this.sortKey = this.checkProperty(actual ,'sortKey');
                if(this.sortKeys){
                  this.sortKeys[actual['sortKey']['path']] = actual['sortKey']['order']
                }
              }
              if(_.has(actual ,'selectedCountry') && this.checkProperty(actual ,'selectedCountry') ){                                     
                this.selectedCountry = this.checkProperty(actual ,'selectedCountry');
                this.changedCountry();
              }
              if(_.has(actual ,'selectedState') && this.checkProperty(actual ,'selectedState') ){                                     
                this.selectedState = this.checkProperty(actual ,'selectedState');
                this.changedState();
              }
              if(_.has(actual ,'selectedCityes') && this.checkProperty(actual ,'selectedCityes') && this.checkProperty(actual ,'selectedCityes', 'length')>0){                                     
                this.selectedCityes = this.checkProperty(actual ,'selectedCityes');
                this.changedCity();
              }
              if(_.has(actual ,'selectedarchive') && this.checkProperty(actual ,'selectedarchive') && this.checkProperty(actual ,'selectedarchive', 'length')>0){                                     
                this.selectedarchive = this.checkProperty(actual ,'selectedarchive');
              }
              if(_.has(actual ,'selected_statusids') && this.checkProperty(actual ,'selected_statusids') && this.checkProperty(actual ,'selected_statusids', 'length')>0){                                     
                this.selected_statusids = this.checkProperty(actual ,'selected_statusids');
              }
              if(_.has(actual ,'startDate') && this.checkProperty(actual ,'startDate') ){                                     
                this.selected_createdDateRange["startDate"] = this.checkProperty(actual ,'startDate');
              }
              if(_.has(actual ,'endDate') && this.checkProperty(actual ,'endDate') ){                                     
                this.selected_createdDateRange["endDate"] = this.checkProperty(actual ,'endDate');
              }
            
              if(_.has(actual ,'searchtxt') && this.checkProperty(actual ,'searchtxt') ){                                     
                this.searchtxt = this.checkProperty(actual ,'searchtxt');
              }
              this.set_filter();
            }else{
              this.set_filter();
            }
          }catch(e){
            if(callFromMounted){
              this.set_filter();
            }
          }   
        }
        else{
          if(callFromMounted){
              this.set_filter();
          }
        } 
      },
      setQueryString(obj){
        const string = JSON.stringify(obj) // convert Object to a String
        this.encodedString = btoa(string) // Base64 encode the String
        this.$route['query']['filter'] = this.encodedString;
      },
      petitionerInvite() {
        Object.assign(this.formerrors, {  msg: ''  });
        this.$validator.validateAll().then(result => {
          if (result && this.isPhoneValid) {
            this.inviting =true;
            this.$store.dispatch("commonAction", {
              data:this.new_user,
              path: "/auth/invite-petitioner",})
              .then(response => {
                this.inviting =false;
              
                if (response.error) {
                  Object.assign(this.formerrors, {
                    msg: response.error.message
                  });
                } else {

                  this.showToster({message:response.data.message,isError:false});
                  this.getPetitioners();
                }
                this.invitePetitionPopupshow(false);

                // this.$router.go('/beneficiaries');
              }).catch((err)=>{
                this.inviting =false;
                Object.assign(this.formerrors, {
                    msg: err
                  });

              })
          }
        });
      },
      
            
      set_filter: function () {
        this.$refs["filter_menu"].dropdownVisible = false;
        this.final_selected_statusids = [];
        if (this.selected_statusids.length > 0) {
          this.final_selected_statusids = [];
          for (let ind = 0; ind < this.selected_statusids.length; ind++) {
            let current_index = this.selected_statusids[ind];
            this.final_selected_statusids.push(current_index["id"]);
          }
        }
        /*
         countries:[],
     states:[],
     locations:[],
     selectedCountry:null,
     selectedState:null,
     selectedCityes:[],
        */


        this.getPetitioners(true);
      },
      clear_filter: function () {
        this.searchtxt = '';
        this.selectedarchive =[];
        this.selectedCountry =null
         this.selectedState =null;
         this.selectedCityes= [];
        this.$refs["filter_menu"].dropdownVisible = false;
        this.selected_statusids = [];
        this.final_selected_statusids = [];
         this.selected_createdDateRange["startDate"] = "";
         this.selected_createdDateRange["endDate"] = "";
      
        this.date = "";
        this.date_range = [];
         this.$router.push({ query: {} })
        this.getPetitioners();
      },
      pageNate(pageNum) {
       
        this.page = pageNum;
        this.getPetitioners(true);
      },
      
      changetPetitionerstatus( ){
        let post_data = {"companyId":this.selectedpetitioner['_id'], "statusId":this.selectedStatus };
        let sts = _.find(this.all_statusids ,{"id":this.selectedStatus});
        if(sts && _.has(sts,"name")){
          post_data['statusName'] = sts['name']

        }
        //alert(JSON.stringify(post_data));

        //post_data = Object.assign(post_data,{"petitionerId":this.selectedpetitioner['_id'] ,"statusId":this.selectedStatus})
      
          this.$store.dispatch("commonAction", {data:post_data ,"path":"/company/update-status"}).then((res) => {
              this.approveConformpopUp =false;
                 this.showToster({message:res.message,isError:false });
                this.getPetitioners();

            }).catch((error) => {
                this.showToster({message:error,isError:true });
               

            });

      },

    },
    mounted() {
      if(this.$route.params && this.$route.params.openCreatePopup ){
        this.invitePetitionPopupshow(true)
      }
       this.masterData("countries");
      this.selected_statusids = [];
      this.final_selected_statusids = [];
      this.seleted_states = [];
      this.final_selected_states = [];

      this.seleted_locations = [];
      this.final_selected_locations = [];
      

      this.sortKeys = { "createdOn":-1, "invitedByName":1, "createdByName":1, "name":1, "email":1, "phone":1, 'statusName':1, 'updatedOn':1 ,"customIdSNo":1 },
   
    this.sortKey = {"path":'createdOn' ,"order":-1};

    if(localStorage.getItem('company_sort_key') && localStorage.getItem('company_sort_value')  && localStorage.getItem('company_sort_value') >=-1 ){
       this.sortKey = {};

      this.sortKey = {"path":localStorage.getItem('company_sort_key') ,"order":parseInt(localStorage.getItem('company_sort_value'))};
      this.sortKeys[localStorage.getItem('company_sort_key')] = parseInt(localStorage.getItem('company_sort_value'));

      //alert();
      

    }
    if(localStorage.getItem('petitioner_perpage')){
        this.perpage = parseInt(localStorage.getItem('petitioner_perpage'));
    }
      this.getCompanyStatusList();
      //this.getPetitioners();
      this.filterQueryPreSelect(true);
      setTimeout(()=>{ 
                    this.isPhoneValid=true;
                   
               } ,100);
     

    },
    computed:{

      checkEditPermissions(){
        let petitionersPermessions =[3,4,5 ,50]
        if(this.checkProperty( this.getUserData ,'tenantDetails' ,'permissions')){


        if(this.checkProperty( this.getUserData['tenantDetails']['permissions'] ,'PETITIONER_COMPLETE_PROFILE')){

          petitionersPermessions = this.getUserData['tenantDetails']['permissions']['PETITIONER_COMPLETE_PROFILE'];

        }
      }
      if(petitionersPermessions.indexOf(this.getUserRoleId)>-1){
        return true;
      }else{
        return false;
      }
      },
    checkEnableSelectAll(){
      let returnVal =false;
let activeItems = _.filter(this.users ,(item)=>{
        return this.checkProperty( item ,'status') !=false
     });
     if(activeItems && this.checkProperty(activeItems ,'length')>0){
       returnVal =true;
     }
      return returnVal;
    }
  }
  };
</script>
