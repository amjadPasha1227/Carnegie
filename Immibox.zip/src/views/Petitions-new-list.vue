<template>
  <div>
    
    <div class="content-header case-search-header">
      <div class="content-header-left">
        <div class="search">
          <vs-input icon-pack="feather" icon="icon-search"
            :placeholder="beneficiaryId ==null?'Search by Case No/Beneficiary':'Search by Case No'"
            class="is-label-placeholder" v-model.lazy="searchtxt" />

        </div>
        <div class="con-select selection_search casetype" v-if="[51].indexOf(getUserRoleId) < 0">
          <multiselect @input="changedVisaTypeClear" v-model="gobalType" :options="visaTypes" :multiple="false"
            :close-on-select="true" :clear-on-select="false" :preserve-search="true" placeholder="Case Type"
            label="name" track-by="name" :preselect-first="false">

            <template slot="selection" slot-scope="{ values, isOpen }">
              <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }} Case Type(s)
                Selected</span>
              <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
            </template>
          </multiselect>
        </div>
  
        <div class="con-select selection_search petitioners"
          v-if="[3,4,5,6,7,8,9,10,11,12,13,14].indexOf(getUserRoleId)>-1 && beneficiaryId ==null && getTenantTypeId !=2">
          <multiselect @input="changedperitionersSearch()" v-model="global_selected_petitioners" :options="all_peritioners"
            :multiple="true" :hideSelected="true" :close-on-select="false" :clear-on-select="false"
            :preserve-search="true" placeholder="Petitioners" label="name" track-by="name"
            :preselect-first="false" @search-change="peritioners_search_fun">
            <template slot="selection" slot-scope="{ values, isOpen }">
              <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }} Petitioner(s)
                Selected</span>
              <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
            </template>

          </multiselect>
        </div>
        <vs-checkbox id="activeCases" @input="changeActiveType(activeCases)" class="ml-2" name="activeCases" v-model="activeCases">Active Cases
        </vs-checkbox>
      </div>


      <div class="content-header-right">
        <!--Sorting dropdown-->
        <div class="sorting_sec">
          <div class="sort_icon">
            <img src="@/assets/images/icons/sort.png" />
            <span v-if="addCls" class="loader"><img src="@/assets/images/main/loader.gif"></span>
          </div>
          <div class="soring_cnt" :class="{'hide': addCls}">
            <ul>
              <li @click="changeSorting(item)" :class="{'active': checkProperty(sortKey,'path' ) ==checkProperty(item,'path' ) , 'sort_ascending': checkProperty(sortKey,'path' ) ==checkProperty(item,'path' ) && item['order']==1 , 'sort_descending': checkProperty(sortKey,'path' ) ==checkProperty(item,'path' ) && item['order'] !=1 }" v-for="( item ,index) in sortingList">
               <!-- v-bind:class="{'sort_ascending':sortKeys['caseNo']==1, 'sort_descending':sortKeys['caseNo']!=1}" --->
                <em></em>{{ item['displayName'] }} 
              </li>
            </ul>
          </div>
        </div>
        
          <!----this.sortKey= {"path":'updatedOn',"order":-1};
   this.sortingList-->
 <!--filter dropdown-->
        <vs-dropdown vs-custom-content vs-trigger-click>
          <vs-button color="primary" class="filter-btn" type="border" icon-pack="feather" icon="icon-chevron-down"
            icon-after>
            <img src="@/assets/images/main/icon-filter.svg" /> Filters
          </vs-button>
          <vs-dropdown-menu ref="filter_menu" class="filters-content">
            <div class="filters-form-fileds">
              <div class="form-container">
                <div class="vx-row">
                  <div class="vx-col md:w-1/3 w-full con-select filters-search"  v-if="false">
                    <label class="typo__label">Title</label>
                    <vs-input icon-pack="feather" icon placeholder="Search by Case No/Beneficiary"
                      class="is-label-placeholder" v-model="filter_searchtxt" />
                  </div>

                  <div class="vx-col md:w-1/3 w-full con-select"
                    v-if="false && [3].indexOf(getUserRoleId)>-1 && this.beneficiaryId==null">
                    <label class="typo__label">Select Branch</label>
                    <multiselect  v-model="selectedBranches" :options="branchList"
                      :multiple="true" :hideSelected="true" :close-on-select="false" :clear-on-select="false"
                      :preserve-search="true" placeholder="Select Branch" label="name" track-by="name"
                      :preselect-first="false">

                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          Branches Selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>

                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Case Type</label>
                    <multiselect @input="changedVisaType" v-model="selectedVisaType" :options="visaTypes"
                      :multiple="false" :close-on-select="true" :clear-on-select="false" :preserve-search="true"
                      placeholder="Select Case Type" label="name" track-by="name" :preselect-first="false">
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }} Case
                          Type(s) Selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>

                  <!---all_subtypes---->
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Case Subtype</label>
                    <multiselect @input="changedsubtypes()" v-model="selected_subtypes"
                    :disabled="selectedVisaType==null"
                      :options="all_subtypes" :multiple="true" :hideSelected="true" :close-on-select="false"
                      :clear-on-select="false" :preserve-search="true" placeholder="Select Case Subtype" label="name"
                      track-by="name" :preselect-first="false">

                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }} Case
                          Subtype(s) Selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">State of the Case</label>
                    <multiselect  v-model="initStatusIdsFilter" @input="changedInitStatus(initStatusIdsFilter)"
                      :options="updatedInitStatus" :multiple="false" :hideSelected="false" :close-on-select="true"
                      :clear-on-select="false" :preserve-search="true" placeholder="Select State of the case" label="name"
                      track-by="name" :preselect-first="false">
                      
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          Status Selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>
                  <!-------------Select Petitioners this.all_peritioners ----------->
                  <div class="vx-col md:w-1/3 w-full con-select"
                    v-if="[3,4,5,6,7,8,9,10,11,12,13,14].indexOf(getUserRoleId)>-1 && beneficiaryId ==null && getTenantTypeId !=2">
                    <label class="typo__label">Petitioner</label>
                    <multiselect @input="changedperitioners()" v-model="selected_peritioners" :options="all_peritioners"
                      :multiple="true" :hideSelected="true" :close-on-select="false" :clear-on-select="false"
                      :preserve-search="true" placeholder="Select Petitioner" label="name" track-by="name"
                      :preselect-first="false" @search-change="peritioners_search_fun">
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          Petitioner(s) Selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>

                    </multiselect>

                  </div>
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Status</label>
                    <multiselect  v-model="selected_statusids"
                      :options="case_statusids" :multiple="true" :hideSelected="true" :close-on-select="false"
                      :clear-on-select="false" :preserve-search="true" placeholder="Select Status" label="name"
                      track-by="id" :preselect-first="false">
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          Status Selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>
                  <div class="vx-col md:w-1/3 w-full con-select"> 
                    <label class="typo__label">I-94 Expiry</label>
                    <multiselect  v-model="selectedI94Expiry" :options="I94ExpiryList"
                      :multiple="false" :close-on-select="true" :clear-on-select="false" :preserve-search="true"
                      placeholder="Select I-94 Expiry" label="name" track-by="name" :preselect-first="false">
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }} I-94 Expiry Selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Premium Processing</label>
                    <multiselect  v-model="selectedpremiumProcessing"
                      :options="premiumProcessingList" :multiple="true" :hideSelected="true" :close-on-select="false"
                      :clear-on-select="false" :preserve-search="true" placeholder="Select Premium Processing"
                      label="name" track-by="name" :preselect-first="false">

                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          Premium Processing(s) Selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>



                 
                  <!--
                  <div v-if="roleId != 6 && roleId != 7" class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Select Users</label>
                    <multiselect
                      @input="changedusers()"
                      v-model="selected_users"
                      :options="users"
                      :multiple="true" :hideSelected="true"
                      :close-on-select="false"
                      :clear-on-select="false"
                      :preserve-search="true"
                      placeholder="Select Users"
                      label="name"
                      track-by="name"
                      :preselect-first="false"
                      @search-change="user_search"
                    >
                      
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} User(s) Selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template>
                    </multiselect>
                  </div>
                  -->

                  
                  <!-------Select Beneficiars-------->
                  <!-- <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Select Beneficiars</label>
                    <multiselect ref="country_selectbox" @input="changedCountry()"  v-model="selected_country_obj" :options="countries"  :multiple="false" :close-on-select="true" :clear-on-select="false" :preserve-search="true" placeholder="Select Country" label="name" track-by="name" :preselect-first="false">
                      <template slot="selection" slot-scope="{ values, search, isOpen }"><span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">{{ values.length }} options selected</span></template>
                    </multiselect>

                  </div>-->
                  <!-------genders--------->
                  <!--<div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Select Gender</label>
                    <multiselect ref="country_selectbox" @input="changedCountry()"  v-model="selected_country_obj" :options="countries"  :multiple="false" :close-on-select="true" :clear-on-select="false" :preserve-search="true" placeholder="Select Country" label="name" track-by="name" :preselect-first="false">
                      <template slot="selection" slot-scope="{ values, search, isOpen }"><span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">{{ values.length }} options selected</span></template>
                    </multiselect>

                  </div>-->
                  <!------------maritalStatusIds---------->
                  <!-- <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Select MaritalStatus</label>
                    <multiselect ref="country_selectbox" @input="changedCountry()"  v-model="selected_country_obj" :options="countries"  :multiple="false" :close-on-select="true" :clear-on-select="false" :preserve-search="true" placeholder="Select Country" label="name" track-by="name" :preselect-first="false">
                      <template slot="selection" slot-scope="{ values, search, isOpen }"><span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">{{ values.length }} options selected</span></template>
                    </multiselect>

                  </div>-->

                  <!----------Select Country------->
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Beneficiary Country</label>
                    <multiselect ref="country_selectbox" @input="changedCountry()"
                      v-model="selected_country_obj" :options="countries" :multiple="false" :close-on-select="true"
                      :clear-on-select="false" :preserve-search="true" placeholder="Select Beneficiary Country"
                      label="name" track-by="name" :preselect-first="false">
                      <template slot="selection" slot-scope="{ values, search, isOpen }">
                        <span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">{{ values.length }}
                          options selected</span>
                      </template>
                    </multiselect>
                  </div>

                  <!--------Select States----->
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Beneficiary State</label>
                    <multiselect v-bind:disabled="country_code <= 0" @input="changedState()"
                      v-model="seleted_states" :options="all_states" :multiple="false" :close-on-select="true"
                      :clear-on-select="false" :preserve-search="true" placeholder="Select Beneficiary State"
                      label="name" track-by="name" :preselect-first="false">
                      <!-- <template slot="selection" slot-scope="{ values, search, isOpen }">
                        <span
                          class="multiselect__single"
                          v-if="values.length &amp;&amp; !isOpen"
                        >{{ values.length }} options selected</span>
                      </template> -->
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          Status Selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>
                  <!---- seleted_locations --->
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Beneficiary Location</label>
                    <multiselect 
                      v-bind:disabled="final_selected_states.length <= 0" v-model="seleted_locations"
                      :options="all_locations" :multiple="true" :hideSelected="true" :close-on-select="false"
                      :clear-on-select="false" :preserve-search="true" placeholder="Select Beneficiary Location"
                      label="name" track-by="name" :preselect-first="false">
                      <!-- <template slot="selection" slot-scope="{ values, search, isOpen }">
                        <span
                          class="multiselect__single"
                          v-if="values.length &amp;&amp; !isOpen"
                        >{{ values.length }} options selected</span>
                      </template> -->
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          Location(s) Selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>

                  <!------- premiumProcessingList:[true ,false],
    selectedpremiumProcessing:[{name:'Enabled' ,_id:true },{name:'Disabled' ,_id:false }],-->


                  

                  <div class="vx-col md:w-1/3 w-full con-select" v-if="[3,4].indexOf(getUserRoleId)>-1 && false">
                    <label class="typo__label">Deleted</label>
                    <multiselect  v-model="selectedarchive"
                      :options="[{ 'name': 'Yes', '_id': false }, { 'name':'No' ,'_id':true}]" :multiple="true"
                      :hideSelected="true" :close-on-select="false" :clear-on-select="false" :preserve-search="true"
                      placeholder="Select" label="name" track-by="name" :preselect-first="false">

                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          Selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>

                  <!--Created Date--->
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Created Date</label>
                    <date-range-picker  :maxDate="new Date()" :autoApply="autoApply"
                      :ranges="false" :opens="'left'" v-model="selected_createdDateRange"></date-range-picker>
                  </div>
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Deadline Date</label>

                    <date-range-picker  :autoApply="autoApply" :ranges="false"
                      :opens="'left'" v-model="selected_deadLineDateRange"></date-range-picker>
                  </div>
                </div>
              </div>
            </div>
            <div class="filters-status">
              <div class="left-buttons"></div>
              <div class="right-buttons">
                <vs-button color="success" class="save" type="filled" v-on:click="set_filter()">Apply</vs-button>
                <vs-button color="dark" class="cancel" type="filled" v-on:click="clear_filter($event)">Clear</vs-button>
              </div>
            </div>
          </vs-dropdown-menu>
        </vs-dropdown>



        <vs-button color="primary" type="border" class="light-blue-btn"
          @click="callFromCapCaseCreation=false;selectedBeneficiary =null ; selectedPetitioner=null;addNewCase(true);permDocRequired=false;Doc140Required=false;uploading=false;prefillJobDetailsError=''"
          v-if="checkCaseCreatePermisions">

          New Case <span>
            <img class="add-user-icon ml-2" src="@/assets/images/main/add-user.svg">
          </span></vs-button>


        <!-- <vs-button
        :disabled="archiving"
          color="primary"
          type="border"
          class="light-blue-btn"
          @click="$modal.show('conformArchivemodal');"
          v-if="checkProperty(selectedForArchiveList ,'length')>0 &&[3,4].indexOf(getUserRoleId) > -1"
        >
        
        Delete <span>
          <img class="add-user-icon ml-2" src="@/assets/images/main/add-user.svg">
        </span></vs-button> -->
        <!-- end -->
      </div>
    </div>

    <div class="accordian-table custom-table no-wrap relative">

      <NoDataFound ref="NoDataFoundRef" :loading="isListLoading" v-if="petitioners.length == 0" content=""
        :heading="callFromSerch?'No Results Found':'No Cases Found'" type='petitions' />


     <div v-if="petitioners.length >  0">
        <div class="table_actions">
          <vs-button :disabled="archiving" color="primary" type="border" class="primary_btn delete_btn"
            @click="$modal.show('conformArchivemodal');internalStatusDetails=null;internalComments='';permDeleteDocs=[];internalErrMsg = '';filterInternalStatus()"
            v-if="checkProperty(selectedForArchiveList ,'length')>0 &&[3,4,50].indexOf(getUserRoleId) > -1">
            
            {{internalStatusTitle}}</vs-button>
        </div>
        <vs-table :data="petitioners">
          <!--
          //"path": clientName "createdOn", updatedOn, createdByName, typeName, subTypeName, caseNo, statusName
          --->
          <template v-if="petitioners.length > 0" slot="thead">
            <vs-th class="mw-280">
              <vs-checkbox :disabled="archiving" v-if="([3,4,50].indexOf(getUserRoleId) > -1 && checkEnableSelectAll && [3,4].indexOf(checkProperty(checkHeaderCheckBox,'id'))<=-1)"
                @change="selectAllforArchive()" :name="'selecteAll'" v-model="selectedAllForArchive" class="">
              </vs-checkbox>

              <a @click="sortMe('caseNo')"
                v-bind:class="{'sort_ascending':sortKeys['caseNo']==1, 'sort_descending':sortKeys['caseNo']!=1}">Case
                No </a>            
            </vs-th> 
            <vs-th v-if="[51].indexOf(getUserRoleId)<=-1">


              <a @click="sortMe('beneficiaryName')"
                v-bind:class="{'sort_ascending':sortKeys['beneficiaryName']==1, 'sort_descending':sortKeys['beneficiaryName']!=1}">Beneficiary</a>

            </vs-th>
            <vs-th> <a @click="sortMe('typeName')"
                v-bind:class="{'sort_ascending':sortKeys['typeName']==1, 'sort_descending':sortKeys['typeName']!=1}">Case
                Type</a></vs-th>
            <vs-th v-if="[50].indexOf(getUserRoleId) <= -1 && beneficiaryId ==null && getTenantTypeId !=2"><a
                @click="sortMe('createdByName')"
                v-bind:class="{'sort_ascending':sortKeys['createdByName']==1, 'sort_descending':sortKeys['createdByName']!=1}">Petitioner</a>
            </vs-th>
            <vs-th>


              <a @click="sortMe('clientName')"
                v-bind:class="{'sort_ascending':sortKeys['clientName']==1, 'sort_descending':sortKeys['clientName']!=1}">Client</a>
            </vs-th>

            <vs-th> <a @click="sortMe('updatedOn')"
                v-bind:class="{'sort_ascending':sortKeys['updatedOn']==1, 'sort_descending':sortKeys['updatedOn']!=1}">
                Last Updated</a></vs-th>

            <vs-th>
              <a @click="sortMe('statusName')"
                v-bind:class="{'sort_ascending':sortKeys['statusName']==1, 'sort_descending':sortKeys['statusName']!=1}">
                Status
              </a>
            </vs-th>
          </template>

          <template slot-scope="{ data }">
            <vs-tr :data="petition" :key="petition.index" v-for="petition in data" class="vs-table--tr">
              <vs-td>
                <vs-checkbox v-if="([3,4,50].indexOf(getUserRoleId) > - 1 && checkProperty(petition ,'status')!=false && [3,4].indexOf(checkProperty(petition,'intStatusDetails','id'))<=-1)"
                  @change="selectForArchive(petition)" :name="'selected_'+petition.index"
                  v-model="petition.selectedForArchive" class=""></vs-checkbox>

               <template v-if="isRfe ||  checkProperty(petition,'typeDetails','id')==9 ||   checkProperty(petition,'rfeCase')==9 ">
                <router-link :to="{
                      name: 'rfe-petition-details',
                      params: { itemId: petition._id },
                       query: {'filter':encodedString}
                    }">{{ petition.caseNo }}</router-link>
              </template>
                <template v-else-if="[51].indexOf(getUserRoleId)>-1 && !checkProperty(petition ,'questionnaireFilled')">
                  <template v-if="checkProperty(petition,'subTypeDetails','id')!=15">    
                    <router-link :to="{
                    name: 'questionnaire',
                    params: { itemId: petition._id },
                    query: {'filter':encodedString}
                  }">{{ petition.caseNo }} </router-link>
                  </template>
                  <template v-else>
                    <router-link :to="{
                    name: 'perm-questionnaire',
                    params: { itemId: petition._id },
                    query: {'filter':encodedString}
                  }">{{ petition.caseNo }}</router-link>
                  </template>
                </template>
                  <template v-else>
                    <template v-if="checkProperty(petition,'subTypeDetails','id')==15">
                      <router-link :to="{
                        name: 'gc-employment-details',
                        params: { itemId: petition._id },
                        query: {'filter':encodedString}
                      }">{{ petition.caseNo }}</router-link>
                    </template>
                    <template v-else>
                      <router-link :to="{
                        name: 'petition-details',
                        params: { itemId: petition._id },
                        query: {'filter':encodedString}
                      }">{{ petition.caseNo }}</router-link>
                    </template>
                  </template>
                  
                <div class="IB_tooltip premium_tooltip" v-if="checkProperty( petition, 'premiumProcessing')">
                  <span>P</span>
                  <div class="tooltip_cnt">
                    <p>Premium Processing</p>
                  </div>
                </div>


              </vs-td>
              <vs-td v-if="[51].indexOf(getUserRoleId)<=-1">
                <span class="cursor-pointer" v-if="[51].indexOf(getUserRoleId)<=-1" @click="petitionlink(petition)">{{
                  checkProperty(petition ,'beneficiaryDetails' ,'name' ) }} </span>
              </vs-td>

              <vs-td class="td_label">
                <div class="cursor-pointer" @click="petitionlink(petition)">
                  {{ checkProperty(petition ,'typeDetails','name') }} <br />
                  <small> {{ checkProperty(petition ,'subTypeDetails','name') }} </small>
                </div>
              </vs-td>
              <vs-td v-if="[50].indexOf(getUserRoleId) <= -1 && beneficiaryId ==null &&  getTenantTypeId !=2"
                class="content_ellipsis">
                <span class="cursor-pointer" @click="petitionlink(petition)">{{
                  checkProperty(petition,'companyDetails','name') }}</span>
              </vs-td>
              <vs-td class="content_ellipsis"><span class="cursor-pointer" @click="petitionlink(petition)"
                  v-if="checkProperty(petition ,'clientInfo' ,'name')"> {{petition.clientInfo.name}} </span></vs-td>
              <vs-td>
                <span class="cursor-pointer" @click="petitionlink(petition)">
                  {{ petition.updatedOn | formatDate }}
                  <!--<a  v-if="petition.lcaId==null && currentuserRole ==6"  @click="goto(petition._id )"  class="btn btn-brown" > 
                             Request LCA </a>
                             -->
                </span>
              </vs-td>

              <vs-td v-if="
                currentuserRole == 7 &&
                 petition.questionnaireFilled &&
                  petition.questionnaireSent && petition.statusId == 1
              ">
                <router-link :to="{
                  name:'questionnaire',
                  params: { itemId: petition._id }
                }">
                  <button class="btn btn-brown">
                    <span class="cursor-pointer">Update Questionnaire</span>
                  </button>
                </router-link>
              </vs-td>
              <vs-td v-else >



                <span :statusId="checkProperty(petition ,'statusDetails','id')" class="statusspan cursor-pointer" @click="petitionlink(petition)"
                 v-bind:class="{[getCaseColors(checkProperty(petition ,'statusDetails','id'))]:true }">
                 {{checkProperty(petition,'statusDetails','name') }}
                </span>
              </vs-td>



            </vs-tr>
          </template>
        </vs-table>

        <div class="table_footer">


          <div class="vx-col  con-select pages_select" v-if="petitioners.length > 0">
            <label class="typo__label">Per Page</label>
            <multiselect @input="changeperPage()" v-model="perpage" :options="perPeges" :multiple="false"
              :close-on-select="true" :clear-on-select="false" :preserve-search="true" placeholder="Per Page"
              :preselect-first="true">

            </multiselect>
            <span class="totla_list_count" v-if="totalCount">Total <em>{{totalCount}}</em></span>
          </div>

          <paginate v-if="petitioners.length > 0" v-model="page" :page-count="totalpages" :page-range="3"
            :margin-pages="2" :click-handler="pageNate"
            prev-class="vs-pagination--buttons btn-prev-pagination vs-pagination--button-prev"
            next-class="vs-pagination--buttons btn-next-pagination vs-pagination--button-next" :prev-text="'<i></i>'"
            :next-text="'<i></i>'" :container-class="'pagination vs-pagination--nav'" :page-class="'page-item'">
          </paginate>
        </div>
        <vs-popup class="holamundo main-popup" title="Questionnaire" :active.sync="SendQuestionnaire">
          <div class="media-header">
            <img src="@/assets/images/main/avatar2.svg" />
            <div class="media-content">
              <h3>{{ selecteduser.userName }}</h3>
              <p>{{ selecteduser.email }}</p>
            </div>
          </div>
          <div class="form-container">
            <div class="vx-row">
              <div class="vx-col w-full">
                <vs-input class="w-full" v-model="selecteduser.typeName" disabled="true" icon-pack="IntakePortal"
                  icon-after icon="IP-disabled" label="Case Type" />
              </div>
              <div class="vx-col w-full">
                <!-- <vs-textarea class="w-full" v-model="selecteduser.instructions" label="Instructions" /> -->
                <ckeditor  class="w-full" v-model="selecteduser.instructions" label="Instructions"  :editor="editor" :config="editorConfig"></ckeditor>

              </div>
            </div>
          </div>
          <div class="popup-footer">
            <vs-button color="dark" @click="SendQuestionnaire = false" class="cancel" type="filled">Cancel</vs-button>
            <vs-button color="success" @click="SendQuestionnaireUser" class="save" type="filled">Send</vs-button>
          </div>
        </vs-popup>
        <vs-popup class="holamundo success-popups" title="Your registration is complete."
          :active.sync="SuccessQuestionnaire">
          <figure>
            <img src="@/assets/images/main/icon-note.svg" alt="login" class="mx-auto" />
          </figure>
          <h2 class="title">Questionnaire has been sent to {{ selecteduser.userName }}</h2>
          <p>
            You will be notified once the beneficiary completes the
            questionnaire.
          </p>
        </vs-popup>
      </div>
    </div>

    <vs-popup class="holamundo main-popup" title="Invite Customer" :active.sync="invitepetitioner">

      <addBenewPet :visatype="visatype" :visasubtype="visasubtype"  @closenewPetPopup="closenewPetPopup" v-if="invitepetitioner" />
    </vs-popup>
   
    <vs-popup class="holamundo main-popup" :class="{'openedNewpetpopup':invitepetitioner}" :title="[2].indexOf(checkProperty(visatype,'id'))>-1?'Add Dependent':'Add Beneficiary'"
      :active.sync="AddBeneficiary">
      <addBeneficiary ref="add_ben" @closeAddBenPopUp="closeAddBenPopUp" @fileNewCase="fileNewCase" :visatype="visatype" :visasubtype="visasubtype" v-if="AddBeneficiary"
        :petitioner="selectedPetitioner" @openAddpetPopUp="openAddpetPopUp" />
    </vs-popup>
    <vs-popup
      class="Change_petition_wrap"
      title="Create Case Confirmation"
      :active.sync="classificationpopup"
    >
      <div class="Change_petition">
        <div class="form-container py-0">
          <div class="vx-row">
            <div class="vx-col w-full">
              <p class="text-center p-0">{{i140CreationMessage }}</p>
            </div>
          </div>
        </div>
      </div>
      <div class="popup-footer">
          <vs-button color="dark" @click="classificationpopup=false ;formerrors.msg='';" class="cancel" type="filled">No
          </vs-button>
          <vs-button color="success" :disabled=" newPetitionFormSubmited || !enableSubmitBtn" @click="classificationpopup =false ;createNewPetition('' ,true)"
            class="save" type="filled">Yes</vs-button>
        </div>
      <!-- <div class="actions_footer">
        <button class="btn active-green ml-0" @click="classificationpopup =false ;createNewPetition('' ,true)"> Yes</button>
      </div> -->
    </vs-popup>
  
    <modal
        name="newCaseCreationModal"
        classes="v-modal-sec"
        :min-width="200"
        :min-height="200"
        :scrollable="true"
        :reset="true"
        width="750px"
        height="auto"
        >
        <div class="v-modal">
        <div class="popup-header fromDetailsPage"> 
        <h2 class="popup-title">
          New Case

        </h2>
        <span @click="$modal.hide('newCaseCreationModal');usciscUpdateStatusError='';NewPetition=false">
          <em class="material-icons">close</em>
        </span>
        </div>
        <form @submit.prevent data-vv-scope="newpetitionform" >
        <div class="form-container errorScroll">
           <div class="vx-row" @click="formerrors.msg='' ;permDocFormatError='';pwdDocFormatError=''"> <!--@keyup="formerrors.msg=''" @click="formerrors.msg=''" -->


            <template>
              <template v-if="callFromCapCaseCreation == false">
              <div class="vx-col " :class="{'w-full':getTenantTypeId ==2  ,'w-1/2':!( getTenantTypeId ==2 )}">
                <div class="form_group">
                  <div class="con-select w-full select-large">
                    <label for="" class="form_label">Case Type<em>*</em></label>
                    <multiselect name="visatype" data-vv-as="Case Type" v-validate="'required'" v-model="visatype"
                      :show-labels="false" track-by="id" label="name" placeholder="Select Case Type"
                      :options="activeVisatypes" :searchable="true" :allow-empty="false" @input="getvisasubtypes">
                    </multiselect>
                  </div>
                  <span class="text-danger text-sm" v-show="errors.has('newpetitionform.visatype')">{{
                    errors.first("newpetitionform.visatype") }}</span>
                </div>
              </div>

              <div class="vx-col " :class="{'w-full':getTenantTypeId ==2 ,'w-1/2':getTenantTypeId !=2}" >
                <div class="form_group">
                  <div class="con-select w-full select-large">
                    <label for="" class="form_label">Case Subtype<em>*</em></label>
                    <multiselect name="visasubtype" data-vv-as="Case Subtype" v-validate="'required'"
                      v-model="visasubtype" :show-labels="false" track-by="id" label="name"
                      placeholder="Select Case Subtype" :options="visasubtypes" :searchable="true" :allow-empty="false"
                      @input="checkBenPermStatus">
                    </multiselect>
                    <!-- formerrors.msg=''; -->
                  </div>
                  <span class="text-danger text-sm" v-show="errors.has('newpetitionform.visasubtype')">{{
                    errors.first("newpetitionform.visasubtype") }}</span>
                </div>
              </div>
              </template>
              <template v-if="callFromCapCaseCreation">
              <div class="vx-col " :class="{'w-full':getTenantTypeId ==2 || [2].indexOf(checkProperty(visatype,'id')) >-1,'w-1/2':!( getTenantTypeId ==2 || [2].indexOf(checkProperty(visatype,'id')) >-1)}">
                <div class="form_group">
                  <div class="con-select w-full select-large">
                    <label for="" class="form_label">Case Type <em>*</em></label>
                    <multiselect name="visatype" data-vv-as="Case Type" v-validate="'required'" v-model="visatype"
                      :show-labels="false" track-by="id" label="name" placeholder="Select Case Type"
                      :options="capActiveVisatype" :searchable="true" :allow-empty="false" @input="getvisasubtypes" :disabled="callFromCapCaseCreation">
                    </multiselect>
                  </div>
                  <span class="text-danger text-sm" v-show="errors.has('newpetitionform.visatype')">{{
                    errors.first("newpetitionform.visatype") }}</span>
                </div>
              </div>

              <div class="vx-col " :class="{'w-full':getTenantTypeId ==2 ,'w-1/2':getTenantTypeId !=2 }"  v-if=" [9].indexOf(checkProperty(visatype,'id')) <=-1" >
                <div class="form_group">
                  <div class="con-select w-full select-large">
                    <label for="" class="form_label">Case Subtype<em>*</em></label>
                    <multiselect name="visasubtype" data-vv-as="Case Subtype" v-validate="'required'"
                      v-model="visasubtype" :show-labels="false" track-by="id" label="name"
                      placeholder="Select Case Subtype" :options="capvisasubtypes" :searchable="true" :allow-empty="false"
                      @input="checkBenPermStatus" >
                    </multiselect>
                    <!-- formerrors.msg=''; -->
                  </div>
                  <span class="text-danger text-sm" v-show="errors.has('newpetitionform.visasubtype')">{{
                    errors.first("newpetitionform.visasubtype") }}</span>
                </div>
              </div>
              </template>
              <div class="vx-col w-full pp-col" v-if="[2,9,10].indexOf(checkProperty(visatype,'id')) <=-1 && (checkProperty(visasubtype,'id')!=15)">
                <vs-checkbox id="premium" name="premiumProcessing" v-model="premiumProcessing">Premium Processing
                </vs-checkbox>

                <!-- <span class="text-danger text-sm"  v-show="errors.has('finalDeterminationFromDOL')">{{ errors.first("finalDeterminationFromDOL") }}</span> -->

              </div>

              <div  class="vx-col  w-full">
                <div class="form_group">
                 
                  <div class="con-select w-full select-large">
                    <label for="" class="form_label">Branch<em>*</em></label>
                    <multiselect name="branch" data-vv-as="Branch" v-validate="'required'" v-model="selectedBranch" :show-labels="false"
                      track-by="_id" label="name" placeholder="Select Branch" :options="branchList" :searchable="true"
                      :allow-empty="false" :multiple="false" :disabled="(branchList.length==1 &&  checkProperty(selectedBranch ,'_id') !='')||disableOffice || callFromCapCaseCreation"
                      @input="formerrors.msg=''">
                    </multiselect>
                  </div>
                  <span class="text-danger text-sm" v-show="errors.has('newpetitionform.branch')">{{
                    errors.first("newpetitionform.branch") }}</span>
                </div>
              </div>
              
            </template>
            

            <template v-if="beneficiaryId ==null">
              <template v-if="([3,4,5,6,7,8,50].indexOf(getUserRoleId)>-1 && getTenantTypeId !=2 )">
                <template v-if="[2,10].indexOf(checkProperty(visatype,'id')) >-1 && [50].indexOf(getUserRoleId)<=-1">
                  <div class="vx-col w-full"  >
                    <div class="custom-radio custom-radio_btns mb-4" >  
                    
                      <vs-radio :name="'isPetitionerisPetitioner'" class="mr-6" :class="{'active':isPetitioner==true}"  v-model="isPetitioner" @input="selectedBeneficiary=null;selectedPetitioner=null;getbeneficiaryMasterDataList();" :vs-value="true"  >Petitioner</vs-radio>
                      <vs-radio :name="'isPetitionerisPetitioner'" v-model="isPetitioner" :class="{'active':isPetitioner==false}"  :vs-value="false" @input="getbeneficiaryMasterDataList();selectedBeneficiary=null" >Individual</vs-radio>
                    </div> 
                  </div>
                  <!-- @input="getIndividualList(true)" -->
           
                </template>
                <div class="vx-col w-1/2" v-if="([3,4,5,6,7,8].indexOf(getUserRoleId)>-1 &&
                 ([2,10].indexOf(checkProperty(visatype,'id')) <=-1 || ([2,10].indexOf(checkProperty(visatype,'id')) >-1 && isPetitioner )))">
                  <div class="form_group">
                    
                    <div class="con-select w-full select-large">
                      <label class="form_label">Select Petitioner<em v-if=" ( [2,10].indexOf(checkProperty(visatype,'id'))>-1 && isPetitioner) || ([2,10].indexOf(checkProperty(visatype,'id'))<=-1)">*</em></label>                       
                      <multiselect v-model="selectedPetitioner" :options="petitionersList" :multiple="false"
                        :hideSelected="false" :close-on-select="true" :clear-on-select="false" :preserve-search="true"
                        :select-label="'Search Petitioner'" placeholder="Select Petitioner" label="name" track-by="name"
                        :preselect-first="false" data-vv-as="Petitioner" v-validate="( [2,10].indexOf(checkProperty(visatype,'id'))>-1 && isPetitioner) || ([2,10].indexOf(checkProperty(visatype,'id'))<=-1)?'required':''"
                        tag-placeholder="Invite Petitioner" :taggable="false" @tag="addNewPet" :searchable="true"
                        @search-change="searchPet" @input="petitionerUpdated" name="Petitioner" :disabled="callFromCapCaseCreation" 
                        >
                        
                        <template slot="selection" slot-scope="{ values, isOpen }">
                          <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                            options selected</span>
                          <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                        </template>
                      </multiselect>
                    </div>
                    <span class="text-danger text-sm" v-show="errors.has('newpetitionform.Petitioner')">{{
                      errors.first("newpetitionform.Petitioner") }}</span>
                  </div>
                  <p v-if="checkPetInvitePermisions && callFromCapCaseCreation == false" class="createnew marb15">Not found?<span @click="addNewPet()">Invite
                      Customer</span> </p>
                </div>

                <div class="vx-col w-1/2" :class="{'w-full':[50 ].indexOf(getUserRoleId)>-1 || ([2,10].indexOf(checkProperty(visatype,'id')) >-1 && (isPetitioner == false || isPetitioner == 'false') ) }"
                  v-if="([3,4,5,6,7,8,50 ].indexOf(getUserRoleId)>-1  )">
                  <div class="form_group">
                    <div class="con-select w-full select-large">
                      <label class="form_label">Select {{[2].indexOf(checkProperty(visatype,'id')) >-1?'Beneficiary':'Beneficiary'}}<em>*</em></label>
                      <multiselect v-model="selectedBeneficiary" :options="beneficiaryMasterDataList" :multiple="false"
                        :hideSelected="false" :close-on-select="true" :clear-on-select="false" :preserve-search="true"
                        :select-label="[2].indexOf(checkProperty(visatype,'id')) >-1?'Search Beneficiary ':'Search Beneficiary'" 
                        :placeholder="[2].indexOf(checkProperty(visatype,'id')) >-1?'Select Beneficiary':'Select Beneficiary'" label="name"
                        track-by="name" :preselect-first="false"
                         :data-vv-as="[2].indexOf(checkProperty(visatype,'id')) >-1?'Beneficiary':'Beneficiary'"
                          v-validate="'required'"
                        :searchable="true" @search-change="getbeneficiaryMasterDataList" name="beneficiary"
                        @input="upDateBenef" :tag-placeholder="[2].indexOf(checkProperty(visatype,'id')) >-1?'Add New Beneficiary ':'Add New Beneficiary'" :taggable="false"
                        @tag="addNewBenFromTag"
                        :disabled="[2,10].indexOf(checkProperty(visatype,'id'))<=-1 && (!checkProperty(selectedPetitioner ,'_id') && [50 ].indexOf(getUserRoleId)<=-1 ) || callFromCapCaseCreation">

                        <template slot="selection" slot-scope="{ values, isOpen }">
                          <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                            options selected</span>
                          <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                        </template>
                      </multiselect>
                    </div>

                    <span class="text-danger text-sm" v-show="errors.has('newpetitionform.beneficiary')">{{
                      errors.first("newpetitionform.beneficiary") }}</span>

                  </div>
                
                  <p v-if="([2].indexOf(checkProperty(visatype,'id')) >-1) || (selectedPetitioner && checkBeneficaryInvitePermisions && callFromCapCaseCreation == false)" class="createnew marb15"
                    >Not found? <span @click="AddBeneficiary =true;selectedBeneficiary=null">
                      <template v-if="[2].indexOf(checkProperty(visatype,'id')) >-1">Invite Beneficiary</template>
                      <template v-else>Invite Beneficiary</template>
                    </span>
                  </p>
                </div>
              </template>

              <template v-else-if=" getTenantTypeId ==2">
                <div class="vx-col " :class="{'w-full':getTenantTypeId ==2 ,'w-1/2':getTenantTypeId !=2}">
                  <div class="form_group">
                    <div class="con-select w-full select-large">
                      <label class="form_label">Select Beneficiary<em>*</em></label>
                      <multiselect v-model="selectedBeneficiary" :options="beneficiaryMasterDataList" :multiple="false"
                        :hideSelected="false" :close-on-select="true" :clear-on-select="false" :preserve-search="true"
                        :select-label="'Search Beneficiary'" placeholder="Select Beneficiary" label="name"
                        track-by="name" :preselect-first="false" data-vv-as="Beneficiary" v-validate="'required'"
                        :searchable="true" @search-change="getbeneficiaryMasterDataList" name="beneficiary"
                        @input="upDateBenef" tag-placeholder="Add New Beneficiary" :taggable="false"
                        @tag="addNewBenFromTag">

                        <template slot="selection" slot-scope="{ values, isOpen }">
                          <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                            options selected</span>
                          <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                        </template>
                      </multiselect>
                    </div>

                    <span class="text-danger text-sm" v-show="errors.has('newpetitionform.beneficiary')">{{
                      errors.first("newpetitionform.beneficiary") }}</span>

                  </div>
                  <p class="createnew">Not found?<span @click="AddBeneficiary =true;selectedBeneficiary=null">Invite
                      Beneficiary</span> </p>
                </div>
              </template>
            </template>
              
              <template v-if="(selectedBeneficiary || beneficiaryId) && checkProperty(visatype,'id')==3 && checkProperty(visasubtype,'id')==16 ">
                <selectField :listContainsId="false" :display="true" :wrapclass="'md:w-1/2 mt-5'" :formscope="'newpetitionform'" :required="true"  cid="classification"   :optionslist="classificationList" v-model="classification" label="Classification"  fieldName="classification" placeHolder="Classification"   /> 
                <selectField  :display="true" :wrapclass="'md:w-1/2 mt-5'" :formscope="'newpetitionform'" :required="true"  cid="category"   :optionslist="categoryList" v-model="category" label="Category"  fieldName="category" placeHolder="Category"   /> 
              </template>
              <template v-if="Doc140Required && (selectedBeneficiary || beneficiaryId) && checkProperty(visatype,'id')==3 && checkProperty(visasubtype,'id')==17 ">
                  <div class="vx-col w-full" @click="value = []">
                      <div class="form_group file_group">
                        <div class="vs-component marb20">
                          <label class="form_label">I-140 Documents<em>*</em></label>
                          <div class="relative"> 
                          <file-upload
                            v-model="value"
                            class="file-upload-input upload_file justify-center"
                            :accept="allDocEntity"
                            :name="'documents'"
                            :multiple="true"
                            
                            :hideSelected="true"
                            @input="upload(value , '140Documents')"
                          >
                            <img
                              class="file-icon"
                              src="@/assets/images/main/file-upload.svg"
                            />
                            Upload 
                          </file-upload>
                          <span  v-if="uploading" class="loader"   ><img src="@/assets/images/main/loader.gif"   /></span>
                          </div>
                          <input type="hidden" :name="'140Documents'" v-validate="'required'"  data-vv-as="140 Documents"  v-model="Dol140Docs">
                          <span class="text-danger text-sm" v-show="errors.has('newpetitionform.140Documents')">*I-140 Documents are required</span>
                      
                        </div>
                        

                        <ul class="uploaded-list note_uploads">
                          <template v-for="(item, index) in Dol140Docs">
                            <vs-chip
                            @click="remove(item, Dol140Docs, index)"
                              :key="index"
                              closable
                            >
                            {{ item.name }}
                            </vs-chip>
                          </template>
                        </ul>
                      </div>
                  </div>
              </template>
            
            
              <template v-if="permDocRequired && (selectedBeneficiary || beneficiaryId) && checkProperty(visatype,'id')==3 && checkProperty(visasubtype,'id')==16 ">
                <div class="vx-col w-full" @click="value = []">
                <div class="form_group file_group">
                  <div class="vs-component marb20">
                   <label class="form_label">PERM Documents<em>*</em></label>
                    <div class="relative">
                   <file-upload
                      v-model="value"
                      class="file-upload-input upload_file justify-center"
                      :accept="allDocEntity"
                      :name="'documents'"
                      :multiple="true"
                      
                      :hideSelected="true"
                      @input="upload(value , 'permDocuments')"
                    >
                      <img
                        class="file-icon"
                        src="@/assets/images/main/file-upload.svg"
                      />
                      Upload 
                    </file-upload>
                    <span  v-if="uploading" class="loader"   ><img src="@/assets/images/main/loader.gif"   /></span>
                    </div>
                    <!---
                      
                    <input type="hidden" v-model="newTask.documents"  data-vv-as="Documents"  v-validate="'required'" name="tdocs">
                    <span  class="text-danger text-sm" v-show="errors.has('tdocs')"   >{{ errors.first('tdocs') }}</span >
                    -->
                    <input type="hidden" :name="'permDocuments'" v-validate="'required'"  data-vv-as="PERM Documents"  v-model="permDolDocs">
                    <span v-if="permDocFormatError" class="text-danger text-sm" >{{permDocFormatError}}</span>
                    <span v-else class="text-danger text-sm" v-show="errors.has('newpetitionform.permDocuments')">*PERM Documents are required</span>
                
                  </div>
                 

                  <ul class="uploaded-list note_uploads">
                    <template v-for="(item, index) in permDolDocs">
                      <vs-chip
                      @click="skillTextError=false;resetPermData(true);remove(item, permDolDocs, index)"
                        :key="index"
                        closable
                      >
                      {{ item.name }}
                      </vs-chip>
                    </template>
                  </ul>
                </div>
                </div>

                <!----PERM JOB DETAILS-->

                <div class="form-container alt-rows-bg perm_creation">
                <div class="vx-row">

                  <immiInput :disabled="permDocPreFilledKyes.indexOf('jobTitle')>-1" :display="true" :wrapclass="'vx-col md:w-1/2'" :required="true" :fieldsArray="[]"
                    cid="permjobTitle" formscope="newpetitionform" v-model="permDetails['jobTitle']" fieldName="prm-jobTitle"
                    label="Job Title" placeHolder="Job Title" :maxLength="25" /> 

                  <immiInput :disabled="permDocPreFilledKyes.indexOf('hoursPerWeek')>-1" :onlyNumbers="true" @input="changedHoursPerWeek" :wrapclass="'vx-col md:w-1/2'" :display="true" cid="permhoursPerWeek"
                    :formscope="'newpetitionform'" v-model="permDetails.hoursPerWeek" :required="true" fieldName="perm-hoursPerWeek"
                    label="Hours per Week" placeHolder="Hours per Week" :maxLength="3" />
                  <immiInput :disabled="permDocPreFilledKyes.indexOf('wageRate')>-1" :onlyNumbers="true" :wrapclass="'vx-col md:w-1/2'" :display="true" cid="permwageRate"
                    :formscope="'newpetitionform'" v-model="permDetails.wageRate" :required="true" fieldName="wageRate"
                    label=" Wage Rate" placeHolder="Wage Rate" :maxLength="10" />
                  <selectField :isDisabled="permDocPreFilledKyes.indexOf('payFrequency')>-1"  :listContainsId="false" :wrapclass="'vx-col md:w-1/2'" :display="true" :required="true"
                    :formscope="'newpetitionform'" cid="permofferpayFrequency" :optionslist="payFrequencyList"
                    v-model="permDetails.payFrequency" fieldName="offerpayFrequency" label="Pay Frequency"
                    placeHolder="Pay Frequency" />
                  <selectField :isDisabled="permDocPreFilledKyes.indexOf('socDetails')>-1" :showOptionItemStatus="true"  :wrapclass="'md:w-1/2'" :required="true" cid="socCode" :formscope="'newpetitionform'"
                    :optionslist="masterSocList" v-model="permDetails.socDetails" @input="updatesocCode" fieldName="socCod"
                    label="SOC Code" placeHolder="SOC Code " />
                    
                    
                  <selectField :isDisabled="permDocPreFilledKyes.indexOf('minDegree')>-1" :wrapclass="'md:w-1/2'" :required="true"  cid="Education"  :formscope="'newpetitionform'" :optionslist="educationTypes" v-model="permDetails.minDegreeDetails" @input="permDetails.minDegree=permDetails.minDegreeDetails['id']"   fieldName="Education" label="Minimum Education" placeHolder="Minimum Education"   />  
                  <immiInput :disabled="permDocPreFilledKyes.indexOf('majorFieldsOfStudy')>-1" :wrapclass="'md:w-1/2'" :display="true" :cid="'majorFieldsOfStudy'" :formscope="'newpetitionform'"  v-model="permDetails.majorFieldsOfStudy" :required="true" fieldName="majorFieldsOfStudy" label="Major Field of Study" placeHolder="Major Field of Study"   />
                  <immiInput :disabled="permDocPreFilledKyes.indexOf('expInYears')>-1" :onlyNumbers="true" :allowFloatingPoint="false" @input="updatedexpInYears" :wrapclass="'md:w-1/2 custom_form_group'" :display="true" cid="expInYears" :formscope="'newpetitionform'"  v-model="permDetails.expInYears" :required="true" fieldName="expInYears" label="Experience in Months" placeHolder="Experience"  :maxLength="5" />
        
                    <template >
            <div class="vx-col w-full mt-2">
                <div class="skilladdsec">
                    <label>Skills Required</label>
                    <ul>
                        <li v-for="(skil , index ) in permDetails['skills']" :key="index">
                            <span class="skill-label">{{skil}}</span>                                  
                            <span v-if="permDocPreFilledKyes.indexOf('skills')<=-1"   @click="removePermSkill(index)" class="row_btn">
                                <img src="@/assets/images/main/delete-row-img.svg">
                            </span>
                        </li>
                    </ul>
                    <div class="add-input-sec" >
                        
                        <div  @keyup="addSkill=true;skillTextError=false" class="skill-text" :class="{'skill-text-error':skillTextError && permDocPreFilledKyes.indexOf('skills')<=-1}">
                            <immiInput :disabled="permDocPreFilledKyes.indexOf('skills')>-1" @keyEnter="addSkill=true;skillTextError=false;addPermNewSkill()" :wrapclass="'w-full'"  :display="true" cid="addSkill" :formscope="'jobOpptInfo'"  v-model="newSkill" :required="false" fieldName="altAcceptExpInYears" placeHolder=""  />
                             <!-- v-if="addSkill" -->
                            <span :class="{'skilsbtn-disable':permDocPreFilledKyes.indexOf('skills')>-1}"   @click="addPermNewSkill()" class="add-more ">Add</span>
                        </div>
                    </div>
                </div>
            </div>
                   </template> 

                  <div class="vx-col  w-full mb-10">
                    <div class="form_group">
                      <label class="form_label">Description<em>*</em></label>
                      <ckeditor :disabled="permDocPreFilledKyes.indexOf('description')>-1 && permDetails.description" name="perm-jobDescription" v-model="permDetails.description" v-validate="'required'" class="w-full"
                        :data-vv-as="'Description'" :editor="editor" :config="editorConfig"></ckeditor>

                      <p v-show="errors.has('newpetitionform.perm-jobDescription')" class="text-danger text-sm"><em>*
                        </em>Description is required</p>
                    </div>
                  </div>

                  <br>
                  <immiswitchyesno :display="true" :wrapclass="'vx-col md:w-1/2'" :fieldsArray="[]"
                    :cid="'fullTimePosition'" formscope="fullTimePosition" v-model="permDetails.fullTimePosition"
                    fieldName="fullTimePosition" label="Is this a full-time position? " placeHolder="" />
                  <immiswitchyesno :display="true" :wrapclass="'vx-col md:w-1/2'" :fieldsArray="[]"
                    :cid="'permanentPosition'" formscope="permanentPosition" v-model="permDetails.permanentPosition"
                    fieldName="permanentPosition" label="Is this a permanent position? " placeHolder="" />
                  <immiswitchyesno v-if="false" :display="true" :wrapclass="'vx-col md:w-1/2'" :fieldsArray="[]"
                    :cid="'newPosition'" formscope="newPosition" v-model="permDetails.newPosition" fieldName="newPosition"
                    label="Is this a new position? " placeHolder="" />




                  <div class="vx-col w-full">


                    <div>
                      <h3 class="small-header">Address</h3>
                      <template v-for="(address ,index) in permDetails['workAddresses']">
                        <addressField :key="index" :display="true" :fieldsArray="questionnaireDetails" formscope="newpetitionform" :showaptType="true"
                          :addFormContainerCls="false" :validationRequired="true" :countries="countries"
                          v-model="permDetails['workAddresses'][index]" :cid="'beneficiaryInfoaddress'+index" />
                      </template>
                    </div>
                  </div>



                </div>
              </div>

                
              </template>
            
            <template v-if="checkProperty(visatype,'id')==3 && checkProperty(visasubtype,'id')==15" >
                <!-- <div  class="vx-row w-full ml-0 mt-4">
                <immiswitchyesno :display="true" :wrapclass="'md:w-1/2 PWD-switch'" @input="setPwdFilled(true)" :fieldsArray="questionnaireDetails" :cid="'isPwdFiled'"  formscope="newpetitionform" v-model="isPwdFiled" fieldName="isPwdFiled" label="PWD Filed/Certified document available?" placeHolder="" />
                </div> -->
                <div class="vx-col w-full pwd-link" v-if="selectedPetitioner || beneficiaryId">
                  <div class="form_group custom-radio_wrap ">
                    <ul class="custom-radio" vs-type="flex" vs-align="center">
                      
                      <li><vs-checkbox name="radioPWDhavingPWD"   @input="changePwdDoc" v-model="isPwdFiled" class="w-full"
                      ><span ref="Free-Flow">Upload Filed/Certified Document</span></vs-checkbox > </li>
                      <li><vs-checkbox   ref="Sequential"  name="radioPWDlinkPWD"   @input="linkExistingPwd"   v-model="isLinkPwd" class="w-full"
                      > <span ref="Sequential">Link Existing PWD</span></vs-checkbox > 
                      </li>
                      <!-- <li><vs-radio   ref="Sequential"  name="radioPWD"  vs-value="noPWD" @input="assignPwdValue"   v-model="isLinkPwd" class="w-full"
                      > <span ref="Sequential">No PWD</span></vs-radio ></li> -->
                    </ul>
                    <!-- <input type="hidden" :name="'radioPWD'" v-validate="'required'" data-vv-as="PWD Selection"  v-model="isLinkPwd">
                    <span class="text-danger text-sm " v-show="errors.has('newpetitionform.radioPWD')">{{errors.first('newpetitionform.radioPWD') }}</span> -->
                  </div>
                </div>
                <!----pwdStatus:'',  pwdStatusList:["Filed" ,"Certified"],-->
                <template v-if="isPwdFiled" >
                  
                                  
                  <div class="vx-col w-full" @click="value = [] ;pwdDocFormatError='';disablePWDstatus = false;prefillJobDetailsError=''" >

                    	


                    <div class="form_group file_group">
                      <div class="vs-component marb20">
                      <label class="form_label">PWD Documents<em>*</em></label>
                        <div class="relative">
                      <file-upload
                          v-model="value"
                          class="file-upload-input upload_file justify-center"
                          :accept="pdfDocEntity"
                          :name="'documents'"
                          :multiple="false"
                          :hideSelected="true"
                          @input="upload(value,'PWD')"
                        >
                          <img
                            class="file-icon"
                            src="@/assets/images/main/file-upload.svg"
                          />
                          Upload 
                        </file-upload>
                        <span  v-if="uploading" class="loader"   ><img src="@/assets/images/main/loader.gif"   /></span>
                        </div>
                        <!---
                          
                        <input type="hidden" v-model="newTask.documents"  data-vv-as="Documents"  v-validate="'required'" name="tdocs">
                        <span  class="text-danger text-sm" v-show="errors.has('tdocs')"   >{{ errors.first('tdocs') }}</span >
                        -->
                       
                        <input  type="hidden" :name="'pwdDocs'" v-validate="'required'"  data-vv-as="PERM Documents"  v-model="pwdResponse['documents']">
                        <span v-if="pwdDocFormatError" class="text-danger text-sm" >{{pwdDocFormatError}}</span>
                        <span v-else-if="errors.has('newpetitionform.pwdDocs')" class="text-danger text-sm" >*PWD Documents are required</span>
                        
                      </div>
                    

                      <ul class="uploaded-list note_uploads">
                        <template v-for="(item, index) in pwdResponse['documents']">
                          <vs-chip
                          @click="remove(item, pwdResponse['documents'], index);resetPrefedKyes()"
                            :key="index"
                            closable
                          >
                          {{ item.name }}
                          </vs-chip>
                        </template>
                      </ul>
                    </div>
                  </div>
                  <div @click="prefillJobDetailsError=''" class="text-danger text-sm formerrors" v-if="prefillJobDetailsError!=''">
                    <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ prefillJobDetailsError }}</vs-alert>
                    </div>
                    <selectField v-if="isPwdFiled" :isDisabled="disablePWDstatus" @input="resetPwdResponse(true);loadingFields($event)"  :listContainsId="false" :wrapclass="'md:w-1/2'" cid="pwdStatus"  :required="true" :optionslist="pwdStatusList" v-model="pwdStatus" :formscope="'newpetitionform'"  fieldName="pwdStatus"  label="PWD Status" placeHolder="PWD Status"  />  
                  
                    <div  class="vx-col md:w-1/2" :class="{'md:w-1/2':pwdStatus !='Certified','md:w-1/2': pwdStatus =='Certified','disabledPwdDocCaseNo':prefilledKyes.indexOf('pwdDocCaseNo')>-1}">

                      <div class="form_group">

                        <label class="form_label">PWD Case Number<em>*</em></label>

                        <vs-input :disabled="prefilledKyes.indexOf('pwdDocCaseNo')>-1"  v-model="pwdResponse.pwdDocCaseNo"   name="pwdDocCaseNo" v-validate="'required'" class="w-full"  data-vv-as="PWD Case Number"    />

                        <span class="text-danger text-sm" v-show="errors.has('newpetitionform.pwdDocCaseNo')">{{ errors.first("newpetitionform.pwdDocCaseNo") }}</span>

                      </div>

                    </div>

                   <immiswitchyesno v-if="false"  @input="setJobDetails($event)" :display="true" wrapclass=" " :fieldsArray="questionnaireDetails" :cid="'hasJobDetails'"  :formscope="'newpetitionform'" v-model="hasJobDetails" fieldName="hasJobDetails" label="Is Job Description available?" placeHolder="" />
                  <template v-if="pwdStatus ==='Certified'">
                  <datepickerField 
                              wrapclass="md:w-1/2"
                              :isDisabled="(prefilledKyes.indexOf('issuedDate')>-1 && pwdResponse.issuedDate !==null && pwdStatus =='Certified')"
                              @input="updateissuedDate($event)"
                              :display="true"  
                              v-model="pwdResponse.issuedDate" 
                              :formscope="'newpetitionform'"  
                              fieldName="issuedDate" 
                              :dateEnableTo="new Date()" 
                              label="Receipt Date" 
                              :validationRequired="true" 
                                />

                        <datepickerField 
                            wrapclass="md:w-1/2" 
                            :isDisabled="(prefilledKyes.indexOf('receivedDate')>-1 && pwdResponse.receivedDate !==null && pwdStatus =='Certified')"
                            :display="true"  
                            v-model="pwdResponse.receivedDate" 
                            :formscope="'newpetitionform'"  
                            fieldName="receivedDate" 
                            :dateEnableTo="new Date()" 
                            label="Received Date" 
                            :validationRequired="true"
                           />

                        <datepickerField 
                        :isDisabled="(!pwdResponse.issuedDate) || (prefilledKyes.indexOf('dueDate')>-1 && pwdResponse.dueDate !==null && pwdStatus =='Certified')"
                        wrapclass="md:w-1/2" 
                        :display="true"  
                        v-model="pwdResponse.dueDate" 
                        :formscope="'newpetitionform'"  
                        fieldName="dueDate" 
                        :dateEnableFrom="pwdResponse.issuedDate" 
                        label="Expiration Date" 
                        :validationRequired="true" 
                          />

                          <div class="vx-col w-full" v-if="false">
                    <div class="form_group" >
                      <label class="form_label">Comments</label>
                      <!-- <vs-textarea
                        data-vv-as="Comments"
                      
                        v-model="pwdResponse.description"
                        name="usciscomments"
                        class="w-full"
                      
                      /> -->
                      <ckeditor   data-vv-as="Comments"
                      
                      v-model="pwdResponse.description"
                      name="usciscomments"
                      class="w-full" :editor="editor" :config="editorConfig"></ckeditor>

                      <span
                        class="text-danger text-sm"
                        v-show="errors.has('newpetitionform.usciscomments')"
                      ><em>*</em> Comments are required</span>
                    </div>
                    </div>
                          


                    
                          <div class="vx-col w-full" v-if="false">
                      <div class="form_group">
                        <label class="form_label">Document Type<em>*</em></label>
                        <div class="con-select w-full DT_multiselect">  
                        <!-- {{documentType}}                 -->
                          <multiselect
                            :name="'documentType'"
                            v-validate="'required'"
                            v-model="pwdResponse.documentType"
                            :show-labels="false"
                            
                            data-vv-as="Document Type"
                            placeholder="Document Type"
                            :options="['Original' ,'Electronic' ]"
                            :searchable="true"
                            :allow-empty="false"
                          >
                          </multiselect>
                        
                          <span  class="text-danger text-sm"  v-show="errors.has('uscisstatus.documentType')"  >{{ errors.first('uscisstatus.documentType') }}</span>
                        </div>
                      </div>
                         </div> 
                  </template> 

                  

                  <template v-if="hasJobDetails ">
                    <permJobCreationForm ref="jobComponent" v-model="jobDetails"  :formscope="'newpetitionform'" :countries="countries" />
                  </template>
                </template>
                <template v-if="isLinkPwd">
                  <linkPwdPopup :selectedPetitioner="selectedPetitioner" :callFormCasePopup="true" @emitPwd="emitPwd" />
                </template>
                <template v-if="selectedPwdId && isLinkPwd">
                  <div class="d-flex" style="align-items: center;">
                  <div class="linked_pwd mr-2">
                  <p v-if="checkProperty(selectedPwdId,'pwdDocCaseNo')">
                    {{ checkProperty(selectedPwdId,'pwdDocCaseNo') }} <template v-if="checkProperty(selectedPwdId,'caseNo')">( {{ checkProperty(selectedPwdId,'caseNo') }} ) </template>
                  </p>
                   <p v-else>
                    {{ checkProperty(selectedPwdId,'caseNo') }}
                   </p>
                   <span @click="moveToTrash(selectedPwdId)" class="remove_pwd cursor-pointer" >
                          <img src="@/assets/images/main/delete-row-img.svg" />
                        </span>
                  </div>
                  </div>
                  
                </template>
              </template>


                 <template v-if="checkProperty(visatype,'id')==9 && (checkProperty(selectedBeneficiary ,'_id') || beneficiaryId )" >
                
                <div class="vx-col w-full pwd-link"  >
                  <div class="form_group custom-radio_wrap mb-4">
                    <label class="form_label mt-2 pb-1">Original Petition</label>
                    <ul class="custom-radio" vs-type="flex" vs-align="center">
                     <li> 
                      <vs-radio @change="resetRfeData()"   name="rfeInternalCase"  vs-value="internalCase" v-model="rfeData.rfeInternalCase" class="w-full" >
                        <span ref="Free-Flow">Internal Case</span>
                      </vs-radio >
                       </li>
                      <li>
                         <vs-radio  @change="resetRfeData()"  name="rfeInternalCase"  vs-value="externalCase"   v-model="rfeData.rfeInternalCase" class="w-full">
                             <span ref="Sequential">Filed Separately</span>
                          </vs-radio > 
               
                      </li>
                      
                    </ul>
                     </div>
                </div>
                <selectField v-if="rfeData.rfeInternalCase=='internalCase'" 
                
                 :wrapclass="'md:w-full'" 
                 cid="h1bCaseId" 
                  :required="true
                  " :optionslist="benficiaryH1BCases"
                   v-model="rfeData.h1bCaseId"
                    :formscope="'newpetitionform'" 
                     fieldName="h1bCaseId" 
                      label="Select Existing H-1B Case"
                       placeHolder="Select Existing H-1B Case"  />
             
<!----- :dateEnableFrom="pwdResponse.issuedDate" -->
                <!-- <div class="vx-col w-full" v-if="rfeData.rfeInternalCase=='externalCase'" @click="value = [] ;formerrors.msg='';pwdDocFormatError=''" >
                   <div class="form_group file_group mb-0">
                    <div class="vs-component marb20">
                    <label class="form_label">Copy of RFE<em>*</em></label>
                      <div class="relative">
                    <file-upload
                        v-model="value"
                        class="file-upload-input upload_file justify-center"
                        :accept="pdfDocEntity"
                        :name="'documents'"
                        :multiple="false"
                        :hideSelected="true"
                        @input="upload(value,'RFE')"
                      >
                        <img
                          class="file-icon"
                          src="@/assets/images/main/file-upload.svg"
                        />
                        Upload 
                      </file-upload>
                      <span  v-if="uploading" class="loader"   ><img src="@/assets/images/main/loader.gif"   /></span>
                      </div>
                      -
                        
                      <input type="hidden" v-model="newTask.documents"  data-vv-as="Documents"  v-validate="'required'" name="tdocs">
                      <span  class="text-danger text-sm" v-show="errors.has('tdocs')"   >{{ errors.first('tdocs') }}</span >
                      
                    
                      <input  type="hidden" :name="'rfeDocs'" v-validate="'required'"  data-vv-as="Copy of RFE"  v-model="rfeData['documents']">
                      <span v-if="pwdDocFormatError" class="text-danger text-sm" >{{pwdDocFormatError}}</span>
                      <span v-else-if="errors.has('newpetitionform.rfeDocs')" class="text-danger text-sm" >*Copy of RFE is required</span>
                      
                    </div>


                    <ul class="uploaded-list note_uploads mt-5">
                      <template v-for="(item, index) in rfeData['documents']">
                        <vs-chip
                        @click="remove(item, rfeData['documents'], index);resetPrefedKyes()"
                          :key="index"
                          closable
                        >
                        {{ item.name }}
                        </vs-chip>
                      </template>
                    </ul>
                  </div>
                </div> -->

                <div class="vx-col w-full RFE_popup_case_doc" v-if="rfeData.rfeInternalCase=='externalCase'" @click="value = [] ;formerrors.msg='';pwdDocFormatError=''" >
                    <div class="form-container mart20 casedocuments__">
                      <div class="documents_group case_documents">
                        <div class="vx-row delete-row">
                          <div class="vx-col w-full">
                            <div class="form_group">
                              <label class="form_label">
                                <span style="display:inline;">Copy of RFE<em>*</em></span>
                              </label>
                              <div class="relative">
                                <file-upload
                                    v-model="value"
                                    class="file-upload-input upload_file justify-center"
                                    :accept="pdfDocEntity"
                                    :name="'documents'"
                                    :multiple="false"
                                    :hideSelected="true"
                                    @input="upload(value,'RFE')"
                                  >
                                    <img
                                      class="file-icon"
                                      src="@/assets/images/main/file-upload.svg"
                                    />
                                    Upload 
                                  </file-upload>
                                  <span  v-if="uploading" class="loader"   ><img src="@/assets/images/main/loader.gif"   /></span>
                                  </div>
                                  <!---
                                    
                                  <input type="hidden" v-model="newTask.documents"  data-vv-as="Documents"  v-validate="'required'" name="tdocs">
                                  <span  class="text-danger text-sm" v-show="errors.has('tdocs')"   >{{ errors.first('tdocs') }}</span >
                                  --> 
                                
                                  <input  type="hidden" :name="'rfeDocs'" v-validate="'required'"  data-vv-as="Copy of RFE"  v-model="rfeData['documents']">
                                  <span v-if="pwdDocFormatError" class="text-danger text-sm" >{{pwdDocFormatError}}</span>
                                  <span v-else-if="errors.has('newpetitionform.rfeDocs')" class="text-danger text-sm" >*Copy of RFE is required</span>
                                  <ul class="uploaded-list note_uploads m-0">
                                    <template v-for="(item, index) in rfeData['documents']">
                                      <vs-chip
                                      @click="remove(item, rfeData['documents'], index);resetPrefedKyes()"
                                        :key="index"
                                        closable
                                      >
                                      <img src="@/assets/images/main/down-arrow2.svg" @click="downloads3file(ditem)" />
                                      {{ item.name }}
                                      </vs-chip>
                                    </template>
                                  </ul>
                              </div>
                          </div>
                        </div>
                      </div>
                    </div>
                </div>
                <div class="vx-col w-full RFE_popup_case_doc" v-if="rfeData.rfeInternalCase=='externalCase'" >
                  <casedocumentslist :showTitle="false" @emitUploadingAction="emitUploadingAction" :docMainCategory="'rfeDocslist'" :docslist="rfeDocslist" formscope="newpetitionform" :fieldsArray="[]" v-model="rfeData.docs" :tplsection="'documents'"  :fieldName="''" ></casedocumentslist>
                </div>
                <template>
                <immiInput :disabled="prefilledKyes.indexOf('uscisReceiptNumber')>-1 " 
                v-if="rfeData.rfeInternalCase=='externalCase'" :wrapclass="'md:w-1/2'"
                 :display="true" cid="uscisReceiptNumber" :formscope="'newpetitionform'" v-model="rfeData.uscisReceiptNumber"
                  :required="true" :maxCharacters="30" fieldName="uscisReceiptNumber" label="USCIS Receipt Number" placeHolder="USCIS Receipt Number" />
                <!----   rfeIssuedDate:null,rfeReceivedDate:null,--->
            
                <datepickerField  v-if="rfeData.rfeInternalCase=='externalCase'" 
                        :isDisabled="prefilledKyes.indexOf('rfeIssuedDate')>-1 "
                        wrapclass="md:w-1/2" 
                        :display="true"  
                        v-model="rfeData.rfeIssuedDate" 
                        :formscope="'newpetitionform'"  
                        fieldName="rfeIssuedDate" 
                        :dateEnableTo="new Date()" 
                        label="RFE Issued Date" 
                        :validationRequired="true" 
                        @input="clearReceivedDate"
                />
                <datepickerField  v-if="rfeData.rfeInternalCase=='externalCase'" 
              :isDisabled="prefilledKyes.indexOf('rfeReceivedDate')>-1 || rfeData.rfeIssuedDate ==null "
              wrapclass="md:w-1/2" 
              :display="true"  
              v-model="rfeData.rfeReceivedDate" 
              :formscope="'newpetitionform'"  
              fieldName="rfeReceivedDate" 
              :dateEnableFrom="rfeData.rfeIssuedDate" 
              :dateEnableTo="new Date()"
              label="RFE Received Date" 
              :validationRequired="false" 
                />
                <datepickerField  v-if="rfeData.rfeInternalCase=='externalCase'" 
                        :isDisabled="prefilledKyes.indexOf('rfeCaseUscisDeadlineDate')>-1 "
                        wrapclass="md:w-1/2" 
                        :display="true"  
                        v-model="rfeData.rfeCaseUscisDeadlineDate" 
                        :formscope="'newpetitionform'"  
                        fieldName="rfeCaseUscisDeadlineDate" 
                        :dateEnableFrom="new Date()" 
                        label="RFE Due Date" 
                        :validationRequired="true" 
                  />
              </template>


               
                  

                </template>

              
          </div>


          <div class="text-danger text-sm formerrors custom_margin" v-show="formerrors.msg">
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
              icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
          </div>
          
        </div>

        <div class="popup-footer relative">
          <span class="loader" v-if="newPetitionFormSubmited" ><img src="@/assets/images/main/loader.gif" /></span>
          <vs-button color="dark" @click="addNewCase(false);NewPetition=false ;formerrors.msg='';" class="cancel" type="filled">Cancel
          </vs-button>
          <vs-button color="success" :disabled=" newPetitionFormSubmited || !enableSubmitBtn || documentUploading" @click="fileNewCase"
            class="save" type="filled">Submit</vs-button>
        </div>
      </form>
        </div>
    </modal>
    <!-----archiveAction(false)-->
    <modal name="conformArchivemodal" classes="v-modal-sec" :min-width="200" :min-height="200" :scrollable="true"
      :reset="true" width="450px" height="auto">
      <div class="v-modal">
        <div class="popup-header fromDetailsPage">
          <h2 class="popup-title">
            {{internalStatusTitle}}

          </h2>
          <span @click="$modal.hide('conformArchivemodal');internalStatusDetails=null;internalComments='';permDeleteDocs=[]">
            <em class="material-icons">close</em>
          </span>
        </div>

        
        <form data-vv-scope="permDeletForm">

          <div class="form-container">

            <div class="vx-row">
              <div class="vx-col w-full">
                <div class="form_group">
                <label class="typo__label">Select Internal Status<em>*</em></label>
                <multiselect  v-model="internalStatusDetails" :options="internalStatusList" :multiple="false"
                  :hideSelected="false" :close-on-select="true" :clear-on-select="false" :preserve-search="true"
                  :select-label="'Search Internal Status'" placeholder="Select Internal Status" label="name" track-by="name"
                  :preselect-first="false" :searchable="true" name="internalStatus"
                  data-vv-as="Internal Status"  v-validate="'required'"  @input="checkDeletedDocs"
                  >
                </multiselect>
                </div>
                <span class="text-danger text-sm"
                 v-show="errors.has('permDeletForm.internalStatus')" 
                 >{{ errors.first("permDeletForm.internalStatus") }}</span>
              
              </div>
              <template v-if="[50].indexOf(getUserRoleId)<=-1 && (checkProperty(internalStatusDetails,'id') == 2 || checkProperty(internalStatusDetails,'id') == 3 )">
              <div class="vx-col w-full" @click="value = []">
                <div class="form_group file_group">
                  <div class="vs-component marb20">
                   <label class="form_label">Documents</label>
                    <div class="relative">
                   <file-upload
                      v-model="value"
                      class="file-upload-input upload_file justify-center"
                      :accept="allDocEntity"
                      :name="'documents'"
                      :multiple="true"
                      
                      :hideSelected="true"
                      @input="upload(value ,'delete')"
                    >
                      <img
                        class="file-icon"
                        src="@/assets/images/main/file-upload.svg"
                      />
                      Upload 
                    </file-upload>
                    <span  v-if="uploading" class="loader"   ><img src="@/assets/images/main/loader.gif"   /></span>
                    </div>
                    <!---
                      
                    <input type="hidden" v-model="newTask.documents"  data-vv-as="Documents"  v-validate="'required'" name="tdocs">
                    <span  class="text-danger text-sm" v-show="errors.has('tdocs')"   >{{ errors.first('tdocs') }}</span >
                    -->
                    <input type="hidden" :name="'permDeleteDocs'"   data-vv-as="PERM Documents"  v-model="permDeleteDocs">
                    <!-- <span class="text-danger text-sm" v-show="errors.has('permDeletForm.permDeleteDocs')">*Documents are required</span> -->
                
                  </div>
                 

                  <ul class="uploaded-list note_uploads">
                    <template v-for="(item, index) in permDeleteDocs">
                      <vs-chip
                      @click="remove(item, permDeleteDocs, index)"
                        :key="index"
                        closable
                      >
                      {{ item.name }}
                      </vs-chip>
                    </template>
                  </ul>
                </div>
                </div>
              </template>
              <div class="vx-col w-full"  >
                <div class="form_group">
                  <label class="form_label">Comments<em>*</em></label>
                  <!-- <vs-textarea
                    data-vv-as="Comments"
                    v-validate="'required'"
                    v-model="internalComments"
                    name="internalcomments"
                    class="w-full"
                  
                  /> -->
                  <ckeditor data-vv-as="Comments"
                    v-validate="'required'"
                    v-model="internalComments"
                    name="internalcomments"
                    class="w-full"  :editor="editor" :config="editorConfig"></ckeditor>

                  <span
                    class="text-danger text-sm"
                    v-show="errors.has('permDeletForm.internalcomments')"
                  ><em>*</em> Comments are required</span>
                </div>
                </div>
          </div>

            <div v-if="formerrors.msg && internalErrMsg ==''">
              <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
                icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
            </div>
            <div v-if="internalErrMsg !='' ">
              <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
                icon="IP-information-button" active="true">{{ internalErrMsg }}</vs-alert>
            </div>

          </div>
        </form>
        <div class="popup-footer relative">
          <figure v-if="archiving" class="loader"><img src="@/assets/images/main/loader.gif" /></figure>
          <vs-button color="dark" class="cancel" type="filled" @click="$modal.hide('conformArchivemodal'); internalErrMsg=''">Cancel
          </vs-button>
          <vs-button :disabled="archiving" color="success" class="save" type="filled" @click="archiveAction_BACKUP()">Submit
          </vs-button>
        </div>

      </div>
    </modal>
    <!-- <modal name="conformArchivemodal" classes="v-modal-sec" :min-width="200" :min-height="200" :scrollable="true"
      :reset="true" width="450px" height="auto">
      <div class="v-modal">
        <div class="popup-header fromDetailsPage">
          <h2 class="popup-title">
            Delete

          </h2>
          <span @click="$modal.hide('conformArchivemodal');">
            <em class="material-icons">close</em>
          </span>
        </div>

        <div class="form-container">

          <div class="vx-row">
            <div class="vx-col w-full">
              <p class="msg_text">Are you sure to continue?</p>

            </div>

          </div>

          <div v-show="formerrors.msg">
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
              icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
          </div>

        </div>
        <div class="popup-footer relative">
          <figure v-if="archiving" class="loader"><img src="@/assets/images/main/loader.gif" /></figure>
          <vs-button color="dark" class="cancel" type="filled" @click="$modal.hide('conformArchivemodal');">No
          </vs-button>
          <vs-button :disabled="archiving" color="success" class="save" type="filled" @click="archiveAction()">Yes
          </vs-button>
        </div>

      </div>
    </modal> -->
    <modal
          name="errorConfirmationModal"
          classes="v-modal-sec"
          :min-width="200"
          :min-height="200"
          :scrollable="true"
          :reset="true"
          width="650px"
          height="auto"
        >
        <div class="v-modal profile_details_modal error-modal-space" >
          <div class="popup-header fromDetailsPage">
            <h2 class="popup-title">
              Confirmation
            </h2>
          </div>
          <form data-vv-scope="addPaymentForm" class="relative" @submit.prevent @keydown.enter.prevent>
        <div
          class="popup_info"
         
          @click="formErrors = ''"
        >
         
          
        </div>
        <div class="form-container">
          {{caseCreationErrMsg}}
        </div>
  
        <div class="popup-footer relative">
          <span class="loader" v-if="loading"
            ><img src="@/assets/images/main/loader.gif"
          /></span>
          <vs-button
            color="dark"
            @click="createCaseWithReplace('false' ,true)"
            class="cancel"
            type="filled"
            >No</vs-button>
          <vs-button
            :disabled="loading"
            color="success"
            @click="createCaseWithReplace('true' ,true)"
            class="save"
            type="filled"
            >Yes 
          </vs-button>
        </div>
      </form>
          </div>
    </modal> 

   

  </div>
</template>

<script>
import addressField from "@/views/forms/fields/address.vue";
import casedocumentslist from "@/views/common/casedocuments.vue";
import immiInput from "@/views/forms/fields/simpleinput.vue";
import datepickerField from "@/views/forms/fields/datepicker.vue";
import selectField from "@/views/forms/fields/simpleselect.vue";
import linkPwdPopup from "@/views/actionpopups/linkPwdPopup.vue"
import permJobCreationForm from "@/views/actionpopups/perm/permJobCreationForm.vue"
import _ from "lodash";
import immiswitchyesno from "@/views/forms/fields/switchyesno.vue"
import DateRangePicker from "vue2-daterange-picker";
import Paginate from "vuejs-paginate";
import Datepicker from "vuejs-datepicker-inv";
import Multiselect from "vue-multiselect-inv";
import JQuery from "jquery";
import NoDataFound from "@/views/common/noData.vue";
import FileUpload from "vue-upload-component/src";
import "vue2-daterange-picker/dist/vue2-daterange-picker.css";
import addBeneficiary  from "@/views/common/addBeneficiary.vue" 
import addBenewPet  from "@/views/common/invitePet.vue" 
import moment from 'moment'
import { stringify } from "querystring";
import Vue from 'vue';
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';

export default {
  provide() {
      return {
          parentValidator: this.$validator,
      };
  },
  props: {
    callFromBen:{
      type:Boolean,
      default:false
    },
    beneficiaryId:null,
    beneficiaryInfo:null,
    petitionerDetails:null,
    isRfe:{
      type: Boolean, default:false
    }
  },
  components: {
    casedocumentslist,
    immiInput,
    addressField,
    linkPwdPopup,
    datepickerField,
    selectField,
    permJobCreationForm,
    immiswitchyesno,
    FileUpload,
    addBeneficiary,
    addBenewPet,
    Datepicker,
    DateRangePicker,
    Multiselect,
    Paginate,
    NoDataFound
  },
  data: () => ({
    selectedI94Expiry:null,
    I94ExpiryList:[
      {'name':'Expired','id':'expired'},
      {'name':'Within 7 Days','id':'with_in_7_days'},
      {'name':'Within 15 Days','id':'with_in_15_days'},
      {'name':'Within 30 Days','id':'with_in_30_days'},
      {'name':'Within 60 Days','id':'with_in_60_days'},
      {'name':'60+ Days','id':'60_plus_days'}
    ], 
    isPetitioner:true,
    benficiaryH1BCases:[],
    
    rfeInternalCase:'externalCase',//'internalCase',
    rfeDocslist:[

      {
          required: true,
          fileUploading:false,
          key: 'orgPetition',
          fieldName: 'orgPetition',
          label:'Original Petition'
      },
      {
          required: false,
          fileUploading:false,
          key: 'petitionerDocs',
          fieldName: 'petitionerDocs',
          label:'Petitioner Documents (if any)'
      },
      {
          required: false,
          fileUploading:false,
          key: 'beneficiaryDocs',
          fieldName: 'beneficiaryDocs',
          label:'Beneficiary Documents'
      },
    
      {
          required: false,
          fileUploading:false,
          key: 'employmentDocs',
          fieldName: 'employmentDocs',
          label:'Employment Documents (if any)'
      },
      {
          required: false,
          fileUploading:false,
          key: 'other',
          fieldName: 'other',
          label:'Others'
      },

    ],
    documentUploading:false,
    rfeData:{
      rfeIssuedDate:null,
      rfeReceivedDate:null,
      rfeCaseUscisDeadlineDate:null,
      uscisReceiptNumber:'',
      rfeInternalCase:'internalCase',//'externalCase',//'internalCase',
      "documents":[],
      "docs":{
        "copyOfRfe":[],
          "orgPetition":[],
          "petitionerDocs":[],
          "employmentDocs":[],
          "beneficiaryDocs":[],
          "other":[]

      },
      h1bCaseId:null
    },

    draftExtractInfo:null,
    skillTextError:false,
    newSkill:'',
    addSkill:true,

    educationTypes:[],
    addCls:false,  
    updatedInitStatus:[
      { _id: "637f7c565648c5150123dall", id: 9, "name": "All", "sortName": "All" },
      {_id: "637f7c565648c5150123deab", id: 1, name: "Active", sortName: "active"},
      { _id: "637f7c565648c5150123dfiled", id: 10, "name": "Filed", "sortName": "Filed" },
      {_id: "637f7c565648c5150123deac", id: 2, name: "On Hold", sortName: "on hold"},
      {_id: "637f7c565648c5150123dead", id: 3, name: "Abandoned", sortName: "abandoned"},
      {_id: "637f7c565648c5150123deae", id: 4, name: "Deleted", sortName: "deleted"}
    ],
    permDocFormatError:'',
    activeCases:true,
    getFiledCases:false,
    payFrequencyList: ["Hour", "Week", "Month", "Year"],
    masterSocList:[],
    permDetails: {
            socCode:'',
            socDetails:null,
            permApplicationNo:'',
            jobTitle: '',

            minDegreeDetails:null,
            minDegree:null,
            skills:[],
            majorFieldsOfStudy:'',
            expInYears:null,

            workAddresses: [
            {
                    line1: null,
                    line2: null,
                    aptType: null,
                    locationId: null,
                    locationDetails: null,
                    stateId: null,
                    stateDetails: null,
                    countryId: null,
                    countryDetails: null,
                    zipcode: null
                }
            ],

            fullTimePosition: false,

            hoursPerWeek: '',

            wageRate: '',

            payFrequency: 'Month', // Year, Month, Bi-Weekly, Week, Hour

            description: '',

            permanentPosition: false,

            newPosition: false

        },
    permDocPreFilledKyes:[],
    selectedPwdId:null,
    isLinkPwd:false,
    disablePWDstatus:false,
    getPendingWithLCA:false,
    debounce:null,
    global_selected_petitioners:[],
    gobalType:[],
    getActiveCases:true,
    getClosedCases:false,
    dashboardBranchIds:[],
    editor: ClassicEditor,
 editorConfig: {
     toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
 },
    i140CreationMessage:'',
    classificationpopup: false,
    capRegId:'',
    callFromCapCaseCreation:false,
    disableOffice:false,
    caseErrorDetails:null,
    loading:false,
    caseCreationErrMsg:'',
    caseErrorCode:'',
    internalStatusTitle:'Hold/Abandon/Delete Case',
    checkHeaderCheckBox:{ "_id": "637f076578adb65c4c208e2d", "id": 1, "name": "Active", "sortName": "active" },
    initStatusIdsFilter:null,
    masterDataList:[],
    internalComments:'',
    permDeleteDocs:[],
    internalErrMsg:'',
    internalStatusDetails:null,
    internalStatusList:[],
    prefilledKyes:[],
    prefillJobDetailsError:'',
    questionnaireDetails:null,
    jobDetails: {
      wageRate: "",
      socOccuTitle: "",
      preferredSocOccuTitle:"",
      
      socCode: "",
			jobTitle: "",
			preferredSocCode: '',
      preferredSocCodeDetails:null,
			classification: "",
			description: "",
			skills: [],
			minDegree: '',
			majorFieldsOfStudy: "",
			expInYears: "",
      altJobRequirements: {

    // Are alternate sets of Education, Training, and/or Experience accepted? "Yes", "No"

    areAltSetsOfEducation:"",// { type: String},
    altevelOfEducation: null,//{ type: Schema.Types.ObjectId, default: null  }, //0bjectId
    altevelOfEducationDetails:null,
    usDiplomaOrDegreeAccepted:'', //{type: String},
    majorsOrFieldsOfStudyAccepted: '',//{type: String},
    isAltTrainingForTheJobOpporAccepted: '',//"Yes" Or "No"
    noOfMonthsOfAltTrainingAccepted: null,//{type: String},
    filedsOrNamesOfTrainingAccepted: "",//{ type: String },
    altEmpExpAccepted: "", //"Yes" Or "No"
    noOfMonthsAltEmpExpAccepted:null,
    splSkillOrOtherRequi:'',
    ForeignLanguage:'',
    LicenseCertification:'',
    residencyFellowship:'',
    otherSplSkillsOrRequi:''

     },
			workAddresses: [{
				"companyName": "",
				"line1" : "",
				"line2" : "",
				"aptType": "",
				"locationId" :'' ,
				"stateId" :'' ,
				"countryId" :'' ,
				"zipcode" : "",
				"locationDetails" : {
					"id" : '',
					"name" : "",
					"stateId" : '',
					"countryId" :'' 
				},
				"stateDetails" : {
					"id" :'' ,
					"name" : "",
					"shortName" : "",
					"countryId" : ''
				},
				"countryDetails" : {
					"id" : 231,
					"shortName" : "US",
					"name" : "United States",
					"phoneCode" : 1,
					"order" : 1,
					"currencySymbol" : "$",
					"currencyCode" : "USD",
					"zipcodeLength" : 5
				},
				"workLocation": true
			}]
		},
    pwdDocFormatError:'',
    pwdResponse:{
      "issuedDate": null,
      "receivedDate": null,
      "dueDate": null,
      "description": "",
      "documents": [],
      "documentType": "",
      pwdDocCaseNo:'',

    },
    hasJobDetails:false,
    isPwdFiled:false,
    pwdStatus:'',
    pwdStatusList:["Filed" ,"Certified"],
    permDocRequired:false,
    Doc140Required:false,
    responsePermId:'',
    response140Id:'',
    enableSubmitBtn:true,
    uploading:false,
    value:[],
    permDolDocs:[],
    Dol140Docs:[],
    category:'',
    categoryList:[],
    classification:'',
    classificationList:['EB2','EB3','EB3S'],
    
    premiumProcessingList:[{name:'Yes' ,_id:true },{name:'No' ,_id:false }],
    selectedpremiumProcessing:[],
    premiumProcessing:false,
    newPetitionFormSubmited:false,
     formerrors: {
      msg: ""
    },
    selectedBranch:null,
    NewPetition:false,
    petitionersList:[],
    invitepetitioner:false,
    AddBeneficiary:false,
    selectedPetitioner:null,
    saveBenbtn:false,
    selectedUser:'',
    selectedUsername:'',
    beneficiaryMasterDataList:[],
    visatypes:[],
    activeVisatypes:[],
    capActiveVisatype:[{ "_id": "63202b2eff21ba23446a8c42", "id": 1, "name": "H-1B", "isCaseTypeSelected": true }],
    capvisasubtypes:[{"_id":"63202b2eff21ba23446a8c38","id":8,"name":"Regular Cap - Consular Processing","order":10,"type":1,"groupCode":"EMP","isCaseTypeSelected":true},
    {"_id":"63202b2eff21ba23446a8c3a","id":10,"name":"Master Cap - Consular Processing","order":9,"type":1,"groupCode":"EMP","isCaseTypeSelected":true},
    {"_id":"63202b2eff21ba23446a8c39","id":9,"name":"Regular Cap - Change of Status","order":11,"type":1,"groupCode":"EMP","isCaseTypeSelected":true},
    {"_id":"63202b2eff21ba23446a8c37","id":7,"name":"Master Cap - Change of Status","order":8,"type":1,"groupCode":"EMP","isCaseTypeSelected":true}],
    visatype:null,
    visasubtypes:[],
    visasubtype:null,
    selectedBeneficiary:null,
     



    branchList:[],
    selectedBranches:[],
   isListloading:false,
    callFromSerch:false,
    sortKeys:{},
    sortKey:{"path":'updatedOn',"order":-1},
    buttoncol: true,
    ChangePetition: false,
    formerrors: {
      msg: ""
    },
    searchtxt: "",
    query: [],
    selected: [],
    petitioners: [],
    currentuserRole: null,
    selecteduser: {
      petitionId: null,
      userName: null,
      email: null,
      typeName: null,
      subTypeName: null,
      instructions: null
    },
    SendQuestionnaire: false,
    SuccessQuestionnaire: false,
    selected_createdDateRange: ["", ""],
    selected_deadLineDateRange: ["", ""],
    autoApply: "",
    countries: [],
    country_code: 0,
    selected_country_obj: "",
    all_states: [],
    seleted_states: [],
    final_selected_states: [],
    singel_final_selected_state: "",
    all_locations: [],
    seleted_locations: [],
    final_selected_locations: [],
    case_statusids:[],
    selected_statusids: [],
    final_selected_statusids: [],
    page: 1,
    perpage: 25,
    totalpages: 0,
    totalCount:0,

    filter_searchtxt: "",
    visaTypes:[],
    selectedVisaType:null,
    all_subtypes: [],
    selected_subtypes: [],
    final_selected_subtypes: [],

    final_filter_roleIds: [3, 4, 5, 9, 10],
    rolebased_filter: {
      3: { name: "supervisorIds", values: [] },
      4: { name: "paralegalIds", values: [] },
      5: { name: "attorneyIds", values: [] },
      9: { name: "offshoreUserIds", values: [] },
      10: { name: "evidenceSupervisorIds", values: [] }
    },
    users: [],
    selected_users: [],
    final_selected_users: [],
    user_search_value: "",
    roleId: 0,

    all_peritioners: [],
    peritioners_search_value: "",
    selected_peritioners: [],
    final_selected_peritioners: [],

  isListLoading:false,
    sortKeys:{},
    
    perPeges: [10,25,50,75,100], // [  {name:10 ,perPage:10} , {name:25 ,perPage:25} ,{name:50 ,perPage:50},{name:100 ,perPage:100}],
    selectedForArchiveList:[],
    archiving:false,
    selectedarchive:[],
    selectedAllForArchive:false,
    encodedString:'',
    classificationResultList:[],
    sortingList:[
      //  {path:'caseNo',order:-1 ,"displayName":"Case Number"},
   //    {path:'createdByName',order:-1 ,"displayName":"Created By Name"},
   //    {path:'typeName',order:-1 ,"displayName":"Case Type"},
    //   {path:'subTypeName',order:-1,"displayName":"Case Sub Type"},
    //   {path:'statusName',order:-1,"displayName":"Case Status"},
       {path:'createdOn',order:-1,"displayName":"Created Date"},
       {path:'updatedOn',order:-1,"displayName":"Updated Date"},
  //     {path:'clientName',order:-1,"displayName":"Client Name"},
    //   {path:'beneficiaryName',order:-1,"displayName":"Beneficiary Name"},
        
   ]
  }),
  watch: {
    searchtxt: function(value) {
      this.searchMe();
      // let text = value.trim();

      // if(text.length>3 || text==''){
      //   setTimeout(()=>{
      //     this.getpetitions(true ,false);
      //   } ,100);

         
      // }
     
    },
     '$route.query.filter':function (val) {
      this.selected_statusids =[];
      this.final_selected_statusids =[];
      this.final_selected_subtypes = []
      this.selected_subtypes = []
      this.selectedVisaType =null;
        if(this.checkProperty(this.$route ,'query' ,'filter')){
                try{
                  let filter =this.$route['query']['filter']; this.checkProperty(this.$route ,'query' ,'filter')
                  var actual = JSON.parse(atob(filter));
                  let keys = Object.keys(actual);
                  if(this.checkProperty(keys ,'length') >0){
                    
                   
                    if(actual && (Object.keys(actual)).length>0 ){               
                    _.forEach(actual ,(item ,key) => {
                        if(key=='matcher' ){
                          
                          if((Object.keys(item)).length>0 ){

                            if(_.has(item ,'typeIds') && this.checkProperty(item , 'typeIds' ,'length')>0 ){
                               
                              this.selectedVisaType = _.find(this.visaTypes ,{"id":item['typeIds'][0]})
                             this.getvisa_subtypes();
                           
                            }  
                            if(_.has(item ,'subTypeIds') && this.checkProperty(item ,'subTypeIds' ,'length')>0){
                                  
                                  
                                  this.final_selected_subtypes = item['subTypeIds'];
                                 
                                  if(this.all_subtypes.length>0){

                                  
                                  this.selected_subtypes = _.filter(this.all_subtypes ,(status)=>{
                                      return item['subTypeIds'].indexOf(status['id'])>-1;
                                      

                                })
                              }

                                

                            }
                               
                            if(_.has(item ,'statusIds') && this.checkProperty(item ,'statusIds' ,'length')>0){
                              let statusIds = item['statusIds']
                              let selectedStatus = _.find(this.case_statusids ,{"id":parseInt(statusIds[0])}); 
                              this.final_selected_statusids =statusIds;
                            if(selectedStatus){
                            this.selected_statusids =[selectedStatus];
                            
                            } 

                            }
                          // if(_.has(item ,'page') && parseInt(item['page'])>0){
                          //   this.page =parseInt(item['page'])
                          // }
                          // if(_.has(item ,'perpage') && parseInt(item['perpage'])>0){
                          //   this.perpage =parseInt(item['perpage'])
                          // }
                                
                          }
                        
                        }
                    })
                  }                    
                  }

                }catch(e){
                }          
              } 
              else{
                this.gobalType = {"_id":"632953d43ecbeaeefe93efefr","id":'ALL',"name":"All","isCaseTypeSelected":true}
                this.selectedVisaType = this.gobalType
              }      
          this.getpetitions(true);
      }
  },
  methods: {
    getIndividualList(){},
    clearReceivedDate(val){
      if(val){
        let startDate = moment(val);
        if(this.rfeData.rfeReceivedDate){
          let endDate= moment(this.rfeData.rfeReceivedDate)
          if(startDate.isAfter(endDate , 'day')){
            this.rfeData.rfeReceivedDate = null
          }
        }
      }
      // else{
      //   this.rfeData.rfeReceivedDate = null
      // }
    },
    resetRfeData(setrfeInternalCase=false){
      this.documentUploading =false;
      this.prefilledKyes = [];
      //alert("ssd fsd");
    //   rfeData:{
      
    //   rfeCaseUscisDeadlineDate:null,
     //uscisReceiptNumber:'',
    //   rfeInternalCase:'externalCase',//'internalCase',
    //   "documents":[],
    //   "docs":{
    //     "copyOfRfe":[],
    //       "orgPetition":[],
    //       "petitionerDocs":[],
    //       "employmentDocs":[],
    //       "beneficiaryDocs":[],
    //       "other":[]

    //   },
    //   h1bCaseId:null
    // }
    if(setrfeInternalCase){
      this.rfeData['rfeInternalCase'] ='internalCase'
      this.premiumProcessing =false;
    }
    
    //rfeIssuedDate:null,rfeReceivedDate:null
    this.rfeData['rfeIssuedDate'] =null
    this.rfeData['rfeReceivedDate'] =null
    this.rfeData['rfeCaseUscisDeadlineDate'] =null
    this.rfeData['uscisReceiptNumber'] =''
    this.rfeData['h1bCaseId'] =null
    this.rfeData['documents'] =[];
    this.rfeData['docs'] ={
        "copyOfRfe":[],
          "orgPetition":[],
          "petitionerDocs":[],
          "employmentDocs":[],
          "beneficiaryDocs":[],
          "other":[]

      }
    this.rfeData['h1bCaseId'] =null
   

    },
    emitUploadingAction(data){
                if(_.has(data,'docMainCategory')){
                    _.map(this[data['docMainCategory']],(item)=>{
                        if(item['fieldName'] == data['fieldName']){
                            item = Object.assign( item ,{ "fileUploading": false})
                            item['fileUploading'] = data['action'] 
                        }
                    })
                }
                this.checkSubmitBtn(data)
            },
            checkSubmitBtn(data){
                this.documentUploading = false;
                if(_.has(data,'docMainCategory')){
                    _.forEach(this[data['docMainCategory']],(item)=>{
                        if(_.has(item,'fileUploading') && item['fileUploading']){
                            this.documentUploading = true;
                            return false;
                        }
                    })
                }
            },
    prefillRfeNoticeDoc(){
      this.draftExtractInfo = null;
      var _dt;
      this.prefilledKyes =[];
      this.$validator.reset();
      if(this.checkProperty(this.rfeData,"documents", 'length' )>0){
            
        this.uploading = true;  
        let path ="/petition/extract-lca-data-from-pdf";
        path ="/common/extract-data-from-pdf";
        //  9014077715 --- 325
      
    
        let postData ={
          "category": "rfe_notice",
          "docType": "rfe_notice",
          documents:[],
          "lcaDocument":''
        };
      
        let doc = this.rfeData['documents'][0];
        postData['lcaDocument'] = doc.path;
        postData['documents'].push(doc.path);
        this.$vs.loading();
        this.$store.dispatch('commonAction', {"data":postData ,"path":path})
            .then((response)=>{
              this.$vs.loading.close();
              this.uploading = false;  
              this.draftExtractInfo =response;
              if(this.checkProperty(this.draftExtractInfo ,'uscisDeadlineDate')){
                this.rfeData['rfeCaseUscisDeadlineDate'] = this.draftExtractInfo['uscisDeadlineDate']; //moment(this.draftExtractInfo['uscisDeadlineDate']).format("YYYY-MM-DD");
                this.prefilledKyes.push('rfeCaseUscisDeadlineDate');
              }

              if(this.checkProperty(this.draftExtractInfo ,'rfeIssuedDate')){
            this.rfeData['rfeIssuedDate'] = this.draftExtractInfo['rfeIssuedDate']; 
            this.prefilledKyes.push('rfeIssuedDate');
          }
          if(this.checkProperty(this.draftExtractInfo ,'rfeReceivedDate')){
            this.rfeData['rfeReceivedDate'] = this.draftExtractInfo['rfeReceivedDate']; 
            this.prefilledKyes.push('rfeReceivedDate');
          }
          
              if(this.checkProperty(this.draftExtractInfo ,'uscisReceiptNumber')){
                this.rfeData['uscisReceiptNumber'] = this.draftExtractInfo['uscisReceiptNumber'];
                this.prefilledKyes.push('uscisReceiptNumber');
              }
            
              

            }).catch((errr)=>{
              this.$vs.loading.close();
              this.pwdDocFormatError = errr
              this.uploading = false;  
            });
      }

    },
  
    getBenficiaryH1BCases(){
      this.rfeData.h1bCaseId =null;
      this.benficiaryH1BCases =[];
      let postData ={
        "matcher":{
          "getMasterDataOnly": true,
          "rfeCases":false,
        "searchString":"",
        "statusIds":[24],
        "beneficiaryIds":[],
        "premiumProcessing":[],
        "stateIds":[],
        "locationIds":[],
        "petitionerIds":[],
        "branchIds":[],
        "typeIds":[1],
        "subTypeIds":[],
        //"getActiveCases":true,
        "deadlineDateRange":[],
        "getMissingDeadlines":false,
        "statusList":[], //get only rfe
        "intStatusIds":[],
        "assignedUserIds":[],
        "getFiledCases":false,
        "countryIds":[]
      },
      "page":1,"perpage":25,
      "sorting":{"path":"updatedOn","order":-1},
     
      
    }
    //this.checkProperty(this.visasubtype,'id') == 9 &&
    //alert(JSON.stringify(this.visatype));
   console.log(JSON.stringify(this.selectedBeneficiary));
    if( this.checkProperty(this.visatype,'id') == 9 && (this.checkProperty(this.selectedBeneficiary ,'_id') || this.beneficiaryId )){


      if(this.checkProperty(this.selectedBeneficiary ,'_id')){
            postData['matcher']['beneficiaryIds']=[];
            postData['matcher']['beneficiaryIds'].push(this.checkProperty(this.selectedBeneficiary ,'_id'));
            
          }else if(this.beneficiaryId){
            postData['matcher']['beneficiaryIds']=[];
            postData['matcher']['beneficiaryIds'].push(this.beneficiaryId);
            
          }

    
    this.$store.dispatch("commonAction", { "data": postData,"path":"/petition-common/list"}).then(response => {  
      let list = [];
     // caseNo
     if(this.checkProperty(response,'list','length') >0){
      list = response.list;
      list =  _.map(list,(item)=>{
        if(_.has(item, 'caseNo')){
          item['name'] = item['caseNo'];
          item['id'] = item['_id'];
          return item;

        }
      })

     }
      this.benficiaryH1BCases =list ;

    })
    }

    },
    updatedexpInYears(){
        if(this.checkProperty( this.permDetails, 'expInYears' )){
          this.permDetails.expInYears = parseInt(this.permDetails.expInYears);
        }
        

      }, 
    addPermNewSkill(){
      
      
            this.skillTextError =false;
            if(this.newSkill && this.newSkill.trim() !=''){

                let skil = this.newSkill.trim();
                if(this.permDetails['skills'].indexOf(skil) <=-1){
                    this.permDetails['skills'].push(skil);
                }

               
                this.newSkill ='';
                this.addSkill =false;
            }else{
                this.skillTextError =true;
            }
        },
        removePermSkill(index ){
            
            this.permDetails['skills'].splice(index ,1);
           // this.$emit('input', this.value);
        },
    getEducationList(){
            this.$store
                .dispatch("getmasterdata", "education_types")
                .then((response) => {
                    this.educationTypes = response;
                                     
                })
                },
    changedHoursPerWeek(){
    
      if(this.checkProperty( this.permDetails, 'hoursPerWeek')){

        this.permDetails['hoursPerWeek'] = parseInt(this.permDetails['hoursPerWeek']);
      }

    },
    resetPermData(callFromPermDocDelete=false){
      this.draftExtractInfo =null;
      let defaultPermDetails = {
            

            socCode:'',
            socDetails:null,
            jobTitle: '',
            minDegreeDetails:null,
            minDegree:null,
            skills:[],
            majorFieldsOfStudy:'',
            expInYears:null,
            workAddresses: [ {line1: null,  line2: null, aptType: null, locationId: null, locationDetails: null,stateId: null, stateDetails: null,   countryId: null,  countryDetails: null, zipcode: null }
            ],
            fullTimePosition: false,
             hoursPerWeek: '',
              wageRate: '',
             payFrequency: 'Month', // Year, Month, Bi-Weekly, Week, Hour
            description: '',
            permanentPosition: false,
            newPosition: false,
            permApplicationNo:'',

        }

        if(callFromPermDocDelete){
        _.forEach(this.permDetails , (item ,key)=>{
            if(_.has(defaultPermDetails ,key) && this.permDocPreFilledKyes.indexOf(key)>-1 ){

              this.permDetails[key] = defaultPermDetails[key];
             


            }

          });
        }else{

          this.permDetails =_.cloneDeep(defaultPermDetails);

        }
        this.draftExtractInfo =null
        this.permDocPreFilledKyes =[];
        this.$validator.reset();



    },

    updatesocCode(item){ 

      if(_.has( item ,'id')){
        this['permDetails']['socCode'] = item['id'];
      }
    },
    getMasterSocList(){

    let query = {};
    query["page"] = 1;
    query["perpage"] = 10000;
    query["matcher"] = { 
       "getInactiveListAlso": true
      };
    query["category"] = "soc_codes";


    this.$store
    .dispatch("getMasterData", query)
    .then((response) => {
      this.masterSocList =response.list
      

    //alert(this.perpage);
    })
    .catch(() => {
    this.masterSocList = [];

    });

    },
    //permDocPreFilledKyes
    prefillPermDocData(){
      this.draftExtractInfo =null;
      let _self =this;
      this.formerrors.msg ='';
      var _dt;
      this.permDocPreFilledKyes =[];
      this.$validator.reset();
    if(this.permDolDocs.length>0){
    this.uploading = true;  
    let path ="/common/extract-data-from-pdf";
    let postData ={
      "docType": "perm",
      documents:[],
    };
    
    //postData['documents'] = this.pwdResponse['documents']
    _.forEach(this.permDolDocs ,(doc)=>{
      postData['documents'].push(doc.path)
        //return doc.path;
    })
    this.$vs.loading();
    this.$store.dispatch('commonAction', {"data":postData ,"path":path})
        .then((response)=>{
          this.uploading = false;  
          let responseData = response['jobDetails'];
          _dt = _.cloneDeep(response['jobDetails']);
          this.draftExtractInfo =response;
        _.forEach(this.permDetails , (item ,key)=>{
            if(_.has(responseData ,key) && responseData[key]){
              
             
              if(key=="wageRate" && responseData[key]){
                let wageRate = responseData[key];
                const specialCharsRegex = /[^0-9.]/g;
                 // Use the replace() method to replace all special characters with an empty string
                 wageRate = wageRate.replace(specialCharsRegex, "");

                this.permDetails['wageRate'] = parseFloat(wageRate);
              }else if( key=="minDegree" , this.checkProperty(responseData ,'minDegree' )){
                    this.permDetails['minDegree'] = responseData['minDegree'];
                    this.permDetails['minDegreeDetails'] = _.find(this.educationTypes, {"id": parseInt(responseData['minDegree'])});
                    this.permDocPreFilledKyes.push("minDegree")
              }else if(key=="socCode"){
                this.permDocPreFilledKyes.push("socDetails");
                this.permDetails['socDetails'] = _.find(this.masterSocList, {"id":parseInt(responseData[key])});
               
              }else if(key=="skills") {

                let skils = responseData[key].split(',');
                this.permDetails['skills'] = _.map(skils,(skil)=>skil.trim())
                if(this.checkProperty(this.permDetails, 'skills', 'length' )>0){
                  this.permDocPreFilledKyes.push(key);
                }
               
              }else{
                this.permDetails[key] = responseData[key];
                this.permDocPreFilledKyes.push(key);
              }
              this.updatedexpInYears();


            }

          });
        
          this.permDetails =_.cloneDeep(this.permDetails);
          

          setTimeout(function(){
          _self.permDetails.workAddresses[0].locationId = responseData.workAddresses[0].locationId;
          _self.permDetails.workAddresses[0].locationDetails = responseData.workAddresses[0].locationDetails;
          },800)
          
          this.$vs.loading.close();

        }).catch((errr)=>{
          this.permDocFormatError =errr
         // this.prefillJobDetailsError = errr
          //this.showToster({message:errr,isError:true });
          this.uploading = false;  
          this.$vs.loading.close();
        });
      }

    },
    moveToTrash(val){
      if (val) {
        this.selectedPwdId = null;
        this.isLinkPwd = false;
      }
    },
    changePwdDoc(val){
      if(val){
        this.isLinkPwd = false;
        this.selectedPwdId =null;
      }
      this.setPwdFilled(true)
    },
    linkExistingPwd(val){
      if(val){
        this.isPwdFiled = false;
      }
    },
    assignPwdValue(val){
      if( val == 'havingPWD'){
        this.isPwdFiled = true;
        this.hasJobDetails  = true;
      }else{
        this.isPwdFiled = false;
        this.hasJobDetails  = false;
      }
      this.pwdStatus ='';
      this.resetPwdResponse();
     // this.hasJobDetails=false
      this.setJobDetails(false)
      this.selectedPwdId = null;
    },
    emitPwd(val){
      if(this.checkProperty(val,'_id')){
        this.selectedPwdId = val;
      }else{
        this.isLinkPwd = false;
        this.selectedPwdId = null;
      }
    },
    searchMe(){
    let self =this;
    this.page = 1;
    clearTimeout(this.debounce)
      this.debounce = setTimeout(() => {
        self.getpetitions(true ,false);
      }, 900)
      },
     classificationfun(){  
       let Payload ={
         "matcher": {
           "searchString":"",
           "typeIds": [3],//[3],
           "subTypeIds": [16],// [16],
           "classificationList":[],// ["EB3"],
           "petitionerIds": [],
           "beneficiaryIds": [],
           "statusIds": [],
           "createdDateRange": [],
           "premiumProcessing": []
         }
       }
      //  if(this.visatype.id && this.visasubtype.id){
      //    Payload["matcher"]["typeIds"] = [this.visatype.id];
      //    Payload["matcher"]["subTypeIds"] = [this.visasubtype.id];  
      //  }
      //  if(this.selectedPetitioner && _.has(this.selectedPetitioner,'_id')){
      //    Payload["matcher"]["petitionerIds"] = [this.selectedPetitioner._id]
      //  }
       if(this.selectedBeneficiary && _.has(this.selectedBeneficiary,'_id')){
         Payload["matcher"]["beneficiaryIds"] = [this.selectedBeneficiary._id]
       }
       if(this.classification){
         Payload["matcher"]["classificationList"] = [this.classification]
       }

       this.newPetitionFormSubmited =true;
          this.$store.dispatch("getList",{data:Payload ,path:'/petition-common/get-case-count'} )
           .then(response => {
             this.classificationResultList = response;
             if(this.classificationResultList>0){
              this.classificationpopup = true;
              this.newPetitionFormSubmited =false;
            }else{
             // alert('dhgj ghds')
             this.newPetitionFormSubmited =false;
             this.classificationpopup = false;
              this.createNewPetition('' ,true)
            }
             
           }).catch((err)=>{
            this.classificationpopup = false;
            this.newPetitionFormSubmited =false;
           })
             
 
      
     },
    
    checkInternalStatusTitle(){
      this.internalStatusTitle = 'Hold/Abandon/Delete Case'
      if(this.getUserRoleId == 50){
       this.internalStatusTitle= 'Hold/Abandon Case';
      }
      if(this.checkProperty(this.initStatusIdsFilter,'id') == 2){
        if([50].indexOf(this.getUserRoleId)<=-1){
          this.internalStatusTitle = 'Abandon/Delete Case'
        }
        else{
          this.internalStatusTitle = 'Abandon Case'
        }
      }
    },
    filterInternalStatus(){
      this.internalStatusList = _.cloneDeep(this.masterDataList)
      if([50].indexOf(this.getUserRoleId)>-1){
      this.internalStatusList =_.filter(this.internalStatusList ,(item)=>{
       return [1,4].indexOf(item.id)<=-1
      })
      }
      if(this.initStatusIdsFilter){
        let filterStatusId = parseInt(this.checkProperty(this.initStatusIdsFilter,'id'))
        if(filterStatusId == 3){
          this.internalStatusList = _.filter(this.internalStatusList ,(item)=>{
          return [filterStatusId,1].indexOf(item.id)<=-1
          })
        }
        else{
          this.internalStatusList = _.filter(this.internalStatusList ,(item)=>{
          return [filterStatusId].indexOf(item.id)<=-1
          })
        }
      }
    },
    getInternalStatusList(){
        let postData ={
      page:1,
    perpage: 1000,
    category:"case_internal_status",      
        }
    this.$store.dispatch("getMasterData",postData ).then(response => { 
      this.masterDataList = response.list;
      
      if([50].indexOf(this.getUserRoleId)>-1){
      this.internalStatusList =_.filter(response.list ,(item)=>{
       return [1,4].indexOf(item.id)<=-1
      })
    }
    else{
      this.internalStatusList = this.masterDataList
    }
    if(this.checkProperty(this.$route ,'query' ,'filter')){
      try{
        let filter =this.$route['query']['filter']; this.checkProperty(this.$route ,'query' ,'filter')
        var actual = JSON.parse(atob(filter));
        let keys = Object.keys(actual);
        if(this.checkProperty(keys ,'length') >0){
         //initStatusIdsFilter
        
        //  if(_.has(actual ,'matcher')){
        //   if(_.has(actual['matcher'] ,'intStatusIds') && this.checkProperty(actual['matcher'] ,'intStatusIds' ,'length')>0){
        //         let selectedIntStsid =actual['matcher']['intStatusIds'][0];
        //         this.initStatusIdsFilter = _.find(this.internalStatusList ,{'id':selectedIntStsid} );  
        //   }

        //  }
  
        }

      }catch(e){
      }       
    }
     });   
      },

    checkDeletedDocs(val){
      this.internalErrMsg=''
      if(this.checkProperty(val, 'id')==1 ||this.checkProperty(val, 'id')==4 ){
        this.permDeleteDocs = []
      }
    },
    getCategoryForCase(){
      let item ={
          matcher:{
           
          },   
          page:this.page,
          perpage: 10000,
          category: "case_category",  
      };
      this.$store.dispatch("getMasterData",item ).then(response => {   
        this.categoryList = response.list;   
       
      });
    },
    loadingFields(item){
      this.$refs['jobComponent'].checkVislibilty(item)
    },
    resetPrefedKyes(){
      this.draftExtractInfo =null;
      this.pwdStatus = ''
      this.classification =''
      this.disablePWDstatus = false
      let tempJobDetails = {
      wageRate: "",
      socOccuTitle: "",
      preferredSocOccuTitle:"",
      
      socCode: "",
			jobTitle: "",
			preferredSocCode: '',
      preferredSocCodeDetails:null,
			classification: "",
			description: "",
			skills: [],
			minDegree: '',
			majorFieldsOfStudy: "",
			expInYears: "",
      altJobRequirements: {

      // Are alternate sets of Education, Training, and/or Experience accepted? "Yes", "No"

      areAltSetsOfEducation:"",// { type: String},
      altevelOfEducation: null,//{ type: Schema.Types.ObjectId, default: null  }, //0bjectId
      altevelOfEducationDetails:null,
      usDiplomaOrDegreeAccepted:'', //{type: String},
      majorsOrFieldsOfStudyAccepted: '',//{type: String},
      isAltTrainingForTheJobOpporAccepted: '',//"Yes" Or "No"
      noOfMonthsOfAltTrainingAccepted: null,//{type: String},
      filedsOrNamesOfTrainingAccepted: "",//{ type: String },
      altEmpExpAccepted: "", //"Yes" Or "No"
      noOfMonthsAltEmpExpAccepted:null,
      splSkillOrOtherRequi:'',
      ForeignLanguage:'',
      LicenseCertification:'',
      residencyFellowship:'',
      otherSplSkillsOrRequi:''

      },
			workAddresses: [{
				"companyName": "",
				"line1" : "",
				"line2" : "",
				"aptType": "",
				"locationId" :'' ,
				"stateId" :'' ,
				"countryId" :'' ,
				"zipcode" : "",
				"locationDetails" : {
					"id" : '',
					"name" : "",
					"stateId" : '',
					"countryId" :'' 
				},
				"stateDetails" : {
					"id" :'' ,
					"name" : "",
					"shortName" : "",
					"countryId" : ''
				},
				"countryDetails" : {
					"id" : 231,
					"shortName" : "US",
					"name" : "United States",
					"phoneCode" : 1,
					"order" : 1,
					"currencySymbol" : "$",
					"currencyCode" : "USD",
					"zipcodeLength" : 5
				},
				"workLocation": true
			}]
		}
      _.forEach(this.jobDetails , (item ,key)=>{
            if(this.prefilledKyes.indexOf(key)>-1){
              this.jobDetails[key] = null;
              if(_.has(tempJobDetails , key)){
                this.jobDetails[key] = tempJobDetails[key];
              }else{
                this.jobDetails[key] = null;
              }
            }
        }); 
        
        
        if(  this.prefilledKyes.indexOf('issuedDate')>-1){
          this.pwdResponse['issuedDate'] = null;
        }
        if( this.prefilledKyes.indexOf('receivedDate')>-1){
          this.pwdResponse['receivedDate'] = null;
        }
        if( this.prefilledKyes.indexOf('dueDate')>-1){
          this.pwdResponse['dueDate'] = null;
        }
        if( this.prefilledKyes.indexOf('pwdDocCaseNo')>-1){
          this.pwdResponse['pwdDocCaseNo'] = '';
        }
        
            
        //this.pwdStatus = ''
        this.prefilledKyes =[];
        this.draftExtractInfo =null;
        this.$validator.reset();

    },
    prefillJobDetails(){
      this.draftExtractInfo = null;
      var _dt;
      this.prefilledKyes =[];
      this.$validator.reset();
    if(this.pwdResponse.documents.length>0){
    this.uploading = true;  
    let path ="/common/extract-data-from-pdf";
    let postData ={
      "docType": "pwd",
      documents:[],
    };
    //postData['documents'] = this.pwdResponse['documents']
    _.forEach(this.pwdResponse['documents'] ,(doc)=>{
      postData['documents'].push(doc.path)
        //return doc.path;
    })
    this.$vs.loading();
    this.$store.dispatch('commonAction', {"data":postData ,"path":path})
        .then((response)=>{
          this.$vs.loading.close();
          this.uploading = false;  
          let responseData = _.cloneDeep(response['jobDetails']);
          _dt = _.cloneDeep(response['jobDetails']);
          this.draftExtractInfo =response;
          _.forEach(this.jobDetails , (item ,key)=>{
            if(_.has(responseData ,key) && responseData[key]){
              
              this.jobDetails[key] = responseData[key];
              this.prefilledKyes.push(key);


            }

          });
          _.forEach(this.pwdResponse , (item ,key)=>{
            if(_.has(responseData ,key) && responseData[key]){
              this.pwdResponse[key] = responseData[key];
              this.prefilledKyes.push(key);
            }

          });
           


          if(this.checkProperty(responseData,'pwdStatus')){
            this.pwdStatus = this.checkProperty(responseData,'pwdStatus')
            this.disablePWDstatus = true
            this.loadingFields(this.pwdStatus)
          }
          else{
            this.disablePWDstatus = false
          }
          this.jobDetails =_.cloneDeep(this.jobDetails);
          var _self = this;
          setTimeout(function(){

            if(_.has(responseData,'issuedDate')){
            _self.pwdResponse['issuedDate'] = _.cloneDeep(responseData['issuedDate']);
            }
            if(_.has(responseData,'receivedDate')){
            _self.pwdResponse['receivedDate'] = _.cloneDeep(responseData['receivedDate']);
            }
            if(_.has(responseData,'dueDate')){
            _self.pwdResponse['dueDate'] = _.cloneDeep(responseData['dueDate']);
            }
            if(_.has(responseData,'pwdDocCaseNo')){
            _self.pwdResponse['pwdDocCaseNo'] = _.cloneDeep(responseData['pwdDocCaseNo']);
            _self.prefilledKyes.push('pwdDocCaseNo');
            }

            if(_self.checkProperty(responseData ,'workAddresses' ,"lemgth") >0){

            
            _self.jobDetails.workAddresses[0].stateDetails = responseData.workAddresses[0].stateDetails;
            _self.jobDetails.workAddresses[0].stateId = responseData.workAddresses[0].stateId;
            }


          },500)

          if(_self.checkProperty(responseData ,'workAddresses' ,"lemgth") >0){
          setTimeout(function(){
          _self.jobDetails.workAddresses[0].locationId = responseData.workAddresses[0].locationId;
          _self.jobDetails.workAddresses[0].locationDetails = responseData.workAddresses[0].locationDetails;
          },800)
        }


        }).catch((errr)=>{
          this.$vs.loading.close();
          this.prefillJobDetailsError = errr
          //this.showToster({message:errr,isError:true });
          this.uploading = false;  
        });
      }

    },
    
    updateissuedDate(val){
      if(val){
      //   if(this.pwdResponse['receivedDate']){
      //   let startData = moment(val);
      //   let endData= moment(this.pwdResponse['receivedDate'])
      //   if(startData.isAfter(endData , 'day')){
      //     this.pwdResponse['receivedDate'] = null
      //   }
      // }
      if(this.pwdResponse['dueDate']){
        let startDate = moment(val);
        let endDate= moment(this.pwdResponse['dueDate'])
        if(startDate.isAfter(endDate , 'day')){
          this.pwdResponse['dueDate'] = null
        }
      }
      }
      else{
        this.pwdResponse.dueDate = null
      }
    },
    resetPwdResponse(fromInput=false){
    this.pwdDocFormatError ='';
    if(fromInput){

      this.pwdResponse['issuedDate'] = null;
      this.pwdResponse['receivedDate'] = null;
      this.pwdResponse['dueDate'] = null;
      this.pwdResponse['description'] = '';
      this.pwdResponse['documentType'] = "Original";
      this.pwdResponse['pwdDocCaseNo'] = "";
      

   
    }else{

      this.pwdResponse = {
      "issuedDate": null,
      "receivedDate": null,
      "dueDate": null,
      "description": "",
      "documents": [],
      "documentType": "Original",
      "pwdDocCaseNo":''

    }
    }
  

    },
    setPwdFilled(callFromCheckBox=false){
      this.pwdDocFormatError ='';
      if(!callFromCheckBox){
        this.isPwdFiled = false;
        
      }
     
      
      this.pwdStatus ='';
      this.resetPwdResponse();
     // this.hasJobDetails=false
      this.setJobDetails(false)
      this.hasJobDetails = this.isPwdFiled;
      this.$validator.reset();
    },
    setJobDetails(item){
      if(!item){
       this.jobDetails={
        wageRate:'',
        jobTitle: "",
        socCode:'',
        socCodeDetails:null,
        preferredSocCode: '',
        socOccuTitle: "",
        preferredSocOccuTitle:"",
        preferredSocCodeDetails:null,
        classification: "",
        description: "",
        skills: [],
        minDegree: '',
        majorFieldsOfStudy: "",
        expInYears: "",
        altJobRequirements: {

        // Are alternate sets of Education, Training, and/or Experience accepted? "Yes", "No"

        areAltSetsOfEducation:"",// { type: String},
        altevelOfEducation: null,//{ type: Schema.Types.ObjectId, default: null  }, //0bjectId
        altevelOfEducationDetails:null,
        usDiplomaOrDegreeAccepted:'', //{type: String},
        majorsOrFieldsOfStudyAccepted: '',//{type: String},
        isAltTrainingForTheJobOpporAccepted: '',//"Yes" Or "No"
        noOfMonthsOfAltTrainingAccepted: null,//{type: String},
        filedsOrNamesOfTrainingAccepted: "",//{ type: String },
        altEmpExpAccepted: "", //"Yes" Or "No"
        noOfMonthsAltEmpExpAccepted:null,
        splSkillOrOtherRequi:'',
        ForeignLanguage:'',
        LicenseCertification:'',
        residencyFellowship:'',
        otherSplSkillsOrRequi:''

        },
        workAddresses: [{
          "companyName": "",
          "line1" : "",
          "line2" : "",
          "aptType": "",
          "locationId" :'' ,
          "stateId" :'' ,
          "countryId" :'' ,
          "zipcode" : "",
          "locationDetails" : {
            "id" : '',
            "name" : "",
            "stateId" : '',
            "countryId" :'' 
          },
          "stateDetails" : {
            "id" :'' ,
            "name" : "",
            "shortName" : "",
            "countryId" : ''
          },
          "countryDetails" : {
            "id" : 231,
            "shortName" : "US",
            "name" : "United States",
            "phoneCode" : 1,
            "order" : 1,
            "currencySymbol" : "$",
            "currencyCode" : "USD",
            "zipcodeLength" : 5
          },
          "workLocation": true
			}]
		   }
      }
    },

    checkBenPermStatus(){
      
      this.resetPermData();
     this.category=null;
     this.classification =null
     
      if(this.checkProperty(this.visasubtype,'id') != 15){
        this.isPwdFiled = false;
        this.setPwdFilled();
      }
      
      this.permDolDocs = [];
      this.Dol140Docs=[];
      this.responsePermId =''
      this.response140Id=''
      this.permDocRequired = false;
      this.Doc140Required =false,
      this.formerrors.msg ='';
      this.enableSubmitBtn =true;
      
      
      if(this.checkProperty(this.visatype,'id')== 3 &&
        this.checkProperty(this.visasubtype,'id')== 16 &&
        (this.checkProperty(this.selectedBeneficiary ,'_id')|| this.beneficiaryId )){

          let postData={
            userId:this.checkProperty(this.selectedBeneficiary ,'_id')
          }
          if(this.checkProperty(this.selectedBeneficiary ,'_id')){
            postData={
            userId:this.checkProperty(this.selectedBeneficiary ,'_id')
            }
          }else if(this.beneficiaryId)(
            postData={  userId:this.beneficiaryId  }
          )
          this.$store.dispatch('commonAction', {"data":postData ,"path":"/perm/get-perm-filed-docs"})
          .then((response)=>{
            let responseData = response;

            
         
           
            if(this.checkProperty(responseData,'code') == "REQUIRED_PERM_DOCS"){
              this.permDocRequired  = true;
              this.enableSubmitBtn =true;
            }
            else{
              if(this.checkProperty(responseData,'permId')){
                if(  this.checkProperty(responseData,'permDocs','length')>0){
                  this.responsePermId = this.checkProperty(responseData,'permId')
                  this.permDolDocs =this.checkProperty(responseData,'permDocs');
                  this.enableSubmitBtn =true;
                } 
                else{  
                  this.formerrors.msg ="Unable to create the I-140 Case";
                  this.enableSubmitBtn =false;
                }
                if(this.checkProperty(responseData,'jobDetails','classification')){
                  this.classification = this.checkProperty(responseData,'jobDetails','classification')
                }
              }
              else{
                this.formerrors.msg ="Unable to create the I-140 Case";
                this.enableSubmitBtn =false;
              }
            }
          }).catch((error)=>{
            this.formerrors.msg = error;
            this.enableSubmitBtn =false;
          })
      }
      //485 case type
      if(this.checkProperty(this.visatype,'id')== 3 && this.checkProperty(this.visasubtype,'id')== 17 && this.checkProperty(this.selectedBeneficiary ,'_id')){
        this.Dol140Docs =[];
        this.Doc140Required =false,
        this.formerrors.msg ='';
        this.enableSubmitBtn =true; 
        let postData={
            userId:this.checkProperty(this.selectedBeneficiary ,'_id'),
            type:this.checkProperty(this.visatype ,'id') ,
            subType:this.checkProperty(this.visasubtype ,'id'),
          }
          this.$store.dispatch('commonAction', {"data":postData ,"path":"/petition/get-i140-filed-docs"})
          .then((response)=>{
            let responseData = response;
           
            if(this.checkProperty(responseData,'code') == "REQUIRED_DOCS"){
              this.Doc140Required  = true;
              this.enableSubmitBtn =true;
            }
            //i140Docs
            //i140Id
            else{
              if(this.checkProperty(responseData,'i140Id')){
                if(this.checkProperty(responseData,'i140Docs','length')>0){
                  this.response140Id = this.checkProperty(responseData,'i140Id')
                  this.Dol140Docs =this.checkProperty(responseData,'i140Docs');
                  this.enableSubmitBtn =true;
                } 
                else{  
                  this.formerrors.msg ="Unable to create the I-485 Case";
                  this.enableSubmitBtn =false;
                }
              }
              else{
                this.formerrors.msg ="Unable to create the I-485 Case";
                this.enableSubmitBtn =false;
              }
            }
          }).catch((error)=>{
            this.formerrors.msg = error;
            this.enableSubmitBtn =false;
          
          })
          
      }
    },
    selectAllforArchive(){
              this.formerrors.msg ='';
          this.selectedForArchiveList =[];
        _.forEach(this.petitioners ,(item)=>{
          item.selectedForArchive =false;
          if(this.selectedAllForArchive && this.checkProperty(item ,'status')!=false){
             item.selectedForArchive =true;
             this.selectedForArchiveList.push(item._id)

          }
         
        })

      if(this.petitioners.length>0 && this.petitioners.length != this.selectedForArchiveList.length ){
        this.selectedAllForArchive =false;
      }
     
      

    },
    archiveAction_BACKUP(){
       this.formerrors.msg ='';
       this.$validator.validateAll("permDeletForm").then((result) => {

     if(result){
      this.internalErrMsg = '';
        let postData ={
        "petitionIds":[],
        "intStatusId": '', // 1. Active 2. On Hold 3. Abandoned 4. Deleted
        "comments": ""
        };
        postData['intStatusId']= this.internalStatusDetails['id']
        postData['comments']= this.internalComments;
        postData['petitionIds'] = this.selectedForArchiveList;
        
       if(this.checkProperty(this.internalStatusDetails, 'id') ==2 || this.checkProperty(this.internalStatusDetails, 'id') ==3){
          if(this.permDeleteDocs){
            
            postData['documents']= this.permDeleteDocs;
          }
        }
        else{
          this.permDeleteDocs = [];
          postData['documents'] = [];
        }
        let finalList = []

        let archiveItem = _.filter(this.petitioners, (item)=>{

             return this.selectedForArchiveList.indexOf(item._id)>-1 && this.internalStatusDetails['id'] != this.checkProperty(item ,"intStatusDetails",'id')
         });
         finalList = archiveItem.map((item)=>item._id);
        postData['petitionIds']=finalList
        if(this.checkProperty(finalList,'length')==0 && this.checkProperty(this.internalStatusDetails, 'id') ){
          this.internalErrMsg = 'Selected Cases are in same status'
          return false
        }
        this.archiving =true;
        this.$store
        .dispatch("commonAction", {"data":postData ,"path":"/petition-common/update-internal-status"})
        .then(response => {
          
          this.archiving =false;
          this.selectedForArchiveList =null;
          this.internalStatusDetails =null;
          this.internalComments=null;
          this.showToster({message:response.message,isError:false });
          this.$modal.hide('conformArchivemodal');
          this.getpetitions();
                                          
                          
        })
        .catch((error)=>{
            this.formerrors.msg  =error
        //  this.showToster({message:error,isError:true });
          this.archiving =false;
        })

    }


  })

    },
    archiveAction(){
       this.formerrors.msg ='';
     let postData ={
       "petitionIds":[]
     };
     postData['petitionIds'] = this.selectedForArchiveList;
     this.archiving =true;
      this.$store
              .dispatch("commonAction", {"data":postData ,"path":"/petition/delete"})
              .then(response => {
               
                this.archiving =false;
                this.selectedForArchiveList =[];
                this.showToster({message:response.message,isError:false });
                this.$modal.hide('conformArchivemodal');
                this.getpetitions();
                                               
                                
              })
              .catch((error)=>{
                 this.formerrors.msg  =error
              //  this.showToster({message:error,isError:true });
                this.archiving =false;
              })

    },

    selectForArchive(caseItem){
       
             this.formerrors.msg ='';
        if(this.archiving ){
         return false
       }else{
         this.archiving =false
       if(this.checkProperty(caseItem ,'selectedForArchive') && this.checkProperty(caseItem ,'status') !=false){
         if(this.selectedForArchiveList.indexOf(caseItem['_id'])<=-1){
            this.selectedForArchiveList.push(caseItem['_id'])

         }

       }else{
          this.selectedForArchiveList = _.filter( this.selectedForArchiveList ,(item)=>{
           return item !=caseItem['_id']
          })
       }

    }
    this.selectedAllForArchive =false
    if(this.petitioners.length==this.selectedForArchiveList.length && this.selectedForArchiveList.length>0){
      this.selectedAllForArchive =true
    }
       

     },
    


      
    addNewBenFromTag(){

    },
     searchPet(searchText=''){
          let _self =this;
     
      
      this.selectedBeneficiary =null;
      this.selectedPetitioner =null;
      this.selectedUser ='';
      this.selectedUsername = '';

      let self =this;
    clearTimeout(self.debounce)
    self.debounce = setTimeout(() => {
        self.getPetitioners(self ,searchText);
      }, 900)
    
      // let filteredData =[];
      //  _.forEach(_self.petitionersList ,(item)=>{
      //           if( item && ( _.has(item ,'name') || _.has(item ,'email')  )){

      //                    if((_.has(item ,'name') && item['name'].includes(searchText)) || (_.has(item ,'email') && item['email'].includes(searchText)) ){
      //                     filteredData.push(item)
      //                    }else{
      //                       return false;
      //                    }

      //           }else{
      //             return false;
      //           }
              
           
      //    })
      //  if( (filteredData.length<=0 )){
      //    this.getPetitioners(true ,searchText);
      //  }
       //this.getPetitioners(true ,searchText);
         
     },
    addNewPet(newPet='' ,id){
       this.newPetOpenFromben =false;
       this.openNewbenForm =false;
       this.addNewPete =true;
       this.invitePetitionPopupshow(true)
     },
    petitionerUpdated(){
      this.selectedBeneficiary = null;
      this.selectedUser ='';
      this.selectedUsername = '';
      this.resetRfeData(true);
      this.getbeneficiaryMasterDataList();
      this.selectedPwdId = null;
      this.isLinkPwd = false;
      this.getBenficiaryH1BCases();
    },

     getvisatypes(){
      this.$store.dispatch("getvisatypes").then(response => {
        this.visatypes = [];//response;
        let placedobj = null
        let obj = {"_id":"632953d43ecbeaeefe93efefr","id":'ALL',"name":"All","isCaseTypeSelected":true}
        placedobj = _.find(this.visaTypes,{'id':'ALL'})
        if(placedobj == null || !placedobj){
          this.visaTypes.push(obj)
        }

        _.forEach(response ,(item)=>{
                    this.visaTypes.push(item)
          });
          if([50,51].indexOf(this.getUserRoleId)>-1){
            this.activeVisatypes = _.filter(response ,(item)=>{
           return item.id !=3
          })
          }else{
            this.activeVisatypes = response
          }
        
      });
      
    },
    getvisaforNewCase(){


      let item ={
          matcher:{
             // "searchString":this.searchtxt,
            
             getActiveList:true,

          },   
          page:this.page,
          perpage: this.perpage,
          category: "petition_types",
         
          
        };
        this.visatype =null;
        this.$store.dispatch("getMasterData",item ).then(response => {
          
          if([51].indexOf(this.getUserRoleId)>-1){
            this.activeVisatypes = _.filter(response.list ,(item)=>{
           return item.id !=3
          })
          }else{
            this.activeVisatypes = response.list
          }

        //  this.activeVisatypes = response.list; 
          /*
          this.activeVisatypes = _.filter(this.activeVisatypes ,(item)=>{
           return item.id !=3
          });
          */
          
         
          if(this.checkProperty(this.activeVisatypes ,'length')>0){
            this.visatype = this.activeVisatypes[0];
           


            if(this.checkProperty(this.$route ,'query' ,'filter')){
                try{
                  let filter =this.$route['query']['filter']; this.checkProperty(this.$route ,'query' ,'filter')
                  var actual = JSON.parse(atob(filter));
                  let keys = Object.keys(actual);
                  if(this.checkProperty(keys ,'length') >0){


                    if(actual && (Object.keys(actual)).length>0 ){
                    _.forEach(actual ,(item ,key) => {
                        if(key=='matcher' ){
                          
                          if((Object.keys(item)).length>0 ){

                            if(_.has(item ,'typeIds') && this.checkProperty(item , 'typeIds' ,'length')>0 ){
                               
                              let visatype = _.find(this.activeVisatypes ,{"id":item['typeIds'][0]})
                              if(visatype){
                                this.visatype = visatype;
                               this.getvisasubtypes();
                               
                              }
                           
                            
                           
                            }

                            
                            
                          }
                        
                        }
                      
                        
                    
                    })
                  }
                    
                    
                  }

                }catch(e){
                  

                }
                  
              }

            
              this.getvisasubtypes(this.visatype)


        }
        
        
        
        });


      
    },
    getvisasubtypes(vsType){
      this.isPetitioner =true;
      
      this.setPwdFilled()
     Object.assign(this.formerrors , {msg:''});
     this.selectedPwdId = null;
     this.isLinkPwd = false;
     this.isPwdFiled = false;
    if(this.visatype && _.has(this.visatype ,"id")){
      if(!this.callFromCapCaseCreation){
        this.visasubtypes =[];
      this.visasubtype = null;
      }
      
     
    
        let item ={
          matcher:{
             // "searchString":this.searchtxt,
             "petitionType":parseInt(this.visatype['id']),
             getActiveList:true,

          },   
          page:this.page,
          perpage: this.perpage,
          category: "petition_sub_types",
         
          
        };
        
        this.$store.dispatch("getMasterData",item ).then(response => {
          if(response['list']){
            this.visasubtypes = response['list'];
            // if(parseInt(this.visatype['id'])==2 && this.checkProperty(this.visasubtypes, 'length') >0){
            //   this.visasubtype =this.visasubtypes[0]
            // }
           
          }
           });
        this.$validator.reset();
        }

        if(this.checkProperty(this.visatype ,"id") ==9){
            this.getBenficiaryH1BCases();
            
          }else{
            this.resetRfeData(true);
            
          }
    },
    createNewPerm( errorCode=''){
      Object.assign(this.formerrors, {
                  msg: ''
                })

            this.$validator.validateAll('newpetitionform').then(result => {
        if (result) {
          let self =this;
          // premiumProcessing:this.premiumProcessing,
      var postdata ={
        type: this.visatype.id,
        userId:this.selectedUser,
        userName:this.selectedUsername,
        typeName:this.visatype.name,
        subType:this.visasubtype.id,
        subTypeName:this.visasubtype.name,
        petitionerId:null,
        branchId:'',
        today: moment().format('YYYY-MM-DD'),
        isPwdFiled:this.isPwdFiled,
        pwdStatus:this.pwdStatus,
        hasJobDetails:this.hasJobDetails
      };
      if(this.getTenantTypeId !=2){
        if([50].indexOf(this.getUserRoleId) > -1){
           postdata['petitionerId'] = this.$store.state.user._id

        }else{
           postdata['petitionerId'] = this.checkProperty(this.selectedPetitioner ,"userId")
        }
       

      }

      if(this.checkProperty(this.beneficiaryInfo ,"name") && this.beneficiaryId){
        postdata['userId'] = this.beneficiaryId;
        postdata['userName'] =this.beneficiaryInfo['name']

  }
     
     
      if(this.selectedBranch && _.has(this.selectedBranch ,"_id")){
        postdata['branchId'] =this.selectedBranch['_id']
      }
      if(this.isPwdFiled){
        postdata['isPwdFiled'] = this.isPwdFiled
        if(!_.has(postdata ,'pwdResponse' )){
                postdata = Object.assign( postdata , {'pwdResponse':{}})
            }
           
        if(this.pwdStatus =='Certified'){
          postdata['pwdResponse']['documentType'] = "";
          
          if(this.pwdResponse['pwdDocCaseNo']){
            postdata['pwdDocCaseNo']  = this.pwdResponse['pwdDocCaseNo'];
          }

          if(this.pwdResponse['issuedDate']){
            postdata['pwdResponse']['issuedDate'] = moment(this.pwdResponse['issuedDate']).format("YYYY-MM-DD");
          }
          if(this.pwdResponse['receivedDate']){
            postdata['pwdResponse']['receivedDate'] = moment(this.pwdResponse['receivedDate']).format("YYYY-MM-DD");
          }

          if(this.pwdResponse['dueDate']){
            postdata['pwdResponse']['dueDate'] = moment(this.pwdResponse['dueDate']).format("YYYY-MM-DD");
          }
         
          postdata['pwdResponse']['description'] = this.pwdResponse['description'];

        }
        postdata['pwdStatus'] = this.pwdStatus;
        postdata['pwdResponse']['documents'] = this.pwdResponse['documents'];    
      }
      if(this.hasJobDetails){
        postdata['hasJobDetails'] = this.hasJobDetails
        postdata['jobDetails'] = _.cloneDeep(this.jobDetails)
        
       
      }
      if(this.isPwdFiled){
          postdata['draftExtractInfo']= this.draftExtractInfo;
        }
      if(errorCode && this.caseErrorCode){
        if(errorCode == 'true'){
          postdata['replaceDefaultUser'] = true
        }
        else{
          postdata['replaceDefaultUser'] = false
        }
      }
      if(self.isLinkPwd && self.checkProperty(self.selectedPwdId,'_id')){
        postdata['pwdId'] =  self.checkProperty(self.selectedPwdId, '_id')
      }
      if(!this.newPetitionFormSubmited){
        this.newPetitionFormSubmited =true;

        this.$modal.hide('errorConfirmationModal');
        this.$store.dispatch("commonCaseAction", {"data":postdata ,"path":"/perm/create"})
        .then(response => {
              this.premiumProcessing = false;
                 if (response.error) {
                Object.assign(this.formerrors, {
                  msg: response.error.message
                });
                this.newPetitionFormSubmited =false;
              } else {
                // if(self.isLinkPwd && self.checkProperty(self.selectedPwdId,'_id')){
                //   let obj={
                //     caseNo:self.checkProperty(response,'caseNo'),
                //     _id:self.checkProperty(response,'_id'),
                //   }
                //   this.linkPwd(obj)
                // }
                this.caseErrorDetails = null
                this.caseErrorCode = ''
                this.caseCreationErrMsg = ''

                   let dt ={
                  petitionId: response._id,
                  userName: this.selectedUsername,
                  email: this.selectedUseremail,
                  typeName: this.visatype.name,
                  subTypeName: this.visasubtype.id,
                  instructions: null
                };
                this.addNewCase(false);
                        this.NewPetition =false; 
                         this.newPetitionFormSubmited =false;
                         this.getpetitions();
                      //this.$vs.notify({title: "Success",text: response.message });

                        this.visatype = {
                        id: 1,
                        name: "H-1B"
                        }
                        this.getvisasubtypes(this.visatype);
                       this.showToster({message:response.message ,isError:false});
                       
                       setTimeout(()=>{
                         if(self.checkProperty(self.selectedBeneficiary ,"anonymousUser" )){
                          this.$router.push({ name: 'gc-employment-details', params: { itemId: response._id } }).catch(err => { })
                         }else{
                          this.$router.push({ name: 'gc-employment-details', params: { itemId: response._id } }).catch(err => { })
                          // this.clear_filter();

                         }
                          
                           
                       } ,10)

                      
                     
              }

        })
        .catch((error)=>{
          //this.showToster({message:error,isError:true});
          let errorr = error.result.error
          this.caseErrorCode = '';
          //this.showToster({message:error,isError:true}); 
          this.newPetitionFormSubmited =false;
          if(_.has(errorr,'code') && this.checkProperty(errorr,'code')){
            this.caseErrorCode = this.checkProperty(errorr,'code')
            this.caseCreationErrMsg = this.checkProperty(errorr,'message')
            this.$modal.show('errorConfirmationModal');
            this.caseErrorDetails ={
              subType:this.visasubtype.id
            }
          }
          else{
            Object.assign(this.formerrors, {
              msg: errorr.message
            });
          }  
        });

      }
      
      
 }else{
          const $ = JQuery;
              if($('.errorScroll .text-danger:visible')){
                var _t = $('.errorScroll .text-danger:visible').first().parent().offset().top;
                if(_t < 0) _t = -(_t)
                  $('.scrollable:visible').scrollTop(_t-50);
                }
             }


});
    },
    linkPwd(val){
      let self = this
      let postData ={
        caseNo:val['caseNo'],
        petitionIds :[val['_id']] ,
        comments:'',
        pwdId: self.checkProperty(self.selectedPwdId, '_id')
      };
      let path = "/pwd/manage-pwd-linking";
      this.$store .dispatch("commonAction", { "data": postData, "path": path }) .then(response => {
        this.showToster({ message: response.message, isError: false });
      }).catch((error) => {
       
      })
    },
    fileNewCase(){
      this.pwdDocFormatError ='';
      if(this.checkProperty(this.visasubtype ,'id' )==15){
        this.createNewPerm()
      }else{

        this.createNewPetition()
      }

    },
    createCaseWithReplace(errorCode=''){
      if(this.checkProperty(this.caseErrorDetails,'subType') == 15){
        this.createNewPerm(errorCode ,true)
      }
      else{
        this.createNewPetition(errorCode,true)
      }
    },
    
    createNewPetition(errorCode='' ,callFromConform=false){
     
      Object.assign(this.formerrors, {
                  msg: ''
                })

            this.$validator.validateAll('newpetitionform').then(result => {
        if (result) {
          
          if(this.checkProperty(this.visasubtype ,'id' )==16 && !callFromConform && errorCode==''  ){
           
          this.classificationfun();
          
          this.newPetitionFormSubmited =true;
          return false;
        }
        if(!callFromConform ){
          this.caseErrorCode =''
        }
       
          let self =this;
      var postdata ={
        type: this.checkProperty(this.visatype, 'id'),
        userId:this.selectedUser,
        userName:this.selectedUsername,
        typeName:this.checkProperty(this.visatype, 'name'),
        subType:this.checkProperty(this.visasubtype, 'id'),
        subTypeName:this.checkProperty(this.visasubtype, 'name'),
        petitionerId:null,
        premiumProcessing:false,
        branchId:'',
        today: moment().format('YYYY-MM-DD'),
       // replaceDefaultUser:false
       
      };

       //h4 case sub types
      if(this.checkProperty(this.visatype,'id') == 2){
        postdata['subType'] = 12;
        postdata['subTypeName'] = '';
      }
      //h4 Ead  sub types
      if(this.checkProperty(this.visatype,'id') == 10){
        postdata['subType'] = 13;
        postdata['subTypeName'] = '';
      }

      if(this.checkProperty(this.visatype,'id') != 2){
        postdata['premiumProcessing'] =this.premiumProcessing
      }
      if(this.checkProperty(this.visatype,'id')== 3 && this.checkProperty(this.visasubtype,'id')== 16 &&
         this.checkProperty(this.permDolDocs,'length')>0 && this.classification !=''){
        postdata['classification'] = this.classification
        postdata['categoryId'] = this.checkProperty(this.category, 'id')
        postdata['permId'] = this.responsePermId
        postdata['permDocs'] = this.permDolDocs;
        if(this.permDocRequired){
          postdata['jobDetails'] = _.cloneDeep(this.permDetails);
          postdata['draftExtractInfo']= this.draftExtractInfo
        }
       
      }
      if(this.checkProperty(this.visatype,'id')== 3 && this.checkProperty(this.visasubtype,'id')== 17 &&
         this.checkProperty(this.Dol140Docs,'length')>0){
        postdata['i140Id'] = this.response140Id
        postdata['i140Docs'] = this.Dol140Docs
      }
      
      /*
       category: '',
        permId: '',
        permDocs:''
      */
      
        if(errorCode == 'true'){
          postdata['replaceDefaultUser'] = true
        }
        if(errorCode == 'false'){
          postdata['replaceDefaultUser'] = false
        }
        
      if(this.getTenantTypeId !=2){
        if([50].indexOf(this.getUserRoleId) > -1){
           postdata['petitionerId'] = this.$store.state.user._id

        }else{
           postdata['petitionerId'] = this.checkProperty(this.selectedPetitioner ,"userId")
        }
       

      }
      
      if(this.callFromCapCaseCreation){
        postdata['capRegId'] = this.capRegId
      }

      if(this.callFromBen && this.beneficiaryId){
        postdata['userId'] = this.beneficiaryId;
        postdata['userName'] = this.checkProperty(this.beneficiaryInfo ,"name")

  }
     
     
      if(this.selectedBranch && _.has(this.selectedBranch ,"_id")){
        postdata['branchId'] =this.selectedBranch['_id']
      }
      //rfe case creation
     if(this.checkProperty(this.visatype,'id')== 9){
         postdata['premiumProcessing'] =false
       
        postdata['rfeIntExtOption'] =this.checkProperty(this.rfeData ,"rfeInternalCase" )  =='internalCase'?'internal':'filed_separately'
        postdata['documents'] = this.rfeData['docs'];
        if(this.checkProperty(this.rfeData ,"rfeInternalCase" )  =='internalCase'){
          postdata['h1bCaseId'] = this.checkProperty(this.rfeData ,"h1bCaseId"  ,"_id");  
          if(this.checkProperty(this.rfeData ,"rfeCaseUscisDeadlineDate")){
          postdata['rfeDueDate'] =moment(this.rfeData['rfeCaseUscisDeadlineDate']).format("YYYY-MM-DD");
          }

        }else {
          if(this.checkProperty(this.rfeData ,"rfeCaseUscisDeadlineDate")){
          postdata['rfeDueDate'] =moment(this.rfeData['rfeCaseUscisDeadlineDate']).format("YYYY-MM-DD");
          }
          if(this.draftExtractInfo ){
            postdata['draftExtractInfo']= this.draftExtractInfo;

          }
          //rfeIssuedDate:null,rfeReceivedDate:null
          postdata['rfeIssuedDate']= this.checkProperty(this.rfeData ,"rfeIssuedDate" );  
          postdata['rfeReceivedDate']= this.checkProperty(this.rfeData ,"rfeReceivedDate" );  

          postdata['uscisReceiptNumber']= this.checkProperty(this.rfeData ,"uscisReceiptNumber" );  
          if(this.checkProperty(this.rfeData ,"documents", 'length') >0 && this.checkProperty(this.rfeData ,"rfeInternalCase" )  !='internalCase'){
          postdata['documents']['copyOfRfe'] = this.rfeData['documents'];
        }
      }
        

      }
     
      

      this.$modal.hide('errorConfirmationModal');
      if(!this.newPetitionFormSubmited){
        this.newPetitionFormSubmited =true;
        this.$store.dispatch("petitioner/createnewpetition", postdata)
        .then(response => {
              this.premiumProcessing = false;
                 if (response.error) {
                Object.assign(this.formerrors, {
                  msg: response.error.message
                });
                this.newPetitionFormSubmited =false;
              } else {
                this.caseErrorDetails = null
                this.caseErrorCode = ''
                this.caseCreationErrMsg = ''
                   let dt ={
                  petitionId: this.checkProperty(response, '_id'),
                  userName: this.selectedUsername,
                  email: this.selectedUseremail,
                  typeName: this.checkProperty(this.visatype, 'name'),
                  subTypeName: this.checkProperty(this.visasubtype,'name'),
                  instructions: null
                }
                let commitData = null
                  this.$store.commit('updateCapCaseDetails',commitData)
                        this.NewPetition =false; 
                         this.newPetitionFormSubmited =false;
                         this.getpetitions();
                      //this.$vs.notify({title: "Success",text: response.message });

                        this.visatype = {
                        id: 1,
                        name: "H-1B"
                        }
                        this.getvisasubtypes(this.visatype);
                       this.showToster({message:response.message ,isError:false});
                       this.addNewCase(false);
                       setTimeout(()=>{

                        if (postdata.subType == 15) {
                      this.$router.push({ name: 'gc-employment-details', params: { itemId: response._id } }).catch(err => { })


                    } else {

                      if (self.checkProperty(self.selectedBeneficiary, "anonymousUser")) {
                        this.goto(response._id);
                      } else {
                        this.goto(response._id);
                        // this.clear_filter();

                      }

                    }
                       
                          
                           
                       } ,10)

                      
                     
              }

        })
        .catch((error)=>{
          console.log(JSON.stringify(error))
          //this.showToster({message:error,isError:true});
          let errorr = this.checkProperty(error, 'result', 'error')
          this.caseErrorCode = '';
          //this.showToster({message:error,isError:true}); 
          this.newPetitionFormSubmited =false;
          if(_.has(errorr,'code') && this.checkProperty(errorr,'code')){
            this.caseErrorCode = this.checkProperty(errorr,'code')
            this.caseCreationErrMsg = this.checkProperty(errorr,'message')
            this.$modal.show('errorConfirmationModal');
            this.caseErrorDetails ={
              subType:this.visasubtype.id
            }
          }
          else{
            Object.assign(this.formerrors, {
              msg: errorr.message
            });
          }  
        });

      }
      
      
        }else{
          const $ = JQuery;
             if($('.errorScroll .text-danger:visible')){
                var _t = $('.errorScroll .text-danger:visible').first().parent().offset().top;
                if(_t < 0) _t = -(_t)
                  $('.scrollable:visible').scrollTop(_t-50);
                }
             }
        
});
    },
    addNewCase(action=true){
      this.newPetitionFormSubmited =false;
      this.documentUploading =false;
      this.draftExtractInfo =null
      this.benficiaryH1BCases =[];
      this.rfeData = {
        rfeIssuedDate:null,
        rfeReceivedDate:null,
        rfeCaseUscisDeadlineDate:null,
        uscisReceiptNumber:'',
        rfeInternalCase:"internalCase", //'externalCase',//'internalCase',
        "documents":[],
        "docs":{
          "copyOfRfe":[],
          "orgPetition":[],
          "petitionerDocs":[],
          "employmentDocs":[],
          "beneficiaryDocs":[],
          "other":[]

       },
         h1bCaseId:null
       }
      this.resetPermData();
      this.disableOffice=false;
      this.disablePWDstatus = false;
      this.pwdDocFormatError ='';
      this.permDocFormatError = '';
      this.setPwdFilled();
      this.isPwdFiled = false;
      this.getvisaforNewCase();
      this.isLinkPwd= false
      this.NewPetition =action;
      if(!this.callFromCapCaseCreation){
        this.visasubtype =null;
        this.selectedBranch =null;
      }
     
      this.premiumProcessing= false;
      
      this.classification ="";
      this.category='';
      this.responsePermId =''
      this.response140Id=''
      this.permDolDocs =[];
      this.Dol140Docs=[];
      this.enableSubmitBtn =true;
      

      let self =this;
      if(this.checkProperty(this.petitionerDetails ,'_id')){
        this.selectedPetitioner = this.petitionerDetails;
        this.selectedPetitioner =  Object.assign(this.selectedPetitioner ,{"userId":self.petitionerDetails['_id']})
      }
      if([50].indexOf(this.getUserRoleId) >-1){
       
        let userId =  this.checkProperty((this.getUserData ,'companyDetails' ,"_id"))
        let name =  this.checkProperty((this.getUserData ,'companyDetails',"name"))
        this.selectedPetitioner ={}
        this.selectedPetitioner  =  Object.assign(this.selectedPetitioner ,{"_id":userId})
        this.selectedPetitioner =  Object.assign(this.selectedPetitioner ,{"name":name})
         this.selectedBeneficiary =null;
          //this.getbeneficiaryMasterDataList();
         
      }
     
      if(this.branchList.length>0 &&  this.selectedBranch ==null){
        this.selectedBranch = _.cloneDeep(this.branchList[0]);
      }
      if([3,4,50].indexOf(this.getUserRoleId)<=-1){
        if(this.checkProperty(this.getUserData,'branchDetails')){
          let branchDetails = this.checkProperty(this.getUserData,'branchDetails')
          this.selectedBranch ={"name":'' ,'_id':''};
          this.selectedBranch['name'] = branchDetails['name'];
          this.selectedBranch['_id']  = branchDetails['_id'];
          this.disableOffice=true;
        }
      }
      if( this.NewPetition){
        this.getPetitioners();
      this.$modal.show('newCaseCreationModal');

      }else{
      this.$modal.hide('newCaseCreationModal');
        //hide 
      }
      
      this.$validator.reset();

    },
    openAddpetPopUp(){
     
      this.selectedPetitioner =null;
      this.invitepetitioner =true;
    },
    closenewPetPopup(selectedPetitioner=null){

   
       
      this.getPetitioners();
       this.selectedPetitioner =selectedPetitioner;
       this.invitePetitionPopupshow(false);
       this.openNewbenFormPopup(true);

    },
   
    upDateBenef(){

     
      if(this.checkProperty(this.selectedBeneficiary ,'name') && this.checkProperty(this.selectedBeneficiary ,'_id') ){
        this.selectedUser =this.checkProperty(this.selectedBeneficiary ,'_id');
        this.selectedUsername = this.checkProperty(this.selectedBeneficiary ,'name');
     }
     this.getBenficiaryH1BCases();
     
        this.checkBenPermStatus();
      
     
    },
   closeAddBenPopUp(selectedBeneficiary=null){
     
      this.AddBeneficiary =false;
     this.selectedBeneficiary =selectedBeneficiary;
     if(this.checkProperty(this.selectedBeneficiary ,'name') && this.checkProperty(this.selectedBeneficiary ,'_id') ){
        this.selectedUser =this.checkProperty(this.selectedBeneficiary ,'_id');
        this.selectedUsername = this.checkProperty(this.selectedBeneficiary ,'name');
     }
     
     this.getBenficiaryH1BCases();
     if(this.checkProperty(this.selectedBeneficiary ,'accountType')=='Individual'){
      this.isPetitioner =false;
     }
        this.getbeneficiaryMasterDataList();
        this.checkBenPermStatus();
      
     
    
   },
   getPetitioners(callFromSerch=false,searchText='' ) {
        let _self =this;
        if(this.callFromSerch){
         
         // this.petitionersList =[];
        }
        let query ={
          "matcher":{
            "searchString": searchText,
            "statusIds": [],
            "countryIds": [],
            "stateIds": [],
            "locationIds": [],
            "createdDateRange": []
          },
        "sorting": { 	"path": "createdOn", 	"order": -1 	},
        "page": 1,
        "perpage": 100,
        getMasterData:true
	}
       
      
        this.$store
          .dispatch("getList",{data:query ,path:'/company/list'} )
          .then(response => {
            
            _self.petitionersList = response.list;

            let filteredData =  _.filter(_self.petitionersList ,(item)=>{
                if( item&& ( _.has(item ,'name') || _.has(item ,'email')  )){

                         if((_.has(item ,'name')&& item['name'].includes(searchText)) || (_.has(item ,'email') && item['email'].includes(searchText)) ){
                           return true;
                         }else{
                            return false;
                         }

                }else{
                  return false;
                }
              
           
         })
       
                   
            //alert(this.perpage);
          }).catch((err)=>{
            this.petitionersList =[];
           
          })
   },
   invitePetitionPopupshow(action =true){
     this.invitepetitioner=action;
   
     if(!action){
      this.selectedBeneficiary =null;
     }
      
      
     },
      openNewbenFormPopup(action =false){
       this.saveBenbtn =false;
       if(action==true){
         this.invitePetitionPopupshow(false);
       }
       if(action){
       
          
         if(this.checkProperty(this.selectedPetitioner ,'userId')){
         
           this.AddBeneficiary =true;
          
            try{
              setTimeout(()=>{
                this.$refs['add_ben'].setPetDetails(this.selectedPetitioner)

              } ,50)
            }catch(e){
            }
          }else{
           
             this.AddBeneficiary =false;
          }

       }else{
          this.AddBeneficiary =action;

       }
       
      
       
       this.$validator.reset();
     },
     getbeneficiaryMasterDataList(text=''){
      let postData = {
          "matcher": {
            "title": text,
            "statusList": [],
            "branchIds": [],
            "companyIds": [], // Required only for Tenant Admin and Branch Manager to list Beneficiaries
            "createdByIds": [],
            "createdDateRange": [],
            "roleIds": [51],
            "statusIds": [],
            "petitionTypeIds": [],
            "petitionSubTypeIds": [],
            "petitionCreatedDateRange": [],
            "petitionStatusIds": [],
            "getPetitionStats": true
          },
        "sorting": {
          "path": "createdOn", // invitedByName, updatedOn, name, email, phone, statusName, roleName
          "order": 1
        },
        "page": 1,
        "perpage": 1000000,
        "getMasterData": true,
        "getBeneficiaryList": true, // Required only for Tenant Admin and Branch Manager to list Beneficiaries
        "branchId": "", // Required when 'getMasterData' is true and roleIds are [4, 5, 6, 7, 8, 9, 10, 11]
        "companyId": "" // Required when 'getMasterData' is true and roleIds are [50, 51]
	};
 
  this.enableAddNewBenTag =false;
    if(this.checkProperty(this.selectedPetitioner ,"_id")){

      postData['companyId'] = this.selectedPetitioner['_id']

    }else if([50,51].indexOf(this.getUserRoleId)>-1 && this.checkProperty(this.getUserData ,"companyDetails" ,"_id")){

    postData['companyId'] = this.checkProperty(this.getUserData ,"companyDetails" ,"_id")
  }else{
    postData['matcher']['accountType'] = 'Individual';
  }


  if([2,10].indexOf(this.checkProperty(this.visatype,'id')) >-1 || (this.isPetitioner == false || this.isPetitioner == 'false') ){
    postData['matcher']['accountType'] = 'Individual';
   // postData['companyId'] = '';
  }
       //this.beneficiaryMasterDataList =[];
       this.$store
        .dispatch("petitioner/getbeneficiaries", postData)
        .then(response => {
          this.beneficiaryMasterDataList = response.list;

          let filteredData =[];
       _.forEach(this.beneficiaryMasterDataList ,(item)=>{
                if( item && ( _.has(item ,'name') || _.has(item ,'email')  )){

                         if((_.has(item ,'name') && item['name'].includes(text)) || (_.has(item ,'email') && item['email'].includes(text)) ){
                          filteredData.push(item)
                         }else{
                            return false;
                         }

                }else{
                  return false;
                }
              
           
         })

         if(filteredData.length<=0){
           this.enableAddNewBenTag =true;
         }
         let  beneficiaryMasterDataList = _.cloneDeep(this.beneficiaryMasterDataList);
         this.beneficiaryMasterDataList =[];
         _.forEach(beneficiaryMasterDataList, (item)=>{
          if(this.checkProperty(item,'name')){
            if(this.checkProperty(item ,'email') ){
              item['name'] =  item['name']+" ("+item['email']+")"
            }
            this.beneficiaryMasterDataList.push(item);
          }
        
        })


          })

    },
      //////////////////////////////////////////


    goto(Id){
      let routeTest = this.$route.params.itemId
          this.$router.push({ name: 'petition-details', params: { itemId:Id } ,query: {'filter':this.encodedString} }).catch(err => {})
    },
    petitionlink(tr) {
      let routedId = tr._id;
      let itemType = tr
      //alert(JSON.stringify(tr))
      if( this.isRfe || this.checkProperty(tr,'rfeCase' ) || this.checkProperty(tr,'typeDetails','id' )==9 ){
        this.$router.push({ path: `rfe-petition-details/${routedId}` ,query: {'filter':this.encodedString} }).catch(err => {})
      }else if(this.checkProperty(itemType,'subTypeDetails','id')==15){
        this.$router.push({ path: `/gc-employment-details/${routedId}` ,query: {'filter':this.encodedString} }).catch(err => {})
      }else{
        this.$router.push({ path: `/petition-details/${routedId}` ,query: {'filter':this.encodedString} }).catch(err => {})
      }
    },
    pageNate(pageNum) {
     
      this.page = pageNum;
      this.getpetitions();
    },
    SendQuestionnaireUser() {
      this.$store
        .dispatch("petitioner/sendquestionnaire", this.selecteduser)
        .then(response => {
          if (response.error) {
            Object.assign(this.formerrors, {
              msg: response.error.message
            });
          } else {
            this.$vs.notify({
              title: "Success",
              position: "top-right",
              color: "primary",              
              text: response.message
            });
            this.SendQuestionnaire = false;
            this.SuccessQuestionnaire = true;
            var timer = this.$router;
            setTimeout(function() {
              timer.go("/cases");
            }, 1000);
          }

          // this.petitioners = response.list;
        });
    },
    setuser(petition) {
      this.selecteduser.petitionId = petition._id;
      this.selecteduser.userName = petition.beneficiaryDetails.name;
      this.selecteduser.email = petition.beneficiaryDetails.email;
      this.selecteduser.typeName =
        petition.typeDetails.name + "/" + petition.subTypeDetails.name;
      this.selecteduser.subTypeName = petition.subTypeDetails.name;
    },
    selectCreatedDateRange(option) {
      option.startDate = moment(option.startDate).format("YYYY-MM-DD");
      option.endDate = moment(option.endDate).format("YYYY-MM-DD");
      this.selected_createdDateRange = [option.startDate, option.endDate];
    },
    set_filter: function() {
      this.global_selected_petitioners = this.selected_peritioners
      this.gobalType = this.selectedVisaType
      //this.$router.push({ query: {} });
      //this.final_selected_statusids = [];
      if(this.initStatusIdsFilter){
        this.checkHeaderCheckBox = this.initStatusIdsFilter
        if(this.initStatusIdsFilter && this.initStatusIdsFilter.id ==1){
          this.activeCases = true;
          this.getFiledCases = false;
        }
        else{
          this.activeCases = false;
        }
        if(this.initStatusIdsFilter && this.initStatusIdsFilter.id ==10){
          this.activeCases = false;
          this.getFiledCases = true;
        }
        if(this.initStatusIdsFilter && [2,3,4,9].indexOf(this.initStatusIdsFilter)>-1){
          this.activeCases = false;
          this.getFiledCases = false;
        }
        this.checkInternalStatusTitle()
      }
      if(this.initStatusIdsFilter==null){
        this.activeCases =false;
      }
      if(this.selected_statusids) {
        this.final_selected_statusids = [];
        for (let ind = 0; ind < this.selected_statusids.length; ind++) {
          let current_index = this.selected_statusids[ind];
          this.final_selected_statusids.push(current_index["id"]);
        }
      }
      if(this.selected_statusids && this.checkProperty(this.selected_statusids, 'length')>0){
        _.forEach(this.selected_statusids,(it)=>{
          if([12,13,22,23,24,31].indexOf(it['id'])>-1){
            this.activeCases = false;
            return false
          }
        })
      }

      /*//states
        this.final_selected_states= [];
        if( this.seleted_states.length >0 ){
          this.final_selected_states = [];
          for(let ind =0;ind < this.seleted_states.length ; ind++ ){
            let current_index =  this.seleted_states[ind];
            this.final_selected_states.push(current_index["id"]);
          }
        }*/

      //alert(this.singel_final_selected_state);

      this.final_selected_locations = [];
      if (this.seleted_locations.length > 0) {
        for (let ind = 0; ind < this.seleted_locations.length; ind++) {
          let current_index = this.seleted_locations[ind];
          this.final_selected_locations.push(current_index["id"]);
        }
      }

      this.searchtxt = this.filter_searchtxt;

      this.getpetitions(false ,false);
      this.page=1;
      this.$refs["filter_menu"].dropdownVisible = false;
    },
    clear_filter: function() {
      this.selectedVisaType =[]
      this.global_selected_petitioners = [];
      this.checkInternalStatusTitle()
      this.initStatusIdsFilter ={ "_id": "637f076578adb65c4c208e2d", "id": 1, "name": "Active", "sortName": "active" };
      this.checkHeaderCheckBox = { "_id": "637f076578adb65c4c208e2d", "id": 1, "name": "Active", "sortName": "active" };
      this.selectedarchive =[];
      this.selected_deadLineDateRange =  ["", ""];
      this.selectedpremiumProcessing = [];
      this.peritioners_search_value ='';
      this.searchtxt = "";
      this.selected_statusids = [];
      this.selectedI94Expiry = null;

      this.selected_country_obj = "";
      this.seleted_states = [];
      this.final_selected_states = [];
      this.singel_final_selected_state = "";

      this.seleted_locations = [];
      this.final_selected_locations = [];
      this.final_selected_statusids = [];

      this.date = "";
      this.date_range = [];
      this.selected_createdDateRange["startDate"] = "";
      this.selected_createdDateRange["endDate"] = "";


      
      this.selectedVisaType =null;
      this.filter_searchtxt = "";
      this.selected_subtypes = [];
      this.final_selected_subtypes = [];

      (this.rolebased_filter = {
        3: { name: "supervisorIds", values: [] },
        4: { name: "paralegalIds", values: [] },
        5: { name: "attorneyIds", values: [] },
        9: { name: "offshoreUserIds", values: [] },
        10: { name: "evidenceSupervisorIds", values: [] }
      }),
        (this.final_selected_peritioners = []);
      this.selected_peritioners = [];
      //this.getPetitioners();
      this.$refs["filter_menu"].dropdownVisible = false;
      this.selected_users =[];
      this.selectedBranches =[];
      this.page=1;
      this.activeCases = true;
       this.getpetitions(false ,false);
       //this.$router.push({ query: {} })
    },
    get_all_states() {
      this.$store.dispatch("getstates", this.country_code).then(response => {
        this.all_states = response;
      });
    },
    getAllLocations() {
      Object.assign(this.query, {
        countryId: this.country_code,
        stateId: this.singel_final_selected_state //this.final_selected_states//3922
      });

      this.$store.dispatch("getlocations", this.query).then(response => {
        this.all_locations = response;
      });
    },
    setQueryString(obj){
      const string = JSON.stringify(obj) // convert Object to a String
      this.encodedString = btoa(string) // Base64 encode the String
      this.$route['query']['filter'] = this.encodedString;
    },
    caseStatus(obj){ 
      let selectedItem = null
      if(obj){
         selectedItem = obj
      }
      
      let postData = {
        "matcher": { 
          "searchString":"",
          "tenantId": "",
          "branchId": "",
          "getWorkFlowConfig": false,
          "getCasenoCodeConfig": false,
          "tenantCustomId": "",
          "petitionTypes": [],
          "getInactiveListAlso": false,
          "caseType": ""
          },
          "category": "case_status",
          "page": 1,
          "perpage": 25,
          "sorting": {    
            "path": "name",
            "order": 1
          }
      }
      if(selectedItem && this.checkProperty(selectedItem, 'id')==1){
        postData['matcher']['caseType'] = "h1b"
      }
      if(selectedItem && this.checkProperty(selectedItem, 'id')==2){
        postData['matcher']['caseType'] = "h4"  
      }
      if(selectedItem && this.checkProperty(selectedItem, 'id')==3){
        postData['matcher']['caseType'] = "gc"  
      }
      if( selectedItem ==null){
        postData['matcher']['caseType'] = ""
      }
      if( this.selected_subtypes && this.checkProperty(this.selected_subtypes,'length')==1){
        _.forEach(this.selected_subtypes,(item)=>{
          if(item['id'] == 15){
            postData['matcher']['caseType'] = "perm"
          }
          if(item['id'] == 16){
            postData['matcher']['caseType'] = "i-140"
          }
          if(item['id'] == 17){
            postData['matcher']['caseType'] = "i-485"
          }
          
        })
      }
      
      //alert(JSON.stringify(this.selectedVisaType))  
       if(this.checkProperty(this.tenantDetails ,"customId")){
        postData['matcher']['tenantCustomId']= this.tenantDetails['customId'];
      }  //"get_case_statusids"  //getMasterData
        this.$store.dispatch("getMasterData",postData).then(response => {
          //alert(JSON.stringify(response))
          
          let list =response.list;
          if( this.selected_subtypes && this.checkProperty(this.selected_subtypes,'length')==1){
              if(_.find(this.selected_subtypes ,{"id":17})){
                list = _.filter( list ,(status)=>{
                  return status.id !=3
                });
              }
          }
           this.case_statusids = list
           if(this.checkProperty(this.$route ,'query' ,'filter')){
              try{
                let filter =this.$route['query']['filter']; this.checkProperty(this.$route ,'query' ,'filter')
                var actual = JSON.parse(atob(filter));
                let keys = Object.keys(actual);
                if(this.checkProperty(keys ,'length') >0){
                  if(actual && (Object.keys(actual)).length>0 ){
                  _.forEach(actual ,(item ,key) => {
                      if(key=='matcher' ){
                        if((Object.keys(item)).length>0 ){
                          if(_.has(item ,'statusIds') && this.checkProperty(item ,'statusIds' ,'length')>0){
                              let statusIds = _.map(item['statusIds'] ,(sid)=>parseInt(sid)) 
                            
                              //let selectedStatus = _.find(this.case_statusids ,{"id":parseInt(statusIds[0])}); 
                              this.final_selected_statusids =statusIds;
                          
                              let selectedStatus = _.filter(this.case_statusids,(itm)=>statusIds.indexOf(itm.id)>-1  ) 
                              
                            if(selectedStatus){
                            this.selected_statusids =selectedStatus //[selectedStatus];
                            
                            }
                            if(!_.find( selectedStatus ,{"id":31}) && statusIds.indexOf(31)>-1 ){
                                let  withdrawn = { "_id": "64429dc92535f74f9af0615b", "id": 31, "name": "Withdrawn", "sortName": "withdrawn" };
                                this.selected_statusids.push(withdrawn);
                              }

                            
                                

                          }
                        }
                      }
                  })
                }
                }
              }catch(e){
              }
            }
            if (this.checkProperty(this.$router.currentRoute ,"query"  ,"status") ){        
                  let status = this.checkProperty(this.$router.currentRoute ,"query"  ,"status");
                  let selectedStatus = _.find(this.case_statusids ,{"id":parseInt(status)});        
                      if(selectedStatus){
                        this.selected_statusids =[selectedStatus];
                        this.final_selected_statusids =[parseInt(status)];
                      }          
            }  
           
        })
    }, 
    getpetitions(callFromSerch=false , applyUrlFilter=false) {
        this.selectedAllForArchive =false;
       this.selectedForArchiveList =[]; 
      this.callFromSerch = callFromSerch;
      let self =this; 
          if(this.callFromSerch){
              this.petitioners  =[];
          }
        let obj = {
          matcher: {
            rfeCases:self.isRfe,
            searchString: self.searchtxt,
            statusIds:self.final_selected_statusids,// [],//this.final_selected_statusids,
            beneficiaryIds:[],
            premiumProcessing:self.selectedpremiumProcessing.map((item)=> item._id),
            //"countryIds": [this.country_code],
            stateIds: [],//[1,2,3,4,5,6], 
            locationIds: self.final_selected_locations,
            //"createdDateRange":self.selected_createdDateRange,
            petitionerIds:self.final_selected_peritioners,
            branchIds:[],
            typeIds:[],
            subTypeIds:[],
            getActiveCases:this.activeCases,
            deadlineDateRange:[],
            "getMissingDeadlines": false,
            statusList:[],
            intStatusIds:[],
            "assignedUserIds":[],
             // "getActiveCases": true, // Send true for Active cases only
              "getFiledCases": this.getFiledCases, // Send true for Active cases only
             // "getClosedCases": true // Send true for Closed cases only,
          },
          page: self.page,
          perpage: self.perpage,
          sorting:self.sortKey
        };
        if(self.selectedBranches.length>0){
         // obj['matcher']['branchIds'] = this.selectedBranches.map((item)=> item._id )
        }
       
        //   if(this.selected_statusids && this.checkProperty(this.selected_statusids , 'id' )){
        //    obj["matcher"]["statusIds"] = [this.selected_statusids['id']];
        // }
        if(this.initStatusIdsFilter && [1,9,10].indexOf(this.initStatusIdsFilter.id)<=-1){
            obj['matcher']['intStatusIds'] =[];
            obj['matcher']['intStatusIds'].push(this.checkProperty(this.initStatusIdsFilter, 'id'))
        }
        if(this.selectedBranch && this.checkProperty(this.selectedBranch ,'_id')){
         obj['matcher']['branchIds'] =[this.selectedBranch['_id']];
        }
        if(this.selectedFromUser && this.checkProperty(this.selectedFromUser ,'_id')){
         obj['matcher']['assignedUserIds'] =[this.selectedFromUser['_id']];
        }
       if(this.selectedarchive.length>0){
            obj["matcher"]["statusList"] = this.selectedarchive.map((item)=>item._id); 
       }
        if (this.singel_final_selected_state > 0) {
          obj["matcher"]["stateIds"] = [this.singel_final_selected_state];
        }
        if (
          this.selected_createdDateRange["startDate"] &&
          this.selected_createdDateRange["startDate"] != "" &&
          this.selected_createdDateRange["endDate"] != "" &&
          this.selected_createdDateRange["endDate"]
        ) {
          obj["matcher"]["createdDateRange"] = [
            this.selected_createdDateRange["startDate"],
            this.selected_createdDateRange["endDate"]
          ];
        }
        if (
          this.selected_deadLineDateRange["startDate"] &&
          this.selected_deadLineDateRange["startDate"] != "" &&
          this.selected_deadLineDateRange["endDate"] != "" &&
          this.selected_deadLineDateRange["endDate"]
        ) {
            obj["matcher"]["getMissingDeadlines"] = false;
            obj["matcher"]["deadlineDateRange"] = [
            this.selected_deadLineDateRange["startDate"],
            this.selected_deadLineDateRange["endDate"]
          ];
        }
        //selected_deadLineDateRange
        obj["matcher"]["countryIds"] = [];
        if (
          this.selected_country_obj["id"] &&
          this.selected_country_obj["id"] > 0
        ) {
          obj["matcher"]["countryIds"] = [this.selected_country_obj["id"]];
        }
        if(this.selectedVisaType && _.has(this.selectedVisaType , 'id' )){
          if(this.checkProperty(this.selectedVisaType, 'id')!='ALL'){
            obj["matcher"]["typeIds"] = [this.selectedVisaType['id']];
            obj["matcher"]["subTypeIds"] = this.final_selected_subtypes;  
          }
           
        }
        if(this.getClosedCases){
          obj["matcher"]["getClosedCases"] = true
        }
        if(this.getActiveCases){
          obj["matcher"]["getActiveCases"] = true
        }
        if(this.getPendingWithLCA){
          obj["matcher"]["getPendingWithLCA"] = true
        }
        //getPendingWithLCA
        if(this.dashboardBranchIds && this.checkProperty(this.dashboardBranchIds, 'length') > 0 ){
          obj['matcher']['branchIds'] = this.dashboardBranchIds;
        }

             
        if(this.beneficiaryId !=null){
          obj["matcher"]['beneficiaryIds'] =[];
          obj["matcher"]['beneficiaryIds'].push(this.beneficiaryId)
        }
        if(this.checkProperty(this.selectedI94Expiry, 'id')){
          obj['matcher']['i94Expiry'] = this.checkProperty(this.selectedI94Expiry, 'id');
        }
         
         let tmpObj =_.cloneDeep(obj['matcher']);
         tmpObj = Object.assign(tmpObj ,{ page: self.page, perpage: self.perpage,sorting:self.sortKey});
         this.setQueryString({'matcher':tmpObj});

        this.isListloading = true;
        this.updateLoading(true);
        this.$store.dispatch("commonAction", { "data": obj,"path":"/petition-common/list"}).then(response => {  
          
            this.addCls =false;    
            this.isListloading = false;
        this.updateLoading(false);
        this.getClosedCases = false;
        this.getActiveCases = false;
        this.dashboardBranchIds = [];
         let tempList =[];
         let list = response.list
         _.forEach( list,(item) => {
            item =Object.assign(item,{ 'selectedForArchive':false});
           if(this.selectedForArchiveList.indexOf(item['_id'])>-1){
              item =Object.assign(item,{ 'selectedForArchive':true});
           }
           tempList.push(item)
           
         });
        //  setTimeout(()=>{
        //   this.caseStatus()
        // },10)
          this.petitioners = list;

            this.updateLoading(false);
            this.totalCount = this.checkProperty(response, 'totalCount')
        this.totalpages = Math.ceil(response.totalCount / this.perpage);
        setTimeout(() =>{
                this.updateLoading(false);
                this.caseStatus(this.selectedVisaType)
               })
        
        }) .catch((err) => {
         
          this.addCls =false;  
           this.isListLoading =false;
            this.updateLoading(false);
             this.petitioners = [];
             setTimeout(() =>{
                this.updateLoading(false);
               })
              
          });
      },
      changeActiveType(item){
        this.page = 1;
          if(item){
            this.initStatusIdsFilter =  { "_id": "637f7c565648c5150123deab", "id": 1, "name": "Active", "sortName": "active" }
            this.selected_statusids = []
              this.set_filter();
          }
          else{
            this.activeCases = false;
            this.initStatusIdsFilter = null;
            this.set_filter();
          }
        } ,
        changedInitStatus(obj){
          if(obj && obj.id ==1 || obj.id ==10 || obj.id ==9 ){
            this.selected_statusids = [];
          }
          //  _.filter(obj, (item) => {
          //  if(this.checkProperty(obj, 'id') != this.checkProperty(item, 'id')){
          //   this.activeCases =false;
          //  }
          // })
          // if(this.checkProperty(obj, 'id')==1){
          //   this.activeCases = true;
          // }
        },
        changedCountry() {
          this.country_code = this.selected_country_obj["id"];
          this.get_all_states();
        },
        changedState() {
          this.singel_final_selected_state = "";
          this.final_selected_locations = [];
          this.singel_final_selected_state = this.seleted_states["id"];
          this.final_selected_states.push(this.seleted_states["id"]);
          this.getAllLocations();
        },
        multiple_changedState() {
          // alert();
          if (this.seleted_states.length > 0) {
            this.final_selected_states = [];
            for (let ind = 0; ind < this.seleted_states.length; ind++) {
              let current_index = this.seleted_states[ind];
              this.final_selected_states.push(current_index["id"]);
            }
            this.getAllLocations();
          } else {
            this.final_selected_states = [];
            this.final_selected_locations = [];
          }
        },
        upload(fils, category='') {
          this.draftExtractInfo =null;
          this.pwdDocFormatError ='';
          let  model =_.cloneDeep(fils);
          this.value =[];
          var _current = this;
          // this.$vs.loading();
    
          let efiles = [];
          efiles = _.filter(model, (e) => {
            return e.url != null && e.url != "";
          });
          let nfiles = _.filter(model, (e) => {
            return e.url == null || e.url == undefined;
          });
    
          let mapper = nfiles.map(
            (item) =>
              (item = {
                name: item.name,
                file: item.file ? item.file : null,
                url: item.url ? item.url : "",
                path: item.path ? item.path : "",
                status: true,
                mimetype: item.type ? item.type : item.mimetype,
              })  
          );
          let tempFiles = [];
          if (mapper.length > 0) {
            this.uploading = true;
            let count = 0;
            mapper.forEach((doc, index) => {
              //rfeData:{}
              if( (category == 'RFE' || category == 'PWD' || category =='permDocuments') && !( doc.mimetype=='application/pdf' )  ){
                this.pwdDocFormatError ="Upload only pdf documents";
                if(category =='permDocuments'){
                  this.permDocFormatError = "Upload only pdf documents";
                }
              
                this.uploading = false;   
                      
                return false;

              }
              let formData = new FormData();
              formData.append("files", doc.file);
              formData.append("secureType", "private");
              formData.append("getDetails", true);
              count++;
              
              this.$store.dispatch("uploadS3File", formData).then((response) => {
                response.data.result.forEach((urlGenerated) => {
                  //alert(JSON.stringify(urlGenerated))
                  //  this.CommentPayload.documents.push(urlGenerated)
                  // if (  _.has(urlGenerated, "name") &&  tempFiles.indexOf(urlGenerated["name"]) <= -1 ) {
                    tempFiles.push(urlGenerated["name"]);
                    if(category == 'RFE'){
                      this.rfeData['documents'] =[];
                      this.rfeData['documents'].push(urlGenerated);
                      this.prefillRfeNoticeDoc();
                    }
                    if(category == 'PWD'){
                      this.pwdResponse['documents'] =[];
                      this.pwdResponse['documents'].push(urlGenerated);
                      this.prefillJobDetails();
                    
                      this.pwdResponse = _.cloneDeep(this.pwdResponse);
                      _current.$validator.reset();
                    
                    }
                    if(category == 'permDocuments'){
                      this.permDolDocs =[];
                      this.permDolDocs.push(urlGenerated);
                      this.prefillPermDocData();
                    }
                    if(category == '140Documents'){
                      this.Dol140Docs.push(urlGenerated);
                    }
                    if(category == 'delete'){
                      this.permDeleteDocs.push(urlGenerated);
                    }
                    
                //   }
                  doc.url = urlGenerated;
                  doc.path = urlGenerated;
                  doc["mimetype"] = urlGenerated["mimetype"];
                  doc["type"] = urlGenerated["mimetype"];
                  delete doc.file;
                  mapper[index] = doc;
                });
                if (index >= mapper.length - 1) {
                  this.uploading = false;
                  // _current.$vs.loading.close();
                }
              });
            });
            if (efiles.length > 0) efiles.push(...mapper);
            //this.CommentPayload["documents"] = efiles
          }
        },
        remove(item, data, filindex) {
          data.splice(filindex, 1);
          this.disablePWDstatus = false;

        },


        filterQueryPreSelect(callFromMounted=false){
           //this.getPendingWithLCA =false;
          // this.getActiveCases = false;
          if(this.checkProperty(this.$route ,'query' ,'filter')){
                    try{
                      let filter =this.$route['query']['filter']; this.checkProperty(this.$route ,'query' ,'filter')
                      var actual = JSON.parse(atob(filter));
                      let keys = Object.keys(actual);
                      if(this.checkProperty(keys ,'length') >0){
                        if(actual && (Object.keys(actual)).length>0 ){
                        _.forEach(actual ,(item ,key) => {
                            if(key=='matcher' ){
                              if((Object.keys(item)).length>0 ){
                                if(_.has(item ,'getPendingWithLCA')){
                                   this.getPendingWithLCA =true; //item['getPendingWithLCA']
                                }
                                if(_.has(item ,'createdDateRange') && this.checkProperty(item , 'createdDateRange' ,'length')>=2 ){
                                  this.selected_createdDateRange ={
                                    "startDate":'',
                                    "endDate":''
                                  };
                                  this.selected_createdDateRange["startDate"] = item['createdDateRange'][0];  
                                  this.selected_createdDateRange["endDate"]   =   item['createdDateRange'][1];
                                  
                                }
                                if(_.has(item ,'typeIds') && this.checkProperty(item , 'typeIds' ,'length')>0 ){
                                   if(this.visaTypes.length>0){
                                    this.selectedVisaType = _.find(this.visaTypes ,{"id":item['typeIds'][0]})
                                    this.gobalType = this.selectedVisaType;
                                    this.getvisa_subtypes();
                                   }else{
                                    this.selectedVisaType ={}; 
                                    this.selectedVisaType = Object.assign(this.selectedVisaType ,{"id":item['typeIds'][0]});
                                    this.gobalType = this.selectedVisaType 
                                    this.getvisa_subtypes();
                                   }
                                  }
                                  if(_.has(item ,'subTypeIds') && this.checkProperty(item ,'subTypeIds' ,'length')>0){
                                    this.final_selected_subtypes = item['subTypeIds'];
                                    if(this.all_subtypes.length>0){ 
                                      this.selected_subtypes = _.filter(this.all_subtypes ,(status)=>{
                                        return item['subTypeIds'].indexOf(status['id'])>-1;
                                      })
                                    }
                                    //this.caseStatus(this.selectedVisaType)
                                  }
                                  if(_.has(item ,'premiumProcessing') && this.checkProperty(item ,'premiumProcessing' ,'length')>0){
                                    if(this.premiumProcessingList.length>0){ 
                                      this.selectedpremiumProcessing = _.filter(this.premiumProcessingList ,(status)=>{
                                        return item['premiumProcessing'].indexOf(status['_id'])>-1;
                                      })
                                    }
                                  }
                                  if(_.has(item ,'petitionerIds') && this.checkProperty(item ,'petitionerIds' ,'length')>0){
                                    this.final_selected_peritioners = item['petitionerIds'];
                                    if(this.all_peritioners.length>0){ 
                                      this.selected_peritioners = _.filter(this.all_peritioners ,(status)=>{
                                        return item['petitionerIds'].indexOf(status['_id'])>-1;
                                      })
                                      this.global_selected_petitioners = _.cloneDeep(this.selected_peritioners)
                                    }
                                  }
                                  if(_.has(item ,'statusIds') && this.checkProperty(item ,'statusIds' ,'length')>0){
                                    console.log('statusIds')
                                    let statusIds = _.map(item['statusIds'] ,(sid)=>parseInt(sid)) 
                                  
                                    //let selectedStatus = _.find(this.case_statusids ,{"id":parseInt(statusIds[0])}); 
                                   //this.final_selected_statusids =statusIds;
                                
                                    let selectedStatus = _.filter(this.case_statusids,(itm)=>[item['statusIds']].indexOf(itm.id)>-1  ) 
                                    
                                  if(selectedStatus){
                                  this.selected_statusids =selectedStatus //[selectedStatus];
                                  }
                                  if(!_.find( selectedStatus ,{"id":31}) && statusIds.indexOf(31)>-1 ){
                                      let  withdrawn = { "_id": "64429dc92535f74f9af0615b", "id": 31, "name": "Withdrawn", "sortName": "withdrawn" };
                                      this.selected_statusids.push(withdrawn);
                                    }

                                  
                                     

                                 }
                                 if(_.has(item, 'getActiveCases') ){
                                  this.getActiveCases = false;
                                  this.activeCases = false;
                                  if(this.checkProperty(item, 'getActiveCases') == true || this.checkProperty(item, 'getActiveCases') == 'true'){
                                    this.getActiveCases = true;
                                    this.activeCases = true
                                  }
                                  if(this.checkProperty(item, 'getActiveCases') == false || this.checkProperty(item, 'getActiveCases') == 'false'){
                                    this.getActiveCases = false;
                                    this.activeCases = false;
                                  }
                                 }
                                 if(_.has(item, 'getClosedCases') && this.checkProperty(item, 'getClosedCases') == true || this.checkProperty(item, 'getClosedCases') == 'true'){
                                  this.getClosedCases = true
                                 }
                                 if(_.has(item, 'branchIds') && this.checkProperty(item, 'branchIds') ){
                                  this.dashboardBranchIds = this.checkProperty(item, 'branchIds')
                                 }
                                 if(_.has(item, 'i94Expiry') && this.checkProperty(item, 'i94Expiry') ){
                                  let findObj = _.find(this.I94ExpiryList,{'id':this.checkProperty(item, 'i94Expiry')});
                                  this.selectedI94Expiry = findObj;
                                 }
                                 
                                 //{ page: self.page, perpage: self.perpage,sorting:self.sortKey}   
                              
                                //  if(_.has(item ,'page') && parseInt(item['page'])>0 ){
                                //   this.page =parseInt(item['page']);   
                                  
                                //  }
                                //  if(_.has(item ,'perpage') && parseInt(item['perpage'])>0){
                                //   this.perpage =parseInt(item['perpage'])
                                //  }
                                //  if(_.has(item ,'sorting') ){
                                //   let sorting = item['sorting'];
                                //   if(_.has(sorting ,'path') && _.has(sorting ,'order')   ){
                                //     if(sorting['order'] >=-1){
                                //         this.sortKey = sorting;
                                //     }

                                //   }
                                  
                                //  } changedperitioners() 
                              }
                            }
                        })
                      }
                      }
                      if(callFromMounted){
                        //alert("dsjk dshfhf")
                        //this.getPetitioners();
                        this.set_filter();
                      }
                    }catch(e){
                      if(callFromMounted){
                        //this.getPetitioners();
                        this.set_filter();
                     }
                    }
          }
          else{
            if(callFromMounted){
                this.getPetitioners();
            }
          }
        },
        getVisaTypes(){
          let item ={
                matcher:{
                    "searchString":'',
                    getWorkFlowConfig:true
                  // "petitionType":

                },   
                page:this.page,
                perpage: this.perpage,
                category: "petition_types",
              "sorting": {
                  "path": "name",
                  "order": 1
                  }
                
              };

              this.$store
                .dispatch("getMasterData",item )
                .then(response => {
                  this.visaTypes = [];
                  let placedobj = null
                  let obj = {"_id":"632953d43ecbeaeefe93efefr","id":'ALL',"name":"All","isCaseTypeSelected":true}
                  placedobj = _.find(this.visaTypes,{'id':'ALL'})
                  if(placedobj == null || !placedobj){
                    this.visaTypes.push(obj)
                  }

                  _.forEach(response.list ,(item)=>{
                    this.visaTypes.push(item)
                  });
                  

                  this.filterQueryPreSelect();
                  


                
                });
        },
        changedVisaType(item){
         // this.$router.push({ query: {} });
          this.selectedVisaType = item;
          this.all_subtypes = [];
          this.final_selected_subtypes = [];
          this.selected_subtypes =[];
          this.selected_statusids =[];
          if(_.has(this.selectedVisaType , "id")){
            this.getvisa_subtypes();

          }
          this.caseStatus(this.selectedVisaType);
          this.setQueryString()
        },
        changedVisaTypeClear(item){
          let obj = item
          
          //alert(JSON.stringify(item))
          this.caseStatus(obj)
          //this.gobalType = this.selectedVisaType
          this.selectedVisaType = this.gobalType
              if (this.selectedVisaType) {
                this.set_filter();
              }
          //this.set_filter();
         // this.$router.push({ query: {} });
          this.changedVisaType(item);
         
        },
        getvisa_subtypes() {
          if(this.selectedVisaType && _.has(this.selectedVisaType ,"id")){
          let item = {
            matcher: {
              getAllSubTypes:false,
              searchString: '',
              petitionType: parseInt(this.selectedVisaType['id']),
              getWorkFlowConfig: false,
            },
            page: 1,
            perpage: 1000,
            category: "petition_sub_types",
            "sorting": {
                "path": "name",
                "order": 1
                }
          };

          if(this.selectedVisaType['id'] =='ALL'){
            item['matcher']['petitionType'] =null;
            item['matcher']['getAllSubTypes'] =true;
          }

          this.$store.dispatch("getMasterData", item).then((response) => {
            this.all_subtypes = response.list;
            if(this.checkProperty(this.$route ,'query' ,'filter')){
              try{
                let filter =this.$route['query']['filter']; this.checkProperty(this.$route ,'query' ,'filter')
                var actual = JSON.parse(atob(filter));
                let keys = Object.keys(actual);
                if(this.checkProperty(keys ,'length') >0){
                  if(actual && (Object.keys(actual)).length>0 ){
                  _.forEach(actual ,(item ,key) => {
                      if(key=='matcher' ){
                        if((Object.keys(item)).length>0 ){
                            if(_.has(item ,'subTypeIds') && this.checkProperty(item ,'subTypeIds' ,'length')>0){
                              this.final_selected_subtypes = item['subTypeIds'];
                              if(this.all_subtypes.length>0){ 
                                this.selected_subtypes = _.filter(this.all_subtypes ,(status)=>{
                                  return item['subTypeIds'].indexOf(status['id'])>-1;
                                })
                              }
                            }
                        }
                      }
                  })
                }
                }
                
              }catch(e){
              }
            }
            // this.filterQueryPreSelect();
          
          });
          }
        },
        changedsubtypes() {
          
          this.selected_statusids =null;
          this.final_selected_subtypes = [];
          if (this.selected_subtypes.length > 0) {
            for (let ind = 0; ind < this.selected_subtypes.length; ind++) {
              let current_index = this.selected_subtypes[ind];
              this.final_selected_subtypes.push(current_index["id"]);
              if([15,16,17].indexOf(current_index['id'])>-1){
                this.caseStatus(this.selected_subtypes);
              } 
            }
          }
          else{
            this.caseStatus();
          }   
        },
       
        getusers() {
          let matcher = {
            roleIds: this.final_filter_roleIds,
            searchString: this.user_search_value,
            page: 1
          };
          let query = {};
          query["page"] = 1;
          query["perpage"] = 100;
          query["matcher"] = matcher;

          this.$store.dispatch("getusers", query).then(response => {
            this.users = response.list;
          });
        },
        get_peritioners() {

        
              
        //petitioner_list_for_tenant_users

          let item ={
              page:1,
              perpage: 10000,
              category: "petitioner_list_for_tenant_users",
              matcher:{
                "searchString":this.peritioners_search_value,
              
              },
              "sorting": {
                "path": "name",
                "order": 1
                }
                          
            };
            if([51].indexOf(this.getUserRoleId)>-1){
              item['category'] = "petitioner_list_for_beneficaries"
            }

      
            this.$store.dispatch("getMasterData", item).then(response => {
            
              this.all_peritioners =response.list;
                  if(this.checkProperty(this.$route ,'query' ,'filter')){
                    try{
                      let filter =this.$route['query']['filter']; this.checkProperty(this.$route ,'query' ,'filter')
                      var actual = JSON.parse(atob(filter));
                      let keys = Object.keys(actual);
                      if(this.checkProperty(keys ,'length') >0){


                        if(actual && (Object.keys(actual)).length>0 ){
                        _.forEach(actual ,(item ,key) => {
                            if(key=='matcher' ){
                              
                              if((Object.keys(item)).length>0 ){

                                if(_.has(item ,'petitionerIds')){
                                  
                                  this.selected_peritioners = _.filter(this.all_peritioners ,(status)=>{
                                      return item['petitionerIds'].indexOf(status['_id'])>-1;

                                })

                                }

                                
                                
                              }
                            
                            }
                          
                            
                        
                        })
                      }
                        
                        
                      }

                    }catch(e){
                      

                    }
                      
                  }

              
            
            });
        },
        changedusers() {
          //rolebased_filter
          this.rolebased_filter = {
            3: { name: "supervisorIds", values: [] },
            4: { name: "paralegalIds", values: [] },
            5: { name: "attorneyIds", values: [] },
            9: { name: "offshoreUserIds", values: [] },
            10: { name: "evidenceSupervisorIds", values: [] }
          };
          if (this.selected_users.length > 0) {
            for (let i = 0; i < this.selected_users.length; i++) {
              let selected_user_item = this.selected_users[i];
              let roleId = selected_user_item["roleId"][0];
              this.rolebased_filter[roleId]["values"].push(
                selected_user_item["_id"]
              );
            }
          }
        },
        user_search(searchValue) {
          this.user_search_value = searchValue;
          this.getusers();
        },
        changedperitionersSearch() {
          this.selected_peritioners = this.global_selected_petitioners
          this.final_selected_peritioners = [];
          if (this.selected_peritioners.length > 0) {
            for (let i = 0; i < this.selected_peritioners.length; i++) {
              this.final_selected_peritioners.push(
                this.selected_peritioners[i]["_id"]
              );
            }
          }
          this.get_peritioners_beneficiaries();
          this.set_filter();
        },

        //
        changedperitioners() {
         // this.$router.push({ query: {} })
          this.final_selected_peritioners = [];
          if (this.selected_peritioners.length > 0) {
            for (let i = 0; i < this.selected_peritioners.length; i++) {
              this.final_selected_peritioners.push(
                this.selected_peritioners[i]["_id"]
              );
            }
          }
          this.get_peritioners_beneficiaries();
        },

        peritioners_search_fun(searchValue) {
          this.peritioners_search_value = searchValue;
          this.get_peritioners();
        },
        get_peritioners_beneficiaries() {},
        sortMe(sort_key=''){

          //   this.sortKeys = {
          //   'caseNo':1,
          //   'beneficiaryDetails.name':1,
          //   "typeDetails.name":1,
          //   "petitionerDetails.name":1,
          //   "updatedOn":1,
          //   "communicationDetailslength":1

          // }

          if(sort_key !=''){
              this.page = 1;
              this.sortKeys[sort_key] = this.sortKeys[sort_key]==1?-1:1
              this.sortKey ={};
              this.sortKey= {"path":sort_key,"order": this.sortKeys[sort_key] }

              localStorage.setItem('petitions_sort_key', sort_key);
              localStorage.setItem('petitions_sort_value', this.sortKey[sort_key]);
              this.getpetitions();
          }
        },
        changeSorting(item){
          
          if(_.has(this.$route,'name')){
            item['order'] = item['order']==1?-1:1;
          this.addCls = true;   
          localStorage.setItem(this.$route['name'] ,JSON.stringify(item));
          this.sortKey = item;
          this.sortKeys[item['path']] = item['order'];
          _.forEach(this.sortKeys, (sortVal, sortKey)=>{
            if(sortKey == item['path'] ){ 
              this.sortKeys[sortKey] = this.sortKey['order'];
            }else{
             // this.sortKeys[sortKey]= this.sortKey['order']==1?-1:1
            }

            
          });
          this.getpetitions();

          }

        },

        changeperPage(){       
          this.page = 1;
          localStorage.setItem('petitions_perpage', this.perpage);
          this.getpetitions(true); 
        },
          getBranchList() {
            this.branchList =[];
          //  alert(JSON.stringify(this.searchtxt)) final_selected_statusids
            let item ={
              filters:{
                  "title":'',
                "createdDateRange":[],
                "statusList":[], 
                "activeList": [],
                "countryIds":[],
                "stateIds":[],
                "locationIds":[]
              

              },
              getMasterData:true,   
              page:1,
              perpage: 1000,
              sorting:{"path":"createdOn" ,"order":-1},
            
            };

            
          
            this.$store
              .dispatch("getList",{"data":item ,"path":"/branch/list"} )
              .then(response => {
                
                this.branchList = response.list;
              if(this.branchList.length ==1){
                this.selectedBranch = this.branchList[0];
              }
              }).catch((error)=>{
                  this.branchList =[];
              })
          }, 
          getCommonMessages(){
      let payLoad={
        "category": [ "COMMON_MESSAGES"]
      }
      this.$store.dispatch("commonAction", {"data":payLoad ,"path":"/messages/list"}).then((response)=>{
        if( _.has(response['messages']['COMMON_MESSAGES'] , 'i140DuplicateCase')){
          this.i140CreationMessage = response['messages']['COMMON_MESSAGES']['i140DuplicateCase']
        }
      }).catch((error)=>{})
    }
      },

  mounted() {
    this.selected_statusids = [];
    this.final_selected_statusids = [];
    this.seleted_states = [];
    this.final_selected_states = [];
    this.seleted_locations = [];
    this.final_selected_locations = [];   
    this.getVisaTypes();  
    this.getEducationList();
    this.getMasterSocList();
    this.caseStatus();
    this.$store.dispatch("getcountries").then(response => {
      this.countries = response;
    });
    // if(this.callFromBen){
    //   this.initStatusIdsFilter = { "_id": "637f7c565648c5150123deab", "id": 1, "name": "Active", "sortName": "active" };
    // }
    this.initStatusIdsFilter = { "_id": "637f7c565648c5150123deab", "id": 1, "name": "Active", "sortName": "active" };
    this.getCommonMessages();
    
    this.getClosedCases = false;
        this.getActiveCases = false;
        this.dashboardBranchIds =[];
   //this.caseStatus();
   
    this.checkInternalStatusTitle()
    if(this.$route.params && this.$route.params.openCreatePopup ){
        this.selectedBeneficiary =null 
        this. selectedPetitioner=null
        var _s = this;
        setTimeout(function(){
          _s.addNewCase(true)
        },600)
    }
      if(this.$route.params && this.$route.params.capCaseCreate ){
        this.selectedBeneficiary =null 
        this.selectedPetitioner=null
        this.callFromCapCaseCreation = true
        this.selectedBranch = null
       // alert(JSON.stringify(this.checkProperty(this.getCapCaseDetails,'branchDetails')))
        if(this.checkProperty(this.getCapCaseDetails,'branchDetails')){
          this.selectedBranch = this.checkProperty(this.getCapCaseDetails,'branchDetails');
        }
        if(this.checkProperty(this.getCapCaseDetails,'companyDetails')){
          this.selectedPetitioner = this.checkProperty(this.getCapCaseDetails,'companyDetails');
        }
        
        if(this.checkProperty(this.getCapCaseDetails,'beneficiaryDetails')){
          this.selectedBeneficiary = this.checkProperty(this.getCapCaseDetails,'beneficiaryDetails');
          this.upDateBenef() 
        }
        if(this.checkProperty(this.getCapCaseDetails,'capRegId')){
          this.capRegId = this.checkProperty(this.getCapCaseDetails,'capRegId')
        }
          //alert(this.checkProperty(this.getCapCaseDetails,'reqConsdnOfAdvDegreeExptn'))
        if(this.checkProperty(this.getCapCaseDetails,'reqConsdnOfAdvDegreeExptn') == true || this.checkProperty(this.getCapCaseDetails,'reqConsdnOfAdvDegreeExptn') == 'true' ){
         
          this.visasubtype = this.capvisasubtypes[1]
         
        } 
        if(this.checkProperty(this.getCapCaseDetails,'reqConsdnOfAdvDegreeExptn') == false || this.checkProperty(this.getCapCaseDetails,'reqConsdnOfAdvDegreeExptn') == 'false'){
        
          this.visasubtype = this.capvisasubtypes[0]
        }
       
       
        var _s = this; 
        setTimeout(function(){
          _s.addNewCase(true)
        },600)
      }
    if(this.checkProperty(this.$route ,'query' ,'filter')){
      try{
        let filter =this.$route['query']['filter']; this.checkProperty(this.$route ,'query' ,'filter')
        var actual = JSON.parse(atob(filter));
        let keys = Object.keys(actual);
        if(this.checkProperty(keys ,'length') >0){
          if(actual && (Object.keys(actual)).length>0 ){
          _.forEach(actual ,(item ,key) => {
              if(key=='matcher' ){
                if((Object.keys(item)).length>0 ){ 
                  if(_.has(item ,'typeIds') && this.checkProperty(item , 'typeIds' ,'length')>0 ){
                      if(this.visaTypes.length>0){
                        this.selectedVisaType = _.find(this.visaTypes ,{"id":item['typeIds'][0]})
                        this.gobalType = this.selectedVisaType;
                        this.getvisa_subtypes();
                      }else{
                        this.selectedVisaType ={}; 
                        this.selectedVisaType = Object.assign(this.selectedVisaType ,{"id":item['typeIds'][0]});
                        this.gobalType = this.selectedVisaType 
                        this.getvisa_subtypes();
                      }
                    }
                    if(_.has(item ,'countryIds') && this.checkProperty(item , 'countryIds' ,'length')>0 ){
                      if(this.countries.length>0){
                        this.selected_country_obj = _.find(this.countries ,{"id":item['countryIds'][0]})
                        this.changedCountry();
                      }
                    }
                }
              }
          })
        }
        }
      }catch(e){
      }
    }
      this.getInternalStatusList()
      this.getCategoryForCase()
       this.getvisasubtypes(this.visatype);
     //this.getPetitioners();
    //this.getvisatypes();
    this.getvisaforNewCase();
    //this.getvisa_subtypes()
    this.username = this.$store.state.user.name;
    this.roleId = this.$store.state.user["roleId"][0];
//"path": "createdOn", updatedOn, createdByName, typeName, subTypeName, caseNo, statusName
    this.sortKeys = {
      'caseNo':1,
      'createdByName':1,
      "typeName":1,
      "subTypeName":1,
      "statusName":1,
      "createdOn":1,
      "updatedOn":-1,
      "clientName":1,
      "beneficiaryName":1  
    }
    this.sortKey= {"path":'updatedOn',"order":-1};
    if(_.has(this.$route,'name')){
      let localSorting = localStorage.getItem(this.$route['name']);
      if(localSorting){
        localSorting = JSON.parse(localSorting);
        if(this.checkProperty(localSorting, "path") && [1,-1].indexOf(this.checkProperty(localSorting, "order")) ){
          this.sortKey = localSorting;
          _.forEach(this.sortKeys, (sortVal, sortKey)=>{
            if(sortKey == localSorting['path'] ){ 
              this.sortKeys[sortKey] = localSorting['order']
            }else{
              this.sortKeys[sortKey]= localSorting['order']==1?-1:1
            }

            
          });
        }


      }


    }
     
   
    this.getbeneficiaryMasterDataList();
    
    this.getusers();
    this.get_peritioners();
    this.currentuserRole = this.$store.state.user.loginRoleId;
  
    this.getpetitions(false ,true);
    
    
    //if([3].indexOf(this.getUserRoleId) >-1){ 
    this.getBranchList();

    this.filterQueryPreSelect(true);
  //  }
  if(this.checkProperty(this.beneficiaryInfo ,"name")){
  this.selectedUser = this.beneficiaryId;
  this.selectedUsername =this.beneficiaryInfo['name']

  }
 
  },
  computed:{
    checkEnableSelectAll(){
      let returnVal =false;
let activeItems = _.filter(this.petitioners ,(item)=>{
        return this.checkProperty( item ,'status') !=false
     });
     if(activeItems && this.checkProperty(activeItems ,'length')>0){
       returnVal =true;
     }
      return returnVal;
    }
  }
};
</script>
