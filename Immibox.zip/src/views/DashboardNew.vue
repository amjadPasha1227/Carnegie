<template>
<div>
    <div class="dashboard-wrapper">
        <div class="dashboard-content" >
            <p class="login-name">Good Morning {{username}}</p>

 <div class="dashboardTabsList">
     <ul class="ux-tabs">

<li class="ux-tab-item active-tab">All Activities </li>
<li class="ux-tab-item">Tasks (10) </li>

     </ul>
</div>
        <div class="dashboardCardsList darktheme">

  <div
    class="grid-wrapper"


 


  >
    <div
      class="grid-item"
      v-for="item in items"
      :key="item.key"

      v-bind:class="{'tall':item.casetracking,'wide':item.document}"

    >
                        <WallMessage :casetracking="item.casetracking" :petitioner="item.petitioner" :role="item.role" :document="item.document" :action="item.action" :title="item.title" v-bind:key="index" :content="item.description" :item="item" :cssclassname="item.cssclass" />

    </div>
  </div>
           




        </div>




    </div>
    </div>
</div>
</template>

<style scoped>
.dashboard-wrapper{
     height: auto !important;
}
.dashboard-wrapper .dashboard-content {
    width: calc(100% - 0px);
    padding: 30px 30px 10px;
    height: auto;
}
.dashboard-wrapper .dashboard-content .login-name{
    font-size: 1.2806973457336426rem;
    line-height: 1.5rem;
    margin-bottom: 10px;
}
.ux-tabs{
        position: relative;
    display: flex;
    flex-wrap: nowrap;
    padding: 0;
    margin-bottom: 0;
}
.ux-tab-item{
        display: inline-flex;
    margin-top: 0;
    margin-bottom: -1px;
    padding: 8px 20px;
    color: #757575;
}
.active-tab{
        border-bottom: 1px solid #000!important;
            color: #626262
}
.dashboardCardsList {
  position: relative;
  height: 100%;

}



.dashboardCardsList .dsCard{


        border-style: none;
    border-width: 0px;
    border-color: hsla(0, 0%, 70%, 0);
    border-radius: 3px;
    box-shadow: 0 8px 30px -8px #d3d3d3;

}
.color1d{
    background-color: rgba(217, 235, 202,0.5);
}
.color2d{
    background-color: rgba(255, 236, 187,0.5);
}
.color3d{
    background-color: rgba(198, 197, 232,0.5);
}
.color4d{
    background-color: rgba(255, 215, 201,0.5);
}

.darktheme .color1d{
    background-color:#0E1D48;
}
.darktheme .color2d{
    background-color: #33a30f;
}
.darktheme .color3d{
    background-color: #7461e5;
}
.darktheme .color4d{
    background-color: #f05a28 ;
}
.darktheme .vue-avatar--wrapper{color:#000 !important;}
.documentsList{
    margin-top:-10px;
    padding-bottom: 10px;
}
.dashboard-wrapper{

    background-color: #ffffff;
    height: calc(100vh - 120px)
}


</style>

<script>
import VueApexCharts from 'vue-apexcharts'
import Vue from 'vue'
import VuePerfectScrollbar from "vue-perfect-scrollbar";
import { MoreVerticalIcon } from 'vue-feather-icons'
import DateRangePicker from "vue2-daterange-picker";
import Avatar from 'vue-avatar'
import WallMessage from '../views/wall/message.vue'
import { MasonryGrid, JustifiedGrid, FrameGrid, PackingGrid } from "@egjs/vue-grid";

import 'vue2-daterange-picker/dist/vue2-daterange-picker.css'
Vue.use(VueApexCharts)

Vue.component('apexchart', VueApexCharts)

export default {
    components: {
        FrameGrid,
        WallMessage,
        Avatar,
        VuePerfectScrollbar,
        MoreVerticalIcon,
        DateRangePicker
    },
    data: function () {
         



        return {
              items: [
                          { title: 'Thomas V Allen',action:false, document:true,role:"Attorney",groupKey:2,cssclass:'color1d heightd', description: 'Congratulations! H1B Petition (CASE 1234523456) Amendment is approved BY USCIS.' },

        { title: 'Ravi Kumar',groupKey:1,role:"Front Office User", petitioner:true, action:true,cssclass:'color4d', description: 'Innvectra Info Solutions registered as Petitioner.' },
        { title: 'Joseph P', groupKey:3,role:"Supervisor",action:false,cssclass:'color3d', description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum is simply dummy text of the printing and typesetting industry.' },
        { title: 'John Doe',groupKey:4, role:"Paralegal",action:false,cssclass:'color4d', description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.' },
        { title: 'Katrina Kivokova', role:"Documentation Manager",action:false,groupKey:1,cssclass:'color2d', description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.' },
        { title: 'Wilimos Dip', role:"Paralegal",casetracking:true,action:false,groupKey:2,cssclass:'color3d', description: 'Your petition docket sent to USCIS. To Track the FedEx use ITTY456566.' },
        { title: 'James Machnoche', role:"Paralegal",action:false,groupKey:3,cssclass:'color1d', description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.' },
        { title: 'Bill David', role:"Front Office User",action:false,groupKey:4,cssclass:'color4d', description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.' },
        { title: 'Igor Vadliman', role:"Paralegal",action:false,groupKey:1,cssclass:'color3d', description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.' },
        { title: 'Satish Reddy',role:"Front Office User",action:false, groupKey:2,cssclass:'color2d', description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.' },
        { title: 'Syam Kumar', role:"Front Office User",action:false,groupKey:3,cssclass:'color1d', description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.' },
        { title: 'Prem Kumar',role:"Branch Manager",action:false, groupKey:4,cssclass:'color4d', description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.' },
    
      { title: 'Ravi Kumar',groupKey:1,role:"Front Office User", petitioner:true, action:true,cssclass:'color4d', description: 'Innvectra Info Solutions registered as Petitioner.' },
         { title: 'Katrina Kivokova', role:"Documentation Manager",action:false,groupKey:1,cssclass:'color2d', description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.' },
        { title: 'Wilimos Dip', role:"LCA Manager",action:true,groupKey:2,cssclass:'color3d', description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.' },
        { title: 'Igor Vadliman', role:"Paralegal",action:false,groupKey:1,cssclass:'color3d', description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.' },
        { title: 'Satish Reddy',role:"Front Office User",action:false, groupKey:2,cssclass:'color2d', description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.' },
    
        { title: 'Thomas V Allen',action:false, document:true,role:"Attorney",groupKey:2,cssclass:'color1d', description: 'Congratulations! H1B Petition (CASE 1234523456) Amendment is approved BY USCIS.' },
        { title: 'Joseph P', groupKey:3,role:"Supervisor",action:false,cssclass:'color3d', description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum is simply dummy text of the printing and typesetting industry.' },
        { title: 'John Doe',groupKey:4, role:"Paralegal",action:false,cssclass:'color4d', description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.' },
           { title: 'Syam Kumar', role:"Front Office User",action:false,groupKey:3,cssclass:'color1d', description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.' },
        { title: 'Prem Kumar',role:"Branch Manager",action:false, groupKey:4,cssclass:'color4d', description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.' },
        { title: 'James Machnoche', role:"Paralegal",action:false,groupKey:3,cssclass:'color1d', description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.' },
        { title: 'Bill David', role:"Front Office User",action:false,groupKey:4,cssclass:'color4d', description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.' },
    
    
    ],
             gap: 5,
    defaultDirection: "end",frame: [[1,1,2,3,3],[1,1,4,4,5]],

    rectSize: 0,
    useFrameFill: true,

             dateRange: {
               // startDate: '2019-12-26',
               // endDate: '2019-12-28',
                },
            username: '',
            activities: [],
            options: {},
            series: [50, 102, 155, 141, 117],
            dashboard_data: {},
            lca_requests: [],
            new_petitioners: [],
            new_petitions: [],
            petitionersCount: {},
            beneficiaryStats: {},

            petitionsCount: {},
            rfe_petitions: [],

            //recent activity data
            recent_activitys: [],
            my_tasks: [],
            roleId: 0,

        }
    },
   
    mounted() {
        this.username = this.$store.state.user.name;
        this.roleId = this.$store.state.user['roleId'][0];
       
        this.petitionsCount = {
            petitionCount: 0,
            rfeCount: 0,
            totalCount: 0
        };
        this.petitionersCount = {
            approvedCount: 0,
            pendingCount: 0,
            totalCount: 0
        };
        this.beneficiaryStats = {
            "total": 0,
            "active": 0,
            "inactive": 0
        };

        this.get_dashboardData();
        this.get_recentActivitys();
        this.get_mytasks();
        this.getactivities();

    },
    methods: {
        get_dashboardData: function () {
            this.$store.dispatch("get_dashboard_data", {}).then(response => {
                this.dashboard_data = response;
                this.lca_requests = this.dashboard_data['lca_requests'] ? this.dashboard_data['lca_requests'] : [];

                this.petitionsCount = this.dashboard_data['petitionsCount'] ? this.dashboard_data['petitionsCount'] : {
                    petitionCount: 0,
                    rfeCount: 0,
                    totalCount: 0
                };
                this.petitionersCount = this.dashboard_data['petitionersCount'] ? this.dashboard_data['petitionersCount'] : {
                    approvedCount: 0,
                    pendingCount: 0,
                    totalCount: 0
                };
                this.beneficiaryStats = this.dashboard_data['beneficiaryStats'] ? this.dashboard_data['beneficiaryStats'] : {
                    "total": 0,
                    "active": 0,
                    "inactive": 0
                };

                this.new_petitioners = this.dashboard_data['new_petitioners'] ? this.dashboard_data['new_petitioners'] : [];
                this.new_petitions = this.dashboard_data['new_petitions'] ? this.dashboard_data['new_petitions'] : [];
                this.rfe_petitions = this.dashboard_data['rfe_petitions'] ? this.dashboard_data['rfe_petitions'] : [];
            });
        },
        get_recentActivitys: function () {
            this.$store.dispatch("get_recent_activitys", {}).then(response => {
                this.recent_activitys = response.list;
                
            });
        },
        getactivities: function () {
            this.$store.dispatch("getactivities").then(response => {
                this.activities = response;
            });
        },
        get_mytasks: function () {
            this.$store.dispatch("get_my_tasks", {}).then(response => {

                this.my_tasks = response.list.map((element) => {
                    //"navigationKey":

                    

                    element["data"]['navigation_link'] = "#";
                    if (element["data"]["navigationKey"] == "USER_DETAILS")
                        // element["data"]['navigation_link'] ="#/company/details/"+element["data"]['companyId'];

                        if (element["data"]["navigationKey"] == "COMPANY_DETAILS")
                            element["data"]['navigation_link'] = "/company/details/" + element["data"]['companyId'];

                    if (element["data"]["navigationKey"] == "PETITION_DETAILS")
                        element["data"]['navigation_link'] = "/petition-details/" + element["data"]['petitionId'];

                    if (element["data"]["navigationKey"] == "LCA_DETAILS")
                        element["data"]['navigation_link'] = "/lca-details/" + element["data"]['lcaId'];

                    if (element["data"]["description"].includes("questionnaire ")) element["data"]['navigation_link'] = "/questionnaire/" + element["data"]['petitionId'];

                    return element;

                });
                
                //this.my_tasks = a//response.list;

            });
        },
        refresh() {
           // alert("REFERESH");
            this.get_recentActivitys();
        },
    }
};
</script>
