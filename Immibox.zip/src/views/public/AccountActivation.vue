<template>
  <div class="vx-col w-full mb-base wizard-container">
    <vx-card>
      <vs-popup class="holamundo status-popup" :active.sync="Comments">
        <div>
          <figure>
            <img src="@/assets/images/main/professional.svg" />
          </figure>
          <h2>Thank You</h2>
          <p>{{ message }}</p>
          <br/><br/>
                <a href="/login"><i class="IP-arrow-pointing-to-right"></i> Back to Sign In</a>

        </div>

        <div class="status-popup-footer">
          <ul>
            <li>
              <i class="icon IP-email"></i>
              <a href="mailto:law@thomasvallen.com">law@thomasvallen.com</a>
            </li>
            <li><i class="icon IP-telephone-1"></i> +1 732-832-7978</li>
          </ul>
        </div>
      </vs-popup>
    </vx-card>
  </div>
</template>
<script>
export default {
  data() {
    return {
      message: "",
      Comments: true
    };
  },
  mounted() {
    var parameters = this.$route.query;
    
    const obj = {
      apiKey: "FV$HSE@JUGUUGU$J5L@HE",
      tenantId: this.getTenantId,
      key: parameters.key,
      userId: parameters.userId
    };
    this.$store.dispatch("petitioner/activateaccount", obj).then(response => {
      if (response.error) {
        this.message = response.error.message;
      } else {
        this.message = response.data.message;
      }
    });
  }
};
</script>
