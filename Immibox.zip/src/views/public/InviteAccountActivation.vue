<template>
  <div class="vx-col w-full mb-base wizard-container">
    <vx-card>
      <vs-popup
        class="popup-accounts"
        title="Your registration is complete."
        :active.sync="SetPassword"
      >
        <div v-if="formsuccess" class="popup-accounts-content popupform">
          <div>
            <figure>
              <img src="@/assets/images/main/icon-sent.svg" alt="login" class="mx-auto" />
            </figure>
            <h2 class="title">Password Updated</h2>
            <p style="margin-bottom:20px;">Please login again to continue</p>
            <a href="javascript:;" @click="reloadthePage">
              <i class="IP-arrow-pointing-to-right"></i> Back to Sign In
            </a>
          </div>
        </div>

        <div v-if="reserkey_success" class="popup-accounts-content popupform">
          <div>
            <figure>
              <img src="@/assets/images/main/icon-sent.svg" alt="login" class="mx-auto" />
            </figure>
            <h2 class="title">Reset Activation key</h2>
            <p style="margin-bottom:20px;">You will receive a Activation linl email along with access as soon.
            </p>
            <a href="javascript:;" @click="reloadthePage">
              <i class="IP-arrow-pointing-to-right"></i> Back to Sign In
            </a>
          </div>
        </div>

         

        <div v-if="!formsuccess" class="popup-accounts-content popupform">
          <div class="vx-card__title text-left">
            <h2 class="title">Set a Password</h2>
          </div>

          <form autocomplete="off">
            <div class="text-danger text-sm formerrors" v-show="formerrors.msg">
              <vs-alert
                color="warning"
                class="warning-alert reg-warning-alert no-border-radius"
                icon-pack="IntakePortal"
                icon="IP-information-button"
                active="true"
              >{{ formerrors.msg }}</vs-alert>
            </div> 

            <div class="login-inputs">
              
              <div
                class="main-placeholder right"
                style="border-bottom: 1px solid #E7E7E8 !important;"
              >
                <div class="errormsg-support">
                  <vs-input
                    type="password"
                    icon="icon IP-key-1"
                    icon-pack="feather"
                    label-placeholder="Password"
                    v-model="password"
                    class="w-full no-icon-border"
                    name="password"
                    ref="password"
                    v-validate="'required|min:6|max:15|strongpassword'"
                      @keyup.enter="updatePassword"
                  />
                </div>
              </div>
              <div class="main-placeholder right">
                <div class="errormsg-support">
                  <vs-input
                    type="password"
                    icon="icon IP-key-1"
                    icon-pack="feather"
                    label-placeholder="Confirm Password"
                    class="w-full no-icon-border"
                    v-validate="'required|min:6|max:15|confirmed:password'"
                    name="confirm_password"
                    data-vv-as="Confirm Password"
                    v-model="confirm_password"
                      @keyup.enter="updatePassword"
                  />
                </div>
              </div>
            </div>
            <div class="password_errors">
              <span
                class="error-text"
                v-show="errors.has('confirm_password')"
              >Password and Confirm Password values do not match.</span>
              <span
                class="error-text"
                v-show="errors.has('password')"
              >{{ errors.first("password") }}</span>
            </div>
            <div class="vx-row sign-filled mt-12">
              <div class="vx-col w-1/2">
                <vs-button @click="updatePassword" class="w-full"  :disabled="password=='' || password !=confirm_password"  type="filled">Update</vs-button>
              </div>
                            
            </div>
          </form>
         
        </div>
        <div class="popup-accounts-footer" v-if="!formsuccess">
          <div class="password-count">
            <i class="icon IP-lock"></i> Password must contain 6 to 15
            characters
          </div>
          <div class="password-strength"></div>
        </div>
         
      </vs-popup>
    </vx-card>
  </div>
</template>
<script>
import { CheckCircleIcon } from "vue-feather-icons";
export default {
  mounted(){
      this.parameters = this.$route.query;
     
  },  
  data() {
    return {
        parameters:null,
      date: null,
      formsuccess: false,
      reserkey_success:false,
      password: "",
      currentpassword: "",
      confirm_password: "",
      SetPassword: true,
      formerrors: {
        msg: ""
      }
    };
  },
  methods: {
    reloadthePage() {
     var self = this;
       this.$store.dispatch("logout").then(() => {
          self.SetPassword = false;
        this.$router.push("/login");
      });
    },
    updatePassword() {
        this.$validator.validateAll().then(result => {
            if (result) {

                const obj = {
                    apiKey: "FV$HSE@JUGUUGU$J5L@HE",
                    tenantId: this.getTenantId,
                    key: this.parameters.key,
                    userId: this.parameters.userId,
                    confirmPassword: this.confirm_password,
                    password: this.password,
                    updatePassword:true,
                };
                    this.$store.dispatch("petitioner/activateaccount", obj).then(response => {
                    if (response.error) {
                        this.message = response.error.message;
                        Object.assign(this.formerrors, {
                            msg: response.error.message
                            });
                    } else {
                        this.message = response.data.message;
                        this.formsuccess = true;
                            document.addEventListener("click", this.reloadthePage);
                    }
                    });
            }

     });

    //   this.$validator.validateAll().then(result => {
    //     if (result) {
    //       var object = {
    //         currentPassword: this.currentpassword,
    //         newPassword: this.password,
    //         email: this.$store.state.user.email
    //       };

    //       this.$store.dispatch("updatepassword", object).then(response => {
    //         if (response.error) {
    //           Object.assign(this.formerrors, {
    //             msg: response.error.message
    //           });
    //         } else {
    //           this.formsuccess = true;
    //           document.addEventListener("click", this.reloadthePage);
    //         }
    //       });
    //     }
    //   });
    },

    requestactivationKey() {
       
               const obj = {
                    apiKey: "FV$HSE@JUGUUGU$J5L@HE",
                    tenantId: this.getTenantId,
                    key: this.parameters.key,
                    userId: this.parameters.userId,
                    
                };
                    this.$store.dispatch("petitioner/requestactivationKey", obj).then(response => {
                    if (response.error) {
                        this.message = response.error.message;
                        Object.assign(this.formerrors, {
                            msg: response.error.message
                            });
                    } else {
                        this.message = response.data.message;
                        this.reserkey_success = true;
                            document.addEventListener("click", this.reloadthePage);
                    }
                    });
            

     
    
    },
  },
  
   beforeDestroy(){
              document.removeEventListener('click', this.reloadthePage);
   },
  components: {
    CheckCircleIcon
  }
};
</script>
