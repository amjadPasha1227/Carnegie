<template>
  <div>
    <div class="content-header case-search-header">
      <div class="content-header-left">
        <!-- <div class="search">
          <vs-input icon-pack="feather" icon="icon-search"
            :placeholder="beneficiaryId ==null?'Search By Case No/Beneficiary':'Search By Case No'"
            class="is-label-placeholder" v-model.lazy="searchtxt" />
        </div>
        <div class="con-select selection_search casetype" v-if="[51].indexOf(getUserRoleId) < 0">
          <multiselect @input="changedVisaTypeClear" v-model="selectedVisaType" :options="visaTypes" :multiple="false"
            :close-on-select="true" :clear-on-select="false" :preserve-search="true" placeholder="Select Case Type"
            label="name" track-by="name" :preselect-first="false">

            <template slot="selection" slot-scope="{ values, isOpen }">
              <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }} Case Type(s)
                Selected</span>
              <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
            </template>
          </multiselect>
        </div>
        <div class="con-select selection_search"
          v-if="[3,4,5,6,7,8,9,10,11,12,13].indexOf(getUserRoleId)>-1 && beneficiaryId ==null && getTenantTypeId !=2">
          <multiselect @input="changedperitionerss()" v-model="selected_peritioners" :options="all_peritioners"
            :multiple="true" :hideSelected="true" :close-on-select="false" :clear-on-select="false"
            :preserve-search="true" placeholder="Select Petitioners" label="name" track-by="name"
            :preselect-first="false" @search-change="peritioners_search_fun">
            <template slot="selection" slot-scope="{ values, isOpen }">
              <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }} Petitioner(s)
                Selected</span>
              <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
            </template>

          </multiselect>
        </div> -->
      </div>
      <div class="content-header-right">
        <!--filter dropdown-->
        <vs-dropdown vs-custom-content vs-trigger-click>
          <vs-button color="primary" class="filter-btn" type="border" icon-pack="feather" icon="icon-chevron-down"
            icon-after>
            <img src="@/assets/images/main/icon-filter.svg" /> Filters
          </vs-button>
          <vs-dropdown-menu ref="filter_menu" class="filters-content">
            <div class="filters-form-fileds">
              <div class="form-container">
                <div class="vx-row">
                  <div class="vx-col md:w-1/3 w-full con-select filters-search">
                    <label class="typo__label">Search</label>
                    <vs-input icon-pack="feather" icon class="is-label-placeholder" v-model="filter_searchtxt" />
                  </div>

                  <div class="vx-col md:w-1/3 w-full con-select"
                    v-if="false && [3].indexOf(getUserRoleId)>-1 && this.beneficiaryId==null">
                    <label class="typo__label">Select Branch</label>
                    <multiselect @input="$router.push({ query: {} })" v-model="selectedBranches" :options="branchList"
                      :multiple="true" :hideSelected="true" :close-on-select="false" :clear-on-select="false"
                      :preserve-search="true" placeholder="Select Branch" label="name" track-by="name"
                      :preselect-first="false">

                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          Branches Selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>

                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Status</label>
                    <multiselect @input="$router.push({ query: {} })" v-model="selected_statusids"
                      :options="all_statusids" :multiple="true" :hideSelected="true" :close-on-select="false"
                      :clear-on-select="false" :preserve-search="true" placeholder="Select Status" label="name"
                      track-by="name" :preselect-first="false">
                      <!-- <template slot="selection" slot-scope="{ values, search, isOpen }">
                        <span
                          class="multiselect__single"
                          v-if="values.length &amp;&amp; !isOpen"
                        >{{ values.length }} options selected</span>
                      </template> -->
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          Status Selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>



                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Case Type</label>
                    <multiselect @input="changedVisaType" v-model="selectedVisaType" :options="visaTypes"
                      :multiple="false" :close-on-select="true" :clear-on-select="false" :preserve-search="true"
                      placeholder="Select Case Type" label="name" track-by="name" :preselect-first="false">

                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }} Case
                          Type(s) Selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>

                  <!---all_subtypes---->
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Case Subtype</label>
                    <multiselect @input="$router.push({ query: {} });changedsubtypes()" v-model="selected_subtypes"
                      :options="all_subtypes" :multiple="true" :hideSelected="true" :close-on-select="false"
                      :clear-on-select="false" :preserve-search="true" placeholder="Select Case Subtype" label="name"
                      track-by="name" :preselect-first="false">

                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }} Case
                          Subtype(s) Selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>

                  <!--
                  <div v-if="roleId != 6 && roleId != 7" class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Select Users</label>
                    <multiselect
                      @input="changedusers()"
                      v-model="selected_users"
                      :options="users"
                      :multiple="true" :hideSelected="true"
                      :close-on-select="false"
                      :clear-on-select="false"
                      :preserve-search="true"
                      placeholder="Select Users"
                      label="name"
                      track-by="name"
                      :preselect-first="false"
                      @search-change="user_search"
                    >
                      
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} User(s) Selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template>
                    </multiselect>
                  </div>
                  -->

                  <!-------------Select Petitioners this.all_peritioners ----------->
                  <div class="vx-col md:w-1/3 w-full con-select"
                    v-if="[3,4,5,6,7,8,9,10,11,12,13,14].indexOf(getUserRoleId)>-1 && beneficiaryId ==null && getTenantTypeId !=2">
                    <label class="typo__label">Petitioners</label>
                    <multiselect @input="changedperitioners()" v-model="selected_peritioners" :options="all_peritioners"
                      :multiple="true" :hideSelected="true" :close-on-select="false" :clear-on-select="false"
                      :preserve-search="true" placeholder="Select Petitioners" label="name" track-by="name"
                      :preselect-first="false" @search-change="peritioners_search_fun">
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          Petitioner(s) Selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>

                    </multiselect>

                  </div>
                  <!-------Select Beneficiars-------->
                  <!-- <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Select Beneficiars</label>
                    <multiselect ref="country_selectbox" @input="changedCountry()"  v-model="selected_country_obj" :options="countries"  :multiple="false" :close-on-select="true" :clear-on-select="false" :preserve-search="true" placeholder="Select Country" label="name" track-by="name" :preselect-first="false">
                      <template slot="selection" slot-scope="{ values, search, isOpen }"><span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">{{ values.length }} options selected</span></template>
                    </multiselect>

                  </div>-->
                  <!-------genders--------->
                  <!--<div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Select Gender</label>
                    <multiselect ref="country_selectbox" @input="changedCountry()"  v-model="selected_country_obj" :options="countries"  :multiple="false" :close-on-select="true" :clear-on-select="false" :preserve-search="true" placeholder="Select Country" label="name" track-by="name" :preselect-first="false">
                      <template slot="selection" slot-scope="{ values, search, isOpen }"><span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">{{ values.length }} options selected</span></template>
                    </multiselect>

                  </div>-->
                  <!------------maritalStatusIds---------->
                  <!-- <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Select MaritalStatus</label>
                    <multiselect ref="country_selectbox" @input="changedCountry()"  v-model="selected_country_obj" :options="countries"  :multiple="false" :close-on-select="true" :clear-on-select="false" :preserve-search="true" placeholder="Select Country" label="name" track-by="name" :preselect-first="false">
                      <template slot="selection" slot-scope="{ values, search, isOpen }"><span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">{{ values.length }} options selected</span></template>
                    </multiselect>

                  </div>-->

                  <!----------Select Country------->
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Country</label>
                    <multiselect ref="country_selectbox" @input="$router.push({ query: {} });changedCountry()"
                      v-model="selected_country_obj" :options="countries" :multiple="false" :close-on-select="true"
                      :clear-on-select="false" :preserve-search="true" placeholder="Select Country" label="name"
                      track-by="name" :preselect-first="false">
                      <template slot="selection" slot-scope="{ values, search, isOpen }">
                        <span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">{{ values.length }}
                          options selected</span>
                      </template>
                    </multiselect>
                  </div>

                  <!--------Select States----->
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">States</label>
                    <multiselect v-bind:disabled="country_code <= 0" @input="$router.push({ query: {} });changedState()"
                      v-model="seleted_states" :options="all_states" :multiple="false" :close-on-select="true"
                      :clear-on-select="false" :preserve-search="true" placeholder="Select States" label="name"
                      track-by="name" :preselect-first="false">
                      <!-- <template slot="selection" slot-scope="{ values, search, isOpen }">
                        <span
                          class="multiselect__single"
                          v-if="values.length &amp;&amp; !isOpen"
                        >{{ values.length }} options selected</span>
                      </template> -->
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          Status Selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>
                  <!---- seleted_locations --->
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Locations</label>
                    <multiselect @input="$router.push({ query: {} })"
                      v-bind:disabled="final_selected_states.length <= 0" v-model="seleted_locations"
                      :options="all_locations" :multiple="true" :hideSelected="true" :close-on-select="false"
                      :clear-on-select="false" :preserve-search="true" placeholder="Select Locations" label="name"
                      track-by="name" :preselect-first="false">
                      <!-- <template slot="selection" slot-scope="{ values, search, isOpen }">
                        <span
                          class="multiselect__single"
                          v-if="values.length &amp;&amp; !isOpen"
                        >{{ values.length }} options selected</span>
                      </template> -->
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          Location(s) Selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>

                  <!------- premiumProcessingList:[true ,false],
    selectedpremiumProcessing:[{name:'Enabled' ,_id:true },{name:'Disabled' ,_id:false }],-->


                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Premium Processing</label>
                    <multiselect @input="$router.push({ query: {} })" v-model="selectedpremiumProcessing"
                      :options="premiumProcessingList" :multiple="true" :hideSelected="true" :close-on-select="false"
                      :clear-on-select="false" :preserve-search="true" placeholder="Select Premium Processing"
                      label="name" track-by="name" :preselect-first="false">

                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          Premium Processing(s) Selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>

                  <div class="vx-col md:w-1/3 w-full con-select" v-if="[3,4].indexOf(getUserRoleId)>-1">
                    <label class="typo__label">Deleted</label>
                    <multiselect @input="$router.push({ query: {} })" v-model="selectedarchive"
                      :options="[{'name':'Deleted' ,'_id':false} ,{'name':'Active' ,'_id':true}]" :multiple="true"
                      :hideSelected="true" :close-on-select="false" :clear-on-select="false" :preserve-search="true"
                      placeholder="Select" label="name" track-by="name" :preselect-first="false">

                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          Selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>

                  <!--Created Date--->
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Created Date</label>
                    <date-range-picker @input="$router.push({ query: {} })" :maxDate="new Date()" :autoApply="autoApply"
                      :ranges="false" :opens="'left'" v-model="selected_createdDateRange"></date-range-picker>
                  </div>
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Deadline Date</label>

                    <date-range-picker @input="$router.push({ query: {} })" :autoApply="autoApply" :ranges="false"
                      :opens="'left'" v-model="selected_deadLineDateRange"></date-range-picker>
                  </div>
                </div>
              </div>
            </div>
            <div class="filters-status">
              <div class="left-buttons"></div>
              <div class="right-buttons">
                <vs-button color="success" class="save" type="filled" v-on:click="set_filter()">Apply</vs-button>
                <vs-button color="dark" class="cancel" type="filled" v-on:click="clear_filter($event)">Clear</vs-button>
              </div>
            </div>
          </vs-dropdown-menu>
        </vs-dropdown>



        <vs-button color="primary" type="border" class="light-blue-btn"
          @click="selectedBeneficiary =null ; selectedPetitioner=null;addNewCase(true)"
          v-if="!isRfe&& checkCaseCreatePermisions">

          New Case <span>
            <img class="add-user-icon ml-2" src="@/assets/images/main/add-user.svg">
          </span></vs-button>
      </div>
    </div>

    <div class="accordian-table custom-table relative">
      <table class="vs-table vs-table--tbody-table">
        <thead class="vs-table--thead">
          <tr><!---->
            <th>
              <div class="vs-table-text"><!---->
                <div class="vs-component con-vs-checkbox vs-checkbox-primary vs-checkbox-default">
                  <input type="checkbox" class="vs-checkbox--input">
                  <span class="vs-checkbox">
                    <span class="vs-checkbox--check">
                      <i class="vs-icon vs-checkbox--icon  material-icons">check</i>
                    </span>
                  </span>
                  <span class="con-slot-label"></span>
                </div>
                <a class="sort_ascending">Case No</a>
              </div>
            </th>
            <th>
              <div class="vs-table-text">
                <a class="sort_ascending">Beneficiary</a>
              </div>
            </th>
            <th>
              <div class="vs-table-text">
                <a class="sort_ascending">Case Type</a>
              </div>
            </th>
            <th>
              <div class="vs-table-text">
                <a class="sort_ascending">Petitioner</a>
              </div>
            </th>
            <th>
              <div class="vs-table-text">
                <a class="sort_ascending">Client</a>
              </div>
            </th>
            <th>
              <div class="vs-table-text">
                <a class="sort_descending">Last Updated</a>
              </div>
            </th>
            <th>
              <div class="vs-table-text">
                <a class="sort_ascending">Status</a>
              </div>
            </th>
          </tr>
        </thead>
        <tr class="vs-table--tr">
          <td class="td vs-table--td">
            <span>
              <div class="vs-component con-vs-checkbox vs-checkbox-primary vs-checkbox-default">
                <input type="checkbox" class="vs-checkbox--input">
                <span class="checkbox_x vs-checkbox">
                  <span class="vs-checkbox--check">
                    <i class="vs-icon vs-checkbox--icon  material-icons">check</i>
                  </span>
                </span>
                <span class="con-slot-label"></span>
              </div>
              <a href="/gc-employment-details" class="">GC-PERM-Certification</a>
            </span>
          </td>
          <td class="td vs-table--td">
            <span>
              <span class="cursor-pointer">Joe Root </span>
            </span>
          </td>
          <td class="td vs-table--td">
            <span>
              <div class="cursor-pointer"> GC <br><small> PERM Certification </small></div>
            </span>
          </td>
          <td class="td vs-table--td">
            <span><span class="cursor-pointer">Roy Groups</span></span>
          </td>
          <td class="td vs-table--td"><span>IDC info Tech</span></td>
          <td class="td vs-table--td"><span><span class="cursor-pointer">Aug 22, 2022</span></span>
          </td>
          <td class="td vs-table--td">
            <span>
              <span class="cursor-pointer status_created">Submitted</span>
            </span>
          </td>
        </tr>
        <tr class="vs-table--tr">
          <td class="td vs-table--td">
            <span>
              <div class="vs-component con-vs-checkbox vs-checkbox-primary vs-checkbox-default">
                <input type="checkbox" class="vs-checkbox--input">
                <span class="checkbox_x vs-checkbox">
                  <span class="vs-checkbox--check">
                    <i class="vs-icon vs-checkbox--icon  material-icons">check</i>
                  </span>
                </span>
                <span class="con-slot-label"></span>
              </div>
              <a href="/gc-employment-details" class="">GC-I-140-Petition</a>
            </span>
          </td>
          <td class="td vs-table--td">
            <span>
              <span class="cursor-pointer">Emma Eva</span>
            </span>
          </td>
          <td class="td vs-table--td">
            <span>
              <div class="cursor-pointer"> GC <br><small> I-140 Petition </small></div>
            </span>
          </td>
          <td class="td vs-table--td">
            <span><span class="cursor-pointer">IDC info Tech</span></span>
          </td>
          <td class="td vs-table--td"><span>IDC info Tech</span></td>
          <td class="td vs-table--td"><span><span class="cursor-pointer">Aug 22, 2022</span></span>
          </td>
          <td class="td vs-table--td">
            <span>
              <span class="cursor-pointer status_created">Submitted</span>
            </span>
          </td>
        </tr>
        <tr class="vs-table--tr">
          <td class="td vs-table--td">
            <span>
              <div class="vs-component con-vs-checkbox vs-checkbox-primary vs-checkbox-default">
                <input type="checkbox" class="vs-checkbox--input">
                <span class="checkbox_x vs-checkbox">
                  <span class="vs-checkbox--check">
                    <i class="vs-icon vs-checkbox--icon  material-icons">check</i>
                  </span>
                </span>
                <span class="con-slot-label"></span>
              </div>
              <a href="/gc-employment-details" class="">GC-I-485-Application</a>
            </span>
          </td>
          <td class="td vs-table--td">
            <span>
              <span class="cursor-pointer">Joe Root </span>
            </span>
          </td>
          <td class="td vs-table--td">
            <span>
              <div class="cursor-pointer"> GC <br><small> I-485 Application </small></div>
            </span>
          </td>
          <td class="td vs-table--td">
            <span><span class="cursor-pointer">NA</span></span>
          </td>
          <td class="td vs-table--td"><span>NA</span></td>
          <td class="td vs-table--td"><span><span class="cursor-pointer">Aug 22, 2022</span></span>
          </td>
          <td class="td vs-table--td">
            <span>
              <span class="cursor-pointer status_created">Submitted</span>
            </span>
          </td>
        </tr>
        <tr class="vs-table--tr">
          <td class="td vs-table--td">
            <span>
              <div class="vs-component con-vs-checkbox vs-checkbox-primary vs-checkbox-default">
                <input type="checkbox" class="vs-checkbox--input">
                <span class="checkbox_x vs-checkbox">
                  <span class="vs-checkbox--check">
                    <i class="vs-icon vs-checkbox--icon  material-icons">check</i>
                  </span>
                </span>
                <span class="con-slot-label"></span>
              </div>
              <a href="/gc-employment-details" class="">GC-PERM-Certification</a>
            </span>
          </td>
          <td class="td vs-table--td">
            <span>
              <span class="cursor-pointer">Jong Yong</span>
            </span>
          </td>
          <td class="td vs-table--td">
            <span>
              <div class="cursor-pointer"> GC <br><small> PERM Certification </small></div>
            </span>
          </td>
          <td class="td vs-table--td">
            <span><span class="cursor-pointer">Roy Groups</span></span>
          </td>
          <td class="td vs-table--td"><span>IDC info Tech</span></td>
          <td class="td vs-table--td"><span><span class="cursor-pointer">Aug 22, 2022</span></span>
          </td>
          <td class="td vs-table--td">
            <span>
              <span class="cursor-pointer status_created">Submitted</span>
            </span>
          </td>
        </tr>
        <tr class="vs-table--tr">
          <td class="td vs-table--td">
            <span>
              <div class="vs-component con-vs-checkbox vs-checkbox-primary vs-checkbox-default">
                <input type="checkbox" class="vs-checkbox--input">
                <span class="checkbox_x vs-checkbox">
                  <span class="vs-checkbox--check">
                    <i class="vs-icon vs-checkbox--icon  material-icons">check</i>
                  </span>
                </span>
                <span class="con-slot-label"></span>
              </div>
              <a href="/gc-employment-details" class="">GC-I-140-Petition</a>
            </span>
          </td>
          <td class="td vs-table--td">
            <span>
              <span class="cursor-pointer">Joe Root </span>
            </span>
          </td>
          <td class="td vs-table--td">
            <span>
              <div class="cursor-pointer"> GC <br><small> I-140 Petition </small></div>
            </span>
          </td>
          <td class="td vs-table--td">
            <span><span class="cursor-pointer">Roy Groups</span></span>
          </td>
          <td class="td vs-table--td"><span>IDC info Tech</span></td>
          <td class="td vs-table--td"><span><span class="cursor-pointer">Aug 22, 2022</span></span>
          </td>
          <td class="td vs-table--td">
            <span>
              <span class="cursor-pointer status_created">Submitted</span>
            </span>
          </td>
        </tr>
      </table>
    </div>

    <vs-popup class="holamundo main-popup" title="Invite Customer" :active.sync="invitepetitioner">

      <addBenewPet @closenewPetPopup="closenewPetPopup" v-if="invitepetitioner" />
    </vs-popup>

    <vs-popup class="holamundo main-popup" :class="{'openedNewpetpopup':invitepetitioner}" :title="'Add Beneficiary'"
      :active.sync="AddBeneficiary">
      <addBeneficiary ref="add_ben" @closeAddBenPopUp="closeAddBenPopUp" v-if="AddBeneficiary"
        :petitioner="selectedPetitioner" @openAddpetPopUp="openAddpetPopUp" />
    </vs-popup>

    <vs-popup class="holamundo main-popup" :class="{'openedNewpetpopup':invitepetitioner || AddBeneficiary}"
      title="New Case" :active.sync="NewPetition">
      <form>

        <div class="form-container">
          <div class="vx-row" >


            <template>
              <div class="vx-col w-1/2">
                <div class="form_group">
                  <div class="con-select w-full select-large">
                    <label for="" class="form_label">Case Type<em>*</em></label>
                    <!-- <multiselect name="visatype" data-vv-as="Case Type" v-validate="'required'" v-model="visatype"
                      :show-labels="false" track-by="id" label="name" placeholder="Select Case Type"
                      :options="casetypeoptions" :searchable="true" :allow-empty="false" @input="getvisasubtypes">
                    </multiselect> -->
                    <multiselect
                              v-model="casevalue"
                              :options="casetypeoptions"
                            ></multiselect>
                  </div>
                  <!-- <span class="text-danger text-sm" v-show="errors.has('newpetitionform.visatype')">{{
                    errors.first("newpetitionform.visatype") }}</span> -->
                </div>
              </div>

              <div class="vx-col w-1/2">
                <div class="form_group">
                  <div class="con-select w-full select-large">
                    <label for="" class="form_label">Case Subtype<em>*</em></label>
                    <!-- <multiselect name="visasubtype" data-vv-as="Case Subtype" v-validate="'required'"
                      v-model="visasubtype" :show-labels="false" track-by="id" label="name"
                      placeholder="Select Case Subtype" :options="visasubtypes" :searchable="true" :allow-empty="false"
                      @input="formerrors.msg=''">
                    </multiselect> -->
                    <multiselect
                         v-model="subcasevalue"
                        :options="casesubtypeoptions"
                      ></multiselect>
                  </div>
                  <!-- <span class="text-danger text-sm" v-show="errors.has('newpetitionform.visasubtype')">{{
                    errors.first("newpetitionform.visasubtype") }}</span> -->
                </div>
              </div>

              <div class="vx-col w-full pp-col">
                <vs-checkbox id="premium" name="premiumProcessing" v-model="premiumProcessing">Premium Processing
                </vs-checkbox>

                <!-- <span class="text-danger text-sm"  v-show="errors.has('finalDeterminationFromDOL')">{{ errors.first("finalDeterminationFromDOL") }}</span> -->

              </div>

              <div v-if="getTenantTypeId !=2 " class="vx-col  w-full">
                <div class="form_group">
                  <div class="con-select w-full select-large">
                    <label for="" class="form_label">Branch<em>*</em></label>
                    <multiselect name="branch" v-validate="'required'" v-model="selectedBranch" :show-labels="false"
                      track-by="_id" label="name" placeholder="Select Branch" :options="branchList" :searchable="true"
                      :allow-empty="false" :multiple="false" :disabled="branchList.length==1"
                      @input="formerrors.msg=''">
                    </multiselect>
                  </div>
                  <span class="text-danger text-sm" v-show="errors.has('newpetitionform.branch')">{{
                    errors.first("newpetitionform.branch") }}</span>
                </div>
              </div>
            </template>

            <template v-if="beneficiaryId ==null ">
              <template v-if="([3,4,5,6,7,50].indexOf(getUserRoleId)>-1 && getTenantTypeId !=2 )">
                <div class="vx-col w-1/2" v-if="([3,4,5,6,7].indexOf(getUserRoleId)>-1 ) && subcasevalue!='I-485 Application'">
                  <div class="form_group">
                    <div class="con-select w-full select-large">
                      <label class="form_label">Select Petitioner<em>*</em></label>
                      <multiselect v-model="selectedPetitioner" :options="petitionersList" :multiple="false"
                        :hideSelected="false" :close-on-select="true" :clear-on-select="false" :preserve-search="true"
                        :select-label="'Search Petitioner'" placeholder="Select Petitioner" label="name" track-by="name"
                        :preselect-first="false" data-vv-as="Petitioner" v-validate="'required'"
                        tag-placeholder="Invite Petitioner" :taggable="false" @tag="addNewPet" :searchable="true"
                        @search-change="searchPet" @input="petitionerUpdated" name="Petitioner">

                        <template slot="selection" slot-scope="{ values, isOpen }">
                          <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                            options selected</span>
                          <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                        </template>
                      </multiselect>
                    </div>
                    <span class="text-danger text-sm" v-show="errors.has('newpetitionform.Petitioner')">{{
                      errors.first("newpetitionform.Petitioner") }}</span>
                  </div>
                  <p v-if="checkPetInvitePermisions" class="createnew">Not found?<span @click="addNewPet()">Invite
                      Customer</span> </p>
                </div>

                <div class="vx-col w-1/2" :class="{'w-full':[50 ].indexOf(getUserRoleId)>-1 }"
                  v-if="([3,4,5,6,7,50 ].indexOf(getUserRoleId)>-1  ) ">
                   <div class="form_group" v-if="subcasevalue=='I-485 Application'">
                    <div class="con-select w-full select-large">
                      <label class="form_label" >Select Individual<em>*</em></label>
                      <multiselect v-model="selectedBeneficiary" :options="beneficiaryMasterDataList" :multiple="false"
                        :hideSelected="false" :close-on-select="true" :clear-on-select="false" :preserve-search="true"
                        :select-label="'Search Individual'" placeholder="Select Individual" label="name"
                        track-by="name" :preselect-first="false" data-vv-as="Beneficiary" v-validate="'required'"
                        :searchable="true" @search-change="getbeneficiaryMasterDataList" name="beneficiary"
                        @input="upDateBenef" tag-placeholder="Add New Individual" :taggable="false"
                        @tag="addNewBenFromTag"
                        :disabled="(!checkProperty(selectedPetitioner ,'_id') && [50 ].indexOf(getUserRoleId)<=-1 )">

                        <template slot="selection" slot-scope="{ values, isOpen }">
                          <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                            options selected</span>
                          <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                        </template>
                      </multiselect>
                    </div>
                  <p class="createnew"
                    @click="AddBeneficiary =true;selectedBeneficiary=null">Not found? <span>Invite Individual</span>
                  </p>
                    <span class="text-danger text-sm" v-show="errors.has('newpetitionform.beneficiary')">{{
                      errors.first("newpetitionform.beneficiary") }}</span>

                  </div>
                  <div class="form_group" v-if="subcasevalue!='I-485 Application'">
                    <div class="con-select w-full select-large">
                      <label class="form_label" >Select Beneficiary<em>*</em></label>
                      <multiselect v-model="selectedBeneficiary" :options="beneficiaryMasterDataList" :multiple="false"
                        :hideSelected="false" :close-on-select="true" :clear-on-select="false" :preserve-search="true"
                        :select-label="'Search Beneficiary'" placeholder="Select Beneficiary" label="name"
                        track-by="name" :preselect-first="false" data-vv-as="Beneficiary" v-validate="'required'"
                        :searchable="true" @search-change="getbeneficiaryMasterDataList" name="beneficiary"
                        @input="upDateBenef" tag-placeholder="Add New Beneficiary" :taggable="false"
                        @tag="addNewBenFromTag"
                        :disabled="(!checkProperty(selectedPetitioner ,'_id') && [50 ].indexOf(getUserRoleId)<=-1 )">

                        <template slot="selection" slot-scope="{ values, isOpen }">
                          <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                            options selected</span>
                          <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                        </template>
                      </multiselect>
                    </div>

                    <span class="text-danger text-sm" v-show="errors.has('newpetitionform.beneficiary')">{{
                      errors.first("newpetitionform.beneficiary") }}</span>

                  </div>
                  <p v-if="selectedPetitioner && checkBeneficaryInvitePermisions" class="createnew"
                    @click="AddBeneficiary =true;selectedBeneficiary=null">Not found? <span>Invite Beneficiary</span>
                  </p>
                </div>
              </template>
              <template v-else-if=" getTenantTypeId ==2">

                <div class="vx-col w-1/2">
                  <div class="form_group">
                    <div class="con-select w-full select-large">
                      <label class="form_label" v-if="subcasevalue!='I-485 Application'">Select Beneficiary<em>*</em></label>
                      <multiselect v-model="selectedBeneficiary" :options="beneficiaryMasterDataList" :multiple="false"
                        :hideSelected="false" :close-on-select="true" :clear-on-select="false" :preserve-search="true"
                        :select-label="'Search Beneficiary'" placeholder="Select Beneficiary" label="name"
                        track-by="name" :preselect-first="false" data-vv-as="Beneficiary" v-validate="'required'"
                        :searchable="true" @search-change="getbeneficiaryMasterDataList" name="beneficiary"
                        @input="upDateBenef" tag-placeholder="Add New Beneficiary" :taggable="false"
                        @tag="addNewBenFromTag">

                        <template slot="selection" slot-scope="{ values, isOpen }">
                          <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                            options selected</span>
                          <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                        </template>
                      </multiselect>
                    </div>

                    <span class="text-danger text-sm" v-show="errors.has('newpetitionform.beneficiary')">{{
                      errors.first("newpetitionform.beneficiary") }}</span>

                  </div>
                  <p class="createnew">Not found?<span @click="AddBeneficiary =true;selectedBeneficiary=null">Invite
                      Beneficiary</span> </p>
                </div>


              </template>
            </template>
          </div>


          <div class="text-danger text-sm formerrors" v-show="formerrors.msg">
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
              icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
          </div>
        </div>

        <div class="popup-footer">
          <vs-button color="dark" @click="NewPetition=false ;formerrors.msg=''" class="cancel" type="filled">Cancel
          </vs-button>
          <vs-button color="success" :disabled="!selectedBranch || newPetitionFormSubmited" @click="createNewPetition"
            class="save" type="filled">Submit</vs-button>
        </div>
      </form>



    </vs-popup>
    <!-----archiveAction(false)-->
    <modal name="conformArchivemodal" classes="v-modal-sec" :min-width="200" :min-height="200" :scrollable="true"
      :reset="true" width="450px" height="auto">
      <div class="v-modal">
        <div class="popup-header fromDetailsPage">
          <h2 class="popup-title">
            Delete

          </h2>
          <span @click="$modal.hide('conformArchivemodal');">
            <em class="material-icons">close</em>
          </span>
        </div>

        <div class="form-container">

          <div class="vx-row">
            <div class="vx-col w-full">
              <p class="msg_text">Are you sure to continue?</p>

            </div>

          </div>

          <div v-show="formerrors.msg">
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
              icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
          </div>

        </div>
        <div class="popup-footer relative">
          <figure v-if="archiving" class="loader"><img src="@/assets/images/main/loader.gif" /></figure>
          <vs-button color="dark" class="cancel" type="filled" @click="$modal.hide('conformArchivemodal');">No
          </vs-button>
          <vs-button :disabled="archiving" color="success" class="save" type="filled" @click="archiveAction()">Yes
          </vs-button>
        </div>

      </div>
    </modal>


  </div>
</template>

<script>
import DateRangePicker from "vue2-daterange-picker";
import Paginate from "vuejs-paginate";
import Datepicker from "vuejs-datepicker-inv";
import Multiselect from "vue-multiselect-inv";
import JQuery from "jquery";
import NoDataFound from "@/views/common/noData.vue";

import "vue2-daterange-picker/dist/vue2-daterange-picker.css";
import addBeneficiary  from "@/views/common/addBeneficiary.vue" 
import addBenewPet  from "@/views/common/invitePet.vue" 
import moment from 'moment'
export default {
  props: {
    beneficiaryId:null,
    beneficiaryInfo:null,
    petitionerDetails:null,
    isRfe:{
      type: 'boolean', default:false
    }
  },
  components: {
    addBeneficiary,
    addBenewPet,
    Datepicker,
    DateRangePicker,
    Multiselect,
    Paginate,
    NoDataFound
  },
  data: () => ({
    premiumProcessingList:[{name:'Enabled' ,_id:true },{name:'Disabled' ,_id:false }],
    selectedpremiumProcessing:[],
    premiumProcessing:false,
    newPetitionFormSubmited:false,
     formerrors: {
      msg: ""
    },
    selectedBranch:null,
    NewPetition:false,
    petitionersList:[],
    invitepetitioner:false,
    AddBeneficiary:false,
    selectedPetitioner:null,
    saveBenbtn:false,
    selectedUser:'',
    selectedUsername:'',
    beneficiaryMasterDataList:[],
    visatypes:[],
    visatype:null,
    visasubtypes:[],
    visasubtype:null,
    selectedBeneficiary:null,
     



    branchList:[],
    selectedBranches:[],
   isListloading:false,
    callFromSerch:false,
    sortKeys:{},
    sortKey:{},
    buttoncol: true,
    ChangePetition: false,
    casevalue:null,
    subcasevalue:null,
    formerrors: {
      msg: ""
    },
    searchtxt: "",
    query: [],
    selected: [],
    petitioners: [],
    currentuserRole: null,
    selecteduser: {
      petitionId: null,
      userName: null,
      email: null,
      typeName: null,
      subTypeName: null,
      instructions: null
    },
    SendQuestionnaire: false,
    SuccessQuestionnaire: false,
    selected_createdDateRange: ["", ""],
    selected_deadLineDateRange: ["", ""],
    autoApply: "",
    countries: [],
    country_code: 0,
    selected_country_obj: "",
    selected_statusids: [],
    final_selected_statusids: [],
    all_states: [],
    seleted_states: [],
    final_selected_states: [],
    singel_final_selected_state: "",
    all_locations: [],
    seleted_locations: [],
    final_selected_locations: [],
    all_statusids: [],
    selected_statusids: [],
    final_selected_statusids: [],
    page: 1,
    perpage: 25,
    totalpages: 0,

    filter_searchtxt: "",
    visaTypes:[],
    casetypeoptions: ["GC Employment"],
    casesubtypeoptions: ["PERM Certification", "I-140 Petition", "I-485 Application"],
    selectedVisaType:null,
    all_subtypes: [],
    selected_subtypes: [],
    final_selected_subtypes: [],

    final_filter_roleIds: [3, 4, 5, 9, 10],
    rolebased_filter: {
      3: { name: "supervisorIds", values: [] },
      4: { name: "paralegalIds", values: [] },
      5: { name: "attorneyIds", values: [] },
      9: { name: "offshoreUserIds", values: [] },
      10: { name: "evidenceSupervisorIds", values: [] }
    },
    users: [],
    selected_users: [],
    final_selected_users: [],
    user_search_value: "",
    roleId: 0,

    all_peritioners: [],
    peritioners_search_value: "",
    selected_peritioners: [],
    final_selected_peritioners: [],

  isListLoading:false,
    sortKeys:{},
    sortKey:{},
    perPeges: [10,25,50,75,100], // [  {name:10 ,perPage:10} , {name:25 ,perPage:25} ,{name:50 ,perPage:50},{name:100 ,perPage:100}],
    selectedForArchiveList:[],
    archiving:false,
    selectedarchive:[],
    selectedAllForArchive:false,
    encodedString:'',
   
  }),
  watch: {
    searchtxt: function(value) {
      let text = value.trim();

      if(text.length>3 || text==''){
         this.getpetitions(true ,false);
      }
     
    },
     '$route.query.filter':function (val) {

        if(this.checkProperty(this.$route ,'query' ,'filter')){
                try{
                  let filter =this.$route['query']['filter']; this.checkProperty(this.$route ,'query' ,'filter')
                  var actual = JSON.parse(atob(filter));
                  let keys = Object.keys(actual);
                  if(this.checkProperty(keys ,'length') >0){


                    if(actual && (Object.keys(actual)).length>0 ){
                    _.forEach(actual ,(item ,key) => {
                        if(key=='matcher' ){
                          
                          if((Object.keys(item)).length>0 ){

                            if(_.has(item ,'typeIds') && this.checkProperty(item , 'typeIds' ,'length')>0 ){
                               
                              this.selectedVisaType = _.find(this.visaTypes ,{"id":item['typeIds'][0]})
                           
                             this.getvisa_subtypes();
                           
                            }

                            
                            
                          }
                        
                        }
                      
                        
                    
                    })
                  }
                    
                    
                  }

                }catch(e){
                  

                }
                  
              }
        
          this.getpetitions(true);
      }
  },
  methods: {
    selectAllforArchive(){
              this.formerrors.msg ='';
          this.selectedForArchiveList =[];
        _.forEach(this.petitioners ,(item)=>{
          item.selectedForArchive =false;
          if(this.selectedAllForArchive && this.checkProperty(item ,'status')!=false){
             item.selectedForArchive =true;
             this.selectedForArchiveList.push(item._id)

          }
         
        })

      if(this.petitioners.length>0 && this.petitioners.length != this.selectedForArchiveList.length ){
        this.selectedAllForArchive =false;
      }
     
      

    },
    archiveAction(){
       this.formerrors.msg ='';
     let postData ={
       "petitionIds":[]
     };
     postData['petitionIds'] = this.selectedForArchiveList;
     this.archiving =true;
      this.$store
              .dispatch("commonAction", {"data":postData ,"path":"/petition/delete"})
              .then(response => {
               
                this.archiving =false;
                this.selectedForArchiveList =[];
                this.showToster({message:response.message,isError:false });
                this.$modal.hide('conformArchivemodal');
                this.getpetitions();
                                               
                                
              })
              .catch((error)=>{
                 this.formerrors.msg  =error
              //  this.showToster({message:error,isError:true });
                this.archiving =false;
              })

    },

    selectForArchive(caseItem){
       
             this.formerrors.msg ='';
        if(this.archiving ){
         return false
       }else{
         this.archiving =false
       if(this.checkProperty(caseItem ,'selectedForArchive') && this.checkProperty(caseItem ,'status') !=false){
         if(this.selectedForArchiveList.indexOf(caseItem['_id'])<=-1){
            this.selectedForArchiveList.push(caseItem['_id'])

         }

       }else{
          this.selectedForArchiveList = _.filter( this.selectedForArchiveList ,(item)=>{
           return item !=caseItem['_id']
          })
       }

    }
    this.selectedAllForArchive =false
    if(this.petitioners.length==this.selectedForArchiveList.length && this.selectedForArchiveList.length>0){
      this.selectedAllForArchive =true
    }
       

     },
    


    goTodetails(petition , stab ='Communication'){

      this.$store.dispatch("setPetitionTab" , stab)
      this.$router.push("/petition-details/"+petition['_id'])
    },  
    addNewBenFromTag(){

    },
     searchPet(searchText){
          let _self =this;
     
      
      this.selectedBeneficiary =null;
      this.selectedPetitioner =null;
      this.selectedUser ='';
      this.selectedUsername = '';
    
      let filteredData =[];
       _.forEach(_self.petitionersList ,(item)=>{
                if( item && ( _.has(item ,'name') || _.has(item ,'email')  )){

                         if((_.has(item ,'name') && item['name'].includes(searchText)) || (_.has(item ,'email') && item['email'].includes(searchText)) ){
                          filteredData.push(item)
                         }else{
                            return false;
                         }

                }else{
                  return false;
                }
              
           
         })
       if( (filteredData.length<=0 )){

         this.getPetitioners( true , searchText);
       }
         
     },
    addNewPet(newPet='' ,id){
       this.newPetOpenFromben =false;
       this.openNewbenForm =false;
       this.addNewPete =true;
       this.invitePetitionPopupshow(true)
     },
    petitionerUpdated(){
      this.selectedBeneficiary = null;
      this.selectedUser ='';
      this.selectedUsername = '';
      this.getbeneficiaryMasterDataList();
    },

     getvisatypes(){
      this.$store.dispatch("getvisatypes").then(response => {
        this.visatypes = response;
      });
    },
    getvisasubtypes(vsType){
      
     Object.assign(this.formerrors , {msg:''});
    
    if(this.visatype && _.has(this.visatype ,"id")){
       this.visasubtypes =[];
      this.visasubtype = null;
     
    
        let item ={
          matcher:{
             // "searchString":this.searchtxt,
             "petitionType":parseInt(this.visatype['id'])

          },   
          page:this.page,
          perpage: this.perpage,
          category: "petition_sub_types",
          
        };

        this.$store.dispatch("getMasterData",item ).then(response => { this.visasubtypes = response.list;  });
        this.$validator.reset();
        }
    },

    createNewPetition(){
      Object.assign(this.formerrors, {
                  msg: ''
                })

            this.$validator.validateAll('newpetitionform').then(result => {
        if (result) {
          let self =this;
      var postdata ={
        type: this.visatype.id,
        userId:this.selectedUser,
        userName:this.selectedUsername,
        typeName:this.visatype.name,
        subType:this.visasubtype.id,
        subTypeName:this.visasubtype.name,
        petitionerId:null,
        premiumProcessing:this.premiumProcessing,
        branchId:'',
        today: moment().format('YYYY-MM-DD'),
      };
      if(this.getTenantTypeId !=2){
        if([50].indexOf(this.getUserRoleId) > -1){
           postdata['petitionerId'] = this.$store.state.user._id

        }else{
           postdata['petitionerId'] = this.checkProperty(this.selectedPetitioner ,"userId")
        }
       

      }

      if(this.checkProperty(this.beneficiaryInfo ,"name") && this.beneficiaryId){
        postdata['userId'] = this.beneficiaryId;
        postdata['userName'] =this.beneficiaryInfo['name']

  }
     
     
      if(this.selectedBranch && _.has(this.selectedBranch ,"_id")){
        postdata['branchId'] =this.selectedBranch['_id']
      }
      if(!this.newPetitionFormSubmited){
        this.newPetitionFormSubmited =true;
        this.$store.dispatch("petitioner/createnewpetition", postdata)
        .then(response => {
              this.premiumProcessing = false;
                 if (response.error) {
                Object.assign(this.formerrors, {
                  msg: response.error.message
                });
                this.newPetitionFormSubmited =false;
              } else {

                   let dt ={
                  petitionId: response._id,
                  userName: this.selectedUsername,
                  email: this.selectedUseremail,
                  typeName: this.visatype.name,
                  subTypeName: this.visasubtype.id,
                  instructions: null
                }
                      
                        this.NewPetition =false; 
                         this.newPetitionFormSubmited =false;
                         this.getpetitions();
                      //this.$vs.notify({title: "Success",text: response.message });

                        this.visatype = {
                        id: 1,
                        name: "H-1B"
                        }
                        this.getvisasubtypes(this.visatype);
                       this.showToster({message:response.message ,isError:false});
                       this.addNewCase(false);
                       setTimeout(()=>{
                         if(self.checkProperty(self.selectedBeneficiary ,"anonymousUser" )){
                             this.goto(response._id);
                         }else{
                            this.goto(response._id);
                          // this.clear_filter();

                         }
                          
                           
                       } ,10)

                      
                     
              }

        })
        .catch((error)=>{
          //this.showToster({message:error,isError:true});
          this.newPetitionFormSubmited =false;
         
          Object.assign(this.formerrors, {
                  msg: error
                });
        
        });

      }
      
      
 } });
    },
    addNewCase(action=true){
      this.NewPetition =action;
      
      let self =this;
      if(this.checkProperty(this.petitionerDetails ,'_id')){
        this.selectedPetitioner = this.petitionerDetails;
        this.selectedPetitioner =  Object.assign(this.selectedPetitioner ,{"userId":self.petitionerDetails['_id']})
      }
      if([50].indexOf(this.getUserRoleId) >-1){
       
        let userId =  this.checkProperty((this.getUserData ,'companyDetails' ,"_id"))
        let name =  this.checkProperty((this.getUserData ,'companyDetails',"name"))
        this.selectedPetitioner ={}
        this.selectedPetitioner  =  Object.assign(this.selectedPetitioner ,{"_id":userId})
        this.selectedPetitioner =  Object.assign(this.selectedPetitioner ,{"name":name})
         this.selectedBeneficiary =null;
          //this.getbeneficiaryMasterDataList();
         
      }
     
      
      this.$validator.reset();

    },
    openAddpetPopUp(){
     
      this.selectedPetitioner =null;
      this.invitepetitioner =true;
    },
    closenewPetPopup(selectedPetitioner=null){

   
       
      this.getPetitioners();
       this.selectedPetitioner =selectedPetitioner;
       this.invitePetitionPopupshow(false);
       this.openNewbenFormPopup(true);

    },
    upDateBenef(){
      if(this.checkProperty(this.selectedBeneficiary ,'name') && this.checkProperty(this.selectedBeneficiary ,'_id') ){
        this.selectedUser =this.checkProperty(this.selectedBeneficiary ,'_id');
        this.selectedUsername = this.checkProperty(this.selectedBeneficiary ,'name');
     }

    },
   closeAddBenPopUp(selectedBeneficiary=null){
     
      this.AddBeneficiary =false;
     this.selectedBeneficiary =selectedBeneficiary;
     if(this.checkProperty(this.selectedBeneficiary ,'name') && this.checkProperty(this.selectedBeneficiary ,'_id') ){
        this.selectedUser =this.checkProperty(this.selectedBeneficiary ,'_id');
        this.selectedUsername = this.checkProperty(this.selectedBeneficiary ,'name');
     }
  
     this.getbeneficiaryMasterDataList();
   },
   getPetitioners(callFromSerch=false,searchText='' ) {
      
       
        let _self =this;
        if(this.callFromSerch){
         
         // this.petitionersList =[];
        }
        let query ={
          "matcher":{
            "searchString": searchText,
            "statusIds": [],
            "countryIds": [],
            "stateIds": [],
            "locationIds": [],
            "createdDateRange": []
          },
        "sorting": { 	"path": "createdOn", 	"order": 1 	},
        "page": 1,
        "perpage": 100,
        getMasterData:true
	}
       
      
        this.$store
          .dispatch("getList",{data:query ,path:'/company/list'} )
          .then(response => {
            
            _self.petitionersList = response.list;

            let filteredData =  _.filter(_self.petitionersList ,(item)=>{
                if( item&& ( _.has(item ,'name') || _.has(item ,'email')  )){

                         if((_.has(item ,'name')&& item['name'].includes(searchText)) || (_.has(item ,'email') && item['email'].includes(searchText)) ){
                           return true;
                         }else{
                            return false;
                         }

                }else{
                  return false;
                }
              
           
         })
       
                   
            //alert(this.perpage);
          }).catch((err)=>{
            this.petitionersList =[];
           
          })
   },
   invitePetitionPopupshow(action =true){
     this.invitepetitioner=action;
      
      
     },
      openNewbenFormPopup(action =false){
       this.saveBenbtn =false;
       if(action==true){
         this.invitePetitionPopupshow(false);
       }
       if(action){
       
          
         if(this.checkProperty(this.selectedPetitioner ,'userId')){
         
           this.AddBeneficiary =true;
          
            try{
              setTimeout(()=>{
                this.$refs['add_ben'].setPetDetails(this.selectedPetitioner)

              } ,50)
            }catch(e){}
          }else{
           
             this.AddBeneficiary =false;
          }

       }else{
          this.AddBeneficiary =action;

       }
       
      
       
       this.$validator.reset();
     },
     getbeneficiaryMasterDataList(text=''){
      let postData = {
          "matcher": {
            "title": text,
            "statusList": [],
            "branchIds": [],
            "companyIds": [], // Required only for Tenant Admin and Branch Manager to list Beneficiaries
            "createdByIds": [],
            "createdDateRange": [],
            "roleIds": [51],
            "statusIds": [],
            "petitionTypeIds": [],
            "petitionSubTypeIds": [],
            "petitionCreatedDateRange": [],
            "petitionStatusIds": [],
            "getPetitionStats": true
          },
        "sorting": {
          "path": "createdOn", // invitedByName, updatedOn, name, email, phone, statusName, roleName
          "order": 1
        },
        "page": 1,
        "perpage": 1000000,
        "getMasterData": true,
        "getBeneficiaryList": true, // Required only for Tenant Admin and Branch Manager to list Beneficiaries
        "branchId": "", // Required when 'getMasterData' is true and roleIds are [4, 5, 6, 7, 8, 9, 10, 11]
        "companyId": "" // Required when 'getMasterData' is true and roleIds are [50, 51]
	};
 
  this.enableAddNewBenTag =false;
    if(this.checkProperty(this.selectedPetitioner ,"_id")){

      postData['companyId'] = this.selectedPetitioner['_id']

    }
     if([50,51].indexOf(this.getUserRoleId)>-1){

    postData['companyId'] = this.checkProperty(this.getUserData ,"companyDetails" ,"_id")
  }
       //this.beneficiaryMasterDataList =[];
       this.$store
        .dispatch("petitioner/getbeneficiaries", postData)
        .then(response => {
          this.beneficiaryMasterDataList = response.list;

          let filteredData =[];
       _.forEach(this.beneficiaryMasterDataList ,(item)=>{
                if( item && ( _.has(item ,'name') || _.has(item ,'email')  )){

                         if((_.has(item ,'name') && item['name'].includes(text)) || (_.has(item ,'email') && item['email'].includes(text)) ){
                          filteredData.push(item)
                         }else{
                            return false;
                         }

                }else{
                  return false;
                }
              
           
         })

         if(filteredData.length<=0){
           this.enableAddNewBenTag =true;
         }


          })

    },
      //////////////////////////////////////////


    goto(Id){
      let routeTest = this.$route.params.itemId
          this.$router.push({ name: 'petition-details', params: { itemId:Id } ,query: {'filter':encodedString} }).catch(err => {})
    },
    petitionlink(tr) {
      let routedId = tr._id;
      const $ = JQuery;

      if (
        $(event.target)
          .parents()
          .hasClass("buttoncol") ||
        $(event.target).hasClass("buttoncol")
      ) {
      } else {
       
        this.$router.push({ path: `/petition-details/${routedId}` ,query: {'filter':this.encodedString} }).catch(err => {})
      }
    },
    pageNate(pageNum) {
     
      this.page = pageNum;
      this.getpetitions();
    },
    SendQuestionnaireUser() {
      this.$store
        .dispatch("petitioner/sendquestionnaire", this.selecteduser)
        .then(response => {
          if (response.error) {
            Object.assign(this.formerrors, {
              msg: response.error.message
            });
          } else {
            this.$vs.notify({
              title: "Success",
              position: "top-right",
              color: "primary",              
              text: response.message
            });
            this.SendQuestionnaire = false;
            this.SuccessQuestionnaire = true;
            var timer = this.$router;
            setTimeout(function() {
              timer.go("/cases");
            }, 1000);
          }

          // this.petitioners = response.list;
        });
    },
    setuser(petition) {
      this.selecteduser.petitionId = petition._id;
      this.selecteduser.userName = petition.beneficiaryDetails.name;
      this.selecteduser.email = petition.beneficiaryDetails.email;
      this.selecteduser.typeName =
        petition.typeDetails.name + "/" + petition.subTypeDetails.name;
      this.selecteduser.subTypeName = petition.subTypeDetails.name;
    },
    selectCreatedDateRange(option) {
      option.startDate = moment(option.startDate).format("YYYY-MM-DD");
      option.endDate = moment(option.endDate).format("YYYY-MM-DD");
      this.selected_createdDateRange = [option.startDate, option.endDate];
    },
    set_filter: function() {
      this.$router.push({ query: {} });
      this.final_selected_statusids = [];

      if (this.selected_statusids.length > 0) {
        this.final_selected_statusids = [];
        for (let ind = 0; ind < this.selected_statusids.length; ind++) {
          let current_index = this.selected_statusids[ind];
          this.final_selected_statusids.push(current_index["id"]);
        }
      }

      /*//states
        this.final_selected_states= [];
        if( this.seleted_states.length >0 ){
          this.final_selected_states = [];
          for(let ind =0;ind < this.seleted_states.length ; ind++ ){
            let current_index =  this.seleted_states[ind];
            this.final_selected_states.push(current_index["id"]);
          }
        }*/

      //alert(this.singel_final_selected_state);

      this.final_selected_locations = [];
      if (this.seleted_locations.length > 0) {
        for (let ind = 0; ind < this.seleted_locations.length; ind++) {
          let current_index = this.seleted_locations[ind];
          this.final_selected_locations.push(current_index["id"]);
        }
      }

      this.searchtxt = this.filter_searchtxt;

      this.getpetitions(false ,false);
      this.$refs["filter_menu"].dropdownVisible = false;
    },
    clear_filter: function() {
      this.selectedarchive =[];
      this.selected_deadLineDateRange =  ["", ""];
      this.selectedpremiumProcessing = [];
      this.peritioners_search_value ='';
      this.searchtxt = "";
      this.selected_statusids = [];

      this.selected_country_obj = "";
      this.seleted_states = [];
      this.final_selected_states = [];
      this.singel_final_selected_state = "";

      this.seleted_locations = [];
      this.final_selected_locations = [];
      this.final_selected_statusids = [];

      this.date = "";
      this.date_range = [];
      this.selected_createdDateRange["startDate"] = "";
      this.selected_createdDateRange["endDate"] = "";


      
      this.selectedVisaType =null;
      this.filter_searchtxt = "";
      this.selected_subtypes = [];
      this.final_selected_subtypes = [];

      (this.rolebased_filter = {
        3: { name: "supervisorIds", values: [] },
        4: { name: "paralegalIds", values: [] },
        5: { name: "attorneyIds", values: [] },
        9: { name: "offshoreUserIds", values: [] },
        10: { name: "evidenceSupervisorIds", values: [] }
      }),
        (this.final_selected_peritioners = []);
      this.selected_peritioners = [];
      //this.getPetitioners();
      this.$refs["filter_menu"].dropdownVisible = false;
      this.selected_users =[];
      this.selectedBranches =[];
     
       this.getpetitions(false ,false);
       this.$router.push({ query: {} })
    },
    get_all_states() {
      this.$store.dispatch("getstates", this.country_code).then(response => {
        this.all_states = response;
      });
    },
    getAllLocations() {
      Object.assign(this.query, {
        countryId: this.country_code,
        stateId: this.singel_final_selected_state //this.final_selected_states//3922
      });

      this.$store.dispatch("getlocations", this.query).then(response => {
        this.all_locations = response;
      });
    },
    get_statusids() {
      Object.assign(this.query, {
        category: "company_statuses"
      });

      this.$store
        .dispatch("get_petition_statusids", this.query)
        .then(response => {
          this.all_statusids = response;
          if (this.checkProperty(this.$router.currentRoute ,"query"  ,"status") ){
         
          let status = this.checkProperty(this.$router.currentRoute ,"query"  ,"status");
          let selectedStatus = _.find(this.all_statusids ,{"id":parseInt(status)});
          
          if(selectedStatus){
            this.selected_statusids =[selectedStatus];
            this.final_selected_statusids =[parseInt(status)];

          }
          
        
        }
        });
    },
    setQueryString(obj){
      const string = JSON.stringify(obj) // convert Object to a String
      this.encodedString = btoa(string) // Base64 encode the String
    
     // var actual = JSON.parse(atob(encodedString))
    },
    getpetitions(callFromSerch=false , applyUrlFilter=false) {
       this.selectedAllForArchive =false;
       this.selectedForArchiveList =[]; 
      this.callFromSerch = callFromSerch;
      let self =this;
      if(this.callFromSerch){
         
          this.petitioners  =[];
        }
      let obj = {
        matcher: {
          rfeCases:self.isRfe,
          searchString: self.searchtxt,
          statusIds: self.final_selected_statusids,
          beneficiaryIds:[],
          premiumProcessing:self.selectedpremiumProcessing.map((item)=> item._id),
          //"countryIds": [this.country_code],
          stateIds: [], //this.final_selected_statusids,
          locationIds: self.final_selected_locations,
          //"createdDateRange":this.selected_createdDateRange,
          petitionerIds:self.final_selected_peritioners,
          branchIds:[],
          typeIds:[],
          subTypeIds:[],
          deadlineDateRange:[],
          "getMissingDeadlines": false,
          statusList:[]
        },
        page: self.page,
        perpage: self.perpage,
        sorting:self.sortKey
      };

      if(self.selectedBranches.length>0){
        //obj['matcher']['branchIds'] = this.selectedBranches.map((item)=> item._id )
      }

     if(this.selectedarchive.length>0){

               obj["matcher"]["statusList"] = this.selectedarchive.map((item)=>item._id);

     }
  

      //
      if (this.singel_final_selected_state > 0) {
        obj["matcher"]["stateIds"] = [this.singel_final_selected_state];
      }

      if (
        this.selected_createdDateRange["startDate"] &&
        this.selected_createdDateRange["startDate"] != "" &&
        this.selected_createdDateRange["endDate"] != "" &&
        this.selected_createdDateRange["endDate"]
      ) {
        obj["matcher"]["createdDateRange"] = [
          this.selected_createdDateRange["startDate"],
          this.selected_createdDateRange["endDate"]
        ];
      }

      if (
        this.selected_deadLineDateRange["startDate"] &&
        this.selected_deadLineDateRange["startDate"] != "" &&
        this.selected_deadLineDateRange["endDate"] != "" &&
        this.selected_deadLineDateRange["endDate"]
      ) {
          obj["matcher"]["getMissingDeadlines"] = false;
          obj["matcher"]["deadlineDateRange"] = [
          this.selected_deadLineDateRange["startDate"],
          this.selected_deadLineDateRange["endDate"]
        ];
      }

      //selected_deadLineDateRange

      obj["matcher"]["countryIds"] = [];
      if (
        this.selected_country_obj["id"] &&
        this.selected_country_obj["id"] > 0
      ) {
        obj["matcher"]["countryIds"] = [this.selected_country_obj["id"]];
      }
      //
      if(this.selectedVisaType && _.has(this.selectedVisaType , 'id' )){
        
         obj["matcher"]["typeIds"] = [this.selectedVisaType['id']];
          obj["matcher"]["subTypeIds"] = this.final_selected_subtypes;

      }

      if(this.beneficiaryId !=null){
        obj["matcher"]['beneficiaryIds'] =[];
        obj["matcher"]['beneficiaryIds'].push(this.beneficiaryId)
      }

      //final_selected_subtypes
     

      //rolebased_filter

      if(this.checkProperty(this.$route ,'query' ,'filter') && applyUrlFilter){
        try{
           let filter =this.$route['query']['filter']; this.checkProperty(this.$route ,'query' ,'filter')
          let filterObj = JSON.parse(atob(filter));
          let keys = Object.keys(filterObj);
           if(filterObj && (Object.keys(filterObj)).length>0 ){
            _.forEach(filterObj ,(item ,key) => {
                if(key=='matcher' ){
                  if((Object.keys(item)).length>0 ){
                   
                    obj['matcher'] = item
                  }
                
                }
                
                if(key =='page' && item >0){
                  obj['page'] = parseInt(item)
                  this.page = parseInt(item)
                }
                if(key =='perpage' && item >0){
                  obj['perpage'] = parseInt(item)
                  
                  this.perpage = parseInt(item)
                }
                if(key=='sorting' ){
                  if((Object.keys(item)).length>0 ){
                    obj['sorting'] = item
                  }
                
                }
            })
          }

        }catch(e){
          //alert(e)

        }
        
          
      }
     
   
      this.setQueryString(obj)

      this.isListloading = true;
      this.updateLoading(true);
      this.$store.dispatch("petitioner/getpetitions", obj).then(response => {
         this.isListloading = false;
        this.updateLoading(false);
        
         let tempList =[];
         let list = response.list
         _.forEach( list,(item) => {
            item =Object.assign(item,{ 'selectedForArchive':false});
           if(this.selectedForArchiveList.indexOf(item['_id'])>-1){
              item =Object.assign(item,{ 'selectedForArchive':true});
           }
           tempList.push(item)
           
         });
          this.petitioners = list;




       
        this.totalpages = Math.ceil(response.totalCount / this.perpage);
       
         //alert(this.totalpages);
      }) .catch((err) => {
          
           this.isListLoading =false;
            this.updateLoading(false);
             this.petitioners = [];
            
        });
    },

    changedCountry() {
      this.country_code = this.selected_country_obj["id"];
      this.get_all_states();
    },

    changedState() {
      this.singel_final_selected_state = "";
      this.final_selected_locations = [];
      this.singel_final_selected_state = this.seleted_states["id"];
      this.final_selected_states.push(this.seleted_states["id"]);
      this.getAllLocations();
    },
    multiple_changedState() {
      // alert();
      if (this.seleted_states.length > 0) {
        this.final_selected_states = [];
        for (let ind = 0; ind < this.seleted_states.length; ind++) {
          let current_index = this.seleted_states[ind];
          this.final_selected_states.push(current_index["id"]);
        }
        this.getAllLocations();
      } else {
        this.final_selected_states = [];
        this.final_selected_locations = [];
      }
    },
   getVisaTypes(){
     let item ={
          matcher:{
              "searchString":'',
              getWorkFlowConfig:true
             // "petitionType":

          },   
          page:this.page,
          perpage: this.perpage,
          category: "petition_types",
         "sorting": {
            "path": "name",
            "order": 1
            }
          
        };

        this.$store
          .dispatch("getMasterData",item )
          .then(response => {
            this.visaTypes = response.list;

             if(this.checkProperty(this.$route ,'query' ,'filter')){
                try{
                  let filter =this.$route['query']['filter']; this.checkProperty(this.$route ,'query' ,'filter')
                  var actual = JSON.parse(atob(filter));
                  let keys = Object.keys(actual);
                  if(this.checkProperty(keys ,'length') >0){


                    if(actual && (Object.keys(actual)).length>0 ){
                    _.forEach(actual ,(item ,key) => {
                        if(key=='matcher' ){
                          
                          if((Object.keys(item)).length>0 ){

                            if(_.has(item ,'typeIds') && this.checkProperty(item , 'typeIds' ,'length')>0 ){
                               
                              this.selectedVisaType = _.find(this.visaTypes ,{"id":item['typeIds'][0]})
                           
                             this.getvisa_subtypes();
                           
                            }

                            
                            
                          }
                        
                        }
                      
                        
                    
                    })
                  }
                    
                    
                  }

                }catch(e){
                  

                }
                  
              }


           
          });
   },
   changedVisaType(item){
    this.$router.push({ query: {} });
     this.selectedVisaType = item;
     this.all_subtypes = [];
     this.final_selected_subtypes = [];
     this.selected_subtypes =[];
     if(_.has(this.selectedVisaType , "id")){
       this.getvisa_subtypes();

     }
   },
    changedVisaTypeClear(item){
    this.set_filter();
    this.$router.push({ query: {} });
    this.changedVisaType(item);
   },
    getvisa_subtypes() {
      
      if(this.selectedVisaType && _.has(this.selectedVisaType ,"id")){
         
      
      let item = {
        matcher: {
          searchString: '',
          petitionType: parseInt(this.selectedVisaType['id']),
          getWorkFlowConfig: false,
        },
        page: 1,
        perpage: 1000,
        category: "petition_sub_types",
        "sorting": {
            "path": "name",
            "order": 1
            }
      };

      this.$store.dispatch("getMasterData", item).then((response) => {
        this.all_subtypes = response.list;

         if(this.checkProperty(this.$route ,'query' ,'filter')){
                try{
                  let filter =this.$route['query']['filter']; this.checkProperty(this.$route ,'query' ,'filter')
                  var actual = JSON.parse(atob(filter));
                  let keys = Object.keys(actual);
                  if(this.checkProperty(keys ,'length') >0){


                    if(actual && (Object.keys(actual)).length>0 ){
                    _.forEach(actual ,(item ,key) => {
                        if(key=='matcher' ){
                          
                          if((Object.keys(item)).length>0 ){

                            if(_.has(item ,'subTypeIds')){
                              
                          
                              this.selected_subtypes = _.filter(this.all_subtypes ,(status)=>{
                                  return item['subTypeIds'].indexOf(status['id'])>-1;

                            })

                            }

                            
                            
                          }
                        
                        }
                      
                        
                    
                    })
                  }
                    
                    
                  }

                }catch(e){
                  

                }
                  
              }
       
      });
      }
    },
    changedsubtypes() {
      this.final_selected_subtypes = [];
      if (this.selected_subtypes.length > 0) {
        for (let ind = 0; ind < this.selected_subtypes.length; ind++) {
          let current_index = this.selected_subtypes[ind];
          this.final_selected_subtypes.push(current_index["id"]);
        }
      }
    },
    getusers() {
      let matcher = {
        roleIds: this.final_filter_roleIds,
        searchString: this.user_search_value,
        page: 1
      };
      let query = {};
      query["page"] = 1;
      query["perpage"] = 100;
      query["matcher"] = matcher;

      this.$store.dispatch("getusers", query).then(response => {
        this.users = response.list;
      });
    },
    get_peritioners() {

     
           
     //petitioner_list_for_tenant_users

       let item ={
          page:1,
          perpage: 10000,
          category: "petitioner_list_for_tenant_users",
          matcher:{
            "searchString":this.peritioners_search_value,
          
          },
          "sorting": {
            "path": "name",
            "order": 1
            }
                      
        };
        if([51].indexOf(this.getUserRoleId)>-1){
          item['category'] = "petitioner_list_for_beneficaries"
        }

  
        this.$store.dispatch("getMasterData", item).then(response => {
         
          this.all_peritioners =response.list;
              if(this.checkProperty(this.$route ,'query' ,'filter')){
                try{
                  let filter =this.$route['query']['filter']; this.checkProperty(this.$route ,'query' ,'filter')
                  var actual = JSON.parse(atob(filter));
                  let keys = Object.keys(actual);
                  if(this.checkProperty(keys ,'length') >0){


                    if(actual && (Object.keys(actual)).length>0 ){
                    _.forEach(actual ,(item ,key) => {
                        if(key=='matcher' ){
                          
                          if((Object.keys(item)).length>0 ){

                            if(_.has(item ,'petitionerIds')){
                              
                              this.all_peritioners = _.filter(this.all_peritioners ,(status)=>{
                                  return item['petitionerIds'].indexOf(status['_id'])>-1;

                            })

                            }

                            
                            
                          }
                        
                        }
                      
                        
                    
                    })
                  }
                    
                    
                  }

                }catch(e){
                  

                }
                  
              }

          
        
        });
    },
    changedusers() {
      //rolebased_filter
      this.rolebased_filter = {
        3: { name: "supervisorIds", values: [] },
        4: { name: "paralegalIds", values: [] },
        5: { name: "attorneyIds", values: [] },
        9: { name: "offshoreUserIds", values: [] },
        10: { name: "evidenceSupervisorIds", values: [] }
      };
      if (this.selected_users.length > 0) {
        for (let i = 0; i < this.selected_users.length; i++) {
          let selected_user_item = this.selected_users[i];
          let roleId = selected_user_item["roleId"][0];
          this.rolebased_filter[roleId]["values"].push(
            selected_user_item["_id"]
          );
        }
      }
    },
    user_search(searchValue) {
      this.user_search_value = searchValue;
      this.getusers();
    },
     changedperitionerss() {
      this.$router.push({ query: {} })
      this.final_selected_peritioners = [];
      if (this.selected_peritioners.length > 0) {
        for (let i = 0; i < this.selected_peritioners.length; i++) {
          this.final_selected_peritioners.push(
            this.selected_peritioners[i]["_id"]
          );
        }
      }
      this.get_peritioners_beneficiaries();
      this.set_filter();
    },

    //
    changedperitioners() {
      this.$router.push({ query: {} })
      this.final_selected_peritioners = [];
      if (this.selected_peritioners.length > 0) {
        for (let i = 0; i < this.selected_peritioners.length; i++) {
          this.final_selected_peritioners.push(
            this.selected_peritioners[i]["_id"]
          );
        }
      }
      this.get_peritioners_beneficiaries();
    },

    peritioners_search_fun(searchValue) {
      this.peritioners_search_value = searchValue;
      this.get_peritioners();
    },
    get_peritioners_beneficiaries() {},
    sortMe(sort_key=''){

      //   this.sortKeys = {
      //   'caseNo':1,
      //   'beneficiaryDetails.name':1,
      //   "typeDetails.name":1,
      //   "petitionerDetails.name":1,
      //   "updatedOn":1,
      //   "communicationDetailslength":1

      // }

      if(sort_key !=''){
          this.sortKeys[sort_key] = this.sortKeys[sort_key]==1?-1:1
          this.sortKey ={};
          this.sortKey= {"path":sort_key,"order": this.sortKeys[sort_key] }

          localStorage.setItem('petitions_sort_key', sort_key);
          localStorage.setItem('petitions_sort_value', this.sortKey[sort_key]);
          this.getpetitions();
      }
          
      

    },
    changeperPage(){
     
      this.page = 1;
      localStorage.setItem('petitions_perpage', this.perpage);
      this.getpetitions(true);
     
      
    },
      getBranchList() {
         this.branchList =[];
      //  alert(JSON.stringify(this.searchtxt)) final_selected_statusids
         let item ={
          filters:{
              "title":'',
             "createdDateRange":[],
             "statusList":[], 
             "activeList": [],
             "countryIds":[],
             "stateIds":[],
             "locationIds":[]
           

          },
          getMasterData:true,   
          page:1,
          perpage: 1000,
          sorting:{"path":"createdOn" ,"order":-1},
         
        };

         
       
        this.$store
          .dispatch("getList",{"data":item ,"path":"/branch/list"} )
          .then(response => {
            
            this.branchList = response.list;
           if(this.branchList.length ==1){
             this.selectedBranch = this.branchList[0];
           }
          }).catch((error)=>{
               this.branchList =[];
          })
      }, 
  },

  mounted() {
    if(this.$route.params && this.$route.params.openCreatePopup ){
        this.selectedBeneficiary =null 
        this. selectedPetitioner=null
        this.addNewCase(true)
      }

    if (this.checkProperty(this.$router.currentRoute ,"query"  ,"status") ){
         
          let status = this.checkProperty(this.$router.currentRoute ,"query"  ,"status");
        
          
          if(status){
           
            this.final_selected_statusids =[parseInt(status)];

          }
          
        
        }
        if(this.checkProperty(this.$route ,'query' ,'page')>0){
            this.page = parseInt(this.checkProperty(this.$route ,'query' ,'page'))
        }
         if(this.checkProperty(this.$route ,'query' ,'search')){
            this.searchtxt =this.checkProperty(this.$route ,'query' ,'search')
        }
     this.visatype = {
        id: 1,
        name: "H-1B"
      }
       this.getvisasubtypes(this.visatype);
     this.getPetitioners();
    this.getvisatypes();
    this.username = this.$store.state.user.name;
    this.roleId = this.$store.state.user["roleId"][0];
//"path": "createdOn", updatedOn, createdByName, typeName, subTypeName, caseNo, statusName
    this.sortKeys = {
      'caseNo':1,
      'createdByName':1,
      "typeName":1,
      "subTypeName":1,
      "statusName":1,
      "createdOn":1,
      "updatedOn":-1,
      "clientName":1,
      "beneficiaryName":1
      
    },

   
     this.sortKey= {"path":'updatedOn',"order":-1};

    if(localStorage.getItem('petitions_sort_key') && localStorage.getItem('petitions_sort_value')  && localStorage.getItem('petitions_sort_value') >=-1 ){
       this.sortKey = {};

      this.sortKey = {"path":localStorage.getItem('petitions_sort_key') ,"order":parseInt(localStorage.getItem('petitions_sort_value'))};
      this.sortKeys[localStorage.getItem('petitions_sort_key')] = parseInt(localStorage.getItem('petitions_sort_value'));

      //alert();
    }
    if(localStorage.getItem('petitions_perpage')){
        this.perpage = parseInt(localStorage.getItem('petitions_perpage'));
    }

     this.getbeneficiaryMasterDataList();
    this.getVisaTypes();  
    this.getusers();
    this.get_peritioners();
    this.currentuserRole = this.$store.state.user.loginRoleId;

     

          this.getpetitions(false ,true);

      
   
    this.$store.dispatch("getcountries").then(response => {
      this.countries = response;
    });

    this.selected_statusids = [];
    this.final_selected_statusids = [];
    this.seleted_states = [];
    this.final_selected_states = [];

    this.seleted_locations = [];
    this.final_selected_locations = [];
    this.get_statusids();
    //if([3].indexOf(this.getUserRoleId) >-1){
      this.getBranchList();
  //  }

  if(this.checkProperty(this.beneficiaryInfo ,"name")){
  this.selectedUser = this.beneficiaryId;
  this.selectedUsername =this.beneficiaryInfo['name']

  }
  },
  computed:{
    checkEnableSelectAll(){
      let returnVal =false;
let activeItems = _.filter(this.petitioners ,(item)=>{
        return this.checkProperty( item ,'status') !=false
     });
     if(activeItems && this.checkProperty(activeItems ,'length')>0){
       returnVal =true;
     }
      return returnVal;
    }
  }
};
</script>
