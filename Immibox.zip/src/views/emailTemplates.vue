<template>
  <div class="settings_right">
    <div class="content-header">
      <div class="content-header-left">
        <div class="search">
          <vs-input icon-pack="feather" icon="icon-search" v-model="searchtxt" placeholder="Search by Name"
            class="is-label-placeholder" />
        </div>
      </div>
      <div class="content-header-right">
        <!--filter dropdown-->
        <vs-dropdown  vs-custom-content vs-trigger-click>
          <vs-button
            color="primary"
            class="filter-btn"
            type="border"
            icon-pack="feather"
            icon="icon-chevron-down"
            icon-after
          >
            <img src="@/assets/images/main/icon-filter.svg" /> Filters
          </vs-button>
          <vs-dropdown-menu ref="filter_menu" class="filters-content settings_filters">

            <div class="filters-form-fileds">
              <div class="form-container">
                <div class="vx-row">
                 
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Select Types</label>
                   
                    <multiselect v-model="selected_typeids" :options="templateTypes" :multiple="true" :hideSelected="true"
                      :close-on-select="false" :clear-on-select="false" :select-label="''" :preserve-search="true"
                      placeholder="Select Types" :preselect-first="false">
                      
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} options selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template> 
                    </multiselect>
                  </div>
                  

                                  
                  <div class="vx-col md:w-1/3 w-full con-select d-none">
                    <label class="typo__label">Select Status</label>
                    
                    <multiselect v-model="selected_statusids" :options="[{'name':'Case' ,'id':'Case'}]" :multiple="true" :hideSelected="true"
                      :close-on-select="false" :clear-on-select="false" :select-label="''" :preserve-search="true"
                      placeholder="Select Status" label="name" track-by="name" :preselect-first="false">
                      
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} options selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template> 
                    </multiselect>
                  </div>

                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Created Date</label>
                    <date-range-picker
                       :maxDate="new Date()"
                      :autoApply="autoApply"
                      :ranges="false"
                      v-model="selected_createdDateRange"
                    ></date-range-picker>
                  </div>
                 </div>
                   
                   
     
              </div>
            </div>
            <div class="filters-status">
              <div class="left-buttons">

              </div>
              <div class="right-buttons">
                <vs-button color="success" class="save" type="filled" v-on:click="set_filter()">Apply</vs-button>
                <vs-button color="dark" class="cancel" type="filled" v-on:click="clear_filter($event)">Clear
                </vs-button>
              </div>
            </div>
          </vs-dropdown-menu>
        </vs-dropdown>
        <!-- end -->
        
       <!---
        <vs-button type="border" class="light-blue-btn" @click="createNew(true)">Send Email<span>
          <img class="add-user-icon ml-2" src="@/assets/images/main/add-user.svg">
        </span>
        </vs-button>
        -->
        <vs-button type="border" class="light-blue-btn" @click="openNewTemplatePopUp(true)">New Email Template<span>
          <img class="add-user-icon ml-2" src="@/assets/images/main/add-user.svg">
        </span>
        </vs-button>

        
      </div>
    </div>
    <NoDataFound ref="NoDataFoundRef"  v-if="list.length == 0 && !callFromSerch" content="You haven't  send any Emails yet. Send emails to start using the ImmiBox" heading="No Emails" type='Email' />
    <NoDataFound ref="NoDataFoundRef"  v-if="list.length == 0 && callFromSerch" content="" heading="No Results Found" type='Email' />

    <div class="accordian-table" v-if="list.length > 0">
      <vs-table :data="list" :no-data-text="'No data found..!'">
        <template slot="thead" v-if="list.length>0">
          <vs-th>
          <a @click="sortMe('name')"  v-bind:class="{'sort_ascending':sortKeys['name']==1, 'sort_descending':sortKeys['name']!=1}" >
             Name
              </a>
          </vs-th>
          

          <vs-th>
           <a @click="sortMe('subject')"  v-bind:class="{'sort_ascending':sortKeys['subject']==1, 'sort_descending':sortKeys['subject']!=1}" >
             Subject
              </a>
          </vs-th>
          <vs-th> Content</vs-th>

         
         <vs-th>
           <a @click="sortMe('type')"  v-bind:class="{'sort_ascending':sortKeys['type']==1, 'sort_descending':sortKeys['type']!=1}" >
             Type
              </a>
          </vs-th>
          
         
        
          <vs-th>

             <a @click="sortMe('createdOn')"  v-bind:class="{'sort_ascending':sortKeys['createdOn']==1, 'sort_descending':sortKeys['createdOn']!=1}" >
             Created On
              </a>
          
          </vs-th>

           <vs-th>

          <a @click="sortMe('updatedOn')"  v-bind:class="{'sort_ascending':sortKeys['updatedOn']==1, 'sort_descending':sortKeys['updatedOn']!=1}" >
             Updated On
              </a>
          
          </vs-th>
          <!-- <vs-th>Status</vs-th> -->
         
          <vs-th class="actions">Actions</vs-th>

        </template>

        <template slot-scope="{data}">
          <vs-tr  :data="tr" :key="indextr" v-for="(tr, indextr) in data">
            <vs-td :data="tr.username" class="td_label">
                        
              {{tr.name }}
              
            </vs-td>
             <vs-td>  {{ checkProperty( tr,'subject') |taskDescription }}  </vs-td>
              <vs-td>  
              
               <div @click="selectedItem=tr;$modal.show('templateDetailsModal')" style="cursor:pointer" class="view-icon-gradiant">
              <template v-if="tr.body.length<=30" >
                  <span v-html="checkProperty( tr,'body')"></span>
              </template>
              <template v-else>

                <span v-html="removeTags( tr['body'])"></span>
                   <img  src="@/assets/images/icons/view.png" />
              </template> 
              
               
             </div>
               </vs-td>
             <vs-td>  {{ checkProperty( tr,'type')}}  </vs-td>
              
            
            <vs-td>
             {{tr.createdOn | formatDateTime}}
            </vs-td>
            
            <vs-td>
             {{tr.updatedOn | formatDateTime}}
            </vs-td>
            <!-- <vs-td> 
              
                <span class="statusspan " :class="{'status_pending':tr.statusId==1,'status_active':tr.statusId==2,'status_rejected':tr.statusId==3,'status_rejected':tr.statusId==4}" >
                {{checkProperty(tr ,"statusDetails" ,'name')}}
                </span> 
               </vs-td> -->

           
           <vs-td > 
           
            <vs-dropdown class="msg_dropdown_icon" :vs-trigger-click="true"  >
                  <a class="a-icon" href.prevent><more-vertical-icon size="1.5x" class="custom-class"></more-vertical-icon></a>
                 
                   
                  <vs-dropdown-menu>
                  
                   <vs-dropdown-item >
                      <a ><p style="cursor:pionter" @click="selectedItem=tr;$modal.show('templateDetailsModal')" > Show Details</p></a>
                   </vs-dropdown-item>
                   <vs-dropdown-item >
                      <a ><p style="cursor:pionter" @click="selectedItem=tr;deleteMe(tr)" > Delete</p></a>
                   </vs-dropdown-item>
                    
                   
                     <vs-dropdown-item >
                      <a ><p style="cursor:pionter" @click="selectedItem=tr;editMe(tr)" >Edit</p></a>
                   </vs-dropdown-item>
                   
                  
                   </vs-dropdown-menu>
                   
                  
                </vs-dropdown>
             </vs-td>

            


          </vs-tr>
        </template>
      </vs-table>
      <paginate  v-if="list.length>0"  v-model="page" :page-count="totalpages" :page-range="3" :margin-pages="2" :click-handler="pageNate"
        prev-class="vs-pagination--buttons btn-prev-pagination vs-pagination--button-prev"
        next-class="vs-pagination--buttons btn-next-pagination vs-pagination--button-next" :prev-text="'<i></i>'"
        :next-text="'<i></i>'" :container-class="'pagination vs-pagination--nav'" :page-class="'page-item'"></paginate>
    </div>


        
        <!-----newTemplateModal-->
         <modal
      name="newTemplateModal"
      classes="v-modal-sec"
      :min-width="200"
      :min-height="200"
      :scrollable="true"
      :reset="true"
      width="600px"
      height="auto"
    >
     <div class="v-modal" >
        <div class="popup-header fromDetailsPage">
          <h2 class="popup-title">
            <template v-if="edit">Edit Email Template</template>
             <template v-else>New Email Template</template>
          </h2>
          <span @click="openNewTemplatePopUp(false)">
            <em class="material-icons">close</em>
          </span>
        </div>
         <form @submit.prevent data-vv-scope="templateForm" >
        <div class="form-container pb-2">
          <div class="vx-row">
          <template >
            <div class="vx-col  w-1/2">
              <div class="form_group  d-block">
                <label class="form_label">Name<em>*</em></label>
                <vs-input @keyup="formerrors.msg=''" v-model="newTemplate.name" name="name" v-validate="'required'" class="w-full"
                   data-vv-as="Name"    />
                <span class="text-danger text-sm"
                  v-show="errors.has('templateForm.name')">{{ errors.first("templateForm.name") }}</span>
              </div>
            </div>

             



            


                  <div class="vx-col w-1/2">
               <div class="form_group  d-block">      
                 <div class="con-select w-full"> 
                    <label for class="form_label">Template Type<em>*</em></label>
                  
                    <multiselect v-model="newTemplate.type" 
                    :options="templateTypes" 
                    :multiple="false" 
                    :hideSelected="true"
                    @input="getAllTags()"
                     v-validate="'required'"
                    data-vv-as="Template Type" 
                      :close-on-select="true" 
                      :clear-on-select="false"
                       :select-label="''" 
                       :preserve-search="true"
                       name="tplType"
                      placeholder="Select Template Type"  
                      :preselect-first="false">
                      
                       <template slot="selection" slot-scope="{ values, isOpen }">
                                                    <span
                                                    class="multiselect__selectcustom"
                                                    v-if="values.length && !isOpen"
                                                    >{{ values.length }} Type(s) selected</span
                                                    >
                                                    <span
                                                    class="multiselect__selectcustom"
                                                    v-if="values.length && isOpen"
                                                    ></span>
                                                </template>
                    </multiselect>
                    <span class="text-danger text-sm" v-show="errors.has('templateForm.tplType')">{{ errors.first("templateForm.tplType") }}</span>
                 </div>
                 </div>
              </div>

              <div class="vx-col   w-full">
              <div class="form_group  d-block">
                <label class="form_label"> Subject<em>*</em></label>
                <vs-input @keyup="formerrors.msg=''" 
                  
                v-model="newTemplate.subject" name="subject" v-validate="'required'" class="w-full"
                   data-vv-as="Subject"    />
                <span class="text-danger text-sm"
                  v-show="errors.has('templateForm.subject')">{{ errors.first("templateForm.subject") }}</span>
              </div>
            </div>

             

            

            
              
            </template>

            

            
            <div class="vx-col w-full">
              <div class="form_group  d-block" >
                <label class="form_label"  >Content<em>*</em></label>
                
                <!----<vs-textarea  data-vv-as="Mail Body"  v-model="newTemplate.body"  name="Description"  v-validate="'required'"  class="w-full" />-->
                 <ckeditor  name="Body" data-vv-as=" Content" v-validate="'required|min:10'" :editor="editor" v-model="newTemplate.body" :config="editorConfig"></ckeditor>
                 <span class="text-danger text-sm" v-show="errors.has('templateForm.Body')">{{ errors.first("templateForm.Body") }}</span>
              </div>
            </div>

                   
            
          </div>
          <div class="vx-row">
              <div class="vx-col w-full">
                <div class="form_group d-block">
                  <label class="form_label">Available Tags</label>

                   <ul class="uploaded-list available_list">
                        <template v-for="(item, index) in allTags">
                        <li :key="index" @click="copyTag(item ,'newTemplate' ,'body')" >
                         {{ item}}
                          </li>
                          
                        </template>
                      </ul>      
                  
                </div>
              </div>
             </div>

          <div class="text-danger text-sm formerrors" v-show="formerrors.msg" @click="formerrors.msg=''">
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
              icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
          </div>
        </div>
        <div class="popup-footer relative">
           <span class="loader" v-if="formSubmited" ><img src="@/assets/images/main/loader.gif"></span>
          <vs-button color="dark" @click="edit=false;openNewTemplatePopUp(false)" class="cancel" type="filled">Cancel</vs-button>
        
          <vs-button color="success" :disabled="formSubmited" class="save"  @click="createOrUpdateTemplate()" type="filled">

            <template v-if="edit">Update</template>
             <template v-else>Save</template>
           
          </vs-button>
        </div>
      </form>

        </div>
        </modal>



    <vs-popup class="holamundo main-popup"  title="Delete Template" :active.sync="approveConformpopUp">
      <div class="form-container">
        
        <div class="vx-row">
          <div class="vx-col w-full">
          <p>Are you sure of Delete this Template?</p>
            
          </div>
          
        </div>

         <div v-show="formerrors.msg">
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
              icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
          </div>
       
      </div>
      <div class="popup-footer">
        <vs-button color="dark" class="cancel" type="filled" @click="approveConformpopUp=false">Cancel </vs-button>
        <vs-button color="success" class="save" type="filled" @click="deleteAction(selectedUser)">Delete</vs-button>
      </div>
    </vs-popup>

      <modal
      name="templateDetailsModal"
      classes="v-modal-sec"
      :min-width="200"
      :min-height="200"
      :scrollable="true"
      :reset="true"
      width="600px"
      height="auto"
    >
     <div class="v-modal" >
        <div class="popup-header fromDetailsPage">
          <h2 class="popup-title">
            <template v-if="edit">Edit Email Template</template>
             <template v-else>Details</template>
          </h2>
          <span @click="$modal.hide('templateDetailsModal')">
            <em class="material-icons">close</em>
          </span>
        </div>
         <form @submit.prevent data-vv-scope="templateForm" >
        <div class="form-container pb-2">
          <div class="vx-row">
          <template >
            <div class="vx-col  w-1/2">
              <div class="form_group  d-block">
                <label class="form_label">Name</label>
                <p class="value">{{checkProperty( selectedItem ,'name')}}</p>
                
              </div>
            </div>

             



            


                  <div class="vx-col w-1/2">
               <div class="form_group  d-block">      
                 <div class="con-select w-full"> 
                    <label for class="form_label">Type</label>
                  
                    <p class="value">{{checkProperty( selectedItem ,'type')}}</p>
                   
                 </div>
                 </div>
              </div>
                 <div class="vx-col w-1/2" v-if="false">
               <div class="form_group  d-block">      
                 <div class="con-select w-full"> 
                    <label for class="form_label">Status</label>
                  
                    <p class="value">{{checkProperty( selectedItem ,'statusDetails' ,'name')}}</p>
                   
                 </div>
                 </div>
              </div>
     
              
            </template>

            <div class="vx-col  w-full">
              <div class="form_group  d-block">
                <label class="form_label"> Subject</label>
                  <p class="value">{{checkProperty( selectedItem ,'subject')}}</p>
              </div>
            </div>
            
            <div class="vx-col w-full">
              <div class="form_group  d-block">
                <label class="form_label"> Content</label>
                
                 <p class="value" v-html="checkProperty( selectedItem ,'body')">{{checkProperty( selectedItem ,'body')}}</p>
              </div>
            </div>

                   
            
          </div>

          <div class="text-danger text-sm formerrors" v-show="formerrors.msg" @click="formerrors.msg=''">
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
              icon="IP-information-button" active="true"></vs-alert>
          </div>
        </div>
        <div class="popup-footer relative">
           
          <vs-button color="dark" @click="edit=false;openNewTemplatePopUp(false);$modal.hide('templateDetailsModal')" class="cancel" type="filled">Cancel</vs-button>
        
          
        </div>
      </form>

        </div>
        </modal>

        <div  class="workflow_view_wrap taskmanagement emailtemplate" :class="{ listopen: sendEmailPopup }">
        <div class="workflow_overlay"   @click="sendEmailPopup = false"></div>
        <div class="workflow_view_cnt questionary_cnt" style="width:60%">
          <div class="workflow_view_title view__title" :class="{ 'pr-0': type == 'showWorkflowview' }" >
            <div>
              <label>Send Email</label>
            </div>
            <span @click="sendEmailPopup = false"><x-icon size="1.5x" class="custom-class"></x-icon></span>
          </div> 

          <div class="workflow_view_sec">
           <form @submit.prevent >
             <VuePerfectScrollbar
            ref="mainSidebarPs"
            class="scroll-area--main-sidebar pt-5"
            :settings="settings"
            @ps-scroll-y="psSectionScroll"
          >
              <div class="form-container pb-2">
                <div class="vx-row">
                <template >
                  <div class="vx-col  w-1/2">
                    <div class="form_group  d-block">     
                      <label for class="form_label">Email Template</label> 
                      <div class="con-select w-full">
                          <multiselect class="w-full" v-model="newform.templateDetails" 
                          :options="activeTemplatsList" :multiple="false" 
                          name="Template"
                            :close-on-select="true" :clear-on-select="false" 
                            :select-label="''" 
                            :preserve-search="true"
                            @input="changedTemplate"
                        
                            data-vv-as="Template"   
                            placeholder="Email Template" label="name" track-by="name" :preselect-first="false">
                            <template slot="selection" slot-scope="{ values, isOpen }">
                              <span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">{{ values.length }}
                                options selected</span>
                            </template>
                          </multiselect>
                          <span class="text-danger text-sm" v-show="errors.has('Template')">{{ errors.first("Template") }}</span>
                      </div>
                      </div>
                  </div>
                  <div class="vx-col  w-1/2">
                    <div class="form_group  d-block">
                      <label class="form_label">Campaign  Name<em>*</em></label>
                      <vs-input @keyup="formerrors.msg=''" v-model="newform.name" name="name" v-validate="'required'" class="w-full"
                        data-vv-as="Name"    />
                      <span class="text-danger text-sm"
                        v-show="errors.has('name')">{{ errors.first("name") }}</span>
                    </div>
                  </div>

                  
                  <div class="vx-col  w-full">
                    <div class="form_group  d-block">
                      <label class="form_label">Select User Types</label>
                      <ul class="group-checklist">
                        <li><vs-checkbox v-if="[3].indexOf(getUserRoleId)>-1" @input="changedUserType()" v-model="newform.internalUser">Internal Users</vs-checkbox></li>
                        <li><vs-checkbox v-model="newform.petitioner"  @input="changedUserType()">Petitioners</vs-checkbox></li>
                        <li><vs-checkbox v-model="newform.beneficiary"  @input="changedUserType()" >Beneficiary</vs-checkbox></li>
                      </ul>
                    </div>
                  </div>
                  
                  <div class="vx-col " :class="{'w-1/2':(newform.internalUser&&newform.petitioner) ,'w-full':!(newform.internalUser&&newform.petitioner)}" v-if="[3].indexOf(getUserRoleId)>-1 && newform.internalUser">
                    <div class="form_group  d-block">      
                      <div class="con-select w-full"> 
                          <label for class="form_label">Branch</label>
                        
                          <multiselect v-model="newform.branchDetails" :options="branchList" :multiple="true" :hideSelected="true"
                        
                            :close-on-select="false"
                             :clear-on-select="false" 
                             :select-label="''" 
                             :preserve-search="true"
                              @input="changedUserType()"
                            placeholder="Select Branch" name="branch" label="name" track-by="name" :preselect-first="false">
                            
                            <template slot="selection" slot-scope="{ values, isOpen }">
                                                          <span
                                                          class="multiselect__selectcustom"
                                                          v-if="values.length && !isOpen"
                                                          >{{ values.length }} Branch(s) selected</span
                                                          >
                                                          <span
                                                          class="multiselect__selectcustom"
                                                          v-if="values.length && isOpen"
                                                          ></span>
                                                      </template>
                          </multiselect>
                          <span class="text-danger text-sm" v-show="errors.has('branch')">{{ errors.first("branch") }}</span>
                      </div>
                      </div>
                  </div>

                  <div class="vx-col " :class="{'w-1/2':(newform.internalUser&&newform.petitioner) ,'w-full':!(newform.internalUser&&newform.petitioner)}"   v-if="[3].indexOf(getUserRoleId)>-1 && newform.petitioner">
                    <div class="form_group  d-block">      
                      <div class="con-select w-full"> 
                          <label for class="form_label">Company</label>
                      
                           <multiselect   
                           v-model="newform.peritionersDetail"
                            :options="all_peritioners" 
                              :multiple="true" 
                              :hideSelected="true"
                              :close-on-select="false" 
                              :clear-on-select="false" 
                              :preserve-search="true"
                              placeholder="Select Company"
                                  label="name"
                                   track-by="name"
                                    :preselect-first="false"
                                    @input="changedUserType()"
                                
                    >
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} Company(s) Selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template>

                    </multiselect>
                          
                      </div>
                      </div>
                  </div>
      

                

                  <div class="vx-col  w-full">
                    <div class="form_group  d-block">      
                          <div class="con-select w-full"> 
                      
                              <label for class="form_label">Users<em>*</em></label>
                            
                              <multiselect class="w-full" v-model="newform.userDetails" 
                              :options="allUsers" :multiple="true" 
                              name="Users"
                                :close-on-select="false" 
                                :clear-on-select="false" 
                                :select-label="''" 
                                :preserve-search="true"
                                 :hideSelected="true"
                                v-validate="'required'"
                                data-vv-as="Users"
                                @input="userSelected"   
                                placeholder="Users" label="name" track-by="name" :preselect-first="false">
                                <template slot="selection" slot-scope="{ values, isOpen }">
                                    <span
                                    class="multiselect__selectcustom"
                                    v-if="values.length && !isOpen"
                                    >{{ values.length }} Users(s) Selected</span
                                    >
                                    <span
                                    class="multiselect__selectcustom"
                                    v-if="values.length && isOpen"
                                    ></span>
                                </template>
                              </multiselect>
                              <span class="text-danger text-sm" v-show="errors.has('Users')">{{ errors.first("Users") }}</span>
                          </div>
                      </div>
                  </div>


                  <div class="vx-col  w-full">
                    <div class="form_group  d-block">
                      <label class="form_label">Custom Emails</label>
                      <vs-input
                        
                    v-model="customEmailTxt" @keyup="formatEmail();formerrors.msg=''"  name="customEmails" class="w-full"
                            />
                      
                    </div>
                  
                  </div>

                  
                    <!------templateDetails:null activeTemplatsList-->
                  
                    
                  </template>

                  

                  <!----
                    <div class="vx-col w-full " >
                    <div class="form_group  d-block">      
                      <div class="con-select w-full"> 
                  
                          <label for class="form_label">Effective Date<em>*</em></label>
                        
                          <datepicker   :typeable="true"
                                      :format="customFormatter"
                                      v-model="effectiveDate"
                                      v-validate="'required'" 
                                      data-vv-as="Effective Date"
                                      :disabled-dates="{ to: new Date() }"
                                      placeholder="MM/DD/YYYY"
                                      name="formeffectiveDate"
                                    ></datepicker>
                          
                          
                          <span class="text-danger text-sm" v-show="errors.has('formeffectiveDate')">{{ errors.first("formeffectiveDate") }}</span>
                      </div>
                      </div>
                    </div>
                    -->

                    <div class="vx-col  w-full">
                    <div class="form_group  d-block">
                      <label class="form_label"> Subject<em>*</em></label>
                      <vs-input @keyup="formerrors.msg=''" 
                        
                      v-model="newform.subject" name="subject" v-validate="'required'" class="w-full"
                        data-vv-as="Subject"    />
                      <span class="text-danger text-sm"
                        v-show="errors.has('subject')">{{ errors.first("subject") }}</span>
                    </div>
                  </div>
                  <div class="vx-col w-full">
                    <div class="form_group  d-block mb-4">
                      <label class="form_label"> Content<em>*</em></label> 
                      
                    <!--- <vs-textarea  data-vv-as="Mail Body" v-model="newform.body"  name="Description"  v-validate="'required'" class="w-full"  />-->
                      <ckeditor data-vv-as="Content"  name="Description"  v-validate="'required|min:10'" :editor="editor" v-model="newform.body" :config="editorConfig"></ckeditor>
                      <span class="text-danger text-sm" v-show="errors.has('Description')">{{ errors.first("Description") }}</span>
                    </div>
                  </div>

                        
                  
                </div>

                <div class="vx-row">
                    <div class="vx-col w-full">
                      <div class="form_group d-block">
                        <label class="form_label">Available Tags</label>

                        <ul class="uploaded-list available_list">
                              <template v-for="(item, index) in allTags">
                              <li :key="index" @click="copyTag(item ,'newform' ,'body')" >
                              {{ item}}
                                </li>
                                
                              </template>
                            </ul>      
                        
                      </div>
                    </div>
                  </div>


                <div class="text-danger text-sm formerrors" v-show="formerrors.msg" @click="formerrors.msg=''">
                  <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
                    icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
                </div>
              </div>

             </VuePerfectScrollbar>

                <div class="popup-footer relative">
                <!--  validateForm ---->
                <span class="loader" v-if="formSubmited" ><img src="@/assets/images/main/loader.gif"></span>
                  <vs-button color="dark" @click="edit=false;createNew(false)" class="cancel" type="filled">Cancel</vs-button>
                
                  <vs-button color="success" :disabled="formSubmited" class="save"  @click="sendMail()" type="filled">Send</vs-button>
                </div>
      </form>
          </div>
        
            
          <div> 
          </div>
          
        </div>
        
      </div>



        
  </div>
</template>

<script>
import DateRangePicker from "vue2-daterange-picker";
  import Datepicker from "vuejs-datepicker-inv";
  import Paginate from "vuejs-paginate";
  import NoDataFound from "@/views/common/noData.vue";
  import docType from "@/views/common/docType.vue";
  import VuePerfectScrollbar from "vue-perfect-scrollbar";
import "vue2-daterange-picker/dist/vue2-daterange-picker.css";

  import _ from "lodash";
  import { FormWizard, TabContent } from "vue-form-wizard";
  import "vue-form-wizard/dist/vue-form-wizard.min.css";
   import moment from 'moment'
  import PhoneMaskInput from "vue-phone-mask-input";
  import JQuery from 'jquery'
  import { TheMask } from 'vue-the-mask'
  
import FileUpload from "vue-upload-component/src";
import VuePhoneNumberInput from 'vue-phone-number-input';
import 'vue-phone-number-input/dist/vue-phone-number-input.css';
import { MoreVerticalIcon } from 'vue-feather-icons';
import CKEditor from '@ckeditor/ckeditor5-vue2';
import Vue from 'vue';
import { XIcon } from 'vue-feather-icons'
Vue.use( CKEditor );
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';

  export default {
    computed:{
      validateForm(){
        if(
          (this.newform.name && this.newform.name.trim() !='' ) 
          && ( _.has(this.newform['type'] ,"name")  )
          && ( _.has(this.newform ,"document") && this.newform.document && (Object.keys(this.newform.document).length>0 ) )
        
        ){

          return false;
        }else{
          return true;
        }

      },
      acceptedFiles(){
      let returnValue ='*';
      if(_.has(this.newform['type'] ,"name")){
        
        if(this.newform['type']['name'] =="Form" ){
          returnValue ='application/pdf';
        }else if(this.newform['type']['name'] =="Letter" ){
          returnValue ='application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document';
        }

      }
      return returnValue;
      //image/*, application/pdf, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document
    }
    },
    components: {
      XIcon,
      docType,
      NoDataFound,
      DateRangePicker,
      VuePhoneNumberInput,
      Datepicker,
      Paginate,
      FileUpload,
      FormWizard,
      TabContent,
      PhoneMaskInput,
      TheMask,
      MoreVerticalIcon,
      VuePerfectScrollbar
    },

    data: () => ({
     
      all_peritioners:[],
      sendEmailPopup: false,
      editor: ClassicEditor,
    editorConfig: {
        // The configuration of the editor.
       toolbar: [ 'bold', 'italic', '|', 'undo','redo' ,"indent" ,"Outdent" ,'NumberedList', 'BulletedList', ],
         //removeButtons:["Image"]
        
    },
    settings: { 
      swipeEasing: true,
    },
       allTags:["userName" ,"email"],
        copyed:false,
        templateTypes:[  "Case" ,  "Generic"   ],
        

        newTemplate:{
            "name": "",
		    "type": "Generic",
            typeDetails:null,
    	    "subject": "",
            "body":[]

        },

      branchList:[],
      branchTempList:[],  
      popUpTitle:'Form/Letter',
      effectiveDate:'',
      isRvisionUpload:false,
      
      formsAndLettersTypeFIlter:[],
      callFromSerch:false,
      formSubmited:false, 
      uploading:false,
      detailsView:false,
      details:null,
    selected_createdDateRange: ["", ""],
    autoApply: "",
        value:[],
        allUserRoles:[ ],
        allUsers:[],
        
      selectedItem:null,
      selectedStatus:2,
      actionText:"Do you want to Delete?",
      formerrors: {
        msg: ""
      },
      date: null,
      approveConformpopUp: false,
     
     newform: {
      name:'' ,
     subject:'',
     branchDetails:[],
     peritionersDetail:[],
      usersRoles:[],
      userDetails:[],
      "document":null ,
      "attachments":[],
      "today":moment().format("YYYY-MM-DD") ,
      "body":'' ,
      customEmailList:[],
     },
     customEmailTxt:'',
      list: [],
      addPopup: false,
      NewPetition: false,
      
     
      searchtxt: "",
      query: [],
      country_code: 231,
      all_statusids: [],
      selected_statusids: [],
      final_selected_statusids: [],
      filter_roleIds: [],
      final_filter_roleIds: [1,2,3,4,5,8,9,10,11,12],

      
      seleted_states: [],
      final_selected_states: [],
      locations: [],
      // locationIds
      final_selected_typesids:[],
      selected_typeids:[],
      
      
      
      date_range: [],
      page: 1,
      perpage: 25,
      totalpages: 0,
      

     
      switch2:true,
      users_status:{},
      edit:false,
      sortKeys:{},
      sortKey:{},
      details:null,
      activeTemplatsList:[],

    }),
    watch: {
      searchtxt: function (value) {
        this.getList(true);
      }

    },
    methods: {
      removeTags(str){
        if ((str===null) || (str===''))
        return '';
      else
          str = str.toString();
          
        // Regular expression to identify HTML tags in 
        // the input string. Replacing the identified 
        // HTML tag with a null string.
        let stri =  str.replace( /(<([^>]+)>)/ig, '');
        stri= (stri.substring(0,30))+"....";	
        return stri

      },
      userSelected(val){
        if(_.find(this.newform.userDetails  ,{"_id":"All"})){
         
          _.forEach(this.allUsers ,(item)=>{
           
              if(!(_.find(this.newform.userDetails, {"_id":item['_id']}))){
                 this.newform.userDetails.push(item);
              }
              
          })

        }
        
      },
     
      get_peritioners() {

     
           
     //petitioner_list_for_tenant_users

       let item ={
          page:1,
          perpage: 10000,
          category: "petitioner_list_for_tenant_users",
          matcher:{
            "searchString":this.peritioners_search_value,
          
          },
          "sorting": {
            "path": "name",
            "order": 1
            }
                      
        };
        if([51].indexOf(this.getUserRoleId)>-1){
          item['category'] = "petitioner_list_for_beneficaries"
        }

  
        this.$store.dispatch("getMasterData", item).then(response => {
         
          this.all_peritioners =response.list
        
        });
    },
      getAllTags(){
      // this.allTags
      
      let query ={
        type:'Generic'
      };
      if(this.checkProperty( this.newTemplate ,'type') == 'Case'){
        query['type'] ='Case';
      }
         this.$store
          .dispatch("getList",{data:query ,path:'/bulk-emails/get-data-tags'} )
          .then(response => {
           
            this.allTags = response;
            })
      },

       removeEmail(i){
     
      this.newform.customEmailList.splice(i ,1);
      this.customEmailTxt =  this.newform.customEmailList.join(',');
      this.formatEmail();
    },

    formatEmail(){
      
        // customEmailTxt:'',
        // sharing:false,
      let emailList= this.customEmailTxt.split(',');
      this.newform.customEmailList =[];
      let tempEmailList =[];
      if(this.checkProperty( emailList ,'length' )>0){
            const validateEmail = (email) => {
            return String(email)
            .toLowerCase()
            .match(
            /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
            );
            };

        this.newform.customEmailList = _.filter(emailList , (email)=>{
            if(validateEmail(email)){
                return true;
              }else{
                return false;
              }

        })
       // alert(JSON.stringify(this.newform.customEmailList));


      }

    },
      async pastMe(item ,datV){
        let text = await navigator.clipboard.readText();
       if(this.copyed){
          this[item][datV] =this[item][datV]+" "+text;
       }
          
        this.copyed =false
      },

      async  copyTag(text='' ,item ,datV){
           this.cocopyTagpyed =false;
        try {
          
          await navigator.clipboard.writeText(text);
          this.pastMe(item ,datV)
          this.copyed =true
                   
        
        } catch ($e) {}
      
    
    },

    
      changedTemplate(item){
        if(this.checkProperty(   this.newform ,'templateDetails','body' )){

          this.newform['body'] = _.cloneDeep( this.newform['templateDetails']['body'] )
        }
        if(this.checkProperty(   this.newform ,'templateDetails','subject' )){

          this.newform['subject'] = _.cloneDeep( this.newform['templateDetails']['subject'] )
        }
         if(this.checkProperty(   this.newform ,'templateDetails','name' )){

          this.newform['name'] = _.cloneDeep( this.newform['templateDetails']['name'] )
        }

      },

       getActiveTemplatsList() {
     
        let matcher = {
          searchString: '',
          type:['Generic'],
          createdDateRange:[],
        
          
        };
       
        let query = {};
        query['page'] = 1;
        query['perpage'] = 10000000000;
        query['filters'] = matcher;
        query['sorting'] = {"path":"createdOn" ,"order":-1};
         //query['getMasterData'] = true;
            
        this.$store
          .dispatch("getList",{data:query ,path:'/custom-emails/list'} )
          .then(response => {
           
            this.activeTemplatsList = response.list;

            this.totalpages = Math.ceil(response.totalCount / this.perpage);
           // alert(response.totalCount);
          }).catch((err)=>{
             this.activeTemplatsList=[];
          })
      },
      deleteMe(tr){
          this.selectedItem=tr;
          this.approveConformpopUp =true;
            this.formSubmited =false; 
            Object.assign(this.formerrors, { msg:''  });

      },
      deleteAction(){
         
          if (_.has(this.selectedItem ,'_id')) {
            this.formSubmited =true; 

            let postData ={emailTplId:''}
           let path = "/custom-emails/delete";
           postData['emailTplId'] = this.selectedItem['_id']

           
           this.$store
              .dispatch("commonAction", {data:postData ,path:path})
              .then(response => {
                this.formSubmited =false;
                this.$vs.loading.close()
                 this.showToster({message:response.message,isError:false });
                 this.getList();
                 this.addPopup =false;
                  this.openNewTemplatePopUp(false);
                  this.approveConformpopUp =false;
                  this.selectedItem = null;
                
              })
              .catch((error)=>{
                this.formSubmited =false;
                 this.$vs.loading.close()
                Object.assign(this.formerrors, {
                    msg:error
                  });
              })
          }
        

        },
        editMe(tr){
            this.selectedItem=tr;
            this.formerrors ={msg:''};
         this.formSubmited =false;
         this.edit =true
            this.newTemplate ={
            "name": "",
           "type": "Generic",
            typeDetails:null,
            "subject": "",
            "body":''

            }
            this.newTemplate['name'] = this.checkProperty( this.selectedItem ,'name');
            this.newTemplate['type'] = this.checkProperty( this.selectedItem ,'type');
            this.newTemplate['subject'] = this.checkProperty( this.selectedItem ,'subject');
            this.newTemplate['body'] = this.checkProperty( this.selectedItem ,'body');
             this.$validator.reset();
            this.$modal.show('newTemplateModal');
        

        },
        createOrUpdateTemplate(){

             this.$validator.validateAll('templateForm').then(result => {
          if (result) {
            this.formSubmited =true; 

            let postData ={"name":this.newTemplate.name ,subject:this.newTemplate.subject, body:this.newTemplate.body ,"userIds":[]}
            postData['name']  =this.newTemplate['name'].trim();
            postData['subject']  =this.newTemplate['subject'].trim();
            postData['type']  =this.newTemplate['type']
           let path = "/custom-emails/create";
           if(this.edit){
                path = "/custom-emails/update";
                postData =Object.assign(postData,{ "emailTplId":''});
                postData['emailTplId'] = this.selectedItem['_id']

           }
           this.$store
              .dispatch("commonAction", {data:postData ,path:path})
              .then(response => {
                this.formSubmited =false;
                this.$vs.loading.close()
                 this.showToster({message:response.message,isError:false });
                 this.getList();
                 this.addPopup =false;
                  this.openNewTemplatePopUp(false);
                  this.getActiveTemplatsList();
                
              })
              .catch((error)=>{
                this.formSubmited =false;
                 this.$vs.loading.close()
                Object.assign(this.formerrors, {
                    msg:error
                  });
              })
          }
        });

        },
        openNewTemplatePopUp(action =false){
          this.formerrors ={msg:''};
          this.formSubmited =false;
          this.edit =false
          this.newTemplate ={
              "name": "",
              "type": "Generic",
              typeDetails:null,
            "subject": "",
              "body":''

          }
          this.$validator.reset();
          if(action){
              this.$modal.show('newTemplateModal');
          }else{
              this.$modal.hide('newTemplateModal');
          }
        
        }, 
         getBranchList(){
        
        let postData ={
          "filters":{"title":"","createdDateRange":[],"statusList":[],"activeList":[]},
           //"getMasterData":true,
           "page":1,
           "perpage":250000,
           "sorting":{"path":"createdOn","order":-1}};
        this.$store.dispatch("getList" ,{ "data":postData,"path":"/branch/list"})
        .then((res)=>{
          let list = res.list
          this.branchList =list;
          this.branchTempList = list;
         
             
          //alert(JSON.stringify(res));
        })
        .catch((err)=>{
          this.branchList =[] ;
        })
        },
        createNew(action =true){
       this.edit =false;
       this.isRvisionUpload =false;
       this.effectiveDate ='';
       
       this.newform = {
        name:'' ,
       subject:'',
       branchDetails:[],
       peritionersDetail:[],
        usersRoles:[],
        userDetails:[],
        "document":null ,
        "attachments":[],
        "today":moment().format("YYYY-MM-DD") ,
        "body":'' ,templateDetails:null,
         customEmailList:[],
          internalUser:false,
         petitioner:false,
         beneficiary:false
         };
        this.customEmailTxt='';
      this.addPopup=action;
      this.formerrors.msg='';
       this.formSubmited =false;
        this.$validator.reset();
       if(this.addPopup){

        this.newTemplate['type'] = 'Generic';
        this.getAllTags();
         this.getUsersList();
         this.showModal()
       }else{
         this.hidewModal()
       }
       this.popUpTitle = "Send Email"
       this.$vs.loading.close();
       this.$validator.reset();

      
     },
         changedUserRoles(){
         this.newform.attachments =[];
         this.newform.document = null;
         this.newform.userDetails =[];
         this.getUsersList();
        
        

      },
      changedUserType(){
       

        setTimeout(()=>{
       //   if(this.checkProperty( this.newform ,'userDetails' ,'length')>0){
          let userDetails = _.cloneDeep(this.newform.userDetails); 
            if(! this.checkProperty(this.newform ,'internalUser' )){
             this.newform.branchDetails = [];
              userDetails = _.filter(userDetails ,(item)=>{
                return [3,2,4,5,6,7,8,9,10,11,12,13,14].indexOf(item.roleId)>-1?false:true
              })
            }
          
            if(! this.checkProperty(this.newform ,'petitioner' )){
              this.newform.peritionersDetail =[];
              userDetails = _.filter(userDetails ,(item)=>{
                return [50].indexOf(item.roleId)>-1?false:true
              })

            }
            if(! this.checkProperty(this.newform ,'beneficiary' )){
               userDetails = _.filter(userDetails ,(item)=>{
                return [51].indexOf(item.roleId)>-1?false:true
              })
            }
          this.newform.userDetails  = _.cloneDeep(userDetails);
       // }
          this.getUsersList();
        },1);

      },
        getUsersList(callFromSerch='') {

         
        this.allUsers =[];
        let matcher = {
          // roleIds: [],
          // title: this.searchtxt,
          // searchString: this.searchtxt,
          // statusIds: [],
          // stateIds: [],
          // locationIds: [],
          // createdDateRange:[],
          // branchIds:[],

          "title": "",
          "categories": [], //"internal-user" ,"beneficiary", "petitioner"
          "companyIds":[],
          "branchIds":[]

         
        };
        // if(this.checkProperty(this.newform ,'usersRoles' ,'length' )>0){
        //   matcher['roleIds'] = this.newform.usersRoles.map((item)=>item.id)
        // }
        if( this.checkProperty(this.newform ,'internalUser' )){
          if( [3].indexOf(this.getUserRoleId)>-1&& this.checkProperty(this.newform ,'branchDetails' ,'length' )>0){
            matcher['branchIds'] = this.newform.branchDetails.map((item)=>item._id)
          }else if([4,5,6,7,8,9,10,11,12 ,13].indexOf(this.getUserRoleId)>-1 && this.checkProperty(this.getMasterData ,'branchDetais' ,"_id")){
            matcher['branchIds'] =[];
            let branchId = this.checkProperty(this.getMasterData ,'branchDetais' ,"_id");
              matcher['branchIds'].push(branchId);

          }
          matcher['categories'].push('internal-user');
        }
        if( this.checkProperty(this.newform ,'petitioner' )){
          if(this.checkProperty(this.newform ,'peritionersDetail' ,'length' ) >0){
             matcher['companyIds'] =  this.newform.peritionersDetail.map((item)=>{
               return item['_id'];
            }) 
          }
           matcher['categories'].push('petitioner');
        }
        if( this.checkProperty(this.newform ,'beneficiary' )){
           matcher['categories'].push('beneficiary');
        }
        

       

     
      
        let query = {};
        query['getMasterData'] = true;
        query['page'] = this.page;
        query['perpage'] = 10000;
        query['matcher'] = matcher;
        query['sorting'] = {"path":'createdOn' ,"order":-1};;
        //alert( JSON.stringify(query['sorting']))

        this.$store
          .dispatch("getList",{data:query ,path:'/bulk-emails/get-users'} )
          .then(response => {
            let list = response.list; 
            this.allUsers =[
              {"_id":"All" ,"name":'All'}
            ];
             _.forEach(list,(item) => {
               item['name'] = item['name']+" ( "+ item['email'] +" - " +item['roleName' ]+" )" 
                this.allUsers.push(_.cloneDeep(item));
            });
         
            
            //alert(this.perpage);
          }).catch((err)=>{
             this.allUsers = [];
            

          })
      },
        showModal(){
            this.sendEmailPopup =true
            //this.$modal.show('sendEmailModel');

      },
      hidewModal(){
        this.sendEmailPopup =false
          //this.$modal.hide('sendEmailModel');
      },
     
      getDetails(id){

        let postData = {'emailTplId':id};
        this.$store.dispatch("commonAction" ,{data:postData,"path":'/custom-emails/details'})
        .then((response) => {
         
          this.details = response;
          this.detailsView =true;

        })
        .catch((error)=>{
            this.detailsView =false;

        })

      },
        
     
       sortMe(sort_key=''){

      
      if(sort_key !=''){
          this.sortKeys[sort_key] = this.sortKeys[sort_key]==1?-1:1
          // this.sortKey[sort_key] = this.sortKeys[sort_key]
          this.sortKey = {"path":sort_key ,"order":this.sortKeys[sort_key]};

          localStorage.setItem('formandLetter_sort_key', sort_key);
          localStorage.setItem('formandLetter_sort_value', this.sortKey[sort_key]);
          this.getList();
      }
          
      

      },
     
     
     
      
      deleteConform(item ){
        this.selectedItem = item;
        this.approveConformpopUp =true;
        this.edit= false;

      },
  
      getList(callFrom=false) {
       this.callFromSerch =callFrom;
        let matcher = {
          searchString: this.searchtxt,
          typeList:this.selected_typeids,
          createdDateRange:[],
        
          
        };
        if (
        this.selected_createdDateRange["startDate"] &&
        this.selected_createdDateRange["startDate"] != "" &&
        this.selected_createdDateRange["endDate"] != "" &&
        this.selected_createdDateRange["endDate"]
      ) {
        matcher["createdDateRange"] = [
          this.selected_createdDateRange["startDate"],
          this.selected_createdDateRange["endDate"]
        ];
      }
        let query = {};
        query['page'] = this.page;
        query['perpage'] = this.perpage;
        query['filters'] = matcher;
        query['sorting'] = this.sortKey;

        this.updateLoading(true);
        
        this.$store
          .dispatch("getList",{data:query ,path:'/custom-emails/list'} )
          .then(response => {
             this.updateLoading(false);
            this.list = response.list;

            this.totalpages = Math.ceil(response.totalCount / this.perpage);
             setTimeout(()=>{ this.updateLoading(false);  } ,10);
           // alert(response.totalCount);
          }).catch(()=>{
             this.updateLoading(false);
              setTimeout(()=>{ this.updateLoading(false);  } ,10);
          })
      },
     
      sendMail() {

        
        this.$validator.validateAll().then(result => {
          if (result) {
            this.formSubmited =true; 

            let postData ={"name":this.newform.name ,subject:this.newform.subject, body:this.newform.body ,"userIds":[] ,"customEmailList":[]}
            postData['name']  =this.newform['name'].trim();
            postData['subject']  =this.newform['subject'].trim();
            _.forEach(this.newform['userDetails'] ,(item)=>{
              if(item._id !='All'){
                postData['userIds'].push(item._id);
              }
              })
           
            postData['customEmails']= this.newform.customEmailList;
           let path = "/bulk-emails/send";
           this.$store
              .dispatch("commonAction", {data:postData ,path:path})
              .then(response => {
                this.formSubmited =false;
                this.$vs.loading.close()
                 this.showToster({message:response.message,isError:false });
                 this.getList();
                 this.addPopup =false;
                  this.hidewModal();
                
              })
              .catch((error)=>{
                this.formSubmited =false;
                 this.$vs.loading.close()
                Object.assign(this.formerrors, {
                    msg:error
                  });
              })
          }
        });
      },
     
    
      
      set_filter: function () {
        
        this.$refs["filter_menu"].dropdownVisible = false;
        this.final_selected_statusids = [];
        if (this.selected_statusids.length > 0) {
          this.final_selected_statusids = [];
          for (let ind = 0; ind < this.selected_statusids.length; ind++) {
            let current_index = this.selected_statusids[ind];
            this.final_selected_statusids.push(current_index["id"]);
          }
        }

        

        
// alert(this.final_selected_typesids)
       

       

        this.getList(true);
      },
      clear_filter: function () {
        this.formsAndLettersTypeFIlter = []
        this.searchtxt ='';
        this.callFromSerch =false;
        this.$refs["filter_menu"].dropdownVisible = false;
        this.selected_statusids = [];
        this.final_selected_statusids = [];
        this.final_selected_typesids = [];
        this.selected_typeids = [];
      
        this.date = "";
        this.date_range = [];
         this.selected_createdDateRange["startDate"] = "";
         this.selected_createdDateRange["endDate"] = "";
        this.getList();
      },
      pageNate(pageNum) {
        this.page = pageNum;
        this.getList();
      },
      
      deleteformandLetter( ){
        let post_data = {"formAndLetterId":this.selectedItem['_id'] }
        this.$store.dispatch("deleteformandLetter", post_data)
          .then(response => {
           this.approveConformpopUp = false;
            this.showToster({message:response.message,isError:false});
            this.getList();
            this.edit =false;


          }).catch((er)=>{
            this.showToster({message:er,isError:true});
          
        });
      },

    },
    mounted() {

      //this.$store.dispatch("updateSidebarWidth", "extended");
       this.getAllTags();
       this.get_peritioners();
      
      this.selected_statusids = [];
      this.final_selected_statusids = [];
      this.seleted_states = [];
      this.final_selected_states = [];
      this.sortKeys = {
            'name':1,
            'type':1,
            'subject':1,
            "createdOn":-1,
            "updatedOn":1,
            docTypeName:1
     
    },

    this.sortKey = {"path":"createdOn" ,"order":-1};
this.getBranchList();
 this.getActiveTemplatsList();

    

    let postData = {
          page:1,
          perpage: 10000,
          category: "user_roles",
         // tenantId: "5db7d79d6032453bd060ed9c",
        }

    this.$store.dispatch("getMasterData", postData).then(response => {
        this.allUserRoles = response.list;

        })

   
     
     // this.getUsersList();
      this.getList();
     

    }
  };
</script>
