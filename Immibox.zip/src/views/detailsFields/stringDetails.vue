<template>
    <div class="vx-col  w-full p-0" :class="wrapclass" >
        <div class="main-list">
           <p>
            {{label}}
            
            <span v-if="formater">
                <span v-if="formater == 'formatML'">
                    <span v-if="tempVisa" >
                        {{fieldValue | formatML(tempVisa) }}
                    </span>
                    <span v-else>
                        {{fieldValue | formatML(visastatuses) }}
                    </span>
                    
                </span>
                <span v-else>
                    {{$options.filters[formater](fieldValue)}}
                </span> 
               
            </span>
            <span v-else>{{fieldValue }}</span>
           </p> 
        </div>
    </div>
</template>

<script>
    export default{
        data: () => ({
            tempVisa:[]
        }),
        methods:{
            getVisaStautes(){
                    this.$store.dispatch("getmasterdata", "visa_status").then((response) => {
                    this.tempVisa = response;
                });
            }
        },
        mounted(){
            this.getVisaStautes()
        },
        props: {
            fieldValue:null,
            label:null,
            formater:{
                type:String,
                default:''
            },
            wrapclass:{
                type:String,
                default:'md:w-1/2'
            },
            visastatuses: {
                type: Array,
                default: null
            }

        }
    }
</script>
    