<template>
    <div class="vx-row m-0 main-list-panel w-full" >
        <div class="vx-col w-full p-0">
            <div class="tabs-content-table mt-2 priorPeriodtable">
                <p>
                    All prior periods of stay in the U.S. over the last seven years</p>
                <template>
                    <vs-table :data="fieldValue" >

                        <template>
                            <template slot="thead">
                                <vs-th>Case Status</vs-th>
                                <vs-th>Date Entered</vs-th>
                                <vs-th>Date Departed</vs-th>
                                <!-- <vs-th>No. of Days</vs-th> -->
                            </template>
                            <template >
                                    <vs-tr  v-for="( val, index) in fieldValue" :key="index">
                                        <vs-td> {{ val.visaStatus  | formatML(tempVisa)}} </vs-td>
                                        <vs-td>{{val.enteredDate | formatDate}}</vs-td>
                                        <vs-td>{{val.departedDate | formatDate}}</vs-td>
                                        <!-- <vs-td >{{val.noOfDays}}</vs-td> -->
                                    </vs-tr>
                            </template>
                        </template>
                    </vs-table>
                </template>
            </div>
        </div>
    </div>
</template>

<script>
   
   export default{ 
    data: () => ({
            tempVisa:[]
        }),
        methods:{
            getVisaStautes(){
                    this.$store.dispatch("getmasterdata", "visa_status").then((response) => {
                    this.tempVisa = response;
                });
            }
        },
        mounted(){
            this.getVisaStautes()
        },
        props: {
            fieldValue:null,
            //fieldStructure:null,
            visastatuses: {
                    type: Array,
                    default: null
                }
        },   
   }
</script>
   