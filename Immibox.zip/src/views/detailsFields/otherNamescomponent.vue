<template>
     <div class="vx-row m-0 main-list-panel" >
            <h5 class="names_title">Used other names previously</h5>
            <template v-for="( val, index) in fieldValue" >
                <template v-for="( vall, field) in val">
                    <template v-if="getFieldStructure({'field':field , 'dataVar':fieldStructure})['type'] == 'string' " >
                        <stringDetails :key="field" :value="vall" 
                        :label="getFieldStructure({'field':field , 'dataVar':fieldStructure})['label']" 
                        v-if="vall" :formater="getFieldStructure({'field':field , 'dataVar':fieldStructure})['formater']" :wrapclass="'md:w-1/3'"  />
                    </template>
              </template>
            </template>

        </div>
</template>

<script>
    import stringDetails from "@/views/detailsFields/stringDetails.vue";
    export default{
        components:{
            stringDetails,
        },
        props: {
            fieldValue:null,
            key:null,
            fieldStructure:null,
            wrapclass:{
                type:String,
                default:'md:w-1/2'
            }
        },
        computed :{
            getFieldStructure(){
                return (data)=>{
                    if(_.has( data ,'dataVar') && data['field']){
                        if(_.has(data['dataVar'],data['field'])){
                            return data['dataVar'][data['field']];
                        }
                    else {
                        return false;
                    }
                }
                else {
                    return false;
                }
            }
            }
        }
    }
</script>
    