<template>
    <div class="vx-col  w-full p-0" :class="wrapclass" >
        <div class="main-list">
           <p>
            {{label}}
            <span>
            <template v-if="formater " >
                {{checkProperty(countryCodeValue,'countryCallingCode')|countryFormatter}}
                {{$options.filters[formater](fieldValue)}}
                
             </template>
             <template v-else>
                {{checkProperty(countryCodeValue,'countryCallingCode')| countryFormatter }} 
                {{fieldValue}}
             </template>
            </span>
           </p> 
        </div>
    </div>
</template>

<script>
    export default{
        props: {
            label:null,
            countryCodeValue:null,
            fieldValue:null,
            key:null,
            fieldStructure:null,
            wrapclass:{
                type:String,
                default:'md:w-1/2'
            },
            formater:{
                type:String,
                default:''
            },

        },
        computed:{
            // checkFiled(){
            //    let returnValue=''
            //     if(!(this.checkProperty(this.countryCodeValue,'countryCallingCode').includes("+"))){
            //         returnValue = "+"+returnValue
            //     }
            //     return returnValue
            // }
        }
    }
</script>
    