<template>
  <div class="vx-col w-full mb-base wizard-container">
    <vx-card>
      <div class="wizard-content-heading">
        <h2>Complete Registration</h2>
        <p>Please take a few moments to complete this short registration form</p>
      </div>
      <form-wizard
        color="rgba(var(--vs-primary), 1)"
        :title="null"
        :subtitle="null"
        finishButtonText="Submit"
        @on-complete="formSubmitted"
      >
        <tab-content name="companydetails" title="Company Details" :before-change="beforeTabSwitch">
          <!-- tab 1 content -->
          <vs-col
            class="m-auto float-none"
            vs-type="flex"
            vs-justify="center"
            vs-align="center"
            vs-lg="8"
            vs-sm="12"
          >
            <div class="form-container mt-6">
              <div class="vx-row">
                <!-- <div class="vx-col md:w-full w-full mt-5">
                        <vs-input label="First Name" v-model="firstName" class="w-full" />
                </div>-->
                <div class="vx-col w-full">
                  <vs-input
                    class="w-full"
                    name="companyname"
                    data-vv-as="Company Name"
                    v-model="petitioner.name"
                    v-validate="'required'"
                    label="Full legal name of your company"
                  />
                  <span
                    class="text-danger text-sm"
                    v-show="errors.has('companyname')"
                  >{{ errors.first("companyname") }}</span>
                </div>
                <div class="vx-col md:w-1/2 w-full">
                  <div class="main-placeholder left">
                    <div class="vs-component vs-input w-full vs-input-primary">
                      <div class="vs-con-input">
                        <vs-input
                          v-mask="'(###)-###-####'"
                          v-model="petitioner.phone"
                          name="companyphone"
                          v-validate="'required|phonevalid'"
                          data-vv-as="Phone Number"
                          placeholder="(XXX)-XXX-XXXX"
                          wrapperClass="vs-con-input"
                          class="w-full"
                          inputClass="vs-inputx vs-input--input normal"
                          label="Phone Number"
                        />
                      </div>
                    </div>

                    <span
                      class="text-danger text-sm"
                      v-show="errors.has('companyphone')"
                    >{{ errors.first("companyphone") }}</span>
                  </div>
                </div>
                <div class="vx-col md:w-1/2 w-full">
                  <div class="vs-component vs-input w-full vs-input-primary">
                    <div class="vs-con-input">
                      <vs-input
                        v-mask="'(###)-###-####'"
                        v-model="petitioner.fax"
                        name="fax"
                        v-validate="'phonevalid'"
                        data-vv-as="Fax Phone Number"
                        placeholder="(XXX)-XXX-XXXX"
                        wrapperClass="vs-con-input"
                        class="w-full"
                        inputClass="vs-inputx vs-input--input normal"
                        label="Fax Phone Number"
                      />
                    </div>
                  </div>

                  <span
                    class="text-danger text-sm"
                    v-show="errors.has('fax')"
                  >{{ errors.first("fax") }}</span>
                </div>
            
                <div class="vx-col md:w-1/2 w-full">
                  <div class="main-placeholder right info-right">
                 <!-- v-validate="'required'" -->
                    <vs-input
                      :maxlength="'15'"
                      class="w-full"
                      v-model="petitioner.naicsCode"
                     
                      name="naicsCode"
                      label="NAICS Code (as per Tax Return)"
                      data-vv-as="NAICS Code (as per Tax Return)"
                      placeholder="NAICS Code (as per Tax Return)"
                    />
                    <span
                      class="text-danger text-sm"
                      v-show="errors.has('naicsCode')"
                    >{{ errors.first("naicsCode") }}</span>
                  </div>
                </div>
                <!-- <div class="vx-col md:w-1/2 w-full mt-5">
                        <vs-select v-model="city" class="w-full select-large" label="City">
                            <vs-select-item :key="index" :value="item.value" :text="item.text" v-for="(item,index) in cityOptions" class="w-full" />
                        </vs-select>
                </div>-->
              </div>
            </div>
          </vs-col>
          <div class="divider"></div>
          <vs-col
            class="m-auto float-none"
            vs-type="flex"
            vs-justify="center"
            vs-align="center"
            vs-lg="8"
            vs-sm="12"
          >
            <div class="form-container">
              <h3 class="small-header">Address</h3>
              <div class="vx-row">
                <div class="vx-col md:w-1/2 w-full">
                  <vs-input
                    v-model="petitioner.address.line1"
                    name="line1"
                    class="w-full"
                    label="Street Address"
                    placeholder="Address"
                    data-vv-as="Address"
                    v-validate="'required'"
                  />
                  <span
                    class="text-danger text-sm"
                    v-show="errors.has('line1')"
                  >{{ errors.first("line1") }}</span>
                </div>
                <div class="vx-col md:w-1/2 w-full">
                  <vs-input
                    v-model="petitioner.address.line2"
                    class="w-full"
                    name="line2"
                    label="Apt, Suite"
                    placeholder="Address"
                    data-vv-as="Address"
                  />
                  <span
                    class="text-danger text-sm"
                    v-show="errors.has('line2')"
                  >{{ errors.first("line2") }}</span>
                </div>
                <div class="vx-col md:w-1/2 w-full">
                  <div class="con-select w-full select-large">
                    <label for class="vs-select--label">Country</label>
                    <multiselect
                      name="country"
                      v-validate="'required'"
                      v-model="countryModel"
                      :disabled="true"
                      @select="selectCountry"
                      :show-labels="false"
                      track-by="id"
                      label="name"
                      placeholder="Select Country"
                      :options="countries"
                      :searchable="true"
                      :allow-empty="false"
                      data-vv-as="Select Country"
                    ></multiselect>
                  </div>

                  <span
                    class="text-danger text-sm"
                    v-show="errors.has('country')"
                  >{{ errors.first("country") }}</span>
                </div>
                <div class="vx-col md:w-1/2 w-full">
                  <div class="con-select w-full select-large">
                    <label for class="vs-select--label">State</label>
                    <multiselect
                      name="state"
                      v-validate="'required'"
                      v-model="stateModel"
                      @select="selectState"
                      :show-labels="false"
                      track-by="id"
                      label="name"
                      placeholder="Select State"
                      :options="states"
                      :searchable="true"
                      :allow-empty="false"
                      data-vv-as="Select State"
                    ></multiselect>
                  </div>

                  <span
                    class="text-danger text-sm"
                    v-show="errors.has('state')"
                  >{{ errors.first("state") }}</span>
                </div>
                <div class="vx-col md:w-1/2 w-full">
                  <div class="con-select w-full select-large">
                    <label for class="vs-select--label">City</label>
                    <multiselect
                      name="city"
                      v-validate="'required'"
                      v-model="locationModel"
                      @select="selectLocation"
                      :show-labels="false"
                      track-by="id"
                      label="name"
                      placeholder="Select City"
                      :options="locations"
                      :searchable="true"
                      :allow-empty="false"
                      data-vv-as="Select City"
                    ></multiselect>
                  </div>

                  <span
                    class="text-danger text-sm"
                    v-show="errors.has('city')"
                  >{{ errors.first("city") }}</span>
                </div>
                <div class="vx-col md:w-1/2 w-full">
                  <vs-input
                    name="zipcode"
                    v-model="petitioner.address.zipcode"
                    v-validate="'numeric|required|min:5|max:5'"
                    class="w-full"
                    label="Zip Code"
                    plceholder="Zip Code"
                    data-vv-as="Zip Code"
                  />

                  <span
                    class="text-danger text-sm"
                    v-show="errors.has('zipcode')"
                  >{{ errors.first("zipcode") }}</span>
                </div>
              </div>
            </div>
          </vs-col>
          <div class="divider"></div>
          <vs-col
            class="m-auto float-none"
            vs-type="flex"
            vs-justify="center"
            vs-align="center"
            vs-lg="8"
            vs-sm="12"
          >
            <div class="form-container">
              <h3 class="small-header">Representative/Authorized signatory</h3>
              <div class="vx-row">
                <div class="vx-col w-full">
                  <vx-input-group class="form-input-group">
                    <vs-input
                      name="firstName"
                      class="w-full"
                      v-model="petitioner.authorizedSignatory.firstName"
                      v-validate="'required'"
                      label="First Name"
                      plceholder="First Name"
                      data-vv-as="First Name"
                    />
                    <vs-input
                      name="middleName"
                      class="w-full"
                      v-model="petitioner.authorizedSignatory.middleName"
                      label="Middle Name"
                      data-vv-as="Middle Name"
                      plceholder="Middle Name"
                    />
                    <vs-input
                      name="lastName"
                      class="w-full"
                      v-model="petitioner.authorizedSignatory.lastName"
                      v-validate="'required'"
                      label="Last Name"
                      data-vv-as="Last Name"
                      plceholder="Last Name"
                    />
                  </vx-input-group>
                  <div class="input-group-error">
                    <p class="w-1/3">
                      <span
                        class="text-danger text-sm"
                        v-show="errors.has('firstName')"
                      >{{ errors.first("firstName") }}</span>
                    </p>
                    <p class="w-1/3"></p>
                    <p class="w-1/3">
                      <span
                        class="text-danger text-sm"
                        v-show="errors.has('lastName')"
                      >{{ errors.first("lastName") }}</span>
                    </p>
                  </div>
                </div>
                <div class="vx-col w-full">
                  <div class="main-placeholder right info-right">
               
                    <vs-input
                      class="w-full"
                      name="title"
                      v-model="petitioner.authorizedSignatory.title"
                      v-validate="'required'"
                      label="Title"
                      data-vv-as="Title"
                      plceholder="Title"
                    />
                  </div>
                  <span
                    class="text-danger text-sm"
                    v-show="errors.has('title')"
                  >{{ errors.first("title") }}</span>
                </div>
                <div class="vx-col md:w-1/2 w-full">
                  <vs-input
                    name="email"
                    v-model="petitioner.authorizedSignatory.email"
                    v-validate="'required|email'"
                    class="w-full"
                    label="Email"
                    data-vv-as="Email"
                    plceholder="Email"
                  />
                  <span
                    class="text-danger text-sm"
                    v-show="errors.has('email')"
                  >{{ errors.first("email") }}</span>
                </div>
                <div class="vx-col md:w-1/2 w-full">
                  <div class="vs-component vs-input w-full vs-input-primary">
                    <vs-input
                      v-mask="'(###)-###-####'"
                      v-model="petitioner.authorizedSignatory.phone"
                      name="authorizedSignatoryphone"
                      v-validate="'required|phonevalid'"
                      data-vv-as="Phone Number"
                      placeholder="(XXX)-XXX-XXXX"
                      wrapperClass="vs-con-input"
                      class="w-full"
                      inputClass="vs-inputx vs-input--input normal"
                      label="Phone Number"
                    />
                  </div>
                  <span
                    class="text-danger text-sm"
                    v-show="errors.has('authorizedSignatoryphone')"
                  >{{ errors.first("authorizedSignatoryphone") }}</span>
                </div>
              </div>
            </div>
          </vs-col>
        </tab-content>
        <!-- tab 2 content -->
        <tab-content title="Business Information">
          <vs-col
            class="m-auto float-none"
            vs-type="flex"
            vs-justify="center"
            vs-align="center"
            vs-lg="8"
            vs-sm="12"
          >
            <div class="form-container mt-12">
              <div class="vx-row">
                <div class="vx-col w-full">
                  <label class="custom-label">Briefly describe the nature of your business</label>
                  <!-- <vs-textarea
                    v-model="petitioner.natureOfBusiness"
                    name="natureOfBusiness"
                    v-validate="'required'"
                    class="w-full"
                    data-vv-as="Nature Of Business"
                  /> -->
                  <ckeditor v-model="petitioner.natureOfBusiness"
                    name="natureOfBusiness"
                    v-validate="'required'"
                    class="w-full"
                    data-vv-as="Nature Of Business"  :editor="editor" :config="editorConfig"></ckeditor>
                  <span
                    class="text-danger text-sm"
                    v-show="errors.has('natureOfBusiness')"
                  >{{ errors.first("natureOfBusiness") }}</span>
                </div>
                <div class="vx-col md:w-1/2 w-full">
                  <label class="date-picker-label">Date of business was established</label>
                  <div class="main-placeholder right">
                    <!-- <i class="placeholder-icon IP-calendar-1"></i> -->
                    <datepicker  :typeable="true"
                      icon-pack="IntakePortal"
                      icon-after
                      name="businessEstdDate"
                      v-model="petitioner.businessEstdDate"
                      v-validate="'required'"
                      icon="IP-calendar-1"
                      data-vv-as="Business established date"
                      placeholder="MM/DD/YYYY"
                      :open-date="new Date(openDate)"
                      :disabled-dates="{from: new Date(startEligibleDate)}"
                    ></datepicker>
                    <span
                      class="text-danger text-sm"
                      v-show="errors.has('businessEstdDate')"
                    >{{ errors.first("businessEstdDate") }}</span>
                  </div>
                </div>
                <div class="vx-col md:w-1/2 w-full">
                  <vs-input
                    name="totalFullTimeEmployees"
                    v-model="petitioner.totalFullTimeEmployees"
                    class="w-full"
                    data-vv-as="Number Of Employees"
                    v-validate="'numeric|required'"
                    label="Total number of full-time employees"
                  />
                  <span
                    class="text-danger text-sm"
                    v-show="errors.has('totalFullTimeEmployees')"
                  >{{ errors.first("totalFullTimeEmployees") }}</span>
                </div>
              </div>
            </div>
          </vs-col>
          <div class="divider" v-if="petitioner.totalFullTimeEmployees >= 50"></div>
          <vs-col
            class="m-auto float-none"
            vs-lg="8"
            vs-sm="12"
            v-if="petitioner.totalFullTimeEmployees >= 50"
          >
            <div class="alert-content-block">
              <p>Are 50 or more individuals employed in United States?</p>
              <vs-button
                class="mr-5"
                v-bind:class="{
                  cactive: petitioner.are50orMoreEmployeesInUS == 'yes'
                }"
                @click="petitioner.are50orMoreEmployeesInUS = 'yes'"
                color="success"
                type="border"
              >Yes</vs-button>
              <vs-button
                v-bind:class="{
                  cactive: petitioner.are50orMoreEmployeesInUS == 'no'
                }"
                @click="petitioner.are50orMoreEmployeesInUS = 'no'"
                color="danger"
                type="border"
              >No</vs-button>
            </div>
          </vs-col>
          <div class="divider"></div>
          <vs-col class="m-auto float-none" vs-lg="8" vs-sm="12">
            <div class="alert-content-block">
              <p>
                Are more than 50 percent of those employees in
                <br />H-1B, L-1A or L-1B nonimmigrant status?
              </p>
              <vs-button
                v-bind:class="{
                  cactive: petitioner.areAbove50PercentH1BL1ALABStatus == 'yes'
                }"
                @click="petitioner.areAbove50PercentH1BL1ALABStatus = 'yes'"
                class="mr-5"
                color="success"
                type="border"
              >Yes</vs-button>
              <vs-button
                v-bind:class="{
                  cactive: petitioner.areAbove50PercentH1BL1ALABStatus == 'no'
                }"
                @click="petitioner.areAbove50PercentH1BL1ALABStatus = 'no'"
                color="danger"
                type="border"
              >No</vs-button>
              <vs-alert v-if="petitioner.areAbove50PercentH1BL1ALABStatus == 'yes'"
                active="true"
                class="h-auto primary-alert mt-5"
              >An additional $4000 must be paid to the Department of Homeland Security towards Border Security Fee.</vs-alert>
            </div>
          </vs-col>
          <div class="divider"></div>

          <vs-col class="m-auto float-none" vs-lg="8" vs-sm="12">
            <div class="form-container clear_both">
              <div class="vx-row">
                <div class="vx-col md:w-1/2 w-full">
               
                  <vs-input
                    class="w-full"
                    label="Estimated gross annual income"
                    name="estimatedGrossAnualIncome"
                    data-vv-as="Estimated gross annual income"
                    v-validate="'required|minval:1'"
                    v-model="petitioner.estimatedGrossAnualIncome"
                  />
                  <span
                    class="text-danger text-sm"
                    v-show="errors.has('estimatedGrossAnualIncome')"
                  >{{ errors.first("estimatedGrossAnualIncome") }}</span>
                </div>
                <div class="vx-col md:w-1/2 w-full">
                  <vs-input
                    class="w-full"
                    name="estimatedNetAnualIncome"
                    v-model="petitioner.estimatedNetAnualIncome"
                    v-validate="'required'"
                    data-vv-as="Estimated net annual income"
                    label="Estimated net annual income"
                  />
                  <span
                    class="text-danger text-sm"
                    v-show="errors.has('estimatedNetAnualIncome')"
                  >{{ errors.first("estimatedNetAnualIncome") }}</span>
                </div>
              </div>
            </div>
          </vs-col>
          <div class="text-danger text-sm formerrors" v-show="formerrors.msg">
            <vs-alert
              color="warning"
              class="warning-alert reg-warning-alert no-border-radius"
              icon-pack="IntakePortal"
              icon="IP-information-button"
              active="true"
            >{{ formerrors.msg }}</vs-alert>
          </div>
        </tab-content>
        <vs-popup
          class="holamundo success-popups"
          title="Your registration is complete."
          :active.sync="popupActive"
        >
          <figure>
            <img src="@/assets/images/main/icon-note.svg" alt="login" class="mx-auto" />
          </figure>
          <h2 class="title">Your registration is complete.</h2>
          <p>
            {{smessage}}
          </p>
        </vs-popup>
      </form-wizard>
    </vx-card>
  </div>
</template>
<script>
import { FormWizard, TabContent } from "vue-form-wizard";
import "vue-form-wizard/dist/vue-form-wizard.min.css";
import Datepicker from "vuejs-datepicker-inv";
import _ from "lodash";
import PhoneMaskInput from "vue-phone-mask-input";
import JQuery from "jquery";
import Vue from 'vue';
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';

export default {
  data() {
    return {
      editor: ClassicEditor,
 editorConfig: {
     toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
 },
      formerrors: {
        msg: "",
      },
      smessage:null,
      openDate: new Date().setFullYear(new Date().getFullYear()),
      startEligibleDate: new Date().setFullYear(new Date().getFullYear()),
      popupActive: false,
      petitioner: {
        name: "",
        phone: "",
        fax: "",
        irstaxId: "",
        naicsCode: "",
        address: {
          line1: "",
          line2: "",
          locationId: "",
          stateId: "",
          countryId: 231,
          zipcode: "",
        },
        authorizedSignatory: {
          name: "",
          firstName: "",
          middleName: "",
          lastName: "",
          title: "",
          email: "",
          phone: "",
          phoneCountryCode: "",
        },
        natureOfBusiness: "",
        businessEstdDate: "",
        totalFullTimeEmployees: "",
        are50orMoreEmployeesInUS: "",
        areAbove50PercentH1BL1ALABStatus: "",
        finalDeterminationFromDOL: "",
        estimatedNetAnualIncome: "",
        estimatedGrossAnualIncome: "",
      },
      countries: [],
      countryModel: {
        _id: "5db7f7409419e34350f11024",
        id: 231,
        name: "United States",
      },
      states: [],
      stateModel: [],
      locations: [],
      locationModel: [],
    };
  },
  computed: {},
  methods: {
    beforeTabSwitch() {
      return this.vaidateFirstStep();
    },
    async vaidateFirstStep() {
      const result = await this.$validator.validateAll().then((result) => {
        var container = document.querySelector("#CompanyDetails0");
        const children = container.querySelectorAll(".text-danger");
        var errorcount = _.filter(children, function (item) {
          return item.style.display == "";
        });
        if (result) {}
        return errorcount.length == 0;
      });
      if (result) {
        this.$validator.reset();
        window.scroll({
          top: 0,
          left: 0,
          behavior: "smooth",
        });
      } else {
        const $ = JQuery;
        const firstField = Object.keys(this.errors.collect())[0];
        const ele = $("[name=" + firstField + "]").parents(".vx-col");
        $("html, body").animate({ scrollTop: ele.offset().top }, 2000);
      }
      return result;
    },
    setAre50(item, value) {
      this.item = value;
    },
    reloadthePage() {
      this.$router.go("/");
    },
    formSubmitted() {
      this.$validator.validateAll().then((result) => {
        if (result) {
          this.$store
            .dispatch("petitioner/completeregistration", this.petitioner)
            .then((response) => {
              if (response.error) {
                Object.assign(this.formerrors, {
                  msg: response.error.message,
                });
              } else {
                this.smessage = response.data.result.message;
                this.popupActive = true;
                document.addEventListener("click", this.reloadthePage);
              }
            })
            .catch(() => {

              
            });
        } else {
          const $ = JQuery;
          const firstField = Object.keys(this.errors.collect())[0];
          const ele = $("[name=" + firstField + "]").parents(".vx-col");
          $("html, body").animate({ scrollTop: ele.offset().top }, 2000);
        }
      });
    },
    selectLocation(option) {
      this.petitioner.address.locationId = option.id;
    },
    selectState(option) {
      this.petitioner.address.stateId = option.id;
      this.locationModel = [];
      this.getLocation();
    },
    selectCountry(option) {
      this.petitioner.address.countryId = option.id;
    },
    getLocation() {
      var obj = {
        stateId: this.petitioner.address.stateId,
        countryId: this.petitioner.address.countryId,
      };

      this.$store.dispatch("getlocations", obj).then((response) => {
        this.locations = response;
      });
    },
  },
  
   beforeDestroy(){
              document.removeEventListener('click', this.reloadthePage);
   },
  mounted() {
    if (this.$store.state.user != null) {
      this.petitioner.name = this.$store.state.user.name;
    }

    this.$store.dispatch("getcountries").then((response) => {
      this.countries = response;
    });

    this.$store
      .dispatch("getstates", this.petitioner.address.countryId)
      .then((response) => {
        this.states = response;
      });
  },
  components: {
    FormWizard,
    TabContent,
    Datepicker,
    PhoneMaskInput,
  },
};
</script>
