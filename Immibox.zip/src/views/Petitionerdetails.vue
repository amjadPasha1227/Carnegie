<template>
<div class="main-tabs-content">
    <!-- header area-->
    <div class="tabs-layout-header">
        <div class="tabs-layout-header-items w-full client-details_tab">
            <div class="items-left" v-if="petitioner.registrationCompleted">
                <h2 class="small-header">{{petitioner.name}}

                </h2>

            </div>
            <div class="items-left" style="background:none;width:auto" v-if="!petitioner.registrationCompleted">

                <ul class="items-list">
                    <li>
                        Client Name
                        <span>
                            {{petitioner.name}}
                        </span> </li>
                    <li>
                        Email
                        <span>
                            {{petitioner.petitionerUserDetails.email}}
                        </span> </li>

                </ul>
            </div>
            <div class="items-right">

                <ul>

                    <li v-if="petitioner.registrationCompleted && petitioner.statusDetails.id == 2">
                        <vs-button class="actions-btn2">
                            <span class="quickbook_action" v-if="!petitioner['qbCustomerId'] " @click="qb_link_customer=true;selected_customer={}">
                                Link Customer to QuickBooks
                            </span>
                            <span v-if="petitioner['qbCustomerId'] " class="status_linked">
                                QuickBooks Linked
                            </span>
                        </vs-button>
                    </li>
                    <li v-if="petitioner.registrationCompleted">
                        <div class="dropdown-button-container">

                            <vs-button>
                                <span class="status_registered status_approved" v-bind:class="{
                    status_registered: petitioner.statusDetails.id == 1,
                    status_approved: petitioner.statusDetails.id == 2,
                    status_rejected: petitioner.statusDetails.id == 3
                  }">
                                    {{petitioner.statusDetails.name}}
                                </span>

                            </vs-button>
                            <vs-dropdown v-if="petitioner.statusDetails.id!=2 && petitioner.statusDetails.id!=5">
                                <vs-button class="btn-drop">
                                    Actions
                                    <i class="material-icons">arrow_drop_down</i>
                                </vs-button>
                                <vs-dropdown-menu class="actions-dropdown">
                                    <vs-dropdown-item v-if="petitioner.statusDetails.id != 2">
                                        <vs-checkbox @click="updatestatus(2,'Approved')" v-model="approved">Approve</vs-checkbox>
                                    </vs-dropdown-item>
                                    <vs-dropdown-item v-if="petitioner.statusDetails.id != 3">
                                        <vs-checkbox @click="updatestatus(3,'On Hold')" v-model="onhold">On Hold</vs-checkbox>
                                    </vs-dropdown-item>

                                </vs-dropdown-menu>
                            </vs-dropdown>

                             <vs-dropdown
                  v-if="petitioner.comments && petitioner.comments.length > 0"
                  vs-custom-content
                  vs-trigger-hover
                  class="msg_dropdown_icon"
                >
                  <a class="a-icon" href.prevent>
                    <img src="@/assets/images/main/message_icon.svg" />
                  </a>

                  <vs-dropdown-menu class="loginx msg_dropdown">
                   <span style="padding:10px 0px;">  <p >{{petitioner.comments[0].comment }}</p>  </span>
                  </vs-dropdown-menu>
                </vs-dropdown>



                        
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <!-- content section start here-->
    <div class="tabs-content 1 ffffffffffffffffffffff">

        <div class="main-list-wrap" v-if="petitioner && petitioner.name && !petitioner.registrationCompleted">

            <div class="status-popup text-center">
                <figure>
                    <img src="@/assets/images/main/professional.svg">
                </figure>
                <p>{{ petitioner.alertMessage }}</p>
            </div>

        </div>

        <!-- <vs-tabs v-if="petitioner.registrationCompleted"> -->
            <vs-tabs>
            <vs-tab>
                <vs-tabs position="left" color="danger" v-model="active_tab">
                    <!-- Company Details start here -->
                    <vs-tab label="Company Details">
                        <div class="tab-inner-content">
                            <div class="tabs-content-panel tab-pad-wrap">

                                <div class="main-list-wrap" v-if="petitioner.registrationCompleted">
                                    <div class="vx-row m-0 main-list-panel">
                                        <div class="vx-col md:w-1/2 w-full p-0">
                                            <div class="main-list">
                                                <p>
                                                    Full legal name of your company
                                                    <span>{{petitioner.name}}</span>
                                                </p>
                                            </div>
                                        </div>
                                   
                                    </div>
                                    <div class="vx-row m-0 main-list-panel">
                                        <div class="vx-col md:w-1/2 w-full p-0">
                                            <div class="main-list">
                                                <p>
                                                    NAICS Code (as per Tax Return)
                                                    <span>{{petitioner.naicsCode}}</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="vx-col md:w-1/2 w-full p-0">
                                            <div class="main-list">
                                                <p>
                                                    Phone Number
                                                    <span>
                                                    <template v-if="checkProperty(petitioner ,'phoneCountryCode' ,'countryCallingCode')">{{checkProperty(petitioner ,"phoneCountryCode" ,'countryCallingCode')+"&nbsp;"}} </template>{{petitioner.phone}}
                                                    </span>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="vx-row m-0 main-list-panel">
                                        <div class="vx-col md:w-1/2 w-full p-0">
                                            <div class="main-list">
                                                <p>
                                                    Fax Number
                                                    <span>{{petitioner.fax | formatPhone}}</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="vx-col md:w-1/2 w-full p-0">
                                            <div class="main-list">
                                                <p>
                                                    Address
                                                    <span v-html="$options.filters.addressformat(petitioner.address)"></span>
                                                </p>
                                            </div>
                                        </div>
                                    </div>

                                    <h3 class="small-header mt-8">Representative/Authorized Signatory </h3>
                                    <div class="vx-row m-0 main-list-panel">
                                        <div class="vx-col w-full p-0">
                                            <div class="main-list">
                                                <p>
                                                    Name
                                                    <span>{{petitioner.authorizedSignatory.title}} {{petitioner.authorizedSignatory.name}} </span>
                                                </p>
                                            </div>
                                        </div>
                                        <!-- <div class="vx-col md:w-1/2 w-full p-0">
                                            <div class="main-list">
                                                <p>
                                                    Title
                                                    <span>{{petitioner.authorizedSignatory.title}}</span>
                                                </p>
                                            </div>
                                        </div> -->
                                    </div>
                                    <div class="vx-row m-0 main-list-panel">
                                        <div class="vx-col md:w-1/2 w-full p-0">
                                            <div class="main-list">
                                                <p>
                                                    Email
                                                    <span>{{petitioner.authorizedSignatory.email}}</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="vx-col md:w-1/2 w-full p-0">
                                            <div class="main-list">
                                                <p>
                                                    Phone Number
                                                    <span>{{petitioner.authorizedSignatory.phone}}</span>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </vs-tab>
                    <!-- Business Information start here -->
                    <vs-tab label="Business Information" v-if="petitioner.registrationCompleted">
                        <div class="tab-inner-content">
                            <div class="tabs-content-panel tab-pad-wrap">
                                <div class="main-list-wrap">
                                    <div class="vx-row m-0 main-list-panel">
                                        <div class="vx-col md:w-1/2 w-full p-0">
                                            <div class="main-list">
                                                <p>
                                                    Briefly describe the nature of your business
                                                    <span v-html="petitioner.natureOfBusiness"></span>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="vx-col md:w-1/2 w-full p-0">
                                            <div class="main-list">
                                                <p>
                                                   Date of business was established
                                                    <span>{{petitioner.businessEstdDate | formatDate}}</span>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="vx-row m-0 main-list-panel">
                                        <div class="vx-col md:w-1/2 w-full p-0">
                                            <div class="main-list">
                                                <p>
                                                    Total number of full-time employees
                                                    <span>{{petitioner.totalFullTimeEmployees}}</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="vx-col md:w-1/2 w-full p-0">
                                            <div class="main-list">
                                                <p>
                                                    Are 50 or more individuals employed in United States?
                                                    <span style="text-transform: capitalize;">{{petitioner.are50orMoreEmployeesInUS}}</span>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="vx-row m-0 main-list-panel">
                                        <div class="vx-col md:w-1/2 w-full p-0">
                                            <div class="main-list">
                                                <p>
                                                    Are more than 50 percent of those employees in
                                                    <br />H-1B, L-1A or L-1B nonimmigrant status?
                                                    <span style="text-transform: capitalize;">{{petitioner.areAbove50PercentH1BL1ALABStatus}}</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="vx-col md:w-1/2 w-full p-0">
                                            <div class="main-list">
                                                <p>
                                                    Estimated net annual income
                                                    <span>$ {{petitioner.estimatedNetAnualIncome}}</span>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="vx-row m-0 main-list-panel">
                                        <div class="vx-col md:w-1/2 w-full p-0">
                                            <div class="main-list">
                                                <p>
                                                    Final determination from DOL or Federal Arbitrator of willful
                                                    violation of any H1B program requirement within 5 years of date.
                                                    <span style="text-transform: capitalize;">{{petitioner.finalDeterminationFromDOL}}</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="vx-col md:w-1/2 w-full p-0">
                                            <div class="main-list">
                                                <p>
                                                    Estimated gross annual income
                                                    <span>$ {{petitioner.estimatedGrossAnualIncome}}</span>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </vs-tab>


                    <vs-tab :label="'Company Docs '" >
                        <CompanyDocsTemplates  :uploadCompanyDocs="true" @updatepetition ="getpetetioner" :currentUser="currentUserId" v-bind:currentRole="currentRole" @download_or_view="download_or_view"  v-bind:petition="petitioner"  />
                    </vs-tab>
                </vs-tabs>
            </vs-tab>
            
        </vs-tabs>
    </div>
    <vs-popup class="holamundo main-popup" title="Comments" v-if="updatestatuspop" :active.sync="updatestatuspop">
        <form>
            <div class="form-container">
                <div class="vx-row">
                    <div class="vx-col w-full">
                        <!-- <vs-textarea v-model="comment" name="comment" label="Write a Comment…" v-validate="'required'" class="w-full" /> -->
                        <ckeditor v-model="comment" name="comment" label="Write a Comment…" v-validate="'required'" class="w-full"  :editor="editor" :config="editorConfig"></ckeditor>

                    </div>
                    <span class="text-danger text-sm" v-show="errors.has('comment')">{{ errors.first("comment") }}</span>

                </div>
            </div>
            <div class="popup-footer">
                <vs-button color="success" @click="postStatus" class="save" type="filled">Update</vs-button>
            </div>
        </form>
    </vs-popup>

    <vs-popup class="holamundo main-popup" title="Link Customer to QuickBooks" v-if="qb_link_customer" :active.sync="qb_link_customer">
        <div class="form-container padb30">
            <div class="vx-row">

                <div class="vx-col w-full">
                    <label class="typo__label">Choose Customer</label>

                    <multiselect v-model="selected_customer" :options="customers_list" :multiple="false" :close-on-select="true" :clear-on-select="false" :preserve-search="true" placeholder="Choose Customer" label="name" track-by="name" :preselect-first="false">
                        <template slot="selection" slot-scope="{ values, search, isOpen }"><span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">{{ values.length }} options selected</span></template>
                    </multiselect>

                    <p style="padding:15px 0px;"> Not found in the list? <a href="javascript:;" @click="createQucikBooks()">Create </a> Customer in QuickBooks

                    </p>
                </div>
            </div>
        </div>
        <div class="popup-footer">
            <vs-button color="dark" class="cancel" @click="qb_link_customer=false" type="filled">Cancel</vs-button>
            <vs-button color="success" class="save " @click="link_customer()" type="filled">Save</vs-button>
        </div>
    </vs-popup>

    <vs-popup class="holamundo success-popups documents_popup" :title="checkProperty(selectedFile,'name')"  :active.sync="docPrivew">
        <h2></h2>
        <div>
            <img :class="{'pdf_view_download':docType == 'pdf', 'office_view_download':docType == 'office'  , 'image_view_download':docType =='image'}" class="download-button" @click="downloads3file(selectedFile)" src="@/assets/images/download.svg" />
            <span :class="{'pdf_view_close':docType == 'pdf', 'office_view_close':docType == 'office'  , 'image_view_close':docType =='image'}" class="close close2" @click="docPrivew= false">dscdscsdc</span>
            <template v-if="docType=='office'">
                <VueDocPreview :value="docValue" type="office" />
            </template>
            <template v-else-if="docType == 'image'">
                <img :src="docValue">
            </template>
            <template v-else-if="docType == 'pdf'">
                <div class="pdf">
                    <object :data="docValue" type="application/pdf" width="1000" height="600" v-if="docPrivew">
                        alt : <a :href="docValue">PDF</a>
                    </object>
                </div>
            </template>
        </div>
    </vs-popup>


</div>
</template>

<script>
import moment from 'moment'
import * as oAuthClient from 'intuit-oauth';
import CompanyDocsTemplates from  "./petition/CompanyDocsTemplates";
import Vue from 'vue';
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';

export default {
     components: {
       
        CompanyDocsTemplates
    },
    data() {
        return {
            editor: ClassicEditor,
 editorConfig: {
     toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
 },
            docPrivew: false,
            docValue: '',
            docType: "",
            selectedFile: null,


              currentRole: null,
             currentUserId: null,
            selected_customer: {},
            qb_link_customer: false,
            petitioner: [],
            updatestatuspop: false,
            companyId: null,
            comment: null,
            statusId: 0,
            arppoved: true,
            onhold: false,
            rejected: true,
            active_tab: 0,
            tabs: [{
                index: 0
            }, {
                index: 1
            }],
            billAddr: {},
            notes: '',
            customers_list: [],
        };
    },
    methods: {
        download_or_view(value) {
            if (_.has(value, "path")) {
                value['url'] = value['path'];
                value['document'] = value['path'];
            }

            if (_.has(value, "url")) {
                value['path'] = value['url'];
                value['document'] = value['url'];
            }

            if (_.has(value, "document")) {
                value['path'] = value['document'];
                value['url'] = value['document'];
            }

            this.selectedFile = value;
            this.docValue = '';
            this.docPrivew = false;
            this.docType = false;
            this.docType = this.findmsDoctype(value);

            if (this.docType == "office" || this.docType == "image") {

                value.url = value.url.replace(this.$globalgonfig._S3URL, "");
                value.url = value.url.replace(this.$globalgonfig._S3URLAWS, "");
                let postdata = {
                    keyName: value.url
                };
                this.$store.dispatch("getSignedUrl", postdata).then((response) => {
                    this.docValue = response.data.result.data;

                    if (this.docType == "office") {
                        this.docValue = encodeURIComponent(response.data.result.data);
                    }
                    this.docPrivew = true;
                });

            } else {

                this.downloads3file(value);
            }

        },

        checkCustomerAvailability() {
            let newPetitionerPayload = {
                billAddr: this.billAddr,
                notes: this.notes,
                displayName: this.petitioner.authorizedSignatory.name,
                primaryPhone: {
                    "FreeFormNumber": this.petitioner.phone
                },
                primaryEmail: {
                    "Address": this.petitioner.authorizedSignatory.email
                }
            }
            let postdata = {
                email: this.petitioner.authorizedSignatory.email,
            }
            Object.assign(postdata, newPetitionerPayload);

            this.$store.dispatch("checkPetitionerAvailability", postdata)
                .then(response => {
                   

                }).catch(err => {})
        },
        updatestatus(statusId, statusName) {
            this.updatestatuspop = true;
            this.statusId = statusId;
            this.statusName = statusName;
            this.currentDate = moment().format('YYYY-MM-DD');
            this.companyId = this.$route.params.itemId;
        },
        postStatus() {
            var $this = this;
            this.$validator.validateAll().then(result => {
                if (result) {
                    this.postStausupdate();
                }

            })

        },
        postStausupdate() {
            this.$store
                .dispatch("petitioner/updatecompanystatus", {
                    companyId: this.companyId,
                    statusId: this.statusId,
                    statusName: this.statusName,
                    currentDate: this.currentDate,
                    comment: this.comment
                })
                .then(response => {
                    this.$router.go(this.$route.name);
                });
        },
        getpetetioner() {
            var companyId = this.$route.params.itemId;
            this.$store
                .dispatch("petitioner/getpetetioner", {
                    companyId: companyId
                })
                .then(response => {
                    this.petitioner = response;
                    this.petitioner['petitionerId'] = response['userId'];
                   // alert(this.petitioner['petitionerId']);
                    if (this.petitioner.address.locationDetails != null) {
                        this.billAddr = {
                            "Line1": this.petitioner.address.line1,
                            "City": this.petitioner.address.locationDetails.name,
                            "Line2": this.petitioner.address.line2,
                            "Country": this.petitioner.address.countryDetails.name,
                            "CountrySubDivisionCode": this.petitioner.address.stateDetails.name,
                            "PostalCode": this.petitioner.address.zipcode,
                        }

                    }

                    if (this.petitioner.statusDetails.id == 3) {
                        this.approved = false;
                        this.onhold = true;
                        this.rejected = false;
                    }
                    if (this.petitioner.statusDetails.id == 4) {
                        this.approved = false;
                        this.onhold = false;
                        this.rejected = true;
                    }
                    //  alert(this.petitioner['qbCustomerId']);
                    this.get_customers_list();
                });
        },
        get_customers_list() {

            let postData = {};
            this.$store.dispatch("get_customers_list", postData)
                .then(response => {
                    this.customers_list = response;

                });

        },
        createQucikBooks() {
            let postData = {
                "companyId": this.petitioner['_id'],
                "name": this.petitioner.name,
                "email": this.petitioner.authorizedSignatory.email,
                "phone": this.petitioner.phone,
                "line": this.petitioner.address.line1,
                "city": this.petitioner.address.locationDetails.name,
                "country": this.petitioner.address.countryDetails.name,
                "state": this.petitioner.address.stateDetails.name,
                "zipcode": this.petitioner.address.zipcode,
            }

            this.$store.dispatch("createQucikBooks", postData)
                .then(response => {

                    //  alert(JSON.stringify(response));
                    this.$vs.notify({
                        title: "Success",
                        position: "top-right",
                        color: "primary",
                        text: response["message"]
                    });
                    this.getpetetioner();
                    this.qb_link_customer = false;

                    //this.qconfig  = response['result'];

                });

        },
        link_customer() {

            if (this.selected_customer['_id'] && this.petitioner['_id']) {
                let postData = {
                    "companyId": this.petitioner['_id'],
                    "customerId": this.selected_customer['_id']
                }

                this.$store.dispatch("link_customers_qb", postData)
                    .then(response => {

                        //  alert(JSON.stringify(response));
                        this.$vs.notify({
                             title: "Success",
                            text: response["message"],
                            title: "Success",
                             position: "top-right",
                            color: "primary",
                        });
                        this.getpetetioner();
                        this.qb_link_customer = false;

                        //this.qconfig  = response['result'];

                    });

            }
        }

    },
    mounted() {
         this.currentRole = this.$store.state.user.loginRoleId;
         this.currentUserId = this.$store.state.user._id;

        this.getpetetioner();
        // this.fetchAccessToken();

    }
};
</script>
