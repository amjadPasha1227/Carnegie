<template>
  <div>
    <div class="content-header">
      <div class="content-header-left">
        <div class="search petition-search">
          <vs-input icon-pack="feather" icon="icon-search" v-model="searchtxt" placeholder="Search by Name/Email/Phone"
            class="is-label-placeholder" />
        </div>
      </div>
      <!-- getTenantTypeId!=2 && -->

      <div class="content-header-right">
        <!--filter dropdown-->
        <vs-dropdown vs-custom-content vs-trigger-click>
          <vs-button color="primary" class="filter-btn" type="border" icon-pack="feather" icon="icon-chevron-down"
            icon-after>
            <img src="@/assets/images/main/icon-filter.svg" /> Filters
          </vs-button>
          <vs-dropdown-menu ref="filter_menu" class="filters-content">

            <div class="filters-form-fileds">
              <div class="form-container">
                <div class="vx-row">
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Status</label>
                    <multiselect v-model="selected_statusids" :options="allCompany_status" :multiple="true"
                      :hideSelected="true" :close-on-select="true" :clear-on-select="false" :preserve-search="true"
                      :select-label="''" placeholder="Select Status" label="name" track-by="name"
                      :preselect-first="false">
                      <!-- <template slot="selection" slot-scope="{ values, search, isOpen }">
                        <span
                          class="multiselect__single"
                          v-if="values.length &amp;&amp; !isOpen"
                        >{{ values.length }} options selected</span>
                      </template> -->
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          options selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>

                   <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Case Type </label>
                    <multiselect @input="changedVsaType" v-model="filteredVisaType" :options="visatypes"
                      :multiple="false" :close-on-select="true" :clear-on-select="false" :preserve-search="true"
                      placeholder="Select Case Type" label="name" track-by="name" :preselect-first="false">
                      <template slot="selection" slot-scope="{ values,  isOpen }"><span class="multiselect__single"
                          v-if="values.length &amp;&amp; !isOpen">{{ values.length }} Case Type
                          selected</span></template>
                    </multiselect>
                  </div>

                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Case Subtype</label>
                    <multiselect v-model="filteredVisaSubTypes" :options="allsubTyps" :multiple="true"
                      :hideSelected="true" :close-on-select="false" :clear-on-select="false" :preserve-search="true"
                      :select-label="''" placeholder="Select Case Subtypes" label="name" track-by="name"
                      :preselect-first="false">

                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          options selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>



                  <!--
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Country</label>
                    <multiselect  @input="changedCountry()" v-model="selected_country_obj" :options="all_countries"  :multiple="false"
                     :close-on-select="true" :clear-on-select="false" :preserve-search="true" placeholder="Select Country" label="name" track-by="name" :preselect-first="false">
                      <template slot="selection" slot-scope="{ values,  isOpen }"><span class="multiselect__single" v-if="values.length &amp;&amp; !isOpen">{{ values.length }} options selected</span></template>
                    </multiselect>
                  </div>

                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">States</label>
                    <multiselect 
                      @input="changedState()"
                      v-model="seleted_states"
                      :options="all_states"
                      :multiple="false"
                      :close-on-select="true"
                      :select-label="''"
                      :clear-on-select="true"
                      :preserve-search="true"
                      placeholder="Select States"
                      label="name"
                      track-by="name"
                      :preselect-first="false"
                    >
                     
                      <template slot="selection" slot-scope="{ values, isOpen }">
                          <span
                          class="multiselect__selectcustom"
                          v-if="values.length && !isOpen"
                          >{{ values.length }} States selected</span
                          >
                          <span
                          class="multiselect__selectcustom"
                          v-if="values.length && isOpen"
                          ></span>
                        </template>
                    </multiselect>
                  </div>
                  
                  <div class="vx-col md:w-1/3 w-full con-select">
                    

                    <label class="typo__label">Locations</label>
                    <multiselect
                      
                      v-model="seleted_locations"
                      :options="all_locations"
                      :multiple="true" :hideSelected="true"
                      :close-on-select="true"
                      :clear-on-select="false"
                      :preserve-search="true"
                       :select-label="''"
                      placeholder="Select Locations"
                      label="name"
                      track-by="name"
                      :preselect-first="false"
                    >
                      
                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && !isOpen"
                        >{{ values.length }} Locations selected</span
                        >
                        <span
                        class="multiselect__selectcustom"
                        v-if="values.length && isOpen"
                        ></span>
                      </template>
                    </multiselect>
                  </div>
                  -->
                  <!-- <div class="vx-col md:w-1/3 w-full con-select"
                    v-if="getTenantTypeId!=2 && [1,2,50,51].indexOf(getUserRoleId)<=-1">
                    <label class="typo__label">Select Petitioner</label>
                    <multiselect v-model="selectedPetitionerforFilter" :options="petitionersList" :multiple="true"
                      :hideSelected="false" :close-on-select="false" :clear-on-select="false" :preserve-search="true"
                      :select-label="'Search Petitioner'" placeholder="Select Petitioner" label="name" track-by="name"
                      :preselect-first="false" :searchable="true">

                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          options selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div> -->
                  <div class="vx-col md:w-1/3 w-full con-select">
                    <label class="typo__label">Created Date</label>
                    <date-range-picker :autoApply="autoApply" :ranges="false" :maxDate="new Date()"
                      v-model="selected_createdDateRange"></date-range-picker>
                  </div>

                </div>
              </div>
            </div>
            <div class="filters-status">
              <div class="left-buttons">

              </div>
              <div class="right-buttons">
                <vs-button color="success" class="save" type="filled" v-on:click="set_filter()">Apply</vs-button>
                <vs-button color="dark" class="cancel" type="filled" v-on:click="clear_filter($event)">Clear</vs-button>
              </div>
            </div>
          </vs-dropdown-menu>
        </vs-dropdown>
        <!-- end -->
        <!-- <vs-button color="primary" type="border" class="light-blue-btn" @click="addNewBeneficiary()"
          v-if="checkBeneficaryInvitePermisions && false">Invite <span>
            <img class="add-user-icon ml-2" src="@/assets/images/main/add-user.svg">
          </span></vs-button> -->
        <vs-button type="border" v-if="checkPetInvitePermisions" class="light-blue-btn"
          @click="invitePetitionPopupshow(true)">Invite Individual<span>
            <img class="add-user-icon ml-2" src="@/assets/images/main/add-user.svg">
          </span>
        </vs-button>
      </div>
    </div>

    <NoDataFound ref="NoDataFoundRef" :loading="isListloading" v-if="users.length == 0"
      :content="callFromSerch?'No Results Found':''" heading="No Results Found" type='Beneficiaries' />
   
    <div class="accordian-table accordian-overley" v-if="users.length>0">
      <vs-table :data="users" class="individual_table" :no-data-text="'No data found...!'">
        <template slot="thead">
          <!--  
        
        "createdOn", // invitedByName, updatedOn, name, email, phone, statusName, roleName--->
          <vs-th><a @click="sortMe('name')" v-bind:class="{
            sort_ascending: sortKeys['name'] == 1,
            sort_descending: sortKeys['name'] != 1,
          }">Name</a></vs-th>
          <!-- <vs-th v-if="[1,2,50].indexOf(getUserRoleId)<=-1 && checkProperty(getUserData['tenantDetails']['typeDetails'],'id') != 2">
            Petitioner
          </vs-th> -->
          <vs-th><a @click="sortMe('email')" v-bind:class="{
            sort_ascending: sortKeys['email'] == 1,
            sort_descending: sortKeys['email'] != 1,
          }">Email</a></vs-th>
          <vs-th>Total Cases</vs-th>
          <vs-th>Active Cases</vs-th>
          <vs-th class="actions">Actions</vs-th>
        </template>

        <template slot-scope="{data}">
            <tbody>
          <vs-tr :data="tr" :key="indextr" v-for="(tr, indextr) in data" class="cursor-pointer">
            <vs-td :data="tr.username">
              <span class="cursor-pointer">
                <img class="user-image" src="@/assets/images/main/avatar2.svg" />
                <!-- <a href="">{{tr.name}}</a> -->
                {{tr.name}}
              </span>
            </vs-td>
            <!-- <vs-td v-if="[1,2,50].indexOf(getUserRoleId)<=-1 && checkProperty(getUserData['tenantDetails']['typeDetails'],'id') != 2">
              <span class="cursor-pointer">
                {{checkProperty(tr,'petitionerDetails','name')}} </span>
            </vs-td> -->

            <vs-td :data="tr.email">
              <template v-if="checkIsTempAccount(tr.email)">
                <span class="cursor-pointer">
                  {{tr.email}}
                </span>
              </template>
            </vs-td>

            <vs-td :data="tr.totalPetitionCount">
              <span class="cursor-pointer">
                <span class="count ">{{tr.totalPetitionCount}}</span>
              </span>
            </vs-td>

            <vs-td :data="tr.activePetitionCount">
              <span class="cursor-pointer">
                <span class="count ">{{tr.activePetitionCount}}</span>
              </span>
            </vs-td>
            <vs-td>
              <!-- <vs-dropdown class="msg_dropdown_icon" :vs-trigger-click="true">
                  <a class="a-icon" href.prevent><more-vertical-icon size="1.5x" class="custom-class"></more-vertical-icon></a>
                 <vs-dropdown-menu class="loginx msg_dropdown">                    
                    <vs-dropdown-item @click="opneDetails(tr);formerrors.msg='';NewPetition=false;selectedUser=tr._id;selectedUseremail=tr.email;selectedUsername=tr.name"> 
                        Details
                    </vs-dropdown-item>
                    <vs-dropdown-item v-if="checkCaseCreatePermisions"  @click="openNewPetitionPopUp(true ,tr);formerrors.msg='';NewPetition=true;selectedUser=tr._id;selectedUseremail=tr.email;selectedUsername=tr.name"> 
                        New Case
                    </vs-dropdown-item>
                    <vs-dropdown-item v-if="[3,4,5,7].indexOf(getUserRoleId)>-1" @click="showSetPassword(true ,tr);formerrors.msg='';NewPetition=false"> 
                        Set Password
                    </vs-dropdown-item>
                    <vs-dropdown-item v-if="[3,4,5,7].indexOf(getUserRoleId)>-1 && checkProperty(tr ,'statusDetails','id') <=1"  @click="resend(tr);formerrors.msg='';NewPetition=false"> 
                        Resend Activation Link
                    </vs-dropdown-item>                    
                   </vs-dropdown-menu> 

                </vs-dropdown> -->
              <div class="menu_dropdown flexible_actions">
                <a class="a-icon" href.prevent>
                  <more-vertical-icon size="1.5x" class="custom-class"></more-vertical-icon>
                </a>
                <div class="menu_list_wrap">
                  <ul class="menu_list">
                    <li class="menu_item"
                      @click="opneDetails(tr);formerrors.msg='';NewPetition=false;selectedUser=tr._id;selectedUseremail=tr.email;selectedUsername=tr.name">
                      Details
                    </li>
                    <!-- <li class="menu_item" v-if="checkCaseCreatePermisions"
                      @click="openNewPetitionPopUp(true ,tr);formerrors.msg='';NewPetition=true;selectedUser=tr._id;selectedUseremail=tr.email;selectedUsername=tr.name">
                      New Case
                    </li> -->
                    <li class="menu_item" v-if="[3,4,5,7].indexOf(getUserRoleId)>-1 && tr.statusId !=3 && tr.statusId !=4"
                      @click="showSetPassword(true ,tr);formerrors.msg='';NewPetition=false">
                      Set Password
                    </li>
                    <li class="menu_item"
                      v-if="[3,4,5,7].indexOf(getUserRoleId)>-1 && [1].indexOf(checkProperty(tr,'companyStatusDetails','id'))>-1 && tr.statusId !=3 && tr.statusId !=4"
                      @click="showSetUpdate(true ,tr);formerrors.msg='';">
                      Update Status
                    </li>
                    <li class="menu_item"
                      v-if="[3,4,5,7].indexOf(getUserRoleId)>-1 && checkProperty(tr ,'statusDetails','id') <=1 && tr.statusId !=3 && tr.statusId !=4"
                      @click="resend(tr);formerrors.msg='';NewPetition=false">
                      Resend Activation Link
                    </li>
                    <!-- <li class="menu_item"
                      v-if="[3].indexOf(getUserRoleId)>-1"
                      @click="conformDeleteWall(tr);errorMsg='';NewPetition=false">
                      Delete
                    </li> -->
                    <li class="menu_item"
                      v-if="[3].indexOf(getUserRoleId) > -1 && tr.statusId==3 && tr.statusId !=2"
                      @click="conformDeleteWall(tr ,2);errorMsg='';NewPetition=false">
                      Active
                    </li>
                    <li class="menu_item"
                      v-if="[3].indexOf(getUserRoleId) > -1 && tr.statusId==2 && tr.statusId !=3"
                      @click="conformDeleteWall(tr ,3);errorMsg='';NewPetition=false">
                      Inactive
                    </li>
                    <li class="menu_item"
                      v-if="[3].indexOf(getUserRoleId) > -1 && tr.statusId !=4 "
                      @click="conformDeleteWall(tr ,4);errorMsg='';NewPetition=false">
                      Delete
                    </li>
                  </ul>
                </div>
              </div>


            </vs-td>
            <template class="expand-user" slot="expand">
              <div class="con-expand-users">
                <div>
                  <vs-table :data="tr.petitions" :no-data-text="'No Cases are filed'">
                    <template slot="thead">
                      <vs-th>Case No</vs-th>
                      <vs-th>Case Type</vs-th>
                      <vs-th>Client</vs-th>
                      <vs-th>Start Date</vs-th>
                      <vs-th>Status</vs-th>
                    </template>

                    <template>
                      <vs-tr :key="ind" v-for="(petition, ind) in tr.petitions">
                        <vs-td :data="petition.caseNo">
                          <span style="cursor:pointer" @click="gotoDetailsPage(petition['_id'],petition['subType'])">
                            {{petition.caseNo}}

                            <button v-if="petition.status" class="btn active-green">Active</button>
                          </span>
                        </vs-td>

                        <vs-td class="td_label">{{ checkProperty(petition ,'typeDetails','name')}}
                          <small> {{ checkProperty(petition ,'subTypeDetails','name') }} </small>
                        </vs-td>

                        <vs-td>
                          <span v-if="checkProperty(petition ,'clientInfo' ,'name')">
                            {{petition.clientInfo.name}}
                          </span>
                        </vs-td>
                        <vs-td>{{petition.createdOn | formatDate}}</vs-td>

                        <vs-td>
                          <!-- <span class="status_active">{{checkProperty(petition ,'statusDetails','name')}}</span> -->
                          <span class="statusspan "  v-bind:class="{
                  'status_created': checkProperty(petition ,'statusDetails','id') == 1,
                  'status_submited': checkProperty(petition ,'statusDetails','id') == 2,
                  'status_inProcess': checkProperty(petition ,'statusDetails','id') == 3,
                  'status_pwd_filed': checkProperty(petition ,'statusDetails','id') == 4,
                  'status_sent_for_signatures': checkProperty(petition ,'statusDetails','id') == 6,
                  'staus_filed_with_USCIS': checkProperty(petition ,'statusDetails','id') == 7,
                  'status_ready_for_filing': checkProperty(petition ,'statusDetails','id') == 8,
                  'status_sent_for_signatures': checkProperty(petition ,'statusDetails','id') == 9,
    
                  
                  'status_certified': checkProperty(petition ,'statusDetails','id') == 11 || checkProperty(petition ,'statusDetails','id') == '11',
                  'response_to_RFE_Filed': checkProperty(petition ,'statusDetails','id') == 12,
                  'response_to_audit': checkProperty(petition ,'statusDetails','id') == 13,
                  'supervisory_to_audit': checkProperty(petition ,'statusDetails','id') == 14,
                  'status_pwd_filed': checkProperty(petition ,'statusDetails','id') == 15,
                  'status_pwd_response': checkProperty(petition ,'statusDetails','id') == 16,
                  'staus_advertisements': checkProperty(petition ,'statusDetails','id') == 17,
                  'Status_received_by_USCIS': checkProperty(petition ,'statusDetails','id') == 19,
                  'Perm_drft_approved': checkProperty(petition ,'statusDetails','id') == 20,
                  'Perm_submited_dol': checkProperty(petition ,'statusDetails','id') == 21,
                  'status_approved': checkProperty(petition ,'statusDetails','id') == 22,
                  'status_denied': checkProperty(petition ,'statusDetails','id') == 23,
                  'status_supervisory_audit': checkProperty(petition ,'statusDetails','id') == 28,
                  
                }">{{ checkProperty(petition ,'statusDetails','name') }}</span>
                        </vs-td>
                      </vs-tr>
                    </template>
                  </vs-table>


                </div>
              </div>
            </template>
          </vs-tr>
            </tbody>
        </template>
      </vs-table>
      
      <div class="table_footer">
        <div class="vx-col  con-select pages_select" v-if="users.length > 0">
            <label class="typo__label">Per Page</label>
            <multiselect @input="changeperPage()" v-model="perpage" :options="perPeges" :multiple="false"
              :close-on-select="true" :clear-on-select="false" :preserve-search="true" placeholder="Per Page"
              :preselect-first="true">

            </multiselect>
            <span class="totla_list_count" v-if="totalCount"> Total <em>{{totalCount}} </em></span>
          </div>
      <paginate v-if="users.length>0" v-model="page" :page-count="totalpages" :page-range="3" :margin-pages="2"
        :click-handler="pageNate" prev-class="vs-pagination--buttons btn-prev-pagination vs-pagination--button-prev"
        next-class="vs-pagination--buttons btn-next-pagination vs-pagination--button-next" :prev-text="'<i></i>'"
        :next-text="'<i></i>'" :container-class="'pagination vs-pagination--nav'" :page-class="'page-item'"></paginate>
      </div>
    </div>
    
    <vs-popup class="holamundo main-popup" title="Invite Individual" v-if="invitepetitioner"
      :active.sync="invitepetitioner">
      <form>
        <div class="form-container">
          <div class="vx-row">
            <!--  <div class="vx-col w-full">
              <div class="form_group">
                <label class="form_label">Company Name<em>*</em></label>
                <vs-input @click="formerrors.msg=''" type="text" class="w-full no-icon-border" name="company name"
                  data-vv-as="Company Name" v-model="new_user.name" v-validate="'required'" />
                <span class="text-danger text-sm" v-show="errors.has('company name')">{{ errors.first("company name")
                  }}</span>
              </div>
            </div> -->

            <div class="vx-col w-1/2">
              <div class="form_group">
                <label class="form_label">First Name<em>*</em></label>
                <vs-input type="text" class="w-full no-icon-border" name="adminFirstName" data-vv-as="First Name"
                  v-model="new_user.adminFirstName" v-validate="'required'" />
                <span class="text-danger text-sm" v-show="errors.has('adminFirstName')">{{
                errors.first("adminFirstName") }}</span>
              </div>
            </div>
            <div class="vx-col w-1/2">
              <div class="form_group">
                <label class="form_label"> Last Name</label>
                <vs-input type="text" class="w-full no-icon-border" name="adminLastName" data-vv-as="Last Name"
                  v-model="new_user.adminLastName" v-validate="''" />
                <span class="text-danger text-sm" v-show="errors.has('adminLastName')">{{ errors.first("adminLastName")
                }}</span>
              </div>

            </div>

            <div class="vx-col w-1/2">
              <div class="form_group">
                <label class="form_label">Email ID<em>*</em></label>
                <vs-input v-model="new_user.email" class="w-full no-icon-border" key="email" name="email"
                  data-vv-as="Email" autocomplete="off" autocorrect="off" autocapitalize="none"
                  v-validate="'required|email'" />
                <span class="text-danger text-sm" v-show="errors.has('email')">{{ errors.first("email") }}</span>
              </div>
            </div>
            <div class="vx-col w-1/2" @click="formerrors.msg=''">
              <div class="form_group ph_number">
                <div class="vs-component">
                  <label for="" class="form_label">Phone Number<em>*</em></label>
                  <VuePhoneNumberInput autocomplete="off" autocorrect="off" icon-pack="feather"
                    class="w-full no-icon-border" :no-example="false" v-validate="'required'" data-vv-as="Phone Number"
                    name="phone" v-bind="vuePhone.props" default-country-code="US" placeholder="Number"
                    :no-country-selector="false" v-model="new_user.phone" @update="updatePhone" :preferred-countries="['US', 'IN']" />
                  <span class="text-danger text-sm" v-show="!isPhoneValid && !errors.has('phone')">*Invalid phone number
                    - Please enter a valid one</span>
                  <span class="text-danger text-sm" v-show="errors.has('phone')">{{ errors.first("phone") }}</span>
                </div>
              </div>
            </div>

          </div>

          <div class="text-danger text-sm formerrors" v-show="formerrors.msg">
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
              icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
          </div>
        </div>
        <div class="popup-footer relative">
          <figure v-if="inviting" class="loader"><img src="@/assets/images/main/loader.gif" /></figure>
          <vs-button color="dark" @click="invitePetitionPopupshow(false)" class="cancel" type="filled">Cancel
          </vs-button>
          <vs-button :disabled="inviting" color="success" @click="petitionerInvite()" class="save" type="filled">Submit</vs-button>
        </div>
      </form>
    </vs-popup>
    <vs-popup class="holamundo main-popup" :title="popUpTitle " :active.sync="deleteIndividualPopup">
        <div class="form-container">
          <div class="vx-row"  >
            <div class="vx-col w-full">
              <!-- <p>{{ popUpText }}</p> -->
              <p>Are you sure to continue?</p>
            </div>
                      
          </div>
          <div class="text-danger text-sm formerrors" v-show="errorMsg">
                <vs-alert
                  color="warning"
                  class="warning-alert reg-warning-alert no-border-radius"
                  icon-pack="IntakePortal"
                  icon="IP-information-button"
                  active="true"
                >{{ errorMsg }}</vs-alert>
          </div>
        </div>
        <div class="popup-footer relative">
           <span class="loader" v-if="loading" ><img src="@/assets/images/main/loader.gif"/></span>
          <vs-button color="dark" class="cancel" type="filled" v-on:click.stop.prevent="deleteIndividualPopup=false;">Cancel</vs-button>
          <vs-button v-if="selectedStatus==2" color="success" class="save" :disabled="loading" type="filled" v-on:click.stop.prevent="deleteIndividual(2)">
               
               Activate
       </vs-button>
       <vs-button v-else-if="selectedStatus==4" color="success" class="save" :disabled="loading" type="filled" v-on:click.stop.prevent="deleteIndividual(4)">
             
             Delete
             
      </vs-button>
      <vs-button v-else-if="selectedStatus==3" color="success" class="save" :disabled="loading" type="filled" v-on:click.stop.prevent="deleteIndividual(3)">
             
       Inactivate
             
      </vs-button>
        </div>
    </vs-popup>



    <!-- <vs-popup class="holamundo main-popup" :class="{'openedNewpetpopup':invitepetitioner || AddBeneficiary}"
      title="New Case" :active.sync="NewPetition">
      <form data-vv-scope="newpetitionform">
        <div class="form-container">
          <div class="vx-row" @keyup="formerrors.msg=''" @click="formerrors.msg=''">

            <template v-if="([3,4].indexOf(getUserRoleId)>-1 && getTenantTypeId !=2 ) && false">
              <div class="vx-col w-1/2">
                <div class="form_group">
                  <div class="con-select w-full select-large">
                    <label class="form_label">Select Petitioner<em>*</em></label>
                    <multiselect v-model="selectedPetitioner" :options="petitionersList" :multiple="false"
                      :hideSelected="false" :close-on-select="true" :clear-on-select="false" :preserve-search="true"
                      :select-label="'Search Petitioner'" placeholder="Select Petitioner" label="name" track-by="name"
                      :preselect-first="false" data-vv-as="Petitioner" v-validate="'required'"
                      tag-placeholder="Invite Petitioner" :taggable="false" @tag="addNewPet" :searchable="true"
                      @search-change="searchPet" @input="petitionerUpdated" name="Petitioner">

                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          options selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>
                  <span class="text-danger text-sm" v-show="errors.has('newpetitionform.Petitioner')">{{
                    errors.first("newpetitionform.Petitioner") }}</span>
                </div>
                <p v-if="checkPetInvitePermisions" class="createnew">Not found Petitioner?<span
                    @click="addNewPet()">Invite Petitioner</span> </p>
              </div>

              <div class="vx-col w-1/2">
                <div class="form_group">
                  <div class="con-select w-full select-large">
                    <label class="form_label">Select Beneficiary<em>*</em></label>
                    <multiselect v-model="selectedBeneficiary" :options="beneficiaryMasterDataList" :multiple="false"
                      :hideSelected="false" :close-on-select="true" :clear-on-select="false" :preserve-search="true"
                      :select-label="'Search Beneficiary'" placeholder="Select Beneficiary" label="name" track-by="name"
                      :preselect-first="false" data-vv-as="Beneficiary" v-validate="'required'" :searchable="true"
                      @search-change="getbeneficiaryMasterDataList" name="beneficiary" @input="upDateBenef"
                      tag-placeholder="Add New Beneficiary" :taggable="false" @tag="addNewBenFromTag"
                      :disabled="!checkProperty(selectedPetitioner ,'_id')">

                      <template slot="selection" slot-scope="{ values, isOpen }">
                        <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }}
                          options selected</span>
                        <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                      </template>
                    </multiselect>
                  </div>

                  <span class="text-danger text-sm" v-show="errors.has('newpetitionform.beneficiary')">{{
                    errors.first("newpetitionform.beneficiary") }}</span>

                </div>
                <p class="createnew" v-if="checkBeneficaryInvitePermisions">Not found?<span
                    @click="addNewBenFromTag()">Invite Beneficiary</span> </p>
              </div>
            </template>
            <template>
              <div class="vx-col w-1/2">
                <div class="form_group">
                  <div class="con-select w-full select-large">
                    <label for="" class="form_label">Case Type<em>*</em></label>
                    <multiselect name="visatype" data-vv-as="Case Type" v-validate="'required'" v-model="visatype"
                      :show-labels="false" track-by="id" label="name" placeholder="Select Case Type"
                      :options="visatypes" :searchable="true" :allow-empty="false" @input="getvisasubtypes">
                    </multiselect>
                  </div>
                  <span class="text-danger text-sm" v-show="errors.has('newpetitionform.visatype')">{{
                    errors.first("newpetitionform.visatype") }}</span>
                </div>
              </div>

              <div class="vx-col w-1/2">
                <div class="form_group">
                  <div class="con-select w-full select-large">
                    <label for="" class="form_label">Case Subtype<em>*</em></label>
                    <multiselect name="visasubtype" data-vv-as="Case Subtype" v-validate="'required'"
                      v-model="visasubtype" :show-labels="false" track-by="id" label="name"
                      placeholder="Select Case Subtype" :options="visasubtypes" :searchable="true" :allow-empty="false"
                      @input="formerrors.msg=''">
                    </multiselect>
                  </div>
                  <span class="text-danger text-sm" v-show="errors.has('newpetitionform.visasubtype')">{{
                    errors.first("newpetitionform.visasubtype") }}</span>
                </div>
              </div>

              <div class="vx-col w-full pp-col">
                <vs-checkbox id="premium" name="premiumProcessing" v-model="premiumProcessing">Premium Processing
                </vs-checkbox>

                

              </div>

              <div class="vx-col  w-full" v-if="getTenantTypeId !=2">
                <div class="form_group">
                  <div class="con-select w-full select-large">
                    <label for="" class="form_label">Branch<em>*</em></label>
                    <multiselect name="branch" v-validate="'required'" v-model="selectedBranch" :show-labels="false"
                      track-by="_id" label="name" placeholder="Select branch" :options="branchList" :searchable="true"
                      :allow-empty="false" :multiple="false" :disabled="branchList.length==1"
                      @input="formerrors.msg=''">
                    </multiselect>
                  </div>
                  <span class="text-danger text-sm" v-show="errors.has('newpetitionform.branch')">{{
                    errors.first("newpetitionform.branch") }}</span>
                </div>
              </div>
            </template>


          </div>


          <div class="text-danger text-sm formerrors" v-show="formerrors.msg">
            <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius" icon-pack="IntakePortal"
              icon="IP-information-button" active="true">{{ formerrors.msg }}</vs-alert>
          </div>
        </div>

        <div class="popup-footer">
          <vs-button color="dark" @click="NewPetition=false ;formerrors.msg=''" class="cancel" type="filled">Cancel
          </vs-button>
          <vs-button color="success" :disabled="!selectedBranch || newPetitionFormSubmited" @click="createNewPetition"
            class="save" type="filled">Submit</vs-button>
        </div>
      </form>



    </vs-popup> -->

    <!-- <vs-popup class="holamundo main-popup" title="Invite Petitioner" :active.sync="invitepetitioner">

      <addBenewPet @closenewPetPopup="closenewPetPopup" v-if="invitepetitioner" />
    </vs-popup> -->
    <!-- 
    <vs-popup class="holamundo main-popup" :class="{'openedNewpetpopup':invitepetitioner}" :title="'Add Beneficiary'"
      :active.sync="AddBeneficiary">
      <addNewbeneficiary ref="add_ben" @closeAddBenPopUp="closeAddBenPopUp" v-if="AddBeneficiary"
        :petitioner="selectedPetitioner" @openAddpetPopUp="openAddpetPopUp" />
    </vs-popup> -->

    <vs-popup class="holamundo main-popup" title="Set Password" :active.sync="setPassword">
      <form @submit.prevent>
        <div class="popup-accounts-content edit_password" v-if="setPassword">

          <div class="form-container" @click="setPasswordErrorMsg=''">
            <div class="form_group">
              <!-- <i class="placeholder-icon IP-hide-1"></i> -->
              <label class="form_label">New Password<em>*</em></label>
              <vs-input type="password" v-validate="'required|min:6|max:15|strongpassword'" data-vv-as="New Password"
                name="currentPassword" v-model="newPassword" class="w-full no-icon-border" ref="password" />
              <span class="text-danger text-sm" v-show="errors.has('currentPassword')">{{
              errors.first("currentPassword") }}<br /></span>
            </div>
            <div class="form_group">
              <!-- <i class="placeholder-icon IP-hide-1"></i> -->
              <label class="form_label">Confirm Password<em>*</em></label>
              <vs-input type="password" v-validate="'required|confirmed:password'" data-vv-as="Confirm Password"
                v-model="confPassword" name="newPassword" class="w-full no-icon-border" />
              <span class="text-danger text-sm" v-show="errors.has('newPassword')">{{
              errors.first("newPassword")
              }}</span>
            </div>

            <div v-if="setPasswordErrorMsg ">
              <vs-alert color="warning" class="warning-alert reg-warning-alert no-border-radius"
                icon-pack="IntakePortal" icon="IP-information-button" active="true">{{ setPasswordErrorMsg}}</vs-alert>
            </div>

          </div>
          <div class="popup-footer justify-between relative">
            <div class="password-count">
              <i class="icon IP-lock"></i> Password must contain 6 to 15 characters
            </div>

            <div class="d-flex">
              <vs-button color="dark" @click="setPassword=false ;updatingPassword=false" class="cancel" type="filled">
                Cancel</vs-button>

              <vs-button class="save w-auto" type="filled" @click="changePassword" :disabled="updatingPassword">
                <figure v-if="updatingPassword" class="loader"><img src="@/assets/images/main/loader.gif" /></figure>
                <template v-if="checkProperty(selectedIten ,'statusDetails','id') ==1">
                  Set Password
                </template>
                <template v-else>Update</template>


              </vs-button>
            </div>
          </div>
        </div>
      </form>
    </vs-popup>
    <vs-popup class="holamundo main-popup" title="Update Status" :active.sync="setUpdated">
      <form @submit.prevent>
        <div class="form-container pt-0">
          <div class="vx-row " v-if="setUpdated">

            <div class="vx-col w-full">
              <div class="form_group">
                <label class="typo__label">Select Status</label>
                <div class="con-select w-full select-large">

                  <multiselect name="Status" v-model="updateStatusId" :options="company_statusids" :multiple="false"
                    :hideSelected="true" :close-on-select="true" :clear-on-select="false" :preserve-search="true"
                    placeholder="Select Status" v-validate="'required'" label="name" track-by="id"
                    :preselect-first="false"
                    :disabled="[3,4].indexOf(checkProperty(setUpdateItem,'companyStatusDetails','id'))>-1">
                    <template slot="selection" slot-scope="{ values, isOpen }">
                      <span class="multiselect__selectcustom" v-if="values.length && !isOpen">{{ values.length }} Status
                        Selected</span>
                      <span class="multiselect__selectcustom" v-if="values.length && isOpen"></span>
                    </template>
                  </multiselect>
                </div>
                <span class="text-danger text-sm" v-show="errors.has('Status')">{{ errors.first("Status") }}</span>
              </div>
            </div>


            <div class="vx-col w-full">
              <label class="form_label">Comments<em>*</em></label>
              <div class="form_group">

                <!-- <vs-textarea data-vv-as="Comment" v-validate="'required'" v-model="commentText" name="comment"
                  class="w-full" /> -->
                  <ckeditor  data-vv-as="Comment" v-validate="'required'" v-model="commentText" name="comment"
                  class="w-full" :editor="editor" :config="editorConfig"></ckeditor>

                <span class="text-danger text-sm" v-show="errors.has('comment')">
                  {{ errors.first("comment") }}</span>
              </div>
            </div>


          </div>
        </div>
        <div class="popup-footer">
          <vs-button color="dark" @click="clearUpdated()" class="cancel" type="filled">Cancel</vs-button>
          <vs-button color="success" class="save" type="filled" @click="updatepet">Update</vs-button>
        </div>
      </form>
    </vs-popup>

  </div>
</template>

<script>

import NoDataFound from "@/views/common/noData.vue";
import Datepicker from "vuejs-datepicker-inv";
import Paginate from "vuejs-paginate";
import DateRangePicker from "vue2-daterange-picker";
import "vue2-daterange-picker/dist/vue2-daterange-picker.css";
import moment from 'moment'
import PhoneMaskInput from "vue-phone-mask-input";
import * as _ from "lodash";
import VuePhoneNumberInput from 'vue-phone-number-input';
import 'vue-phone-number-input/dist/vue-phone-number-input.css'; 
import addNewbeneficiary  from "@/views/common/addBeneficiary.vue" 
import addBenewPet  from "@/views/common/invitePet.vue" 
import { MoreVerticalIcon } from 'vue-feather-icons'
import Vue from 'vue';
Vue.use( CKEditor );
import CKEditor from '@ckeditor/ckeditor5-vue2';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
export default {
  components: {
    addNewbeneficiary,
    addBenewPet,
    NoDataFound,
    VuePhoneNumberInput,
    Datepicker,
    Paginate,
    DateRangePicker,
    moment,
    PhoneMaskInput,
    MoreVerticalIcon
  },
  data: () => ({
    inviting:false,
   //finalName:'',
   editor: ClassicEditor,
   editorConfig: {
     toolbar: [ 'bold', 'italic', '|', 'undo','redo'  ,'NumberedList', 'BulletedList', ],
  },
  setPassword:false,
   newPassword:'',
   confPassword:'',
   updatingPassword:false,
   setPasswordErrorMsg:'',
    setUpdated:false,
    selected_statusids:[],

    premiumProcessing:false,
    newPetOpenFromben:false,
    enableAddNewBenTag:false,
    invitepetitioner:false,
    openNewbenForm:false,
    selectedBeneficiary:null,
    beneficiaryMasterDataList:[],
    selectedIten:null,
     all_statusids:[],                

    addNewPete:false,
    isPetitionerPhoneValid:true,
    new_user: {
      name:'',
      firstName: "",
      lastName: "",
      adminFirstName: "",
      adminLastName: "",
      roleId: 12,
      email: "",
      phone: "",
      active: true,
      "accountType": "Individual",
        address: {
          "line1": "",
          "line2": "",
          "locationId": "",
          "stateId": "",
          "countryId": 231,
          "zipcode": ""
        }
      },
    selectedPetitioner:null,
    petitionersList:[],
    selectedPetitionerforFilter:[],
    enableAddNewpet:false,
    isListloading:false,
    sortKeys: {},
    sortKey: {},
    filteredVisaType:null,
    filteredVisaSubTypes:[],
    allsubTyps:[],
    isPhoneValid:true,
    callFromSerch:false,
    newPetitionFormSubmited:false,
    formerrors: {
      msg: ""
    },
    date: null,
    visatype:{
        id: 1,
        name: "H-1B"
      },
      vuePhone:{
        props:{
          translations:{
            phoneNumberLabel:"Phone Number"
          }
        }

      },
    visasubtype:null,
    selectedBranch:null,
    branchList:[],
    //visasubtype:null,
    selectedUser:null,
    selectedUsername:null,
    selectedUseremail:null,
    beneficiary: {
      name: "",
      email: "",
      phone:"",
      phoneCountryCode :{countryCode:'',countryCallingCode:''}
    },
    users: [],
    AddBeneficiary: false,
    NewPetition: false,
    visatypes:[],
    visasubtypes:[],
    searchtxt: "",
    query: [],
    country_code: 231,

    all_countries : [],
    selected_country_obj:'',
    filtered_country:'',

    all_statusids: [],
    selected_statusids: [],
    final_selected_statusids: [],
    allCompany_status: [],
    all_states: [],
    seleted_states: [],
    final_selected_states: [],
    singel_final_selected_state:'',
    // locationIds
    all_locations: [],
    seleted_locations: [],
    final_selected_locations: [],
    //date: "",
    date_range: [],
    page: 1,
    perPeges: [10,25,50,75,100],
    perpage: 50,
    totalCount:0,
    totalpages: 0,
    selected_createdDateRange:{},
    autoApply: "",
    saveBenbtn:false,
    commentText:'',
    updateStatusId: '',
    selectedItem:'',
    deleteIndividualPopup: false,
    selectedIndividualItem:null,
    errorMsg:'',
    popUpText:'',
    popUpTitle:'',
    selectedStatus:null,
    loading:false,
    encodedString:'',
  }),
  watch: {
    searchtxt: function(value) {
      this.getbeneficiaries(true);
    }
  },
  methods: {
    changeperPage(){       
          this.page = 1;
          this.getbeneficiaries(true); 
        },
    conformDeleteWall(item,statusId=0){
      this.selectedStatus = statusId
      this.popUpText  =''; 
       this.popUpTitle ='';
       if(this.selectedStatus ==2){
        this.popUpText  =' Are you sure Active this Beneficiary?'; 
        this.popUpTitle ="Active";
       }
       if(this.selectedStatus ==3){
        this.popUpText  ='Are you sure Inactive this Beneficiary?';
        this.popUpTitle ="Inactive";
       }

       if(this.selectedStatus ==4){
        this.popUpText  ='Are you sure Delete this Beneficiary?'; 
        this.popUpTitle =" Delete";
       }
        this.loading =false;
        this.deleteIndividualPopup =true;
        this.selectedIndividualItem = item;
        this.errorMsg ='';
    },
    deleteIndividual(statusId=0){
      
       let  postData={
        };
       postData['userId'] = this.selectedIndividualItem._id
       postData['statusId'] = this.selectedStatus
        postData['statusName']= '';
        if(this.selectedStatus ==2){
          postData['statusName']  ='Active'
       }
       if(this.selectedStatus ==3){
        postData['statusName']  ='Inactive' 
       }

       if(this.selectedStatus ==4){
        postData['statusName']  ='Delete' 
       }
       let path ="users/manage-status"
          this.loading =true;
          this.$store.dispatch("commonAction", {"data":postData ,"path":path})
        .then(response => {
          this.showToster({message:response.message,isError:false });
          this.loading =false;
          this.deleteIndividualPopup =false;
          this.selectedIndividualItem =null;
          this.getbeneficiaries();    
          this.errorMsg ='';                            
        }).catch((error)=>{
          //this.showToster({message:error,isError:true });
          this.loading =false;
          this.errorMsg =error;
        })
      },
    showSetUpdate(action = false, selectedItem = null) {
      this.selectedUserId = selectedItem;
      this.updateStatusId =null;
      this.commentText ='';
      this.setUpdateItem= selectedItem;
      this.setUpdated= action;
      this.$validator.reset();
     },
    getCompanyStatusList() {
  
   this.company_statusids = [];
   this.allCompany_status = [];
      let postdata = {
        page: 1,
        perpage: 1000,
        category: "company_status",
      };
  
      this.$store
        .dispatch("getMasterData", postdata)
        .then((res) => {
          this.allCompany_status = res["list"];
          this.company_statusids = res["list"];
          this.company_statusids = _.filter(this.company_statusids, (item) => {
            return [ 2, 3, 4].indexOf(item["id"]) > -1;
          });
         
        })
        .catch(() => {});
    },

     showSetPassword(action =false ,selectedItem=null){
     
        this.newPassword ='';
        this.confPassword = '';
        this.$validator.reset();
        this.selectedIten = selectedItem;
       
        this.setPassword =action;
        
         this.setPasswordErrorMsg = "";
          

      },
      clearUpdated(){
        this.setUpdated=false;
        this.setUpdateItem='';
        this.updateStatusId='';
        this.commentText = '';
        this.selectedUserId = '';

      },
    updatepet() {
      
        this.$validator.validateAll().then((result) => {
          if ( result ) {
            let Payload ={
          userId:this.checkProperty(this.selectedUserId,'_id'),
          statusId: this.updateStatusId.id, 
          statusName:this.updateStatusId.name,
          comment:this.commentText,
        };
            this.$store.dispatch("commonAction", { "data": Payload ,"path":"/users/update-customer-status"}).then((response) => {
          this.getbeneficiaries();
         this.setUpdated=false;
        }).catch((error)=>{})
        }
        })
       },
       changePassword() {
      this.$validator.validateAll().then((result) => {
        this.setPasswordErrorMsg ='';
        if (result) {
           
           let self =this;
          let postData = {
            newPassword: self.newPassword,
            currentPassword: self.confPassword,
            userId: self.selectedIten['_id'],
            //email: this.getUserData.email,
           // roleId: this.getUserRoleId,
         
          };
          ///auth/change-password,
          this.updatingPassword =true;
          this.$store.dispatch("commonAction", {"data":postData ,"path":"/auth/change-password"}).then((response) => {
              this.showToster({message:response.message,isError:false });
           
              // this.$vs.notify({ text: response.data.message, });
              this.setPassword = false;
              this.formerrors.msg = null;
              this.updatingPassword =false;
            
          }).catch((error)=>{
               this.setPasswordErrorMsg = error;
              this.updatingPassword =false;
          })
        }
      });
      },

    resend(item){
        this.selectedIten = item;
        
        let obj = { "email": this.selectedIten['email'] ,"tenantId":''};
        obj['tenantId'] = this.checkProperty(this.getUserData ,"tenantDetails","_id");
        this.$store
              .dispatch("resend", obj)
              .then(response => {
                   if (response.error) {
                  
                     this.showToster({message:response.error.message ,isError:true})
                } else {
                  this.showToster({message:response.data.message ,isError:false})
                  
                }
                
              })
              .catch((err)=>{
                this.showToster({message:err ,isError:true});

              });

      },
    openAddpetPopUp(){
      this.newPetOpenFromben =true;
      this.selectedPetitioner =null;
      this.invitepetitioner =true;
    },
    // closenewPetPopup(selectedPetitioner=null){

   
       
    //   this.getPetitioners();
    //    this.selectedPetitioner =selectedPetitioner;
    //    this.invitePetitionPopupshow(false);
    
    //    if( this.checkProperty(this.selectedPetitioner ,"userId")){
    //       this.openNewbenFormPopup(true);
    //    }else{
         
    //       this.openNewbenFormPopup(false);
          

    //    }
     

    // },
    upDateBenef(){
      if(this.checkProperty(this.selectedBeneficiary ,'name') && this.checkProperty(this.selectedBeneficiary ,'_id') ){
        this.selectedUser =this.checkProperty(this.selectedBeneficiary ,'_id');
        this.selectedUsername = this.checkProperty(this.selectedBeneficiary ,'name');
     }

    },
   closeAddBenPopUp(selectedBeneficiary=null){
     this.newPetOpenFromben =false;
      this.AddBeneficiary =false;
     
     this.selectedBeneficiary =selectedBeneficiary;
     if(this.checkProperty(this.selectedBeneficiary ,'name') && this.checkProperty(this.selectedBeneficiary ,'_id') ){
        this.selectedUser =this.checkProperty(this.selectedBeneficiary ,'_id');
        this.selectedUsername = this.checkProperty(this.selectedBeneficiary ,'name');
     }
    this.AddBeneficiary =false;
     this.getbeneficiaries();
   },
    opneDetails(tr){
      let itId = tr
      this.$router.push({ path: `/individuals-details/${itId['_id']}` ,query: {'filter':this.encodedString} }).catch(err => {})
      //this.$router.push("/beneficiaries-details/"+tr['_id'])
      //this.$router.push("/individuals-details/"+ tr['_id'])
    }, 
    petitionerUpdated(){
      this.selectedBeneficiary = null;
      this.selectedUser ='';
      this.selectedUsername = '';
      this.getbeneficiaryMasterDataList();
    },
    getbeneficiaryMasterDataList(text=''){
      let postData = {
          "matcher": {
            "title": text,
            "statusList": [],
            "branchIds": [],
            "companyIds": [], // Required only for Tenant Admin and Branch Manager to list Beneficiaries
            "createdByIds": [],
            "createdDateRange": [],
            "roleIds": [51],
            "statusIds": [],
            "petitionTypeIds": [],
            "petitionSubTypeIds": [],
            "petitionCreatedDateRange": [],
            "petitionStatusIds": [],
            "getPetitionStats": true
          },
        "sorting": {
          "path": "createdOn", // invitedByName, updatedOn, name, email, phone, statusName, roleName
          "order": 1
        },
        "page": 1,
        "perpage": 1000000,
        "getMasterData": true,
        "getBeneficiaryList": true, // Required only for Tenant Admin and Branch Manager to list Beneficiaries
        "branchId": "", // Required when 'getMasterData' is true and roleIds are [4, 5, 6, 7, 8, 9, 10, 11]
        "companyId": "" // Required when 'getMasterData' is true and roleIds are [50, 51]
	};
  this.enableAddNewBenTag =false;
    if(this.checkProperty(this.selectedPetitioner ,"_id")){

      postData['companyId'] = this.selectedPetitioner['_id']

    }
       //this.beneficiaryMasterDataList =[];
       this.$store
        .dispatch("petitioner/getbeneficiaries", postData)
        .then(response => {
          this.beneficiaryMasterDataList = response.list;

          let filteredData =[];
       _.forEach(this.beneficiaryMasterDataList ,(item)=>{
                if( item && ( _.has(item ,'name') || _.has(item ,'email')  )){

                         if((_.has(item ,'name') && item['name'].includes(searchText)) || (_.has(item ,'email') && item['email'].includes(searchText)) ){
                          filteredData.push(item)
                         }else{
                            return false;
                         }

                }else{
                  return false;
                }
              
           
         })

         if(filteredData.length<=0){
           this.enableAddNewBenTag =true;
         }


          })

    },

    // addNewBenFromTag(newBen=''){
    //   this.beneficiary['email'] =newBen;
    //   this.invitePetitionPopupshow(false)
    //   this.openNewbenFormPopup(true);

    // },

    

     searchPet(searchText){
          let _self =this;
     
      this.enableAddNewpet =false;
      this.selectedBeneficiary =null;
      this.selectedPetitioner =null;
      this.selectedUser ='';
      this.selectedUsername = '';
      this.newPetitioner.email =searchText;
      let filteredData =[];
       _.forEach(_self.petitionersList ,(item)=>{
                if( item && ( _.has(item ,'name') || _.has(item ,'email')  )){

                         if((_.has(item ,'name') && item['name'].includes(searchText)) || (_.has(item ,'email') && item['email'].includes(searchText)) ){
                          filteredData.push(item)
                         }else{
                            return false;
                         }

                }else{
                  return false;
                }
              
           
         })
       if( (filteredData.length<=0 )){

          //this.enableAddNewpet =true;
       // this   this.addNewPete = true;
         this.getPetitioners( true , searchText);
       }
         
     },
    //  addNewPet(newPet='' ,id){
    //    this.newPetOpenFromben =false;
    //    this.openNewbenForm =false;
    //    this.addNewPete =true;
    //    this.invitePetitionPopupshow(true)
    //  },

      updatePetitionerPhone(item) {
         
       this.isPetitionerPhoneValid =true;
      if (item.isValid) {
        
       this.newPetitioner.phoneCountryCode = {countryCode:item.countryCode,countryCallingCode:item.countryCallingCode};
       this.newPetitioner.phone = item.nationalNumber;
       
      }else{
        this.isPetitionerPhoneValid =false;
      }
     },

    //  openNewbenFormPopup(action =false){
    //    this.saveBenbtn =false;
    //    if(action==true){
    //      this.invitePetitionPopupshow(false);
    //    }
    //    if(action){

    //      if(this.checkProperty(this.selectedPetitioner ,'userId')){
          
    //         this.AddBeneficiary =true;
    //         try{
    //           setTimeout(()=>{
    //             this.$refs['add_ben'].setPetDetails(this.selectedPetitioner)

    //           } ,50)
    //         }catch(e){
    //         }
    //       }else{
    //         this.$validator.validateAll('newpetitionform').then((res)=>{

    //         });
    //          this.AddBeneficiary =false;
    //       }

    //    }else{
    //       this.AddBeneficiary =action;

    //    }
       
      
       
    //    this.$validator.reset();
    //  },
    petitionerInvite() {
      Object.assign(this.formerrors, { msg: '' });
      this.$validator.validateAll().then(result => {
        if (result && this.isPhoneValid) {
          this.inviting =true;
          let payload= _.cloneDeep(this.new_user)
          payload.name=this.checkProperty(this.new_user,'adminFirstName')+' '+this.checkProperty(this.new_user,'adminLastName')
          this.$store.dispatch("commonAction", {
            data: payload,
            path: "/auth/invite-petitioner",
          })
            .then(response => {
              this.inviting =false;
              if (response.error) {
                Object.assign(this.formerrors, {
                  msg: response.error.message
                });
              } else {

                this.showToster({ message: response.data.message, isError: false });
                this.getbeneficiaries();
              }
              this.invitePetitionPopupshow(false);

              // this.$router.go('/beneficiaries');
            }).catch((err) => {
              this.inviting =false;
              Object.assign(this.formerrors, {
                msg: err
              });

            })
        }
      });
    },
     invitePetitionPopupshow(action =true){
      this.inviting =false;
      //  this.invitepetitioner=action;
      // this.isPetitionerPhoneValid=true;
      // // this.$validator.reset();
     
       //this.new_user.name = Object.assign(this.new_user(adminFirstName + ' ' + adminLastName));
       //this.new_user = Object.assign(this.new_user,{ name: adminFirstName+' '+adminLastName  });
       this.new_user = {
        //  name: "",// adminFirstName + ' '+adminLastName
        // name: adminFirstName +' '+adminLastName,
         name:'',
         adminFirstName: "",
         adminLastName: "",
         email: "",
         phoneCountryCode: { countryCode: '', countryCallingCode: '' },
         roleId: 12,
         phone: "",
         invite: true,
         "accountType": "Individual"
       }
       this.invitepetitioner = action;
       this.isPhoneValid = true;
     },
    
      

      getPetitioners(callFromSerch=false,searchText='' ) {
      
        this.enableAddNewpet =false
        let _self =this;
        if(this.callFromSerch){
         
         // this.petitionersList =[];
        }
        let query ={
          "matcher":{
            "searchString": searchText,
            "statusIds": [],
            "countryIds": [],
            "stateIds": [],
            "locationIds": [],
            "createdDateRange": []
          },
        "sorting": { 	"path": "createdOn", 	"order": 1 	},
        "page": 1,
        "perpage": 100,
        getMasterData:true
	}
       
      
        this.$store
          .dispatch("getList",{data:query ,path:'/company/list'} )
          .then(response => {
            
            _self.petitionersList = response.list;

            let filteredData =  _.filter(_self.petitionersList ,(item)=>{
                if( item&& ( _.has(item ,'name') || _.has(item ,'email')  )){

                         if((_.has(item ,'name')&& item['name'].includes(searchText)) || (_.has(item ,'email') && item['email'].includes(searchText)) ){
                           return true;
                         }else{
                            return false;
                         }

                }else{
                  return false;
                }
              
           
         })
       
        if( callFromSerch && (!filteredData || (filteredData && filteredData.length<=0 ))  ){
         
          this.enableAddNewpet =true;
          this.addNewPete = true;
        }
       
          }).catch((err)=>{
            this.petitionersList =[];
           
          })
      },
   
    gotoDetailsPage(petitionId='',subType=0){
    
      if(petitionId !=''){
          if([15].indexOf(subType)>-1){
            
            this.$router.push("/gc-employment-details/"+petitionId);
          
          }else{
            this.$router.push("/petition-details/"+petitionId);
          }
         
        }

    },
    sortMe(sort_key = "") {
       this.sortKey = {
			"path": "createdOn", // invitedByName, updatedOn, name, email, phone, statusName, roleName
			"order": 1
		}
      if (sort_key != "") {
        this.sortKeys[sort_key] = this.sortKeys[sort_key] == 1 ? -1 : 1;
        localStorage.setItem("tickets_sort_key", sort_key);
        localStorage.setItem("tickets_sort_value", this.sortKey[sort_key]);

        this.sortKey ={"path":sort_key ,"order":parseInt(this.sortKeys[sort_key])};
        this.getbeneficiaries();
      }
    },
    
    changedVsaType(item){
      this.filteredVisaSubTypes = [] ;
      this.allsubTyps = [];
      this.filteredVisaType =item;
      if(this.filteredVisaType && _.has(this.filteredVisaType ,"id")){
        this.allsubTyps = [];
        let item ={
          matcher:{
             // "searchString":this.searchtxt,
            "petitionType": parseInt(this.filteredVisaType['id'])
          },   
          page:1,
          perpage: 10000,
          category: "petition_sub_types",
          
        };

        this.$store.dispatch("getMasterData",item ).then(response => { this.allsubTyps = response.list;  });
        }
    },
     
    // openNewPetitionPopUp(action=false ,item=null){
    //   this.newPetOpenFromben =false;
    //   this.invitepetitioner =false;
    //   this.openNewbenForm =false;
    //   this.selectedPetitioner =null;
    //   this.selectedBeneficiary =item;
    //    if(this.checkProperty(item ,'petitionerDetails')){
    //       this.selectedPetitioner =item['petitionerDetails'];
    //       this.getbeneficiaryMasterDataList();

    //    }
      
    //    this.getPetitioners( true , '');
      
    //   this.visatype = {
    //     id: 1,
    //     name: "H-1B"
    //   }
           
    //   if(this.visatypes.length > 0){
    //     this.visatype = _.find(this.visatypes, { "id": 1 });
    //        this.visaSUBtype = _.find(this.visatypes, { "id": 2 });
    //   }
      
    //   this.getvisasubtypes(this.visatype);
    //   Object.assign(this.formerrors, {
    //               msg: ''
    //             })
    //   this.newPetitionFormSubmited =false;
    //   this.NewPetition=action;
    //   this.$validator.reset();
    //   },
    addNewBeneficiary(){
      this.newPetOpenFromben =false;
      this.invitepetitioner =false;
      this.openNewbenForm=false;
      this.beneficiary = {
      firstName:'',
      lastName:'',  
      name: "",
      email: "",
      phone:"",
      phoneCountryCode :{countryCode:'',countryCallingCode:''}
    }
    Object.assign(this.formerrors, {
                  msg: ''  });
   
    this.AddBeneficiary = true;
   this.$validator.reset();
   this.isPhoneValid =true;
   this.saveBenbtn =false;
   this.getPetitioners( true , '');

    },
    updatePhone(item) {
         
       this.isPhoneValid =true;
      if (item.isValid) {
        
        this.new_user.phoneCountryCode = {countryCode:item.countryCode,countryCallingCode:item.countryCallingCode};
        this.new_user.phone = item.nationalNumber;
       
      }else{
        this.isPhoneValid =false;
      }
     },

    getBranchList(){
       this.selectedBranch = null;
       this.branchList = [];
       let postData = {
         "filters":{
           "title":"",
            "createdDateRange":[],
            "statusList":[],
            "activeList":[]
          },
       "getMasterData":true,
       "page":1,
       "perpage":25000,
       "sorting":{"path":"createdOn","order":-1}
       }
       this.$store.dispatch("getList" ,{data:postData,path:"/branch/list"})
       .then(response => {
         this.branchList = response.list;
         if(this.branchList.length ==1){
           this.selectedBranch = this.branchList[0];
         }
       })
       .catch(error => {

       })

    },
    goto(Id){
          this.$router.push({ name: 'petition-details', params: { itemId:Id } }).catch(err => {})
          // if(){
          //   this.$router.push({ name: 'gc-employment-details', params: { itemId:Id } }).catch(err => {})
          // }
    },
    createNewPetition(){
      Object.assign(this.formerrors, {
                  msg: ''
                })

            this.$validator.validateAll('newpetitionform').then(result => {
        if (result) {
          let self =this;
      var postdata ={
        type: this.visatype.id,
        userId:this.selectedUser,
        userName:this.selectedUsername,
        typeName:this.visatype.name,
        subType:this.visasubtype.id,
        subTypeName:this.visasubtype.name,
        premiumProcessing:this.premiumProcessing,
        petitionerId:null,
        branchId:'',
        today: moment().format('YYYY-MM-DD'),
      };
      if(this.getTenantTypeId !=2){
        if([50].indexOf(this.getUserRoleId) > -1){
           postdata['petitionerId'] = this.$store.state.user._id

        }else{
           postdata['petitionerId'] = this.checkProperty(this.selectedPetitioner ,"userId")
        }
       

      }
     
     
      if(this.selectedBranch && _.has(this.selectedBranch ,"_id")){
        postdata['branchId'] =this.selectedBranch['_id']
      }
      if(!this.newPetitionFormSubmited){
        this.newPetitionFormSubmited =true;
        this.$store.dispatch("petitioner/createnewpetition", postdata)
        .then(response => {
          this.premiumProcessing = false;
                 if (response.error) {
                Object.assign(this.formerrors, {
                  msg: response.error.message
                });
                this.newPetitionFormSubmited =false;
              } else {

                   let dt ={
                  petitionId: response._id,
                  userName: this.selectedUsername,
                  email: this.selectedUseremail,
                  typeName: this.visatype.name,
                  subTypeName: this.visasubtype.id,
                  instructions: null
                }
                      this.$store.dispatch("petitioner/sendquestionnaire", dt).then(response => { })
                       this.NewPetition =false; 
                      //this.$vs.notify({title: "Success",text: response.message });
                       this.showToster({message:response.message ,isError:false});
                       this.openNewPetitionPopUp(false);
                       setTimeout(() =>{
                        
                         if(self.checkProperty(self.selectedBeneficiary ,"anonymousUser" )){
                             self.goto(response._id);
                         }else{
                            self.goto(response._id);
                          // this.getbeneficiaries();

                         }
                       },50)
                     
              }

        })
        .catch((error)=>{
          //this.showToster({message:error,isError:true});
          this.newPetitionFormSubmited =false;
         
          Object.assign(this.formerrors, {
                  msg: error
                });
        
        });

      }
      
      
 } });
    },
    getbeneficiaries(callFromSerch=false) {
      this.callFromSerch = callFromSerch;
      let postData ={
         matcher:{
            roleIds: [50],
            title: this.searchtxt,
            searchString: this.searchtxt,
            statusIds: this.final_selected_statusids,
            "petitionTypeIds": [],
            "petitionSubTypeIds": [],
            "petitionSearchString": "",
            "petitionCreatedDateRange": [],
            "petitionStatusIds": [], 
            "getPetitionStats": true,
            "beneficiaryType": "individual-list", // beneficiary or individual-list or beneficiary-list,
            "companyIds":[],
            //"petitionCreatedDateRange":[],
         },
         sorting:this.sortKey,
         page: this.page,
         perpage: this.perpage,
         getBeneficiaryList:false
      }
      if(this.checkProperty(this.$route ,'query' ,'filter')){
        try{
           let filter =this.$route['query']['filter']; this.checkProperty(this.$route ,'query' ,'filter')
          var actual = JSON.parse(atob(filter));
          let keys = Object.keys(actual);
          if(this.checkProperty(keys ,'length') >0){


            if(actual && (Object.keys(actual)).length>0 ){
            _.forEach(actual ,(item ,key) => {
                if(key=='matcher' ){
                  if((Object.keys(item)).length>0 ){
                    postData['matcher'] = item
                  }
                
                }
               
              //   if(callFromSerch){
              //   if(key =='page' && item >0){
              //     postData['page'] = parseInt(item)
              //     this.page = parseInt(item)
              //   }
              //   if(key =='perpage' && item >0){
              //     postData['perpage'] = parseInt(item)
                  
              //     this.perpage = parseInt(item)
              //   }
              //   if(key=='sorting' ){
              //     if((Object.keys(item)).length>0 ){
              //       postData['sorting'] = item
              //     }
                
              //   }
              // }
            
            })
          }    
          }
        }catch(e){
        }   
      }
      if((this.selected_createdDateRange['startDate'] && this.selected_createdDateRange['startDate'] !=''  ) && (this.selected_createdDateRange['endDate'] !='' && this.selected_createdDateRange['endDate'] ) ){
        postData['matcher']['petitionCreatedDateRange'] = [this.selected_createdDateRange['startDate'], this.selected_createdDateRange['endDate']]

      }
      /*
      this.filteredVisaType =null;
      this.filteredVisaSubTypes = [] ; filteredVisaSubTypes
      */
      if(this.filteredVisaType && _.has(this.filteredVisaType ,"id")){
        postData['matcher']['petitionTypeIds'] = [this.filteredVisaType['id']];

      }

      if(this.filteredVisaSubTypes && this.filteredVisaSubTypes.length>0 ){
        postData['matcher']['petitionSubTypeIds'] = this.filteredVisaSubTypes.map((item)=>{return item['id']})

      //   if (this.selected_statusids && this.selected_statusids.length>0 ){
      //   postData['matcher']['statusIds'] = this.filteredVisaSubTypes.map((item)=>{return item['id']})

      // }
      }
      // if(this.selectedPetitionerforFilter && this.selectedPetitionerforFilter.length>0 ){
      //   postData['matcher']['companyIds'] = this.selectedPetitionerforFilter.map((item)=>{return item['_id']})

      // }
    postData['getBeneficiaryList'] =true
      
      postData['matcher']["accountType"] = "Individual"; 
      let tempObj={
        filteredVisaType:this.filteredVisaType,
        filteredVisaSubTypes:this.filteredVisaSubTypes,
        selected_statusids:this.selected_statusids,
        searchtxt:this.searchtxt,
        page: this.page,
        perpage: this.perpage,
        sortKey: this.sortKey,
      };
      if (
        this.selected_createdDateRange["startDate"] &&
        this.selected_createdDateRange["startDate"] != "" &&
        this.selected_createdDateRange["endDate"] != "" &&
        this.selected_createdDateRange["endDate"]
      ) { 
        tempObj["startDate"] = moment(this.selected_createdDateRange["startDate"]).format("YYYY-MM-DD");
        tempObj["endDate"] = moment(this.selected_createdDateRange["endDate"]).format("YYYY-MM-DD");
      }
      this.setQueryString(tempObj);
     this.isListloading =true;
      this.updateLoading(true);
      this.$store
        .dispatch("petitioner/getbeneficiaries", postData)
        .then(response => {
          this.users = response.list;
          this.totalCount = this.checkProperty(response, 'totalCount')
          this.totalpages = Math.ceil(response.totalCount / this.perpage);
          this.isListloading =false;
          this.updateLoading(false);
          setTimeout(() =>{
            this.updateLoading(false);
          } ,10)
          
        }).catch((err)=>{
         this.users = [];
           this.isListLoading =false;
           this.updateLoading(false);
           setTimeout(() =>{
            this.updateLoading(false);
          } ,10)
         
        })
    },
    filterQueryPreSelect(callFromMounted=false){
      if(this.checkProperty(this.$route ,'query' ,'filter')){
        try{
          let filter =this.$route['query']['filter']; this.checkProperty(this.$route ,'query' ,'filter')
          var actual = JSON.parse(atob(filter));
          let keys = Object.keys(actual);
          if(this.checkProperty(keys ,'length') >0 ){
            if(_.has(actual ,'page') && this.checkProperty(actual ,'page')){                                     
              this.page = this.checkProperty(actual ,'page');
            }
            if(_.has(actual ,'perpage') && this.checkProperty(actual ,'perpage')){                                     
              this.perpage = this.checkProperty(actual ,'perpage');
            }
            if(_.has(actual ,'sortKey') && this.checkProperty(actual ,'sortKey')){                                     
              this.sortKey = this.checkProperty(actual ,'sortKey');
              if(this.sortKeys){
                this.sortKeys[actual['sortKey']['path']] = actual['sortKey']['order']
              }
            }
            if(_.has(actual ,'filteredVisaType') && this.checkProperty(actual ,'filteredVisaType') ){                                     
              this.filteredVisaType = this.checkProperty(actual ,'filteredVisaType');
            }
            if(_.has(actual ,'filteredVisaSubTypes') && this.checkProperty(actual ,'filteredVisaSubTypes') && this.checkProperty(actual ,'filteredVisaSubTypes', 'length')>0){                                     
              this.filteredVisaSubTypes = this.checkProperty(actual ,'filteredVisaSubTypes');
            }
            if(_.has(actual ,'startDate') && this.checkProperty(actual ,'startDate') ){                                     
              this.selected_createdDateRange["startDate"] = this.checkProperty(actual ,'startDate');
            }
            if(_.has(actual ,'endDate') && this.checkProperty(actual ,'endDate') ){                                     
              this.selected_createdDateRange["endDate"] = this.checkProperty(actual ,'endDate');
            }
            if(_.has(actual ,'searchtxt') && this.checkProperty(actual ,'searchtxt') ){                                     
              this.searchtxt = this.checkProperty(actual ,'searchtxt');
            }
            if(_.has(actual ,'selected_statusids') && this.checkProperty(actual ,'selected_statusids') && this.checkProperty(actual ,'selected_statusids', 'length')>0){                                     
              this.selected_statusids = this.checkProperty(actual ,'selected_statusids');
            }
            this.set_filter();
          }else{
            this.set_filter();
          }
        }catch(e){
          if(callFromMounted){
            this.set_filter();
          }
        }   
      }
      else{
        if(callFromMounted){
            this.set_filter();
        }
      } 
    },
    setQueryString(obj){
      const string = JSON.stringify(obj) // convert Object to a String
      this.encodedString = btoa(string) // Base64 encode the String
      this.$route['query']['filter'] = this.encodedString;
    },
    savebeneficiary() {
      this.$validator.validateAll().then(result => {

        this.saveBenbtn =false;
        if (result) {
          let self =this;
          this.beneficiary = Object.assign(this.beneficiary,{"roleId":51});
          this.beneficiary['name'] =  this.beneficiary['firstName'].trim()+" "+this.beneficiary['lastName'].trim();
          this.beneficiary['firstName'] =  this.beneficiary['firstName'].trim();
          this.beneficiary['lastName'] =  this.beneficiary['lastName'].trim();
          this.beneficiary['name'] =  this.beneficiary['name'].trim();
          this.saveBenbtn =true;
          let postData = this.beneficiary;
          if(self.selectedPetitioner && _.has(self.selectedPetitioner ,"_id")){
              postData = Object.assign(postData,{ "companyId": self.selectedPetitioner['_id']})
          }
          this.$store
            .dispatch("beneficiaryregister", postData)
            .then(response => {
              this.saveBenbtn =false;
              if (response.error) {
                Object.assign(this.formerrors, {
                  msg: response.error.message
                });
              } else {
                this.AddBeneficiary =false;
                this.selectedBeneficiary =response.data['result']
                this.showToster({message:response.data.message,isError:false });
                this.openNewbenForm =false;
               // this.$router.go("/beneficiaries");
                this.getbeneficiaries();
              }

              // this.$router.go('/beneficiaries');
            })
            .catch((err)=>{
              this.saveBenbtn =false;
                //this.showToster({message:err,isError:true })
                Object.assign(this.formerrors, {
                  msg: err
                });

            });
        }
      });
    },

    get_statusids() {
      let postData = {
          page:1,
          perpage: 10000,
          category: "user_status",
         // tenantId: "5db7d79d6032453bd060ed9c",
        }

      this.$store.dispatch("getMasterData", postData).then(response => {
        this.all_statusids =  _.filter(response.list,function(i){
    return i['id']!=1;
});
      });
    },

    //get all_states
    get_all_states() {
      this.$store.dispatch("getstates", this.filtered_country).then(response => {
        this.all_states = response;
      });
    },
    getvisatypes(){
      this.$store.dispatch("getvisatypes").then(response => {
        this.visatypes = response;
      });
    },
    getvisasubtypes(vsType){
      
     Object.assign(this.formerrors , {msg:''});
    
    if(this.visatype && _.has(this.visatype ,"id")){
       this.visasubtypes =[];
      this.visasubtype = null;
     
    
        let item ={
          matcher:{
             // "searchString":this.searchtxt,
             "petitionType":parseInt(this.visatype['id'])

          },   
          page:this.page,
          perpage: this.perpage,
          category: "petition_sub_types",
          
        };

        this.$store.dispatch("getMasterData",item ).then(response => { this.visasubtypes = response.list;  });
        this.$validator.reset();
        }
    },
    getAllLocations() {
      Object.assign(this.query, {
        countryId: this.filtered_country,
        stateId: this.singel_final_selected_state//this.final_selected_states //3922
      });

      this.$store.dispatch("getlocations", this.query).then(response => {
        this.all_locations = response;
      });
    },
    changedState(){
      this.singel_final_selected_state = '';
      this.final_selected_locations = [];
      this.singel_final_selected_state= this.seleted_states["id"];
      this.final_selected_states.push(this.seleted_states["id"]);
      this.getAllLocations();
    },
    multiple_changedState: function() {

      if (this.seleted_states.length > 0) {
        this.final_selected_states = [];
        for (let ind = 0; ind < this.seleted_states.length; ind++) {
          let current_index = this.seleted_states[ind];
          this.final_selected_states.push(current_index["id"]);
        }
        this.getAllLocations();
      } else {
        this.final_selected_states = [];
        this.final_selected_locations = [];
      }
    },
    set_filter: function () {
      this.final_selected_statusids = [];
      if (this.selected_statusids.length > 0) {
        this.final_selected_statusids = [];
        for (let ind = 0; ind < this.selected_statusids.length; ind++) {
          let current_index = this.selected_statusids[ind];
          this.final_selected_statusids.push(current_index["id"]);
        }
      }

      //states
      this.final_selected_states = [];
      if (this.seleted_states.length > 0) {
        this.final_selected_states = [];
        for (let ind = 0; ind < this.seleted_states.length; ind++) {
          let current_index = this.seleted_states[ind];
          this.final_selected_states.push(current_index["id"]);
        }
      }

     this.final_selected_locations = [];
      if (this.seleted_locations.length > 0) {
        for (let ind = 0; ind < this.seleted_locations.length; ind++) {
          let current_index = this.seleted_locations[ind];
          this.final_selected_locations.push(current_index["id"]);
        }
      }

      this.getbeneficiaries(true);
      //this.getPetitioners();
      this.$refs["filter_menu"].dropdownVisible = false;
    },
    clear_filter: function() {
      
      this.searchtxt ='';
      this.selected_statusids = [];
      this.final_selected_statusids = [];
      this.seleted_states = [];
      this.final_selected_states = [];
      this.singel_final_selected_state ='';
      this.seleted_locations = [];
      this.final_selected_locations = [];
      this.date = "";
      this.date_range = [];
      this.selected_country_obj='';

      this.selected_createdDateRange['startDate']=null;
      this.selected_createdDateRange['endDate']=null;
      this.selected_createdDateRange = [];
      this.filtered_country = ''
      this.filteredVisaType =null;
      this.filteredVisaSubTypes = [] ;
      this.selectedPetitionerforFilter =[];
    
      this.$refs["filter_menu"].dropdownVisible = false;
      this.$router.push({ query: {} })
      this.getbeneficiaries();
      //this.getPetitioners();

    },
    pageNate(pageNum) {
      this.page = pageNum;
      this.getbeneficiaries(true);
    },
    selectCreatedDateRange(option) {
        option.startDate = moment(option.startDate).format("YYYY-MM-DD");
        option.endDate = moment(option.endDate).format("YYYY-MM-DD");
        this.selected_createdDateRange = [option.startDate, option.endDate];
      },

    changedCountry(){
      this.filtered_country = this.selected_country_obj['id'];
      this.get_all_states();
    }
  },
  mounted() {
    if (this.$route.params && this.$route.params.openCreatePopup) {
      this.invitePetitionPopupshow(true)
    }
    this.getPetitioners();
    this.changedVsaType();
    this.sortKey = {
			"path": "createdOn", // invitedByName, updatedOn, name, email, phone, statusName, roleName
			"order": 1
		}
    this.sortKeys = {
      invitedByName:1,
      updatedOn:1,
      name:1,
      email:1,
      phone:1,
      statusName: 1,
      createdOn: -1,
      roleName:1,
      
    }
      let postData = {
        matcher: {},
        page:1,
        perpage: 1000,
        category: 'countries',
       
      }
      this.getBranchList();
    this.$store.dispatch("getMasterData" ,postData).then(response => {
      this.all_countries = response.list;
    });

    this.selected_statusids = [];
    this.final_selected_statusids = [];
    this.seleted_states = [];
    this.final_selected_states = [];

    this.seleted_locations = [];
    this.final_selected_locations = [];
    this.get_statusids();

    this.getvisatypes();
    this.getvisasubtypes();
    //this.getbeneficiaries();
   this.getCompanyStatusList();
   this.filterQueryPreSelect(true)
    
  }
};
</script>
