<template>
      <div>
       
      <div v-if="isloaded" class="gc_appcontent"  >
        <!-- <h4> {{dt['blockName']}}</h4> -->
        <!-- <h4 style="font-size:20px; color:#C69942; font-family: 'Arial Bold', sans-serif; display:block; text-align:center; margin-bottom:20px"> {{blockName}}</h4> -->
           
        <div class="gc_appcontent_right" >
          <h5 class="print_title" style=" font-size:20px; font-family: 'Arial', sans-serif; font-weght:600; padding:0px 0; margin-bottom:10px" >Personal Info</h5>
          <div class="gc_app_details-cnt">
            
            <div class="gc_scrool-cnt">
              
              <ul style="display:flex; flex-wrap: wrap; padding:0px; margin:0px">
                <li v-if="dataTabpop.firstName" style="list-style-type:none; width:33.3%; height:60px ">
                  
                  <p  style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px" >First Name</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop.firstName}}</label>
                </li>
                <li v-if="dataTabpop['middleName']" style="list-style-type:none; width:33.3%; height:60px">
                  <p  style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px" >Middle Name</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop.middleName}}</label>
                </li>
                <li v-if="dataTabpop['lastName']" style="list-style-type:none; width:33.3% ; height:60px">
                  <p  style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px" >Last Name</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop['lastName']}}</label>
                </li>

                 <li v-if="dataTabpop['email']" style="list-style-type:none; width:66.6% ; height:60px">
                  <p  style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px" >Email</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop['email']}}</label>
                </li>
                <li v-if="dataTabpop['gender']" style="list-style-type:none; width:33.3% ; height:60px">
                  <p  style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px" >Gender</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop['gender']}}</label>
                </li>
                
                 <li v-if="dataTabpop['dateOfBirth']" style="list-style-type:none; width:33.3% ; height:60px">
                  <p  style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px" >Date of Birth</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop['dateOfBirth'] | formatDate }}</label>
                </li>
                
                <li v-if="dataTabpop['maritalStatus']" style="list-style-type:none; width:33.3%; height:60px ">
                  <p  style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px" >Marital Status</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop['maritalStatus']['name']}}</label>
                </li>

                 <li v-if="dataTabpop['childrenCount']" style="list-style-type:none; width:33.3%; height:60px ">
                  <p  style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px" >How many children do you have?</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop['childrenCount']}}</label>
                </li>
               
                <li v-if="dataTabpop['dateOfMarriage']" style="list-style-type:none; width:33.3% ; height:60px">
                  <p  style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px" > Date of Marriage</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop['dateOfMarriage'] | formatDate }}</label>
                </li>

                <li v-if=" dataTabpop['placeOfMarriage'] && checkEmptyObjects(dataTabpop['placeOfMarriage'])" style="list-style-type:none; width:66.6% ; height:60px">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px"> Place of Marriage</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">
                    {{ dataTabpop.placeOfMarriage | addformat}}</label>
                  
                   
                </li>

              
              </ul>
              
              <ul style="display:flex; flex-wrap: wrap; padding:0px; margin:0px">
                <li  v-if="dataTabpop.homePhoneNumber" style="list-style-type:none; width:33.3% ; height:60px">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Daytime Telephone Number</p>
                 <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop.homePhoneNumber}}</label>
                </li>
                <li v-if="dataTabpop.cellPhoneNumber" style="list-style-type:none; width:33.3% ; height:60px">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Mobile Telephone Number</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop.cellPhoneNumber}}</label>
                </li>
                <li v-if="dataTabpop.SSN" style="list-style-type:none; width:33.3% ; height:60px">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Social Security number (If any)</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop.SSN }}</label>
                </li>
                <li  v-if="dataTabpop.alienNumber" style="list-style-type:none; width:33.3% ; height:60px">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Your Alien Number (if applicable)</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop.alienNumber }}</label>
                </li>
                <li v-if="dataTabpop.passportNumber" style="list-style-type:none; width:33.3% ; height:60px">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Passport Number</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop.passportNumber}}</label>
                </li>
                <li v-if="dataTabpop.passportExpiryDate" style="list-style-type:none; width:33.3% ; height:60px" >
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Passport Expiration Date</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{ dataTabpop.passportExpiryDate | formatDate}}</label>
                </li>
                <li class="col-2" v-if="dataTabpop.placeOfBirth && checkEmptyObjects(dataTabpop.placeOfBirth)" style="list-style-type:none; width:33.3% ; height:60px">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Place Of Birth</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{ dataTabpop.placeOfBirth | addformat}}</label>
                </li>
                <li v-if="dataTabpop.nationality " style="list-style-type:none; width:33.3% ; height:60px">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Nationality</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop.nationality.name}}</label>
                </li>


                <li v-if="dataTabpop.dayTimePhoneNumber" style="list-style-type:none; width:33.3% ; height:60px">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Daytime Telephone Number</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop.dayTimePhoneNumber}}</label>
                </li>
                
                <li v-if="dataTabpop.phoneNumber" style="list-style-type:none; width:33.3% ; height:60px">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Mobile Telephone Number</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop.phoneNumber}}</label>
                </li>

                
                <li v-if="dataTabpop.SSN" style="list-style-type:none; width:33.3% ; height:60px">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Social Security Number</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop.SSN}}</label>
                </li>
                <li v-if="dataTabpop.alienNumber" style="list-style-type:none; width:33.3% ; height:60px">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Alien Number</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop.alienNumber}}</label>
                </li>
                
                 <li v-if="dataTabpop.passportNumber" style="list-style-type:none; width:33.3% ; height:60px">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Passport Number</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop.passportNumber}}</label>
                </li>

                
                 <li v-if="dataTabpop.passportExpiryDate" style="list-style-type:none; width:33.3% ; height:60px">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Passport Expiration Date</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop.passportExpiryDate | formatDate}}</label>
                </li>

                                 


                <li v-if="checkEmptyObjects(dataTabpop.height) && dataTabpop.height !=null && dataTabpop.height.feet !=null &&  dataTabpop.height.inches !=null" style="list-style-type:none; width:33.3% ; height:60px" >
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Height</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop.height.feet}} feet {{dataTabpop.height.inches}} inches'</label>
                </li>
                <li v-if="dataTabpop.weight" style="list-style-type:none; width:33.3% ; height:60px">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Weight</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop.weight}}</label>
                </li>
                <li v-if="dataTabpop.race" style="list-style-type:none; width:33.3% ; height:60px">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Race</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop.race.name}}</label>
                </li>
                <li v-if="dataTabpop.hairColor" style="list-style-type:none; width:33.3% ; height:60px">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Hair Color</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{ dataTabpop.hairColor.name}}</label>
                </li>
                <li class="col-2" v-if="dataTabpop.eyeColor" style="list-style-type:none; width:33.3% ; height:60px">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Eye Color</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{ dataTabpop.eyeColor.name}}</label>
                </li>

              
              </ul>

              <!-- //allOtherNamesUsed -->
             <template v-if="checkEmptyObjects(dataTabpop.allOtherNamesUsed) && dataTabpop.allOtherNamesUsed !=null && dataTabpop.allOtherNamesUsed.length>0">
               <div class="gc_scrool-cnt">
                 <h6 style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:13px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">All other names you have used including maiden name and last names from previous marriages</h6>
              <ul v-for=" otn in dataTabpop.allOtherNamesUsed" :key="otn" style="display:flex; flex-wrap: wrap; padding:0px; margin:0px">
                <li v-if="otn.firstName && otn.firstName !=''" style="list-style-type:none; width:33.3% ; height:60px">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">First Name</p>
                 <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{otn.firstName}}</label>
                </li>
                <li v-if="otn.middleName && otn.middleName !=''"  style="list-style-type:none; width:33.3% ; height:60px">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Middle Name</p>
                 <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{otn.middleName}}</label>
                </li>

                <li v-if="otn.lastName && otn.lastName !=''" style="list-style-type:none; width:33.3% ; height:60px" >
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Last Name</p>
                 <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{otn.lastName}}</label>
                </li>

              </ul>  

               </div>
             </template>

              <template v-if="dataTabpop.previouslyMarried == 'Yes' && dataTabpop['previouslyMarried'] && checkEmptyObjects(dataTabpop.previouslyMarried) " >


                <div class="gc_scrool-cnt">
                 <h6 style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:13px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">Previous Spouse</h6>
                <ul style="display:flex; flex-wrap: wrap; padding:0px; margin:0px">

                <li v-if="dataTabpop['previouslyMarried']['firstName']" style="list-style-type:none; width:33.3% ; height:60px">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">First Name</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop['previouslyMarried']['firstName']}}</label>
                </li>
                <li v-if="dataTabpop['previouslyMarried']['middleName']" style="list-style-type:none; width:33.3% ; height:60px">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px"> Middle Name</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop['previouslyMarried']['middleName']}}</label>
                </li>
                <li v-if="dataTabpop['previouslyMarried']['lastName']" style="list-style-type:none; width:33.3% ; height:60px">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Last Name</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop['previouslyMarried']['lastName']}}</label>
                </li>

                <li v-if="dataTabpop['previouslyMarried']['placeOfMarriage'] && checkEmptyObjects(dataTabpop.previouslyMarried) " style="list-style-type:none; width:33.3% ; height:60px">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Place Of Marriage</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">
                     {{ dataTabpop['previouslyMarried']['placeOfMarriage'] | addformat}}
                   
                    </label>
                </li>
                
                <li v-if="dataTabpop['previouslyMarried']['dateOfMarriageEnded']" style="list-style-type:none; width:33.3% ; height:60px">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Date Of Marriage Ended</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop['previouslyMarried']['dateOfMarriageEnded'] | fromDate}}</label>
                </li>
                
                <li v-if="dataTabpop['previouslyMarried']['placeOfTermination']" style="list-style-type:none; width:33.3% ; height:60px">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Place Of Termination</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop['previouslyMarried']['placeOfTermination'] }}</label>
                </li>

                </ul>
                </div>
              </template>

              <div class="gc_app_details-list" v-if="applicationRequired && dataTabpop.applicationRequired !=null &&  dataTabpop.applicationRequired !=undefined">
                <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Adjustment of status to Permanent Residency (Form I-485) required for your Child?</p>
                <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px" v-if="dataTabpop.applicationRequired" class="yes_option">Yes</label>
                <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px"  v-if="!dataTabpop.applicationRequired" class="no_option">No</label>
              </div>
              
              <div class="gc_app_details-list" v-if="dataTabpop.haveMarriageCertificate">
                <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Have a Marriage Certificate?</p>
                <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px"  v-if="dataTabpop.haveMarriageCertificate=='Yes'" class="yes_option">Yes</label>
                <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px"  v-if="dataTabpop.haveMarriageCertificate !='Yes'" class="no_option">No</label>
              </div>

              <div class="gc_app_details-list" v-if="dataTabpop.birthCertHaveNamePobDob">
                <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">If your name is different from that stated on your birth certificate, have you had it legally changed?</p>
                <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px" v-if="dataTabpop.birthCertHaveNamePobDob=='Yes'" class="yes_option">Yes</label>
                <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px" v-if="dataTabpop.birthCertHaveNamePobDob !='Yes'" class="no_option">No</label>
              </div>

              <div class="gc_app_details-list" v-if="dataTabpop.have2AffidavitsAttestingToMarriage" >
                <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Do you have Two (2) Affidavits of Birth from family members?</p>
                <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px"  v-if="dataTabpop.have2AffidavitsAttestingToMarriage=='No'"  class="no_option">No</label>
                 <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px"  v-if="dataTabpop.have2AffidavitsAttestingToMarriage=='Yes'" class="yes_option">Yes</label>
              </div>
              

              <div class="gc_app_details-list" v-if=" dataTabpop.previouslyMarried =='Yes' ||  dataTabpop.previouslyMarried=='No'" >
                <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Mrried previously?</p>
                <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px" v-if="dataTabpop.previouslyMarried=='No'"  class="no_option">No</label>
                 <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px" v-if="dataTabpop.previouslyMarried=='Yes'" class="yes_option">Yes</label>
              </div>



             

              <template v-if="dataTabpop.previouslyMarried == 'Yes' && dataTabpop['previouslyMarried']" >


                <div class="gc_app_details-list" >
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px"> Obtain U.S Permanent Residence Through Spouse? </p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px" v-if=" dataTabpop['previouslyMarried']['obtainPermResidenceThroughSpouse'] =='No'"  class="no_option">No</label>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px" v-if=" dataTabpop['previouslyMarried']['obtainPermResidenceThroughSpouse'] =='Yes'" class="yes_option">Yes</label>
                </div>
                
              </template>

            </div>
           
          </div>
        </div> 
        <!-- End personal_info-->

      <!-- Address Tab--->
      <div class="gc_appcontent_right" >
          <h5 class="print_title" style=" font-size:20px; font-family: 'Arial', sans-serif; font-weght:600; padding:0px 0; margin-bottom:10px">Adresses</h5>
          <div class="gc_app_details-cnt">
           
               <div class="gc_scrool-cnt" v-if="checkEmptyObjects(dataTabpop['address']) ">
                 <h6 style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:13px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">Current US Home Address</h6>
                 <ul style="display:flex; flex-wrap: wrap; padding:0px; margin:0px" >
                  <li v-if="dataTabpop.address" style="list-style-type:none; width:33.3% ; height:60px">
                    <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Street Address</p>                   
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop.address.line1}}</label>                                      
                  </li>
                  <li v-if="dataTabpop.address" style="list-style-type:none; width:33.3% ; height:60px">
                    <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Apt, Suite</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop.address.line2}}</label>
                  </li>
                  <li v-if="dataTabpop.address && dataTabpop.address['location'] !=undefined && dataTabpop.address['location']" style="list-style-type:none; width:33.3% ; height:60px">
                    <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Location</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop.address.location.name  }}</label>
                  </li>
                  <li v-if="dataTabpop['address'] && dataTabpop['address']['state'] !=null" style="list-style-type:none; width:33.3% ; height:60px">
                    <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">State</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop.address.state.name}}</label>
                  </li>
                
                  <li v-if="dataTabpop['address'] && dataTabpop['address']['country'] !=null" style="list-style-type:none; width:33.3% ; height:60px">
                    <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Country</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop.address.country.name}}</label>
                  </li>
                  <li v-if="dataTabpop['address'] && dataTabpop['address']['zipcode'] !=null" style="list-style-type:none; width:33.3% ; height:60px">
                    <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Zip Code</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop.address.zipcode}}</label>
                  </li>
                </ul>
               </div>

                <template v-if="checkEmptyObjects(dataTabpop['mailingAddress']) && dataTabpop['mailingAddress']">
                  <div class="gc_scrool-cnt">
                   <h6 style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:13px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">Current Mailing Address </h6>
                  <ul style="display:flex; flex-wrap: wrap; padding:0px; margin:0px" >
                   
                  <li v-if="dataTabpop.mailingAddress" style="list-style-type:none; width:33.3% ; height:60px">
                    <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Street Address</p>                   
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop.mailingAddress.line1}}</label>                                      
                  </li>
                  <li v-if="dataTabpop.mailingAddress" style="list-style-type:none; width:33.3% ; height:60px">
                    <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Apt, Suite</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop.mailingAddress.line2}}</label>
                  </li>
                  <li v-if="dataTabpop.mailingAddress && dataTabpop.mailingAddress['location'] !=undefined && dataTabpop.mailingAddress['location']" style="list-style-type:none; width:33.3% ; height:60px">
                    <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Location</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop.mailingAddress.location.name  }}</label>
                  </li>
                  <li v-if="dataTabpop['mailingAddress'] && dataTabpop['mailingAddress']['state'] !=null" style="list-style-type:none; width:33.3% ; height:60px">
                    <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">State</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop.mailingAddress.state.name}}</label>
                  </li>                
                  <li v-if="dataTabpop['mailingAddress'] && dataTabpop['mailingAddress']['country'] !=null" style="list-style-type:none; width:33.3% ; height:60px">
                    <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Country</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop.mailingAddress.country.name}}</label>
                  </li>
                  <li v-if="dataTabpop['mailingAddress'] && dataTabpop['mailingAddress']['zipcode'] !=null" style="list-style-type:none; width:33.3% ; height:60px">
                    <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Zip Code</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px"> {{dataTabpop.mailingAddress.zipcode}}</label>
                  </li>
                  </ul>
                  </div>
                

                </template>

                

                <template v-if="dataTabpop['residenceAddressUSAbroad'] && checkEmptyObjects(dataTabpop['residenceAddressUSAbroad'])">
                  <div class="gc_scrool-cnt">
                  <h6 style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:13px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">Your Residence starting with most current for the Past Five Years in the U.S and Aboard</h6>
                  <ul v-for="residenceAddressUSAbroad in dataTabpop.residenceAddressUSAbroad" :key="residenceAddressUSAbroad" style="display:flex; flex-wrap: wrap; padding:0px; margin:0px" >
                   
                  <li v-if="residenceAddressUSAbroad" style="list-style-type:none; width:33.3% ; height:60px">
                    <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Street Address</p>                   
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{residenceAddressUSAbroad.line1}}</label>                                      
                  </li>
                  <li v-if="residenceAddressUSAbroad" style="list-style-type:none; width:33.3% ; height:60px">
                    <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Apt, Suite</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{residenceAddressUSAbroad.line2}}</label>
                  </li>
                  <li v-if="residenceAddressUSAbroad && residenceAddressUSAbroad['location'] !=undefined && residenceAddressUSAbroad['location']" style="list-style-type:none; width:33.3% ; height:60px">
                    <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Location</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{residenceAddressUSAbroad.location.name  }}</label>
                  </li>
                  <li v-if="residenceAddressUSAbroad && residenceAddressUSAbroad['state'] !=null" style="list-style-type:none; width:33.3% ; height:60px">
                    <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">State</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{residenceAddressUSAbroad.state.name}}</label>
                  </li>
                
                  <li v-if="residenceAddressUSAbroad['country'] !=null" style="list-style-type:none; width:33.3% ; height:60px">
                    <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Country</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{residenceAddressUSAbroad.country.name}}</label>
                  </li>
                  <li v-if="residenceAddressUSAbroad['zipcode'] !=null" style="list-style-type:none; width:33.3% ; height:60px">
                    <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Zip Code</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{residenceAddressUSAbroad.zipcode}}</label>
                  </li>
                   <li v-if="residenceAddressUSAbroad && residenceAddressUSAbroad['fromDate'] !=null" style="list-style-type:none; width:33.3% ; height:60px">
                    <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">From Date</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop.lastAddressOutsideUS.fromDate | formatDate }}</label>
                  </li>
                   <li v-if="dataTabpop['residenceAddressUSAbroad'] && residenceAddressUSAbroad['toDate'] !=null" style="list-style-type:none; width:33.3% ; height:60px">
                    <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">To Date</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{residenceAddressUSAbroad.toDate  | formatDate}}</label>
                  </li>
                </ul>
                  </div>

                </template>

                <template v-if="dataTabpop['lastAddressOutsideUS'] && checkEmptyObjects(dataTabpop['lastAddressOutsideUS'])">
                  <div class="gc_scrool-cnt">
                   <h6 style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:13px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">Last Address outside Of the United States for more than one year</h6>
                   <ul  style="display:flex; flex-wrap: wrap; padding:0px; margin:0px">
                   
                  <li v-if="dataTabpop.lastAddressOutsideUS" style="list-style-type:none; width:33.3% ; height:60px">
                    <p  style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Street Address</p>                   
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop.lastAddressOutsideUS.line1}}</label>                                      
                  </li>
                  <li v-if="dataTabpop.lastAddressOutsideUS" style="list-style-type:none; width:33.3% ; height:60px">
                    <p  style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Apt, Suite</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop.lastAddressOutsideUS.line2}}</label>
                  </li>
                  <li v-if="dataTabpop.lastAddressOutsideUS && dataTabpop.lastAddressOutsideUS['location'] !=undefined && dataTabpop.lastAddressOutsideUS['location']" style="list-style-type:none; width:33.3% ; height:60px">
                    <p  style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Location</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop.lastAddressOutsideUS.location.name  }}</label>
                  </li>
                  <li v-if="dataTabpop['lastAddressOutsideUS'] && dataTabpop['lastAddressOutsideUS']['state'] !=null" style="list-style-type:none; width:33.3% ; height:60px"> 
                    <p  style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">State</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop.lastAddressOutsideUS.state.name}}</label>
                  </li>                
                  <li v-if="dataTabpop['lastAddressOutsideUS'] && dataTabpop['lastAddressOutsideUS']['country'] !=null" style="list-style-type:none; width:33.3% ; height:60px">
                    <p  style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Country</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop.lastAddressOutsideUS.country.name}}</label>
                  </li>
                  <li v-if="dataTabpop['lastAddressOutsideUS'] && dataTabpop['lastAddressOutsideUS']['zipcode'] !=null" style="list-style-type:none; width:33.3% ; height:60px">
                    <p  style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Zip Code</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop.lastAddressOutsideUS.zipcode}}</label>
                  </li>
                   <li v-if="dataTabpop['lastAddressOutsideUS'] && dataTabpop['lastAddressOutsideUS']['fromDate'] !=null" style="list-style-type:none; width:33.3% ; height:60px">
                    <p  style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">From Date</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px"> {{dataTabpop.lastAddressOutsideUS.fromDate | formatDate}}</label>
                  </li>
                   <li v-if="dataTabpop['lastAddressOutsideUS'] && dataTabpop['lastAddressOutsideUS']['toDate'] !=null" style="list-style-type:none; width:33.3% ; height:60px">
                    <p  style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">To Date</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop.lastAddressOutsideUS.toDate | formatDate }}</label>
                  </li>
                   </ul>
                  </div> 
                </template> 
          </div>
      </div>      
      <!--End Address Tab--->

      <!---immigration--->
      <div class="gc_appcontent_right" >
        <h5 class="print_title" style=" font-size:20px; font-family: 'Arial', sans-serif; font-weght:600; padding:0px 0; margin-bottom:10px" >Immigration</h5>
          <div class="gc_app_details-cnt">            
               <div class="gc_scrool-cnt"> 
                  <ul style="display:flex; flex-wrap: wrap; padding:0px; margin:0px">
                  <li v-if="dataTabpop['currentStatus']" style="list-style-type:none; width:33.3% ; height:60px">
                    <p  style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Current Status</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop['currentStatus']}}</label>                                      
                  </li>                  
                  <li v-if="dataTabpop['statusExpiryDate']" style="list-style-type:none; width:33.3% ; height:60px">
                    <p  style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Status Expiry Date</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop.statusExpiryDate | formatDate}}</label>
                  </li>
                  <li v-if="dataTabpop['lastEntryPlaceInUs'] && checkEmptyObjects(dataTabpop['lastEntryPlaceInUs'])" style="list-style-type:none; width:33.3% ; height:60px">
                    <p  style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Place of Last Entry into the USA</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">
                      {{ dataTabpop['lastEntryPlaceInUs'] | addformat}}                      
                       <!-- {{dataTabpop['lastEntryPlaceInUs']['location']['name']}}
                       {{ dataTabpop['lastEntryPlaceInUs']['location']['name'] && dataTabpop['lastEntryPlaceInUs']['state']['name']?' , '+dataTabpop['lastEntryPlaceInUs']['state']['name']:''}} -->
                    </label>
                  </li> 
                  <li v-if="dataTabpop['visaIssuedDate'] !=null" style="list-style-type:none; width:33.3% ; height:60px">
                    <p  style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Case Issued Date</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop['visaIssuedDate'] | formatDate}}</label>
                  </li>
                  
                  <li v-if="dataTabpop['visaExpiryDate'] !=null" style="list-style-type:none; width:33.3% ; height:60px">
                    <p  style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Case Expiry Date</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop['visaExpiryDate'] | formatDate}}</label>
                  </li>
                 
                  <li v-if="dataTabpop['visaIssuedAt'] && dataTabpop['visaIssuedAt'] !=null && dataTabpop['visaIssuedAt'] !=undefined" style="list-style-type:none; width:33.3% ; height:60px">
                    <p  style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Case Issued At</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop['visaIssuedAt'] }}</label>
                  </li>
                  <!-- Most Recent Entry into the USA-->
                  <li v-if="dataTabpop['mostRecentEntryDateInUs'] && dataTabpop['mostRecentEntryDateInUs'] !=null && dataTabpop['mostRecentEntryDateInUs'] !=undefined" style="list-style-type:none; width:33.3% ; height:60px">
                    <p  style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Most Recent Entry into the USA</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop['mostRecentEntryDateInUs']  | formatDate}}</label>
                  </li>

                   <li v-if="dataTabpop['initialEntryDateInUs'] && dataTabpop['initialEntryDateInUs'] !=null" style="list-style-type:none; width:33.3% ; height:60px">
                    <p  style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Initial (First) Entry into the USA</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop['initialEntryDateInUs']  | formatDate}}</label>
                  </li>
                  <!-- Manner of Most recent entry into the USA -->
                  <li v-if="dataTabpop['mannerOfMostEntryInUs'] && dataTabpop['mannerOfMostEntryInUs'] && dataTabpop['mannerOfMostEntryInUs'] !=null" style="list-style-type:none; width:33.3% ; height:60px"> 
                    <p  style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:15px; height:22px; margin-bottom:0px; padding-bottom:2px">Manner of Most recent entry into the USA</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop['mannerOfMostEntryInUs'] }}</label>
                  </li>

                  <!-- Expiration Date on Form I-94 -->
                  <li v-if="dataTabpop['formI94ExpiryDate'] && dataTabpop['formI94ExpiryDate'] !=null" style="list-style-type:none; width:33.3% ; height:60px">
                    <p  style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Expiration Date on Form I-94</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop['formI94ExpiryDate']  | formatDate}}</label>
                  </li>

                  <li v-if="dataTabpop['i140PrioityDate'] && dataTabpop['i140PrioityDate'] !=null" style="list-style-type:none; width:33.3% ; height:60px">
                    <p  style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Priority Date of I-140</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop['i140PrioityDate']  | formatDate}}</label>
                  </li>
                  <!-- Most Recent Form I-94 Card Number -->
                  <li v-if="dataTabpop['formI94CardNumber'] && dataTabpop['formI94CardNumber'] !=null" style="list-style-type:none; width:33.3% ; height:60px">
                    <p  style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Most Recent Form I-94 Card Number</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop['formI94CardNumber'] }}</label>
                  </li>
                  
                  <li v-if="dataTabpop['residedFromDateinUs'] && dataTabpop['residedFromDateinUs'] !=null" style="list-style-type:none; width:33.3% ; height:80px">
                    <p  style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:15px; height:20px;  margin-bottom:0px; padding-bottom:2px">Date From which you have reside in the USA</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop['residedFromDateinUs'] | fromDate }}</label>
                  </li>
                  <!-- Current Non Immigrant Visa Number -->
                  <li v-if="dataTabpop['nonImmVisaNumber'] && dataTabpop['nonImmVisaNumber'] !=null" style="list-style-type:none; width:33.3% ; height:60px">
                    <p  style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Current Non Immigrant Case Number</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop['nonImmVisaNumber'] }}</label>
                  </li>
                  
                  <li v-if="dataTabpop['classificationCategory'] && dataTabpop['classificationCategory'] !=null &&  checkEmptyObjects(dataTabpop['classificationCategory'])" style="list-style-type:none; width:33.3% ; height:60px">
                    <p  style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Classification</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop['classificationCategory']['name'] }}</label>
                  </li>


                </ul>
                <template v-if="dataTabpop['allCountryIssuedPassports']  && dataTabpop['allCountryIssuedPassports'] !=null && dataTabpop['allCountryIssuedPassports'] !=undefined && dataTabpop['allCountryIssuedPassports'].length>0 && checkEmptyObjects(dataTabpop['allCountryIssuedPassports'])">
                <span style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:13px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">All Countries that have Issued you a currently valid passport </span>
                <ul class="list_items" v-for="cp in dataTabpop['allCountryIssuedPassports']"  :key="cp" style="display:flex; flex-wrap: wrap; padding:0px; margin:0px">
                  <li v-if="cp['country']" style="list-style-type:none; width:33.3% ; height:60px">
                    <p  style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Country</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{cp['country']['name']}}</label>
                  </li>
                  <li v-if="cp['number']" style="list-style-type:none; width:33.3% ; height:60px">
                    <p  style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Passport Number</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{cp['number']}}</label>
                  </li>
                  <li v-if="cp['issuedDate']" style="list-style-type:none; width:33.3% ; height:60px">
                    <p  style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Issued Date</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{cp['issuedDate'] | formatDate}}</label>
                  </li>
                  <li v-if="cp['expiryDate']" style="list-style-type:none; width:33.3% ; height:60px">
                    <p  style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Expiration Date</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{cp['expiryDate'] | formatDate}}</label>
                  </li>
                </ul>
                </template>
                
                <div class="gc_app_details-list" v-if="dataTabpop['areYouInpectedByImmOfficer']">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Were you inspected by any Immigration Officer?</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px" class="yes_option" v-if="dataTabpop['areYouInpectedByImmOfficer']=='Yes'" >Yes</label>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px" class="no_option" v-if="dataTabpop['areYouInpectedByImmOfficer']=='No'">No</label>
                </div>
                <div class="gc_app_details-list"  v-if="dataTabpop['everIssuedEADFromUscis']" >
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Have you ever Been Issued an Employment Authorization document (EAD) from the USCIS?</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px" class="yes_option" v-if="dataTabpop['everIssuedEADFromUscis']=='Yes'" >Yes</label>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px" class="no_option" v-if="dataTabpop['everIssuedEADFromUscis']=='No'">No</label>
                </div>
                <div class="gc_app_details-list" v-if="dataTabpop['enterByVisaWaiverProgram']" >
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Did You Enter in US Under Case Waiver Program</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px" class="yes_option" v-if="dataTabpop['enterByVisaWaiverProgram']=='Yes'" >Yes</label>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px" class="no_option" v-if="dataTabpop['enterByVisaWaiverProgram']=='No'">No</label>
                </div>
                <template v-if="dataTabpop['holdPermResidenceInOtherCountry']">
                <div class="gc_app_details-list" v-if="dataTabpop['holdPermResidenceInOtherCountry']" >
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Do you hold "Permanent Residence" in other country?</p>
                   <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px" class="yes_option" v-if="dataTabpop['holdPermResidenceInOtherCountry']=='Yes'" >Yes</label>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px" class="no_option" v-if="dataTabpop['holdPermResidenceInOtherCountry']=='No'">No</label>
                </div>
                <div class="gc_app_details-list" v-if="dataTabpop['permResidenceInOtherCountry'] && checkEmptyObjects(dataTabpop['permResidenceInOtherCountry'])">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:13px; height:13px; margin-bottom:0px; padding-bottom:5px">Country</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop['permResidenceInOtherCountry']['name']}}</label>
                </div>
                </template>
                <div class="gc_app_details-list" v-if="dataTabpop['everApplyPermResidentStatus']">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:14px; height:25px; margin-bottom:0px; padding-bottom:5px">Have you ever applied for AOS in the U.S. or an Immigrant case at an U.S. Embassy/Consulate to obtain permanent resident status before?</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px" class="yes_option" v-if="dataTabpop['everApplyPermResidentStatus']=='Yes'" >Yes</label>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px" class="no_option" v-if="dataTabpop['everApplyPermResidentStatus']=='No'">No</label>
                </div>
               </div>
              
             
          </div>
      </div>  
      <!--END immigration--->
      
      <!--occupational_skills--->
      <div class="gc_appcontent_right" >
        <h5 class="print_title" style=" font-size:20px; font-family: 'Arial', sans-serif; font-weght:600; padding:0px 0; margin-bottom:10px" >Occupational Skills</h5>
        <div class="gc_app_details-cnt">
          
              <div class="gc_scrool-cnt">
                
                <div class="gc_scrool-cnt">
                  <template v-if="dataTabpop['education'] && dataTabpop['education'].length>0 && checkEmptyObjects(dataTabpop['education'])" >
                  <h6 style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:13px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">Education</h6>
                <ul class="education" v-for=" edu in dataTabpop['education']" :key="edu" style="display:flex; flex-wrap: wrap; padding:0px; margin:0px" >
                  <li v-if="edu['schoolName']" style="list-style-type:none; width:33.3% ; height:60px">
                    <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">School Name</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{ edu['schoolName']}}</label>                                      
                  </li>
                  <li v-if="edu['degree']" style="list-style-type:none; width:33.3% ; height:60px">
                    <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Degree</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{ edu['degree']}}</label>
                  </li>
                  <li v-if="edu['fieldOfStudy']" style="list-style-type:none; width:33.3% ; height:60px">
                    <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Field of Study</p>
                      <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{ edu['fieldOfStudy']}}</label>
                  </li>
                  <li v-if="edu['fromDate']" style="list-style-type:none; width:33.3% ; height:60px">
                    <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">From Date</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{ edu['fromDate'] | formatDate}}</label>
                  </li>
                  <li v-if="edu['toDate']" style="list-style-type:none; width:33.3% ; height:60px">
                    <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">To Date</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{ edu['toDate'] | formatDate}}</label>
                  </li>
              </ul>
                  </template>

              <ul style="display:flex; flex-wrap: wrap; padding:0px; margin:0px" class="w-full"  v-if=" (dataTabpop['currentJobTitle'] != null && dataTabpop['currentJobTitle'] !='' ) ||  ( dataTabpop['currentJobTitle'] != null && dataTabpop['currentJobTitle'] !='' ) || ( dataTabpop['currentAnnualSalary'] != null && dataTabpop['currentAnnualSalary'] !='' )">
                <li class="width50" v-if="dataTabpop['currentJobTitle'] !=null && dataTabpop['currentJobTitle'] !=''" style="list-style-type:none; width:50% ; height:60px">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Current Job Title</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{ dataTabpop['currentJobTitle']}}</label>
                </li>
                <li class="width50" v-if="dataTabpop['employerName']!= null && dataTabpop['employerName']!=''" style="list-style-type:none; width:50% ; height:60px">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Current Employer Name</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{ dataTabpop['currentJobTitle']}}</label>
                </li>

                <li class="width50" v-if="dataTabpop['currentAnnualSalary'] != null && dataTabpop['currentAnnualSalary'] !='' " style="list-style-type:none; width:50% ; height:60px">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Current Annual Salary</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{ dataTabpop['currentAnnualSalary'] | formatprice}}</label>
                </li>

                <li class="width50" style="list-style-type:none; width:50% ; height:60px" v-if="dataTabpop['employerAddress'] ">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Employer Address</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{ dataTabpop['employerAddress'] }}</label>
                </li>
              </ul>
              <template v-if=" dataTabpop['employmentHistoryUSAbroad'] !=null && checkEmptyObjects(dataTabpop['employmentHistoryUSAbroad']) && dataTabpop['employmentHistoryUSAbroad'].length>0">
              
              <h6 style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:13px; line-height:15px; height:25px; margin-bottom:0px; padding-bottom:0px">The following information about your current and past employment for the past five years in the U.S and aboard starting with your most current Job</h6>
              <ul style="display:flex; flex-wrap: wrap; padding:0px; margin:0px" class="list_items" v-for="emp in dataTabpop['employmentHistoryUSAbroad'] " :key='emp' >
                <li v-if=" emp['employerName'] !=null  && emp['employerName']" style="list-style-type:none; width:33.3% ; height:60px" >
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Name of Employer</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{emp['employerName']}}</label>                </li>
                
                <li v-if=" emp['occupation'] !=null  && emp['occupation']" style="list-style-type:none; width:33.3% ; height:60px">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Occupation</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{emp['occupation']}}</label>
                </li>                
                <li  v-if=" emp['fromDate'] !=null  && emp['fromDate']" style="list-style-type:none; width:33.3% ; height:60px">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">From Date</p>
                  {{emp['fromDate'] | formatDate}}
                </li>
                <li  v-if=" emp['toDate'] !=null  && emp['toDate']" style="list-style-type:none; width:33.3% ; height:60px">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">To Date</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{emp['toDate'] | formatDate}}</label>
                </li>
                <li v-if="emp['address'] &&  emp['address']['line1'] !=null && emp['address']['line1'] !=''" style="list-style-type:none; width:33.3% ; height:60px">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Street Address</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{ emp['address']['line1']}}</label>
                </li>
                <li v-if="emp['address'] &&  emp['address']['line2'] !=null && emp['address']['line2'] !=''" style="list-style-type:none; width:33.3% ; height:60px">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Apt, Suite</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{ emp['address']['line2']}}</label>
                </li>
                <!-- <li v-if="emp['address'] !=null || (emp['address']['city'] !=null) || emp['address']['state'] !=null || emp['address']['country'] !=null
                
                " >
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">Location</label>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">
                    {{emp['address']['city']['name']}}
                    {{ emp['address']['city']['name']&& emp['address']['state']? ', '+emp['address']['state']['name']:'' }}
                      {{ emp['address']['state']['name']&& emp['address']['country']? ' , '+emp['address']['country']['name']:'' }}

                  </label>
                </li> -->
                <li v-if="emp['address'] && emp['address']['zipcode'] !=null && emp['address']['zipcode'] !='' " style="list-style-type:none; width:33.3% ; height:60px">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Zip Code</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{ emp['address']['zipcode']}}</label>
                </li> 
              </ul>

              </template>
              <template v-if="dataTabpop['lastEmployerOutsideUS'] != null && checkEmptyObjects(dataTabpop['lastEmployerOutsideUS']) " >
              <h6 style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:13px; line-height:15px; height:25px; margin-bottom:0px; padding-bottom:0px">Last Employer outside of the United States for more than one year</h6>
              <ul class="list_items" style="display:flex; flex-wrap: wrap; padding:0px; margin:0px">
                <li v-if=" dataTabpop['lastEmployerOutsideUS']['employerName'] !=null  && dataTabpop['lastEmployerOutsideUS']['employerName']" style="list-style-type:none; width:33.3% ; height:60px">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Name of Employer</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop['lastEmployerOutsideUS']['employerName']}}</label>
                </li>
                
                <li v-if=" dataTabpop['lastEmployerOutsideUS']['occupation'] !=null  && dataTabpop['lastEmployerOutsideUS']['occupation']" style="list-style-type:none; width:33.3% ; height:60px">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Occupation</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop['lastEmployerOutsideUS']['occupation']}}</label>
                </li>
                
                <li  v-if=" dataTabpop['lastEmployerOutsideUS']['fromDate'] !=null  && dataTabpop['lastEmployerOutsideUS']['fromDate']" style="list-style-type:none; width:33.3% ; height:60px">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">From Date</p>
                  {{dataTabpop['lastEmployerOutsideUS']['fromDate'] | formatDate}}
                </li>
                <li  v-if=" dataTabpop['lastEmployerOutsideUS']['toDate'] !=null  && dataTabpop['lastEmployerOutsideUS']['toDate']" style="list-style-type:none; width:33.3% ; height:60px">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">To Date</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop['lastEmployerOutsideUS']['toDate'] | formatDate}}</label>
                </li>
                <li v-if="dataTabpop['lastEmployerOutsideUS']['address'] &&  dataTabpop['lastEmployerOutsideUS']['address']['line1'] !=null && dataTabpop['lastEmployerOutsideUS']['address']['line1'] !=''" style="list-style-type:none; width:33.3% ; height:60px">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Street Address</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{ dataTabpop['lastEmployerOutsideUS']['address']['line1']}}</label>
                </li>
                <li v-if="['address'] &&  dataTabpop['lastEmployerOutsideUS']['address']['line2'] !=null && dataTabpop['lastEmployerOutsideUS']['address']['line2'] !=''" style="list-style-type:none; width:33.3% ; height:60px">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Apt, Suite</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{ dataTabpop['lastEmployerOutsideUS']['address']['line2']}}</label>
                </li>
                  <li v-if="dataTabpop['lastEmployerOutsideUS']['address'] && dataTabpop['lastEmployerOutsideUS']['address']['zipcode'] !=null && dataTabpop['lastEmployerOutsideUS']['address']['zipcode'] !='' " style="list-style-type:none; width:33.3% ; height:60px">
                  <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Zip Code</p>
                  <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{ dataTabpop['lastEmployerOutsideUS']['address']['zipcode']}}</label>
                </li> 
              </ul>
              
              </template>



              
              </div>

              
              </div>
            
          
        </div>
      </div> 
      
      <!-----END occupational_skills--->

      <!----assets_financials--->
      <div class="gc_appcontent_right" >
        <h5 class="print_title" style=" font-size:20px; font-family: 'Arial', sans-serif; font-weght:600; padding:0px 0; margin-bottom:10px">Assets &amp; Financials</h5>
          <div class="gc_app_details-cnt">
            
               <div class="gc_scrool-cnt">
                 <template v-if=" dataTabpop['assets'] !=undefined && dataTabpop['assets']!=null && dataTabpop['assets'].length>0  && checkEmptyObjects(dataTabpop['assets'])">
                  <h6 style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:13px; line-height:15px; height:25px; margin-bottom:0px; padding-bottom:0px">Assets</h6>
                  <ul v-for=" ( asst , indx) in dataTabpop['assets']" :key="indx" style="display:flex; flex-wrap: wrap; padding:0px; margin:0px" >
                    <li v-if="asst['aType']" style="list-style-type:none; width:33.3% ; height:60px">
                      <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Type</p>
                      <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{asst['aType']['name']}}</label>                                        
                    </li>
                    <li v-if="asst['nameOfHolder']" style="list-style-type:none; width:33.3% ; height:60px">
                      <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Name of the Holder</p>
                      <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{asst['nameOfHolder']}}</label>
                    </li>
                    <li v-if="asst['amount']" style="list-style-type:none; width:33.3% ; height:60px">
                      <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Amount</p>
                      <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{asst['amount'] | formatprice}}</label>
                    </li> 
                </ul>
                </template>
                <h6 style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:13px; line-height:15px; height:25px; margin-bottom:0px; padding-bottom:0px">Financials</h6>
                <ul class="list_items" style="display:flex; flex-wrap: wrap; padding:0px; margin:0px">
                  <li v-if="dataTabpop['depositsInUSBank']" style="list-style-type:none; width:33.3% ; height:60px">
                    <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Deposits in Bank in the USA</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop['depositsInUSBank'] | formatprice}}</label>
                  </li>
                  <li v-if="dataTabpop['valueOfRealEstate']" style="list-style-type:none; width:33.3% ; height:60px">
                    <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Value of Real Estate, If Owned</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop['valueOfRealEstate'] | formatprice}}</label>
                  </li>
                  <li v-if="dataTabpop['cashSurrenderValueOfLifeInsurance']" style="list-style-type:none; width:33.3% ; height:60px">
                    <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Cash Surrender Value of Life Insurance</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{ dataTabpop['cashSurrenderValueOfLifeInsurance'] | formatprice}}</label>
                  </li>

                  <li v-if="dataTabpop['reasonableValueProperty']" style="list-style-type:none; width:33.3% ; height:60px" >
                    <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Reasonable Value of Personal Property</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{ dataTabpop['reasonableValueProperty'] | formatprice}}</label>
                  </li>
                  <li style="list-style-type:none; width:33.3% ; height:60px">
                    <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Market Value of Stocks and Bons</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{ dataTabpop['marketValueOfStocksBonds'] | formatprice}}</label>
                  </li>
                  
                  <li v-if="dataTabpop['creditScore']" style="list-style-type:none; width:33.3% ; height:60px">
                    <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Credit Score</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{ dataTabpop['creditScore'] | formatprice}}</label>
                  </li>
                  
                  
                  
                  <li v-if="dataTabpop['amountOfMortgageOnProperty']" style="list-style-type:none; width:33.3% ; height:60px">
                    <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Amount of Mortgage on the Property</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{ dataTabpop['amountOfMortgageOnProperty'] | formatprice}}</label>
                  </li>

                  

                  <li v-if="dataTabpop['sumOfLifeInsurance']" style="list-style-type:none; width:33.3% ; height:60px">
                    <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Sum of Life Insurance</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{ dataTabpop['sumOfLifeInsurance'] | formatprice}}</label>
                  </li>
                  <template v-if="checkEmptyObjects(dataTabpop['healthInsurance']) && dataTabpop['healthInsurance']">
                  <li style="list-style-type:none; width:33.3% ; height:60px">
                    <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Health Insurance Premium</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop['healthInsurance']['premium'] | formatprice }}</label>
                  </li>
                  <li v-if=" dataTabpop['healthInsurance'] && dataTabpop['healthInsurance']['renewalDate']" style="list-style-type:none; width:33.3% ; height:60px">
                    <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Health Insurance Renewal Date</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop['healthInsurance']['renewalDate']  | formatDate}}</label>
                  </li>
                  </template>
                </ul>
                <template v-if="checkEmptyObjects(dataTabpop['liabilitiesDebts']) && dataTabpop['liabilitiesDebts'] !=undefined && dataTabpop['liabilitiesDebts'] !=null && dataTabpop['liabilitiesDebts'].length>0">
                <h6 style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:13px; line-height:15px; height:25px; margin-bottom:0px; padding-bottom:0px">Your Liabilities/Debts</h6>
                <ul style="display:flex; flex-wrap: wrap; padding:0px; margin:0px" class="liabilities" v-for="liabilitiesDebt  in dataTabpop['liabilitiesDebts']" :key="liabilitiesDebt">
                  <li style="list-style-type:none; width:33.3% ; height:60px" v-if="liabilitiesDebt['lType'] && liabilitiesDebt['lType']['name'] && liabilitiesDebt['lType']['name']!=null && liabilitiesDebt['lType']['name']!=''">
                    <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Type</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{ liabilitiesDebt['lType']['name']}}</label>
                  </li>
                  <li style="list-style-type:none; width:33.3% ; height:60px" v-if="liabilitiesDebt['amount'] && liabilitiesDebt['amount'] !='' && liabilitiesDebt['amount'] !=null">
                    <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Amount</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{ liabilitiesDebt['amount'] | formatprice}}</label>
                  </li>                                      
                </ul>
                </template>
                <template v-if="dataTabpop['publicBenefits'] !=null && dataTabpop['publicBenefits'] !=undefined && dataTabpop['publicBenefits'].length>0">
                <h6 style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:13px; line-height:15px; height:25px; margin-bottom:0px; padding-bottom:0px">Public Benefits</h6>
                <ul class="benefits" style="display:flex; flex-wrap: wrap; padding:0px; margin:0px">
                  <li v-for="benf  in dataTabpop['publicBenefits']" :key="benf" style="list-style-type:none; width:100% ;"> 
                    <label style="font-family: 'Arial', sans-serif; font-weight:normal; color:#1D202C; font-size:13px; line-height:15px; height:18px; margin-bottom:0px; padding-bottom:0px">{{ getPubliBenfitName(benf)}}</label>
                  </li>
                   
                </ul> 
                </template>
               </div>
              
           
          </div>
      </div> 
      <!----END assets_financials---->

      <!----parents--->
      <div class="gc_appcontent_right" >
        <h5 class="print_title" style=" font-size:20px; font-family: 'Arial', sans-serif; font-weght:600; padding:0px 0; margin-bottom:10px" v-if="checkEmptyObjects(dataTabpop['father'])|| checkEmptyObjects(dataTabpop['mother'])">Parents</h5>
          <div class="gc_app_details-cnt">
            
               <div class="gc_scrool-cnt"  v-if="dataTabpop['father'] && (dataTabpop['father']['firstName'] || dataTabpop['father']['lastName']) && checkEmptyObjects(dataTabpop['father'])">
                
                  <h6 style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:13px; line-height:15px; height:25px; margin-bottom:0px; padding-bottom:0px">Father</h6>
                  <ul class="parentname" style="display:flex; flex-wrap: wrap; padding:0px; margin:0px">
                    <li v-if="dataTabpop['father']['firstName']" style="list-style-type:none; width:33.3% ; height:60px">
                      <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">First Name</p>
                      <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop['father']['firstName']}}</label>
                    </li>
                    <li v-if="dataTabpop['father']['middleName']" style="list-style-type:none; width:33.3% ; height:60px">
                      <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Middle Name</p>
                      <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop['father']['middleName']}}</label>
                    </li>
                    <li v-if="dataTabpop['father']['lastName']" style="list-style-type:none; width:33.3% ; height:60px">
                      <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Last Name</p>
                      <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop['father']['lastName']}}</label>
                    </li>
                    <li v-if="dataTabpop['father']['birthFirstName'] || dataTabpop['father']['birthLastName']" style="list-style-type:none; width:33.3% ; height:60px">
                      <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Name at Birth</p>
                      <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop['father']['birthFirstName']}} {{dataTabpop['father']['birthLastName']}} </label>
                    </li>
                  </ul>
                  <ul style="display:flex; flex-wrap: wrap; padding:0px; margin:0px">
                    <li v-if="dataTabpop['father']['placeOfBirth'] && checkEmptyObjects(dataTabpop['father']['placeOfBirth'])" style="list-style-type:none; width:33.3% ; height:60px">
                      <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Place of Birth</p>
                      <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px"> 
                         {{ dataTabpop['father']['placeOfBirth'] | addformat}}
                          </label>
                    </li>
                    <li v-if="dataTabpop['father']['currentResidence'] && checkEmptyObjects(dataTabpop['father']['currentResidence'])" style="list-style-type:none; width:33.3% ; height:60px">
                      <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Current Residence</p>
                      <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">
                        {{ dataTabpop['father']['currentResidence'] | addformat}}
                         <!-- {{dataTabpop['father']['currentResidence']['location']['name']}}
                        {{  dataTabpop['father']['currentResidence']['location']['name'] && dataTabpop['father']['currentResidence']['state']['name']?','+dataTabpop['father']['currentResidence']['state']['name']:''}}
                        {{  dataTabpop['father']['currentResidence']['state']['name'] && dataTabpop['father']['currentResidence']['country']['name']?','+dataTabpop['father']['currentResidence']['country']['name']:''}}
                          -->

                      </label>
                    </li>
                    <li v-if="dataTabpop['father']['dateOfBirth']" style="list-style-type:none; width:33.3% ; height:60px">
                      <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Date of Birth</p>
                      <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop['father']['dateOfBirth'] | formatDate}}</label>
                    </li>
                  </ul>
                  <div class="gc_app_details-list" v-if="dataTabpop['father']['everUSCitizen']" >
                    <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Is Your Father now or was he ever A U.S Citizen?</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px" v-if="dataTabpop['father']['everUSCitizen']=='Yes'" class="yes_option">Yes</label>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px" v-if="dataTabpop['father']['everUSCitizen'] !='Yes'" class="no_option">No</label>

                    <template v-if="dataTabpop['father']['everUSCitizen']=='Yes'">
                    <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px" class="mart15">From When Your Father now or was he ever A U.S Citizen</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{ dataTabpop['father']['usCitizenSince'] | formatDate}}</label>
                    </template>
                  </div>
               </div>
               <div class="gc_scrool-cnt"  v-if="dataTabpop['mother'] && (dataTabpop['mother']['firstName'] || dataTabpop['mother']['lastName'])  && checkEmptyObjects(dataTabpop['mother'])">
                 
                  <h6 style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:13px; line-height:15px; height:25px; margin-bottom:0px; padding-bottom:0px">Mother</h6>
                  <ul class="parentname" style="display:flex; flex-wrap: wrap; padding:0px; margin:0px">
                        <li v-if="dataTabpop['mother']['firstName']" style="list-style-type:none; width:33.3% ; height:60px">
                        <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">First Name</p>
                        <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop['mother']['firstName']}}</label>
                        </li>
                        <li v-if="dataTabpop['mother']['middleName']" style="list-style-type:none; width:33.3% ; height:60px">
                        <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Middle Name</p>
                        <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop['mother']['middleName']}}</label>
                        </li>
                        <li v-if="dataTabpop['mother']['lastName']" style="list-style-type:none; width:33.3% ; height:60px">
                        <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Last Name</p>
                        <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop['mother']['lastName']}}</label>
                        </li>
                      
                    <li v-if="dataTabpop['mother']['birthFirstName'] || dataTabpop['mother']['birthLastName']"  style="list-style-type:none; width:33.3% ; height:60px">
                      <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Name at Birth</p>
                      <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop['mother']['birthFirstName']}} {{dataTabpop['mother']['birthLastName']}} </label>
                    </li>
                  </ul>
                  <ul style="display:flex; flex-wrap: wrap; padding:0px; margin:0px">
                    <li v-if="dataTabpop['mother']['placeOfBirth'] && checkEmptyObjects(dataTabpop['mother']['placeOfBirth']) " style="list-style-type:none; width:33.3% ; height:60px">
                      <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Place of Birth</p>
                      <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px"> 

                         {{ dataTabpop['mother']['placeOfBirth'] | addformat}}
                        <!-- {{dataTabpop['mother']['placeOfBirth']['location']['name']}}
                        {{  dataTabpop['mother']['placeOfBirth']['location']['name'] && dataTabpop['mother']['placeOfBirth']['state']['name']?','+dataTabpop['mother']['placeOfBirth']['state']['name']:''}}
                       
                        {{  dataTabpop['mother']['placeOfBirth']['state']['name'] && dataTabpop['mother']['placeOfBirth']['country']['name']?','+dataTabpop['mother']['placeOfBirth']['country']['name']:''}}
                          -->
                          </label>
                    </li>
                    <li v-if="dataTabpop['mother']['currentResidence'] && checkEmptyObjects(dataTabpop['mother']['currentResidence'])" style="list-style-type:none; width:33.3% ; height:60px">
                      <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Current Residence</p>
                      <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">
                        
                        {{ dataTabpop['mother']['currentResidence'] | addformat}}

                         

                      </label>
                    </li>
                    <li v-if="dataTabpop['mother']['dateOfBirth']" style="list-style-type:none; width:33.3% ; height:60px">
                      <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:20px; margin-bottom:0px; padding-bottom:5px">Date of Birth</p>
                      <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{dataTabpop['mother']['dateOfBirth'] | formatDate}}</label>
                    </li>
                  </ul>
                  <div class="gc_app_details-list" v-if="dataTabpop['mother']['everUSCitizen'] && dataTabpop['mother']['everUSCitizen']=='Yes'" >
                    <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px">Is Your Mother now or was he ever A U.S Citizen?</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px" v-if="dataTabpop['mother']['everUSCitizen'] =='Yes'" class="yes_option">Yes</label>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px" v-if="dataTabpop['mother']['everUSCitizen'] !='Yes'" class="no_option">No</label>

                    <template v-if="dataTabpop['mother']['everUSCitizen']=='Yes'">
                    <p style="display:block; font-family: 'Arial', sans-serif; color:#5B5D66; font-size:13px; line-height:12px; height:13px; margin-bottom:0px; padding-bottom:5px" class="mart15">From When Your Father now or was he ever A U.S Citizen</p>
                    <label style="font-family: 'Arial', sans-serif; font-weight:600; color:#1D202C; font-size:15px; line-height:15px; height:15px; margin-bottom:0px; padding-bottom:0px">{{ dataTabpop['mother']['usCitizenSince'] | formatDate}}</label>
                    </template>
                  </div>
               </div>
            
          </div>
      </div> 
      <!----END parents---->

        

      </div>
      </div>
</template>

 <style>
 /* @font-face {
    font-family: 'robotobold';
    src: url('../assets/fonts/roboto-bold_1.woff2') format('woff2'),
         url('../assets/fonts/roboto-bold_1.woff') format('woff');
    font-weight: normal;
    font-style: normal;

} */

li {list-style-type:none !important;}

</style>


<script> 

import JQuery from "jquery";

export default {
  components: {
     
  },
  name: "app",
  props:{
    dataTabpop:null,
    blockName:{
      type:String,
      default:'Principal Applicant'
    },
    isloaded:false,
    //petition:[],
    publicbenefits:{type:Array,default:[]},
    allOtherNamesUsedValid:{type:Boolean , default:true },
    applicationRequired:{type:Boolean , default:false },
  },
  methods:{

      checkEmptyObjects(CObject){
       var bool = false;
            if(CObject == null || CObject == undefined ) {
         return bool;
       }
      Object.keys(CObject).forEach(function (key, keyIndex) {

          if(CObject[key]!=null && typeof CObject[key] === 'object' && CObject[key] !== null
){
                       Object.keys(CObject[key]).forEach(function (subkey, subkeyIndex) {
   if(subkey=='_id' || subkey=='id'){

   }else{
       if(CObject[key] && CObject[key][subkey] && typeof CObject[key][subkey] === 'object' && CObject[key][subkey] !== null){
                       Object.keys(CObject[key][subkey]).forEach(function (ssubkey, ssubkeyIndex) {
                              if(ssubkey=='_id' || ssubkey=='id'){

   }else{

       
              if(CObject[key][subkey][ssubkey]!=null &&  CObject[key][subkey][ssubkey]!=undefined &&  CObject[key][subkey][ssubkey]!='' ){
          bool = true;
           
       }

   }
                           
                       })


       }else{

              if(CObject[key] && CObject[key][subkey] &&  CObject[key][subkey]!=null &&  CObject[key][subkey]!=undefined &&  CObject[key][subkey]!='' ){
          bool = true;
           
       }

       }

    


   }


         })

          }else{

              if(CObject[key]!=null  && CObject[key]!='' ){


                    bool = true;
              }


          }



      })
        return bool;
      },
    
     getPubliBenfitName(id){

       let dt = _.find(this.publicbenefits ,(obj)=>{
           return obj['id']=id
       })
       if(dt){
         return dt['name'];

       }else{
         return '';
       }

     },
     
   },
  
  data: () => ({
    printTemplateData:[],
   
     // petition: null,
          
  }),
  mounted(){
   //alert(JSON.stringify(this.dataTabpop));
  }
 
}
 
</script>
